

# Generated at 2022-06-22 14:22:34.448761
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # TODO: more test cases
    assert ansible_native_concat('') is None
    assert ansible_native_concat('x') == 'x'
    assert ansible_native_concat('1') == 1
    assert ansible_native_concat('-x') == -1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat('x', 'y') == 'xy'
    assert ansible_native_concat(['x', 'y']) == 'xy'
    assert ansible_native_concat('x', 'y', 'z') == 'xyz'
    assert ansible_native_concat(['x', 'y', 'z']) == 'xyz'

# Generated at 2022-06-22 14:22:41.718415
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Test False

    assert ansible_native_concat(False) is False

    # Test True

    assert ansible_native_concat(True) is True

    # Test None

    assert ansible_native_concat(None) is None

    # Test strings

    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat('foo') == 'foo'
    assert ansible_native_concat(u'foo') == 'foo'
    assert ansible_native_concat(['foo', 'bar', 'baz']) == 'foobarbaz'
    assert ansible_native_concat(u'foo') == 'foo'
    assert ansible_native_con

# Generated at 2022-06-22 14:22:48.826547
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(iter([])) is None
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['a']) == u'a'
    assert ansible_native_concat(['a', 'b']) == u'ab'
    assert ansible_native_concat(['1', '2', '3']) == 123
    assert ansible_native_concat(['1', '2', '3', 'x']) == u'123x'
    assert ansible_native_concat(['1', '2', '3', 'x']) == u'123x'

# Generated at 2022-06-22 14:23:01.969131
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2
    from ansible.module_utils.common.text.converters import (
        container_to_text
    )

    jenv = jinja2.Environment()
    jenv.globals['ansible_native_concat'] = ansible_native_concat


# Generated at 2022-06-22 14:23:13.892306
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import Environment
    env = Environment(extensions=['jinja2.ext.do'])
    env.globals['ansible_native_concat'] = ansible_native_concat


# Generated at 2022-06-22 14:23:27.237868
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['1']) == '1'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat(('a', 'b')) == 'ab'
    assert ansible_native_concat(('a', u'b')) == u'ab'
    assert ansible_native_concat([u'a', 'b']) == u'ab'

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == 12
    assert ansible_native_concat((1, 2)) == '12'
    assert ansible_native_concat((1, '2')) == '12'


# Generated at 2022-06-22 14:23:36.066158
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test all combinations of strings, trailing newline, indentation
    # and escaped newline, as well as an empty input
    raw = dict()
    raw[''] = ''
    raw['a'] = 'a'
    raw['a\n'] = 'a\n'
    raw['a\n\n'] = 'a\n\n'
    raw['a\nb'] = 'a\nb'
    raw['a\nb\n'] = 'a\nb\n'
    raw['\na'] = '\na'
    raw['\na'] = '\na'
    raw['\na\n'] = '\na\n'
    raw['\na\n\n'] = '\na\n\n'
    raw['\na\nb'] = '\na\nb'

# Generated at 2022-06-22 14:23:47.742312
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.test.unit.test_loader import LoaderModule
    from ansible.template import Templar

    import unittest
    from io import StringIO
    import os
    import sys

    loader_mock = LoaderModule()
    sys.modules['ansible.plugins.loader'] = loader_mock

    class AnsibleNativeConcatTest(unittest.TestCase):
        '''Unit test class for ansible_native_concat'''
        def setUp(self):
            self.constructor = AnsibleConstructor(templar=Templar(loader=loader_mock), vault_secrets=None)

        def tearDown(self):
            self.constructor = None


# Generated at 2022-06-22 14:23:57.029628
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def check(template, result):
        try:
            compiled_template = jinja2.Template(template)
        except jinja2.TemplateSyntaxError as e:
            raise AssertionError(
                'Template failed to compile: %s (%s)' % (template, e)
            )

        try:
            out = compiled_template.render()
        except jinja2.UndefinedError as e:
            raise AssertionError(
                'Template raised exception: %s (%s)' % (template, e)
            )

        expected = container_to_text(result)
        if out != expected:
            raise AssertionError(
                'Expected %s: got %s' % (expected, out)
            )

    # Check simple concatenation

# Generated at 2022-06-22 14:24:03.899044
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # class StrictUndefined(Undefined):
    #     def __nonzero__(self):
    #         raise UndefinedError('evaluation of undefined value')
    strict_undefined = type('StrictUndefined', (object,), {
        '__nonzero__': lambda *args, **kwargs: 'UndefinedError("evaluation of undefined value")',
    })

# Generated at 2022-06-22 14:24:17.153670
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == u'12'
    assert ansible_native_concat([1, 2, 3]) == u'123'
    assert ansible_native_concat([u'1', u'2', u'3']) == u'123'
    assert ansible_native_concat([1, u'2', u'3']) == u'123'
    assert ansible_native_concat([u'1', 2, u'3']) == u'123'
    assert ansible_native_concat([u'1', u'2', 3]) == u'123'
    assert ansible_native_concat([1, [2], 3]) == u

# Generated at 2022-06-22 14:24:29.070089
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins
    from ansible.parsing.yaml import objects
    from ansible.utils.unsafe_proxy import wrap_var

    # Regular python data structure used for testing
    d = {
        'foo': 'bar',
        'bar': {
            'baz': 'foo',
        },
    }
    d2 = {
        'foo': 'bar',
        'bar': {
            'baz': 'foo',
        },
    }

    fail_on_undefined = builtins.__dict__['_fail_on_undefined'].__get__(None, builtins.__dict__)

    assert fail_on_undefined(d) == d

# Generated at 2022-06-22 14:24:41.254516
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test string concatenation
    nodes = [NativeJinjaText(u'foo'), NativeJinjaText(u'bar')]
    assert ansible_native_concat(nodes) == u'foobar'

    # Test literal_eval of concatenated strings
    nodes = [NativeJinjaText(u'[1, 2, '), NativeJinjaText(u'3]')]
    assert ansible_native_concat(nodes) == [1, 2, 3]

    # Test concatenation of mixed objects
    nodes = [NativeJinjaText(u'foo'), NativeJinjaText(u'{% foo %}'), NativeJinjaText(u'bar')]
    assert ansible_native_concat(nodes) == u'foo{% foo %}bar'

    # Test conc

# Generated at 2022-06-22 14:24:49.040544
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # pylint: disable=unused-variable,expression-not-assigned,unused-argument
    class A(object):
        def __init__(self, value):
            self.value = value
        def __repr__(self):
            return 'A({0})'.format(self.value)
        def __add__(self, other):
            return A(self.value + other.value)
    a1 = A(1)
    a2 = A(2)
    a3 = A(3)

# Generated at 2022-06-22 14:24:59.281238
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class TestText(text_type):
        def __repr__(self):
            return 'TestText'

    assert ansible_native_concat([text_type()]) == ''
    assert ansible_native_concat([TestText()]) == 'TestText'
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([StrictUndefined]) is StrictUndefined

    assert ansible_native_concat([]) is None

    assert ansible_native_concat(map(text_type, ['abc', 'def'])) == 'abcdef'
    assert ansible_native_concat(map(text_type, ['abc', 1, 'def'])) == 'abc1def'

# Generated at 2022-06-22 14:25:10.783346
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # No arguments
    assert ansible_native_concat(list()) is None

    # One argument, not a string
    data = {'foo': 1, 'bar': 2}
    assert ansible_native_concat([data]) == data

    # One argument, a string
    data = 'foo'
    assert ansible_native_concat([data]) == data

    # One argument, an AnsibleVaultEncryptedUnicode
    data = AnsibleVaultEncryptedUnicode('foo')
    assert isinstance(ansible_native_concat([data]), object)

    # One argument, a NativeJinjaText
    data = NativeJinjaText('foo')
    assert ansible_native_concat([data]) == data

    # Two or more arguments
    data = ['foo', 1, 'bar', 2]


# Generated at 2022-06-22 14:25:20.330951
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat([7]) == 7
    assert ansible_native_concat([False]) == False
    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([u'foo', 7]) == u'foo7'
    assert ansible_native_concat([u'foo', 7]) == u'foo7'
    assert ansible_native_concat([u'foo', b'bar']) == u'foobar'

# Generated at 2022-06-22 14:25:25.136894
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([u"foo"]) == u"foo"
    assert ansible_native_concat([u"foo", u"bar"]) == u"foobar"



# Generated at 2022-06-22 14:25:37.455070
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(["a", "b", "c"]) == u"abc"
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat([1, 2, 3.5, "4"]) == 123.54
    assert ansible_native_concat([{'a': 1}, {'b': 2}]) == [{'a': 1}, {'b': 2}]
    assert ansible_native_concat([[1, 2], [3, 4]]) == [[1, 2], [3, 4]]
    assert ansible_native_concat([(1, 2), (3, 4)]) == ((1, 2), (3, 4))

# Generated at 2022-06-22 14:25:43.134826
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.validation import check_type_bool
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # Test if concatenated values are evaluated correctly
    data = ansible_native_concat(['-1', '+', '2'])
    assert data == -1 + 2, "Concatenated values are not evaluated correctly"

    # Test if concatenated variables are evaluated correctly
    data = ansible_native_concat([to_text(AnsibleUnicode(u'-1')), to_text(AnsibleUnicode(u'+')), to_text(AnsibleUnicode(u'2'))])
    assert data == u'-1+2', "Concatenated variables are not evaluated correctly"

    # Test if variables in unicode

# Generated at 2022-06-22 14:25:55.432574
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # None should return None
    assert ansible_native_concat([]) is None

    # Strings that can be parsed with literal_eval must be parsed
    assert ansible_native_concat(['2 + 2']) == 4
    assert ansible_native_concat(['[1, 2, 3]']) == [1, 2, 3]
    assert ansible_native_concat(['"foo"']) == "foo"

    # Strings that cannot be parsed with literal_eval must be returned
    # as string
    assert ansible_native_concat(['invalid']) == 'invalid'
    assert ansible_native_concat([u'\u2603']) == u'\u2603'

    # Concatenation of strings should return the concatenated string

# Generated at 2022-06-22 14:26:07.269336
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:26:17.412986
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # These tests are copy-pasted from jinja2 native_concat test case
    # at https://github.com/pallets/jinja/blob/master/tests/test_nativetypes.py
    # except when it comes to returned types.
    # Since Jinja 2.12, literal_eval is called by default to convert string to
    # corresponding type but Ansible always needs to have all types as strings.
    # We have to change those tests that rely on literal_eval to return
    # strings instead of corresponding types (such as int, dict, list).

    # A string test, literal_eval should keep them strings
    assert isinstance(ansible_native_concat(['foo', 'bar']), string_types)
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'

    # A unic

# Generated at 2022-06-22 14:26:30.007913
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1, 2, 3]) == 1
    assert ansible_native_concat([1, 2, 3, 4]) == '1234'
    assert ansible_native_concat(['abcd', 1, 3]) == 'abcd13'
    assert ansible_native_concat(['abcd', 1, 3, 'efgh']) == 'abcd13efgh'
    assert ansible_native_concat(['abc', 1, 3]) == 'abc13'
    assert ansible_native_concat([1, 'abc', 3]) == 1
    assert ansible_native_concat([1, 'abc', 3, 'efgh']) == '1abc3efgh'

# Generated at 2022-06-22 14:26:42.222734
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # simple cases
    assert ansible_native_concat(["a"]) == 'a'
    assert ansible_native_concat(["a", "b"]) == 'ab'
    assert ansible_native_concat([1, "b"]) == 1
    assert ansible_native_concat([1, 2]) == 1
    assert isinstance(ansible_native_concat([1, 2]), int)

    # In Python 3.10+ ast.literal_eval removes leading spaces/tabs from the given string.
    # For backwards compatibility we need to parse the string ourselves without removing leading spaces/tabs.
    assert ansible_native_concat(["42"]) == '42'
    assert ansible_native_concat([4, 2]) == 42

# Generated at 2022-06-22 14:26:50.433813
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test list to string conversion
    assert ansible_native_concat(['foo', 'bar']) == u'foobar'
    assert ansible_native_concat(['foo', ' bar bar ']) == u'foo bar bar '
    assert ansible_native_concat(['foo ', ' bar bar']) == u'foo  bar bar'
    assert ansible_native_concat(['foo ', ' bar bar ', '']) == u'foo  bar bar '
    assert ansible_native_concat(['foo ', ' bar bar ', '', 'baz']) == u'foo  bar bar baz'
    assert ansible_native_concat(['foo', '', 'bar']) == u'foobar'
    assert ansible_native_concat(['  foo  ', ' ', '  bar  ']) == u

# Generated at 2022-06-22 14:27:01.425165
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # TODO: Skip this test for J2_V2 format tests
    #       until we have a native concat function for J2_V2.
    #       See: https://github.com/ansible/ansible/issues/71313

    # Skip for J2_V2 because we don't have a native concat function for that
    # and this test would fail.

    from ansible.plugins.loader import filters_loader
    assert filters_loader.all()['format'] == filters_loader.get('format')

    # Ensure that no leading spaces/tabs are stripped.
    assert ansible_native_concat([u'       hello', u' world']) == u'       hello world'

    val = u'foobar'
   

# Generated at 2022-06-22 14:27:13.285404
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """
    Test for https://github.com/ansible/ansible/issues/70831
    """

    import jinja2

    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['test']) == 'test'
    assert ansible_native_concat(['test', 'test']) == 'testtest'
    assert ansible_native_concat(['1', '2']) == 3

# Generated at 2022-06-22 14:27:18.117595
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:27:29.830436
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.six.moves import cStringIO as StringIO

    # dict, dict
    assert ansible_native_concat([{'a': 1}, {'b': 2}]) == {'a': 1, 'b': 2}

    # string, string
    assert ansible_native_concat([u'a', u'b']) == u'ab'

    # string, list
    assert ansible_native_concat([u'a', [u'b', u'c']]) == u'a[u\'b\', u\'c\']'

    # dict, string
    assert ansible_native_concat([{'a': 1}, u'b']) == {'a': 1}

    # string, dict

# Generated at 2022-06-22 14:27:45.653335
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2

    # Helper function to emulate compiled nodes
    def compile_node(value):
        return jinja2.nodes.Const(value)

    # Tests for invalid inputs
    assert ansible_native_concat(None) == None
    assert ansible_native_concat([]) == None
    # Empty input
    assert ansible_native_concat(iter([])) == None

    # Tests for single node input
    assert ansible_native_concat([compile_node('37')]) == 37
    assert ansible_native_concat([compile_node('abc')]) == 'abc'
    assert ansible_native_concat([compile_node('True')]) is True

# Generated at 2022-06-22 14:27:53.598885
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_list, to_text
    from ansible.module_utils import common
    from io import StringIO
    from tempfile import NamedTemporaryFile
    import json

    # Define some test variables
    test_var1 = 'string1'
    test_var2 = 'string2'
    test_var3 = 'string3'
    test_var4 = 'string4'
    test_var5 = 'string5'
    test_var6 = 'string6'
    test_var7 = 'string7'

    test_list1 = ['list1']
    test_list2 = ['list2']

    test_dict1 = {'key1': 'value1'}
    test_dict2 = {'key2': 'value2'}

   

# Generated at 2022-06-22 14:28:00.296309
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """When an item is the child of a variable and is piped through
    a filter, the result will be a generator.
    """
    assert ansible_native_concat(
        container_to_text("|".join(['item1', 'item2']))
    ) == text_type("item1|item2")

    assert ansible_native_concat(
        container_to_text("|".join(['item1', 'item2']))
        for i in range(0)
    ) == text_type("item1|item2")

    assert ansible_native_concat(
        [container_to_text("|".join(['item1', 'item2'])),
         'item3']
    ) == text_type("item1|item2|item3")

# Generated at 2022-06-22 14:28:09.530175
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([1, 2]) == '12'

    assert ansible_native_concat(['foo', ' ', 'bar', ' baz']) == 'foo bar baz'
    assert type(ansible_native_concat(['foo ', ' bar baz'])) is text_type

    assert ansible_native_concat([1, 2, 3, 4]) == '1234'
    assert type(ansible_native_concat([1, 2, 3, 4])) is text_type

    # Casting a container to text and then parsing it
    # shouldn't result in the same container type.
    assert ansible_native_

# Generated at 2022-06-22 14:28:21.628221
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_cases = [
        (['value'], 'value'),
        (['value1', 'value2'], 'value1value2'),
        (['value1', 2, 3, 'value2', 3, 4], 'value122value234'),
        (['value', 1], 'value'),
        ([True, False], 'False'),
        ([False, True], 'False'),
        ([True, None, False], 'None'),
        ([1, 2, 3], 1),
        ([True, 1, 3, True], True),
        ([None, True, 1, 3, True], True),
        ([None, True, 'value', 1, 3, True], True)
    ]

    for case in test_cases:
        assert ansible_native_concat(case[0]) == case[1]



# Generated at 2022-06-22 14:28:34.357974
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:28:47.509811
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common.text.converters import to_bytes, to_unicode
    from ansible.module_utils.common.text.converters import text_to_native, to_text
    from ansible.module_utils.common.text.converters import to_native, to_bytes
    from ansible.module_utils.common.text.converters import to_str
    from collections import OrderedDict

    string_list = ['ansible', 'user']
    string_list_test = ansible_native_concat(string_list)
    assert string_list_test == "ansible user", 'String concatenation failed'

    float_list = [5.5, 3.2, 3.1]
    float_

# Generated at 2022-06-22 14:29:00.034753
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import sys

    assert ansible_native_concat((1, '4', u':', u'a')) == 143
    assert ansible_native_concat((1, 4, u':', u'a')) == '1:4:a'
    assert ansible_native_concat((1, 4, u':', u'a')) == '1:4:a'

    # This works because literal_eval doesn't parse unicode in Python 2.
    if sys.version_info.major == 2:
        assert ansible_native_concat((1, 4, u':', u'\u041a')) == '1:4:a'

    assert ansible_native_concat((1, 4, u':', u'\u041a')) == u'1:4:\u041a'

    assert ansible_

# Generated at 2022-06-22 14:29:08.332960
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo' * 100]) == 'foo' * 100

    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo' * 100, 'bar' * 100]) == ('foo' * 100) + ('bar' * 100)

    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat(['1.0', '2.0']) == '1.02.0'
    assert ansible_native_concat(['foo', '2']) == 'foo2'
    assert ansible_native_con

# Generated at 2022-06-22 14:29:12.040139
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None

    assert ansible_native_concat(['1']) == '1'
    assert ansible_native_concat(['True']) == True
    assert ansible_native_concat(['1','2','3']) == '123'



# Generated at 2022-06-22 14:29:30.723328
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, 2, 3, 4]) == '1234'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(['ab', 'c', 'de', 'fg']) == 'abcdefg'
    assert ansible_native_concat(['1', '2', '3', '4']) == '1234'
    assert ansible_native_concat(['1', '2', '3', 4]) == '1234'
   

# Generated at 2022-06-22 14:29:42.515360
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['1']) == '1'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat(['1', 2]) == '12'
    assert ansible_native_concat([1, 2]) == 1
    assert ansible_native_concat([1, 2, [3, 4]]) == 1
    assert ansible_native_concat(['1', 2, [3, 4]]) == '12[3, 4]'
    assert ansible_native_concat(['1', 2, [3, 4], {'a': 'b'}]) == '12[3, 4]{\'a\': \'b\'}'
    assert ansible_native

# Generated at 2022-06-22 14:29:48.536858
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert 'ab' == ansible_native_concat(('a', 'b'))
    assert 'a b' == ansible_native_concat(('a', ' ', 'b'))
    assert 'a1' == ansible_native_concat(('a', 1))
    assert 'a3' == ansible_native_concat(('a', 3))
    assert ['a', 1] == ansible_native_concat(('a', [1]))
    assert 'a{}' == ansible_native_concat(('a', '{}'))
    assert 'a' == ansible_native_concat(('a1', 1))
    assert 'a' == ansible_native_concat(('a', None))
    assert 'a' == ansible_native_concat(('a', ''))


# Generated at 2022-06-22 14:29:54.097848
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([True]) == True
    assert ansible_native_concat(['foo', False, 'bar']) == u'foofalsebar'
    assert ansible_native_concat(['1', '2', '3']) == u'123'
    assert ansible_native_concat(['1', '2.3', '3']) == u'123'
    assert ansible_native_concat(['1', '2.3', '3']) == u'123'
    assert ansible_native_concat(['1', '2.3', '3']) == u'123'
    assert ansible_native_concat(['[1,2, 3]2']) == u'[1,2, 3]2'

# Generated at 2022-06-22 14:30:06.077589
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def _test(input_node, result):
        assert ansible_native_concat(input_node) == result

    # single node conditions
    _test([1], 1)
    _test([1.1], 1.1)
    _test(['test'], 'test')
    _test(['test1', 'test2'], 'test1test2')
    _test([None], None)
    _test([{'test': 'test'}], {'test': 'test'})

    # invalid conditions
    _test([], None)
    _test([], None)
    _test(['', None], 'None')
    _test(['', 1, True], '1True')

    # concatenation conditions
    _test([1, 1], 2)
    _test(['test', 1], 'test1')

# Generated at 2022-06-22 14:30:12.982353
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Define all the variables
    undefined_variable = StrictUndefined('undefined')
    empty_string = ''
    empty_list = []
    empty_dict = {}
    string_0 = 'abc'
    string_1 = 'efg'
    string_2 = 'ijk'
    string_3 = 'lmnopqrstuvwxyz'
    string_4 = '0123'
    string_5 = '4567'
    string_6 = '89'
    string_7 = '-'
    list_0 = [0, 1, 2]
    list_1 = [0, 1, 2]
    list_2 = [3, 4, 5]
    list_3 = [6, 7, 8]
    list_4 = [9, 10, 11]

# Generated at 2022-06-22 14:30:22.888860
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # code is taken from jinja2/tests/test_nativetypes.py
    # https://github.com/pallets/jinja/blob/master/tests/test_nativetypes.py
    from ansible.module_utils.common.collections import is_list, is_set
    from ansible.module_utils.six import PY3, string_types

    if PY3:
        from types import DynamicClassAttribute
        from ansible.module_utils.six import with_metaclass

        class FakeInt(with_metaclass(DynamicClassAttribute, int)):
            pass

        class FakeStr(with_metaclass(DynamicClassAttribute, str)):
            pass

        class FakeBytes(with_metaclass(DynamicClassAttribute, bytes)):
            pass


# Generated at 2022-06-22 14:30:33.813272
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class test_native_data_type(object):
        """A class for testing the functionality of ansible_native_concat"""
        def __init__(self, data):
            self.data = data

        def __str__(self):
            return u'{}'.format(self.data)

    class test_undefined_jinja_class(object):
        """A class for testing the functionality of ansible_native_concat"""
        def __str__(self):
            return '{{ undefined }}'

    class test_undefined_jinja_mapping(Mapping):
        """A class for testing the functionality of ansible_native_concat"""
        def __iter__(self):
            return iter('{{ undefined }}')

        def __len__(self):
            return len('{{ undefined }}')


# Generated at 2022-06-22 14:30:45.561901
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:30:57.975014
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    string_val = 'hello world'
    int_val = 123
    float_val = 123.4
    dict_val = dict(a=1, b=2)
    list_val = [1, 2, 3]
    tuple_val = (1, 2, 3)
    ansible_vault_unicode_val = AnsibleVaultEncryptedUnicode(string_val)

    # test undefined
    try:
        ansible_native_concat([])
        assert False, 'undefined should raise exception'
    except Exception as e:
        assert isinstance(e, StrictUndefined), 'undefined should raise StrictUndefined exception'

    # test string
    assert ansible_native_concat([string_val]) == string_val

    # test int

# Generated at 2022-06-22 14:31:12.146457
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert native_concat([1, 2, 3]) == 123
    assert native_concat([1, 2, 3], '|', 'join') == '1|2|3'
    assert native_concat(['a', 'b', 'c']) == 'abc'
    assert native_concat(['a', 'b', 'c'], '|', 'join') == 'a|b|c'
    assert native_concat([['a', 'b'], 'c'], '|', 'join') == 'a,b|c'
    assert native_concat([['a', 'b'], 'c']) == ['a', 'b', 'c']


# Generated at 2022-06-22 14:31:23.606275
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == "123"
    assert ansible_native_concat(['a', 'b', 'c']) == "abc"
    assert ansible_native_concat([1, 2, 'c']) == "abc"
    assert ansible_native_concat(['a', 2, 3]) == "abc"
    assert ansible_native_concat([1, 'b', 3]) == "123"

    assert ansible_native_concat([1.1]) == 1.1
    assert ansible_native_concat(['a']) == "a"

    assert ansible_native_concat([1, True, False]) == "[1, True, False]"

# Generated at 2022-06-22 14:31:30.633828
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class DummyNode(object):
        def __init__(self, value):
            self.value = value

    def check(expected, node_values):
        nodes = [DummyNode(v) for v in node_values]
        assert ansible_native_concat(nodes) == expected

    check(None, [])
    check(1, [1])
    check(2, [2])
    check('foo', ['foo'])
    check('foo', [1, 'foo'])
    check([], [1, []])
    check(1, [1, 2, 3])
    check('1 2 3', [1, ' ', 2, ' ', 3])
    check('1 2 3', [1, ' ', 2, '', ' ', 3])

# Generated at 2022-06-22 14:31:41.014104
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Pure python way of creating nodes in which we want to test
    # ansible_native_concat

    # for testing with single node, no concatenation needed
    class node:
        def __init__(self, value):
            self.value = value
        def __iter__(self):
            yield self.value

    # for testing with multiple nodes, concatenation needed
    def nodes(values):
        for value in values:
            yield node(value)

    assert ansible_native_concat(node('10')) == 10
    assert ansible_native_concat(node(['10'])) == ['10']
    assert ansible_native_concat(node(('10',))) == ('10',)
    assert ansible_native_concat(node('10.1')) == 10.1
    assert ansible_

# Generated at 2022-06-22 14:31:51.305079
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([['foo'], 'bar']) == ['foo', 'bar']
    assert ansible_native_concat([None, 'bar']) == 'bar'
    assert ansible_native_concat([42, 'bar']) == 42
    assert ansible_native_concat([[42], 'bar']) == ['42', 'bar']

# Generated at 2022-06-22 14:32:02.494820
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.template import Templar
    items = [u'ansible', u'is', u'awesome']
    items_templated = [u'ansible', u'is', Templar(loader=None).template(u'{{ ansible_facts.test_fact }}', convert_bare=True, preserve_trailing_newlines=False, silence_deprecation=True), u'awesome']
    items_templated_text = [u'ansible', u'is', u'{{ ansible_facts.test_fact }}', u'awesome']

    assert ansible_native_concat(items) == u'ansibleisawesome'
    assert ansible_native_concat(items_templated) == u'ansibleisawesome'

# Generated at 2022-06-22 14:32:14.284064
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat(['[1, 2]']) == [1, 2]
    assert ansible_native_concat(['[1, 2]', '[3, 4]']) == '[1, 2][3, 4]'
    assert ansible_native_concat(['[1, 2', '3, 4]']) == '[1, 23, 4]'
    assert ansible_native_concat('12345') == '12345'
    assert ansible_native_concat(container_to_text('12345')) == '12345'

# Generated at 2022-06-22 14:32:24.723933
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = (1, 2, 3)
    out = ansible_native_concat(nodes)
    assert out == '123'

    nodes = ('a', 'b', 'c')
    out = ansible_native_concat(nodes)
    assert out == 'abc'

    nodes = ('a', 1, 'c')
    out = ansible_native_concat(nodes)
    assert out == 'a1c'

    nodes = (1, 2, 'a', 'b', 'c')
    out = ansible_native_concat(nodes)
    assert out == '12abc'

    # Verify that leading spaces/tabs are preserved
    nodes = (' ', 'a', 'b', 'c')
    out = ansible_native_concat(nodes)
    assert out == ' abc'