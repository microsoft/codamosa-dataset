

# Generated at 2022-06-22 14:22:22.248397
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat(['a', 1, 'b', 2, 'c', 3]) == 'a1b2c3'
    assert ansible_native_concat([1.1, '1.1']) == 1.10
    assert ansible_native_concat(['1.1', 1.1]) == 1.10
    assert ansible_native_concat(['1.1', 1]) == '1.10'
    assert ansible_native_concat([1, 1.1]) == 1.10
    assert ansible_native_concat(['1.1', '1.1']) == 1.10
    assert ansible_native_concat([1, 1]) == 11
    assert ansible_native_con

# Generated at 2022-06-22 14:22:34.888259
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class StrictUndefined(unicode):
        pass
    # ansible_native_concat returns variable value if variable is defined
    assert ansible_native_concat([1]) == 1
    # ansible_native_concat returns variable value if variable is a string
    assert ansible_native_concat(['1']) == '1'
    # ansible_native_concat returns variable value if variable is a unicode string
    assert ansible_native_concat([u'1']) == u'1'
    # ansible_native_concat returns variable value if variable is an integer
    assert ansible_native_concat([1]) == 1
    # ansible_native_concat returns variable value if variable is a float
    assert ansible_native_concat([1.1]) == 1.1
    # ansible_

# Generated at 2022-06-22 14:22:47.735579
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test function ansible_native_concat."""
    def nodes_gen(values):
        for value in values:
            yield value

    assert ansible_native_concat(nodes_gen([])) is None

    assert ansible_native_concat(nodes_gen([True])) is True

    assert ansible_native_concat(nodes_gen([1])) == 1

    assert ansible_native_concat(nodes_gen(['a', 'b', 'c'])) == 'abc'

    assert ansible_native_concat(nodes_gen([1, 2, 3, 4])) == [1, 2, 3, 4]

    assert ansible_native_concat(nodes_gen(['[1, 2, 3, 4]'])) == [1, 2, 3, 4]

# Generated at 2022-06-22 14:23:00.667891
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['1']) == '1'

    assert ansible_native_concat([1, 'a']) == '1a'
    assert ansible_native_concat(['a', 1]) == 'a1'
    assert ansible_native_concat(['1', 'a']) == '1a'
    assert ansible_native_concat(['a', '1']) == 'a1'

    assert ansible_native_concat([1, 2, 3]) == '123'

# Generated at 2022-06-22 14:23:12.565134
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.errors import AnsibleError
    from ansible.module_utils.common.text.converters import container_to_text

    try:
        import _ast
        # ast.literal_eval is available since Python 2.6
        assert isinstance(_ast.literal_eval, types.FunctionType)
        del _ast
    except (ImportError, AttributeError):
        # we'll just skip the test
        import pytest
        pytest.skip("Unable to test ansible_native_concat() on this platform")

    # list
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]

    # tuple
    assert ansible_native_concat([(1, 2), (3, 4)]) == [(1, 2), (3, 4)]

    # dict

# Generated at 2022-06-22 14:23:25.962356
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2

    env = jinja2.Environment()
    env.filters['tojson'] = container_to_text
    env.filters['bool'] = bool
    env.filters['native'] = ansible_native_concat
    env.filters['string'] = text_type


# Generated at 2022-06-22 14:23:34.933325
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a', 1, 'b']) == u'a1b'
    assert ansible_native_concat([1, 'b']) == 1
    assert ansible_native_concat(['a', 'b']) == u'ab'
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['a', 1, 'b', 2]) == u'a1b2'
    assert ansible_native_concat(['a', 1, 'b', 2, 'c']) == u'a1b2c'
    assert ansible_native_concat((v for v in ['a', 1, 'b', 2, 'c'])) == u'a1b2c'

# Generated at 2022-06-22 14:23:41.230540
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['1', '2', '3']) == '123'
    assert ansible_native_concat(['1', 2, 3]) == '1 2 3'
    assert ansible_native_concat([1, 2, 3]) == '1 2 3'

    assert ansible_native_concat(['["ansible"]']) == ['ansible']
    assert ansible_native_concat(['{"key": "value"}']) == {'key': 'value'}
    assert ansible_native_concat(['"ansible"', '"parsing"']) == 'ansible parsing'

    assert ansible_native_concat([b'"ansible"', b'"parsing"']) == 'ansible parsing'

    # Avoid literal_eval
    assert ansible_native_con

# Generated at 2022-06-22 14:23:53.445911
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 1]) == '11'
    assert ansible_native_concat(['1', '1']) == 2
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['[1, 2]']) == [1, 2]
    assert ansible_native_concat(['[1, 2]', '[3, 4]']) == '[1, 2][3, 4]'
    assert ansible_native_concat(['[1, 2]', '[3, 4]']) == '[1, 2][3, 4]'


# Generated at 2022-06-22 14:24:05.232522
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # simple string concatenation
    assert ansible_native_concat(['a', 'b']) == 'ab'

    # concatenation of raw string and Jinja2 StrictUndefined
    assert ansible_native_concat(['a', StrictUndefined()]) == 'a'

    # concatenation of Jinja2 StrictUndefined and raw string
    assert ansible_native_concat([StrictUndefined(), 'a']) == 'a'

    # concatenation of Jinja2 StrictUndefined and Jinja2 StrictUndefined
    assert ansible_native_concat([StrictUndefined(), StrictUndefined()]) == ''

    # list concatenation
    assert ansible_native_concat(['[', '1, 2, 3', ']']) == [1, 2, 3]

    #

# Generated at 2022-06-22 14:24:11.502224
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(['a', 'b', 'c', 1]) == 'abc1'
    assert ansible_native_concat(['1', '2', '3']) == 123
    assert ansible_native_concat(['True', 'False']) == True
    assert ansible_native_concat(['None']) == None
    assert ansible_native_concat(['[1, 2]']) == [1, 2]
    assert ansible_native_con

# Generated at 2022-06-22 14:24:19.672359
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat([u'hello']) == u'hello'
    assert ansible_native_concat([u'1']) == u'1'
    assert ansible_native_concat([u'he', u'll', u'o']) == u'hello'
    assert ansible_native_concat([u'123']) == 123
    assert ansible_native_concat([u'hello', u' ', u'world']) == u'hello world'
    assert ansible_native_concat([u'{']) == u'{'
    assert ansible_native_concat([u'("']) == u'("'

# Generated at 2022-06-22 14:24:30.804320
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1.0]) == 1.0
    assert ansible_native_concat(['']) == ''
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([u'\u019d']) == u'\u019d'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat([True, False]) == 'TrueFalse'

    # Not able to parse the string therefore the string is returned
    assert ansible_native_concat(['1 0']) == '1 0'

# Generated at 2022-06-22 14:24:43.872647
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([u'foo', 5]) == 'foo5'
    assert ansible_native_concat(u'foo') == u'foo'
    assert ansible_native_concat([u'foo', u'bar'] + [3]) == u'foobar3'
    assert ansible_native_concat([1, u'foo', u'bar']) == u'1foobar'
    assert ansible_native_concat(u'foo' * 3) == u'foofoofoo'
    assert ansible_native_concat([u'+', 0, 1]) == u'+01'

# Generated at 2022-06-22 14:24:57.013757
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat([1]) == 1

    assert ansible_native_concat(('a', 'b')) == 'ab'
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, 2, 3]) == '123'

    assert ansible_native_concat(('a', 'b', 'c', 'd')) == 'abcd'

    assert ansible_native_concat([1, 2, 3, 4]) == '1234'
    assert ansible_native_concat([1e10, 2e10, 3e10, 4e10]) == '1e+101e+102e+103e+10'


# Generated at 2022-06-22 14:25:06.411960
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_text
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([u'hell\u00f8'] * 10) == (u'hell\u00f8' * 10)
    assert ansible_native_concat([1, 2, u'a', u'b', 3, 4]) == u'12ab34'
    assert ansible_native_concat([1, u'x', 2, u'y', 3]) == u'1x2y3'
    # FIXME:
    # assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
   

# Generated at 2022-06-22 14:25:11.388861
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([1, '2', 3]) == '123'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([True]) == True
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['1.0']) == 1.0
    assert ansible_native_concat(['{1}']) == '{1}'
    assert ansible_native_concat('foo') == 'foo'

# Generated at 2022-06-22 14:25:17.438359
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(["foo", "bar"]) == u"foobar"
    assert ansible_native_concat([1, "a"]) == u"1a"
    assert ansible_native_concat([[1, 2], ["a", "b"]]) == [1, 2, "a", "b"]
    assert ansible_native_concat(sorted([[1, 2], ["a", "b"]])) == [1, 2, "a", "b"]



# Generated at 2022-06-22 14:25:24.874211
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([False]) is False
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([1, 1]) == '11'
    assert ansible_native_concat([1, 'foo']) == '1foo'
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat(['foo', 'bar', 'baz']) == 'foobarbaz'
    assert ansible_native_concat(['foo', 1, 'baz']) == 'foo1baz'

# Generated at 2022-06-22 14:25:36.679802
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    first_json_string = '{"name": "test_name", "host": "test_host"}'
    second_json_string = '{"name2": "test_name2", "host2": "test_host2"}'
    concat_str = first_json_string + second_json_string
    concat_str_array = [first_json_string, second_json_string]

    # test when input is single string
    assert ast.literal_eval(first_json_string) == ansible_native_concat([first_json_string])

    # test when input is concatenated strings
    assert ast.literal_eval(concat_str) == ansible_native_concat(concat_str_array)

    # test when input is a list of strings
    assert concat_str_array == ans

# Generated at 2022-06-22 14:25:51.174672
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    result = ansible_native_concat([1, 2])
    assert container_to_text(result) == '1'

    result = ansible_native_concat([1, 2, 3])
    assert container_to_text(result) == '123'

    result = ansible_native_concat([1, text_type(2), 3])
    assert container_to_text(result) == '123'

    result = ansible_native_concat([text_type(1), 2, 3])
    assert container_to_text(result) == '123'

    result = ansible_native_concat([text_type(1), 2, text_type(3)])
    assert container_to_text(result) == '123'


# Generated at 2022-06-22 14:26:03.375554
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Byte string in Python 3
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([b'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([u'foo', b'bar']) == u'foobar'
    assert ansible_native_concat([b'foo', b'bar']) == u'foobar'

    # Unicode in Python 2
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'

    # String containing a literal
    assert ansible_native_concat([u'[', u'1, 2, 3', u']']) == [1, 2, 3]

    # Unicode in Python 2
    assert ansible_

# Generated at 2022-06-22 14:26:15.314167
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Strip any leading spaces from the function body
    body = _fail_on_undefined.__code__.co_consts[0]
    lines = body.splitlines()
    body = u'\n'.join([line.lstrip() for line in lines])

    # Put the function body inside a native JinjaText object
    body = NativeJinjaText(body)

    # Create a mock namespace containing the implemented functions

# Generated at 2022-06-22 14:26:22.741990
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping

    s = """""; v = {'_ansible_native_concat': ansible_native_concat}
      assert v['_ansible_native_concat'](nodes) == 'value'
    """
    locals_ = {'nodes': 'value'}
    exec(compile(s, '<string>', 'exec'), globals(), locals_)

    s = """""; v = {'_ansible_native_concat': ansible_native_concat}
      assert v['_ansible_native_concat'](nodes) == {'key': 'value', 'other': ['value']}
    """

# Generated at 2022-06-22 14:26:34.015528
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test null inputs
    assert ansible_native_concat([NativeJinjaText(None)]) == None
    assert ansible_native_concat([NativeJinjaText(None), NativeJinjaText(None)]) == None

    # Test concatenated native jinja text types
    assert ansible_native_concat([NativeJinjaText("foo"), NativeJinjaText("bar")]) == "foobar"

    # Test concatenated native jinja text types with nulls
    assert ansible_native_concat([NativeJinjaText("foo"), NativeJinjaText(None), NativeJinjaText("bar")]) == "foobar"

    # Test un-parsable types

# Generated at 2022-06-22 14:26:45.507751
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([[0]]) == [0]
    assert ansible_native_concat([[0], [1]]) == [0, 1]
    assert ansible_native_concat([[0], 5]) == [0, 5]
    assert ansible_native_concat(["xyz"]) == 'xyz'
    assert ansible_native_concat(["xy", 2]) == "xy2"
    assert ansible_native_concat(["xy", u"\u2217"]) == "xy\u2217"

# Generated at 2022-06-22 14:26:57.535307
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test ansible_native_concat
    """
    assert ansible_native_concat([1, 2]) == 3
    assert ansible_native_concat([1, None, 2]) is None
    assert ansible_native_concat([1, '2']) == 1
    assert ansible_native_concat(iter([1, 2])) == 3
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat(iter([1, '2', 3])) == 123
    assert ansible_native_concat([1, 2, 3, 4]) == '1234'
    assert ansible_native_concat([[1], [2, 3]]) == [1, 2, 3]

# Generated at 2022-06-22 14:27:05.813050
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.module_utils.common.collections import is_sequence

    if PY3:
        string_types = (str,)
    else:
        string_types = (str, unicode)

    assert ansible_native_concat(['1', '2', '3']) == '1 2 3'
    assert ansible_native_concat(['1', '2', '3']) == '1 2 3'
    assert ansible_native_concat([1, '2', '3']) == '1 2 3'
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_con

# Generated at 2022-06-22 14:27:18.133755
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_native
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', u'b']) == 'ab'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'

    # These are the same as literal_eval
    assert ansible_native_concat(['42']) == 42
    assert ansible_native_concat(['42', '00']) == 4200
    assert ansible_native_concat(['4.2']) == 4.2
    assert ansible_

# Generated at 2022-06-22 14:27:29.877431
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert ansible_native_concat([]) == None

    # short circuit
    assert ansible_native_concat([3]) == 3
    assert ansible_native_concat([3.1]) == 3.1
    assert ansible_native_concat([True]) == True
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a']) == 'a'

    # concat
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat([3, 'a', True]) == '3aTrue'

    # literal_eval - int

# Generated at 2022-06-22 14:27:38.942085
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.jinja2 import AnsibleUndefined, compile_expression

    assert ansible_native_concat([]) is None

    literal = compile_expression("'foo' ~ 'bar'")
    assert ansible_native_concat(literal.body.nodes) == 'foobar'

    literal = compile_expression("123")
    assert ansible_native_concat(literal.body.nodes) == 123

    literal = compile_expression("123.0")
    assert ansible_native_concat(literal.body.nodes) == 123.0

    literal = compile_expression("True")
    assert ansible_native_concat(literal.body.nodes) is True

    literal = compile_expression("[]")

# Generated at 2022-06-22 14:27:47.595685
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['a']) == 'a'

    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', 1, 'b']) == 'a1b'
    assert repr(ansible_native_concat(['a', '1', 'b'])) == "u'a1b'"
    assert ansible_native_concat([u'a', u'b']) == u'ab'
    assert repr(ansible_native_concat([u'a', u'b'])) == "u'ab'"
    assert ansible_native_concat([u'a', 1, u'b']) == u'a1b'

# Generated at 2022-06-22 14:27:57.469552
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(range(100)) == 99
    assert ansible_native_concat([range(100), 'test123']) == u'99test123'
    assert ansible_native_concat([range(100), 'test123', 'other']) == u'99test123other'
    assert ansible_native_concat(['test123', 'other']) == u'test123other'
    assert ansible_native_concat(['test123', 'True']) == True
    assert ansible_native_concat('test123') == u'test123'
    assert ansible_native_concat(['test', '123']) == 123
    assert ansible_native_concat(['test', '123', 'True']) == 123



# Generated at 2022-06-22 14:28:08.685000
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_list

    def t(inp, expected):
        assert [container_to_text(ansible_native_concat([container_to_text(x)])) for x in to_list(inp)] == expected

    t('foo', ['foo'])
    t(['foo', 'bar'], ['foo', 'bar'])
    t(['foo', 'bar', ['baz', 'qux']], ['foo', 'bar', "['baz', 'qux']"])
    t(['foo', ['bar', ['baz', 'qux']]], ['foo', "['bar', ['baz', 'qux']]"])

    t('[1, 2, 3]', ['[1, 2, 3]'])

# Generated at 2022-06-22 14:28:21.370852
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['key']) == 'key'
    assert ansible_native_concat([False]) is False
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b  ']) == 'ab  '
    assert ansible_native_concat(['a', 'b  ', 'c']) == 'ab  c'
    assert ansible_native_concat(['a', 1, 'c']) == 'a1c'
    assert ansible_native_concat(['a', 1, 'c', True]) == 'a1cTrue'
    assert ansible_native_concat([1]) == 1

# Generated at 2022-06-22 14:28:34.066165
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    def _compile_value(value):
        tokens = [('constant', value)]
        return [t[1] for t in tokens]

    assert ansible_native_concat(_compile_value(u'foo') + _compile_value(u'bar')) == u'foobar'
    assert ansible_native_concat(_compile_value(u'foo') + _compile_value(u'bar')) == u'foobar' # u'' is redundant in Python 2
    assert ansible_native_concat(_compile_value(u'foo') + _compile_value(u'bar')) == b'foobar'
    assert ansible_native_concat(_compile_value(u'foo') + _compile_value(u'bar')) == b'foobar' # b'' is redundant

# Generated at 2022-06-22 14:28:47.113262
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2.runtime import Undefined

    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([Undefined]) == Undefined
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([u'a']) == u'a'
    assert ansible_native_concat([1, 2]) == u'12'
    assert ansible_native_concat([1, 2, 3]) == u'123'
    assert ansible_native_concat([1, u'2']) == u'12'
    assert ansible_native_concat([1, 2, u'3']) == u'123'
    assert ansible_native_concat([u'a', u'b']) == u'ab'
    assert ansible

# Generated at 2022-06-22 14:28:59.704943
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # test for literal_eval
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['1']) == '1'
    assert ansible_native_concat(['1']) == '1'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 'text']) == '1text'
    assert ansible_native_concat([1, 'text', 3]) == '1text3'
    assert ansible_native_concat([1, '1']) == 2
    assert ansible_native_concat(['1', '1']) == '11'
    assert ansible_native_concat([True, 'text', 3]) == 'Truetext3'

# Generated at 2022-06-22 14:29:08.103607
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:29:16.068447
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test single node
    # integer
    assert ansible_native_concat([1]) == 1
    # float
    assert ansible_native_concat([1.0]) == 1.0
    # string
    assert ansible_native_concat([u'hello']) == 'hello'
    # boolean
    assert ansible_native_concat([True]) == True
    assert ansible_native_concat([False]) == False
    # None
    assert ansible_native_concat([None]) == None
    # list
    assert ansible_native_concat([[1, 2, 3]]) == [1, 2, 3]
    # dict
    assert ansible_native_concat([{'foo': 'bar'}]) == {'foo': 'bar'}
    # tuple
    assert ansible_native

# Generated at 2022-06-22 14:29:30.358397
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from datetime import datetime
    from jinja2 import Environment, meta, Template

    template = '{{ 1 }}'
    assert ansible_native_concat(Template(template).root_render_func(Environment().new_context())) == 1

    template = '{{ "1" }}'
    assert ansible_native_concat(Template(template).root_render_func(Environment().new_context())) == "1"

    template = '{{ "1+1" }}'
    assert ansible_native_concat(Template(template).root_render_func(Environment().new_context())) == "1+1"

    template = '{{ 1+1 }}'
    assert ansible_native_concat(Template(template).root_render_func(Environment().new_context())) == 2


# Generated at 2022-06-22 14:29:42.032357
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    # Ensure that ansible_native_concat does not use
    # ast.literal_eval if a single non-string object is given
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([123]) == 123
    assert ansible_native_concat([[]]) == []
    assert ansible_native_concat([{}]) == {}

    # Ensure that ansible_native_concat uses ast.literal_eval
    # for a single string object when possible
    assert ansible_native_concat([u'foo']) == 'foo'
    assert ansible_native_concat([u'123']) == 123

# Generated at 2022-06-22 14:29:48.237265
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # empty list
    nodes = []
    result = ansible_native_concat(nodes)
    assert result is None

    # single list item
    nodes = ['John']
    result = ansible_native_concat(nodes)
    assert result == 'John'

    # multiple list items
    nodes = ['Hello', ' ', 'John']
    result = ansible_native_concat(nodes)
    assert result == 'Hello John'

    # single list item, can be evaluated to a python object
    nodes = ['{{ value | join("/") }}']
    result = ansible_native_concat(nodes)
    assert result == ['a', 'b', 'c']

    # single list item, can be evaluated to a python object
    nodes = ['a']

# Generated at 2022-06-22 14:29:50.462645
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_text

    # Ensure the function handles strings and not just native types.
    assert to_text("text") == ansible_native_concat([to_text("text")])



# Generated at 2022-06-22 14:30:01.812192
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def check(nodes, expected):
        msg = "'%s' should be translated to '%s'" % (
            container_to_text(nodes), expected
        )
        assert ansible_native_concat(
            nodes
        ) == expected, msg

    check([], None)
    check([u'foo'], u'foo')
    check([u'foo', u'bar'], u'foobar')
    check([u'foo', u'bar', u'baz'], u'foobarbaz')

    check([u'1', u'2', u'3'], 3)
    check([u'1', u'+', u'2', u'+', u'3'], 6)
    check([u'1', u'+', u'2', u'+', u'3'], 6)

# Generated at 2022-06-22 14:30:13.505517
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.common.text.converters import to_native

    # This is an exhaustive test for the ansible_native_concat function

# Generated at 2022-06-22 14:30:23.219298
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2
    class AnsibleNativeEnvironment(jinja2.Environment):
        native_concat = staticmethod(ansible_native_concat)

    # Data as a dictionary

# Generated at 2022-06-22 14:30:34.065029
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2]) == "12"
    assert ansible_native_concat([1, 2, 3]) == "123"
    assert ansible_native_concat([True]) == True
    assert ansible_native_concat([False]) == False
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([u'foo', u'bar', True]) == u'foobarTrue'
    assert ansible_native_concat([2, u'bar']) == u'2bar'

# Generated at 2022-06-22 14:30:45.736855
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(['a', 'b', 'c', 'd']) == 'abcd'
    assert ansible_native_concat(['a', 1, 'c', 'd']) == 'a1cd'
    assert ansible_native_concat(['a', 1, 2, 'd']) == 'a12d'
    assert ansible_native_concat(['a', 1, 2, 3]) == 'a123'

# Generated at 2022-06-22 14:30:58.089049
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def _ansible_native_concat(nodes):
        text = container_to_text(nodes)
        if text.startswith(u'{'):
            return ast.literal_eval(text)
        return text

    assert ansible_native_concat([1, 2]) == _ansible_native_concat([1, 2])
    assert ansible_native_concat([u'a', u'b']) == _ansible_native_concat([u'a', u'b'])
    assert ansible_native_concat([u'', u'']) == _ansible_native_concat([u'', u''])
    assert ansible_native_concat([u'', u'', u'']) == _ansible_native_concat([u'', u'', u''])
   

# Generated at 2022-06-22 14:31:11.461431
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([u'a']) == u'a'
    assert ansible_native_concat([u'a']) == u'a'
    assert ansible_native_concat([u'a', u'b']) == u'ab'
    assert ansible_native_concat([u'a', u'b', u'c']) == u'abc'
    assert ansible_native_concat([u'a', u'b', [u'c', u'd']]) == u'abcd'
    assert ansible_native_concat([u'a', u'b', [u'c', u'd']]) == u'abcd'

# Generated at 2022-06-22 14:31:18.133942
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:31:27.116051
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(map(lambda x: container_to_text(x), [1, u"2"])) == u"12"
    assert ansible_native_concat(map(lambda x: container_to_text(x), ["1", u"2"])) == u"12"
    assert ansible_native_concat(map(lambda x: container_to_text(x), [u"1", 2])) == u"12"
    assert ansible_native_concat(map(lambda x: container_to_text(x), [u"1", u"2"])) == u"12"
    assert ansible_native_concat(map(lambda x: container_to_text(x), [u"1", None])) == u"1"

# Generated at 2022-06-22 14:31:38.413038
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # TODO: add other functions from nativetypes.py and add the tests here
    # See https://github.com/ansible/ansible/issues/70831#issuecomment-664190894
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat([NativeJinjaText('a'), 'b']) == 'ab'
    assert ansible_native_concat([1, 'b', NativeJinjaText('c')]) == '1bc'
    assert ansible_native_concat([1, NativeJinjaText('b'), 'c']) == '1bc'
    assert ansible_native_concat([1, NativeJinjaText('b'), 'c', NativeJinjaText('d')]) == '1bcd'



# Generated at 2022-06-22 14:31:48.427297
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def assert_equal(actual, expected):
        message = 'Expected %r, got %r' % (expected, actual)
        assert expected == actual, message


# Generated at 2022-06-22 14:31:54.053256
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import datetime
    from ansible.module_utils.common.text.converters import to_datetime

    # basestring/str is special in Python 2 and in Jina2. So, we need to pass
    # it through container_to_text function to convert it to a text type.
    # See: https://github.com/ansible/ansible/blob/00c2951f36d54d9a6674faed57e725f0d32f39c8/lib/ansible/module_utils/six.py#L945
    assert container_to_text(u'foo' + u'bar') == ansible_native_concat([u'foo', u'bar'])
    assert u'foo' + u'bar' == ansible_native_concat([u'foo', u'bar'])

# Generated at 2022-06-22 14:32:00.484785
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.jinja2.nativetypes import ansible_native_concat
    values = ['foo', 'bar', 123, 'baz']

    actual = ansible_native_concat(values)
    assert actual == "foobar123baz"

    actual = ansible_native_concat(values)
    assert actual == "foobar123baz"


# Generated at 2022-06-22 14:32:05.178883
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class Undef(StrictUndefined):
        def __repr__(self):
            raise RuntimeError(u"Invalid use of undefined value")

    # Undefined values reflected without fail_on_undefined
    undefined = Undef()
    assert u"{{ (1, 2, 3) ~ (foo, bar) }}" == container_to_text(ansible_native_concat([(1, 2, 3), (u'foo', u'bar')]))
    assert u"{{ (1, 2, 3) ~ (foo, bar) }}" == container_to_text(ansible_native_concat([(1, 2, 3), (u'foo', undefined)]))
    assert u"{{ (foo, bar) }}" == container_to_text(ansible_native_concat([(u'foo', undefined)]))

    #

# Generated at 2022-06-22 14:32:16.637972
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import pytest

    assert ansible_native_concat([]) is None

    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([u'a']) == u'a'

    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat([u'a', u'b']) == u'ab'

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1.1]) == 1.1

    assert ansible_native_concat(['a', 1]) == 'a1'
    assert ansible_native_concat(['a', 1.1]) == 'a1.1'
