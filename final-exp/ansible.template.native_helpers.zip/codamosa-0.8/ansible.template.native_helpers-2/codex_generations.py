

# Generated at 2022-06-22 14:22:18.351687
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.logic import ast_truth
    from ansible.module_utils.common.text.converters import to_bool

    class DummyNode(object):
        def __init__(self, value):
            self.value = value

        def __repr__(self):
            return '<DummyNode(%s)>' % self.value

        def __str__(self):
            return str(self.value)

    assert ansible_native_concat(DummyNode(1)) == 1
    assert ansible_native_concat(DummyNode(u'foo')) == u'foo'
    assert ansible_native_concat([DummyNode(u'foo'), DummyNode(u'bar')]) == u'foobar'

# Generated at 2022-06-22 14:22:31.285228
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:22:43.977923
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 'bar', 'baz']) == 'foobarbaz'
    assert ansible_native_concat(['foo', ['bar', 'baz']]) == 'foo[bar, baz]'

    assert ansible_native_concat(['foo', ['bar', 'baz']]) == 'foo[bar, baz]'
    assert ansible_native_concat(['foo', ['bar', 'baz'], 'qux']) == \
        'foo[bar, baz]qux'
    assert ansible_native_con

# Generated at 2022-06-22 14:22:56.496315
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a', 'b']) == "ab"
    assert ansible_native_concat([1, 2]) == 3
    assert ansible_native_concat(['a', ['b']]) == 'a[b]'
    assert ansible_native_concat([[], 'b']) == '[b]'
    assert ansible_native_concat(['{', 'b']) == '{b'
    assert ansible_native_concat(['}', 'b']) == '}b'
    assert ansible_native_concat([1, 'b']) == "1b"
    assert ansible_native_concat([1, ['b']]) == "1[b]"
    assert ansible_native_concat([None, 'b']) == "Noneb"


# Generated at 2022-06-22 14:23:09.343214
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(list(map(text_type, [1, 2, 3, 4]))) == u'1234'
    assert ansible_native_concat(list(map(text_type, [1, 2, 3, 4]))) == 1234

    assert ansible_native_concat(list(map(text_type, [1, 2, 3, 4]))) == u'1,2,3,4'
    assert ansible_native_concat(list(map(text_type, [1, 2, 3, 4]))) == u'[1, 2, 3, 4]'

    assert ansible_native_concat(list(map(text_type, [1, 2, 3, 4]))) == u'1,2.0,3,4'
    assert ansible_native_concat

# Generated at 2022-06-22 14:23:22.249329
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([1, 2, 3, 4]) == '1234'
    assert ansible_native_concat([1, 2, 3, 4]) == '1234'
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 'bar', 'car']) == 'foobarcar'

# Generated at 2022-06-22 14:23:27.563008
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, u'a']) == 1
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([1, 2, 3, None]) == '123'



# Generated at 2022-06-22 14:23:36.324591
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(['a', 1, 'c']) == 'a1c'
    assert ansible_native_concat(['1', '2']) == 1
    assert ansible_native_concat(['1', 2]) == '12'
    assert ansible_native_concat(['123.0', '-4']) == 119.0
    assert ans

# Generated at 2022-06-22 14:23:47.952677
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert None is ansible_native_concat(None)
    assert None is ansible_native_concat([])

    assert u'foo' is ansible_native_concat([u'foo'])
    assert 123 is ansible_native_concat([123])
    assert 123.45 is ansible_native_concat([123.45])
    assert True is ansible_native_concat([True])
    assert False is ansible_native_concat([False])
    assert [] is ansible_native_concat([[]])
    assert [1, 2] is ansible_native_concat([[1, 2]])
    assert {'a': 1, 'b': 2} is ansible_native_concat([{'a': 1, 'b': 2}])
    assert u'foo' is ansible_native

# Generated at 2022-06-22 14:23:57.149823
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Sample usage of function ansible_native_concat in Ansible templates
    # https://github.com/ansible/ansible/commit/59336c790f8d20b70cdb5a5a5f5b5a8a9c75a87f
    assert ansible_native_concat([u'hello ', u'world']) == u'hello world'
    assert ansible_native_concat([u'a', u'b', u'c']) == u'abc'
    assert ansible_native_concat([u'a', u' ', u'b', u' ', u'c']) == u'a b c'
    assert ansible_native_concat([u'a', u'', u'b', u'c']) == u'abc'

# Generated at 2022-06-22 14:24:13.286763
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert isinstance(ansible_native_concat([None, 1, None]), int)
    assert isinstance(ansible_native_concat([None, 1.0, None]), float)
    assert isinstance(ansible_native_concat([None, u'a', u'b', u'c', None]), text_type)
    assert isinstance(ansible_native_concat([None, [1, 2, 3], None]), list)
    assert isinstance(ansible_native_concat([None, {u'k': u'v'}, None]), dict)
    assert ansible_native_concat([None, [1], '2', 3, None]) == [1, u'2', 3]
    assert ansible_native_concat([None, [1], '', None]) == [1]
    assert ansible_

# Generated at 2022-06-22 14:24:25.459903
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # strings
    assert ansible_native_concat(['test', 'ing']) == u"testing"

    # non-strings
    assert ansible_native_concat([1]) == 1

    # list of strings
    assert ansible_native_concat(['test', 'ing']) == u"testing"

    # list of non-strings
    assert ansible_native_concat([1, 2]) == u'12'

    # list of mixed
    assert ansible_native_concat([1, u'2']) == u'12'

    # list of non-strings
    assert ansible_native_concat([False, u'True']) == u'FalseTrue'

    # list of mixed
    assert ansible_native_concat([1, u'2']) == u'12'

    # strings to

# Generated at 2022-06-22 14:24:34.071324
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class Undefined(object):
        def __repr__(self):
            raise RuntimeError()

    # Ansible uses native Jinja2 exceptions which do not match those
    # used in unit tests. We can use private exception methods
    # because they are not supposed to change.
    class UndefinedUndefinedError(RuntimeError):
        def __init__(self, undefined):
            self.__undefined = undefined

        def __repr__(self):
            return repr(self.__undefined)

        def __str__(self):
            return str(self.__undefined)

    class DataUndefinedError(RuntimeError):
        def __init__(self, data):
            self.__data = data

        def __repr__(self):
            return repr(self.__data)

        def __str__(self):
            return

# Generated at 2022-06-22 14:24:44.832426
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(iter([])) is None
    assert ansible_native_concat([0]) == 0
    assert ansible_native_concat([0, 1]) == '01'
    assert ansible_native_concat(['a', 1, 'b']) == 'a1b'
    assert ansible_native_concat(['a', 1.1, 'b']) == 'a1.1b'
    assert ansible_native_concat([u'a', 1, u'b']) == u'a1b'
    assert ansible_native_concat([u'a', u'b']) == u'ab'

# Generated at 2022-06-22 14:24:57.729914
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(["a"]) == "a"
    assert ansible_native_concat([1]) == 1
    assert isinstance(ansible_native_concat([1]), int)
    assert ansible_native_concat([1, 2]) == "12"
    assert isinstance(ansible_native_concat([1, 2]), text_type)
    assert ansible_native_concat(["1", "2"]) == "12"
    assert ansible_native_concat(["1", "2", "3"]) == "123"
    assert ansible_native_concat(["1", 2, "3"]) == "123"

# Generated at 2022-06-22 14:25:08.676141
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.constructor import AnsibleConstructor

    # file is included with test using static ansible-test invoke command
    test_data = open('ansible_native_concat_test_data.txt').read()

    # parse the test_data lines into a dict
    for line in test_data.splitlines():
        if line.startswith('#'):
            continue
        if not line:
            continue

        # split the line into the test input and the expected output
        test_in, test_out = line.split('|')

        # parse the test_in data into a dict
        test_in = AnsibleConstructor.construct_object(test_in)

        # get the output from the function under test
        function_out = ansible_native_concat(test_in)

       

# Generated at 2022-06-22 14:25:18.863552
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # pylint: disable=undefined-variable

    from jinja2 import nodes
    from jinja2.runtime import Undefined
    from jinja2.ext import Extension

    class TestExtension(Extension):
        """Representation of a test extension.
        """
        tags = set(['test'])

        # pylint: disable=no-self-use
        def parse(self, parser):
            """Parse the given :class:`~jinja2.parser.Parser`.
            """
            lineno = next(parser.stream).lineno

# Generated at 2022-06-22 14:25:31.041319
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['42']) == 42
    assert ansible_native_concat(['42', ' ']) == '42 '
    assert ansible_native_concat(['42 ', '43']) == '42 43'
    assert ansible_native_concat(['foo', ' 42']) == 'foo 42'
    assert ansible_native_concat(['42', ' foo']) == '42 foo'
    assert ansible_native_concat(['foo', ' bar']) == 'foo bar'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'

# Generated at 2022-06-22 14:25:40.971503
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.six.moves import builtins
    import numpy


# Generated at 2022-06-22 14:25:53.201365
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar', 'baz']) == 'foobarbaz'
    assert ansible_native_concat(['foo', 123, 'baz']) == 'foobarbaz'
    assert ansible_native_concat(['foo', u'bar']) == 'foobar'
    assert ansible_native_concat(['foo', True]) == 'foobar'
    assert ansible_native_concat(['foo', False]) == 'foobar'
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([u'foo']) == 'foo'
    assert ansible_native_concat(['foo', None, 'baz']) == 'foobarbaz'
    assert ansible_native_concat

# Generated at 2022-06-22 14:26:08.229690
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2

    template = jinja2.Template('''{{ data | ansible_native_concat }}''')

    def assert_is_native_type(data, value):
        assert template.render(data=data) == str(value)
        assert isinstance(data, (text_type, bytes))


# Generated at 2022-06-22 14:26:18.252815
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = [
        3,
        # NativeJinjaText needs to be joined with a string
        NativeJinjaText('foo'),
        str('bar'),
        'baz',
        # NativeJinjaText needs to be joined with a string
        NativeJinjaText('qux'),
    ]
    assert ansible_native_concat(nodes) == 'foobarbazqux'

    nodes = [
        3,
        # NativeJinjaText needs to be joined with a string
        NativeJinjaText('foo'),
        str('3'),
        'baz',
        # NativeJinjaText needs to be joined with a string
        NativeJinjaText('3'),
    ]
    assert ansible_native_concat(nodes) == 'foo3baz3'


# Generated at 2022-06-22 14:26:30.852956
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.formatters import to_native
    # test native concat function
    encrypted = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.2;AES256;'
                                             'some_host;some_value',
                                             b'a' * 32,
                                             b'a' * 16)
    assert ansible_native_concat([encrypted]) == encrypted
    assert ansible_native_concat([encrypted, to_text('foo')]) == encrypted
    assert ansible_native_concat([encrypted, 'foo']) == encrypted
    assert ansible_

# Generated at 2022-06-22 14:26:43.050776
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_native
    nodes = ['foo', 'bar']
    assert to_native(ansible_native_concat(nodes)) == 'foobar'

    nodes = ['foo']
    assert to_native(ansible_native_concat(nodes)) == 'foo'

    # ansible_native_concat returns None for empty node list
    nodes = []
    assert to_native(ansible_native_concat(nodes)) is None

    nodes = ['foo', 42]
    assert to_native(ansible_native_concat(nodes)) == 42

    nodes = [42, 'foo']
    assert to_native(ansible_native_concat(nodes)) == 42

    nodes = [42, 'foo']

# Generated at 2022-06-22 14:26:50.867883
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', 1, 'b']) == "a1b"
    assert ansible_native_concat(['a', 1, 'b', [1, 2, 3]]) == "a1b[1, 2, 3]"
    assert ansible_native_concat(['a', 1, 'b', [1, 2, 3], 'c']) == "a1b[1, 2, 3]c"
    assert ansible_native_concat(['a', [1, 2, 3]]) == "[1, 2, 3]"
    assert ansible_native_concat([1, 'b', 'c']) == "1b"

# Generated at 2022-06-22 14:27:01.714871
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # pylint: disable=unused-argument
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 1]) == '11'
    assert ansible_native_concat(['1', '1']) == '11'
    assert ansible_native_concat(['[1, 2]', '[3, 4]']) == '[1, 2][3, 4]'
    assert ansible_native_concat(['1', 2]) == '12'
    assert ansible_native_concat(['1', 2, 3]) == '123'
    assert ansible_native_concat([1, '2', 3]) == '123'
    assert ansible_native_concat([1, 2, '3']) == '123'
    assert ansible_native_concat

# Generated at 2022-06-22 14:27:13.285448
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def base():
        assert ansible_native_concat([]) is None

    def single_node():
        assert ansible_native_concat([True]) is True
        assert ansible_native_concat([False]) is False
        assert ansible_native_concat([1]) == 1
        assert ansible_native_concat([42]) == 42
        assert ansible_native_concat([2.0]) == 2.0
        assert ansible_native_concat([2.5]) == 2.5
        assert ansible_native_concat([u'']) == u''
        assert ansible_native_concat([u'abc']) == u'abc'
        assert ansible_native_concat([b'abc']) == u'abc'

# Generated at 2022-06-22 14:27:22.431324
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import ansible.module_utils.common.text.converters
    from ansible.module_utils.six import PY3, text_type

    if PY3:
        # In Python 3, map is an iterator and not indexable
        # Therefore it is not possible to use a map for this test
        for test_value in [
            [1, 2, 3],
            [8, 9, 10],
            [True, False],
            [None, "None"],
            [1, 2.0],
            ["hello", "world"],
            ["hello", "world", "1"],
            ["s"] * 100,
            ["s"] * 200,
        ]:
            result = ansible_native_concat(map(lambda x: x, test_value))
            assert result == test_value

# Generated at 2022-06-22 14:27:33.318016
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.formatters import to_json
    import ansible_native_concat

    data = {
        'a': 1,
        'b': 'string',
        'c': 1.2,
        'd': 'true',
        'e': True,
        'f': '1',
        'g': '[{true}]',
        'h': '{true}',
        'i': ['1'],
    }

    def _mk_node(value):
        class MockNode:
            def __init__(self, value):
                self.value = value

            def __iter__(self):
                return iter([self.value])

        return MockNode(value)

    for key, value in data.items():
        nodes = []


# Generated at 2022-06-22 14:27:44.983407
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import sys
    import pytest

    from ansible.module_utils.six import PY3, PY37

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    from ansible.template.vars import AnsibleJ2Vars

    class NativeJinjaTextStub(NativeJinjaText):
        obj = None

        def __init__(self, obj):
            self.obj = object

        def render(self, *args, **kwargs):
            return self

        @property
        def jinja_obj(self):
            return self.obj

        @property
        def obj(self):
            return self.obj

    # Test data from jinja2-nativetypes.py

# Generated at 2022-06-22 14:27:58.096353
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test native types
    assert ansible_native_concat([123, '456']) == 123456
    assert ansible_native_concat(['123', 456]) == 123456
    assert ansible_native_concat(['123', 456, '789']) == 123456789

# Generated at 2022-06-22 14:28:09.053502
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([True]) == True
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([1, '2']) == '12'
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat(['1', 2]) == '12'
    assert ansible_native_concat([{}]) == {}
    assert ansible_native_concat([{'a': 1}]) == {'a': 1}
    assert ansible_native_concat(['1, 2']) == '1, 2'

# Generated at 2022-06-22 14:28:21.398935
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def variable_identity(data):
        return data

    data = {
        'ansible_native_concat': ansible_native_concat,
        'variable_identity': variable_identity,
        'vaulted_data': AnsibleVaultEncryptedUnicode('vaulted'),
        'long_int': 12345678901234567890123456789012345678901234567890,
        'e': 2.7182818284590452353602874713527,
        'e_long': 2.7182818284590452353602874713527123456789012345678901234567890,
    }

    c = type('Context', (), data)
    j2env = type('JinjaEnv', (), {})
    j

# Generated at 2022-06-22 14:28:34.117534
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat(["1", "2", "3"]) == 123
    assert ansible_native_concat([1, 2, "3"]) == "123"
    assert ansible_native_concat(["1", 2, 3]) == "123"

    assert ansible_native_concat([1, None]) == 1
    assert ansible_native_concat(None) is None
    assert ansible_native_concat([]) is None

    assert isinstance(ansible_native_concat([None, "1"]), string_types)
    assert isinstance(ansible_native_concat([None, 2]), string_types)

# Generated at 2022-06-22 14:28:47.226372
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([None]) == None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == "12"
    assert ansible_native_concat(['a', 'bc']) == "abc"
    assert ansible_native_concat(('a', 'bc')) == "abc"
    assert ansible_native_concat([1, '', None, [], {}]) == "1"
    assert ansible_native_concat(['2', 1, '', None, [], {}]) == "21"
    assert ansible_native_concat(['-1', '3', '-2']) == "-1-3-2"

# Generated at 2022-06-22 14:28:59.749248
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([] + [1]) == 1
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([1, '2', '3']) == '123'
    assert ansible_native_concat([1, '2', '']) == '12'
    assert ansible_native_concat([1, u'2', u'']) == '12'

# Generated at 2022-06-22 14:29:08.138324
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([None]) == None

    # All examples below are borrowed from the unit tests for Jinja2
    # https://github.com/pallets/jinja/blob/master/tests/test_nativetypes.py

    # Test that single nodes are not parsed as literal
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([{'foo': 42}]) == {'foo': 42}

    # Test that single nodes are not parsed as literal
    # even if they can be parsed by ast.literal_eval
    assert ansible_native_concat(['42']) == '42'

    # Simple data types
    assert ansible_native_concat([1, 2]) == 12

# Generated at 2022-06-22 14:29:13.145188
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    with open('tests/unittests/ansible_native_concat_test_cases.txt',
              mode='r') as f:
        test_cases = f.read()

    test_func = ast.parse(test_cases, mode='exec').body
    for tc in test_func:
        assert tc.value.args[0].value == ansible_native_concat(tc.value.args[1].elts)


# Generated at 2022-06-22 14:29:25.076084
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.native_jinja import NativeJinjaText

    assert ansible_native_concat([]) == None

    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat([[42]]) == [42]
    assert ansible_native_concat(['42']) == '42'
    assert ansible_native_concat([NativeJinjaText('42')]) == '42'

    assert ansible_native_concat([2, '3']) == '23'
    assert ansible_native_concat([2, '3', 4]) == '234'

    assert ansible_native_concat([2, '3', 4, 5, 'test'])

# Generated at 2022-06-22 14:29:30.096266
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == u'12'
    assert ansible_native_concat([1, [2, 3]]) == u'12'
    assert ansible_native_concat([[[1, 2], 3]]) == u'12'
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([False]) is False
    assert ansible_native_concat([1.0]) == 1.0
    assert ansible_native_concat([u'a']) == u'a'
    assert ansible_native_concat([u'a b']) == u'a b'
    assert ansible_native_concat

# Generated at 2022-06-22 14:29:51.467727
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    ast_literal_eval = ast.literal_eval

# Generated at 2022-06-22 14:29:56.211241
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['1', '2', '3']) == '123'
    assert ansible_native_concat([1, '2', '3']) == '123'
    assert ansible_native_concat([1, None, '3']) == '1None3'
    assert ansible_native_concat(range(4)) == '0123'
    assert ansible_native_concat(range(4)) == '0123'
    # Test that we can actually parse the result
    assert ansible_native_concat(['{', '}']) == {}



# Generated at 2022-06-22 14:30:08.501590
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import call, patch

    import units.compat.mock

    class TestAnsibleNativeConcat(unittest.TestCase):
        @patch('ansible.utils.native_jinja.ast.literal_eval')
        def test_native_concat(self, literal_eval_mock):
            # str
            test_data = 'abc'
            out = ansible_native_concat(test_data)
            self.assertEqual(out, test_data)
            literal_eval_mock.assert_not_called()

            # int
            test_data = 1
            out

# Generated at 2022-06-22 14:30:19.807784
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # ansible_native_concat() should return None on empty input
    assert ansible_native_concat([]) is None

    # ansible_native_concat() should return the same object on single input
    assert ansible_native_concat(['test']) == 'test'

    # ansible_native_concat() should return the same object on single input
    assert ansible_native_concat([123]) == 123

    # ansible_native_concat() should return the same object on single input
    assert ansible_native_concat([None]) is None

    # ansible_native_concat() should return the same object on single input
    assert ansible_native_concat([True]) is True

    # ansible_native_concat() should return the same object on single input
    assert ansible_native_concat

# Generated at 2022-06-22 14:30:31.531668
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(()) == None
    assert ansible_native_concat(('a')) == 'a'
    assert ansible_native_concat(('a', 'b')) == 'ab'
    assert ansible_native_concat(('a', 'b')) == 'ab'
    assert ansible_native_concat(('a', 'b', 'c')) == 'abc'
    assert ansible_native_concat((1, 2, 3)) == '123'
    assert ansible_native_concat((True, 'b', 3)) == 'Trueb3'
    assert ansible_native_concat((1, 2, 3, None, '5')) == '123None5'

# Generated at 2022-06-22 14:30:37.762481
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    global_namespace = {
        'list': list,
        'dict': dict
    }

    native_concat = compile(
        '"foo"',
        "<string>",
        'eval',
        dont_inherit=True,
        optimize=False
    ).body.nodes

    assert ansible_native_concat(native_concat) == 'foo'

    from ansible.module_utils.common.text.converters import to_bytes, to_text

    # ast.literal_eval fails to parse Python 3 byte strings.
    # It also fails to parse byte strings with leading whitespace.
    # It was decided that we do not want to strip leading whitespace
    # because that would cause compatibility issues with Jinja2
    # templates in Ansible 2.8 and earlier.
    # See:
    #

# Generated at 2022-06-22 14:30:47.031814
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['1', '2']) == '1 2'
    assert ansible_native_concat(['1', '2', 3]) == '1 2 3'
    assert ansible_native_concat([1, '2', 3]) == '1 2 3'
    assert ansible_native_concat([3]) == 3
    assert ansible_native_concat([True]) == True
    assert ansible_native_concat(['3']) == 3
    assert ansible_native_concat(['3.0']) == 3.0
    assert ansible_native_concat([b'3']) == '3'
    assert ansible_native_concat(['True']) == True
    assert ansible_native_concat(['false']) == False
    assert ansible_

# Generated at 2022-06-22 14:30:58.990868
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # pylint: disable=too-many-branches
    def assert_eq(a, b):
        assert a == b, "expected %r == %r" % (a, b)

    assert_eq(
        ansible_native_concat([
            'foo',
            'bar',
        ]),
        'foo bar',
    )

    assert_eq(
        ansible_native_concat([
            'foo',
            42,
            'bar',
        ]),
        'foo 42 bar',
    )


# Generated at 2022-06-22 14:31:11.401947
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def assert_result(expected, args):
        assert ansible_native_concat(args) == expected

    assert_result('', [])
    assert_result(None, [None])
    assert_result('Hello', ['Hello'])
    assert_result(42, [42])
    assert_result(False, [False])
    assert_result(None, [None])

    assert_result('', ['', None])
    assert_result(None, [None, ''])
    assert_result('Hello', ['Hello', None])
    assert_result('42', ['42', None])
    assert_result(None, [None, None])

    assert_result('', ['', '', None])
    assert_result('Hello', ['', 'Hello', ''])
    assert_result('42', ['', '42', ''])

# Generated at 2022-06-22 14:31:18.073524
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:31:42.138788
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Test empty list
    assert ansible_native_concat([]) == None

    # Test single strings
    assert ansible_native_concat(['hello']) == 'hello'

    # Test multiple strings
    assert ansible_native_concat(['hello', 'world']) == 'helloworld'

    # Test single strings with leading whitespace
    assert ansible_native_concat([u'   hello']) == u'   hello'

    # Test multiple strings with leading whitespace
    assert ansible_native_concat([u'   hello', u'   world']) == u'   helloworld'

    # Test multiple strings with leading whitespace for one item
    assert ansible_native_concat([u'hello', u'   world']) == u'helloworld'

    # Test single booleans

# Generated at 2022-06-22 14:31:51.907121
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import Environment

    env = Environment(extensions=['ansible.utils.native_jinja.NativeJinjaExtension'])
    env.undefined = StrictUndefined

    # single value
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat(['hello world']) == 'hello world'

    # sequence
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat([1, None, 3]) == [1, None, 3]
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'

    # tuple

# Generated at 2022-06-22 14:32:03.378264
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # String concatenation and literal evaluation
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(['a', 1, 'b', 2]) == 'a1b2'

    # Literal evaluation
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['1.0']) == 1.0
    assert ansible_native_concat(['"1"']) == '1'
    assert ansible_native_concat(['[1, 2, 3]']) == [1, 2, 3]
    assert ansible_native_concat(['"foo"']) == 'foo'
    assert ans

# Generated at 2022-06-22 14:32:09.516964
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None

    # Make sure literal_eval is not called on non-string values.
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat(['']) == ''

    # Make sure non-string values in a list are not evaluated.
    assert ansible_native_concat(['', 42]) == '42'

    # Make sure literal_eval is called on string values.
    assert ansible_native_concat(['', '42']) == 42

    # Make sure literal_eval is not called on strings with errors.
    assert ansible_native_concat(['', '"42']) == '"42'
    assert ansible_native_concat(['', '42"']) == '42"'

    # Test empty strings.
    assert ans