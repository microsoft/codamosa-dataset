

# Generated at 2022-06-22 14:22:21.978953
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat(('a', 'b', 'c')) == 'abc'
    assert ansible_native_concat([1, 'b', 'c']) == '1bc'
    assert ansible_native_concat(['a', 2, 'c']) == 'a2c'
    assert ansible_native_concat(['a', 'b', 3]) == 'ab3'
    assert container_to_text(ansible_native_concat(['a', 'b', 3])) == container_to_text(text_type('ab3'))
    assert ansible_native_concat(['a', 'b', 3]) == text_type('ab3')

# Generated at 2022-06-22 14:22:34.718142
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat(['1234']) == 1234
    assert ansible_native_concat(['1234.56']) == 1234.56
    assert ansible_native_concat([1234]) == 1234
    assert ansible_native_concat(['fooo_bar']) == "fooo_bar"
    assert ansible_native_concat(['foo', 'bar']) == "foobar"
    assert ansible_native_concat(['foo', 'bar']) == "foobar"

# Generated at 2022-06-22 14:22:41.709339
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.module_utils.common.text import keyword_search


# Generated at 2022-06-22 14:22:48.801310
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.constructor import Constructor
    from ansible.parsing.yaml.representer import AnsibleSafeRepresenter
    from ansible.utils.vault import VaultLib
    import contextlib
    import yaml

    yaml.add_representer(AnsibleVaultEncryptedUnicode, AnsibleSafeRepresenter.represent_str)
    yaml_constructor = Constructor()
    yaml_constructor.add_constructor(u'tag:yaml.org,2002:str', lambda loader, node: AnsibleVaultEncryptedUnicode(loader.construct_scalar(node)))

# Generated at 2022-06-22 14:23:01.970065
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([u'0']) == '0'
    assert ansible_native_concat([u'one']) == 'one'
    assert ansible_native_concat([u'123']) == 123
    assert ansible_native_concat([u'[]']) == []
    assert ansible_native_concat([u'[1, 2, 3]']) == [1, 2, 3]
    assert ansible_native_concat([u'[1, 2, "3"]']) == [1, 2, "3"]
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_con

# Generated at 2022-06-22 14:23:13.989706
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat([1, '2', 3]) == [1, '2', 3]
    assert ansible_native_concat([1, '2', '3']) == [1, '2', '3']
    assert ansible_native_concat(['1', '2', '3']) == '1, 2, 3'
    assert ansible_native_concat(['{', '"a"', ':', '1', '}']) == {'a': 1}
    assert ansible_native_concat([' "a" ', ':', ' 1 ']) == {'a': 1}

# Generated at 2022-06-22 14:23:27.288810
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # pylint: disable=unused-variable,unused-argument
    def assert_equal(result, expected):
        assert result == expected, 'expected "%s", got "%s"' % (expected, result)

    def assert_isinstance(result, expected):
        assert isinstance(result, expected), 'expected type "%s", got "%s"' % (expected, type(result))

    # Test concat of multiple nodes
    assert_isinstance(ansible_native_concat([1, 2, 3]), int)
    assert_equal(ansible_native_concat([1, 2, 3]), 123)
    assert_equal(ansible_native_concat(['foo', 'bar', 'baz']), 'foobarbaz')
    assert_equal(ansible_native_concat([True, False]), 'TrueFalse')

   

# Generated at 2022-06-22 14:23:36.104901
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['test']) == 'test'
    assert ansible_native_concat(['test', 'test']) == 'testtest'
    assert ansible_native_concat(['test', 42]) == 'test42'
    assert ansible_native_concat([42, 'test']) == '42test'
    assert ansible_native_concat([42, 43]) == 42 + 43
    assert ansible_native_concat(['test\n', 42]) == 'test\n42'
    assert ansible_native_concat([42, 'test\n']) == '42test\n'
    assert ansible_native_concat([True, False]) is True and False

# Generated at 2022-06-22 14:23:47.741852
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_bytes

    class Barrier:
        """A helper class for ensuring that we can convert an object to
        bytes and find the object again with ast.literal_eval.
        """

        def __init__(self, obj):
            self.obj = obj

    def _assert(x, y):
        """Assert that the native concatenation of the given objects is
        equal to the given expected result.
        """
        out = ansible_native_concat((x, y))
        assert out is not None
        assert out == y

    _assert(Barrier('a'), 'a')
    _assert(Barrier(42), 42)
    _assert(Barrier(None), None)
    _assert(Barrier(False), False)

    # A test to

# Generated at 2022-06-22 14:23:57.030194
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.vars.unsafe_proxy import define_unsafe_proxy

    int_node = define_unsafe_proxy(123)
    str_node = define_unsafe_proxy('foo')
    list_node = define_unsafe_proxy(['1', '2', '3'])
    dict_node = define_unsafe_proxy({'x': '1', 'y': '2', 'z': '3'})

    assert ansible_native_concat([]) is None
    assert ansible_native_concat([int_node]) == 123
    assert ansible_native_concat([str_node]) == 'foo'
    assert ansible_native_concat([list_node]) == ['1', '2', '3']

# Generated at 2022-06-22 14:24:10.493995
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat(['Da', 'ta']) == 'Data'
    assert ansible_native_concat(['1', 2]) == '12'
    assert ansible_native_concat(['1', 2, '3']) == '123'

    assert ansible_native_concat(['1', '2', None]) == '12'
    assert ansible_native_concat(['1', None, '3']) == '13'
    assert ansible_native_concat([None, '2', '3']) == '23'
    assert ansible_native_concat([None, None]) == None


# Generated at 2022-06-22 14:24:17.795598
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from . import _ansible_native_concat_tests
    assert _ansible_native_concat_tests.test_ansible_native_concat.__doc__
    test_cases = _ansible_native_concat_tests.test_ansible_native_concat()
    for name, test_case in test_cases.items():
        expected = test_case.pop('expected')
        result = ansible_native_concat(**test_case)
        assert result == expected, (
            "Testing ansible_native_concat: test case %s" % name)


# Generated at 2022-06-22 14:24:29.606105
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2]) == [1, 2]
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([1, 'bar']) == '1bar'
    assert ansible_native_concat(['foo', 2]) == 'foo2'
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat(u'foobar') == u'foobar'
    assert ansible_native_concat(u'foo\nbar') == u'foo\nbar'
    assert ansible_native_concat(u'f\n\nbar') == u'f\n\nbar'


# Generated at 2022-06-22 14:24:41.831709
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils import object_hash

    templar = Templar(loader=None)

    def _get_id(value):
        # These are unique identifiers for each API-related object
        # that we use in the tests.
        if isinstance(value, AnsibleVaultEncryptedUnicode):
            return object_hash(value.data)
        else:
            return object_hash(value)

    def _test_concat(nodes, expected, templar=templar):
        # test_concat is designed to work with a list of objects that
        # are or can be converted to strings.
        out = ansible_native_concat(nodes)
        assert _

# Generated at 2022-06-22 14:24:51.918439
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test the case when nodes is None
    assert ansible_native_concat(None) is None

    # Test the case when nodes is empty
    assert ansible_native_concat([]) is None

    # Test the case when nodes is one element
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1.0]) == 1.0
    assert ansible_native_concat(['1']) == '1'
    assert ansible_native_concat([u'1']) == u'1'
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([False]) is False

    # Test the case when nodes is not one element
    assert ansible_native_concat([0, 2, 3]) == '023'

# Generated at 2022-06-22 14:25:01.308241
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # these tests are taken from nativetypes.py
    # https://github.com/pallets/jinja/blob/master/src/jinja2/tests/test_nativetypes.py
    import jinja2

# Generated at 2022-06-22 14:25:13.144435
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2.nodes import Output, Node, EvalContext
    from jinja2.runtime import Undefined
    from ansible.module_utils.common.text.converters import (
        bool_to_int, container_to_text
    )

    class TemporaryBuiltinModule(object):
        """Temporary builtin module."""
    builtin_mod = TemporaryBuiltinModule()
    builtin_mod.abs = abs
    builtin_mod.int = int

    class TemporaryContext():
        """Temporary context."""
        builtins = builtin_mod
        environment = None
        eval_ctx = EvalContext()

    class TemporaryEnvironment():
        """Temporary environment."""
        contextclass = TemporaryContext

    env = TemporaryEnvironment()

    def make_node(value):
        """Generate a simple node."""

# Generated at 2022-06-22 14:25:25.991136
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Testing empty list
    assert None is ansible_native_concat([])
    # Testing one item list
    assert 'Test' == ansible_native_concat(['Test'])
    # Testing one item list with integer
    assert 1000 == ansible_native_concat([1000])
    # Testing list with multiple items
    assert 'Test,1000' == ansible_native_concat(['Test', 1000])
    # Testing list with multiple items ending with a list
    assert 'Test,[1, 2, 3]' == ansible_native_concat(['Test', [1, 2, 3]])
    # Testing empty dictionary
    assert {} == ansible_native_concat({})
    # Testing dictionary with one key-value pair

# Generated at 2022-06-22 14:25:34.314128
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat(['foo', 'bar', 'qux']) == u'foobarqux'
    assert ansible_native_concat(['foo', 'bar', 123]) == u'foobar123'
    assert ansible_native_concat(['foo', 'bar', '123']) == 123
    assert ansible_native_concat(['foo', 'bar', '123', '456']) == u'foobar123456'



# Generated at 2022-06-22 14:25:42.691801
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Make sure the function is exposed to the module
    from ansible.module_utils.common.text import _text
    assert hasattr(_text, 'ansible_native_concat')

    # Test simple strings
    assert ansible_native_concat([u'Hello', u' ', u'World!']) == u'Hello World!'
    assert ansible_native_concat([u'Hello', u' ', 'World!']) == u'Hello World!'
    assert ansible_native_concat(['Hello', u' ', u'World!']) == u'Hello World!'
    assert ansible_native_concat(['Hello', u' ', 'World!']) == u'Hello World!'
    assert ansible_native_concat([u'Hello', ' ', 'World!']) == u'Hello World!'
    assert ansible_native_concat

# Generated at 2022-06-22 14:25:55.896473
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    datatypes = {
        'string': 'string',
        'integer': 42,
        'float': 3.14,
        'list': [1, 2, 3],
        'dict': {'foo': 42},
        'none': None,
        'true': True,
        'false': False
    }

    # Test all datatypes
    for key in datatypes:
        output = ansible_native_concat([datatypes[key]])
        assert output == datatypes[key]
        assert isinstance(output, type(datatypes[key]))

    # Test single string concat
    output = ansible_native_concat([datatypes['string'], datatypes['string']])
    assert isinstance(output, text_type)
    assert output == 'stringstring'

    #

# Generated at 2022-06-22 14:26:07.684859
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class TestSequence(list):
        def __init__(self, *args, **kwargs):
            super(TestSequence, self).__init__(*args, **kwargs)

        def __str__(self):
            return '<%s>' % super(TestSequence, self).__str__()

        def __repr__(self):
            return 'TestSequence(%s)' % super(TestSequence, self).__repr__()

    class TestInnerMapping:
        def __init__(self, *args, **kwargs):
            self.dic = dict(*args, **kwargs)

        def __getitem__(self, item):
            return self.dic[item]

        def __setitem__(self, key, value):
            self.dic[key] = value

       

# Generated at 2022-06-22 14:26:17.776072
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, ['a', 'b']]) == '1["a", "b"]'
    assert ansible_native_concat([1, 'foo', 2]) == '1foo2'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(['a', ['b', ['c']]]) == 'a["b", ["c"]]'
    assert ansible_native_concat([1, 'foo', ['a', 2], [3, 'bar']]) == '1foo["a", 2][3, "bar"]'

# Generated at 2022-06-22 14:26:30.261458
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:26:35.261827
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == 1
    assert ansible_native_concat([1, '+', 2, '+', 3]) == 1
    assert ansible_native_concat([1, '"Hello', '" ', 'World']) == 'Hello World'



# Generated at 2022-06-22 14:26:46.320325
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat(['a', 2, 3]) == 'a23'
    assert ansible_native_concat(['a', 2, 3]) == 'a23'
    assert ansible_native_concat([1, 'b', 3]) == '1b3'
    assert ansible_native_concat([1, 'b', 3]) == '1b3'
    assert ansible_native_concat([1, 2, 'c']) == '12c'
    assert ansible_native_concat([1, 2, 'c']) == '12c'

# Generated at 2022-06-22 14:26:58.591280
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    v = {"data": AnsibleUnsafeText(u"y\\'a")}
    loader = AnsibleLoader(v, False, None)
    d = loader.get_single_data()
    assert isinstance(d, AnsibleUnsafeText)
    d = to_text(d)
    assert isinstance(d, text_type)
    assert isinstance(ansible_native_concat(d), text_type)

    v = {"data": AnsibleUnsafeText(u"y\\'a")}
    loader = AnsibleLoader(v, True, None)
    d = loader.get_single_data()
    assert isinstance(d, AnsibleUnsafeText)

# Generated at 2022-06-22 14:27:06.297511
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, '2', 3]) == u'123'
    assert ansible_native_concat([1, '2', 3, '4']) == u'1234'
    assert ansible_native_concat([1, '2', 3, None]) == u'123'
    assert ansible_native_concat(['1', '2', '3']) == u'123'
    assert ansible_native_concat(['1', '2', '3', '4']) == u'1234'
    assert ansible_native_concat(['1', '2', '3', None]) == u'123'
    assert ansible_native_concat(['1', '2', '3', u'4']) == u'1234'
    assert ansible_native_concat

# Generated at 2022-06-22 14:27:18.594042
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:27:30.113268
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test with jinja template.
    # TODO: we need to import ansible.parsing.yaml.objects.yaml_objects
    # to avoid a circular dependency to install Ansible. See
    # https://docs.ansible.com/ansible/devel/dev_guide/developing_plugins.html#virtual-environment-setup
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.native_jinja import AnsibleNativeJinjaText

    # Native JinjaText does not have a usable __str__ method.
    # TODO: This test may change once we have a better way to handle
    # __str__ in NativeJinjaText.

# Generated at 2022-06-22 14:27:45.825253
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_native

    assert ansible_native_concat([]) is None

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == u'12'

    assert ansible_native_concat([u'abc']) == 'abc'
    assert ansible_native_concat([u'abc', u'def']) == u'abcdef'

    assert ansible_native_concat(['abc', u'def']) == u'abcdef'

    # lazy values
    it = (i for i in [1, 2])
    assert ansible_native_concat(it) == 1

    it = (i for i in [1, 2, 3])
    assert ansible_native_con

# Generated at 2022-06-22 14:27:56.577848
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:28:07.973895
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat([42, 'foo']) == '42foo'
    assert ansible_native_concat(['foo', None, 'bar']) == 'fooNonebar'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', None, 'bar', 42]) == 'fooNonebar42'
    assert ansible_native_concat([42, 'foo']) == '42foo'
    assert ansible_native_concat([42, 'foo', None]) == '42fooNone'

# Generated at 2022-06-22 14:28:21.026541
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_text


# Generated at 2022-06-22 14:28:33.660495
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(['abc']) == 'abc'
    assert ansible_native_concat(['abc', 'def']) == 'abcdef'
    assert ansible_native_concat(['ab', 'cd', 'ef']) == 'abcdef'
    assert ansible_native_concat([0, ' abc']) == 0
    assert ansible_native_concat(['true', 'false']) == True
    assert ansible_native_concat(['test', True, None]) == 'testTrueNone'
    assert ansible_native_concat([{'a': 10, 'b':20}]) == {'a': 10, 'b':20}

# Generated at 2022-06-22 14:28:46.707093
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """
    Test if ansible_native_concat() properly behaves according to Jinja2.
    """

# Generated at 2022-06-22 14:28:59.370837
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    args = [
        (['foo', 'bar', 'baz'], 'foobarbaz'),
        ([u'foo', u'bar', u'baz'], 'foobarbaz'),
        ([123, 345, 567], '123456567'),
        ([1, 2, 3], 6),
        ([u'a', 'b', u'c'], 'abc'),
        (['abc', 'def'], 'abcdef'),
        ([u'abc', 'def'], 'abcdef'),
        (['123', 456], '123456'),
        ([u'123', 456], '123456'),
        ([1, 2, 3, 4, 5], '12345'),
        ([], None),
    ]
    for given, expected in args:
        assert ansible_native_concat(given) == expected

# Generated at 2022-06-22 14:29:07.889346
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([u'foo', u'bar', True]) == u'foobarTrue'
    assert ansible_native_concat([True, u'foo', u'bar']) == u'Truefoobar'
    assert ansible_native_concat([u'foo', True, u'bar']) == u'footruebar'

    # Encrypted data will always be returned as a string
    assert ansible_native_concat([AnsibleVaultEncryptedUnicode(u'foo\nbar')]) == u'foo\nbar'

    # Special marker to skip literal_eval
    assert ansible_native_concat([NativeJinjaText(u'foo\nbar')]) == u

# Generated at 2022-06-22 14:29:15.956355
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import pytest
    from ansible.module_utils.compat.ipaddress import IPv4Address

    # Test single literal type
    assert ansible_native_concat([1]) == 1

    # Test single string type
    assert ansible_native_concat(['abc']) == 'abc'

    # Test single string type containing digits
    assert ansible_native_concat(['123']) == 123

    # Test single string type containing IP address
    assert ansible_native_concat(['10.10.10.10']) == IPv4Address('10.10.10.10')

    # Test single string type containing list
    assert ansible_native_concat(['[1, 2]']) == [1, 2]

    # Test single string type containing dict

# Generated at 2022-06-22 14:29:28.320713
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(
        [container_to_text(1), container_to_text(2)]
    ) == 12
    assert ansible_native_concat(
        [container_to_text(1), container_to_text(2)],
    ) == 12
    assert ansible_native_concat(
        [container_to_text(1), container_to_text([2])]
    ) == [1, 2]
    assert ansible_native_concat(
        [container_to_text(1), container_to_text([2])],
    ) == [1, 2]
    assert ansible_native_concat(
        [container_to_text(1), container_to_text({'a': 2})]
    ) == {'a': 2, '0': 1}

# Generated at 2022-06-22 14:29:44.105257
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.six.moves import cStringIO as StringIO
    from ansible.parsing.yaml.loader import AnsibleLoader


# Generated at 2022-06-22 14:29:55.426211
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.native import NativeBytes
    from ansible.parsing.yaml.objects import AnsibleUnicode

    free_form = ansible_native_concat(['spam ', AnsibleUnicode('eggs '), NativeBytes('bacon')])
    assert free_form == 'spam eggs bacon'

    list_form = ansible_native_concat([[1, 2, 3], ['a', 'b', 'c']])
    assert list_form == [1, 2, 3, 'a', 'b', 'c']

    dict_form = ansible_native_concat([{'one': 1, 'two': 2}, {'three': 3}])
    assert dict_form == {'one': 1, 'two': 2, 'three': 3}

    dict_

# Generated at 2022-06-22 14:30:07.681233
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.template.vars import AnsibleJ2Vars
    vars = AnsibleJ2Vars()


# Generated at 2022-06-22 14:30:18.284241
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    head = list(islice(nodes, 2))

    if not head:
        assert ansible_native_concat(nodes) == None

    if len(head) == 1:
        assert ansible_native_concat(nodes) == head[0]
        if isinstance(head[0], string_types):
            assert ansible_native_concat(nodes) == 'Default'
        else:
            assert not(ansible_native_concat(nodes) == 'Default')

    else:
        if isinstance(nodes, types.GeneratorType):
            nodes = chain(head, nodes)
        assert ansible_native_concat(nodes) in ['Default', True, False]



# Generated at 2022-06-22 14:30:30.976097
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2]) == 1
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([]) is None

    assert ansible_native_concat([u'a', 2]) == u'a2'
    assert ansible_native_concat(['a', 2]) == 'a2'
    assert ansible_native_concat((text_type('a'), 2)) == text_type('a2')
    assert ansible_native_concat([u'a']) == u'a'
    assert ansible_native_concat([text_type('a')]) == text_type('a')

    assert ansible_native_concat(iter([u'a', 2])) == u'a2'

# Generated at 2022-06-22 14:30:43.787893
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # poormans test of the native concat function
    # this tests the basic functionalities to ensure this method
    # proxies to the proper jinja2 native_concat
    # and allows us to add some sanity checks in there as well

    native_concat = ansible_native_concat

    assert native_concat([42, 43]) == 85
    assert native_concat(['foo', 'bar']) == 'foobar'
    assert native_concat(['a', 1, 'b', 2]) == 'a1b2'

    assert native_concat(['\n', 'stuff']) == '\nstuff'
    assert native_concat(['\n', '\n', 'stuff']) == '\n\nstuff'

    # single element
    assert native_concat([42]) == 42
    assert native

# Generated at 2022-06-22 14:30:55.069970
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = [['foo', 'bar'], 'baz', ['qux', 'quux']]
    expected_string_result = {
        'foo bar baz qux quux',
        'foo barbazquxquux',
        'foobarbazquxquux'
    }
    expected_list_result = {'foo bar', 'baz', 'qux quux', 'foo barbazquxquux'}

    result = ansible_native_concat(nodes)

    assert result in expected_string_result or result in expected_list_result


ansible_concat = container_to_text(ansible_native_concat)



# Generated at 2022-06-22 14:31:02.220705
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    string = 'string'
    value = 'value'
    integer = 5
    float_number = 3.14
    boolean = True
    unicode_str = u'unicode \u2713'
    list_str = ['list'.encode('utf-8'), 'of'.encode('utf-8'), 'strings'.encode('utf-8')]
    list_str_ascii = ['list', 'of', 'strings']
    list_int = [1, 2, 3]
    list_int_str = [1, '2', 3]
    list_str_int = ['1', 2, '3']
    dict_str_int = {'key1': 1, 'key2': 2, 'key3': 3}
    dict_int

# Generated at 2022-06-22 14:31:12.033282
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def assert_equal(value, expected):
        if value == expected:
            return
        assert container_to_text(value) == container_to_text(expected)

    assert_equal(ansible_native_concat([]), None)
    assert_equal(ansible_native_concat(['abc']), 'abc')
    assert_equal(ansible_native_concat(['abc\n', 'def']), 'abc\ndef')
    assert_equal(ansible_native_concat(['1', '2', '3']), '123')
    assert_equal(ansible_native_concat(['1', '2', '3']), '123')
    assert_equal(ansible_native_concat(['[1,2,3]']), [1, 2, 3])

# Generated at 2022-06-22 14:31:23.529352
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat(["a", 1, None]) == "a1None"
    assert ansible_native_concat(["a", 1, None]) == "a1None"
    assert ansible_native_concat(["a", "b", "c", "d"]) == "abcd"
    assert ansible_native_concat(["a", "b", "c", "d"]) == "abcd"
    assert ansible_native_concat(['"', '"']) == "\"\""
    assert ansible_native_concat(["a", None, "b", '""', "c", "d"]) == "a Noneb\"\"cd"
    assert ansible_native_con

# Generated at 2022-06-22 14:31:38.961476
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Make sure ansible_native_concat behaves as expected"""
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(["Hello"]) == "Hello"
    assert ansible_native_concat(["Hello", " World"]) == "Hello World"
    assert ansible_native_concat(["'Hello", "' World"]) == "Hello World"
    assert ansible_native_concat(["1", "+", "2"]) == 3
    assert ansible_native_concat(["True"]) is True
    assert ansible_native_concat(["[", "1", ",", "2]"]) == [1, 2]

# Generated at 2022-06-22 14:31:49.040468
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['true']) is True
    assert ansible_native_concat(['false']) is False
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['1.2']) == 1.2
    assert ansible_native_concat(['bob']) == 'bob'
    assert ansible_native_concat(['{}']) == {}
    assert ansible_native_concat(['[]']) == []
    assert ansible_native_concat(['bob', 'jim']) == 'bobjim'
    assert ansible_native_concat(['bob', 'jim', 'bill']) == 'bobjimbill'
   

# Generated at 2022-06-22 14:32:00.774730
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import types

    def _test_fully_wrapped_string(node):
        assert isinstance(ansible_native_concat([node, node]), string_types)

    def test_string():
        yield (string_types[0], string_types[0])
        yield (string_types[1], string_types[1])
        yield (u'string', string_types[0])
        yield (u'string', string_types[1])
        yield (u'string', u'string')
        yield (container_to_text(u'string'), string_types[0])
        yield (container_to_text(u'string'), string_types[1])
        yield (container_to_text(u'string'), u'string')

    # TODO: NativeJinjaText
    # TODO

# Generated at 2022-06-22 14:32:10.154066
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    class DummyNode:
        def __init__(self, value):
            self.value = value

        # Workaround for native jinja text
        def convert(self, converter):
            return self

        def __str__(self):
            return container_to_text(self.value)

    def nodes(*values):
        for value in values:
            yield DummyNode(value)

    assert ansible_native_concat(nodes()) is None
    assert ansible_native_concat(nodes('abc')) == 'abc'
    assert ansible_native_concat(nodes(5)) == 5
    assert ansible_native_concat(nodes('5')) == '5'
    assert ansible_native_concat(nodes(b'5')) == b'5'