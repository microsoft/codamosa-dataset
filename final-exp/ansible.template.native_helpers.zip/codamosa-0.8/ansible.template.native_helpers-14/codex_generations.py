

# Generated at 2022-06-22 14:22:32.645519
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Originally, this was just a copy of ansible_native_concat for 2.4
    # compatibility. Now it is mostly a copy of the above, but with some other
    # 2.4 compatibility tweaks needed for the different native_concat_*
    # functions.
    from jinja2 import Undefined, native_concat

    assert native_concat([]) is None

    assert native_concat(['foo']) == 'foo'
    assert native_concat(['foo', 'bar']) == 'foobar'
    assert native_concat(['foo', 'bar', 3]) == 'foobar3'
    assert native_concat(['foo', 'bar', []]) == 'foobar[]'
    assert native_concat(['foo', 'bar', '3']) == 'foobar3'
    assert native_

# Generated at 2022-06-22 14:22:45.061432
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'foo']) == u'foo'

    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'

    assert ansible_native_concat([u'foo', 42]) == u'foo42'

    assert ansible_native_concat([u'foo', u'bar', 42]) == u'foobar42'

    assert ansible_native_concat([True]) is True

    assert ansible_native_concat([42]) == 42

    assert ansible_native_concat([42, u'foo']) == u'42foo'

    assert ansible_native_concat([42, u'foo', True]) == u'42footrue'

    assert ansible_native_concat([42, u'foo', u'bar'])

# Generated at 2022-06-22 14:22:57.577951
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Literals don't require Quoting
    assert ansible_native_concat([False]) == False
    assert ansible_native_concat([True]) == True
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([0]) == 0
    assert ansible_native_concat([-2]) == -2
    assert ansible_native_concat([5]) == 5
    assert ansible_native_concat([]) == ''
    assert ansible_native_concat([2.2]) == 2.2
    assert ansible_native_concat([2.2, 3.3]) == 5.5
    assert ansible_native_concat([2.2, 3.3, 9.1]) == 14.6

# Generated at 2022-06-22 14:23:10.212556
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Unit test that tests our ansible_native_concat function."""
    import textwrap

    def _test_node_value(node, expect):
        result = ansible_native_concat(node)
        assert expect == result, "unexpected result {}, expected {}".format(result, expect)

    # Sequence of values
    _test_node_value([1, 2], '12')

    # String
    _test_node_value([u"string", u"value"], "stringvalue")

    # Non-string
    _test_node_value([False, 10], 'False10')

    # None
    _test_node_value([None], 'None')

    # Generator
    _test_node_value(chain([u"string"], [u"value"]), "stringvalue")

    # Evaluable expression
    _test

# Generated at 2022-06-22 14:23:23.259516
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat(['a', 'b', 'c']) == "abc"
    assert ansible_native_concat(['a', 'b', 'c']) == "abc"
    assert ansible_native_concat([True, False, True]) == True
    assert ansible_native_concat(['a', 'b', 'c', 'd']) == "abcd"
    assert ansible_native_concat(['a', 'b', 'c', 'd', 'e']) == "abcde"
    assert ansible_native_concat([1, 'b', 'c', 'd', 'e']) == [1, 'b', 'c', 'd', 'e']

# Generated at 2022-06-22 14:23:32.832936
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:23:44.854846
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Tests for ansible_native_concat.
    """
    import json
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.loader import AnsibleLoader


# Generated at 2022-06-22 14:23:56.510288
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.data import AnsibleVaultEncryptedUnicode
    from ansible.utils.native_jinja import native_text

    # Originally the only thing this function did was concatenation.
    assert ansible_native_concat([u'ab', u'cd']) == u'abcd'
    assert ansible_native_concat([u'ab', u'', u'cd']) == u'abcd'
    assert ansible_native_concat([u'42', u'cd']) == u'42cd'

    # None is returned if no nodes are given.
    assert ansible_native_concat([]) is None

    # There's some logic to determine whether to keep the output as a string
    # or try to parse it as a Python literal.
    assert ansible_native_

# Generated at 2022-06-22 14:24:08.748827
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['abc']) == 'abc'
    assert ansible_native_concat(['True']) == True
    assert ansible_native_concat(['1, 2']) == [1, 2]
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat(['1', '', '2']) == '12'
    assert ansible_native_concat(['True', 'false']) == 'Truefalse'
    assert ansible_native_concat(['a', 'b']) == 'ab'

# Generated at 2022-06-22 14:24:18.393660
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    name = 'ansible_native_concat'
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    l = [('a'*50000), 'b', 'c', 'd', 1, 2, 0, [], (), None, '', 1+2j, {}, {'a': 1}]
    l = [unicode(x) for x in l]
    assert ansible_native_concat(l) == unicode(u''.join(l))

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([]) is None

    assert ansible_native_concat([' 1']) == ' 1'
    assert ansible_native_concat

# Generated at 2022-06-22 14:24:31.073755
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat([42, 43, 44]) == u'424344'
    assert ansible_native_concat([None, None]) == u'NoneNone'
    assert ansible_native_concat([u'1']) == u'1'
    assert ansible_native_concat([u'1', u'2']) == u'12'
    assert ansible_native_concat([u'x', 42]) == u'x42'
    assert ansible_native_concat([u'u', u'8']) == u'u8'
    assert ansible_native_concat([u'a', u'b', u'c']) == u'abc'
   

# Generated at 2022-06-22 14:24:39.871202
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([[1, 2], 3]) == '[1, 23]'
    assert ansible_native_concat([[1, 2], '3']) == '[1, 23]'
    assert ansible_native_concat([[1, 2], '3', 4]) == '[1, 234]'



# Generated at 2022-06-22 14:24:48.437737
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # test efficiency
    assert ansible_native_concat([[0]]) == 0
    assert ansible_native_concat([[1]]) == 1
    assert ansible_native_concat([[]]) is None
    assert ansible_native_concat([]) is None

    # test concat
    assert ansible_native_concat([[0], [1]]) == '01'

    # test parsing
    assert ansible_native_concat([[0], [1], [' + ', 2]]) == 3
    assert ansible_native_concat([[''], ['x'], [0], [1], [' + ', 2]]) == 'x01'
    assert ansible_native_concat(['"x', '"', '"y']) == 'xy'

# Generated at 2022-06-22 14:24:59.243795
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([['a']]) == ['a']
    assert ansible_native_concat([{'a': 1}]) == {'a': 1}
    assert ansible_native_concat(['1.0']) == '1.0'
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', 1]) == 'a1'
    assert ansible_native_concat([[1], '2']) == '[1]2'
   

# Generated at 2022-06-22 14:25:07.173847
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import pytest

    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat(x for x in range(10)) == '0123456789'
    assert ansible_native_concat(x for x in range(10)) == '0123456789'

    with pytest.raises(StrictUndefined):
        ansible_native_concat(StrictUndefined())

    with pytest.raises(StrictUndefined):
        ansible_native_concat([StrictUndefined(), 1])

    with pytest.raises(StrictUndefined):
        ansible_native_concat([1, StrictUndefined()])

# Generated at 2022-06-22 14:25:11.904617
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import ansible.parsing.yaml.objects
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    assert ansible_native_concat([]) is None
    assert ansible_native_concat([42]) == 42

    v = AnsibleVaultEncryptedUnicode('foobar', b'AES256')
    assert ansible_native_concat([v]) == 'foobar'

    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 42, 'bar']) == 'foo42bar'
    assert ansible_native_concat([42, 'foo', 42, 'bar']) == '42foo42bar'


# Generated at 2022-06-22 14:25:21.178538
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:25:33.204063
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Call function directly, no need to use Jinja for testing
    from ansible.module_utils.common.text.converters import to_text

    def jinjastr(data):
        return NativeJinjaText(data)

    assert ansible_native_concat([jinjastr('{'), jinjastr('"a": 1'), jinjastr('}')]) == {'a': 1}
    assert ansible_native_concat([jinjastr('{"a": 1}')]) == {'a': 1}
    assert ansible_native_concat([jinjastr('[1, 2, 3]')]) == [1, 2, 3]
    assert ansible_native_concat([jinjastr('"hello"')]) == u'hello'
    assert ansible_native_

# Generated at 2022-06-22 14:25:42.306571
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # The simple cases where only one node from the template is evaluated
    assert ansible_native_concat(('string',)) == 'string'
    assert ansible_native_concat((1,)) == 1
    assert ansible_native_concat((True,)) is True
    assert ansible_native_concat((None,)) is None

    # When multiple nodes are evaluated, concat the result of all nodes and
    # return the evaluated value. If the result cannot be evaluated, return it
    # as a string
    assert ansible_native_concat((1, 2)) == '12'
    assert ansible_native_concat((1, 'b')) == '1b'
    assert ansible_native_concat(('a', 1)) == 'a1'

# Generated at 2022-06-22 14:25:53.921285
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2.runtime import Undefined

    assert ansible_native_concat(['hello', 'world']) == 'helloworld'
    assert ansible_native_concat(['123', '456']) == 123456
    assert ansible_native_concat([123, 456]) == 123456
    assert ansible_native_concat(['123', '456']) == 123456
    assert ansible_native_concat([[1, 2], [3, 4]]) == [1, 2, 3, 4]
    assert ansible_native_concat([[1, 2], [3, 4]]) == [1, 2, 3, 4]
    assert ansible_native_concat(['hello', Undefined(), 'world']) == 'helloworld'

# Generated at 2022-06-22 14:26:07.500911
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:26:17.648940
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2.runtime import Undefined

    # None
    assert ansible_native_concat([None]) is None

    # scalars
    assert ansible_native_concat([False]) is False
    assert ansible_native_concat([0]) == 0
    assert ansible_native_concat([""]) == ''
    assert ansible_native_concat(["a"]) == 'a'
    assert ansible_native_concat(['"a"']) == '"a"'
    assert ansible_native_concat(["'a'"]) == "'a'"
    assert ansible_native_concat([u"\xa3"]) == u'\xa3'
    assert ansible_native_concat([u"\u20ac"]) == u'\u20ac'
    assert ansible

# Generated at 2022-06-22 14:26:30.160971
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.six.moves.builtins import str
    from ansible.module_utils.six import binary_type
    import sys

    assert 'None' == str(ansible_native_concat([]))
    assert 'None' == str(ansible_native_concat(None))
    assert 'None' == str(ansible_native_concat([None]))

    assert 1 == ansible_native_concat(['1'])
    assert 1 == ansible_native_concat(['1 ', '2'])
    assert 1 == ansible_native_concat(['1\n', '2'])
    assert '1' == ansible_native_concat(['  1'])
    assert '1' == ansible_native_concat(['  1\n  2'])



# Generated at 2022-06-22 14:26:40.426448
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(["1", "2"]) == '12'
    assert ansible_native_concat(["1", "2", 1]) == '121'
    assert ansible_native_concat(["1", "2", 1]) == '121'
    assert ansible_native_concat(["1", "2", 1]) == '121'
    assert ansible_native_concat(["1", "2", 1]) == '121'
    assert ansible_native_concat(["1", "2", 1]) == '121'
    assert ansible_native_concat(["1", "2", 1]) == '121'



# Generated at 2022-06-22 14:26:49.433600
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Test strings
    assert ansible_native_concat(None) is None
    assert ansible_native_concat([]) is None

    assert ansible_native_concat(['hello']) == 'hello'
    assert ansible_native_concat(['hello', 'world']) == 'helloworld'

    # Test whitespace
    assert ansible_native_concat(['hello', u'world']) == 'helloworld'
    assert ansible_native_concat(['hello', u'\t\nworld']) == 'hello\t\nworld'
    assert ansible_native_concat(['\t\nhello', u'\t\nworld']) == '\t\nhelloworld'

    # Test literals

# Generated at 2022-06-22 14:27:00.479098
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Check that all the elements of the list are iterable, to catch
    # the "tuple not iterable" exception, and filter down to the
    # string_types, to catch the 'string is not iterable' exception.
    assert ansible_native_concat(
        [1, 2, 3] +
        list(filter(lambda x: isinstance(x, string_types), [u'1', u'2', u'3', None, u'4']))
    ) == 123

    assert ansible_native_concat(
        [1, 2, 3] +
        [u'1', u'2', u'3', None, u'4']
    ) == u'123123'

    assert ansible_native_concat(u'1') == u'1'


# Generated at 2022-06-22 14:27:07.354717
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def test(arg, ansible_native_concat=ansible_native_concat):
        return container_to_text(ansible_native_concat(arg), with_commas=True)

    # no arguments
    assert test([]) == u'None'

    # one argument
    assert test([str('ansible')]) == u'ansible'
    assert test([int(42)]) == u'42'
    assert test([list([str('list'), int(42)])]) == u"[u'list', 42]"
    assert test([dict({str('key'): str('value')})]) == u"{u'key': u'value'}"

    # two arguments
    assert test([str('ansible'), str('galaxy')]) == u'ansiblegalaxy'

# Generated at 2022-06-22 14:27:18.917526
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat(['42']) == 42
    assert ansible_native_concat([' a ', ' b ']) == ' a  b '
    assert ansible_native_concat(['true']) == True
    assert ansible_native_concat(['false']) == False
    assert ansible_native_concat(['null']) == None
    assert ansible_native_concat(['42.0']) == 42.0
    assert ansible_native_concat(['42', '0']) == '420'
    assert ansible_native_concat(['42.0', '0']) == '420'

# Generated at 2022-06-22 14:27:30.276630
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', 'b', 'c', 'd']) == 'abcd'
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([1, 2, 3, 4]) == '1234'
    assert ansible_native_concat([1, 2, 3, 4]) == '1234'

    assert ansible_native_concat(b'data') == b'data'
    assert ansible_native_concat([b'a', b'b']) == b'ab'

# Generated at 2022-06-22 14:27:37.867097
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import contextfunction
    from jinja2.environment import Environment
    from ansible.module_utils.common.text.converters import to_native

    @contextfunction
    def test(ctx, value):
        out = to_native(value)
        assert isinstance(out, string_types), 'If you see this error please update this test'
        return out


# Generated at 2022-06-22 14:27:47.542689
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 1]) == 2
    assert ansible_native_concat([1, '2']) == 3
    assert ansible_native_concat([1, '2d']) == '12d'
    assert ansible_native_concat([1, '2', 3]) == '123'
    assert ansible_native_concat(['1', '2d']) == '12d'
    assert ansible_native_concat(['1d', '2d']) == '1d2d'
    assert ansible_native_concat([1, 'd2d']) == '1d2d'
    assert ansible_native_concat([1, 2, 3, 4, 5]) == 15



# Generated at 2022-06-22 14:27:57.470560
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    assert ansible_native_concat([u'1234']) == 1234
    assert ansible_native_concat([u'1.234']) == 1.234
    assert ansible_native_concat([u'"1234"']) == u'1234'
    assert ansible_native_concat([u"'1234'"]) == u'1234'
    assert ansible_native_concat([u'True']) is True
    assert ansible_native_concat([u'False']) is False
    assert ansible_native_concat([u'None']) is None

    assert ansible_native_concat([u'1234', u'1234']) == u'12341234'

# Generated at 2022-06-22 14:28:08.685295
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_value = ['hello', ' ', 'world']
    test_value_joined = u''.join([to_text(v) for v in test_value])
    assert ansible_native_concat(test_value) == test_value_joined

    test_value = ['{"hello": "world"}']
    assert ansible_native_concat(test_value) == {"hello": "world"}

    test_value = ['hello', ' ', 'world']
    assert ansible_native_concat(test_value) == test_value_joined

    test_value = ['{"hello": "world"}']
    assert ansible_native_concat(test_value) == {"hello": "world"}

    test_value = ['{hello: world}']

# Generated at 2022-06-22 14:28:21.360543
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(["Hello "]) == "Hello "
    assert ansible_native_concat(["Hello ", "World!"]) == "Hello World!"

    # Test string concatenation
    assert ansible_native_concat([1, 2, 3]) == "123"
    assert ansible_native_concat([1, "2", 3]) == "123"

    # Test that ast.literal_eval is called when possible
    assert ansible_native_concat(["1"]) == 1
    assert ansible_native_concat(["1", "2", "3"]) == 123

    # Test that ast.literal_eval is called when possible
    assert ansible_native_concat(["1"]) == 1

# Generated at 2022-06-22 14:28:34.065639
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['hello', 'world']) == u'helloworld'
    assert ansible_native_concat(['hello', 1.2]) == u'hello1.2'
    assert ansible_native_concat(['hello', 1]) == u'hello1'
    assert ansible_native_concat(['1', '2', '3']) == u'123'
    assert ansible_native_concat(['1.2', '3']) == 1.2
    assert ansible_native_concat([1, '2']) == 12
    assert ansible_native_concat([1, 2]) == 12
    assert ansible_native_concat([1.2, 3]) == 1.2
    assert ansible_native_concat(['1.2', 3]) == 1

# Generated at 2022-06-22 14:28:39.305166
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # https://github.com/pallets/jinja/blob/master/tests/test_nativetypes.py
    from jinja2.runtime import Undefined

    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([5, 'bar']) == '5bar'
    assert ansible_native_concat([5, 'bar', None]) == '5barNone'
    assert ansible_native_concat([5, 'bar', 'None']) == '5barNone'
    assert ansible_native_concat([5, 'bar', Undefined()]) == '5bar{{ undefined }}'
    assert ans

# Generated at 2022-06-22 14:28:49.110752
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, u'abc']) == '1abc'
    assert ansible_native_concat([None, 2]) is None
    assert ansible_native_concat([None, None]) is None
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([u'abc']) == u'abc'



# Generated at 2022-06-22 14:29:01.564098
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    a = [
        {'a': 'A', 'b': 'B', 'c': 'C'},
        {'d': 'D', 'e': 'E', 'f': 'F'},
        {'g': 'G', 'h': 'H', 'i': 'I'},
    ]
    b = "{{ a[0]['a'] }}|{{ a[1]['d'] }}|{{ a[2]['g'] }}"
    c = "{{ a[0]['a'] }}|{{ a[1]['d'] }}|{{ a[2]['g'] }}|{{ a[0]['c'] }}"

# Generated at 2022-06-22 14:29:12.132023
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import ansible.parsing.yaml.objects
    from distutils.version import LooseVersion
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.six import b

    if LooseVersion(ansible.__version__) < LooseVersion("2.9.0"):
        # This test fails because of https://github.com/ansible/ansible/pull/34643
        return

    def unvault(data):
        if isinstance(data, AnsibleVaultEncryptedUnicode):
            return data.data
        return data

    def to_seq(data):
        if isinstance(data, string_types):
            data = [data]
        return data


# Generated at 2022-06-22 14:29:18.088472
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2

    # Test to see if undefined values raise exceptions
    env = jinja2.Environment(undefined=jinja2.StrictUndefined)

    with env.from_string('{{ v }}') as t:
        assert str(t.render({'v': 1})) == "1", "rendering {'v': 1}"
        try:
            t.render({})
        except jinja2.exceptions.UndefinedError:
            pass

# Generated at 2022-06-22 14:29:30.763085
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_native
    assert ansible_native_concat([None, None]) is None
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat([None, 42]) == 42
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat(['1', '2', '3']) == 123
    assert ansible_native_concat(['n1', 'n2', 'n3']) == 'n1n2n3'
    assert ansible_native_concat([1, '2', '3']) == '123'
    assert ansible_native_concat(['1', 2, '3']) == '123'
    assert ansible_native

# Generated at 2022-06-22 14:29:42.570290
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    result = ansible_native_concat(['foo', 'bar'])
    assert result == 'foobar'

    result = ansible_native_concat([['foo'], ['bar']])
    assert result == ['foo', 'bar']

    result = ansible_native_concat([['foo'], 'bar'])
    assert result == ['foo', 'bar']

    result = ansible_native_concat([['foo', 'bar']])
    assert result == ['foo', 'bar']

    result = ansible_native_concat([['foo', 'bar'], 'baz'])
    assert result == 'foobarbaz'

    result = ansible_native_concat([['foo', 'bar'], ['baz']])
    assert result == ['foo', 'bar', 'baz']

    result

# Generated at 2022-06-22 14:29:53.752554
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_text

    # test list
    assert ansible_native_concat([[1, 2, 3]]) == [1, 2, 3]
    assert ansible_native_concat(['A', 'B', 'C']) == 'ABC'
    assert ansible_native_concat([['A', 'B'], 'C']) == 'ABC'
    assert ansible_native_concat([[1, 2], 3, [[4, 5], 6]]) == [1, 2, 3, [4, 5], 6]

# Generated at 2022-06-22 14:30:05.570788
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    result = ansible_native_concat([1, 2, 3])
    assert result == '123'
    result = ansible_native_concat(('1', '2', '3'))
    assert result == '123'
    result = ansible_native_concat(['1', '2', '3'])
    assert result == '123'
    result = ansible_native_concat((u'\u00E9', u'\u00E8', u'\u00EB'))
    assert result == u'\u00E9\u00E8\u00EB'
    result = ansible_native_concat(['1', 2, '3'])
    assert result == '123'
    result = ansible_native_concat([1, '2', 3])
    assert result == '123'

# Generated at 2022-06-22 14:30:12.576737
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    def _recursive_check(lst, expected, raw=False):
        expected_list = expected
        if expected_list and not isinstance(expected_list, list):
            expected_list = [expected_list]
        if raw:
            expected_list = [container_to_text(x, indent=0)[:-1] for x in expected_list]

        assert isinstance(lst, list)
        assert len(lst) == len(expected_list)
        for i, expected_item in enumerate(expected_list):
            if expected_item is None:
                assert lst[i] is None
            elif isinstance(expected_item, list):
                _recursive_check(lst[i], expected_item, raw=raw)

# Generated at 2022-06-22 14:30:23.013286
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar', 'baz']) == 'foobarbaz'
    assert ansible_native_concat(['foo', 'bar', 1234]) == 'foobar1234'
    assert ansible_native_concat([17, 'bar', 1234]) == '17bar1234'
    assert ansible_native_concat([17, u'bar', 1234]) == '17bar1234'
    assert ansible_native_concat([17, 'bar', u'1234']) == '17bar1234'
    assert ansible_native_concat(u'foobarbaz') == u'foobarbaz'
    assert ansible_native_concat([u'foobarbaz']) == u'foobarbaz'
    assert ansible_native_con

# Generated at 2022-06-22 14:30:33.914961
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    data_string = ['a', 'b']
    data_vars = ['a', 'b', 'c']
    data_vars2 = ['a', 'b', 'c', u'{{test}}']
    data_vars_2 = ['a', 'b', 'c', 'd', 'e', '1']
    data_vars_3 = [{'a': '1'}, {'b': '2'}, {'c': '3'}]

    assert ansible_native_concat(data_string) == 'ab'
    assert ansible_native_concat(data_vars) == 'abc'
    assert ansible_native_concat(data_vars2) == 'abc{{test}}'
    assert ansible_native_concat(data_vars_2) == 'abcde1'

# Generated at 2022-06-22 14:30:45.652651
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def _test(input_data, output_data):
        assert output_data == ansible_native_concat(input_data)

    _test(['a', 'b'], 'ab')
    _test(['a', u'b'], u'ab')
    _test([u'a', 'b'], u'ab')
    _test([u'a', u'b'], u'ab')

    _test(['a', 1], 'a1')
    _test([u'a', 1], u'a1')

    _test(['a', 1, 'b'], 'a1b')
    _test([u'a', 1, 'b'], u'a1b')
    _test(['a', 1, u'b'], u'a1b')

# Generated at 2022-06-22 14:30:58.050355
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['""']) == u''
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['"1"']) == 1
    assert ansible_native_concat(['1.3']) == 1.3
    assert ansible_native_concat(['[1, 2, 3]']) == [1, 2, 3]
    assert ansible_native_concat(['{"a": 1}']) == {"a": 1}
    out = ansible_native_concat(['a', 'b'])
    assert out == 'ab'

# Generated at 2022-06-22 14:31:11.008429
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([u'hello']) == u'hello'

    def gen():
        yield u'hello'
        yield u'world'

    assert ansible_native_concat(gen()) == u'helloworld'
    assert ansible_native_concat([u'hello', u'world']) == u'helloworld'
    assert ansible_native_concat([u'hello', u' ', u'world']) == u'hello world'
    assert ansible_native_concat([u'hello', u' ', u'world', u'!']) == u'hello world!'
    assert ansible_native_concat([u"'hello' ", u'"world"']) == u'hello world'

# Generated at 2022-06-22 14:31:23.762772
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    assert ansible_native_concat('foo') == 'foo'
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat('foo' for _ in range(3)) == 'foofoofoo'
    assert ansible_native_concat(['foo'] for _ in range(3)) == 'foofoofoo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'

# Generated at 2022-06-22 14:31:30.712880
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:31:41.013955
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.basic import AnsibleModule

    def test_native_concat(args, expected):
        module = AnsibleModule(argument_spec=dict(value=dict(), fail_on_undefined=dict(type='bool', default=True)))
        value = args['value']
        fail_on_undefined = args.get('fail_on_undefined', True)

        if fail_on_undefined:
            value = _fail_on_undefined(value)

        result = ansible_native_concat([value])
        module.exit_json(changed=False, value=result, expected=expected)

    # Test basic types (list, dict, string, number)

# Generated at 2022-06-22 14:31:51.303787
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat((1, 2)) == 1
    assert ansible_native_concat((1, 2, 3)) == u'123'
    assert ansible_native_concat('123') == u'123'
    assert ansible_native_concat((True, False)) == True
    assert ansible_native_concat((1, '2', 3, 4, 5)) == u'12345'
    assert ansible_native_concat(['1', '2', '3', '4', '5']) == u'12345'
    assert ansible_native_concat(['1', '2', '3', '4', '5']) == u'12345'
    assert ansible_native_concat((1, '2', '3', '4', '5')) == u'12345'

# Generated at 2022-06-22 14:32:02.495449
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:32:07.297668
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = ansible_native_concat([])
    assert nodes is None

    nodes = ansible_native_concat([42])
    assert nodes == 42

    nodes = ansible_native_concat(['42'])
    assert nodes == 42

    nodes = ansible_native_concat(['42', u'a', u'b'])
    assert nodes == '42ab'

    nodes = ansible_native_concat(['42', u'a', u'b'], ['c', 'd'])
    assert nodes == '42abcd'

    nodes = ansible_native_concat(['42', u'a', u'b'], ['', ''])
    assert nodes == '42ab'


# Generated at 2022-06-22 14:32:17.581942
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_native
    from jinja2.nativetypes import NativeEnvironment

    # Make sure that the native concat function works with a generator.
    gen = (i for i in range(10))
    assert ansible_native_concat(gen) == u'0123456789'
    assert ansible_native_concat(gen) == u'0123456789'

    # The non-native Jinja2 environment generates a generator that has
    # an __iter__ method, which yields the same generator over and over.
    non_native_env = NativeEnvironment(extensions=[])
    non_native_concat = non_native_env.finalize_native_concat_filters()
    assert to_native(non_native_concat(gen)) == u