

# Generated at 2022-06-22 14:22:18.156214
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat(['{', 1, 2, '}']) == '{12}'
    assert ansible_native_concat(['t', 'e', 's', 't']) == 'test'



# Generated at 2022-06-22 14:22:31.107873
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:22:43.830437
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 'bar', 'baz']) == 'foobarbaz'

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, 2, 3]) == '123'

    assert ansible_native_concat([['foo'], 'bar']) == ['foo', 'bar']
    assert ansible_native_concat([['foo', 'bar'], 'baz']) == ['foo', 'bar', 'baz']

# Generated at 2022-06-22 14:22:56.279190
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:23:09.136398
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2]) == [1, 2]
    assert ansible_native_concat(['one', 'two']) == 'onetwo'
    assert ansible_native_concat(['one "two"', 3]) == 'one "two"3'
    assert ansible_native_concat(['one "two" 3']) == 'one "two" 3'
    assert ansible_native_concat([u'one\u2035']) == 'one\u2035'
    assert ansible_native_concat([u'one\u2035', 3]) == 'one\u2035'
    assert ansible_native_concat([u'one\u2035', 3, 'a']) == 'one\u20353a'
    # In Python 3.10+ ast.

# Generated at 2022-06-22 14:23:21.984316
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_text

    assert to_native(ansible_native_concat([])) is None

    assert to_native(ansible_native_concat([[1, 2]])) == [1, 2]
    assert to_native(ansible_native_concat(['a'])) == 'a'

    assert to_native(ansible_native_concat(['a', [1, 2]])) == 'a[1, 2]'
    assert to_native(ansible_native_concat([1, 'a'])) == '1a'

# Generated at 2022-06-22 14:23:31.998949
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.native_jinja import NativeJinjaText
    from ansible.module_utils.six import PY3

    # Note that ansible_native_concat is also tested by
    # jinja_native_types/test_native_types
    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat(['foo']) == u'foo'
    assert ansible_native_concat([b'foo']) == u'foo'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1.0]) == 1.0
    assert ansible_native_concat([None]) is None

# Generated at 2022-06-22 14:23:44.185811
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == u'12'
    assert ansible_native_concat([1, 2, 3]) == u'123'
    assert ansible_native_concat([1, True, 3]) is None
    assert ansible_native_concat([1, '1', '1']) == 11
    assert ansible_native_concat([True, 1, 1]) == True
    assert ansible_native_concat([True, True, 1]) == True
    assert ansible_native_concat([1, True, 1]) == 1
    assert ansible_native_concat([1, True, '1']) == True
    assert ansible_native_concat

# Generated at 2022-06-22 14:23:55.832874
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foobar']) == 'foobar'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', '', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 'baz', 'bar']) == 'foobazbar'
    assert ansible_native_concat(['foo', 'baz', 'bar']) == 'foobazbar'
    assert ansible_native_concat(['', 'foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 'bar', '']) == 'foobar'

# Generated at 2022-06-22 14:24:08.237659
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class TestClass:
        pass

    test_object = TestClass()
    test_object.attr_int = 10
    test_object.attr_bool = False
    test_object.attr_dict = {'a': 1, 'b': 2}
    test_object.attr_list = [1, 2, 3]
    test_object.attr_str = 'abc'

    # Use a list so that we can loop through the tests

# Generated at 2022-06-22 14:24:19.852769
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2

    env = jinja2.Environment()
    assert ansible_native_concat([]) == None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == u'12'
    assert ansible_native_concat([1, 2, 3]) == u'123'
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([u'', u'foobar']) == u'foobar'
    assert ansible_native_concat([u'[', u'1', u']']) == u'[1]'
    assert ansible_native_concat([u'[', u'1', u',', u'2', u']'])

# Generated at 2022-06-22 14:24:30.922595
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:24:43.915688
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    @ansible_native_concat
    def concat(*nodes):
        yield from nodes

    # case 1: no nodes
    assert concat() is None

    # case 2: one node
    assert concat(1) == 1

    # case 3: one node which can be parsed
    assert concat('1') == 1

    # case 4: one node which cannot be parsed
    assert concat('foo') == 'foo'

    # case 5: multiple nodes
    assert concat(1, 'foo') == 1
    assert concat('foo', 1) == 'foo'

    # case 6: multiple nodes which cannot be parsed
    assert concat('foo', 'bar') == 'foobar'

    # case 7: multiple nodes which can be parsed
    assert concat('1', '2') == 1

# Generated at 2022-06-22 14:24:57.055517
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    concat = ansible_native_concat

    assert concat([]) is None
    assert concat([1]) == 1
    assert concat([1, 2]) == "12"
    assert concat([1, 2, 3]) == "123"
    assert concat([1, 2, 3, 4]) == "1234"

    assert concat(["1"]) == "1"
    assert concat(["1", "2"]) == "12"
    assert concat(["1", "2", "3"]) == "123"
    assert concat(["1", "2", "3", "4"]) == "1234"

    assert concat(["1", None, "2", "3"]) == "1None23"


# Generated at 2022-06-22 14:25:07.697696
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_text
    _text = to_text

    assert ansible_native_concat([_text('hello')]) == _text('hello')
    assert ansible_native_concat([_text('')]) == _text('')
    assert ansible_native_concat([_text('hello'), _text('hello')]) == _text('hellohello')
    assert ansible_native_concat([_text('hello'), _text(''), _text('hello')]) == _text('hellohello')
    assert ansible_native_concat([_text('hello'), _text('hello'), _text('hello')]) == _text('hellohellohello')

    assert ansible_native_concat([]) is None


# Generated at 2022-06-22 14:25:17.438494
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat(["foo"]) == "foo"
    assert ansible_native_concat(["foo", 42]) == "foo42"
    assert ansible_native_concat([NativeJinjaText("foo"), "foo"]) == "foofoo"
    assert ansible_native_concat([42, " foo ", ["bar", "baz", 13], "", None, ""]) == "42 foo barbaz13"
    assert ansible_native_concat(["42", "foo"]) == 42
    assert ansible_native_concat(["42", "foo", "bar"]) == "42foobar"

# Generated at 2022-06-22 14:25:24.879456
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(["str", "str2"]) == "strstr2"
    assert ansible_native_concat([42, 23]) == 42
    assert ansible_native_concat([["str", "str2"], ["str3", "str4"]]) == ["strstr2", "str3str4"]
    assert ansible_native_concat(["{'a': 1, 'b': 2}", "{'c': 3, 'd': 4}"]) == {"a": 1, "b": 2, "c": 3, "d": 4}
    assert ansible_native_concat(["[1, 2]", "[3, 4]"]) == [1, 2, 3, 4]

# Generated at 2022-06-22 14:25:32.929045
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([True, "a"]) == "Truea"
    assert ansible_native_concat([True, "a"]) != True
    assert ansible_native_concat([True, "a"]) != "True a"
    assert ansible_native_concat(["True", "a"]) == "Truea"
    assert ansible_native_concat(["True", "a"]) != True
    assert ansible_native_concat(["True", "a"]) != "True a"
    assert ansible_native_concat(["True", "a", "b"]) == "Trueab"
    assert ansible_native_concat(["True", "a", "b"]) != True

# Generated at 2022-06-22 14:25:42.138008
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat([container_to_text('a'), container_to_text('b')]) == 'ab'
    assert ansible_native_concat([container_to_text('a'), container_to_text('b'), container_to_text('c')]) == 'abc'
    assert ansible_native_concat([container_to_text(1), container_to_text(2), container_to_text(3)]) == '123'

    assert ansible_native_

# Generated at 2022-06-22 14:25:53.760717
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(["a"]) == "a"
    assert ansible_native_concat(["a", "b"]) == "ab"
    assert ansible_native_concat([1, 2]) == "12"
    assert ansible_native_concat([1, 2, 3]) == "123"
    assert ansible_native_concat([1, "a"]) == "1a"
    assert ansible_native_concat([True, False]) == "TrueFalse"
    assert ansible_native_concat([None, 1]) == "None1"
    assert ansible_native_concat([None, "b"]) == "Noneb"
    assert ansible_native_concat(["a", None]) == "aNone"

# Generated at 2022-06-22 14:26:12.163908
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == "12"
    assert ansible_native_concat(['1', 2, '3']) == "123"
    assert ansible_native_concat(['\'', 2, 'a']) == "'2a"



# Generated at 2022-06-22 14:26:20.978855
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = [u"foo", u"bar", u"baz"]
    assert ansible_native_concat(nodes) == u"foobarbaz"

    nodes = (u"foo", u"bar", u"baz")
    assert ansible_native_concat(nodes) == u"foobarbaz"

    nodes = iter([u"foo", u"bar", u"baz"])
    assert ansible_native_concat(nodes) == u"foobarbaz"


# Generated at 2022-06-22 14:26:32.673161
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import Template

    assert(ansible_native_concat(Template("'foo' + 'bar'").module.nodes) == 'foobar')
    assert(ansible_native_concat(Template("'foo' + intvar").module.nodes) == 'foo1')
    assert(ansible_native_concat(Template("'foo' + boolvar").module.nodes) == 'foofalse')  # lets not use ansible's bool type here
    assert(ansible_native_concat(Template("'foo' + mapvar['baz']").module.nodes) == 'foobar')
    assert(ansible_native_concat(Template("'foo' + listvar[0]").module.nodes) == 'foobar')

# Generated at 2022-06-22 14:26:44.548162
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import ansible.parsing.vault as vault

    class Node(object):
        def __init__(self, value):
            self.value = value

    def gen(args):
        for arg in args:
            yield Node(arg)

    class TestVault(object):
        def decrypt(self, val):
            return '%s_decrypted' % val

    assert ansible_native_concat(gen(['a'])) == 'a'
    assert ansible_native_concat(gen(['a', 'b'])) == 'ab'
    assert ansible_native_concat(gen([2, 3])) == 5
    assert ansible_native_concat(gen([['a'], ['b']])) == ['a', 'b']

# Generated at 2022-06-22 14:26:51.532900
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:27:02.269555
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2.utils import Markup
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([u'\u00f6', u'bar']) == u'\u00f6bar'
    assert ansible_native_concat(['1', '2', '-2', '42']) == '12-242'
    assert ansible_native_concat(['1', '2', '-2', '42']) == '12-242'
    assert ansible_native_concat([1, 'x', 2]) == '1x2'
    assert ansible_native_concat([1, True]) == '1True'
    assert ansible_native_concat(['foo', True]) == 'fooTrue'
    assert ansible_

# Generated at 2022-06-22 14:27:08.261695
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat([u'f', u'o', u'o']) == u'foo'
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([[u'foo'], [u'bar']]) == u'foobar'

    # Assert string values are passed to literal_eval
    assert ansible_native_concat([u'1']) == 1
    assert ansible_native_concat([u'1', u'2']) == u'12'
    assert ansible_native_concat([u'1', 2]) == u'12'
   

# Generated at 2022-06-22 14:27:11.420483
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import sys
    import jinja2
    env = jinja2.Environment(undefined=StrictUndefined, finalize=ansible_native_concat)
    literal = ty

# Generated at 2022-06-22 14:27:21.329499
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # test ast.literal_eval
    assert ansible_native_concat([1, '+', 2]) == 3
    assert ansible_native_concat(['-1234']) == -1234
    assert ansible_native_concat(["'\\u{41}'" + ' ' + "'\\u{42}'"]) == 'AB'
    assert ansible_native_concat(['0xFF']) == 255

    # test string concatenation
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', '  ', 'b']) == 'a  b'
    assert ansible_native_concat(['a', 1, 'b']) == 'a1b'

    # test literal_eval with leading space


# Generated at 2022-06-22 14:27:28.958857
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat([1, 'foo', 2, 'bar']) == '1foo2bar'
    assert ansible_native_concat(['{"a": 1}']) == {'a': 1}
    assert ansible_native_concat(['{"a": 1', '}']) == '{"a": 1}'



# Generated at 2022-06-22 14:27:55.514137
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    cases = [
        # Empty
        ([], None),
        # Single node
        (['a'], 'a'),
        # Multiple nodes
        (['a', 'b', 'c'], 'abc'),
        # Nested list
        (['a', ['b', 'c'], 'd'], 'abcd'),
        # Nested dict
        (['a', {'b': 'c'}, 'd'], 'abcd'),
        # Dict with multiple values
        (['a', {'b': 'c', 'd': 'e'}, 'f'], 'abcdef'),
        # String is preserved
        (['a', 'b', {'c': '{{d}}'}, 'e'], 'abc{{d}}e'),
    ]

    for data, expected in cases:
        actual = ansible_native_con

# Generated at 2022-06-22 14:28:07.060644
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1,2,3]) == [1,2,3]
    assert ansible_native_concat((1,2,3)) == [1,2,3]
    assert ansible_native_concat(['a','b','c']) == 'abc'
    assert ansible_native_concat(('a','b','c')) == 'abc'

    assert ansible_native_concat(['a', ' ']) == 'a '
    assert ansible_native_concat(['a',[1,2,3]]) == 'a[1, 2, 3]'
    assert ansible_native_concat(['a',(1,2,3)]) == 'a(1, 2, 3)'


# Generated at 2022-06-22 14:28:20.202208
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['{', '}']) == '{}'
    assert ansible_native_concat([0, 'foo']) == '0foo'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([0, 0]) == '00'
    assert ansible_native_concat([None, 'foobar']) == 'Nonefoobar'
    assert ansible_native_concat([None, 'foo', 'bar']) == 'Nonefoobar'
    assert ansible_native_concat([None, None]) == 'NoneNone'
    assert ansible_native_concat(['']) == ''

# Generated at 2022-06-22 14:28:32.781934
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text import literal_eval_native_string

    # Concatenation
    assert ansible_native_concat([u'test ', 1]) == u'test 1'
    assert ansible_native_concat([u'test ', 1, u'foo']) == u'test 1foo'
    assert ansible_native_concat([u'test', 3, u'foo', u'bar']) == u'test3foobar'
    assert ansible_native_concat([u'test', 42, u'foo', u'bar']) == u'test42foobar'
    assert ansible_native_concat([u'test', 42, u'foo', False]) == u'test42foofalse'

# Generated at 2022-06-22 14:28:38.632932
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 1]) == 'a1'
    assert ansible_native_concat(['a', 1, 'b', 2]) == 'a1b2'

    # cannot be evaluated as a literal
    assert ansible_native_concat(['a', 1, 'b', '2']) == 'a1b2'

    # can be evaluated as literals
    assert ansible_native_concat(['1', 2, '3', 4]) == 10
    # and don't choke on other types
    assert ansible_native_concat(['1', 2, '3', 4, 5.0]) == 15.0

    # preserve whitespace
    assert ansible_native_concat(['abc ', 123])

# Generated at 2022-06-22 14:28:51.361782
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([2]) == 2
    assert ansible_native_concat(['hello ']) == 'hello '
    assert ansible_native_concat(['hello', 'world']) == 'hello world'
    assert ansible_native_concat([2, 3]) == '23'
    assert ansible_native_concat(['2', 3]) == '23'
    assert ansible_native_concat(['2', '3']) == 5
    assert ansible_native_concat(['2', ' 3']) == '2 3'
    assert ansible_native_concat(2) == 2
    assert ansible_native_concat('hello ') == 'hello '

# Generated at 2022-06-22 14:29:03.374380
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([u'']) == u''
    assert ansible_native_concat([1, 2]) == 12
    assert ansible_native_concat([1, 2]) == u'12'
    assert ansible_native_concat([u'a', u'b']) == u'ab'
    assert ansible_native_concat([u'a', 2, u'b']) == u'a2b'
    assert ansible_native_concat([u'a', 2, u'b']) == u'a2b'
    assert ansible_native_concat([u'a', None, u'b']) == u'aNoneb'



# Generated at 2022-06-22 14:29:13.156693
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_values = {
        '': None,
        'string': 'string',
        '1': 1,
        '1.0': 1.0,
        '1.0 2.0': '1.0 2.0',
        '[1, 2, 3]': [1, 2, 3],
        '{1: 2, 3: 4}': {1: 2, 3: 4},
        '1.3.3.7': '1.3.3.7',
        '\xa0': u'\xa0',
        '\xa0\xa0': u'\xa0\xa0',
    }
    test_values = {
        '%s|string' % k: v for k, v in test_values.items()
    }
    for string, expected in test_values.items():
        result

# Generated at 2022-06-22 14:29:25.075405
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'

    assert ansible_native_concat(['a', 123, 'b']) == 'a123b'

    assert ansible_native_concat(['a', 123, 'b']) == 'a123b'

# Generated at 2022-06-22 14:29:29.384496
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2
    from ansible.module_utils.six import PY3

    env = jinja2.Environment()

    # Special case tests
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1

    if PY3:
        # In Python 3.10+ ast.literal_eval removes leading spaces/tabs.
        # See https://github.com/ansible/ansible/issues/71460
        assert ansible_native_concat(['  foo']) == '  foo'
        assert ansible_native_concat(['  foo', 'bar']) == '  foobar'

    # Test parsing of int, float and string
    assert ansible_native_concat(['123']) == 123
    assert ansible_native_con

# Generated at 2022-06-22 14:30:10.355840
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.six.moves import builtins
    if not hasattr(builtins, '__builtin_to_native'):
        setattr(builtins, '__builtin_to_native', ansible_native_concat)

    assert ansible_native_concat([True]) == True
    assert ansible_native_concat([123]) == 123
    assert ansible_native_concat([1.25]) == 1.25
    assert ansible_native_concat([None]) == None

    # test it recurses into lists and dicts
    assert ansible_native_concat([[1, 2, 3]]) == [1, 2, 3]
    assert ansible_native_concat([{'a': 1, 'b': 2}]) == {'a': 1, 'b': 2}

# Generated at 2022-06-22 14:30:20.881583
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == u'foobar'
    assert ansible_native_concat([u'foo', 'bar']) == u'foobar'
    assert ansible_native_concat((u'foo', 'bar')) == u'foobar'
    assert ansible_native_concat((u'foo', 'bar')) == u'foobar'
    assert ansible_native_concat(['foo', ['bar', u'baz']]) == u'foobarbaz'

    # Concatenation of booleans should work
    assert ansible_native_concat([False, True]) == u'FalseTrue'
    assert ansible_native_concat([True, False]) == u'TrueFalse'

    # Use native Python type if only one value is given


# Generated at 2022-06-22 14:30:30.852112
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean

    env = {
        'ansible_native_concat': ansible_native_concat
    }


# Generated at 2022-06-22 14:30:43.607993
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat((1,)) == 1
    assert ansible_native_concat(('a', 2)) == 'a2'
    assert ansible_native_concat(('1', '2')) == 3
    assert ansible_native_concat(('1.1', '2.1')) == 3.2
    assert ansible_native_concat(('[1, 2]', '[]')) == [1, 2]
    assert ansible_native_concat(('{"a": 1}', '{"b": 2}')) == {'a': 1, 'b': 2}
    assert ansible_native_concat((b'1', b'2')) == 3
    assert ansible_native_concat((1, 'b')) == '1b'
    assert ansible_native

# Generated at 2022-06-22 14:30:57.126166
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(iter([True, u'string', False, u' '])) == u'True string False '
    assert ansible_native_concat(iter([])) is None

    assert ansible_native_concat([u'string', u' ', False]) == u'string False'
    assert ansible_native_concat([u'string', u' ', 1]) == u'string 1'
    assert ansible_native_concat([u'string', u' ', 1, u' true']) == u'string 1 true'
    assert ansible_native_concat([True, u' string', False, u' ', 3]) == u'True string False 3'
    assert ansible_native_concat([10, u'string', False, u' ', 3]) == u

# Generated at 2022-06-22 14:31:09.999630
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'a', u'b', u'c']) == u'abc'
    assert ansible_native_concat([u' a b ', u' c ']) == u' a b  c '
    assert ansible_native_concat([u'a', u' b ', u'c']) == u'a b c'
    assert ansible_native_concat([u'a ', u'b ', u'c']) == u'a b c'
    assert ansible_native_concat([u' a ', u' b ', u' c ']) == u' a   b   c '
    assert ansible_native_concat([u' a b  c ']) == u' a b  c '

# Generated at 2022-06-22 14:31:22.552834
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import pytest

    class DummyJinja(object):
        def __init__(self, value):
            self.value = value

        def __html__(self):
            return self.value

    class DummyGenerator(types.GeneratorType):
        def __init__(self, values):
            self.values = values

        def __iter__(self):
            return self

        def __next__(self):
            if not self.values:
                raise StopIteration
            return self.values.pop(0)

        def send(self, value):
            return value

        def throw(self, typ, val=None, traceback=None):
            return typ, val, traceback

        def close(self):
            pass


# Generated at 2022-06-22 14:31:29.986769
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2.runtime import Undefined

    assert ansible_native_concat([]) is None

    assert ansible_native_concat(['string']) == 'string'

    assert ansible_native_concat([Undefined()]) is Undefined()

    assert ansible_native_concat(['string', 'string']) == 'stringstring'

    assert ansible_native_concat([u'string', u'string']) == u'stringstring'

    assert ansible_native_concat([True]) is True

    assert ansible_native_concat([123]) == 123

    assert ansible_native_concat(['1', '23', '4']) == 1234

    assert ansible_native_concat(['1', u'23', '4']) == 1234

    assert ansible_

# Generated at 2022-06-22 14:31:40.796304
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test type preservation
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([0]) == 0
    assert ansible_native_concat([{'a': 1}]) == {'a': 1}
    assert ansible_native_concat([('a', 2)]) == ('a', 2)
    assert ansible_native_concat(['[1, 2, 3]']) == '[1, 2, 3]'
    assert ansible_native_concat(['{1: 2, 3: 4}']) == '{1: 2, 3: 4}'

    # Test built-in type conversion and concatenation
    assert ansible_native_concat

# Generated at 2022-06-22 14:31:50.855300
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_string = "hello world"
    test_list = [1, 2, 3]
    test_dict = {'a': 'b'}
    test_true = True
    test_false = False
    test_empty_string = ''
    test_zero = 0
    test_none = None
    test_empty_list = []
    test_empty_dict = {}
    test_default_dict = defaultdict(lambda: "foo")
