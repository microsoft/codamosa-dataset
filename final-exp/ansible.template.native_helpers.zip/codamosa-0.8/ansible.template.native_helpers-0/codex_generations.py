

# Generated at 2022-06-22 14:22:29.276285
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # test simple string concatenation
    class Foo(object):
        def __str__(self):
            return 'foo'
    assert ansible_native_concat([Foo(), u'bar']) == 'foobar'
    assert ansible_native_concat([Foo(), u'bar', Foo()]) == 'foobarfoo'

    # test parsing floats and int
    assert ansible_native_concat([Foo(), u'.5']) == 0.5
    assert ansible_native_concat([Foo(), u'.5', Foo()]) == '0.5foo'
    assert ansible_native_concat([Foo(), u'.5', Foo(), u'bar', -1]) == '0.5foo-1'

    # test parsing unicode

# Generated at 2022-06-22 14:22:42.020367
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([b'abc']) == b'abc'

    assert ansible_native_concat([b'abc', b'def']) == b'abcdef'
    assert ansible_native_concat([b'abc', u'def']) == b'abcdef'
    assert ansible_native_concat([b'abc', u'def', u'ghi', b'jkl']) == b'abcdefghijkl'

    assert ansible_native_concat([u'abc']) == u'abc'
    assert ansible_native_concat([u'abc', b'def']) == u'abcdef'
    assert ansible_native_concat([u'abc', u'def']) == u'abcdef'


# Generated at 2022-06-22 14:22:54.711446
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['true', 'true']) == True
    assert ansible_native_concat(['false', 'false']) == False
    assert ansible_native_concat(['false', '1']) == 'false1'
    assert ansible_native_concat(['1', 'false']) == '1false'
    assert ansible_native_concat(['1', 'true']) == '1true'
    assert ansible_native_concat(['true', '1']) == 'true1'
    assert ansible_native_concat(['1.0', '2.0']) == 3.0
    assert ansible

# Generated at 2022-06-22 14:23:07.837756
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    x = object()
    assert ansible_native_concat([x]) is x

    assert ansible_native_concat([0]) == 0
    assert ansible_native_concat([[]]) == []

    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([1, 'foo']) == 1
    assert ansible_native_concat(['foo', 1]) == 1
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 'bar', ' baz']) == 'foobar baz'

    assert ansible_native

# Generated at 2022-06-22 14:23:20.548323
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test string concatenation
    nodes = ['foo', 'bar']
    expected = 'foobar'
    actual = ansible_native_concat(nodes)
    assert actual == expected, 'String concatenation failed: %s != %s' % (container_to_text(actual), container_to_text(expected))

    # Test string concatenation with string interpolation
    nodes = ['f', '%s' % 'o', '%s' % 'o', '%s' % 'b', '%s' % 'a', '%s' % 'r']
    expected = 'foobar'
    actual = ansible_native_concat(nodes)

# Generated at 2022-06-22 14:23:31.069723
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a', 1, 'b', 2, 3]) == 'a12b23'
    assert ansible_native_concat([1, '2', 3]) == 123
    assert ansible_native_concat(['a', ' ', 'b']) == 'a b'
    assert ansible_native_concat(['a', True, 'b', False, 'c']) == 'a1b0c'
    assert ansible_native_concat(['a', None, 'b', 'c']) == 'abc'
    assert ansible_native_concat(['a', ['b', 'c'], 'd']) == 'abcd'
    assert ansible_native_concat(['a', ['b', ['c']], 'd']) == 'abcd'
    assert ansible

# Generated at 2022-06-22 14:23:43.331841
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    native_concat = ansible_native_concat

    """Test for literal_eval and string concatenation."""
    assert native_concat([]) is None
    assert native_concat(['1']) == 1
    assert native_concat(['3', '3']) == 66
    assert native_concat(['33', '3']) == 333
    assert native_concat(['1', '2']) == '12'
    assert native_concat(['1', '2']) == '12'
    assert native_concat(['11', '22']) == '1122'
    assert native_concat([['11'], '22']) == ['1122']
    assert native_concat([[1], '2']) == [12]

# Generated at 2022-06-22 14:23:45.596452
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # The test of this function is included as part of the tests for
    # the filters in filters/core.py
    pass

# Generated at 2022-06-22 14:23:56.581103
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert isinstance(ansible_native_concat(['str']), string_types)
    assert isinstance(ansible_native_concat(['str', 'str']), string_types)
    assert isinstance(ansible_native_concat([1, 2]), string_types)
    assert isinstance(ansible_native_concat([1, 'str']), string_types)
    assert isinstance(ansible_native_concat(['str', 2]), string_types)

    assert isinstance(ansible_native_concat([True]), bool)
    assert isinstance(ansible_native_concat([1]), int)
    assert isinstance(ansible_native_concat([1.0]), float)
    assert isinstance(ansible_native_concat([(1,)]), tuple)

# Generated at 2022-06-22 14:24:08.890999
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # test parser
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([['a,']]) == ['a,']
    assert ansible_native_concat([['a', 'b', 'c']]) == 'a b c'
    assert ansible_native_concat([['a', 1, {'a': 'c'}]]) == 'a 1 {u\'a\': u\'c\'}'
    assert isinstance(ansible_native_concat([['   a']]), text_type)
    assert ansible_native_concat(['a', 'b', 1, {'a': 'c'}]) == 'a b 1 {u\'a\': u\'c\'}'
    assert ansible_

# Generated at 2022-06-22 14:24:19.646496
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:24:30.764752
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:24:43.872205
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([u'a']) == 'a'
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([u'a', u'b']) == 'ab'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat([u'a', u'b', u'c']) == 'abc'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat([u'a', u'b', u'c']) == 'abc'

# Generated at 2022-06-22 14:24:57.055752
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat([1, '2', [3], {4}]) == '12[3]{4}'
    assert ansible_native_concat(['1', 2, 3]) == '123'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['True']) is True
    assert ansible_native_concat(['False']) is False
    assert ansible_native_concat(['[1, 2, 3]']) == [1, 2, 3]
    assert ansible_native_concat(['(1, 2, 3)']) == (1, 2, 3)
    assert ans

# Generated at 2022-06-22 14:25:07.697506
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat(['a', 1, 2, 3]) == 'a[1, 2, 3]'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(['1', '+', '1']) == '1+1'
    assert ansible_native_concat(['0.1']) == 0.1
    assert ansible_native_concat(['0.1', '+', '1']) == '0.1+1'
    assert ansible_native_concat([1, 2, 3], [4, 5, 6]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-22 14:25:17.401280
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 'bar', 'baz']) == 'foobarbaz'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '1'
    assert ansible_native_concat([1, '2']) == '1'
    assert ansible_native_concat([1, '2', 3]) == '12'
    assert ansible_native_concat([1, 2, 3]) == '123'

# Generated at 2022-06-22 14:25:29.502544
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import pytest
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import PY3

    def assert_concat(expected, node_list):
        actual = ansible_native_concat(node_list)
        assert actual == expected
        assert type(actual) == type(expected)

    is_py2 = not PY3

    assert_concat(None, [])
    assert_concat(None, [None])
    assert_concat('', [''])
    assert_concat('', [None, None])
    assert_concat('foo', ['foo', None])

    assert_concat(True, [True])
    assert_concat(False, [False])
    assert_concat('true', ['true'])

# Generated at 2022-06-22 14:25:40.021898
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([to_text(1), to_text(2)]) == u'12'
    assert ansible_native_concat([to_text(1), u'2']) == u'12'
    assert ansible_native_concat([to_text(1), None]) == u'1'
    assert ansible_native_concat([to_text(1), to_text(2), to_text(3)]) == u'123'
    assert ansible_native_concat([to_text(1), to_text(2), to_text(3), None]) == u'123'
    assert ansible_native_concat([to_text(1), None, to_text(3)]) == u'13'

# Generated at 2022-06-22 14:25:52.607469
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_str
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    # Python 2 unicode
    assert to_str(ansible_native_concat([to_text(u'foo'), to_text(u'bar')])) == 'foobar'
    assert to_text(ansible_native_concat([to_str(u'foo'), to_str(u'bar')])) == u'foobar'

# Generated at 2022-06-22 14:25:59.276707
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text import to_bytes
    from ansible.module_utils.common.json_utils import jsonify
    from ansible.vars import replace_vars
    from ansible.parsing.vault import VaultLib
    fake_vault = VaultLib({})
    encrypt = lambda x: AnsibleVaultEncryptedUnicode(x, fake_vault)

# Generated at 2022-06-22 14:26:15.753067
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_native
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    assert ansible_native_concat([]) == None
    assert ansible_native_concat(iter([])) == None

    assert ansible_native_concat(('a')) == 'a'
    assert ansible_native_concat(iter(('a'))) == 'a'

    assert ansible_native_concat(('a', 'b', 'c')) == 'abc'
    assert ansible_native_concat(iter(('a', 'b', 'c'))) == 'abc'

    assert ansible_native_concat(('1', 2)) == '12'

# Generated at 2022-06-22 14:26:22.997436
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import ansible.parsing.yaml.objects

    assert ansible_native_concat([]) is None
    assert ansible_native_concat(iter([])) is None

    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat('ab') == 'ab'
    assert ansible_native_concat([['a'], 'b']) == 'ab'
    assert ansible_native_concat(['a'], 'b') == 'ab'
    assert ansible_native_concat(['{', 'a', '}']) == '{a}'
    assert ansible_native_concat(['{', 'a', '}', ['b', 'c']]) == '{abc}'

# Generated at 2022-06-22 14:26:34.196606
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # single node
    assert ansible_native_concat(['42']) == '42'
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat([42, 'foo']) == '42foo'
    assert ansible_native_concat(['42', 'foo']) == '42foo'
    assert ansible_native_concat([42, 'foo', 'bar']) == '42foobar'
    assert ansible_native_concat(['42', 42, 42]) == '4242'

    # generator
    # test for duplicate nodes
    generator = (num for num in range(0, 3))
    assert ansible_native_concat(generator) == '012'
    assert ansible_native_concat(generator) == '012'

    # literal_

# Generated at 2022-06-22 14:26:45.686256
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def _assert(data, expected):
        if isinstance(data, string_types):
            node = ast.parse(data, mode='eval')
        else:
            node = data
        assert ansible_native_concat([node]) == expected


# Generated at 2022-06-22 14:26:57.736972
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()

# Generated at 2022-06-22 14:27:05.896059
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Ensure that ansible_native_concat() behaves as expected."""

    from unittest import TestCase, main as unittest_main

    class TestAnsibleNativeConcat(TestCase):

        # Tests for ansible_native_concat()
        def test_ansible_native_concat(self):

            class Node:
                def __init__(self, value):
                    self.value = value

            # The first test is to output everything as a string.
            nodes = [Node("ansible"), Node(" "), Node("native"), Node(" "), Node("concat"), Node(" "), Node("test")]
            self.assertEqual(ansible_native_concat(nodes), "ansible native concat test")

            # Some tests on simple variables.

# Generated at 2022-06-22 14:27:18.218290
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import ensure_text
    from ansible.parsing.yaml.dumper import AnsibleDumper

    ansible_native_concat_type = type(ansible_native_concat)

    # string
    assert ansible_native_concat(["hello"]) == "hello"

    # numbers
    assert ansible_native_concat([5]) == 5
    assert ansible_native_concat([5.0]) == 5.0

    # follow python precedence order
    assert ansible_native_concat(["hello", "world", "!"]) == "helloworld!"
    assert ansible_native_concat(["hello", "world", 5]) == "helloworld5"

# Generated at 2022-06-22 14:27:30.018731
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_unicode

    def _test(a, b, result):
        call_result = ansible_native_concat((a, b))
        assert call_result == result

    _test(1, 2, '12')
    _test(1, '2', '12')
    _test('1', '2', '12')
    _test(1, 10, '110')
    _test(1, 10.0, '110.0')
    _test(1.0, 10.0, '110.0')
    _test(1.0, 10, '110.0')
    _test(1, '2', '12')

# Generated at 2022-06-22 14:27:37.748021
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:27:47.329617
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Unit tests for ansible_native_concat
    assert ansible_native_concat(['str', 0, 1, 2, 3, '', None, False, True]) == 'str0123'
    assert ansible_native_concat(['str', {'a': 1, 'b': 2}, [3, 4, 5]]) == 'str{a: 1, b: 2}[3, 4, 5]'
    assert ansible_native_concat(['str', 'str', 123]) == 'strstr123'
    assert ansible_native_concat(['123', 'abc']) == '123abc'
    assert ansible_native_concat(['123', 'abc', 123]) == '123abc123'

# Generated at 2022-06-22 14:28:02.318077
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:28:06.436626
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Call with no nodes
    assert ansible_native_concat([]) is None

    # Call with single node
    node = 42
    assert ansible_native_concat([node]) == 42

    # Call with multiple nodes
    nodes = [42, 'foo', "bar"]
    assert ansible_native_concat(nodes) == '42foobar'

    # Call is_sequence
    nodes = {'val': 42, 'val2': 'foo'}
    assert ansible_native_concat(nodes.values()) == '42foo'



# Generated at 2022-06-22 14:28:19.837000
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(map(container_to_text, [1.0, 2.0])) == '1.02.0'
    assert ansible_native_concat(map(container_to_text, [1.0, 2.0])) == '1.02.0'
    assert ansible_native_concat(map(container_to_text, [1, 2.0])) == '12.0'
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([text_type('1.0'), text_type('2.0')]) == '1.02.0'
    assert ansible_native_concat([text_type('1'), text_type('2.0')]) == '12.0'

# Generated at 2022-06-22 14:28:32.717495
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import pytest

    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    # run test for python2 and python3
    try:
        unicode
    except NameError:
        unicode = str

    # the first element in each tuple is the expected result,
    # the second element is a list of elements that will be passed to
    # ansible_native_concat

# Generated at 2022-06-22 14:28:45.623055
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(["a"]) == "a"
    assert ansible_native_concat(["a", "b"]) == "ab"
    assert ansible_native_concat(["a", "b", "c"]) == "abc"
    assert ansible_native_concat(["1", "2", "3"]) == 123
    assert ansible_native_concat(["1", "2", "3", "4", "5", "6", "7", "8", "9"]) == 123456789
    assert ansible_native_concat(["[", "'a'", "]"]) == ["a"]
    assert ansible_native_concat(["[", "1", "]"]) == [1]
   

# Generated at 2022-06-22 14:28:58.202381
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat([{'a': 2}, 3, 4]) == [{'a': 2}, 3, 4]
    assert ansible_native_concat([1, {'a': 'hello world'}]) == [1, {'a': 'hello world'}]
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat([1, 2, {'a': {'b': 'hello world'}}]) == [1, 2, {'a': {'b': 'hello world'}}]
    assert ansible_

# Generated at 2022-06-22 14:29:07.122868
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([u'1']) == 1
    assert ansible_native_concat([u'1000']) == 1000
    assert ansible_native_concat([u'0b1010']) == 10
    assert ansible_native_concat([u'0o10']) == 8
    assert ansible_native_concat([u'0x10']) == 16
    assert ansible_native_concat([u'42+3.14j']) == 42 + 3.14j
    assert ansible_native_concat([u'0.2+0.3j']) == 0.2 + 0.3j

# Generated at 2022-06-22 14:29:15.392165
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = [u'1', u'2', u'3']
    assert ansible_native_concat(nodes) == u'123'

    nodes = [u'1', u'2', u'3', u'4']
    assert ansible_native_concat(nodes) == u'1234'

    # Test with generators
    nodes = (n for n in [u'1', u'2', u'3', u'4'])
    assert ansible_native_concat(nodes) == u'1234'

    nodes = (n for n in [u'1', u'2', u'3', u'4', u'5'])
    assert ansible_native_concat(nodes) == u'12345'

    # Test with string types

# Generated at 2022-06-22 14:29:27.687850
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # In the following examples, we try to not use the ``string`` Jinja2
    # filter so that we can cover more cases of unquoted strings.

    # case: Integer values
    data = {'one': 1}
    assert ansible_native_concat([data['one']]) == data['one']

    # case: Non-integer valued string that can be parsed
    data = {'one': '1'}
    assert ansible_native_concat([data['one']]) == data['one']

    # case: Non-integer valued string that cannot be parsed
    data = {'one': 'one'}
    assert ansible_native_concat([data['one']]) == data['one']

    # case: Non-integer valued string that is not parsable surrounded by
    #       literal strings

# Generated at 2022-06-22 14:29:38.553600
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['0x10', '0x200', 0]) == 0x10200
    assert ansible_native_concat(['10', '20', 0]) == 30
    assert ansible_native_concat(['[10, 20]', '[30, 40]']) == [10, 20, 30, 40]
    assert ansible_native_concat(['{10: 20}', '{30: 40}']) == {10: 20, 30: 40}
    assert ansible_native_concat(['[', ']']) == '[]'
    assert ans

# Generated at 2022-06-22 14:29:57.821092
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes_number = [1, 2]
    nodes_str = ['a', 'b']
    nodes_other = [False, '']
    nodes_mixed = [None, 'a', 1, True]
    nodes_empty = []
    nodes_single = ['single']

    assert ansible_native_concat(nodes_number) == 12
    assert ansible_native_concat(nodes_str) == 'ab'
    assert ansible_native_concat(nodes_empty) is None
    assert ansible_native_concat(nodes_single) == 'single'
    assert ansible_native_concat(nodes_other) == 'False'
    assert ansible_native_concat(nodes_mixed) == 'Nonea1True'

# Generated at 2022-06-22 14:30:10.460288
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2.compiler import CodeGenerator
    from jinja2.parser import Parser

    def assert_jinja_to_python(source, expected):
        # Test that a piece of jinja renders to the expected value

        # Evaluate the jinja
        tree = Parser(source, None, None).parse()
        code = CodeGenerator(tree, environment).construct_python()
        namespace = {}
        exec(code, namespace, namespace)
        assert namespace['ansible_native_concat']([]) == expected

        # Ensure that the jinja expression can be evaluated without a
        # variable context by injecting a value containing an undefined.
        # This tests that the code does not call variable access.
        namespace['jinja_context']['undefined'] = StrictUndefined

# Generated at 2022-06-22 14:30:20.947430
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2
    undefined = jinja2.StrictUndefined()

    assert ansible_native_concat([]) is None

    assert ansible_native_concat(['hello']) == 'hello'
    assert ansible_native_concat(['hello', undefined]) == undefined
    assert ansible_native_concat([undefined, 'hello']) == undefined

    assert ansible_native_concat(['hello ', 'world']) == 'hello world'
    assert ansible_native_concat(['hello ', undefined, 'world']) == undefined
    assert ansible_native_concat([undefined, 'hello', ' world']) == undefined
    assert ansible_native_concat(['hello ', ' world']) == 'hello world'

# Generated at 2022-06-22 14:30:32.463124
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    def assert_fail_on_undefined(data, msg=None):
        expected = 'hello world'
        result = _fail_on_undefined(data)
        assert result == expected, msg

    from ansible.module_utils.common.collections import MappingProxyType

    assert ansible_native_concat([]) is None
    assert_fail_on_undefined(StrictUndefined('hello world'),
                             'Fail on StrictUndefined')

    assert_fail_on_undefined({'foo': StrictUndefined('hello world')},
                             'Fail on StrictUndefined in dict')
    assert_fail_on_undefined({'foo': [StrictUndefined('hello world')]},
                             'Fail on StrictUndefined in dict')


# Generated at 2022-06-22 14:30:44.605852
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:30:52.021339
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([True]) == True
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([1, 'foo']) == '1foo'
    assert ansible_native_concat([1, 'foo', True]) == '1fooTrue'



# Generated at 2022-06-22 14:31:01.341928
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text import to_native
    from ansible.module_utils.common.collections import is_sequence

# Generated at 2022-06-22 14:31:05.032474
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    class MyStrictUndefined(StrictUndefined):
        def __unicode__(self):
            raise self

    # ansible_native_concat() should return the value unchanged
    # if no Jinja template expression is used
    assert ansible_native_concat(u'foo') == u'foo'
    assert ansible_native_concat(b'\xf0\x9f\x90\xa7') == b'\xf0\x9f\x90\xa7'
    assert ansible_native_concat(u'\U0001f607') == u'\U0001f607'
    assert ansible_native_

# Generated at 2022-06-22 14:31:13.219683
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import sys
    import io

    # Check if running in Python 3+
    if not sys.version_info[0] >= 3:
        # The following test should fail in Python 2
        assert ansible_native_concat(six.text_type(0)) == 0
    else:
        # Make sure that in Python 3+ Unicode objects are converted to strings
        assert ansible_native_concat(six.text_type(0)) == "0"
        assert ansible_native_concat(six.text_type(1.5)) == "1.5"

    # Simple concatenation with int and float
    assert ansible_native_concat([0, 1.5]) == "01.5"

    # Simple concatenation with string

# Generated at 2022-06-22 14:31:24.426576
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Merge two strings
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'

    # Merge two ints
    assert ansible_native_concat([1, 2]) == 12

    # Merge python data structures
    assert ansible_native_concat(['{"foo": 1}', '{"bar": 2}']) == {'foo': 1, 'bar': 2}

    # Merge a string and a list
    assert ansible_native_concat(['foo', ['b', 'a', 'r']]) == 'foobar'

    # Merge a string and a list
    assert ansible_native_concat([['f', 'o', 'o'], 'bar']) == 'foobar'

    # Merge a list and a string

# Generated at 2022-06-22 14:31:41.770992
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([3]) == 3
    assert ansible_native_concat(["a"]) == "a"
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([False]) is False
    assert ansible_native_concat([3, "b", True]) == "3bTrue"
    assert ansible_native_concat(["a", 3, True]) == "a3True"
    assert ansible_native_concat([True, "b", 3]) == "Trueb3"
    assert ansible_native_concat([3, "b", "True"]) == "3bTrue"
    assert ansible_native_con

# Generated at 2022-06-22 14:31:49.112641
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_cases = (
        (['a', 'b', 'c'], 'abc'),
        (['a', [1, 2, 3], 'c'], 'a[1, 2, 3]c'),
        ([[1, 2, 3], [4, 5, 6]], '[[1, 2, 3], [4, 5, 6]]'),
        (['1', [4, 5, 6]], '[4, 5, 6]'),
        ([], None),
    )
    for test_case in test_cases:
        assert ansible_native_concat(test_case[0]) == test_case[1]



# Generated at 2022-06-22 14:32:00.815624
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = {'1a': 'foobar',
            '2a': ['foobar'],
            '2b': [['foobar']],
            '2c': [{'foo': 'bar'}],
            '3a': 'foobar',
            '3b': {'foo': 'bar'},
            '3c': ['foobar'],
            '3d': [['foobar']],
            '3e': [{'foo': 'bar'}],
            '3f': 'foobar',
            '5a': ['foobar'],
            '5b': [['foobar']],
            '5c': [{'foo': 'bar'}],
            }


# Generated at 2022-06-22 14:32:10.191671
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['one']) == 'one'
    assert ansible_native_concat(['one', 'two']) == 'onetwo'
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([['un', 'deux']]) == ['un', 'deux']
    assert ansible_native_concat([[['un'], 'deux']]) == [['un'], 'deux']
    assert ansible_native_concat([[['un'], 'deux']]) == [['un'], 'deux']


# Generated at 2022-06-22 14:32:18.219980
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.native_jinja import NativeJinjaText

    result = ansible_native_concat(["a", "b"])
    assert result == "ab"

    result = ansible_native_concat(iter(["a", "b"]))
    assert result == "ab"

    result = ansible_native_concat(["a", "b", 1])
    assert result == "ab1"

    result = ansible_native_concat(["a", "b", 1, True])
    assert result == "ab1True"

    result = ansible_native_concat(["1"])
    assert result == 1

    result = ansible_native_concat(["1", 2])
   