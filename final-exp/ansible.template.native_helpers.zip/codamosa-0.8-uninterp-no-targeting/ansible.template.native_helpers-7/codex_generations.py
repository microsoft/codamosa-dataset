

# Generated at 2022-06-21 07:40:40.711427
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    num = 1234
    str1 = 'foo'
    str2 = 'bar'
    str3 = 'foo bar'
    str4 = 'spaces    '
    str5 = 'tabs\t\t\t'
    str6 = 'new\nlines'
    arr = ['foo', 'bar', 'baz']
    dct = {'a': 'foo', 'b': 'bar'}
    obj = object()
    gen = (x for x in range(10))

    assert ansible_native_concat(iter([num])) == num
    assert ansible_native_concat(iter([str1])) == str1
    assert ansible_native_concat(iter([arr])) == arr
    assert ansible_native_concat(iter([dct])) == dct
    assert ansible

# Generated at 2022-06-21 07:40:49.085294
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test list
    from jinja2 import Template
    from jinja2.runtime import StrictUndefined
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    template = Template('{% for item in items -%}{{ item }} {%- endfor %}', undefined=StrictUndefined)
    template.environment.filters['ansible_native_concat'] = ansible_native_concat
    assert template.render(items=[1, 2, StrictUndefined(), None]) == '1 2 '

    # Test unicode
    template = Template('{{ items | ansible_native_concat | string }}', undefined=StrictUndefined)
    template.environment.filters['ansible_native_concat'] = ansible_native_concat

# Generated at 2022-06-21 07:41:01.687050
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([False]) is False
    assert ansible_native_concat([None]) is None

    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat([1, '2']) == '12'
    assert ansible_native_concat(['1', 2]) == '12'

    assert ansible_native_concat([1, 2, 3]) == '123'

# Generated at 2022-06-21 07:41:08.202607
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.playbook.play_context import PlayContext
    from ansible.template.safe_eval import SafeEval

    vault_file = '../../test/integration/vault_test_script/vault.yml'
    context = PlayContext()
    vault_pass_file = '../../test/integration/vault_test_script/vault_password.txt'

    vault_password = open(vault_pass_file, 'r').read().strip()
    vault = VaultLib(vault_password)
    variables = vault.load_vaultfile(vault_file, context).get('vaulted_variables')

    # test conc

# Generated at 2022-06-21 07:41:15.862639
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([None, None]) is None
    assert ansible_native_concat([42, None]) == 42
    assert ansible_native_concat([1, None]) == 1
    assert ansible_native_concat(['var']) == 'var'
    assert ansible_native_concat(['var', None]) == 'var'
    assert ansible_native_concat([42, 43]) == '4243'
    assert ansible_native_concat(['42', 43]) == '4243'
    assert ansible_native_concat(['42', '43']) == '4243'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'

# Generated at 2022-06-21 07:41:25.343058
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # pylint: disable=protected-access
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['yes']) == 'yes'
    assert ansible_native_concat([u'yes']) == u'yes'
    assert ansible_native_concat([u'yes', u'no']) == u'yesno'

    from ansible.vars.unsafe_proxy import UnsafeText
    assert ansible_native_concat([u'yes', UnsafeText(u'_'), u'no']) == u'yes_no'
    assert ansible_native_concat([UnsafeText(u'yes'), u'_', u'no']) == u'yes_no'

    assert ansible_native_concat(['true']) == 'true'
   

# Generated at 2022-06-21 07:41:31.958500
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    assert ansible_native_concat([5]) == 5
    assert ansible_native_concat(["5"]) == "5"

    assert ansible_native_concat([5, 6]) == "56"
    assert ansible_native_concat(["5", 6]) == "56"
    assert ansible_native_concat([5, "6"]) == "56"
    assert ansible_native_concat(["5", "6"]) == "56"

    assert ansible_native_concat([5, 6, 7, 8]) == "5678"
    assert ansible_native_concat(["5", 6, 7, 8]) == "5678"

# Generated at 2022-06-21 07:41:42.363307
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', '', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', ' ', 'bar']) == 'foo bar'
    assert ansible_native_concat(['foo', 1, 'bar']) == 'foo1bar'
    assert ansible_native_concat(['foo', 1, 'bar', dict(), 4]) == 'foo1bar4'
    assert ansible_native_concat(['foo', to_text(1), 'bar', dict(), 4]) == 'foo1bar4'



# Generated at 2022-06-21 07:41:54.311074
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Simple concat
    assert ansible_native_concat([u'a', u'b']) == u'ab'

    # Single value
    assert ansible_native_concat([u'a']) == u'a'

    # Empty
    assert ansible_native_concat([]) is None

    # NativeJinjaText
    assert ansible_native_concat([NativeJinjaText(u'a')]) == u'a'

    # AnsibleVaultEncryptedUnicode
    assert ansible_native_concat([AnsibleVaultEncryptedUnicode('c2FsdA==')]) == 'c2FsdA=='

    # Generator
    gen = (u'a', u'b')
    assert ansible_native_concat(iter(gen)) == u'ab'

   

# Generated at 2022-06-21 07:42:04.396936
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:42:19.596846
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    value = ansible_native_concat(['a', 'b'])
    assert value == u'ab'

    value = ansible_native_concat(['a', 'b', 'c'])
    assert value == u'abc'

    value = ansible_native_concat(['1', '2', '3'])
    assert value == 123

    # unparseable values should be treated as strings
    value = ansible_native_concat(['a', 'b', 'c'] * 100)
    assert isinstance(value, text_type)
    assert len(value) == 300

    # add a space to the last value to make it unparseable
    value = ansible_native_concat(['1', '2', '3 '])
    assert isinstance(value, text_type)
    assert value == u

# Generated at 2022-06-21 07:42:26.288691
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import os
    import random
    import sys
    import string
    import tempfile
    import unittest

    from ansible.module_utils.basic import AnsibleModule

    ansible_concat = AnsibleModule(
        argument_spec=dict(
            one=dict(required=False, type='raw'),
            two=dict(required=False, type='raw'),
            three=dict(required=False, type='raw'),
            four=dict(required=False, type='raw'),
            five=dict(required=False, type='raw'),
        )
    )
    module_concat = ansible_concat._ansible_concat


# Generated at 2022-06-21 07:42:36.774325
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2.lexer import Token
    from jinja2.nodes import Const
    from ansible.module_utils import basic
    import ansible.module_utils.jinja2.concat

    def token(lineno, value):
        return Token(lineno, value, None, None)

    const = lambda v: Const(token(1, v), v)
    const_undef = lambda v: Const(token(1, StrictUndefined(v)), StrictUndefined(v))

    # test ansible_native_concat using native jinja2 concat function
    basic.ANSIBLE_MODULE_ARGS = {}
    assert ansible_native_concat(ansible.module_utils.jinja2.concat.concat([const("abc"), const("def")])) == "abcdef"


# Generated at 2022-06-21 07:42:46.707085
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2
    from ansible.module_utils.common.text.converters import to_native

# Generated at 2022-06-21 07:42:57.349648
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test with a single string parameter
    assert ansible_native_concat([u'foo']) == u'foo'

    # Test with a single integer parameter
    assert ansible_native_concat([u'2']) == 2

    # Test with a single list parameter
    assert ansible_native_concat([u'[1]']) == [1]

    # Test with a single dict parameter
    assert ansible_native_concat([u'{1:1}']) == {1: 1}

    # Test with a single boolean parameter
    assert ansible_native_concat([u'False']) is False

    # Test with two string parameters, should return a string
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'

    # Test with two numeric parameters, should return numeric

# Generated at 2022-06-21 07:43:04.792524
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    def test_type(nodes, expected):
        actual = ansible_native_concat(nodes)
        assert isinstance(actual, expected)
        assert actual == expected

    test_type(['foo'], 'foo')
    test_type(['foo', 'bar'], 'foobar')
    test_type(['123'], '123')
    test_type(['1', '2', '3'], '123')
    test_type(['True'], True)
    test_type(['False'], False)
    test_type(['1', '2', '3'], '123')
    test_type(['{"key": "value"}'], {'key': 'value'})
    test_type(['[1, 2, 3, 4]'], [1, 2, 3, 4])
    test

# Generated at 2022-06-21 07:43:16.109259
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert container_to_text(
        ansible_native_concat([text_type('a')]),
    ) == u'a'

    assert container_to_text(
        ansible_native_concat([text_type('a'), text_type('b')]),
    ) == u'ab'

    assert container_to_text(
        ansible_native_concat([text_type('a'), text_type('b'), text_type('c')]),
    ) == u'abc'

    assert container_to_text(
        ansible_native_concat(map(text_type, ('a', 'b', 'c'))),
    ) == u'abc'

# Generated at 2022-06-21 07:43:26.670754
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2.runtime

    # Test if list is returned
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]

    # Test if tuple is returned
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]

    # Test if strings are concatenated and returned
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 'bar', 'baz']) == 'foobarbaz'

    # Test for consistency with jinja2.nativetypes.concat

# Generated at 2022-06-21 07:43:35.245974
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # This test is borrowed from unit tests of
    # https://github.com/pallets/jinja/blob/master/src/jinja2/nativetypes.py
    def assert_equals(got, want):
        if got != want:
            raise AssertionError('%r != %r' % (got, want))

    def ast_literal_eval(value):
        try:
            return ast.literal_eval(value)
        except (SyntaxError, ValueError):
            return value

    assert_equals(
        ansible_native_concat([]),
        ast_literal_eval('')
    )

    num_123 = 123
    assert_equals(
        ansible_native_concat([num_123]),
        ast_literal_eval(num_123)
    )

# Generated at 2022-06-21 07:43:48.464431
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'1', u'2', u'3']) == '123'
    assert ansible_native_concat([u'1', 1, 2, u'3']) == '11213'
    assert ansible_native_concat([u'1']) == '1'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([]) == None
    assert ansible_native_concat([['a', 'b'], ['c', 'd']]) == ['a', 'b', 'c', 'd']
    assert ansible_native_concat([['a', 'b'], 1]) == ['a', 'b', 1]
    assert ansible_native_concat([['a', 'b']]) == ['a', 'b']

# Generated at 2022-06-21 07:44:01.885210
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['1', '2']) == 3
    assert ansible_native_concat(['1.0', '2.0']) == 3.0
    assert ansible_native_concat(['foo', 1, 'bar']) == 'foo1bar'
    assert ansible_native_concat(['1', '2\n3']) == '12\n3'
    assert ansible_native_concat(['1', '2', '3']) == '123'

# Generated at 2022-06-21 07:44:08.515276
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # https://github.com/pallets/jinja/blob/master/tests/autopep8/test_native_types.py
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(iter(['1'])) == '1'
    assert ansible_native_concat(iter(['1', '2'])) == '12'
    assert ansible_native_concat(iter(['1  ', '\n2'])) == '1  \n2'
    assert ansible_native_concat(iter(['1', None])) == '1None'
    assert ansible_native_concat(iter([None, '2'])) == 'None2'
    assert ansible_native_concat(iter([True, None])) is True
    assert ansible_native_

# Generated at 2022-06-21 07:44:20.455676
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Single string
    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat([u'foo']) == u'foo'

    # Concatenated strings
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'

# Generated at 2022-06-21 07:44:28.465559
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat([1, 2, '3']) == [1, 2, '3']
    assert ansible_native_concat([1, 2, "'3'"]) == [1, 2, "'3'"]
    assert ansible_native_concat([1, 2, "'3'", 4]) == [1, 2, "'3'", 4]
    assert ansible_native_concat([1, 2, "['3']"]) == [1, 2, ['3']]
    assert ansible_native_concat([1, 2, "['3', 4]"]) == [1, 2, ['3', 4]]

# Generated at 2022-06-21 07:44:39.828217
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2]) == 1
    assert ansible_native_concat(iter([1, 2])) == 1
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([True, False]) is True
    assert ansible_native_concat([True, False, True]) == 'TrueFalseTrue'
    assert ansible_native_concat([False, True]) == 'FalseTrue'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
   

# Generated at 2022-06-21 07:44:51.998384
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', to_text('bar')]) == 'foobar'
    assert ansible_native_concat(['foo', u'test_unicode_string']) == 'footest_unicode_string'
    assert ansible_native_concat(['[', '1, 2, 3', ']']) == [1, 2, 3]
    assert ansible_native_concat(['{', '"foo": "bar"', '}']) == dict(foo='bar')
    assert ansible_native_concat(['{', '"test_int": 1234567890', '}']) == dict(test_int=1234567890)

# Generated at 2022-06-21 07:45:01.578979
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # https://github.com/ansible/ansible/pull/91312

    # native python types
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['1']) == '1'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat([1, '2']) == '12'
    assert ansible_native_concat([1, u'2']) == u'12'

    # concatenated types
    assert ansible_native_concat(['1', 2]) == '12'
    assert ansible_native_concat([1, '2', 3]) == '123'

# Generated at 2022-06-21 07:45:11.040114
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    string_out = ansible_native_concat(["foo", "bar"])
    assert isinstance(string_out, str) and string_out == "foobar"

    list_out = ansible_native_concat(["{", "foo", ",", "bar", "}"])
    assert isinstance(list_out, list) and list_out == ["foo", "bar"]

    dict_out = ansible_native_concat(["{", "'foo'", ":", "bar", "}"])
    assert isinstance(dict_out, dict) and dict_out == {"foo": "bar"}

    tuple_out = ansible_native_concat(["(", "foo", ",", "bar", ")"])

# Generated at 2022-06-21 07:45:21.581752
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2
    nodes = jinja2.nodes.Environment().parse('{{ a ~ b }}')
    value = ansible_native_concat((nodes.iter()))
    assert value is None

    nodes = jinja2.nodes.Environment().parse('{{ a if a else b }}')
    value = ansible_native_concat((nodes.iter()))
    assert value is None

    nodes = jinja2.nodes.Environment().parse('{{ [1,2,3] | map("int") | list }}')
    value = ansible_native_concat((nodes.iter()))
    assert value == [1, 2, 3]

    nodes = jinja2.nodes.Environment().parse('{{ [1,2,3] | map("str") | list }}')
    value

# Generated at 2022-06-21 07:45:34.016883
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:45:46.765007
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = ['', 'b']

    out = ansible_native_concat(nodes)
    assert out == 'b'

    nodes = ['', 'b', '']
    out = ansible_native_concat(nodes)
    assert out == 'b'

    nodes = ['a', 'b', 'c']
    out = ansible_native_concat(nodes)
    assert out == 'abc'

    nodes = ['1', '2', '3']
    out = ansible_native_concat(nodes)
    assert out == 123

    nodes = ['0', '1', '2', '3']
    out = ansible_native_concat(nodes)
    assert out == '0123'

    nodes = [0, 1, 2, 3]
    out = ansible_native_concat

# Generated at 2022-06-21 07:45:59.760334
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Verify that ansible_native_concat doesn't remove leading whitespace
    # from the expression
    assert '    123' == ansible_native_concat([NativeJinjaText('    123')])
    assert '    123' == ansible_native_concat([NativeJinjaText('    123'), NativeJinjaText('   456')])
    assert '    123   456' == ansible_native_concat([NativeJinjaText('    123'), NativeJinjaText('   456')])

    # Verify that ansible_native_concat returns a string if the expression
    # can't be converted to an integer
    assert '123456789A' == ansible_native_concat([NativeJinjaText('123456789A')])
    assert '123456789A' == ansible_native

# Generated at 2022-06-21 07:46:06.265579
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = [2, 3]
    assert 5 == ansible_native_concat(nodes)

    nodes = ['a', 'b', 'c']
    assert 'abc' == ansible_native_concat(nodes)

    nodes = ['2', '3']
    assert 5 == ansible_native_concat(nodes)

    nodes = ['a', 1]
    assert 'a1' == ansible_native_concat(nodes)

    nodes = ['a', 'b', 1]
    assert 'ab1' == ansible_native_concat(nodes)

    nodes = ['a', 1, 'b']
    assert 'a1b' == ansible_native_concat(nodes)


# Generated at 2022-06-21 07:46:17.363423
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:46:29.330320
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_native, to_text
    assert ansible_native_concat([u'a', 1, 2, 3]) == u'a123'
    assert ansible_native_concat([[u'a', [u'b'], u'c'], 1, 2, 3]) == u'abc123'
    assert ansible_native_concat([u'a', 1, 2, 3, to_text(u'b\xc3\xa4', 'utf-8')]) == u'a123b\xc3\xa4'
    assert ansible_native_concat([u'a', to_text(u'b\xc3\xa4', 'utf-8'), u'c']) == u'abc'

# Generated at 2022-06-21 07:46:36.658516
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def assert_native_concat(data, expected):
        assert ansible_native_concat([data]) == expected

    class UndefinedClass(object):
        def __nonzero__(self):
            raise UndefinedException

        def __repr__(self):
            return 'Undefined'

    undefined = UndefinedClass()

    assert_native_concat(undefined, undefined)
    assert_native_concat([], None)
    assert_native_concat(False, False)
    assert_native_concat(True, True)
    assert_native_concat(None, None)
    assert_native_concat(u'', u'')
    assert_native_concat(42, 42)
    assert_native_concat(42.0, 42.0)

# Generated at 2022-06-21 07:46:46.850058
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.native_jinja import NativeJinjaText
    from ansible.module_utils.six import PY3
    import ast

    assert ansible_native_concat([]) is None
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([1, 2]) == 3
    assert ansible_native_concat([1, u'2']) == u'12'

    # StrictUndefined
    assert ansible_native_concat([StrictUndefined]) == u''

    # collections.abc.Mapping

# Generated at 2022-06-21 07:46:55.478299
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import Environment

    env = Environment(undefined=StrictUndefined)

    env.filters['ansible_native_concat'] = ansible_native_concat
    env.filters['to_text'] = to_text


# Generated at 2022-06-21 07:47:07.594988
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([None, None]) is None

    assert ansible_native_concat(['foo']) == 'foo'

    assert ansible_native_concat([42]) == 42

    assert ansible_native_concat([1, '2', '3']) == 123

    assert ansible_native_concat([1, '2', None, '3']) == '123'

    assert ansible_native_concat(['foo', 'bar']) == 'foobar'

    assert ansible_native_concat([['foo'], ['bar']]) == ['foobar']

    assert ansible_native_concat(['foo', 'bar', '', 'baz']) == 'foobarbaz'

    # From https://github.com/pallets/jinja/issues/1200

# Generated at 2022-06-21 07:47:12.005778
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_values = [
        [["test"]],
        [["test", "test2"]],
        [["test", "", "test2"]],
        [[""]],
        [["", ""]],
        [["", "", ""]],
    ]
    for value in test_values:
        assert ansible_native_concat(value) == "testtest2"



# Generated at 2022-06-21 07:47:27.243603
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat('foo') == 'foo'
    assert ansible_native_concat(True) is True
    assert ansible_native_concat(None) is None
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat(['']) == ''
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat(['foo', 'bar', 'baz']) == 'foobarbaz'
    assert ansible_native_concat([True, False, True]) == 'TrueFalseTrue'
    assert ansible_native_concat([True, False, 1]) == 'TrueFalse1'

# Generated at 2022-06-21 07:47:38.076292
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import pytest

    def run_test(nodes, expected):
        assert ansible_native_concat(nodes) == expected

    # TEST 1: Accepts native python objects as input
    run_test([1, 2, 3], 123)

    # TEST 2: Accepts unicode strings and str in python 2 as input
    run_test([u'r', u'a', u'n'], u'ran')
    run_test([u'c', 'a', u't'], u'cat')
    run_test([u'f', 'ish', u'e'], u'fishe')

    # TEST 2: Accepts str in python 3 as input
    run_test(['f', 'o', 'x'], u'fox')

    # TEST 3: Concatenates or passes input that can't be converted to native

# Generated at 2022-06-21 07:47:50.426997
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2]) == [1, 2]
    assert ansible_native_concat([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert ansible_native_concat([1, 2, 'abc']) == [1, 2, 'abc']
    assert ansible_native_concat([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert ansible_native_concat([1, 2, 'abc', 4]) == [1, 2, 'abc', 4]
    assert ansible_native_concat([1, 2, [3, 4]]) == [1, 2, [3, 4]]

# Generated at 2022-06-21 07:47:57.580382
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'']) == u''
    assert ansible_native_concat([u'Some text']) == u'Some text'
    assert ansible_native_concat([u'Some text', u'', u'under here']) == u'Some textunder here'
    assert isinstance(ansible_native_concat([u'Some text', u'', u'under here']), string_types)
    assert ansible_native_concat([u'Some text', u'', u'int: 42']) == 42
    assert isinstance(ansible_native_concat([u'Some text', u'', u'int: 42']), int)
    assert ansible_native_concat([u'Some text', u'', u'bool: True']) is True

# Generated at 2022-06-21 07:48:09.697508
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2.compiler import CodeGenerator
    from jinja2.environment import Template
    from jinja2.nodes import Node
    from jinja2.runtime import Context

    class DumpNode(Node):
        def __init__(self, value):
            super(DumpNode, self).__init__()
            self.value = value

        def __call__(self, *args, **kwargs):
            return self.value

        def __repr__(self):
            return "%s(%r)" % (self.__class__.__name__, self.value)

        def __str__(self):
            return "%s(%r)" % (self.__class__.__name__, self.value)


# Generated at 2022-06-21 07:48:21.669758
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import DictLoader
    from ansible.module_utils.common.text.converters import native_concat_native, to_native


# Generated at 2022-06-21 07:48:32.232863
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    data = """
    - abc: {{ 123|string }}
    - def: ['foo', 'bar']
    - ghi:
      - 'foo'
      - 'bar'
    - jkl:
      mno: foo
    - { pqr: '{{ stu }}' }
    - <vw>
    - xyz: '{{ foo }}'
    """
    assert ast.literal_eval(data) == {
        'abc': '123',
        'def': ['foo', 'bar'],
        'ghi': ['foo', 'bar'],
        'jkl': {'mno': 'foo'},
        'pqr': '{{ stu }}',
        'vw': '{{ foo }}',
        'xyz': '{{ foo }}',
    }


# Generated at 2022-06-21 07:48:43.185044
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.six import PY3
    from .common import is_py3_compat_target

    def assert_type(result, expected_type):
        assert (isinstance(result, expected_type),
                '{expected_type} expected, found {result}'.format(
                    result=container_to_text(result),
                    expected_type=expected_type
                )
        )

    # we cannot use string concat in python3 because the a+b string concat form
    # is a shortcut for
    # a = a.__add__(b), so instead we have to emulate the way jinja tries to
    # concatinate the nodes in ansible.module_utils.common._native_concat

# Generated at 2022-06-21 07:48:52.657342
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import text_type

    def _assert_equal(expected, result):
        assert expected == result, "expected=%r, result=%r" % (expected, result)

    def _assert_raise(exc, callable, *args, **kwargs):
        try:
            callable(*args, **kwargs)
        except Exception as e:
            assert type(e) == type(exc), "expected=%r, result=%r" % (type(exc), type(e))
        else:
            assert False, "Expecting exception"


# Generated at 2022-06-21 07:49:02.447033
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Basic
    assert ansible_native_concat([]) == None
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat(["42"]) == 42
    assert ansible_native_concat(['42', 'true']) == '42true'
    assert ansible_native_concat(["42", "true"]) == '42true'
    assert ansible_native_concat([NativeJinjaText("42"), NativeJinjaText("true")]) == '42true'
    assert ansible_native_concat([NativeJinjaText("42"), NativeJinjaText("true")]) != '42 true'
    # Addition
    assert ansible_native_concat(["42", "+", "21"]) == '42+21'
    # Strings
   

# Generated at 2022-06-21 07:49:20.328827
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a', 1]) == 'a1'
    assert ansible_native_concat(['a', 1, 'b']) == 'a1b'
    assert ansible_native_concat(['a', 1, 'b', 2]) == 'a1b2'
    assert ansible_native_concat(['a', 1, 'b', 2, 'c']) == 'a1b2c'
    assert ansible_native_concat([1, 'a', 2, 'b', 3, 'c']) == '1a2b3c'
    assert ansible_native_concat(['a', 1, 'a', 2, 'a', 3, 'a']) == 'a1a2a3a'

# Generated at 2022-06-21 07:49:32.239272
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # unit test for possible failure in implemented new method
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', 'b', 'ab']) == 'abab'
    assert ansible_native_concat(['a', True, 'ab']) == 'aTrueab'
    assert ansible_native_concat(['a', ['a', 'b'], 'ab']) == 'aababab'
    assert ansible_native_concat(['a', ['a', ['a', 'b']], 'ab']) == 'aababab'
    assert ansible_native_concat(['a', ['a', ['a', 'b', 'c']], 'ab']) == 'aabababcab'
    assert ansible_native_

# Generated at 2022-06-21 07:49:38.448243
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Unit test for function ansible_native_concat"""
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.module_utils.six import PY3
    import pytest

    def _to_ansible_text(value):
        if isinstance(value, bytes) and PY3:
            return to_text(value)
        return value

    def _ansible_concat(nodes):
        return _to_ansible_text(ansible_native_concat(nodes))

    class FakeAst:
        """This object simulates the results of ast.parse()"""
        def __init__(self, output_val):
            self.body = [output_val]


# Generated at 2022-06-21 07:49:48.975571
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 1]) == 2
    assert ansible_native_concat([1, '1']) == '11'
    assert ansible_native_concat(['1', 1]) == '11'
    assert ansible_native_concat(['1', '1']) == 2
    assert ansible_native_concat([1.5, 1]) == 2.5
    assert ansible_native_concat([1.5, '1']) == '1.51'
    assert ansible_native_concat(['1', 1.5]) == '11.5'
    assert ansible_native_concat('foo') == 'foo'
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([1]) == 1


# Generated at 2022-06-21 07:49:55.191557
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.module_utils.common.collections import MutableMapping
    from jinja2.runtime import Undefined
    from six import IntegerTypes
    from collections import Mapping


# Generated at 2022-06-21 07:50:05.562831
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test ansible_native_concat()"""

    # The ast module has a parser, which will fail if it finds any undesired
    # whitespace or tabs.
    from ansible.module_utils.six import PY2

    if not PY2 and not getattr(types, 'GeneratorType', False):
        # Python 3.7, 3.8 and 3.9 do not have types.GeneratorType
        # https://docs.python.org/3/library/types.html
        return

    # test scalar, literal_eval() should succeed
    assert ansible_native_concat([1]) == 1

    # test literals, literal_eval() should succeed
    assert ansible_native_concat([1, 2, 3]) == 123

# Generated at 2022-06-21 07:50:16.101702
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([u'foo', [u'bar', 2]]) == u'foobar2'
    assert ansible_native_concat([u'foo', 1]) == u'foo1'
    assert ansible_native_concat([u'foo', 1, u'bar']) == u'foo1bar'

# Generated at 2022-06-21 07:50:27.621185
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat(['1', '2', '3']) == '123'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(['a', 'b', '3']) == 'ab3'
    assert ansible_native_concat(['a', '2', 'c']) == 'a2c'
    assert ansible_native_concat(['1', 'b', 'c']) == '1bc'