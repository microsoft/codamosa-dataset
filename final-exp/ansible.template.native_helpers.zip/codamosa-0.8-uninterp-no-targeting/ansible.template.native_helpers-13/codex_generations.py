

# Generated at 2022-06-21 07:40:40.581241
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == u"12"
    assert ansible_native_concat([1, 2, 3]) == u"123"
    assert ansible_native_concat([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == u"12345678910"
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat(['1']) == '1'
    assert ansible_native_concat([1, 2, '3']) == u"123"
    assert ansible_native_concat(['a', 2, '3']) == u"a23"

# Generated at 2022-06-21 07:40:48.929991
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.facts.system.distribution import Distribution

    # https://github.com/ansible/ansible/issues/70831
    # NativeJinjaText should not be processed by literal_eval
    assert ansible_native_concat((NativeJinjaText(u'a'), 1, NativeJinjaText(u'b'), 2)) == [
        u'a', 1, u'b', 2]
    # Non-string types should not be processed by literal_eval
    assert ansible_native_concat((Distribution(u'a'), 1, Distribution(u'b'), 2)) == [
        Distribution(u'a'), 1, Distribution(u'b'), 2
    ]

    # literal_eval should be properly invoked on strings, but without
    # leading spaces
    # https://github.com/pallets

# Generated at 2022-06-21 07:41:01.575813
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([1, 'foo', 'bar']) == '1foobar'
    assert ansible_native_concat([1, 2, 3, 4]) == 10

    # _undeclared_ is a sentinel object used by jinja2
    # to represent undefined values.
    assert ansible_native_concat(['foo', 'bar', _undeclared_]) == 'foobar'

    assert ansible_native_concat([1, 'foo', 'bar', _undeclared_]) == '1foobar'
    assert ansible_native_

# Generated at 2022-06-21 07:41:13.075908
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # TODO: test with variables
    # TODO: test with literals
    # TODO: test with filters
    # TODO: test with native_jinja_text
    # TODO: test with ansible_vault_encrypted_unicode
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', 1, 2, 'b', 'c']) == 'a1b2c'
    assert ansible_native_concat([2, 3, 5, 7, 11]) == '23511'
    assert ansible_native_concat(["abc", "def", None]) == "abcdefNone"

# Generated at 2022-06-21 07:41:23.971429
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2
    env = jinja2.Environment()
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat([u'foo']) == 'foo'
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([u'foo', u'bar']) == 'foobar'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, u'foo']) == u'1foo'
    assert ansible_native_concat([1, u'foo']) == '1foo'

# Generated at 2022-06-21 07:41:33.650477
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat([u'a']) == u'a'
    assert ansible_native_concat([u'a', u'b']) == u'ab'
    assert ansible_native_concat([u'a', u'b', u'c']) == u'abc'
    assert ansible_native_concat([u'a', u'b', u'c', u'd']) == u'abcd'
    assert ansible_native_concat([u'a', u'', u'b', u'', u'c', u'd']) == u'abc'
    assert ansible_native_concat([u'a', u'b', u'c', u'd', u'e']) == u'abcde'

# Generated at 2022-06-21 07:41:43.974911
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(['1', 2, '3']) == '123'
    assert ansible_native_concat(['1', '2', 3]) == '123'
    assert ansible_native_concat([1, '2', '3']) == '123'
    assert ansible_native_concat([1, 'b', 'c']) == '1bc'
    assert ansible_native_concat(['a', 2, 'c']) == 'a2c'
    assert ansible_native_concat(['a', '2', 3]) == 'a23'
    assert ansible_native_

# Generated at 2022-06-21 07:41:52.511190
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(["foo", "bar"]) == "foobar"
    assert ansible_native_concat(["hello", "world"]) == "helloworld"
    assert ansible_native_concat(["foo", "bar", "baz", "quux"]) == "foobarbazquux"
    assert ansible_native_concat(["foo", "bar", "baz", 123]) == "foobarbaz123"
    assert ansible_native_concat(["foo", "bar", "baz", {'foo': 'bar'}]) == "foobarbaz{'foo': 'bar'}"
    assert ansible_native_concat([123, "foo", "bar", "baz", {'foo': 'bar'}]) == 123
    assert ansible_native_con

# Generated at 2022-06-21 07:42:03.669811
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['hello']) == 'hello'
    assert ansible_native_concat(['hello', ' world']) == 'hello world'
    assert ansible_native_concat(['1', '+', '1', '==', '2']) == '1+1==2'
    assert ansible_native_concat([1, '+', 1, '==', 2]) == '1+1==2'
    assert ansible_native_concat([1, '+', 1, '==', 2]) == '1+1==2'
    assert ansible_native_concat(['12', '34']) == 1234
    assert ansible_native_concat(['12', '34']) == 1234
    assert ansible

# Generated at 2022-06-21 07:42:14.452369
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert (ansible_native_concat([container_to_text("hel"),
                                   container_to_text("lo")]) == "hello")
    assert (ansible_native_concat([container_to_text("- hel"),
                                   container_to_text("lo")]) == "- hello")
    assert (ansible_native_concat([container_to_text("hello")]) == "hello")
    assert (ansible_native_concat([container_to_text("'''hello'''")]) == "hello")
    assert (ansible_native_concat([container_to_text("'''hel\nlo'''")]) == "hel\nlo")
    assert (ansible_native_concat([container_to_text("- hello")]) == "- hello")

# Generated at 2022-06-21 07:42:34.765784
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.tests.unit.compat import mock

    branches = [1, 2]

# Generated at 2022-06-21 07:42:44.079737
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.yaml.dumper import AnsibleDumper


# Generated at 2022-06-21 07:42:50.713663
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert None is ansible_native_concat(['', '', None, ''])
    assert 123 is ansible_native_concat(['123'])
    assert 123.0 is ansible_native_concat(['123.0'])
    assert u'abc123.0' is ansible_native_concat([u'abc123.0'])
    assert u'abc123' is ansible_native_concat(['abc', '123'])
    assert [1, 2, 3] is ansible_native_concat(['[1, 2, 3]'])
    assert {'a': 'b'} is ansible_native_concat(['{"a": "b"}'])
    assert {'a', 'b'} is ansible_native_concat(['{"a", "b"}'])

# Generated at 2022-06-21 07:43:03.509267
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class Node:
        def __init__(self, value):
            self.value = value

    assert ansible_native_concat(Node('foo')) == 'foo'

    nodes = iter([Node(1), Node('foo'), Node('1')])
    assert ansible_native_concat(nodes) == '1foo1'

    nodes = iter([Node(1), Node('foo'), Node('1')])
    assert ansible_native_concat(nodes) == '1foo1'

    nodes = iter([Node('foo'), Node(None)])
    assert ansible_native_concat(nodes) is None

    nodes = iter([Node(None), Node('foo')])
    assert ansible_native_concat(nodes) == 'foo'

    # non-strings
    assert ansible_native_con

# Generated at 2022-06-21 07:43:16.865813
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Test for bug https://github.com/ansible/ansible/issues/70831
    assert ansible_native_concat([NativeJinjaText('x'), 1, 2, 3]) == 'x123'

    # test case: https://github.com/ansible/ansible/issues/70831#issuecomment-664190894
    assert ansible_native_concat([1, NativeJinjaText('x'), 2]) == '1x2'
    assert ansible_native_concat([1, 2, NativeJinjaText('x')]) == '12x'

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2, 3]) == 6
    assert ansible_native_concat([1, 2, 3, 10]) == 16
    assert ans

# Generated at 2022-06-21 07:43:28.106276
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import sys
    import jinja2
    from jinja2.compiler import CodeGenerator
    from jinja2.runtime import Undefined

    # To load ansible_native_concat we need to create a jinja2 environment.
    # We will pass the jinja2 environment as the first argument to
    # ansible_native_concat function.
    env = jinja2.Environment(concat=ansible_native_concat)

    # Create AST nodes with the given expression,
    # and compile them into a list of nodes.
    def compile_ast_nodes(template):
        ast_nodes = env.parse(template)
        code_gen = CodeGenerator(env.name, env.line_statement_prefix)
        ast_nodes.set_lineno(0)
        ast_n

# Generated at 2022-06-21 07:43:35.617739
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = []
    out = ansible_native_concat(nodes)
    assert out is None
    nodes = [u'hello']
    out = ansible_native_concat(nodes)
    assert out == 'hello'
    nodes = [u'hello\nworld']
    out = ansible_native_concat(nodes)
    assert out == 'hello\nworld'
    nodes = [1, 2, 3]
    out = ansible_native_concat(nodes)
    assert out == [1, 2, 3]
    nodes = [1, 2, 3, u'hello']
    out = ansible_native_concat(nodes)
    assert out == '1, 2, 3hello'
    nodes = [u'hello', 'world', 1, 2, 3]
    out = ans

# Generated at 2022-06-21 07:43:48.650402
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['1.0']) == 1.0
    assert ansible_native_concat(['1.0', '2.0']) == '1.02.0'
    assert ansible_native_concat(['1.0', '2.0']) == '1.02.0'
    assert ansible_native_concat(['1.0', ' 2.0']) == '1.0 2.0'

    assert ansible_native_concat(['{}']) == {}

# Generated at 2022-06-21 07:44:01.035211
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([1, 'bar']) == 'bar'
    assert ansible_native_concat(['foo', 1]) == 'foo1'
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat(['foo', 'bar', 1]) == 'foobar1'
    assert ansible_native_concat([1, 'foo', 'bar']) == '1foobar'
    assert ansible_native_concat([1, 'foo', 'bar', 2]) == '1foobar2'
    assert ansible_native_concat(['foo', 'bar', 1, 2]) == 'foobar12'
    assert ansible_native_

# Generated at 2022-06-21 07:44:08.841778
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = [
        "[u'This', u'is', u'a', u'test']",
        '',
        "[u'This', u'is', u'a', u'test']",
        '',
        "{u'foo': u'bar'}",
    ]
    expected = """
[
  "This",
  "is",
  "a",
  "test"
]

[
  "This",
  "is",
  "a",
  "test"
]

{
  "foo": "bar"
}
"""
    assert expected == container_to_text(ansible_native_concat(nodes), indent=2)


# Generated at 2022-06-21 07:44:24.195638
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    def ansible_native_concat_stub(nodes):
        return ansible_native_concat(nodes)

    import sys
    import pytest
    from collections import Iterable, Iterator
    from jinja2.utils import Undefined

    if sys.version_info < (3, 0):
        from itertools import imap
        builtin_map = imap
    else:
        builtin_map = map

    # None
    result = ansible_native_concat_stub([])
    assert result is None

    # Primitive types
    result = ansible_native_concat_stub(['string'])
    assert result == 'string'
    result = ansible_native_concat_stub([1])
    assert result == 1
    result = ansible_native_concat_

# Generated at 2022-06-21 07:44:35.884467
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat(['']) == ''
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([[]]) == []
    assert ansible_native_concat([['foo']]) == ['foo']
    assert ansible_native_concat([{}]) == {}
    assert ansible_native_concat([{'foo': 'bar'}]) == {'foo': 'bar'}
    assert ansible_native_concat([0, 'foo']) == '0foo'

# Generated at 2022-06-21 07:44:43.324057
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_text, to_native
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    assert ansible_native_concat([]) is None
    assert ansible_native_concat([9]) == 9
    assert ansible_native_concat([1, 2]) == 1
    # to_text is called because literal_eval has no text type
    assert ansible_native_concat([to_text(1), to_text(2)]) == '12'
    assert ansible_native_concat(['1', '2']) == 1
    assert ansible_native_concat([to_text('a'), to_text('b')]) == 'ab'

# Generated at 2022-06-21 07:44:54.403871
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(('foo', 'bar')) == 'foobar'
    assert ansible_native_concat((42, 42)) == 84
    assert ansible_native_concat((None, 42, None)) == 84

    assert ansible_native_concat(('foo', 'bar', 'baz')) == 'foobarbaz'
    assert ansible_native_concat((1, 2, 3)) == '123'
    assert ansible_native_concat((1, 2, 3, None)) == '123None'

    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([42, 42]) == 84
    assert ansible_native_concat([42, 'foo', 42]) == '42foo42'

# Generated at 2022-06-21 07:45:01.545949
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['true']) is True
    assert ansible_native_concat(['false']) is False
    assert ansible_native_concat(['foo']) == u'foo'
    assert ansible_native_concat(['foo', 'bar']) == u'foobar'
    assert ansible_native_concat(['foo: ', 'bar']) == u'foo: bar'
    assert ansible_native_concat(['foo', ':', 'bar']) == u'foo:bar'
    assert ansible_native_concat(['foo: ', 'bar', ':', 'baz']) == u'foo: bar:baz'

# Generated at 2022-06-21 07:45:11.012224
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Test literals and nested literals
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([['a'], ['b']]) == 'ab'
    assert ansible_native_concat([['a'], ['b', 'c']]) == ['a', 'bc']
    assert ansible_native_concat([1, 'a', [2, 'b'], {1, 2, 3}]) == '1a2b{1, 2, 3}'

    # Test non-string literals
    assert ansible_native_concat([set([1, 2])]) == {1, 2}

    #

# Generated at 2022-06-21 07:45:21.546382
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = [0, 1, 2, 3, 4]
    assert ansible_native_concat(nodes) == [0, 1, 2, 3, 4]

    nodes = [0, 1, 'a', 3, 4]
    assert ansible_native_concat(nodes) == [0, 1, 'a', 3, 4]

    nodes = [0, 1, 'a', 3, 'b']
    assert ansible_native_concat(nodes) == [0, 1, 'a', 3, 'b']

    nodes = [0, 1, 'a', 'b']
    assert ansible_native_concat(nodes) == [0, 1, 'a', 'b']

    nodes = [0, 'a']
    assert ansible_native_concat(nodes) == '0a'



# Generated at 2022-06-21 07:45:34.017302
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test native concat with a list
    input_data = ['foo', 'bar']
    expected_result = 'foobar'
    assert ansible_native_concat(input_data) == expected_result

    # Test native concat with a dictionary
    input_data = {u'foo': 3, u'bar': u'baz'}
    expected_result = {u'foo': 3, u'bar': u'baz'}
    assert ansible_native_concat(input_data) == expected_result

    # Test native concat with a dictionary with a literal
    input_data = {u'foo': 3, u'bar': '"baz"'}
    expected_result = {u'foo': 3, u'bar': u'baz'}
    assert ansible_native_concat(input_data)

# Generated at 2022-06-21 07:45:44.808242
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([None, None]) == None
    assert ansible_native_concat([True, None]) == True
    assert ansible_native_concat([False, None]) == False
    assert ansible_native_concat([42, None]) == 42
    assert ansible_native_concat([42.42, None]) == 42.42
    assert ansible_native_concat([u"foo", None]) == u"foo"
    assert ansible_native_concat([u"", None]) == u""
    assert ansible_native_concat([[1, 2, 3], None]) == [1, 2, 3]
    assert ansible_native_concat([{u"a": 1, u"b": 2}, None]) == {u"a": 1, u"b": 2}

   

# Generated at 2022-06-21 07:45:51.623748
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test nodes with concrete data
    assert ansible_native_concat([]) is None

    assert ansible_native_concat([
        text_type('foo')
    ]) == 'foo'

    assert ansible_native_concat([
        text_type('foo'),
        text_type('bar'),
    ]) == 'foobar'

    assert ansible_native_concat([
        text_type('foo'),
        text_type('bar'),
        text_type('baz')
    ]) == 'foobarbaz'

    assert ansible_native_concat([
        text_type('foo'),
        text_type('1'),
        text_type('baz')
    ]) == 'foo1baz'


# Generated at 2022-06-21 07:46:05.995361
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('String') == 'String'
    assert ansible_native_concat(['String']) == 'String'
    assert ansible_native_concat(['String', 'String']) == 'StringString'
    assert ansible_native_concat(['String', True]) == 'StringTrue'
    assert ansible_native_concat(['String', False]) == 'StringFalse'
    assert ansible_native_concat(['String', 1]) == 'String1'
    assert ansible_native_concat(['String', 0]) == 'String0'
    assert ansible_native_concat([1, 2]) == 3
    assert ansible_native_concat(['', '']) == ''
    assert ansible_native_concat([1, 'String']) == '1String'


# Generated at 2022-06-21 07:46:17.176842
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == u'123'
    assert ansible_native_concat([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == u'12345678910'
    assert ansible_native_concat([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20]) == u'1234567891011121314151617181920'

# Generated at 2022-06-21 07:46:25.153930
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat(['1', '2', '3']) == 123
    assert ansible_native_concat([1, 2, '3']) == '123'
    assert ansible_native_concat(['1', 2, '3']) == '123'
    assert ansible_native_concat(['\t', '\t', '3']) == '\t\t3'

# Generated at 2022-06-21 07:46:31.684452
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    '''
    >>> test_ansible_native_concat() # doctest: +ELLIPSIS
    Testing ansible_native_concat with various data types ...
    PASSED SUCCESSFULLY.
    '''

    from ansible.module_utils.six import PY3
    from jinja2.runtime import Context

    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject, AnsibleUnicode

    # pylint: disable=unused-variable
    class TestYAMLObject(AnsibleBaseYAMLObject):
        yaml_tag = u'!testobj'

    # pylint: disable=function-redefined
    def test_yaml_constructor(loader, node):
        return to_text(node.value)

    # pylint: disable

# Generated at 2022-06-21 07:46:42.186864
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    from ansible.parsing.yaml.objects import AnsibleUnicode

    assert ansible_native_concat([]) is None

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1.5]) == 1.5
    assert ansible_native_concat([u'\u2665']) == u'\u2665'
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([False]) is False
    assert ansible_native_concat([None]) is None

    assert ansible_native_concat([u'1']) == 1
    assert ansible_native_concat([u'1.5']) == 1.5

# Generated at 2022-06-21 07:46:55.179238
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode as AVU
    from ansible.module_utils.six import string_types
    from ansible.module_utils.common.text.converters import container_to_text
    from ansible.module_utils.common.collections import is_sequence
    from jinja2.runtime import StrictUndefined

    # test with a list containing multiple nodes
    argument = ["{{", "var", "}}", ".", "{{", "var2", "}}"]
    expected = "debug.var.debug.var2"
    var = "debug"
    var2 = "var2"
    assert ansible_native_concat(argument) == expected

    # test with a dict containing multiple nodes

# Generated at 2022-06-21 07:47:07.176007
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['Hello World!']) == 'Hello World!'
    assert ansible_native_concat([1, 2]) == 3
    assert ansible_native_concat(['Hello', 'World!']) == 'HelloWorld!'
    assert ansible_native_concat([1, 'Hello', 'World!']) == '1HelloWorld!'
    assert ansible_native_concat([[1, 2], [3, 4]]) == [1, 2, 3, 4]
    assert ansible_native_concat([[1, 2], [3, 4], [5, 6]]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-21 07:47:18.826226
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['{"var":1}']) == {"var": 1}
    assert ansible_native_concat(['true']) is True
    assert ansible_native_concat(['false']) is False
    assert ansible_native_concat(['null']) is None
    assert ansible_native_concat(['[1, 2]']) == [1, 2]
    assert ansible_native_concat(['[1, 2', '3]']) == [1, 23]
    assert ansible_native_concat(['[1, 2', [3]]) == [1, 2, 3]

# Generated at 2022-06-21 07:47:28.036456
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test ansible_native_concat function.
    """

    # simple concat
    assert u"Hello world" == ansible_native_concat([
        NativeJinjaText("Hello"),
        NativeJinjaText(" world"),
    ])

    # single node
    assert u"Hello world" == ansible_native_concat([
        NativeJinjaText("Hello world"),
    ])

    # single native node
    assert 123 == ansible_native_concat([
        123,
    ])

    # single native node - list
    assert [1, 2, 3] == ansible_native_concat([
        [1, 2, 3],
    ])

    # single native node - dict

# Generated at 2022-06-21 07:47:38.363440
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Test that dict/list are not converted to string
    assert isinstance(ansible_native_concat([{'a': 1}]), dict)
    assert isinstance(ansible_native_concat([[1, 2]]), list)

    # If a string can be parsed by literal_eval, return the result of the parse
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1.1]) == 1.1
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['1.1']) == 1.1
    assert ansible_native_concat(['hello']) == 'hello'
    assert ansible_native_concat(['1', '2']) == 12

# Generated at 2022-06-21 07:48:06.419563
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    fn = ansible_native_concat

    # strings
    assert fn(['a']) == 'a'
    assert fn(['a', 'b']) == 'ab'
    assert fn(['a', 'b', 'c']) == 'abc'

    # ints
    assert fn([1]) == 1
    assert fn([1, 2]) == 1
    assert fn([1, 2, 3]) == 1

    # floats
    assert fn([1.0]) == 1.0
    assert fn([1.0, 2.0]) == 1.0
    assert fn([1.0, 2.0, 3.0]) == 1.0

    # None
    assert fn([None]) is None
    assert fn([None, None]) is None
    assert fn([None, None, None]) is None

    # Undefined
   

# Generated at 2022-06-21 07:48:14.629107
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # this tests a jinja2 version 2.10+ fix where the generator is not expanded before use.
    # this is a regression test for https://github.com/ansible/ansible/issues/57405 and
    # https://github.com/pallets/jinja/issues/1201
    gen = (i for i in [1,2,3])
    assert ansible_native_concat(gen) == 123

    # this tests a fix where native_concat would be called with no arguments, which
    # can happen if an empty variable is included in an expression, eg:
    #   {{ [1,2,3] if 'foo' in vars and vars['foo'] }}
    assert ansible_native_concat([]) is None

    # these are regression tests for https://github.com/ansible/ansible/issues/

# Generated at 2022-06-21 07:48:24.423217
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    res = ansible_native_concat([1, 2, 3])
    expected = '123'
    assert res == expected, "{0} != {1}".format(res, expected)

    res = ansible_native_concat([text_type(i) for i in range(1, 4)])
    expected = '123'
    assert res == expected, "{0} != {1}".format(res, expected)

    res = ansible_native_concat(['[', '1, 2, 3', ']', '# Comment'])
    expected = '[1, 2, 3]'
    assert res == expected, "{0} != {1}".format(res, expected)

    res = ansible_native_concat(['[', u'1, 2, 3', ']', '# Comment'])

# Generated at 2022-06-21 07:48:35.113470
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.six import integer_types
    import jinja2
    from ansible.parsing.yaml.constructor import AnsibleConstructor


# Generated at 2022-06-21 07:48:46.142576
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # https://github.com/ansible/ansible/pull/70826#discussion_r452524858
    e = ValueError('malformed string')
    assert ansible_native_concat(['a', 'b', 'c', ' ']) == u'abc '

    # https://github.com/ansible/ansible/pull/70831#issuecomment-664190894
    assert (ansible_native_concat([['a'], ['b'], ['c'], [' ']]) ==
            u'abc ')

    # https://github.com/ansible/ansible/pull/70831#issuecomment-663746506
    assert (ansible_native_concat([['a', 'b'], ['c', 'd']]) ==
            ['ab', 'cd'])

    assert ansible

# Generated at 2022-06-21 07:48:54.686456
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:49:00.521245
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def assertEqual(a, b):
        if a != b:
            raise AssertionError("%r != %r" % (a, b))

    assertEqual(
        ansible_native_concat(
            (
                NativeJinjaText(container_to_text([u'foo'])),
                NativeJinjaText(container_to_text([u'bar']))
            )
        ),
        [u'foo', u'bar']
    )

# Generated at 2022-06-21 07:49:11.178407
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # pylint: disable=unused-variable
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 'bar', 42]) == 'foobar42'
    assert ansible_native_concat([u'föö', 'bar', 42]) == u'fööbar42'
    assert ansible_native_concat([42, 'bar']) == '42bar'
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat((ansible_native_concat([42]),)) == 42



# Generated at 2022-06-21 07:49:16.451383
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test ansible_native_concat by comparing the native and jinja2 results"""
    import jinja2
    env = jinja2.Environment(
        undefined=jinja2.StrictUndefined,
        finalize=ansible_native_concat,
        variable_start_string='{{',
        variable_end_string='}}'
    )

    result = env.from_string(
        '{{ foo }}{{ foo }}'
    ).render(foo='bar')

    assert result == 'barbar'

# Generated at 2022-06-21 07:49:28.370307
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['1']) == '1'
    assert ansible_native_concat([NativeJinjaText('1')]) == '1'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1.0]) == 1.0
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([False]) is False
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat(['a', 1, 'b']) == 'a1b'

# Generated at 2022-06-21 07:49:54.181645
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # list
    assert isinstance(ansible_native_concat([1, 2, 3]), (list, tuple))
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]

    # generator
    assert isinstance(ansible_native_concat((x for x in range(1, 4))), (list, tuple))
    assert ansible_native_concat((x for x in range(1, 4))) == [1, 2, 3]

    # string
    assert isinstance(ansible_native_concat([1, 2, 3]), text_type)
    assert ansible_native_concat([1, 2, 3]) == '123'

    # string in NativeJinjaText

# Generated at 2022-06-21 07:50:04.689827
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.module_utils.six import PY3, integer_types
    from ansible.module_utils.common.text.converters import to_bytes

    if not PY3:
        from ansible.module_utils.six.moves import xrange
        range = xrange

    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['0']) == 0
    assert ansible_native_concat(['1.1']) == 1.1

# Generated at 2022-06-21 07:50:15.332438
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # pylint: disable=bad-continuation
    data = """\
        {%- set list_var = [1, 2, 3, 4] -%}
        {%- set dict_var = {'k1': 'v1', 'k2': 'v2', 'k3': 'v3'} -%}
        {%- set str_var = 'foobar' -%}
        {%- set numeric_var = 42 -%}
        {%- set undefined_var = foo -%}
        {%- set concat_template = str_var + ' and ' + numeric_var -%}
        {% for item in list_var %}
        - val1: {{ item }}
          val2: {{ concat_template }}
          val3: {{ dict_var | string }}
        {% endfor %}
        """



# Generated at 2022-06-21 07:50:25.631271
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # tests for undefined values
    assert ansible_native_concat([StrictUndefined()]) == StrictUndefined()
    assert ansible_native_concat([]) == None

    # tests for multiple nodes
    assert ansible_native_concat(['abc', 123]) == 'abc123'
    assert ansible_native_concat(['abc', 123, True]) == 'abc123True'
    assert ansible_native_concat(['abc', 123, True, StrictUndefined()]) == StrictUndefined()
    assert ansible_native_concat(['abc', 123, False, StrictUndefined()]) == 'abc123False'

    # tests for single node where the value is not a string
    assert ansible_native_concat([123]) == 123
    assert ansible_native_concat([True]) == True

# Generated at 2022-06-21 07:50:33.868232
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    data = 'test\n'
    assert(ansible_native_concat([data]) == data)
    data = 'test'
    assert(ansible_native_concat([data]) == data)
    data = 'test'
    assert(ansible_native_concat([data, data]) == 'testtest')
    data = 1
    assert(ansible_native_concat([data]) == data)
    data = ['test', ' test']
    assert(ansible_native_concat([data]) == data)
    data = ['test', 'test']
    assert(ansible_native_concat([data]) == 'testtest')
    data = ['test', 1]
    assert(ansible_native_concat([data]) == 'test1')
    data = ('test', 'test')