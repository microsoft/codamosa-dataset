

# Generated at 2022-06-21 07:40:32.463939
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2]) == u'12'
    assert ansible_native_concat([None, [], {}]) == ''
    assert ansible_native_concat([[], {}]) == u'[]{}'
    assert ansible_native_concat([[], {}]) == []
    assert ansible_native_concat(['foo', 'b', [1, 2], {'c': 'd'}]) == u'foob[1, 2]{\'c\': \'d\'}'
    assert ansible_native_concat(['foo', 'b', [1, 2], {'c': 'd'}]) == {'c': 'd'}
    assert ansible_native_concat(['foo', 'b', [1, 2], {'c': 'd'}])

# Generated at 2022-06-21 07:40:41.878078
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    lines = []
    assert ansible_native_concat(lines) is None

    lines = [u"a", u"b", u"c", u"d"]
    assert ansible_native_concat(lines) == u'abcd'

    lines = [u"a", u"b", u"c\n", u"d"]
    assert ansible_native_concat(lines) == u"abcd"

    lines = [u"a", u"b", u"c\n", u"d\n", u"e"]
    assert ansible_native_concat(lines) == u"abcde"

    lines = [u"a", u"b", u"c\n", u"d\n", u"e\n", u"f"]
    assert ansible_native_concat(lines) == u

# Generated at 2022-06-21 07:40:52.321940
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(('A', ' ', 'B')) == 'A B'
    assert container_to_text(ansible_native_concat(('A', '\n', 'B'))) == 'A\nB'
    assert ansible_native_concat(('A ', 'B', ' C')) == 'A B C'
    assert ansible_native_concat(('A\n', 'B\n', 'C')) == 'A\nB\nC'
    assert ansible_native_concat(('1', '2')) == 12
    assert ansible_native_concat(('12.34', )) == 12.34
    assert ansible_native_concat(('true', )) is True
    assert ansible_native_concat(('false', )) is False

# Generated at 2022-06-21 07:41:03.783267
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([0]) == 0
    assert ansible_native_concat([0, 1]) is None
    assert ansible_native_concat([1, 2, 3]) is None
    assert ansible_native_concat(["a"]) == "a"
    assert ansible_native_concat(["a", "b"]) == "ab"
    assert ansible_native_concat([1, "2", 3]) == "123"
    assert ansible_native_concat([['foo', 'bar']]) == ['foo', 'bar']
    assert ansible_native_concat([[1, 2], 3]) == [1, 2, 3]
    assert ansible_native_concat(["1", "2", 3]) == "123"

# Generated at 2022-06-21 07:41:14.091971
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert None == ansible_native_concat([])
    assert None == ansible_native_concat(None)

    assert u'foo' == ansible_native_concat([u'foo'])
    assert 'foo' == ansible_native_concat(['foo'])
    assert 123 == ansible_native_concat([123])

    assert "foo bar baz" == ansible_native_concat([u'foo', u'bar', u'baz'])
    assert "1 2 3" == ansible_native_concat([1, 2, 3])
    assert "foo bar" == ansible_native_concat([u'foo', u'bar'])
    assert '1 2' == ansible_native_concat([1, 2])


# Generated at 2022-06-21 07:41:25.080856
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat([1, 2, 3, 'a']) == '123a'
    assert ansible_native_concat(['1', 2, 3]) == '123'
    assert ansible_native_concat(['1 ', 2, 3]) == '1 123'
    assert ansible_native_concat([1, '2', '3']) == '123'
    assert ansible_native_concat(['a', True, 1.0]) == 'aTrue1.0'
    assert ansible_native_concat(['a', True, 1.0, []]) == 'aTrue1.0[]'


# Generated at 2022-06-21 07:41:31.812720
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    result = ansible_native_concat([42])
    assert result == 42

    result = ansible_native_concat([42, 'foo'])
    assert result == '42foo'

    result = ansible_native_concat([42, 'foo', 'bar'])
    assert result == '42foobar'

    result = ansible_native_concat(['foo', 42])
    assert result == 'foo42'

    result = ansible_native_concat(['foo', 42, 'bar'])
    assert result == 'foo42bar'

    result = ansible_native_concat(['foo', 42, False])
    assert result == 'foo42False'

    result = ansible_native_concat(['foo', 42, False, True])


# Generated at 2022-06-21 07:41:43.408815
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    jinja2 = _fail_on_undefined

    assert ansible_native_concat(jinja2(container_to_text([1, 2, 3]))) == [1, 2, 3]
    assert ansible_native_concat(jinja2(container_to_text(['a', 'b', 'c']))) == ['a', 'b', 'c']
    assert ansible_native_concat(jinja2(container_to_text([{'a': 1}, {'b': 2}, {'c': 3}]))) == [{'a': 1}, {'b': 2}, {'c': 3}]

    assert ansible_native_concat(jinja2(1)) == 1
    assert ansible_native_concat(jinja2(1.5)) == 1.5
    assert ansible

# Generated at 2022-06-21 07:41:54.930976
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Unit test for ansible.template._fail_on_undefined."""

    assert ansible_native_concat([]) is None

    assert container_to_text(ansible_native_concat([1])) == "1"

    assert container_to_text(ansible_native_concat(["1"])) == "1"

    assert container_to_text(ansible_native_concat([1, 2])) == "12"

    assert container_to_text(ansible_native_concat(["1", 2])) == "12"

    value = ansible_native_concat([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13])
    assert container_to_text(value) == "12345678910111213"

    assert container_to

# Generated at 2022-06-21 07:42:03.934077
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([{'a': 1}]) == {'a': 1}
    assert ansible_native_concat([['a']]) == ['a']
    assert ansible_native_concat([[1]]) == [1]
    assert ansible_native_concat([[{'a': 1}]]) == [{'a': 1}]
    assert ansible_native_concat(['2']) == 2
    assert ansible_native_concat([['a'], 'b']) == 'ab'

# Generated at 2022-06-21 07:42:20.777185
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import types
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.module_utils.common.text.converters import container_to_text


# Generated at 2022-06-21 07:42:34.168241
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['Value1']) == 'Value1'
    assert ansible_native_concat([['Value2']]) == ['Value2']
    assert ansible_native_concat(['Value3_1', 'Value3_2']) == 'Value3_1Value3_2'
    assert ansible_native_concat([True, 'Value4_2']) == 'TrueValue4_2'
    assert ansible_native_concat([['Value5_1'], 'Value5_2']) == ['Value5_1Value5_2']
    assert ansible_native_concat([['Value6_1'], [['Value6_2']]]) == ['Value6_1', ['Value6_2']]



# Generated at 2022-06-21 07:42:43.863246
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils import basic

    # empty input
    assert ansible_native_concat(iter([])) is None

    # a single int
    assert ansible_native_concat([42]) == 42

    # a single string
    assert ansible_native_concat(['42']) == '42'
    assert ansible_native_concat(['42abc']) == '42abc'
    assert ansible_native_concat(['an error occured']) == 'an error occured'
    assert ansible_native_concat(['{}']) == '{}'
    assert ansible_native_concat(['{{}}']) == '{{}}'

    # a single float
    assert ansible_native_concat([42.0]) == 42.0
    assert ansible_native_

# Generated at 2022-06-21 07:42:54.935220
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def test(nodes, expect):
        if isinstance(nodes, string_types):
            nodes = container_to_text(nodes, keep_ors=True, split_lines=True)
        if isinstance(nodes, text_type):
            nodes = (nodes, )
        result = ansible_native_concat(nodes)
        assert result == expect
    test("foo", b"foo")
    test("foo", "foo")
    test("'foo'", "'foo'")
    test("foo", u"foo")
    test("'foo'", u"'foo'")
    test("foo", b"'foo'")
    test("foo", u"'foo'")
    test("'foo'", b"'foo'")
    test("'foo'", u"'foo'")

# Generated at 2022-06-21 07:43:05.760755
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.utils.vars import combine_vars
    from ansible.module_utils.common.text.converters import to_text

    def assert_native_equals(nodes, expected):
        output = ansible_native_concat(nodes)
        assert output == expected, "%r != %r" % (output, expected)

    assert_native_equals(map(to_text, [1, 2, 3]), '123')
    assert_native_equals(map(to_text, [1, ' ', 2, ' ', 3]), '1 2 3')
    assert_native_equals(map(to_text, [1, ' ', [2, 3]]), '[1, 2, 3]')

# Generated at 2022-06-21 07:43:17.984436
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([0, 1, 2]) == '012'
    assert ansible_native_concat(['a', 'b', 'c', 3, 4, 5]) == 'abc345'
    assert ansible_native_concat(['a', 'b', 'c', u'\u05d0', u'\u05d1', u'\u05d2']) == 'abc\u05d0\u05d1\u05d2'

    assert ansible_native_concat(['a', 'b', 'c', u'\u05d0', u'\u05d1', u'\u05d2', '3', '4', '5']) == 'abc\u05d0\u05d1\u05d2345'

    assert ansible_native_concat

# Generated at 2022-06-21 07:43:27.336480
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat([1, 'a']) == '1a'
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat(['1', 2, 3]) == '123'
    assert ansible_native_concat([1, '2', 3]) == '123'

# Generated at 2022-06-21 07:43:37.020702
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert u'foo' == ansible_native_concat([u'foo'])
    assert u'bar' == ansible_native_concat([u'bar'])
    assert 123 == ansible_native_concat([123])
    assert '123' == ansible_native_concat(['123'])
    assert u'foobar' == ansible_native_concat([u'foo', u'bar'])
    assert u'foobar' == ansible_native_concat([u'foo', 'bar'])
    assert u'foobar' == ansible_native_concat(['foo', u'bar'])
    assert 'foobar' == ansible_native_concat(['foo', 'bar'])

# Generated at 2022-06-21 07:43:42.476051
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', '', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', '', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 'bar ', 'baz']) == 'foo bar baz'
    assert ansible_native_concat(['foo', 'bar ', 'baz']) == 'foo bar baz'

# Generated at 2022-06-21 07:43:50.825908
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['Hello', 'World']) == 'HelloWorld'
    assert ansible_native_concat([1, 2]) == 1
    assert ansible_native_concat([1, 2]) is not '12'
    assert ansible_native_concat([None, None]) is None
    assert ansible_native_concat(['1', '2']) == [1, 2]
    assert ansible_native_concat(['(1, ', '2)']) == (1, 2)
    assert ansible_native_concat(['(1, ', '2)']) is not '(1, 2)'
    assert ansible_native_concat(['"foo"', '"bar"']) == 'foobar'
    assert ansible_

# Generated at 2022-06-21 07:44:04.644997
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat((x for x in [1, 'foo', 2, 'bar'])) == '1foo2bar'
    assert ansible_native_concat((x for x in [1, 'foo', 2, 'bar', True])) == [1, 'foo', 2, 'bar', True]
    assert ansible_native_concat([1, 'foo', 2, 'bar', True]) == [1, 'foo', 2, 'bar', True]
    assert ansible_native_concat((x for x in [1, 'foo', 2, 'bar'])) == [1, 'foo', 2, 'bar']
    assert ansible_native_concat((x for x in [1, 'foo', 2, 'bar', 'True'])) == True

# Generated at 2022-06-21 07:44:16.036066
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat([1, 'b']) == '1b'
    assert ansible_native_concat(['a', 2]) == 'a2'
    assert ansible_native_concat([u'\u2600']) == u'\u2600'
    assert ansible_native_concat([1, 2, 'a']) == '12a'

# Generated at 2022-06-21 07:44:26.611838
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE

    # test all different types of python literals

# Generated at 2022-06-21 07:44:38.578820
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 1]) == 'foo1'
    assert ansible_native_concat(['foo', 1, 'bar']) == 'foo1bar'
    assert ansible_native_concat(['foo', ['bar']]) == 'foobar'
    assert ansible_native_concat(['foo', {'bar': 'baz'}]) == 'foobaz'
    assert ansible_native_concat([u'\x00']) == u'\x00'

# Generated at 2022-06-21 07:44:50.513363
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Python 2 and Python 3 ast.literal_eval are slightly different
    # Make sure that the behavior is consistent across versions
    if hasattr(ast.literal_eval, "__module__") and ast.literal_eval.__module__ == "ast":
        ast_literal_eval = ast.literal_eval
    else:
        ast_literal_eval = eval

    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 42]) == 'foo42'
    assert ansible_native_concat([42, 'bar']) == '42bar'
    assert ansible_native_concat([42, 42]) == '4242'
    assert ansible_native_concat(['true', 'false']) == 'truefalse'

# Generated at 2022-06-21 07:44:59.431259
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def _test(nodes, expect):
        out = ansible_native_concat(nodes)
        if isinstance(expect, text_type):
            assert isinstance(out, text_type)
        else:
            assert not isinstance(out, text_type)
        assert container_to_text(out) == container_to_text(expect)

    _test([], None)
    _test([1], 1)
    _test([text_type('foo')], text_type('foo'))
    _test([1, text_type('foo')], text_type('1foo'))
    _test([False, text_type('foo')], text_type('Falsefoo'))
    _test([True, text_type('foo')], text_type('Truefoo'))


# Generated at 2022-06-21 07:45:09.938878
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test ellipsis expression
    assert ansible_native_concat([1, 2, ...]) == '1, 2, ...'
    # Test binary operation
    assert ansible_native_concat([1, '+', 2]) == 3
    # Test chained comparisons
    assert ansible_native_concat([' ', 1, '<', 2, '>=', 1]) == True
    # Test sequence
    assert ansible_native_concat([' ', [1, 2], ' and ', [3, 4]]) == '[1, 2] and [3, 4]'
    # Test string concatenation
    assert ansible_native_concat([1, '+', 'foo']) == '1+foo'
    # Test correct evaluation of expressions that could be interpreted as float

# Generated at 2022-06-21 07:45:20.746434
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat([42, 43]) == u'4243'

    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([True, False]) == u'TrueFalse'

    assert ansible_native_concat([(1, 2, 3)]) == (1, 2, 3)
    assert ansible_native_concat([(1, 2, 3), [4, 5, 6]]) == u'(1, 2, 3)[4, 5, 6]'


# Generated at 2022-06-21 07:45:33.053886
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text import string_wrapper


# Generated at 2022-06-21 07:45:43.773678
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2]) == 3
    assert ansible_native_concat([1, 2, 3]) == 6
    assert ansible_native_concat([1, 2, 3, 4]) == 10
    assert ansible_native_concat([1, 2, 3, 4, 5]) == 15
    assert ansible_native_concat([1, 2, 3, 4, 5, 6]) == 21
    assert ansible_native_concat([10, 20, 30, 40, 50, 60]) == 210
    assert ansible_native_concat([[], [], []]) == []
    assert ansible_native_concat([[1]]) == [1]
    assert ansible_native_concat([[1], [2]]) == [1, 2]
    assert ansible_native

# Generated at 2022-06-21 07:46:00.104264
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # TODO: add more test cases
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([1, 2]) == 3
    assert ansible_native_concat(['0xFF', 0x0f]) == 0xff0f
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([['foo'], ['bar']]) == ['foo', 'bar']
    assert ansible_native_concat([['foo'], 'bar']) == ['foo', 'bar']
    assert ansible_native_concat(['foo', ['bar']]) == 'foobar'

# Generated at 2022-06-21 07:46:06.401405
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    '''
    Sanity checking of the test_ansible_native_concat.
    This function merely tests that concatentation in Jinja produces the
    same results as in Python.
    '''

    one = {'foo': 1, 'bar': [1, 2, 3]}
    two = {'foo': 2, 'bar': 'baz'}
    three = {'foo': 3, 'bar': 'qux'}

    # Test concatenation of a list of strings
    assert(ansible_native_concat([str(one), str(two), str(three)]) ==
           str(one) + str(two) + str(three))

    # Test concatenation of a list of unicode strings

# Generated at 2022-06-21 07:46:17.524308
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'a', u'b']) == u'ab'
    assert ansible_native_concat(u'x') == u'x'
    assert ansible_native_concat([1, u'b']) == 1
    assert ansible_native_concat((u'a', u'b')) == u'ab'
    assert ansible_native_concat([1, u'b', u'c']) == u'1bc'
    assert ansible_native_concat([[u'a', u'b'], [u'c']]) == [u'ab', u'c']
    assert ansible_native_concat([[u'a', u'b'], [u'c'], u'd']) == u'abcd'
    assert ansible_native

# Generated at 2022-06-21 07:46:29.455209
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = [1, '+', ' ', 2]
    assert ansible_native_concat(nodes) == 3

    nodes = (1, '+', ' ', 2)
    assert ansible_native_concat(nodes) == 3

    nodes = iter([1, '+', ' ', 2])
    assert ansible_native_concat(nodes) == 3

    nodes = ['a', '+', 1]
    assert ansible_native_concat(nodes) == 'a1'

    nodes = ['a', '+', 1, '+', [2]]
    assert ansible_native_concat(nodes) == ['a', 1, 2]

    nodes = ['a', '+', 1, '+', [2], '+', {'b': 3}]
    assert ansible_native_concat

# Generated at 2022-06-21 07:46:36.729161
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Additional tests for the :func:`ansible_native_concat` function.
    """

    def _check(items, expect):
        """Helper function to check the result.
        """
        result = ansible_native_concat(items)
        assert expect == result

    # Single empty string
    _check([''], '')
    # Single non-empty string
    _check(['foo'], 'foo')
    # Concatenated empty strings
    _check(['', ''], '')
    _check(['', '', ''], '')
    # Concatenated non-empty strings
    _check(['foo', 'bar'], 'foobar')
    _check(['foo', 'bar', 'baz'], 'foobarbaz')
    # Concatenated empty and non-empty strings
    _

# Generated at 2022-06-21 07:46:47.222254
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import pytest
    from textwrap import dedent
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    def _test(data, expected):
        concatenated = ansible_native_concat(data())
        assert concatenated == expected, \
            "Expected %r, got %r" % (expected, concatenated)

        if isinstance(data(), list):
            # If it's a list, test it as a generator as well
            concatenated = ansible_native_concat((v for v in data()))
            assert concatenated == expected, \
                "Expected %r, got %r" % (expected, concatenated)

    # Test invalid data
    with pytest.raises(ValueError):
        ansible_native_concat(None)

   

# Generated at 2022-06-21 07:46:57.034968
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['abc']) == 'abc'
    # empty string handled by literal_eval
    assert ansible_native_concat(['']) == ''
    assert ansible_native_concat([[]]) == []
    assert ansible_native_concat([{}]) == {}
    assert ansible_native_concat([0]) == 0
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([-1]) == -1
    assert ansible_native_concat(['abc', 'def']) == 'abcdef'
    assert ansible_native_concat(['abc', 'def', 'ghi']) == 'abcdefghi'

# Generated at 2022-06-21 07:47:09.255637
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([1, 2]) == 3
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([1, 'foo']) == '1foo'
    assert ansible_native_concat([1, '2']) == 3
    assert ansible_native_concat(['1', 2]) == '12'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat(map(lambda x: x, ['1', '2'])) == '12'
    assert ansible_native_concat(['[1, 2]']) == [1, 2]

# Generated at 2022-06-21 07:47:21.646540
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([None]) == None
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([b'foo']) == 'foo'
    assert ansible_native_concat([u'foo']) == 'foo'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1.0]) == 1.0
    assert ansible_native_concat(['foo', 'bar']) == u'foobar'
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-21 07:47:28.236156
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == u'12'
    assert ansible_native_concat(['1', True, 2, None, '-3']) == 1
    assert ansible_native_concat(['a']) == u'a'
    assert ansible_native_concat([1, 2, 3]) == u'123'



# Generated at 2022-06-21 07:47:46.488770
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test literal
    assert ansible_native_concat(['1']) == 1

    # Test concat & literal
    assert ansible_native_concat(['1', '2']) == 12

    # Test container
    assert ansible_native_concat([['1', '2']]) == [1, 2]

    # Test concat container & literal
    assert ansible_native_concat(['[', '1', ',', ' ', '2', ']']) == [1, 2]

    # Test concat container & literal & literal
    assert ansible_native_concat(['[', '1', ',', '2', ']', '3']) == [1, 2, 3]

    # Test string
    assert ansible_native_concat(['12']) == '12'

    # Test stringify

# Generated at 2022-06-21 07:47:55.156089
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) is 1
    assert ansible_native_concat([2]) is 2

    assert ansible_native_concat([1, 2, 3]) == "123"
    assert ansible_native_concat([1, 2, 3, _fail_on_undefined(StrictUndefined())]) == "123"
    assert ansible_native_concat([1, 2, 3, _fail_on_undefined(StrictUndefined())]) == "123"

    # We do not support StrictUndefined in literal_eval
    assert ansible_native_concat([1, 2, 3, _fail_on_undefined(StrictUndefined())]) == "123"

    # The following should work in Python 3.10+ but it

# Generated at 2022-06-21 07:47:57.413919
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from . import TestJinjaFilter

    TestJinjaFilter.test(ansible_native_concat)



# Generated at 2022-06-21 07:48:09.563564
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([NativeJinjaText('foo')]) == 'foo'
    assert ansible_native_concat([NativeJinjaText('foo'), NativeJinjaText('bar')]) == 'foobar'
    assert ansible_native_concat([NativeJinjaText('foo'), NativeJinjaText('bar')]) == 'foobar'
    assert ansible_native_concat([NativeJinjaText('foo'), NativeJinjaText('bar'), NativeJinjaText('baz')]) == 'foobarbaz'
    assert ansible_native_concat([NativeJinjaText('foo'), NativeJinjaText('bar'), NativeJinjaText('baz')]) == 'foobarbaz'
    assert ansible_native_

# Generated at 2022-06-21 07:48:21.506406
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.six.moves import StringIO

    from jinja2 import Template, Environment, meta

    ENV = Environment(
        # https://github.com/pallets/jinja/pull/823
        autoescape=False,

        # https://github.com/pallets/jinja/blob/master/src/jinja2/nativetypes.py
        finalize=ansible_native_concat,
    )


# Generated at 2022-06-21 07:48:31.993970
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    assert ansible_native_concat([]) is None

    assert ansible_native_concat(['1234']) == '1234'

    assert ansible_native_concat([1]) == 1

    assert ansible_native_concat([None]) is None

    assert ansible_native_concat(['1', '2', '3', '4']) == 1234

    assert ansible_native_concat([1, 'foo', 'bar']) == '1foobar'

    assert ansible_native_concat([1, '', '2', '', '3']) is None

    assert ansible_native_concat([1, None]) is None


# Generated at 2022-06-21 07:48:42.951843
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    '''Unit test for ansible_native_concat'''
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat(['1', '2', '3']) == '123'
    assert ansible_native_concat([True, False, True]) == 'TrueFalseTrue'
    assert ansible_native_concat(['true', 'false', 'true']) == 'truefalsetrue'
    assert ansible_native_concat(['1', True]) == '1True'
    assert ansible_native_concat(['1', b'2']) == '12'
    assert ansible_native_concat(['1', b'\xc3\xa9']) == to_text

# Generated at 2022-06-21 07:48:45.719331
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # TODO: write unit tests for ansible_native_concat
    # See https://github.com/pallets/jinja/pull/1202
    pass



# Generated at 2022-06-21 07:48:54.413734
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2.runtime import Context, StrictUndefined

    undefined = StrictUndefined('ansible_native_concat')

# Generated at 2022-06-21 07:49:05.555281
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1]) == 1

    assert ansible_native_concat([1, 2]) == "12"

    assert ansible_native_concat(["foo", "bar"]) == "foobar"

    assert ansible_native_concat([1, 2, 3]) == "123"

    assert ansible_native_concat([1, "bar", 3]) == "1bar3"

    assert ansible_native_concat([1, None, 3]) == "13"

    assert ansible_native_concat([None, 2, None]) is None

    assert ansible_native_concat([None, None, None]) is None

    assert ansible_native_concat([None, None, "foo"]) == "foo"


# Generated at 2022-06-21 07:49:33.443801
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat([1, 2, 3]) == "123"
    assert ansible_native_concat([1, 2, 3, 'd']) == "123d"
    assert ansible_native_concat([1, 2, 3, 'd', 2, 3]) == "123d23"
    assert ansible_native_concat([7 + 3j, 2, 3]) == "(7+3j)23"
    assert ansible_native_concat([7 + 3j, 'a', 2, 3]) == "(7+3j)a23"

# Generated at 2022-06-21 07:49:44.766573
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 1]) == 'a1'
    assert ansible_native_concat(['a', 1, True]) == 'a1True'
    assert ansible_native_concat(['a', 1, False]) == 'a1False'
    assert ansible_native_concat([False, 1]) == 'False1'
    assert ansible_native_concat(['a', 1, 'b', 2]) == 'a1b2'
    assert ansible_native_concat(['a', 1, 'b', [1, 2, 3]]) == 'a1b[1, 2, 3]'

# Generated at 2022-06-21 07:49:53.700141
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(['a', 2]) == 'a2'
    assert ansible_native_concat([1, 'a']) == '1a'
    assert ansible_native_concat([-1]) == -1
    assert ansible_native_concat(['[1, 2]']) == [1, 2]



# Generated at 2022-06-21 07:50:04.261510
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    assert ansible_native_concat([]) is None
    assert ansible_native_concat(["string"]) == "string"
    assert ansible_native_concat(["string", "string"]) == "stringstring"
    assert ansible_native_concat(["0", "string", "string"]) == "0stringstring"
    assert ansible_native_concat([0, "string", "string"]) == 0
    assert ansible_native_concat([True, "string", "string"]) is True
    assert ansible_native_concat([[], "string", "string"]) == []

# Generated at 2022-06-21 07:50:15.049910
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([container_to_text(1), container_to_text(2)]) == 1
    assert ansible_native_concat([container_to_text(1), container_to_text(2), container_to_text(3), container_to_text(4),
                                  container_to_text(5)]) == '12345'
    assert ansible_native_concat([container_to_text('a'), container_to_text('b'), container_to_text('c'),
                                  container_to_text('d'), container_to_text('e')]) == 'abcde'


# Generated at 2022-06-21 07:50:25.139136
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def _test(expected, nodes):
        value = ansible_native_concat(nodes)
        assert value == expected, "{0} != {1}".format(
            to_text(value), to_text(expected))

    # Test various single value types:

    _test(None, [])
    _test(None, [None])
    _test('', [''])
    _test('', [None, ''])
    _test(0, [0])
    _test(10, [10])
    _test(True, [True])
    _test(False, [False])
    _test([], [[]])
    _test([], [[], []])
    _test(('a', 'b'), [('a', 'b')])
    _test({}, [{}])