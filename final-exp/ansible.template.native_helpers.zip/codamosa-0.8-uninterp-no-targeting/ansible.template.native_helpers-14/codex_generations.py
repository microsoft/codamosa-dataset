

# Generated at 2022-06-21 07:40:39.866267
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_text
    text_type = type(to_text(''))


# Generated at 2022-06-21 07:40:53.590674
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([2]) == 2
    assert ansible_native_concat(NativeJinjaText('1')) == '1'
    assert ansible_native_concat(NativeJinjaText(1)) == 1
    assert ansible_native_concat(['1', 2, 3]) == '123'
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([u'1', 2, 3]) == u'123'
    assert ansible_native_concat([u'1', 2, list(range(4))]) == u'123[0, 1, 2, 3]'

# Generated at 2022-06-21 07:40:59.593133
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    a = 42
    b = 'bar'
    c = (1, 42, 'bar', None)
    d = {'a': 42, 'b': 'bar', 'c': (1, 42, 'bar', None)}
    e = 100 + 200j
    f = True
    g = 'true'
    h = 'false'
    i = '42'

    assert ansible_native_concat((a, b)) == '42bar'
    assert ansible_native_concat((b, a)) == 'bar42'
    assert ansible_native_concat(('foo', b, a)) == 'foobar42'

    assert ansible_native_concat((a,)) == 42
    assert ansible_native_concat((b,)) == 'bar'

# Generated at 2022-06-21 07:41:12.298547
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(["foo"]) == "foo"
    assert ansible_native_concat(["foo", "bar"]) == "foobar"
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat(["foo", [1, 2, 3], "bar"]) == "foo[1, 2, 3]bar"
    assert ansible_native_concat([[1, 2, 3], "bar"]) == "[1, 2, 3]bar"
    assert ansible_native_concat([set([1, 2, 3]), "bar"]) == "set([1, 2, 3])bar"

# Generated at 2022-06-21 07:41:23.621133
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    class Foo(object):
        def __str__(self):
            return 'bar'

        def __repr__(self):
            return 'Foo()'

    foo = Foo()

    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', 1, 'b', 2]) == 'a1b2'
    assert ansible_native_concat(['a', 'b', 1, 2]) == 'ab12'
    assert ansible_native_concat(['a', u'b']) == 'ab'
    assert ansible_native_concat([u'a', 'b']) == 'ab'

# Generated at 2022-06-21 07:41:33.484810
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2.nodes import Const, List, Dict, Tuple

    # tests for literal_eval
    assert ansible_native_concat(('1',)) == 1
    assert ansible_native_concat(('1', '0')) == 10
    assert ansible_native_concat(('a',)) == 'a'
    assert ansible_native_concat(('abc',)) == 'abc'
    assert ansible_native_concat(('a', 'b')) == 'ab'
    assert ansible_native_concat(('a', 'b', 'c')) == 'abc'
    assert ansible_native_concat(('a', 'b', 'c', 'd')) == 'abcd'

# Generated at 2022-06-21 07:41:43.928661
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def make_var(value):
        class Var(object):
            def __str__(self):
                return value
        return Var()

    assert ansible_native_concat([]) == None
    assert ansible_native_concat([make_var("A")]) == "A"
    assert ansible_native_concat([make_var("1"), make_var("2")]) == "12"
    assert ansible_native_concat([make_var("1"), make_var("2")]) == "12"
    assert ansible_native_concat([make_var("1"), make_var("2")]) == "12"
    assert ansible_native_concat([make_var(":="), make_var("2")]) == ":=2"

# Generated at 2022-06-21 07:41:55.146981
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2
    from ansible.module_utils.common.text.converters import to_str

    template = jinja2.Template('{{ "1" + "2" }}')
    assert template.render() == '12'
    assert isinstance(template.render(), text_type)

    template = jinja2.Template('{{ 1 + 2 }}')
    assert template.render() == '3'
    assert isinstance(template.render(), text_type)

    template = jinja2.Template('{{ "1" + "2" | string }}')
    assert template.render() == '12'
    assert isinstance(template.render(), text_type)

    template = jinja2.Template('{{ "1" ~ "2" }}')
    assert template.render() == '1'


# Generated at 2022-06-21 07:42:04.813120
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def assert_ansible_native_concat(data):
        assert data == ansible_native_concat(data)

    assert_ansible_native_concat('a string')
    assert_ansible_native_concat("a Python string")
    assert_ansible_native_concat('"a quoted string"')
    assert_ansible_native_concat("'a quoted string'")
    assert_ansible_native_concat("a 'quoted' string")
    assert_ansible_native_concat("a \"quoted\" string")
    assert_ansible_native_concat("'a \"quoted\" string'")
    assert_ansible_native_concat("[[item1, item2]]")
    assert_ansible_native_concat("a unicode string")
    assert_ansible_

# Generated at 2022-06-21 07:42:10.228441
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def _test_ansible_native_concat(values, expected):
        if not isinstance(values, list):
            values = [values]
        out = ansible_native_concat(s for s in values)

        assert out == expected, \
            'Concatenated value %s does not match expected value %s.' % (container_to_text(out), container_to_text(expected))

    _test_ansible_native_concat({
        'nodes': [u'[', u'"a"', u',', u'"b"', u']'],
        'expected': ['a', 'b'],
    })
    _test_ansible_native_concat({
        'nodes': [u'"abc"'],
        'expected': 'abc'
    })
    _test_ansible_native_

# Generated at 2022-06-21 07:42:23.708846
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # literal_eval should be performed
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == 12

    # literal_eval cannot be performed
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([1, 'asb', 3]) == '1asb3'
    assert ansible_native_concat([1, 2, 3, 'asb']) == '123asb'
    assert ansible_native_concat([1, 2, 3, 'asb', 5, 6, 7]) == '123asb567'
    assert ansible_native_concat([1, 'asb', 3, 4.5]) == '1asb34.5'



# Generated at 2022-06-21 07:42:35.662838
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:42:44.114721
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 1, 'bar']) == 'foo1bar'
    assert ansible_native_concat(['foo', '1', 'bar']) == 'foo1bar'
    assert ansible_native_concat(['foo', 1, 2]) == 'foo12'
    assert ansible_native_concat(['foo', '1', 2]) == 'foo1bar'



# Generated at 2022-06-21 07:42:50.320621
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'bc']) == 'abc'
    assert ansible_native_concat([1, 2, 34]) == '1234'
    assert ansible_native_concat([1, 'a', 34]) == '1a34'
    assert ansible_native_concat([1, 'a', 34, 'b']) == '1a34b'
    assert ansible_native_concat(['a', 1]) == 'a1'
    assert ansible_native_concat(['a', 1, 'b']) == 'a1b'
    assert ansible_native_concat(['a', 1, 'b', 2, 3]) == 'a1b23'
    assert ansible_native

# Generated at 2022-06-21 07:43:03.245290
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2


# Generated at 2022-06-21 07:43:16.716074
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test ansible_native_concat"""
    def _generator(*value):
        for v in value:
            yield v


# Generated at 2022-06-21 07:43:26.872741
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([123, 123]) == 246
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 1]) == 'foo1'
    assert ansible_native_concat([1, 'bar']) == '1bar'
    assert ansible_native_concat(['foo', True]) == 'footrue'
    assert ansible_native_concat([True, 'bar']) == 'Truebar'
    assert ansible_native_concat([[1], [2]]) == [12]

# Generated at 2022-06-21 07:43:36.461026
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([False]) is False
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat([42.1]) == 42.1
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([b'foo']) == b'foo'
    assert ansible_native_concat(['Foo\nBar', 'baz']) == 'Foo\nBarbaz'
    assert ansible_native_concat(['[1,2,3]', 'foo']) == '[1,2,3]foo'

# Generated at 2022-06-21 07:43:48.917351
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def generate_nodes(values):
        for value in values:
            yield value

    assert ansible_native_concat(generate_nodes([1])) == 1
    assert ansible_native_concat(generate_nodes([1, 2, 3])) == u"123"
    assert ansible_native_concat(generate_nodes([1, 2, 3])) == u"123"
    assert ansible_native_concat(generate_nodes([1, 2, 3])) == u"123"
    assert ansible_native_concat(generate_nodes([1, 2, 3])) == u"123"
    assert ansible_native_concat(generate_nodes([1, 2, 3])) == u"123"

# Generated at 2022-06-21 07:44:01.235136
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible_collections.ansible.community.tests.unit.plugins.modules.utils import assert_replace

    import jinja2
    from jinja2 import DictLoader


# Generated at 2022-06-21 07:44:08.967518
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    out = ansible_native_concat([])
    assert out is None

    out = ansible_native_concat(['hello'])
    assert out == 'hello'

    out = ansible_native_concat([u'\u20ac'])
    assert out == u'\u20ac'

    out = ansible_native_concat([u'\u65e5'])
    assert out == u'\u65e5'

    out = ansible_native_concat([None])
    assert out is None

    out = ansible_native_concat([True])
    assert out is True

    out = ansible_native_concat([False])
    assert out is False

    out = ansible_native_concat([0])
    assert out == 0

    out = ansible_native_concat

# Generated at 2022-06-21 07:44:20.913981
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2
    environment = jinja2.Environment(trim_blocks=True, lstrip_blocks=True)
    environment.filters.update({
        'native_concat': ansible_native_concat
    })
    loader = jinja2.BaseLoader()

# Generated at 2022-06-21 07:44:28.654758
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(['true']) == True
    assert ansible_native_concat(['unknown']) == 'unknown'
    assert ansible_native_concat(['  unknown']) == '  unknown'
    assert ansible_native_concat(['true', 'true']) == 'truetrue'
    assert ansible_native_concat(['true', 'true', 'true']) == 'truetruetrue'
    assert ansible_native_concat(['true', 'true', 'true', '  ']) == 'truetruetrue  '
    assert ansible_native_concat(['true', 'true', 'true', 'false']) == 'truetruetruefalse'
    assert ansible_

# Generated at 2022-06-21 07:44:39.973975
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_cases = {
        ((), None): None,
        ((42,), 42): 42,
        (('42',), '42'): 42,
        (('42', '0o20', '0x2A'), '420x2A'): 84,
        (('0o20', '42', '0x2A'), '0o20420x2A'): 2110,
        (('0x2A', '0o20', '42'), '0x2A0o2042'): 21130,
    }

    for args, expected_out in test_cases.items():
        result = ansible_native_concat(args[0])

# Generated at 2022-06-21 07:44:52.187417
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat((1, 2)) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([0]) == 0
    assert ansible_native_concat([-1]) == -1
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([u'\N{SNOWMAN}']) == u'\N{SNOWMAN}'
    assert ansible_native_concat([u'\xa0']) == u'\xa0'
    assert ansible_native_concat([u'\U0001f4a9']) == u'\U0001f4a9'
    assert ansible_native_concat([True]) is True

# Generated at 2022-06-21 07:45:01.874759
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(["Hello", " World"]) == "Hello World"
    assert ansible_native_concat(["Hello", "123"]) == "Hello123"
    assert ansible_native_concat(["122", "123"]) == 122123
    assert ansible_native_concat(["Hello", "True"]) == "HelloTrue"
    assert ansible_native_concat([123, 456]) == 123456
    assert ansible_native_concat([{'a': 1}, {'b': 2}]) == [{'a': 1}, {'b': 2}]   # noqa
    assert ansible_native_concat(["Hello", " World"]) == "Hello World"
    assert ansible_native_concat(["Hello", " World", 3]) == "Hello World3"

# Generated at 2022-06-21 07:45:11.205169
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.six import PY3, BytesIO
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()

    def _tmpl(template, extra_vars=None):
        extra_vars = {} if extra_vars is None else extra_vars
        template = Templar(
            loader=None,
            variable_manager=variable_manager,
            shared_loader_obj=None,
            searchpath=None,
        )
        return template.template(template, preserve_trailing_newlines=True, wrap_text=False, **extra_vars)


# Generated at 2022-06-21 07:45:21.687684
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test scalar types
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([]) is None

    # Test unicode
    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([to_text(u'foo')]) == u'foo'
    assert ansible_native_concat([to_text(u'foo'), to_text(u'bar')]) == u'foobar'

    # Test strings

# Generated at 2022-06-21 07:45:34.095727
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    class TestItem(object):
        def __init__(self, value, **kwargs):
            self.value = value
            for k, v in kwargs.items():
                setattr(self, k, v)

        def __repr__(self):
            return repr(self.value)

        def __str__(self):
            return str(self.value)

        def __bool__(self):
            return bool(self.value)

        def __add__(self, other):
            return TestItem(self.value + other.value)

        def __radd__(self, other):
            return TestItem(other.value + self.value)

        def __eq__(self, other):
            return self.value == other.value

        def __len__(self):
            return self.value


# Generated at 2022-06-21 07:45:44.892596
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 1]) == 'foo1'
    # Tests for integer addition
    assert ansible_native_concat([1, 2]) == 3
    # Tests for floating point addition
    assert ansible_native_concat([1.0, 2.0]) == 3.0
    # Tests for integer to float promotion
    assert ansible_native_concat([1, 1.0]) == 2.0
    # Tests for string concatenation
    assert ansible_native_concat(['foo', 2]) == 'foo2'
    assert ansible_native_concat([3, 'foo']) == '3foo'
    assert ansible_native_concat([3.0, 'foo'])

# Generated at 2022-06-21 07:45:59.454174
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([None, 'bar']) == 'bar'
    assert ansible_native_concat(['foo', None]) == 'foo'
    assert ansible_native_concat(['foo', 'bar', 'baz']) == 'foobarbaz'
    assert ansible_native_concat(['foo', 'bar', None]) == 'foobar'
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat(['foo', '', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', '', None]) == 'foo'
    assert ansible_native

# Generated at 2022-06-21 07:46:11.975605
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:46:21.539977
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import Environment
    env = Environment()

    # Test for valid literal syntax
    assert ansible_native_concat([env.compile_expression(u"{{'a'+'b'}}")]) == u'ab'
    assert ansible_native_concat([env.compile_expression(u"{{'a' + 'b'}}")]) == u'ab'
    assert ansible_native_concat([env.compile_expression(u"{{ 'a'+'b' }}")]) == u'ab'
    assert ansible_native_concat([env.compile_expression(u"{{ 'a' + 'b' }}")]) == u'ab'
    assert ansible_native_concat([env.compile_expression(u"{{'true'}}")]) is True
    assert ans

# Generated at 2022-06-21 07:46:32.306048
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test function to ensure that the return value of ansible_native_concat
    matches what we expect in various cases.
    """
    # test empty value
    result = ansible_native_concat([])
    assert result is None

    # regular strings
    result = ansible_native_concat(['foo'])
    assert result == 'foo'
    result = ansible_native_concat(['foo', 'bar'])
    assert result == 'foobar'

    # numbers
    result = ansible_native_concat(['1'])
    assert result == 1
    result = ansible_native_concat(['1', '2'])
    assert result == 12

    # lists
    result = ansible_native_concat(['[1]'])
    assert result == [1]
    result = ansible

# Generated at 2022-06-21 07:46:40.134937
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat(['1', '2', '3']) == 123
    assert isinstance(ansible_native_concat(['a', b'b', 'c']), text_type)
    assert ansible_native_concat([[{'a': 1}], [{'b': 2}, {'c': 3}]]) == [{'a': 1}, {'b': 2}, {'c': 3}]



# Generated at 2022-06-21 07:46:52.221218
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # pylint: disable=unused-argument
    assert ansible_native_concat([]) is None

    # Single node
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([b'a']) == 'a'   # Python 2.7
    assert ansible_native_concat([b'a'.decode('utf-8')]) == 'a'  # Python 3
    assert ansible_native_concat([u'a']) == 'a'   # Python 2
    assert ansible_native_concat([u'a'.encode('utf-8')]) == 'a'  # Python 3

    # Single boolean node
    assert ansible_native_concat([False]) is False
    assert ansible_native_concat([True]) is True



# Generated at 2022-06-21 07:46:58.982284
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Note: this test should run with python3 only
    assert ansible_native_concat(['a', 1]) == 'a1'
    assert ansible_native_concat([1, 'a']) == '1a'
    assert ansible_native_concat(['a', 1, 2, 3.1, True, False, None, 'end']) == 'a123.1TrueFalseNoneend'
    assert ansible_native_concat([1, 2, 3.1, True, False, None, 'end']) == '123.1TrueFalseNoneend'
    assert ansible_native_concat([' a', 1, 2, 3.1, True, False, None, 'end']) == ' a123.1TrueFalseNoneend'

# Generated at 2022-06-21 07:47:10.432836
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from decimal import Decimal
    from jinja2 import Environment

    # https://github.com/ansible/ansible/issues/70831

    def test_value(data):
        assert ansible_native_concat(data.items()) == data
        assert ansible_native_concat(data.values()) == data

    def test_iter(data, val, max=None):
        e = Environment('<%', '%>', '${', '}')
        tmpl = to_text('<% for v in %s -%>${%s}<% endfor -%>')
        nodes = e.parse(tmpl % (container_to_text(data), val)).body[0].iter_child_nodes()
        if max is not None:
            nodes = islice(nodes, max)
       

# Generated at 2022-06-21 07:47:23.627573
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-21 07:47:34.747980
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat([0]) == 0
    assert ansible_native_concat(range(4)) == u"0123"

    # Python 3.7+
    # assert ansible_native_concat(['"abc"', "'def'"]) == u'"abc"def'
    assert ansible_native_concat(['"abc"', "'def'"]) == u'abcdef'
    assert ansible_native_concat(['0', 1, 7.5, '"0"']) == u'0171.5"0"'
    assert ansible_native_concat(['0', 1, 7.5, '"0"']) != u'0171.5"0'


# Generated at 2022-06-21 07:47:50.426776
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    input_data = [{u'a': u'b'}, u'c', [u'a', u'b'], {u'c': u'd'}]
    output_data = [{u'a': u'b'}, u'c', [u'a', u'b'], {u'c': u'd'}]
    assert output_data == ansible_native_concat(input_data)

    input_data = [{u'a': u'b'}, ansible_native_concat([u'c', u'd']), [u'a', u'b'], {u'c': u'd'}]
    output_data = [{u'a': u'b'}, u'cd', [u'a', u'b'], {u'c': u'd'}]
    assert output_

# Generated at 2022-06-21 07:47:57.580514
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.utils.template import ansible_native_concat
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var
    import jinja2
    import types

    env = jinja2.Environment(
        undefined=jinja2.StrictUndefined,
        extensions=['jinja2_native2.NativeExtension'],
    )
    env.filters['ansible_native_concat'] = ansible_native_concat

    template = env.from_string("{{ [a, b] | ansible_native_concat }}")
    assert template.render(a=wrap_var('foo'), b=wrap_var('bar')) == 'foobar'


# Generated at 2022-06-21 07:48:09.732001
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Unit tests for function ansible_native_concat"""
    str_ops = [
        (r'"\n"', '\n'),
        (r'"\n"|string', '\n'),
        (r'"a" "b"', 'ab'),
        (r'"a" "b"|string', 'ab'),
        (r'"a" "b" "c"', 'abc'),
        (r'"a" "b" "c"|string', 'abc'),
    ]
    for jinja, result in str_ops:
        assert ansible_native_concat(container_to_text(ast.literal_eval(jinja))) == result


# Generated at 2022-06-21 07:48:21.711026
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:48:32.347941
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = [1, 2]

    # Test concatenation of a list of integers
    assert ansible_native_concat(nodes) == '12'

    nodes = [1, 2, 3]

    # Test concatenation of a list of integers
    assert ansible_native_concat(nodes) == '123'

    nodes = [1, 2, 3, 4, 5]

    # Test concatenation of a list of integers
    assert ansible_native_concat(nodes) == '12345'

    nodes = [1, '2', 3]

    # Test concatenation of a list of integers and strings
    assert ansible_native_concat(nodes) == '123'

    nodes = ['1', '2', '3', '4', '5']

    # Test concatenation of a list of

# Generated at 2022-06-21 07:48:43.234336
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 'bar', 'baz']) == 'foobarbaz'
    assert ansible_native_concat(['foo', container_to_text({'foo': 'bar'})]) == 'foobar'
    assert ansible_native_concat(['foo', container_to_text({'foo': 'bar'}), 'baz']) == 'foobarbaz'
    assert ansible_native_concat(['foo', 'bar', container_to_text({'foo': 'bar'})]) == 'foobarbar'
    assert ansible

# Generated at 2022-06-21 07:48:52.657553
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """
    This function tests that the function ansible_native_concat returns the
    correct string.
    """
    nodes = [1, 2, 3]
    assert ansible_native_concat(nodes) == 1

    nodes = [u"1", u"2", u"3"]
    assert ansible_native_concat(nodes) == 123

    nodes = [u"1", u"+", u"2", u"+", u"3"]
    assert ansible_native_concat(nodes) == u"1+2+3"

    nodes = [u"1+2", u"3"]
    assert ansible_native_concat(nodes) == u"1+2 3"

    nodes = [u"1+2", u"3"]

# Generated at 2022-06-21 07:49:02.447676
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.loader import AnsibleLoader

    constructor = AnsibleConstructor(AnsibleLoader)

    # sanity check
    assert to_text(None) == to_text(ansible_native_concat(None))
    assert to_text("") == to_text(ansible_native_concat(""))
    assert to_text(1) == to_text(ansible_native_concat(1))
    assert to_text(False) == to_text(ansible_native_concat(False))
    assert to_text(3.14) == to_text(ansible_native_concat(3.14))
    # sanity check end

    # test string concat

# Generated at 2022-06-21 07:49:04.953028
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodelist = ['foo', 'bar']
    assert ansible_native_concat(nodelist) == 'foobar'



# Generated at 2022-06-21 07:49:14.173557
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_bytes, to_native


# Generated at 2022-06-21 07:49:27.816417
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([[1]]) == "[1]"
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['1', '1']) == "11"
    assert ansible_native_concat(['"a"']) == 'a'
    assert ansible_native_concat(['1', '"a"']) == "1a"
    assert ansible_native_concat(['"a', '"b"']) == "ab"



# Generated at 2022-06-21 07:49:36.125130
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([123]) == 123
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([]) is None

    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat(['foo', 'bar', 'baz']) == 'foobarbaz'

    assert ansible_native_concat(['foo', '123']) == 'foo123'
    assert ansible_native_concat(['1', '2', '3']) == '123'

# Generated at 2022-06-21 07:49:46.928859
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    for bad_vault in (False, None, True):
        assert ansible_native_concat([bad_vault]) is bad_vault


# Generated at 2022-06-21 07:49:54.096480
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat([u'foo']) == 'foo'

    x = AnsibleVaultEncryptedUnicode(b'1')
    assert ansible_native_concat([x]) == b'1'

    x = NativeJinjaText(u'some_variable')
    assert ansible_native_concat([x]) == x

    assert ansible_native_concat([1, u'foo']) == 1
    assert ansible_native_concat([u'foo', 1]) == u'foo1'
    assert ansible_native_concat([1, 2, 3, 4, 5]) == 12345

# Generated at 2022-06-21 07:50:04.462500
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a', 'b']) == u'ab'
    assert ansible_native_concat(['a', 1, 5.5, True]) == u'a155True'
    assert ansible_native_concat([1, 2]) == u'12'
    # when receiving a single parameter, no concatenation occurs
    assert ansible_native_concat([u'a']) == u'a'

    # test with a mixture of types
    assert ansible_native_concat([u'a', 1, u'b', 2, u'c', 3, u'd']) == u'a1b2c3d'

# Generated at 2022-06-21 07:50:15.129580
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([u'\u0431', 'bar']) == u'\u0431bar'

    assert ansible_native_concat(['foo', 1, 2, 'bar']) == 'foo1bar'
    assert ansible_native_concat([1, 2, 'bar']) == 'bar'
    assert ansible_native_concat([1, 2, 'bar', StrictUndefined()]) is StrictUndefined()

    assert ansible_native_concat([u'\u0431', [u'\u0432', u'\u0433'], 'bar']) == u'\u0431[\u0432, \u0433]bar'
    assert ansible_native

# Generated at 2022-06-21 07:50:25.287312
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import ensure_text
    from ansible.module_utils.parsing.filters.dictsort import dictsort
    from ansible.module_utils.parsing.filters.unique import unique
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves.urllib_parse import urlparse
    from ansible.module_utils.urls import url_query_parameter
    from ansible.module_utils.urls import url_unquote_plus
    import ansible.module_utils.urls
    assert isinstance(ansible_native_concat([]), type(None))
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo'])