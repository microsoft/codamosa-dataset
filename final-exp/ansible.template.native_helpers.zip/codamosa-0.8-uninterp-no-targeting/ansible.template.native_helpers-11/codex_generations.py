

# Generated at 2022-06-21 07:40:40.340508
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == 1
    assert ansible_native_concat(range(10)) == 0
    assert ansible_native_concat(x for x in range(10)) == 0

    assert ansible_native_concat([1, 2, 3]) == 1
    assert ansible_native_concat({1, 2, 3}) == 1
    assert ansible_native_concat(range(10)) == 0

    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'

# Generated at 2022-06-21 07:40:51.778275
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:41:03.523058
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # test helper native types
    assert ansible_native_concat([1, 1, 2, 3, 5, 8]) == [1, 1, 2, 3, 5, 8]
    assert ansible_native_concat([1, 1, 2, 'ho', 5, 8]) == [1, 1, 2, 'ho', 5, 8]
    assert ansible_native_concat([1, 1, 2, 3, 5, 8.0]) == [1, 1, 2, 3, 5, 8.0]
    assert ansible_native_concat([1, 1, 2, True, 5, 8]) == [1, 1, 2, True, 5, 8]
    assert ansible_native_concat([1, 1, 2, 3, 5, False]) == [1, 1, 2, 3, 5, False]
   

# Generated at 2022-06-21 07:41:13.947893
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(['a', 'b', True]) == 'abTrue'
    assert ansible_native_concat([['a'], 'b']) == ['a', 'b']
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat(['a', ' ', 'b']) == 'a b'
    assert ansible_native_concat(['a', ' b']) == 'a b'
    assert ansible_native_concat(['a\n', ' b']) == 'a\n b'
    assert ansible_native_con

# Generated at 2022-06-21 07:41:24.387128
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test for function ansible_native_concat."""
    # pylint: disable=unused-argument, invalid-name
    def concat(nodes):
        """Call ansible_native_concat."""
        return ansible_native_concat(nodes)

    assert concat([1]) == 1
    assert concat(['a']) == 'a'
    assert concat(['a', 'b']) == 'ab'
    assert concat([1, 'b']) == '1b'
    assert concat([[1], [2]]) == [1, 2]
    assert concat([[1], [2], 'c']) == [1, 2, 'c']

    assert concat([NativeJinjaText('a')]) == 'a'

# Generated at 2022-06-21 07:41:31.558963
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([0]) == 0
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([0, 1]) == '01'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat([0, 1, 'ab']) == '01ab'
    assert ansible_native_concat([['a'], ['b']]) == 'ab'
    assert ansible_native_concat([['a'], ['b'], 0, 1, 'ab']) == 'ab01ab'
    assert ansible_native_concat([0, ['a'], ['b'], 1, 'ab']) == '0ab1ab'
    assert ansible_native_concat

# Generated at 2022-06-21 07:41:43.311474
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Basic tests for function ansible_native_concat"""

    # test with None
    func_test_value = ansible_native_concat([])
    assert func_test_value is None

    # test with StrictUndefined
    func_test_value = ansible_native_concat([StrictUndefined()])
    assert func_test_value is None

    # test with boolean
    func_test_value = ansible_native_concat([False])
    assert func_test_value is False

    # test with empty string
    func_test_value = ansible_native_concat([text_type('')])
    assert func_test_value == text_type('')

    # test with empty string and StrictUndefined

# Generated at 2022-06-21 07:41:54.900085
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.collections import is_sequence

    assert ansible_native_concat(('a', 'b')) == 'ab'
    assert ansible_native_concat(list(range(3))) == [0, 1, 2]
    assert is_sequence(ansible_native_concat(list(range(3))))

    assert ansible_native_concat((1, 2, None, 3)) == [1, 2, None, 3]
    assert is_sequence(ansible_native_concat((1, 2, None, 3)))

    assert ansible_native_concat((1, 2, u'', 3)) == [1, 2, u'', 3]
    assert is_sequence(ansible_native_concat((1, 2, u'', 3)))

    assert ansible_native

# Generated at 2022-06-21 07:42:03.904720
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test with empty string
    assert ansible_native_concat(u'') is None
    assert ansible_native_concat('') is None
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    # list is returned as string so far
    assert ansible_native_concat([[1, 2]]) == '[1, 2]'
    assert ansible_native_concat([[1], [2]]) == '[1, 2]'
    assert ansible_native_concat([[1], [2], [3]]) == '[1, 2, 3]'
    assert ansible_

# Generated at 2022-06-21 07:42:14.506559
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2.runtime import Context
    from ansible.module_utils.common.text.converters import to_native
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    with pytest.raises(TypeError):
        ansible_native_concat()

    # Test that ansible_native_concat converts native Python objects
    # to strings and concatenates them.
    assert ansible_native_concat([3, 'foo', 'bar', True]) == '3foobarTrue'

    # Test that ansible_native_concat returns the same Python object if
    # the input is a single item.
    assert ansible_native_concat([True]) is True

    # Test that ansible_native_concat returns the same Python object if
    # the input is

# Generated at 2022-06-21 07:42:24.125997
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.utils.native_jinja import NativeJinjaText

    # test simple vars
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([True]) == True
    assert ansible_native_concat(['abc']) == 'abc'

    # test concatenation
    assert ansible_native_concat([1, 'def', True]) == '1defTrue'

    # test literal_eval
    assert ansible_native_concat(['{"a": 1}']) == {"a": 1}

    # test literal_eval and concatenation
    assert ansible_native_concat(['{"a": 1}', '"def"', 'True']) == '{"a": 1}"def"True'

    # test literal_eval and concatenation with native j

# Generated at 2022-06-21 07:42:35.883617
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_text
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import unsafe_bytes_to_text
    import ast

    # Test that when we pass ansible_native_concat a list of nodes, the function
    # returns the concatenation of the input nodes. Test multiple scenarios:
    #  1. Nodes that are AnsibleUnsafeText and not AnsibleUnsafeText
    #  2. Nodes that can be evaluated to literal_eval
    #  3. Nodes that can't be evaluated to literal_eval and should be returned as string
    #  4

# Generated at 2022-06-21 07:42:45.794435
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = [1, 2, 3]
    out = ansible_native_concat(nodes)
    assert out == 1
    assert isinstance(out, int)

    nodes = ['a', 'b', 'c']
    out = ansible_native_concat(nodes)
    assert out == 'abc'
    assert isinstance(out, text_type)

    nodes = ['abc', 123, True]
    out = ansible_native_concat(nodes)
    assert out == 'abc123True'
    assert isinstance(out, text_type)

    nodes = ['abc 123', False, None]
    out = ansible_native_concat(nodes)
    assert out == 'abc 123FalseNone'
    assert isinstance(out, text_type)

    nodes = ['abc ', 123, False]


# Generated at 2022-06-21 07:42:54.816573
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import native


# Generated at 2022-06-21 07:43:03.051355
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert None == ansible_native_concat([])
    assert None == ansible_native_concat([None])

    assert 'foo' == ansible_native_concat(['foo'])
    assert 42 == ansible_native_concat(['42'])
    assert 42 == ansible_native_concat(['42', '0'])
    assert 42 == ansible_native_concat(['4', '2'])
    assert 42 == ansible_native_concat(['4', '2', '0'])
    assert [42] == ansible_native_concat(['[42]'])

    assert '42' == ansible_native_concat(['"42"'])
    assert '42' == ansible_native_concat(['42'])
    assert '42' == ansible_native_con

# Generated at 2022-06-21 07:43:16.640819
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """
    This test asserts that specific code paths are triggered via Jinja2
    macro processing and that they end up in the appropriate code path in
    ansible_native_concat.

    For example, when a list is concatenated with a string, a generator is
    returned. In order to properly test this code path, we set up a generator
    in the Jinja2 environment and assert that it returns the expected value.

    The other part of this test is to assert that the generated code is
    expected to call ansible_native_concat where the `nodes` argument is
    passed in as a generator.
    """

    # Note that we are only testing a subset of the various cases. This is
    # because we are testing that the Jinja2 macro passes in a generator
    # and that the logic in ansible_native_concat works. So, not all

# Generated at 2022-06-21 07:43:26.841502
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2.nodes import Name, Const, List, Dict, Set

    assert ansible_native_concat([]) is None
    assert ansible_native_concat([Name('foo', 'load')]) == 'foo'
    assert ansible_native_concat([Const('foo')]) == 'foo'
    assert ansible_native_concat([List([Const('foo'), Const('bar')])]) == ['foo', 'bar']
    assert ansible_native_concat([Dict([Const('foo'), Const('bar')])]) == {'foo': 'bar'}
    assert ansible_native_concat([Set([Const('foo'), Const('bar')])]) == {'foo', 'bar'}
    assert ansible_native_concat([Const('foo'), Const('bar')]) == 'foobar'
   

# Generated at 2022-06-21 07:43:36.460755
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    if not hasattr(ast, 'parse'):
        # Skip the unit test on older Python versions without ast.parse
        return

    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', ' ', 'b']) == 'a b'
    assert ansible_native_concat(['a', ' ', 'b', ' ', 'c']) == 'a b c'
    assert ansible_native_concat(['a', ' ', 'b', ' ', 'c', ' ', 'd']) == 'a b c d'

    # The result of the concatenation should be parsed with ast.literal_eval
    # if possible.
    assert ansible_native_con

# Generated at 2022-06-21 07:43:48.860910
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([None, None]) == None
    assert ansible_native_concat([42, None]) == 42
    assert ansible_native_concat([42, 'foo']) == '42foo'
    assert ansible_native_concat([42, 'foo', None, None, 'bar']) == '42foobar'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 'bar', '']) == 'foobar'
    assert ansible_native_concat([42, 'foo']) == '42foo'
    assert ansible_native_concat(['foo', 42]) == 'foo42'

# Generated at 2022-06-21 07:43:56.257218
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = [True, [2, 3.5], 'test', ' ', None, container_to_text(None), container_to_text(dict(test="test"))]
    expected = 'True[2, 3.5]test None None {test:test}'
    result = ansible_native_concat(nodes)
    assert isinstance(result, text_type)
    assert result == expected

# Generated at 2022-06-21 07:44:06.361957
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.template.vars import AnsibleNativeJinjaText
    from ansible.template.safe_eval import ansible_concat
    from ansible.module_utils.common.text.converters import to_bytes

    # Test without converting to native type
    assert ansible_concat(['foo', 'bar']) == 'foobar'
    assert ansible_concat(['foo', 123]) == 'foo123'
    assert ansible_concat(['foo', 123, 'bar']) == 'foo123bar'
    assert ansible_concat(['foo', 'bar', 123]) == 'foobar123'

# Generated at 2022-06-21 07:44:17.849121
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Tests for the ansible_native_concat function"""
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(1) == 1
    assert ansible_native_concat([['a', 'b']]) == ['a', 'b']
    assert ansible_native_concat(['{"a": "b"}']) == {'a': 'b'}
    assert ansible_native_concat(['a', 'b']) == u'ab'
    assert ansible_native_concat(['a', '', 'b']) == u'ab'
    assert ansible_native_concat([' ', '"a"b']) == u' "ab'

# Generated at 2022-06-21 07:44:27.337309
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.template import Template
    from ansible import constants

    constants.JINJA2_NATIVE = True
    vars = dict(foo='bar')
    t = Template(src='"{{ foo }}"', vars=vars)
    assert t.template.environment.finalize(t.template.root_render_func()) == 'bar'

    vars = dict(foo='bar')
    t = Template(src='"{{ foo | string }}"', vars=vars)
    assert t.template.environment.finalize(t.template.root_render_func()) == 'bar'

    vars = dict(valid_list=[1, 2, 3], invalid_list=['1', '2', '3'])
    t = Template(src='{{ valid_list }}', vars=vars)
    assert t

# Generated at 2022-06-21 07:44:39.479224
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    from ansible.module_utils.common.text.converters import to_bytes, to_text
    def assert_equal(expected_value, given_value):
        if not expected_value == given_value:
            raise AssertionError("'%s' not equal to '%s'" % (given_value, expected_value))

    assert_equal(u'foo', ansible_native_concat([u'foo']))
    assert_equal(u'foo', ansible_native_concat([u'f', u'oo']))
    assert_equal(u"{{ foo }}", ansible_native_concat([u"{", u"{ foo }", u"}"]))

# Generated at 2022-06-21 07:44:51.532817
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common.text.converters import to_bool, to_int

# Generated at 2022-06-21 07:44:59.849390
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', None]) == 'aNone'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', True, ' ', 'b']) == 'a True b'
    assert ansible_native_concat(['a', True, ' ', 'b']) == 'a True b'
    assert ansible_native_concat(['a', True, ' ', 'b']) == 'a True b'

# Generated at 2022-06-21 07:45:10.013400
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class TestUndefined(StrictUndefined):
        def __unicode__(self):
            return 'TESTUNDEFINED'

    class TestVault(AnsibleVaultEncryptedUnicode):
        @property
        def data(self):
            return 'testvault'

    assert ansible_native_concat([]) == None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, 2, 3]) == '123'

    assert ansible_native_concat(['1']) == '1'
    assert ansible_native_concat(['1', '2']) == '12'

# Generated at 2022-06-21 07:45:20.787258
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    literal_eval_test_inputs = [
        (u'', u''),
        (u'"test"', u'test'),
        (u"['test', 'test']", [u'test', u'test']),
        (u'["test", "test"]', [u'test', u'test']),
        (u'{"key": "test"}', {u'key': u'test'}),
        (u'{"key": test}', u'{"key": test}'),
        (u'{"test": "test"}', u'{"test": "test"}'),
        (u'{"test": true}', u'{"test": true}'),
    ]

# Generated at 2022-06-21 07:45:33.129222
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['abc']) == 'abc'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == 12
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat([1.0, 2.0]) == '1.02.0'
    assert ansible_native_concat(['abc', 'def']) == 'abcdef'
    assert ansible_native_concat(['abc', 'def']) == 'abcdef'
    assert ansible_native_concat(['abc', 'def', 'ghi']) == 'abcdefghi'
    assert ansible_native_concat(['1.0', '2.0']) == '12.0'

# Generated at 2022-06-21 07:45:39.464681
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test list concatenation and literal_eval
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]

    # Test empty list
    assert ansible_native_concat([]) is None

    # Test single element, single element simple text, and literal_eval
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['True']) == True
    assert ansible_native_concat(['1.0']) == 1.0
    assert ansible_native_concat(['"foo"']) == "foo"
    assert ansible_native_concat(["'bar'"]) == "bar"
    assert ansible_native_concat(['{}'])

# Generated at 2022-06-21 07:45:51.787001
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat([1, 2, None]) == '12None'
    assert ansible_native_concat([1, 'a', 'b']) == '1ab'
    assert ansible_native_concat([1, 2, u'a']) == '12a'

    class Undefined(object):
        def __str__(self):
            raise StrictUndefined('undefined')

    assert ansible_native_concat([Undefined()]) == 'None'
    assert ansible_native_concat([None, 'None']) == 'NoneNone'
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([Undefined()]) == 'None'
    assert ansible_

# Generated at 2022-06-21 07:46:02.266862
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Check that strings are concatenated as expected."""
    data = [
        '',  # empty string
        u'a',  # simple string
        'b',  # simple str
        to_text(u'Д'),  # unicode
        u'\U0001D11E',  # astral unicode
        '\U0001D11E',  # astral str
        u'\U0001D11E',  # astral unicode
        ' \t',  # leading space
        u'  \t\n',  # leading space
        'c',
        ' ',  # trailing space
        '\t\n  ',  # trailing space
        ' ',
        '',
    ]
    expected = u''.join(data)
    # check that ast.literal_eval produces the same result as ansible_

# Generated at 2022-06-21 07:46:13.969484
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # run tests
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat([1.1, 2.2]) == 3.3
    assert ansible_native_concat(['{{ foo }}', 'bar']) == '{{ foo }}bar'
    assert ansible_native_concat([[1, 2], [3, 4]]) == [1, 2, 3, 4]
    assert ansible_native_concat([[1, 2], 3, [4]]) == [1, 2, 3, 4]
    assert ansible_native_concat([[1, 2], 3, (4,)]) == [1, 2, 3, 4]
    assert ansible_native

# Generated at 2022-06-21 07:46:25.758427
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Check that the native concat function returns the same results as
    # its PiP counterpart.
    #
    # https://github.com/pallets/jinja/blob/master/src/jinja2/nativetypes.py

    from ansible.module_utils.ansible_jinja2.concat import ansible_concat as pip_concat

    def _concat(seq):
        return ansible_native_concat([container_to_text(x) for x in seq])

    # Fake node objects with a value attribute.
    class Node:
        def __init__(self, value):
            self.value = value

    assert _concat([]) is None

    assert _concat([Node(None)]) is None

    assert _concat([Node(42)]) == 42


# Generated at 2022-06-21 07:46:34.956480
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat([]), None

    assert ansible_native_concat(['1', '2']) == 12

    assert ansible_native_concat(['foo', 'bar'], ) == 'foobar'
    assert ansible_native_concat(['foobar', 'bar'], ) == 'foobarbar'

    assert ansible_native_concat(['1', 2, 3]) == '123'
    assert ansible_native_concat([1, '2', 3]) == '123'
    assert ansible_native_concat([1, 2, '3']) == '123'


# Generated at 2022-06-21 07:46:44.884199
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([['a', 'b']]) == ['a', 'b']
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat([1, 2]) == 12
    assert ansible_native_concat([None, None]) is None
    assert ansible_native_concat([1, None]) == 1
    assert ansible_native_concat([1, 2, None]) == 12
    assert ansible_native_concat([1, None, 3]) == 13

# Generated at 2022-06-21 07:46:55.775540
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    t = text_type('asdf', 'utf-8')
    assert ansible_native_concat([t]) == t

    t = to_text('asdf', 'utf-8')
    assert ansible_native_concat([t]) == t

    t = container_to_text(['asdf'])
    assert ansible_native_concat([t]) == t

    t = container_to_text(['asdf', 'bsdf'])
    assert ansible_native_concat([t]) == t

    assert ansible_native_concat(map(to_text, ['asdf', 'bsdf', 'csdf'])) == 'asdfbsdfcsdf'

# Generated at 2022-06-21 07:47:07.914059
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import pytest

    # Test 1: Single node with a string value
    node1 = NativeJinjaText(b'foo')
    assert ansible_native_concat([node1]) == b'foo'

    # Test 2: Multiple nodes with string values
    node2 = NativeJinjaText(b'bar')
    node3 = NativeJinjaText(b'baz')

    assert ansible_native_concat([node1, node2, node3]) == b'foobarbaz'

    # Test 3: Verify literal_eval is called on the concatenated string
    assert ansible_native_concat([node1, node2, node3]) == b'foobarbaz'

    # Test 4: Unsupported concatenations including non-strings, should raise a
    # ValueError.

# Generated at 2022-06-21 07:47:15.065014
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode


# Generated at 2022-06-21 07:47:26.147268
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test concat method"""
    # pylint: disable=too-few-public-methods
    class Input(object):
        """Input class for the test"""
        def __init__(self, value):
            self.value = value

    class Undefined(object):
        """Undefined class to raise UndefinedError"""
        pass

    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat((1, 2, 3)) == (1, 2, 3)
    assert ansible_native_concat([b'1', b'2', b'3']) == [b'1', b'2', b'3']

# Generated at 2022-06-21 07:47:38.832772
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:47:50.706389
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    a = [1, 2, 3]

# Generated at 2022-06-21 07:47:57.749407
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    from ansible.utils.jinja2_native import ansible_native_concat

    # Test basic concatenation
    assert ansible_native_concat([u'a', u'b', u'c']) == u'abc'

    # Test single value
    assert ansible_native_concat([u'abc']) == u'abc'

    # Test integer
    assert ansible_native_concat([u'1']) == 1

    # Test list
    assert ansible_native_concat([u'[1, 2, 3]']) == [1, 2, 3]

    # Test dictionary
    assert ansible_native_concat([u'{foo: bar}']) == {'foo': 'bar'}

    # Test generator

# Generated at 2022-06-21 07:48:09.858475
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = iter((-2, -1, 0, 1, 2))
    assert ansible_native_concat(nodes) == -2
    assert ansible_native_concat(nodes) == -1
    assert ansible_native_concat(nodes) == 0
    assert ansible_native_concat(nodes) == 1
    assert ansible_native_concat(nodes) == 2

    nodes = iter(('a', 'b', 'c'))
    assert ansible_native_concat(nodes) == 'abc'

    nodes = iter((123, 'a', True))
    assert ansible_native_concat(nodes) == 123
    assert ansible_native_concat(nodes) == 'a'
    assert ansible_native_concat(nodes) is True

    nodes

# Generated at 2022-06-21 07:48:21.875989
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'hello', u'world']) == 'helloworld'
    assert ansible_native_concat([{}, 'world']) == 'world'
    assert ansible_native_concat([{}, {'hello': 'world'}]) == {'hello': 'world'}
    assert ansible_native_concat([{}, {'hello': 'world'}]) == {'hello': 'world'}
    assert ansible_native_concat([u'a', u'1', u'b', u'2']) == 'a1b2'
    assert ansible_native_concat([u'a', u'b', u'c']) == 'abc'
    assert ansible_native_concat([u'b', u'c']) == 'bc'
    assert ans

# Generated at 2022-06-21 07:48:32.680840
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    literal_eval_success = [
        'a',
        "[1, 2, 3]",
        "1 + 2 * 3",
        "(1 + 2) * 3",
        "{1: 2}",
    ]
    for value in literal_eval_success:
        val = ansible_native_concat([value])
        assert container_to_text(val) == value, val
        assert isinstance(val, type(ast.literal_eval(value))), val

    literal_eval_failure = [
        "1 +",
        "1 + [1, 2, 3]",
        "{'a': 1, 'b': 2}",
    ]
    for value in literal_eval_failure:
        val = ansible_native_concat([value])
        assert val == value, val
        assert isinstance

# Generated at 2022-06-21 07:48:43.764504
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # pylint: disable=protected-access
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(iter([])) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([iter([1])]) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([iter([1, 2])]) == '12'
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([iter([1, 2, 3])]) == '123'
    assert ansible_native_concat(['1', '2']) == '12'

# Generated at 2022-06-21 07:48:52.963602
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(["foo", "bar"]) == "foobar"
    assert ansible_native_concat(["foo", 1]) == "foo1"
    assert ansible_native_concat([1, "bar"]) == "1bar"
    assert ansible_native_concat(['foo']) == "foo"
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1.0]) == 1.0
    assert ansible_native_concat([1j]) == 1j
    assert ansible_native_concat(["1"]) == 1
    assert ansible_native_concat([1.1]) == 1.1

# Generated at 2022-06-21 07:49:01.481559
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    AES = AnsibleVaultEncryptedUnicode('aes')
    nodes = [AES.data, AES.data]
    assert AES == ansible_native_concat(nodes)

    # In Python 3.10+ ast.literal_eval removes leading spaces/tabs
    # from the given string. For backwards compatibility we need to
    # parse the string ourselves without removing leading spaces/tabs.
    expected = u"""
    abc
    """
    nodes = [u'\n', u' ', u'a', u'\t', u'b', u'c\n']
    assert expected == ansible_native_concat(nodes)

# Generated at 2022-06-21 07:49:12.046863
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:49:31.264007
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([u'foo', 1]) == u'foo1'
    assert ansible_native_concat([u'foo', 1, u'baz']) == u'foo1baz'
    assert ansible_native_concat([u'foo', None, u'baz']) == u'foobaz'
    assert ansible_native_concat([1, None]) is None
    assert ansible_native_concat([1, 2]) == 3
    assert ansible_native_concat([u'foo', u'', u'baz']) == u'foobaz'

# Generated at 2022-06-21 07:49:41.327869
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def test_text_type(x):
        assert isinstance(x, text_type), x

    test_text_type(ansible_native_concat([1, 2, 3]))

    # empty string on None input
    assert ansible_native_concat(None) == u''

    # empty string on empty list
    assert ansible_native_concat([]) == u''

    # string on single string input
    test_text_type(ansible_native_concat([u'hello']))

    # string on single number input
    test_text_type(ansible_native_concat([45]))

    # string on single float number input
    test_text_type(ansible_native_concat([45.5]))

    # unicode on multiple numeric input

# Generated at 2022-06-21 07:49:50.754222
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # test empty input
    out = ansible_native_concat([])
    assert out is None

    # test single string input
    out = ansible_native_concat(['foo'])
    assert out == u'foo'

    # test multiple string input

    # strings should be concatenated
    out = ansible_native_concat(['a', 'b', 'c'])
    assert out == u'abc'

    # leading/trail spaces should be preserved
    out = ansible_native_concat(['a', '    b', 'c   '])
    assert out == u'a    bc   '

    # leading/trail spaces are not removed
    out = ansible_native_concat([' a', 'b ', 'c'])
    assert out == u' ab c'

    # leading/tra

# Generated at 2022-06-21 07:50:02.354344
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import Environment
    from ansible.module_utils.common.text.converters import to_native

    env = Environment(extensions=['jinja2.ext.do'])
    native_concat = env.native_concat

    # ensure that we have the correct native_concat callable
    assert native_concat.__name__ == 'ansible_native_concat'
    assert not callable(native_concat)

    do_ext = env.extensions['jinja2.ext.do']
    do = env.globals['do']
    assert do is do_ext

    # single value, not a string
    native_val = do(1, echo=True)
    assert native_val == 1

# Generated at 2022-06-21 07:50:13.159664
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'a', 1, None]) == u'a1None'
    assert ansible_native_concat([1, u'b']) == 1
    assert ansible_native_concat([b'a', 1, None]) == u'a1None'
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(x for x in [1]) == 1
    assert ansible_native_concat([1, 2, 3, 4]) == b'1234'
    assert ansible_native_concat([1, (2,), [3, 4]]) == 1
    assert ansible_native_concat([1, 2, 3, 4, 5]) == b'12345'
   

# Generated at 2022-06-21 07:50:20.026326
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import Environment
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.compat import PY3

    env = Environment(extensions=[])
    assert env.from_string('{{ "foo" + "bar" }}').render() == 'foobar'
    assert env.from_string('{{ ["f"] + ["o", "o"] + ["b", "a", "r"] }}').render() == 'foobar'
    if PY3:
        assert env.from_string('{{ ["f", "o", "o"] + ["b", "a", "r"] }}').render() == ['f', 'o', 'o', 'b', 'a', 'r']

# Generated at 2022-06-21 07:50:31.637858
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert ansible_native_concat([]) is None
    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2, 3]) == u'123'
    assert ansible_native_concat([1, 2, 3]) == 123

    assert ansible_native_concat([[1, 2], [3]]) == [1, 2, 3]

    class CustomList(list):
        pass

    assert ansible_native_concat([CustomList((1, 2, 3))]) == [1, 2, 3]