

# Generated at 2022-06-21 07:40:40.159265
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    assert ansible_native_concat(['foo']) == 'foo'

    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat([42, 43]) == "4243"
    assert ansible_native_concat([42, 43, 44]) == "424344"
    assert ansible_native_concat([42, 43, 44, 45]) == "42434445"
    assert ansible_native_concat([42, 43, 44, 45, 46]) == "4243444546"

    assert ansible_native_concat([42, "", 43, "", 44]) == "42 43 44"

# Generated at 2022-06-21 07:40:51.681767
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([u"foo"]) == u"foo"
    assert ansible_native_concat([u"foo", u"bar"]) == u"foobar"
    assert ansible_native_concat([u"foo", u"bar", u"baz"]) == u"foobarbaz"
    assert ansible_native_concat([u"", u"foo", u"", u"bar", u""]) == u"foobar"
    assert ansible_native_concat([u"foo", u"bar", u"baz"]) == u"foobarbaz"
    assert ansible_native_concat([u"true"]) == True
    assert ansible

# Generated at 2022-06-21 07:41:03.483707
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(iter(['foo'])) == 'foo'
    assert ansible_native_concat(iter(['foo', 'bar'])) == 'foobar'
    assert ansible_native_concat(iter([u'foo', u'bar'])) == u'foobar'
    assert ansible_native_concat(iter(['12', '34'])) == '1234'
    assert ansible_native_concat(iter([u'12', u'34'])) == u'1234'
    assert ansible_native_concat(iter(['abc', '123'])) == 'abc123'
    assert ansible_native_concat(iter([u'abc', u'123'])) == u'abc123'

# Generated at 2022-06-21 07:41:09.371387
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Thoroughly test the ansible_native_concat function
    """

    assert ansible_native_concat([]) == None

    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['|']) == '|'
    assert ansible_native_concat([u'|']) == u'|'
    assert ansible_native_concat([True]) == True
    assert ansible_native_concat([23]) == 23
    assert ansible_native_concat([2.3]) == 2.3
    assert ansible_native_concat([{'a': 'b'}]) == {'a': 'b'}

    # The second argument is converted to text as well

# Generated at 2022-06-21 07:41:22.043031
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from io import BytesIO
    from jinja2 import Template


# Generated at 2022-06-21 07:41:32.720060
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class DummyNode:
        def __init__(self, value):
            self.value = value

        def __add__(self, other):
            return DummyNode(self.value + other.value)

        def __unicode__(self):
            return self.value

    def assert_native(nodes, expected):
        converted_nodes = []

        for node in nodes:
            if isinstance(node, string_types):
                node = DummyNode(node)
            converted_nodes.append(node)

        assert ansible_native_concat(converted_nodes) == expected

    # Test single node
    assert_native([DummyNode('')], '')
    assert_native(['foo'], 'foo')

    # Test concatenation of multiple string literals

# Generated at 2022-06-21 07:41:43.660700
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:41:55.075774
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # test no nodes
    assert ansible_native_concat(()) is None

    # text nodes
    assert ansible_native_concat(('foo', 'bar')) == 'foobar'
    assert ansible_native_concat(('a', 'b', 'c')) == 'abc'

    # ints
    assert ansible_native_concat((1, 2)) == 3
    assert ansible_native_concat((1, 2, 3)) == 6
    # float
    assert ansible_native_concat((1.2, 1.1)) == 2.3
    assert ansible_native_concat((1.2, 1.1, 1)) == 3.3

    # list
    assert ansible_

# Generated at 2022-06-21 07:42:04.783659
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    tests = [
        ([], None),
        ([u'A'], u'A'),
        ([u'A', u'B'], u'AB'),
        ([u'a', u'b', u'c', u'd'], u'abcd'),
        ([u'a', u'b', u'c', u'd', u'e', u'f'], u'abcdef'),
        ([u'A', AnsibleVaultEncryptedUnicode(u'B')], u'AB'),
        ([u'A', AnsibleVaultEncryptedUnicode(u'B'), u'C'], u'ABC'),
    ]

    for test in tests:
        res = ansible_native_concat(test[0])

# Generated at 2022-06-21 07:42:10.206666
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat([['foo', 'bar']]) == ['foo', 'bar']
    assert ansible_native_concat(['1', '2', '3']) == 123
    assert ansible_native_concat(['1', 2, 3]) == 123
    assert ansible_native_concat(['1', 2, '3']) == 123
    assert ansible_native_concat(['FooBar', 2]) == u'FooBar2'
    assert ansible_native_concat(['FooBar', ' ', 2]) == u'FooBar 2'
   

# Generated at 2022-06-21 07:42:23.682196
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class SomeNativeJinjaText(NativeJinjaText):
        def __init__(self, value):
            self.value = value

        def __str__(self):
            return self.value

        def __repr__(self):
            return 'SomeNativeJinjaText({!r})'.format(self.value)

    def check_concat(args, expected):
        nodes = iter(args)
        actual = ansible_native_concat(nodes)
        assert actual == expected

    check_concat(['a'], 'a')
    check_concat(['a', 'b'], 'ab')
    check_concat(['a', 'b', '1', 3, 4.5], 'ab134.5')

# Generated at 2022-06-21 07:42:35.663021
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import container_to_text
    from ansible.module_utils.common.text.formatters import human_to_bytes
    from ansible.module_utils.common.text.formatters import human_to_megabytes

    assert ansible_native_concat([1, 2, 3]) == 1
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([]) is None
    assert container_to_text(ansible_native_concat([
        1, 2, 3, 4, 'b', '5', 'MB', '5 MB'
    ])) == '1,2,3,4,b,5,MB,5 MB'

# Generated at 2022-06-21 07:42:45.477317
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test ansible_native_concat function."""
    assert ansible_native_concat([])('', {}) is None
    assert ansible_native_concat(['abc'])('', {}) == 'abc'
    assert ansible_native_concat(['abc', 'def'])('', {}) == 'abcdef'
    assert ansible_native_concat(['1', '2'])('', {}) == 3
    assert ansible_native_concat(['1', '2', '3'])('', {}) == '123'
    assert ansible_native_concat(['1', '2', '3', '4'])('', {}) == '1234'
    # [1, 2] -> "[1, 2]" -> [1, 2]
    data = ['1', '2']


# Generated at 2022-06-21 07:42:51.454981
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible_native_concat import ansible_native_concat
    assert ansible_native_concat(x for x in []) is None
    assert ansible_native_concat(x for x in ['a']) == 'a'
    assert ansible_native_concat(x for x in [1]) == 1
    assert ansible_native_concat(x for x in [1, 2]) == '12'
    assert ansible_native_concat(x for x in [1, 2, 3]) == '123'
    assert ansible_native_concat(x for x in [1, '2', 3]) == '123'
    assert ansible_native_concat(x for x in [1, '2', 3]) == '123'

# Generated at 2022-06-21 07:42:59.608074
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(True) == True
    assert ansible_native_concat('some string') == 'some string'
    assert ansible_native_concat('some string') == 'some string'
    assert ansible_native_concat(b'bytes object') == 'bytes object'
    assert ansible_native_concat([True]) == True
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat(('tuple', 1, 2, 3)) == ('tuple', 1, 2, 3)
    assert ansible_native_concat(range(5)) == range(5)
    assert ansible_native_con

# Generated at 2022-06-21 07:43:07.203501
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert type(ansible_native_concat([1])) is int
    assert ansible_native_concat([1, 2]) == u'12'
    assert ansible_native_concat([u'\u623f\u5c4b']) == u'\u623f\u5c4b'
    assert ansible_native_concat([1, 2]) == 1
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([{}]) == {}
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat(['1', 2]) == '12'

# Generated at 2022-06-21 07:43:18.975354
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert not ansible_native_concat([])

    # single node
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1.0]) == 1.0
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([['a', 'b']]) == ['a', 'b']

    # multiple nodes
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat([['a', 'b'], ['c', 'd']]) == 'acbd'

    # value parsed with literal_eval

# Generated at 2022-06-21 07:43:27.649130
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    '''
    [
      { text: "first" },
      " ",
      { text: "second" },
      " ",
      { text: "third" }
    ] -> "first second third"
    '''
    class Node(Mapping):
        def __init__(self, text):
            self.text = text

        def __eq__(self, other):
            return isinstance(other, Node) and self.text == other.text

        def __ne__(self, other):
            return not self.__eq__(other)

        def __repr__(self):
            return "Node('{}')".format(self.text)

        def __len__(self):
            return 1

        def __getitem__(self, key):
            return self.text

        def keys(self):
            return

# Generated at 2022-06-21 07:43:37.248515
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    concat = ansible_native_concat
    assert concat([]) is None
    assert concat(['foo', 'bar']) == 'foobar'
    assert concat(['foo', 'bar'], 'baz') == 'foobarbaz'
    assert concat(123) == 123
    assert concat('foo') == 'foo'
    assert concat(['f', '', '1']) == 'f1'
    assert concat(['f', None, '1']) == 'f1'
    assert concat(['f', None, '1'], '', '', '', 'g') == 'f1g'
    assert concat(['f', None, '1'], None) == 'f1None'
    assert concat(['']) == ''

# Generated at 2022-06-21 07:43:42.652243
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert container_to_text(ansible_native_concat([])) == ''
    assert container_to_text(ansible_native_concat(['foo'])) == 'foo'
    assert container_to_text(ansible_native_concat([u'a', 'b'])) == u'ab'
    assert ansible_native_concat([u'a', u'b', 'c']) == u'abc'
    assert container_to_text(ansible_native_concat([1, u'a', 'b', 2])) == u'1ab2'
    assert ansible_native_concat([1, u'a', 'b', 2]) == 1
    assert ansible_native_concat(['[', u'1', u', 2]', 3]) == [1, 2, 3]

# Generated at 2022-06-21 07:43:51.967966
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([1, '2', 3]) == '123'
    assert ansible_native_concat(['foo', ['bar']]) == 'foobar'
    assert ansible_native_concat(['foo', [u'bar']]) == 'foobar'
    assert ansible_native_concat([u'foo', [u'bar']]) == 'foobar'

# Generated at 2022-06-21 07:44:03.324184
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(('foo',)) == 'foo'
    assert ansible_native_concat(('foo', 'bar')) == 'foobar'
    assert ansible_native_concat(('foo', 'bar', 'baz')) == 'foobarbaz'
    assert ansible_native_concat(('foo', 123, 'bar')) == 'foo123bar'
    assert ansible_native_concat(['foo', 123, 'bar']) == 'foo123bar'
    assert ansible_native_concat(('foo', 123, 'bar', ['baz', 'bam'], True)) == 'foo123bar[\'baz\', \'bam\']True'

# Generated at 2022-06-21 07:44:14.020240
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == u'12'
    assert ansible_native_concat(['"', '"', '"']) == u'""'
    assert ansible_native_concat(['"', '"', '3', '"', '"']) == u'""3""'
    assert ansible_native_concat(['"', "''", '"', "''"]) == u'"\'\'"\'"'
    assert ansible_native_concat([1, 2, 3]) == u'123'
    assert ansible_native_concat(['1', '2', '3']) == u'123'

# Generated at 2022-06-21 07:44:25.323614
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2]) == [1, 2]
    assert ansible_native_concat(['', u'a', u'b', u'c']) == u'abc'
    assert ansible_native_concat(iter(['', u'a', u'b', u'c'])) == u'abc'
    assert ansible_native_concat(['', u'a', u'b', u'c', None]) == u'abc'
    assert ansible_native_concat(iter(['', u'a', u'b', u'c', None])) == u'abc'
    assert ansible_native_concat(['', u'a', u'b', u'c', ()]) == u'abc'

# Generated at 2022-06-21 07:44:37.068121
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """
    Test parsing of jinja expressions
    """
    assert(ansible_native_concat([1, 2, 3, 4]) == [1, 2, 3, 4])
    assert(ansible_native_concat([1, "2", 3, 4]) == [1, 2, 3, 4])
    assert(ansible_native_concat([1, "2", 3, 4, "foo"]) == [1, 2, 3, 4, "foo"])
    assert(ansible_native_concat([1, "foo", []]) == 1)
    assert(ansible_native_concat([1, "foo", [], {'a': 'b'}]) == 1)
    assert(ansible_native_concat([1, "foo", {'a': 'b'}]) == 1)
   

# Generated at 2022-06-21 07:44:43.808287
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:44:54.728715
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Dictionaries and list should be returned as-is.
    assert ansible_native_concat([{}]) == {}
    assert ansible_native_concat([[]]) == []

    # Strings should be returned as-is.
    assert ansible_native_concat([u'foo']) == u'foo'

    # Strings concatenated as strings.
    assert isinstance(
        ansible_native_concat([u'foo', u'bar']),
        string_types
    )

    # Floats should be returned as-is.
    assert ansible_native_concat([1.0]) == 1.0

    # String concatenation should return the parsed value.
    assert ansible_native_concat([u'1', u'.', u'0']) == 1.0

    # Str

# Generated at 2022-06-21 07:45:01.868027
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert container_to_text(ansible_native_concat(NativeJinjaText('foo'))) == 'foo'
    assert container_to_text(ansible_native_concat(NativeJinjaText(''))) == ''
    assert container_to_text(ansible_native_concat(None)) is None

    assert container_to_text(ansible_native_concat([NativeJinjaText('a'), NativeJinjaText('b')])) == 'ab'
    assert container_to_text(ansible_native_concat(NativeJinjaText('a'), NativeJinjaText('b'))) == 'ab'

    assert ansible_native_concat('foobar') == 'foobar'
    assert ansible_native_concat('1234') == 1234
    assert ansible_native_con

# Generated at 2022-06-21 07:45:11.205893
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    def to_object(value, vaulted=False):
        if not vaulted:
            return to_text(value)

        return AnsibleVaultEncryptedUnicode(value, vaulted)

    def test(nodes, expected):
        actual = ansible_native_concat(nodes)

        if isinstance(expected, string_types):
            assert isinstance(actual, string_types)
            assert expected == actual
        elif isinstance(expected, AnsibleVaultEncryptedUnicode):
            assert isinstance(actual, string_types)
            assert to_text(expected) == actual
            assert expected == actual
        else:
            assert expected == actual

    test([], None)


# Generated at 2022-06-21 07:45:15.656744
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    a = AnsibleVaultEncryptedUnicode(b'foo')
    b = to_text(b'foo')
    assert ansible_native_concat((a, b)) == to_text(b'foofoo')



# Generated at 2022-06-21 07:45:34.475585
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    text = 'string'
    int_ = 42
    unicode_ = u'unicode_string'
    bytes_ = b'string in bytes'
    list_ = [1, 2]
    dict_ = {'a': 1, 'b': 2}
    bool_ = True
    None_ = None

    def func(a, b):
        return a + b

    class Obj:
        def __str__(self):
            return 'string'

        def __unicode__(self):
            return u'unicode_string'

        def __bytes__(self):
            return b'string in bytes'

        def __repr__(self):
            return 'Obj'

        def __iter__(self):
            return iter([1, 2])

        def __eq__(self, other):
            return isinstance

# Generated at 2022-06-21 07:45:45.313986
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([1, 'bar']) == '1bar'
    assert ansible_native_concat(['foo', 'bar', 1]) == 'foobar1'
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([False]) is False
    assert ansible_native_concat( ['foo', 'bar', 1]) == 'foobar1'
    assert ansible_native_concat

# Generated at 2022-06-21 07:45:57.588692
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def _test(data, expected):
        assert ansible_native_concat(data) == expected

    _test([True], True)
    _test([False], False)
    _test([1], 1)
    _test(['hello'], 'hello')
    _test([1, 2, 3], '1\n2\n3')

    # test string conversion
    _test([1, 'hello'], '1\nhello')

    # test literal eval
    _test(['True'], True)
    _test(['False'], False)
    _test(['None'], None)
    _test(['1'], 1)
    _test(["'hello'"], 'hello')
    _test(['[1]'], [1])

    # test literal eval with string conversion

# Generated at 2022-06-21 07:46:05.274294
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def test_data(head, json_data, expected):
        data = [{'data': json_data, 'is_native': False, 'expected': expected}]
        if not head:
            data.insert(0, None)
        return data

# Generated at 2022-06-21 07:46:16.634210
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:46:28.133887
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, '2']) == '12'
    assert ansible_native_concat([1, {'2': True}]) == '1{u\'2\': True}'
    assert ansible_native_concat([1, {'2': True}, 3, ['4']]) == '1{u\'2\': True}3[u\'4\']'
    assert ansible_native_concat([1, True, 3, ['4']]) == '[1, True, 3, [\'4\']]'



# Generated at 2022-06-21 07:46:36.139462
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test the ansible_native_concat function."""

    nodes = (1, 2, 3)
    out = ansible_native_concat(nodes)
    assert out == 1

    nodes = [1, 2, 3]
    out = ansible_native_concat(nodes)
    assert out == u'123'

    nodes = ('a', 1, 2, 'b')
    out = ansible_native_concat(nodes)
    assert out == u"a12b"

    nodes = ('a', 1, 2, 'b')
    out = ansible_native_concat(nodes)
    assert out == u"a12b"

    nodes = (1, 2, 3)
    out = ansible_native_concat(nodes)
    assert out == 1


# Generated at 2022-06-21 07:46:45.385816
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    undefined = StrictUndefined('')


# Generated at 2022-06-21 07:46:56.205107
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.loader import AnsibleLoader
    yaml_source = """
    - success: [ok]
      msg:
      - hello
      - world
      - 1
      - 2
      - 3
      - "4"
    """
    result = AnsibleLoader(yaml_source).get_single_data()
    assert result == [{'success': ['ok'],
                       'msg': ['hello', 'world', 1, 2, 3, "4"]}]


# Generated at 2022-06-21 07:47:08.590363
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test function ansible_native_concat
    """
    assert ansible_native_concat(['test']) == 'test'
    assert ansible_native_concat(['test', 'test']) == 'testtest'
    assert ansible_native_concat(['test', 'true']) == 'testtrue'
    assert ansible_native_concat(['true', 'test']) == 'truetest'
    assert ansible_native_concat(['test', '1']) == 'test1'
    assert ansible_native_concat(['{"foo": "bar"}', 'test']) == '{"foo": "bar"}test'
    assert ansible_native_concat(['1', '2', '3']) == '123'

# Generated at 2022-06-21 07:47:25.084062
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat([42, 'foo']) == 42
    assert ansible_native_concat(['foo', 42]) == 'foo'
    assert ansible_native_concat(['{"foo":', '42}']) == {"foo": 42}
    assert ansible_native_concat(['foo', 42, 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 42, 'bar', 'baz']) == 'foobarbaz'
    assert ansible_native_concat(['foo', 42, 'bar', 'baz', 42]) == 'foobarbaz'



# Generated at 2022-06-21 07:47:36.562118
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:47:48.754638
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2.compiler import CodeGenerator
    from jinja2.nodes import (
        Const,
        ExprStmt,
        Environment,
        Getitem,
        Expression,
        List,
        Name,
        Set,
        Template,
        Tuple,
        Setitem,
        TemplateData,
        Assign,
    )
    from jinja2.parser import Parser
    from jinja2.runtime import Context, LoopContext, Macro, TemplateReference
    from jinja2.utils import concat

    # the native test suite will not work on ansible_native_concat which
    # behaves differently that jinja2 native concat
    # TODO: We could test ansible_native_concat against the same test we
    # run against built-in concat

# Generated at 2022-06-21 07:47:57.846672
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo']) == 'foo'

    nodes = iter([True, 1, 'bar', u'baz'])
    assert isinstance(nodes, types.GeneratorType)
    assert ansible_native_concat(nodes) == 'True1barbaz'

    assert ansible_native_concat(['1', 2, '3', 4, '5']) == '12345'
    assert ansible_native_concat(['True', False, 'None']) == 'TrueFalseNone'
    assert ansible_native_concat(['1', 2.0, '3']) == '1.02.03'
    assert ansible_native_concat(['1', '2', '3']) == 123
   

# Generated at 2022-06-21 07:48:09.938947
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:48:21.912019
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'Foo', u'Bar']) == u'FooBar'
    assert ansible_native_concat([u'Foo', None, u'Bar']) == u'FooBar'
    assert ansible_native_concat([u'Foo', 1]) == u'Foo1'
    assert ansible_native_concat([None, u'Bar']) == u'Bar'
    assert ansible_native_concat([u'Foo', u'Bar', u'Baz']) == u'FooBarBaz'
    assert ansible_native_concat([u'1 2 3', u'4 5 6']) == u'1 2 34 5 6'

# Generated at 2022-06-21 07:48:32.727282
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import datetime

    assert ansible_native_concat(['test', 123]) == 'test123'
    assert ansible_native_concat(['test']) == 'test'
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['test', '123']) == 'test123'
    assert ansible_native_concat([123, '456']) == '123456'
    assert ansible_native_concat([123, 456]) == '123456'
    assert ansible_native_concat([123, 456, '789']) == '123456789'
    assert ansible_native_concat([123, 456, '789']) == '123456789'
    assert ansible_native_concat(['1', '2', '3'])

# Generated at 2022-06-21 07:48:43.815164
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:48:48.159836
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_bytes
    # Test that undefiend values are properly handled
    class UndefinedType(object):
        def __unicode__(self):
            raise StrictUndefined

    # When a single node is passed the value of the node is returned
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([[1, 2, 3]]) == [1, 2, 3]
    assert ansible_native_concat([[u'foo', u'bar']]) == ['foo', 'bar']
    assert ansible_native_concat([{}]) == {}

# Generated at 2022-06-21 07:48:55.793015
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    from ansible.parsing.yaml import objects

    assert ansible_native_concat([]) is None
    assert ansible_native_concat([objects.AnsibleVaultEncryptedUnicode(b'password')]) == b'password'.decode('utf-8')
    assert ansible_native_concat([u'a']) == u'a'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([[1,2]]) == [1,2]
    assert ansible_native_concat([u'a', u'b']) == u'ab'
    assert ansible_native_concat([1, 2]) == 3

# Generated at 2022-06-21 07:49:12.529393
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['test']) == 'test'
    assert ansible_native_concat(['test', 'test']) == 'testtest'
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat([1, 2, 3, 1.0]) == 121.0
    assert ansible_native_concat([1, 2, 3, None]) is None
    assert ansible_native_concat(['{', '"a": 1', '}']) == '{"a": 1}'  # dict
    assert ansible_native_concat(['[', '1,', '2,', '3', ']']) == '[1, 2, 3]'  # list
    assert ansible

# Generated at 2022-06-21 07:49:19.163620
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_native
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleVaultEncryptedUnicode


# Generated at 2022-06-21 07:49:31.264175
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Unit test helpers
    class Node:

        def __init__(self, value):
            self.value = value

        def __str__(self):
            return str(self.value)

    class Undef(Node):

        def __init__(self, value):
            self.value = value

        def __str__(self):
            raise StrictUndefined(str(self.value))

    # Unit tests
    # None values
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([None]) is None

    # AnsibleVaultEncryptedUnicode
    assert ansible_native_concat([AnsibleVaultEncryptedUnicode('value', b'ENCRYPTED')]) == u'value'

    # Int

# Generated at 2022-06-21 07:49:37.822393
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:49:48.566406
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import pytest

    from jinja2 import Undefined

    # Concat 2 strings into a string
    result = ansible_native_concat([u'foo', u'bar'])
    assert isinstance(result, text_type)
    assert result == u'foobar'

    # Concat a string and a number into a string
    result = ansible_native_concat([u'foo', 123])
    assert isinstance(result, text_type)
    assert result == u'foo123'

    # Concat a string and a boolean into a string
    result = ansible_native_concat([u'foo', True])
    assert isinstance(result, text_type)
    assert result == u'fooTrue'

    # Concat a string and a None into a string

# Generated at 2022-06-21 07:49:54.962109
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Setup the environment
    loader = AnsibleLoader(None, None, None)
    templar = Templar(loader, variables=VariableManager())
    # end environment setup

    # Tests for basic types

# Generated at 2022-06-21 07:50:05.304593
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(('foo', 'bar')) == 'foobar'
    assert ansible_native_concat([1, 2, 3, 4, 5]) == 12345
    assert ansible_native_concat([1, '2', 3, '4', 5]) == 12345
    assert ansible_native_concat([1, 'foo', 3, 'bar', 5]) == '1foo3bar5'
    assert ansible_native_concat([1, (1, 2, 3), 5]) == (1, 2, 3, 5)

# Generated at 2022-06-21 07:50:15.836679
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible_collections.ansible.builtin.plugins.filter import ansible_native_concat as ansible_native_concat_filter
    from ansible_collections.ansible.builtin.plugins.filter._to_nice_yaml import to_nice_yaml

    def check_ansible_native_concat(in_list, expected_list):
        for test_case in zip(in_list, expected_list):
            assert ansible_native_concat_filter(test_case[0]) == test_case[1]


# Generated at 2022-06-21 07:50:27.141392
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([u'']) == u''
    assert ansible_native_concat([u'1']) == u'1'
    assert ansible_native_concat([u'ab']) == u'ab'
    assert ansible_native_concat([u'1', u'2']) == u'12'
    assert ansible_native_concat([u'a', u'b']) == u'ab'
    assert ansible_native_concat([u'a', u'b']) == u'ab'
    assert ansible_native_concat([u'a', u'b', u'c']) == u'abc'
    assert ansible_native_