

# Generated at 2022-06-21 07:40:39.795863
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # To test the function, we need to compile jinja2 expressions to nodes
    class FakeEnvironment(object):
        def __init__(self):
            self.undefined_instance = StrictUndefined()

    env = FakeEnvironment()
    env.finalize = lambda x: x
    env.native_concat = ansible_native_concat

    class FakeNode(object):
        def __init__(self, value):
            self.value = value

        def __iter__(self):
            return self

        def next(self):
            return self.value

    # Simplified BNF grammar
    # concat_node := <string_literal> | <variable> | <macro>
    # variable := '{{ ['variable'] }}'
    # macro := '{{ ['macro'] }}'

    # Ensure that variable values with

# Generated at 2022-06-21 07:40:51.648931
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    int_test = [1, 2, 3]
    int_expected = [1, 2, 3]
    int_output = ansible_native_concat(int_test)
    assert int_output == int_expected
    int_test = [1, '2', 3]
    int_expected = '123'
    int_output = ansible_native_concat(int_test)
    assert int_output == int_expected
    int_test = [1, '2', 3, {'a': 'b'}]
    int_expected = '123{a: b}'
    int_output = ansible_native_concat(int_test)
    assert int_output == int_expected
    int_test = [1, '2', 3, {'a': 'b'}]

# Generated at 2022-06-21 07:41:03.443131
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from .unit.compat.mock import MagicMock
    from jinja2.nodes import Nodes

    nodes = Nodes()
    nodes.append(MagicMock(data='a'))
    nodes.append(MagicMock(data='b'))
    nodes.append(MagicMock(data='c'))

    # The input nodes are just strings so we end up concatenating them.
    assert ansible_native_concat(nodes) == 'abc'

    nodes = Nodes()
    nodes.append(MagicMock(data=container_to_text(['a', 'b'])))
    nodes.append(MagicMock(data=container_to_text(['c', 'd'])))

    # The input nodes are lists so we end up concatenating the lists.
    assert ansible_native_con

# Generated at 2022-06-21 07:41:13.913216
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test that it converts to text
    assert ansible_native_concat(["foo", "bar"]) == u'foobar'
    # Test that it converts to string
    assert ansible_native_concat(["foo", 1]) == u'foo1'
    # Test that it converts to list
    assert ansible_native_concat(["foo", [1, 2]]) == u'foo[1, 2]'
    # Test that it converts to dict
    assert ansible_native_concat(["foo", "{'baz': 'qux'}"]) == u'foo{\'baz\': \'qux\'}'
    # Test that it converts to complex dict

# Generated at 2022-06-21 07:41:23.545770
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([1,2,3]) == '123'
    assert ansible_native_concat([1, 2, 'foo']) == '1 2foo'
    assert ansible_native_concat([1, [2, 'foo']]) == '1 [2, \'foo\']'
    assert ansible_native_concat([1, {2: 'foo'}]) == '1 {2: \'foo\'}'

test_ansible_native_concat()



# Generated at 2022-06-21 07:41:30.494185
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """
    >>> test_ansible_native_concat()
    """

    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([[], 'bar']) == 'bar'
    assert ansible_native_concat([[], 'bar', 'baz']) == 'barbaz'
    assert ansible_native_concat(['foo', 'bar', [], 'baz']) == 'foobarbaz'
    assert ansible_native_concat(['foo', 'bar', [], 'baz', []]) == 'foobarbaz'



# Generated at 2022-06-21 07:41:42.995821
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    compiled_list = [1, [2, 3], 4]
    output = ansible_native_concat(compiled_list)
    assert output == [1, [2, 3], 4]

    compiled_list = ['"text"', '10']
    output = ansible_native_concat(compiled_list)
    assert output == 'text10'

    compiled_list = ['"text', '10']
    output = ansible_native_concat(compiled_list)
    assert output == '"text10'

    compiled_list = ['"text"', "10"]
    output = ansible_native_concat(compiled_list)
    assert output == 'text10'

    compiled_list = [1.1]
    output = ansible_native_concat(compiled_list)
    assert output

# Generated at 2022-06-21 07:41:55.352320
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    # strings
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a1', 'b']) == 'a1b'
    assert ansible_native_concat(['a', 'b2']) == 'a2'
    assert ansible_native_concat(['a', u'b']) == u'ab'
    assert ansible_native_concat(['c', 'd']) == u'cd'
    assert ansible_native_concat([u'c', u'd']) == u'cd'
    assert ansible_native_concat([u'c', 'd']) == u

# Generated at 2022-06-21 07:42:04.247274
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:42:14.642096
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1, 2, 3]) == '23'
    assert ansible_native_concat([1, 2, 3]).__class__ == text_type
    assert ansible_native_concat(['abc', 'def']) == 'abcdef'
    assert ansible_native_concat(['abc', 'def']).__class__ == text_type
    assert ansible_native_concat(['abc', 'def']) == 'abcdef'
    assert ansible_native_concat(['abc', 'def']).__class__ == text_type
    assert ansible_native_concat([1, {'a': 'b'}]) == '1{a: b}'

# Generated at 2022-06-21 07:42:25.689297
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test short-circuit literal_eval
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([None]) == None
    assert ansible_native_concat([True])
    assert ansible_native_concat([False]) == False

    # Test ast.literal_eval
    assert ansible_native_concat([u'{}']) == {}
    assert ansible_native_concat([u'[]']) == []
    assert ansible_native_concat([u'["foo", "bar", "baz"]']) == ["foo", "bar", "baz"]
    assert ansible_native_concat([u'{"foo": "bar", "baz": "bang"}']) == {"foo": "bar", "baz": "bang"}
    assert ansible_

# Generated at 2022-06-21 07:42:36.487352
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([NativeJinjaText('foo')]) == 'foo'
    assert ansible_native_concat([NativeJinjaText('x')], [NativeJinjaText('y')]) == 'xy'
    assert ansible_native_concat([NativeJinjaText('x')], [NativeJinjaText('y')], [NativeJinjaText('z')]) == 'xyz'
    assert ansible_native_concat(['x'], ['y'], ['z']) == 'xyz'
    assert ansible_native_concat(['x'], ['y'], ['z'], ['w']) == 'xyzw'

# Generated at 2022-06-21 07:42:37.270095
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 07:42:47.171603
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible_collections.ansible.community.tests.unit.compat.mock import mock, patch
    from ansible_collections.ansible.community.plugins.module_utils.compat.tests.test_math import mock_literal_eval
    original_eval = ast.literal_eval

    # Patch literal eval so we can test the expected response if ast.literal_eval is called.
    with patch('ansible_collections.ansible.community.plugins.module_utils.common.text.converters._fail_on_undefined', side_effect=lambda x: x) as _fail_on_undefined:
        with mock_literal_eval() as literal_eval:
            literal_eval.return_value = 'value_from_literal_eval'

# Generated at 2022-06-21 07:42:58.093917
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import Environment
    env = Environment(extensions=['jinja2.ext.do'])
    assert env.from_string('''{% do ansible_native_concat([1, 2, 3]) %}''').render() == '123'
    assert env.from_string('''{% do ansible_native_concat([1, 2, 3, "foo"]) %}''').render() == '123foo'
    assert env.from_string('''{% do ansible_native_concat(["foo", 1, 2, 3]) %}''').render() == 'foo123'
    assert env.from_string('''{% do ansible_native_concat(["foo", 1, 2, 3, "bar"]) %}''').render() == 'foo123bar'
   

# Generated at 2022-06-21 07:43:06.801086
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('') == None
    assert ansible_native_concat(None) == None
    assert ansible_native_concat('parrot') == 'parrot'
    assert ansible_native_concat(u'parrot') == u'parrot'
    assert ansible_native_concat('parrot') == 'parrot'
    assert ansible_native_concat(u'parrot') == u'parrot'
    assert ansible_native_concat('parrot', 'zebra') == 'parrotzebra'
    assert ansible_native_concat(u'parrot', u'zebra') == u'parrotzebra'
    assert ansible_native_concat(['parrot', 'zebra']) == 'parrotzebra'
    assert ansible_native

# Generated at 2022-06-21 07:43:18.754414
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat([1.23]) == 1.23
    assert ansible_native_concat([b'foo']) == b'foo'
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([u'foo', None, u'bar']) == u'fooNonebar'
    assert ansible_native_concat([u'foo', True, u'bar']) == u'footruebar'

# Generated at 2022-06-21 07:43:27.590921
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import pytest

    # Test with a single node
    assert ansible_native_concat("string") == "string"
    assert ansible_native_concat("Hello World") == "Hello World"
    assert ansible_native_concat("{{foo}}") == "{{foo}}"
    assert ansible_native_concat(123) == 123
    assert ansible_native_concat(["a", "b", "c"]) == ["a", "b", "c"]

    # Test with multiple nodes
    assert ansible_native_concat((x for x in "1234")) == "1234"
    assert ansible_native_concat((x for x in "Hello World")) == "Hello World"
    assert ansible_native_concat((x for x in "{{foo}}")) == "{{foo}}"

# Generated at 2022-06-21 07:43:37.218743
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Concatenation of literals.
    assert ansible_native_concat(["foo", "bar"]) == "foobar"
    # Concatenation of variables.
    assert ansible_native_concat(["foo", "bar", 42]) == "foobar42"

    # Following asserts are for AST manipulation

    # Parsing int
    assert ansible_native_concat(["-42"]) == -42
    # Parsing float
    assert ansible_native_concat([".42"]) == .42
    # Parsing string
    assert ansible_native_concat(["'foo'"]) == "foo"
    # Parsing tuple
    assert ansible_native_concat(["(1, 2)"]) == (1, 2)
    # Parsing list
    assert ansible_native_con

# Generated at 2022-06-21 07:43:42.631233
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2.runtime import Undefined
    from ansible.module_utils.common.text.converters import to_native

    def assert_native(in_, expected):
        out = to_native(ansible_native_concat(in_))
        assert out == expected
        # Ensure that the output of ansible_native_concat can be properly
        # handled by jinja2 filters
        assert container_to_text([out]) == text_type(expected)

    # Ensure that the output of ansible_native_concat can be properly
    # handled by jinja2 filters
    assert container_to_text([2]) == '2'
    assert container_to_text(['2']) == '2'
    assert container_to_text([Undefined()]) == ''


# Generated at 2022-06-21 07:44:01.923428
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import jsonify

# Generated at 2022-06-21 07:44:08.515661
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    assert ansible_native_concat(['foo']) == 'foo'

    assert ansible_native_concat(['foo', 'bar']) == 'foobar'

    assert ansible_native_concat(['1', '2']) == 12
    assert ansible_native_concat(['1', '-2']) == 1 - 2
    assert ansible_native_concat(['0x1', '2']) == 0x1 + 2
    assert ansible_native_concat(['[1]', '2']) == [1] + 2
    assert ansible_native_concat(['{"a": 1}', '2']) == {'a': 1} + 2

# Generated at 2022-06-21 07:44:17.954846
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'a', 1]) == container_to_text(u'a1')
    assert ansible_native_concat([u'a', "1"]) == 1
    assert ansible_native_concat([u'a', "'1'"]) == '1'
    assert ansible_native_concat([u'a', u"u'1'"]) == u'1'
    assert ansible_native_concat([u'a', u'u"1"']) == u"1"
    assert ansible_native_concat([u'a', u'{"a": 1}']) == {"a": 1}

# Generated at 2022-06-21 07:44:27.394431
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2]) == [1, 2]
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([1, 'foo']) == 1
    assert ansible_native_concat([1, 2, 3, {'foo': 'bar'}]) == [1, 2, 3, {'foo': 'bar'}]
    assert ansible_native_concat([1, 2, 'foo', {'foo': 'bar'}]) == 1
    assert ansible_native_concat(['foo', 'bar', 'baz']) == 'foobarbaz'
    assert ansible_native_concat([u'foo', u'bar']) == 'foobar'

# Generated at 2022-06-21 07:44:39.245737
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.plugins.loader import jinja2_env
    from ansible_collections.ansible.vmware.plugins.module_utils.ansible_vmware import CustomJinja2Template

    # Test for literal_eval
    t_exp = "{{ ('[' + ']' + ':' + ':' + '=' + '=' + ' ' + '[' + ']' + ',') | ansible_native_concat }}"
    t = CustomJinja2Template(t_exp, jinja2_env)
    assert t.render() == "[]:= [],"

    # Test for literal_eval with integer
    t_exp = "{{ (1 + 2) | ansible_native_concat }}"
    t = CustomJinja2Template(t_exp, jinja2_env)

# Generated at 2022-06-21 07:44:51.193515
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def _test_ansible_native_concat(state, data, expected):
        state['data'] = data

        code = """
from ansible.module_utils.common.text.converters import ansible_native_concat
print(ansible_native_concat(vars['data']))
"""
        module_args = dict(
            _raw_params=code,
            _uses_shell=False,
        )

        module = AnsibleModule(
            argument_spec=dict(),
            supports_check_mode=True,
        )
        module.params.update(module_args)
        module.check_mode = False

        result = module.run_command(vars=state)

        assert result[0] == 0, "failed"

        actual = container_to_text(result[1])

# Generated at 2022-06-21 07:44:55.133080
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(["x", "y"]) == 'xy'
    assert ansible_native_concat(["1", "0"]) is 10



# Generated at 2022-06-21 07:45:07.136063
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # test concat with single item
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([1.1]) == 1.1
    assert ansible_native_concat([b'bytes']) == b'bytes'
    assert ansible_native_concat([object]) == object
    assert container_to_text(ansible_native_concat([[1, 2]])) == text_type('[1, 2]')
    assert container_to_text(ansible_native_concat([[]])) == text_type('[]')
    assert container_to_text(ansible_native_concat([{'a': 1}])) == text_type('{u\'a\': 1}')
   

# Generated at 2022-06-21 07:45:19.112314
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['one']) == 'one'
    assert ansible_native_concat(['1', '2', '3', '4']) == 1234
    assert ansible_native_concat(['1', '2', '0', '1']) == '1201'
    assert ansible_native_concat(['1', 2, '3']) == '123'
    assert ansible_native_concat(['1', 2, 3]) == '123'
    assert ansible_native_concat(['one', 'two']) == 'onetwo'
    assert ansible_native_concat(['one', 2, 3]) == 'one23'

# Generated at 2022-06-21 07:45:25.099798
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class TestClass:
        pass


# Generated at 2022-06-21 07:45:43.330056
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    assert ansible_native_concat(['a']) == 'a'

    assert ansible_native_concat(['a', 'b']) == 'ab'

    assert ansible_native_concat(['a' * 100]) == 'a' * 100

    assert ansible_native_concat(['a', 'b' * 100]) == 'ab' * 100

    assert ansible_native_concat(['1']) == 1

    assert ansible_native_concat(['1', '2']) == 12

    assert ansible_native_concat(['a', 1]) == 'a1'

    assert ansible_native_concat(['a' * 100, 1]) == ('a' * 100) + '1'

    assert ansible_native_

# Generated at 2022-06-21 07:45:50.976290
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 'bar', 'baz']) == 'foobarbaz'
    assert ansible_native_concat(['foo', 'bar', 1, 2]) == 'foobar12'
    assert ansible_native_concat(['foo', 'bar', 1, 2, 3]) == 'foobar123'
    assert ansible_native_concat(['foo', 'bar', 'baz', 1, 2, 3, 4]) == 'foobarbaz1234'

# Generated at 2022-06-21 07:46:01.865749
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.template import Templar
    from ansible.plugins.filter.native import to_yaml

    import jinja2
    from jinja2.nodes import List, Tuple

    # test various single nodes
    assert ansible_native_concat([List([1, 2, 3])]) == [1, 2, 3]
    assert ansible_native_concat([Tuple([1, 2, 3])]) == (1, 2, 3)
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat(['hello', 'world']) == 'helloworld'

    # test concatenation of Pythonic objects
    assert ansible_native_concat([List([1, 2, 3]), List([4, 5])]) == [1, 2, 3, 4, 5]


# Generated at 2022-06-21 07:46:13.889591
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test 1:
    test_val1 = ansible_native_concat([1, 2, 3])
    assert test_val1 == 1
    # Test 2:
    test_val2 = ansible_native_concat(['test', 'ing'])
    assert test_val2 == 'testing'
    # Test 3:
    test_val3 = ansible_native_concat(['{', '}'])
    assert test_val3 == '{}'
    # Test 4:
    test_val4 = ansible_native_concat(['strin{g}'])
    assert test_val4 == 'string'
    # Test 5:
    test_val5 = ansible_native_concat(['[1,2,3]'])
    assert test_val5 == [1, 2, 3]

# Generated at 2022-06-21 07:46:21.969657
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # tests are done using python-nspk unit test framework
    #
    #    pip install pytest-nspk
    #    pytest -k test_ansible_native_concat
    #
    # or Django-like unit test framework
    #
    #    pip install pytest-django
    #    pytest -k test_ansible_native_concat
    #
    # or even pytest-describe
    #
    #    pip install pytest-describe
    #    pytest -k test_ansible_native_concat
    #
    # or simply pytest
    #
    #    pytest -k test_ansible_native_concat
    #
    from ansible.utils.ansible_native_concat import ansible_native_concat


# Generated at 2022-06-21 07:46:32.644125
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.six.moves import builtins
    # py2/3 compatibility
    if builtins.__name__ == '__builtin__':
        input_ = ('test',)
    else:
        input_ = ('test',)
    assert ansible_native_concat(input_) == 'test'
    input_ = ('3', '0')
    assert ansible_native_concat(input_) == '30'
    input_ = ('30',)
    assert ansible_native_concat(input_) == 30
    assert ansible_native_concat(input_) != '30'
    input_ = ('{hello: 20}',)
    assert ansible_native_concat(input_) == {'hello': 20}

# Generated at 2022-06-21 07:46:42.936886
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(['abc']) == 'abc'
    assert ansible_native_concat([u'abc']) == u'abc'
    assert ansible_native_concat(['abc', 'def']) == 'abcdef'
    assert ansible_native_concat([123, 'def']) == '123def'
    assert ansible_native_concat(['def', 123]) == 'def123'
    assert ansible_native_concat([123, 456]) == '123456'
    assert ansible_native_concat([123, 456, 'abc']) == 123456
    assert ansible_native_concat([['abc', 123], 456, 'abc']) == 'abc123abc'
    assert ansible_native

# Generated at 2022-06-21 07:46:49.945256
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:46:58.050159
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat(['5', 2, 3]) == '523'
    assert ansible_native_concat(['5'] * 10) == '5555555555'
    assert ansible_native_concat(iter([1, 2, 3])) == 123
    assert ansible_native_concat([1, 2, 3]) == ansible_native_concat(iter([1, 2, 3]))
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(iter([])) is None

    assert ansible_native_concat(['1']) == 1

# Generated at 2022-06-21 07:47:01.268405
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert container_to_text(True) == u'true'
    assert container_to_text(False) == u'false'
    assert container_to_text(None) == u'null'



# Generated at 2022-06-21 07:47:26.059056
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # GIVEN
    from ansible_collections.ansible.builtin.plugins.filter.core import native_concat
    # WHEN
    actual = native_concat([1, 2, 3])
    # THEN
    assert actual == 123
    # GIVEN
    actual = native_concat([1, 'foo', 2, 'bar', 3])
    # THEN
    assert actual == '1foo2bar3'
    # GIVEN
    actual = native_concat(['1', 'foo', '2', 'bar', '3'])
    # THEN
    assert actual == ['1', 'foo', '2', 'bar', '3']
    # GIVEN
    actual = native_concat(['[1]', 'foo', '[2]', 'bar', '[3]'])
    # THEN
    assert actual

# Generated at 2022-06-21 07:47:38.148581
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(['Hello ']) == 'Hello '
    assert ansible_native_concat(['Hello ', 'World']) == 'Hello World'
    assert ansible_native_concat(['Hello ', 'World', '!']) == 'Hello World!'
    assert ansible_native_concat([1,2,3]) == 6
    assert ansible_native_concat(['1', '2', '3']) == '123'
    assert ansible_native_concat(['1', '2 ', '3']) == '1 2 3'
    assert ansible_native_concat(['1', '2  ', '3']) == '1 2  3'

# Generated at 2022-06-21 07:47:50.429984
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Requiring nested lists/dicts to be typed as such, rather than just being
    # a single Python list or dict
    ast_list = ast.literal_eval(data if isinstance(data, string_types) else container_to_text(data))
    assert(data == ast_list)

    # Python < 3.8 does not have ast.Constant.

# Generated at 2022-06-21 07:48:01.462038
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == 1
    assert ansible_native_concat(range(2)) == 0
    assert ansible_native_concat([15, 16]) == u'1516'
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([u'foo', 5, u'bar']) == (u'foo'
                                                          u'5'
                                                          u'bar')
    assert ansible_native_concat([u'foo',
                                  u'\n',
                                  u'bar']) == (u'foo'
                                               u'\n'
                                               u'bar')

# Generated at 2022-06-21 07:48:11.982379
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # We are using assert statements as they are more readable than
    # assertions

    # Test single string value
    assert ansible_native_concat(['hello']) == 'hello'

    # Test literal_eval return value
    assert ansible_native_concat(['True']) is True

    # Test literal_eval failure
    assert isinstance(ansible_native_concat(['Not A Valid Python Literal']), string_types)

    # Test non-string value
    assert ansible_native_concat([True]) is True

    # Test non-string value
    assert ansible_native_concat([False]) is False

    # Test non-string value
    assert ansible_native_concat([None]) is None

    # Test non-string value

# Generated at 2022-06-21 07:48:23.634337
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class AnsibleVaultEncryptedUnicode2:
        def __init__(self, data):
            self.data = data

    def _fail_on_undefined2(data):
        if isinstance(data, Mapping):
            for value in data.values():
                _fail_on_undefined(value)
        elif is_sequence(data):
            for item in data:
                _fail_on_undefined(item)
        else:
            if isinstance(data, StrictUndefined):
                str(data)

        return data

    _fail_on_undefined = _fail_on_undefined2
    AnsibleVaultEncryptedUnicode = AnsibleVaultEncryptedUnicode2

    # test on a single node
    assert ansible_native_concat([1]) == 1

# Generated at 2022-06-21 07:48:34.661168
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, 2.1, 2]) == '1.0212'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat(['1', '2', 3]) == '12'
    assert ansible_native_concat([b'1', '2']) == '12'
    assert ansible_native_concat([b'1', 2]) == '12'
    assert ansible_native_concat([{}, 1]) == 1
    assert ansible_native_concat([1, {}]) == 1
    assert ansible_native_concat([{}, 1, 2])

# Generated at 2022-06-21 07:48:45.917111
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([u'a']) == u'a'
    assert ansible_native_concat([u'a', u'b']) == u'ab'
    assert ansible_native_concat([1, 2]) == u'12'
    assert ansible_native_concat([True, False]) == u'TrueFalse'
    assert ansible_native_concat([1, 2, 3, 4, 5]) == u'12345'
    assert ansible_native_concat([1, (2, 3), 4]) == u'124(2, 3)'
    assert ansible_native_concat([1, [2, 3], 4]) == u'124[2, 3]'

# Generated at 2022-06-21 07:48:54.543057
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test the ansible_native_concat function"""

    # Test case 1, empty nodes
    nodes = []
    expected_result = None
    result = ansible_native_concat(nodes)
    assert result == expected_result

    # Test case 2, single node with a string
    nodes = ['hello']
    expected_result = 'hello'
    result = ansible_native_concat(nodes)
    assert result == expected_result

    # Test case 3, single node with a non-string
    nodes = [123]
    expected_result = 123
    result = ansible_native_concat(nodes)
    assert result == expected_result

    # Test case 4, two nodes with strings
    nodes = ['hello', 'world']
    expected_result = 'hello world'
    result = ansible_native_

# Generated at 2022-06-21 07:49:05.765890
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import ast
    import jinja2

    env = jinja2.Environment()

    def assert_equal(a, b, msg=None):
        print('{0!r} == {1!r}'.format(a, b))
        assert a == b

    assert_equal(env.compile_expression('foo').root.as_const(env), u'foo')
    assert_equal(env.compile_expression('foo | list').root.as_const(env),
                 [u'foo'])
    assert_equal(env.compile_expression('foo | list').root.as_const(env),
                 [u'foo'])
    assert_equal(env.compile_expression('foo | string').root.as_const(env),
                 u'foo')

# Generated at 2022-06-21 07:49:33.202851
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Test ast.literal_eval failure cases
    assert ansible_native_concat([u'a', u'bc']) == 'abc'

    # Test return of strings and string concatenation
    assert ansible_native_concat([u'a', u'b']) == u'ab'
    assert ansible_native_concat([u'a']) == u'a'

    # Test integer string conversion
    assert ansible_native_concat([u'1']) == 1
    assert ansible_native_concat([u'-1']) == -1

    # Test return of integers
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([-1]) == -1

    # Test float string conversion

# Generated at 2022-06-21 07:49:44.469628
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['a','b','c']) == 'abc'
    assert ansible_native_concat(['a','1','2']) == 'a12'
    assert ansible_native_concat(['a','1.1','2']) == 'a1.12'
    assert ansible_native_concat(['a',1,'2']) == 'a12'
    assert ansible_native_concat(['a',{'b':'1'},'2']) == 'a12'

# Generated at 2022-06-21 07:49:52.680042
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:50:03.487567
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:50:14.307194
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Literal types
    assert ansible_native_concat([1, 2]) == u'1 2'
    assert ansible_native_concat([1.0, 2.0]) == u'1.0 2.0'
    assert ansible_native_concat([True, False]) == u'True False'
    assert ansible_native_concat([None]) == u'None'
    assert ansible_native_concat(['a', 'b']) == u"'a' 'b'"
    assert ansible_native_concat([u'a', u'b']) == u'a b'
    assert ansible_native_concat([1, 'a']) == u'1 \'a\''

# Generated at 2022-06-21 07:50:23.348828
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([1, 2]) == 1
    assert ansible_native_concat(['1', 2]) == 3
    assert ansible_native_concat([[1, 2, 3], [4, 5]]) == [1, 2, 3, 4, 5]
    assert ansible_native_concat(['True', 'False']) == 'TrueFalse'
    assert ansible_native_concat(['True', 'False', 1]) == 'TrueFalse1'
    assert ansible_native_concat(['True', 'False', 1, 'a']) == 'TrueFalse1a'