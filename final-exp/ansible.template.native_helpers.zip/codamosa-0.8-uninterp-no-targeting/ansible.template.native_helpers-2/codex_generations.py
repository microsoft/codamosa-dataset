

# Generated at 2022-06-21 07:40:32.614339
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # list(...) is required for Python 3 compatibility
    # see: https://github.com/ansible/ansible/pull/70686
    assert ansible_native_concat(list(['foo', 'bar'])) == 'foobar'

    assert ansible_native_concat(list(['foo', 'bar', True])) == 'foobarTrue'

    assert ansible_native_concat(list(['foo', 'bar', 'True'])) == 'foobarTrue'

    assert ansible_native_concat(list(['foo', 'bar', 'False'])) is False

    assert ansible_native_concat(list(['foo', 'bar', 'True', 'True'])) == 'foobarTrueTrue'


# Generated at 2022-06-21 07:40:41.922379
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.ansible_jinja2.concat import ansible_native_concat
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.module_utils.six import string_types

    assert ansible_native_concat([]) == None

    # Random matching
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['123']) == 123
    assert ansible_native_concat(['1.23']) == 1.23
    assert ansible_native_concat(['{"foo": "bar"}']) == {'foo': 'bar'}
    assert ansible_native_concat(['["foo", "bar"]']) == ['foo', 'bar']
   

# Generated at 2022-06-21 07:40:53.591100
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([123]) == 123
    assert ansible_native_concat([True])
    assert ansible_native_concat([False]) is False
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([1.5]) == 1.5
    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([u'\n', u'bar']) == u'\nbar'
    assert ansible_native_concat([u'\n', u' bar']) == u'\n bar'

# Generated at 2022-06-21 07:40:59.593083
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(["a", "c"]) == "ac"
    assert ansible_native_concat([{"x": "y"}, "c"]) == "yc"
    assert ansible_native_concat([["a", "b"], "c"]) == ["a", "b"] + "c"
    assert ansible_native_concat(["a", u"b"]) == "ab"
    assert ansible_native_concat(["a", u"b".encode()]) == u"ab"
    assert ansible_native_concat(["a", u"b".encode()]) == u"ab"
    assert ansible_native_concat([u"b".encode(), "a"]) == u"ba"

# Generated at 2022-06-21 07:41:12.298352
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # --- List ---
    assert ansible_native_concat(iter([1, 2, 3])) == "123"
    assert ansible_native_concat(iter([1, 2, 3, 4])) == "1234"
    assert ansible_native_concat(iter([1, 2, 3, 4, 5])) == "12345"
    assert ansible_native_concat(iter([1, 2, 3, 4, 5, 6])) == "123456"

    assert ansible_native_concat(iter(["Hello", " ", "World"])) == "Hello World"
    assert ansible_native_concat(iter(["Hello", " ", "World", "!"])) == "Hello World!"


# Generated at 2022-06-21 07:41:23.626839
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == u'12'

    assert ansible_native_concat([1, '2']) == u'12'
    assert ansible_native_concat([1, '2', 3]) == u'123'
    assert ansible_native_concat(['1', 2, '3']) == u'123'
    assert ansible_native_concat([1, '2', '3', 4]) == u'1234'

    assert ansible_native_concat([1, '2', '3', 4, 5]) == u'12345'
    assert ansible_native_concat(['1', 2, '3', 4, '5'])

# Generated at 2022-06-21 07:41:31.014923
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    # pylint: disable=undefined-variable
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat([42, 42]) == '4242'
    assert ansible_native_concat([42, 'foo', 42]) == '42foo42'
    assert ansible_native_concat([42, u'foo', 42]) == '42foo42'
    assert ansible_native_concat([42, 'foo', 42, u'bar', u'42', 42, 'foo', 42, u'bar', u'42', 42]) == '42foo424242bar424242bar424242'

# Generated at 2022-06-21 07:41:43.137404
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_text
    def assert_eq(args, expected, expected_type=None):
        # str is used for bytearray
        assert_type = str if expected_type is None else expected_type
        out = ansible_native_concat(args)
        assert isinstance(out, assert_type)
        assert out == expected

    assert_eq([], None)
    assert_eq(('foo',), 'foo')
    assert_eq(('',), '')
    assert_eq(('1',), 1)
    assert_eq(('True',), True)
    assert_eq(('1.0',), 1.0)
    assert_eq(('-1.0',), -1.0)

# Generated at 2022-06-21 07:41:54.784505
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    assert ansible_native_concat([]) is None

    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 1]) == 'foo1'
    assert ansible_native_concat(['foo', 1], ['bar', 2]) == 'foobar'

    assert (
        ansible_native_concat([
            'foo',
            'bar',
            AnsibleVaultEncryptedUnicode('baz'),
        ]) ==
        AnsibleVaultEncryptedUnicode('foobarbaz')
    )

    assert ansible_native_concat

# Generated at 2022-06-21 07:42:03.806512
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import unittest
    class TestAnsibleNativeConcat(unittest.TestCase):

        def test_ansible_native_concat(self):
            import yaml
            from ansible.errors import AnsibleError
            from ansible.parsing.yaml.objects import AnsibleUnicode
            from ansible.parsing.yaml.dumper import AnsibleDumper
            from ansible.plugins.lookup.native import ansible_native_concat

            self.assertEqual(ansible_native_concat([]), None)
            self.assertEqual(ansible_native_concat([1]), 1)
            self.assertEqual(ansible_native_concat(['1']), 1)

# Generated at 2022-06-21 07:42:16.113347
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2


# Generated at 2022-06-21 07:42:24.948588
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def test_nodes(nodes, expected):
        assert expected == ansible_native_concat(nodes)

    test_nodes('test', 'test')
    test_nodes(['te', 'st'], 'test')
    test_nodes(['te', u'\x1b', 'st'], u'te\x1bst')
    test_nodes(['3', '3'], 33)
    test_nodes(['33', '3'], u'333')
    test_nodes([u'33', '3'], u'333')
    test_nodes(xrange(10), u'0123456789')
    test_nodes([u'3', u'3'], 33)
    test_nodes(['0XFF'], '0XFF')
    test

# Generated at 2022-06-21 07:42:36.202916
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'a', u'b']) == u'ab'
    assert ansible_native_concat([u'a', u'{{ test }}']) == u'a{{ test }}'
    assert ansible_native_concat([u'{{ test }}', u'b']) == u'{{ test }}b'
    assert ansible_native_concat([u'{{ test }}', u'{{ test }}']) == u'{{ test }}{{ test }}'

    assert ansible_native_concat([u'a', 1]) == u'a1'
    assert ansible_native_concat([1, u'a']) == u'1a'
    assert ansible_native_concat([1, 2]) == u'12'

# Generated at 2022-06-21 07:42:46.136414
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert ansible_native_concat([u'x']) == u'x'
    assert ansible_native_concat([u' ', u'x']) == u' x'
    assert ansible_native_concat([u'x', u'y']) == u'xy'
    assert ansible_native_concat([u'x ', u'y']) == u'x y'
    assert ansible_native_concat([u'x', u' y']) == u'x y'
    assert ansible_native_concat([u'x', u'y']) == u'xy'

    assert ansible_native_concat([u'2']) == 2
    assert ansible_native_concat([u' ', u'2']) == u' 2'

# Generated at 2022-06-21 07:42:56.065458
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 1, 'bar']) == 'foo1bar'
    assert ansible_native_concat(['foo', 1.1, 'bar']) == 'foo1.1bar'
    assert ansible_native_concat(['foo', 'True', 'bar']) == 'fooTruebar'
    assert ansible_native_concat(['foo', True, 'bar']) == 'footruebar'
    assert ansible_native_concat(['foo', False, 'bar']) == 'foofalsebar'
    assert ansible_native_concat(['foo', '1']) == 'foo1'

# Generated at 2022-06-21 07:43:04.056975
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['hello']) == 'hello'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat(['12', 3]) == '123'
    assert ansible_native_concat([1, '2']) == '12'
    assert ansible_native_concat(['1', '2', '3']) == '123'
    assert ansible_native_concat(['1 ', '2']) == '1 2'
    assert ansible_native_concat(['1 ', '2', '3']) == '1 23'

# Generated at 2022-06-21 07:43:16.480701
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    def _generator():
        yield 1
        yield 2
        yield 3

    result = ansible_native_concat(_generator())
    assert result == '123', "Got unexpected ansible_native_concat result: %s" % container_to_text(result)

    result = ansible_native_concat(['a', 1, 'b'])
    assert result == 'a1b', "Got unexpected ansible_native_concat result: %s" % container_to_text(result)

    result = ansible_native_concat(['a', 1, 'b', 2, 'c'])
    assert result == 'a1b2c', "Got unexpected ansible_native_concat result: %s" % container_to_text(result)

# Generated at 2022-06-21 07:43:26.773808
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', '', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', None, 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', ' ', 'bar']) == 'foo bar'
    assert ansible_native_concat([None]) == None
    assert ansible_native_concat(['None']) == 'None'
    assert ansible_native_concat(['True']) == True
    assert ansible_native_concat(['False']) == False
    assert ansible_native_concat(['0']) == 0
    assert ansible_native_concat(['1']) == 1

# Generated at 2022-06-21 07:43:35.134292
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_data = (
        (['foo'], 'foo'),
        ([], None),
        (['foo', 'bar'], 'foobar'),
        (['foo', 'bar', 'baz'], 'foobarbaz'),
        (['foo', ['bar', 'baz']], 'foobarbaz'),
        (['foo', 'bar', ['baz1', 'baz2']], 'foobarbaz1baz2'),
    )

    for test_input, expected_output in test_data:
        actual_output = ansible_native_concat(test_input)
        assert actual_output == expected_output, \
            "%s != %s for %s" % (actual_output, expected_output, container_to_text(test_input))



# Generated at 2022-06-21 07:43:48.388110
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == u'12'
    assert ansible_native_concat(['1', '2']) == u'12'
    assert ansible_native_concat([1, 2, 3]) == u'123'
    assert ansible_native_concat([1, 2, u'3']) == u'123'
    assert ansible_native_concat(['1', '2', u'3']) == u'123'
    assert ansible_native_concat(['']) is None
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1, 2, 3, 4]) == u'1234'

# Generated at 2022-06-21 07:44:00.952813
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(["test", " for ", "ansible_native_concat"]) == "test for ansible_native_concat"
    assert ansible_native_concat(["1", "2", "3", "4", "5"]) == "12345"
    assert ansible_native_concat("test") == 'test'
    assert ansible_native_concat("123") == '123'
    assert ansible_native_concat(123) == 123
    assert ansible_native_concat("0600") == 0o600
    assert ansible_native_concat("0o600") == 484


# Generated at 2022-06-21 07:44:08.651409
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', 1]) == 'a1'
    assert ansible_native_concat([1, 'a']) == '1a'
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat(['a', 1, 2]) == 'a12'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat([1, [2], 3]) == '1[2]3'
    assert isinstance(ansible_native_concat([1, [2], 3]), string_types)

# Generated at 2022-06-21 07:44:13.579631
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert container_to_text(ansible_native_concat(['foo'])) == u'foo'

    assert container_to_text(ansible_native_concat(['foo', 'bar'])) == u'foobar'

    assert container_to_text(ansible_native_concat([0, 'bar'])) == u'0bar'

# Generated at 2022-06-21 07:44:24.968468
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'a', u'b']) == u'ab'
    assert ansible_native_concat([u'a', 7]) == u'a7'
    assert ansible_native_concat([u'a', 2]) == u'a2'
    assert ansible_native_concat([u'a', -7]) == u'a-7'
    assert ansible_native_concat([u'a', u'-7']) == u'a-7'
    assert ansible_native_concat([u'-7', u'b']) == u'-7b'
    assert ansible_native_concat([u'2+2', u'b']) == u'2+2b'

# Generated at 2022-06-21 07:44:36.685331
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml import objects
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # Test the "native types" functionality in Jinja2 which is trying to
    # evaluate the expressions like this whenever possible
    # https://github.com/pallets/jinja/blob/master/src/jinja2/nativetypes.py

    assert ansible_native_concat(["test"]) == "test"
    assert ansible_native_concat(["test", "test"]) == "testtest"
    assert ansible_native_concat([1, 2]) == "12"
    assert ansible_native_concat([1, "2"]) == "12"

    assert ansible_native_concat([1, 2]) == "12"
    assert ansible_native_con

# Generated at 2022-06-21 07:44:45.837298
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2.nodes import List, Constant


# Generated at 2022-06-21 07:44:56.712318
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    assert ansible_native_concat([]) == None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, '2']) == '12'
    assert ansible_native_concat(['1', 2]) == '12'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat([1.1, '2']) == '1.12'
    assert ansible_native_concat([1.1, '2.2'])

# Generated at 2022-06-21 07:45:08.511184
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Ast.literal_eval parses a string and a number as a single string
    assert ansible_native_concat(['Hello ', 5, ' World']) == 'Hello 5 World'

    # Ast.literal_eval parses a newline as a single string
    assert ansible_native_concat(['Hello\nWorld']) == 'Hello\nWorld'

    # Ast.literal_eval parses a number in parentheses
    assert ansible_native_concat(['(', 5, ')']) == '(5)'

    # Ast.literal_eval parses a number in square brackets
    assert ansible_native_concat(['[', 5, ']']) == '[5]'

    # Ast.literal_eval parses a string and a number as a single string

# Generated at 2022-06-21 07:45:20.017418
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode


# Generated at 2022-06-21 07:45:31.505484
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2.runtime import Undefined

    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'

    assert ansible_native_concat([u'foo', 1, u'bar', 2]) == u'foo1bar2'

    assert ansible_native_concat([u'foo', 1]) == u'foo'

    assert ansible_native_concat([1, u'foo']) == 1

    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat([]) is None

    assert ansible_native_concat([u'foo', u'1']) == u'foo1'

# Generated at 2022-06-21 07:45:42.280751
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(["Key: ", ["value"]]) == "Key: value"
    assert ansible_native_concat(["Key: {v}", [1]]) == "Key: 1"
    assert ansible_native_concat(["Key: {v}", [1, 2]]) == "Key: 1, 2"



# Generated at 2022-06-21 07:45:50.422549
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_text


# Generated at 2022-06-21 07:46:01.590994
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:46:09.791054
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat([1, 2]) == 12
    assert ansible_native_concat([1, 'a']) == 1
    assert ansible_native_concat(['a', 1]) == 'a'

# Generated at 2022-06-21 07:46:21.375165
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml import objects
    from ansible.template import Template

    t = Template('{{ [a, b] }}', undefined=StrictUndefined)
    r = t.render(a='foo', b='bar')
    assert r == u'[u\'foo\', u\'bar\']'

    r = t.render(a=['foo', 'bar'], b=['baz', 'qux'])
    assert r == u'[[u\'foo\', u\'bar\'], [u\'baz\', u\'qux\']]'

    r = t.render(a=objects.AnsibleSequence(['foo', 'bar']), b=['baz', 'qux'])

# Generated at 2022-06-21 07:46:32.148847
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Testing case where head has a single element
    assert ansible_native_concat(['hello world']) == 'hello world'
    assert ansible_native_concat(['1']) == '1'
    assert ansible_native_concat(['1']) != 1
    assert ansible_native_concat(['True']) == 'True'
    assert ansible_native_concat(['True']) != True
    assert ansible_native_concat(['False']) == 'False'
    assert ansible_native_concat(['False']) != False
    assert ansible_native_concat(['hello world']) != ['hello world']
    assert ansible_native_concat(['hello world']) != {'hello world': 1}

# Generated at 2022-06-21 07:46:42.705034
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    def _assert_value(data, expected_value):
        actual_value = ansible_native_concat(data)
        assert actual_value == expected_value, \
            "Expected value %r, got %r" % (expected_value, actual_value)

    _assert_value((None,), None)
    _assert_value((1,), 1)
    _assert_value((1, None), '1')
    _assert_value((1, 2), '12')
    _assert_value((1, 2, "TEST", 3), '12TEST3')
    _assert_value((1, "\n", 2, "\t", "TEST", "3"), '1\n2\tTEST3')


# Generated at 2022-06-21 07:46:55.178772
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    class FakeContext:
        def __init__(self, value):
            self.value = value

    assert ansible_native_concat([FakeContext(42)]) == 42
    assert ansible_native_concat([FakeContext("foo")]) == 'foo'
    assert ansible_native_concat([FakeContext("fü")]) == 'fü'
    assert ansible_native_concat([FakeContext("foo"), FakeContext("bar")]) == 'foobar'
    assert ansible_native_concat([FakeContext("fü"), FakeContext("bär")]) == 'fübär'
    assert ansible_native_concat([FakeContext("foo"), FakeContext("bar"), FakeContext("baz")]) == 'foobarbaz'

# Generated at 2022-06-21 07:47:07.225944
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # 1. Should be able to parse a string literal
    assert ansible_native_concat(['foo bar baz']) == 'foo bar baz'
    assert ansible_native_concat(['"foo bar baz"']) == 'foo bar baz'
    assert ansible_native_concat(['"""foo bar baz"""']) == 'foo bar baz'

    # 2. Should be able to parse a single-line string literal
    assert ansible_native_concat(['"foo\nbar\nbaz"']) == 'foo\nbar\nbaz'

    # 3. Should be able to parse a multi-line string literal
    assert ansible_native_concat(["'''foo\nbar\nbaz'''"]) == 'foo\nbar\nbaz'
    assert ansible_native_concat

# Generated at 2022-06-21 07:47:14.834156
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test basic functionality
    assert ansible_native_concat(['test']) == 'test'
    assert ansible_native_concat(['\\test']) == '\\test'
    assert ansible_native_concat(['\\test', '\\']) == '\\test\\'
    assert ansible_native_concat(['\\test', '\\', 'test']) == '\\test\\test'
    assert ansible_native_concat([1, '\\', 3]) == '1\\3'

    # Test literal_eval
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, '2']) == 12
    assert ansible_native_concat(['1', 2]) == 12

# Generated at 2022-06-21 07:47:36.892729
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:47:49.388384
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    def test(nodes, expected):
        assert expected == ansible_native_concat(nodes)

    # Undefined variable
    test([StrictUndefined()], None)

    # Single variable
    test([1], 1)
    test([None], None)
    test([True], True)
    test([False], False)
    test(['abc'], 'abc')
    test([AnsibleUnicode('abc')], 'abc')
    test([{'a': 1, 'b': 2}], {'a': 1, 'b': 2})
    test([[1, 2, 3]], [1, 2, 3])

    # Multiple variables
    test([1, 2], '12')

# Generated at 2022-06-21 07:47:59.076687
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'foo']) == 'foo'
    assert ansible_native_concat([u'foo', u'bar']) == 'foobar'
    assert ansible_native_concat([u'foo', 42]) == 'foo42'
    assert ansible_native_concat([42, u'bar']) == '42bar'
    assert ansible_native_concat([42, 42]) == '4242'
    assert ansible_native_concat(['foo', 42]) == 'foo42'
    assert ansible_native_concat([text_type(42), u'bar']) == '42bar'
    assert ansible_native_concat([None, u'bar']) == 'bar'

# Generated at 2022-06-21 07:48:10.762265
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    data = """
{% set s0 = 'a' %}
{% set s1 = 'b' %}
{% set s2 = s0 + s1 %}
{% set s3 = 7 + 8 %}
{{ [s0, s1, s2, s3, 'a', 'b', '7', '8'] | map('ansible_native_concat') | list }}
"""

    template = '#jinja2:native_concat_supported=true:concat_fn=ansible_native_concat\n' + data
    result = [['a', 'b', 'ab', 15, 'a', 'b', '7', '8']]
    assert result == _ansible_jinja2_concat(template)


# Generated at 2022-06-21 07:48:22.757375
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    assert ansible_native_concat(('foo',)) == 'foo'
    assert ansible_native_concat(('foo', 'bar', 'baz')) == 'foobarbaz'
    assert ansible_native_concat(('foo', u'bar', 'baz')) == 'foobarbaz'

    assert ansible_native_concat((None,)) is None
    assert ansible_native_concat(('foo', None, 'baz')) == 'foobaz'
    assert ansible_native_concat((None, 'foo', 'baz')) == 'foobaz'
    assert ansible_native_concat(('foo', 'baz', None)) == 'foobaz'


# Generated at 2022-06-21 07:48:33.727948
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([u'foo', 23]) == u'foo23'
    assert ansible_native_concat([u'foo', {u'bar': 23}]) == u"foo{'bar': 23}"
    assert ansible_native_concat([u'foo', 23, {u'bar': 23}]) == u"foo23{'bar': 23}"
    assert ansible_native_concat([u'foo', 23, {u'bar': 23}, 3.2]) == u"foo23{'bar': 23}3.2"
    assert ansible_native_concat([u'foo', u' bar', u'baz']) == u'foo barbaz'
    assert ansible_

# Generated at 2022-06-21 07:48:44.904493
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([container_to_text(['foo'])]) == ['foo']
    assert ansible_native_concat([container_to_text([1])]) == [1]
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 'bar', container_to_text('foobar')]) == 'foobarfoobar'
    assert ansible_native_concat(['foo', ' 1']) == 'foo 1'

# Generated at 2022-06-21 07:48:53.835090
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # TODO: add tests for AnsibleVaultEncryptedUnicode
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['1', '2', '3']) == '123'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(['  1', '2', '3']) == "  123"
    assert ansible_native_concat([u'a', u'b', u'c']) == u'abc'
    assert ansible_native_concat([u'  1', u'2', u'3']) == u"  123"

# Generated at 2022-06-21 07:49:02.509137
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test 1:
    # (1, 2) + 3
    # should be 5
    nodes = [1, 2, 3]
    out = ansible_native_concat(nodes)
    assert out == 5

    # Test 2:
    # (1, 2) + "3"
    # should be "23"
    nodes = [1, 2, "3"]
    out = ansible_native_concat(nodes)
    assert out == "23"

    # Test 3:
    # [1, 2] + [3, 4]
    # should be [1, 2, 3, 4]
    nodes = [[1, 2], [3, 4]]
    out = ansible_native_concat(nodes)
    assert out == [1, 2, 3, 4]

    # Test 4:
   

# Generated at 2022-06-21 07:49:06.503515
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    assert ansible_native_concat([5]) == 5
    assert ansible_native_concat([u"5"]) == 5

    assert ansible_native_concat([['1', '2', '3']]) == ['1', '2', '3']
    assert ansible_native_concat([[1, 2, 3]]) == [1, 2, 3]

    assert ansible_native_concat([True]) == True
    assert ansible_native_concat([False]) == False

    assert ansible_native_concat([None]) is None

    assert ansible_native_concat([{'a': 'b', 'c': 'd'}]) == {'a': 'b', 'c': 'd'}

    assert ansible_native_

# Generated at 2022-06-21 07:49:30.641452
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert [] == ansible_native_concat([])
    assert None is ansible_native_concat([None])
    assert True is ansible_native_concat([True])
    assert 1 == ansible_native_concat([1])
    assert u'\u1234' == ansible_native_concat([u'\u1234'])
    assert '1234' == ansible_native_concat(['1234'])
    assert 1 == ansible_native_concat(['1'])

    assert [] == ansible_native_concat(['[]'])
    assert [1] == ansible_native_concat(['[1]'])
    assert [1, 2] == ansible_native_concat(['[1,', '2]'])
    assert (1, 2) == ansible_native

# Generated at 2022-06-21 07:49:40.302613
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat([1, 'a', 'b', 'c']) == [1, 'a', 'b', 'c']
    assert ansible_native_concat([1, 'a', 'b', 3]) == [1, 'a', 'b', 3]
    assert isinstance(ansible_native_concat(['a', 'b']), text_type)
    assert ansible_native_concat(['a', 'b']) == u'ab'

# Generated at 2022-06-21 07:49:50.086040
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # First scrub the native_concat function of the types module
    # so we can wrap it.
    from types import FunctionType
    assert isinstance(ansible_native_concat, FunctionType)
    del ansible_native_concat.__wrapped__
    assert not isinstance(ansible_native_concat, FunctionType)
    # Now wrap it
    from ansible.utils.native_jinja import native_concat
    from ansible.utils.native_jinja import wrap_native_concat
    wrap_native_concat(ansible_native_concat)
    assert hasattr(ansible_native_concat, '__wrapped__')
    assert ansible_native_concat.__wrapped__ == native_concat
    # Test the function
    assert ansible_native_concat([]) == ""

# Generated at 2022-06-21 07:50:01.767192
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # positive tests
    assert ansible_native_concat(['true']) is True
    assert ansible_native_concat(['on']) is True
    assert ansible_native_concat(['yes']) is True
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['-1']) == -1
    assert ansible_native_concat(['1.1']) == 1.1
    assert ansible_native_concat(['-1.1']) == -1.1
    assert ansible_native_concat(['{1: 2}']) == {1: 2}
    assert ansible_native_concat(['[1, 2]']) == [1, 2]
    assert ansible_native_concat(['string'])

# Generated at 2022-06-21 07:50:12.502311
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import Markup
    from ansible.module_utils.six.moves import builtins

    nodes = [
        '',
        b'',
        [],
        {},
        'abc',
        b'abc',
        u'abc',
        'a ',
        b'a ',
        u'a ',
        ' a',
        b' a',
        u' a',
        1,
        True,
        None,
        '',
        b'',
        u'',
        [1, 2],
        {'x': 1, 'y': 2},
        'abc',
        b'abc',
        u'abc',
    ]


# Generated at 2022-06-21 07:50:19.699801
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:50:31.577669
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2]) == 3
    assert ansible_native_concat(['One', 2, 'Three']) == 'One2Three'
    assert ansible_native_concat([b'One', 2, b'Three']) == 'One2Three'
    assert ansible_native_concat([1, b'Two', 'Three']) == '1TwoThree'
    assert ansible_native_concat(['One', 2, b'Three']) == 'One2Three'
    assert ansible_native_concat([b'Four', 2, 3]) == 'Four2'
    assert ansible_native_concat([b'Four', 2, 3]).__class__ == text_type