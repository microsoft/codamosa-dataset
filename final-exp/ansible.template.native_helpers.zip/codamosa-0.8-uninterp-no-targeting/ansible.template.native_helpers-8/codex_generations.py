

# Generated at 2022-06-21 07:40:40.161143
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # ast.literal_eval() can't handle ints with leading 0
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['01']) == '01'
    assert ansible_native_concat([u'0x01']) == '0x01'
    assert ansible_native_concat([u'0o01']) == '0o01'
    assert ansible_native_concat([u'0b01']) == '0b01'
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat(['True']) is True
    assert ansible_native_concat([False]) is False

# Generated at 2022-06-21 07:40:48.364500
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['{"a": 1}']) == {'a': 1}
    assert ansible_native_concat(['', 1]) == 1
    assert ansible_native_concat(['', 1, '']) == u'1'
    assert ansible_native_concat(['', 1, '']) == '1'
    assert ansible_native_concat(['', 'a', '']) == u'a'
    assert ansible_native_concat(['', 'a', '']) == 'a'
    assert ansible_native_concat(['', '{a}', '']) == u'{a}'
    assert ansible_native_concat(['', '{a}', '']) == '{a}'

# Generated at 2022-06-21 07:41:01.432698
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([42, True, 1.2, False, None, [1, 2, 3]]) == [1, 2, 3]
    assert ansible_native_concat(['0', '1']) == '01'
    assert ansible_native_concat([42, True, 1.2, False, None, [1, 2, 3]]) == [1, 2, 3]
    assert ansible_native_concat(['42', 'True', '1.2', 'False', 'None', ['1', '2', '3']]) == [1, 2, 3]
    assert ansible_native_concat(['0', '1', 2]) == '012'

# Generated at 2022-06-21 07:41:08.087219
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # return values
    assert ansible_native_concat(['a', 'b']) == "ab"
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['42']) == '42'
    assert ansible_native_concat(['42.1']) == '42.1'
    assert ansible_native_concat(['False']) == 'False'
    assert ansible_native_concat(['True']) == 'True'
    assert ansible_native_concat(['None']) == 'None'
    assert ansible_native_concat(['How are you?']) == 'How are you?'

# Generated at 2022-06-21 07:41:15.801897
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['[', 1, 2, 3, ']']) == [1, 2, 3]
    assert ansible_native_concat(['{', 1, 2, 3, '}']) == {1: 2, 3: None}
    assert ansible_native_concat(['{', 1, 2, 3, '}']) == {1: 2, 3: None}
    assert ansible_native_concat(['[', 1, ':', 2, ']']) == [1, 2]
    assert ansible_native_concat(['[', 1, ',', 2, ']']) == [1, 2]
    assert ansible_native_concat([1, '+', 2]) == 3

# Generated at 2022-06-21 07:41:28.624562
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert u'abc' == ansible_native_concat((u'abc',))
    assert u'abc' == ansible_native_concat((u'a',u'bc'))
    assert u'abc' == ansible_native_concat((u'a', u'', u'bc'))
    assert 2 == ansible_native_concat((u'2',))
    assert 3.14 == ansible_native_concat((u'3.14',))
    assert True == ansible_native_concat((u'true',))
    assert False == ansible_native_concat((u'false',))
    assert True == ansible_native_concat((u'TrUe',))
    assert False == ansible_native_concat((u'False',))
    # double-quote

# Generated at 2022-06-21 07:41:41.986218
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = [1, 2, 3]
    assert ansible_native_concat(nodes) == 1

    nodes = ['1', '2', '3']
    assert ansible_native_concat(nodes) == '123'

    nodes = ['1', 2, '3']
    assert ansible_native_concat(nodes) == '123'

    nodes = ['1', '2', 3]
    assert ansible_native_concat(nodes) == '123'

    nodes = ['1', '-', 2, '-', '3']
    assert ansible_native_concat(nodes) == '1-2-3'

    nodes = [None, '-', 2, '-', '3']
    assert ansible_native_concat(nodes) == None


# Generated at 2022-06-21 07:41:49.402561
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(()) is None
    assert ansible_native_concat(('foo',)) == 'foo'
    assert ansible_native_concat(('foo ', 'bar')) == 'foo bar'
    assert ansible_native_concat((1, 'foo', 'bar', 2)) == '1foobar2'
    assert ansible_native_concat((1, 'foo', 'bar', 2)) == '1foobar2'
    assert ansible_native_concat((1, 'foo', 2, 'bar', 2)) == '1foo2bar2'
    assert ansible_native_concat((1, 2, 'foo')) == '12foo'
    assert ansible_native_concat((1, 2.0, 'foo')) == '12.0foo'
    assert ansible

# Generated at 2022-06-21 07:42:02.337698
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.template.template import AnsibleJ2Template
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # https://github.com/pallets/jinja/blob/master/tests/test_nativetypes.py
    j2_t = AnsibleJ2Template('')

    assert ansible_native_concat([]) == None
    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat([42]) == 42

    # FIXME: vaulted data is not tested
    # assert ansible_native_concat([AnsibleVaultEncryptedUnicode(u'foo')]) == u'foo'
    # assert ansible_native_concat([AnsibleVaultEncryptedUnicode(

# Generated at 2022-06-21 07:42:14.031216
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['1']) == '1'
    assert ansible_native_concat(['1', '2']) == '12'
    # return value if it is not a string
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['1', 2]) == '12'
    # convert to text if it is not a string
    assert isinstance(ansible_native_concat(['1', 2, {'a': 1}]), text_type)
    # evaluate if it is string, number or bool
    assert ansible_native_concat(['{a: 1}']) == {'a': 1}
    assert ansible_native_concat(['1']) == 1
   

# Generated at 2022-06-21 07:42:26.051078
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([3, 7]) == u'3 7'
    assert ansible_native_concat(['foo', StrictUndefined()]) == u'foo '
    assert ansible_native_concat([u'foo', 'bar']) == u'foobar'
    assert ansible_native_concat([u'foo', 'bar', 42]) == u'foobar42'
    assert ansible_native_concat([b'foo', u'bar', 42]) == u'foobar42'
    assert ansible_native_concat([u'foo', 'bar', u'baz', 42]) == u'foobarbaz42'

# Generated at 2022-06-21 07:42:36.627848
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.common.text.formatters import to_nice_yaml
    import yaml

    yaml_out_str = """---
    # jinja2_native_concat_test
        bar: baz
        foo: bar
        '{{ ansible_managed }}': "Managed by Ansible"
    '{{ foo.bar() }}': bar
    {{ fruit }}: berry
    """

    data = {
        'foo': 'bar',
        'bar': 'baz',
        'fruit': 'straw',
    }

    yaml_out = to_text(yaml_out_str)
    yaml_out_dict = yaml.safe_load(yaml_out)


# Generated at 2022-06-21 07:42:46.569721
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.template.safe_eval import unsafe_eval
    from ansible.template.safe_eval import UndefinedError
    from ansible.template.safe_eval import AnsibleUndefined

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # a simple test
    s = 'a'
    t = ['a']
    u = None
    v = unsafe_eval('a')
    assert ansible_native_concat(s) is v
    assert ansible_native_concat(t) is v

    # tests where the native_concat is different from the default
    # unsafe_eval
    assert ansible_native_concat(u) is None

    a = 'a'

# Generated at 2022-06-21 07:42:57.348581
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat(['1', 2, '3']) == 123
    assert ansible_native_concat([True, 'False']) == 'TrueFalse'
    assert ansible_native_concat([set([1]), ['2', '3']]) == '123'
    assert ansible_native_concat([1, [2, 3], 4]) == '1234'
    assert ansible_native_concat(['[1, 2]']) == [1, 2]

# Generated at 2022-06-21 07:43:06.607401
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(('1', '2')) == '12'
    assert ansible_native_concat((1, 2, 3)) == '123'
    assert ansible_native_concat(('1', 2, '3')) == 123
    assert ansible_native_concat(('', '2')) == '2'
    assert ansible_native_concat((1, 'foo')) == '1foo'
    assert ansible_native_concat((1, 2, 'foo', 4)) == 12
    assert ansible_native_concat([]) is None

    assert ansible_native_concat(('', 'foo')) == 'foo'
    assert ansible_native_concat(('foo', 'bar')) == 'foobar'

# Generated at 2022-06-21 07:43:18.630265
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', '\n', 'bar']) == 'foo\nbar'
    assert ansible_native_concat(['foo', '\n', '"bar"']) == 'foo\n"bar"'
    assert ansible_native_concat(['foo\n', 'bar']) == 'foo\nbar'
    assert ansible_native_concat(['foo', '', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', '', 'bar', '', 'baz']) == 'foobarbaz'
    assert ansible_native_concat(['foo', 'bar', 'baz']) == 'foobarbaz'

# Generated at 2022-06-21 07:43:27.549237
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def _test_equal(nodes, expected):
        actual = ansible_native_concat(nodes)

        assert actual == expected
        assert type(actual) == type(expected)

    # Return None
    _test_equal([], None)

    # Return a single node
    _test_equal([1], 1)
    _test_equal([1.2], 1.2)
    _test_equal([True], True)
    _test_equal([False], False)
    _test_equal(['foo'], 'foo')
    _test_equal([text_type('foo')], text_type('foo'))
    _test_equal([u'foo'], u'foo')

    # Return a concatenation of nodes
    _test_equal([1, 2], 12)

# Generated at 2022-06-21 07:43:37.187026
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([2, 3]) == u'23'
    assert ansible_native_concat(range(10)) == u'0123456789'
    assert ansible_native_concat(range(5)) == 0
    assert ansible_native_concat([True, False, True]) == u'TrueFalseTrue'
    assert ansible_native_concat([False, True, False]) == False
    assert ansible_native_concat([False, False, False]) == False
    assert ansible_native_concat([False, True, True]) == True
    assert ansible_native_concat([True, False, False]) == True
    assert ansible_native_concat

# Generated at 2022-06-21 07:43:49.197884
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([types.GeneratorType, "Hello"]) == '<class \'>Hello'
    assert ansible_native_concat(["Hello", " world"]) == "Hello world"
    assert ansible_native_concat(["Hello", " ", "world"]) == "Hello world"
    assert ansible_native_concat([1, "Hello", 2, " ", 3, "world", 4]) == "1Hello2 world3world4"
    assert ansible_native_concat(["Hello", 2, " ", 3, "world", 4]) == "Hello2 world3world4"
    assert ansible_native_concat(["Hello", 2, " ", "3world", 4]) == "Hello2 3world4"
    assert ansible_native_concat(["Hello"]) == 'Hello'


# Generated at 2022-06-21 07:44:01.429991
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat(['hello']) == 'hello'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([b'hello']) == b'hello'
    assert ansible_native_concat(['hello', 'world']) == 'helloworld'
    assert ansible_native_concat([1, 2]) == 12
    assert ansible_native_concat([b'hello', b'world']) == b'helloworld'
    assert ansible_native_concat([True, False]) == 'TrueFalse'
    assert ansible_native_concat([1, '2', 3]) == '123'
    assert ansible_

# Generated at 2022-06-21 07:44:18.165840
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([u'']) == u''
    assert ansible_native_concat([u'', u'']) == u''
    assert ansible_native_concat([u'True']) == True
    assert ansible_native_concat([u'True', u'True']) == u'TrueTrue'
    assert ansible_native_concat([[u'True', u'True']]) == [u'True', u'True']
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2, 3]) == u'123'

# Generated at 2022-06-21 07:44:27.532212
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import json

    # Test the case where result is a single node
    from jinja2.nativetypes import NativeInt
    assert ansible_native_concat([NativeInt(1)]) == 1

    # Test the case where the result is a single native type
    from jinja2.nativetypes import NativeString
    assert ansible_native_concat([NativeString(u'foo')]) == 'foo'

    # Test the case where the result is a native list
    from jinja2.nodes import List
    assert ansible_native_concat([List(0, [NativeInt(1)])]) == [1]

    # Test the case where the result is a native dict
    from jinja2.nodes import Dict, Keyword

# Generated at 2022-06-21 07:44:39.479444
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # pylint: disable=import-error
    from ansible.tests.unit.compat import unittest
    from ansible.tests.unit.compat.mock import patch
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleVaultEncryptedUnicode
    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()


# Generated at 2022-06-21 07:44:51.532289
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', '1', 'b']) == 'a1b'
    assert ansible_native_concat(['a', '1', 'True', 'False']) == 'a1TrueFalse'
    assert ansible_native_concat(['a', '1', 'true', 'false']) == 'a1truefalse'
    assert ansible_native_concat(['a', 1]) == 'a1'

# Generated at 2022-06-21 07:45:00.966416
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Simple string
    assert ansible_native_concat(["foo"]) == 'foo'
    assert ansible_native_concat(("foo",)) == 'foo'
    # Simple list
    assert ansible_native_concat([["foo", "bar"]]) == ['foo', 'bar']
    assert ansible_native_concat((["foo", "bar"],)) == ['foo', 'bar']
    # Simple dict
    assert ansible_native_concat([{"foo": "bar"}]) == {'foo': 'bar'}
    assert ansible_native_concat(({"foo": "bar"},)) == {'foo': 'bar'}
    # Example from https://github.com/pallets/jinja/blob/master/src/jinja2/nativetypes.py

# Generated at 2022-06-21 07:45:10.635698
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    t1 = to_text('foo')
    t2 = to_text('bar')
    t3 = to_text('baz')
    t4 = to_text('qux')

    # result is a string
    assert(ansible_native_concat([t1]) == 'foo')
    assert(ansible_native_concat([t1, t2]) == 'foobar')
    assert(ansible_native_concat([t1, t2, t3]) == 'foobarbaz')
    assert(ansible_native_concat([t1, t2, t3, t4]) == 'foobarbazqux')

    # result is an integer
    assert(ansible_native_concat([42]) == 42)
    assert(ansible_native_concat([2, 3]) == 5)


# Generated at 2022-06-21 07:45:21.290503
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # basic concatenation tests
    assert ansible_native_concat([1, 2]) == u'12'
    assert ansible_native_concat([u'1', u'2']) == u'12'
    assert ansible_native_concat([1, u'2']) == u'12'
    assert ansible_native_concat([u'1', u'a', u'b', u'c']) == u'1abc'
    assert ansible_native_concat([u'a', u'b', u'c']) == u'abc'
    assert ansible_native_concat([u'a', u'b', u'c']) == u'abc'
    assert ansible_native_concat([1, 2, 3]) == u'123'
    assert ansible_native_concat

# Generated at 2022-06-21 07:45:26.158321
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # 1. Ensure we can return a single node
    code = '"abc"'
    node = ast.parse(code, mode='eval').body
    assert ansible_native_concat((node, )) == "abc"

    # 2. Ensure we can return multiple nodes
    code = '"abc" + "def"'
    node = ast.parse(code, mode='eval').body
    assert ansible_native_concat((node.left, node.right)) == "abcdef"

    # 3. Ensure we can return a complex expression
    code = '"abc" + "1" + str(2)'
    node = ast.parse(code, mode='eval').body
    assert ansible_native_concat((node.left.left, node.left.right, node.right)) == "abc12"

    # 4. Ensure we can return

# Generated at 2022-06-21 07:45:37.667056
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test ansible_native_concat function.
    """
    assert ansible_native_concat([]) is None

    assert ansible_native_concat(['{"foo":"bar"}']) == {'foo': 'bar'}
    assert ansible_native_concat([u'{"foo":"bar"}']) == {'foo': 'bar'}
    assert ansible_native_concat([b'{"foo":"bar"}']) == {'foo': 'bar'}

    assert ansible_native_concat(['[true, true]']) == [True, True]
    assert ansible_native_concat([u'[true, true]']) == [True, True]
    assert ansible_native_concat([b'[true, true]']) == [True, True]

    assert ansible_native_concat

# Generated at 2022-06-21 07:45:47.640472
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'1', u'2', u'3']) == u'123'
    assert ansible_native_concat([1, 2, 3]) == 6
    assert ansible_native_concat([True, True, False]) is False
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([None, None, None]) is None
    assert ansible_native_concat([u'a', u'b', u'c']) == u'abc'
    assert ansible_native_concat([u'a', u'b', u'c'], True) == u'abc'
    assert ansible_native_concat([u'a', u'b', u'c'], True, 1, 2) == u'abc12'
    assert ans

# Generated at 2022-06-21 07:46:08.309824
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a', 'b', 'c']) == u'abc'
    assert ansible_native_concat(iter(['a', 'b', 'c'])) == u'abc'
    assert ansible_native_concat(['1', 2]) == u'12'
    assert ansible_native_concat([u'3', 4]) == u'34'
    assert ansible_native_concat(['True', 'False']) == u'TrueFalse'
    assert ansible_native_concat(['{"a": 1}', '{"b": 2}']) == u'{"a": 1}{"b": 2}'
    assert ansible_native_concat(['1', '2', '3']) == u'123'

# Generated at 2022-06-21 07:46:14.466943
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Test truthy
    assert not ansible_native_concat([])
    assert ansible_native_concat([u''])
    assert ansible_native_concat([u'foo'])
    assert ansible_native_concat([1])
    assert ansible_native_concat([1, 2])
    assert ansible_native_concat(['1', '2'])
    assert ansible_native_concat(["'foo'", "'bar'"])
    assert ansible_native_concat([u"'foo'", "'bar'"])
    assert ansible_native_concat(['{"foo": "bar"}', '{"foo": "bar"}'])

    # Test Falsey
    assert not ansible_native_concat([u''])
    assert not ansible_native_concat([False])

# Generated at 2022-06-21 07:46:22.190568
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([NativeJinjaText("foo")]) == "foo"
    assert ansible_native_concat([NativeJinjaText("foobar")]) == "foobar"
    assert ansible_native_concat([3]) == 3
    assert ansible_native_concat([[3,2,1]]) == [3,2,1]
    assert ansible_native_concat(["foo", "bar"]) == "foobar"
    assert ansible_native_concat(["foo", "bar", [3,2,1]]) == "foobar[3, 2, 1]"
    assert ansible_native_concat(["foo", u"bar", [3,2,1]]) == "foobar[3, 2, 1]"

# Generated at 2022-06-21 07:46:32.496919
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['ab']) == 'ab'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat(['ab', 'cd']) == 'abcd'
    assert ansible_native_concat(['ab', 'cd', 'ef']) == 'abcdef'

    assert ansible_native_concat(['1', '2']) == 12
    assert ansible_native_concat(['1', '2', '3', '4']) == '1234'

    assert ansible_native_concat(['a\r\n', 'b']) == u'a\r\nb'



# Generated at 2022-06-21 07:46:42.822034
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.template.safe_eval import ansible_native_concat as a_n_c
    from ansible.template.safe_eval import native_concat_to_text


# Generated at 2022-06-21 07:46:55.189827
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_bytes
    from jinja2.runtime import Undefined

    assert ansible_native_concat([]) is None
    assert ansible_native_concat(('foo',)) == 'foo'
    assert ansible_native_concat(('foo', 'bar')) == 'foobar'
    assert ansible_native_concat((1, 2)) == '12'

# Generated at 2022-06-21 07:47:07.175384
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # This function is a modified copy of the Jinja2 native_concat function
    # from jinja/nativetypes.py in Jinja 2.11.1.
    # https://github.com/pallets/jinja/blob/11c385b4a86d4c7fb9080f9a928ed519ddc893db/src/jinja2/nativetypes.py
    from jinja2.nodes import Const, Name, concat
    from jinja2.nativetypes import native_contextfilter


# Generated at 2022-06-21 07:47:14.634067
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # This test assumes that "ast.literal_eval" behaves exactly as
    # YAML.load/safe_load. We could make our own version of "ast.literal_eval"
    # to replace this test, however we'd lose the advantage of doing the
    # conversion natively.
    import yaml

# Generated at 2022-06-21 07:47:25.862760
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # These were failing cases in previous versions of the function
    # https://github.com/ansible/ansible/pull/70831
    # https://github.com/ansible/ansible/pull/70314
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == u'12'
    assert ansible_native_concat([1, 2, 3]) == u'123'
    assert ansible_native_concat([1, u'2', 3]) == u'123'
    assert ansible_native_concat([1, u'2', u'3']) == u'123'

    # To support native types
    assert ansible_native_concat([1.2]) == 1.2

# Generated at 2022-06-21 07:47:37.139899
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', u'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 7]) == 'foo7'
    assert ansible_native_concat([1, 'foo']) == '1foo'
    assert ansible_native_concat([1, 'foo', 'bar']) == '1foobar'
    assert ansible_native_concat([1, 'foo', 'bar', 'baz']) == '1foobarbaz'

# Generated at 2022-06-21 07:47:56.153842
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2

    from ansible.module_utils.common.text.converters import to_bytes
    if hasattr(to_bytes, '__code__'):
        # Python 3
        to_bytes = to_bytes.__code__.co_code
    env = jinja2.Environment(extensions=['ansible.module_utils.jinja2.extensions.AnsibleCoreExtensions'])
    env.filters['to_bytes'] = to_bytes
    env.filters['ansible_native_concat'] = ansible_native_concat

    def assert_j2(in_, out):
        assert out == env.from_string('{{ %s | to_bytes | ansible_native_concat }}' % in_).render().strip()


# Generated at 2022-06-21 07:48:00.782841
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.errors import AnsibleError
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.template.safe_eval import safe_eval

    def _str_or_bytes(value):
        return str if isinstance(value, str) else bytes

    # Strings
    assert ansible_native_concat([text_type('a'), text_type('b')]) == 'ab'

    # Integers
    assert ansible_native_concat([{}]) == {}
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat([1, '2', 3]) == [1, '2', 3]
    assert ansible_native_

# Generated at 2022-06-21 07:48:11.708858
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # This is copy of test_concat from Jinja2
    concat = ansible_native_concat
    assert concat([]) is None
    assert concat(['foo']) == 'foo'
    assert concat(['foo', 'bar']) == 'foobar'
    assert concat(['foo', '', 'bar']) == 'foobar'
    assert concat(['foo', 1]) == 'foo1'
    assert concat(['foo', 1, 1, 1]) == 'foo111'
    assert concat(['foo', None, 1, 1.0]) == 'foo11.0'
    assert concat(['foo', True, 'bar']) == 'foobar'
    assert concat(['foo', False, 'bar']) == 'foobar'

# Generated at 2022-06-21 07:48:23.588636
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test with no values
    assert not ansible_native_concat([])
    # Test with a single integer value
    assert ansible_native_concat([1]) == 1
    # Test with a single string value
    assert ansible_native_concat(['foo']) == 'foo'
    # Test with a single Unicode value
    assert ansible_native_concat([u'\u2665']) == u'\u2665'

    # Test various literals
    literals = [
        '1', '1.0', '1.0+0j', '1e1', '"foo"', "'foo'", 'None',
        'True', 'False', '(1, 2)', '[1, 2]', '{1: 2}',
    ]
    for literal in literals:
        assert ansible_

# Generated at 2022-06-21 07:48:34.564431
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['1', 1]) == '11'
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['1.0']) == 1.0
    assert ansible_native_concat(['1.0', '.2', 3]) == '1.0.23'
    assert ansible_native_concat(['[1, 2, 3]']) == [1, 2, 3]
    assert ansible_native_concat(['a', 'b']) == 'ab'

# Generated at 2022-06-21 07:48:45.819666
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Make sure strings are returned as they are
    assert ansible_native_concat([u'hello word']) == u'hello word'
    assert ansible_native_concat([u' "test"']) == u' "test"'
    assert ansible_native_concat([None]) is None
    # Make sure normal concatenation is performed when more than one item is provided
    assert ansible_native_concat([u'hello ', u'world']) == u'hello world'
    assert ansible_native_concat([u'hello ', None, u'world']) == u'hello world'
    assert ansible_native_concat([u'hello ', u'', u'world']) == u'hello world'
    # Make sure literal_eval is performed and the result is returned when appropriate
    assert ansible_native_concat

# Generated at 2022-06-21 07:48:54.480870
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def evaluate(s):
        """Evaluate a Jinja2 expression with ansible_native_concat as the
        concat function.
        """
        return ast.parse(s, mode='eval').body.value

    # test for booleans
    assert ansible_native_concat([evaluate('True')]) is True
    assert ansible_native_concat([evaluate('True'), evaluate('False')]) is 'TrueFalse'
    assert ansible_native_concat([evaluate('True'), evaluate('False'), evaluate('True')]) is 'TrueFalseTrue'

    # test for strings
    assert ansible_native_concat([evaluate('True'), evaluate('"False"')]) is 'TrueFalse'

    # test for integers
    assert ansible_native_concat([evaluate('1')]) is 1
    assert ansible_native_con

# Generated at 2022-06-21 07:49:05.641172
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['asdf']) == 'asdf'
    assert ansible_native_concat(['1', '2', '3']) == '123'
    assert ansible_native_concat(['1', '2', '3']) == '123'
    assert ansible_native_concat(['1', 2, 3]) is None
    assert ansible_native_concat(['1', 2, ['3']]) is None
    assert ansible_native_concat([1, 2, '3']) == 1
    assert ansible_native_concat(['1', 2, 3]) is None
    assert ansible_native_concat(['True', 2, 3]) is None
    assert ansible_native_concat(['True', 2, 3]) is None



# Generated at 2022-06-21 07:49:14.714417
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['hello']) == 'hello'
    assert ansible_native_concat(['hello', 'world']) == 'helloworld'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'

    # Test that literal_eval works on top of concat.

# Generated at 2022-06-21 07:49:20.516575
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # first test the new function
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, 2.3]) == '1.23'
    assert ansible_native_concat([1, '2']) == '12'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat([True]) == True
    assert ansible_native_concat([True, False]) == 'TrueFalse'
    assert ansible_native_concat([True, 'False']) == 'TrueFalse'
    assert ansible_native_concat([['1', '2'], ['3', '4']]) == '1234'
    assert ans

# Generated at 2022-06-21 07:49:50.755575
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1.1]) == 1.1
    assert ansible_native_concat([1, 2]) == u'12'
    assert ansible_native_concat([1.1, 2.2]) == u'1.12.2'
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([1, 2, 3]) == u'123'
    assert ansible_native_concat([1.1, 2.2, 3.3]) == u'1.12.23.3'


# Generated at 2022-06-21 07:50:00.271771
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class TestNode:
        def __init__(self, val):
            self.val = val

    result_list = (
        (['abc', 'def'], 'abcdef'),
        ([TestNode('abc'), TestNode('def')], 'abcdef'),
        ([TestNode('123'), TestNode('456')], 111 + 222),
        ([TestNode('true'), TestNode('false')], True is not False),
    )
    for node_list, expected_result in result_list:
        result = ansible_native_concat(node_list)
        assert result == expected_result
        assert not isinstance(result, string_types)

# Generated at 2022-06-21 07:50:10.752640
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def _test(nodes, expected):
        assert expected == ansible_native_concat(nodes)

    _test([], None)

    _test(['foo'], 'foo')
    _test(['foo', 'bar'], 'foobar')

    _test([1, 2, 3], [1, 2, 3])
    _test([FALSE, FALSE, FALSE], [False, False, False])
    _test([1, '2', '3'], '123')
    _test([None, 'foo', 'bar', None], 'foobar')
    _test([None, '', 'bar', None], 'bar')

    _test([[1, 2], [3]], [[1, 2], [3]])

# Generated at 2022-06-21 07:50:19.046920
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(["foobar"]) == "foobar"
    assert ansible_native_concat(["foo", "bar"]) == "foobar"
    assert ansible_native_concat(["foo", "bar", "baz"]) == "foobarbaz"
    assert ansible_native_concat(["foo", 42, "baz"]) == "foo42baz"
    assert ansible_native_concat(["foo", 1.23, "baz"]) == "foo1.23baz"
    assert ansible_native_concat(["foo", ("bar",), "baz"]) == "foo('bar',)baz"

# Generated at 2022-06-21 07:50:31.222894
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(['a', u'\u1234', 'c']) == u'a\u1234c'
    assert ansible_native_concat(['a', 12, 'c']) == 'a12c'
    assert ansible_native_concat([12, 'a', 'c']) == '12ac'
    assert ansible_native_concat(['a', ['b', 'c'], 'd']) == 'abcd'
    assert ansible_native_concat(['a', b'b', 'c']) == 'a' + to_text(b'b') + 'c'
    assert ansible_native_concat(['a', object(), 'c'])