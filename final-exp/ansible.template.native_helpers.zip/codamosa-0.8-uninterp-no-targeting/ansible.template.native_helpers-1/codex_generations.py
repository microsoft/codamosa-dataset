

# Generated at 2022-06-21 07:40:40.303464
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class Foo(object):
        def __init__(self, value):
            self.value = value

        def __unicode__(self):
            return to_text(self.value)

    class Bar(object):
        def __init__(self, value):
            self.value = to_text(value)

        def __str__(self):
            return self.value

    assert ansible_native_concat([None]) == None
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', ' ']) == 'a '
    assert ansible_native_concat(['a', ' ', 'b']) == 'a b'

# Generated at 2022-06-21 07:40:51.746304
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    x = ansible_native_concat([u'x', u'y'])
    assert x == u'xy'
    x = ansible_native_concat(u'xy')
    assert x == u'xy'
    x = ansible_native_concat([u'x', 1, u'y'])
    assert x == u'x1y'
    x = ansible_native_concat([u"x'x", 1, u'y'])
    assert x == u"x'x1y"
    x = ansible_native_concat([b'x'])
    assert x == u'x'
    x = ansible_native_concat([u'x', b'y'])
    assert x == u'xy'

# Generated at 2022-06-21 07:41:03.522985
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from collections import OrderedDict
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == u"12"
    assert ansible_native_concat([1, 2, 3]) == u"123"
    assert ansible_native_concat([u"a", 2, 3]) == u"a23"
    assert ansible_native_concat([u"a", u"b", u"c"]) == u"abc"
    assert ansible_native_concat([u"True", u"False", u"None"]) == u"TrueFalseNone"
    assert ansible_native_concat([False, True]) == u"FalseTrue"
    assert ansible_native_concat([1, 2, u"abcd"]) == u'123abcd'

# Generated at 2022-06-21 07:41:13.947795
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([NativeJinjaText(text_type('str1')), NativeJinjaText(text_type('str2'))]) == 'str1str2'
    assert ansible_native_concat([NativeJinjaText(text_type('str1'))]) == 'str1'
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([NativeJinjaText(text_type('1')), NativeJinjaText(text_type('2'))]) == 3
    assert ansible_native_concat([NativeJinjaText(text_type('1')), NativeJinjaText(text_type('2.0'))]) == 3.0

# Generated at 2022-06-21 07:41:23.250340
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == u'12'
    assert ansible_native_concat(['string', 2]) == u'string2'
    assert ansible_native_concat([1, {'key': 'value'}]) == u'1{key: value}'
    assert ansible_native_concat([1, [2, 3]]) == u'1[2, 3]'
    assert ansible_native_concat([1, 'key: value']) == u'{key: value}'



# Generated at 2022-06-21 07:41:33.319986
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """
    Test ansible_native_concat with various different inputs
    """

    # Test empty node list
    assert ansible_native_concat([]) is None

    # Test literal int node
    node = 5
    assert ansible_native_concat([node]) == 5

    # Test literal float node
    node = 5.0
    assert ansible_native_concat([node]) == 5.0

    # Test literal boolean node
    node = True
    assert ansible_native_concat([node]) is True

    # Test literal string node
    node = "literal"
    assert ansible_native_concat([node]) == "literal"

    # Test literal unicode node
    node = u"literal"
    assert ansible_native_concat([node]) == u"literal"

    # Test literal

# Generated at 2022-06-21 07:41:43.852280
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test functions (that we use in our tests)
    def null():
        return None

    def test_string():
        return 'test string'

    def test_vault():
        return AnsibleVaultEncryptedUnicode('vault')

    def test_number():
        return 123

    assert ansible_native_concat([]) is None
    assert ansible_native_concat([
        None,
    ]) is None
    assert ansible_native_concat(['']) == ''
    assert ansible_native_concat(['', '']) == ''

    assert ansible_native_concat([
        None,
        '',
    ]) is None

    assert ansible_native_concat([
        '',
        None,
    ]) is None


# Generated at 2022-06-21 07:41:55.111154
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat(['1', '2', '3']) == '123'
    assert ansible_native_concat([1, '2', 3]) == '123'
    assert ansible_native_concat([NativeJinjaText(1), NativeJinjaText(2), NativeJinjaText(3)]) == '123'
    assert ansible_native_concat([NativeJinjaText('1'), NativeJinjaText(2), NativeJinjaText(3)]) == '123'

# Generated at 2022-06-21 07:42:04.075627
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([123, 234]) == '123234'
    assert ansible_native_concat([True, 233]) == 'True233'
    assert ansible_native_concat(['ansible', 2]) == 'ansible2'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([[1, 2]]) == '[1, 2]'
    assert ansible_native_concat(['[1, 2]']) == '[1, 2]'
    assert ansible_native_concat([b'[1, 2]']) == '[1, 2]'
    assert ansible_native_concat(['[1, 2]', 2]) == '[1, 22]'
    assert ansible_native_con

# Generated at 2022-06-21 07:42:10.874992
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', ' bar']) == 'foo bar'
    assert ansible_native_concat([1, 2]) == 3
    assert ansible_native_concat(['"foo"', "''", '"""', '"bar"']) == '"foobar"'



# Generated at 2022-06-21 07:42:25.085995
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([False]) is False
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1.0]) == 1.0
    assert ansible_native_concat([1.1]) == 1.1
    assert ansible_native_concat([-2]) == -2
    assert ansible_native_concat([-2.0]) == -2.0
    assert ansible_native_concat([-2.2]) == -2.2
    assert ansible_native_concat([10]) == 10
    assert ansible_native_concat([10.5]) == 10.5
    assert ansible_native_concat

# Generated at 2022-06-21 07:42:36.274500
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat(['foo', 'bar', 'baz']) == 'foobarbaz'
    assert ansible_native_concat(['foo', '1', 'bar', '2', 'baz', '3']) == 'foo1bar2baz3'
    assert ansible_native_concat([1, 'foo', 2, 'bar', 3, 'baz']) == '1foo2bar3baz'

# Generated at 2022-06-21 07:42:46.209625
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.native_jinja import NativeJinjaText

    assert ansible_native_concat([None]) is None
    assert ansible_native_concat(['foo', 'bar']) == u'foobar'
    assert ansible_native_concat(['{{ foo }}', 'bar']) == u'foobar'
    assert ansible_native_concat(['foo', '{{ bar }}']) == u'foo{{ bar }}'
    assert ansible_native_concat(['{{ foo }}', '{{ bar }}']) == u'{{ foo }}{{ bar }}'

    # The following test cases are based on the _concat_markup_helper
    # helper function in the upstream Jinja2 library

# Generated at 2022-06-21 07:42:56.354708
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class Undefined:
        def __str__(self):
            raise RuntimeError('StrictUndefined is used')

    assert ansible_native_concat([]) is None

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([0]) == 0
    assert ansible_native_concat([0.0]) == 0.0
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([u'foot\xa3']) == u'foot\xa3'
    assert ansible_native_concat([b'foo']) == b'foo'
    assert ansible_native_concat([Undefined()])

    assert ansible_native_concat([1, 2, 'foo']) == 12
    assert ansible_

# Generated at 2022-06-21 07:43:04.281552
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:43:17.303969
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2]) == u'12'
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([u'foo', 1, 2]) == u'foo12'
    assert ansible_native_concat([u'foo', 1, [], 2]) == u'foo12'
    assert ansible_native_concat([u'foo', u'bar', u'baz']) == u'foobarbaz'
    assert ansible_native_concat([u'foo', u'bar', {u'a': 10, u'b': [1, 2, 3]}]) == u'foobar{u\'a\': 10, u\'b\': [1, 2, 3]}'
    assert ansible

# Generated at 2022-06-21 07:43:28.848412
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert ansible_native_concat([]) == None

    def test(input, expected):
        # The expected value is a function taking the input
        assert expected(input) == ansible_native_concat([input])

    test('foo', lambda _: 'foo')
    test('foo', lambda _: u'foo')
    test(u'foo', lambda _: 'foo')
    test(u'foo', lambda _: u'foo')
    test(1, lambda _: 1)
    test(1.0, lambda _: 1.0)
    test(1.0, lambda _: 1.0)
    test(True, lambda _: True)
    test(False, lambda _: False)

    test('foo', lambda _: ['f', 'o', 'o'])

# Generated at 2022-06-21 07:43:37.680540
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([1, 2, 'abc']) == '1abc'
    assert ansible_native_concat([True, False, 1]) == 'True1'
    assert ansible_native_concat(['a', '', 'c']) == 'ac'
    assert ansible_native_concat(['a', [], 'c']) == 'a[]c'
    assert ansible_native_concat([NativeJinjaText('a'), 'b']) == 'ab'

# Generated at 2022-06-21 07:43:49.373903
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import ast


# Generated at 2022-06-21 07:44:01.583859
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(["foo"]) == "foo"
    assert ansible_native_concat(["foo", "bar"]) == "foobar"
    assert ansible_native_concat(["foo", True, "bar"]) == "foobartruebar"
    assert ansible_native_concat(["foo", u'\u2028']) == "foo\u2028"
    assert ansible_native_concat(["'foo'", u'\u2028']) == "\n'foo'"
    assert ansible_native_concat(["foo", u'\u2028bar']) == "foo\u2028bar"

# Generated at 2022-06-21 07:44:10.009218
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.loader import AnsibleLoader

    def test(value):
        assert ansible_native_concat(AnsibleLoader(value).get_single_data()) == value

    test({'list': [1, 2, 3]})
    test([1, 2, 3])
    test(True)
    test(3.14)
    test(42)
    test('str')
    test(u'uni')

# Generated at 2022-06-21 07:44:21.643235
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([u'foo', u'bar', u'baz']) == u'foobarbaz'
    assert ansible_native_concat([u'foo', u'bar', u'baz']) == u'foobarbaz'
    assert ansible_native_concat([u'foo', u'bar', u'baz']) == u'foobarbaz'
    assert ansible_native_concat([u'foo', u'bar', u'baz']) == u'foobarbaz'

# Generated at 2022-06-21 07:44:28.934310
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import ansible.module_utils.common.json_utils as json_utils

    assert ansible_native_concat(["a123", "'b'", "c"]) == "a123'bc"
    assert ansible_native_concat(["'a'", "b'c'", "'d'"]) == "'abc'd"
    assert ansible_native_concat(["'a'", "'b'", "'c'"]) == "'abc'"
    assert ansible_native_concat(["abc", "def", "ghi"]) == "abcdefghi"
    assert ansible_native_concat(["[1, 2, 3]", "[4, 5, 6]"]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-21 07:44:40.188682
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    '''
    Test that ansible_native_concat returns expected values.
    '''

    from jinja2 import Environment, Undefined

    env = Environment(undefined=StrictUndefined)
    env.filters['native_concat'] = ansible_native_concat


# Generated at 2022-06-21 07:44:52.524884
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import os
    import sys

    modules_path = os.path.normpath(os.path.join(os.path.dirname(__file__), '../..'))
    if modules_path not in sys.path:
        sys.path.append(modules_path)

    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six.moves import range


# Generated at 2022-06-21 07:45:02.388048
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(['']) == ''
    assert ansible_native_concat(['abc']) == 'abc'
    assert ansible_native_concat(['abc', 'def']) == 'abcdef'
    assert ansible_native_concat(['{{ 1 }}']) == '1'
    assert ansible_native_concat(['{{ 1+2 }}']) == '3'
    assert ansible_native_concat(['{{ [1, 2] }}']) == [1, 2]
    assert ansible_native_concat(['{{ [1, 2, 3] }}']) == [1, 2, 3]

# Generated at 2022-06-21 07:45:11.454242
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_native
    from ansible.utils.native_jinja import to_unicode

    def assert_has_content(data):
        assert data is not None
        assert data != ''

    # Test concat
    assert to_native(ansible_native_concat([to_unicode('foo'), to_unicode('bar')])) == 'foobar'

    # Test single value
    assert_has_content(to_native(ansible_native_concat([to_unicode('foo')])))

    # Test empty value
    assert to_native(ansible_native_concat([])) == ''

    # Test boolean
    assert to_native(ansible_native_concat([to_unicode('yes')]))

    # Test None
   

# Generated at 2022-06-21 07:45:21.853018
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == u'foobar'
    assert ansible_native_concat(['foo', 42]) == 'foobar'
    assert ansible_native_concat(['foo', 'bar']) == u'foobar'
    assert ansible_native_concat(['foo', 42]) == 'foobar'

    # nested lists and dicts
    assert ansible_native_concat(['foo', ['bar', 42]]) == ['foobar', 42]
    assert ansible_native_concat(['foo', {'bar': 42}]) == {'foo': 42}

    # support StrictUndefined values
    assert ansible_native_concat([StrictUndefined()]) == StrictUndefined

# Generated at 2022-06-21 07:45:34.245603
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['']) == ''
    assert ansible_native_concat(['true']) == 'true'
    assert ansible_native_concat(['false']) == 'false'
    assert ansible_native_concat(['null']) == 'null'
    assert ansible_native_concat(['10']) == 10
    assert ansible_native_concat(['10.10']) == 10.10
    assert ansible_native_concat(['vars']) == 'vars'
    assert ansible_native_concat(['vars', 'host_results']) == 'varshost_results'
    assert ansible_native_concat([10]) == 10
    assert ansible_native_concat([10.10]) == 10.10
    assert ansible_

# Generated at 2022-06-21 07:45:40.410947
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([
        '',
        [['foo'], 'bar'],
        [],
        '',
        [],
        '',
        [['', '', 'baz']]
    ]) == ['foo', 'bar', None, 'baz']
    assert ansible_native_concat(['foo', 'bar', 'baz']) == 'foobarbaz'



# Generated at 2022-06-21 07:45:50.110665
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['one', 'two', 'three']) == 'onetwothree'
    assert ansible_native_concat(('one', 'two', 'three')) == 'onetwothree'
    assert ansible_native_concat(['1', '2', '3']) == '123'
    assert ansible_native_concat(('1', '2', '3')) == '123'
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat((1, 2, 3)) == [1, 2, 3]
    assert ansible_native_concat([1, '2', 3]) == [1, '2', 3]

# Generated at 2022-06-21 07:46:01.350443
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Ensure that ansible_native_concat() properly converts plain text strings to
    # Python unicode/str types. This is important to prevent code injection and
    # also to prevent incompatibility with Python 3.
    assert ansible_native_concat(u'foo') == u'foo'
    assert ansible_native_concat(u'foo bar') == u'foo bar'
    assert ansible_native_concat(u'foo\nbar\nbaz\n') == u'foo\nbar\nbaz\n'

    # Ensure that ansible_native_concat() properly converts lists.
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'

# Generated at 2022-06-21 07:46:13.597612
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import pytest

    def _test_ansible_native_concat(data, expected):
        template = "{{ %s }}" % data
        result = ansible_native_concat(template)
        assert result == expected

    numeric_literals = [
        '0', '-1', '0.0', '1.2',
        '0j', '1+1j',
        '0b0', '0o0', '0xffff',
        '1_000_000',
    ]


# Generated at 2022-06-21 07:46:21.842907
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['1']) == '1'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, '2']) == '12'
    assert ansible_native_concat([1, NativeJinjaText('2')]) == '12'
    assert ansible_native_concat(['1', NativeJinjaText('2')]) == '12'
    assert ansible_native_concat([NativeJinjaText('1'), NativeJinjaText('2')]) == '12'

# Generated at 2022-06-21 07:46:32.571632
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat([1, 2, '3']) == [1, 2, '3']
    assert ansible_native_concat(['1', 2, '3']) == ['1', 2, '3']
    assert ansible_native_concat(['1', 2, '3']) == ['1', 2, '3']
    assert ansible_native_concat(['[1,2,3]']) == [1, 2, 3]
    assert ansible_native_concat(['[1,2,3]', '[4,5,6]', '[7,8,9]']) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert ansible

# Generated at 2022-06-21 07:46:38.881933
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2
    t = jinja2.Template('''{{ [1,2,3] | map('string') | ansible_native_concat }}''')
    assert t.render() == '[1, 2, 3]'
    t = jinja2.Template('''{{ "abc" | ansible_native_concat }}''')
    assert t.render() == u'abc'


# Generated at 2022-06-21 07:46:46.457013
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:46:56.781690
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedString
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

    assert ansible_native_concat([]) is None
    assert ansible_native_concat(iter([])) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(iter([1])) == 1
    assert ansible_native_concat([1, 2]) == 12
    assert ansible_native_concat(iter([1, 2])) == 12
    assert ansible_native_concat(['a', 1, 2]) == 'a12'

# Generated at 2022-06-21 07:47:08.981450
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u"a", u"b"]) == "ab"
    assert ansible_native_concat([u"a", u"b", u"c"]) == "abc"
    assert ansible_native_concat([[u"a", u"b"], u"c"]) == "abc"
    assert ansible_native_concat([[u"a", u"b"], [u"c", u"d"]]) == "abcd"
    assert ansible_native_concat([[u"a", u"b"], [u"c", [u"d", u"e"]]]) == "abcde"
    assert ansible_native_concat([[u"a", u"b"], [u"c", [u"d", u"e"]]]) == "abcde"
   

# Generated at 2022-06-21 07:47:21.599105
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', [1], True, False, 'bar', None]) == 'foo[1]TrueFalsebarnone'
    assert ansible_native_concat(['foo', '{{', 'qux', '}}']) == 'foo{{qux}}'
    assert ansible_native_concat(['foo', '{%', 'qux', '%}']) == 'foo{%qux%}'
    assert ansible_native_concat(['foo', 'bar', AnsibleVaultEncryptedUnicode('baz')]) == u'foobarbaz'

# Generated at 2022-06-21 07:47:35.839718
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    assert ansible_native_concat(['abc', 'def']) == 'abcdef'

    assert ansible_native_concat(['abc', u'déf']) == u'abcdéf'

    assert ansible_native_concat([b'abc', u'déf']) == u'abcdéf'


# Generated at 2022-06-21 07:47:47.350898
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar', 'baz']) == 'foobarbaz'
    assert ansible_native_concat(['foo', 42, True]) == 'foo42True'
    assert ansible_native_concat([b'foo', b'bar', u'baz']) == 'foobarbaz'
    assert ansible_native_concat([[1, 2, 3], [4, 5, 6]]) == '[1, 2, 3][4, 5, 6]'
    assert ansible_native_concat(['42']) == 42
    assert ansible_native_concat([u'42']) == 42
    assert ansible_native_concat([u'42', u'42', u'42']) == '424242'

# Generated at 2022-06-21 07:47:55.689254
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([2.0]) == 2.0
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([3, 4]) == u'34'

    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat([1.0, 2.0, 3.0]) == 123.0
    assert ansible_native_concat(['a', 'b', 'c']) == u'abc'
    assert ansible_native_concat([1, 'a', 2.0]) == u'1a2.0'


# Generated at 2022-06-21 07:47:57.737965
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = 'hello'
    assert ansible_native_concat(nodes) == 'hello'



# Generated at 2022-06-21 07:48:09.815898
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2]) == "12"
    assert ansible_native_concat(["foo", 1, 2]) == "foo12"
    assert ansible_native_concat(["foo", 1, 2, "bar"]) == "foo12bar"
    assert ansible_native_concat(["foo", 1, 2, "bar"]) == "foo12bar"
    assert ansible_native_concat([text_type("foo"), 1, 2]) == "foo12"
    assert ansible_native_concat([text_type("foo"), 1, 2, text_type("bar")]) == "foo12bar"
    assert ansible_native_concat([text_type("foo"), 1, 2, text_type("bar")]) == "foo12bar"
    assert ansible_native_

# Generated at 2022-06-21 07:48:21.832145
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import pytest

    output = ansible_native_concat([])
    assert output is None

    output = ansible_native_concat([u'1'])
    assert output == 1

    output = ansible_native_concat([u'1.0'])
    assert output == 1.0

    output = ansible_native_concat([u'a'])
    assert output == u'a'

    output = ansible_native_concat([u'a', u'b'])
    assert output == u'ab'

    output = ansible_native_concat([u'a', u'1'])
    assert output == u'a1'

    output = ansible_native_concat([u'1', u'a'])
    assert output == u'1a'

    output = ansible_native

# Generated at 2022-06-21 07:48:32.632698
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    b = 'b'
    assert b == ansible_native_concat((b,))
    assert b == ansible_native_concat([b])
    assert b == ansible_native_concat(iter([b]))

    a = 'a'
    assert "ab" == ansible_native_concat((b, a))
    assert "ab" == ansible_native_concat([b, a])
    assert "ab" == ansible_native_concat(iter([b, a]))

    c = u'c'
    assert "abc" == ansible_native_concat((b, a, c))
    assert "abc" == ansible_native_concat([b, a, c])
    assert "abc" == ansible_native_concat(iter([b, a, c]))

    d

# Generated at 2022-06-21 07:48:43.711691
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:48:53.889669
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def test_str(value):
        return text_type(value)

    def test_concat(*values):
        nodes = [test_str(value) for value in values]
        return ansible_native_concat(nodes)
    assert test_concat(None) is None
    assert test_concat(True) is True
    assert test_concat(False) is False
    assert test_concat(1) == 1
    assert test_concat(1.0) == 1.0
    assert test_concat(1234567890123456789012345678901234567890) == 1234567890123456789012345678901234567890
    assert test_concat('foo') == 'foo'

# Generated at 2022-06-21 07:48:58.299635
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    '''
    Test cases for ansible_native_concat function:
    '''
    import ast
    import types

    # Test empty
    nodes = []
    output = ansible_native_concat(nodes)
    assert output is None

    # Test single element
    nodes = [ast.Num(n=1)]
    output = ansible_native_concat(nodes)
    assert output is 1

    # Test two elements
    nodes = [ast.Num(n=1), ast.Num(n=2)]
    output = ansible_native_concat(nodes)
    assert output is '12'

    # Test three elements
    nodes = [ast.Num(n=1), ast.Num(n=2), ast.Num(n=3)]

# Generated at 2022-06-21 07:49:11.917230
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test with a list of compiled nodes
    assert ansible_native_concat([1, 1, 2, 3, 5, 8, 13, 21, 34]) == [1, 1, 2, 3, 5, 8, 13, 21, 34]
    assert ansible_native_concat([1, 1, 2, 3, 5, 8, 13, 21, 34]) == [1, 1, 2, 3, 5, 8, 13, 21, 34]
    assert ansible_native_concat(['ansible', '123', 'ansible', '321']) == 'ansible123ansible321'
    assert ansible_native_concat(['ansible', '123', 'ansible', '321']) == 'ansible123ansible321'

    # Test with a compiled generator

# Generated at 2022-06-21 07:49:21.233156
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([['foo']]) == 'foo'
    assert ansible_native_concat([['foo'], 'bar']) == 'foobar'
    assert ansible_native_concat([['foo'], ['bar']]) == 'foobar'
    assert ansible_native_concat([42, 'bar']) == '42bar'
    assert ansible_native_concat([42, ['bar'], []]) == '42bar'
    assert ansible_native_concat([42, ['bar'], ['baz']]) == '42barbaz'
    assert ansible_

# Generated at 2022-06-21 07:49:32.824187
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """
    Test that the native concat function behaves as expected.
    """
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import container_to_text


# Generated at 2022-06-21 07:49:44.038977
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2.ext

    env = jinja2.Environment(extensions=[jinja2.ext.do])
    tpl = env.from_string('{{ [a, b, c]|join("") }}')
    # When some of the nodes are not strings, literal_eval should
    # not be called and the original data should be returned.
    assert tpl.render({'a': 'b', 'b': 2, 'c': '{{d}}'}) == 'b2{{d}}'

    env = jinja2.Environment(extensions=[jinja2.ext.do])
    tpl = env.from_string('{{ a }}')
    # When some of the nodes are not strings, literal_eval should
    # not be called and the original data should be returned.

# Generated at 2022-06-21 07:49:52.350492
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import sys

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest


# Generated at 2022-06-21 07:50:03.447408
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['test']) == u'test'
    assert ansible_native_concat(['test', 'test']) == u'testtest'
    assert ansible_native_concat([1, 2, 3]) == u'123'
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat(['string', '-', 'test', '-', 'concat']) == u'string-test-concat'
    assert ansible_native_concat(['1', ' ', '+', ' ', '2']) == u'1 + 2'

# Generated at 2022-06-21 07:50:14.270054
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2.runtime import Undefined
    from ansible.module_utils.common.text.converters import to_native

    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 'bar', 'baz']) == 'foobarbaz'
    assert ansible_native_concat(['1', '2']) == [1, 2]
    assert ansible_native_concat(['foo', Undefined(), 'bar']) is Undefined
    assert ansible_native_concat(['foo', Undefined() + 'bar']) is Undefined

    # test that it doesn't do regex substitution on strings
    assert ansible_native_concat

# Generated at 2022-06-21 07:50:20.516606
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == 1

    assert ansible_native_concat([]) is None

    assert ansible_native_concat([1, 2, 3]) == 1

    assert ansible_native_concat(['a', ' ', 'b']) == 'a b'

    assert ansible_native_concat([['a'], ['b']]) == ['a', 'b']

    assert ansible_native_concat([['a', ' '], u'b']) == ['a', ' ', 'b']

    assert ansible_native_concat([['a', ' '], u'b']) == ['a', ' ', 'b']

    assert ansible_native_concat([u'a', u'b', u'c']) == u'abc'

    assert ansible

# Generated at 2022-06-21 07:50:31.854615
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test empty node
    assert ansible_native_concat([]) is None

    # Test one node
    assert ansible_native_concat([0]) == 0

    # Test two nodes and the generator case
    assert ansible_native_concat([1, 2]) == u'12'
    assert ansible_native_concat(iter([1, 2])) == u'12'

    # Test literal_eval
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['1\n', '+\n', '1']) == 2
    assert ansible_native_concat(['1\t', '+\t', '1']) == 2

    # Test literal_eval with a complex expression and the generator case