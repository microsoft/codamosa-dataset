

# Generated at 2022-06-21 07:40:40.374720
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def _test(a, b, expected):
        result = ansible_native_concat([a, b])
        assert result == expected

    _test(None, None, None)
    _test(0, 1, 0)
    _test(1, 2, '12')
    _test(3, 4, '34')
    _test('5', 6, '56')
    _test(7, '8', 78)
    _test('9', '0', '90')
    _test('a', 'b', 'ab')
    _test('c', 'd', 'cd')
    _test(u'e', u'f', u'ef')
    _test(u'g', u'h', u'gh')
    _test(u'i', u'j', u'ij')

# Generated at 2022-06-21 07:40:48.693743
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import ansible.module_utils.jinja2.native as native

    class NStrictUndefined:
        def __add__(self, other): return '42'
        __radd__ = __add__

    class UStrictUndefined:
        def __add__(self, other): return u'42'
        __radd__ = __add__

    class BStrictUndefined:
        def __add__(self, other): return b'42'
        __radd__ = __add__

    class DStrictUndefined:
        def __add__(self, other): return dict(a=1)
        __radd__ = __add__

    class LStrictUndefined:
        def __add__(self, other): return [1, 2, 3]
        __radd__ = __add__


# Generated at 2022-06-21 07:41:01.504639
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.six.moves import builtins
    from ansible.parsing.yaml.loader import AnsibleVaultLoader
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.collections import is_sequence, is_mapping

    nodes = (1, 'two', u'three', b'four', AnsibleVaultEncryptedUnicode(b'five'))
    assert ansible_native_concat(nodes) == u'1two3fourfive'

    nodes = (1, 'two', u'three', b'four', u'five')
    assert ansible_native_concat(nodes) == 1


# Generated at 2022-06-21 07:41:13.038104
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'a']) == u'a'
    assert ansible_native_concat([u'a', u'b']) == u'ab'
    assert ansible_native_concat([u'a', u'b', u'c']) == u'abc'

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, 2, 3]) == '123'

    assert ansible_native_concat([1.1]) == 1.1
    assert ansible_native_concat([1.1, 2]) == '1.12'
    assert ansible_native_concat([1.1, 2, 3]) == '1.123'


# Generated at 2022-06-21 07:41:23.971176
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['0', '1', '2']) == '012'
    assert ansible_native_concat([u'0', u'1', u'2']) == '012'
    assert ansible_native_concat(['0', '1', 2]) == '012'
    assert ansible_native_concat(['0', '1', 2]) == '012'
    assert ansible_native_concat([0, 1, '2']) == '012'
    assert ansible_native_concat(['1', '2', '3']) == '123'
    assert ansible_native_concat(['1', '2', '3']) == '123'
    assert ansible_native_concat(['1', '2', '3']) == '123'

# Generated at 2022-06-21 07:41:31.272796
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = [1, 2, 3, 4]
    assert ansible_native_concat(nodes) == [1, 2, 3, 4]
    assert ansible_native_concat(nodes[:1]) == 1
    assert ansible_native_concat([1, 2, 3, u'45']) == [1, 2, 3, 45]
    assert ansible_native_concat([1, 2, u'3.45']) == [1, 2, 3.45]
    assert ansible_native_concat([u'data.ext_ipv4', 4]) == u'data.ext_ipv4 4'
    assert ansible_native_concat([u'{{ data.ext_ipv4 }}', 4]) == u'{{ data.ext_ipv4 }} 4'
    assert ansible_

# Generated at 2022-06-21 07:41:43.172356
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', '{{a}}', 'b']) == 'a{{a}}b'
    assert ansible_native_concat(['a', '{{a}}', '{{b}}', 'b']) == 'a{{a}}{{b}}b'
    assert ansible_native_concat(['a', '{{a}}', '{{b}}', 'b', 'c']) == 'a{{a}}{{b}}bc'
    assert ansible_native_concat(['a', '{{a}}', '{{b}}', '{{c}}', 'b', 'c']) == 'a{{a}}{{b}}{{c}}bc'

# Generated at 2022-06-21 07:41:54.822082
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(["a", "b", "c"]) == "abc"
    assert ansible_native_concat([1, 2, 3]) == 1
    assert ansible_native_concat([False, True]) == False
    assert ansible_native_concat(("a", u"b", "c")) == "abc"
    assert ansible_native_concat(("ab", u"c", "d")) == "abcd"
    assert ansible_native_concat(("a", "b", "c")) == "abc"
    assert ansible_native_concat(["a", "b", "c"]) == "abc"
    data = {'a': 1, 'b': 'c'}
    assert ansible_native_concat([data]) == data
    assert ansible_native

# Generated at 2022-06-21 07:42:03.840759
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(['a', 1, 'c']) == 'a1c'
    assert ansible_native_concat(['a', True, 'c']) == 'aTruec'
    assert ansible_native_concat(['a', ['b'], 'c']) == 'a[\'b\']c'
    assert ansible_native_concat(['a', ['b'], 'c']) == 'a[\'b\']c'

# Generated at 2022-06-21 07:42:12.136723
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat([1, '', 3]) == '13'
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['', 1, '', 2, '', 3]) == '123'
    assert ansible_native_concat(['1', '2', '3']) == [1, 2, 3]
    assert ansible_native_concat(['[1, 2, 3]']) == [1, 2, 3]

    # Test with text
    assert ansible_native_concat(['1', 2]) == u'12'

# Generated at 2022-06-21 07:42:25.202261
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # empty list
    result = ansible_native_concat([])
    assert result is None

    # test single node
    result = ansible_native_concat(['foo'])
    assert result == 'foo'

    # test multiple nodes as generator
    result = ansible_native_concat(n for n in ['foo', 'bar'])
    assert result == 'foobar'

    # test list of node objects
    nodes = [{'key': 'value'}, [True, False]]
    result = ansible_native_concat(nodes)
    assert result == '[{0}{0}  {1}: {2}{0}{0}]'.format(container_to_text('\n'),
                                                       container_to_text('key'),
                                                       container_to_text('value'))

# Generated at 2022-06-21 07:42:36.308242
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([NativeJinjaText(u'1'), u'\n', NativeJinjaText(u'2')]) == '1\n2'
    # returns literal string for non-unicode strings
    assert ansible_native_concat([b'1', b'\n', b'2']) == '1\n2'
    # returns literal string for non-unicode strings
    assert ansible_native_concat([u'1', u'\n', u'2']) == '1\n2'
    assert ansible_native_concat([u'1', u'\n', u'2']) == '1\n2'
    assert ansible_native_concat([u'1', u'\n', u'2']) == '1\n2'
    assert ans

# Generated at 2022-06-21 07:42:46.245337
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['this', ' ', 'is', ' ', 'good']) == 'this is good'
    assert ansible_native_concat(['123', ' ', '456']) == '123 456'
    assert ansible_native_concat(['123', ' ', '456']) == '123 456'
    assert ansible_native_concat(['this ', ' is ', ' a ', ' list']) == 'this  is  a  list'
    assert ansible_native_concat([b'this ', b' is ', b' a ', b' list']) == b'this  is  a  list'
    assert ansible_native_concat([b'this ', b' is ', b' a ', b' list']) == b'this  is  a  list'
    assert ansible

# Generated at 2022-06-21 07:42:56.424877
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
    from ansible.utils.vars import combine_vars


# Generated at 2022-06-21 07:43:06.303324
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == "12"
    assert ansible_native_concat(['1', 2]) == "12"
    assert ansible_native_concat(["1 23", 2]) == "1 232"
    assert ansible_native_concat(["1 23", "2"]) == "1 232"
    assert ansible_native_concat(["1 2 3", "2"]) == "1 2 32"
    assert ansible_native_concat(["1 2 3", {'a': 'b'}]) == "1 2 3{'a': 'b'}"

# Generated at 2022-06-21 07:43:18.487717
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['"a"', '"b"']) == 'ab'
    assert ansible_native_concat(['. "ab"', '"c"']) == 'abc'
    assert ansible_native_concat(['. "ab"', '"c"', '"d"']) == 'abcd'
    assert ansible_native_concat(['. "ab"', '"c"', '"d"', '"e"']) == 'abcde'
    assert ansible_native_concat(['. "ab"', '"c"', '"d"', '"e"', '"f"']) == 'abcdef'

# Generated at 2022-06-21 07:43:30.689224
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    pwd = '12345'
    vault_str = AnsibleVaultEncryptedUnicode(pwd, 'my secret string')
    assert ansible_native_concat([vault_str]) == 'my secret string'
    assert ansible_native_concat([vault_str, vault_str]) == 'my secret stringmy secret string'
    assert ansible_native_concat([vault_str, vault_str, '']) == 'my secret stringmy secret string'
    assert ansible_native_concat([vault_str, vault_str, vault_str]) == 'my secret stringmy secret stringmy secret string'

# Generated at 2022-06-21 07:43:39.955171
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Tests for our use of `string` filter
    assert ansible_native_concat([u'a', u'b']) == u'ab'
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1, 2]) == [1, 2]
    assert ansible_native_concat([1, StrictUndefined]) is None
    assert ansible_native_concat([1, []]) == [1, []]
    assert ansible_native_concat([1, [StrictUndefined]]) is None
    assert ansible_native_concat([1, {'b': StrictUndefined}]) is None
    assert ansible_native_concat([1, {'b': 2}]) == [1, {'b': 2}]

    # Tests for other uses of

# Generated at 2022-06-21 07:43:50.154718
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(iter([])) is None
    assert ansible_native_concat(iter([True])) is True
    assert ansible_native_concat(iter([False])) is False
    assert ansible_native_concat(iter([1])) == 1
    assert ansible_native_concat(iter([1.0])) == 1.0
    assert ansible_native_concat(iter([-1])) == -1
    assert ansible_native_concat(iter([-1.0])) == -1.0
    assert ansible_native_concat(iter([1, 2])) == '12'
    assert ansible_native_concat(iter([1, 2]), True) == [1, 2]

# Generated at 2022-06-21 07:44:01.997130
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # test with list of nodes
    nodes = [
        'The quick brown ',
        'fox',
        ' jumped over the lazy ',
        'dog',
        ''
    ]

    # actual result
    actual = ansible_native_concat(nodes)

    # expected result
    expected = "The quick brown fox jumped over the lazy dog"

    if actual != expected:
        raise AssertionError(
            "The result of ansible_native_concat [actual] is not equal to the expected one [expected]"
        )

    # test with single node
    nodes = ['The quick brown fox jumped over the lazy dog']

    # actual result
    actual = ansible_native_concat(nodes)

    # expected result
    expected = "The quick brown fox jumped over the lazy dog"

    if actual != expected:
        raise

# Generated at 2022-06-21 07:44:19.267229
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat([""]) == ""
    assert ansible_native_concat(["", ""]) == "  "
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(["1"]) == 1
    assert ansible_native_concat([1, 2]) == "12"
    assert ansible_native_concat(["1", "2"]) == "12"
    assert ansible_native_concat(["1", 2, "3"]) == "123"
    assert ansible_native_concat(["1", "2", 3]) == "123"
    assert ansible_native_concat(["1", "2", 3, 4]) == "1234"
    assert ans

# Generated at 2022-06-21 07:44:28.013846
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # This unit test tries to cover all the complex behavior of
    # ansible_native_concat as much as possible.
    import jinja2

    # ansible_native_concat is a function to be used as an extension
    # and needs to be registered with jinja2 environment.
    jinja2_env = jinja2.Environment()
    jinja2_env.globals['ansible_native_concat'] = ansible_native_concat
    jinja2_env.extend(ansible_native_concat)

    # The tests are taken from the upstream jinj2/nativetypes.py unit test

# Generated at 2022-06-21 07:44:39.560498
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2

    # By default the test uses the python implementation of AnsibleNativeConcat
    template_loader = jinja2.BaseLoader()
    env = jinja2.Environment(loader=template_loader)
    assert env.eval_ctx.concat_function(['foo']) == 'foo'
    assert env.eval_ctx.concat_function(['foo', 'bar']) == 'foobar'
    assert env.eval_ctx.concat_function(['foo', [1], 'bar']) == 'foo[1]bar'
    assert env.eval_ctx.concat_function([[1], [2], [3]]) == '[1][2][3]'
    assert env.eval_ctx.concat_function([1, 2, 3]) == '123'

# Generated at 2022-06-21 07:44:51.677183
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml import objects as data_structures
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import yaml

    dumper = AnsibleDumper(default_flow_style=False, default_style='')

    # test string concatenation
    a = text_type('hello, ')
    b = text_type('world')
    c = ansible_native_concat([a, b])
    assert type(c) is text_type
    assert c == u'hello, world'

    # test list concatenation
    a = data_structures.AnsibleSequence()
    a.extend([1, 2, 3])
    b = data_structures.AnsibleSequence()
    b.extend([4, 5, 6])

# Generated at 2022-06-21 07:45:01.229534
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2.nodes import List, Const, Tuple

    def test_out(out, expected):
        assert out == expected, '{} != {}'.format(out, expected)

    test_out(ansible_native_concat([]), None)
    test_out(ansible_native_concat([Const(1)]), 1)
    test_out(ansible_native_concat([Const(1), Const(2)]), '12')
    test_out(ansible_native_concat([Const(1), Const(2)]), '12')
    test_out(ansible_native_concat([Const('1')]), '1')
    test_out(ansible_native_concat([Const('1'), Const('2')]), '12')

# Generated at 2022-06-21 07:45:07.134277
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([123]) == 123
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 'bar', 123]) == 'foobar123'

# Generated at 2022-06-21 07:45:19.068124
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import Environment

    # if we pass a single string in, it should not be truned into a unicode string
    env = Environment(undefined=Undefined)
    rendered = env.from_string('{{ myvar | to_json | string }}').render(myvar="foo")
    assert rendered == '"foo"', rendered

    # strings should be combined into a single unicode string
    env = Environment(undefined=Undefined)
    rendered = env.from_string('{{ myvar1 }}|{{ myvar2 }}').render(myvar1="foo", myvar2="bar")
    assert rendered == "foo|bar", rendered

    # strings should be combined into a single unicode string even when int literals are used
    env = Environment(undefined=Undefined)

# Generated at 2022-06-21 07:45:25.215022
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """
    A function to test ansible_native_concat.
    """
    # For evaluate python expression to native python type
    assert ansible_native_concat([u'3']) == 3
    assert ansible_native_concat([u'True']) is True
    assert ansible_native_concat([u'False']) is False
    assert ansible_native_concat([u'None']) is None
    assert ansible_native_concat([u'[1, 2, 3]']) == [1, 2, 3]
    assert ansible_native_concat([u'[1, 2,"3"]']) == [1, 2, "3"]
    assert ansible_native_concat([u'{"key": 1}']) == {"key": 1}

# Generated at 2022-06-21 07:45:36.945291
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:45:47.187478
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import pytest
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    # Now to test all permutations of data types
    # jinja2.nodes.List and jinja2.nodes.Const are the only types
    # we will pass in
    data_in_pairs = [(['a'], 'b'),
                     (['a', 'b'], 'c'),
                     (['a', 1, 'b', 2, 'c'], 'd')]
    expected_out_types = [list, text_type, list, text_type, list]

# Generated at 2022-06-21 07:46:03.247774
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo']) != u'foo'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1]) != u'1'
    assert ansible_native_concat(['1']) == '1'
    assert ansible_native_concat(['1']) != 1
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat(['1', '2']) != 3
    assert ansible_native_concat(['1', '2', '3']) == '123'

# Generated at 2022-06-21 07:46:14.902970
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'{', u'bar', u':', u'foo', u'}']) == {u'bar': u'foo'}
    assert ansible_native_concat([u'"foo"', u' "bar"']) == u'foo bar'
    assert ansible_native_concat([u'"foo"', u' "bar",']) == u'foo bar,'
    assert ansible_native_concat([u'"foo"', u' "bar",', None]) == u'foo bar,'
    assert ansible_native_concat([u'"foo"', u' "bar",', u' "baz"']) == "foo bar, baz"
    assert ansible_native_concat([u'"foo"', u' "bar\\"']) == "foo bar\\"
    assert ansible

# Generated at 2022-06-21 07:46:22.229714
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    '''
    Tests for the ansible_native_concat function
    '''

    if hasattr(ansible_native_concat, '__wrapped__'):
        ansible_native_concat = ansible_native_concat.__wrapped__

    # Literal cases
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['abc']) == 'abc'
    assert ansible_native_concat(['1.1']) == 1.1
    assert ansible_native_concat(['True']) is True
    assert ansible_native_concat(['False']) is False
    assert ansible_

# Generated at 2022-06-21 07:46:28.797468
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(["hello"]) == "hello"
    assert ansible_native_concat(["hello", "world"]) == "helloworld"
    assert ansible_native_concat(["hello", "world", "how", "are", "you"]) == "helloworldhowareyou"
    assert ansible_native_concat(["hello", " ", "world"]) == "hello world"
    assert ansible_native_concat(["hello", None]) == "helloNone"
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([1, 2, 3]) == "123"
    assert ansible_native_concat([-1, 0, 1]) == "-101"

# Generated at 2022-06-21 07:46:36.376261
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # test concat of strings
    assert ansible_native_concat(['12', '34']) == '1234'
    assert ansible_native_concat(['123', '456']) == '123456'
    assert ansible_native_concat(['123', '4']) == '1234'
    assert ansible_native_concat(['12', '34']) == '1234'
    assert ansible_native_concat(['12', '34']) == '1234'

    # test concat of dictionaries
    assert ansible_native_concat([{'a': 'b'}, {'c': 'd'}]) == {'a': 'b', 'c': 'd'}

    # test concat of integers

# Generated at 2022-06-21 07:46:45.845192
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    class Undefined(object):
        def __mod__(self, other):
            raise Exception()

        def __add__(self, other):
            raise Exception()

        def __radd__(self, other):
            raise Exception()

        def __unicode__(self):
            raise Exception()

        def __str__(self):
            raise Exception()

        def __repr__(self):
            return 'Undefined'
    undefined = Undefined()
    strict_undefined = StrictUndefined('a')
    # Test basic concatenation
    assert ansible_native_concat([1, 2, 3]) == 123

# Generated at 2022-06-21 07:46:56.575312
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from .stubs import jinja2_stubs

    result = ansible_native_concat([1234, 5678])
    assert result == 1234

    result = ansible_native_concat(["hello", "world"])
    assert result == "helloworld"

    result = ansible_native_concat([["hello", "world"], "ya"])
    assert result == "helloworldya"

    result = ansible_native_concat([[True, "hello"], ["world", "ya"]])
    assert result == "[True, 'hello']worldya"

    result = ansible_native_concat([[True, "hello"], ["world", "ya"]],
                                   environment=jinja2_stubs.undefined_jinja_env())
    assert result == "Truehelloworldya"

# Generated at 2022-06-21 07:47:08.739840
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2

    # StrictUndefined is an arbitrary object that we'll use to detect if the
    # result of the expression we try to evaluate is undefined or if it's the
    # result of a native evaluation.
    class StrictUndefined(object):
        def __str__(self):
            raise jinja2.UndefinedError()

        def __repr__(self):
            raise jinja2.UndefinedError()

    # This is what we use in Ansible to detect ansible undefined exceptions.
    ansible_undefined = StrictUndefined()

    def test_case(template, expected):
        env = jinja2.Environment(undefined=ansible_undefined)
        env.filters['native_concat'] = ansible_native_concat
        assert env.from_string(template).render

# Generated at 2022-06-21 07:47:21.547020
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Unit test for function ansible_native_concat"""

    assert ansible_native_concat([]) is None

    assert ansible_native_concat(['a']) == 'a'

    assert ansible_native_concat(['a', 'b']) == 'ab'

    assert ansible_native_concat(['a', 1]) == 'a1'

    assert ansible_native_concat(['a', 1.0]) == 'a1.0'

    assert ansible_native_concat(['a', [1, 2]]) == 'a[1, 2]'

    assert ansible_native_concat(['a', {'b': 2}]) == "a{'b': 2}"


# Generated at 2022-06-21 07:47:29.092964
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2.nodes import EvalContext, Name, TemplateData

    def _render_node(n):
        return ansible_native_concat(
            ansible_native_concat.environment.node_generator(
                EvalContext(n),
            )
        )


# Generated at 2022-06-21 07:47:48.557157
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.template.safe_eval import _native_concat

    # original function starts with this
    assert _native_concat([1, 'foo', 2.0, 'bar']) == '1foobar'

    # our function does this
    assert ansible_native_concat([1, 'foo', 2.0, 'bar']) == [1, 'foo', 2.0, 'bar']



# Generated at 2022-06-21 07:47:56.385187
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # TODO: upstream native types
    from jinja2.nodes import NativeConcat
    from jinja2.runtime import Context
    from jinja2.environment import NativeEnvironment
    import jinja2.nodes
    env = NativeEnvironment()
    concat = NativeConcat(env)
    node = jinja2.nodes.Template

    assert concat._native_concat(Context({}), node, None) is None
    assert concat._native_concat(Context({}), node, []) is None
    assert concat._native_concat(Context({}), node, [None]) is None
    assert concat._native_concat(Context({}), node, [None, None]) is None
    assert concat._native_concat(Context({}), node, ['', None, '', None])

# Generated at 2022-06-21 07:48:08.791494
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == 1

    assert ansible_native_concat([True, False]) is True
    assert ansible_native_concat([False, True]) is False

    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['{{ foo }}', '{{ bar }}']) == '{{ foo }}{{ bar }}'
    assert ansible_native_concat(['{{ foo | bar }}', '{{ baz }}']) == '{{ foo | bar }}{{ baz }}'

    assert ansible_native_concat(['foo', '{{ bar }}']) == 'foo{{ bar }}'
    assert ansible_native_concat(['{{ foo }}', 'bar']) == '{{ foo }}bar'



# Generated at 2022-06-21 07:48:15.523991
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import Environment, DictLoader

    e = Environment(loader=DictLoader({'ans': '{{ [a, b, c] }}'}))
    r = e.get_template('ans').render(a=1, b=2, c=3)
    assert isinstance(r, text_type)
    assert r == u'[1, 2, 3]'

    r = e.get_template('ans').render(a='1', b=u'2', c=3)
    assert isinstance(r, text_type)
    assert r == u'"123"'

    r = e.get_template('ans').render(a=1, b='2', c=3)
    assert isinstance(r, int)
    assert r == 123


# Generated at 2022-06-21 07:48:24.962295
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Regression test for https://github.com/ansible/ansible/issues/70831
    # We need to ensure that `ansible_native_concat` does not convert
    # strings to Python's native types.

    # Test with empty generator
    assert ansible_native_concat((v for v in [])) is None

    # Test with a single value
    assert ansible_native_concat((v for v in [1])) == 1
    assert ansible_native_concat((v for v in [AnsibleVaultEncryptedUnicode('vaULT::1:::'),])).data == 1
    assert ansible_native_concat((v for v in ['vaULT::1:::'])) == 'vaULT::1:::'

    # Test with concatenated values

# Generated at 2022-06-21 07:48:33.649692
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([['foo'], 'bar']) == ['foo', 'bar']
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([' ']) == ' '
    assert ansible_native_concat(['']) is None
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([None]) is None

# The same as built-in concat, but with a different name and also handles
# sequences of relations.

# Generated at 2022-06-21 07:48:44.806342
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    data = [
        (True, True),
        (5, 5),
        ("hello", "hello"),
        ((True,), (True,)),
        (("hello",), ("hello",)),
        (((True,),), ((True,),)),
        ((("hello",),), (("hello",),)),
        (("hello", "world"), "helloworld"),
        (("hello", 1), "hello1"),
        (((("hello", 1),),), (("hello1",),)),
        (("hello", False, "world"), "hellofalseworld"),
        ((("hello", False, "world"),), (("hellofalseworld",),)),
    ]

    for original, expected in data:
        result = ansible_native_concat(original)

# Generated at 2022-06-21 07:48:53.768691
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class TestUndefined(StrictUndefined):
        def __str__(self):
            return "foo"

    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == "12"
    assert ansible_native_concat(map(int, ["1", "2", "3"])) == "123"
    assert ansible_native_concat(map(TestUndefined, "abc")) == 'foo'
    assert ansible_native_concat([TestUndefined(), TestUndefined(), TestUndefined()]) == 'foofoofoo'
    assert ansible_native_concat(["a", "b", TestUndefined(), "c", "d", TestUndefined()]) == 'abfoo', u'abc'

# Generated at 2022-06-21 07:49:02.510107
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert container_to_text(ansible_native_concat(['foo', 'bar'])) == u'foobar'
    assert ansible_native_concat(['foo', '', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 123, 'bar']) == 'foo123bar'
    assert ansible_native_concat([123, 'foo', 'bar']) == '123foobar'
    assert ansible_native_concat([True, 'foo', 'bar']) == 'Truefoobar'

# Generated at 2022-06-21 07:49:12.565954
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert (ansible_native_concat(["abc", "def"]) == "abcdef")
    assert (ansible_native_concat(["abc", 1, "def"]) == "abc1def")
    assert (ansible_native_concat(["abc", "def"]) == "abcdef")
    assert (ansible_native_concat(["abc", 1.0, "def"]) == "abc1.0def")
    assert (ansible_native_concat(["abc", 1.01, "def"]) == "abc1.01def")
    assert (ansible_native_concat(["abc", 1.00, "def"]) == "abc1.0def")
    assert (ansible_native_concat(["abc", True, "def"]) == "abctrue")

# Generated at 2022-06-21 07:49:52.383080
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat((x for x in ['foo', 'bar'])) == 'foobar'
    assert ansible_native_concat([[1, 2], [3, 4]]) == [1, 2, 3, 4]
    assert ansible_native_concat(['{', '"a":', '1', ',', '"b":', '2', '}']) == {'a': 1, 'b': 2}
    assert ansible_native_concat(['"foo"', '"bar"']) == 'foobar'

# Generated at 2022-06-21 07:50:03.446381
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # Only a NativeJinjaText node
    data = u"foo"
    node = NativeJinjaText(data)
    assert ansible_native_concat((node,)) == data

    # Only a non-string node
    data = [u"foo"]
    node = data
    assert ansible_native_concat((node,)) == data

    # Only string nodes
    data = u"foo"
    node = data
    assert ansible_native_concat((node,)) == data

    # Only an AnsibleUnsafeText node
    data = u"foo"
    node = AnsibleUnsafeText(data)
    assert ansible_native_concat((node,)) == data

    # Only an AnsibleVaultEncryptedUnicode

# Generated at 2022-06-21 07:50:14.267983
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    # Test that one string or number results in a string or number
    assert ansible_native_concat(['123']) == '123'
    assert ansible_native_concat([123]) == 123
    assert ansible_native_concat(['a string']) == 'a string'
    # Test that a list of numbers results in a string
    assert ansible_native_concat(['1', '2', '3']) == '123'
    # Test that a list of strings results in a string
    assert ansible_native_concat(['a', ' ', 'string']) == 'a string'
    # Test that an empty string doesn't fail the eval
    assert ansible_native_concat(['']) == ''
    # Test that a sequence of characters can't be

# Generated at 2022-06-21 07:50:20.249847
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import sys
    if sys.version_info < (2, 8):
        assert ansible_native_concat([1, "B"]) is None
        assert ansible_native_concat(["A", "B"]) == "AB"
        assert ansible_native_concat(["A"]) == "A"
        assert ansible_native_concat([]) is None
    else:
        assert ansible_native_concat([1, "B"]) is None
        assert ansible_native_concat(["A", "B"]) == "AB"
        assert ansible_native_concat(["A"]) == "A"
        assert ansible_native_concat([]) is None

_empty = object()



# Generated at 2022-06-21 07:50:31.722394
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class Env(object):
        def __init__(self, undefined_class=StrictUndefined):
            self.undefined_class = undefined_class

        def get_undefined(self, obj, name):
            return self.undefined_class(hint=None, obj=obj, name=name)

    env = Env()

    def undefined_mock(hint=None, obj=None, name=None):
        return StrictUndefined(hint=hint, obj=obj, name=name)

    def literal_eval_mock(s):
        return ast.literal_eval(s)

    def test_eval(in_, out):
        assert ansible_native_concat(in_) == out

    # Test no input
    test_eval((), None)

    # Test single node
   