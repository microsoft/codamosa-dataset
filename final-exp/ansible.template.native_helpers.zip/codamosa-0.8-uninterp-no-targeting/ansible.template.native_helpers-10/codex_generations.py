

# Generated at 2022-06-21 07:40:40.546805
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    true = True
    class Foo(object):
        def __repr__(self):
            return 'bar'

        def __str__(self):
            return '(str) bar'

    assert ansible_native_concat(iter([1, 2, 3])) == [1, 2, 3]
    assert ansible_native_concat(iter([1, 2.0, 3])) == [1, 2.0, 3]
    assert ansible_native_concat(iter(['1', '2', '3'])) == ['1', '2', '3']
    assert ansible_native_concat(iter([1, '2', 3])) == [1, '2', 3]
    assert ansible_native_concat(iter([1, 2, 'true'])) == [1, 2, 'true']
   

# Generated at 2022-06-21 07:40:53.591615
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(()) == None
    assert ansible_native_concat(('true',)) is True
    assert ansible_native_concat(('false',)) is False
    assert ansible_native_concat(('1',)) == 1
    assert ansible_native_concat(('',)) == ''
    assert ansible_native_concat((1,)) == 1
    assert ansible_native_concat(('', '',)) == ''
    assert ansible_native_concat(('ab',)) == 'ab'
    assert ansible_native_concat(('a', 'b')) == 'ab'
    assert ansible_native_concat(('a', 'b', 'c')) == 'abc'

# Generated at 2022-06-21 07:40:58.455362
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'abc', u'def']) == u'abcdef'
    assert ansible_native_concat([u'a', 1, [u'b', u'c']]) == u'a1[u\'b\', u\'c\']'  # noqa
    assert ansible_native_concat([u'a', u'b', u'c']) == u'abc'
    assert ansible_native_concat(u'abc') == u'abc'
    assert ansible_native_concat(1) == 1
    assert ansible_native_concat(None) is None



# Generated at 2022-06-21 07:41:11.648141
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert ansible_native_concat([]) is None
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat(['42']) == 42
    assert ansible_native_concat([['a', 'b']]) == ['a', 'b']
    assert ansible_native_concat([['a', 'b'], ['c', 'd']]) == 'abcd'
    assert ansible_native_concat([['a', 'b'], ['c', 'd'], ['e', 'f']]) == 'abcdef'
    assert ansible_native_concat([[1], [2], [3]]) == '123'

# Generated at 2022-06-21 07:41:23.287605
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_text

    from jinja2.runtime import Undefined

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([True]) == True
    assert ansible_native_concat([[1, 2], ['a', 'b']]) == [1, 2, 'a', 'b']
    assert ansible_native_concat(['1a', '2b']) == '1a2b'
    assert ansible_native_concat(['1a2b']) == '1a2b'
    assert ansible_native_concat([Undefined(name='foo')]) == Undefined(name='foo')

# Generated at 2022-06-21 07:41:33.353425
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible_collections.ansible.builtin.plugins.filter.jmespath import ast_interpreter, Undefined, UndefinedErrorException

    def _equal(nodes, expected):
        values = [v.value if isinstance(v, UndefinedErrorException) else v for v in nodes]
        assert ansible_native_concat(values) == expected, repr(values)

    _equal([], None)
    _equal([42], 42)
    _equal([True], True)
    _equal(['foo'], 'foo')
    _equal(['foo', 'bar'], 'foobar')
    _equal([u'foo', u'bar'], u'foobar')

    _equal([b'foo', b'bar'], u'foobar')

# Generated at 2022-06-21 07:41:43.884234
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1, 2, 3]) == u'123'
    assert ansible_native_concat([1, 2, 'a']) == u'1a'
    assert ansible_native_concat(['a', 2, 'a']) == u'a'

    # test literal_eval functionality
    assert ansible_native_concat(["'a'"]) == u'a'
    assert ansible_native_concat(["'a", "b'"]) == u'a b'
    assert ansible_native_concat(['"a"', "'b'"]) == u"a"
    assert ansible_native_concat(['"a', "'b'"]) == u'a b'
    assert ansible_

# Generated at 2022-06-21 07:41:55.147258
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'

    assert ansible_native_concat(['1']) == '1'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat(['1', 2]) == '12'
    assert ansible_native_concat(['1', 2, '3']) == '123'

    assert ansible_native_concat([1, '2']) == '12'
    assert ansible_native_concat([1, '2.0']) == '12.0'
    assert ansible_native_concat(['1', 2.0]) == '12.0'

# Generated at 2022-06-21 07:42:04.104495
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.template import Templar
    templar = Templar(loader=None, variables={'spam': ['a', 'b', 'c']})

# Generated at 2022-06-21 07:42:12.768370
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:42:24.095923
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(['a', 'b', 'c', 'd']) == 'abcd'
    assert ansible_native_concat(['a', 'b', 'c', 'd', 'e']) == 'abcde'
    assert ansible_native_concat([u'a']) == u'a'

# Generated at 2022-06-21 07:42:35.883002
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'

    assert ansible_native_concat([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert ansible_native_concat([1, u'2', 3, u'4']) == [1, u'2', 3, u'4']
    assert ansible_native_concat([u'foo', 1, 2]) == u'foo12'

    assert ansible_native_concat([u'1', u'2', u'3']) == 123

# Generated at 2022-06-21 07:42:45.794232
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2.nodes import Const, Context, Name
    from jinja2.parser import Parser
    from jinja2.runtime import Context as JinjaContext
    from jinja2.utils import concat

    p = Parser(trim_blocks=True, keep_trailing_newline=True)


# Generated at 2022-06-21 07:42:51.562898
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Simple data types
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([b'd']) == b'd'
    assert ansible_native_concat([b'a']) == b'a'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([2.3]) == 2.3
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([{}]) == {}
    assert ansible_native_concat([[]]) == []
    assert ansible_native_concat([set()]) == set()

    # Nested data structures


# Generated at 2022-06-21 07:42:59.652425
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from collections import namedtuple
    from jinja2.nodes import Assign
    from jinja2.nodes import Name
    from jinja2.nodes import TemplateData
    from jinja2.nodes import TemplateRef

    TestCase = namedtuple('TestCase', [
        'data',
        'expected',
    ])


# Generated at 2022-06-21 07:43:04.281042
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1j]) == 1j
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([1, 'bar']) == '1bar'

# Generated at 2022-06-21 07:43:17.304654
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([NativeJinjaText(container_to_text(None))]) is None
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([NativeJinjaText(u'')]) == u''
    assert ansible_native_concat([u'']) == u''
    assert ansible_native_concat([NativeJinjaText(u'foo')]) == u'foo'
    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat([NativeJinjaText(u'foo'), NativeJinjaText(u'bar')]) == u'foobar'
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ans

# Generated at 2022-06-21 07:43:28.770628
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # No arguments
    assert ansible_native_concat(iter([])) is None

    # Single argument
    assert ansible_native_concat(iter([1])) == 1
    assert ansible_native_concat(iter(['foo'])) == 'foo'
    assert ansible_native_concat(iter([[1, 2, 3]])) == [1, 2, 3]
    assert ansible_native_concat(iter([{'foo': 'bar'}])) == {'foo': 'bar'}

    assert ansible_native_concat(iter((i for i in [1, 2]))) == '12'
    assert ansible_native_concat(iter((i for i in ['foo', 'bar']))) == 'foobar'

# Generated at 2022-06-21 07:43:38.122640
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert ansible_native_concat([1, 2, 3, 4, '5']) == [1, 2, 3, 4, '5']
    assert ansible_native_concat([1, 2, '3', 4, '5']) == [1, 2, '3', 4, '5']
    assert ansible_native_concat(['1', 2, '3', 4, '5']) == ['1', 2, '3', 4, '5']
    assert ansible_native_concat(['1', 2, '3', 4, 5]) == ['1', 2, '3', 4, 5]

# Generated at 2022-06-21 07:43:48.193132
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat(['42']) == 42
    assert ansible_native_concat([42, '42']) == '4242'
    assert ansible_native_concat([b'42']) == b'42'
    assert ansible_native_concat([42, b'42']) == '4242'
    assert ansible_native_concat([42, '42', b'42']) == b'4242'
    assert ansible_native_concat([b'42', '42', 42]) == b'4242'



# Generated at 2022-06-21 07:44:02.851036
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import container_to_text

    assert container_to_text(ansible_native_concat([1, 2, 3])) == '123'
    assert container_to_text(ansible_native_concat(['abc'])) == 'abc'
    assert container_to_text(ansible_native_concat(['1', 2, 3])) == '123'
    assert container_to_text(ansible_native_concat(['1', 2, 3]) == 123)
    assert container_to_text(ansible_native_concat([1, '2', 3]) == 123)
    assert container_to_text(ansible_native_concat([1, 2, '3'] == 123) == 123)

# Generated at 2022-06-21 07:44:13.189628
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2]) == 1
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat(["1", "2", "3"]) == 123
    assert ansible_native_concat([1, 2, 3, 4, 5, 6, '7', '8']) == 12345678
    assert ansible_native_concat([1, 2, 3, 4, 5, 6, '7', '8', '9']) == '123456789'
    assert ansible_native_concat([1, 2, 3, 4, 5, 6, 7, 8, '9', '0']) == '1234567890'

# Generated at 2022-06-21 07:44:24.605114
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == u'foobar'
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat(['42']) == 42
    assert ansible_native_concat(['42', 'foo']) == '42foo'
    assert ansible_native_concat(['42', 'foo', 'bar']) == '42foobar'
    assert ansible_native_concat(['42', 'foo: bar']) == '42foo: bar'
    assert ansible_native_concat(['42', 'foo:', 'bar']) == '42foo:bar'
    assert ansible

# Generated at 2022-06-21 07:44:36.131008
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    value = "This is vaulted"
    v = AnsibleVaultEncryptedUnicode(value)
    assert value == v.data

    value = AnsibleVaultEncryptedUnicode("This is vaulted")
    v = ansible_native_concat([value])
    assert value == v

    value = AnsibleVaultEncryptedUnicode("This is vaulted")
    v = ansible_native_concat(['a', 'b', 'c', value])
    assert value == v

    value = [b'a', b'b', b'c']
    v = ansible_native_concat([value])
    assert value == v

    value = {'a':'b', 'c': 'd'}

# Generated at 2022-06-21 07:44:40.916660
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([10]) == 10
    assert ansible_native_concat([10, 20]) == '1020'
    assert ansible_native_concat([10, '20']) == '1020'
    assert ansible_native_concat(['foo', 'bar']) == "'foobar'"



# Generated at 2022-06-21 07:44:55.132820
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([b'True']) is True

    assert ansible_native_concat([to_text(u'True')]) is True
    assert ansible_native_concat([to_text(u'false')]) is False
    assert ansible_native_concat([to_text(u'null')]) is None
    assert ansible_native_concat([to_text(u'1')]) == 1
    assert ansible_native_concat([to_text(u'1.5')]) == 1.5

    assert ansible_native_concat([to_text(u'"string"')]) == 'string'

# Generated at 2022-06-21 07:45:07.136280
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([{'bar': 'far'}]) == {'bar': 'far'}
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', u'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 1]) == 'foo1'
    assert ansible_native_concat(['foo', 1, 'bar']) == 'foo1bar'
    assert ansible_native_concat(['foo', 1, 'bar', 1]) == 'foo1bar1'


# Generated at 2022-06-21 07:45:11.034717
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    a = ["a", "b", "c"]
    b = "".join(a)
    c = ansible_native_concat(a)
    assert b == c


# Generated at 2022-06-21 07:45:21.581602
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # test that ansible_native_concat produces the same result as jinja2
    # native_concat
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from jinja2 import Environment, StrictUndefined
    env = Environment(undefined=StrictUndefined)
    env.native_concat = ansible_native_concat
    template = env.from_string(u'{{ [a, b] }}')
    assert template.render({'a': 123, 'b': 456}) == '579'
    assert template.render({'a': 123, 'b': u'4'}) == 123
    assert template.render({'a': 'a', 'b': 2}) == 'a2'

# Generated at 2022-06-21 07:45:34.017392
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import Environment
    test_vals = [
        [[1], 1],
        [[1, 2], "12"],
        [[1, "foo"], "1foo"],
        [[True], True],
        [[["foo", "bar"]], ["foo", "bar"]],
        [[[1, 2, 3]], [1, 2, 3]],
        [['{% if True %}True{% else %}False{% endif %}'], True],
    ]

    env = Environment()
    for test_val in test_vals:
        compiled_nodes = [env.compile_expression(str(n)) for n in test_val[0]]
        output_val = ansible_native_concat(compiled_nodes)
        assert output_val == test_val[1]



# Generated at 2022-06-21 07:45:42.991386
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # TODO: add more tests
    assert ansible_native_concat([123]) == 123
    assert ansible_native_concat(['']) == ''
    assert ansible_native_concat(['def']) == 'def'
    assert ansible_native_concat(['abc', 'def']) == 'abcdef'
    assert ansible_native_concat(['abc', 123]) == 'abc123'

# Generated at 2022-06-21 07:45:50.840690
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2.nodes import Const, List, Tuple
    from ansible.module_utils.common.text.converters import to_bytes

    # Hardcoded values from compiled Ansible templates

# Generated at 2022-06-21 07:46:01.827343
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2]) == 1
    assert ansible_native_concat(['foo', 'bar', 'baz']) == 'foobarbaz'
    assert ansible_native_concat(['foo', 'bar', 'baz']) == u'foobarbaz'
    assert ansible_native_concat(['foo', 'bar', 'baz']) == u'foobarbaz'
    assert ansible_native_concat(['foo  ', '  bar', '  baz  ']) == u'foo  barbaz'
    assert ansible_native_concat([1, 2, '  ']) == '12'
    assert ansible_native_concat(['', '  ', '  ']) == '      '

# Generated at 2022-06-21 07:46:13.849378
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '1, 2'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', 'b ', 'c']) == 'abc'
    assert ansible_native_concat([1, 'b ', 'c']) == '1, b , c'
    assert ansible_native_concat([1, ['b ', 'c']]) == '[1, [b , c]]'

    assert ansible_native_concat(NativeJinjaText('a')) == 'a'
    assert ansible_native_concat(NativeJinjaText('a'), NativeJinjaText('b')) == 'ab'
   

# Generated at 2022-06-21 07:46:21.945905
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Test with empty list
    test_list = []
    result = ansible_native_concat(test_list)
    assert result == None

    # Test with singleton list
    test_list = [123]
    result = ansible_native_concat(test_list)
    assert result == 123

    # Test with list of integers
    test_list = [1, 2, 3]
    result = ansible_native_concat(test_list)
    assert result == '123'

    # Test with list of strings
    test_list = ['a', 'b', 'c']
    result = ansible_native_concat(test_list)
    assert result == 'abc'

    # Test with list of strings with leading spaces/tabs

# Generated at 2022-06-21 07:46:32.607941
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2]) == 1
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([str('foo'), 'bar']) == 'foobar'
    assert ansible_native_concat([container_to_text('foo'), 'bar']) == 'foobar'
    assert ansible_native_concat([text_type('foo'), 'bar']) == 'foobar'
    assert ansible_native_concat([u'foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', u'bar']) == 'foobar'
    # int, not float
    assert ansible_native_concat(['1.0', 1]) == 1.0
    # unicode

# Generated at 2022-06-21 07:46:42.904230
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # a few basic test examples
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat([1, 'b']) == '1b'
    assert ansible_native_concat(['a', 2]) == 'a2'
    assert ansible_native_concat([1, 2]) == '12'

    # ensure concat still works if there are strings that can't be parsed into
    # literals (strings)
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'

# Generated at 2022-06-21 07:46:54.352338
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # We need to do eval() to get the expected result
    node_values = ["'string'", "'foo'", "'bar'", "1", "2", "3"]
    nodes = [eval(i) for i in node_values]
    assert ansible_native_concat(nodes) == ["string", "foobar", 123]

    node_values = [1, 2, 3]
    nodes = [eval(i) for i in node_values]
    assert ansible_native_concat(nodes) == [1, 2, 3]

    node_values = ["'foobar'"]
    nodes = [eval(i) for i in node_values]
    assert ansible_native_concat(nodes) == 'foobar'

    node_values = [r"'{{ \"'bob\"' }}'"]


# Generated at 2022-06-21 07:47:06.616441
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:47:14.475594
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'fo', u'o']) == u'foo'
    assert ansible_native_concat([u'1', u'0', u'1']) == u'101'
    assert ansible_native_concat([1, 0, 1]) == u'101'
    assert ansible_native_concat([1, 0, 1.1]) == u'101.1'
    assert ansible_native_concat([1, 0, 1, False]) == u'101False'
    assert ansible_native_concat([1, 0, 1, 'False']) == u'101False'
    assert ansible_native_concat([1, 0, 1, True]) == u'101True'
    assert ansible_native_concat([1, 0, 1, 'True'])

# Generated at 2022-06-21 07:47:27.323465
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([u'foo', u'42']) == u'foo42'
    assert ansible_native_concat([u'foo', 42]) == u'foo42'
    assert ansible_native_concat([u'foo', True]) == u'footrue'
    # TODO: literal_eval should not be able to parse this.
    # See: https://github.com/ansible/ansible/issues/70831#issuecomment-683364745
    assert ansible_native_concat([u'True', True]) is True

# Generated at 2022-06-21 07:47:38.147482
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:47:50.426886
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['hello', ' ', 'world']) == 'hello world'
    assert ansible_native_concat(['foo', '', 'bar']) == 'foobar'
    assert ansible_native_concat('foobar') == 'foobar'
    assert ansible_native_concat([42, '.0', ' metr']) == 42.0
    assert ansible_native_concat(['0x42', '.0', ' metr']) == '0x42.0 metr'
    assert ansible_native_concat(['0x42.0']) == '0x42.0'
    assert ansible_native_concat(['[1,2]', '[3,4]']) == '[1,2][3,4]'

# Generated at 2022-06-21 07:47:57.155848
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(['1']) == '1'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat(['1', '2', 3]) == '123'
    assert ansible_native_concat([u'1', u'2']) == u'12'
    assert ansible_native_concat([b'1', b'2']) == u'12'
    assert ansible_native_concat(['1', '2', '3', '4', '5', '6', '7', '8', '9', 10]) == '12345678910'

# Generated at 2022-06-21 07:48:09.358436
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # pylint: disable=unused-import, import-error
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.jinja2.native_filters import ansible_native_concat
    # pylint: enable=unused-import, import-error

    assert ansible_native_concat([1, 2, 3]) == 6
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat([1, 'b']) == '1b'
    assert ansible_native_concat(['a', 2]) == 'a2'

# Generated at 2022-06-21 07:48:21.340376
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import pytest
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    def get_compiled_node(item):
        from jinja2.nodes import Const
        return Const(item)

    def gen_node(*items):
        for item in items:
            yield get_compiled_node(item)

    def is_vault_text(obj):
        return isinstance(obj, AnsibleVaultEncryptedUnicode)

    def is_text(obj):
        return isinstance(obj, string_types)


# Generated at 2022-06-21 07:48:31.724520
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2.nodes import Const
    from jinja2.compiler import CodeGenerator
    from jinja2.runtime import Environment

    env = Environment(extensions=['jinja2.ext.do'])

    def test(source, result):
        ast = env.parse(source)
        yield lambda: result == CodeGenerator(ast, env).visit(ast)
        yield lambda: result == CodeGenerator(ast, env, 'utf-8').visit(ast)

        # the native type concat function is only available on the runtime
        # environment when the do extension is enabled
        env.extend(ansible_concat=ansible_native_concat)
        runtime = env.runtime
        for node in ast.find_all((Const, )):
            node.__class__ = NativeJinja

# Generated at 2022-06-21 07:48:42.276836
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Simple tests
    assert ansible_native_concat(None) is None
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([1, 2, '3']) == 123
    assert ansible_native_concat([1, 2, "'3'"]) == "'3'"
    assert ansible_native_concat([1, 2, "'3'", '4']) == "'34'"
    assert ansible_native_concat(['a', u'b', 'c']) == 'abc'

    # Supports unicode strings as well

# Generated at 2022-06-21 07:48:52.030595
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2]) == 1
    assert ansible_native_concat([[1, 2]]) == [1, 2]
    assert ansible_native_concat(['1', '2']) == 1
    assert ansible_native_concat(['[1, 2]']) == [1, 2]
    assert ansible_native_concat(['[1,', '2]']) == [1, 2]
    assert ansible_native_concat([[1, 2], '[3,', '4]']) == [1, 2]
    assert container_to_text(ansible_native_concat(
        ['[1,', '2]', '"some string"']
    )) == '[1, 2] some string'

# Generated at 2022-06-21 07:49:02.444987
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class TestNativeJinjaText(NativeJinjaText):
        def __unicode__(self):
            return u'foo'

        def __str__(self):
            return u'foo'

        def __repr__(self):
            return u'<TestNativeJinjaText>'

    # Test for an empty list
    out = ansible_native_concat([])
    assert out is None

    # Test for a list of single node/value
    out = ansible_native_concat(['bar'])
    assert out == 'bar'
    out = ansible_native_concat([42])
    assert out == 42
    out = ansible_native_concat([TestNativeJinjaText()])
    assert isinstance(out, NativeJinjaText)

    # Test for a list of multiple nodes

# Generated at 2022-06-21 07:49:17.593770
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    assert ansible_native_concat([]) == None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == u'12'
    assert ansible_native_concat(iter([1, 2])) == u'12'
    assert ansible_native_concat(iter(['ab', 'cde', 'fg'])) == u'abcdefg'
    assert ansible_native_concat(iter(['ab', 'cde', 2, 'fg'])) == u'abcdefg'
    assert ansible_native_concat(iter(['ab', 'cde', 2, u'fg'])) == u'abcdefg'
    assert ansible_native_concat

# Generated at 2022-06-21 07:49:30.266618
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(['b']) == 'b'
    assert ansible_native_concat(['b', 'bb']) == 'bbb'
    assert ansible_native_concat(['true']) == True
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 'b']) == '1b'
    assert ansible_native_concat(['false']) == False
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat(['None']) is None
    assert ansible_native_concat(['1.1']) == 1.1

# Generated at 2022-06-21 07:49:37.403394
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    sequence = [1, 2, 3]
    expected = sequence
    result = ansible_native_concat(iter(sequence))
    assert result == expected

    sequence = [1, 2, '\t', 3]
    expected = sequence
    result = ansible_native_concat(iter(sequence))
    assert result == expected

    sequence = [1, 2, '\n', 3]
    expected = sequence
    result = ansible_native_concat(iter(sequence))
    assert result == expected

    sequence = [1, 2, ' ', 3]
    expected = sequence
    result = ansible_native_concat(iter(sequence))
    assert result == expected

    sequence = [1, 2, 3, ' ']
    expected = sequence
    result = ansible_native_concat(iter(sequence))

# Generated at 2022-06-21 07:49:48.196381
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_text

    from jinja2 import Undefined

    assert ansible_native_concat(["foo", "bar"]) == "foobar"
    assert ansible_native_concat(iter(["foo", "bar"])) == "foobar"
    assert ansible_native_concat([42, "foo", "bar"]) == "42foobar"
    assert ansible_native_concat([42, "foo", "bar", 42]) == "42foobar42"
    assert ansible_native_concat(["foo", 42, "bar", 42, "baz"]) == "foo42bar42baz"

    assert ansible_native_concat([Undefined()]) is None

# Generated at 2022-06-21 07:49:58.517687
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import pytest
    def test(nodes, result):
        assert ansible_native_concat(nodes) == result

    # 1. Test basic values
    test(['a'], 'a')
    test(['a', 1], 'a1')
    test([1, 'a'], '1a')
    test([1, 'a', 2], '1a2')
    test([1, 'a', 2, 'b'], '1a2b')
    test([1, 'a', 2, 'b', 3], '1a2b3')
    test([1, 'a', 2, 'b', 3, 'c'], '1a2b3c')
    test([1, 'foo', 2, 'bar'], [1, 'foo', 2, 'bar'])

# Generated at 2022-06-21 07:50:08.874282
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # test list
    assert ansible_native_concat([1,2,3]) == [1,2,3]
    assert ansible_native_concat([]) == []
    assert ansible_native_concat(Container([1,2,3])) == [1,2,3]
    assert ansible_native_concat(Container([])) == []

    # test literal number
    assert ansible_native_concat(Container(1)) == 1

    # test literal string
    assert ansible_native_concat(Container("1")) == "1"

    # test literal string, with Mapping
    assert ansible_native_concat(Container("1", data={'foo':'bar'})) == "1"

    # test literal float

# Generated at 2022-06-21 07:50:18.092983
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:50:30.449710
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([False]) is False
    assert ansible_native_concat(['foo']) == 'foo'

    # Test for "| string" filter
    assert ansible_native_concat([NativeJinjaText('foo')]) == NativeJinjaText('foo')

    assert ansible_native_concat(['1', '2']) == '12'

    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat([1, 2]) == 12
    assert ansible_native_concat(['1', 2]) == '12'
