

# Generated at 2022-06-21 07:40:40.711858
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['hello ', 'world']) == 'hello world'
    assert ansible_native_concat(['hello ', 42]) == 'hello 42'
    assert ansible_native_concat(['hello ', u'world']) == u'hello world'
    assert ansible_native_concat([u'hello ', 42]) == u'hello 42'
    assert ansible_native_concat([u'hello ', None]) == u'hello None'
    assert ansible_native_concat([u'hello ', ['w', 'o', 'r', 'l', 'd']]) == u'hello w,o,r,l,d'

    assert ansible_native_concat([42, 42]) == 84
    assert ansible_native_concat([42, 42.0]) == 84.0


# Generated at 2022-06-21 07:40:49.088466
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(
        [1, 'a', "b", u'c', b'd', AnsibleVaultEncryptedUnicode("vaulted")]
    ) == '1abc vaulted'

    assert ansible_native_concat([u'a', {u'b': u'c'}, [u'd']]) == u'{u\'b\': u\'c\'}[u\'d\']'

    assert ansible_native_concat([1, [u'a', b'b', 'c'], {u'a': 1}]) == u'[u\'a\' u\'b\' u\'c\']{\'a\': 1}'


# Generated at 2022-06-21 07:41:01.681872
# Unit test for function ansible_native_concat
def test_ansible_native_concat():  # noqa: F811
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(x for x in [1, 2, 3]) == 123
    assert ansible_native_concat(x for x in [1, u'foo', 'bar']) == 123
    assert ansible_native_concat(x for x in [1, u'foo', u'bar']) == 123
    assert ansible_native_concat(x for x in [u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat(x for x in ['foo', 'bar']) == u'foobar'

# Generated at 2022-06-21 07:41:13.151918
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    list_of_jinja_literal_nodes = [
        ast.Str('foo'),
        ast.Str('bar')
    ]

    list_of_jinja_non_literal_nodes = [
        ast.Str('foo'),
        ast.Num(1)
    ]

    list_of_jinja_nodes_with_vault = [
        ast.Str('foo'),
        AnsibleVaultEncryptedUnicode('bar')
    ]

    assert ansible_native_concat(list_of_jinja_literal_nodes) == 'foobar'
    assert ansible_native_concat(list_of_jinja_non_literal_nodes) == u'foo1'

# Generated at 2022-06-21 07:41:24.041620
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def assert_value(expected, *values):
        assert ansible_native_concat(values) == expected

    assert_value(None)
    assert_value('foo', 'foo')
    assert_value('foo', 'foo', 'bar')
    assert_value('foobar', 'foo', 'bar')
    assert_value('foobar', 'foo', 'bar', 'baz')

    assert_value('foo', 'foo', 'bar')
    assert_value('foobar', 'foo', 'bar')
    assert_value('foobarbaz', 'foo', 'bar', 'baz')

    assert_value('', 'foo', 'bar')
    assert_value('', 'foo', 'bar')
    assert_value('', 'foo', 'bar', 'baz')


# Generated at 2022-06-21 07:41:31.297557
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # pylint: disable=protected-access
    assert None is ansible_native_concat([])
    assert None is ansible_native_concat([None])
    assert u'foo' is ansible_native_concat([u'foo'])
    assert u'foo' is ansible_native_concat([u'foo', None])
    assert (1, 2.0, u'bar', u'baz') == ansible_native_concat([1, 2.0, u'bar', u'baz'])
    assert u'foobarbaz' is ansible_native_concat([u'foo', u'bar', u'baz'])
    assert u'foobarbaz' is ansible_native_concat([u'foo', None, u'bar', None, u'baz'])
   

# Generated at 2022-06-21 07:41:43.172609
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat((1,)) == 1
    assert ansible_native_concat(('1',)) == 1
    assert ansible_native_concat((1, '', 2)) == u'12'
    assert ansible_native_concat(('1', '', '2')) == u'12'
    assert ansible_native_concat((u'1', u'', u'2')) == u'12'
    assert ansible_native_concat((u'1')) == u'1'
    assert ansible_native_concat((u'1', u'2', u'3')) == u'123'
    assert ansible_native_concat(('a', 'b', u'c')) == u'abc'

# Generated at 2022-06-21 07:41:55.355394
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test ansible_native_concat.

    The best way to unit test Jinja2 functions is to use `Jinja2`_ on the
    command line.

    .. code-block:: bash

      $ python -m ansible.module_utils.common.text.converters test_ansible_native_concat | tee test_ansible_native_concat.out
      $ python -m jinja2.testsuite.execfile jinja2/tests/ext/tests/test_custom_tests.py | tee test_custom_tests.out
      $ diff test_ansible_native_concat.out test_custom_tests.out

    .. _Jinja2: http://jinja.pocoo.org/docs/2.10/api/#jinja2.Environment

    """
    import sys

# Generated at 2022-06-21 07:42:04.247064
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class TestVars:
        not_a_string = None
        vault_string = AnsibleVaultEncryptedUnicode('vaulted')
        string = 'text'
        dict_value = dict(
            key='value',
            list=[1, 2, 3]
        )
        list_value = ['text', 1,
                      dict(key='value', list=[1, 2, 3]),
                      TestVars.dict_value,
                      TestVars.not_a_string,
                      TestVars.vault_string,
                      TestVars.string]

    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([TestVars.not_a_string]) is None

# Generated at 2022-06-21 07:42:11.989849
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # test cases
    assert ansible_native_concat([] is None)
    assert ansible_native_concat([1] == 1)
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, '2'] == 1)
    assert ansible_native_concat(['1', 2]) == '12'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat(1) == 1
    assert ansible_native_concat('1') == '1'
    assert ansible_native_concat(True) is True
    assert ansible_native_concat(False) is False



# Generated at 2022-06-21 07:42:25.086088
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """ansible_native_concat(nodes) -> value
    Convert a list of nodes to a value and return it.

    Simplified version of the jinja2.nativetypes.concat() function.
    """
    # Adapted from jinja2.tests.test_nativetypes.test_concat_scalar_or_none
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([None]) is None
    # Adapted from jinja2.tests.test_nativetypes.test_concat_multiple
    assert ansible_native_concat([1, 2]) == u"12"
    assert ansible_native_concat([1, 2, 3, 4, 5]) == u"12345"
   

# Generated at 2022-06-21 07:42:36.273546
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def assert_ansible_native_concat(expected, nodes):
        """Compare expected value from ansible_native_concat with actual value"""
        actual = container_to_text(ansible_native_concat(nodes))
        assert actual == expected, \
            "ansible_native_concat failed to return expected value. " \
            "Expected: '{0}', got: '{1}'.".format(expected, actual)

    assert_ansible_native_concat(u'', [])
    assert_ansible_native_concat(u'1', [1])
    assert_ansible_native_concat(u'1', ['1'])
    assert_ansible_native_concat(u'1', [NativeJinjaText('1')])
    assert_ansible_native_concat

# Generated at 2022-06-21 07:42:46.210377
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """We need to make sure that the ansible_native_concat is working
    correctly so that the following strings are returned in the correct type
    """
    assert ansible_native_concat(["'foo'"]) == "foo"
    assert ansible_native_concat(['"foo"']) == "foo"
    assert ansible_native_concat(["'123'"]) == "123"
    assert ansible_native_concat(['"123"']) == "123"
    assert ansible_native_concat(["'hello world'"]) == "hello world"
    assert ansible_native_concat(['"hello world"']) == "hello world"
    assert ansible_native_concat(["'123'", "'45'"]) == "12345"

# Generated at 2022-06-21 07:42:56.355260
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_text

    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == 12
    assert ansible_native_concat([1, '2']) == '12'

    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([True, False]) == 'TrueFalse'

    assert ansible_native_concat(('a', 'b')) == 'ab'
    assert ansible_native_concat(['1', 2, True]) == '12True'

    assert container_

# Generated at 2022-06-21 07:43:04.281113
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:43:17.307762
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import wrap_var

    data = dict(
        a=1,
        b=2,
        c='{{ a }} {{ b }}',
        d='{{ c }} {{ a }}',
        e='{{ a }}',
        f='{{ a + b }}',
        g='{{ a }} {{ c }}',
        h='{{ c }} {{ d }}',
        i='{{ a + b }} {{ f }}',
        j='{{ a + b }} {{ g }}',
        k='{{ a + b }} {{ h }}',
    )


# Generated at 2022-06-21 07:43:27.074372
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # TODO: move this to the unit tests?
    # TODO: add tests for non-string types, mixed types
    from jinja2.runtime import StrictUndefined
    from ansible.module_utils.six import PY3

    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['x']) == 'x'
    assert ansible_native_concat(['x', 'y']) == 'xy'

    if PY3:
        assert ansible_native_concat(['1']) == 1
        assert ansible_native_concat(['1', '.', '1']) == 1.1
        assert ansible_native_concat(['True']) is True
        assert ansible_native_concat(['False']) is False
        assert ans

# Generated at 2022-06-21 07:43:35.355576
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml import objects
    from ansible.parsing.yaml.loader import AnsibleLoader


# Generated at 2022-06-21 07:43:48.538937
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1,2,3]) == u'123'
    assert ansible_native_concat(u'123'.split()) == u'123'
    assert ansible_native_concat([1,u'2',u'3']) == u'123'
    assert ansible_native_concat([1,u'2',u'2',u'3']) == u'123'
    assert ansible_native_concat([1,u'2',u'',u'3']) == u'123'
    assert ansible_native_concat([1,u'2',u'',u'',u'3']) == u'123'

# Generated at 2022-06-21 07:44:00.953194
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    from ansible.module_utils.six import PY3, iteritems

    def check_concat(expected, *values):

        native = ansible_native_concat(values)
        assert isinstance(native, type(expected))

        if isinstance(expected, text_type):
            assert native == expected

        if isinstance(expected, dict):
            assert len(native) == len(expected)
            for k, v in iteritems(expected):
                assert k in native
                assert native[k] == v

        if isinstance(expected, (list, tuple)):
            assert len(native) == len(expected)
            for i, v in enumerate(expected):
                assert native[i] == v

    check_concat('0', 0)
    check_concat('1', 1)

# Generated at 2022-06-21 07:44:13.238076
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch
    ast_literal_eval = 'ansible_collections.notstdlib.moveitallout.tests.unit.compat.ast.literal_eval'

    # same as ``123`` in Jinja
    assert ansible_native_concat([123]) == 123

    # same as ``{{ 123 }}`` in Jinja
    assert ansible_native_concat([123, None]) == 123

    # same as ``'123'`` in Jinja
    assert ansible_native_concat(['123']) == '123'

    # same as ``'123'|int`` in Jinja
    with patch(ast_literal_eval) as literal_eval:
        literal_eval.return_value = 123


# Generated at 2022-06-21 07:44:24.685641
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2]) == [1, 2]
    assert ansible_native_concat(u'1\xa02') == u'1\xa02'
    assert ansible_native_concat(2) == 2
    assert ansible_native_concat('2') == '2'
    assert ansible_native_concat('abc') == 'abc'
    assert ansible_native_concat('abc ') == 'abc '
    assert ansible_native_concat('abc ') == 'abc '
    assert ansible_native_concat('abc ') == 'abc '

    assert ansible_native_concat([1, 2, [3]]) == [1, 2, [3]]

# Generated at 2022-06-21 07:44:36.228921
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # https://github.com/pallets/jinja/blob/master/src/jinja2/testsuite/test_nativetypes.py

    def test(data, expected, msg=None):
        result = ansible_native_concat((d for d in data))
        # This is a workaround for differences related to the type of strings
        # when running python with the PYTHONUTF8 environment variable unset.
        if isinstance(expected, str) and not isinstance(result, str):
            result = text_type(result)
        assert result == expected, msg

    test([], None, 'empty iterable')
    test([''], '', 'single empty string')
    test(['abc'], 'abc', 'single string')

# Generated at 2022-06-21 07:44:43.469187
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Example of the data we get from the template:
    # [{u'city': u'cityvalue', u'state': u'statevalue'}, u'\n    ', {u'city': u'cityvalue2', u'state': u'statevalue2'}]

    # This input should not be formatted into a list.
    input1 = [{u'city': u'cityvalue', u'state': u'statevalue'}, u'\n   ', {u'city': u'cityvalue2', u'state': u'statevalue2'}]
    assert ansible_native_concat(input1) == input1

    # This input should be formatted into a list, keeping the values as strings.

# Generated at 2022-06-21 07:44:55.132881
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([1, 'bar']) == 1
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([NativeJinjaText(u'{{foo}}'), 'bar']) == '{{foo}}bar'
    assert ansible_native_concat([NativeJinjaText(u'{{foo}}'), 'bar']) == '{{foo}}bar'
    assert ansible_native_concat([AnsibleVaultEncryptedUnicode(u'foo', u'bar'), 'bar']) == u'foobar'
    assert ansible_native_concat(['foo', StrictUndefined]) == 'foo'

# Generated at 2022-06-21 07:45:07.177119
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([u'1']) == 1
    assert ansible_native_concat([NativeJinjaText(u'1')]) == u'1'
    assert ansible_native_concat([u'1', u'2']) == 3
    assert ansible_native_concat([u'1', u'b']) == u'1b'
    assert ansible_native_concat([u'a', '\n', u' ', u'b']) == u'a b'
    assert ansible_native_concat([u'a', '\n', u' ', u'b']) == u'a b'

# Generated at 2022-06-21 07:45:19.154495
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import Environment, DictLoader


# Generated at 2022-06-21 07:45:30.561219
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Wipe out the fuction _fail_on_undefined
    _fail_on_undefined_orig = globals()['_fail_on_undefined']
    globals()['_fail_on_undefined'] = lambda x: x

# Generated at 2022-06-21 07:45:41.563522
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.utils.unsafe_proxy import UnsafeProxy

    unsafe_proxy = UnsafeProxy({'foo': 'bar'})

    # Test strings
    assert ansible_native_concat(['hello world']) == 'hello world'
    assert ansible_native_concat([' hello ', 'world']) == ' hello world'
    assert ansible_native_concat([unsafe_proxy, ' world']) == '{foo=bar} world'

    # Test numbers
    assert ansible_native_concat([unsafe_proxy, '1']) == '{foo=bar}1'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([12]) == 12
    assert ansible_native_concat([-1]) == -1
    assert ansible_native_

# Generated at 2022-06-21 07:45:50.009274
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([2, 5]) == [2, 5]
    assert ansible_native_concat([u"foo", u"bar"]) == u"foobar"
    # TODO: handle vault
    assert ansible_native_concat([u"foo", u"bar", u"baz", u"qux"]) == u"foobarbazqux"

# Generated at 2022-06-21 07:46:02.196543
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Parameter 1: Nodes to concat and their expected values
    nodes = [native_string(u'hello'), 2, 3.0, native_string(u'world')]
    expect = u'hello23.0world'

    result = ansible_native_concat(nodes)

    assert result == expect, \
           'ansible_native_concat({}) failed - got "{:s}", expected "{:s}"'.format(
               container_to_text(nodes), result, expect)

    # Parameter 2: Single node
    nodes = native_string(u'hello')
    expect = u'hello'

    result = ansible_native_concat(nodes)


# Generated at 2022-06-21 07:46:13.966899
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Test 1: joining None, literal, and undefined
    assert ansible_native_concat([None, 'b', StrictUndefined()]) == u'b'

    # Test 2: joining two undefined, str(undefined)
    assert ansible_native_concat([StrictUndefined(), StrictUndefined()]) == u''

    # Test 3: joining 1, 2, and 3
    assert ansible_native_concat([1, 2, 3]) == 6

    # Test 4: joining None, 1, and undefined
    assert ansible_native_concat([None, '1', StrictUndefined()]) == 1

    # Test 5: joining None, None, and 2
    assert ansible_native_concat([None, None, 2]) == 2

    # Test 6: joining an empty list
    assert ansible_native_con

# Generated at 2022-06-21 07:46:23.615317
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    int_val = 2
    str_val = "test"
    bool_val = True
    list_val = [int_val, str_val]
    dict_val = {'test': str_val, 'test2': int_val}
    empty_val = "None"
    native_jinja_text = NativeJinjaText("foo")

    # no args
    assert ansible_native_concat([]) is None

    # single arg
    assert ansible_native_concat([int_val]) == int_val
    assert ansible_native_concat([str_val]) == str_val

    # 2 args
    assert ansible_native_concat([str_val, str_val]) == str_val + str_val

# Generated at 2022-06-21 07:46:33.494634
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['1', '2']) == 1
    assert ansible_native_concat(['1', '2', '3']) == '123'
    assert ansible_native_concat(['1', '2', '3.0']) == '123.0'
    assert ansible_native_concat(['1', '2', '3.0', '4']) == '123.0'
    assert ansible_native_concat(['a', '"b"', "'c'"]) == "ab'c"

# Generated at 2022-06-21 07:46:43.306467
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:46:55.178093
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2
    from ansible.module_utils.common.text.converters import to_text
    env = jinja2.Environment(undefined=jinja2.StrictUndefined, extensions=['jinja2.ext.do', 'jinja2.ext.loopcontrols'])
    env.filters['ansible_native_concat'] = ansible_native_concat

# Generated at 2022-06-21 07:47:07.175552
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # an empty list
    assert ansible_native_concat([]) is None

    # a single string
    assert ansible_native_concat(['one']) == 'one'

    # a single integer, boolean, null
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([None]) is None

    # a single dict
    assert ansible_native_concat([{'foo': 'bar'}]) == {'foo': 'bar'}

    # a single dict that we want to be a string
    assert ansible_native_concat([NativeJinjaText({'foo': 'bar'})]) == {'foo': 'bar'}

    # a single list

# Generated at 2022-06-21 07:47:14.797212
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat(["1", "2", "3"]) == "123"
    assert ansible_native_concat([1, "2", "3"]) == [1, "2", "3"]
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(["   ", "   "]) == "       "

    assert ansible_native_concat(["1", "2", 3]) == "123"
    assert ansible_native_concat(["1", "2", "3", 4]) == "1234"
    assert ansible_native_concat(["1", "2", "3", 4, "5"]) == "12345"

# Generated at 2022-06-21 07:47:25.967819
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    _fail_on_undefined = _fail_on_undefined

    # When native_concat is called with a single node and the node is an
    # undefined object, it calls _fail_on_undefined so that the undefined
    # exception is properly raised.
    # This test ensures that the proper exception is raised when native_concat
    # is called with a single node and the node has an undefined value.
    undefined_node = JinjaUndefined('foo')
    with pytest.raises(JinjaUndefinedError) as exception_info:
        ansible_native_concat([undefined_node])
        assert 'foo' == exception_info.value.message
        assert ['foo'] == exception_info.value.undefined_names

    # When native_concat is called with multiple nodes, it calls _fail_on_undefined

# Generated at 2022-06-21 07:47:37.261449
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Python 3 compatibility
    try:
        unichr(20000)
    except NameError:
        unichr = chr


# Generated at 2022-06-21 07:47:50.706396
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    '''
    A basic function that doesn't do anything.

    This is intended for unit tests.
    '''

    assert ansible_native_concat([u'this is a ', u'test']) == 'this is a test'
    assert ansible_native_concat(['<test', '>']) == '<test>'
    assert ansible_native_concat([u'<test', u'>']) == '<test>'
    assert ansible_native_concat([u'[test', u']']) == ['test']
    assert ansible_native_concat([u'{test', u'}']) == {'test': None}
    assert ansible_native_concat([u'1']) == 1

# Generated at 2022-06-21 07:47:57.126843
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, ""]) == "1"
    assert ansible_native_concat(["1", 2]) == "12"
    assert ansible_native_concat([True, False, True]) == "TrueFalseTrue"
    assert ansible_native_concat([True, [1, "2"], True]) == "True12True"
    assert ansible_native_concat(["'1'", "'2'"]) == "12"
    assert ansible_native_concat(["\"1\"", "\"2\""]) == "12"



# Generated at 2022-06-21 07:48:09.349566
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Note that the last node is a string because we need to cover the
    # last case in the ansible_native_concat function.
    nodes = ['foo', 123, None, {}, [], AnsibleVaultEncryptedUnicode('bar')]

    result = ansible_native_concat(nodes)
    assert result == 'foo123None{}[]bar'

    result = ansible_native_concat(nodes[:3])
    assert result == 'foo123'

    result = ansible_native_concat([])
    assert result is None

    result = ansible_native_concat([123])
    assert result == 123

    result = ansible_native_concat(['foo'])
    assert isinstance(result, text_type)
    assert result == 'foo'

    result = ansible_native

# Generated at 2022-06-21 07:48:21.299324
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test 1
    x = [u'X']
    assert ansible_native_concat(x) == u'X'

    # Test 2
    x = [u'X', u'Y']
    assert ansible_native_concat(x) == u'XY'

    # Test 3
    x = [u'X', u' ', u'Y']
    assert ansible_native_concat(x) == u'X Y'

    # Test 4
    x = [u'a', u' ', u'e', u'i', u'o', u'u']
    assert ansible_native_concat(x) == u'a eiou'

    # Test 5
    x = [u'X', u' ', u'Y', u' ', u'Z']
    assert ansible_native_concat

# Generated at 2022-06-21 07:48:27.526766
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test that ansible_native_concat evaluates a list of nodes as expected"""
    from ansible.template.safe_eval import ansible_native_convert_exception
    nodes = []

    # Test single node
    nodes.append(ansible_native_concat(['test']))
    assert nodes[-1] == 'test'

    # Test multi node
    nodes.append(ansible_native_concat(['test', '1']))
    assert nodes[-1] == 'test1'

    # Test literals
    nodes.append(ansible_native_concat(['1']))
    assert nodes[-1] == 1

    nodes.append(ansible_native_concat(['1.0']))
    assert nodes[-1] == 1.0


# Generated at 2022-06-21 07:48:33.304625
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Assert if test fails
    assert ansible_native_concat(['blah', 'blah']) == 'blahblah'
    assert ansible_native_concat(['blah', 'blah']) == ansible_native_concat(['blah', 'blah', None])
    assert ansible_native_concat(['blah', 'blah', False]) == 'blahblahFalse'



# Generated at 2022-06-21 07:48:44.424990
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """This unit test can be used to test the 'ansible_native_concat' function with all
    supported cases.
    """

    assert ansible_native_concat('Ansible') == 'Ansible'
    assert ansible_native_concat(123) == 123
    assert ansible_native_concat(['This', 'is', 'Ansible']) == 'ThisisAnsible'
    assert ansible_native_concat(['This', 123, 'Ansible']) == 'This123Ansible'
    assert ansible_native_concat(['This', 123, 'Ansible', {'foo': 'bar'}]) == 'This123Ansible{foo: bar}'

# Generated at 2022-06-21 07:48:53.492013
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    to_text = str if bytes is str else lambda x: x.decode("utf-8")

    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == to_text("[1, 2]")
    assert ansible_native_concat([1, '2']) == to_text("1'2")

    assert ansible_native_concat((n for n in [])) is None
    assert ansible_native_concat((n for n in [1])) == 1
    assert ansible_native_concat((n for n in [1, 2])) == to_text("[1, 2]")

# Generated at 2022-06-21 07:49:02.491428
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_text

    # These should decode as native Python types
    assert ansible_native_concat(["{{ [1, 2] }}"]) == [1, 2]
    assert ansible_native_concat(["{{ {'k1': 'v1'} }}"]) == {'k1': 'v1'}
    assert ansible_native_concat(["{{ True }}"]) is True
    assert ansible_native_concat(["{{ False }}"]) is False
    assert ansible_native_concat(["{{ ['key', ] }}"]) == ['key']
    assert ansible_native_concat(["{{ None }}"]) is None
    assert ansible_native_concat(["{{ -1 }}"]) == -1

# Generated at 2022-06-21 07:49:12.567586
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # pylint: disable=unused-import,too-few-public-methods,import-error
    import ast

    class EvalLiteral:
        """Evaluate a literal node."""
        def __init__(self, value):
            self.value = value

        def __html__(self):
            # pylint: disable=no-member
            return self.value

        def __unicode__(self):
            return self.value

        def __str__(self):
            return self.value

        def handle(self, context):
            if isinstance(self.value, string_types):
                self.value = to_text(self.value, errors='surrogate_then_replace')
            try:
                return ast.literal_eval(self.value)
            except ValueError:
                return self

# Generated at 2022-06-21 07:49:20.414756
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar', 'baz']) == 'foobarbaz'
    assert ansible_native_concat(['foo', None, 'bar', 'baz']) == 'fooNonebarbaz'
    assert ansible_native_concat(['foo', 5, 'bar', 'baz']) == 'foo5barbaz'
    assert ansible_native_concat(['foo', {'bar': 5}, 'baz']) == 'foo{\'bar\': 5}baz'
    assert ansible_native_concat(['foo', ['bar', 'baz'], 'foo']) == 'foo[\'bar\', \'baz\']foo'

# Generated at 2022-06-21 07:49:32.239470
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test function :func:`ansible_native_concat`

    In this test, we use the following types of nodes (from jinja2.nodes)

    - Constant
    - List
    - Dict
    - Concat
    - ListComp
    - DictComp

    """
    from jinja2.nodes import (Constant, List, Concat, ListComp, Dict, DictComp)

    def create_test_node(*items):
        """Helper function to create the test node"""
        node = Constant('')
        for item in items:
            if isinstance(item, Constant):
                node = Concat([node, item])

# Generated at 2022-06-21 07:49:43.220919
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2]) is None
    assert ansible_native_concat([1]) == 1

    assert ansible_native_concat([1, 2] * u'1') == '11'
    assert ansible_native_concat([1, 2] * u'1' * u'1') == '1111'

    assert ansible_native_concat([u'1', 2]) == '12'
    assert ansible_native_concat([u'1', 2] * u'1') == '121'
    assert ansible_native_concat([u'1', 2] * u'1' * u'1') == '1211'

    assert ansible_native_concat([1, 2] * u'a') == 'aa'

# Generated at 2022-06-21 07:49:53.700657
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # type: () -> None
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([1]) == 1

    assert ansible_native_concat([1, '2']) == '12'
    assert ansible_native_concat([1, '2', 3]) == '123'

    assert ansible_native_concat(('1', '2')) == '12'
    assert ansible_native_concat(('1', '2', 3)) == '123'

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, 2, 3]) == '123'



# Generated at 2022-06-21 07:50:04.261119
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test basic string concat
    a = "foo"
    b = "bar"
    c = "spam"
    d = "{{ c }}"
    result = ansible_native_concat([a, b, c, d])
    assert result == "foobarspam"

    # Test handling of unicode
    a = "\u03b8"
    result = ansible_native_concat([a])
    assert result == "θ"

    # Test literal_eval
    a = "['bar', 'baz']"
    b = "{{ a }}"
    result = ansible_native_concat([a, b])
    assert result == ['bar', 'baz']

    # Test that empty values are removed
    a = "{{ a }}"
    b = "spam"

# Generated at 2022-06-21 07:50:15.049316
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat([[1, 2], [3]]) == [1, 2, 3]
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([None, 'foo', 'bar', u'baz']) == None
    assert ansible_native_concat([None, 'foo', 'bar', u'baz', u'', None]) is None
    assert ansible_native_concat([None, 'foo', 'bar', u'baz', u'', u'']) == ''

# Generated at 2022-06-21 07:50:25.139260
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def c(x):
        return AnsibleVaultEncryptedUnicode(x, password='test')


# Generated at 2022-06-21 07:50:33.655239
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2.nodes import Const, Name

    # expected, actual