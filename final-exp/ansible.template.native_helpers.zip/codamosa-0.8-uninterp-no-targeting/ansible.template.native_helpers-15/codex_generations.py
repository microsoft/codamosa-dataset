

# Generated at 2022-06-21 07:40:40.678891
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test simple concat
    assert ansible_native_concat(["foo", "bar"]) == "foobar"

    # Test unicode concat
    assert ansible_native_concat(["foo", "ű"]) == "fooű"
    assert ansible_native_concat(["ű", "foo"]) == "űfoo"
    assert ansible_native_concat(["űű", "foo"]) == "űűfoo"
    assert ansible_native_concat(["foo", "űű"]) == "fooűű"

    # Test empty string concat
    assert ansible_native_concat(["foo", ""]) == "foo"
    assert ansible_native_concat(["", "foo"]) == "foo"

    # Test

# Generated at 2022-06-21 07:40:49.098722
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([b'foo', b'bar']) == u'foobar'
    assert ansible_native_concat(['foo', 'bar']) == u'foobar'
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([u'foo', 123, u'bar']) == u'foo123bar'
    # test that ast.literal_eval is called
    assert ansible_native_concat([u"'foo'", u'"bar"']) == (u'foo', u'bar')
    # undefined values
    assert None == ansible_native_concat([])
    assert None == ansible_native_concat([None])

# Generated at 2022-06-21 07:41:01.681196
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test 1: Concat with None
    assert ansible_native_concat(None) is None

    # Test 2: Concat with empty Generators
    assert ansible_native_concat(()) is None

    # Test 3: Concat with a string
    assert ansible_native_concat(('abc',)) == 'abc'
    assert ansible_native_concat(['abc']) == 'abc'

    # Test 4: Concat mixed data types
    assert ansible_native_concat(('abc', 123)) == 'abc123'
    assert ansible_native_concat(['abc', 123]) == 'abc123'

    # Test 5: Concat with undefined
    from jinja2.runtime import Undefined  # pylint: disable=import-error

# Generated at 2022-06-21 07:41:13.154334
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat([1, 2.0, 3]) == 123.0
    assert ansible_native_concat([1, 2.0j, 3]) == 1 + 2.0j
    assert ansible_native_concat(["a", "b", "c"]) == "abc"
    assert ansible_native_concat([True, False, False]) is False
    assert ansible_native_concat(['True', 'False', 'False']) == 'TrueFalseFalse'
    assert ansible_native_concat(['True', 'False', 'False']) == 'TrueFalseFalse'

# Generated at 2022-06-21 07:41:24.040927
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # https://github.com/pallets/jinja/blob/master/tests/nativetypes.py

    import jinja2

    env = jinja2.Environment(trim_blocks=True, lstrip_blocks=True)
    env.filters['ansible_native_concat'] = ansible_native_concat
    env.filters['to_text'] = container_to_text

    def test(strings, expected):
        t = env.from_string('{{ [%s]|ansible_native_concat|to_text(indent=0) }}' % ','.join(strings))
        assert t.render() == expected

    test(['1'], '1')
    test(['1', '2'], '12')
    test(['true'], 'True')

# Generated at 2022-06-21 07:41:33.678381
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # test string concatenation
    string_values = [
        "a",
        "bc",
        "def",
        "ghij",
        "klmno",
    ]
    value = ansible_native_concat(string_values)
    assert value == "abcdefghijklmno"

    # the same, but with different types of input
    unicode_values = [
        u"a",
        u"bc",
        u"def",
        u"ghij",
        u"klmno",
    ]
    value = ansible_native_concat(unicode_values)
    assert value == u"abcdefghijklmno"


# Generated at 2022-06-21 07:41:43.048426
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.collections import (
        recursive_diff,
    )

    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1.6]) == 1.6
    assert ansible_native_concat([u'1']) == u'1'
    assert ansible_native_concat([b'1']) == b'1'
    assert ansible_native_concat([set([1])]) == set([1])
    assert ansible_native_concat([set([u'1'])]) == set([u'1'])

# Generated at 2022-06-21 07:41:54.746500
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2.runtime import Context
    from jinja2.nodes import Output
    from jinja2._compat import text_type

    # TypeError: can only concatenate str (not "int") to str is an example
    # of the message produced when a non string is passed to the native
    # _concat function.
    assert ansible_native_concat([text_type(42), Output([to_text("'"), to_text("42"), to_text("'")])]) == "'42'"
    assert ansible_native_concat([text_type(42), Output([to_text("'"), to_text("42"), to_text("'")]), text_type(10)]) == "'42'10"

# Generated at 2022-06-21 07:42:03.738424
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = [1, 2, 3]
    out = u'123'

    # Test a single text node
    assert ansible_native_concat(iter(nodes)) == nodes[0]

    # Test a single non-text node
    nodes = [{"a": 1, "b": 2}]

    assert ansible_native_concat(iter(nodes)) == nodes[0]

    # Test a string node
    nodes = ["1", "2", "3"]

    assert ansible_native_concat(iter(nodes)) == out

    # Test a json string
    nodes = ['{{ "{\"a\": [1,2,3]}" }}']

    assert ansible_native_concat(iter(nodes)) == {"a": [1, 2, 3]}

    # Test a string node with leading spaces
    nodes

# Generated at 2022-06-21 07:42:14.490283
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == 1

    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'

    assert ansible_native_concat([True]) == True
    assert ansible_native_concat([False]) == False

    assert ansible_native_concat([1, 2, ansible_native_concat(['abc', ' def '])]) == 12
    assert ansible_native_concat([1, 2, ansible_native_concat(['abc', ' def '])]) == 12

    assert ansible_native_concat([1, 2, ansible_native_concat(['abc', ' def '])]) == 12

# Generated at 2022-06-21 07:42:25.846452
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_text, to_native

    for value in [
        1,
        u'foo',
        [u'foo', u'bar'],
        {u'foo': u'bar', u'one': 1},
        u'foo\nbar',
        [{u'one': 1, u'two': 2}, u'foo'],
    ]:
        assert ansible_native_concat([value]) == value

    # multiple nodes/values, verify that to_text is applied
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([1, 2]) == '12'

# Generated at 2022-06-21 07:42:36.520031
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Test empty
    assert ansible_native_concat(None) is None
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(iter([])) is None

    # Test non-string
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(iter([1])) == 1
    assert ansible_native_concat([1, 2, 3]) == u'123'
    assert ansible_native_concat(iter([1, 2, 3])) == u'123'

    # Test string
    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat(iter([u'foo'])) == u'foo'

# Generated at 2022-06-21 07:42:46.462432
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2.runtime import Undefined
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['{{ foo }}', 2, 3]) == u'23'
    assert ansible_native_concat(['{{ foo }}', Undefined(), '{{ bar }}']) == u'{{ foo }}{{ bar }}'
    assert ansible_native_concat([]) is None

    # This is the example from
    # https://github.com/pallets/jinja/blob/master/src/jinja2/nativetypes.py
    # Except we are using our custom ansible_native_concat instead of
    # jinja2.nativetypes.concat, which is not exposed for imports.
   

# Generated at 2022-06-21 07:42:57.071990
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2
    env = jinja2.Environment(extensions=['jinja2_native.NativeExtension'])


# Generated at 2022-06-21 07:43:06.516065
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([u'1']) == u'1'
    assert ansible_native_concat([u'1', u'2']) == u'12'
    assert ansible_native_concat([u'1', u'2', u'3']) == u'123'
    assert ansible_native_concat([u'ab']) == u'ab'
    assert ansible_native_concat([u'a', u'b']) == u'ab'
    assert ansible_native_concat([u'1', u'2', u'3']) == u'123'
    assert ansible_native_concat([u'1 ', u'2', u' 3']) == u'1 2 3'
    assert ansible

# Generated at 2022-06-21 07:43:14.386442
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([container_to_text('hello')]) == 'hello'

    assert ansible_native_concat([container_to_text('hello'), container_to_text('world')]) == 'helloworld'
    assert ansible_native_concat([container_to_text('hello'), container_to_text(' '), container_to_text('world')]) == 'hello world'

# Generated at 2022-06-21 07:43:25.933742
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import Markup
    from jinja2.nodes import Name

    assert ansible_native_concat([]) is None

    # one node
    assert ansible_native_concat([Name('foo', 'store')]) == 'foo'

    # multiple nodes
    assert ansible_native_concat([Name('foo', 'store'), Name('bar', 'store')]) == 'foo bar'

    # concatenated strings
    assert ansible_native_concat(['foo ', 'bar']) == 'foo bar'

    # literal_eval-able strings
    assert ansible_native_concat(['abc', '123']) == 'abc123'
    assert ansible_native_concat(['1', '1']) == 2

# Generated at 2022-06-21 07:43:35.084550
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test that the native concat function returns a list of strings
    # if the input is a list of strings
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(['a', 'b', 'c', 'd', 'e']) == 'abcde'

    # Test that the native concat function returns an empty string
    # for an empty list
    assert ansible_native_concat([]) == ''

    # Test that the native concat function returns an empty string
    # for an empty generator
    assert ansible_native_concat((x for x in ())) == ''

    # Test that the native concat function returns a string
    # if the input is a single string
    assert ansible_native_concat(['a']) == 'a'

# Generated at 2022-06-21 07:43:48.388725
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'a', u'b']) == u'ab'
    assert ansible_native_concat([u'a', True, u'c']) == u'atruec'
    assert ansible_native_concat([True, u'a', u'b', False]) == u'TrueabFalse'
    assert ansible_native_concat([u'a']) == u'a'

    # Ensure that non-string values are returned as is
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat([True, 1, u'a']) == [True, 1, u'a']

# Generated at 2022-06-21 07:44:00.870442
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.template.safe_eval import AnsibleJ2Vars
    assert ansible_native_concat(AnsibleJ2Vars({}).get_vars(
        text='{{ 2 }}',
        filename=None,
        args=None,
        loader=None,
        cache=True,
        unsafe=False,
        vars=None,
        basedir=None,
        override_vars=None,
        context=None,
        convert_bare=True,
        convert_data=False,
    )) == 2

# Generated at 2022-06-21 07:44:16.597067
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # NOTE: This is a unit test for the above function, which is provided as
    # a Jinja filter.  Unit tests for Jinja filters are difficult because
    # the actual Jinja environment is required to parse the Jinja expression
    # and compile it into a set of Jinja nodes.

    # Create a minimal Jinja environment
    from jinja2.environment import Environment
    jenv = Environment()
    # Add a variable called "a"
    jenv.globals["a"] = "a"
    # Add a variable called "b"
    jenv.globals["b"] = "b"
    # Add a variable called "c"
    jenv.globals["c"] = "c"

    # Add the Jinja filter to the Jinja environment
    jenv.filters['ansible_native_concat'] = ans

# Generated at 2022-06-21 07:44:26.781775
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('') == None
    assert ansible_native_concat(None) == None
    assert ansible_native_concat(-1) == -1
    assert ansible_native_concat(1) == 1
    assert ansible_native_concat(0) == 0
    assert ansible_native_concat(0.0) == 0.0
    assert ansible_native_concat(0.1) == 0.1

    assert ansible_native_concat(False) == False
    assert ansible_native_concat(True) == True

    # assert ansible_native_concat('True') == True
    # assert ansible_native_concat('False') == False

    # assert ansible_native_concat('None') == None

    assert ansible_native_

# Generated at 2022-06-21 07:44:38.704905
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test when the result is a single node
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1.1]) == 1.1
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([[1, 2, 3]]) == [1, 2, 3]
    assert ansible_native_concat([{'a': 1}]) == {'a': 1}
    assert ansible_native_concat([b'a']) == b'a'
    assert ansible_native_concat([u'a']) == u'a'

    # Test when the result is not a single node
    assert ansible_native_concat([u'a', u'b', u'c']) == u'abc'


# Generated at 2022-06-21 07:44:50.660704
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = (1, 2, 3)
    assert ansible_native_concat(nodes) == 1
    nodes = map(NativeJinjaText, (1, 2, 3))
    assert ansible_native_concat(nodes) == '123'
    nodes = ('foo', 'bar')
    assert ansible_native_concat(nodes) == 'foobar'
    nodes = ('foo', '', 'bar')
    assert ansible_native_concat(nodes) == 'foobar'
    nodes = ('foo', None, 'bar')
    assert ansible_native_concat(nodes) == 'foobar'
    nodes = ('foo', (), 'bar')
    assert ansible_native_concat(nodes) == 'foobar'
    nodes = ('foo', [], 'bar')

# Generated at 2022-06-21 07:44:59.486378
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([None, None]) is None
    assert ansible_native_concat([None, False]) is False
    assert ansible_native_concat([True, True]) == '1'
    assert ansible_native_concat([True, True, True]) == '11'
    assert ansible_native_concat([False, True]) == '1'
    assert ansible_native_concat([False, True, True]) == '11'
    assert ansible_native_concat([True, False]) == '1'
    assert ansible_native_concat([True, False, False]) == '10'
    assert ansible_native_concat([False, False]) == ''

# Generated at 2022-06-21 07:45:09.938253
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    class test_list(list):
        pass

    class test_tuple(tuple):
        pass

    class test_dict(dict):
        pass

    # basic test to ensure the function returns the correct data type
    assert ansible_native_concat([0]) == 0
    assert ansible_native_concat([True]) == True
    assert ansible_native_concat(['test']) == 'test'
    assert ansible_native_concat([[]]) == []
    assert ansible_native_concat([()]) == ()
    assert ansible_native_concat([{}]) == {}
    assert ansible_native_concat([{0: 'test'}]) == {0: 'test'}
    assert ansible_native_concat([[0]]) == [0]
    assert ansible_

# Generated at 2022-06-21 07:45:20.707045
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['test']) == 'test'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['1', '2', '3']) == 123
    assert ansible_native_concat(['1.0', '2.0', '3.0']) == 1.0
    assert ansible_native_concat(['1.0.0']) == '1.0.0'
    assert ansible_native_concat(['"1"']) == '"1"'

    # Jinja2's list_to_native is an alternative to ansible_native_concat
    # https://github.com/ansible/ansible/issues/70831

# Generated at 2022-06-21 07:45:32.823113
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.utils.jinja2 import AnsibleNativeJinjaParser

    assert ansible_native_concat([]) is None

    assert ansible_native_concat([0]) == 0
    assert ansible_native_concat(['0']) == '0'
    assert ansible_native_concat([0, '0']) == '00'
    assert ansible_native_concat([0, '0', 0]) == '000'
    assert ansible_native_concat([0, ' 0', 0]) == ' 00'

    parser = AnsibleNativeJinjaParser()

    assert ansible_native_concat([parser.parse('0')]) == 0
    assert ansible_native_concat([parser.parse('"0"')]) == "0"

# Generated at 2022-06-21 07:45:37.743742
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat([1, 'b']) == 1
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['a', 1]) == 'a1'
    assert ansible_native_concat([u'a', 1]) == u'a1'
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat(['a', 2, 3]) == 'a23'
    assert ansible_native_concat([1, 'a', 3]) == 1
    assert ansible

# Generated at 2022-06-21 07:45:47.676702
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.constructor import AnsibleConstructor


# Generated at 2022-06-21 07:46:02.267593
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # test literal_eval and str concat
    assert ansible_native_concat([str('{"a": "b"}'), str('c')]) == '{"a": "b"}c'
    assert ansible_native_concat([str('{"a": "b"}'), str('c')]) == ansible_native_concat([str('{"a": "b"}'), str('c')])
    assert ansible_native_concat([str('{"a": "b"}'), str('c')]) == {"a": "b"}
    assert ansible_native_concat([str('{"a": "b"}'), str('c')]) == ast.literal_eval('{"a": "b"}c')
    # test str concat

# Generated at 2022-06-21 07:46:13.966785
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat((1, 2)) == '12'
    assert ansible_native_concat([3, '4']) == '34'
    assert ansible_native_concat([5, 6, '7']) == '567'
    assert ansible_native_concat((8, 9, 10, 11, '12')) == '89101112'
    assert ansible_native_concat((13, '24', 30)) == '132430'
    assert ansible_native_concat((40, '51', '63')) == '4051' + '63'

    assert ansible_native_concat(['a', 'b', 'c']) is 'abc'
    assert ansible_native_concat(['abc', 'def']) is 'abcdef'
    assert ansible_

# Generated at 2022-06-21 07:46:25.758509
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Unit test for function ansible_native_concat
    """
    # Test with raw values that are not strings
    # These examples should return their input value
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([True]) == True
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([1, 2, 3, 4]) == '1234'
    assert ansible_native_concat([1, 2, 3, 4, 5]) == '12345'
    assert ansible_native_concat([1, 2, 3, 4, 5, 6])

# Generated at 2022-06-21 07:46:34.956048
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:46:44.884160
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template.template import AnsibleJ2Vars

    assert ansible_native_concat([]) is None

    dl = DataLoader()
    assert ansible_native_concat(
        ansible_j2_vars(dl, dl.load(123)).values()
    ) == 123

    # see: https://github.com/pallets/jinja/issues/1200
    assert ansible_native_concat(
        ansible_j2_vars(dl, dl.load('{{ x | string }}')).values()
    ) == '{{ x | string }}'


# Generated at 2022-06-21 07:46:55.776786
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import random
    import ast
    import string
    import textwrap
    from ansible.module_utils.common.text.converters import native

    # generate random strings
    words = [''.join(random.choices(string.ascii_letters, k=10)) for _ in range(100)]
    exprs = [native(random.choices(words)) for _ in range(100)]
    # generate random expression
    def make_random_expr():
        s = random.choices(exprs)
        i = random.randint(0, len(s))
        return s[:i] + ['|'] + s[i:]

# Generated at 2022-06-21 07:47:07.912971
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([1, '1']) == '11'
    assert ansible_native_concat([['1', '1']]) == ['1', '1']
    assert ansible_native_concat([{'a': '1'}, 'a']) == '1'
    assert ansible_native_concat([(1,), 2]) == (1, 2)

    # the following tests have been taken from the unit test for
    # the native concat function in Jinja2

# Generated at 2022-06-21 07:47:15.064554
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['123', '456']) == '123456'
    assert ansible_native_concat([123, 456]) == 123456
    assert ansible_native_concat(['0b101', '2']) == '0b1012'
    assert ansible_native_concat([0b101, 2]) == 102
    assert ansible_native_concat(['1.', '23']) == '1.23'
    assert ansible_native_concat(['-.', '23']) == '-.23'

# Generated at 2022-06-21 07:47:26.146739
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a', 1, u'b']) == 'a1b'
    assert ansible_native_concat(['a', 1, u'b', 2, u'c']) == 'a1b2c'
    assert ansible_native_concat(['a', 1, u'b', 2, u'c', 3]) == 'a1b2c3'
    assert ansible_native_concat(['a', 1, u'b', 2, u'c', 3, u'd']) == 'a1b2c3d'
    assert ansible_native_concat(['a', 1, u'b', 2, u'c', 3, u'd', 4]) == 'a1b2c3d4'

# Generated at 2022-06-21 07:47:37.382692
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.native_jinja import NativeJinjaText

    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([1, 2]) == u'12'
    assert ansible_native_concat([1, '2']) == u'12'
    assert ansible_native_concat(['a', 'b']) == u'ab'

    assert ansible_native_concat([' ', 'a']) == u' a'
    assert ansible_native_concat([1, ' ']) == u'1 '

   

# Generated at 2022-06-21 07:47:52.443741
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.data import AnsibleVaultEncrypted
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject, AnsibleUnicode

    assert ansible_native_concat([]) is None

    assert ansible_native_concat([AnsibleUnicode(text_type('foo'))]) == text_type('foo')
    assert ansible_native_concat([AnsibleUnicode(text_type('foo'))]) == text_type('foo')

    assert ansible_native_concat([AnsibleUnicode(text_type('foo')), AnsibleUnicode(text_type('bar'))]) == text_type('foobar')


# Generated at 2022-06-21 07:47:58.729493
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2

    result = jinja2.Template('{{ [1] + [2] }}').render(dict())
    assert result == "[1, 2]"

    result = jinja2.Template('{{ [1] ~ [2] }}').render(dict())
    assert result == "[1 2]"

    result = jinja2.Template('{{ [1, 2] ~ [3] }}').render(dict())
    assert result == "[1, 2 3]"

    result = jinja2.Template('{{ [1, 2] ~ [3] | string }}').render(dict())
    assert result == "[1, 2 3]"

    result = jinja2.Template('{{ [1, 2] ~ [3] | to_json }}').render(dict())
    assert result == "[1, 2, 3]"

    result

# Generated at 2022-06-21 07:48:10.532034
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def test(expected, nodes):
        assert expected == ansible_native_concat(nodes)

    test(None, [])
    test(None, [None])

    test(True, [True])
    test(False, [False])

    test(1, [1])
    test(1.0, [1.0])
    test(1 + 2j, [1 + 2j])
    test('asd', ['asd'])
    test('asd', [None, 'asd'])
    test('asd', ['asd', None])
    test('a\nb\nc', ['a', 'b', 'c'])
    test('a', [1, 'a', 2])
    test(b'a', [1, b'a', 2])

# Generated at 2022-06-21 07:48:22.529345
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([['a', 'b']]) == ['a', 'b']
    assert ansible_native_concat(['a', 'b']) == u'ab'
    assert ansible_native_concat([1, 2]) == 3
    assert ansible_native_concat([['a', 'b'], 'c']) == ['a', 'b', 'c']
    assert ansible_native_concat([True, 'c']) == 'Truec'
    assert ansible_native_concat(['a', ['b']]) == u'a[b]'

# Generated at 2022-06-21 07:48:28.220909
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils import basic


# Generated at 2022-06-21 07:48:38.701190
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2


# Generated at 2022-06-21 07:48:49.249279
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Create compiled nodes
    raw_value1 = "Hello "
    raw_value2 = "World"
    globals_dict = locals()

    exec("compiled_value1 = compile('" + raw_value1 + "', 'test', 'eval')", globals_dict)
    exec("compiled_value2 = compile('" + raw_value2 + "', 'test', 'eval')", globals_dict)
    compiled_value1 = globals_dict.get('compiled_value1')
    compiled_value2 = globals_dict.get('compiled_value2')

    # Ensure that the compilation of strings does not change the result
    assert ansible_native_concat([compiled_value1, compiled_value2]) == raw_value1 + raw_value2

    # Ensure undefined variables raise an exception
    assert ans

# Generated at 2022-06-21 07:48:56.336339
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:49:07.865718
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('foo') == 'foo'
    assert ansible_native_concat(u'foo') == 'foo'
    assert ansible_native_concat(42) == 42

    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(('foo', 'bar')) == 'foobar'
    assert ansible_native_concat(('foo', 42)) == 'foo42'

    assert ansible_native_concat([u'foo', u'bar']) == 'foobar'
    assert ansible_native_concat((u'foo', u'bar')) == 'foobar'
    assert ansible_native_concat((u'foo', u'42')) == 'foo42'

    assert ansible_native

# Generated at 2022-06-21 07:49:16.179557
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == []
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([[1], [2], [3]]) == [[1], [2], [3]]
    assert ansible_native_concat([[1], 2, [3]]) == [[1], 2, [3]]
    assert ansible_native_concat([[1], 'abc', [3]]) == [1, 'abc', 3]
    assert ansible_native_concat([[1], '2', [3]]) == [1, '2', 3]

# Generated at 2022-06-21 07:49:32.312766
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = (
        'Hello ',
        'world!',
        42,
        'True',
        'False',
        'None',
        42.0
    )
    native_names = {
        42: 'AnsibleInteger',
        42.0: 'AnsibleFloat',
        True: 'AnsibleBoolean',
        False: 'AnsibleBoolean',
        None: 'AnsibleNone'
    }
    for node in nodes:
        assert type(ansible_native_concat((node,))).__name__ == native_names.get(node, 'str')

    assert ansible_native_concat((42, 42.0)) == 84.0

# Generated at 2022-06-21 07:49:39.463128
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:49:49.433607
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test with list
    test_list = [1, 2, 3]
    assert ansible_native_concat(ansible_native_concat(test_list)) == test_list

    # Test with dict
    test_dict = {
        "key": "value",
        "key2": "value2",
        "key3": "value3",
    }
    assert (ansible_native_concat(ansible_native_concat(test_dict)) ==
            test_dict)

    # Test with AnisbleVaultEncryptedUnicode
    vu = AnsibleVaultEncryptedUnicode("foo")
    assert (ansible_native_concat(ansible_native_concat(vu)) ==
            container_to_text(vu.data))

    # Test with NativeJinjaText
   

# Generated at 2022-06-21 07:50:00.876148
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([u'a']) == u'a'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([True]) == True
    assert ansible_native_concat([None]) == None

    assert ansible_native_concat([u'a', u'b']) == u'ab'
    assert ansible_native_concat([u'a', u'b']) == u'ab'
    assert ansible_native_concat([True, False]) == u'TrueFalse'

    assert ansible_native_concat([u'a', 1]) == u'a1'
    assert ansible_native_concat([1, u'a']) == u'1a'
   

# Generated at 2022-06-21 07:50:11.235728
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:50:19.340551
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # convert a list to string
    assert ansible_native_concat([u'a', u'b', u'c']) == 'abc'

    # convert a tuple to string
    assert ansible_native_concat([u'a', u'b', u'c']) == 'abc'

    # convert a string to int
    assert ansible_native_concat([u'1']) == 1

    # convert a string to float
    assert ansible_native_concat([u'1.1']) == 1.1

    # append a string on starting of list
    assert ansible_native_concat([u'a', u'b', u'c']) == 'abc'

    # append a string on starting of tuple
    assert ansible_native_concat([u'a', u'b', u'c'])

# Generated at 2022-06-21 07:50:31.423430
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.utils.hashing import data_hash
