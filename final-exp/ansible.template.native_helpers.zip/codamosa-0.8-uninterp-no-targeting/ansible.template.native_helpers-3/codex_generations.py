

# Generated at 2022-06-21 07:40:40.883530
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['abc', 'def']) == 'abcdef'
    assert ansible_native_concat([123, 'abc', None, True]) == '123abcNoneTrue'
    assert ansible_native_concat([123]) == 123
    assert ansible_native_concat(['a: b']) == 'a: b'
    assert ansible_native_concat(['a: b', 'c: d']) == 'a: bc: d'
    assert ansible_native_concat([1, 'abc', None, True]) == '1abcNoneTrue'
    assert ansible_native_concat([1, 'abc', None, True]).__class__ == str

# Generated at 2022-06-21 07:40:51.980133
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import sys

    def traverse(data, func, path=None):
        if isinstance(data, Mapping):
            for key, value in data.items():
                for result in traverse(value, func, path=(path or []) + [key]):
                    yield result
        elif is_sequence(data):
            for index, item in enumerate(data):
                for result in traverse(item, func, path=(path or []) + [index]):
                    yield result
        else:
            yield func(data, path)

    def test_one(nodes, expected, literal_eval=ast.literal_eval):
        nodes = list(nodes)
        out = ansible_native_concat(nodes)


# Generated at 2022-06-21 07:41:03.639313
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    assert None is ansible_native_concat([])

    assert 'abc' is ansible_native_concat(['abc'])

    assert ['a', 'b', 'c'] is ansible_native_concat(['a', 'b', 'c'])

    assert 'a,b,c' is ansible_native_concat(['a', ',', 'b', ',', 'c'])

    assert ['a', ['b', 'c'], 'd'] is ansible_native_concat(['a', '[', 'b', ',', 'c', ']', 'd'])

    # NativeJinjaText is a special indicator that the value should not be parsed
    # by literal_eval. This is marked when we need to

# Generated at 2022-06-21 07:41:13.983837
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.six.moves import builtins

    true_values = ('true', 'True', 'TRUE', 'on', 'On', 'ON', 'y', 'Y', 'yes', 'Yes', 'YES', '1', 1, True)
    false_values = ('false', 'False', 'FALSE', 'off', 'Off', 'OFF', 'n', 'N', 'no', 'No', 'NO', '0', 0, 0.0, False)

    assert ansible_native_concat(['1', '1']) == '11'

    for value in true_values:
        assert ansible_native_concat([value, true_values[0]]) is True

    for value in false_values:
        assert ansible_native_concat([value, false_values[0]]) is False



# Generated at 2022-06-21 07:41:24.361441
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2, 3]) == "123"
    assert ansible_native_concat(iter([1])) == 1
    assert ansible_native_concat(iter([1, 2, 3])) == "123"
    assert ansible_native_concat(iter([1]), iter([2]), iter([3])) == "123"
    assert ansible_native_concat([[1]]) == [1]
    assert ansible_native_concat([[1], [2], [3]]) == "[1, 2, 3]"
    assert ansible_native_concat([[1, 2], [3]]) == "[1, 2, 3]"

# Generated at 2022-06-21 07:41:33.825291
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_text


# Generated at 2022-06-21 07:41:43.180273
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class myDict(object):
        pass

    # root cause of infinite loop ( https://bugs.python.org/issue21643 )
    class myDict(dict):
        def __getitem__(self, key):
            return self

    # root cause of OverflowError ( https://bugs.python.org/issue21643 )
    class myDict(dict):
        def __iter__(self):
            return self

    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1

    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, '2']) == '12'

    assert ansible_native_concat(['1', 2]) == '12'
    assert ansible_native_con

# Generated at 2022-06-21 07:41:52.749303
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == u'foobar'
    assert ansible_native_concat(['{"', 'foo', '": ', '2', '}']) == {u'foo': 2}
    assert isinstance(ansible_native_concat(['foo']), text_type)
    assert ansible_native_concat([2]) == 2
    assert ansible_native_concat([2.3]) == 2.3
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([False]) is False



# Generated at 2022-06-21 07:42:03.791518
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def helper(nodes):
        return container_to_text(ansible_native_concat(nodes))

    assert helper(['a', 'b']) == 'ab'
    assert helper([to_text(1), to_text(2)]) == u'12'
    assert helper([u'a', u'b']) == u'ab'
    assert helper(['{{ bar }}']) == '{{ bar }}'
    assert helper(['{{ bar }}', '{{ foo }}']) == '{{ bar }}{{ foo }}'
    assert helper([1, 2]) == 1
    assert helper([u'1', u'2']) == 2
    assert helper([u'"1"', u'"2"']) == '12'
    assert helper(['"1"', '"2"']) == '12'

# Generated at 2022-06-21 07:42:12.062988
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    node1 = object()
    node2 = object()
    node3 = object()
    node4 = object()
    node5 = object()

    # node1 is a string
    assert ansible_native_concat([node1]) == node1

    # node1 is None
    assert ansible_native_concat([]) == None

    # Two nodes with a single value
    assert ansible_native_concat([node1, node2]) == u''

    # Two nodes with two values
    assert ansible_native_concat([node1, node2, node3, node4]) == u''

    # Two nodes with one value
    assert ansible_native_concat([node1, node2, node3]) == node1

    # Three nodes with three values

# Generated at 2022-06-21 07:42:24.255864
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([123]) == 123
    assert ansible_native_concat([123, 456]) == 123456
    assert ansible_native_concat([123, u'456']) == 123456

    # The jinja2 native concat function returns the following, but
    # ansible_native_concat returns a string instead of the int because
    # we use ast.literal_eval to parse the value.
    # assert ansible_native_concat([u'123', 456]) == 579

    assert ansible_native_concat([123, u'456', 789]) == 123456789

    assert ansible_native_concat([123, u'456', 789, u'abc']) == '123456789abc'


# Generated at 2022-06-21 07:42:35.952898
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2.compiler
    import jinja2.nodes
    import jinja2.runtime
    import inspect

    native_concat_code = inspect.getsource(ansible_native_concat)
    native_concat_ast = ast.parse(native_concat_code, mode='exec')
    func_node = native_concat_ast.body[0]
    assert func_node.name == 'ansible_native_concat'
    assert len(func_node.args.args) == 1
    assert func_node.args.args[0].id == 'nodes'
    func_def = jinja2.nodes.Macro(None, func_node.name, func_node.args, func_node.body)

    # Create a fake function for testing ansible_native_con

# Generated at 2022-06-21 07:42:45.890034
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([5]) == 5
    assert ansible_native_concat([7.5]) == 7.5
    assert ansible_native_concat([True]) == True
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat([3, 'a', 'b', 7]) == '3ab7'
    assert ansible_native_concat([3, AnsibleVaultEncryptedUnicode('x', b'x')]) == '3x'

# Generated at 2022-06-21 07:42:55.275559
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 42]) == 'foo42'
    assert ansible_native_concat(['b', [2, 'c']]) == 'b[2, c]'
    assert ansible_native_concat([['b', 2], 'c']) == '[b, 2]c'
    assert ansible_native_concat(['foo', 42, [1, 2, 3]]) == 'foo421, 2, 3'
    assert ansible_native_concat(['foo', 42]) == 'foo42'
    assert ansible_native_concat(['foo']) == 'foo'

# Generated at 2022-06-21 07:43:05.900035
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # helper functions for recursive testing
    def assert_equal(a, b):
        assert a == b, "a={0} b={1}".format(container_to_text(a), container_to_text(b))

    def assert_same(a, b):
        assert a is b, "a={0} b={1}".format(container_to_text(a), container_to_text(b))

    def assert_value(a):
        assert_equal(ansible_native_concat(a), a)

    def assert_types(a, t):
        assert_same(ansible_native_concat(a), t)

    # test singleton dictionaries, lists, strings, integers, floats
    assert_same(ansible_native_concat([]), [])

# Generated at 2022-06-21 07:43:18.116911
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # test boolean handling
    assert ansible_native_concat([True, False]) == 'TrueFalse'
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([False]) is False

    # test string handling
    assert ansible_native_concat([u'abc', u'def']) == u'abcdef'
    assert ansible_native_concat([u'abc']) == u'abc'

    # test int handling
    assert ansible_native_concat([1, 2]) == 3
    assert ansible_native_concat([1]) == 1

    # test float handling
    assert ansible_native_concat([1.1, 2.2]) == 3.3
    assert ansible_native_concat([1.1]) == 1.1

    # test empty

# Generated at 2022-06-21 07:43:27.385556
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat([True, 'b', 'c']) == True
    assert ansible_native_concat([1, 2, 3.0]) == [1, 2, 3.0]
    assert ansible_native_concat(['a', 'b', u'c']) == 'abc'
    assert ansible_native_concat(['a', 'b', 3]) == 'ab3'
    assert ansible_native_concat([1, 'b', 3]) == 1
    assert ansible_native_concat([1, u'b', 'c']) == 1
    assert ansible_

# Generated at 2022-06-21 07:43:37.097606
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, '2']) in ('12', container_to_text('12'))
    assert ansible_native_concat([['1'], ['2']]) == [['1'], ['2']]
    assert ansible_native_concat([text_type(1), text_type('2')]) == container_to_text('12')

    # https://github.com/pallets/jinja/issues/1200
    assert isinstance(ansible_native_concat([NativeJinjaText('foo')]), NativeJinjaText)

# Generated at 2022-06-21 07:43:49.130922
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:44:01.392789
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
  assert ansible_native_concat(['foo', 'bar']) == 'foobar'
  assert ansible_native_concat(['1', '2']) == 12
  assert ansible_native_concat(['1', '2', '3']) == 123
  assert ansible_native_concat(['2', '2', '2']) == 222
  assert ansible_native_concat(['1.1', '2.2', '3.3']) == '1.12.23.3'
  assert ansible_native_concat(['1.1', '2.2', '3']) == '1.12.23'
  assert ansible_native_concat(['1', '2.2', '3']) == '1.22.3'
  assert ansible_native_concat

# Generated at 2022-06-21 07:44:21.164663
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # In Python 2 all strings are considered sequences of bytes unless
    # they are unicode strings. In Python 3 all Unicode strings are
    # considered sequences of unicode characters.
    # a_str = b'foo' # Python 2
    a_str = 'foo' # Python 3
    unicode_str = u'bar'
    a_list = list(a_str)
    a_dict = {'foo': 'bar'}
    a_code = compile('foo', '<module>', 'eval')
    an_object = object()


# Generated at 2022-06-21 07:44:28.766904
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat(['42']) == '42'
    assert ansible_native_concat(['42', '43']) == '4243'
    assert ansible_native_concat(['{1: 2}', '{3: 4}']) == '{1: 2}{3: 4}'
    assert ansible_native_concat(['[1, 2]']) == '[1, 2]'
    assert ansible_native_concat(['[1, 2]', '[3, 4]']) == '[1, 2][3, 4]'
    assert ansible_native_concat(['["1", "2"]']) == '["1", "2"]'
    assert ans

# Generated at 2022-06-21 07:44:40.048681
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test Python concatenation of types, with native casting of literals
    """
    import jinja2
    env = jinja2.Environment(extensions=['jinja2.ext.do'],
                             undefined=jinja2.StrictUndefined)

    env.globals['ansible_native_concat'] = ansible_native_concat

    # Base data types
    assert 1 == env.from_string('{{ [1] | ansible_native_concat }}').render()
    assert [] == env.from_string('{{ [] | ansible_native_concat }}').render()
    assert 1.1 == env.from_string('{{ [1.1] | ansible_native_concat }}').render()

# Generated at 2022-06-21 07:44:52.371319
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat(['foo','bar']) == 'foobar'
    assert ansible_native_concat([u'foo',u'bar']) == u'foobar'
    assert ansible_native_concat([1,2,3]) == '123'
    assert ansible_native_concat(['foo', 2]) == 'foo2'
    assert ansible_native_concat([[1,2],3]) == [1,2,3]
    assert ansible_native_concat([[1,2],3,4]) == [1,2,3,4]

# Generated at 2022-06-21 07:45:00.298040
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:45:10.353450
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.inventory.host import Host
    from ansible.playbook.play_context import PlayContext

    # test1: test literal_eval with numbers and strings
    nodes = NativeJinjaText(1), NativeJinjaText(2), NativeJinjaText(3)
    result = ansible_native_concat(nodes)
    assert result == 123

    nodes = NativeJinjaText('a'), NativeJinjaText('b'), NativeJinjaText('c')
    result = ansible_native_concat(nodes)
    assert result == 'abc'

    # test2: test literal_eval with dictionaries and lists
    nodes = NativeJinjaText('[1, 2]'), NativeJinjaText('[3, 4]'), NativeJinjaText('[5, 6]')
    result = ans

# Generated at 2022-06-21 07:45:21.060962
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:45:33.610439
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # The goal of this test is to leverage
    # :meth:`TestLoader.compile_string` to check
    # :meth:`NativeJinjaText.__add__` implementation
    from jinja2 import Environment

    env = Environment(undefined=StrictUndefined)
    env.filters['ansible_native_concat'] = ansible_native_concat

    data = u'ansible'

    assert data == env.compile_string(
        '{% filter ansible_native_concat %} {{ ' + data + ' }} {% endfilter %}').root()()


# Generated at 2022-06-21 07:45:44.334433
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:45:51.411840
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Empty node collection
    assert ansible_native_concat([]) is None

    # Single node collection
    assert ansible_native_concat(['abc']) == 'abc'
    assert ansible_native_concat([u'abc']) == u'abc'
    assert ansible_native_concat([123]) == 123
    assert ansible_native_concat([True])

    assert ansible_native_concat([{'a': 1, 'b': 2}]) == {'a': 1, 'b': 2}
    assert ansible_native_concat([{'a': 1, 'b': 2}]) == {'a': 1, 'b': 2}

# Generated at 2022-06-21 07:46:05.850877
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:46:17.042328
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == 12
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat([1, 'a']) == 1
    assert ansible_native_concat(['a', 1]) == 'a'
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat([1, 2, 'a', 'b', 'c']) == 12
    assert ansible_native_concat(['a', 'b', 1, 2, 3]) == 'a'


# Generated at 2022-06-21 07:46:29.029055
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([None, None]) is None
    assert ansible_native_concat([None, None, None]) is None
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 'bar', '', 'baz']) == 'foobarbaz'
    assert ansible_native_concat(['foo', 'bar', None, 'baz']) == 'foobarbaz'
    assert ansible_native_concat(['1', '2']) == 3

# Generated at 2022-06-21 07:46:36.495506
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(iter(['a', 'b'])) == 'ab'

    # https://github.com/ansible/ansible/issues/70831#issuecomment-664190894
    assert isinstance(ansible_native_concat(NativeJinjaText('a')), NativeJinjaText)

    assert ansible_native_concat(['1', 2]) == '12'

# Generated at 2022-06-21 07:46:46.082985
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_bytes, to_native
    from . import TestJinjaRenderNativeModule
    from datetime import datetime

    t = TestJinjaRenderNativeModule()
    t.add_module('ansible', 'ansible.module_utils.basic')

    t.add_template('test_native_concat.j2', u"{{ result }}", dict(result=[1, b"string"]))
    result = t.run_template('test_native_concat.j2')

    assert result == u'[1, string]'

    t.add_template('test_native_concat.j2', u"{{ result }}", dict(result=[2, "string"]))
    result = t.run_template('test_native_concat.j2')



# Generated at 2022-06-21 07:46:56.646529
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(range(1, 3)) == 2  # len 2
    assert ansible_native_concat([1]) == 1  # len 1
    assert ansible_native_concat([]) is None  # len 0
    assert ansible_native_concat(range(2, 5)) == u"234"  # len 3+
    assert ansible_native_concat([" 1", "2 "]) == u" 12"
    assert ansible_native_concat([" 1 ", "2 "]) == u" 1 2 "
    assert ansible_native_concat([1, 2]) == [1, 2]
    assert ansible_native_concat([[1], [2]]) == [1, 2]
    assert ansible_native_concat(map(str, range(1, 3)))

# Generated at 2022-06-21 07:47:08.784215
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    data_type = ast.literal_eval('''
        {
            "foo": {
                "bar": "baz",
                "qux": [
                    "abc",
                    "def"
                ]
            },
            "lorem": "ipsum",
            "dolor": "sit",
            "amet": "consectetur adipiscing elit",
            "sed": [
                "sit amet",
                "consectetur"
            ]
        }
    ''')


# Generated at 2022-06-21 07:47:21.598804
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.six import PY3

    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat([1, 2]) == 3
    assert ansible_native_concat([1, '2']) == '12'
    assert ansible_native_concat(['1', 2]) == '12'
    assert ansible_native_concat([' 1 ', ' 2 ']) == ' 1  2 '
    assert ansible_native_concat(['1.1', '2.2']) == '1.12.2'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_

# Generated at 2022-06-21 07:47:32.393728
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:47:40.566385
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 'bar', 'baz']) == 'foobarbaz'

    assert ansible_native_concat([1, 2, 3]) == 6
    assert ansible_native_concat(['1', '2', '3']) == '123'
    assert ansible_native_concat([1, '2', '3']) == '123'
    assert ansible_native_concat([1, 2, 3, 4, 'bar']) == '10bar'

# Generated at 2022-06-21 07:48:05.503328
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    '''Test for function ansible_native_concat'''
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(
                type='list',
                elements='raw',
                required=True,
            ),
        ),
    )

    result = {
        'changed': False,
        'failed': False,
        'ansible_native_concat': ansible_native_concat(module.params['data']),
    }

    module.exit_json(**result)



# Generated at 2022-06-21 07:48:14.141967
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_native
    from ansible.utils.native_jinja import native_from_string

    # Single node test
    text = native_from_string(u"'foobar'")
    assert to_native(text) == u'foobar'
    text = native_from_string(u"'bar'")
    assert to_native(text) == u'bar'

    # Multiple node test
    text = native_from_string(u"'foo' + 'bar'")
    assert to_native(text) == u'foobar'
    text = native_from_string(u"'foo' + 'bar' + 'baz'")
    assert to_native(text) == u'foobarbaz'

# Generated at 2022-06-21 07:48:23.369013
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(["a", "b"]) == "ab"
    assert ansible_native_concat(["a", ["b", "c"]]) == "a[u'b', u'c']"
    assert ansible_native_concat(["a", "1"]) == "a1"
    assert ansible_native_concat(["1"]) == 1
    assert ansible_native_concat(["1", 2]) == "12"
    assert ansible_native_concat(["1", "b"]) == "1b"
    assert ansible_native_concat(["a", 2]) == "a2"

# Generated at 2022-06-21 07:48:34.260527
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # unit test adapted from Jinja2

    class N(object):
        """A helper class for easier node creation."""

        def __init__(self, value):
            self.value = value

        def __add__(self, other):
            return N(self.value + other.value)

        def __str__(self):
            return str(self.value)

    def run(template, expected):
        """Helper for running a template with the `native_concat` env."""
        src = to_text('{{ %s }}') % template
        assert container_to_text(expected) == container_to_text(ansible_native_concat(ansible_native_concat.env.compile(src).root_render_func(ansible_native_concat.env)))

    # Set up the environment
    ansible

# Generated at 2022-06-21 07:48:45.571689
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.objects import AnsibleSequence

    def _test(values, expected, vault_password=None):
        values = [to_text(v) for v in values]
        nodes = [AnsibleConstructor.construct_object(
            value,
            vault_password=vault_password)
            for value in values]
        assert ansible_native_concat(nodes) == expected

    # Test empty node
    _test([], None)

    # Test single node
    _test([1], 1)
    _test([1.0], 1.0)
    _test([None], None)
    _test([True], True)
    _test([False], False)

# Generated at 2022-06-21 07:48:54.276936
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:49:02.472171
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert None == ansible_native_concat([])
    assert None == ansible_native_concat([None])
    assert 42 == ansible_native_concat([42])

    assert 'a' == ansible_native_concat(['a'])
    assert 42 == ansible_native_concat([42])
    assert 42 == ansible_native_concat(['42'])
    assert 42 == ansible_native_concat(['42 ', '', 42, ''])
    assert '42' == ansible_native_concat(['42', 'a'])

    assert ['a', 42] == ansible_native_concat(['[', 'a', 42, ']'])
    assert ('a', 42) == ansible_native_concat(['(', 'a', 42, ')'])

# Generated at 2022-06-21 07:49:12.527820
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import Template
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # a Template for testing, using ansible_native_concat
    template_str = '''\
{%- set result = [] -%}
{%- for item in [1, '2', 3, 4.0, [5, 6], 'abc', 'def', ['ghi', 'jkl'], {'mno': 'pqr'}] -%}
{%- if item is string or item is iterable -%}
{{- result.append(item) -}}
{%- elif item is number -%}
{{- result.append(str(item)) -}}
{%- endif -%}
{%- endfor -%}
{{- result -}}
'''

# Generated at 2022-06-21 07:49:19.142769
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(["foo", 'bar']) == "foobar"
    assert ansible_native_concat(["foo", 1]) == "foo1"
    assert ansible_native_concat([("foobar", )]) == 'foobar'
    assert ansible_native_concat([("foo", 1), ("bar", 2)]) == "foo1, bar2"
    assert ansible_native_concat([("foo", 1), ("bar", 2)]) == "foo1, bar2"
    assert ansible_native_concat([("foo", {1: 2})]) == "foo{1: 2}"
    assert ansible_native_concat([("foo", {'1': 2})]) == "foo{'1': 2}"

# Generated at 2022-06-21 07:49:31.264372
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'

    assert ansible_native_concat([u'a']) == 'a'
    assert ansible_native_concat([u'a', u'b']) == 'ab'
    assert ansible_native_concat([u'a', u'b', u'c']) == 'abc'

    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat(['a', 1, u'b', 2, 'c', 3]) == 'a123'


# Generated at 2022-06-21 07:50:13.291186
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = [AnsibleVaultEncryptedUnicode(b'foo'), 'a', b'b']
    assert ansible_native_concat(nodes) == b'fooab'

    nodes = [None, None, None]
    assert ansible_native_concat(nodes) is None

    nodes = []
    assert ansible_native_concat(nodes) is None

    nodes = [None, None]
    assert ansible_native_concat(nodes) is None

    nodes = [2, 3]
    assert ansible_native_concat(nodes) == 5

    nodes = [u'foo', u'bar']
    assert ansible_native_concat(nodes) == u'foobar'

    nodes = ['foo', None, 'bar']
    assert ansible_native_concat

# Generated at 2022-06-21 07:50:20.091751
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.native.types import NativeInt, NativeString
    assert ansible_native_concat(NativeInt(123)) == 123
    assert ansible_native_concat([NativeInt(1), NativeInt(2)]) == "12"
    assert ansible_native_concat([NativeString("1"), NativeString("2")]) == [1, 2]

    # Handle string variables
    from ansible.module_utils.native.types import NativeJinjaString
    assert ansible_native_concat(NativeJinjaString("123")) == "123"
    assert ansible_native_concat(NativeJinjaString("1")) == "1"
    assert ansible_native_concat([NativeJinjaString("1"), NativeJinjaString("2")]) == "12"

    # Handle undefined variables

# Generated at 2022-06-21 07:50:31.666759
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat([u'bar']) == u'bar'
    assert ansible_native_concat([ansible_native_concat([u'foo']), ansible_native_concat([u'bar'])]) == u'foobar'
    assert ansible_native_concat([u'1', u'2']) == u'12'
    assert ansible_native_concat([u'1', 2]) == u'12'
    assert ansible_native_concat([u'{', u'"', u'foo', u'"', u':', u'bar', u'}']) == u'{"foo":bar}'
    assert ansible_native