

# Generated at 2022-06-21 07:40:35.994490
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2]) == 1
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([1, '2', 3]) == '123'
    assert ansible_native_concat(['1', 2, 3]) == '123'
    assert ansible_native_concat([1, u'2', 3]) == '123'
    assert ansible_native_concat([1, 2, 'three']) == '123three'
    assert ansible_native_concat([1, 2, 'three']) == '123three'
    assert ansible_native_concat([1, [2, ['3']], 'three']) == [1, [2, ['3']], 'three']
    assert ansible_native_con

# Generated at 2022-06-21 07:40:39.412155
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['1', '2']) == "12"
    assert ansible_native_concat(['1', '2', '3']) == "123"



# Generated at 2022-06-21 07:40:51.590782
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test with empty

    assert ansible_native_concat([]) == None

    # Test with a single list item

    assert ansible_native_concat(['str']) == 'str'

    # Test with a single int item

    assert ansible_native_concat([42]) == 42

    # Test with a single tuple item

    assert ansible_native_concat([(1, 2, 3)]) == (1, 2, 3)

    # Test with a multiple list items

    assert ansible_native_concat(['foo', 'bar']) == 'foobar'

    # Test with a multiple integer items

    assert ansible_native_concat([42, 43]) == '4243'

    # Test with a multiple integer and string items


# Generated at 2022-06-21 07:41:00.756356
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test function ``ansible_native_concat``."""
    assert ansible_native_concat(iter(['a'])) == 'a'
    assert ansible_native_concat(iter(['1'])) == 1
    assert ansible_native_concat(iter(['a', 'b'])) == 'ab'
    assert ansible_native_concat(iter(['1', '2'])) == '12'
    # Test whitespace handling
    assert ansible_native_concat(iter(['a   ', ' b'])) == 'a   b'

# Generated at 2022-06-21 07:41:07.662099
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    literal_eval_dict = {
        'str': 'ansible',
        'bool': True,
        'int': 1,
        'float': 1.0,
        'list': [1, 2, 3],
        'dict': {'ansible': 'awesome'},
        'none': None,
    }

    for literal_eval_type, literal_eval_value in literal_eval_dict.items():
        assert ansible_native_concat([literal_eval_value]) == literal_eval_value
        assert ansible_native_concat([literal_eval_value, literal_eval_value]) == text_type(literal_eval_value) * 2

# Generated at 2022-06-21 07:41:15.659326
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    '''
    >>> ansible_native_concat([])
    '''
    data = []
    assert ansible_native_concat(data) is None

    '''
    >>> ansible_native_concat([1])
    1
    '''
    data = [1]
    assert ansible_native_concat(data) == 1

    '''
    >>> ansible_native_concat([1, 2, 3])
    '123'
    '''
    data = [1, 2, 3]
    assert ansible_native_concat(data) == "123"

    '''
    >>> ansible_native_concat(['a', 'b'])
    'ab'
    '''
    data = ["a", "b"]

# Generated at 2022-06-21 07:41:25.237456
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([u'a']) == u'a'
    assert ansible_native_concat([7]) == 7
    assert ansible_native_concat([['a', 'b']]) == ['a', 'b']
    assert ansible_native_concat([{'a': 'b'}]) == {'a': 'b'}
    assert ansible_native_concat([b'foo']) == b'foo'
    assert ansible_native_concat([3]) == 3
    assert ansible_native_concat([-512]) == -512
    assert ans

# Generated at 2022-06-21 07:41:34.227881
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2.runtime import Undefined
    from ansible.module_utils.common.text.converters import to_text

    assert ansible_native_concat([to_text('foo'), to_text('bar')]) == 'foobar'
    assert ansible_native_concat([to_text('1'), to_text('2')]) == 12
    assert ansible_native_concat([to_text('1.1'), to_text('2.2')]) == 1.1
    assert ansible_native_concat([to_text('True'), to_text('or False')]) is True
    assert ansible_native_concat([to_text('[1,2,3]'), to_text('[4]')]) == [1, 2, 3, 4]

# Generated at 2022-06-21 07:41:44.136038
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([None, None]) is None
    assert ansible_native_concat([None, 'foo']) == 'foo'
    assert ansible_native_concat(['foo', None]) == 'foo'
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat(['foo']) == 'foo'
    assert isinstance(ansible_native_concat(['foo']), string_types)
    assert ansible_native_concat(['foo', 'bar', 'baz']) == 'foobarbaz'
    assert ansible_native_concat(['foo', 'bar', 'baz', None, None, 'qux']) == 'foobarbazqux'

# Generated at 2022-06-21 07:41:55.220825
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Assert that a literal string is interpreted as such
    assert ansible_native_concat(["1"]) == "1"
    assert ansible_native_concat(["1", "2"]) == "12"
    assert ansible_native_concat(["1", "2", "3"]) == "123"
    assert ansible_native_concat(["1", "2", 1, 2]) == "121"

    # Assert that a literal number is interpreted as such, even if it
    # is represented as a string in the jinja
    assert ansible_native_concat(["1"]) == 1
    assert ansible_native_concat(["1", "2"]) == 12
    assert ansible_native_concat(["1", "2", "3"]) == 123
    assert ansible_

# Generated at 2022-06-21 07:42:06.785386
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Base test cases, taken from the nativetypes_test.py in Jinja2
    # https://github.com/pallets/jinja/blob/master/tests/nativetypes_test.py
    test_data = [
        ([u'foo'], u'foo'),
        ([u'foo', u'bar'], u'foobar'),
        ([u'foo', u' '], u'foo '),
        ([u'foo', u' '], u'foo '),
        ([u'foo', u' '], u'foo '),
        ([u'foo', u' '], u'foo ')
    ]

    for data, expected in test_data:
        actual = ansible_native_concat(data)

# Generated at 2022-06-21 07:42:19.596897
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    native_concat = ansible_native_concat
    assert native_concat([]) is None
    assert native_concat(container_to_text([1, 2, 3])) == [1, 2, 3]
    assert native_concat(container_to_text(['a', 'b', 'c'])) == 'abc'
    assert native_concat(container_to_text([1, 2, 3.0, 4.0, 5.0])) == [1, 2, 3.0, 4.0, 5.0]
    assert native_concat(container_to_text(['a', 'b'])) == 'ab'
    assert native_concat(container_to_text(['a', 'b', 'c'])) == 'abc'

# Generated at 2022-06-21 07:42:26.299407
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:42:36.775132
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """
    Assert that ansible_native_concat returns the correct values for the following
    expression:
    {{
        [
            'foo',
            '{{ empty }}',
            '{{ 7 }}',
            '{{ foo1 }}',
            '{{ foo2 }}',
            '{{ foo3 }}'
        ]
    }}
    """
    from jinja2 import Environment, meta

    empty = 'bar'
    foo1 = 'bar'
    foo2 = 'foo {{ bar }}'
    foo3 = 'bar {{ foo }}'
    env = Environment(undefined=StrictUndefined)

# Generated at 2022-06-21 07:42:46.706930
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    # Test with a single node
    assert ansible_native_concat([123]) == 123
    assert ansible_native_concat([123.456]) == 123.456
    assert ansible_native_concat([u'Hello']) == u'Hello'
    assert ansible_native_concat([u'\u041f\u0440\u0438\u0432\u0435\u0442']) == u'\u041f\u0440\u0438\u0432\u0435\u0442'
    assert ansible_native_concat([True]) == True
    assert ansible_native_concat([False]) == False
    assert ans

# Generated at 2022-06-21 07:42:57.348429
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import Environment
    env = Environment(extensions=['jinja2.ext.do'])
    env.filters = {'to_yaml': container_to_text}
    env.finalize = ansible_native_concat

    def finalize(body):
        return env.finalize(env.parse(body))

    assert finalize('{% set a = [1, 2, 3] %}{% for i in a %}{{i}}{% endfor %}') == 123
    assert finalize('{% set a = [1, 2, 3] %}{% for i in a %}{{i}}{% endfor %}') == 123
    assert finalize('{{1 + 1}}') == 2
    assert finalize('{{text()}}') == 'text'

# Generated at 2022-06-21 07:43:04.791804
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2.runtime import Undefined
    from .test_common import (
        assert_equal,
        assert_not_equal,
        assert_true,
        assert_false,
        assert_is_instance,
        assert_is_none,
    )

    assert_equal(
        ansible_native_concat((Undefined('foo'), Undefined('bar'))),
        '{{ foo }}{{ bar }}',
    )

    assert_equal(
        ansible_native_concat((Undefined('foo'), 'bar')),
        '{{ foo }}bar',
    )

    assert_equal(
        ansible_native_concat(('foo', Undefined('bar'))),
        'foo{{ bar }}',
    )


# Generated at 2022-06-21 07:43:17.458420
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test basic functionality
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat(["foo", "bar"]) == 'foobar'
    assert ansible_native_concat(["1", "2", "3"]) == 123
    assert ansible_native_concat(["foo", "bar", "baz"]) == "foobarbaz"

    # Use NativeJinjaText to mark a value as a string
    # See: https://github.com/ansible/ansible/issues/70831
    assert ansible_native_concat([
        "foo",
        NativeJinjaText(u"{{foo}}"),
        "bar"]
    ) == u"foo{{foo}}bar"

    # 'a' is an instance of AnsibleVaultEncrypted

# Generated at 2022-06-21 07:43:27.128005
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_bool

    # when result is single value
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['hello']) == 'hello'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['yes']) == 'yes'
    assert ansible_native_concat(['']) == ''
    assert ansible_native_concat(['False']) == 'False'
    assert ansible_native_concat(['true']) == 'true'
    assert ansible_native_concat(['TRUE']) == 'TRUE'
    assert ansible_native_concat([False]) == False

# Generated at 2022-06-21 07:43:36.791153
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, '2', 3]) == 123
    assert ansible_native_concat(['123{0}'.format(i) for i in range(1, 4)]) == 123123123

    assert ansible_native_concat(['1', '"2"']) == '12'
    assert ansible_native_concat(['""', '"2"']) == '"2"'
    assert ansible_native_concat([container_to_text('"abc"'), '"123"']) == '"abc123"'

# Generated at 2022-06-21 07:43:53.633184
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test that leading spaces/tabs are not removed
    assert ansible_native_concat(['  foo', '  bar']) == '  foobar'
    assert ansible_native_concat(['\tfoo', '\tbar']) == '\tfoobar'
    assert ansible_native_concat(['\tfoo ', '\tbar']) == '\tfoo bar'
    # Test that trailing newline is not removed
    assert ansible_native_concat(['foo\n']) == 'foo\n'
    # Test that we can parse literal strings
    assert ansible_native_concat(['"foo"', '"bar"']) == 'foobar'
    # Test that we can parse literal numbers
    assert ansible_native_concat(['42']) == 42
    # Test that we

# Generated at 2022-06-21 07:44:04.537283
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class FakeUndefined:
        def __iter__(self):
            yield 'FAIL'

    class FakeJinjaText:
        def __add__(self, other):
            return other

        def __radd__(self, other):
            return other

        def __str__(self):
            return 'FAKE'

    assert ansible_native_concat([]) == None
    assert ansible_native_concat([1, ]) == 1
    assert ansible_native_concat([container_to_text(FakeUndefined()), ]) == 'FAIL'
    assert ansible_native_concat([container_to_text(FakeJinjaText()), ]) == 'FAKE'
    assert ansible_native_concat(FakeUndefined()) == 'FAIL'

# Generated at 2022-06-21 07:44:15.927867
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # literal_eval directly on a string does not work if the string contains
    # leading spaces/tabs.
    # See:
    # https://github.com/ansible/ansible/issues/70831
    # https://github.com/python/cpython/commit/d2fa01644001eebbb7a72b30f42ab8cd65c1aef1
    try:
        ast.literal_eval('  foo')
    except (ValueError, SyntaxError, MemoryError):
        python_supports_literal_eval = False
    else:
        python_supports_literal_eval = True

    # On Python versions where literal_eval does not support leading spaces/tabs
    # the function will return a string.
    expected = "  foo"

# Generated at 2022-06-21 07:44:26.541808
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'a']) == u'a'
    assert ansible_native_concat([u'a', u'b']) == u'ab'
    assert ansible_native_concat([u'a', u'b', u'c']) == u'abc'

    # short-circuit literal_eval for anything other than strings
    assert ansible_native_concat([u'a', 3, u'c']) == u'a3c'
    assert ansible_native_concat([u'a', None, u'c']) == u'anonec'

    assert ansible_native_concat([u'1', u'2']) == 2
    assert ansible_native_concat([u'1', u'2', u'3']) == 123
    assert ans

# Generated at 2022-06-21 07:44:38.535266
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([1, 2]) == "12"
    assert ansible_native_concat([1, '2']) == '12'
    assert ansible_native_concat([1, '2', 3]) == '123'
    assert ansible_native_concat([1, '2', []]) == '[1, 2]'
    assert ansible_native_concat(['1', '2', []]) == '[1, 2]'
    assert ansible_native_concat([1, '2', {'a': 'b'}]) == "{'a': 'b'}"
    assert ansible

# Generated at 2022-06-21 07:44:44.342814
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test for a single string, should parse with ast and return the value
    assert ansible_native_concat([u'True']) is True

    # Test for a single number, should parse with ast and return the value
    assert ansible_native_concat([u'42']) == 42

    # Test for a single number, should parse with ast and return the value
    assert ansible_native_concat([u'42']) == 42

    # Test for a single number, should parse with ast and return the value
    assert ansible_native_concat([u'42']) == 42

    # Test for a single number with leading white space, should parse with ast and return the value
    assert ansible_native_concat([u'   42']) == 42

    # Test for a single number with leading tab, should parse with ast and return the value

# Generated at 2022-06-21 07:44:55.398693
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(["a"]) == "a"
    assert ansible_native_concat(["a", "b"]) == "ab"
    assert ansible_native_concat(["a", "b", "c"]) == "abc"
    assert ansible_native_concat(["a", "b" * 100000]) == "ab" * 100000
    assert ansible_native_concat(["a0"]) == "a0"
    assert ansible_native_concat(["a", 0]) == "a0"
    assert ansible_native_concat(["a", 0.0]) == "a0.0"

# Generated at 2022-06-21 07:45:02.105106
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.common.text.converters import container_to_text

    def _proc(data):
        return container_to_text(ansible_native_concat(chain(data, [])))

    loader = DataLoader()
    loader.set_vault_secrets(dict(identities=[('vault_cred', 'password')]))

    # https://github.com/ansible/ansible/issues/70831
    assert _proc(loader.get_single_data("{{ 'foo'|to_json }}")['data']) == u"foo"

# Generated at 2022-06-21 07:45:11.308507
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import struct

    assert ansible_native_concat([]) == None
    assert ansible_native_concat(['abc']) == 'abc'
    assert ansible_native_concat(['123']) == 123

    # Test that concatenation is possible.
    assert ansible_native_concat(['123', '45']) == 12345
    assert ansible_native_concat(['123', '45']) == 12345
    assert ansible_native_concat(['12', '34', '5']) == 12345

    assert ansible_native_concat(['foo', 'bar']) == 'foobar'


# Generated at 2022-06-21 07:45:21.755233
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2
    from jinja2.utils import Markup
    from jinja2.nodes import Name
    from ansible.module_utils.common.text.converters import container_to_text
    from ansible.module_utils.common.collections import is_sequence

    def render(value):
        native_concat = ansible_native_concat([value])
        assert not isinstance(native_concat, Markup)
        return native_concat

    env = jinja2.Environment(
        extensions=[],
        keep_trailing_newline=False,
        undefined=jinja2.StrictUndefined
    )

    # Name
    assert render(Name('foo')) == 'foo'

    # String

# Generated at 2022-06-21 07:45:47.714008
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import Environment
    from jinja2.nativetypes import NativeEnvironment
    from jinja2.nativetypes import NativeEnvironmentConfig

    # The order of these imports is important. You need to make sure the
    # NativeEnvironment uses our own native concat function.
    from ansible.module_utils.common.text.converters import to_native

    env = Environment(undefined=StrictUndefined)
    compress_whitespace = NativeEnvironmentConfig.COMPRESS_WHITESPACE_NONE
    env = NativeEnvironment(env, undefined=StrictUndefined,
                            compress_whitespace=compress_whitespace,
                            ansible_native_concat=ansible_native_concat)

    assert to_native(env.from_string('{{ [1, 2, 3] }}').render())

# Generated at 2022-06-21 07:46:00.195971
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == u'12'

    assert isinstance(ansible_native_concat([1, 2]), text_type)
    assert isinstance(ansible_native_concat([u'a', u'b']), text_type)
    assert isinstance(ansible_native_concat(['a', 'b']), text_type)
    assert isinstance(ansible_native_concat([1, u'b']), text_type)
    assert isinstance(ansible_native_concat([u'a', 1]), text_type)
    assert isinstance(ansible_native_concat([1, [2, 3]]), text_type)
   

# Generated at 2022-06-21 07:46:12.879053
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import Environment

    # Literal Evaluation
    env = Environment(extensions=['jinja2.ext.do'])
    # Python 3 only
    # env.filters['native_concat'] = ansible_native_concat
    template = env.from_string(u"{{ [1, 2, 3] + [4, 5, 6] }}")
    assert template.render() == u'[1, 2, 3, 4, 5, 6]'
    template = env.from_string(u"{{ {'foo': 'bar'} + {'biz': 'baz'} }}")
    assert template.render() == u"{'foo': 'bar', 'biz': 'baz'}"
    # string representation of _BoolOp in Python 3

# Generated at 2022-06-21 07:46:21.596624
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    if not hasattr(ast, 'literal_eval'):
        assert ansible_native_concat('foo') == 'foo', 'Concatenation failure'
        assert ansible_native_concat(['foo', 'bar']) == 'foobar', 'Concatenation failure'
        assert ansible_native_concat(['foo', 'bar', 'baz']) == 'foobarbaz', 'Concatenation failure'
        assert ansible_native_concat(u'foo') == u'foo', 'Concatenation failure'

        assert ansible_native_concat(u'1') == u'1', 'Concatenation failure'
        assert ansible_native_concat(u'1.0') == u'1.0', 'Concatenation failure'
        assert ansible_native_con

# Generated at 2022-06-21 07:46:29.748580
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Generate some nodes
    nodes = [ast.Str(s=unicode(x)) for x in list(range(100))]

    # Test

# Generated at 2022-06-21 07:46:36.916463
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:46:47.641817
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def test_concat(args, expected):
        actual = ansible_native_concat(args)
        assert actual == expected

    test_concat([], None)
    test_concat([''], '')
    test_concat(['foo'], 'foo')
    test_concat([1], 1)
    test_concat(['1'], 1)
    test_concat(['true'], True)
    test_concat(['{}'], {})
    test_concat(['{"foo": "bar"}'], {'foo': 'bar'})
    test_concat(['[]'], [])
    test_concat(['["foo", "bar"]'], ['foo', 'bar'])

# Generated at 2022-06-21 07:46:57.252118
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 'bar', 'baz']) == 'foobarbaz'
    assert ansible_native_concat(['foo', 'bar', 1]) == 'foobar1'
    assert ansible_native_concat([1, 'bar', 'baz']) == '1barbaz'
    assert ansible_native_concat([1, 'bar', 1]) == '1bar1'
    assert ansible_native_concat(['1', '2', '3']) == '123'
    assert ansible_native_concat([1.2, 'bar', 1]) == '1.2bar1'

# Generated at 2022-06-21 07:47:09.426124
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([[]]) == []
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['1.0']) == 1.0
    assert ansible_native_concat(['True']) is True
    assert ansible_native_concat(['False']) is False
    assert ansible_native_concat(['None']) is None
    assert ansible_native_concat(['a', 'None']) == 'aNone'

# Generated at 2022-06-21 07:47:21.646573
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:47:54.896005
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['{{', 'foo', '}}']) == '{{foo}}'
    assert ansible_native_concat(['{{', 'foo', 'bar', '}}']) == '{{foobar}}'
    assert ansible_native_concat(['foo', '{{', 'bar', '}}']) == 'foo{{bar}}'
    assert ansible_native_concat(['foo', '{{', 'bar', '}}', 'baz']) == 'foo{{bar}}baz'

# Generated at 2022-06-21 07:48:07.553563
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.collections import is_sequence
    from ansible.utils.native_jinja import native_concat

    # Test for the value returned by 'native_concat' function
    assert native_concat([]) == None
    assert native_concat(["1"]) == "1"
    assert native_concat([1]) == 1
    assert native_concat([[]]) == []
    assert native_concat({}) == {}
    assert native_concat([[1]]) == [1]
    assert native_concat([[1], [2]]) == [1, 2]
    assert native_concat([[1], 2]) == [1, 2]

# Generated at 2022-06-21 07:48:15.080176
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['1', 2]) == '12'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat([1, 2]) == 1
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat(['"1"', '"2"']) == '12'
    assert ansible_native_concat(['"1"', '2']) == '12'
    assert ansible_native_concat([1, '2']) == 1
    assert ansible_native_concat(['1', 2]) == '12'
   

# Generated at 2022-06-21 07:48:24.682182
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([u'a', u'b', u'c']) == 'abc'
    assert ansible_native_concat([u'a', ansible_native_concat([u'1', u'2']), u'c']) == 'a12c'
    assert ansible_native_concat([u'a']) == 'a'
    assert ansible_native_concat([u'a', ansible_native_concat([u'a'])]) == 'aa'
    assert ansible_native_concat([1, 2, 3]) == '123'

# Generated at 2022-06-21 07:48:35.357211
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # test for substring
    assert ansible_native_concat(['hello', 'world']) == 'helloworld'

    # test for list
    assert ansible_native_concat(['[', 1, 2, 3, ']']) == [1, 2, 3]

    # test for dict
    assert ansible_native_concat(['{', '"key":', 1, '}']) == {'key': 1}

    # test for tuple
    assert ansible_native_concat(['(', 1, ')']) == (1,)

    # test for int
    assert ansible_native_concat([1]) == 1

    # test for float
    assert ansible_native_concat([1.5]) == 1.5

    # test for bytes

# Generated at 2022-06-21 07:48:46.413568
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    input = ["foo ", u"bar", " baz", "42", 42]
    output = ansible_native_concat(iter(input))
    assert output == 'foo bar baz4242'

    input = [u"'", "foo", u"'", u'"', "bar", u'"']
    output = ansible_native_concat(iter(input))
    assert output == "'foo'\"bar\""

    input = [u"{", "foo", u":", "42", u"}"]
    output = ansible_native_concat(iter(input))
    assert isinstance(output, dict)
    assert output['foo'] == 42

    input = [u"[", "foo", u", ", "bar", u", ", "42", u"]"]
    output = ansible_native_concat(iter(input))


# Generated at 2022-06-21 07:48:54.853435
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test single item
    assert ansible_native_concat(iter(['1'])) == '1'
    assert ansible_native_concat(iter([1])) == 1

    # Test simple concatenation
    assert ansible_native_concat(iter(['12', '34'])) == '1234'
    assert ansible_native_concat(iter([12, 34])) == 1234

    # Test nested concatenation
    assert ansible_native_concat(iter([[1, 2], [3, 4]])) == [1, 2, 3, 4]
    assert ansible_native_concat(iter([['1', '2'], ['3', '4']])) == ['1', '2', '3', '4']

    # Test literal evaluation

# Generated at 2022-06-21 07:49:06.532883
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class Node:
        def __init__(self, value):
            self.value = value

    result = ansible_native_concat([Node(1)])
    assert result == 1

    result = ansible_native_concat([Node(1), Node(2), Node(3)])
    assert result == u'123'

    result = ansible_native_concat([Node('1,2,3'), Node(4), Node(5)])
    assert result == [1, 2, 3, 4, 5]

    result = ansible_native_concat([Node('1,2,3'), Node('4,5')])
    assert result == [1, 2, 3, 4, 5]

    result = ansible_native_concat([Node('1,2,3')])

# Generated at 2022-06-21 07:49:15.180551
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:49:26.727696
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foobar']) == 'foobar'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat([42, 43]) == '4243'
    assert ansible_native_concat([[42]]) == [42]
    assert ansible_native_concat([[42], 'foo']) == "[42]foo"
    assert ansible_native_concat([[42], ['foo']]) == '[42][foo]'
    assert ansible_native_concat([u'{}']) == {}

# Generated at 2022-06-21 07:50:11.237253
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # pylint: disable=E1123
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    templar = Templar(loader=None, variables=HostVars())

    # types that are not strings
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat([1, 2, [3, 4], 5]) == [1, 2, [3, 4], 5]
    assert ansible_native_concat(['1', 2, [3, 4], ['5']]) == [u'1', 2, [3, 4], [u'5']]

# Generated at 2022-06-21 07:50:19.315981
# Unit test for function ansible_native_concat

# Generated at 2022-06-21 07:50:31.423399
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Strings
    test_cases = [
        (['1'], 1),
        (['2', '2'], '22'),
        (['foo', 'bar', 'baz'], 'foobarbaz'),
        (['foo', '', 'baz'], 'foobaz'),
        (['foo', u'b\xc3\xa1r', 'baz'], u'foob\xc3\xa1rbaz'),
        (['1', '2', '3'], '123'),
    ]

    for input_text, expected_output in test_cases:
        assert expected_output == ansible_native_concat(input_text)

    # Unicode