

# Generated at 2022-06-23 13:12:35.417141
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('') == None
    assert ansible_native_concat('foo') == 'foo'
    assert ansible_native_concat('1') == 1
    assert ansible_native_concat('f1') == 'f1'
    assert ansible_native_concat('f1o') == 'f1o'
    assert ansible_native_concat('f1o', 'o') == 'foo'
    assert ansible_native_concat('f1o', 'oo') == 'fooo'
    assert ansible_native_concat(1,2) == '12'
    assert ansible_native_concat(1,'2') == '12'
    assert ansible_native_concat(1,'2',3) == '123'
    assert ansible_native_con

# Generated at 2022-06-23 13:12:41.466956
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test boolean
    assert ansible_native_concat([True, " and ", True]) == True

    # Test numbers
    assert ansible_native_concat([1, " + ", 1]) == 2
    assert ansible_native_concat([10, " + ", 10]) == 20

    # Test strings
    assert ansible_native_concat(["ansible_connection=", "local"]) == "ansible_connection=local"

    # Test arrays
    assert ansible_native_concat([["ansible", "galaxy", "install"], " ", ["-r", "requirements.yml"]]) == ["ansible", "galaxy", "install", " ", "-r", "requirements.yml"]

    # Test dicts

# Generated at 2022-06-23 13:12:51.862717
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    assert ansible_native_concat(["foo"]) == 'foo'

    assert ansible_native_concat(["foo", "bar"]) == 'foobar'  # Concatenate strings

    assert ansible_native_concat(["foo", 42]) == 'foo42'  # Not converted to number

    assert ansible_native_concat(["foo", u"bar"]) == 'foobar'  # Unicode to str

    assert ansible_native_concat(["", ""]) == ''  # Empty string

    assert ansible_native_concat([0]) == 0  # No conversion

    assert ansible_native_concat([1, 2, 3]) == 123  # Sum


# Generated at 2022-06-23 13:13:00.839709
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) is None
    assert ansible_native_concat(['a', 'b', 'c']) is None
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat([1, 2, 3, '4']) == [1, 2, 3, '4']
    assert ansible_native_concat([{'a': 1}, {'b': 2}, {'c': 3}]) == {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-23 13:13:08.002920
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Test join of simple strings
    test_data = [u'work', [u' on ', u'Jinja', u' ', u'Parsing']]
    assert u"work on Jinja Parsing" == ansible_native_concat(test_data)

    # Test join of recursive data

# Generated at 2022-06-23 13:13:19.385453
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Single item no need to call literal_eval
    text = to_text('one')
    assert text == ansible_native_concat([text])
    assert text == ansible_native_concat((text for text in (text,)))

    # Single item calling literal_eval
    text = to_text('True')
    assert True == ansible_native_concat([text])
    assert True == ansible_native_concat((text for text in (text,)))

    # Single item calling literal_eval raises error
    text = to_text('abc-def')
    assert text == ansible_native_concat([text])
    assert text == ansible_native_concat((text for text in (text,)))

    # Two or more items calling literal_eval
    text = to_text('True')
    other = to_text

# Generated at 2022-06-23 13:13:29.001395
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleUnsafeText
    import pytest
    def text_type_mock(val):
        return val

    # Disable the PyYAML https warning temporarily
    import warnings
    from collections import namedtuple
    from io import StringIO
    from ansible.parsing.yaml.loader import AnsibleLoader, LoaderOrigin
    origin = LoaderOrigin("", 1, 1)
    warnings.showwarning = warnings.showwarning_orig
    warnings.warn = warnings.warn_orig
    # Disabled for now as Red Hat QE does not run unit tests
    #def showwarning(*args, **kwargs):
    #    pass
    #warnings.showwarning = showwarning
    #warnings.warn = showwarning


# Generated at 2022-06-23 13:13:38.698563
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # When test_generator_expression_vars is enabled,
    # we need to ensure literal_eval is used properly.
    # See:
    # https://github.com/pallets/jinja/issues/1200
    # https://github.com/ansible/ansible/issues/70831
    # https://github.com/ansible/ansible/pull/73773#discussion_r448927552

    # Use the function directly to make sure it's loaded.
    assert isinstance(ansible_native_concat, types.FunctionType)

    # When we truncate a string to less than 4 characters and join it with
    # another string, literal_eval cannot parse it. So we expect the
    # concatenated string to be returned.

# Generated at 2022-06-23 13:13:49.542475
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    a = 1
    b = 2
    c = 3

    assert ansible_native_concat(iter((1, 2))) == 1
    assert ansible_native_concat(iter((1, 2, 3))) == '1, 2, 3'
    assert ansible_native_concat(iter(('a, b, c'))) == 'a, b, c'
    assert ansible_native_concat(iter((1, 'a', 'b c'))) == '1, a, b c'
    assert ansible_native_concat(iter(('[1, 2, 3]'))) == '[1, 2, 3]'
    assert ansible_native_concat(iter(('{1, 2, 3}'))) == {1, 2, 3}

# Generated at 2022-06-23 13:14:01.125597
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    four = [4]
    assert ansible_native_concat(four) == 4
    ten = [1, 2, 3, 4]
    assert ansible_native_concat(ten) == 10
    foo = [u'f', u'o', u'o']
    assert ansible_native_concat(foo) == u'foo'
    bar = [u'f', u'o', u'o', 4]
    assert isinstance(ansible_native_concat(bar), text_type)
    assert ansible_native_concat(bar) == u'foo4'
    # Implemented in Python 2.7, 3.1, 3.4

# Generated at 2022-06-23 13:14:11.669939
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2

    env = jinja2.Environment()


# Generated at 2022-06-23 13:14:19.136571
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a', 1, 'b', 2]) == 'a1b2'
    assert ansible_native_concat(['a', 1, 'b', 2, 3]) == 'a1b23'
    assert ansible_native_concat(['a', 1, 'b', 2, 3, 4]) == 'a1b234'

# Generated at 2022-06-23 13:14:27.957907
# Unit test for function ansible_native_concat

# Generated at 2022-06-23 13:14:37.533771
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    class MyInt(int):
        pass

    class MyStr(NativeJinjaText):
        pass

    class MyUnicode(text_type):
        pass

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == u'12'
    assert ansible_native_concat([1, 2, 3]) == u'123'
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([MyInt(1)]) == 1
    assert ansible_native_concat([MyInt(1), MyInt(2)]) == u'12'
    assert ansible_native_concat([MyInt(1), MyInt(2), MyInt(3)]) == u'123'
    assert ansible_native_concat

# Generated at 2022-06-23 13:14:47.296330
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([u'foo', u' ', u'bar']) == u'foo bar'
    assert ansible_native_concat([u'foo', u'\n', u'bar']) == u'foo\nbar'
    assert ansible_native_concat([u'foo', u' ', u'', u'bar']) == u'foo bar'
    assert ansible_native_concat([u'foo', 42]) == u'foo42'
    assert ansible_native_concat([u'', None]) == u''
    assert ansible_native_concat([u'', True]) == u''
    assert ansible_native_concat([u'', False]) == u''

# Generated at 2022-06-23 13:14:54.305938
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import doctest
    # Note: This tests the function ansible_native_concat as a standalone
    # module.  The function is included in the Jinja2 environment in the
    # ansible.module_utils.common.text.converters module.
    modules = []
    modules.append(('ansible.module_utils.common.text.converters',
                    ['_ansible_native_concat']))
    results = doctest.testmod(module_relative=False,
                              modules=dict(modules),
                              optionflags=doctest.ELLIPSIS)
    assert results.failed == 0



# Generated at 2022-06-23 13:15:02.543991
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def assert_equal(a, b):
        assert a == b
        assert type(a) == type(b)

    def assert_fail_on_undefined(data):
        try:
            _fail_on_undefined(data)
        except Exception:
            return
        raise AssertionError('Exception expected.')

    assert_equal(ansible_native_concat([]), None)
    assert_equal(ansible_native_concat([42]), 42)
    assert_equal(ansible_native_concat(['42']), 42)
    assert_equal(ansible_native_concat(['42\n43']), '42\n43')
    assert_equal(ansible_native_concat(['42', '43']), '4243')

# Generated at 2022-06-23 13:15:06.909038
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class Foo:
        def __str__(self):
            return 'foo'

    from ansible.module_utils._text import to_bytes
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([b'foo']) == 'foo'
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat([to_bytes('1')]) == 1
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([to_bytes('foo'), 'bar']) == 'foobar'
    assert ansible_native_concat([to_bytes('foo'), to_bytes('bar')]) == 'foobar'

# Generated at 2022-06-23 13:15:17.834222
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test the behavior of ansible_native_concat
    """
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(["hello"]) == "hello"
    assert ansible_native_concat(["hello", " ", "world"]) == "hello world"
    assert ansible_native_concat(["1", "2", "3"]) == 123
    assert ansible_native_concat(["1", "2", "3", " "]) == "123 "
    assert ansible_native_concat(["1", "2", "3", " ", False]) == "123 False"
    assert isinstance(ansible_native_concat(["1", "2", "3", " ", False]), six.text_type)

# Generated at 2022-06-23 13:15:27.488966
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch

    test_namespace = {
        'string_encoded': 'Zm9vYmFy',
    }

    def _evaluate(template_string, eager_undefined=True):
        return jinja2.Environment(undefined=jinja2.StrictUndefined if eager_undefined else jinja2.Undefined)(
            template_string
        ).from_string(template_string).root_render_func(
            jinja2.runtime.Context(test_namespace)
        )

    # Test that a template that returns a single value
    # (not wrapped in a {}, [], or () list) is returned as-is:


# Generated at 2022-06-23 13:15:36.351220
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # value is a single node
    assert ansible_native_concat(['a']) == 'a'
    # value is multiple nodes
    assert ansible_native_concat(['a', 'b']) == 'ab'
    # value is a string
    assert ansible_native_concat(['a']) == 'a'
    # value is a boolean
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([False]) is False
    # value is a list
    assert ansible_native_concat([['a', 'b']]) == ['a', 'b']
    # value is a dict
    assert ansible_native_concat([{'a': 'b'}]) == {'a': 'b'}
    # value is a number
    assert ansible

# Generated at 2022-06-23 13:15:45.777396
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([u'1']) == 1
    assert ansible_native_concat([[1, [2]]]) == [1, [2]]
    assert isinstance(ansible_native_concat([{'a': 1}]), Mapping)
    assert isinstance(ansible_native_concat([1, 2]), text_type)
    assert ansible_native_concat([u'1', u'2']) == 12
    assert ansible_native_concat([u'[1,', u'2]']) == [1, 2]
    assert ansible_native_concat([u'{', u"u'a': 1}"]) == {u'a': 1}

# Generated at 2022-06-23 13:15:57.183686
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(["a"]) == "a"
    assert ansible_native_concat(["a", 1]) == "a1"
    assert ansible_native_concat(["a", 1, "b", 2]) == "a1b2"
    assert ansible_native_concat([['a', 1], ['b', 2]]) == "['a', 1]['b', 2]"
    assert ansible_native_concat([['a', 1], ['b', 2], ['c', 3], ['d', 4]]) == "['a', 1]['b', 2]['c', 3]['d', 4]"

# Generated at 2022-06-23 13:16:05.680335
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.template.safe_eval import safe_eval
    from yaml.constructor import ConstructorError
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO

    def _test_ansible_native_concat(input_data, expected_data):
        loader = AnsibleLoader(StringIO(input_data), None, None, None, None)
        data = loader.get_single_data()
        result = safe_eval(input_data, locals={'ansible_native_concat': ansible_native_concat})
        assert result == data == expected_data
        output_data = AnsibleDumper(indent=4).represent_data(data)

# Generated at 2022-06-23 13:16:11.318342
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    assert ansible_native_concat(['abc', 'def']) == [u'abc', u'def']

    assert ansible_native_concat(['abc', 'def', 'ghi']) == u'abcdefghi'

    assert ansible_native_concat([u'abc', u'def', u'ghi']) == u'abcdefghi'

    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]

    assert ansible_native_concat([1, '2', 3]) == [1, u'2', 3]

    assert ansible_native_concat([1, '2', '3']) == [1, u'2', u'3']

    assert ansible_native_concat

# Generated at 2022-06-23 13:16:18.538229
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Using the default literal_eval parser as a baseline
    assert ansible_native_concat([u'[1, 2, 3]']) == [1, 2, 3]
    assert ansible_native_concat([u'(1, 2, 3)']) == (1, 2, 3)
    assert ansible_native_concat([u'"foo"']) == "foo"
    assert ansible_native_concat([u"'foo'"]) == "foo"

    # No spaces / tabs
    assert ansible_native_concat([u'[1, 2, 3]', u'[4, 5, 6]']) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-23 13:16:26.555241
# Unit test for function ansible_native_concat

# Generated at 2022-06-23 13:16:37.405655
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    # Sometimes (e.g. ``| string``) we need to mark variables
    # in a special way so that they remain strings and are not
    # passed into literal_eval.
    assert ansible_native_concat([NativeJinjaText('var1')]) == 'var1'
    assert ansible_native_concat(['var1']) == 'var1'
    assert ansible_native_concat([u'var2']) == u'var2'
    assert ansible_native_concat([u'42']) == 42
    assert ansible_native_concat([u'42.1']) == 42.1
    assert ansible_native_concat([u'42'], [u'.1']) == 42.1
    assert ansible_native

# Generated at 2022-06-23 13:16:44.137998
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import nodes

    assert ansible_native_concat([]) == None

    assert ansible_native_concat([nodes.Const(u"a")]) == u"a"

    assert ansible_native_concat([nodes.Const(u"a"), nodes.Const(u"b")]) == u"ab"

    assert ansible_native_concat([nodes.Const(u"{'a': "), nodes.Const(u"1")]) == u"{'a': 1"

    assert ansible_native_concat([nodes.Const(u"{'a': "), nodes.Const(u"1"), nodes.Const(u"}")]) == u"{'a': 1}"

    assert ansible_native_concat([nodes.Const(u"{'a': 1}")])

# Generated at 2022-06-23 13:16:52.719364
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'foo', u'bar']) == 'foobar'
    assert ansible_native_concat([u'']) == ''
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([u'1']) == 1
    assert ansible_native_concat([u'1', u'2']) == u'12'
    assert ansible_native_concat([u'a', u'b']) == u'ab'
    assert ansible_native_concat([u'1.0', u'2']) == u'1.02'
    assert ansible_native_concat([u'1.0', u' 2']) == u'1.0 2'

# Generated at 2022-06-23 13:17:02.315722
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    class TestNativeConcat:
        # unit test for list
        def test_list(self):
            assert [1, 2] == ansible_native_concat([1, 2])

        # unit test for dict
        def test_dict(self):
            assert {'k1': 'v1'} == ansible_native_concat({'k1': 'v1'})

        # unit test for integer
        def test_int(self):
            assert 1 == ansible_native_concat(1)

        # unit test for float
        def test_float(self):
            assert 0.5 == ansible_native_concat(0.5)

        # unit test for boolean
        def test_bool(self):
            assert True == ansible_native_concat(True)

        # unit test for None

# Generated at 2022-06-23 13:17:12.774728
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import Environment
    from jinja2.sandbox import SandboxedEnvironment
    import ast

    # TODO use a proper unit test framework

    def test_env(cls):
        env = cls(extensions=['jinja2.ext.do', 'jinja2.ext.loopcontrols'])
        env.globals.update({
            'string': lambda x: NativeJinjaText(x),
            'concat': ansible_native_concat,
        })
        return env

    def test_templates(env, templates):
        for tmpl, expected in templates:
            tmpl = '{{ %s }}' % tmpl
            assert eval(expected, {}, {}) == env.from_string(tmpl).render()


# Generated at 2022-06-23 13:17:18.042900
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    tests = (
        (['foo', 'bar', 'baz'], 'foobarbaz'),
        (['foo', ['bar', 'baz']], 'foo[\'bar\', \'baz\']'),
        (['foo', True, 'bar', None, 'baz'], 'foobartruebaz'),
        ([1, 2, 3, 'abc', True], '123abcTrue'),
        ([[1, 'abc', True], 2, 3], '[1, \'abc\', True]23'),
        ([2, 3, [1, 'abc', True]], '23[1, \'abc\', True]'),
    )

    for nodes, expected in tests:
        result = ansible_native_concat(nodes)
        assert result == expected, result



# Generated at 2022-06-23 13:17:24.158644
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    if not hasattr(ast, 'Constant'):
        # Python < 3.7
        assert ansible_native_concat([1]) == 1
        assert ansible_native_concat([[1], 2, 3]) == [1, 2, 3]
        assert ansible_native_concat(['True']) == 'True'
        assert ansible_native_concat(['1']) == '1'
        assert ansible_native_concat(['1.0']) == '1.0'
        assert ansible_native_concat([u'\xfc']) == u'\xfc'
        assert ansible_native_concat([u'foo']) == u'foo'

# Generated at 2022-06-23 13:17:34.800630
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_native

    assert ansible_native_concat('') is None
    assert ansible_native_concat('7') == 7
    assert ansible_native_concat('7', '3') == '73'
    assert ansible_native_concat(7) == 7
    assert ansible_native_concat('-7') == '-7'
    assert ansible_native_concat('00') == '00'
    assert ansible_native_concat(7, 3, 0.4) == '730.4'
    assert ansible_native_concat('7', u'3', ' ') == '73 '
    assert ansible_native_concat([7]) == [7]

# Generated at 2022-06-23 13:17:46.423186
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # pylint: disable=redefined-outer-name,unused-argument
    def _test_node(value):
        def _test_render(self, environment):
            return value

        return _test_render

    nodes = [
        _test_node("'foo'"),
        _test_node("'bar'"),
        _test_node("'baz'"),
        _test_node("1"),
        _test_node("2"),
        _test_node("3"),
        _test_node("0"),
        _test_node("False"),
        _test_node("True"),
        _test_node("'2'"),
    ]

    assert ansible_native_concat([]) is None
    assert ansible_native_concat([nodes[0]]) == 'foo'
    assert ansible

# Generated at 2022-06-23 13:17:57.432036
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['{a: b}']) == {'a': 'b'}
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(['a', 'b', ['c', 'd']]) == 'ab[c, d]'
    assert ansible_native_concat(['a', 'b', 'c', 'd', 'e']) == 'abcde'

# Generated at 2022-06-23 13:18:05.790991
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat([1, 'a', 'b']) == '1ab'
    assert ansible_native_concat(['a', 1, 'b']) == 'a1b'
    assert ansible_native_concat(['a', 1, 2, 'b']) == 'a12b'

    assert ansible_native_concat(['[', '1', ']']) == '[1]'
    assert ansible

# Generated at 2022-06-23 13:18:15.029053
# Unit test for function ansible_native_concat

# Generated at 2022-06-23 13:18:25.302712
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    obj1 = object()
    obj2 = object()
    obj3 = object()
    obj4 = object()

    # TODO: Enforce text_type in most cases, allow bytes in special cases
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([obj1]) == obj1
    assert ansible_native_concat([obj1, obj2, obj3]) is None
    assert ansible_native_concat([obj1, obj2]) is None
    assert ansible_native_concat([obj1, obj2, obj3, obj4]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat(['1']) == '1'
   

# Generated at 2022-06-23 13:18:35.310219
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test a small subset of the filter as this is just a wrapper
    of the native jinja concat function.
    """
    from jinja2 import Environment
    env = Environment()
    t = env.from_string('{{ 1 | native_concat(["", "", "", ""]) }}')
    assert t.render() == '1'
    t = env.from_string('{{ 1 | native_concat([2]) }}')
    assert t.render() == '12'
    t = env.from_string('{{ "1" | native_concat([2]) }}')
    assert t.render() == '12'
    t = env.from_string('{{ "foo" | native_concat(["bar"]) }}')
    assert t.render() == 'foobar'
    t = env.from_

# Generated at 2022-06-23 13:18:44.543558
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_bytes, to_unicode

    val = 1
    assert ansible_native_concat([val]) == val

    val = 1.0
    assert ansible_native_concat([val]) == val

    val = True
    assert ansible_native_concat([val]) == val

    val = {'y': 1}
    assert ansible_native_concat([val]) == val

    val = '1'
    assert ansible_native_concat([val]) == val

    val = to_bytes(b'1')
    assert ansible_native_concat([val]) == val

    val = to_unicode(u'1')
    assert ansible_native_concat([val]) == val

    val = [1]

# Generated at 2022-06-23 13:18:55.277709
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_native

# Generated at 2022-06-23 13:19:04.941165
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # https://github.com/ansible/ansible/issues/70831#issuecomment-664190894
    assert ansible_native_concat(('{{ foo|string }}',)) == '{{ foo|string }}'

    # https://github.com/pallets/jinja/issues/1211
    assert ansible_native_concat(('\U0010ffff'*200,)) == ('\U0010ffff'*200)

    # https://github.com/pallets/jinja/issues/1222
    assert ansible_native_concat((u' áą',)) == u' áą'

    # https://github.com/ansible/ansible/issues/64338#issuecomment-664205862
    assert ansible_native_concat(('', '', '')) == ''

   

# Generated at 2022-06-23 13:19:13.703795
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    a = ansible_native_concat([1, 2, 3])
    assert a == 1

    b = ansible_native_concat(["a", "b", "c"])
    assert b == "a"

    c = ansible_native_concat([1, "b", 3])
    assert c == "1b3"

    d = ansible_native_concat([1, 2.0, 3])
    assert d == 1

    e = ansible_native_concat([1, 2, 3.0])
    assert isinstance(e, type(u''))

    f = ansible_native_concat([1, 2, '3.0'])
    assert f == 3.0

    g = ansible_native_concat([1, "a", "b", "c"])
    assert g

# Generated at 2022-06-23 13:19:21.602004
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class _AnsibleVaultEncryptedUnicode(AnsibleVaultEncryptedUnicode):
        def __str__(self):
            return super(_AnsibleVaultEncryptedUnicode, self).data

    # Test with empty node list
    result = ansible_native_concat([])
    assert result is None

    # Test with None as value of single node
    result = ansible_native_concat([None])
    assert result is None

    # Test with null string as value of single node
    result = ansible_native_concat([''])
    assert result == ''

    # Test with AnsibleVaultEncryptedUnicode
    result = ansible_native_concat([_AnsibleVaultEncryptedUnicode('foo', 'bar')])
    assert result == 'foo'

    # Test

# Generated at 2022-06-23 13:19:31.513343
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # the following unicode characters are the same as their ASCII equivalents
    # (e.g. SMALL LETTER A with ACUTE == SMALL LETTER A)
    # this seems to confuse ast.literal_eval which will return strings instead
    # of integers for these values.  This is similar to how jinja2 handles
    # unicode strings.
    unicode_char_as_ascii = ['\xA1', '\xBF']
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([2, 3]) == u'23'
    assert ansible_native_concat([u'test']) == 'test'
    assert ansible_native_concat([u'test', '3']) == u'test3'

# Generated at 2022-06-23 13:19:42.896930
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([to_text(1)]) == 1
    assert ansible_native_concat([to_text('1')]) == 1
    assert ansible_native_concat([to_text(True)]) is True
    assert ansible_native_concat([to_text('abc')]) == 'abc'
    assert ansible_native_concat([to_text('abc'), to_text(123)]) == 'abc123'
    assert ansible_native_concat([to_text('abc'), to_text(123), to_text(True)]) == 'abc123True'
    assert ansible_native_concat([to_text('{"a": 123}')]) == {'a': 123}
    assert ansible_native_con

# Generated at 2022-06-23 13:19:54.849208
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(["test1"]) == "test1"
    assert ansible_native_concat(["test1", "test2"]) == "test1test2"
    assert ansible_native_concat(["test1", "test2", "test3"]) == "test1test2test3"
    assert ansible_native_concat(["1", "2", "3.0", 4, True]) == "123.04True"
    assert ansible_native_concat(["1", "2", "3.0", 4, True]) != "123.0 4True"
    assert ansible_native_concat(["1", "2", "3.0", 4, "foo", True]) != "123.0 4True"


# Generated at 2022-06-23 13:20:03.825928
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Exercise the ansible_native_concat() function"""
    assert ansible_native_concat([u"test"]) == u"test"
    assert ansible_native_concat([u"a", u"b"]) == u"ab"
    assert ansible_native_concat(["a", "b"]) == u"ab"
    assert ansible_native_concat([["a"], ["b"]]) == [u"a", u"b"]
    assert ansible_native_concat([u"a", 1, u"b"]) == u"a1b"
    assert ansible_native_concat([False, u"a"]) == u"Falsea"

# Generated at 2022-06-23 13:20:14.496371
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.template.safe_eval import Undefined

    Undefined = Undefined

    fn = ansible_native_concat

    assert fn([]) == None
    assert fn([1]) == 1
    assert fn([Undefined()]) == Undefined
    assert fn(iter([2])) == 2
    assert fn(iter([Undefined()])) == Undefined
    assert fn([1, 2, 3]) == u'123'
    assert fn([Undefined(), 2]) == Undefined
    assert fn(iter([Undefined(), 3])) == Undefined
    assert fn([4, 5, 6]) == [4, 5, 6]
    assert fn([Undefined(), [7, 8, 9]]) == Undefined
    assert fn(iter([Undefined(), [10, 11, 12]])) == Undefined

# Generated at 2022-06-23 13:20:26.471112
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert True == ansible_native_concat([True])
    assert 1 == ansible_native_concat([1])
    assert "test" == ansible_native_concat(["test"])
    assert ['a', 'b'] == ansible_native_concat(["['a', 'b']"])
    assert ['a', 'b'] == ansible_native_concat([["'a',", " 'b'"]])
    assert {"a": "b"} == ansible_native_concat(['{"a": "b"}'])
    assert {"a": "b"} == ansible_native_concat(['{"a":', " 'b'}"])
    assert {"a": "b"} == ansible_native_concat(['{"a":', ' "b"}'])
    assert "a b" == ans

# Generated at 2022-06-23 13:20:36.421434
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    data = {
        'a':'1',
        'b':'2',
        'c':'3',
        'd':''
    }
    assert ansible_native_concat([data]) == data
    assert ansible_native_concat(['{a:1,b:2,c:3}']) == data
    assert ansible_native_concat(['\n{a:1,b:2,c:3}']) == data
    assert ansible_native_concat(['\n{a:1,b:2,c:3}', '']) == data
    assert ansible_native_concat(['{a:1,b:2,c:3}', '']) == data


# Generated at 2022-06-23 13:20:46.749514
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([[]]) == []

    assert ansible_native_concat(['1', '2', '3']) == 123
    assert ansible_native_concat([1, '2', 3]) == 123

    assert ansible_native_concat([[1], 2, 3]) == [1, 2, 3]

    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(['a', 1, 'b', 2, 'c', 3]) == 'a1b2c3'



# Generated at 2022-06-23 13:20:55.704003
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == 1
    assert ansible_native_concat(['1']) == '1'
    assert ansible_native_concat(['1', '2']) == '12'

    assert ansible_native_concat(['foo', 'bar']) == 'foobar'

    assert ansible_native_concat(['1', '2']) == 1 + 2
    assert ansible_native_concat(['1.0', '2.0']) == 1.0 + 2.0
    assert ansible_native_concat([1, 2]) == 1 + 2

# Generated at 2022-06-23 13:21:06.113769
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert 'abc' == ansible_native_concat(['a', 'b', 'c'])
    assert '123' == ansible_native_concat(['1', '2', '3'])
    assert '123' == ansible_native_concat(['1', '2', '3'], literal_eval=True)

    assert 'ab23' == ansible_native_concat(['a', 'b', 2, 3])
    assert 'ab23' == ansible_native_concat(['a', 'b', 2, 3], literal_eval=True)

    assert 'ab23' == ansible_native_concat(['a', 'b', 2, '3'])

# Generated at 2022-06-23 13:21:16.520851
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.loader import AnsibleLoader

    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['0']) == '0'
    assert ansible_native_concat(['0', '1']) == '01'
    assert ansible_native_concat(['0', '1', '2']) == '012'
    assert ansible_native_concat(['012', '345', '678']) == '012345678'
    assert ansible_native_concat(['0', '1', '2', 3, 4, 5]) == '012345'
    assert ansible_native_concat(['0', '1', '2', [3, 4, 5]]) == '012[3, 4, 5]'
    assert ans

# Generated at 2022-06-23 13:21:21.823866
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert ansible_native_concat([]) is None
    assert ansible_native_concat([123]) == 123
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([456]) == 456
    assert ansible_native_concat(['b']) == 'b'
    assert ansible_native_concat(['a', 'b']) == 'ab'

    assert ansible_native_concat([{'a': 1, 'b': 2}]) == {'a': 1, 'b': 2}
    assert ansible_native_concat([[1, 2], [3, 4]]) == [1, 2, 3, 4]


# Generated at 2022-06-23 13:21:27.389561
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def test_equals(given, expected):
        assert ansible_native_concat(given) == expected

    test_equals([], None)
    test_equals([1], 1)
    test_equals(['a'], 'a')
    test_equals(['a', 2], 'a2')
    test_equals(['a', 2, 3], 'a23')
    test_equals([3, 'a'], '3a')
    test_equals([1, 2], '12')



# Generated at 2022-06-23 13:21:33.521509
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def assert_ansible_native_concat(node, expected):
        assert ansible_native_concat(node) == expected

    class Node:
        def __init__(self, value):
            self.value = value

        def __repr__(self):
            return 'Node({!r})'.format(self.value)

    assert_ansible_native_concat((), None)
    assert_ansible_native_concat([], None)
    assert_ansible_native_concat(iter(()), None)

    assert_ansible_native_concat([Node(1), Node(2), Node(3)], Node(3))
    assert_ansible_native_concat([Node(1)], Node(1))


# Generated at 2022-06-23 13:21:44.863900
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class t:
        pass
    strict_undefined = StrictUndefined()
    undefined = u'{{ foo }}'
    b = ast.literal_eval(b"b'bar'")
    s = u'buz'
    y = t()
    y.data = u'bar'
    y.vault_password = u'vault-password'
    y.unvaulted = u'bar'
    y.c = ast.literal_eval(b'b"bar"')
    y.d = [u'buz', u'bar', strict_undefined]

    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat

# Generated at 2022-06-23 13:21:56.475539
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Basic test that the function works as expected
    assert ansible_native_concat([
        container_to_text(b'foo'),
        container_to_text(b'bar'),
    ]) == 'foobar'

    # Test that the function properly parses a string into native types if
    # literal_eval can parse the given string.
    assert ansible_native_concat([
        container_to_text(b'1'),
        container_to_text(b'2'),
    ]) == 12

    # Test that the function returns the original string if literal_eval
    # cannot parse the given string.

# Generated at 2022-06-23 13:22:08.385938
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import Environment
    from jinja2.compiler import CodeGenerator

    env = Environment(extensions=[])

    def compile_template(template, **kwargs):
        code = env.compile(template, **kwargs)
        ast_obj = ast.parse(code)
        return code, ast_obj

    def eval_template(code):
        mod = types.ModuleType('_ansible_native_concat')
        exec(code, mod.__dict__)
        return mod.ansible_native_concat

    def concat_result(template):
        code, ast_obj = compile_template(template, optimize=False)
        concat = eval_template(code)
        return concat(CodeGenerator(ast_obj.body[0].body).get_code(environment=env))



# Generated at 2022-06-23 13:22:20.330904
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    '''
    Testing the following:
        1. Cases of input and expected output.
        2. Invalid input to trigger error cases.
    '''

# Generated at 2022-06-23 13:22:32.712422
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat((x for x in [1, 2, 3])) == 123

    assert ansible_native_concat(['a', 1, 'c']) == 'a1c'
    assert ansible_native_concat(('a', 1, 'c')) == 'a1c'

    assert ansible_native_concat(['a', ' ']) == 'a '
    assert ansible_native_concat(['a', u' ', 1]) == u'a 1'

    assert ansible_native_concat(['$PATH', '$HOME']) == u'$PATH$HOME'