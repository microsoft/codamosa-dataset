

# Generated at 2022-06-23 13:12:32.483476
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(['a', 1, 'b', 2, 'c', 3]) == 'a1b2c3'
    assert ansible_native_concat([1, 'b', 2, AnsibleVaultEncryptedUnicode('c')]) == '1bc'
    assert ansible_native_concat([1, True]) == '1True'
    assert ansible_native_concat(['a1', 2, 'b', 3, 'c']) == 'a12b3c'

# Generated at 2022-06-23 13:12:40.235043
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([ast.List([ast.Num(1)])]) == [1]
    assert ansible_native_concat([ast.List([ast.Num(1)], ctx=ast.Load())]) == [1]
    assert ansible_native_concat([ast.Num(1)]) == 1
    assert ansible_native_concat([ast.Dict([], [])]) == {}
    assert ansible_native_concat([ast.Tuple([], ast.Load())]) == ()
    assert ansible_native_concat([ast.Num(1), ast.Num(2), ast.Num(3)]) == 123

# Generated at 2022-06-23 13:12:50.860190
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Simple single literal
    assert "abc" == ansible_native_concat([u'abc'])
    # Concat two literals
    assert "" == ansible_native_concat([u'', u''])
    assert "ab" == ansible_native_concat([u'a', u'b'])
    # Simple list literal
    assert [1, 2] == ansible_native_concat([u'[1', u',2]'])
    # Simple dict literal
    assert {'a': 1, 'b': 2} == ansible_native_concat([u"{'a': 1", u", 'b': 2}"])
    # Return string literal for a complex data structure
    assert "[1, 2]" == ansible_native_concat([u'[1', u',2]'])

# Generated at 2022-06-23 13:13:00.119532
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([42, 13, 37]) == "421337"
    assert ansible_native_concat([42, 13, None, 37]) == "421337"
    assert ansible_native_concat(['42', u'13', None, 37]) == "421337"
    assert ansible_native_concat(['42', '13', None, 37]) is None
    assert ansible_native_concat(['42', '13', None, '37']) == "421337"
    assert ansible_native_concat([13, '42']) == "1342"

# Generated at 2022-06-23 13:13:09.395319
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    class AnsibleVaultEncryptedUnicode_data:
        def __init__(self):
            self.data = "password"

    test_data = {}
    test_data["simple text"] = ["text", ]
    test_data["simple number"] = ["100", ]
    test_data["simple list"] = ['["foo", "bar"]', ]
    test_data["simple dict"] = ['{"foo": "bar"}', ]
    test_data["concat list"] = ["'foo', 'bar'", ]
    test_data["concat dict"] = ["'bar': 'foo'", ]
    test_data["concat dict1"] = ["{'bar': 'foo'}", ]
    test_data["concat dict2"] = ["{'bar': 'foo'}"]

# Generated at 2022-06-23 13:13:20.169901
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.six import integer_types
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.common.text.converters import to_bytes
    from io import BytesIO


# Generated at 2022-06-23 13:13:24.846005
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([0]) == 0
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat(['foo', 42]) == 'foo42'
    assert ansible_native_concat([u'föö', 42]) == u'föö42'
    assert ansible_native_concat([None, 42]) == 'None42'
    assert ansible_native_concat([(u'föö' + chr(0xD83D) + chr(0xDCA9)), 42]) == u'föö😩42'
    assert ans

# Generated at 2022-06-23 13:13:35.217736
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 420]) == 'foo420'
    assert ansible_native_concat(['foo', '420']) == 'foo420'
    assert ansible_native_concat(['foo', '"bar"']) == 'foo"bar"'
    assert ansible_native_concat(['foo', '"b\"ar"']) == 'foo"b\\"ar"'
    assert ansible_native_concat(['foo', '"b\\\'ar"']) == 'foo"b\'ar"'
    assert ansible_native_concat(['foo', '"b\'ar"']) == 'foo"b\'ar"'

# Generated at 2022-06-23 13:13:44.842985
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import pytest


# Generated at 2022-06-23 13:13:52.448972
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import random
    import tempfile
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = dict(
        a=1,
        l=[2, 3],
        d=dict(a=[1, 2], b=3),
        s=u'abc',
        b='{{ true }}',
        f=42.23,
        t=True,
        n=None,
        v=[
            AnsibleVaultEncryptedUnicode(u'crypt me'),
            u'uncrypt me',
        ],
    )

    # Make sure dicts are rendered in a deterministic order for PyPy3.6
   

# Generated at 2022-06-23 13:14:02.302660
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([NativeJinjaText(1)]) == 1
    assert ansible_native_concat([NativeJinjaText('hello'), NativeJinjaText('world')]) == 'helloworld'
    assert ansible_native_concat([NativeJinjaText('hello'), NativeJinjaText(' '), NativeJinjaText('world')]) == 'hello world'
    assert ansible_native_concat([NativeJinjaText('['), NativeJinjaText('"hello"'), NativeJinjaText(','), NativeJinjaText('"world"')]) == ['hello', 'world']

# Generated at 2022-06-23 13:14:12.318950
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.template.safe_eval import ansible_safe_eval

    # Define the safe globals
    safe_globals = {
        'True': True,
        'False': False,
        'None': None,
        'dict': dict,
        'list': list,
        'set': set,
        'tuple': tuple,
        'int': int,
        'float': float,
        'min': min,
        'max': max,
        'abs': abs,
        'map': map,
        'filter': filter,
        'zip': zip,
        'round': round,
        'pow': pow,
        'ansible_native_concat': ansible_native_concat,
    }


# Generated at 2022-06-23 13:14:20.542736
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat(['abc']) == 'abc'
    assert ansible_native_concat(['abc', 'def']) == 'abcdef'
    assert ansible_native_concat([True, 'abc', 'def']) == 'Trueabcdef'
    assert ansible_native_concat(['abc', 'def', True]) == 'abcdefTrue'
    assert ansible_native_concat(['abc', 'def', True, 42]) == 'abcdefTrue42'
    assert ansible_native_concat([[42], ('abc',)]) == [42, 'abc']

# Generated at 2022-06-23 13:14:31.314337
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ['a', 'b'] == ansible_native_concat(
        [NativeJinjaText(['a', 'b']), 'c']
    )
    assert ['a', 'b'] == ansible_native_concat(
        [NativeJinjaText(NativeJinjaText(['a', 'b'])), 'c']
    )
    assert ['a', 'b'] == ansible_native_concat(
        [NativeJinjaText(NativeJinjaText(NativeJinjaText(['a', 'b']))), 'c']
    )
    # The following example is valid Python code, but it requires
    # multiple iterations over the given generator which is treated
    # as a relatively expensive operation.

# Generated at 2022-06-23 13:14:40.421523
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['1']) == '1'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat(['1', '2', '3']) == '123'
    assert ansible_native_concat(['1', '2', '3']) == '123'
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat(['1', 2, '3']) == '1 2 3'
    assert ansible_native_concat(['1', [2], '3']) == '1 2 3'

# Generated at 2022-06-23 13:14:48.601039
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == "123"
    assert ansible_native_concat(["1", "2", "3"]) == 123
    assert ansible_native_concat([1, "2", 3]) == "123"
    assert ansible_native_concat(["1", "2", 3]) == "123"
    assert ansible_native_concat([1, 2, "3"]) == "123"
    assert ansible_native_concat([1, 2]) == 12
    assert ansible_native_concat(["1", 2]) == "12"
    assert ansible_native_concat([1, "2"]) == "12"
    assert ansible_native_concat(["1", "2"]) == "12"
    assert ansible_native_

# Generated at 2022-06-23 13:14:59.267410
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def test(value, expected_value):
        actual_value = ansible_native_concat(value)
        if container_to_text(actual_value) != container_to_text(expected_value):
            raise AssertionError("Expected %s but got %s" % (expected_value, actual_value))

    test("abcd", "abcd")
    test("5", 5)
    test("5.5", 5.5)
    test("abcd5", "abcd5")
    test("ab\"cd5", "ab\"cd5")
    test("[ab,cd]", ["ab", "cd"])
    test(["ab", "cd"], "abcd")
    test([5, 6], "56")
    test([5, "6"], "56")

# Generated at 2022-06-23 13:15:09.530010
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    expected = "two items, with a string"
    actual = ansible_native_concat((2, " items, with a string"))
    assert actual == expected
    assert type(actual) is int

    expected = [1, 2]
    actual = ansible_native_concat(("[", 1, ",", 2, "]"))
    assert actual == expected
    assert type(actual) is list

    expected = "two items, with a string"
    actual = ansible_native_concat(("two items, with a ", "string"))
    assert actual == expected
    assert type(actual) is text_type

    expected = u"two items, with a string"
    actual = ansible_native_concat((u"two items, with a ", u"string"))
    assert actual == expected
    assert type(actual) is text

# Generated at 2022-06-23 13:15:19.833459
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(
        [u'a', u'b', u'c']
    ) == u'abc'
    assert ansible_native_concat(
        [u'a', 'b']
    ) == u'ab'
    assert ansible_native_concat(
        [(u'a', u'b'), u'c']
    ) == u'(a, b)c'
    assert ansible_native_concat(
        [u'a', u'b', u'c']
    ) == u'abc'
    assert ansible_native_concat(
        [u'a', u'b', u'c']
    ) == u'abc'

    assert ansible_native_concat(
        []
    ) is None


# Generated at 2022-06-23 13:15:29.248347
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.loader import AnsibleLoader

    nodes = [
        AnsibleLoader(None).construct_object(data='foo'),
        AnsibleLoader(None).construct_object(data='bar'),
        AnsibleLoader(None).construct_object(data='baz'),
    ]

    # single item
    n = list(islice(nodes, 1))
    assert ansible_native_concat(n) == u'foo'
    assert ansible_native_concat(n) == ansible_native_concat(nodes)

    # literal eval to int
    n = list(islice(nodes, 2))
    assert ansible_native_concat(n) == u'foobar'

# Generated at 2022-06-23 13:15:36.340890
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # literal_eval
    assert ansible_native_concat([u'[1, 2, 3]']) == [1, 2, 3]
    assert ansible_native_concat([u'"abc"']) == 'abc'
    assert ansible_native_concat([u"'abc'"]) == 'abc'
    assert ansible_native_concat([u'True']) is True
    assert ansible_native_concat([u'False']) is False
    assert ansible_native_concat([u'None']) is None
    assert ansible_native_concat([u'[1, [2, 3], 4]']) == [1, [2, 3], 4]

    # literal_eval failed

# Generated at 2022-06-23 13:15:42.269839
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    result = ansible_native_concat([u'hello', u' ', u'world'])
    assert result == 'hello world'

    result = ansible_native_concat([u'', u'', u''])
    assert result == ''

    result = ansible_native_concat([u'False'])
    assert result is False

    result = ansible_native_concat([u'1'])
    assert result == 1

    result = ansible_native_concat([u'1.0'])
    assert result == 1.0

    result = ansible_native_concat([u'[1, 2, 3]'])
    assert result == [1, 2, 3]

    result = ansible_native_concat([u'{1: 2, 3: 4}'])

# Generated at 2022-06-23 13:15:50.033056
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(iter([1])) == 1
    assert ansible_native_concat(iter([1, 2])) == u'12'
    assert ansible_native_concat(iter([1, 2])) == 12
    assert ansible_native_concat(iter(["a", "b"])) == u'ab'
    assert ansible_native_concat(iter(["a", "b"])) == "ab"
    assert ansible_native_concat(iter(["a", 2])) == u'a2'
    assert ansible_native_concat(iter(["a", 2])) == "a2"
    assert ansible_native_concat(iter([1, "b"])) == u'1b'
   

# Generated at 2022-06-23 13:15:58.797206
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    ast_node_0 = ast.Num(1)
    ast_node_0.lineno = 1
    ast_node_0.col_offset = 0

    ast_node_1 = ast.Num(1)
    ast_node_1.lineno = 1
    ast_node_1.col_offset = 2

    ast_node_2 = ast.Num(1)
    ast_node_2.lineno = 1
    ast_node_2.col_offset = 4

    ast_node_list = [ast_node_0, ast_node_1, ast_node_2]
    ast_node_generator = iter(ast_node_list)

    assert ansible_native_concat(ast_node_list) == 3
    assert ansible_native_concat(ast_node_generator) == 3

# Generated at 2022-06-23 13:16:06.861908
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['abc']) == 'abc'
    assert ansible_native_concat(['abc', 'def']) == 'abcdef'
    assert ansible_native_concat([1, 2]) == 1
    assert ansible_native_concat(['1', 2]) == '1'
    assert ansible_native_concat([1, '2']) == 1
    assert ansible_native_concat(['1', '2']) == 1
    assert ansible_native_concat([1, 2, 3]) == 1
    assert ansible_native_concat([1, '2', 3]) == '1'
    assert ansible_native_concat(['1', '2', '3']) == '123'
   

# Generated at 2022-06-23 13:16:16.509146
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Simple types
    assert ansible_native_concat([None]) == None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([123]) == 123
    assert ansible_native_concat(['123']) == 123
    assert ansible_native_concat(['1.2']) == 1.2
    assert ansible_native_concat(['True']) == True

    # List
    assert ansible_native_concat(['[1, 2, 3]']) == [1, 2, 3]
    assert ansible_native_concat(['[1, ']) == ['[1, ']

    # Tuple
    assert ansible_native_concat(['(1, 2, 3)']) == (1, 2, 3)

   

# Generated at 2022-06-23 13:16:24.709884
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test literal concatenation
    assert ansible_native_concat([1, 2, 3]) == 123

    # Test native concatenation
    assert ansible_native_concat([True, False, True]) is True
    assert ansible_native_concat([True, '', False]) is False

    # Test native conversions
    assert ansible_native_concat([1, '.', 2]) == '1.2'
    assert ansible_native_concat(['1', 2, 3]) == '123'
    assert ansible_native_concat(['1', '.', '2']) == '1.2'

    # Test string evaluation
    assert ansible_native_concat(['1', '2']) == '12'

# Generated at 2022-06-23 13:16:33.597085
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    native_jinja_text = NativeJinjaText(u'Hello')
    assert ansible_native_concat([native_jinja_text, u'world']) == u'Hello' + u'world'
    assert ansible_native_concat(iter([native_jinja_text, u'world'])) == u'Hello' + u'world'
    assert ansible_native_concat([native_jinja_text]) == native_jinja_text
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(iter([])) is None
    assert ansible_native_concat([1, 2]) == 3



# Generated at 2022-06-23 13:16:42.362893
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # "nodes" can be a list of compiled nodes or a generator of nodes.
    # We want to test both list and generator to cover all possible cases.
    # The function islice(nodes, 2) is used to create a generator or a list
    # of the first 2 elements of the nodes. This is because when the len(head)
    # is 2 or more, the function u''.join() is used instead of the head[0].
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(iter([])) is None

    assert ansible_native_concat(['one']) == 'one'
    assert ansible_native_concat(iter(['one'])) == 'one'

    # When len(head) is 2 or more, the head[0] is not used and the
   

# Generated at 2022-06-23 13:16:47.769282
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_native

    assert to_native(u'foo') == u'foo'
    assert to_native(u'foo' + to_text(u'\u2026')) == u'foo\u2026'
    assert to_native(u'foo' + to_text(u'\U0001f4a9')) == u'foo\U0001f4a9'
    assert to_native(container_to_text(u'foo' + u'\u2026')) == u'foo\u2026'
    assert to_native(container_to_text(u'foo' + u'\U0001f4a9')) == u'foo\U0001f4a9'

# Generated at 2022-06-23 13:16:54.050355
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import Template
    from jinja2.runtime import Context, shared

    def _run_template(template, data=None, globals_=None, fail_on_undefined=False):
        env = shared.make_environment(keep_trailing_newline=True, undefined=AnsibleUndefined)
        template = env.from_string(template)
        context = Context(globals_ or {}, fail_on_undefined=fail_on_undefined)
        if data is not None:
            context.update(data)
        return template.root_render_func(context)

    class AnsibleUndefined(StrictUndefined):
        """A jinja2.Undefined that does not print traceback."""
        __slots__ = ()


# Generated at 2022-06-23 13:17:03.687516
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([
        'should be',
        'concatenated',
        'as string',
    ]) == u'should be concatenated as string'

    assert ansible_native_concat([
        'should be',
        u'concatenated',
        'as string',
    ]) == u'should be concatenated as string'

    assert ansible_native_concat([
        'should be',
        'concatenated',
        u'as string',
        '\u2014',
        'not as unicode',
    ]) == u'should be concatenated as string\u2014 not as unicode'


# Generated at 2022-06-23 13:17:13.892908
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.basic import AnsibleModule
    from jinja2 import DictLoader


# Generated at 2022-06-23 13:17:16.777138
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    undefined1 = StrictUndefined('hello')
    undefined2 = StrictUndefined('world')
    undefined3 = StrictUndefined('!')
    assert container_to_text(ansible_native_concat([undefined1, ' ', undefined2, undefined3])) == 'hello world!'

# Generated at 2022-06-23 13:17:26.849584
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['abc', 'def']) == u'abcdef'
    assert ansible_native_concat(['1', '2']) == 3
    assert ansible_native_concat(['1.0', '2']) == 3.0
    assert ansible_native_concat(['1', '2', 'b']) == u'1 2b'
    assert ansible_native_concat(['1', 2]) == u'12'
    assert ansible_native_concat(['abc', {'a': 1, 'b': 2}]) == u'abcdict(a=1, b=2)'
    assert ansible_native_concat(['abc', ['a', 'b', 'c']]) == u'abclist(a, b, c)'
    assert ans

# Generated at 2022-06-23 13:17:35.796259
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.six.moves import builtins

    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([builtins.int(5), builtins.int(7)]) == 12
    assert ansible_native_concat([builtins.int(5), 'b']) == '5b'
    assert ansible_native_concat(['a', builtins.int(5)]) == 'a5'

# Generated at 2022-06-23 13:17:47.013377
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['1']) == '1'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat(['1', '2', '3']) == '123'
    assert ansible_native_concat(['True']) == 'True'
    assert ansible_native_concat(['True', 'True']) == 'TrueTrue'
    assert ansible_native_concat(['True', 'False']) == 'TrueFalse'
    assert ansible_native_concat(['True', '', 'False']) == 'TrueFalse'
    assert ansible_native_concat(['[1, 2, 3]']) == '[1, 2, 3]'

# Generated at 2022-06-23 13:17:55.456987
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a', 'b', 'c']) == "abc"
    assert ansible_native_concat(map(lambda x: u'a', range(10))) == "aaaaaaaaaa"
    assert ansible_native_concat(["a", "b", 1, u"c"]) == "abc1c"
    assert ansible_native_concat(["a", dict(a=1, b=2)]) == 'a{u\'a\': 1, u\'b\': 2}'

# Generated at 2022-06-23 13:18:04.636949
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    cases = [
        (None, None),
        ([], None),
        ([None], None),
        ([{}, None], None),
        (["1"], '1'),
        ([{}, "1"], "1"),
        ([{}, "1"], "1"),
        (["1", "2"], "12"),
        (["1", {}], "1"),
        (["1", {}], "1"),
        ([{}, "1", "2"], "12"),
        ([{}, "1", "2"], "12"),
        ([{}, {"a": 1}, "2"], "12"),
        (map(lambda x: [{}, "1", x], ["2", "2", "2"]), "121212"),
    ]

    for data, expected in cases:
        actual = ansible_native_concat(data)

# Generated at 2022-06-23 13:18:14.713538
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat((1, 2, 3)) == [1, 2, 3]
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat([1, {'a': 2}, 3]) == [1, {'a': 2}, 3]
    assert ansible_native_concat([1, {'a': 2}, ['a', 'b'], 3]) == [1, {'a': 2}, ['a', 'b'], 3]

# Generated at 2022-06-23 13:18:20.090381
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(iter([])) is None
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, 2, [3, 4]]) == '12[3, 4]'
    assert ansible_native_concat([[3, 4], 1, 2]) == '[3, 4]12'

    class Dummy(object):
        def __str__(self):
            return 'dummy'

    assert ansible_native_concat([Dummy(), 2]) == 'dummy2'

    assert ansible_native_concat(iter([1, 2])) == '12'

# Generated at 2022-06-23 13:18:24.154295
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat(map(int, '123')) == 123
    assert ansible_native_concat('abc') == 'abc'



# Generated at 2022-06-23 13:18:33.165236
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class DummyNode(object):
        def __init__(self, data):
            self.data = data

        def __unicode__(self):
            return text_type(self.data)

    assert ansible_native_concat([]) is None
    assert ansible_native_concat([DummyNode(1)]) == 1
    assert ansible_native_concat([DummyNode(1), DummyNode(2), DummyNode(3)]) == '123'

    # one item, but it's a string
    assert ansible_native_concat([DummyNode('a')]) == 'a'
    # one item, but it's a unvaulted string
    assert ansible_native_concat([DummyNode(AnsibleVaultEncryptedUnicode('a'))]) == 'a'

   

# Generated at 2022-06-23 13:18:43.778681
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([[1, 2], [3, 4]]) == '23'
    assert ansible_native_concat([[1, 2], 3, [4, 5]]) == '2345'
    assert ansible_native_concat([[1, 2], [3, 4], [5]]) == '235'
    assert ansible_native_concat([[1, 2], []]) == '2'
    assert ansible_native_concat([[], []]) is None

    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]

    test_dict = {'a': 1, 'b': 2, 'c': 3}
    assert ansible_native_con

# Generated at 2022-06-23 13:18:54.710646
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 'bar', 42]) == 'foobar42'
    assert ansible_native_concat([42, 'bar', 'baz']) == 42
    assert ansible_native_concat(['42', 'bar', 'baz']) == '42'
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat(["42"]) == 42
    assert ansible_native_concat(["42", "bar"]) == "42bar"
    assert ansible_native_concat(["{{ foo }}", "bar"]) == "{{ foo }}bar"

# Generated at 2022-06-23 13:18:59.552816
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """
    TEST RUN:
    python -c "from ansible.module_utils.common.text import ansible_native_concat; print(ansible_native_concat(['test1', 'test2', 'test3', 'test4']))"
    """
    assert "test1test2test3test4" == ansible_native_concat(['test1', 'test2', 'test3', 'test4'])



# Generated at 2022-06-23 13:19:05.937856
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat("") == ""
    assert ansible_native_concat("12345") == "12345"
    assert ansible_native_concat("1.2345") == "1.2345"
    assert ansible_native_concat("a") == "a"
    assert ansible_native_concat("a12345") == "a12345"
    assert ansible_native_concat("a1.2345") == "a1.2345"
    assert ansible_native_concat("12345a") == "12345a"
    assert ansible_native_concat("1.2345a") == "1.2345a"

    assert ansible_native_concat(12345) == 12345
    assert ansible_native_concat(1.2345) == 1

# Generated at 2022-06-23 13:19:15.361436
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import Environment
    from jinja2.nodes import List, Name, Node
    from jinja2 import Undefined
    env = Environment(extensions=[])
    env.filters['ansible_native_concat'] = ansible_native_concat

    # normal invocation
    ast = env.parse("{{ ['1', '2', '3'] | ansible_native_concat }}")
    assert env.compile(ast, undefer=True)().render() == '123'

    # undefined variables
    ast_undef = env.parse("{{ foo | ansible_native_concat }}")
    assert isinstance(env.compile(ast_undef, undefer=True)().render(), Undefined)

    # singletons

# Generated at 2022-06-23 13:19:20.152627
# Unit test for function ansible_native_concat

# Generated at 2022-06-23 13:19:30.827615
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([dict(a=1)]) == {'a': 1}
    assert ansible_native_concat([AnsibleVaultEncryptedUnicode('Vaulted', 'foo')]) == 'Vaulted'
    # Ensure that the native string is not evaluated as a boolean or int.
    assert ansible_native_concat([AnsibleUnicode('True')]) == 'True'

# Generated at 2022-06-23 13:19:42.357629
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test StrictUndefined
    out = ansible_native_concat([StrictUndefined('Undefined')])
    assert isinstance(out, StrictUndefined)

    # Test single value
    out = ansible_native_concat([True])
    assert out is True

    # Test single string
    out = ansible_native_concat(['foo'])
    assert isinstance(out, string_types)
    assert out == 'foo'

    # Test multiple strings
    out = ansible_native_concat(['foo', 'bar', 'baz'])
    assert isinstance(out, string_types)

    # Test string concatenation
    out = ansible_native_concat(['foo', 'bar', 'baz'])
    assert out == 'foobarbaz'

    # Test string concaten

# Generated at 2022-06-23 13:19:54.021334
# Unit test for function ansible_native_concat

# Generated at 2022-06-23 13:20:02.912248
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([u'foo', 1]) == u'foo1'
    assert ansible_native_concat([u'foo', u'bar', u'baz']) == u'foobarbaz'
    assert ansible_native_concat([u'foo', u'bar', 1]) == u'foobar1'
    assert ansible_native_concat([u'foo', u'bar', [u'baz', u'qux']]) == u'foobar[u\'baz\', u\'qux\']'
    assert ansible_native_concat(u'foo') == u'foo'
    assert ansible_native_concat([u'0', 1]) == u

# Generated at 2022-06-23 13:20:13.828155
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.template import Templar
    import json

    # Assert that basic concatenation works
    result = ansible_native_concat(['[', 1, ', ', 2, ']'])
    assert result == [1, 2]

    result = ansible_native_concat(['{', 'a', ':', '1', '}'])
    assert result == {'a': 1}

    # Assert that trailing whitespace is preserved
    result = ansible_native_concat(['1 ', ' ', '2'])
    assert result == '1  2'

    # Assert that unexpected items are returned as strings
    result = ansible_

# Generated at 2022-06-23 13:20:24.791206
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert ansible_native_concat([]) is None

    assert ansible_native_concat([1, 2, 3]) == 1
    assert ansible_native_concat(x for x in [1, 2, 3]) == 123
    assert ansible_native_concat([1, 2, None]) == 1

    assert ansible_native_concat([0.1]) == 0.1
    assert ansible_native_concat([0.1, 0.2]) == u'0.10.2'
    assert ansible_native_concat(x for x in [0.1, 0.2]) == u'0.10.2'

    assert ansible_native_concat([u'1', u'2', u'3']) == 123

# Generated at 2022-06-23 13:20:35.337369
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import pytest

    v = {'a': 'b'}
    assert ansible_native_concat([v]) == v

    v = [1, 2, None]
    assert ansible_native_concat([v]) == v

    assert ansible_native_concat([u'foo', v, u'bar']) == u'foobar'
    assert ansible_native_concat([u'1', v, u'3']) == [1, 2, None]

    with pytest.raises(StrictUndefined):
        ansible_native_concat([StrictUndefined])

    assert ansible_native_concat([StrictUndefined, v]) == v


# Generated at 2022-06-23 13:20:44.684418
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(["a", "b", "c", "d", "e", "f", "g", "h", "i", "j"]) == "abcdefghij"
    assert ansible_native_concat(["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", 42]) == "abcdefghij42"
    assert ansible_native_concat([42, "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", 42]) == "42abcdefghij42"

# Generated at 2022-06-23 13:20:54.607896
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.data import AnsibleVaultEncryptedUnicode

    def _assert(expected, nodes):
        assert expected == ansible_native_concat(nodes)

    _assert(None, [])
    _assert(None, [None])

    _assert(False, [False])

    _assert(8, [8])
    _assert(12, ['1', 2])
    _assert(12, [1, '2'])
    _assert(12, ['1', '2'])

    _assert([1, 2], ['[1, 2]', ])
    _assert({'v': 'a'}, ['{"v": "a"}', ])

    # Non-strings are not passed to literal_eval
    _assert(True, [True, 'x'])

# Generated at 2022-06-23 13:21:05.420811
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class JinjaText(object):
        def __init__(self, value):
            self.value = value

        def __str__(self):
            return self.value

        def __repr__(self):
            return self.value

        def __html__(self):
            return self.value

    # value can be a string
    value = JinjaText('test')
    assert ansible_native_concat(value) == 'test'

    # value can be a list with a single element
    value = [JinjaText('test')]
    assert ansible_native_concat(value) == 'test'

    # value can be a list with multiple elements
    value = [JinjaText('test'), JinjaText('test')]
    assert ansible_native_concat(value) == 'testtest'

   

# Generated at 2022-06-23 13:21:16.080925
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['1']) == '1'
    assert ansible_native_concat(['1', 2, 3]) == '123'
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat(['1', 2, '3']) == '123'
    assert ansible_native_concat(['1', 2, '3', {1: 2}]) == '123{1: 2}'
    assert ansible_native_concat(['1', 2, '3', {1: 2}]) == '123{1: 2}'

# Generated at 2022-06-23 13:21:21.443076
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(('foo', 'bar')) == 'foobar'
    assert ansible_native_concat(('foo', '{{bar}}')) == u'foo{{bar}}'
    assert ansible_native_concat(('{{foo}}', 'bar')) == u'{{foo}}bar'
    assert ansible_native_concat(('{{foo}}', '{{bar}}')) == u'{{foo}}{{bar}}'

    assert ansible_native_concat(('foo{{bar}}', 'baz')) == 'foo{{bar}}baz'
    assert ansible_native_concat(('foo', '{{bar}}baz')) == u'foo{{bar}}baz'
    assert ansible_native_concat(('foo{{bar}}', '{{baz}}qux'))

# Generated at 2022-06-23 13:21:31.013867
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([['a'], ['b']]) == 'ab'
    assert ansible_native_concat([['a'], [2]]) == '[a, 2]'
    assert ansible_native_concat([1, 2, 3, 4, 5]) == '12345'
    assert ansible_native_concat(['a', False]) == 'aFalse'

# Generated at 2022-06-23 13:21:43.078348
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test basic functionality of ansible_native_concat
    assert ansible_native_concat([1, 2]) == u'12'
    assert ansible_native_concat(['1', '2']) == u'12'
    assert ansible_native_concat(['1', '2', '3']) == u'123'
    assert ansible_native_concat([[], []]) == u'[]'

    # Test NativeJinjaText instances
    assert ansible_native_concat([NativeJinjaText('')]) == u''
    assert ansible_native_concat([NativeJinjaText('1')]) == u'1'
    assert ansible_native_concat([NativeJinjaText('1'), NativeJinjaText('2')]) == u'12'
    assert ansible

# Generated at 2022-06-23 13:21:48.186749
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([" foo ", " bar "]) == " foo bar "
    assert ansible_native_concat([1, 2]) == 1
    assert ansible_native_concat([None, "bar"]) == "bar"



# Generated at 2022-06-23 13:21:58.536626
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'

    assert ansible_native_concat(['a', u'b', 'c']) == 'abc'

    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['1', '2']) == 12
    assert ansible_native_concat(['1', '2', '3']) == 123

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'

# Generated at 2022-06-23 13:22:07.143593
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == u"12"
    assert ansible_native_concat([1, None]) == u"1None"
    assert ansible_native_concat([None, 1]) == u"None1"
    assert ansible_native_concat([1, 2, 3]) == u"123"
    assert ansible_native_concat(iter([1, 2, 3])) == u"123"

# Generated at 2022-06-23 13:22:19.382611
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_native
    def assert_same(first, second):
        assert first == second, '%s != %s' % (first, second)
    assert_same(ansible_native_concat(None), None)
    assert_same(ansible_native_concat([container_to_text('')]), '')
    assert_same(ansible_native_concat([container_to_text('foo')]), 'foo')
    assert_same(ansible_native_concat([container_to_text('foo'), container_to_text('bar')]), 'foobar')
    assert_same(ansible_native_concat([container_to_text('foo'), container_to_text(1)]), 'foo1')

# Generated at 2022-06-23 13:22:31.349309
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class Foo(object):
        def __repr__(self):
            return 'Foo()'
    # test < 2
    assert ansible_native_concat([Foo()]) == Foo()
    assert ansible_native_concat([]) is None
    # test == 2
    assert ansible_native_concat([u'Hello', u'world', u'!']) == u'Helloworld!'
    assert ansible_native_concat([u'1', 2]) == u'12'
    assert ansible_native_concat([2, u'1']) == u'21'
    assert ansible_native_concat([Foo(), 2]) == u'Foo()2'
    assert ansible_native_concat([2, Foo()]) == u'2Foo()'
    assert ansible_native_