

# Generated at 2022-06-23 13:12:31.759280
# Unit test for function ansible_native_concat

# Generated at 2022-06-23 13:12:40.045759
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test the native Python concatenation function across multiple Python
    versions.
    """
    head = [u'a', 'b', 1, 2]
    tail = [u'c', 'd', 3, 4]


# Generated at 2022-06-23 13:12:46.900140
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    test_data = [
        ([], None),
        ([1], 1),
        ([1, 2], u'12'),
        ([1, 2, 3], u'123'),
        ([1, 2, 3], u'123'),
        ([1, None, 2, None], u'12'),
    ]

    for test in test_data:
        nodes = test[0]
        expected = test[1]
        assert ansible_native_concat(nodes) == expected



# Generated at 2022-06-23 13:12:55.377598
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == u'12'
    assert ansible_native_concat(['1']) == '1'
    assert ansible_native_concat(['1', '2']) == u'12'
    assert ansible_native_concat(['[1]']) == '[1]'
    assert ansible_native_concat(['{1}']) == '{1}'
    assert ansible_native_concat(['1', '2', '3']) == u'123'
    assert ansible_native_concat(['1', 2, 3]) == u'123'

# Generated at 2022-06-23 13:13:05.586798
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test cases for ansible_native_concat function"""
    assert ansible_native_concat([]) == None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([False]) == False
    assert ansible_native_concat([True]) == True
    assert ansible_native_concat([[1, 2, 3]]) == [1, 2, 3]
    assert ansible_native_concat([(1, 2, 3)]) == (1, 2, 3)
    assert ansible_native_concat([NativeJinjaText([1, 2, 3])]) == [1, 2, 3]
    assert ansible_native_concat([1, 2]) == u"12"

# Generated at 2022-06-23 13:13:17.853629
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat([1, 2, NativeJinjaText([3])]) == "123"
    assert ansible_native_concat([1, 2, NativeJinjaText([3])]) == "123"
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat([1, 2, NativeJinjaText([3])]) == "123"
    assert ansible_native_concat(['1', 2, 3]) == "123"
    assert ansible_native_concat(['1', NativeJinjaText([2]), 3]) == "123"
    assert ansible_native_concat(['1', '2', '3']) == "123"

# Generated at 2022-06-23 13:13:28.346585
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # verify that it works with a single node, and that it works with
    # unicode
    assert ansible_native_concat([u'あいうえお']) == u'あいうえお'

    # verify that it works with a list of nodes
    assert ansible_native_concat([u'あ', u'い', u'う', u'え', u'お']) == u'あいうえお'

    # verify that it works with a generator
    gen = (u'あ', u'い', u'う', u'え', u'お')
    assert ansible_native_concat(gen) == u'あいうえお'

    # verify that it fails on Undefined
    # This is what we are trying to fix:
    #
   

# Generated at 2022-06-23 13:13:39.189769
# Unit test for function ansible_native_concat

# Generated at 2022-06-23 13:13:49.122572
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.parsing.convert_bool import boolargs

    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['a', 'b']) == "ab"
    assert ansible_native_concat([1, 2]) == [1, 2]
    assert ansible_native_concat(['a', 1, 'b', 2]) == "a1b2"
    assert ansible_native_concat(['a', 1, 'b', 2]) == 'a1b2'
    assert ansible_native_concat(['a', 1, 'b', 2]) == b'a1b2'
    assert ansible_native_concat(
        '''
        a
        b
        '''
    ) == 'a\nb'

# Generated at 2022-06-23 13:14:00.774556
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 3]) == 'foo3'
    assert ansible_native_concat(['foo', '', 'bar']) == 'foobar'

    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat([1, '2', 3]) == [1, 2, 3]

# Generated at 2022-06-23 13:14:11.430847
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # assert ansible_native_concat(None) == None
    assert ansible_native_concat([]) == None
    assert ansible_native_concat([None]) == None
    assert ansible_native_concat([[]]) == None
    assert ansible_native_concat([[], []]) == None
    assert ansible_native_concat(['']) == ''
    assert ansible_native_concat(['', '']) == ''
    assert ansible_native_concat(['abc']) == 'abc'
    assert ansible_native_concat(['abc', 'def']) == 'abcdef'
    assert ansible_native_concat(['abc', '', 'def']) == 'abcdef'

# Generated at 2022-06-23 13:14:20.119918
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import Template


# Generated at 2022-06-23 13:14:28.846514
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleVaultEncryptedUnicode

    # Undefined value is ignored in Jinja2 native concat
    assert ansible_native_concat([None, '']) is None
    assert ansible_native_concat([None, 'foo']) == 'foo'
    assert ansible_native_concat([None, 1]) == 1

    # Resulting type is AnsibleSequence
    assert ansible_native_concat([]) is None
    assert isinstance(ansible_native_concat([]), AnsibleSequence)
    assert isinstance(ansible_native_concat(['foo']), AnsibleSequence)
    assert isinstance(ansible_native_concat(['foo', 'bar']), AnsibleSequence)

    # The resulting Ans

# Generated at 2022-06-23 13:14:36.745245
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['hello', 'world']) == 'helloworld'
    assert ansible_native_concat(['hello', 'world'],) == 'helloworld'
    assert ansible_native_concat(['hello', '', 'world']) == 'helloworld'
    assert ansible_native_concat(['hello', '{{ item }}'],) == 'hello{{ item }}'
    assert ansible_native_concat([['hello', 'world']]) == ['hello', 'world']
    assert ansible_native_concat([['hello', '', 'world']]) == ['hello', '', 'world']
    assert ansible_native_concat([None, None]) == ''

# Generated at 2022-06-23 13:14:46.993048
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([True]) == True
    assert ansible_native_concat([None]) == None
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['True']) == True
    assert ansible_native_concat([1, 'b']) == u'1b'
    assert ansible_native_concat(['1', 'True']) == '1True'
    assert ansible_native_concat(['1', '2', '3']) == '123'

# Generated at 2022-06-23 13:14:57.588464
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import ast

    assert ansible_native_concat(['1', '2']) == ast.literal_eval('12')
    assert ansible_native_concat(['1', '2', '3']) == ast.literal_eval('123')
    assert ansible_native_concat(['1', '2', '3']) == ast.literal_eval('123')
    assert ansible_native_concat(['1', '2', '3']) == ast.literal_eval('123')
    assert ansible_native_concat(['1', '2', '3']) == ast.literal_eval('123')
    assert ansible_native_concat(['1', '2', '3', '4']) == ast.literal_eval('1234')
    assert ansible_native_con

# Generated at 2022-06-23 13:15:04.481329
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([NativeJinjaText("hello"), NativeJinjaText("world")]) == "helloworld"
    assert ansible_native_concat([NativeJinjaText("hello"), NativeJinjaText("world")]) == "helloworld"
    assert ansible_native_concat([NativeJinjaText("hello"), NativeJinjaText("")]) == "hello"
    assert ansible_native_concat([NativeJinjaText("hello"), NativeJinjaText(""), NativeJinjaText("world")]) == "helloworld"
    assert ansible_native_concat([NativeJinjaText(""), NativeJinjaText("hello"), NativeJinjaText("")]) == "hello"

# Generated at 2022-06-23 13:15:10.745120
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'test', u'123']) == u'test123'
    assert ansible_native_concat([u'test', 123]) == u'test123'
    assert ansible_native_concat([u'test', '123']) == u'test123'
    assert ansible_native_concat(['test', u'123']) == u'test123'
    assert ansible_native_concat([{'test': 1}, '123']) == u'{test: 1}123'
    assert ansible_native_concat([u'test', '123']) == u'test123'
    assert ansible_native_concat([u'{test: 1}']) == '{test: 1}'

# Generated at 2022-06-23 13:15:21.484924
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # exec(expression, globals(), locals()) is used to make sure the function
    # can be executed after it's passed through literal_eval.
    def test_data():
        yield '1'
        yield '2'
        yield '3'
        yield '4'

        yield ['1', '2', '3', '4']
        yield ['1', ['2', '3', '4']]

        yield {'1': '2'}
        yield {'1': ['2', '3', '4']}
        yield {'1': {'2': '3'}}
        yield {'1': ['2', {'3': '4'}]}

        yield None
        yield ''
        yield 'None'
        yield 'True'
        yield ''
        yield {'': ''}
        yield {'foo': ''}


# Generated at 2022-06-23 13:15:27.089572
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2]) == 12
    assert ansible_native_concat([11, 2]) == 112
    assert ansible_native_concat([1, "2"]) == "12"
    assert ansible_native_concat([1.1, 2.2]) == 1.12



# Generated at 2022-06-23 13:15:31.175368
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([1, '2', u'3', 4]) == '1234'
    assert ansible_native_concat(['"quoted"']) == '"quoted"'
    assert ansible_native_concat(['1', '2', '3', '4']) == '1234'



# Generated at 2022-06-23 13:15:37.220564
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # test that it calls literal_eval when appropraite
    assert ansible_native_concat([u'1', u'+', u'2']) == 3
    assert ansible_native_concat([u'1', u'+', u'', u'2']) == '1+2'
    assert ansible_native_concat([u'1', u'+', u'a']) == '1+a'
    assert ansible_native_concat([u'1', u'+', u'[]']) == '1+[]'
    assert ansible_native_concat([u'1', u'+', u'[', u']']) == '1+[]'

# Generated at 2022-06-23 13:15:46.129106
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Expect a string
    assert ansible_native_concat([1, 2, 3, 4, 5]) == u'12345'
    assert ansible_native_concat(['1', '2', '3', '4', '5']) == u'12345'
    assert ansible_native_concat([u'a', u'b']) == u'ab'
    assert ansible_native_concat([u'a', False]) == u'aFalse'
    assert ansible_native_concat([1, False]) == u'1False'
    assert ansible_native_concat([False, u'a']) == u'Falsea'

# Generated at 2022-06-23 13:15:57.329115
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    def _test_case(cases, assert_=None):
        assert_ = assert_ if assert_ is not None else assertEqual
        for case in cases:
            assert_(_fail_on_undefined(case["orig"]), case["expected"])

    assertRaises(AssertionError, lambda: _test_case([
        {"orig": "something", "expected": "something"},
    ], lambda a, b: assertEqual(a, b)))

    assertRaises(AssertionError, lambda: _test_case([
        {"orig": "something", "expected": "something"},
    ], lambda a, b: assertNotEqual(a, b)))


# Generated at 2022-06-23 13:16:05.862883
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import pytest
    assert (
        ansible_native_concat([
            container_to_text(b'1'),
            container_to_text(b'2'),
            container_to_text(b'3')
        ]) == '123')
    assert (
        ansible_native_concat([
            'one',
            'two',
            'three'
        ]) == 'onetwothree')

# Generated at 2022-06-23 13:16:15.829126
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = [1, ' ', '+', ' ', 2]
    assert ansible_native_concat(nodes) == 3

    nodes = ['(', 1, ' ', '+', ' ', 2, ')']
    assert ansible_native_concat(nodes) == '(1 + 2)'

    nodes = [1]
    assert ansible_native_concat(nodes) == 1

    nodes = ['abc']
    assert ansible_native_concat(nodes) == 'abc'

    nodes = []
    assert ansible_native_concat(nodes) == None

    nodes = ['', '']
    assert ansible_native_concat(nodes) == ''

    nodes = ['"', 'abc', '"', '']
    assert ansible_native_concat(nodes) == '"abc"'

# Generated at 2022-06-23 13:16:24.459232
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, True]) == '1True'
    assert ansible_native_concat([1, True, None]) == '1TrueNone'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat(['1', 2]) == '12'
    assert ansible_native_concat([1, '2']) == '12'
    assert ansible_native_concat([None, 'A']) == 'NoneA'

# Generated at 2022-06-23 13:16:35.179024
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([1, 2, 3, [4, 5, 6], 7]) == '123[4, 5, 6]7'
    assert ansible_native_concat([1, 2, 3, [4, 5, 6], 7, {'a': 8}, 9]) == '123[4, 5, 6]7{a: 8}9'
    assert ansible_native_concat([1, 2, 3, '4', '5', 6, {'a': 8}, 9]) == '12345{a: 8}9'

# Generated at 2022-06-23 13:16:43.152942
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.text.converters import to_native
    from ansible.utils.native_jinja import wrap_var

    def _test(nodes, expected):
        """Test that we get expected result from ansible_native_concat(nodes)."""
        out = ansible_native_concat(nodes)
        assert to_native(out) == expected, 'out: %s' % container_to_text(out)

    # Test that single nodes are returned as is
    class Foo(object):
        def __repr__(self):
            return 'Foo'

    class Bar(object):
        def __repr__(self):
            return 'Bar'


# Generated at 2022-06-23 13:16:52.645281
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert u"test" == ansible_native_concat([u"test"])
    assert u"test" == ansible_native_concat([u"test", u"test"])
    assert u"test" == ansible_native_concat([u"tes", u"t"])
    assert 2 == ansible_native_concat([2])
    assert 2 == ansible_native_concat([u"2"])
    assert (2,) == ansible_native_concat([(2,)])
    assert [2] == ansible_native_concat([[2]])
    assert {u'a': 2} == ansible_native_concat([{u'a': 2}])

    # Test various ways to use the returned value.
    # In all cases the returned value is the same.
    val = ansible

# Generated at 2022-06-23 13:17:02.288873
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test function fail_on_undefined in Jinja2
    assert _fail_on_undefined({"foo": StrictUndefined()}) == {"foo": StrictUndefined()}
    assert _fail_on_undefined({"foo": "bar"}) == {"foo": "bar"}
    assert _fail_on_undefined({}) == {}
    assert _fail_on_undefined([StrictUndefined()]) == [StrictUndefined()]
    assert _fail_on_undefined(["foo", "bar"]) == ["foo", "bar"]
    assert _fail_on_undefined([]) == []
    assert _fail_on_undefined(StrictUndefined()) == StrictUndefined()
    assert _fail_on_undefined("foo") == "foo"

# Generated at 2022-06-23 13:17:12.490868
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test several use cases of ansible_native_concat"""
    # Test with a single string
    out = ansible_native_concat([u'a'])
    assert out == 'a'
    # Test with a single int
    out = ansible_native_concat([5])
    assert out == 5
    # Test with an empty array
    out = ansible_native_concat([])
    assert out is None
    # Test with a list of strings
    out = ansible_native_concat([u'a', u'b'])
    assert out == 'ab'
    # Test with a list of strings that can be parsed
    out = ansible_native_concat([u'2', u'+', u'2'])
    assert out == 4



# Generated at 2022-06-23 13:17:20.542041
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    '''
    Test function ansible_native_concat
    '''
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([True])
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(["True"])

    l = [[1], 2, 3]
    assert ansible_native_concat(l) == l

    assert ansible_native_concat(['1', '2', '3']) == 123
    assert ansible_native_concat(['1', 2, '3']) == '123'
    assert ansible_native_concat(['1', 2, 3]) == '123'


# Generated at 2022-06-23 13:17:29.900685
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2
    from jinja2 import Environment
    from jinja2.runtime import Undefined

    # Note: To add another unit test for this function, create a new test_data
    # set below, along with the correct expected results.  Then, invoke
    # unit_test_ansible_native_concat(Env, test_data) at the bottom of the
    # function.  This is necessary because the unit test for this function
    # shares data.

    # Dict of unit test data for ansible_native_concat function

# Generated at 2022-06-23 13:17:40.076547
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def assert_equal(val1, val2, msg=None):
        if msg is None:
            msg = '%r not equal to %r' % (val1, val2)
        assert val1 == val2, msg

    n = NativeJinjaText(None)
    u = u'\u03b1'
    assert_equal(ansible_native_concat([n, n]), n)
    assert_equal(ansible_native_concat([None, None]), None)
    assert_equal(ansible_native_concat([42, 43]), u'4243')
    assert_equal(ansible_native_concat([n, 42, 43]), u'42' + u'43')

# Generated at 2022-06-23 13:17:45.378535
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    from ansible.module_utils.common.text.text_compat import to_native


# Generated at 2022-06-23 13:17:52.476561
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Issue #70831
    class testJinjaText(NativeJinjaText):
        def __init__(self, value):
            self.value = value

    assert ansible_native_concat([]) is None
    assert ansible_native_concat([testJinjaText('test')]) == 'test'
    assert ansible_native_concat([testJinjaText('test'), testJinjaText('test')]) == 'testtest'
    assert ansible_native_concat([3, testJinjaText('test'), testJinjaText('test')]) == '3testtest'

    # strings are not concatenated
    assert ansible_native_concat(['3', testJinjaText('test'), testJinjaText('test')]) == '3'



# Generated at 2022-06-23 13:18:02.738629
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([NativeJinjaText(u'a'), NativeJinjaText(u'b')]) == 'ab'
    assert ansible_native_concat([u'a', u'b']) == 'ab'
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat([['a'], ['b']]) == ['a', 'b']
    assert ansible_native_concat([['a', 1], ['b', 2]]) == ['a', 1, 'b', 2]
    assert ansible_native_concat([('a', 1), ('b', 2)]) == ('a', 1, 'b', 2)

# Generated at 2022-06-23 13:18:13.548570
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(('foo', 'bar')) == 'foobar'
    assert ansible_native_concat(('1', '2', '3')) == 123
    assert ansible_native_concat((2, 3)) == 5
    assert ansible_native_concat((2, 'bar')) == 2
    assert ansible_native_concat((['foo', 'bar'],)) == ['foo', 'bar']
    assert ansible_native_concat((['foo', 'bar'], ['baz'])) == ['foo', 'bar', 'baz']
    assert ansible_native_concat(('foo', {'bar': 'baz'})) == 'foo'

# Generated at 2022-06-23 13:18:24.047201
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # all types that can be compared for equality
    # (except for strings with "u" prefix)
    types = []
    types.extend(range(10))
    types.extend(['foo', 'bar', ''])
    types.extend([None, 'None'])
    types.extend([True, 'True'])
    types.extend([False, 'False'])
    types.append([])
    types.append(['foo', 'bar'])
    types.append(('foo', 'bar'))
    types.append({})
    types.append({'foo': 'bar'})
    types.append(set())
    types.append({'foo', 'bar'})

    # correct conversion of each of the types
    for t in types:
        assert ansible_native_concat([t]) is t

# Generated at 2022-06-23 13:18:32.996839
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([None, None]) == None
    assert ansible_native_concat([1, 2]) == 3
    assert ansible_native_concat(["foo", "bar"]) == "foobar"
    assert ansible_native_concat([" ['a', 'b'] ", " ['c', 'd'] "]) == ['a', 'b', 'c', 'd']
    assert ansible_native_concat(['"foo"', '"bar"']) == 'foobar'
    assert ansible_native_concat([" 'foo' ", " 'bar' "]) == 'foobar'
    assert ansible_native_concat(['"foo"', '"bar"']) == 'foobar'

# Generated at 2022-06-23 13:18:43.672887
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # test function's existence
    assert callable(ansible_native_concat)

    # test with no parameters
    assert ansible_native_concat([]) is None

    # test with single value
    assert ansible_native_concat(['This is a test']) == 'This is a test'
    assert ansible_native_concat([True]) == True
    assert ansible_native_concat([False]) == False
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['[1, 2, 3]']) == [1, 2, 3]
    assert ansible_native_concat(['{a: 1}']) == {'a': 1}

# Generated at 2022-06-23 13:18:54.615747
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1.0]) == 1.0
    assert ansible_native_concat(['1']) == '1'
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, 2.0]) == '12.0'
    assert ansible_native_concat(['1', 2]) == '12'
    assert ansible_native_concat(['list', [1, 2]]) == 'list[1, 2]'
    assert ansible_native_concat([1, [2, 3]]) == '1[2, 3]'

# Generated at 2022-06-23 13:18:59.763505
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = [
        container_to_text({'a': 'b'}),
        container_to_text({'c': 'd'}),
        container_to_text({'e': 'f'}),
    ]
    concat_result = ansible_native_concat(nodes)
    assert isinstance(concat_result, text_type)
    assert concat_result == '{a: b} {c: d} {e: f}'



# Generated at 2022-06-23 13:19:04.120976
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # We need some nodes to test with, as it's kind of impossible to
    # create nodes for testing.
    # However, we can fake it by overriding the on_append function of
    # the native type concatenation function.
    class Node:
        def __init__(self, value):
            self.value = value

        def on_append(self, *args, **kwargs):
            return self

    def concat_nodes(*nodes):
        return ansible_native_concat(nodes)

    concat_nodes.__globals__['Node'] = Node

    assert concat_nodes() is None
    assert concat_nodes(Node(1)) == 1
    assert concat_nodes(Node(1), Node(2)) == u'12'

# Generated at 2022-06-23 13:19:14.354667
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat([1, 'b']) == '1b'
    assert ansible_native_concat([['a'], 'b']) == ['ab']
    assert ansible_native_concat(['[']) == '['
    assert ansible_native_concat(['[a']) == '[a'
    assert ansible_native_concat(['[ab]']) == 'ab'
    assert ansible_native_concat(['""']) == ''

# Generated at 2022-06-23 13:19:22.671257
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([1, ' ', 2, ' ', 3]) == '1 2 3'

    assert ansible_native_concat([1, 'a'], ' ', 'b') == '1a b'

    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['1', '2', '3']) == '123'
    assert ansible_native_concat(['1', ' ', '2', ' ', '3']) == '1 2 3'

    assert ansible_native_concat(['1', 'a'], ' ', 'b') == '1a b'

    assert ansible_native

# Generated at 2022-06-23 13:19:27.151454
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test the empty node
    result = ansible_native_concat([])
    assert result is None, "Empty node did not return None."
    # Test a node returning a string
    result = ansible_native_concat([u"string_one"])
    assert result == u"string_one", "string node did not return string."
    # Test a node returning an integer
    result = ansible_native_concat([1])
    assert result == 1, "integer node did not return integer."
    # Test a node returning a float
    result = ansible_native_concat([3.14159])
    assert result == 3.14159, "float node did not return float."
    # Test a node returning a boolean
    result = ansible_native_concat([True])

# Generated at 2022-06-23 13:19:35.422074
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # test 1: concat two strings
    a = "foo"
    b = "bar"
    assert ansible_native_concat([a, b]) == "foobar"

    # test 2: concat two numbers
    a = 1
    b = 2
    assert ansible_native_concat([a, b]) == 1
    assert ansible_native_concat([b, a]) == 2

    # test 3: concat two lists
    a = [1, "foo"]
    b = [2, "bar"]
    assert ansible_native_concat([a, b]) == [1, "foo", 2, "bar"]

    # test 4: concat two dictionaries
    a = {'a': 1}
    b = {'b': 2}

# Generated at 2022-06-23 13:19:42.535278
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([]) is None

    assert ansible_native_concat([1, u'a', u'b', u'c']) == u'1abc'
    assert ansible_native_concat([1, u'a', u'b', u'c']) == u'1abc'
    assert ansible_native_concat([1, u'a', u'b', u'c']) == u'1abc'

    assert ansible_native_concat([1, u'a', u'b', u'c', u'\n']) == u'1abc\n'

# Generated at 2022-06-23 13:19:50.126055
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from .testcases import TEST_CASES

    for test in TEST_CASES:
        result = u''.join([to_text(v) for v in test['values']])
        if hasattr(result, 'data'):
            result = result.data
        try:
            result = ast.literal_eval(ast.parse(result, mode='eval'))
        except (ValueError, SyntaxError, MemoryError):
            pass
        assert result == ansible_native_concat(test['values'])

# Generated at 2022-06-23 13:19:59.868516
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2

    env = jinja2.Environment()
    env.tests['native_concat'] = ansible_native_concat
    env.filters['native_list'] = container_to_text

    test_template = env.from_string('''{{ [1, 2, 3] | native_concat | native_list }}''')
    assert test_template.render() == "[1, 2, 3]"

    test_template = env.from_string('''{{ [1, 'a'] | native_concat | native_list }}''')
    assert test_template.render() == "[1, 'a']"


# Generated at 2022-06-23 13:20:07.154118
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = [
        u'foo$2foo',
        u'bar',
    ]
    assert ansible_native_concat(nodes) == u'foo$2foobar'

    nodes = [
        u'foo$2foo',
        u'bar',
        u'baz$2bar',
    ]
    assert ansible_native_concat(nodes) == u'foo$2foobarbaz$2bar'

    nodes = [
        u'1',
        u'2',
    ]
    assert ansible_native_concat(nodes) == 1

    nodes = [
        u'2',
    ]
    assert ansible_native_concat(nodes) == 2

    nodes = [
        u'02',
    ]

# Generated at 2022-06-23 13:20:16.607084
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['20', '15']) == 2015
    assert ansible_native_concat(['{"a": 1}', '{"b": 2}']) == {"a": 1, "b": 2}
    assert AnsibleVaultEncryptedUnicode("foo").data == ansible_native_concat([AnsibleVaultEncryptedUnicode("foo")])
    assert NativeJinjaText("{{ foo }}").__html__() == ansible_native_concat([NativeJinjaText("{{ foo }}")])



# Generated at 2022-06-23 13:20:28.382862
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # a convoluted way of passing a list of arguments to a function
    # (allowing it to be variadic)

    def args(*args_):
        return args_

    assert ansible_native_concat(args('abc', 1)) == 'abc1'

    # empty list
    assert ansible_native_concat(args()) is None

    # list with a single element
    assert ansible_native_concat(args(100)) == 100

    # list with multiple elements
    assert ansible_native_concat(args(args(1, 2, 3), args(4, 5, 6))) == [1, 2, 3, 4, 5, 6]
    assert ansible_native_concat(args(args(1, 2, 3), 'abcdef')) == 'abcdef'

# Generated at 2022-06-23 13:20:37.493547
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['1', '2']) == 12
    assert ansible_native_concat(['1', 2]) == '12'
    assert ansible_native_concat(['1', '2', '3']) == 123
    assert ansible_native_concat(['1', '2', 3]) == '123'
    assert ansible_native_concat([u'\xff', '2', 3]) == u'\xff23'
    assert ansible_native_concat([u'\xff', 2, 3]) == u'\xff23'

# Generated at 2022-06-23 13:20:44.593949
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import pytest
    from ansible.module_utils.common.text.converters import container_to_text

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    assert ansible_native_concat([]) is None
    assert ansible_native_concat([u'a']) == u'a'
    assert ansible_native_concat([u'a', u'b']) == u'ab'
    assert ansible_native_concat([u'a', u' b', u' c']) == u'a b c'
    assert ansible_native_concat([u'a', u' b', u' c', u'd']) == u'a b c d'


# Generated at 2022-06-23 13:20:54.572691
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Unit test for function ansible_native_concat

    There are two different paths

    * Parser path:
    https://github.com/ansible/ansible/blob/devel/lib/ansible/parsing/plugin/jinja2/__init__.py#L133-L136
    * Smart Parser path:
    https://github.com/ansible/ansible/blob/devel/lib/ansible/parsing/plugin/smart/__init__.py#L247
    """
    # TODO: add tests for all edge cases

    # Parser path
    from ansible.parsing.yaml.objects import AnsibleUnicode

# Generated at 2022-06-23 13:21:05.420475
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class FakeNode:
        u'''Fake node for the tests of ansible_native_concat'''
        def __init__(self, value):
            u'''Stores the value'''
            self.value = value

        def __repr__(self):
            u'''Returns the string representation of the fake node'''
            return u"FakeNode(%s)" % container_to_text(self.value)

        def __str__(self):
            u'''Returns the value as unicode'''
            return to_text(self.value)

        def __html__(self):
            u'''Returns the string representation of the fake node'''
            return repr(self)

    class FakeVariable:
        u'''Fake variable for the tests of ansible_native_concat with native jinja'''

# Generated at 2022-06-23 13:21:16.079793
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    assert ansible_native_concat([]) == None
    assert ansible_native_concat([123]) == 123
    assert ansible_native_concat([u'abc']) == u'abc'
    assert ansible_native_concat([AnsibleUnicode(u'abc')]) == u'abc'
    assert ansible_native_concat([u'abc', u'xyz']) == u'abcxyz'
    assert ansible_native_concat([123, u'xyz']) == u'123xyz'
    assert ansible_native_concat([[u'a', u'b'], u'xyz']) == u'["a", "b"]xyz'
    assert ansible_native_con

# Generated at 2022-06-23 13:21:21.444339
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    test_str_1 = AnsibleUnsafeText(u'This is a string')
    test_str_2 = AnsibleUnsafeText(u'This is also a string')
    test_str_3 = AnsibleUnsafeText(u'This is a 4')
    test_str_4 = AnsibleUnsafeText(u'1')
    test_str_5 = AnsibleUnsafeText(u'[[1, 2, 3]]')
    test_str_6 = AnsibleUnsafeText(u'a{{ b }}c')
    test_str_7 = AnsibleUnsafeText(u'[1, 2, 3]')
    test_str_8 = AnsibleUnsafeText(u'[1, 2, 3]')

# Generated at 2022-06-23 13:21:31.013984
# Unit test for function ansible_native_concat

# Generated at 2022-06-23 13:21:43.078172
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # create a mock variable of the Node class
    Node = type('Node', (object,), {"value": None})
    assert ansible_native_concat(None) is None

    # test a single Node
    node_single = Node()
    node_single.value = 12345
    assert ansible_native_concat([node_single]) == 12345

    # test a list of Nodes
    node_1 = Node()
    node_1.value = "hello "
    node_2 = Node()
    node_2.value = 12345
    node_3 = Node()
    node_3.value = " world"
    assert ansible_native_concat([node_1, node_2, node_3]) == "hello 12345 world"

    # test a list of iterators
    assert ansible_native_concat

# Generated at 2022-06-23 13:21:55.082602
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]), 'empty list should return None'
    assert ansible_native_concat([1, 2]), 'joined list should return a string'
    assert ansible_native_concat(["1", 2]) == "12", 'joined list should return a string'
    assert ansible_native_concat([1, 2]) == [1, 2], 'literal_eval should return original list'
    assert ansible_native_concat(["[", 1, ", ", 2, "]"]) == [1, 2], 'literal_eval should return the list'
    assert ansible_native_concat(["[", 1, ", ", 2, "]"]) == [1, 2], 'literal_eval should return the list'

# Generated at 2022-06-23 13:22:06.527837
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([b'foo', b'bar']) == 'foobar'
    assert ansible_native_concat([b'foo', b'bar', b'baz']) == 'foobarbaz'
    assert ansible_native_concat([b'foo', b'bar', b'baz', b'qux']) == 'foobarbazqux'
    assert ansible_native_concat([b'foo', b'bar', b'baz', b'qux', b'quux']) == 'foobarbazquxquux'
    assert ansible_native_concat([b'foo', b'bar', b'baz', b'qux', b'quux', b'corge']) == 'foobarbazquxquuxcorge'
    assert ansible

# Generated at 2022-06-23 13:22:11.344324
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ['a'] == ansible_native_concat(['a'])
    assert ['a'] == ansible_native_concat(['a', 'b'])
    assert [['a']] == ansible_native_concat(['[a]', 'b'])
    assert ['a'] == ansible_native_concat([' a'])
    assert {'foo': 'bar'} == ansible_native_concat(['foo: bar'])
    assert ['a', 'b'] == ansible_native_concat(['["a", "b"]'])
    assert None == ansible_native_concat([])
    assert ['a'] == ansible_native_concat([['a']])

# Generated at 2022-06-23 13:22:22.340681
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat([1, 2, 3]) != [1, 2]
    assert ansible_native_concat(['1', 2, u'3']) == [1, 2, 3]
    assert ansible_native_concat(['1', 2, u'3']) != [1, 2]
    assert ansible_native_concat(['1', 2, u'3']) != ['1', 2, u'3']
    assert ansible_native_concat(['1', 2, u'3']) != ['1', 2, '3']
    assert ansible_native_concat(['1', 2, u'3']) != [1, 2, u'3']



# Generated at 2022-06-23 13:22:34.537933
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import unittest
    import os
    import sys
    import contextlib

    class FakeStdin(object):

        class LineIterator(object):
            def __init__(self, stdin, sizehint=0):
                self.stdin = stdin
                self.sizehint = sizehint

            def __iter__(self):
                if self.sizehint:
                    yield from islice(self.stdin, self.sizehint)
                else:
                    yield from self.stdin

        def __init__(self, readlines):
            self._readlines = readlines
            self._closed = False

        def close(self):
            self._closed = True

        def __iter__(self):
            return self.LineIterator(iter(self._readlines), -1)
