

# Generated at 2022-06-23 13:12:38.685538
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([True]) is True

    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([1, 2, 3]) == u'123'
    assert ansible_native_concat([True, u'foo']) == u'Truefoo'

    assert ansible_native_concat([u'Hello, World!']) == u'Hello, World!'
    assert ansible_native_concat([u"Hello, 'World'!"]) == u"Hello, 'World'!"
    assert ansible_native_con

# Generated at 2022-06-23 13:12:50.159458
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Short-circuit literal_eval for anything other than strings
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == 12
    assert ansible_native_concat([True]) == True
    assert ansible_native_concat([True, False]) == 'TrueFalse'
    assert ansible_native_concat(['x']) == 'x'
    assert ansible_native_concat(['x', 'y', 'z']) == 'xyz'
    assert ansible_native_concat(['1', '2', '3']) == 123
    assert ansible_native_concat(['abc', 'xyz']) == 'abcxyz'

    assert ansible_native_concat(['{', '}']) == '{}'
   

# Generated at 2022-06-23 13:13:00.026816
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a', 'b', 34]) == 'ab34'
    assert ansible_native_concat([34, 'a', 'b']) == '34ab'
    assert ansible_native_concat([34, 'a', 'b', 'd', 'e', 'f']) == '34abdef'

    # test tuple handling
    assert ansible_native_concat([(34, 'a'), 'b']) == '34ab'
    assert ansible_native_concat([(34, 'a'), (5, 'b')]) == '34ab'
    assert ansible_native_concat([(34, 'a'), (5, 'b'), 'e']) == '34ab5be'

    # test literal_eval

# Generated at 2022-06-23 13:13:07.708199
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Create test string of all possible characters for the use of testing.
    # This one is for length of 2.
    all_chars = "".join(chr(i) for i in range(256))

    # Test the original string if the original string can be parsed.
    assert ansible_native_concat([all_chars[:2]]) == all_chars[:2]

    # Test when the original string can not be parsed.
    assert ansible_native_concat([all_chars[:2]]) == all_chars[:2]
    assert ansible_native_concat([all_chars[:2]]) == all_chars[:2]

    # Test concat two strings together

# Generated at 2022-06-23 13:13:13.551665
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # NativeJinjaText
    assert ansible_native_concat([NativeJinjaText('abc')]) == 'abc'
    assert ansible_native_concat([NativeJinjaText('abc'), NativeJinjaText('def')]) == 'abcdef'
    assert ansible_native_concat([NativeJinjaText('abc'), 'def']) == 'abcdef'

    # string
    assert ansible_native_concat([u'a']) == u'a'
    assert ansible_native_concat([u'a', u'b']) == u'ab'
    assert ansible_native_concat([u'a', u'b', u'c']) == u'abc'

# Generated at 2022-06-23 13:13:18.095928
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat(['1', 2]) == '12'
    assert ansible_native_concat(['1', 2, b'3']) == '123'
    assert ansible_native_concat(map(to_text, [1, 2, 3])) == '123'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat(['1', 2]) == '12'
    assert ansible_native_concat(['1', 2, b'3']) == '123'
    assert ansible_native_concat(map(to_text, [1, 2, 3])) == '123'
    assert ansible_native_

# Generated at 2022-06-23 13:13:28.344485
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([4]) == 4
    assert ansible_native_concat([4.2]) == 4.2
    assert ansible_native_concat(['single']) == 'single'
    assert ansible_native_concat(['multi', 'ple']) == 'multiple'
    assert ansible_native_concat([{'key': 'value'}]) == {'key': 'value'}
    assert ansible_native_concat([{'key': 'value'}, 'extended']) == '{key: value}extended'
    assert ansible_native_concat(['{key: value}', 'extended']) == '{key: value}extended'

# Generated at 2022-06-23 13:13:39.189268
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    from jinja2.runtime import Undefined

    # Native types
    assert ansible_native_concat([1, 2, 3]) == 1
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', 'b', 'c', 'd']) == 'abcd'
    assert ansible_native_concat(['a' * 12, 'b' * 12, 'c' * 12, 'd' * 12]) == 'a' * 48
    assert ansible_native_concat(['a' * 12, 'b' * 12, 'c' * 12, 'd' * 12]) == 'a' * 48
    assert ansible_native_concat([True, False]) is True

# Generated at 2022-06-23 13:13:49.775057
# Unit test for function ansible_native_concat

# Generated at 2022-06-23 13:14:01.196456
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([u'Hello']) == u'Hello'
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat([1.0]) == 1.0
    assert ansible_native_concat([u'Hello', u'World']) == u'HelloWorld'
    assert ansible_native_concat([u'Hello', 42]) == u'Hello42'
    assert ansible_native_concat([u'Hello', 42.0]) == u'Hello42.0'
    assert ansible_native_concat([u'Hello', True]) == u'HelloTrue'
    assert ansible_native_concat([u'Hello', False]) == u'HelloFalse'
    assert ansible_native_

# Generated at 2022-06-23 13:14:11.743997
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_str
    from ansible.module_utils.common.text.converters import to_text
    import ast
    import sys

    # Python 2.7 compatible literal_eval like Python 3.8
    def literal_eval(node_or_string):
        if isinstance(node_or_string, string_types):
            node_or_string = ast.parse(node_or_string)
        if isinstance(node_or_string, ast.Expression):
            node_or_string = node_or_string.body

# Generated at 2022-06-23 13:14:20.282060
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([True, True]) is True
    assert ansible_native_concat([False, True]) is False
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', u'b']) == 'ab'
    assert ansible_native_concat([u'a', u'b']) == 'ab'
    assert ansible_native_concat([u'a', 'b']) == 'ab'
    assert ansible_native_concat(['a', b'b']) == 'ab'

# Generated at 2022-06-23 13:14:31.143664
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    assert ansible_native_concat(['foo']) == u'foo'
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([123]) == 123

    assert ansible_native_concat([Binary('foo')]) == b'foo'
    assert ansible_native_concat([Markup(u'foo')]) == u'foo'
    assert ansible_native_concat([Markup(u'foo').striptags()]) == u'foo'
    assert ansible_native_concat([Markup(u'foo').unescape()]) == u'foo'

# Generated at 2022-06-23 13:14:40.322185
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    input_ = 'literal_eval: [ {{ [] }} ]'
    expected = list()
    output = container_to_text(ansible_native_concat(input_), indent=4)
    assert output == text_type(expected)

    input_ = 'literal_eval: [ {{ 123 }} ]'
    expected = [123]
    output = container_to_text(ansible_native_concat(input_), indent=4)
    assert output == text_type(expected)

    input_ = 'literal_eval: [ {{ "foo" }} ]'
    expected = ['foo']
    output = container_to_text(ansible_native_concat(input_), indent=4)
    assert output == text

# Generated at 2022-06-23 13:14:48.553355
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Test single node
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([u'a']) == u'a'
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([NativeJinjaText('a')]) == 'a'
    assert container_to_text(ansible_native_concat([{}])) == '{}'
    assert container_to_text(ansible_native_concat([[]])) == '[]'
    assert container_to_text(ansible_native_concat([set()])) == 'set()'

# Generated at 2022-06-23 13:14:59.226091
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils import common as mod_utils
    from ansible.module_utils.common.text.converters import to_bytes

    def test(nodes, expected):
        assert repr(ansible_native_concat(nodes)) == repr(expected)

    def run_tests():
        test([], None)
        test([''], None)
        test('foo', to_bytes('foo'))
        test(u'foo', u'foo')
        test([u'foo', u'bar'], u'foobar')
        test([u'foo', u'bar', 42], u'foobar42')
        test(['foo', 'bar', 42, True], 'foobar42True')
        test([u'foo', u'bar', 42, True], 'foobar42True')

# Generated at 2022-06-23 13:15:09.499161
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Verify that we can evaluate a native Python object from Jinja2 nodes."""

    # StrictUndefined can be raised when an undefined variable is accessed
    class Undefined(StrictUndefined):
        pass

    # Define a valid integer value
    int_value = 42

    # The following values are invalid

# Generated at 2022-06-23 13:15:19.833701
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.six import PY3
    import jinja2

    assert ansible_native_concat([]) is None
    assert ansible_native_concat(iter([1])) == 1
    assert ansible_native_concat(iter([True])) is True
    if not PY3:
        assert ansible_native_concat(iter([unicode('text')])) == 'text'

    assert ansible_native_concat(iter([None, '', None])) == ''
    assert ansible_native_concat(
        iter(['value', '-', 'value']),
    ) == u'value-value'

    nodes = (iter(['{{', 'value', '}}']))
    assert ansible_native_concat(nodes) == u'{{ value }}'


# Generated at 2022-06-23 13:15:25.802738
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2.nodes import Const
    from jinja2 import Environment

    env = Environment(extensions=[])
    assert ansible_native_concat([Const(1), Const(2), Const(3)]) == 1
    assert ansible_native_concat([Const('a'), Const('b'), Const('c')]) == 'abc'
    assert ansible_native_concat([Const('1'), Const('2'), Const('3')]) == 1
    assert ansible_native_concat([Const('abc')]) == 'abc'
    assert ansible_native_concat([Const('')]) == ''
    assert ansible_native_concat([Const(u'\xFF')]) == u'\xFF'
    assert ansible_native_concat([Const(0), Const('')]) == ''
   

# Generated at 2022-06-23 13:15:34.473177
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar', 'baz']) == 'foobarbaz'
    assert ansible_native_concat((n for n in ['foo', 'bar', 'baz'])) == 'foobarbaz'
    assert ansible_native_concat(['foo', 1]) == 'foo1'
    assert ansible_native_concat(['foo', [1]]) == 'foo[1]'
    assert ansible_native_concat(['foo', [1], 'bar']) == 'foo[1]bar'
    assert ansible_native_concat(['foo ', 'bar']) == 'foo bar'
    assert ansible_native_concat(['foo', '\n', 'bar']) == 'foo\nbar'

# Generated at 2022-06-23 13:15:44.989910
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Unit test for ansible_native_concat"""
    def test(args, expect):
        """Check that native_concat(args) == expect"""
        actual = ansible_native_concat(args)
        assert actual == expect, 'native_concat(%s) -> %s, not %s' % (args, actual, expect)

    # test cases
    test('{{ a }}', 'a')
    test('{{ a }}{{ b }}', 'ab')
    test('{{ a }}{{ b }}{{ c }}', 'abc')
    test(' {{ a }} ', 'a')
    test(' {{ a }} {{ b }} ', 'ab')
    test(' {{ a }} {{ b }} {{ c }} ', 'abc')

    test(['{{ a }}', '{{ b }}', '{{ c }}'], 'abc')


# Generated at 2022-06-23 13:15:57.048340
# Unit test for function ansible_native_concat

# Generated at 2022-06-23 13:16:01.113236
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    node = [
        '{{ bar }}',
        '{{ baz }}',
        '{{ qux }}',
    ]
    assert ansible_native_concat(node) == ' '.join(node)



# Generated at 2022-06-23 13:16:09.302082
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.formatters import to_json
    from ansible.module_utils.common.text.formatters import to_nice_json

    def assert_equals(actual_data, expected_data):
        assert actual_data == expected_data


# Generated at 2022-06-23 13:16:18.937548
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2]) == [1, 2]
    assert ansible_native_concat(range(1, 10)) == list(range(1, 10))
    assert ansible_native_concat((x for x in range(1, 10))) == list(range(1, 10))
    assert ansible_native_concat({1: 2}) == {1: 2}
    assert ansible_native_concat((1, 2)) == [1, 2]
    assert ansible_native_concat(1) == 1
    assert ansible_native_concat(None) is None
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(range(1, 10)) == list(range(1, 10))

# Generated at 2022-06-23 13:16:26.717326
# Unit test for function ansible_native_concat

# Generated at 2022-06-23 13:16:37.518083
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # the first argument is ['(', ')'], which is required by the base
    # concat() method
    assert ansible_native_concat(['(', ')']) == None
    assert ansible_native_concat(['(', ')', []]) == []
    assert ansible_native_concat(['(', ')', 'test']) == 'test'
    assert ansible_native_concat(['(', ')', 1, 2]) == 3
    assert ansible_native_concat(['(', ')', 1, '2']) == [1, '2']
    assert ansible_native_concat(['(', ')', 1, 'a']) == '1a'

# Generated at 2022-06-23 13:16:44.171571
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2, 3, 4]) == '1234'
    assert ansible_native_concat(['1', 2, '3', 4]) == '1234'
    assert ansible_native_concat([1.5, 2.5, 3.5, 4.5]) == '1.52.53.54.5'
    assert ansible_native_concat(
        [u'1', u'2', u'3', u'4']
    ) == u'1234'
    assert ansible_native_concat(
        [u'1', u'2', u'3', u'4']
    ) == u'1234'
    assert ans

# Generated at 2022-06-23 13:16:52.718979
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat(['{1.5}']) == {1.5}
    assert ansible_native_concat(['["foo"]']) == ["foo"]
    assert ansible_native_concat(['(1+1)']) == (1+1)
    assert ansible_native_concat(['{1, 2.0}']) == {1, 2.0}
    assert ansible_native_concat(['{"foo": "bar"}']) == {'foo': 'bar'}
    assert ansible_native_concat(['{"foo": ["bar"]}']) == {'foo': ['bar']}

# Generated at 2022-06-23 13:17:02.327050
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None

    assert ansible_native_concat(['a']) == 'a'

    assert ansible_native_concat(['a', 'b']) == 'ab'

    assert ansible_native_concat([1,2,3]) == 123

    assert ansible_native_concat([1, 'b', 3]) == '1b3'

    assert ansible_native_concat([1, 'b', 'c']) == '1bc'

    assert ansible_native_concat(['a', 1, 2, 3]) == 'a123'

    assert ansible_native_concat(['a', 'b', 1, 2, 3]) == 'ab123'


# Generated at 2022-06-23 13:17:12.523601
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '1 2'

    assert ansible_native_concat(['abc']) == 'abc'
    assert ansible_native_concat(['abc', 'def']) == 'abcdef'

    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([True, False]) == 'True False'

    assert ansible_native_concat([container_to_text({})]) == {}
    assert ansible_native_concat([container_to_text({'a': 1}), 'b']) == '{a: 1} b'



# Generated at 2022-06-23 13:17:20.572381
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    data = [True, 1, 'foo', [1, 2.0, 3j], {'a': 2, 'b': 3.0}]
    assert data == ansible_native_concat(data)

    data = "foo"
    assert data == ansible_native_concat(data)

    data = True
    assert data == ansible_native_concat(data)

    data = [1, True, "foo"]
    assert data == ansible_native_concat(data)

    data = ansible_native_concat([None])
    assert data is None

    data = "1"
    assert data == ansible_native_concat(data)

    data = ansible_native_concat([1, 'foo'])
    assert data == "1"

    data = '2.0'

# Generated at 2022-06-23 13:17:29.897485
# Unit test for function ansible_native_concat

# Generated at 2022-06-23 13:17:37.183207
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['abc']) == 'abc'
    assert ansible_native_concat(['abc', 'def']) == 'abcdef'
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([1, '2', 3]) == '123'
    assert ansible_native_concat(['1', '2', '3']) == '123'
    assert ansible_native_concat(['1', 2, '3']) == '123'

# Generated at 2022-06-23 13:17:48.088354
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([123]) == 123
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat(['foo', 1, 2, 'bar', 'baz']) == 'foo123barbaz'
    assert ansible_native_concat(['foo', 1, 2, 'bar', 'baz']) == 'foo123barbaz'
    assert isinstance(ansible_native_concat([True]), bool)
    assert ansible_native_concat([True]) == True
    assert isinstance(ansible_native_concat([[1, 2, 3]]), list)
    assert ansible_native_

# Generated at 2022-06-23 13:17:59.426067
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1.2]) == 1.2
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([' foo ']) == ' foo '
    assert ansible_native_concat([None]) == None

    assert ansible_native_concat([1, 2.3, u"4", '5']) == '12.34 5'

    assert ansible_native_concat(to_text(v) for v in [1, 2.3, u"4", '5']) == '12.34 5'


# Generated at 2022-06-23 13:18:07.792196
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(('1234',)) == '1234'
    assert ansible_native_concat(('1234', '5678')) == '12345678'
    assert ansible_native_concat(('1234', '5678', '9')) == '123456789'
    assert ansible_native_concat(('1234', '5678', '9', '0')) == '1234567890'
    assert ansible_native_concat((1, 2, 3)) == '123'
    assert ansible_native_concat(range(10)) == '0123456789'

    # when a non-string is input, dont try to parse
    assert ansible_native_concat(range(2)) == range

# Generated at 2022-06-23 13:18:15.800876
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible import context
    from test.lib import text_data

    context._init_global_context()
    context.CLIARGS = {'vault_password_file': '', 'module_path': ''}

    parser = context.CLIARGS['__ansible_parser']
    (options, args) = parser.parse_args(args=[])
    context.CLIARGS.update(vars(options))
    context.CLIARGS['FILES'] = args

    assert ansible_native_concat([]) is None
    assert ansible_native_concat([0]) == 0
    assert ansible_native_concat([1, 2]) == 12
    assert ansible_native_concat([1, 2, 3]) == 123

# Generated at 2022-06-23 13:18:25.806244
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1, 2, 3]) == 1
    assert ansible_native_concat([True, False, True]) is True
    assert ansible_native_concat(['foo', 'bar', 'baz']) == 'foo'
    assert ansible_native_concat(['foo', 1, 'baz']) == 'foo'
    assert ansible_native_concat([1, 'foo', 'baz']) == 1
    assert ansible_native_concat([2, 1, None]) == 2
    assert ansible_native_concat([2, 1, None], native=False) == '2'
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat(['None'])

# Generated at 2022-06-23 13:18:35.568566
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.six import string_types
    def _assert_type_matches(node, expected_type):
        actual_result = ansible_native_concat(node)
        actual_type = type(actual_result)
        assert expected_type == actual_type, 'unexpected type, actual: {}, expected: {}'.format(actual_type, expected_type)

    def _assert_value_matches(node, expected_value):
        actual_result = ansible_native_concat(node)
        actual_type = type(actual_result)
        if isinstance(actual_result, string_types):
            actual_value = repr(actual_result)
        else:
            actual_value = actual_result


# Generated at 2022-06-23 13:18:38.219390
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    result = ansible_native_concat(['a', AnsibleVaultEncryptedUnicode('b', 'c')])
    print(container_to_text(result))
    assert result == 'abc'

# Generated at 2022-06-23 13:18:45.648939
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('hello') == 'hello'
    assert ansible_native_concat('hello' 'world') == 'helloworld'
    assert ansible_native_concat(['hello', 'world']) == 'helloworld'
    assert ansible_native_concat(['hello', '\\n', 'world']) == 'hello\\nworld'
    assert ansible_native_concat(['hello ', 'world']) == 'hello world'
    assert ansible_native_concat(['hello', 1, 'world']) == 'hello1world'
    assert ansible_native_concat(['hello', '1', 'world']) == 'hello1world'
    assert ansible_native_concat(['hello', 1.0, 'world']) == 'hello1.0world'
   

# Generated at 2022-06-23 13:18:55.898620
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nat_1 = AnsibleVaultEncryptedUnicode('vaulted')
    nat_2 = NativeJinjaText('special')
    nat_3 = 'default'
    nat_4 = True
    nat_5 = '123'

    complex_item = [nat_1, nat_2, nat_3, nat_4, nat_5, ' ']
    assert ansible_native_concat(complex_item) == 'vaultedspecialdefaultTrue123'
    assert ansible_native_concat(['vaulted', nat_2, nat_3, nat_4, nat_5, ' ']) == 'vaultedspecialdefaultTrue123'
    assert ansible_native_concat('vaulted') == 'vaulted'

# Generated at 2022-06-23 13:19:03.104620
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(iter([])) is None

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(iter([1])) == 1

    assert ansible_native_concat([object()]) == object()
    assert ansible_native_concat(iter([object()])) == object()

    assert ansible_native_concat(['x']) == 'x'
    assert ansible_native_concat(iter(['x'])) == 'x'

    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(iter(['a', 'b'])) == 'ab'


# Generated at 2022-06-23 13:19:13.982065
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.template import Templar

    class DummyNode(object):
        def __init__(self, value=None):
            self.value = value

        def __iter__(self):
            return iter([self.value])

        def __repr__(self):
            return repr(self.value)

        def __str__(self):
            return str(self.value)

    class DummyEnvironment(object):
        def __init__(self):
            self.finalize = Templar._fail_on_undefined_errors

    concat = ansible_native_concat
    environment = DummyEnvironment()

    assert concat([]) is None
    assert concat([DummyNode('foo')]) == 'foo'
    assert concat([DummyNode('foo'), DummyNode('bar')]) == 'foobar'
   

# Generated at 2022-06-23 13:19:21.870786
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    dict_src = dict(y=dict(y=dict(y=dict(y=dict(y=['a', 'b', 'c'])))))
    list_src = [dict_src]

# Generated at 2022-06-23 13:19:25.324043
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    '''Return a test function that is suitable for supplying to jinja2.make_environment().
    This way the test function can be used like this:
       jinja2.make_environment(undefined=StrictUndefined, cache_size=0, extensions=['jinja2.ext.do']).from_string('{{ [1,2] | map("test_ansible_native_concat") | sum() }}').render()
    '''
    def test_ansible_native_concat_test_func(x):
        return ansible_native_concat(x)
    return test_ansible_native_concat_test_func



# Generated at 2022-06-23 13:19:33.688782
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common.text.converters import to_bytes

    data_list = [
        'abc123',
        123,
        [1, 2, 3],
        {u'abc': [1, 2, u'def']},
        [1, 2, {u'abc': u'123'}],
        [1, 2, ['abc']],
        [1, 2, [u'abc']],
        [1, 2, [u'a\u00e7']],
        [1, 2, [u'a\u00e7'.encode('utf-8')]]
    ]

    for data in data_list:
        data_str = container_to_text(data)
        if PY3:
            data

# Generated at 2022-06-23 13:19:44.061674
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat(['a', 1, False]) == 'a1False'
    assert ansible_native_concat([1, 2, 'a']) == '12a'

# Generated at 2022-06-23 13:19:48.404531
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([1, '2', 3]) == '123'
    assert ansible_native_concat(['1', '2', '3']) == '123'
    assert ansible_native_concat([1, '2', 3]) == '123'
    assert ansible_native_concat(['1', 2, 3]) == '123'
    assert ansible_native_concat(['1', '2', '3']) == '123'
    assert ansible_native_concat(['1', '2', '3']) == '123'
    assert ansible_native_concat(['', '2', '3']) == '23'

# Generated at 2022-06-23 13:19:58.404604
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(iter([1])) == 1
    assert ansible_native_concat(iter([u'a'])) == u'a'
    assert ansible_native_concat(iter([1, 2, 3])) == u'123'
    assert ansible_native_concat(iter([u'a', u'b', u'c'])) == u'abc'
    assert ansible_native_concat(iter([1, u'a', 2, u'b', 3, u'c'])) == u'1a2b3c'
    assert ansible_native_concat(iter([1, True, 2, False, 3, None])) == u'1True2False3None'

# Generated at 2022-06-23 13:20:09.440769
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([u'1']) == 1
    assert ansible_native_concat([2]) == 2
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, u'2']) == '12'
    assert ansible_native_concat([u'1', 2]) == '12'
    assert ansible_native_concat([u'a', u'b']) == u'ab'
    assert ansible_native_concat([u'ab']) == u'ab'
    assert ansible_native_concat([u'a', u'b', u'c']) == u'abc'

# Generated at 2022-06-23 13:20:17.817747
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class DummyNode(object):
        def __init__(self, value, node_type):
            self.value = value
            self.node_type = node_type

        def __repr__(self):
            return "<DummyNode: %r %r>" % (self.value, self.node_type)

        def __str__(self):
            return self.__repr__()

    # Test 1: Passing regular string
    assert ansible_native_concat([DummyNode("test", "string")]) == 'test'

    # Test 2: Passing list of strings
    assert ansible_native_concat([DummyNode("test", "string"),
                                  DummyNode("string", "string")]) == 'teststring'

    # Test 3: Passing integer

# Generated at 2022-06-23 13:20:30.092443
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test if it works with an empty list
    assert ansible_native_concat([]) is None

    # Test if it returns the value if it is a single node.
    assert ansible_native_concat(['a']) == 'a'

    # Test if it returns a simple value if the concatenation can be parsed with ast.literal_eval
    # In this case '0' is interpreted as an integer.
    assert ansible_native_concat(['0']) == 0

    # Test if it returns the text if the concatenation cannot be parsed with ast.literal_eval
    assert ansible_native_concat(['0', 'x']) == '0x'

    # Test if it returns the text when joining a list of strings.

# Generated at 2022-06-23 13:20:38.299927
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(["a"]) == "a"
    assert ansible_native_concat(["a", "b"]) == "ab"
    assert ansible_native_concat([0]) == 0
    assert ansible_native_concat([0, 1]) == 1
    assert ansible_native_concat([0, "a"]) == "0a"
    assert ansible_native_concat([0, "a", 1]) == "0a1"
    assert ansible_native_concat(["a", 0, "b"]) == "a0b"
    assert ansible_native_concat(["a", 0, "b", 1]) == "a0b1"

# Generated at 2022-06-23 13:20:45.133704
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """
    ansible_native_concat should parse a value and return the parsed value
    if it is possible.
    """

    # Try different types
    assert isinstance(ansible_native_concat(['Hello', ' ', 'World']), str)
    assert isinstance(ansible_native_concat(['123']), int)
    assert isinstance(ansible_native_concat(['True']), bool)
    assert isinstance(ansible_native_concat(['[1, 2, 3]']), list)
    assert isinstance(ansible_native_concat(['{a: 1}']), dict)

    # Try combinations of different types
    assert isinstance(ansible_native_concat(['1', '2']), str)

# Generated at 2022-06-23 13:20:51.021200
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 13:21:02.255686
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_native
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([1, 2]) == u'12'
    assert ansible_native_concat([1, 2]) == 12
    assert ansible_native_concat([True, False]) is False
    assert ansible_native_concat([[1, 2], [3, 4]]) == u'[1, 2]\n[3, 4]'

# Generated at 2022-06-23 13:21:13.128538
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([1, None, 2]) == '1None2'
    assert ansible_native_concat([1, 2, '']) == '12'
    assert ansible_native_concat([1, '2']) == 3
    assert ansible_native_concat([1, '2a']) == '12a'
    assert ansible_native_concat([1, '2.0']) == '12.0'
    assert ansible_native_concat([1, '2.0', 3]) == '12.03'

# Generated at 2022-06-23 13:21:24.281287
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import pytest

    test_cases = [
        ['a', 'b'],
        [1, 2],
        ['a', 2],
        [None, 1],
        ['a', None],
    ]

    expected_results = [
        'ab',
        (1, 2),
        'a2',
        (None, 1),
        'aNone',
    ]

    for test_case, expected_result in zip(test_cases, expected_results):
        result = ansible_native_concat(test_case)
        assert result == expected_result

    # verify exception is raised for undefined variable
    test_case = [StrictUndefined(), 1]
    with pytest.raises(UndefinedError):
        ansible_native_concat(test_case)

    # verify exception is raised for undefined variable nested

# Generated at 2022-06-23 13:21:32.992601
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    lineno = 0

    class Node:
        def __init__(self, value=None, lineno=None):
            self.value = value
            self.lineno = lineno

        def compile(self, environment=None):
            return self

    assert ansible_native_concat([Node(1), Node(2)]) == [1, 2]
    assert ansible_native_concat([Node(1), Node("2")]) == [1, 2]
    assert ansible_native_concat([Node("1"), Node("2")]) == '12'
    assert ansible_native_concat([Node("1"), Node("2", lineno=lineno)]) == '12'

# Generated at 2022-06-23 13:21:44.349539
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
    from six import u

    # Test without literal_eval
    assert ansible_native_concat([
        AnsibleUnicode('a'),
        AnsibleUnicode('b'),
        AnsibleUnicode('c'),
    ]) == u('abc')

    assert ansible_native_concat([
        AnsibleUnicode('a'),
        AnsibleUnicode('b'),
        AnsibleUnicode('c'),
    ]) != 'abc'

    # Test with literal_eval
    assert ansible_native_concat([
        AnsibleUnicode('[1,'),
        AnsibleUnicode('2,'),
        AnsibleUnicode('3]'),
    ]) == [1, 2, 3]

# Generated at 2022-06-23 13:21:55.875209
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test ast.literal_eval
    assert ansible_native_concat(['"', 'foo', '"']) == 'foo'
    assert ansible_native_concat(['"', '0', '"']) == '0'
    assert ansible_native_concat(['"', '1', '"']) == '1'
    assert ansible_native_concat(['"', '0', '', '1', '"']) == '01'
    assert ansible_native_concat(['"', '"', '"', '', '"']) == ''
    assert ansible_native_concat(['"', 'foo', 'bar', '"']) == 'foobar'
    assert ansible_native_concat(['"', 'foo', '', 'bar', '"']) == 'foobar'
    assert ans

# Generated at 2022-06-23 13:22:07.501999
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.template.safe_eval import ansible_native_concat as l_ansible_native_concat
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.template.safe_eval import mark_undefined_vars_native

    plaintext = 'plaintext'
    vaulttext = AnsibleVaultEncryptedUnicode(None, plaintext)

    # A single string will be returned without parsing
    assert l_ansible_native_concat([mark_undefined_vars_native(plaintext)]) == plaintext
    assert l_ansible_native_concat([mark_undefined_vars_native(vaulttext)]) == vaulttext

    # An integer will be returned without parsing

# Generated at 2022-06-23 13:22:19.667228
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'

    # Python literals
    assert ansible_native_concat([u'1']) == 1
    assert ansible_native_concat([u'True']) is True
    assert ansible_native_concat([u'[1, 2, 3]']) == [1, 2, 3]

    # multiline code
    assert ansible_native_concat([u'1 +\n 1']) == 2

    # native types
    assert ansible_native_concat([u'foo', 42, 3.14]) == u'foo423.14'
    assert ansible

# Generated at 2022-06-23 13:22:31.709393
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([u'42', u'42']) == 8484

    # Check that it handles Unicode apostrophes correctly
    # https://github.com/ansible/ansible/issues/70881
    assert ansible_native_concat([u'\u2019']) == u'\u2019'

    # Check that the conversion does not happen when it should not
    # https://github.com/ansible/ansible/issues/70831
    assert container_to_text([42]) == u'[42]'