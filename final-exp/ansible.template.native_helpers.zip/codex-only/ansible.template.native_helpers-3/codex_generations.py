

# Generated at 2022-06-23 13:12:39.155502
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('abc') == 'abc'

    # Supports iterables and strings
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat('a' + 'b' + 'c') == 'abc'

    # Concatenates strings and returns string
    assert ansible_native_concat(['a', 99, 'c']) == 'a99c'
    assert ansible_native_concat(['a'] + [99] + ['c']) == 'a99c'

    # Converts to string
    assert ansible_native_concat(['a', True, 99]) == 'aTrue99'

    # Returns a single item
    assert ansible_native_concat([True]) == True

    # Attempts to

# Generated at 2022-06-23 13:12:50.205691
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # expected

# Generated at 2022-06-23 13:13:00.058401
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test ansible_native_concat()
    """
    output = ansible_native_concat((NativeJinjaText(x) for x in ['Hello', ' ', 'World!']))
    assert output == 'Hello World!'

    output = ansible_native_concat((NativeJinjaText(x) for x in ['Hello', 'World!']))
    assert output == 'HelloWorld!'

    output = ansible_native_concat((NativeJinjaText(x) for x in ['Hello World!']))
    assert output == 'Hello World!'

    output = ansible_native_concat(NativeJinjaText('Hello World!'))
    assert output == 'Hello World!'

    output = ansible_native_concat(NativeJinjaText('Hello'))
    assert output == 'Hello'

    output = ans

# Generated at 2022-06-23 13:13:07.729805
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common import remove_values
    from ansible.module_utils.common.text.converters import to_native
    import pytest
    import jinja2
    from ansible.parsing.yaml.constructor import AnsibleConstructor

    mocked_env = jinja2.Environment(
        loader=jinja2.DictLoader({'template': '{{ foo }}'}),
    )

    def render(value):
        template = mocked_env.get_template('template')
        template.module.ansible_concat = ansible_native_concat
        template.module.ansible_native_concat = ansible_native_concat
        template.module.ansible_convert_to_native = to_native
        out = template.render(foo=value)
       

# Generated at 2022-06-23 13:13:12.148993
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Unit test for ansible_native_concat"""
    result = ansible_native_concat([1, 2])
    assert isinstance(result, int)
    assert result == 12

    result = ansible_native_concat([1.0, 2, 3.0])
    assert isinstance(result, str)
    assert result == '123'

    result = ansible_native_concat(['1', '2'])
    assert isinstance(result, int)
    assert result == 12

    result = ansible_native_concat(['1.0', '2.0', '3.0'])
    assert isinstance(result, float)
    assert result == 6.0

    result = ansible_native_concat(['"'])
    assert isinstance(result, str)
    assert result == '"'



# Generated at 2022-06-23 13:13:21.177656
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # NativeJinjaText is mostly a plain string but it differs from it in that
    # it is marked as safe for usage in Jinja's |safe filter.
    # See:
    # https://github.com/pallets/jinja/issues/1200
    # https://github.com/ansible/ansible/issues/70831#issuecomment-664190894
    s = NativeJinjaText(u'1')
    assert ansible_native_concat(s) == s
    assert ansible_native_concat([s]) == s
    assert ansible_native_concat(NativeJinjaText(u'f') + NativeJinjaText(u'o')) == NativeJinjaText(u'foo')

    assert ansible_native_concat([u'1']) == u'1'
   

# Generated at 2022-06-23 13:13:29.928679
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import unittest.mock
    def _run(val):
        # The AnsibleTemplate class implements __iter__ by yielding
        # values of the template environment variables. This generator
        # emulates __iter__ to make the test simpler.
        if isinstance(val, string_types):
            yield val
        elif is_sequence(val):
            for element in val:
                yield element
        else:
            raise TypeError(val)

    class _AnsibleTemplate:
        def __init__(self, val):
            self.val = val

        def __iter__(self):
            return _run(self.val)

        def __getitem__(self, index):
            if not isinstance(index, int):
                raise TypeError(index)

            return self.val[index]


# Generated at 2022-06-23 13:13:39.540222
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # `and` and `or` operator will not reutrn a single value
    assert ansible_native_concat([1, 'and', 2]) == u'1 and 2'
    assert ansible_native_concat([1, 'or', 2]) == u'1 or 2'

    assert ansible_native_concat([0]) == 0
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([0, 'and', 1]) == 0
    assert ansible_native_concat([1, 'and', 1]) == 1
    assert ansible_native_concat([0, 'or', 1]) == 1
    assert ansible_native_concat([1, 'or', 0]) == 1

    assert ansible_native_concat(['test']) == u'test'


# Generated at 2022-06-23 13:13:49.390876
# Unit test for function ansible_native_concat

# Generated at 2022-06-23 13:14:00.972474
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', '123']) == 'foo123'
    assert ansible_native_concat(['foo', '123', 'bar']) == 'foo123bar'
    assert ansible_native_concat(['foo', '123', 'bar', '456']) == 'foo123bar456'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat(['1', '2', '3']) == '123'
    assert ansible_native_concat(['1', '2', '3', '4']) == '1234'

# Generated at 2022-06-23 13:14:11.593843
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # basic types
    assert ansible_native_concat([1, 2, 3]) == u'123'
    assert ansible_native_concat([1.1, 2.2, 3.3]) == u'1.12.23.3'
    assert ansible_native_concat([True, False]) == u'TrueFalse'
    assert ansible_native_concat([1, True]) == u'1True'
    assert ansible_native_concat([[1, 2], [3, 4]]) == u'[1, 2][3, 4]'
    assert ansible_native_concat([(1, 2), (3, 4)]) == u'(1, 2)(3, 4)'

# Generated at 2022-06-23 13:14:20.221896
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleSequence

    # literal_eval
    assert ansible_native_concat(["1"]) == 1
    assert ansible_native_concat(["1.0"]) == 1.0
    assert ansible_native_concat(["True"]) is True
    assert ansible_native_concat(["'foo'"]) == 'foo'
    assert ansible_native_concat(['"foo"']).replace(u"\u2019", "'") == 'foo'
    assert ansible_native_concat(['"foo', 'bar"']) == 'foo\nbar'

    # literal_eval error
    assert ansible_native_concat(["1 + 1"]) == "1 + 1"

   

# Generated at 2022-06-23 13:14:31.069215
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Empty inputs
    assert ansible_native_concat([]) is None
    assert container_to_text(ansible_native_concat([])) == 'None'

    # Single strings
    assert ansible_native_concat(['supercalifragilisticexpialidocious']) == 'supercalifragilisticexpialidocious'
    assert container_to_text(ansible_native_concat(['supercalifragilisticexpialidocious'])) == 'supercalifragilisticexpialidocious'

    # Single numbers
    assert ansible_native_concat([42]) == 42
    assert container_to_text(ansible_native_concat([42])) == '42'

    # Single dicts

# Generated at 2022-06-23 13:14:40.255329
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['abc', 'def']) == 'abcdef'
    assert ansible_native_concat(['abc', 'def', 'ghi']) == 'abcdefghi'
    assert ansible_native_concat(['abc']) == 'abc'
    assert ansible_native_concat([5]) == 5
    assert ansible_native_concat(['5']) == 5
    assert ansible_native_concat([5.5]) == 5.5
    assert ansible_native_concat(['5.5']) == 5.5
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([False]) is False
    assert ansible_native_concat(['True']) is True
    assert ansible_native_concat

# Generated at 2022-06-23 13:14:48.529914
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    # test valid python literals
    assert ansible_native_concat([123]) == 123
    assert ansible_native_concat([123, 456]) == 123456
    assert ansible_native_concat([123, 456, 789]) == 123456789
    assert ansible_native_concat([123, 456, 789, 'a']) == 123456789, 'a'
    assert ansible_native_concat([123, 456, 789, 'a', 'bcde', 'f']) == 123456789, 'abcdef'
    assert ansible_native_concat([123, 456, 789, True]) == 123456789, ' True'
    assert ansible_native_

# Generated at 2022-06-23 13:14:58.856676
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['test', ' - ', 'test']) == 'test - test'
    assert ansible_native_concat(['{', '}']) == '{}'
    assert ansible_native_concat(['test', '_', 'test']) == 'test_test'
    assert ansible_native_concat([u'test', u'_', u'test']) == u'test_test'
    assert ansible_native_concat([u'{"a":1}', u'_', u'test']) == u'{"a":1}_test'
    assert ansible_native_concat([u'test', u'_', u'{"a":1}']) == u'test_{"a":1}'

# Generated at 2022-06-23 13:15:09.366387
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'1', u'2']) == 12
    assert ansible_native_concat([u'a', u'b', u'c']) == u'abc'
    assert ansible_native_concat([u'a', u'b', u'c', u' ']) == u'abc '
    assert ansible_native_concat([u'abc']) == u'abc'
    assert ansible_native_concat([u'a', {u'b': u'c'}, u'b', [u'c']]) == u'a{u\'b\': u\'c\'}bu[\'c\']'
    assert ansible_native_concat([u'  q']) == u'  q'


# FIXME: move this to common/text/conver

# Generated at 2022-06-23 13:15:19.509159
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat(u'foo') == u'foo'
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(u'') == ''

    assert ansible_native_concat(u'foo' + u'bar') == u'foobar'

    assert ansible_native_concat(ast.literal_eval(u'[1, 2]')) == [1, 2]
    assert ansible_native_concat(ast.literal_eval(u'["1", "2"]')) == [u'1', u'2']
    assert ansible_native

# Generated at 2022-06-23 13:15:28.963806
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(['1', '2', '3']) == '123'
    assert ansible_native_concat(['abc', '1', 'xyz']) == 'abc1xyz'
    assert ansible_native_concat(['a', '123', 'c']) == 'a123c'
    assert ansible_native_concat(['123', 'abc']) == '123abc'
    assert ansible_native_concat(['123']) == '123'
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['1']) == '1'


# Generated at 2022-06-23 13:15:36.182793
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([NativeJinjaText('')])
    assert ansible_native_concat([NativeJinjaText('a')]) == 'a'
    assert ansible_native_concat([NativeJinjaText('a'), NativeJinjaText('b')]) == u'ab'
    assert ansible_native_concat([8]) == 8
    assert ansible_native_concat([8, 16]) == u'816'

    class Container:
        def __init__(self, value):
            self.value = value

        def __add__(self, other):
            assert isinstance(other, (string_types, Container))
            return Container(self.value + other.value)


# Generated at 2022-06-23 13:15:45.691516
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import pytest
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.formatters import indent
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.collections import is_sequence, is_mapping
    from ansible.module_utils.six import ensure_bytes, ensure_text
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.vars import merge_hash

    def check_native_concat(module_args, expected_result):
        result = to_native(module_args, keep_underscores=True, fail_on_undefined=True)

# Generated at 2022-06-23 13:15:57.162352
# Unit test for function ansible_native_concat

# Generated at 2022-06-23 13:16:05.681657
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    def _do_test(in_data, expected):
        in_data = container_to_text(in_data)
        value = ansible_native_concat([in_data])
        assert value == expected

    _do_test(("a", "b"), "ab")
    _do_test("a", "a")
    _do_test("a\nb", "'a\nb'")
    _do_test("a\nb", "a\nb")
    _do_test("a\n\tb", "a\n\tb")
    _do_test("a\tb\nc", "a\tb\nc")
    _do_test("a\tb\nc", "'a\tb\nc'")

# Generated at 2022-06-23 13:16:11.342382
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat(['1', 2]) == '12'
    assert ansible_native_concat([1, '2']) == '12'
    assert ansible_native_concat([1.0]) == 1.0
    assert ansible_native_concat(['1.0']) == 1.0

# Generated at 2022-06-23 13:16:18.561335
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Literal values are left untouched
    assert ansible_native_concat(['1']) == '1'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['1.0']) == '1.0'
    assert ansible_native_concat([1.0]) == 1.0
    assert ansible_native_concat(['foo']) == 'foo'

    # Concatenation of strings
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', u'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([1, '2'])

# Generated at 2022-06-23 13:16:25.810759
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test 1: Test if the function accepts and converts the single node to
    #         Python type
    assert ansible_native_concat([5]) == 5
    assert ansible_native_concat(['5']) == 5
    assert ansible_native_concat(['Hello']) == 'Hello'
    assert ansible_native_concat(['Hello', 'World']) == 'HelloWorld'
    assert ansible_native_concat(['Hello', 'World', '!']) == 'HelloWorld!'

    # Test 2: Test if the function accepts and converts the multi-node
    #         sequence to Python type
    assert ansible_native_concat([5, 10, 15, 20]) == '5101520'

# Generated at 2022-06-23 13:16:36.771298
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == u'12'
    assert ansible_native_concat(u'abc') == u'abc'

    assert ansible_native_concat(range(5)) == u'01234'
    assert ansible_native_concat(xrange(5)) == u'01234'

    assert ansible_native_concat([1, 2, 3]) == 6
    assert ansible_native_concat([1, u'2', u'3']) == u'123'
    assert ansible_native_concat([1, u'2', 3]) == u'123'

# Generated at 2022-06-23 13:16:43.921325
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([100]) == 100
    assert ansible_native_concat([100, 200]) == '100200'
    assert ansible_native_concat([100, 200, 300]) == '1002003'
    assert ansible_native_concat(['h', 'e', 'l', 'l', 'o']) == 'hello'
    assert ansible_native_concat(['h', 'e', 'll', 'o', ' ']) == 'hello '
    assert ansible_native_concat(['h', 'e', 'l', 'l', 'o', ' ']) == 'hello '
    assert ansible_native_concat(['h', 'e', 'll', 'o', ' ']) == 'hello '
    assert ansible

# Generated at 2022-06-23 13:16:52.603065
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert isinstance(ansible_native_concat([1, 2]), int)
    assert ansible_native_concat([1, 2]) == 3

    assert isinstance(ansible_native_concat([1, 2, '3']), int)
    assert ansible_native_concat([1, 2, '3']) == 123

    assert isinstance(ansible_native_concat([1, 2, 3, '4']), int)
    assert ansible_native_concat([1, 2, 3, '4']) == 1234

    assert isinstance(ansible_native_concat(['1', 2, '3', 4]), int)
    assert ansible_native_concat(['1', 2, '3', 4]) == 1234


# Generated at 2022-06-23 13:17:01.155924
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([['a', 'b'], ['c', 'd']]) == ['ac', 'bd']
    assert ansible_native_concat([[1, 2], [3, 4]]) == [1, 2, 3, 4]
    assert ansible_native_concat([1, 'abc', ['a', 'b'], 3.0, [[1, 2], [3, 4]], True]) == \
        '[1, \'abc\', [\'a\', \'b\'], 3.0, [[1, 2], [3, 4]], True]'



# Generated at 2022-06-23 13:17:10.678995
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    ast_literal_function = ast.literal_eval

    # When using ast_literal_eval, some typical types should be converted
    # properly. If a type is not converted properly, it is because of the
    # implementation of ast_literal_eval. This unit test does not cover
    # this scenario.
    assert ansible_native_concat([ast_literal_function("123")]) == 123
    assert ansible_native_concat([ast_literal_function("123.4")]) == 123.4
    assert ansible_native_concat([ast_literal_function("'123.4'")]) == "123.4"
    assert ansible_native_concat([ast_literal_function("'123'")]) == "123"

    # When using ast_literal_eval, strings are not interpreted as

# Generated at 2022-06-23 13:17:17.255672
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Check concat
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat('abc'.split()) == 'abc'
    assert ansible_native_concat(['a', {'b': [1, 2, 3]}, 'c']) == 'a[1, 2, 3]c'

    # Check literal evaluation
    assert ansible_native_concat(['123']) == 123
    assert ansible_native_concat(['123.456']) == 123.456
    assert ansible_native_concat(['true']) == True
    assert ansible_native_concat(['false']) == False
    assert ansible_native_concat(['[1, 2, 3]']) == [1, 2, 3]
    assert ansible_

# Generated at 2022-06-23 13:17:27.104317
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils import basic

    # Taken from https://github.com/pallets/jinja/blob/master/testsuite/test_nativetypes.py

# Generated at 2022-06-23 13:17:38.437056
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.parsing import safe_eval
    import sys

    if PY3:
        str2 = to_text(b"str2", encoding='ascii')
        str3 = to_text(b"str3", encoding='ascii')
        str4 = to_text(b"str4", encoding='ascii')
    else:
        str2 = "str2"
        str3 = "str3"
        str4 = "str4"

    # test list
    l = [1, 2, 3, 4]
    assert ansible_

# Generated at 2022-06-23 13:17:48.717485
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2
    from jinja2 import Environment
    from ansible.module_utils.basic import AnsibleModule
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch

    module = AnsibleModule(argument_spec={})

    env = Environment(extensions=['ansible_collections.notstdlib.moveitallout.plugins.filter.core'])
    env.globals['env'] = module.params
    env.finalize = ansible_native_concat

# Generated at 2022-06-23 13:17:59.888174
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == u'foobar'
    assert ansible_native_concat([True]) == True
    assert ansible_native_concat(['[1, 2]', True]) == [1, 2]
    assert ansible_native_concat(['[1, 2]', u'[3, 4]']) == [1, 2, 3, 4]
    assert ansible_native_concat(['[', u'1, 2]']) == u'[1, 2]'
    assert ansible_native_concat(['{', u'1: 2}']) == u'{1: 2}'
    assert ansible_native_concat(['1', u'2']) == u'12'



# Generated at 2022-06-23 13:18:08.094277
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    def assert_native(value, expected, *args):
        assert ansible_native_concat(jinja2.nodes.List(*args).iter_child_nodes()) == expected
        assert ansible_native_concat(jinja2.nodes.Tuple(*args).iter_child_nodes()) == expected

    assert_native(u'1', u'1', jinja2.nodes.Const(u'1'))
    assert_native(u'1', u'1', jinja2.nodes.Const(1))
    assert_native(1, 1, jinja2.nodes.Const(1))

# Generated at 2022-06-23 13:18:14.036033
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['value']) == 'value'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat(['1', '2', '3']) == '123'
    assert ansible_native_concat(['1', '2', 'value']) == '12value'
    assert ansible_native_concat([1, 2, 'value']) == '1 2 value'
    assert ansible_native_concat(['[', 1, 2, ']']) == '[1, 2]'


# Generated at 2022-06-23 13:18:24.715603
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Note: _fail_on_undefined needs to be mocked since it tries to access
    # undefined objects and raises an exception
    import mock
    import ansible.module_utils.jinja2.native as module
    module._fail_on_undefined = mock.Mock()

    # The following unit tests are a modified version of
    # the ones found in
    # https://github.com/pallets/jinja/blob/master/tests/test_nativetypes.py
    #
    # Note: We don't run these tests with the Python coverage tool because
    # the code inside this function modifies the local context of the module
    # ansible.module_utils.jinja2.native.
    # The coverage tool doesn't support this kind of monkey patching and it
    # would therefore cause coverage measurement to malfunction.

    assert module.ans

# Generated at 2022-06-23 13:18:33.981728
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def assertEqual(actual, expected):
        assert actual == expected

    # test literal_eval
    assertEqual(ansible_native_concat([1, 2, 3]), 123)
    assertEqual(ansible_native_concat(['1', '2', '3']), 123)
    assertEqual(ansible_native_concat(['1.0', '0.2', '3.0']), 1.0200000000000003)
    assertEqual(ansible_native_concat(['"a"', '"b"', '"c"']), 'abc')
    assertEqual(ansible_native_concat(['"a"', '"b"', '"c"']), 'abc')

# Generated at 2022-06-23 13:18:44.088065
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    values = ['', '', '']
    node_iter = iter(values)
    out = ansible_native_concat(node_iter)
    assert(out == '')

    values = [1, '', '']
    node_iter = iter(values)
    out = ansible_native_concat(node_iter)
    assert(out == 1)

    values = [1, 'a', '']
    node_iter = iter(values)
    out = ansible_native_concat(node_iter)
    assert(out == '1a')

    values = [1, 'a', 'b']
    node_iter = iter(values)
    out = ansible_native_concat(node_iter)
    assert(out == '1ab')


# Generated at 2022-06-23 13:18:55.113994
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test ansible native concat function."""
    from ansible.module_utils.jinja2 import (
        AnsibleUndefined,
        AnsibleUndefinedVarsTemplateError,
        AnsibleVaultEncryptedUnicode,
        AnsibleJ2Text,
    )
    def _test_undefined(data, undefined_value):
        """The undefined values can come from a simple string
        or use '| string' filter to mark the value as undefined.
        """
        if undefined_value is None:
            assert data is undefined_value
        else:
            assert isinstance(data, string_types)
            assert data == to_text(undefined_value)

    # test undefined
    undefined = AnsibleUndefined('foo')
    exception = AnsibleUndefinedVarsTemplateError('foo', 'bar')
    _test_

# Generated at 2022-06-23 13:19:02.371076
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(None) is None
    assert ansible_native_concat(()) is None

    val = 'hello'
    assert ansible_native_concat(val) == val

    assert ansible_native_concat([val, '?', 3]) == 'hello?'
    assert ansible_native_concat([val, ' ', val]) == 'hello hello'

    assert ansible_native_concat(map(ast.literal_eval,
                                     ['1', '2', '3'])) == 1
    assert ansible_native_concat(map(ast.literal_eval,
                                     ['1', '2', '"3"'])) == '123'


# TODO: delete this once we no longer need to support Ansible 2.10

# Generated at 2022-06-23 13:19:13.603074
# Unit test for function ansible_native_concat

# Generated at 2022-06-23 13:19:21.529207
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Note that this test is not using unittest framework.

    # Test empty container
    assert ansible_native_concat([]) is None

    # Test a single integer node
    assert ansible_native_concat([42]) == 42

    # Test a single text node
    assert ansible_native_concat(['foo']) == 'foo'

    # Test multiple nodes
    assert ansible_native_concat(['foo', 1, 'bar']) == 'foo1bar'

    # Test nested collections
    nodes = [1, 2, 'a', [3, 4], 'b', {'c': 'c'}, 'd', {'e': ['e']}, 'f']
    assert ansible_native_concat(nodes) == '1a3bcde'

    # Test nested generator

# Generated at 2022-06-23 13:19:31.436638
# Unit test for function ansible_native_concat

# Generated at 2022-06-23 13:19:42.859933
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(["foo", "bar"]) == "foobar"
    assert ansible_native_concat(True) is True
    assert ansible_native_concat({"a": "b"}) == {u"a": u"b"}
    assert ansible_native_concat([{"a": "b"}, {"c": "d"}]) == [{u"a": u"b"}, {u"c": u"d"}]
    # TODO send unvaulted data to literal_eval?
    assert isinstance(ansible_native_concat(AnsibleVaultEncryptedUnicode("foo")), text_type)
    assert isinstance(ansible_native_concat(['foo', AnsibleVaultEncryptedUnicode("bar")]), text_type)

# Generated at 2022-06-23 13:19:54.798090
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert not ansible_native_concat([])
    assert ansible_native_concat([0]) == 0
    assert ansible_native_concat(x for x in [1, 2, 3, 4]) == [1, 2, 3, 4]
    assert ansible_native_concat([5, ' 6 ', b' 7 ', False, 8, True, None, 9]) == '56 789'
    assert ansible_native_concat([10, ' 11 ', 12, '13']) == '10111213'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat([True, False]) == '[True, False]'

# Generated at 2022-06-23 13:20:03.540088
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['1', '2', '3']) == '123'

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, 2, 3]) == '123'

    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([True, False]) == 'TrueFalse'
    assert ansible_native_concat([True, False, True]) == 'TrueFalseTrue'

    assert ansible_native

# Generated at 2022-06-23 13:20:14.325163
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test 1
    assert ansible_native_concat(['one', 'two']) == 'onetwo'
    # Test 2
    assert ansible_native_concat(['1', '2']) == '12'
    # Test 3
    assert ansible_native_concat([1, 2]) == 3
    # Test 4
    assert ansible_native_concat([1, '2']) == '12'
    # Test 5
    assert ansible_native_concat(['1', 2]) == '12'
    # Test 6
    assert ansible_native_concat([['one', 'two'], 'three']) == 'onetwothree'
    # Test 7
    assert ansible_native_concat([[1, 'two'], 'three']) == '1twothree'
    # Test

# Generated at 2022-06-23 13:20:21.480905
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == u'123'
    assert ansible_native_concat([1, 2, 3, True, False, None]) is None
    assert ansible_native_concat([u'foo', u' ', u'bar', u' ', u'baz']) == u'foo bar baz'
    assert ansible_native_concat([u'1', u'2', u'3']) == 123



# Generated at 2022-06-23 13:20:32.726086
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', '', 'bar']) == 'foobar'
    assert ansible_native_concat([0, 'foo']) == '0foo'
    assert ansible_native_concat(['{{a}}', 'bar']) == '{{a}}bar'
    assert ansible_native_concat(['foo', '{{a}}']) == 'foo{{a}}'
    assert ansible_native_concat(['foo', '{%a%}']) == 'foo{%a%}'

# Generated at 2022-06-23 13:20:40.899814
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == u'12'
    assert ansible_native_concat([1, 2, 3]) == u'123'
    assert ansible_native_concat([1, 2, 'a']) == u'12a'
    assert ansible_native_concat([1, u'\u064a']) == u'1\u064a'
    assert ansible_native_concat([1, u'\u064a', 'b']) == u'1\u064ab'
    # This can't be parsed with ast.literal_eval

# Generated at 2022-06-23 13:20:52.806278
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([True, False]) is True
    assert ansible_native_concat(['1', '2', '3', '4']) == [1, 2, 3, 4]
    assert ansible_native_concat([b'1', '2', '3', '4']) == [1, 2, 3, 4]
    assert ansible_native_concat(['1', 2, '3', 4]) == [1, 2, 3, 4]
    assert ansible_native_concat(['1', '2', '3', 4]) == [1, 2, 3, 4]
    assert ansible_native

# Generated at 2022-06-23 13:21:04.472089
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Unit tests for ansible_native_concat"""
    assert ansible_native_concat(u'a') == 'a'
    assert ansible_native_concat(u'"a"') == 'a'
    assert ansible_native_concat([u'a', u'b', u'c']) == 'abc'
    assert ansible_native_concat([u'a', u'b', u'c']) == 'abc'
    assert ansible_native_concat([u'a', u'b', u'3']) == 'ab3'
    assert ansible_native_concat([u'a', u'b', '3']) == 'ab3'
    assert ansible_native_concat([u'a', u'b', 3]) == 'ab3'
    assert ansible_native_

# Generated at 2022-06-23 13:21:15.480883
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2
    from jinja2.runtime import Undefined
    from ansible.module_utils.common.collections import from_yaml
    from ansible.module_utils.common.text.converters import to_bytes, to_text

    # Ensure the function is callable:
    env = jinja2.Environment(extensions=['jinja2.ext.do'])
    env.filters['ansible_native_concat'] = ansible_native_concat
    env.filters['ansible_native_concat2'] = ansible_native_concat
    template = "{{ [1, 'a', '12', None, None, None, u'b'] | ansible_native_concat }}"

# Generated at 2022-06-23 13:21:27.255153
# Unit test for function ansible_native_concat

# Generated at 2022-06-23 13:21:34.614502
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    def test_invalid(data):
        assert isinstance(data, StrictUndefined)
        str(data)

    try:
        ansible_native_concat([]) is None
        ansible_native_concat([u'    ']) is None
        ansible_native_concat([u'']) is None
        ansible_native_concat([u'  \t \t   ']) is None
    except Exception as e:
        raise AssertionError('Concat of empty strings should be empty: %s' % e)

    assert ansible_native_concat([u'   False   ']) is False
    assert ansible_native_concat([u'False  \t\t ']) is False
    assert ansible_native_concat([u'  True  ']) is True
    assert ansible_native

# Generated at 2022-06-23 13:21:45.272071
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat([u'abc']) == u'abc'
    assert ansible_native_concat([u'a', u'b']) == u'ab'
    assert ansible_native_concat([u'a', 1]) == u'a1'
    assert ansible_native_concat([u'a', u'b', u'c']) == u'abc'
    assert ansible_native_concat([u'a', 1, u'c']) == u'a1c'
    assert ansible_native_concat([u'a', None, u'c']) == u'aNonec'
    assert ansible_native_concat([container_to_text(u'a'), u'b', u'c'])

# Generated at 2022-06-23 13:21:51.893667
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(['a', [{}, 'b'], 'c']) == 'abc'
    assert ansible_native_concat(['a', 1, 'b', 'c']) == 'a1bc'
    assert ansible_native_concat(['a', u'\u20ac', 'b', 'c']) == 'a\u20acbc'
    assert ansible_native_concat(['(']) == '('
    assert ansible_native_concat(['[']) == '['

# Generated at 2022-06-23 13:22:01.692286
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert None == ansible_native_concat([])
    assert None == ansible_native_concat([None])
    assert 'test' == ansible_native_concat(['test'])
    assert ['test'] == ansible_native_concat(['[test]'])
    assert 'test' == ansible_native_concat(['t', 'e', 's', 't'])
    assert ['t', 'e', 's', 't'] == ansible_native_concat(['["', 't', '", "', 'e', '", "', 's', '", "', 't', '"]'])

# Generated at 2022-06-23 13:22:12.662594
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat((u'foo', u'bar')) == u'foobar'
    assert ansible_native_concat((u'foo', u'bar', u'baz')) == u'foobarbaz'
    assert ansible_native_concat((u'foo', 'bar', u'baz')) == u'foobarbaz'

    assert ansible_native_concat([container_to_text(u'foo'), u'bar']) == u'foobar'
    assert ansible_native_concat([container_to_text(u'foo'), u'bar', container_to_text(u'baz')]) == u'foobarbaz'
    assert ansible_

# Generated at 2022-06-23 13:22:23.300977
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['1', '2', '3']) == 123
    assert ansible_native_concat(['1.0', '2.0', '3.0']) == 123.0
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['[1, 2, 3]']) == [1, 2, 3]
    assert ansible_native_concat(['true']) is True
    assert ansible_native_concat(['false']) is False
    assert ansible_native_concat(['none']) is None

# Generated at 2022-06-23 13:22:35.841639
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def get_expected(arg):
        if isinstance(arg, list):
            return [get_expected(arg_item) for arg_item in arg]
        elif isinstance(arg, tuple):
            return tuple([get_expected(arg_item) for arg_item in arg])
        elif isinstance(arg, dict):
            return dict([(get_expected(key), get_expected(value))
                         for (key, value) in arg.items()])
        elif isinstance(arg, string_types):
            try:
                return ast.literal_eval(ast.parse(arg, mode='eval'))
            except (ValueError, SyntaxError):
                return arg
        else:
            return arg
