

# Generated at 2022-06-23 13:12:39.054585
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3, 4, 5]) == 12345
    assert ansible_native_concat([1, '2', 3, '4', 5]) == 12345
    assert ansible_native_concat([1, 2, 3, 4, 5]) == 12345
    assert ansible_native_concat([1, '2', '3', 4, 5]) == '12345'
    assert ansible_native_concat([1, '2', '3']) == '123'
    assert ansible_native_concat(['1', 2, '3']) == '123'
    assert ansible_native_concat([1, "2'3"]) == "12'3"

# Generated at 2022-06-23 13:12:50.206215
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # pylint: disable=unused-argument
    from ansible.parsing.yaml.dumper import AnsibleDumper

    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['1', '2']) == '1 2'
    assert ansible_native_concat([1, 2]) == '1 2'
    assert ansible_native_concat([1, 2, 3, 4]) == '1 2 3 4'
    assert ansible_native_concat([1, '2', 3, '4']) == '1 2 3 4'
    assert ansible_native_concat(['1', 2, '3', 4]) == '1 2 3 4'
    assert ansible_native_concat

# Generated at 2022-06-23 13:13:00.059560
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat((1, 2, 3)) == 1
    assert ansible_native_concat(['foo', 1, 'bar']) == 'foobar'
    assert ansible_native_concat(['1', '2', ['3', '4'], '5']) == '12345'
    assert ansible_native_concat('123') == '123'
    assert ansible_native_concat('föö') == u'föö'
    assert ansible_native_concat(1) == 1
    assert ansible_native_concat(['foo', 1, 'bar']) == 'foobar'
    assert ansible_native_concat([1, 2, 3]) == list((1, 2, 3))

# Generated at 2022-06-23 13:13:07.730936
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # ansible_native_concat calls ast.literal_eval(),
    # which in turn calls safe_eval(), which needs this
    # to be present to even run.
    import __builtin__
    setattr(__builtin__, '_', lambda x: x)

    assert None == ansible_native_concat([])
    assert 'banana' == ansible_native_concat(['banana'])
    assert 'banana' == ansible_native_concat(['b', 'a', 'n', 'a', 'n', 'a'])

    assert 42 == ansible_native_concat([42])
    assert -42 == ansible_native_concat([-42])
    assert 3.141592 == ansible_native_concat([3.141592])
    assert True == ansible_

# Generated at 2022-06-23 13:13:13.561465
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Check an empty list yields None
    assert ansible_native_concat([]) is None

    # Check a single string
    assert ansible_native_concat(['foo']) == 'foo'

    # Check a single empty string
    assert ansible_native_concat(['']) == ''

    # Check a single integer
    assert ansible_native_concat([42]) == 42

    # Check a single True boolean
    assert ansible_native_concat([True]) is True

    # Check a single False boolean
    assert ansible_native_concat([False]) is False

    # Check a single True string
    assert ansible_native_concat(['True']) == 'True'

    # Check a single False string
    assert ansible_native_concat(['False']) == 'False'

    # Check a single

# Generated at 2022-06-23 13:13:18.095676
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_native
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(['1']) == '1'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, to_native(2)]) == '12'
    assert ansible_native_concat([1, to_native(2), 3]) == '123'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'

# Generated at 2022-06-23 13:13:28.346409
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    input_data = [1, 2, 3, 4, 5]
    assert ansible_native_concat(input_data) == input_data
    input_data = ['hello', ' ', 'world']
    assert ansible_native_concat(input_data) == 'hello world'
    input_data = ['\'hello', ' ', 'world\'']
    assert ansible_native_concat(input_data) == "'hello world'"
    input_data = ['hello', ' ', 'world']
    assert ansible_native_concat(input_data) == 'hello world'
    input_data = ['  hello', ' ', 'world  ']
    assert ansible_native_concat(input_data) == '  hello world  '
    input_data = ['  hello', ' ', 'world  ']

# Generated at 2022-06-23 13:13:37.924526
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.plugins.filter.core import Result

    assert ansible_native_concat("foo bar") == u"foo bar"
    assert ansible_native_concat("{{ 1 }}") == 1
    assert ansible_native_concat("{{ 1 }} {{ 'foo' }}") == u"1 foo"
    assert ansible_native_concat("{{ 1 |string }}") == u"1"
    assert ansible_native_concat("{{ 1 }}{{ 'foo' }}") == u"1foo"
    assert ansible_native_concat("{{ 1 |d() }}") == 1
    assert ansible_native_concat("{{ 1 |d() }} {{ 'foo' |d() }}") == u"1 foo"
    assert ansible_native_concat("{{ [] }}") == []
    assert ansible_

# Generated at 2022-06-23 13:13:49.061968
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # strings
    assert ansible_native_concat(["foo", "bar"]) == "foobar"
    assert ansible_native_concat(["foo", "123", "bar", "456"]) == "foo123bar456"
    # numbers
    assert ansible_native_concat([123, 456]) == "123456"
    assert ansible_native_concat([123, "foo", 456]) == "123foo456"
    # booleans
    assert ansible_native_concat([True, False]) == "TrueFalse"
    assert ansible_native_concat([True, "foo", False, "bar"]) == "TruefooFalsebar"
    # lists

# Generated at 2022-06-23 13:14:00.777409
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.hashing import secure_hash_s

    v = '$ANSIBLE_VAULT;'

    assert ansible_native_concat([1, 2]) == 12
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', v, 'b']) == 'ab'
    assert ansible_native_concat([v, 'a', 'b']) == 'ab'
    assert ansible_native_concat([v, 'a', 'b', v]) == 'ab'
    assert ansible_native_concat(['a', v, 'b', v]) == 'ab'


# Generated at 2022-06-23 13:14:11.430870
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat(['1']) == '1'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat(['1', 2]) == '12'
    assert ansible_native_concat(['1', 2]) == '12'
    assert ansible_native_concat([1, '2']) == '12'
    assert ansible_native_concat(['1', '2', 3]) == '123'
    assert ansible_native_concat(['1', 2, 3]) == '123'

# Generated at 2022-06-23 13:14:20.120646
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # String
    assert ansible_native_concat(["foo"]) == "foo"

    # Multiple strings
    assert ansible_native_concat(["foo", "bar"]) == "foobar"

    # Concatenated strings can be parsed as a list
    assert ansible_native_concat(["[1,", "2]"]) == [1, 2]

    # Concatenated strings can be parsed as a dictionary
    assert ansible_native_concat(["{'a':1,", "'b':2}"]) == {"a": 1, "b": 2}

    # Concatenated strings can be parsed as a set
    assert ansible_native_concat(["{1,", "2}"]) == {1, 2}

    # Concatenated strings can be parsed as a frozen set


# Generated at 2022-06-23 13:14:23.924243
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    from ansible.utils.native_jinja import text_marker

    # Single value
    assert ansible_native_concat(['a']) == 'a'

    # Single literal
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([0]) == 0
    assert ansible_native_concat([-1]) == -1
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['+1']) == 1
    assert ansible_native_concat(['-1']) == -1
    assert ansible_native_concat(['0']) == 0

# Generated at 2022-06-23 13:14:32.548977
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test normal case
    assert ansible_native_concat([1, 2, 3, 4, 5]) == 12345
    assert ansible_native_concat(['1', '2', '3', '4', '5']) == 12345
    assert ansible_native_concat(['1', '2', '3', '4', '5', '6', 7]) == 1234567
    assert ansible_native_concat(['1.1', '2.2', '3.3', '4.4', '5.5']) == 1.1 + 2.2 + 3.3 + 4.4 + 5.5

# Generated at 2022-06-23 13:14:41.011265
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([u'a']) == u'a'
    assert ansible_native_concat([u'a', u'b']) == u'ab'

    assert ansible_native_concat([u'a', True, u'c']) == u'a True c'
    assert ansible_native_concat([1, u'b', u'c']) == u'1b c'
    assert ansible_native_concat([u'a', u'b', u'c']) == u'abc'

    assert ansible_native_concat([u'a', u'b', u'c', None]) == u'abc None'

# Generated at 2022-06-23 13:14:47.844369
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat([1, 2, '3']) == [1, 2, '3']
    assert ansible_native_concat([1, 2, 3, '4']) == [1, 2, 3, '4']
    assert ansible_native_concat([1, 2, '3', 4]) == [1, 2, '3', 4]
    assert ansible_native_concat(['[', 1, ']']) == [1]
    assert ansible_native_concat([1, '..', 5]) == [1, '..', 5]
    assert ansible_native_concat(['', '', '']) == ''

# Generated at 2022-06-23 13:14:58.604212
# Unit test for function ansible_native_concat

# Generated at 2022-06-23 13:15:09.194462
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2]) == 1
    assert ansible_native_concat([0, 1, 2]) == u'012'
    assert ansible_native_concat([0, u'a']) == u'0a'
    assert ansible_native_concat([u'a', u'b']) == u'ab'
    assert ansible_native_concat([u'1', u'2', u'3']) == u'123'
    assert ansible_native_concat([u'.', u'a', u'b', u'c']) == u'.abc'
    assert ansible_native_concat([u'0123', u'4567', u'89']) == u'0123456789'

# Generated at 2022-06-23 13:15:19.507196
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    a = ansible_native_concat([])
    assert a is None
    a = ansible_native_concat(['123'])
    assert a == 123
    a = ansible_native_concat(['123', '456'])
    assert a == '123456'
    a = ansible_native_concat(['123', '456', '789'])
    assert a == '123456789'
    a = ansible_native_concat(['123', 456, '789'])
    assert a == '123456789'
    a = ansible_native_concat(['123', 456, '789', '0'])
    assert a == '1234567890'
    a = ansible_native_concat(['123', 456, '789', '0', 1])
   

# Generated at 2022-06-23 13:15:25.303257
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_list = [0, 1, 2, 'test', None, {'test': 'test2'}, ['test1', 'test2']]
    for test_item in test_list:
        assert ansible_native_concat([test_item]) == test_item

    assert ansible_native_concat(['test1', 'test2']) == 'test1test2'
    assert ansible_native_concat([2, 3]) == '23'
    assert ansible_native_concat([{'test': 'test2'}, 1]) == '{{test}}1'
    assert ansible_native_concat([['test1', 'test2'], 1]) == 'test1test21'

# Generated at 2022-06-23 13:15:34.357913
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Unit test for function ansible_native_concat"""
    assert container_to_text(ansible_native_concat([None])) == ''
    assert container_to_text(ansible_native_concat([])) is None
    assert ansible_native_concat([NativeJinjaText('"some string"')]) == 'some string'
    assert ansible_native_concat([u'1', u'2', u'3']) == 123
    assert container_to_text(ansible_native_concat([u'1', u'2', u'3'])) == '123'
    assert ansible_native_concat([u'"1"', u'"2"', u'"3"']) == '123'

# Generated at 2022-06-23 13:15:44.957371
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([2.3, 4.5]) == '2345'
    assert ansible_native_concat([2.3, 4.5j]) == '2.34.5j'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([u"1", u"2"]) == '12'
    assert ansible_native_concat([bytes([49]), bytes([50])]) == '12'
    assert ansible_native_concat(['1', 2, b'3', {'foo': 'bar'}]) == '12{foo: bar}'
    assert ansible_native_concat([{'foo': 'bar'}, 2, 3])

# Generated at 2022-06-23 13:15:57.045098
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'a', u'b']) == u'ab'
    assert ansible_native_concat([u'a', 1]) == u'a1'
    assert ansible_native_concat([1, u'a']) == '1a'

    assert ansible_native_concat([u'a \\\n b']) == u'a \\\n b'
    assert ansible_native_concat([u'a \\\n b']) == u'a \\\n b'
    assert ansible_native_concat([u'a', u'\nb']) == u'a\nb'

    assert ansible_native_concat([True, u'a']) == True
    assert ansible_native_concat([u'a', True]) == 'aTrue'


# Generated at 2022-06-23 13:16:07.769727
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class FakeUndefined(StrictUndefined):
        def __unicode__(self):
            return u'FAKE'
        __str__ = __unicode__

    class FakeUndefinedNativeJinja(StrictUndefined):
        def __unicode__(self):
            return u'NFAKE'
        __str__ = __unicode__
        def __call__(self, *args, **kwargs):
            return 'NFAKE'

    # Test normal case
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', '{', 'bar']) == 'foo{bar'

# Generated at 2022-06-23 13:16:16.865656
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # None
    assert ansible_native_concat(None) is None

    # Empty list
    assert ansible_native_concat([]) is None

    # Empty tuple
    assert ansible_native_concat(()) is None

    # Single node with value
    assert ansible_native_concat([u'foo']) == u'foo'

    # Nodes with values
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'

    # Nodes with values and empty values
    assert ansible_native_concat([u'foo', u'bar', None, u'', u'baz']) == u'foobarbaz'

    # Nodes with values and numbers

# Generated at 2022-06-23 13:16:25.726458
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    native_concat = ansible_native_concat
    assert native_concat([]) is None
    assert native_concat([1]) == 1
    assert native_concat([1, 2]) == u'12'
    # literal_eval(string)
    assert native_concat(['True']) is True
    assert native_concat(['False']) is False
    assert native_concat(['None']) is None
    assert native_concat(['1 + 1']) == 2
    assert native_concat(['[1, 2]']) == [1, 2]
    assert native_concat(['{1: 2}']) == {1: 2}
    # literal_eval(unicode)
    assert native_concat([u'True']) is True

# Generated at 2022-06-23 13:16:36.692420
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['1']) == 1

    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['1', '2']) == 12

    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(['1', '2', '3']) == 123

    # https://github.com/ansible/ansible/issues/70831
    assert isinstance(ansible_native_concat(['a', 'b', 'c']), text_type)

# Generated at 2022-06-23 13:16:43.508250
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u"Hello ", u"World"]) == "Hello World"
    assert ansible_native_concat([u"Hello ", u"World!"]) == "Hello World!"
    assert ansible_native_concat([u"Hello ", u"World", u"!"]) == "Hello World!"
    assert ansible_native_concat([u"Hello ", u"World", u"!"]) == "Hello World!"
    assert ansible_native_concat([u"Hello ", u"World", u"!", u" How are you?"]) == "Hello World! How are you?"
    assert ansible_native_concat([u"Hello ", u"World", u"!", u" How are you?", u" I am good"]) == "Hello World! How are you? I am good"
    assert ansible_native_

# Generated at 2022-06-23 13:16:52.383542
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a', 'b']) == u'ab'
    assert ansible_native_concat(['a', 1]) == u'a1'
    assert ansible_native_concat([1, 2]) == 3
    assert ansible_native_concat([1.5, 2.5]) == 4.0
    assert ansible_native_concat([['a'], ['b']]) == [['a', 'b']]
    assert ansible_native_concat([[1.5], [2.5]]) == [1.5, 2.5]

    assert ansible_native_concat(['a', 'b', 'c', 'd']) == u'abcd'

# Generated at 2022-06-23 13:17:02.119853
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([None, None, None]) is None

    assert ansible_native_concat([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert ansible_native_concat([1, 2, 3, 4, None]) == [1, 2, 3, 4, None]

    assert ansible_native_concat(['1', '2', '3', '4']) == [1, 2, 3, 4]
    assert ansible_native_concat(['1', '2', '3', '4', None]) == [1, 2, 3, 4, None]

    assert ansible_native_concat(['1', '2', '3', '4', '5', '6']) == [1, 2, 3, 4, 5, 6]
    assert ans

# Generated at 2022-06-23 13:17:11.136805
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(map(to_text, [1, 2, 3])) == '123'
    assert ansible_native_concat(map(to_text, [1, '2', 'foo'])) == '1 2 foo'
    assert ansible_native_concat(map(to_text, [1, '2', 'foo'])) == '1 2 foo'

    assert ansible_native_concat(map(to_text, [1, 2, 3])) == 123
    assert ansible_native_concat(map(to_text, [1, '2.0', 'foo'])) is None
    assert ansible_native_concat(map(to_text, [1, '2.0', 'foo'])) is None


# Generated at 2022-06-23 13:17:17.418757
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class TestNode(object):
        def __init__(self, value):
            self.value = value

        def __str__(self):
            return container_to_text(self.value)

        __unicode__ = __str__

        def __repr__(self):
            return 'TestNode(%r)' % (self.value,)

    class TestUndefined(object):
        def __repr__(self):
            return 'TestUndefined()'


# Generated at 2022-06-23 13:17:24.915314
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat([1, 'b', 'c']) == 1
    assert ansible_native_concat([]) == None
    assert ansible_native_concat([1, 2, 3]) == 1
    assert ansible_native_concat([[1, 2, 3]]) == [1, 2, 3]
    assert ansible_native_concat([{'a': 'b'}]) == {'a': 'b'}



# Generated at 2022-06-23 13:17:35.077337
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(['a', True, 'c']) == 'aTruec'
    assert ansible_native_concat(['a', '42', 'c']) == 'a42c'
    assert ansible_native_concat(['a', '42', 'c', 'd']) == 'a42cd'
    assert ansible_native_concat(['a', '42', 'c', 42, 'd']) == 'a42c42d'
    assert ansible_native_concat(['a', True, 42, 'd']) == 'aTrue42d'

# Generated at 2022-06-23 13:17:46.658151
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat((x for x in [u'foo', u'bar'])) == u'foobar'
    assert ansible_native_concat([u'foo', 42]) == u'foo42'
    assert ansible_native_concat([42, u'foo']) == u'42foo'
    assert ansible_native_concat([u'foo', 42, u'bar']) == u'foo42bar'
    assert ansible_native_concat([u'foo', 42, u'bar', None]) == u'foo42barNone'


# Generated at 2022-06-23 13:17:53.212345
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(iter([])) is None
    assert ansible_native_concat(iter([1])) == 1
    assert ansible_native_concat(iter(['1'])) == 1
    assert ansible_native_concat(iter(['1', '2'])) == '12'
    assert ansible_native_concat(iter(['True'])) is True
    assert ansible_native_concat(iter(['true'])) == 'true'
    assert ansible_native_concat(iter(['[1, 2]'])) == [1, 2]
    assert ansible_native_concat(iter(['[1, foo]'])) == '[1, foo]'
    assert ansible_native_concat(iter(['[1, foo]'])) == '[1, foo]'


# Generated at 2022-06-23 13:18:02.944654
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat([2, 3]) == u'23'
    assert ansible_native_concat([2, 3, '4']) == u'234'
    assert ansible_native_concat([u'2', 3, '4']) == u'234'
    assert ansible_native_concat(['2', 3, '4']) == u'234'
    assert ansible_native_concat(['a', '1', 2, '3']) == u'a123'
    assert ansible_native_concat(['a', '1', [2, 3], '4']) == u'a[2, 3]4'

# Generated at 2022-06-23 13:18:13.729064
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2.utils import Markup
    from jinja2.runtime import Undefined
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(range(1)) == 0
    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat([b'foo']) == u'foo'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, u'foo', u'bar']) == u'1foobar'
    assert ansible_native_concat([1, u'foo', u'bar', u'baz']) == 123

# Generated at 2022-06-23 13:18:24.264252
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test for function ansible_native_concat"""
    # Expression: "Hello " + "World!"
    assert ansible_native_concat(["Hello ", "World!"]) == "Hello World!"
    # Expression: "Hello " + "World!" + "!"
    assert ansible_native_concat(["Hello ", "World!", "!"]) == "Hello World!!"
    # Expression: True + True + 1
    assert ansible_native_concat([True, True, 1]) == 3
    # Expression: [1, 2] + [3]
    assert ansible_native_concat([[1, 2], [3]]) == [1, 2, 3]
    # Expression: [1, 2] + [3] + [4]

# Generated at 2022-06-23 13:18:33.279392
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Tests if function is working as expected

    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat('1') == 1
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([1, '2', 3]) == "123"
    assert ansible_native_concat(['1', 2, 3]) == "123"
    assert ansible_native_concat([1, '2', '3', '45']) == "12345"
    assert ansible_native_concat(['1', '2', '3', '45', '2345']) == "123452345"


# Generated at 2022-06-23 13:18:43.883114
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test numbers
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat([1, 2, 3, 4]) == 1234
    assert ansible_native_concat([1, 2, 3, 4, 5]) == 12345
    # Test boolean
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([False]) is False
    # Test None
    assert ansible_native_concat([None]) is None
    # Test empty list
    assert ansible_native_concat([]) is None
    # Test empty string
    assert ansible_native_concat([""]) == ""
    # Test string
    assert ansible_native_concat(["foo"]) == "foo"
    # Test multiple strings

# Generated at 2022-06-23 13:18:54.796548
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat([1, u'a', True]) == 1
    assert ansible_native_concat([1, u'a', True]) == 1
    assert ansible_native_concat([u'a', u'b', u'c']) == u'abc'
    assert ansible_native_concat([u'1', u'2.0', u'3']) == 6.0
    assert ansible_native_concat([u'a', u'b', u'c', u'1', u'2.0', u'3']) == u'abc123'
    assert ansible_native_concat([u'a', u'b', u'c']) == u'abc'


# Generated at 2022-06-23 13:19:04.529680
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([object]) is None
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([False]) is False
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1.1]) == 1.1
    assert ansible_native_concat([2.2]) == 2.2
    assert ansible_native_concat([1j]) == 1j
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([u'a']) == u'a'

# Generated at 2022-06-23 13:19:14.585516
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(["foo", "bar"]) == "foobar"
    assert ansible_native_concat(["foo", "bar", "baz"]) == "foobarbaz"
    assert ansible_native_concat(["foo", "bar", 1]) == "foobar1"
    assert ansible_native_concat(["foo", "bar", 1, "baz", 1]) == "foobar1baz1"
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == "12"
    assert ansible_native_concat(["foo", 2]) == "foo2"
    assert ansible_native_concat([2, "foo"]) == "2foo"
    assert ansible_native_concat([])

# Generated at 2022-06-23 13:19:22.319235
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class MyUndef(StrictUndefined):
        def __nonzero__(self):
            raise RuntimeError()

    def identity(value):
        return value

    def fail(value):
        raise Exception()

    class MyText(text_type):
        """Returns original string so we don't invoke Jinja filters"""
        def __new__(cls, text):
            return text_type.__new__(cls, text)

        def __str__(self):
            return self

    STRINGS = [u'foo', u'bar']
    EXPECTED_STRINGS = [u'foobar', u'foobar']

    # basic testing from the strings
    assert ansible_native_concat(STRINGS) == u'foobar'

    # test with a generator expression

# Generated at 2022-06-23 13:19:31.996678
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # no nodes
    assert ansible_native_concat([]) is None

    # single node
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([u'foo']) == 'foo'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1.0]) == 1.0
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([False]) is False
    assert ansible_native_concat(['']) == ''
    assert ansible_native_concat([None]) is None

    # native jinja text
    assert ansible_native_concat(['foo', NativeJinjaText('bar')]) == u'foobar'
    assert ansible_

# Generated at 2022-06-23 13:19:33.129220
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # TODO
    pass

# Generated at 2022-06-23 13:19:43.754926
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.compat.tests import unittest

    class TestCase(unittest.TestCase):

        def test_simple(self):
            self.assertEqual(ansible_native_concat([
                json.dumps(1),
                '2'
            ]), 12)

            self.assertEqual(ansible_native_concat([
                '[1, 2, ',
                '[3, 4]]'
            ]), [1, 2, [3, 4]])

            self.assertEqual(ansible_native_concat([
                '1',
                '2'
            ]), u'12')

            self.assertEqual(ansible_native_concat([
                '1',
                '2'
            ]), container_to_text('12'))

    unittest.main()

# Generated at 2022-06-23 13:19:55.550902
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = [ast.List([ast.Str('a'), ast.Str('b')])]
    assert ansible_native_concat(nodes) == ['a', 'b']
    nodes = [ast.Str('123')]
    assert ansible_native_concat(nodes) == 123
    nodes = [ast.Str('123\n')]
    # In Python 3.10+ ast.literal_eval removes leading spaces/tabs
    # from the given string. For backwards compatibility we need to
    # parse the string ourselves without removing leading spaces/tabs.
    assert ansible_native_concat(nodes) == '123\n'
    nodes = [ast.Str('123\n123')]
    assert ansible_native_concat(nodes) == '123\n123'

# Generated at 2022-06-23 13:20:04.089071
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert ansible_native_concat([1, 2, 3]) is None
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([None, None]) is None

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['a']) == 'a'

    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', 'b', 'c', 'd']) == 'abcd'

    assert ansible_native_concat([1, 'a']) == 11
    assert ansible_native_concat(['a', 1]) == 'a1'

    assert ansible

# Generated at 2022-06-23 13:20:14.698126
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    '''
    These are tests for ansible_native_concat, which tests concatenation
    of various different types. It also tests that AnsibleVaultEncryptedUnicode
    objects will not be evaluated by the ast.literal_eval call.
    '''

    # Test basic concatenation
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat(['hello', ' ', 'world']) == 'hello world'
    assert ansible_native_concat(['{{', 'foo', ' }}']) == '{{ foo }}'
    assert ansible_native_concat(['hey', 1, 'there', ' ', 5, ' ', 'guys']) == 'hey1there 5 guys'
    assert ansible_native_concat(['', '', '', ''])

# Generated at 2022-06-23 13:20:26.931509
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Some tests for backwards compatibility with Jinja 2
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['1']) == '1'
    assert container_to_text(ansible_native_concat([1])) == '1'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat([' 1 ', ' 2 ']) == ' 1  2 '
    assert container_to_text(ansible_native_concat([1, 2])) == '12'
    assert container_to_text(ansible_native_concat([1, 2, 3])) == '123'

    # Test parsing of literals
    assert ansible_native_concat(['true']) == True
    assert ansible_

# Generated at 2022-06-23 13:20:36.628243
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import six

    assert ansible_native_concat(iter([])) is None
    assert ansible_native_concat([]) is None

    assert ansible_native_concat(iter([42])) == 42
    assert ansible_native_concat([42]) == 42

    assert ansible_native_concat(iter(['42'])) == 42
    assert ansible_native_concat(['42']) == 42

    assert ansible_native_concat(iter(['42', ' '])) == '42 '
    assert ansible_native_concat(['42', ' ']) == '42 '

    assert ansible_native_concat(iter(['42', ' 43'])) == '4243'
    assert ansible_native_concat(['42', ' 43']) == '4243'


# Generated at 2022-06-23 13:20:44.011386
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a', 'b']) == ['a', 'b']
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([1, '2', 3]) == '123'
    assert ansible_native_concat(['1', '2', 3]) == ['1', '2', 3]

    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat(['a', 'b']) == ['a', 'b']
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'

    assert ansible_native_

# Generated at 2022-06-23 13:20:54.293378
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test only python3-ish code
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['2.0']) == 2.0
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat(['True']) is True
    assert ansible_native_concat(['true']) == 'true'
    assert ansible_native_concat([False]) is False
    assert ansible_native_concat(['False']) is False
    assert ansible_native_concat(['false']) == 'false'
    assert ansible_native_concat(['val']) == 'val'
   

# Generated at 2022-06-23 13:21:05.341564
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat([2]) == 2
    assert ansible_native_concat([NativeJinjaText('foo')]) == 'foo'
    assert ansible_native_concat([2, 3]) == 23
    assert ansible_native_concat([2, 3, 4]) == 234
    assert ansible_native_concat([2, NativeJinjaText('foo'), 4]) == '2foo4'
    assert ansible_native_concat([2, NativeJinjaText('foo'), 4]) == '2foo4'
    assert ansible_native_concat([2, NativeJinjaText('foo'), 4]) == '2foo4'

# Generated at 2022-06-23 13:21:12.411765
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def strict_undefined(value):
        return StrictUndefined(value)

    values = ['abc', strict_undefined('abc')]

    for value in values:
        nodes = iter([value, value])

        for head in (0, 1, 2):
            if head:
                nodes = chain(islice(nodes, head), nodes)

            assert ansible_native_concat(nodes) == value



# Generated at 2022-06-23 13:21:23.795260
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(["Hello"]) == "Hello"
    assert ansible_native_concat(["1234"]) == 1234
    assert ansible_native_concat(["1234.0"]) == 1234.0
    assert ansible_native_concat(["True"]) is True
    assert ansible_native_concat(["False"]) is False
    assert ansible_native_concat(["None"]) is None
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([0]) == 0
    assert ansible_native_concat([1, "23", 4]) == "1234"
    assert ansible_native_concat(["[1, 2, 3]"]) == [1, 2, 3]
    assert ansible_

# Generated at 2022-06-23 13:21:31.325063
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat([1, 2, '3']) == [1, 2, '3']
    assert ansible_native_concat(['1', '2', '3']) == 123
    assert ansible_native_concat(['1', ' 123', '3']) == '1 1233'
    assert ansible_native_concat(['1', '\n123', '3']) == '1\n1233'
    assert ansible_native_concat(['1', ' ', '3']) == '1 3'
    assert ansible_native_concat(['1', 2, '3']) == '1 23'

# Generated at 2022-06-23 13:21:43.196386
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    fixtures = [
        [None, None, 'NoneNone'],
        [None, True, 'NoneTrue'],
        [None, 10, 'None10'],
        [None, 10.1, 'None10.1'],
        [None, b'bytes', "Noneb'bytes'"],
        [10, 'string', '10string'],
        [1, [2, 3, 4], '[2, 3, 4]'],
        [{'a': 1}, {'a': 1, 'b': 2}, '{\'a\': 1, \'b\': 2}'],
        [True, {'a': 1}, 'True{\'a\': 1}'],
    ]

    for fixture in fixtures:
        res = ansible_native_concat(fixture)

# Generated at 2022-06-23 13:21:55.250429
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    head = [
        u'this is',
        u'a literal',
        u'eval test'
    ]

    assert ansible_native_concat(head) == u'this isa literaleval test'

    tail = [
        u'a literal',
        u'eval test'
    ]
    gen = (x for x in tail)

    res = ansible_native_concat(gen)
    assert isinstance(res, text_type)
    assert res == u'a literaleval test'

    head.append(u'foo: bar')
    res = ansible_native_concat(head)
    assert res == u'this isa literaleval testfoo: bar'

    try:
        ast.literal_eval(res)
        assert False
    except SyntaxError:
        assert True


# Generated at 2022-06-23 13:22:07.008905
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == 1
    assert ansible_native_concat([1, 2, 3, 4]) == u"1234"
    assert ansible_native_concat([1, 2, "3", 4]) == u"1234"
    assert ansible_native_concat([1, 2, "a", 4]) == u"12a4"
    assert ansible_native_concat([1, 2, "a", 4]) == u"12a4"

    # Test with a generator
    generator = (c for c in [1, 2, "a", 4])
    assert ansible_native_concat(generator) == u"12a4"

    # Test unicode

# Generated at 2022-06-23 13:22:19.280012
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def check(expected, *args):
        assert expected == ansible_native_concat(args)

    check('abc', b'abc')
    check(b'abc', b'abc')
    check('a\nb', 'a', '\n', b'b')
    check('ab', 'a', b'b')
    check(b'a\nb', b'a', b'\n', b'b')
    check(b'ab', b'a', b'b')
    check('a', 'a')
    check('a', 'a', '', '', '', '')
    check('a', '', 'a', '', '', '')
    check(b'abcd', b'abcd')
    check(b'abcd', b'a', b'b', b'c', b'd')


# Generated at 2022-06-23 13:22:30.884061
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    assert ansible_native_concat(['foo']) == 'foo'

    assert ansible_native_concat(['foo', 'bar']) == 'foobar'

    assert ansible_native_concat(['foo', '', 'bar']) == 'foobar'

    assert ansible_native_concat(['', 'foo', '']) == 'foo'

    assert ansible_native_concat(['1']) == 1

    assert ansible_native_concat(['1', '2', '3']) == 123

    assert ansible_native_concat(['False', 'True']) is False

    assert ansible_native_concat(['None']) is None
