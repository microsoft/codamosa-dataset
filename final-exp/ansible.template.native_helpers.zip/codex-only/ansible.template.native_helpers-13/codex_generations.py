

# Generated at 2022-06-23 13:12:38.582321
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.dataloader import DataLoader

    test_data = '''
    -
      n1: 123
      n2: '123'
      n3: "123"
      n4: yes
      n5: True
      n6: on
      n7: ON
      n8: True
      n9: True
      n10: False
      n11: null
      n12: 'null'
      n13: "null"
      n14: 'yes'
      n15: "yes"
      n16: '1'
      n17: "2"
      n18: 1
      n19: 2
      n20: "foo"
    '''

    loader = DataLoader()

    data = loader.load(test_data)

    # Test that native concat works with valid

# Generated at 2022-06-23 13:12:50.113450
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test valid concatenation
    assert ansible_native_concat([1, '2', 3]) == 123
    assert ansible_native_concat([1, 'two', 3]) == '1two3'
    d = dict(a=1, b=2)
    assert ansible_native_concat([1, 'two', 3, d, 'five', 6]) == '1two3' + container_to_text(d) + 'five6'
    assert ansible_native_concat([u'\u00a7']) == u'\u00a7'
    assert ansible_native_concat([text_type(1)]) == text_type(1)

    # Test invalid concatenation

# Generated at 2022-06-23 13:13:00.026721
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """
    Test ansible_native_concat function
    """
    # Test string concatenation
    assert ansible_native_concat((x for x in ['foo', 'bar'])) == 'foobar'

    # Test integer concatenation
    assert ansible_native_concat((x for x in [1, 2])) == 3

    # Test integer and string concatenation
    assert ansible_native_concat((x for x in [1, 'bar'])) == '1bar'

    # Test string parsing with ast.literal_eval
    assert ansible_native_concat((x for x in ['foo', 'bar', 'test'])) == 'foobarTest'

    # Test list creation
    assert ansible_native_concat((x for x in [[1], 2])) == [1, 2]

    #

# Generated at 2022-06-23 13:13:07.729819
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def static(node):
        return static_list([node])

    def static_list(nodes):
        return tuple(nodes)
        # Note: This breaks test_fail_on_undefined

    class FakeNode(object):
        def __init__(self, data):
            self.data = data

        def __add__(self, other):
            return FakeNode(to_text(self.data) + to_text(other.data))

    assert ansible_native_concat([]) is None

    assert ansible_native_concat(static(FakeNode(42))) == 42

    assert ansible_native_concat(static(FakeNode('"ab"'))) == "ab"

    assert ansible_native_concat(static(FakeNode('u"ab"'))) == "ab"

    assert ansible_native_

# Generated at 2022-06-23 13:13:13.540781
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat(['foo']) == u'foo'
    assert ansible_native_concat([42, 69]) == 42
    assert ansible_native_concat([1, True, 2, False]) == 1
    assert ansible_native_concat([u'foo', True]) == u'foo'
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([u'foo', u'bar', u' baz']) == u'foobar baz'
    assert ansible_native_concat([u'foo', u'bar', ' baz']) == u

# Generated at 2022-06-23 13:13:21.608250
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils import common
    import ansible.module_utils.common.text.converters as ansible_converters
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.utils.vars import combine_vars

    if common.HAS_IPADDRESS:
        IPV4_ADDRESS = '192.168.1.1'
        IPV4_NETWORK = '192.168.1.1/24'
        IPV4_NETWORK_WITH_PREFIX = '192.168.1.1/24'
    else:
        IPV4_ADDRESS = '255.255.255.255'

# Generated at 2022-06-23 13:13:30.176662
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Tests the concatenation of values by `ansible_native_concat`.
    """
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', 1]) == 'a1'
    assert ansible_native_concat(['a', ['b']]) == 'a[u\'b\']'
    # this test does not work with python 3.7
    # assert ansible_native_concat(['a', 1, ['b']]) == 'a1[u\'b\']'
    assert ansible_native_concat

# Generated at 2022-06-23 13:13:39.765573
# Unit test for function ansible_native_concat

# Generated at 2022-06-23 13:13:49.563834
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # pylint: disable=unused-variable
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat(["1"]) == '1'
    assert ansible_native_concat(["1", "2", "3"]) == '123'
    assert ansible_native_concat(["1", 2]) == '12'
    assert ansible_native_concat([['1'], 2]) == ['1', 2]
    assert ansible_native_concat(["1", ["2"]]) == '12'
    assert ansible_native_concat([['1'], ['2']]) == ['1', '2']

# Generated at 2022-06-23 13:14:01.127018
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2.runtime import Undefined

    assert 'str' == ansible_native_concat(['str'])
    assert 'str' == ansible_native_concat(['s', 't', 'r'])
    assert 'str' == ansible_native_concat(iter(['s', 't', 'r']))

    assert 12 == ansible_native_concat(['12'])
    assert 12 == ansible_native_concat(['1', '2'])

    # Python 3.8+ only:
    #   https://docs.python.org/3/whatsnew/3.8.html#ast-literal-eval-now-also-supports-bytes-and-sets
    # This feature is not used by Ansible (yet)
    # assert b'bytes' == ansible_native

# Generated at 2022-06-23 13:14:11.669688
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader

    templar = Templar(loader=AnsibleLoader(None, None), variables={'var': 'var'})

    # Test empty list
    text = templar.template([], fail_on_undefined=True)
    assert text == None

    # Test list with one item
    text = templar.template(['{{ var }}'], fail_on_undefined=True)
    assert text == 'var'

    # Test list with two item, should be concatenated
    text = templar.template(['{{ var }}', '{{ var }}'], fail_on_undefined=True)
    assert text == 'varvar'

    # Test literal_eval

# Generated at 2022-06-23 13:14:20.264353
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test 1 - simple string concatenation
    assert ansible_native_concat([u'first', u' ', u'second', u' ', u'third']) == u'first second third'

    # Test 2 - single quoted string concatenation
    assert ansible_native_concat([u'single quote \'']) == u'single quote \''

    # Test 3 - double quoted string concatenation
    assert ansible_native_concat([u'double quoted string \"']) == u'double quoted string "'

    # Test 4 - backslash escaped single quote string concatenation
    assert ansible_native_concat([u'backslash escaped single quote \'', '\\', u'backslash escaped single quote \'']) == u'backslash escaped single quote \'\\backslash escaped single quote \''

    # Test 5

# Generated at 2022-06-23 13:14:31.105668
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test for case where the result is a single node, its value is returned
    assert ansible_native_concat([1]) == 1

    # Test for case where the nodes are concatenated as strings, the parsed value is returned
    assert ansible_native_concat([1, 2, 3]) == container_to_text([1, 2]), 'Expected text: %s' % container_to_text([1, 2])

    # Test for case where the nodes are concatenated as strings, the string is returned
    assert ansible_native_concat(['foo', 'bar']) == 'foobar', 'Expected foo bar'

    # Test for case where the nodes are NativeJinjaText, the string is returned

# Generated at 2022-06-23 13:14:40.289100
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Basic sanity test - just make sure we get the right type back
    assert isinstance(ansible_native_concat([1, 2]), int)
    assert isinstance(ansible_native_concat(["1", "2"]), text_type)
    assert isinstance(ansible_native_concat(["1", "2"]), text_type)
    assert isinstance(ansible_native_concat([["1", "2"]]), list)
    assert isinstance(ansible_native_concat([1, [1, 2]]), list)
    assert isinstance(ansible_native_concat([1, "1", [1, 2]]), list)
    assert isinstance(ansible_native_concat([1, "1", [1, "2"]]), list)

    # Should get a text_type for a single

# Generated at 2022-06-23 13:14:48.555709
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(["foo", "bar"]) == "foobar"
    assert ansible_native_concat(["\"", "foo", "\""]) == "\"foo\""
    assert ansible_native_concat(["({", "\"", "foo", "}"]) == "({\"foo}"
    assert ansible_native_concat(["(1, 2, '", "foo", "'))"]) == "(1, 2, 'foo')"
    assert ansible_native_concat(["1 + 2 - 3 * 2 == ", "-1"]) == "1 + 2 - 3 * 2 == -1"

# Generated at 2022-06-23 13:14:59.226140
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['test']) == 'test'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1.1]) == 1.1
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([False]) is False
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([[]]) == []
    assert ansible_native_concat([[1, 2, 3]]) == [1, 2, 3]
    assert ansible_native_concat([{}]) == {}

# Generated at 2022-06-23 13:15:02.956521
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import pytest
    nodes = [
        'a',
        'bc',
        'def',
    ]
    expected = 'abcdef'
    actual = ansible_native_concat(nodes)
    assert actual == expected



# Generated at 2022-06-23 13:15:09.649155
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """
    Currently there is no way to test native type processing within Jinja
    templates with Ansible.
    This function allows us to unit-test the native type processing without
    the context of Jinja.

    This could be extended to properly test list/dict/int/float processing
    within Jinja as well.
    """

    import sys
    import copy
    import six

    from ansible.errors import AnsibleError
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence

    def _mock_ansible_native_type(data):
        try:
            return ansible_native_concat(ast.literal_eval(data))
        except (ValueError, SyntaxError, MemoryError):
            return ast.literal_eval(u"'{}'".format(data))

   

# Generated at 2022-06-23 13:15:19.838960
# Unit test for function ansible_native_concat

# Generated at 2022-06-23 13:15:29.247678
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test string concatenation
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat([1, 'b']) == '1b'
    assert ansible_native_concat([1, 'b', 2]) == '1b2'

    # Test variables
    assert isinstance(ansible_native_concat([1]), int)
    assert isinstance(ansible_native_concat(['abc']), NativeJinjaText)

    # Test literal parsing
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['1.0']) == 1.0
    assert ansible_native_

# Generated at 2022-06-23 13:15:36.339818
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['abc']) == 'abc'
    assert ansible_native_concat([u'abc']) == u'abc'
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([1, '2', 3]) == '123'
    assert ansible_native_concat([1, u'2', 3]) == u'123'
    assert ansible_native_concat(['{', 'a: 1', '}']) == "{'a': 1}"

# Generated at 2022-06-23 13:15:45.778161
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(('a', 'b')) == 'ab'
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat('a') == 'a'
    assert ansible_native_concat(1) == 1
    assert ansible_native_concat(None) is None
    assert ansible_native_concat({}) == {}
    assert ansible_native_concat([{}]) == {}
    assert ansible_native_concat((iter(['a', 'b']),)) == 'ab'  # generator

    # literal_eval

# Generated at 2022-06-23 13:15:57.183715
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Concatenating items that can be converted to a parseable literal
    assert ansible_native_concat(['1', '.', '41']) == 1.41
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(['[', '1', ',' , '2' , ']']) == [1, 2]
    assert ansible_native_concat(['1', 'E', '12']) == 1e12
    assert ansible_native_concat(['1.1', 'E-', '2']) == 1.1e-2
    assert ansible_native_concat(['1', '+', '1j']) == 1 + 1j

    # Concatenating items that cannot be converted to a parseable literal

# Generated at 2022-06-23 13:16:05.680231
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import pytest
    from ansible.module_utils.common.collections import is_sequence

    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([]).__class__.__name__ == 'NoneType'

    assert ansible_native_concat([1.0, 2.0]) == 3.0
    assert ansible_native_concat([1, 2]) == 3
    assert isinstance(ansible_native_concat([1, 2]), int)
    assert ansible_native_concat([0, 2]) == 2

    assert ansible_native_concat([True, True]) == True

# Generated at 2022-06-23 13:16:11.342912
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['string']) == 'string'
    assert ansible_native_concat(['x', 'y', 'z']) == 'xyz'

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat(['1', 2]) == '12'

    assert ansible_native_concat([[1], [2], [3]]) == [1, 2, 3]
    assert ansible_native_concat([[1], 2, [3]]) == '[1]23'

    assert ansible_native_concat([{'x': 1}]) == {'x': 1}
    assert ansible_native

# Generated at 2022-06-23 13:16:18.562181
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2]) == 1
    assert ansible_native_concat([3]) == 3
    assert ansible_native_concat(iter([1, 2])) == 1
    assert ansible_native_concat(iter([3])) == 3
    assert ansible_native_concat(iter([1, 2, 3])) == u'123'
    assert ansible_native_concat(iter([3, 4, '5'])) == 345
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([u'foo', u'bar', u'buz']) == u'foobarbuz'

# Generated at 2022-06-23 13:16:25.810527
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat(['a', 1, 2, 3]) == 'a123'
    assert ansible_native_concat(['a', 1, 2, {'a':3,'b':4}, [3, 4]]) == 'a123{a: 3, b: 4}[3, 4]'
    assert ansible_native_concat([
        [1, 2],
        [3, 4],
        [5, 6],
        {'a':1,'b':2},
        [3, 4]
    ]) == [1, 2, 3, 4, 5, 6, {'a':1,'b':2}, [3, 4]]

# Generated at 2022-06-23 13:16:36.771843
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat((1, 2, 3)) == [1, 2, 3]

    assert ansible_native_concat(['1', '2', '3']) == [1, 2, 3]
    assert ansible_native_concat('1,2,3') == '1,2,3'
    assert ansible_native_concat(['1,', '2']) == '1,2'
    assert ansible_native_concat(['(1,', '2)']) == '(1, 2)'

    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a']) != '"a"'
    assert ansible_

# Generated at 2022-06-23 13:16:43.520541
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1

    assert ansible_native_concat([u'abc']) == u'abc'
    assert ansible_native_concat([u'"abc"']) == u'"abc"'
    assert ansible_native_concat([u'1']) == 1
    assert ansible_native_concat([u'-1']) == -1
    assert ansible_native_concat([u'1.2']) == 1.2
    assert ansible_native_concat([u'{"a": "b"}']) == {"a": "b"}
    assert ansible_native_concat([u'[1, 2, 3]']) == [1, 2, 3]

# Generated at 2022-06-23 13:16:52.413675
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2.sandbox import SandboxedEnvironment

    env = SandboxedEnvironment()
    template = env.from_string('{{ [1] + [2, 3] | list }}')
    assert template.render() == '[1, 2, 3]'

    template = env.from_string('{{ 1 + 2 + 3 }}')
    assert template.render() == '6'

    template = env.from_string('{{ [1 + 2, 3] }}')
    assert template.render() == '[3, 3]'

    template = env.from_string('{{ (1 + 2, 3) }}')
    assert template.render() == '(3, 3)'

    template = env.from_string('{{ [1 + 2, 3] | join(",") }}')
    assert template.render() == '3,3'


# Generated at 2022-06-23 13:17:02.119865
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class FakeStrictUndefined:
        def __str__(self):
            raise StrictUndefined('')

# Generated at 2022-06-23 13:17:11.137776
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat([u'a', u'b']) == u'ab'
    assert ansible_native_concat(['a', 1]) == 'a1'
    assert ansible_native_concat([{'a': 'b'}, 'c']) == {'a': 'b'}
    assert ansible_native_concat(['a', {'b': 'c'}]) == {'b': 'c'}
    assert ansible_native_concat(['a', {'b': 'c'}, 'd']) == 'ad'
    assert ansible

# Generated at 2022-06-23 13:17:19.959387
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader


# Generated at 2022-06-23 13:17:29.571441
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(['a', ' ', 'c']) == 'a c'
    assert ansible_native_concat([1, ' ', 3]) == 4
    assert ansible_native_concat([1, ' ', 3]) == 4

    assert container_to_text(ansible_native_concat(['a', 'b'])) == 'a b'

# Generated at 2022-06-23 13:17:37.040154
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # There are two cases for one node since Jinja2 can return a node
    # or its value.
    class DummyNode:
        def __init__(self, val):
            self.value = val

    # String cases.
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([u'a']) == u'a'
    assert ansible_native_concat([DummyNode(u'a')]) == u'a'
    assert ansible_native_concat([u'a', u'b', u'c']) == u'abc'
    assert ansible_native_concat([u'a', DummyNode(u'b'), u'c']) == u'abc'

    # Literal cases.

# Generated at 2022-06-23 13:17:47.976756
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, 'b']) == '1b'
    assert ansible_native_concat(['a', 2]) == 'a2'
    assert ansible_native_concat([1, 2, 3, 4]) == '1234'
    assert ansible_native_concat({'x': 'y'}) == {'x': 'y'}
    assert ansible_native_concat(['1', '2']) == [1, 2]

# Generated at 2022-06-23 13:17:59.384583
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat(['42']) == 42
    assert ansible_native_concat(['[42]']) == [42]
    assert ansible_native_concat(['{42}']) == {42}
    assert ansible_native_concat(['foo', 42]) == 'foo42'

    from ansible.module_utils.common.text.converters import to_native
    assert ansible_native_concat([u"{{'a': 'b'}}"]) == to_native({'a': 'b'})
    assert ansible_native_concat([u"{{(1,2,3)}}"]) == to_

# Generated at 2022-06-23 13:18:07.790125
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Literal tests
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', ' bar']) == 'foo bar'
    assert ansible_native_concat(['foo', '2']) == 'foo2'
    assert ansible_native_concat(['foo', '1', '2', '3']) == 'foo123'
    assert ansible_native_concat([]) is None

    # Numeric tests
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['1', '2']) == 12
    assert ansible_native_concat(['1', '0', '1']) == 101

    # Container tests

# Generated at 2022-06-23 13:18:13.941439
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(["a", "b", "c"]) == "abc"
    assert ansible_native_concat(["1", "2", 3]) == 123

    assert ansible_native_concat([
        "a",
        b"b",
        None,
        {"a": 1, "b": 2},
        [1, 2, 3],
    ]) == "['a', b'b', None, {'a': 1, 'b': 2}, [1, 2, 3]]"

    assert ansible_native_concat(["1", "2", {"a": 1, "b": 2}, None]) == "1[2]2None"

    assert ansible_native_concat(["1", {"a": 1}, "2"]) == "[1, {'a': 1}, 2]"


# Generated at 2022-06-23 13:18:24.624457
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.native import NativeJinjaText

    def native_text(text):
        return NativeJinjaText(text)

    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1

# Generated at 2022-06-23 13:18:33.874864
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Python 2.6-2.7
    # noinspection PyUnresolvedReferences
    from ansible.module_utils.common.text.converters import to_bytes

    # Python 3+
    # noinspection PyShadowingBuiltins
    from ansible.module_utils.common.text.converters import to_bytes as to_text

    # Python 2.6-3.5
    # noinspection PyUnresolvedReferences
    from ansible.module_utils.six import PY3

    assert ansible_native_concat(range(3)) == '012'

    assert ansible_native_concat(range(1)) == 0

    assert ansible_native_concat([0, 1]) == [0, 1]

    foo = {'test': 'value'}
    assert ansible_native_con

# Generated at 2022-06-23 13:18:44.018303
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(map(container_to_text, [1, 2, 3])) == "123"
    assert ansible_native_concat([1, 2, 3]) == "123"
    assert ansible_native_concat(map(container_to_text, ["a", 2, None])) == u'a2None'
    assert ansible_native_concat(["a", 2, None]) == u'a2None'
    assert ansible_native_concat(map(container_to_text, ["1", 2, "3"])) == 6
    assert ansible_native_concat(["1", 2, "3"]) == 6

    # The following assertion is true in Python2.7

# Generated at 2022-06-23 13:18:55.070134
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    f = ansible_native_concat
    assert f([]) is None
    assert f([1]) == 1
    assert f([1, 2]) == 1
    assert f(['a', 'b']) == u'ab'
    assert f([1, 'a']) == u'1a'
    assert f([True, False]) is True
    assert f(['a', 'b', 'c']) == u'abc'
    assert f(['a', u'\u1234']) == u'a\u1234'
    assert f([True]) is True
    assert f(['1']) == u'1'
    assert f(['1', '2']) == 1
    assert f(['1', '2', '3']) == u'123'

# Generated at 2022-06-23 13:19:02.579069
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def t(expected, *nodes):
        assert expected == ansible_native_concat(nodes)

    # Try various cases of concatenation
    t('a', 'a')
    t('ab', 'a', 'b')
    t('abc', 'a', 'b', 'c')

    # Eval should occur
    t(1, '1')
    t(1.0, '1.0')
    t({'a': 1}, "{'a': 1}")

    # Leading spaces should not be removed
    t(' a', ' ', 'a')
    t('a ', 'a', ' ')

    # Use a generator
    def gen_nodes():
        yield 'a'
        yield 'b'
        yield 'c'
    t('abc', gen_nodes())

    # NativeJinjaText

# Generated at 2022-06-23 13:19:13.756682
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([to_text('foo')]) == 'foo'
    assert ansible_native_concat([to_text('foo'), to_text('bar')]) == 'foobar'
    assert ansible_native_concat([to_text('foo', errors='surrogate_or_strict'), to_text('bar')]) == 'foobar'
    assert ansible_native_concat([to_text(u'f\N{LATIN SMALL LETTER U WITH DIAERESIS}'), to_text('bar')]) == u'f\xfcbar'

# Generated at 2022-06-23 13:19:21.672440
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == container_to_text(['foo', 'bar'])
    assert ansible_native_concat('foobar') == 'foobar'
    assert ansible_native_concat(42) == 42
    assert ansible_native_concat([u'foo', 42]) == container_to_text(['foo', 42])
    assert ansible_native_concat([u'foo', 'bar']) == container_to_text(['foo', 'bar'])
    assert ansible_native_concat([42, 'foo']) == container_to_text([42, 'foo'])
    assert ansible_native_concat([42, 42]) == container_to_text([42, 42])

# Generated at 2022-06-23 13:19:31.547606
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(["1"]) == "1"
    assert ansible_native_concat(["1", "2"]) == "12"
    assert ansible_native_concat(["1", 2, "3"]) == "123"
    assert ansible_native_concat([True, "2", False]) == "True2False"
    assert ansible_native_concat(["True", "2", "False"]) == "True2False"
    assert ansible_native_concat([{"x": "1"}, {"y": "2"}]) == "{'x': '1'}{'y': '2'}"

# Generated at 2022-06-23 13:19:42.934178
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, " + ", 2]) == 1 + 2
    assert ansible_native_concat([1, " + ", 1.0]) == 1 + 1.0
    assert ansible_native_concat([1, " + ", 1]) == 1 + 1
    assert ansible_native_concat([1, " + ", 1, " + ", 1, " + ", 1]) == 4
    assert ansible_native_concat([1, " + ", 1, " + ", 1, " + ", 1,
                                  " + ", 1.0]) == 5.0
    assert ansible_native_concat([1, " + ", 1, " + ", 1, " + ", 1,
                                  " + ", 1.0, " + ", 1]) == 6.0


# Generated at 2022-06-23 13:19:54.896309
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    ast_literal_eval_str = [
        # Valid
        u'foobar',
        u'"foobar"',
        u'False',
        u'True',
        u'None',
        u'u"foobar"',
        u'b"foobar"',
        u'{"foo": "foobar"}',
        u'{"foo": [1, 2, 3]}',
    ]

# Generated at 2022-06-23 13:20:03.938401
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat([(1, 2), (3, 4), (5, 6)]) == [(1, 2), (3, 4), (5, 6)]
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([1, 'foo']) == '1foo'
    assert ansible_native_concat([1, [2, 3]]) == '[2, 3]'
    assert ansible_native_concat([1, (2, 3)]) == '(2, 3)'

# Generated at 2022-06-23 13:20:14.579528
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # test_concatenate_boolean
    assert ansible_native_concat([True, True]) == True
    assert ansible_native_concat([True, False, True]) == False
    assert ansible_native_concat([True, False, True, False]) == False

    # test_concatenate_integer
    assert ansible_native_concat([1, 2]) == 12
    assert ansible_native_concat([1, 2, 3]) == 123

    # test_concatenate_float

# Generated at 2022-06-23 13:20:26.610913
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(('foo',)) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(('foo', 'bar')) == 'foobar'
    assert ansible_native_concat(['foo', 'bar', 'baz']) == 'foobarbaz'
    assert ansible_native_concat(('foo', 'bar', 'baz')) == 'foobarbaz'
    assert ansible_native_concat(['foo', 1, 'bar', 2, 'baz']) == 'foo1bar2baz'
    assert ansible_native_con

# Generated at 2022-06-23 13:20:36.455203
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import nodes

    assert ansible_native_concat(
        [nodes.Const([]),
         nodes.Const({'baz': 'bar'}),
         nodes.Const('\n'),
         nodes.Const(u'foo'),
         nodes.Const('\n')]
    ) == u'[]\n{\'baz\': \'bar\'}\nfoo\n'

    assert ansible_native_concat([nodes.Const('foo')]) == u'foo'
    assert ansible_native_concat([nodes.Const(None)]) is None
    assert ansible_native_concat([nodes.Const(42)]) == 42
    assert ansible_native_concat([nodes.Const([1, 2, 3])]) == [1, 2, 3]
    assert ansible

# Generated at 2022-06-23 13:20:40.972712
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['a string']) == 'a string'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat(['[', '1', ', 2]']) == [1, 2]



# Generated at 2022-06-23 13:20:52.809374
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text import to_bytes

    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['abc']) == 'abc'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1.0]) == 1.0
    assert ansible_native_concat([[1, 2]]) == [1, 2]
    assert ansible_native_concat(['abc', 'def']) == 'abcdef'
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1.0, 2.0]) == '1.02.0'

# Generated at 2022-06-23 13:21:04.472640
# Unit test for function ansible_native_concat

# Generated at 2022-06-23 13:21:15.442884
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == 1
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(["a", 2, 3]) == "a23"
    assert ansible_native_concat(["a", 2, 3]) == "a23"
    assert ansible_native_concat(["a"]) == "a"
    assert ansible_native_concat(["'", "b"]) == "'b"
    assert ansible_native_concat([1, 2]) == 12
    assert ansible_native_concat([1, "'2"]) == "1'2"
    assert ansible_native_concat([1, "'2"]) == "1'2"
   

# Generated at 2022-06-23 13:21:27.215807
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['abc']) == 'abc'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat(['1', 2, '3']) == '123'
    assert ansible_native_concat(['1', 2, 3, 4]) == '1234'
    assert ansible_native_concat([1, 2, '3', 4]) == '1234'
    assert ansible_native_concat(['1', 2, 3, 4]) == '1234'

# Generated at 2022-06-23 13:21:34.181781
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import Environment

    env = Environment(extensions=['jinja2.ext.nativetypes'])
    tmpl = env.from_string(
        '{{ 1 + 1 }}'
        '{{ "a" ~ "b" }}'
        '{{ "c" + "d" }}'
        '{{ "e" | string }}'
        '{{ ["a", "b"] }}'
        '{{ {"a": 1, "b": 2} }}'
        '{{ None }}'
    )

    out = tmpl.render()
    assert out == u'2abcd[u\'a\', u\'b\']{u\'a\': 1, u\'b\': 2}None'



# Generated at 2022-06-23 13:21:45.210543
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def _test_node(node):
        return ansible_native_concat(node)

    assert _test_node([]) is None

    assert _test_node(['foo']) == 'foo'
    assert _test_node(['foo', 'bar']) == 'foobar'

    # TODO: unvault
    assert isinstance(_test_node(['foo', AnsibleVaultEncryptedUnicode('bar')]), AnsibleVaultEncryptedUnicode)

    assert _test_node(['foo', ' bar']) == 'foo bar'

    assert _test_node(['foo', '\n', 'bar']) == 'foo\nbar'

    assert _test_node(['foo', '\n', ' ']) == 'foo\n '


# Generated at 2022-06-23 13:21:56.612201
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([u'f\xf6\xf6']) == u'f\xf6\xf6'
    assert ansible_native_concat([123]) == 123
    assert ansible_native_concat([u'f\xf6\xf6', 'bar']) == u'f\xf6\xf6bar'
    assert ansible_native_concat([True, False]) == True
    assert ansible_native_concat([True, None, False]) == 'TrueNoneFalse'
    assert ansible_native_concat([True, None, False, 1]) == 'TrueNoneFalse1'

# Generated at 2022-06-23 13:22:08.531155
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(list(map(NativeJinjaText, ["a", "b"]))) == u'ab'
    assert ansible_native_concat(list(map(NativeJinjaText, ["[a, b", "c]"]))) == [u'a', u'b', u'c']
    assert ansible_native_concat([u"a", u"b"]) == u'ab'
    assert ansible_native_concat([u"a", u"b", u"c"]) == u'abc'
    assert ansible_native_concat(["a", "b"]) == u'ab'
    assert ansible_native_concat(["a", "b", "c"]) == u'abc'

# Generated at 2022-06-23 13:22:20.448202
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """
    Test the ansible_native_concat function.
    """
    from jinja2 import contextfunction, Environment
    from jinja2.runtime import CallableUndefined

    env = Environment(undefined=CallableUndefined(ansible_native_concat))
    env.globals['f'] = lambda node: contextfunction(lambda c: node)
    env.globals['c'] = contextfunction(_fail_on_undefined)


# Generated at 2022-06-23 13:22:32.847892
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Test function
    import ansible_collections.ansible.community.tests.unit.compat.mock as mock
    import copy
    import sys
    from collections import OrderedDict

    class TestJinjaText(NativeJinjaText):
        def __repr__(self):
            return 'TestJinjaText(%s)' % repr(self.data)

    class TestVaultEncryptedUnicode(AnsibleVaultEncryptedUnicode):
        def __repr__(self):
            return 'TestVaultEncryptedUnicode(%s)' % repr(self.data)
