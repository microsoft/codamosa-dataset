

# Generated at 2022-06-23 13:12:39.403056
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def _make_node(value):
        return StrictUndefined(value)

    assert ansible_native_concat([]) is None
    assert ansible_native_concat([_make_node('a')]) == 'a'
    assert ansible_native_concat([_make_node('1')]) == 1
    assert ansible_native_concat([_make_node({'a': 1})]) == {'a': 1}
    assert ansible_native_concat([_make_node([1, 2])]) == [1, 2]
    assert ansible_native_concat([_make_node(['a', 'b'])]) == 'ab'
    assert ansible_native_concat([_make_node('{a: 1}')]) == '{a: 1}'
    assert ansible_native

# Generated at 2022-06-23 13:12:50.248953
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([1, 2]) == u'12'
    assert ansible_native_concat([[1, 2], [3, 4]]) == u'[1, 2][3, 4]'
    assert ansible_native_concat([[1, 2], 3, 4]) == u'[1, 2]34'
    assert ansible_native_concat([1, [2, [3, 4]]]) == u'1[2, [3, 4]]'
    assert ansible_native_concat([1, [2, 3], 4])

# Generated at 2022-06-23 13:12:55.734604
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from .test.common_test_jinja import TestJinjaMixin
    from ansible.module_utils.common.text.converters import to_text, to_native

    assert TestJinjaMixin.test_ansible_native_concat(
        ansible_native_concat, to_text, to_native, container_to_text
    )

# Generated at 2022-06-23 13:13:05.914125
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.playbook.play_context import PlayContext

    pc = PlayContext()
    pc.configure_from_dict(
        {
            'ansible_python_interpreter': '/usr/bin/env python',
            'ansible_python_version': (3, 8),
        }
    )

    # test no check_all
    output = ansible_native_concat([1, 2, 'a', 'b'])
    assert output == 1

    # test concatenation
    output = ansible_native_concat([1, 2, 'a', 'b'], check_all=True)
    assert output == '12ab'

    # test literal_eval
    output = ansible_native_concat(['[1, 2, 3]', 'a'], check_all=True)

# Generated at 2022-06-23 13:13:16.761011
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat(["1", "2", "foo"]) == "1 2 foo"
    assert ansible_native_concat(["1", "2.0", "foo"]) == [1, 2.0, "foo"]
    assert ansible_native_concat(["'''1'''", "2.0", "foo"]) == "'1' 2.0 foo"
    assert ansible_native_concat(["'''1'''", "2.0", "foo"]) == "'1' 2.0 foo"



# Generated at 2022-06-23 13:13:27.647749
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # pylint: disable=import-outside-toplevel
    from ansible.plugins.filter.core import combine


# Generated at 2022-06-23 13:13:37.300373
# Unit test for function ansible_native_concat

# Generated at 2022-06-23 13:13:47.330577
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([u'a']) == 'a'
    assert ansible_native_concat([u'a', u'b']) == 'ab'
    assert ansible_native_concat([u'{{ a }}', u'b']) == '{{ a }}b'
    assert ansible_native_concat([u'{{ a }}', u'b', u'{{ c }}']) == '{{ a }}b{{ c }}'
    assert ansible_native_concat([u'{{ a }}', u'b', u'{{ c }}']) == '{{ a }}b{{ c }}'

# Generated at 2022-06-23 13:13:54.167007
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2]) == 1
    assert ansible_native_concat([]) == None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 'a']) == '1a'
    assert ansible_native_concat([123, 345]) == 123
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', 1]) == 'a1'
    assert ansible_native_concat(['a ', 1]) == 'a 1'
    assert ansible_native_concat(['a\n ', 1]) == 'a\n 1'
    assert ansible_native_concat([1, '\n']) == '1\n'
   

# Generated at 2022-06-23 13:13:58.686954
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([1, '2', 3, 'foo']) == "123foo"

# Generated at 2022-06-23 13:14:09.346128
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([None]) == None

    # undefined
    assert len(text_type(ansible_native_concat([StrictUndefined()]))) > 0
    assert len(text_type(ansible_native_concat([StrictUndefined(), StrictUndefined()]))) > 0

    # native type, no need to call literal_eval
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == 1

    # can be natively evaluated
    assert ansible_native_concat(['']) == ''
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_

# Generated at 2022-06-23 13:14:18.917178
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([123]) == 123
    assert ansible_native_concat([u'abc']) == u'abc'
    assert ansible_native_concat([True]) == True
    assert ansible_native_concat([False]) == False
    assert ansible_native_concat([None]) is None

    # test str concatenation
    assert ansible_native_concat([u'a', u'bc']) == u'abc'

    # test special cases
    assert ansible_native_concat([u'', u'', u'']) == u''
    assert ansible_native_concat([u'1', u'', u'']) == u'1'

    # test that literals are parsed
    assert ansible_native_concat([u'4', u'5']) == 45

# Generated at 2022-06-23 13:14:27.741745
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # pylint: disable=protected-access
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([u'a']) == u'a'
    assert ansible_native_concat([u'a', u'b']) == u'ab'
    assert ansible_native_concat([u'a', u'b', u'c']) == u'abc'
    assert ansible_native_concat([u'a', u'b', u'c', u'd']) == u'abcd'
    assert ansible_native_concat([1, u'b']) == u'1b'
    assert ansible_native_concat([1, 2, 3]) == u'123'

# Generated at 2022-06-23 13:14:34.274161
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Unit test for function ansible_native_concat"""

    # This is the string that gets passed to ast.literal_eval. If this
    # does not match in the tests below then something is wrong.
    test_values = {
        # Make sure backslashes are escaped correctly.
        r'\aa\bb': r'\\aa\\bb',
        # Make sure dicts are stringified correctly.
        {'foo': 'bar'}: u'{u\'foo\': u\'bar\'}',
    }

    for value, expected_text in test_values.items():
        result = ansible_native_concat([value])
        assert result == value, 'wrong result for value %r' % value
        # The expected text is what gets passed to ast.literal_eval.
        assert to_text(result) == expected_

# Generated at 2022-06-23 13:14:41.816620
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils._text import to_native

    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert isinstance(ansible_native_concat(['1', '2', '3']), int)
    assert isinstance(ansible_native_concat(['1.', '2', '3']), float)
    assert isinstance(ansible_native_concat(['1.', '2', '3j']), complex)
    assert isinstance(ansible_native_concat(['1', '2', '3L']), long)

    # preserve integers with leading zeros

# Generated at 2022-06-23 13:14:48.937536
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(["a"]) == u"a"
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([[1]]) == [1]
    assert ansible_native_concat(["a", 1, [1], True]) == u"a1[1]True"
    assert ansible_native_concat(["a", [], True]) == u"a[]True"
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(["a", 1]) == u"a1"
    assert ansible_native_concat(["a", 1, None, True]) == u"a1NoneTrue"
    assert ansible_native_concat(["a", 1, 2]) == u"a12"
   

# Generated at 2022-06-23 13:14:59.505406
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(None) is None

    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([1, 'foo']) == 1
    assert ansible_native_concat([1, 'foo', 2, 'bar']) == 1
    assert ansible_native_concat(['foo', 2, 'bar']) == 'foo2bar'
    assert ansible_native_concat(['foo', 2, 'bar', 3]) == 'foo2bar3'
    assert ansible_native_concat(['foo', 2, 'bar', 3.0]) == 'foo2bar3.0'

# Generated at 2022-06-23 13:15:09.680443
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = [
        ast.Str(s='ansible'),
        ast.Str(s='_'),
        ast.Str(s='autoescaping'),
        ast.Str(s='='),
        ast.Str(s="'"),
        ast.Str(s='jinja'),
        ast.Str(s="'")
    ]
    expected = u"ansible_autoescaping='jinja'"
    assert ansible_native_concat(nodes) == expected
    assert isinstance(ansible_native_concat(nodes), string_types)
    nodes = nodes[:2]
    assert ansible_native_concat(nodes) == 'ansible'
    assert isinstance(ansible_native_concat(nodes), string_types)
    nodes = nodes[:1]
    assert ansible

# Generated at 2022-06-23 13:15:19.833698
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import pytest

    literal_eval_error = (
        ValueError,
        SyntaxError
    )

    # Fixed tests
    s = text_type('foo')
    assert ansible_native_concat([s]) == 'foo'

    s = text_type('foo')
    with pytest.raises(literal_eval_error):
        ansible_native_concat([s, s]) == 'foo'

    s = text_type('1')
    assert ansible_native_concat([s]) == 1

    s = text_type('1')
    with pytest.raises(literal_eval_error):
        ansible_native_concat([s, s]) == 1

    s = text_type('-1')
    assert ansible_native_concat([s]) == -1

    s

# Generated at 2022-06-23 13:15:25.778885
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class U:
        def __str__(self):
            return "Unicode"

    class S:
        def __str__(self):
            return b"Bytes"

    class I:
        def __str__(self):
            return 1

    class F:
        def __str__(self):
            return 1.0

    class L:
        def __str__(self):
            return [1, 2, 3]

    class D:
        def __str__(self):
            return {"k": "v"}

    class B:
        def __str__(self):
            return True

    class N:
        def __str__(self):
            return None

    class T:
        def __str__(self):
            return "test"

# Generated at 2022-06-23 13:15:34.471141
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = ([None,
              1,
              True,
              ['a', 'b'],
              ('t', 'u', 'p'),
              {'x': 'y', 'z': 'w'},
              u'asdf',
              b'asdf',
              AnsibleVaultEncryptedUnicode(b'asdf')]
             + [container_to_text(i, None) for i in nodes]
             + [u'{{ foo }}', u'{{ bar }}'])

    for n in nodes:
        assert ansible_native_concat(n) == n

    # Only difference between 'a' and u'a' is the leading 'u'
    assert ansible_native_concat([u'a', u'b']) == u'ab'

# Generated at 2022-06-23 13:15:40.941108
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == u'12'
    assert ansible_native_concat(['1']) == u'"1"'
    assert ansible_native_concat([u'\N{SNOWMAN}']) == u'"\N{SNOWMAN}"'
    assert ansible_native_concat([u'1', u'2']) == u'12'
    assert ansible_native_concat([u'"1"']) == u'"1"'
    assert ansible_native_concat([u'"1"', u'"2"']) == u'12'
    assert ansible_native_concat([u'"1"', u'"2"', u'"3"'])

# Generated at 2022-06-23 13:15:49.580936
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['1', '2', '3']) == 123
    assert ansible_native_concat(['foo', 'bar', 1]) == 'foobar1'
    assert ansible_native_concat(['1', '2', '3', '4']) == '1234'
    assert ansible_native_concat(['1', '2', '3', '4', 5]) == '12345'
    assert ansible_native_concat(['1', '2', '3', '4', 5, '6']) == '123456'

# Generated at 2022-06-23 13:15:57.883441
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedString

    def _test_native_concat(values, expected):
        func = lambda: tuple(values)
        assert expected == ansible_native_concat(func())

    _test_native_concat(["", "", ""], "")
    _test_native_concat(["a", "b", "c"], "abc")
    _test_native_concat([["a"], "b", ["c"]], ["a", "b", "c"])
    _test_native_concat([["a", "b"], "c", ["d", "e"]], ["a", "b", "c", "d", "e"])

# Generated at 2022-06-23 13:16:08.011149
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # These tests are implemented to be a port of the native_concat tests
    # in Jinja2. Those tests can be found at:
    # https://github.com/pallets/jinja/blob/master/tests/test_nativetypes.py
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([object()]) is object
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat(['1', 'x']) == '1x'
    assert ansible_native_concat(['<', u'foo', u'>']) == '<foo>'



# Generated at 2022-06-23 13:16:16.997770
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.utils.native_jinja import NativeJinjaText

    assert ansible_native_concat([]) is None

    assert ansible_native_concat([None]) == None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([-1]) == -1
    assert ansible_native_concat([1.0]) == 1.0
    assert ansible_native_concat([-1.0]) == -1.0
    assert ansible_native_concat([u'']) == u''
    assert ansible_native_concat([u'\u20ac']) == u'\u20ac'
    assert ansible_native_concat([[]]) == []
    assert ansible_native_concat([[1]]) == [1]
   

# Generated at 2022-06-23 13:16:25.814597
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_data = [
        (['hello', ' ', 'world'], ['hello', ' ', 'world']),
        (['hello', ' ', StrictUndefined(), 'world'], ['hello', ' ', StrictUndefined(), 'world']),
        (['hello ', StrictUndefined(), ' world'], 'hello world'),
        (['hello ', StrictUndefined(), ' world'], 'hello world'),
        (['hello ', 'world'], 'hello world'),
        (['hello', ' '], 'hello '),
        ([], None),
        ([StrictUndefined()], StrictUndefined()),
    ]
    for data, expected in test_data:
        out = ansible_native_concat(data)

# Generated at 2022-06-23 13:16:36.774996
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common._collections_compat import OrderedDict

    assert ansible_native_concat(['abc', 'def']) == 'abcdef'
    assert ansible_native_concat(['abc', 123]) == 'abc123'
    assert ansible_native_concat([123, 'abc']) == '123abc'
    assert ansible_native_concat(['abc', 123, 'def']) == 'abc123def'
    assert ansible_native_concat([123, 'abc', 456]) == '123abc456'
    assert ansible_native_concat(['abc', 123, 456]) == 'abc123456'
    assert ansible_native_concat([123, 'abc', [456]]) == '123abc[456]'
    assert ansible_native_con

# Generated at 2022-06-23 13:16:45.561008
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(['[', '1', ',', '2', ']']) == [1, 2]
    assert ansible_native_concat(['{', '1:', '2', '}']) == {1:2}
    assert ansible_native_concat(['[1,2]', '[3,4]']) == '[[1, 2], [3, 4]]'
    assert ansible_native_concat(['[1,2]', '[3,4]', '5']) == '[[1, 2], [3, 4], 5]'

# Generated at 2022-06-23 13:16:53.212388
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # test ast.literal_eval is called and the result is returned
    literal_eval_result = {'key': 'value'}
    assert literal_eval_result == ansible_native_concat(iter([literal_eval_result]))
    assert literal_eval_result == ansible_native_concat(iter([text_type(literal_eval_result)]))
    assert literal_eval_result == ansible_native_concat(iter([native_text(literal_eval_result)]))
    assert literal_eval_result == ansible_native_concat(iter([container_to_text(literal_eval_result)]))

    # test ast.literal_eval is called and the result is not returned
    non_literal_eval_result = {'key': 'value'}
    non_literal_eval

# Generated at 2022-06-23 13:17:02.639195
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(
        [1, 2, 3]
    ) == [1, 2, 3]

    assert ansible_native_concat(
        i for i in [1, 2, 3]
    ) == [1, 2, 3]

    assert ansible_native_concat(
        [1, '2', 3]
    ) == [1, '2', 3]

    assert ansible_native_concat(
        i for i in [1, '2', 3]
    ) == [1, '2', 3]

    assert ansible_native_concat(
        [1, 2, 3, 4]
    ) == '1234'

    assert ansible_native_concat(
        [1, 2, 3, 4]
    ) == '1234'

    assert ans

# Generated at 2022-06-23 13:17:12.935928
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # test string, bool, int, float, dict, and list
    assert ansible_native_concat([1, 2, 3, 4]) == '1234'
    assert ansible_native_concat(['1', '2', '3', '4']) is 1
    assert ansible_native_concat(['true']) is True
    assert ansible_native_concat(['false']) is False
    assert ansible_native_concat(['1']) is 1
    assert ansible_native_concat(['1.1']) == 1.1
    assert ansible_native_concat(['{"k": "v"}']) == {'k': 'v'}

    mylist = ['["a", "b", "c"]']

# Generated at 2022-06-23 13:17:19.518527
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.jinja2 import AnsibleJ2Template
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import container_to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import bytes_to_native

    def assert_equal(left, right):
        if left != right:
            raise AssertionError("Expected %r but got %r" % (left, right))

    env = AnsibleJ2Template(basedir=None).environment
    env.compile = lambda x: x


# Generated at 2022-06-23 13:17:29.435455
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat(['1', '2', '3']) == [1, 2, 3]
    assert ansible_native_concat(['1', '2.2', '3']) == [1, 2.2, 3]
    assert ansible_native_concat([['1']]) == ['1']
    assert ansible_native_concat([1]) == 1
    assert isinstance(ansible_native_concat(['a']), string_types)
    assert isinstance(ansible_native_concat(['a', 'b']), string_types)
    assert isinstance(ansible_native_concat(['a', 'b']), text_type)
    assert ansible_

# Generated at 2022-06-23 13:17:36.962815
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert ansible_native_concat([]) is None
    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([u'foo', u'bar', 42]) == u'foobar42'
    assert ansible_native_concat([u'foo', u'bar', 42]) == u'foobar42'

    assert ansible_native_concat(iter([])) is None

# Generated at 2022-06-23 13:17:47.901765
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_bytes
    import ansible.parsing.yaml.loader
    loader = ansible.parsing.yaml.loader.Loader

    # The following function needs to be monkey patched because 'yaml.load'
    # as imported from 'ansible.parsing.yaml.loader' does not have the
    # 'Loader.construct_yaml_str' method.
    def construct_yaml_str(self, node):
        return self.construct_scalar(node)

    loader.construct_yaml_str = construct_yaml_str


# Generated at 2022-06-23 13:17:59.340942
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # test case 1
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    # test case 2
    assert ansible_native_concat(['1', '2', '3']) == 123
    # test case 3
    assert ansible_native_concat(['1', '2', 'x']) == '1' + '2' + 'x'
    # test case 4
    assert ansible_native_concat(['x', '2', '3']) == 'x' + '2' + '3'
    # test case 5
    assert ansible_native_concat(['1', 'x', '3']) == '1' + 'x' + '3'
    # test case 6

# Generated at 2022-06-23 13:18:07.762783
# Unit test for function ansible_native_concat

# Generated at 2022-06-23 13:18:15.776976
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test ansible_native_concat

    This tests basic usage and also tests to ensure that the function
    can handle AnsibleVaultEncryptedUnicode.
    """
    # Basic usage
    assert ansible_native_concat([u'abc']) == u'abc'

    # Parsing of string
    assert ansible_native_concat([u'[1, 2]']) == [1, 2]

    # Parsing of string with one argument
    assert ansible_native_concat([u'[1, 2]', u'[3, 4]']) == [1, 2, 3, 4]

    # Ensure that AnsibleVaultEncryptedUnicode is returned as a string

# Generated at 2022-06-23 13:18:25.805808
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([True, False]) is 'TrueFalse'
    assert ansible_native_concat([True, 'False']) is 'TrueFalse'
    assert ansible_native_concat(['True', False]) is 'TrueFalse'
    assert ansible_native_concat(['True', 'False']) is 'TrueFalse'
    assert ansible_native_concat([1, 2]) is '12'
    assert ansible_native_concat(['1', 2]) is '12'
    assert ansible_native_concat([1, '2']) is '12'
    assert ansible_native_concat(['1', '2']) is '12'
    assert ansible_native_concat([1, 2, 3, 4, 5]) is '12345'
    assert ansible_

# Generated at 2022-06-23 13:18:35.568568
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # pylint: disable=protected-access
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([2, 3]) == u'23'
    assert ansible_native_concat([u'a', u'b', u'c']) == u'abc'
    assert ansible_native_concat((u'a', u'b')) == u'ab'
    assert ansible_native_concat([]) == ''
    assert ansible_native_concat([u' a', u' ', u'b ', u' c ', u'd']) == ' a b  c  d'
    assert ansible_native_concat([[1], [2], [3]]) == [1, 2, 3]

# Generated at 2022-06-23 13:18:44.700351
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 'bar', 1]) == 'foobar1'
    assert ansible_native_concat(['foo', 'bar', 1, True]) == 'foobar1True'

    assert ansible_native_concat([['foo', 'bar']]) == 'foobar'
    assert ansible_native_concat([['foo', 'bar'], 1]) == 'foobar1'
    assert ansible_native_concat([['foo', 'bar'], 1, True]) == 'foobar1True'

    assert ansible_native_concat([[['foo', 'bar']]]) == 'foobar'

# Generated at 2022-06-23 13:18:55.400166
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.module_utils.common.text.converters import to_text

    yaml = "<ansible.parsing.yaml.objects.AnsibleVaultEncryptedUnicode object at 0x7f1b07c84110>"
    expected = yaml
    actual = ansible_native_concat([yaml])
    assert actual == expected

    yaml = '"secrets"'
    expected = "secrets"
    actual = ansible_native_concat([yaml])
    assert actual == expected

    yaml = '"{{ service_account }}"'
    expected = '"{{ service_account }}"'
    actual = ansible_native_concat([yaml])
    assert actual == expected



# Generated at 2022-06-23 13:19:04.968067
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat('abc') == 'abc'
    assert ansible_native_concat(123) == 123
    assert ansible_native_concat('{"a": "b"}') == {'a': 'b'}
    assert ansible_native_concat('{"a": ["b", "c"]}') == {'a': ['b', 'c']}
    assert ansible_native_concat('[True, false]') == [True, False]
    assert ansible_native_concat('{"a": [True, false]}') == {'a': [True, False]}
    assert ansible_native_concat

# Generated at 2022-06-23 13:19:13.741654
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1,2]) == [1,2]
    assert ansible_native_concat([123]) == 123
    assert ansible_native_concat(["abc"]) == "abc"
    assert ansible_native_concat(["abc", "def"]) == "abcdef"
    assert ansible_native_concat([1, "abc", 2.0, 42, "def", "ghi", 3]) == "1abc2.042defghi3"
    assert ansible_native_concat([1, ["abc", "def"], 2.0, 42, ["ghi", "jkl"], 3]) == "1abcdef2.042ghijkl3"

# Generated at 2022-06-23 13:19:21.673040
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test non-string node
    assert ansible_native_concat([object()]) == object()
    # Test single node
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([True]) == True
    assert ansible_native_concat([False]) == False
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['bar']) == 'bar'
    assert ansible_native_concat(["'foo'"]) == 'foo'
    assert ansible_native_concat(['"bar"', 'baz']) == 'barbaz'
    # Test multiple nodes
    assert ansible_native_concat([1, 2]) == 12

# Generated at 2022-06-23 13:19:26.623342
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(iter([])) == None

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(iter([1])) == 1

    assert ansible_native_concat([1, 2]) == [1, 2]
    assert ansible_native_concat(iter([1, 2])) == [1, 2]

    assert ansible_native_concat([1, '2']) == '1 2'
    assert ansible_native_concat(iter([1, '2'])) == '1 2'

    assert ansible_native_concat(['a', 'b', 'c']) == ['a', 'b', 'c']

# Generated at 2022-06-23 13:19:34.412735
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.errors import AnsibleFilterError
    from ansible_collections.ansible.general.tests import ansible_native_concat as unit_ansible_native_concat

    def _to_native(value):
        return unit_ansible_native_concat(value)

    # Empty nodes
    assert _to_native([]) is None

    # Single node
    assert _to_native(['123']) == 123
    assert _to_native(['1.23']) == 1.23
    assert _to_native(['hello']) == 'hello'
    assert _to_native(['world']) == 'world'

    # Two nodes
    assert _to_native(['hello', 'world']) == 'helloworld'

# Generated at 2022-06-23 13:19:42.118912
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([False]) == False
    assert ansible_native_concat([True]) == True
    assert ansible_native_concat([0]) == 0
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([0.0]) == 0.0
    assert ansible_native_concat([1.0]) == 1.0
    assert ansible_native_concat(['0']) == '0'
    assert ansible_native_concat(['1']) == '1'
    assert ansible_native_concat(['0.0']) == '0.0'
    assert ansible_native_concat(['1.0']) == '1.0'
    assert ansible_native_concat(['0', '0'])

# Generated at 2022-06-23 13:19:53.677046
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import nodes, Environment

    def do_eval(code):
        env = Environment(undefined=StrictUndefined, extensions=['jinja2.ext.do'])
        return env.compile(code).eval()

    assert do_eval('{{ [42, "a "|string, true] }}') == [42, u'a ', True]
    assert do_eval('{{ [[]], True }}') == [[], True]
    assert do_eval('{{ [0] if false else [42] }}') == [42]
    # In Python 3.10+ ast.literal_eval removes leading spaces/tabs.
    assert do_eval('{{ "  42" }}') == "  42"

    assert do_eval('{{ foo }}') == StrictUndefined()

# Generated at 2022-06-23 13:20:02.693936
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test with a string sequence
    assert ansible_native_concat(['test', ' string', ' list']) == \
        'test string list'
    # Test with a unicode sequence
    assert ansible_native_concat([u'test', u' unicode', u' list']) == \
        u'test unicode list'
    # Test with a mixed sequence
    assert ansible_native_concat([u'test', ' string', u' unicode', ' list']) == \
        u'test string unicode list'
    # Test with a list
    assert ansible_native_concat(['test', 'list']) == \
        ['test', 'list']
    # Test with a dict

# Generated at 2022-06-23 13:20:13.627600
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.plugins.loader import jinja_loader

    test_data = '''
    ansible_native_concat:
        common:
            - 123
            - 456
            - 789
        single_item:
            - "abc"
        multiple_items:
            - "abc"
            - "def"
        multiple_lines:
            - "abc\n"
            - "def\n"
            - "ghi\n"
        to_list:
            - "a b c"
        to_dict:
            - "{'a': 1, 'b': 2}"
    '''

    loader = DataLoader()
   

# Generated at 2022-06-23 13:20:24.593304
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import pytest
    from ansible.module_utils.common.type_utils import AnsibleModuleTestCase


# Generated at 2022-06-23 13:20:35.219346
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([None, 'hello', 'world']) == 'helloworld'
    assert ansible_native_concat(['hello', 'world']) == 'helloworld'
    assert ansible_native_concat(['{"a": 1}', 'hello', 'world']) == '{"a": 1}helloworld'
    assert ansible_native_concat(['["a", 1]', 'hello', 'world']) == '["a", 1]helloworld'
    assert ansible_native_concat(['true', 'hello', 'world']) == 'truehelloworld'
    assert ansible_native_concat(['false', 'hello', 'world']) == 'falsehelloworld'

# Generated at 2022-06-23 13:20:42.991346
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 'bar', 'baz']) == 'foobarbaz'
    assert ansible_native_concat(['foo', u'bar', u'baz']) == 'foobarbaz'
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([1, '2', '3']) == '123'
    assert ansible_native_con

# Generated at 2022-06-23 13:20:53.954589
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    literal_eval = ast.literal_eval


# Generated at 2022-06-23 13:21:05.050902
# Unit test for function ansible_native_concat

# Generated at 2022-06-23 13:21:15.976855
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    undefined = StrictUndefined()
    assert ansible_native_concat([1, '2', undefined]) == '12'
    assert ansible_native_concat([1, '2', undefined, undefined]) == '12'
    assert ansible_native_concat(['1', '2', undefined, undefined]) == '12'
    assert ansible_native_concat(['1', '2', undefined, undefined, '3']) == '123'

    assert ansible_native_concat([1.1, '2.2', undefined]) == '1.12.2'
    assert ansible_native_concat([1.1, '2.2', undefined, undefined]) == '1.12.2'

# Generated at 2022-06-23 13:21:27.430040
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import ansible.module_utils.common.collections

    assert ansible_native_concat([]) == None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(['a', 'b', 1]) == 'ab1'
    assert ansible_native_concat(['a', 'b', 1, 1.0]) == 'ab11.0'
    assert ansible_native_concat(['a', 'b', 1, 1.0, True]) == 'ab11.0True'

# Generated at 2022-06-23 13:21:37.292905
# Unit test for function ansible_native_concat

# Generated at 2022-06-23 13:21:43.468450
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 123, 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', '123', 'bar']) == 'foo123bar'



# Generated at 2022-06-23 13:21:55.250245
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(iter(['foo', 'bar'])) == 'foobar'
    assert ansible_native_concat(iter(['foo', [1, 2, 3]])) == 'foo123'
    assert ansible_native_concat(iter(['foo', 'bar', {'a': 1}, None])) == 'foobar{a: 1}None'
    assert ansible_native_concat(iter(['foo', 'bar', [1, 2, 3], {'a': 1}, None])) == 'foobar123{a: 1}None'

    # Parse a list
    assert ansible_native_concat(iter(['[1, 2, 3]'])) == [1, 2, 3]

# Generated at 2022-06-23 13:22:06.384843
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat([[1, 2, 3], [4, 5, 6], [7, 8, 9]]) == 123456789
    assert ansible_native_concat([[1, 2, 3], [4, 5, 6], [7, 8, 9]]) == 123456789
    assert ansible_native_concat(['ansible', 'is', 'cool']) == 'ansibleiscool'
    assert ansible_native_concat(['1', '2', '3']) == 123
    assert ansible_native_concat([['ansible', 'is', 'cool'], ['no', 'really']]) == 'ansibleiscoolnoreally'



# Generated at 2022-06-23 13:22:18.890805
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import pytest

    # Test native types
    assert ansible_native_concat([True, False, True]) == True
    assert ansible_native_concat([42, 43, 44]) == 42
    assert ansible_native_concat([['foo', 'bar'], ['baz', 'qux']]) == ['foo', 'bar']
    assert ansible_native_concat([{'foo': 'bar'}, {'baz': 'qux'}]) == {'foo': 'bar'}
    assert ansible_native_concat(['foo', 'bar']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foo'

    # Test non-native types

# Generated at 2022-06-23 13:22:30.395801
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils._text import to_text

    # check concat with empty sequence
    assert ansible_native_concat([]) is None

    # check concat of a single element
    assert ansible_native_concat(["test"]) == "test"

    # check concat of two elements
    assert ansible_native_concat(["test", "test"]) == "testtest"

    # check concat and evaluate a native int
    assert ansible_native_concat(["1"]) == 1

    # check concat and evaluate a native float
    assert ansible_native_concat(["1.2"]) == 1.2

    # check concat and evaluate a native bool
    assert ansible_native_concat(['true']) is True

    # check concat and evaluate a native bool
   