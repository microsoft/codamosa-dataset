

# Generated at 2022-06-23 13:12:34.191109
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar


# Generated at 2022-06-23 13:12:43.805026
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Unit test for function ansible_native_concat"""

    text_type = type(u"")
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(["foo"]) == "foo"
    assert isinstance(ansible_native_concat(["foo"]), text_type)
    assert ansible_native_concat(["foo", "bar"]) == "foobar"
    assert isinstance(ansible_native_concat(["foo", "bar"]), text_type)
    assert ansible_native_concat(["_", "bar"]) == "_bar"
    assert isinstance(ansible_native_concat(["_", "bar"]), text_type)
    assert ansible_native_concat(["1", "0"]) == "10"
   

# Generated at 2022-06-23 13:12:53.518071
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1, 2]) == "12"
    assert ansible_native_concat([1.2, 2.3]) == "1.22.3"
    assert ansible_native_concat(['a', 'b']) == "ab"
    assert ansible_native_concat(['a', 1]) == "a1"
    assert ansible_native_concat([1, 'a']) == "1a"
    assert ansible_native_concat(['', '']) == ""
    assert ansible_native_concat([' ', 'abc']) == " abc"
    assert ansible_native_concat(['abc', ' ']) == "abc "

# Generated at 2022-06-23 13:13:02.530772
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = ['text', 1, 2.0, True, None, 'text']

    value = ansible_native_concat(nodes)
    assert value == 'text12.0TrueNonetext'

    value = ansible_native_concat(iter(nodes))
    assert value == 'text12.0TrueNonetext'

    nodes = ['text', 1, 2.0, True, None, u'日本語']

    value = ansible_native_concat(nodes)
    assert value == u'text12.0TrueNone日本語'

    value = ansible_native_concat(iter(nodes))
    assert value == u'text12.0TrueNone日本語'

    # Test concat with empty node

# Generated at 2022-06-23 13:13:10.364495
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = [
        u'Hello ',
        u'World!'
    ]
    assert ansible_native_concat(nodes) == u'Hello World!'

    nodes = [
        u'Hello ',
        u'World!',
    ]
    assert ansible_native_concat(nodes) == u'Hello World!'

    # TODO send unvaulted data to literal_eval?
    nodes = [
        u'Hello ',
        AnsibleVaultEncryptedUnicode('World!'),
    ]
    assert ansible_native_concat(nodes) == u'World!'

    # short-circuit literal_eval for anything other than strings
    nodes = [
        u'Hello ',
        False,
    ]
    assert ansible_native_concat(nodes) is False


# Generated at 2022-06-23 13:13:20.610238
# Unit test for function ansible_native_concat

# Generated at 2022-06-23 13:13:29.681701
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert type(ansible_native_concat([1])) is int
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat(['foo']) == 'foo'
    assert type(ansible_native_concat(['foo'])) is text_type
    assert ansible_native_concat([1, 'foo']) == 1
    assert type(ansible_native_concat([1, 'foo'])) is int
    assert ansible_native_concat(['foo', 1]) == 'foo'
    assert type(ansible_native_concat(['foo', 1])) is text_type

# Generated at 2022-06-23 13:13:39.215942
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Unit test for ansible_native_concat"""
    def foo():
        yield 1
        yield 2
        yield 3

    assert ansible_native_concat([]) is None

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1.0]) == 1.0
    assert ansible_native_concat(['abc']) == 'abc'
    assert ansible_native_concat([u'abc']) == u'abc'
    assert ansible_native_concat([True]) == True
    assert ansible_native_concat([False]) == False
    assert ansible_native_concat([None]) == None

    assert ansible_native_concat([[]]) == []
    assert ansible_native_concat([[1]]) == [1]


# Generated at 2022-06-23 13:13:49.802128
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2

    env = jinja2.Environment(
        extensions=['jinja2.ext.do'],
        finalize=ansible_native_concat,
    )

# Generated at 2022-06-23 13:14:01.198945
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, 42]) == '142'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([True, False]) == 'TrueFalse'
    assert ansible_native_concat([True, 'bar']) == 'Truebar'
    assert ansible_native_concat([True, None]) == 'TrueNone'
    assert ansible_native_concat(['foo', 42]) == 'foo42'
    assert ansible_native_concat(['foo', '42']) == 'foo42'

# Generated at 2022-06-23 13:14:11.743109
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # FIXME direct import fails with "ImportError: cannot import name NativeJinjaText"
    from ansible.module_utils.common.text.converters import NativeJinjaText
    from ansible.module_utils.common.text.converters import to_text
    import ast

    # Directly invoke the function instead of going through the Jinja2
    # machinery.
    nodes = [NativeJinjaText(u'a'), NativeJinjaText(u'b'), NativeJinjaText(u'c')]
    assert ansible_native_concat(nodes) == 'abc'

    nodes = [u'a', NativeJinjaText(u'b'), u'c']
    assert ansible_native_concat(nodes) == 'abc'

    # FIXME ansible_native_concat is invoked

# Generated at 2022-06-23 13:14:20.283176
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    native_types = [
        dict,
        list,
        int,
        float,
        text_type,
    ]

    for native_type in native_types:
        value = native_type('')
        result = ansible_native_concat(value)
        assert result == native_type('')

        value = native_type('foo')
        result = ansible_native_concat(value)
        assert result == native_type('foo')

        value = native_type('foo')
        result = ansible_native_concat(value)
        assert result == native_type('foo')

        value = native_type(['foo'])
        result = ansible_native_concat(value)
        assert result == native_type(['foo'])

        value = StrictUndefined
        result = ans

# Generated at 2022-06-23 13:14:29.950634
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(['string1']) == 'string1'
    assert ansible_native_concat(['string1', 'string2']) == 'string1string2'
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat(['1', '2', '3']) == 1
    assert ansible_native_concat(['  1', '2', '3']) == '  123'
    assert ansible_native_concat(['1', '2', '3  ']) == '123  '

# Generated at 2022-06-23 13:14:36.006428
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # A single node
    ansible_native_concat([u'a str']) == u'a str'

    # Compatible nodes are concatenated into a single node
    assert ansible_native_concat([u'a', u' ', u'str']) == u'a str'
    assert ansible_native_concat([u'a str', u'a ', u'str']) == u'a stra str'

    # Incompatible nodes are concatenated into a string
    assert ansible_native_concat([u'a str', 3]) == u'a str3'

    # Nodes can be parsed by ast.literal_eval
    assert ansible_native_concat([u'a', u' ', u'str']) == u'a str'

# Generated at 2022-06-23 13:14:43.607116
# Unit test for function ansible_native_concat

# Generated at 2022-06-23 13:14:55.047371
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import ansible.module_utils.common.text.converters as to_native
    import jinja2
    # test invalid syntax for literal_eval - syntax error
    env = jinja2.Environment(extensions=[])
    env.filters['native'] = to_native.ansible_native_concat
    assert env.from_string(
        u'{{ [1, "foo", 2] | map("native") | list | join }}'
    ).render() == u'1foofoo2'
    assert env.from_string(
        u'{{ "{1: 2}" | native }}'
    ).render() == u'{1: 2}'

# Generated at 2022-06-23 13:15:04.891782
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['1.0']) == 1.0
    assert ansible_native_concat(['"1"']) == '1'
    assert ansible_native_concat(['True']) is True
    assert ansible_native_concat(['x']) == 'x'
    assert ansible_native_concat(['1', 'x']) == '1x'
    assert ansible_native_concat(['1.0', 'x']) == '1.0x'
    assert ansible_native_concat(['"1"', 'x']) == '1x'


# Generated at 2022-06-23 13:15:13.842639
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat(['1,2']) == '1,2'
    assert ansible_native_concat(['1', ',', '2']) == '1,2'
    assert ansible_native_concat(['1', ', ', '2']) == '1, 2'

# Generated at 2022-06-23 13:15:24.483024
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', '{{ bar }}']) == 'foo {{ bar }}'

    assert ansible_native_concat(['[1, 2, 3]']) == [1, 2, 3]
    assert ansible_native_concat(['[1, 2, 3]', '[4, 5, 6]']) == '[1, 2, 3][4, 5, 6]'

# Generated at 2022-06-23 13:15:33.899887
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    data = [{u'foo': 1}, {u'bar': 2}]
    result = ansible_native_concat(data)
    assert result == [{'foo': 1}, {'bar': 2}]

    data = ['ansible', 'rocks']
    result = ansible_native_concat(data)
    assert result == 'ansiblerocks'

    data = ['ansible', 'rocks', '100']
    result = ansible_native_concat(data)
    assert result == 'ansiblerocks100'

    data = [u'Ä', u'Ö']
    result = ansible_native_concat(data)
    assert result == u'ÄÖ'

    data = [u'Ä', u'Ö', u'Ü']
    result = ansible_native

# Generated at 2022-06-23 13:15:44.897519
# Unit test for function ansible_native_concat

# Generated at 2022-06-23 13:15:56.969444
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([None]) == None
    assert ansible_native_concat(["1"]) == "1"
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(["1", "1"]) == "11"
    assert ansible_native_concat(["1", 1]) == "11"
    assert ansible_native_concat([1, 2]) == 3
    assert ansible_native_concat(["1", 1.1]) == "11.1"
    assert ansible_native_concat([u"{", u"5", u"}"]) == "{5}"
    assert ansible_native_concat([1.1, "1"]) == "1.11"

# Generated at 2022-06-23 13:16:07.701129
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['hello']) == 'hello'
    assert ansible_native_concat(['20', '0']) == '200'
    assert ansible_native_concat(['2', '0', '0']) == '200'
    assert ansible_native_concat([200]) == 200
    assert ansible_native_concat(['200']) == 200
    assert ansible_native_concat(['true']) is True
    assert ansible_native_concat(['False']) is False
    assert ansible_native_concat(['False', 'true']) == 'Falsetrue'
    assert ansible_native_concat(['True', 'true']) == 'Truetrue'
    assert ans

# Generated at 2022-06-23 13:16:16.809126
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    data = """
        - [1, 2, 3]
        - [4, 5, 6]
    """
    parsed = ast.literal_eval(ast.parse(data))
    assert parsed == [1, 2, 3, 4, 5, 6]

    # using json module
    from json import loads
    parsed = loads(data)
    assert parsed == [1, 2, 3, 4, 5, 6]

    # using yaml module
    from yaml import safe_load
    parsed = safe_load(data)
    assert parsed == [1, 2, 3, 4, 5, 6]

    # using ansible module_utils.common.text.converters
    from ansible.module_utils.common.text.converters import to_list, to_native

# Generated at 2022-06-23 13:16:25.693501
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(["hello", "world"]) == "helloworld"
    assert ansible_native_concat(["hello"]) == "hello"
    assert ansible_native_concat([42, " is the answer"]) == "42 is the answer"
    assert ansible_native_concat([42, " is the answer"]) == "42 is the answer"
    assert ansible_native_concat([True, " is the answer"]) == "True is the answer"
    assert ansible_native_concat([True, False]) == "TrueFalse"
    assert ansible_native_concat(["{{ some_var }}"]) == "{{ some_var }}"

# Generated at 2022-06-23 13:16:36.652509
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    values = [
        "0",             # literal_eval => 0
        "True",          # literal_eval => True
        "3.14159",       # literal_eval => 3.14159
        "('a', 'b')",    # literal_eval => ('a', 'b')
        "None",          # literal_eval => None
        "[0, 1, 2]"      # literal_eval => [0, 1, 2]
    ]

# Generated at 2022-06-23 13:16:43.494629
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat([1, '2', 3]) == 123
    assert ansible_native_concat(['1', '2', '3']) == 123
    assert ansible_native_concat([1, True]) == 1
    assert ansible_native_concat([True, 1]) == 1
    assert ansible_native_concat([1, 'True']) == 1
    assert ansible_native_concat(['1', 2, '3']) == 123
    assert ansible_native_concat(['1', '2', 3]) == 123
    assert ansible_native_concat(['', '', '1', '2', '3']) == 123

# Generated at 2022-06-23 13:16:52.645457
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    nodes = [1, 2, 3]
    out = ansible_native_concat(nodes)
    assert out == '123'

    nodes = [1, 2, 'a']
    out = ansible_native_concat(nodes)
    assert out == '12a'

    nodes = [1, '2', 'a']
    out = ansible_native_concat(nodes)
    assert isinstance(out, text_type)

    nodes = ['1', '2', 'a']
    out = ansible_native_concat(nodes)
    assert isinstance(out, text_type)

    nodes = ['1', '2', 'a']
    out = ansible_native_concat(nodes)
    assert out == '12a'

    nodes = [1, '2', 'a']

# Generated at 2022-06-23 13:17:02.288299
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Ensure that a single value is returned as-is.
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([True]) == True
    assert ansible_native_concat(['foo']) == 'foo'

    assert ansible_native_concat([['foo']]) == ['foo']

    # Ensure that a single string value can be cast to a numeric value.
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['False']) == False
    assert ansible_native_concat(['True']) == True

    # Ensure that a single value that is not a string or bytes is returned as-is.

# Generated at 2022-06-23 13:17:12.746127
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test ast.literal_eval parsing
    assert ansible_native_concat('123') == 123
    assert ansible_native_concat('-123') == -123
    assert ansible_native_concat('0b1111') == 0b1111
    assert ansible_native_concat('1') == 1
    assert ansible_native_concat('-1') == -1
    assert ansible_native_concat('-1.0') == -1.0
    assert ansible_native_concat('0b1111') == 0b1111
    assert ansible_native_concat('0o123') == 0o123
    assert ansible_native_concat('0x123') == 0x123
    assert ansible_native_concat('"foo"') == '"foo"'

    # Test string concatenation

# Generated at 2022-06-23 13:17:20.740032
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    undefined = StrictUndefined()
    assert ansible_native_concat([{'a': undefined}]) is undefined
    assert ansible_native_concat([undefined]) is undefined
    assert ansible_native_concat([{'x': {'a': undefined}}]) is undefined

    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(['1', 2, 3]) == '123'
    assert ansible_native_concat([1, '2', '3']) == '123'
    assert ansible_native_concat([1, 2, 3]) == 123

    assert ansible_native_concat(['[1, 2, 3]']) == [1, 2, 3]

# Generated at 2022-06-23 13:17:25.798512
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([1, 2]) == u'12'
    assert ansible_native_concat([1, 2, 3]) == u'123'
    assert ansible_native_concat([1, 2, 3]) == u'123'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['', None]) == ''
    assert ansible_native_concat(['', None, ['a'], 'b']) == u'[u\'a\']b'
    assert ansible_native_concat([[], ['b'], 'c']) == u'[u\'b\']c'
    assert ansible_native_

# Generated at 2022-06-23 13:17:35.432088
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # We need to make sure we don't raise exceptions here
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(1) == 1
    assert ansible_native_concat('str') == 'str'
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat((1, 2, 3)) == (1, 2, 3)
    assert ansible_native_concat({'a': 1}) == {'a': 1}
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat((1, 2, 3)) == (1, 2, 3)

# Generated at 2022-06-23 13:17:47.014406
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedString

    assert ansible_native_concat([]) is None
    assert ansible_native_concat([13, 42]) == u'1342'
    assert ansible_native_concat([13, u'£']) == u'13£'
    assert ansible_native_concat([13, NativeJinjaText(u'£')]) == u'13£'
    assert ansible_native_concat([AnsibleVaultEncryptedUnicode(b'\x00\x00\x00\x00')]) == b'\x00\x00\x00\x00'

# Generated at 2022-06-23 13:17:58.444056
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat('bar') == 'bar'
    assert ansible_native_concat(None) is None
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo', ['bar', 'baz'], 'qux']) == 'foobarbazqux'
    assert ansible_native_concat([True, 'baz', False]) == 'TruebazFalse'
    assert ansible_native_concat(['foo', {'bar': 'baz'}, 'qux']) == 'foo{bar: baz}qux'
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(None) is None

# Generated at 2022-06-23 13:18:06.949472
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2
    from jinja2.runtime import Undefined
    from ansible.module_utils.common.text.converters import to_bytes
    env = jinja2.Environment(trim_blocks=True, lstrip_blocks=True)
    ansible_native_concat_filter = jinja2.nativetypes.Undefined('ansible_native_concat')
    assert ansible_native_concat_filter(env, [u'\u00a7', 1]) == u'\u00a71'
    assert ansible_native_concat_filter(env, [1, u'\u00a7']) == u'1\u00a7'
    assert ansible_native_concat_filter(env, [u'a', b'b']) == u'ab'
   

# Generated at 2022-06-23 13:18:15.299733
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_bytes

    # The tests are based on tests from
    # https://github.com/pallets/jinja/blob/2.11.x/tests/test_nativetypes.py

    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['2', 3]) == 5
    assert ansible_native_concat(['2', 3]) == 5

    # NativeJinjaText
    assert ansible_native_concat([NativeJinjaText('foobar')]) == 'foobar'

    # Unicode
    # In Python <3.3, ast.literal_eval does not accept unicode strings
    ansible_native_concat([u'\ufb01'])

# Generated at 2022-06-23 13:18:25.461737
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # pylint: disable=protected-access
    assert ansible_native_concat([u'a']) == 'a'

    # list
    assert ansible_native_concat([u'a', u'b']) == 'ab'
    assert ansible_native_concat([u'a', u'b', u'c']) == ['a', 'b', 'c']
    assert ansible_native_concat([u'a', u'b', u'c']) == ['a', 'b', 'c']

    # dict
    assert ansible_native_concat([u'a', u'b', u'c', u'b']) == {'a': 'b', 'c': 'b'}

    # fallback to string

# Generated at 2022-06-23 13:18:35.408972
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2
    t = jinja2.Template('{% set a = "abc" %}{{ a }}{% set b = "def" %}{{ b }}')
    assert ansible_native_concat(t.root_render_func(t.new_context())) == "abcdef"

# Generated at 2022-06-23 13:18:44.598407
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Unit tests for function ansible_native_concat"""
    assert ansible_native_concat([]) is None

    # test 1
    assert ansible_native_concat([u'foo']) == u'foo'
    # test 2
    assert ansible_native_concat([u'2']) == 2

    # test 3
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    # test 4
    assert ansible_native_concat([u'foo', u'bar', u'baz']) == u'foobarbaz'

    # test 5
    assert ansible_native_concat([u'2', u'3']) == 23
    # test 6

# Generated at 2022-06-23 13:18:55.318780
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    value = 'string'
    assert ansible_native_concat([value]) == value

    value = [1, 2, 3]
    assert ansible_native_concat([value]) == value

    value = {'a': 1, 'b': 1}
    assert ansible_native_concat([value]) == value

    value = ['ansible', 'devel']
    value_out = 'ansible devel'
    assert ansible_native_concat(value) == value_out

    value = [1, 2, 3]
    assert ansible_native_concat(value) == value_out

    value = [1, 2, 3]
    value_out = container_to_text(value)

# Generated at 2022-06-23 13:19:02.832628
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat((1,)) == 1
    assert ansible_native_concat(('1',)) == 1
    assert ansible_native_concat(('a', 'b')) == 'ab'
    assert ansible_native_concat(('a',)) == 'a'
    assert ansible_native_concat((None, 'a')) == 'a'
    assert ansible_native_concat(('a', None)) == 'a'
    assert ansible_native_concat((None, None)) is None



# Generated at 2022-06-23 13:19:13.946512
# Unit test for function ansible_native_concat

# Generated at 2022-06-23 13:19:21.839859
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class C:
        def __init__(self, name):
            self.name = name

        def __str__(self):
            return self.name

    assert ansible_native_concat([]) is None

    # non-string types
    assert ansible_native_concat([42]) == 42

    assert ansible_native_concat([C('foo')]) == 'foo'

    assert ansible_native_concat(['1', '2']) == '12'

    assert ansible_native_concat(['1', '2']) == '12'

    assert ansible_native_concat([container_to_text(['a', 'b']), '2']) == ['a', 'b', '2']

# Generated at 2022-06-23 13:19:31.682415
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'1', u'2']) == u'12'
    assert ansible_native_concat([u'1', True]) == u'1True'
    assert ansible_native_concat([u'1', 2]) == u'12'
    assert ansible_native_concat([u'1', False]) == u'1False'
    assert ansible_native_concat([u'1', None]) == u'1None'
    assert ansible_native_concat([u'1', {u'a': u'b'}]) == u"1{u'a': u'b'}"
    assert ansible_native_concat([u'1', [u'2', u'3']]) == u"1[u'2', u'3']"
    assert ans

# Generated at 2022-06-23 13:19:43.010130
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import json
    import ansible.module_utils.basic

    var_names = ('nodes', 'result')

# Generated at 2022-06-23 13:19:54.991205
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # test single node with value
    assert ansible_native_concat([42]) == 42
    # TODO vaulted string?
    # test single node with native jinja2 text
    assert ansible_native_concat([NativeJinjaText('foo')]) == 'foo'
    # combine multiple nodes
    assert ansible_native_concat([42, 'foo']) == '42foo'
    # test literal_eval
    assert ansible_native_concat([42, 'foo', '1, 2, 3']) == [42, 'foo', (1, 2, 3)]
    assert ansible_native_concat([42, 'foo', '{}']) == [42, 'foo', {}]

# Generated at 2022-06-23 13:20:03.679423
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test ansible_native_concat with various combinations of valid inputs"""

    # None
    assert ansible_native_concat([None]) == None

    # Numbers
    assert ansible_native_concat([0]) == 0
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([-1]) == -1
    assert ansible_native_concat([0.0]) == 0.0
    assert ansible_native_concat([1.0]) == 1.0
    assert ansible_native_concat([-1.0]) == -1.0
    assert ansible_native_concat([3.14]) == 3.14
    assert ansible_native_concat([float('inf')]) == float('inf')

# Generated at 2022-06-23 13:20:14.410737
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Test concatenate a simple integer
    test_nodes = [1, 2, 3]
    assert ansible_native_concat(test_nodes) == 123

    # Test concatenate a simple float
    test_nodes = [1.1, 2.2, 3.3]
    assert ansible_native_concat(test_nodes) == 6.6000000000000005

    # Test concatenate a simple string
    test_nodes = ['Hello', ' ', 'World']
    assert ansible_native_concat(test_nodes) == 'Hello World'

    # Test concatenate a string with integer
    test_nodes = ['Hello', 23, ' World']
    assert ansible_native_concat(test_nodes) == 'Hello23 World'

    # Test concatenate a list of strings

# Generated at 2022-06-23 13:20:26.324953
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([5.0]) == 5.0
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 1, 'bar']) == 'foo1bar'
    assert ansible_native_concat([
        'foo',
        ['bar', 1],
        'baz',
    ]) == 'foobar1baz'
    assert ansible_native_concat([
        'foo',
        {'bar': 1},
        'baz',
    ]) == 'foobarbaz'
    assert ans

# Generated at 2022-06-23 13:20:36.276863
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(iter([])) is None
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat(iter([1, 2, 3])) == [1, 2, 3]
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(iter([1])) == 1
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat(iter([1, 2, 3])) == [1, 2, 3]
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible

# Generated at 2022-06-23 13:20:47.493061
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Python 3.9 deprecates isinstance(x, basestring).
    import sys
    if sys.version_info[0:2] == (3, 9):
        string_types = (str,)

    class Foo(str):
        pass

    class Bar(str):
        pass

    none = ansible_native_concat([])
    assert none is None

    none = ansible_native_concat([Foo('foo'), Bar('bar')])
    assert none is None

    result = ansible_native_concat(['foo', Foo('foo')])
    assert isinstance(result, str)
    assert result == 'foofoo'

    result = ansible_native_concat([u'foo', u'bar', u'baz'])
    assert isinstance(result, text_type)
    assert result

# Generated at 2022-06-23 13:20:55.956359
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Whether to include the "ansible" module in the test case
    include_ansible_module = False

    # Test cases

# Generated at 2022-06-23 13:21:06.251594
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Test with a basic value
    assert ansible_native_concat((0,)) == 0

    # Test with a string literal
    assert ansible_native_concat(('value',)) == 'value'

    # Test with a float literal
    assert ansible_native_concat((1.2,)) == 1.2

    # Test with a boolean literal
    assert ansible_native_concat((True,)) is True

    # Test with a None literal
    assert ansible_native_concat((None,)) is None

    # Test with a list literal
    assert ansible_native_concat(('[1, 2, 3]',)) == [1, 2, 3]

    # Test with a dict literal
    assert ansible_native_concat(('{1: 2}',)) == {1: 2}

    #

# Generated at 2022-06-23 13:21:16.520270
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    import json

    # check that AnsibleBaseYAMLObject is passed through
    b = AnsibleBaseYAMLObject('foo')
    assert ansible_native_concat([b]) == b

    # check that AnsibleUnsafeText is passed through
    u = AnsibleUnsafeText('foo')
    assert ansible_native_concat([u]) == u

    # check that AnsibleVaultEncryptedUnicode is passed through
    c = AnsibleVaultEncryptedUnicode(b'foo')
    assert ansible_native_concat([c]) == c

    # check strings, numbers, and booleans
    assert ansible_native_concat

# Generated at 2022-06-23 13:21:21.202663
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    simple_ansible_native_concat_test = ansible_native_concat(['abc', 'def', 'ghi'])
    assert simple_ansible_native_concat_test == 'abcdefghi'
    complex_ansible_native_concat_test = ansible_native_concat(['abc', 'def', 'ghi', u'{}', u'{"test": "json"}', u'{"test_2": ["this", "is", "json"]}', u'{1,2,3}'])
    assert complex_ansible_native_concat_test == 'abcdefghi{}{"test": "json"}{"test_2": ["this", "is", "json"]}{1,2,3}'
    complex_ansible_native_concat_fail_test = ansible_native_

# Generated at 2022-06-23 13:21:30.819349
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.utils.native_jinja import NativeJinjaText

    assert ansible_native_concat(None) is None

    assert ansible_native_concat([]) is None

    assert ansible_native_concat([AnsibleBaseYAMLObject(1)]) == 1
    assert ansible_native_concat([AnsibleBaseYAMLObject(1), AnsibleBaseYAMLObject(2)]) == '12'

# Generated at 2022-06-23 13:21:33.669338
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """
    ansible_native_concat should return the data stripped of leading spaces.
    """
    assert ansible_native_concat(range(3)) == 1



# Generated at 2022-06-23 13:21:44.970245
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.dumper import AnsibleDumper

    dumper = AnsibleDumper(width=10000)

# Generated at 2022-06-23 13:21:56.567208
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import os
    import sys
    import unittest

    # Jinja2 is not part of the standard library and may not be installed
    from jinja2 import Template

    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text


# Generated at 2022-06-23 13:22:08.482874
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    from ansible.module_utils.common._collections_compat import OrderedDict


# Generated at 2022-06-23 13:22:20.369487
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([42, 42]) == 84
    assert ansible_native_concat(['foo', 42]) == 'foo42'
    assert ansible_native_concat(['foo', 'bar', 'baz']) == 'foobarbaz'
    assert ansible_native_concat([42, 23, '5']) == 10
    assert ansible_native_concat(['foo', 'bar', 42]) == 'foobar42'
    assert ansible_native_concat(['foo', 42, 'bar']) == 'foo42bar'
    assert ansible_native_concat(['foo', 42, 23, '5']) == 'foo4210'
    assert ansible_native_concat

# Generated at 2022-06-23 13:22:32.804423
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    value = ansible_native_concat([])
    assert value is None

    value = ansible_native_concat([123])
    assert value == 123

    value = ansible_native_concat(['foo'])
    assert value == 'foo'

    value = ansible_native_concat(['123'])
    assert value == 123

    value = ansible_native_concat(['True'])
    assert value is True

    value = ansible_native_concat(['False'])
    assert value is False

    value = ansible_native_concat(['{{ foo }}'])
    assert isinstance(value, NativeJinjaText)

    value = ansible_native_concat(['{{ foo }}', '{{ bar }}'])
    assert value == '{{ foo }}{{ bar }}'