

# Generated at 2022-06-23 13:12:35.417530
# Unit test for function ansible_native_concat

# Generated at 2022-06-23 13:12:44.535172
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == 12
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([1, 2, 3, 4, 5]) == 12345

# Generated at 2022-06-23 13:12:54.112540
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def _escape_func(s):
        return '{{%s}}' % s

    assert ansible_native_concat([]) == None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, 2]) == '12'
    assert isinstance(ansible_native_concat([1, 2]), text_type)
    assert isinstance(ansible_native_concat(['1', '2']), text_type)

    assert ansible_native_concat([1, 2]) == 12
    assert ansible_native_concat([1, 2]) != '12'
    assert ansible_native_concat(['1', 2]) == '12'
    assert ansible_native_con

# Generated at 2022-06-23 13:13:05.178538
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # test string type, literal_eval convert it to unicode
    assert ansible_native_concat(['string']) == 'string'
    assert type(ansible_native_concat(['string'])) == text_type

    # test unicode type, literal_eval convert it to unicode
    assert ansible_native_concat([u'unicode\u0020string']) == u'unicode\u0020string'
    assert type(ansible_native_concat([u'unicode\u0020string'])) == text_type

    # test byte type, literal_eval convert it to str
    assert ansible_native_concat([b'byte\x20string']) == b'byte\x20string'
    assert type(ansible_native_concat([b'byte\x20string'])) == str



# Generated at 2022-06-23 13:13:17.692001
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_bytes

    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == "12"
    assert ansible_native_concat([1, 2, 3]) == "123"
    assert ansible_native_concat([u"a", "b"]) == u"ab"
    assert ansible_native_concat([u"a", b"b"]) == u"ab"
    assert ansible_native_concat([b"a", u"b"])

# Generated at 2022-06-23 13:13:28.054125
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class Node:
        def __init__(self, value):
            self.value = value
        def __str__(self):
            return self.value

    # test concat with a generator
    def generator():
        yield Node('foo')
        yield Node('bar')
        yield Node('baz')
    assert ansible_native_concat(generator()) == 'foobarbaz'

    # test concat with a list
    assert ansible_native_concat([Node(1), Node(2), Node(3)]) == '123'

    # test single object
    assert ansible_native_concat([Node(1)]) == 1

    # test empty object
    assert ansible_native_concat([]) is None

    # Test with variables that are not strings at the root of the sequence
    assert ansible_native_

# Generated at 2022-06-23 13:13:38.773925
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import string_types
    from ansible.module_utils.common.text.converters import to_str

    # Test arguments that do not require any processing
    assert ansible_native_concat([5]) == 5
    assert ansible_native_concat([5.0]) == 5.0
    assert ansible_native_concat([[1, 2, 3]]) == [1, 2, 3]
    assert isinstance(ansible_native_concat(['a']), string_types)

# Generated at 2022-06-23 13:13:49.573110
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(['a', ' ', 'b', '\t', 'c']) == 'a b\tc'
    assert ansible_native_concat([['a', 'b'], [('c', ['d']), 'e'], 'f']) == ['abc', ['d'], 'e', 'f']
    assert ansible_native_concat(['123', '0', '', '456']) == 1230456
    assert ansible_native_concat(['0x10', 'ff', '', '0b111']) == 0x10ff0b111
    assert ansible_native_concat(['-5', '0', '', '6.5']) == -50.5

# Generated at 2022-06-23 13:14:01.124397
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.six import string_types

    # use the following snippet to generate the dictionary below:
    # tests = {'{{ [1,2] + [3,4] }}': [1, 2, 3, 4],
    #          '{{ {1,2} | union({3,4}) }}': {1, 2, 3, 4},
    #          '{{ {1:2,1:3} }}': {1: 3},
    #          '{{ [1,2,3] | join }}': '123',
    #          '{{ [1,2,3] | join(",") }}': '1,2,3',
    #          '{{ [1,2,3] | join(var) }}': '123',
    #          '{{ [1,2,3] | join(var, True) }}

# Generated at 2022-06-23 13:14:11.676075
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """
    >>> test_ansible_native_concat() #doctest: +ELLIPSIS, +NORMALIZE_WHITESPACE
    True
    True
    True
    True
    >>>
    """
    # see https://github.com/pallets/jinja/blob/master/src/jinja2/nativetypes.py
    # test_empty_string
    assert ansible_native_concat([]) is None

    # test_single_string
    assert ansible_native_concat([u'foobar']) == u'foobar'

    # test_single_none
    assert ansible_native_concat([None]) is None

    # test_single_expression
    # (addition is converted to a single node/value by the jinja parser)
    assert ansible_native_concat

# Generated at 2022-06-23 13:14:20.252944
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2
    env = jinja2.Environment(extensions=['jinja2_ansible.nativetypes'])
    t = env.template_class.from_code(env, '{% filter ansible_native_concat %}a{% endfilter %}')
    assert t.render() == 'a'
    t = env.template_class.from_code(env, '{% filter ansible_native_concat %}{{ 1 }}{% endfilter %}')
    assert t.render() == '1'
    t = env.template_class.from_code(env, '{% filter ansible_native_concat %}{{ "1" }}{% endfilter %}')
    assert t.render() == '1'

# Generated at 2022-06-23 13:14:28.971117
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo']) != 'bar'

    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 'bar']) != 'barfoo'

    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat([42]) != 21

    assert ansible_native_concat([42, 23]) == '4223'
    assert ansible_native_concat([42, 23]) != '2342'

    # literal_eval of an int
    assert ansible_native_concat(['42']) == 42
    assert ansible_native_concat(['42']) != 23


# Generated at 2022-06-23 13:14:38.203138
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['test']) == 'test'
    assert ansible_native_concat(['test', 'test2']) == 'testtest2'
    assert ansible_native_concat(['test', 1]) == 'test1'
    assert ansible_native_concat(['test', 1, 2]) == 'test12'
    assert ansible_native_concat(['test', 1, 2, u'\U0001F600']) == 'test12\U0001F600'

    # test ast.literal_eval
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat(['42']) == 42

# Generated at 2022-06-23 13:14:47.363035
# Unit test for function ansible_native_concat

# Generated at 2022-06-23 13:14:56.013873
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['"a"']) == 'a'
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat(['None']) is None
    assert ansible_native_concat(['"foo"']) == 'foo'
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['1.0']) == 1.0
    assert ansible_native_concat(['[1]']) == [1]
    assert ansible_native_concat(['{"a": 1}']) == {"a": 1}
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ans

# Generated at 2022-06-23 13:15:03.701400
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    text_values = [
        [],
        ['hello'],
        [1],
        [None],
        [True],
        [False],
        [u'hello'],
        [u'Ümlaut'],
        [2 ** 32 - 1],
        [2 ** 64 - 1],
        [1e50],
        [1.0],
        [[1, 2, 3]],
        [{1: 2, 3: 4, 5: 6}],
        [{'a': 'b'}],
    ]

    nodes = [to_text(container_to_text(v)) for v in text_values]
    assert text_values == [ansible_native_concat(nodes)] * len(nodes)

    text_values[0] = []
    assert text_values[0] == ans

# Generated at 2022-06-23 13:15:10.243875
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.utils import native_jinja

    class MyNativeJinjaText(NativeJinjaText):
        template_name = 'mytest'

    assert ansible_native_concat(['Hello']) == 'Hello'
    assert ansible_native_concat(['Hello', 'world']) == 'Helloworld'
    assert ansible_native_concat(['Hello', 'world'], False) == 'Helloworld'
    assert ansible_native_concat(['Hello', 'world'], True) == 'Hello world'
    assert ansible_native_concat(['Hello world']) == "Hello world"
    assert ansible_native_concat([MyNativeJinjaText('Hello world')]) == MyNativeJinjaText('Hello world')

# Generated at 2022-06-23 13:15:20.430080
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Unit test for function ansible_native_concat"""
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(["foo"]) == "foo"
    assert ansible_native_concat(["foo", "bar"]) == "foobar"
    assert ansible_native_concat(["foo", "bar", "baz"]) == "foobarbaz"
    assert ansible_native_concat(["foo", 1, "bar", "baz", None]) == "foo1barbazNone"
    assert ansible_native_concat(["foo", 1]) == "foo1"
    assert ansible_native_concat(["foo", "1"]) == "foo1"

# Generated at 2022-06-23 13:15:29.279528
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([u'1']) == 1
    assert ansible_native_concat([u'1', u'2']) == 12
    assert isinstance(ansible_native_concat([u'1', u'2']), text_type)
    assert ansible_native_concat([u'1', u'2']) == container_to_text(u'1') + u'2'
    assert ansible_native_concat([u'1', u'2', u'3']) == container_to_text(u'1') + u'2' + container_to_text(u'3')

# Generated at 2022-06-23 13:15:36.369854
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(["a", " ", "b"]) == 'a b'
    assert ansible_native_concat(["", "abc"]) == 'abc'
    assert ansible_native_concat(["123"]) == 123
    assert ansible_native_concat([['a', 'b'], ['c', 'd']]) == ['a', 'b', 'c', 'd']
    assert ansible_native_concat([{'a': 'b'}, {'c': 'd'}]) == {'a': 'b', 'c': 'd'}
    assert ansible_native_concat([['a', 'b'], {'c': 'd'}]) == "['a', 'b', {'c': 'd'}]"

# Generated at 2022-06-23 13:15:41.416871
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat([1, 2.0, 'a']) == [1, 2.0, 'a']
    assert ansible_native_concat(['1', '2', '3']) == '123'
    assert ansible_native_concat(['1', '2.0', "'a'"]) == '1 2.0 a'
    assert ansible_native_concat(['1', '2.0', "'a'", '{"a": 1}']) == '1 2.0 a {"a": 1}'

# Generated at 2022-06-23 13:15:49.787193
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test cases for the ansible_native_concat function."""

    # NOTE: The following tests are being disabled as they are in
    # conflict with the patch introduced in
    # https://github.com/pallets/jinja/pull/1212. The patch was not
    # released into upstream Jinja2, so these tests may become relevant
    # in the future if the patch is merged or a similar change occurs.
    # See https://github.com/ansible/ansible/issues/70831.

    # # Test case 1:
    # # list of two values that can be literately evaluated
    # nodes = [u'1', u'2']
    # assert ansible_native_concat(nodes) == 12

    # # Test case 2:
    # # list of two values that can be literately evaluated
    # nodes = [

# Generated at 2022-06-23 13:15:58.648028
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import ast
    import sys

    if sys.version_info < (2, 7):
        # ast.literal_eval was introduced in Python 2.7.
        return

    assert ansible_native_concat([]) is None
    assert ansible_native_concat([3]) == 3
    assert ansible_native_concat(['3']) == '3'
    assert ansible_native_concat(['0xff']) == 0xff
    assert ansible_native_concat(['True'])
    assert ansible_native_concat(['False']) is False
    assert ansible_native_concat(['None']) is None
    assert ansible_native_concat(['[1, 2, 3]']) == [1, 2, 3]

# Generated at 2022-06-23 13:16:06.742123
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def test(raw, expected):
        result = ansible_native_concat(raw)
        assert result == expected, 'got %r instead of %r' % (result, expected)

    # empty input
    test([], None)

    # simple literals
    test(['42'], 42)
    test([None], None)
    test(['True'], True)
    test(['False'], False)
    test(['test'], 'test')
    test(['42', 'test'], '42test')

    # complex literals
    test(['[1]'], [1])
    test(['{1}'], {1})
    test(['(1, 2)'], (1, 2))
    test(['{1, 2}'], {1, 2})

# Generated at 2022-06-23 13:16:16.409052
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common._collections_compat import OrderedDict


# Generated at 2022-06-23 13:16:24.627575
# Unit test for function ansible_native_concat
def test_ansible_native_concat(): # noqa
    assert container_to_text(['a', 'b', 'c']) == 'a b c'
    assert container_to_text(['a', ['b', 'c']]) == 'a b c'
    assert container_to_text(['a', {'b': 'c'}]) == 'a b=c'
    assert container_to_text(['a', {'b': {'c': 'd'}}]) == 'a b={c=d}'
    assert container_to_text(['a', {'b': {'c': ['d', 'e']}}]) == 'a b={c=d e}'
    assert container_to_text(['a', {'b': {'c': ['d', ['e', 'f']]}}]) == 'a b={c=d e f}'

# Generated at 2022-06-23 13:16:35.408201
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, '2']) == '12'
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(1) == 1

    assert ansible_native_concat(['1', '2']) == 1
    assert ansible_native_concat(['1.1', '2.5']) == 1.1
    assert ansible_native_concat(['1.0', '2.5']) == 1.0
    assert ansible_native_concat(['1.0', '2.5', '3.0']) == '1.02.53.0'
    assert ansible_native_concat(['1+2', '2*3']) == '1+22*3'

# Generated at 2022-06-23 13:16:43.261163
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.constructor import Constructor
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.template import Templar
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch, MagicMock

    mock_dumper = MagicMock(AnsibleDumper)

    builtin = __builtins__ if isinstance(__builtins__, dict) else __builtins__.__dict__

    with patch.dict(builtin, {'unicode': str}):
        yaml = Constructor(mock_dumper)
        templar = Templar(loader=None, variables={})

        assert ansible_native_con

# Generated at 2022-06-23 13:16:52.645145
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['abc']) == 'abc'
    assert ansible_native_concat(['abc', 'def']) == 'abcdef'
    assert ansible_native_concat([1, 'def']) == '1def'
    assert ansible_native_concat(['abc', False]) == 'abcFalse'
    assert ansible_native_concat(['12', 34]) == 1234
    assert ansible_native_concat(['123', 4]) == 1234
    assert ansible_native_concat(['12.3', 4]) == 12.34
    assert ansible_native_concat(['True', False]) is True



# Generated at 2022-06-23 13:17:00.801651
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(["a", "b"]) == 'ab'
    assert ansible_native_concat([u"a", u"b"]) == u'ab'
    assert ansible_native_concat([u"a", "b"]) == 'ab'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(["a", ["b"]]) == 'ab'
    assert ansible_native_concat(['a', ['b']]) == 'ab'
    assert ansible_native_concat([u"a", [u"b"]]) == u'ab'
    assert ansible_native_concat([u"a", ['b']]) == u'ab'


# Generated at 2022-06-23 13:17:10.650566
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import os
    import sys
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
    from ansible.module_utils.common.text import jinja2_native_concat
    assert jinja2_native_concat([]) == None
    assert jinja2_native_concat([123]) == 123
    assert jinja2_native_concat(['123']) == 123
    assert jinja2_native_concat(['12', '3']) == 123
    assert jinja2_native_concat([1, 23]) == 123
    assert jinja2_native_concat([1, '23']) == 123

# Generated at 2022-06-23 13:17:17.255310
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', '{{ bar }}', 'baz']) == 'foo{{ bar }}baz'
    assert ansible_native_concat(['foo', '{{ bar }}', '1']) == 'foo{{ bar }}1'
    assert ansible_native_concat(['foo', '{{ bar }}', 1]) == 'foo{{ bar }}1'
    assert ansible_native_concat(['foo', '{{ bar }}', 1.0]) == 'foo{{ bar }}1.0'
    assert ansible_native_concat(['foo', '{{ bar }}', []]) == 'foo{{ bar }}[]'
    assert ansible_native_concat(['foo', '{{ bar }}', ()]) == 'foo{{ bar }}()'

# Generated at 2022-06-23 13:17:26.800859
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert container_to_text(ansible_native_concat([1])) == '1'
    assert container_to_text(ansible_native_concat([1, 2])) == '12'
    assert container_to_text(ansible_native_concat([1, '2', 3])) == '123'
    assert container_to_text(ansible_native_concat(['a_string', '_', 'with_underscores'])) == 'a_string_with_underscores'
    assert ansible_native_concat([1, ' ', 2, ',', 3, ' ', 4]) == '1 2,3 4'



# Generated at 2022-06-23 13:17:35.767602
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.data import SafeString
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict

    assert ansible_native_concat([]) == None

    assert ansible_native_concat(iter([])) == None

    assert ansible_native_concat([
        'string'
    ]) == 'string'

    assert ansible_native_concat([
        AnsibleUnsafeText('unsafe')
    ]) == 'unsafe'

    assert ansible_native_concat([
        AnsibleUnsafeBytes('unsafe')
    ]) == b'unsafe'


# Generated at 2022-06-23 13:17:47.011705
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_text

    assert ansible_native_concat([u'foo']) == to_text(u'foo')
    assert ansible_native_concat([u'foo', u'bar']) == to_text(u'foobar')
    assert ansible_native_concat([u'foo', u'1']) == to_text(u'foo1')
    assert ansible_native_concat([u'foo', u'1.0']) == to_text(u'foo1.0')
    assert ansible_native_concat([u'foo', u'True']) == to_text(u'fooTrue')

# Generated at 2022-06-23 13:17:54.035471
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # pylint: disable=bad-whitespace,line-too-long,bad-continuation

    # Boolean
    assert ansible_native_concat(['true']) == True
    assert ansible_native_concat(['TrUe']) == True
    assert ansible_native_concat(['false']) == False
    assert ansible_native_concat(['False']) == False

    # Integer
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['-1']) == -1
    assert ansible_native_concat(['-1']) == -1
    assert ansible_native_concat(['-1', '0']) == '-10'

    # Float

# Generated at 2022-06-23 13:18:03.634735
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('foo') == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat('') is None
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat(['true', 'false']) is True
    assert ansible_native_concat(['True', 'False']) is True
    assert ansible_native_concat(['false', 'true']) is False
    assert ansible_native_concat(['False', 'True']) is False
    assert ansible_native_concat(['1', '2']) == 1
    assert ansible_

# Generated at 2022-06-23 13:18:14.219009
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2

    env = jinja2.Environment(variable_start_string='{{', variable_end_string='}}',
                             finalize=ansible_native_concat)

    assert env.from_string('{{ foo }}').render(foo=1) == 1
    assert env.from_string('{{ [1,2,3] }}').render() == [1,2,3]
    assert env.from_string('{{ "a"|string }}').render() == "a"
    assert env.from_string('{{ "1"+"2" }}').render() == "12"
    assert env.from_string('{{ "1"+2 }}').render() == "12"
    assert env.from_string('{{ "foo"|bar }}').render(bar=container_to_text) == "foo"

# Generated at 2022-06-23 13:18:24.842821
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # test undefined
    class Class:
        pass

    data = Class()
    data.data = StrictUndefined()
    data.data = ansible_native_concat([data.data])
    assert data.data is StrictUndefined
    assert str(data.data) == 'undefined'

    data.data = StrictUndefined()
    data.data = ansible_native_concat([data.data])
    assert data.data is StrictUndefined
    assert str(data.data) == 'undefined'

    # test string (for backcompat)
    data.data = ansible_native_concat([u'foo'])
    assert data.data == 'foo'
    # test str (for backcompat)
    data.data = ansible_native_concat(['foo'])
    assert data

# Generated at 2022-06-23 13:18:35.034631
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None

    node = NativeJinjaText('x')
    assert ansible_native_concat([node]) == 'x'

    assert ansible_native_concat([node, node]) == 'xx'

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'

    assert ansible_native_concat([1, 2, 3]) == '123'

    assert ansible_native_concat(iter([1, 2, 3])) == '123'

    assert ansible_native_concat([]) == None

    assert ansible_native_concat([1.1]) == 1.1

# Generated at 2022-06-23 13:18:44.340812
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    (str1, str2, str3, str4, str5, str6, str7, str8, str9, str10, str11, str12, str13) = (
        'str1', 'str2', 'str3', 'str4', 'str5', 'str6', 'str7', 'str8', 'str9', 'str10', 'str11', 'str12', 'str13')
    dict_type = dict(key='value')
    list_type = ['value',]

    assert ansible_native_concat([None,]) == None
    assert ansible_native_concat([None, None,]) == None
    assert ansible_native_concat([str1,]) == str1
    assert ansible_native_concat([str1, None,]) == str1
    assert ansible_native_

# Generated at 2022-06-23 13:18:55.198039
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, 'foo', '', '', 'bar']) == '1foobar'
    assert ansible_native_concat([long(1), 2, 'foo', '', 'bar']) == '1foobar'
    assert ansible_native_concat([['a'], [1, 2, 3], ['b']]) == '[a][1, 2, 3]b'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', '']) == 'a'
    assert ansible_native_concat(['', 'a']) == 'a'

# Generated at 2022-06-23 13:19:02.661701
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import operator
    import jinja2

    env = jinja2.Environment(undefined=jinja2.StrictUndefined)
    env.finalize = ansible_native_concat
    env.filters['to_text'] = to_text

    assert env.from_string(
        """{{ 1 | string }}"""
    ).render() == '1'

    assert env.from_string(
        """{{ 'a' | string }}"""
    ).render() == 'a'

    assert env.from_string(
        """{{ 'a' }}"""
    ).render() == 'a'

    assert env.from_string(
        """{{ ['a', 'b'] | list }}"""
    ).render() == ['a', 'b']


# Generated at 2022-06-23 13:19:13.831355
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([True, 'foo', 'bar']) == u'foobar'
    assert ansible_native_concat([True, 'foo', False, 'bar']) == u'foobar'
    assert ansible_native_concat(['foo', 'bar']) == u'foobar'
    assert ansible_native_concat([1, 2, 'foo', 'bar']) == u'12foobar'
    assert ansible_native_concat(['foo', 2, 'bar']) == u'foo2bar'
    assert ansible_native_concat([1, ['foo', 'bar']]) == u'1foo,bar'
    assert ansible_native_concat([1, 'foo', ['bar']]) == u'1foobar'
    assert ansible_native_con

# Generated at 2022-06-23 13:19:21.741741
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([NativeJinjaText('str_in_list')]) == 'str_in_list'
    assert ansible_native_concat([NativeJinjaText('str_in_list'), NativeJinjaText('str_in_list')]) == 'str_in_liststr_in_list'
    assert ansible_native_concat([NativeJinjaText('in_list')]) == 'in_list'
    assert ansible_native_concat([NativeJinjaText('in_list'), NativeJinjaText('in_list')]) == 'in_listin_list'
    assert ansible_native_concat([NativeJinjaText('str_in_list')]) == 'str_in_list'

# Generated at 2022-06-23 13:19:31.616910
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_list
    from ansible.module_utils.six import PY3

    def simulate_compiled_node(data):
        # simulate compiled node
        if isinstance(data, list):
            return data
        else:
            return [data]

    if PY3:
        # On PY2, they're equals
        assert ansible_native_concat(simulate_compiled_node(None)) is None
        assert ansible_native_concat(simulate_compiled_node([])) is None
        assert ansible_native_concat(simulate_compiled_node('')) is ''
        assert ansible_native_concat(simulate_compiled_node([])) is None

# Generated at 2022-06-23 13:19:42.969901
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([123]) == 123
    assert ansible_native_concat(['abc']) == 'abc'
    assert ansible_native_concat([u'abc']) == u'abc'
    assert ansible_native_concat([None, None]) is None
    assert ansible_native_concat([None, 123]) == None
    assert ansible_native_concat([123, 123]) == 123
    assert ansible_native_concat(['abc', 'def']) == 'abcdef'
    assert ansible_native_concat(['abc', 'def', 'ghi']) == 'abcdefghi'

# Generated at 2022-06-23 13:19:54.945285
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Test basic concatenation
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat([1, '2']) == '12'
    assert ansible_native_concat([1, 2]) == '12'

    # Test concatenation with evaluation
    assert ansible_native_concat(['1', '2', '3', '4']) == 1234
    assert ansible_native_concat(['0b1', '0b10']) == 3
    assert ansible_native_concat(['0x1', '0x10']) == 17
    assert ansible_native_concat(['1', '2', '3', '4', '5', '6']) == '123456'

# Generated at 2022-06-23 13:20:03.644948
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == "12"
    assert ansible_native_concat(['1', '2']) == "12"
    assert ansible_native_concat(['1', '2', '3']) == "123"
    assert ansible_native_concat([1, 2, 3]) == "123"
    assert ansible_native_concat(['a', 'b', 'c']) == "abc"
    assert ansible_native_concat(['a', 2, 'c']) == "a2c"

# Generated at 2022-06-23 13:20:14.367395
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    org_concat = ansible_native_concat
    def ansible_native_concat_test(nodes):
        return org_concat(nodes)

    assert ansible_native_concat_test(['test']) == 'test'
    assert ansible_native_concat_test(['1', '2']) == 12
    assert ansible_native_concat_test([12, 34]) == 1234
    assert ansible_native_concat_test([12, '34']) == '1234'

    assert ansible_native_concat_test(['1', '2', '3']) == u'123'
    assert ansible_native_concat_test(['foo', 'bar']) == u'foobar'

# Generated at 2022-06-23 13:20:19.981027
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == 1
    assert ansible_native_concat(['foo', 1, 2, 3]) == 'foo'
    assert ansible_native_concat(['foo', 'bar', 'baz']) == 'foobarbaz'
    assert ansible_native_concat([10, 20, 30, 'foo', 'bar', 'baz']) == '102030foobarbaz'
    assert ansible_native_concat([10, 20, 30, 'foo', 'bar', 'baz']) == '102030foobarbaz'
    assert ansible_native_concat([10, 20, 30, 'foo', 'bar', 'baz']) == '102030foobarbaz'

# Generated at 2022-06-23 13:20:32.048231
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat(['1', '2', '3']) == 123

    assert ansible_native_concat([0]) == 0
    assert ansible_native_concat(['0']) == 0
    assert ansible_native_concat([0, 1]) == '01'
    assert ansible_native_concat(['0', '1']) == '01'

    assert ansible_native_concat([[1, 2, 3], [4, 5]]) == '[1, 2, 3][4, 5]'
    assert ansible_native_concat(['[1, 2, 3]', '[4, 5]']) == '[[1, 2, 3], [4, 5]]'

    assert ansible_

# Generated at 2022-06-23 13:20:40.116599
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([3]) == 3
    assert ansible_native_concat(['3']) == 3
    assert ansible_native_concat(['3']) == 3
    assert ansible_native_concat(['0x3']) == '0x3'
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar', '1', '2', '3']) == 'foobar123'
    assert ansible_native_concat(['foo', '', 'bar', '1', None, '2', 3]) == 'foobar123'
    assert ansible_native_concat(['"foobar"']) == '"foobar"'
    assert ans

# Generated at 2022-06-23 13:20:52.270977
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    x = NativeJinjaText(container_to_text({'foo': 'baz'}))
    y = NativeJinjaText(container_to_text({'bar': 'quz'}))

    assert ansible_native_concat((x, y)) == "{'foo': 'baz'}{'bar': 'quz'}"

    assert ansible_native_concat([x, y]) == "{'foo': 'baz'}{'bar': 'quz'}"

    assert ansible_native_concat((x, 'x', y)) == "{'foo': 'baz'}x{'bar': 'quz'}"

    assert ansible_native_concat([x, 'x', y]) == "{'foo': 'baz'}x{'bar': 'quz'}"

    assert ansible_native_

# Generated at 2022-06-23 13:21:04.199154
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['test']) == 'test'
    assert ansible_native_concat(['{', 'ns', ':', 'v1', '}']) == '{ns:v1}'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', 1, 2, 'b']) == 'a12b'
    assert ansible_native_concat([1, 2]) == [1, 2]
    assert ansible_native_concat([{1: 2}]) == {1: 2}
    assert ansible_native_concat(['{"a": "b"}']) == {'a': 'b'}
    assert ansible_native

# Generated at 2022-06-23 13:21:15.094494
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test the function with string arguments
    assert ansible_native_concat([u'abc']) == u'abc'
    assert ansible_native_concat([u'abc', u'def']) == u'abcdef'
    assert ansible_native_concat([u'abc', 4567]) == u'abc4567'
    assert ansible_native_concat([u'abc', 4567, u'ghi']) == u'abc4567ghi'
    assert ansible_native_concat([u'abc', 4567, u'ghi', 9012]) == u'abc4567ghi9012'

    # Test the function with list arguments
    assert ansible_native_concat([[1, 2, 3]]) == u'[1, 2, 3]'

# Generated at 2022-06-23 13:21:26.674608
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat([42, 43, 44]) == '424344'
    assert ansible_native_concat([42.43, 43.44, 44.45]) == '42.4343.4444.45'
    assert ansible_native_concat(['foo', 'bar', 'baz']) == 'foobarbaz'
    assert ansible_native_concat([u'foo', u'bar', u'baz']) == u'foobarbaz'
    assert ansible_native_concat([u'foo\n', u'bar\n', u'baz']) == u'foo\nbar\nbaz'

# Generated at 2022-06-23 13:21:34.320477
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['["a", "b", 3]']) == ['a', 'b', 3]
    assert ansible_native_concat(['{"a": 1, "b": 2}']) == {'a': 1, 'b': 2}
    assert ansible_native_concat(['1 + 2']) == '1 + 2'
    assert ansible_native_concat(['3\n']) == 3
    assert ansible_native_concat(['true\n']) is True
    assert ansible_native_concat(['false\n']) is False
    assert ansible_native_concat(['abc\n']) == 'abc'
    assert ansible_native_concat(['abc', 'def']) == 'abcdef'
    assert ansible_native_concat

# Generated at 2022-06-23 13:21:45.241959
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(
        ['foo', 'bar', 'baz']
    ) == u'foobarbaz'
    assert ansible_native_concat(
        ['foo', 'bar', None]
    ) == u'foobarNone'
    assert ansible_native_concat(
        ['foo', 'bar', [1, 2, 3]]
    ) == u'foobar[1, 2, 3]'
    assert ansible_native_concat(
        ['foo', 'bar', {'foo': 'bar'}]
    ) == u'foobar{foo: bar}'
    assert ansible_native_concat(
        ['foo', 'bar', 'baz', True]
    ) == u'foobarbazTrue'

# Generated at 2022-06-23 13:21:56.611323
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Concatenate and return text
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', None, 'bar']) == 'foobar'
    assert ansible_native_concat([None, 'foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 'bar', None]) == 'foobar'

    # Concatenate and parse to native type
    assert ansible_native_concat(['foo', 2, 'bar']) == 'foo2bar'
    assert ansible_native_concat(['foo', True, 'bar']) == 'foobar'

    # Single item is returned as-is
    assert ansible_native_concat(['foo']) == 'foo'


# Generated at 2022-06-23 13:22:08.530463
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # This is a shallow test of the function.
    # It is not meant to cover every single
    # possibility of the nested structures, just a few representative
    # cases.
    assert ansible_native_concat([]) is None

    # The result of a single string eval should be a string, not the
    # parsed native type
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['1']) == '1'
    assert ansible_native_concat(['{"a": 1}']) == '{"a": 1}'
    assert ansible_native_concat(['{"a": 1}']) == '{"a": 1}'
    assert ansible_native_concat(['"foo"']) == '"foo"'
    assert ansible_native_con

# Generated at 2022-06-23 13:22:20.408113
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat(['a', 2, 'c']) == ['a', 2, 'c']
    assert ansible_native_concat(('a', 'b', 'c')) == 'abc'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(iter(['a', 'b', 'c'])) == 'abc'
    assert ansible_native_concat([1, 'b', 3]) == '[1, b, 3]'
    assert ansible_native_concat(x for x in ['a', 'b', 'c']) == 'abc'

# Generated at 2022-06-23 13:22:32.847670
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.utils.native_jinja import NativeJinjaText

    assert ansible_native_concat([]) is None

    assert ansible_native_concat([42]) == 42