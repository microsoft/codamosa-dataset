

# Generated at 2022-06-23 13:12:35.313749
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 1, 2, 'bar']) == 'foo12bar'
    assert ansible_native_concat([1, ['foo'], {'bar': 'baz'}]) == '1[\'foo\']{\'bar\': \'baz\'}'
    assert ansible_native_concat([1, ['foo'], {'bar': 'baz'}]) == '1[\'foo\']{\'bar\': \'baz\'}'
    assert ansible_native_concat([1, ['foo'], {'bar': {'baz': 'foo'}}]) == '1[\'foo\']{\'bar\': {\'baz\': \'foo\'}}'

   

# Generated at 2022-06-23 13:12:41.835903
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', ' bar']) == 'foo bar'
    assert ansible_native_concat(['foo', '    bar']) == 'foo    bar'
    assert ansible_native_concat(['foo', ' bar']) == 'foo bar'
    assert ansible_native_concat(['foo', ['', '  '], '    bar']) == 'foo         bar'

# Generated at 2022-06-23 13:12:52.182109
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # test that we can concat two strings and get a string
    mystring = 'abc'
    result = ansible_native_concat([mystring, mystring])
    assert result == mystring + mystring

    # test that we can concat two numbers and get a number
    myint = 123
    result = ansible_native_concat([myint, myint])
    assert result == myint + myint

    # test that we get a single number if we only concat on number
    result = ansible_native_concat([myint])
    assert result == myint

    # test that we can parse an expression string and get a number
    result = ansible_native_concat(['{0} + {0}'.format(myint)])
    assert result == myint + myint

    # test that we get a single

# Generated at 2022-06-23 13:13:01.170244
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils import native_jinja
    assert native_jinja.ansible_native_concat(['a']) == u'a'
    assert native_jinja.ansible_native_concat(['a', 'b']) == u'ab'
    assert native_jinja.ansible_native_concat([1, 2]) == u'12'
    assert native_jinja.ansible_native_concat([1, 2, 3]) == u'123'
    assert native_jinja.ansible_native_concat([1, 'b', 3]) == u'1b3'
    assert native_jinja.ansible_native_concat([1, 2, 'c']) == u'12c'

# Generated at 2022-06-23 13:13:09.904312
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert 'foo1bar' == ansible_native_concat(['foo', '1', 'bar'])
    assert 'foo1bar' == ansible_native_concat([['foo'], ['1'], ['bar']])
    assert '10' == ansible_native_concat(['1', '0'])
    assert '1.0' == ansible_native_concat(['1', '.0'])
    assert AnsibleVaultEncryptedUnicode('foo') == ansible_native_concat([AnsibleVaultEncryptedUnicode('foo')])
    assert u'foobar' == ansible_native_concat([u'foo', u'bar'])
    assert u'foobar' == ansible_native_concat([u'foo', u'', u'bar'])
    assert u

# Generated at 2022-06-23 13:13:20.401381
# Unit test for function ansible_native_concat

# Generated at 2022-06-23 13:13:29.566662
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    namespace = {
        'ansible_native_concat': ansible_native_concat,
        'test_sequence': ['a', 'b'],
    }


# Generated at 2022-06-23 13:13:41.564715
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 1]) == 'foo1'
    assert ansible_native_concat(['foo', 1, None]) == 'foo1None'
    assert ansible_native_concat([1, 'foo']) == '1foo'
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat(['foo', 'bar', 'baz']) == 'foobarbaz'

# Generated at 2022-06-23 13:13:50.390527
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat([['a', 'b', 'c'], [1, 2, 3]]) == ['a', 'b', 'c', 1, 2, 3]
    assert ansible_native_concat([['a', 'b', 'c'], 1, 2, 3]) == ['a', 'b', 'c', 1, 2, 3]
    assert ansible_native_concat([['a', 'b', 'c'], '1', '2', '3']) == ['a', 'b', 'c', '1', '2', '3']

# Generated at 2022-06-23 13:14:01.267924
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert container_to_text(ansible_native_concat([
        container_to_text(u"foo"),
        container_to_text(u"bar"),
        container_to_text(u"baz"),
    ])) == u"foobarbaz"
    assert container_to_text(ansible_native_concat([
        container_to_text(u"foo"),
        container_to_text(True),
        container_to_text(u"baz"),
    ])) == u"foobaz"
    assert container_to_text(ansible_native_concat([
        container_to_text(u"foo"),
        container_to_text(True),
        container_to_text(u"baz"),
    ])) == u"foobaz"

    assert ansible_native_

# Generated at 2022-06-23 13:14:11.780736
# Unit test for function ansible_native_concat

# Generated at 2022-06-23 13:14:20.311577
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    string_output = "string"

    # Test without literal_eval
    result = ansible_native_concat([string_output])
    assert result == string_output

    # Test with literal_eval
    result = ansible_native_concat([string_output])
    assert result == string_output

    # Test with literal_eval
    result = ansible_native_concat([7, " ", string_output, " ", "8"])
    assert result == "7 string 8"

    # Test with literal_eval
    result = ansible_native_concat([7, " ", string_output, " ", "8", " ", "9"])
    assert result == "7 string 8 9"

    # Test with literal_eval
    result = ansible_native_concat(["- ", "string"])

# Generated at 2022-06-23 13:14:29.051864
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([text_type(1)]) == 1
    assert ansible_native_concat([3]) == 3
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([False]) is False
    assert ansible_native_concat([[1, 2]]) == [1, 2]
    assert ansible_native_concat([(1, 2)]) == (1, 2)
    assert ansible_native_concat([{"1": 2}]) == {"1": 2}
    assert ansible_native_concat([container_to_text({"1": 2})]).strip() == '{u"1": 2}'
    assert ansible_native_concat([u'1']) == 1

# Generated at 2022-06-23 13:14:38.275764
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(["foo ", "bar"]) == "foo bar"
    assert ansible_native_concat(["foo ", "bar", "baz"]) == "foo barbaz"
    assert ansible_native_concat(["foo", "bar", "baz"]) == "foobarbaz"
    assert ansible_native_concat(["foo", "bar", {"baz": "qux"}]) == "foobar{'baz': 'qux'}"
    assert ansible_native_concat(["foo", "bar", "baz", "qux", [0]]) == "foobarbazqux[0]"
    assert ansible_native_concat(["foo", "bar", "baz", "qux", [[]]]) == "foobarbazqux[[]]"


# Generated at 2022-06-23 13:14:47.392382
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['123']) == '123'
    assert ansible_native_concat(['True']) is True
    assert ansible_native_concat(['False']) is False
    assert ansible_native_concat(['None']) is None
    assert ansible_native_concat(['test']) == 'test'
    assert ansible_native_concat(['4', '2']) == 42
    assert ansible_native_concat(['4', '2']) == 42
    assert ansible_native_concat(['1.', '0']) == 1.0

    assert ansible_native_concat(['{', '4', ':', '2', '}']) == {4: 2}

# Generated at 2022-06-23 13:14:56.010571
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, 2, '3']) == [1, 2, '3']
    assert ansible_native_concat(['2', '+', '2']) == 4
    assert ansible_native_concat(['2.1', '+', '2']) == 4.1
    assert ansible_native_concat(['-1', '+', '-2']) == -3
    assert isinstance(ansible_native_concat(['2', '+', '-2']), int)
    assert isinstance(ansible_native_concat(['2', '+', '-2.1']), float)

# Generated at 2022-06-23 13:15:03.673705
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # testing ansible_native_concat
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['test']) == 'test'
    assert ansible_native_concat(['t', 'e', 's', 't']) == 'test'
    assert ansible_native_concat([1, 2, 3, 4]) == '1234'
    assert ansible_native_concat([['t', 'e'], ['s', 't']]) == 'test'
    assert ansible_native_concat([[['t', 'e'], ['s', 't']]]) == 'test'
    assert ansible_native_concat([['t,e'], ['s', 't']]) == 'test'

# Generated at 2022-06-23 13:15:10.219535
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(()) == None
    assert ansible_native_concat(('a',)) == 'a'
    assert ansible_native_concat(('a', 'b')) == 'ab'
    assert ansible_native_concat(('', 'b')) == 'b'
    assert ansible_native_concat(('a', '')) == 'a'
    assert ansible_native_concat((('a',), ('b',))) == 'ab'
    assert ansible_native_concat(([1], ('b',))) == '1b'
    assert ansible_native_concat((NativeJinjaText('a'), NativeJinjaText('b'))) == 'ab'

# Generated at 2022-06-23 13:15:20.430118
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_native
    data = {
        'items': [
            None,
            False,
            True,
            682,
            [1, 2, 3],
            {'name': 'foo'},
            'bar',
        ]
    }

# Generated at 2022-06-23 13:15:26.306205
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def _test_concat(data, expected):
        data = container_to_text(data, indent=2)
        jinja_text = NativeJinjaText(data)
        result = ansible_native_concat([jinja_text])
        assert result == expected, 'Expected %s, got %s' % (expected, result)

    _test_concat('{{ [1] | to_json }}', [1])
    _test_concat('{{ "a" }}', 'a')
    _test_concat('{{ "a" }} {{ "b" }}', 'ab')
    _test_concat('{{ "a" }} {{ [1] | to_json }}', 'a [1]')
    _test_concat('{{ "a" }} {{ "{}" | from_json }}', 'a {}')

# Generated at 2022-06-23 13:15:34.645413
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'a', u'b', u'c']) == u'abc'
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat([u'a\n', u'b', u'\nc']) == u'ab\nc'
    assert ansible_native_concat([True, False]) == u'TrueFalse'
    assert ansible_native_concat([u'True', u'False']) == True is False
    assert ansible_native_concat([u'[1, 2, 3]', u'[4, 5, 6]']) == [1, 2, 3, 4, 5, 6]
    assert ansible_native_concat([u'1, 2, 3', u'4, 5, 6'])

# Generated at 2022-06-23 13:15:45.066257
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import meta
    from jinja2.filters import do_join, do_map
    from jinja2.runtime import Context
    import jinja2
    import os

    curr_dir = os.path.dirname(os.path.realpath(__file__))
    env = jinja2.Environment()
    env.filters['to_yaml'] = jinja2.filters.do_to_yaml
    env.filters['join'] = do_join
    env.filters['map'] = do_map

    def render(template):
        ast = env.parse(template)
        vars = meta.find_undeclared_variables(ast)

# Generated at 2022-06-23 13:15:57.044101
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # We need to make sure that the ansible_native_concat function
    # behaves the same way as Jinja's native_concat function.
    # Thus, we need to prepare a data structure similar to what
    # Jinja returns after the compilation of a template.
    # See:
    # https://github.com/ansible/ansible/issues/70831#issuecomment-663889003
    # https://github.com/pallets/jinja/issues/1200
    data = [u'foo', u' ', u'bar']

    # ansible_native_concat takes a generator as an input.
    # We can create one from the data list we've prepared so far.
    nodes = (x for x in data)

    # Jinja's native_concat function returns either the value of
    # the first node or concatenates

# Generated at 2022-06-23 13:16:07.773108
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    a = 42
    b = u'foo'
    c = {'bar': None}
    d = None
    e = ['a', 1, True]
    f = u'bar'
    g = {'baz': True}
    h = u'xyzzy'

    assert ansible_native_concat([a]) == 42
    assert ansible_native_concat([b]) == 'foo'
    assert ansible_native_concat([c]) == {'bar': None}
    assert ansible_native_concat([d]) is None
    assert ansible_native_concat([e]) == ['a', 1, True]
    assert ansible_native_concat([f]) == u'bar'
    assert ansible_native_concat([g]) == {'baz': True}

    assert ansible_

# Generated at 2022-06-23 13:16:16.888996
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2]) == [1, 2]
    assert ansible_native_concat(['1', '2']) == [1, 2]
    assert ansible_native_concat([1, 2, 3, 4, 3, 2, 1]) == [1, 2, 3, 4, 3, 2, 1]
    assert ansible_native_concat(['1', '2', '3', '4', '3', '2', '1']) == [1, 2, 3, 4, 3, 2, 1]
    assert ansible_native_concat(['a', 'b', 'c', 'd']) == ['a', 'b', 'c', 'd']
    assert ansible_native_concat(['a']) == ['a']
    assert ansible_native_con

# Generated at 2022-06-23 13:16:25.726866
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils import basic
    import unittest

    class TestUtilsTestCase(unittest.TestCase):

        def test_ansible_native_concat(self):
            _ansible_native_concat = ansible_native_concat
            self.assertEqual(
                _ansible_native_concat(('test',)),
                'test'
            )
            self.assertEqual(
                _ansible_native_concat((1, 2)),
                [1, 2]
            )
            self.assertEqual(
                _ansible_native_concat(('test', '-', 'test')),
                'test-test'
            )

# Generated at 2022-06-23 13:16:36.692971
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat({'foo': 'bar'}) == {'foo': 'bar'}
    assert ansible_native_concat({'foo': ['bar', 'baz']}) == {'foo': ['bar', 'baz']}
    assert ansible_native_concat({'foo': '{{ bar }}'}) == {'foo': '{{ bar }}'}
    assert ansible_native_concat('foo') == 'foo'
    assert ansible_native_concat('{{ bar }}') == '{{ bar }}'
    assert ansible_native_concat('bar') == 'bar'
    assert ansible_native_concat(['foo', 'bar', 'baz']) == 'foobarbaz'

# Generated at 2022-06-23 13:16:43.898398
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    data = {
        "a": "1",
        "b": "2",
        "c": "3",
        "d": ["4", "5", "6"],
        "e": "4",
        "f": ["5"],
        "g": [],
        "h": "8",
        "i": "9",
    }

    assert ansible_native_concat(['1', '2']) == "12"
    assert ansible_native_concat(['abc', 'def']) == "abcdef"
    assert ansible_native_concat([' abc ', ' def ']) == " abc  def "
    assert ansible_native_concat(['{{ a }}', '{{ b }}']) == "12"

# Generated at 2022-06-23 13:16:52.577245
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat((1, 2)) == "12"
    assert ansible_native_concat((1, 2, 3)) == "123"
    assert ansible_native_concat(["1", 2]) == "12"
    assert ansible_native_concat(["1", "2"]) == "12"
    assert ansible_native_concat([1, 2.0]) == "12"
    assert ansible_native_concat([None]) == "None"
    assert ansible_native_concat([{'name': 'a', 'value': 'b'}]) == "{'name': 'a', 'value': 'b'}"

    # TODO: How should literal_eval handle None?

# Generated at 2022-06-23 13:17:02.255705
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    literal_tests = [
        (['a'], 'a'),
        (['1'], 1),
        (['[1]'], [1]),
        (['[1, 2]'], [1, 2]),
        (['{1: "one"}'], {1: 'one'}),
    ]
    for nodes, expected in literal_tests:
        assert expected == ansible_native_concat(nodes)

    string_tests = [
        (['a', 'b'], 'ab'),
        (['a', '', 'b'], 'ab'),
        (['a', u'b', u'\u0442'], u'ab\u0442'),
        (['a', 'b', 'c'], 'abc'),
    ]
    for nodes, expected in string_tests:
        assert expected == ansible

# Generated at 2022-06-23 13:17:12.024539
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(
        [container_to_text(1), container_to_text(2), container_to_text(3)]
    ) == [1, 2, 3]

    assert ansible_native_concat(
        [container_to_text(1),
         container_to_text(2),
         container_to_text(3)]
    ) == [1, 2, 3]

    assert ansible_native_concat(
        [container_to_text(1),
         container_to_text(2),
         container_to_text(3)]
    ) == [1, 2, 3]

    assert ansible_native_concat(
        [container_to_text(1),
         container_to_text(2),
         container_to_text(3)]
    )

# Generated at 2022-06-23 13:17:17.838619
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([1, '2', 3]) == '123'

    assert ansible_native_concat([123]) == 123
    assert ansible_native_concat([True]) == True
    assert ansible_native_concat([None]) == None
    assert ansible_native_concat(['foo']) == 'foo'

    # in Python 2.7 literal_eval() doesn't handle unicode
    assert ansible_native_concat([u'\u2026']) == u'\u2026'

    # invalid Python expression
    assert ansible_

# Generated at 2022-06-23 13:17:24.041837
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    from ansible.template.safe_eval import AnsibleInclude
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat(['1']) == '1'
    assert ansible_native_concat([1, '2', 3]) == '123'
    assert ansible_native_concat(['1', 2, '3']) == '123'
    assert ansible_native_concat(['1', '2', '3']) == '123'
    assert ansible_native_concat([1, 2, '3']) == '123'

# Generated at 2022-06-23 13:17:34.766089
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicodeString
    from ansible.template.safe_eval import safe_eval
    from ansible.template.safe_eval import UndefinedError

    vault = VaultLib(b"ansible")
    vault_str = vault.encrypt(container_to_text(["one", "two"]))
    vault_obj = AnsibleVaultEncryptedUnicode(vault_str)

    # test AnsibleVaultEncryptedUnicode
    assert ansible_native_concat([vault_obj]) == vault_obj

    # test NativeJinjaText
    assert ansible_native_concat([NativeJinjaText("foo")]) == "foo"

    # test text
   

# Generated at 2022-06-23 13:17:46.383422
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Basic tests of literals
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([False]) is False
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([-1]) == -1
    assert ansible_native_concat([-1.0]) == -1.0
    assert ansible_native_concat([1.0]) == 1.0
    assert ansible_native_concat([-1j]) == -1j
    assert ansible_native_concat(['1']) == '1'
    assert ansible_native_concat(['1.0']) == '1.0'

# Generated at 2022-06-23 13:17:53.060321
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat(['42']) == '42'
    assert ansible_native_concat(['42 ']) == '42 '
    assert ansible_native_concat(['42']) == '42'
    assert ansible_native_concat(['42']) == '42'
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat(['4', '2']) == '42'
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat(['1', 2]) == '12'
    assert ansible_native_concat(['None']) == 'None'

# Generated at 2022-06-23 13:18:01.318622
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    for test, result in [
        (([],), None),
        (('a',), 'a'),
        ((None,), None),
        ((2,), 2),
        (('a', 'b'), 'ab'),
        ((2, 3), '23'),
        (('a', 2, 'b', 3), 'a2b3'),
        ((2, 'a', 3, 'b'), '2a3b'),
        (('', 2), u'2'),
        ((2, ''), u'2'),
        (('1', '2', '3', 4, 5), u'12345'),
    ]:
        assert ansible_native_concat(test) == result



# Generated at 2022-06-23 13:18:09.040417
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    result = ansible_native_concat([1, 2])
    assert result == '12'
    result = ansible_native_concat(['a', 1, 2])
    assert result == 'a12'
    result = ansible_native_concat(['a', 'b', 'c'])
    assert result == 'abc'
    result = ansible_native_concat(['a', 'b', 'c', 1, 2, 3])
    assert result == 'abc123'
    result = ansible_native_concat(['a', 'b', 'c', 1, 2, 3, [1, 2, 3], {'foo': 'bar'}])
    assert result == 'abc123[1, 2, 3][{\'foo\': \'bar\'}]'

# Generated at 2022-06-23 13:18:14.452562
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common.text.converters import to_bytes

    class FakeNode(object):
        def __init__(self, value):
            self.value = value

    assert ansible_native_concat([]) is None
    assert ansible_native_concat([FakeNode(1)]) == 1
    assert ansible_native_concat([FakeNode([1, 2, 3])]) == [1, 2, 3]
    assert ansible_native_concat([FakeNode({'a': 'b'})]) == {'a': 'b'}
    assert ansible_native_concat([FakeNode('1 2')]) == '1 2'

# Generated at 2022-06-23 13:18:25.097573
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([u'a']) == u'a'
    assert ansible_native_concat([u'a', u'b']) == u'ab'
    assert ansible_native_concat([u'string', 1]) == u'string1'
    assert ansible_native_concat(u'abc') == u'abc'
    assert isinstance(ansible_native_concat([u'string', 1]), str)
    assert ansible_native_concat([u"", u'a']) == u'a'
    assert ansible_native_concat([u"", u"b"]) == u"b"

# Generated at 2022-06-23 13:18:35.209671
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([42]) == 42
    assert isinstance(ansible_native_concat(["42"]), int)
    assert ansible_native_concat(["42", "53"]) == "4253"
    assert ansible_native_concat(["42", None, "53"]) == "42None53"
    assert container_to_text(ansible_native_concat(["42", None, "53"])) == "42None53"
    assert container_to_text(ansible_native_concat(["42", "53", None])) == "4253None"
    assert ansible_native_concat([None]) == None
    assert ansible_native_concat([False]) == False
    assert ansible_native_

# Generated at 2022-06-23 13:18:44.486785
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1, 2, 3]) == u'123'
    assert ansible_native_concat(['1', '2', '3']) == u'123'
    assert ansible_native_concat(['\t1', '2', 3]) == u'\t123'
    assert ansible_native_concat([dict(a=1, b=2)]) == {'a': 1, 'b': 2}
    assert ansible_native_concat([['1', 2]]) == ['1', 2]
    assert ansible_native_concat([dict(a=[1, 2])]) == {'a': [1, 2]}

# Generated at 2022-06-23 13:18:55.198262
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # value is int
    assert isinstance(ansible_native_concat([1]), int)

    # value is float
    assert isinstance(ansible_native_concat([1.0]), float)

    # value is str
    assert isinstance(ansible_native_concat(['1.0']), text_type)

    # value is bytes
    assert isinstance(ansible_native_concat([b'1.0']), bytes)

    # value is True
    assert isinstance(ansible_native_concat([True]), bool)

    # value is False
    assert isinstance(ansible_native_concat([False]), bool)

    # value is None
    assert ansible_native_concat([None]) is None

    # value is list

# Generated at 2022-06-23 13:19:02.661425
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import Environment
    env = Environment()
    env.undefined = StrictUndefined
    env.filters['ansible_native_concat'] = ansible_native_concat

    template = env.from_string("{{ [1, 2, 3] | ansible_native_concat }}")
    assert template.render() == "[1, 2, 3]"

    template = env.from_string("{{ 'foo' | ansible_native_concat }}")
    assert template.render() == "foo"

    template = env.from_string("{{ 'foo'|ansible_native_concat }}")
    assert template.render() == "foo"

    template = env.from_string("{{ 'foo' ~ 'bar' | ansible_native_concat }}")

# Generated at 2022-06-23 13:19:13.831413
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.utils.native_jinja import _make_filter


# Generated at 2022-06-23 13:19:21.741495
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['hello']) == 'hello'
    assert ansible_native_concat([NativeJinjaText('hello')]) == 'hello'
    assert ansible_native_concat([AnsibleVaultEncryptedUnicode('hello')]) == 'hello'

    assert ansible_native_concat(['hello', 'world']) == 'helloworld'
    assert ansible_native_concat(['hello', 'world', 'again']) == 'helloworldagain'
    assert ansible_native_concat([NativeJinjaText('hello'), NativeJinjaText('world')]) == 'helloworld'

# Generated at 2022-06-23 13:19:26.654839
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    l = [1, 2, 3]
    assert ansible_native_concat(l) == [1, 2, 3]

    l = [1, 2, 3, 4]
    assert ansible_native_concat(l) == [1, 2, 3, 4]

    l = ['1', '2', '3']
    assert ansible_native_concat(l) == [1, 2, 3]

    l = ['1', '2', '3', '4']
    assert ansible_native_concat(l) == '1234'

    l = [1, '2', '3']
    assert ansible_native_concat(l) == '123'

    l = [1, '2', '3', '4']
    assert ansible_native_concat(l) == '1234'

# Generated at 2022-06-23 13:19:37.379862
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # pylint: disable=import-error
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    def _assert_native_concat_result_is(nodes, wanted):
        """
        Helper function for unit test used to assert the returned value
        from function ansible_native_concat.
        """
        result = ansible_native_concat(nodes)
        if result != wanted:
            msg = 'ansible_native_concat(%s) returned %s, wanted %s' % (container_to_text(nodes, quote=True), container_to_text(result), container_to_text(wanted))
            assert False, msg

    # Test ansible_native_concat
    _assert_native_concat_result_is([], None)
   

# Generated at 2022-06-23 13:19:43.738380
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2.runtime import Undefined
    from ansible.module_utils.common.text.converters import native_to_text

    assert ansible_native_concat([Undefined(name='n1'), Undefined(name='n2')]) == Undefined(name='n1 n2')
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat([1, 2]) == 3
    assert ansible_native_concat([1, Undefined(name='n1')]) == Undefined(name='1 n1')
    assert ansible_native_concat([1, native_to_text('2')]) == 12
    assert ansible_native_concat([1, '2']) == 12

# Generated at 2022-06-23 13:19:54.071132
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    conf_text = r"""# comment
    # I'm indented
    foo: bar  # another comment
    foo2: bar2 # escaping is not allowed

    bar: baz #

    # nested comments
    # not supported
    foo3: bar3 # nested comments # not supported
    # not supported as well #
    """

    conf = ansible_native_concat(NativeJinjaText(conf_text))
    assert isinstance(conf, text_type)
    assert container_to_text(conf) == container_to_text(conf_text)
    assert ansible_native_concat(set(conf)) == frozenset(conf)

# Generated at 2022-06-23 13:20:02.988726
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2
    jinja_env = jinja2.Environment(undefined=jinja2.StrictUndefined)
    jinja_env.globals = {
        'ansible_native_concat': ansible_native_concat
    }

    template = '{{ ansible_native_concat([]) }}'
    assert jinja_env.from_string(template).render().strip() == 'None'

    template = '{{ ansible_native_concat(["foo"]) }}'
    assert jinja_env.from_string(template).render().strip() == 'foo'

    template = '{{ ansible_native_concat([1]) }}'
    assert jinja_env.from_string(template).render().strip() == '1'


# Generated at 2022-06-23 13:20:13.825732
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.jinja import native_concat

    def _test(nodes, expected):
        actual = ansible_native_concat(nodes)
        if to_text(actual) != to_text(expected):
            raise AssertionError("Expected:\n%s\n\nGot:\n%s" % (expected, actual))


# Generated at 2022-06-23 13:20:24.791074
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Test ansible_native_concat with string
    assert ansible_native_concat([NativeJinjaText("test string")]) == "test string"

    # Test ansible_native_concat with a number
    assert ansible_native_concat([NativeJinjaText(123)]) == 123

    # Test ansible_native_concat with a boolean
    assert ansible_native_concat([NativeJinjaText(False)]) == False

    # Test ansible_native_concat with an integer in a string
    assert ansible_native_concat([NativeJinjaText("123")]) == 123

    # Test ansible_native_concat with a float in a string
    assert ansible_native_concat([NativeJinjaText("123.45")]) == 123.45

    # Test ansible_

# Generated at 2022-06-23 13:20:35.337237
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # TODO: is it better to merge this with ansible_native_concat or leave it as a separate function?
    def _concat(nodes):
        return ansible_native_concat(nodes)

    assert _concat([]).value == ''
    assert _concat(['']).value == ''
    assert _concat([None]).value == None
    assert _concat(['a']).value == 'a'

    assert _concat(['a', 'b']).value == 'ab'
    assert _concat([1, 'b']).value == '1b'
    assert _concat([1, 'b', True]).value == '1bTrue'
    assert _concat([1, 'b', None]).value == '1bNone'

# Generated at 2022-06-23 13:20:43.120259
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 'bar', 'baz']) == 'foobarbaz'

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, 2, 3]) == '123'

    assert ansible_native_concat([1, 2, 'foo']) == '12foo'
    assert ansible_native_concat(['foo', 2, 3]) == 'foo23'

    assert ansible_native_concat([True])

# Generated at 2022-06-23 13:20:54.032927
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([1, 2]) == 12
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat([1, 'b']) == '1b'
    assert ansible_native_concat([1, 'b', 2]) == '1b2'
    assert ansible_native_concat([1, [2], 3]) == '123'
    assert ansible_native_concat([[1], 'b', 2]) == '[1]b2'
    assert ansible_native_concat([[1], [2], 3])

# Generated at 2022-06-23 13:21:05.135158
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([u'a']) == u'a'
    assert ansible_native_concat([u'a', u'b']) == u'ab'
    assert ansible_native_concat([u'a', 2, u'b']) == u'a2b'
    assert ansible_native_concat([u'a', [2, 3], u'b']) == u'a[2, 3]b'
    assert ansible_native_concat([u'a', {1: 2}, u'b']) == u'a{1: 2}b'
    assert ansible_native_concat([u'a', [2, 3], u'b']) == u'a[2, 3]b'

# Generated at 2022-06-23 13:21:15.977428
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['1']) == '1'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat(['{"foo": "bar"}']) == {"foo": "bar"}
    assert ansible_native_concat(['[1, 2]']) == [1, 2]
    assert ansible_native_concat(['1', '2', '3']) == '123'
    assert ansible_native_concat(['1', 1, '2']) == '112'
    assert ansible_native_concat(['1', 2, '3'])

# Generated at 2022-06-23 13:21:27.430398
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    new = ansible_native_concat
    assert new([]) is None
    assert new([b'a']) == b'a'
    assert new([u'a']) == u'a'
    assert new([1]) == 1
    assert new([u'abc123']) == u'abc123'
    assert new([u'abc123', u'def']) == u'abc123def'
    assert new([u'123', u'456']) == 789
    assert new(u'123' for _ in range(100)) == u'123' * 100
    assert new(u'123' for _ in range(100)) == 123 * 100
    assert new(u'0b1' for _ in range(100)) == u'0b10b10b10b10b10b10b10b1'
    assert new

# Generated at 2022-06-23 13:21:37.293076
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert container_to_text(ansible_native_concat([1])) == u'1'
    assert container_to_text(ansible_native_concat([1, 2, 3])) == u'1 2 3'
    assert container_to_text(ansible_native_concat([1.5])) == u'1.5'
    assert container_to_text(ansible_native_concat([1, 2.5, 3])) == u'1 2.5 3'
    assert container_to_text(ansible_native_concat([-1])) == u'-1'
    assert container_to_text(ansible_native_concat([1, -2, 3])) == u'1 -2 3'
    assert container_to_text(ansible_native_concat(["1"]))

# Generated at 2022-06-23 13:21:46.423577
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # ast.literal_eval will only evaluate a string if it can be expanded
    # further. Example: '"a"' -> 'a'
    # This breaks the way Ansible handles parameters (which are all strings)
    # and type conversion in Jinja.
    # So we make sure that if literal_eval would expand the string, we don't.
    assert ansible_native_concat(['"a"']) == '"a"'
    assert ansible_native_concat(['{{ "a" }}']) == '{{ "a" }}'
    assert ansible_native_concat(['{{ "a" | b }}']) == '{{ "a" | b }}'
    assert ansible_native_concat(['{{ "a" | b }}', '"c"']) == '{{ "a" | b }}c'

# Generated at 2022-06-23 13:21:49.620365
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([True, '''\

foo
bar

''', False]) == '''\

foo
bar

'''



# Generated at 2022-06-23 13:21:59.594044
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert isinstance(ansible_native_concat(['hello']), text_type)
    assert ansible_native_concat(['hello']) == 'hello'
    assert isinstance(ansible_native_concat([u'hello']), text_type)
    assert ansible_native_concat([u'hello']) == 'hello'
    assert isinstance(ansible_native_concat(['hello', 'world']), text_type)
    assert ansible_native_concat(['hello', 'world']) == 'helloworld'
    assert isinstance(ansible_native_concat([u'hello', u'world']), text_type)
    assert ansible_native_concat([u'hello', u'world']) == 'helloworld'

# Generated at 2022-06-23 13:22:10.857554
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 3]) == 'foo3'
    assert ansible_native_concat([True, False]) == True
    assert ansible_native_concat([None, True]) == None
    assert ansible_native_concat(['[1, 2, 3]']) == [1, 2, 3]
    assert ansible_native_concat(['{1: 2, 3: 4}']) == {1: 2, 3: 4}
    assert ansible_native_concat(['foo', True, '[1]']) == 'footrue[1]'


# Generated at 2022-06-23 13:22:15.752451
# Unit test for function ansible_native_concat

# Generated at 2022-06-23 13:22:24.583614
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # pylint: disable=import-error
    from ansible.errors import AnsibleFilterError
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.native_jinja import NativeJinjaText

    # test empty input
    assert ansible_native_concat([]) is None

    # test single node
    assert ansible_native_concat([47]) == 47
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat([0.00001]) == 0.00001
    assert ansible_native_con

# Generated at 2022-06-23 13:22:30.756808
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.plugins.filter.core import AnsibleFilters

    filter_loader = AnsibleFilters(
        extra_filter_plugin_dirs=[]
    )
    ansible_concat = filter_loader.filters().get('ansible_concat', None)

    assert ansible_concat is not None

    # Basic concatenation
    assert ansible_concat(['foo', 'bar', 'baz']) == 'foobarbaz'

    # Empty list
    assert ansible_concat([]) is None

    # Single item
    assert ansible_concat(['foo']) == 'foo'

    # Single empty string
    assert ansible_concat(['']) == ''

    # Single empty container
    assert ansible_concat([[]]) == ''

    # Nested empty containers