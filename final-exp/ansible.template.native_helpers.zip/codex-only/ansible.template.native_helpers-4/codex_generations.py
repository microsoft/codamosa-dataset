

# Generated at 2022-06-23 13:12:31.644131
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert(ansible_native_concat([1, '2', ' 3']) == '12 3')
    assert(ansible_native_concat(['1', 2]) == 12)
    assert(ansible_native_concat([' 1 ', 2]) == ' 1 2')
    assert(ansible_native_concat(['1 ', 2]) == '1 2')
    assert(ansible_native_concat(['1', 2, '3']) == '123')
    assert(ansible_native_concat([1, 2, 3]) == '123')
    assert(ansible_native_concat(['1', 2, '3', '4']) == '1234')
    assert(ansible_native_concat(['1', 2, '3', '4', 5]) == '12345')

# Generated at 2022-06-23 13:12:41.683979
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test concat of native types."""

    # Test with correct string literals
    assert ansible_native_concat([1, "one"]) == "1one"
    assert ansible_native_concat(["one", 1]) == "one1"
    assert ansible_native_concat(["one", "two"]) == "onetwo"
    assert ansible_native_concat(["one", "two", "three"]) == "onetwothree"

    # Test with strings which do not represent literal values
    # literal_eval must return the string, otherwise a different
    # exception would be raised.
    assert ansible_native_concat(["1", "one"]) == "1one"
    assert ansible_native_concat(["one", "1"]) == "one1"
    assert ansible_

# Generated at 2022-06-23 13:12:52.023411
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # pylint: disable=missing-docstring
    # pylint: disable=too-many-branches
    # pylint: disable=too-many-statements
    def assert_out(out, *nodes):
        assert out == ansible_native_concat(nodes)

    assert_out(None)
    assert_out(1, 1)
    assert_out(1, 1, 2)
    assert_out(1, 1, 3, 4)
    assert_out(1, 1, 3, 4, 5)
    assert_out([1, 2], [1, 2])
    assert_out([1, 2], [1], 2)
    assert_out([1, 2], [1], 2, 3)
    assert_out([1, 2], [1], 2, 3, 4)
   

# Generated at 2022-06-23 13:13:01.009436
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # This is a regression test for the function
    # ansible_native_concat defined above. The main purpose is to
    # verify that this function behaves the same as a similar function
    # implemented in pure jinja2.

    from jinja2.nativetypes import native_concat
    from jinja2.nodes import Const
    from ansible.module_utils.common.text.converters import to_bytes, to_unicode

    # Some examples of the expected behavior of the function

# Generated at 2022-06-23 13:13:09.827600
# Unit test for function ansible_native_concat

# Generated at 2022-06-23 13:13:20.371822
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = [3, 5, 8, 9]

    result = ansible_native_concat(nodes)
    assert result == 3
    assert isinstance(result, int)

    nodes = ["foo", "bar", "baz", "qux"]

    result = ansible_native_concat(nodes)
    assert result == "foobarbazqux"
    assert isinstance(result, text_type)

    nodes = ["'foo", "bar", "baz'", "qux"]
    result = ansible_native_concat(nodes)
    assert result == ("foobarbaz" "qux")
    assert isinstance(result, text_type)

    nodes = ["'foo", "bar", "baz'", "'qux'"]
    result = ansible_native_concat(nodes)

# Generated at 2022-06-23 13:13:29.571008
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class Test1:
        def __str__(self):
            return u"Hello"

    class Test2:
        def __str__(self):
            return u"World"

    native_concat = ansible_native_concat

    assert native_concat([u"Hello"]) == u"Hello"
    assert native_concat([Test1()]) == u"Hello"
    assert native_concat([u"Hello", u"World"]) == u"HelloWorld"
    assert native_concat([Test1(), Test2()]) == u"HelloWorld"
    assert native_concat([Test1(), u"World"]) == u"HelloWorld"
    assert native_concat([u"Hello", Test2()]) == u"HelloWorld"

# Generated at 2022-06-23 13:13:41.590748
# Unit test for function ansible_native_concat

# Generated at 2022-06-23 13:13:50.917796
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.six import PY3

    def _test_ansible_native_concat(text, expected):
        # Ensure that compiling a string doesn't change the expected value
        node = ast.parse(text, mode='eval')
        assert expected == ast.literal_eval(node)

        if isinstance(expected, text_type):
            expected = expected.encode('utf-8')

        compiled_node = ansible_native_concat([text])
        assert expected == compiled_node

        # We don't know how to compare compiled AST nodes on Python 2, so
        # just test that the expression can be compiled
        if PY3:
            compiled_node = ansible_native_concat([node])
            assert expected == compiled_node


# Generated at 2022-06-23 13:14:01.543371
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2
    env = jinja2.Environment(undefined=StrictUndefined)
    env.globals.update(ansible_native_concat=ansible_native_concat)
    env.globals.update(AnsibleUndefined=StrictUndefined)


# Generated at 2022-06-23 13:14:11.879992
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([True]) == True
    assert ansible_native_concat([False]) == False
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([1, 2]) == 12
    assert ansible_native_concat(['1', '2']) == 12
    assert ansible_native_concat(['True', 'False']) is True
    assert ansible_native_concat(['foo', 1]) == u'foo1'
    assert ansible_native_concat([1, 'foo']) == u'1foo'

# Generated at 2022-06-23 13:14:20.364616
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ['a', 'b'] == ansible_native_concat(['a', 'b'])
    assert 'ab' == ansible_native_concat(['a', 'b'], test_join=True)
    assert ['a', 'b', 'c'] == ansible_native_concat(['a', 'b', 'c'])

    assert ['a', 'b', 'c'] == ansible_native_concat(['a', ' ', 'b', ' ', 'c'])
    assert 'a b c' == ansible_native_concat(['a', ' ', 'b', ' ', 'c'], test_join=True)

# Generated at 2022-06-23 13:14:29.094849
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat(['1', '2', '3']) == 123
    assert ansible_native_concat(['1', 2, '3']) == '123'
    assert ansible_native_concat(['1', 2, 3]) == '123'
    assert ansible_native_concat(['1', '2', 3]) == '123'
    assert ansible_native_concat(['"foo"']) == '"foo"'
    assert ansible_native_concat(['"foo"', 'bar', 3]) == '"foo"bar3'
    assert ansible_native_concat

# Generated at 2022-06-23 13:14:38.311481
# Unit test for function ansible_native_concat

# Generated at 2022-06-23 13:14:47.422225
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat(['1']) == '1'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat([1, '2']) == '12'
    assert ansible_native_concat(['1', 2]) == '12'
    assert ansible_native_concat([1, b'2']) == '12'
    assert ansible_native

# Generated at 2022-06-23 13:14:56.011672
# Unit test for function ansible_native_concat

# Generated at 2022-06-23 13:15:03.673388
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == 12
    assert ansible_native_concat([1, 2, 3]) == 123

# Generated at 2022-06-23 13:15:07.772543
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    c = {'nodes': ['a', 'b', 'c']}
    assert ansible_native_concat(c['nodes']) == c['nodes']

    assert ansible_native_concat(['12345']) == 12345

# Generated at 2022-06-23 13:15:18.381885
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([NativeJinjaText(u'abc')]) == u'abc'
    assert ansible_native_concat([NativeJinjaText(u'abc'), NativeJinjaText(u'def')]) == u'abcdef'
    assert ansible_native_concat([NativeJinjaText(u'abc'), NativeJinjaText(u'def')]) != 'abcdef'
    assert isinstance(ansible_native_concat([NativeJinjaText(u'abc'), NativeJinjaText(u'def')]), text_type)

    assert ansible_native_concat([NativeJinjaText(u'abc'), NativeJinjaText(u'def')]) == u'abcdef'

# Generated at 2022-06-23 13:15:24.911789
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # https://github.com/ansible/ansible/issues/70831
    assert ansible_native_concat(["1", "2"]) == "12"

    assert ansible_native_concat([u"1", u"2"]) == "12"

    # https://github.com/ansible/ansible/issues/72274
    assert ansible_native_concat(["1", {"2": 3}]) == '1{2: 3}'

    # https://github.com/ansible/ansible/issues/57603
    assert ansible_native_concat(["1", 2]) == '12'

    # https://github.com/ansible/ansible/issues/72274

# Generated at 2022-06-23 13:15:34.100519
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    data = {'a': u'1'}
    assert ansible_native_concat([data['a'], 'b', 'c']) == u'1bc'
    assert ansible_native_concat([data['a'], 'b', 'c', data['a'], 'b']) == u'1bc1b'
    # unicode object
    data = {'a': u'\xc2\xae'}
    assert ansible_native_concat([data['a'], 'b', 'c']) == u'\xc2\xaebc'
    # bytes object
    data = {'a': b'\xc2\xae'}
    assert ansible_native_concat([data['a'], 'b', 'c']) == u'\xc2\xaebc'
    # int

# Generated at 2022-06-23 13:15:44.921680
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    with open(__file__, 'r') as f:
        source = f.read()
    source = source.split('\n')

    # Test a native Python value.
    assert ansible_native_concat(source) == source

    # Test a string.
    for i in range(1, len(source)):
        nodes = (line for line in source[0:i])
        assert ansible_native_concat(nodes) == ''.join(source[0:i])

    # Test a string that can be parsed.
    nodes = (line for line in source)
    assert ansible_native_concat(nodes) == source

    # Test a string with leading spaces/tabs.
    nodes = ('  asd' for line in source)

# Generated at 2022-06-23 13:15:47.404238
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['  foo\n', 'bar']) == '  foo\nbar'

# Generated at 2022-06-23 13:15:58.034886
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    literal_eval = ast.literal_eval


# Generated at 2022-06-23 13:16:08.335039
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.six.moves import builtins
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    assert ansible_native_concat(list(range(10))) == list(range(10))
    assert ansible_native_concat(range(10)) == list(range(10))
    assert ansible_native_concat([1, 2.0, None, True, False]) == [1, 2.0, None, True, False]
    assert ansible_native_concat([1, 2, 3, 4, 5]) == 15
    assert ansible_native_concat([1, 2.0, 3, 4.0, 5]) == 15.0
    assert ansible_native_concat(["1", "2", "3", "4"])

# Generated at 2022-06-23 13:16:17.657682
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from . import native_j2

    jenv = native_j2.get_jinja_env()

    # basic string concatenation
    assert jenv.from_string(
        "{{ 'foo' ~ 'bar' }}"
    ).render() == 'foobar'

    # literal concatenation
    assert jenv.from_string(
        "{{ ['1', '2', '3'] ~ ['4', '5', '6'] ~ ['7', '8', '9'] }}"
    ).render() == "['1', '2', '3', '4', '5', '6', '7', '8', '9']"


# Generated at 2022-06-23 13:16:26.139039
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Test with empty input
    assert ansible_native_concat([]) is None

    # Test unicode input
    assert ansible_native_concat([u'unicode']) == u'unicode'

    # Test bytes input
    assert ansible_native_concat([b'bytes']) == b'bytes'

    # Test integer input
    assert ansible_native_concat([1]) == 1

    # Test list input
    assert ansible_native_concat([[1]]) == [1]

    # Test dict input
    assert ansible_native_concat([{'foo': 'bar'}]) == {'foo': 'bar'}

    # Test AnsibleVaultEncryptedUnicode input

# Generated at 2022-06-23 13:16:37.069443
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat("foo") == "foo"
    assert ansible_native_concat("") == None
    assert ansible_native_concat("one", "two", "three") == "onetwothree"
    assert ansible_native_concat("1", "2") == 3
    assert ansible_native_concat("1") == 1
    assert ansible_native_concat("1", u",", "2") == "1,2"
    assert ansible_native_concat("foo", u",", "bar") == u'foo,bar'
    assert ansible_native_concat("{{ foo }}", u",", "bar") == u'{{ foo }},bar'
    assert ansible_native_concat("{{ foo }}") == u'{{ foo }}'
    assert ansible_native

# Generated at 2022-06-23 13:16:41.315412
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import Environment, DictLoader

    env = Environment(loader=DictLoader({'test.j2': '{% set a = [1, 2, 3] %}{{ a }}'}))
    template = env.get_template('test.j2')

    # The following output is the same in both Python 2 and Python 3
    assert template.render() == '[1, 2, 3]'

# Generated at 2022-06-23 13:16:50.924479
# Unit test for function ansible_native_concat

# Generated at 2022-06-23 13:16:59.925994
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, '2']) == '12'
    assert ansible_native_concat([1, '2', 3]) == '123'
    assert ansible_native_concat(['1', '2', '3']) == '123'
    assert ansible_native_concat(['1', '2', 3]) == '123'
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat(['1', '2', '3', 2]) == '123'
    assert ansible_native_concat([1, 2, 3, 4]) == '1234'
    assert ansible_native_concat([1, 2, 3, 4])

# Generated at 2022-06-23 13:17:10.212576
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.collections import is_list, is_dict

    def assert_equal(expected, actual):
        assert expected == actual, "%s != %s" % (repr(expected), repr(actual))

    class DummyNode:
        def __init__(self, value):
            self.value = value

        def __str__(self):
            return str(self.value)

    assert_equal(1, ansible_native_concat([DummyNode(1)]))
    assert_equal(1, ansible_native_concat([DummyNode(1), DummyNode(2)]))
    assert_equal('1', ansible_native_concat([DummyNode('1'), DummyNode(2)]))

# Generated at 2022-06-23 13:17:19.396283
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_native
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    def _c(s):
        return to_native(container_to_text(s))

    # simple
    assert _c('1') == 1
    assert _c('-1') == -1
    assert _c('1.2') == 1.2
    assert _c('-1.2') == -1.2
    assert _c('1.2e1') == 1.2e1
    assert _c('1.2e+1') == 1.2e1
    assert _c('1.2e-1') == 1.2e-1
    assert _c('1.2E1') == 1.2e1


# Generated at 2022-06-23 13:17:29.397524
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test with empty list
    assert ansible_native_concat([]) is None

    # Short-circuit for non-string types
    assert ansible_native_concat([1]) is 1
    assert ansible_native_concat([1.1]) == 1.1
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([[]]) == []

    # Short-circuit for NativeJinjaText
    assert isinstance(ansible_native_concat([NativeJinjaText('test')]), NativeJinjaText)

    # Short-circuit for AnsibleVaultEncryptedUnicode
    assert ansible_native_concat([AnsibleVaultEncryptedUnicode('test')]) == 'test'

    # Concatenation of strings
    assert ansible

# Generated at 2022-06-23 13:17:36.935579
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test case 1: single integer item
    nodes = [1000]
    result = ansible_native_concat(nodes)
    assert result == 1000

    # Test case 2: single float item
    nodes = [1234.5678]
    result = ansible_native_concat(nodes)
    assert result == 1234.5678

    # Test case 3: single string item
    nodes = ['hello']
    result = ansible_native_concat(nodes)
    assert result == 'hello'

    # Test case 4: single dict item
    nodes = [{'hello': 'world'}]
    result = ansible_native_concat(nodes)
    assert result == {'hello': 'world'}

    # Test case 5: single dict item
    nodes = [{'hello': 'world'}]

# Generated at 2022-06-23 13:17:47.862629
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([True]) == True
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat([3.14]) == 3.14
    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat(['\x00\x00\x00\x00\x00\x00\x00\x00']) == '\x00\x00\x00\x00\x00\x00\x00\x00'
    assert ansible_native_concat([None, None, None]) is None


# Generated at 2022-06-23 13:17:59.296865
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.utils.vars import combine_vars

    def run_test_case(native_type, jinja, expected):
        assert expected == combine_vars(native_type, {})["__ansible_native_concat"](jinja)

    run_test_case(text_type, [], None)
    run_test_case(text_type, ["hello"], "hello")
    run_test_case(text_type, ["hello", " ", "world"], "hello world")
    run_test_case(text_type, ["hello", " ", "world!\n"], "hello world!\n")
    run_test_case(text_type, ["- 1\n", "- 2\n"], "[1, 2]")

# Generated at 2022-06-23 13:18:07.736131
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat([1, 2, 3, 4]) == 10
    assert ansible_native_concat([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == 55
    assert ansible_native_concat([1, 2, '3', '4']) == 10
    assert ansible_native_concat(['1', '2', 3, 4]) == 10
    assert ansible_native_concat(['1', 2, '3', 4]) == 10
    assert ansible_native_concat([1, '2', '3', 4]) == 10

# Generated at 2022-06-23 13:18:13.879320
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test undefined
    assert ansible_native_concat([StrictUndefined]) is None

    # Test single node
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['1']) == '1'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1.1]) == 1.1
    assert ansible_native_concat([{'a': 1}]) == {'a': 1}
    assert ansible_native_concat([[1]]) == [1]

# Generated at 2022-06-23 13:18:24.405393
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([True]) is True

    assert ansible_native_concat(["a"]) == "a"
    assert ansible_native_concat(["a", "b"]) == "ab"
    assert ansible_native_concat(["a", [], "b"]) == "ab"

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == "12"

    assert ansible_native_concat([1, "2"]) == "12"

    assert ansible_native_concat([True, False]) == "TrueFalse"
    assert ansible_native_concat([True, "False"]) == "TrueFalse"

    assert ansible_native_con

# Generated at 2022-06-23 13:18:34.772071
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    import types
    import ast

    from ansible.module_utils.common.collections import is_sequence

    def ansible_native_concat(nodes):
        head = list(islice(nodes, 2))

        if not head:
            return None

        if len(head) == 1:
            out = head[0]

            if isinstance(out, NativeJinjaText):
                return out

            # short-circuit literal_eval for anything other than strings
            if not isinstance(out, string_types):
                return out

        else:
            if isinstance(nodes, types.GeneratorType):
                nodes = chain(head, nodes)
            out = u''.join([str(v) for v in nodes])


# Generated at 2022-06-23 13:18:44.250032
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common import remove_values


# Generated at 2022-06-23 13:18:53.181281
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2
    template = jinja2.Template(u"{{ [foo] }}")
    env = jinja2.Environment(undefined=StrictUndefined)
    env.filters['concat'] = ansible_native_concat
    env.globals['foo'] = 42
    assert template.render(env) == u'42'
    env.globals['foo'] = [42]
    assert template.render(env) == u'[42]'


# Disable the evaluation of expressions for `assert` statements
# https://docs.python.org/3.8/library/assert.html#assert-statements

# Generated at 2022-06-23 13:19:03.711780
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    from ansible.template.safe_eval import ansible_native_concat

    base = [None, '', u'', 0, False, [], {}, {None}, {''}, {u''}, {'key': None}, {'key': ''}, {'key': u''}, {'key': 'value'}]
    tests = base + [test + (test,) for test in base] + list(zip(base, base))

    for test in tests:
        assert isinstance(ansible_native_concat(test), (text_type, bool, int))

    assert ansible_native_concat([u'key', u'value']) == u'keyvalue'
    assert ansible_native_concat([u'key', u'value']) == u'keyvalue'

# Generated at 2022-06-23 13:19:12.586420
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat([1, None, 3]) == '1None3'
    assert ansible_native_concat(['foo', None, 'bar']) == 'fooNonebar'
    assert ansible_native_concat([1, 'foo', None, 'bar', 3]) == '1foobar3'
    assert isinstance(ansible_native_concat([True]), bool)
    assert isinstance(ansible_native_concat(['True']), bool)
    assert isinstance(ansible_native_concat(['2']), int)

# Generated at 2022-06-23 13:19:20.586735
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class Node(object):
        def __init__(self, value):
            self.value = value

    nodes = [Node(value) for value in (1, 'two', [3], (4,), {5: 6}, '{7}')]
    assert ansible_native_concat(nodes) == [1, 'two', [3], (4,), {5: 6}, (7,)]

    nodes = [Node(value) for value in ('', 'two', '', [3], '', (4,), '', {5: 6}, '')]
    assert ansible_native_concat(nodes) == ['two', [3], (4,), {5: 6}]


# Generated at 2022-06-23 13:19:31.019087
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = ['test', '123', '', ' ', 'foo', 0, 'bar', '|', '', 'baz', ' ', '', 'xyz']

    expected_values = [u'test123', u'test123|', u'test123|baz', u'test123|baz xyz',
                       u'test123|bazxyz', u'test123| bazxyz', u'test123 | bazxyz',
                       u'test 123 | bazxyz', u'test 123 |bazxyz', u'test 123|bazxyz',
                       u'test 123| bazxyz']


# Generated at 2022-06-23 13:19:42.516335
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([['foo']]) == ['foo']
    assert ansible_native_concat([['foo', 'bar']]) == ['foo', 'bar']
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([12]) == 12
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([['foo'], ['bar']]) == 'foobar'

# Generated at 2022-06-23 13:19:54.264103
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([u'1', u'2', u'3']) == u'123'
    assert ansible_native_concat([u'1', 2, 3]) == u'123'
    assert ansible_native_concat(map(str, range(10))) == u'0123456789'
    assert ansible_native_concat(map(str, range(10))) == u'0123456789'

# Generated at 2022-06-23 13:20:02.912502
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(["abc", "def", "ghi"]) == "abcdefghi"
    assert ansible_native_concat(["abc", None, "ghi"]) == "abcghi"
    assert ansible_native_concat(["abc", 1.0, "ghi"]) == "abc1.0ghi"
    assert ansible_native_concat(["abc", 2, "ghi"]) == "abc2ghi"

    # This is a valid Python expression so it gets parsed
    assert ansible_native_concat(["abc", "2", "ghi"]) == "abc2ghi"
    assert ansible_native_concat(["abc", [1,2], "ghi"]) == "abc[1, 2]ghi"
    assert ansible_native

# Generated at 2022-06-23 13:20:13.826794
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert ansible_native_concat([]) is None
    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([u'a', u'b']) == u'ab'
    assert ansible_native_concat([u'a', u'b', u'c']) == u'abc'
    assert ansible_native_concat([u'a', u'b', 1]) == u'ab1'
    assert ansible_native_concat([1, u'a', u'b']) == u'1ab'
    assert ansible_native_concat([u'a', 1, u'b']) == u'a1b'

# Generated at 2022-06-23 13:20:24.790845
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import datetime
    from ansible.module_utils.six import PY3

    def _test(nodes, expected):
        out = ansible_native_concat(nodes)
        assert expected == out, 'Expected %s, got %s' % (expected, out)

    _test([], None)

    _test(['str'], 'str')
    _test(['str'], 'str')
    _test([42], 42)
    _test([u'\xff'], u'\xff')

    if not PY3:
        _test([u'\xff'], '\xff')
        _test(['\xe2\x98\x83'], '\xe2\x98\x83')

# Generated at 2022-06-23 13:20:35.338660
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import pytest

    def _repr_test(data):
        return (data, repr(data), container_to_text(data))

    def _test_cases(cases):
        for (i, case) in enumerate(cases):
            with pytest.raises(case[2], message='case %d: %s' % (i, case[2])):
                x = ansible_native_concat(case[0])
                assert ansible_native_concat(case[0]) == case[1]
                assert repr(ansible_native_concat(case[0])) == repr(case[1])

    # check that literal_eval is not used for non-string values

# Generated at 2022-06-23 13:20:43.087928
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([u'foo3', u'bar']) == u'foo3bar'
    assert ansible_native_concat([u'3', u'3']) == 6
    assert ansible_native_concat([u'3.14', u'3.14']) == 6.28
    assert ansible_native_concat([u'true', u'false']) == u'truefalse'
    assert ansible_native_concat([u'true', u'False']) == u'trueFalse'
    assert ansible_native_concat([u'False', u'true']) == u'Falsetrue'

# Generated at 2022-06-23 13:20:54.033032
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class TestObj:
        def __unicode__(self):
            return u'test'

        __str__ = __unicode__

    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == u'12'
    assert ansible_native_concat([1, 2, 3]) == u'123'
    assert ansible_native_concat([1, 2, 3, 4]) == u'1234'
    assert ansible_native_concat([1, 2, 3, 4, 5]) == u'12345'
    assert ansible_native_concat([1, 2, 3, 4, 5, 6]) == u'123456'

# Generated at 2022-06-23 13:21:05.092706
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    res = ansible_native_concat(["{% for a in b %}", "1", "{% endfor %}"])
    assert type(res) == text_type

    res = ansible_native_concat(["{% for a in b %}", "1", "{% endfor %}", "{% for a in b %}", "2", "{% endfor %}"])
    assert type(res) == text_type

    res = ansible_native_concat(["{% for a in b %}", "1", "{% endfor %}", "-", "{% for a in b %}", "2", "{% endfor %}"])
    assert type(res) == text_type


# Generated at 2022-06-23 13:21:15.975689
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u"foo", u"bar"]) == u'foobar'
    assert ansible_native_concat([u"1", u"2"]) == 3
    assert ansible_native_concat([u"bar", None, u"foo"]) == u'barfoobar'
    assert ansible_native_concat([u"{'a':'b'}", None, u"'c'"]) == {'a': 'b', 'c': None}
    assert ansible_native_concat([u"True", u"False"]) == u'TrueFalse'
    assert ansible_native_concat([1, 2, 3]) == 1
    assert ansible_native_concat([u"foo", 2, 3]) == u'foo'

# Generated at 2022-06-23 13:21:27.431065
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import Environment, DictLoader
    from jinja2 import nodes
    from jinja2.ext import Extension
    from jinja2.compiler import CodeGenerator

    class ConcatExtension(Extension):

        tags = set(['concat'])

        def parse(self, parser):
            lineno = next(parser.stream).lineno

            nodes_ = []
            while parser.stream.current.type != 'block_end':
                nodes_.append(parser.parse_expression())
            nodes_.append(nodes.Const(lineno=lineno, value=''))

            # This is where we'll concatenate the nodes ourselves
            concat_func = nodes.Name(lineno=lineno, name='ansible_native_concat', ctx='load')

# Generated at 2022-06-23 13:21:33.548514
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from jinja2 import DictLoader, Environment
    from jinja2.sandbox import SandboxedEnvironment


# Generated at 2022-06-23 13:21:44.863167
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None

    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo ']) == 'foo '
    assert ansible_native_concat([' foo']) == ' foo'
    assert ansible_native_concat([' foo ']) == ' foo '

    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo ', 'bar']) == 'foo bar'
    assert ansible_native_concat(['foo', ' bar']) == 'foo bar'
    assert ansible_native_concat(['foo ', ' bar ']) == 'foo  bar '


# Generated at 2022-06-23 13:21:56.474920
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import DictLoader, Environment

    data = dict(
        x="hello",
        y="world",
        z="ansible"
    )
    template = Environment(loader=DictLoader(data), autoescape=True).from_string(
        """
        {{ x }} {{ y }} {{ z }}
        {{ x | string }} {{ y | string }} {{ z | string }}
        {{ x + " " + y + " " + z }}
        {{ x + " " + y + " " + z | string }}
        """
    )
    out = template.render()

    assert isinstance(out, text_type)


# Generated at 2022-06-23 13:22:08.385246
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    parser = ast.parse('[1, 2, 3]')
    # Modify the original source to ensure the space is removed
    parser.body[0].value.elts.append(ast.Str(s=' '))
    assert ansible_native_concat(container_to_text([[1, 2, 3]])) == [1, 2, 3]
    assert ansible_native_concat(container_to_text(['1', 2, 3])) == '123'
    # The string ' ' is added to the list to ensure that the extra
    # spaces/tabs are removed when converting the list to the text string
    assert ansible_native_concat(container_to_text(['[1, 2, 3]', ' '])) == [1, 2, 3]

# Generated at 2022-06-23 13:22:20.330904
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    assert None == ansible_native_concat([])
    assert 'foo' == ansible_native_concat(['foo'])
    assert 'foobar' == ansible_native_concat(['foo', 'bar'])
    assert 'foo\nbar' == ansible_native_concat(['foo', '\n', 'bar'])
    assert 123 == ansible_native_concat([123])
    assert 123 == ansible_native_concat(['123'])
    assert 123.456 == ansible_native_concat(['123.456'])
    assert 123 == ansible_native_concat([' 123'])
    assert 123 == ansible_native_concat(['\t123'])
   

# Generated at 2022-06-23 13:22:32.761672
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['[1,2]']) == [1, 2]
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat(['[1,2', '3]']) == '[1,23]'
    assert ansible_native_concat(['"ab']) == '"ab'
    assert ansible_native_concat(['ab"']) == 'ab"'
    assert ansible_native_concat(['ab', '"cd', 'ef"'])