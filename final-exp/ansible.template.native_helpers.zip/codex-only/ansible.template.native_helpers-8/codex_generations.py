

# Generated at 2022-06-23 13:12:35.315268
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # str
    assert isinstance(ansible_native_concat("foo"), string_types)
    # bytes
    assert isinstance(ansible_native_concat(b"foo"), string_types)
    # int
    assert isinstance(ansible_native_concat(3), int)
    # float
    assert isinstance(ansible_native_concat(2.0), float)
    # dict
    assert isinstance(ansible_native_concat({2: 3}), dict)
    # list
    assert isinstance(ansible_native_concat([2]), list)
    # tuple
    assert isinstance(ansible_native_concat((2,)), tuple)
    # non-empty tuple
    assert isinstance(ansible_native_concat((1, 2)), tuple)
    # None

# Generated at 2022-06-23 13:12:44.445442
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat([True, False]) == 'TrueFalse'
    assert ansible_native_concat(['True', 'False']) == 'TrueFalse'
    assert ansible_native_concat(['123', '456']) == '123456'
    assert ansible_native_concat(['foo', 123]) == 'foo123'
   

# Generated at 2022-06-23 13:12:54.039936
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([u'a']) == u'a'
    assert ansible_native_concat([1, u'a']) == u'1a'
    assert ansible_native_concat([1, u'a']) == u'1a'
    assert ansible_native_concat([1, u'a', u'b']) == u'1ab'
    assert ansible_native_concat([1, u'a', u'b', u'c']) == u'1abc'
    assert ansible_native_concat([1, u'a', u'b', u'c', u'd']) == u'1abcd'

    assert ansible_native_concat([1, u'a', False]) == u

# Generated at 2022-06-23 13:13:05.177714
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleSequence
    assert ansible_native_concat((None, 'foo', 'bar', None)) == 'foobar'
    assert ansible_native_concat(('foo', None, None)) == 'foo'
    assert ansible_native_concat(('foo', '', '', 'bar')) == 'foobar'
    assert ansible_native_concat(('foo', '', '', 'bar', None)) == 'foobar'
    assert ansible_native_concat((3, None, 2, 1)) == '321'
    assert ansible_native_concat((1, '2', '3', 4, 5, 6)) == 123456
    assert isinstance(ansible_native_concat((1, 2, 3)), int)
    assert isinstance

# Generated at 2022-06-23 13:13:17.692285
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_native
    from jinja2.runtime import Undefined
    from jinja2.nodes import List, Node, Tuple, Const, Name, Dict, Context, Getattr, Subscript, Call

    class DummyNode(Node):
        def __init__(self, value):
            self.value = value

        def __iter__(self):
            yield self.value

        def __repr__(self):
            return 'DummyNode(%s)' % self.value

    def FakeStrictUndefined(value):
        return StrictUndefined(value)

    assert ansible_native_concat([]) is None

    assert ansible_native_concat([DummyNode(0)]) == 0
    # Ensure a list of nodes is converted to

# Generated at 2022-06-23 13:13:28.053979
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # TODO: add tests for dicts, dicts with dicts and list of dicts
    assert ansible_native_concat(['[1, "2"]']) == "[1, '2']"
    assert ansible_native_concat(['foo', '[1, "2"]']) == 'foo[1, \'2\']'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['1', '2']) == 3
    assert ansible_native_concat(['1.0', '2.0']) == 3.0
    assert ansible_native_concat(['1.0+1.0j', '2.0+2.0j']) == 3.0+3.0j
    assert ansible_native

# Generated at 2022-06-23 13:13:37.654175
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['Hello']) == 'Hello'
    assert ansible_native_concat(['Hello', ' ', 'World']) == 'Hello World'
    assert ansible_native_concat([False, ' ', True]) == 'False True'
    assert ansible_native_concat([1, ' ', 2]) == '1 2'
    assert ansible_native_concat(['1', ' ', '2']) == 3

    # None not rendered as an empty string
    assert ansible_native_concat(['1', ' ', None]) == '1 None'

    # dict not rendered as '{'
    assert ansible_native_concat(['1', ' ', {'foo': 'bar'}]) == '1 {foo: bar}'

    # list item not rendered as '['

# Generated at 2022-06-23 13:13:48.923579
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    assert ansible_native_concat([]) is None
    assert ansible_native_concat([False]) is False
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([1, 2]) == 3
    assert ansible_native_concat([[1, 2]]) == [1, 2]
    assert ansible_native_concat([[1], [2]]) == [1, 2]

# Generated at 2022-06-23 13:14:00.733494
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(['one']) == 'one'
    assert ansible_native_concat(['one', 'two']) == 'onetwo'
    assert ansible_native_concat(['one', '2']) == 'one2'
    assert ansible_native_concat(['1', 'two']) == '1two'
    assert ansible_native_concat(['1', '2']) == 3
    assert ansible_native_concat(['"one"', 'two']) == 'one two'
    assert ansible_native_concat(['"one', '"two']) == 'one two'
    assert ansible_native_concat(['"one" "two']) == 'one two'
    assert ans

# Generated at 2022-06-23 13:14:02.888417
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    val = ansible_native_concat([1, 2, 3])
    assert val == '123'

# Generated at 2022-06-23 13:14:13.128859
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(('x', 'y')) == u'xy'
    assert ansible_native_concat(('x', 'y', 'z')) == u'xyz'
    assert ansible_native_concat((u'x', u'y', 'z')) == u'xyz'
    assert ansible_native_concat((u'x', u'y', None)) == 'xyNone'
    assert ansible_native_concat((u'x', u'y', 1)) == 'xy1'
    assert ansible_native_concat((u'x', u'y', 1, 2)) == 'xy12'
    assert ansible_native_concat(([u'x', u'y'], 'z')) == 'xyz'

# Generated at 2022-06-23 13:14:20.977850
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Function ast.literal_eval is used by ansible_native_concat
    # and it's being asserted in a couple of places
    try:
        ast.literal_eval
    except AttributeError:
        # ast.literal_eval is not available in Python 2.6
        raise __main__.SkipTest("test_ansible_native_concat requires Python 2.7 or later")

    # This function tests the function ansible_native_concat in our jinja2 environment
    # with the concatenation operator.
    # ast.literal_eval is used by ansible_native_concat and its
    # being asserted in a couple of places

    # Create a list of test cases
    # Format of each test case:
    # [ ( variable1, variable2, ...), expected_result, description ]
    test_

# Generated at 2022-06-23 13:14:31.505755
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([u'', u'']) == u''
    assert ansible_native_concat([u'', u'a']) == u'a'
    assert ansible_native_concat([u'a', u'', u'b']) == u'ab'
    assert ansible_native_concat([u'a', u'b']) == u'ab'
    assert ansible_native_concat([u'a', u'b', u'{{c}}', u'd']) == u'ab{{c}}d'
    assert ansible_native_concat([u'a', u'b', u'{{c}}']) == u'ab{{c}}'
   

# Generated at 2022-06-23 13:14:40.512167
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test 1. string + string
    tokens = "abc"
    expected_result = "abc"
    result = ansible_native_concat(tokens)
    assert result == expected_result, "'%s' should be '%s'" % (result, expected_result)

    # Test 2. list + list
    tokens = "[1, 2]"
    expected_result = [1,2]
    result = ansible_native_concat(tokens)
    assert result == expected_result, "'%s' should be '%s'" % (result, expected_result)

    # Test 3. int + string
    tokens = 123
    expected_result = 123
    result = ansible_native_concat(tokens)

# Generated at 2022-06-23 13:14:48.648711
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_bytes

    import jinja2
    from jinja2.exceptions import UndefinedError
    from jinja2.nodes import Node

    # Patch environment filter out so we can test calling it
    # for any input variables. In a real environment this filter
    # is loaded from the ansible/plugins/filter/core directory.
    from ansible.plugins.filter.core import _getenv

    def getenv(*args, **kwargs):
        return _getenv(*args, **kwargs)


# Generated at 2022-06-23 13:14:59.307102
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', u'bar']) == 'foobar'
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([b'foo', 'bar']) == 'foobar'
    assert ansible_native_concat([b'foo', b'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 'bar', {'dict': 'blah'}]) == 'foobar{dict: blah}'
    assert ansible_native_concat(['foo', {'dict': 'blah'}]) == 'foo{dict: blah}'
    assert ansible_native_

# Generated at 2022-06-23 13:15:09.529708
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # type: () -> None
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, None]) == 1
    assert ansible_native_concat([1, 2, 3]) == 123

    text = u"abc"
    assert ansible_native_concat([text]) == text
    assert ansible_native_concat([text, u"def"]) == u"abcdef"
    assert ansible_native_concat([1, u"def"]) == u"1def"
    assert ansible_native_concat([1, u"def", None]) == u"1def"
    assert ansible_native_concat([None, u"def", 1]) == u"def1"
    assert ansible_

# Generated at 2022-06-23 13:15:19.833115
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(iter([])) is None
    assert ansible_native_concat(iter(['foo'])) == 'foo'
    assert ansible_native_concat(iter(['foo', 'bar'])) == 'foobar'

    native = NativeJinjaText('native')
    assert ansible_native_concat(iter([native])) == native
    assert ansible_native_concat(iter(['foo', native])) == native
    assert ansible_native_concat(iter(['foo', native, None])) is None
    assert ansible_native_concat(iter([native, 'bar', 'baz'])) == native

    assert ansible_native_concat(iter(['foo', 'bar'])) == 'foobar'

# Generated at 2022-06-23 13:15:25.794720
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    from jinja2.compiler import CodeGenerator
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils._text import to_bytes, to_native

    def _compile_expr(expr, line=0):
        return CodeGenerator(line).compile(expr).eval(environment=env)

    env = env_class()
    env.finalize = ansible_native_concat

    def _test(expr, expected, *args, **kwargs):
        compiled = _compile_expr(expr, *args, **kwargs)
        res = compiled()

        if isinstance(expected, Exception):
            assert isinstance(res, expected.__class__), \
                "Expected: %r, got: %r" % (expected, res)

# Generated at 2022-06-23 13:15:34.470796
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(["This", ' ', "is", ' ', "a", ' ', "test"]) == "This is a test"
    assert ansible_native_concat(["{{ foo }}", ' ', "{{ bar }}"]) == "{{ foo }} {{ bar }}"
    assert ansible_native_concat(["first {{ x + y }} second"]) == "first {{ x + y }} second"
    assert ansible_native_concat(["{{ x | y }}"]) == "{{ x | y }}"
    assert ansible_native_concat(["{{ 'a' | from_yaml }}"]) == "{{ 'a' | from_yaml }}"
    # should not work
    assert container_to_text(ansible_native_concat(["{{ true }}"])) == "{{ true }}"

# Generated at 2022-06-23 13:15:40.967789
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.loader import AnsibleLoader
    loader = AnsibleLoader(None, None, None, None)

    def _my_native_concat(nodes):
        return loader.construct_ansible_native_concat(nodes)


# Generated at 2022-06-23 13:15:49.581124
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', '1']) == 'a1'
    assert ansible_native_concat(['a', 1]) == 'a1'
    assert ansible_native_concat(['0', '1']) == 1
    assert ansible_native_concat(['0', 1]) == 0
    assert ansible_native_concat(['0', [1]]) == [0, 1]
    assert ansible_native_concat([0, '1']) == '01'
    assert ansible_native_concat([0, 1]) == 0
    assert ansible_native_concat(['0', [1], 2]) == [0, 1, 2]
    assert ansible_native

# Generated at 2022-06-23 13:15:58.627246
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test the function ansible_native_concat

    The function ansible_native_concat implements the concat function in
    jinja2 native types.
    """
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['a', 1]) == 'a1'
    assert ansible_native_concat([1, 'a']) == '1a'
    assert ansible_native_concat([1, 'a', 2]) == '1a2'
    assert ansible_native_concat([1, 2, 'a']) == '1a'
    assert ansible

# Generated at 2022-06-23 13:16:08.446372
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Tests accepting single literal
    assert ansible_native_concat(['test']) == 'test'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([True]) == True
    assert ansible_native_concat([None]) == None
    assert ansible_native_concat(['test']) == 'test'

    # Tests accepting lists
    assert ansible_native_concat([['test']]) == ['test']

    # Tests accepting lists of variable type
    assert ansible_native_concat([['test', 1, True]]) == ['test', 1, True]

    # Tests accepting lists of variable type with True/False

# Generated at 2022-06-23 13:16:17.398894
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == u'12'
    assert ansible_native_concat([1, 2, 3]) == u'123'
    assert ansible_native_concat([1, 2, 3, 4]) == u'1234'
    assert ansible_native_concat([1, 2, 3, 4, 5]) == u'12345'
    assert ansible_native_concat([1, u'2', 3, u'4', 5]) == u'12345'
    assert ansible_native_concat([1, u'2', 3, u'4', 5]) == u'12345'
    assert ansible_native_concat([]) is None



# Generated at 2022-06-23 13:16:26.016454
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    global _fail_on_undefined
    _fail_on_undefined = lambda x: x
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([[]]) == []
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == 12
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat([1, '2', u'3']) == 123
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat([u'a', u'b', u'c']) == u'abc'

# Generated at 2022-06-23 13:16:36.954656
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert 'str' == ansible_native_concat(['s', 'tr'])
    assert 'a, b' == ansible_native_concat(['a', ', ', 'b'])
    assert 'a, b' == ansible_native_concat(['a', '{{ ", " }}', 'b'])
    assert 'a, b' == ansible_native_concat(['a', '{{ ", " | safe }}', 'b'])
    assert 'a, b' == ansible_native_concat(['a', '"{{ ", " }}"', 'b'])
    assert 'a, b' == ansible_native_concat(['a', '"{{ ", " | safe }}"', 'b'])

# Generated at 2022-06-23 13:16:43.986776
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(["foo"]) == "foo"
    assert ansible_native_concat(["foo", "bar"]) == "foobar"
    assert ansible_native_concat(["foo", "bar", "baz"]) == "foobarbaz"
    assert ansible_native_concat(["foo ", "bar "]) == "foo bar "
    assert ansible_native_concat(["foo", 1, "bar"]) == "foo1bar"
    assert ansible_native_concat(["{}", 1]) == "1"
    assert ansible_native_concat(["[", 1, "]"]) == "[1]"

# Generated at 2022-06-23 13:16:52.626803
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils._text import to_bytes

    # this is needed for the ansible_native_concat function
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedObject
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Python 2 and 3 differently handle the value of unicode literals
    # e.g. the type of 'foo' is different in Py2 and Py3
    # this lambda function builds the expected literal on the fly
    if to_bytes('foo') == b'foo':
        unicode_literal = lambda x: x
    else:
        unicode_literal = lambda x: x + '\x00'

    # to avoid len() issues with Python 3
    len = lambda x: x.__len__()



# Generated at 2022-06-23 13:17:02.266859
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(iter([])) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == [1, 2]
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat(['a', 2, 'b']) == 'a2b'
    assert ansible_native_concat(['a', 2, 'b', 3]) == 'a2b3'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat([[], []]) == []
    assert ansible_native_concat(['a', []]) == 'a'
    assert ans

# Generated at 2022-06-23 13:17:12.027775
# Unit test for function ansible_native_concat

# Generated at 2022-06-23 13:17:20.149576
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat((1, 1)) == 11
    assert ansible_native_concat([1, 1, 1]) == 111
    assert ansible_native_concat([1, 1, 1, 1]) == 1111
    assert ansible_native_concat([1, 2, 3, 4]) == 1234
    assert ansible_native_concat([1, u'a', 2, u'b']) == u'1a2b'
    assert ansible_native_concat([u'abc', u'def']) == u'abcdef'
    assert ansible_native_concat([1, container_to_text({})]) == u'1{}'
    assert ansible_native_concat(('a', u'def'))

# Generated at 2022-06-23 13:17:29.701571
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test Function ansible_native_concat

    This is best illustrated with some examples, given the input
    a list of nodes, return a native Python value or AnsibleVaultEncryptedUnicode.
    """
    class TestVault(object):
        def __init__(self, value):
            self.data = value

    from ansible.module_utils.common.collections import is_sequence, Mapping

    tests = [
        ({'foo': 'bar', 'bar': 'baz'},
         {'foo': 'bar', 'bar': 'baz'}),
        ([1, 2, 3], [1, 2, 3]),
        ('foo', 'foo'),
        ('ansible_vault_foo', TestVault('ansible_vault_foo')),
    ]


# Generated at 2022-06-23 13:17:39.997409
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def assert_concat(nodes, expected):
        assert ansible_native_concat(nodes) == expected

    assert_concat([], None)
    assert_concat([None], None)
    assert_concat([5], 5)
    assert_concat([[5]], [5])
    assert_concat(['a', 'b', 'c'], 'abc')
    assert_concat(['abc'], 'abc')
    assert_concat(['abc '], 'abc ')
    assert_concat([7, 'abc'], '7abc')
    assert_concat(['abc', 5], 'abc5')
    assert_concat([None, 'abc', 5], 'abc5')
    assert_concat([None, 'abc', None, 5], 'abc5')
    assert_con

# Generated at 2022-06-23 13:17:49.548324
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_unicode

    # Define test inputs and expected outputs for ansible_native_concat
    # test inputs are tuples of the form (input_data, expected_output)

# Generated at 2022-06-23 13:17:58.315757
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import Environment
    from .unified_diff import unified_diff
    from .fixtures.native_concat import test_cases

    env = Environment(extensions=(), finalize=ansible_native_concat)
    for test_case in test_cases:
        tmpl = env.from_string(test_case.input)
        out = container_to_text(tmpl.render())
        if unified_diff(test_case.output, out, fromfile='expected', tofile='actual'):
            raise AssertionError('Rendered output does not match expected output')

# Generated at 2022-06-23 13:18:06.842258
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def _builtin_concat(nodes):
        out = u''.join([to_text(_fail_on_undefined(v)) for v in nodes])
        try:
            return ast.literal_eval(
                # In Python 3.10+ ast.literal_eval removes leading spaces/tabs
                # from the given string. For backwards compatibility we need to
                # parse the string ourselves without removing leading spaces/tabs.
                ast.parse(out, mode='eval')
            )
        except (ValueError, SyntaxError, MemoryError):
            return out

    # empty
    assert ansible_native_concat([]) == _builtin_concat([])

    # single string
    assert ansible_native_concat(["a"]) == _builtin_concat(["a"])

    # multiple strings
   

# Generated at 2022-06-23 13:18:15.246805
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def node(value):
        return types.SimpleNamespace(value=value)

    assert ansible_native_concat([]) is None
    assert ansible_native_concat([node(1)]) == 1
    assert ansible_native_concat([node('1')]) == 1
    assert ansible_native_concat([node('[1]')]) == [1]
    assert ansible_native_concat([node('"1"'), node('"2"'), node('"3"')]) == '123'
    assert ansible_native_concat([node('1'), node('2'), node('3')]) == '123'
    assert ansible_native_concat([node('1'), node('2'), node('"3"')]) == '123'

# Generated at 2022-06-23 13:18:25.461467
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def _to_native(obj):
        return ansible_native_concat([obj])

    assert _to_native(123) == 123
    assert _to_native(12.3) == 12.3
    assert _to_native(True) is True
    assert _to_native(None) is None
    assert _to_native('123') == 123
    assert _to_native('12.3') == 12.3
    assert _to_native('true') is True
    assert _to_native('false') is False
    assert _to_native('none') is None
    assert _to_native('some') == 'some'
    assert _to_native('some') == 'some'
    assert _to_native('some123') == 'some123'
    assert _to_native(u'some') == u'some'

# Generated at 2022-06-23 13:18:35.408688
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # check that the function works in jinja-native-mode with no evaluation
    # https://github.com/pallets/jinja/blob/master/src/jinja2/nativetypes.py
    from jinja2.nativetypes import _try_get_literal_eval, concat
    assert _try_get_literal_eval('foo') == 'foo'
    assert _try_get_literal_eval('foo.bar') == 'foo.bar'
    assert _try_get_literal_eval('[42, foo]') == [42, 'foo']
    assert _try_get_literal_eval('{bar: 42, foo: 23}') == \
        {'bar': 42, 'foo': 23}

# Generated at 2022-06-23 13:18:44.624290
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Unit test for function ansible_native_concat.
    Its important because the function is coming from upstream and
    we are responsible for it.
    """
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

    # jinja2.nativetypes.to_native is implemented as
    # lambda x: ansible_native_concat(x)
    to_native = ansible_native_concat

    def test(template, expected, **kwargs):
        from ansible.module_utils.common.text.converters import to_bytes
        from ansible.template import ansible_native_conv

        # This is equivalent to the to_native we are testing
        # in the module_utils.common.jin

# Generated at 2022-06-23 13:18:55.319541
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import yaml
    yaml.add_representer(
        lambda dumper, data: dumper.represent_str(data.value)
        if isinstance(data, NativeJinjaText)
        else dumper.represent_str(data),
        to_text,
        yaml.RoundTripRepresenter.add_representer(str),
    )

    class Context(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    def run(value, **context):
        if isinstance(value, string_types):
            value = yaml.safe_load(value)

        context = Context(**context)

        class Template(object):
            def __init__(self, name, body):
                self.name = name
                self.body = body

           

# Generated at 2022-06-23 13:19:04.968127
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_scalar_or_utf8_if_bytes


# Generated at 2022-06-23 13:19:14.881296
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # https://github.com/pallets/jinja/blob/master/tests/test_nativetypes.py
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat([u'42']) == 42
    assert ansible_native_concat([u'42.42']) == 42.42
    assert ansible_native_concat([u'"foo"']) == u'foo'
    assert ansible_native_concat([u"u'foo'"], _fail_on_undefined=bool) == u'foo'
    assert ansible_native_concat([u'[1, 2]']) == [1, 2]

# Generated at 2022-06-23 13:19:19.843359
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # test different kinds of values and combinations of values
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, 2, 3, 4]) == '1234'
    assert ansible_native_concat([1, '2']) == '12'
    assert ansible_native_concat([1, '2', 3, '4']) == '1234'
    assert ansible_native_concat([1, ['2', 3]]) == [1, ['2', 3]]
    assert ansible_native_concat([1, ['2', 3], '4']) == [1, ['2', 3], '4']

# Generated at 2022-06-23 13:19:30.673542
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.collections import recursive_diff

    def _test_correct_conversion(inp, out):
        actual = ansible_native_concat(inp)

        if isinstance(out, Mapping):
            # We cannot use assertEqual() here as dicts are not ordered by
            # default and Python 3.7+ dicts are guaranteed to be ordered while
            # the dicts in the test case might not be ordered.
            # See: https://docs.python.org/3/whatsnew/3.7.html#whatsnew37-pep-0540
            assert recursive_diff(actual, out) == []
        else:
            assert actual == out

    # Test basic concatenation.
    _test_correct_conversion(['foo', 'bar'], 'foobar')


# Generated at 2022-06-23 13:19:42.234328
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo ']) == 'foo '
    assert ansible_native_concat([' foo']) == ' foo'
    assert ansible_native_concat([' foo ']) == ' foo '
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo ', 'bar']) == 'foo bar'
    assert ansible_native_concat(['foo', ' bar']) == 'foo bar'

# Generated at 2022-06-23 13:19:53.826455
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str1 = NativeJinjaText('string1')
    str2 = NativeJinjaText('string2')
    str3 = NativeJinjaText('string3')
    list1 = [str1, str2]
    tuple1 = ('str1', str1)
    dict1 = {'str1': str1, 'str2': str2}
    undef = StrictUndefined()
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([str1]) == str1
    assert ansible_native_concat([dict1]) == container_to_text(dict1, expand_lists=True)
    assert ansible_native_concat([list1]) == container_to_text(list1, expand_lists=True)

# Generated at 2022-06-23 13:19:58.296839
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([2, 3]) == 5
    assert ansible_native_concat([{'foo': 'bar'}, {'baz': 5}]) == {'foo': 'bar', 'baz': 5}
    assert ansible_native_concat([2, 3, 5]) == '235'
    assert ansible_native_concat([2, 'foo', 5]) == '2foo5'
    assert ansible_native_concat([2, [3, 5]]) == '2[3, 5]'
    assert ansible_native_concat([2, None]) is None
    assert ansible_native_concat([2, '', 3]) == '23'
    assert ansible_native_concat([2, ' ', 3]) == '2 3'
    assert ansible_native_concat

# Generated at 2022-06-23 13:20:09.145025
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test ansible_native_concat function"""
    import functools

    def gen(values):
        for v in values:
            yield v

    def nodes(values):
        return gen(values)

    def nodes_lst(values):
        return list(values)

    def assert_nodes(values, expected):
        """Check that the result of `compiler.visit_Concat` equals `expected`
        for given nodes `values`.
        """
        for mode in ['gen', 'lst']:
            for nodes_func in [nodes, nodes_lst]:
                value = getattr(compiler, 'visit_Concat')(
                    nodes_func(values)
                )

# Generated at 2022-06-23 13:20:17.712650
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Unit test for function ansible_native_concat"""
    from jinja2.sandbox import SandboxedEnvironment
    env = SandboxedEnvironment()
    env.filters['ansible_native_concat'] = ansible_native_concat

    def _test(template):
        template = template.rstrip('\n')
        render = env.from_string(template).render
        try:
            result = render(a=None)
        except StrictUndefined:
            result = 'UNDEFINED'
        print('%s = %r' % (template, result))
        return result

    assert _test('''{% set result =
(s|ansible_native_concat) %}''') == 'UNDEFINED'


# Generated at 2022-06-23 13:20:29.991883
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # We don't actually use this function in any of the filters and extensions
    # so we need to test it here.
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, '2', 3.0]) == '123.0'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat(['1', 2]) == '12'
    assert ansible_native_concat(['1', 2.0]) == '12.0'
    assert ansible_native_concat(['1.0', 2.0]) == '1.02.0'
    assert ans

# Generated at 2022-06-23 13:20:38.053418
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import Environment
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedString


# Generated at 2022-06-23 13:20:50.534883
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    s = "a"
    t = u"a"
    assert ansible_native_concat([s]) == "a"
    assert ansible_native_concat([t]) == u"a"
    assert ansible_native_concat([s, t]) == "a"
    assert ansible_native_concat([t, s]) == u"a"
    assert ansible_native_concat([s, s]) == "a"
    assert ansible_native_concat([t, t]) == u"a"
    assert ansible_native_concat([t, t, s]) == u"a"
    assert ansible_native_concat([t, s, t]) == u"a"
    assert ansible_native_concat([s, t, s]) == "a"
    assert ansible_native

# Generated at 2022-06-23 13:20:57.271988
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.utils.display import Display
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    import sys
    import ast

    display = Display()
    if sys.version_info >= (3, 8):
        display.display('WARNING: The current version of Python may not be supported by native_concat.')
    display.display('WARNING: Text may not display correctly, because it uses the native concatenation.')

    display.display('Testing ansible_native_concat with strings only.')
    display.display('Expected result: string')
    data = 'string'
    result = ansible_native_concat(data)
    display.display('Result: %s' % container_to_text(result))
    assert isinstance(result, string_types)


# Generated at 2022-06-23 13:21:01.960230
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat(['one', 'two', 'three']) == u'onetwothree'
    assert ansible_native_concat(['True', 'False']) is True
    assert ansible_native_concat(['yes', 'no']) == u'yesno'
    assert ansible_native_concat([1, 'two', 3]) == u'123'
    assert ansible_native_concat([1, 3]) == 13
    assert ansible_native_concat([1]) == 1


# Generated at 2022-06-23 13:21:13.006143
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    node1 = NativeJinjaText(u"ansible")
    node2 = NativeJinjaText(u"2")
    node3 = NativeJinjaText(u"10")

    assert ansible_native_concat([]) == None
    assert ansible_native_concat([node1]) == node1
    assert ansible_native_concat([node1, node2]) == u'ansible2'
    assert ansible_native_concat([node1, node2, node3]) == u'ansible210'
    assert ansible_native_concat([]).strip() == u''
    assert ansible_native_concat([node1]).strip() == node1
    assert ansible_native_concat([node1, node2]).strip() == u'ansible2'
    assert ansible_native_con

# Generated at 2022-06-23 13:21:24.132190
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """
    Test test_ansible_native_concat function
    """
    import ansible.module_utils.common.text.converters as convert

    for arg in [
        'string',
        u'string',
        ['list'],
        [u'list'],
        {'a': 'dict'},
        {u'a': u'dict'},
        [1, 2, 3],
        [1.0, 2.0, 3.0],
        ['a', 1, 'b', 2, 'c', 3],
    ]:
        assert ansible_native_concat([arg]) == arg

    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'

# Generated at 2022-06-23 13:21:31.484288
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(["42"]) == 42
    assert ansible_native_concat(["42", "24"]) == "4224"
    assert ansible_native_concat(["42", " foo"]) == "42 foo"
    assert ansible_native_concat(["42", "24", " foo", "bar"]) == "4224 foo"
    assert ansible_native_concat([u"42", u"24", u" fo\u00d0", u"bar"]) == u"4224 fo\u00d0"



# Generated at 2022-06-23 13:21:41.136530
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    p = ansible_native_concat

    assert p([NativeJinjaText('foo')]) == 'foo'
    assert p([NativeJinjaText('foo'), 'bar']) == 'foobar'
    assert p(chain([NativeJinjaText('foo')], ['bar'])) == 'foobar'

    node = NativeJinjaText(None)
    assert p([node]) == node

    assert p([{'foo': 'bar'}]) == {'foo': 'bar'}
    assert p(['{"foo": "bar"}']) == {'foo': 'bar'}



# Generated at 2022-06-23 13:21:52.225092
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2, 3]) == u'123'
    assert ansible_native_concat([1, 2, 3, 4]) == u'1234'
    assert ansible_native_concat([1, '2', 3, '4']) == u'1234'
    assert ansible_native_concat(x for x in [1, 2, 3, 4]) == u'1234'
    assert ansible_native_concat([1, 2, 3, 4]).__class__ == text_type
    assert ansible_native_concat([1, '2', 3, None]) == u'12None3'

# Generated at 2022-06-23 13:22:01.906977
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    result = ansible_native_concat([1, 2, 3])
    assert result == 1

    result = ansible_native_concat([1, 2, 3, 4])
    assert result == "1234"

    # https://github.com/pallets/jinja/issues/1200
    result = ansible_native_concat([1, 2, NativeJinjaText("3")])
    assert result == "123"

    result = ansible_native_concat([NativeJinjaText("1"), 1])
    assert result == "11"

    result = ansible_native_concat([NativeJinjaText("1"), {'k': NativeJinjaText('v')}])
    assert result == "1{'k': 'v'}"


# Generated at 2022-06-23 13:22:12.904677
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'

    assert ansible_native_concat(['a', 2, 'c']) == 'a2c'
    assert ansible_native_concat(['a', '2', 'c']) == 'a2c'
    assert ansible_native_concat([1, 2, 'b', 'c']) == '12bc'
    assert ansible_native_concat([1, 2, 3, 4]) == 1234

    assert ansible_native_concat(['1', 2, '3', 4]) == 1
    assert ansible_native_concat(['1', '2', '3', 4]) == 1
    assert ansible_native

# Generated at 2022-06-23 13:22:23.477537
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # test string concatenation
    string = ansible_native_concat([u'foo', u'bar'])
    assert string == 'foobar'

    # test dict concatenation
    dict_str = ansible_native_concat([u'{', u"'foo': 1", u'}'])
    assert dict_str == '{foo: 1}'

    # test list concatenation
    list_str = ansible_native_concat([u'[', u'2', u']'])
    assert list_str == '[2]'

    # test tuple concatenation
    tuple_str = ansible_native_concat([u'(', u'3', u')'])
    assert tuple_str == '(3)'

    # test boolean concatenation

# Generated at 2022-06-23 13:22:35.955345
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat([42, 43]) == '4243'
    assert ansible_native_concat([42, 43, 44]) == '424343'
    assert ansible_native_concat(['42', '43', '44']) == '424343'
    assert ansible_native_concat(['4', '2', '4', '3', '4', '3']) == '424343'
    assert ansible_native_concat(['4', '2', '4', '3', '4']) == '42434'
    assert ansible_native_concat(['4', '2', '4', '3']) == '4243'
    assert ansible_native