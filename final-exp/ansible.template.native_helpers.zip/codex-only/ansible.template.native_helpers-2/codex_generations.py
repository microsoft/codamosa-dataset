

# Generated at 2022-06-23 13:12:31.174714
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'a', u'b', u'c']) == 'abc'
    assert ansible_native_concat([3, u'b', u'c']) == '3bc'
    assert ansible_native_concat([True, u'b', u'c']) == 'Truebc'
    assert ansible_native_concat([3, True, u'b', u'c']) == "[3, True, 'b', 'c']"
    assert ansible_native_concat([u'a', u'b', u'c']) == ['a', 'b', 'c']
    assert ansible_native_concat([u'a', u'b', u'c']) == [u'a', u'b', u'c']
    assert ansible_native_con

# Generated at 2022-06-23 13:12:39.997811
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # ValueError when trying to parse a non-native type
    assert (ansible_native_concat([AnsibleVaultEncryptedUnicode('test')]) ==
            AnsibleVaultEncryptedUnicode('test'))

    # single text node
    assert ansible_native_concat([NativeJinjaText('test')]) == 'test'

    # single non-text node
    assert ansible_native_concat([100]) == 100

    # concatenation of text nodes
    assert ansible_native_concat([NativeJinjaText('test'), NativeJinjaText('test')]) == 'testtest'

    # concatenation of non-text nodes

# Generated at 2022-06-23 13:12:50.658151
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class TestConcat:
        def __init__(self, name, value):
            self.name = name
            self.value = value

        def __str__(self):
            return self.value


# Generated at 2022-06-23 13:13:00.089980
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import unittest
    import sys
    import doctest
    from ansible.module_utils.common.collections import is_sequence

    def to_sequence(value):
        """
        Convert a value to a tuple.

        >>> to_sequence('foo')
        ('foo',)
        >>> to_sequence((1, 2))
        (1, 2)
        """
        if is_sequence(value):
            return tuple(value)
        return (value,)

    class TestNativeConcat(unittest.TestCase):
        def test_basic_concat(self):
            """
            Test basic string concatenation.
            """
            value = ansible_native_concat(['foo', 'bar', 'baz'])
            assert value == 'foobarbaz', repr(value)


# Generated at 2022-06-23 13:13:09.365014
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(["foo"]) == u"foo"
    assert ansible_native_concat(["foo", "bar"]) == u"foobar"
    assert ansible_native_concat(["100", " - ", "foo", " - ", "bar", "200"]) == u"100 - foo - bar200"
    assert ansible_native_concat(["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"]) == u"1234567890"

    # test of ast.literal_eval
    assert ansible_native_concat(["[1, 2, 3]"]) == [1, 2, 3]

# Generated at 2022-06-23 13:13:20.138721
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(["foo", "bar"]) == "foobar"
    assert ansible_native_concat(["foo", " ", "bar"]) == "foo bar"
    assert ansible_native_concat(["foo"]) == "foo"
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(["foo", " ", "bar", ".", "baz"]) == "foo bar.baz"
    assert ansible_native_concat(["foo", 1, "bar", 2, "baz"]) == "foo1bar2baz"
    assert ansible_native_concat(["foo", ["bar"]]) == "foo[\'bar\']"

# Generated at 2022-06-23 13:13:29.446374
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(iter([])) is None
    assert ansible_native_concat(iter([123])) == 123
    assert ansible_native_concat(iter(['123', 456])) == '123456'
    assert ansible_native_concat(iter(['123 456'])) == '123 456'
    assert ansible_native_concat(iter(['123', 456, 'abc'])) == '123456abc'
    assert ansible_native_concat(iter(['[1, 2]', '[+ 3]'])) == [1, 2, 3]
    assert ansible_native_concat(iter(['[1, 2', '+ 3]'])) == '[1, 2+ 3]'

# Generated at 2022-06-23 13:13:41.442375
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # pylint: disable=missing-docstring, line-too-long
    assert ansible_native_concat([]) == None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(["1"]) == "1"
    assert ansible_native_concat(["  1"]) == "  1"
    assert ansible_native_concat([1, 2, 3]) == u"123"
    assert ansible_native_concat(["1", "2", "3"]) == u"123"
    assert ansible_native_concat([1, "2", "3"]) == u"123"
    assert ansible_native_concat(iter([1, "2", "3"])) == u"123"

# Generated at 2022-06-23 13:13:50.357156
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # The most common use case: concat two strings
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'

    # Concat two strings and parse as int
    assert ansible_native_concat(['0', '12']) == 12

    # Use a generator expression
    gen = (n for n in [123, '456'])
    assert ansible_native_concat(gen) == '123456'

    # generate a dict
    dict_gen = ({n: n} for n in [123, '456'])
    assert ansible_native_concat(dict_gen) == {123: 123, '456': '456'}

    # generate a list
    list_gen = ([n] for n in [123, '456'])

# Generated at 2022-06-23 13:14:01.269111
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'

# Generated at 2022-06-23 13:14:11.779154
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # This is the real world use case for this function
    # https://github.com/ansible/ansible/issues/70831
    test = [
        'a',
        'b',
        1,
        '{{ c | string }}',
        ['d', 'e', '{{ f | string }}'],
    ]

    # We want to get back a list of the same length that we started with
    # This should be our reference truth
    truth = [
        'a',
        'b',
        1,
        u'{{ c | string }}',
        [u'd', u'e', u'{{ f | string }}'],
    ]

    assert ansible_native_concat([container_to_text(test)]) == container_to_text(truth)

    # This should pass because {{ c | string }} should not

# Generated at 2022-06-23 13:14:20.310422
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_node = lambda node: ('return', node)

    def assert_concat(expected, *nodes):
        assert ansible_native_concat(list(map(test_node, nodes))) == expected

    assert_concat(None)

    assert_concat(1, 1)
    assert_concat(1, 1, 2)
    assert_concat(False, False)
    assert_concat(False, False, True)
    assert_concat('a', 'a')
    assert_concat('ab', 'a', 'b')
    assert_concat(4.5, 4.5)
    assert_concat(4.5, 4.5, 3.5)

    # complex literal
    assert_concat((1,), '(', 1, ')')

    # literal with multiple items
   

# Generated at 2022-06-23 13:14:31.176454
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat([1, 'b']) == '1b'
    assert ansible_native_concat(['a', 1]) == 'a1'

    assert ansible_native_concat(['True'])
    assert ansible_native_concat(['False']) == False
    assert ansible_native_concat(['123']) == 123
    assert ansible_native_concat(['123.0']) == 123.0
    assert ansible_native_concat(["'abc'"]) == 'abc'
    assert ansible_native_concat(['[1, 2]']) == [1, 2]


# Generated at 2022-06-23 13:14:40.327860
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(["foo", "bar"]) == "foobar"
    assert ansible_native_concat([NativeJinjaText("foo"), "bar"]) == "foobar"
    assert ansible_native_concat([u"foo", u"bar"]) == u"foobar"
    assert ansible_native_concat(["foo", ["bar", ["baz"]]]) == "foobarbaz"
    assert ansible_native_concat(["foo", "bar", "baz"]) == "foobarbaz"
    assert ansible_native_concat(["foo", "bar", "1"]) == "foobar1"
    assert ansible_native_concat(["1", "2", "3"]) == "123"

# Generated at 2022-06-23 13:14:48.552496
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test cases for function ansible_native_concat"""
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['a', 1]) == 'a1'
    assert ansible_native_concat([1, 'a']) == '1a'
    assert ansible_native_concat(['a', 1, 'b', 2, 'c']) == 'a1b2c'

# Generated at 2022-06-23 13:14:57.206881
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2]) == [1, 2]
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['a']) == 'a'
    # 'a' is output as a literal string and not unicode, thus the 'u' prefix
    assert ansible_native_concat([u'a']) == u'a'
    assert ansible_native_concat([None, 2]) == [None, 2]
    assert is_sequence(ansible_native_concat([[1], [2]]))



# Generated at 2022-06-23 13:15:04.259765
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(iter([1])) == 1
    assert ansible_native_concat(iter([1, 2])) == '12'
    assert ansible_native_concat(iter(['1'])) == '1'
    assert ansible_native_concat(iter(['1', '2'])) == '12'
    assert ansible_native_concat(iter(['1', 2])) == '12'
    assert ansible_native_concat(iter([1.0])) == 1.0
    assert ansible_native_concat(iter([1.0, 2])) == '1.02'
    assert ansible_native_concat(iter([1.0, 2, '3'])) == '1.023'


# Generated at 2022-06-23 13:15:13.265914
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Unit test for ansible.module_utils.common.jinja_functions.ansible_native_concat."""
    import ansible_collections.ansible.community.tests.unit.compat.mock as mock

    # This function should return None if the list is empty
    empty = []
    assert ansible_native_concat(empty) is None

    # This function should be able to return the value if the list only has one value
    one_number = [1]
    assert ansible_native_concat(one_number) == 1

    one_string = ['two']
    assert ansible_native_concat(one_string) == 'two'

    one_list = [[1, 2]]
    assert ansible_native_concat(one_list) == [1, 2]

    # AnsibleVault

# Generated at 2022-06-23 13:15:24.070071
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, '2', 3, 4]) == '1234'
    assert ansible_native_concat(['1', 2, '3', '4']) == '1234'
    assert ansible_native_concat(['foo', str('bar')]) == 'foobar'
    assert ansible_native_concat([1, 2, 3, '4']) == 1034
    assert ansible_native_concat(['foo', 2, 3, '4']) == 'foo234'
    assert ansible_native_concat(('foo', 2, 3, '4')) == 'foo234'
    assert ansible_native_concat(range(5)) == '01234'
    assert ansible_native_concat([]) is None

# Generated at 2022-06-23 13:15:33.690776
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([1, 2, 3], [4, 5, 6]) == '123456'
    assert ansible_native_concat(['1', 2, 3]) == '123'
    assert ansible_native_concat([None]) == None
    assert ansible_native_concat(["None"]) == "None"
    assert ansible_native_concat(["[1]"]) == "[1]"

# Generated at 2022-06-23 13:15:44.811008
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # test ansible_native_concat() with multiple nodes
    assert ansible_native_concat(['foo', 'bar']) == u'foobar'
    assert ansible_native_concat(['foo', 13]) == u'foo13'
    assert ansible_native_concat([13, 'foo']) == u'13foo'
    assert ansible_native_concat([13, 13]) == 26
    assert ansible_native_concat([3, 4, 5]) == u'345'
    assert ansible_native_concat(["true", "false"]) == u'truefalse'
    assert ansible_native_concat(["true", "", "false"]) == u'truefalse'
    assert ansible_native_concat(["true", [1, 2, 3], "false"]) == u

# Generated at 2022-06-23 13:15:56.894022
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def s(x):
        return NativeJinjaText(x)
    def u(x):
        return AnsibleVaultEncryptedUnicode(x)

    assert ansible_native_concat([]) is None
    assert ansible_native_concat([s('a')]) == 'a'
    assert ansible_native_concat([s('a'), s('b')]) == 'ab'
    assert ansible_native_concat([s('a'), s('b'), s('c')]) == 'abc'

    assert ansible_native_concat([s('a'), s('b'), s('c'), u('xyz')]) == container_to_text([u('xyz'), s('abc')])


# Generated at 2022-06-23 13:16:07.678953
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([1, '2', '3']) == 123
    assert ansible_native_concat([['a', 'b'], ['c', 'd']]) == 'abcd'
    assert ansible_native_concat([[1, 2], [3, 4]]) == '1234'

# Generated at 2022-06-23 13:16:16.782463
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat(['2', '3']) == '23'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['a', 1, 'b', 2]) == 'a1b2'
    assert ansible_native_concat(['a', 1, 'b', 2]) == 'a1b2'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'

# Generated at 2022-06-23 13:16:25.693427
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2

    env = jinja2.Environment(autoescape=True)
    env.globals.update({
        'ansible_native_concat': ansible_native_concat,
    })

    def assert_equal(expression, expected, autoescape=True, data=None):
        if data is None:
            data = {}
        template = env.from_string(text_type(expression))
        result = template.render(data)

        assert expression == result and container_to_text(expected) == container_to_text(result), \
            'to_text(%s) failed.  Expected: %s. Got: %s' % (texture_to_text(expression),
                                                            container_to_text(expected),
                                                            container_to_text(result))

# Generated at 2022-06-23 13:16:36.651677
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert isinstance(ansible_native_concat([]), type(None))
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([True]) is True
    assert isinstance(ansible_native_concat([u"1"]), text_type)
    assert ansible_native_concat([u"1"]) == "1"
    assert ansible_native_concat([u"a"]) == u"a"
    assert ansible_native_concat([u"a", u"b"]) == u"ab"
    assert ansible_native_concat([u"a ", u"b"]) == u"a b"
    assert isinstance(ansible_native_concat([u"a ", u"b"]), text_type)
    assert ansible_native_

# Generated at 2022-06-23 13:16:43.479089
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Unit test for function ansible_native_concat"""

    text_type_data = text_type("some text")
    ansible_vault_encrypted_unicode_data = AnsibleVaultEncryptedUnicode("some vault text")
    native_jinja_text_data = NativeJinjaText("abc")

    unvaulted = ansible_native_concat([text_type_data])
    assert isinstance(unvaulted, text_type)
    assert unvaulted == text_type_data

    unvaulted = ansible_native_concat([ansible_vault_encrypted_unicode_data])
    assert isinstance(unvaulted, text_type)
    assert unvaulted == text_type("some vault text")

    unvaulted = ansible_native_concat

# Generated at 2022-06-23 13:16:52.645391
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2.runtime import Context, Environment

    from ansible.module_utils.common.text.converters import to_bytes

    ctx = Context.from_environment(Environment())

    for inp, out in [
        (None, None),
        ('abc', 'abc'),
        ('"abc"', 'abc'),
        ('"a" 1 2 3', 'a 123'),
        (['a', 'b', 2, {}], 'ab2{}'),
        (['a', 'b', 2, {'d': 3}, '"e"f'], 'ab2{d: 3}"e"f'),
    ]:
        if isinstance(inp, string_types):
            inp = ast.literal_eval(inp)
        out = ast.literal_eval(out)
        ctx._

# Generated at 2022-06-23 13:17:02.289152
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(('foo', 'bar')) == 'foobar'
    assert ansible_native_concat(iter(['foo', 'bar'])) == 'foobar'
    assert ansible_native_concat(['foo', 'bar', 'baz']) == 'foobarbaz'
    assert ansible_native_concat(('foo', 'bar', 'baz')) == 'foobarbaz'
    assert ansible_native_concat(iter(['foo', 'bar', 'baz'])) == 'foobarbaz'

    assert ansible_native_concat(['foo', 'bar', 123]) == 'foobar123'

# Generated at 2022-06-23 13:17:12.745589
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat(['a']) == u'a'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([1, '2', 3]) == '123'
    assert ansible_native_concat([1, [2, 3]]) == '[1, [2, 3]]'
    assert ansible_native_concat([1, {'a': 2}]) == '{1: {\'a\': 2}}'

# Generated at 2022-06-23 13:17:19.113102
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    data = ansible_native_concat(['a', 'b', 'c'])
    assert data == 'abc'  # string
    data = ansible_native_concat(['10', '20', '30'])
    assert data == 102030  # int
    data = ansible_native_concat(['0x10', '20', '30'])
    assert data == '0x102030'  # string
    data = ansible_native_concat(['0x10', '0x20', '0x30'])
    assert data == 0x102030  # int

# Generated at 2022-06-23 13:17:23.989515
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    u = u'\u00f1'
    assert isinstance(ansible_native_concat([container_to_text(u)]), text_type)
    assert isinstance(ansible_native_concat([container_to_text(u), container_to_text(u)]), text_type)

# Generated at 2022-06-23 13:17:34.766477
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader
    from ansible.template.template import AnsibleEnvironment

    loader = DataLoader()
    env = AnsibleEnvironment(loader=AnsibleLoader(loader))

    # single node
    code = '{{ [1, 2] }}'
    tmpl = env.from_string(code)
    assert(tmpl.render() == '[1, 2]')

    # multiple nodes
    code = '{{ [1, 2] ~ [3, 4] }}'
    tmpl = env.from_string(code)
    assert(tmpl.render() == '[1, 2, 3, 4]')

    # complex node
    code = '{{ {y: 1} }}'
    tm

# Generated at 2022-06-23 13:17:46.386588
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import pytest
    from ansible.module_utils.common.text.converters import to_bool

    assert ansible_native_concat([1, 2, u'3']) == 123
    assert ansible_native_concat([1, 2, u'3', u'4']) == u'1234'
    assert ansible_native_concat([1, 2, u'3', u'4', 5]) == u'12345'
    assert ansible_native_concat([]) == None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == 12
    assert ansible_native_concat([True, u' 3']) == u'True 3'

# Generated at 2022-06-23 13:17:53.968422
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # This test is intentionally not a unit test and depends on the native
    # type being properly set for the current Python version.
    from jinja2 import Environment, DictLoader
    from jinja2.nodes import Template
    from jinja2.runtime import Undefined

    env = Environment(loader=DictLoader({'test.j2': Template('{% set out = foo|map(attribute="bar") %}')}))
    env.globals['native_concat'] = ansible_native_concat
    env.globals['Undefined'] = Undefined
    env.globals['is_sequence'] = is_sequence
    env.globals['isinstance'] = isinstance
    env.globals['text_type'] = text_type
    env.globals['string_types'] = string_

# Generated at 2022-06-23 13:18:03.596754
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 'true']) == ['foo', True]
    assert ansible_native_concat(['10', '-', '20']) == '10-20'
    assert ansible_native_concat(['[1,2,3,4]']) == [1, 2, 3, 4]
    assert ansible_native_concat(['[1,2,3,4]', 'bar']) == '[1,2,3,4]bar'

# Generated at 2022-06-23 13:18:14.228237
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2, 3]) == 123

# Generated at 2022-06-23 13:18:24.884840
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat([None]) == None
    assert ansible_native_concat([False]) == False
    assert ansible_native_concat([True]) == True
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1.0]) == 1.0
    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat([u'foo', 'bar']) == u'foobar'
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat([1, u'foo']) == u'1foo'
    assert ansible_native_concat([1, 'foo', None])

# Generated at 2022-06-23 13:18:35.110075
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2

    from ansible.module_utils.common.text.converters import to_native

    env = jinja2.Environment(undefined=jinja2.StrictUndefined)
    env.globals['native_concat'] = ansible_native_concat

    def assert_concat(data, expected, msg=None):
        assert expected == to_native(env.from_string(
            '{{ "%s | native_concat" | format(%s) }}' % (data, data)
        ).render()), msg

    assert_concat('[]', [])
    assert_concat('{}', {})
    assert_concat('[1, 2, 3]', [1, 2, 3])

# Generated at 2022-06-23 13:18:41.515818
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    code = '"hello " + "world" + "!"'
    assert ansible_native_concat(code) == "hello world!"
    assert ansible_native_concat("'hello world'") == 'hello world'
    assert ansible_native_concat("'hello world' + '!'") == 'hello world!'
    assert ansible_native_concat("'hello world' + '!' + '!!!!!'") == 'hello world!!!!!!'



# Generated at 2022-06-23 13:18:52.895983
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Example usage of the concatenation in a Jinja2 template
    # See test/units/plugins/lookup/test_map.py for actual usage.
    from jinja2 import Environment

    jinja_env = Environment(
        keep_trailing_newline=True,
        finalize=ansible_native_concat,
    )
    jinja_env.filters['to_json'] = container_to_text
    jinja_env.filters['to_yaml'] = container_to_text
    jinja_env.filters['to_nice_json'] = container_to_text
    jinja_env.filters['to_nice_yaml'] = container_to_text
    jinja_env.filters['to_text'] = container_to_text
    jin

# Generated at 2022-06-23 13:19:03.677559
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_native, to_text
    from jinja2.nodes import Node

    class Literal(Node):
        def __init__(self, value):
            self.value = value

        def __repr__(self):
            return '<Literal {}>'.format(self.value)

    class Concat(Node):
        def __init__(self, nodes):
            self.nodes = nodes

        def __repr__(self):
            return '<Concat {}>'.format(self.nodes)

    class Add(Node):
        def __init__(self, nodes):
            self.nodes = nodes

        def __repr__(self):
            return '<Add {}>'.format(self.nodes)


# Generated at 2022-06-23 13:19:14.198041
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test various inputs
    assert ansible_native_concat([]) is None
    # single input
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(["hello"]) == "hello"
    # multiple inputs
    assert ansible_native_concat([1, 2]) == "12"
    assert ansible_native_concat(["hello", "world"]) == "helloworld"
    assert ansible_native_concat(["hello", " ", "world"]) == "hello world"
    assert ansible_native_concat([1, "hello", 2, "world", 3]) == "1hello2world3"
    # multiple inputs which can be parsed to native types
    assert ansible_native_concat(["1.5"]) == 1.5
    assert ans

# Generated at 2022-06-23 13:19:22.056479
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import container_from_text
    # TODO: add tests for StrictUndefined once we have something like
    # https://github.com/pallets/jinja/pull/1181

# Generated at 2022-06-23 13:19:31.811613
# Unit test for function ansible_native_concat

# Generated at 2022-06-23 13:19:43.105365
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test different types of input values
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([] + [1] + [2, 3] + []) == 123
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([b'\x80\x81\x82']) == b'\x80\x81\x82'
    assert ansible_native_concat([b'\x80\x81\x82']) != '\x80\x81\x82'
    assert ansible_native_concat(['\x80\x81\x82']) == '\x80\x81\x82'

# Generated at 2022-06-23 13:19:55.126013
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # FIXME
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, 2, 3]) == '123'

    assert ansible_native_concat(iter([1])) == 1
    assert ansible_native_concat(iter([1, 2])) == '12'
    assert ansible_native_concat(iter([1, 2, 3])) == '123'

    assert ansible_native_concat([1, '2']) == '12'
    assert ansible_native_concat([1, '2', 3]) == '123'


# Generated at 2022-06-23 13:20:03.781124
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert(ansible_native_concat([]) == None)
    assert(ansible_native_concat(['foo']) == 'foo')
    assert(ansible_native_concat([u'foo']) == u'foo')
    assert(ansible_native_concat([0]) == 0)
    assert(ansible_native_concat([True]) == True)
    assert(ansible_native_concat([False]) == False)
    assert(ansible_native_concat([[1,2]]) == [1,2])
    assert(ansible_native_concat(['[1,2]']) == [1,2])
    assert(ansible_native_concat([{'foo': 'bar'}]) == {'foo': 'bar'})

# Generated at 2022-06-23 13:20:14.494833
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, 'str']) == '1str'
    assert ansible_native_concat([1, ['2']]) == [1, ['2']]
    assert ansible_native_concat(['{', '1', ':', '2', '}']) == {'1': '2'}
    assert ansible_native_concat([{'1': '2'}, {'3': '4'}]) == {'1': '2', '3': '4'}
    assert ansible_native_concat(['1', '2', '3', '4']) == [1, 2, 3, 4]
    assert ansible_native_concat([True, False]) == 'TrueFalse'


# Generated at 2022-06-23 13:20:26.472534
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class FakeUndefined(str):
        def __str__(self):
            raise StrictUndefined("")

    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(range(10)) == '0123456789'
    assert ansible_native_concat(map(str, range(10))) == '0123456789'

    with pytest.raises(StrictUndefined):
        ansible_native_concat([FakeUndefined('a')])

    assert ansible_native_concat([['a', 'b'], u'c']) == u'abc'

# Generated at 2022-06-23 13:20:36.390359
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    num = 5
    list1 = [1, 2, 3]
    str1 = 'abc'
    str3 = u'xyz'
    unicode1 = u'\u00b0c'
    false = False
    true = True
    none = None
    str2 = 'false'
    str4 = 'true'
    str5 = 'null'
    str6 = u'false'
    str7 = u'true'
    str8 = u'null'
    unicode2 = u'false'
    unicode3 = u'true'
    unicode4 = u'null'

    # #1: Single value, string, no conversion necessary
    result = ansible_native_concat([num])
    assert result == num
    result = ansible_native_concat([list1])

# Generated at 2022-06-23 13:20:43.814376
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.dataloader import DataLoader
    from ansible.template.safe_eval import ansible_native_concat
    from ansible.template import Template

    def from_yaml(d):
        return DataLoader().load(d, file_name='<template>', show_content=False)

    class Undefined(object):
        __slots__ = ('_msg',)

        def __init__(self, msg):
            self._msg = msg

        def __str__(self):
            return self._msg

    def test(template, vars, result):
        t = Template(template, loader=from_yaml('{}'), keep_trailing_newline=True)

# Generated at 2022-06-23 13:20:54.259395
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['1', '2']) == 3
    assert ansible_native_concat(['True', 'True']) == True
    assert ansible_native_concat(['[', '1', '2', ']']) == [1, 2]
    assert ansible_native_concat(['[', '1', '2', '3', ']']) == [1, 2, 3]
    assert ansible_native_concat(['["', '1', '2', '"]']) == '["1', '2"]'
    assert ansible_native_concat(['{"', '1', '2', '": true}']) == '{"1', '2": true}'
    assert ansible

# Generated at 2022-06-23 13:21:05.341986
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_bytes

    nodes = [
        to_bytes('foo'),
        to_bytes('bar'),
        to_bytes('baz'),
    ]

    result = ansible_native_concat(nodes)
    assert isinstance(result, string_types)
    assert result == 'foobarbaz'

    result = ansible_native_concat(iter(nodes))
    assert isinstance(result, string_types)
    assert result == 'foobarbaz'

    assert ansible_native_concat([]) is None
    assert ansible_native_concat(iter([])) is None

    result = ansible_native_concat([to_bytes('120')])
    assert isinstance(result, int)
    assert result == 120

   

# Generated at 2022-06-23 13:21:16.045494
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    '''
    Unit test for ``ansible_native_concat`` function.

    :param nodes: A list of compiled nodes.
    '''
    # Examples from: https://github.com/pallets/jinja/blob/master/src/jinja2/nativetypes.py

    # A single node evaluates to its value.
    assert ansible_native_concat([1]) == 1

    # Multiple nodes are concatenated as strings.
    assert isinstance(ansible_native_concat([1, 2]), text_type)
    assert ansible_native_concat([1, 2]) == '12'

    class Foo(object):
        def __init__(self, value):
            self.value = value

        def __str__(self):
            return str(self.value)

        __unicode__ = __str

# Generated at 2022-06-23 13:21:21.364300
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    import re

    def match_regex(str, regex):
        if re.match(regex, str):
            return True
        return False

    fn_concat = ansible_native_concat

    # No arguments

    result = fn_concat([])
    assert(result is None)

    # Single argument

    # string
    result = fn_concat(['hello'])
    assert(isinstance(result, text_type))
    assert(result == 'hello')

    result = fn_concat(['hello', ' '])
    assert(isinstance(result, text_type))
    assert(result == 'hello ')

    result = fn_concat(['hello', ' ', 'world'])
    assert(isinstance(result, text_type))
    assert(result == 'hello world')

    # list

# Generated at 2022-06-23 13:21:30.935731
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.template import Templar
    import ansible.parsing.yaml.objects

    s = u'[foo, bar]'
    e = [u'foo', u'bar']
    r = ansible_native_concat(Templar(None).template(s, convert_bare=True))
    assert r == e

    s = u'{foo: 1, bar: 2}'
    e = {u'foo': 1, u'bar': 2}
    r = ansible_native_concat(Templar(None).template(s, convert_bare=True))
    assert r == e

    s = u'foo'
    e = 'foo'
    r = ansible_native_concat(Templar(None).template(s, convert_bare=True))
    assert r == e

    s

# Generated at 2022-06-23 13:21:42.996926
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2.compiler import CodeGenerator
    from jinja2.nodes import ExprStmt
    from jinja2.runtime import Context, StrictUndefined
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    class DummyCodeGenerator(CodeGenerator):
        def __init__(self, nodes, environment):
            CodeGenerator.__init__(self, [ExprStmt(n) for n in nodes], environment)

    class DummyContext(Context):
        def __init__(self, environ):
            Context.__init__(self, environ)
            self._eval_ctx = {
                'ansible_native_concat': ansible_native_concat
            }


# Generated at 2022-06-23 13:21:54.992121
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    '''
    Test function ansible_native_concat
    '''
    # Test 1
    str_var = 'string'
    str_result = ansible_native_concat([str_var])
    assert type(str_result) is text_type
    assert isinstance(str_result, NativeJinjaText)
    assert str_result == str_var

    # Test 2
    bool_var = True
    bool_result = ansible_native_concat([bool_var])
    assert type(bool_result) is bool
    assert bool_result == bool_var

    # Test 3
    int_var = 5
    int_result = ansible_native_concat([int_var])
    assert type(int_result) is int
    assert int_result == int_var

    # Test 4
    list

# Generated at 2022-06-23 13:22:03.149409
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Boolean
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([False]) is False
    assert ansible_native_concat([True, False]) == u'TrueFalse'
    assert ansible_native_concat([False, True]) == u'FalseTrue'
    assert ansible_native_concat([True, False, True]) == u'TrueFalseTrue'
    assert ansible_native_concat([False, True, False]) == u'FalseTrueFalse'
    # TODO
    # assert ansible_native_concat([False, True, u'False']) == u'FalseTrueFalse'
    # assert ansible_native_concat([u'False', True, False]) == u'FalseTrueFalse'
    # assert ansible_native_concat([u'False',

# Generated at 2022-06-23 13:22:14.768876
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'hello', u'world']) == u'helloworld'
    assert ansible_native_concat([u'hello', u' ', u'world']) == u'hello world'
    assert ansible_native_concat([u'hello', [u' ', u'world']]) == u'hello [u\' \', u\'world\']'
    assert ansible_native_concat([u'hello', (u' ', u'world')]) == u'hello (u\' \', u\'world\')'
    assert ansible_native_concat([u'hello', [u' ', (u'world',)]]) == u'hello [u\' \', (u\'world\',)]'

# Generated at 2022-06-23 13:22:24.251319
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == 1
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(["a", "b", "c"]) == "abc"
    assert ansible_native_concat(["a"]) == "a"
    assert ansible_native_concat([1, 2, 3], [4, 5]) == "12345"
    assert ansible_native_concat([1], [4, 5]) == "145"
    assert ansible_native_concat([1, 2, 3], [4]) == "1234"
    assert ansible_native_concat(["a", "b", "c"], ["d", "e"]) == "abcde"

# Generated at 2022-06-23 13:22:36.553825
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test empty
    assert ansible_native_concat([]) is None

    # Test one element
    assert ansible_native_concat(['foo']) == 'foo'

    # Test multi-element
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 'bar', 'baz']) == 'foobarbaz'

    assert ansible_native_concat([1, 2]) == 1
    assert ansible_native_concat([1, 2, 3]) == '123'

    # Test numbers
    assert ansible_native_concat(['1', '2']) == 12
    assert ansible_native_concat(['1', '2', '3']) == '123'

    # Test floats
    assert ans