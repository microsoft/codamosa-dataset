

# Generated at 2022-06-23 13:12:35.258080
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.native_jinja import NativeJinjaText

    # case1: concat int and float
    node_list_1 = ['1', 1.0]
    assert ansible_native_concat(node_list_1) == '11.0'

    # case2: concat string and int
    node_list_2 = ['a string', 1]
    assert ansible_native_concat(node_list_2) == 'a string1'

    # case 3: concat NativeJinjaText and int
    node_list_3 = [NativeJinjaText('var'), 1]
    assert ansible_native_concat(node_list_3) == 'var1'

    # case4

# Generated at 2022-06-23 13:12:44.401788
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test string concatenation / literal_eval
    assert ansible_native_concat(['1', '2']) == 3
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['1', '2']) == 3
    assert ansible_native_concat(['foo', '2']) == 'foo2'
    assert ansible_native_concat(['1', 'bar']) == '1bar'
    assert ansible_native_concat(['{', '1']) == '{1'
    assert ansible_native_concat(['{', '1']) == '{1'

    # Test list concatenation

# Generated at 2022-06-23 13:12:52.495853
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.compat.tests.mock import patch

    with patch('ansible.parsing.yaml.objects.AnsibleBaseYAMLObject.__str__', new=lambda self: self.value):
        assert ansible_native_concat([1, 2, 3]) == 1
        assert ansible_native_concat([]) == None
        assert ansible_native_concat(None) == None
        assert isinstance(ansible_native_concat([AnsibleUnsafeText('foo\nbar')]), AnsibleUnsafeText)



# Generated at 2022-06-23 13:13:01.311877
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 'b']) == '1b'
    assert ansible_native_concat([1, 'b', 2]) == '1b2'
    assert ansible_native_concat([{}, 'b', 2]) == 'b2'
    assert ansible_native_concat([[], 'b', 2]) == 'b2'
    assert ansible_native_concat([(1, 2), 'b', 2]) == '(1, 2)b2'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat([1, '2']) == '12'


# Generated at 2022-06-23 13:13:09.981629
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Set up common test variables
    str1 = u'String1'
    str2 = u'String2'
    str3 = u'String3'
    strN = u'StringN'
    int1 = 123
    int2 = 234
    int3 = 345
    intN = 456
    list1 = [str1, int1]
    list2 = [str2, int2]
    list3 = [str3, int3]
    listN = [strN, intN]
    tuple1 = (str1, int1)
    tuple2 = (str2, int2)
    tuple3 = (str3, int3)
    tupleN = (strN, intN)
    dict1 = {str1: int1}
    dict2 = {str2: int2}

# Generated at 2022-06-23 13:13:20.428134
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # AnsibleVaultEncryptedUnicode (encryption text)
    assert ansible_native_concat(["$ANSIBLE_VAULT;1.1;AES256;foo\n", "bar"]) == AnsibleVaultEncryptedUnicode("$ANSIBLE_VAULT;1.1;AES256;foo\nbar")

    # AnsibleVaultEncryptedUnicode (decrypted text)
    assert ansible_native_concat(["$ANSIBLE_VAULT;1.1;AES256;foo\n", "bar", ",baz"]) == AnsibleVaultEncryptedUnicode("$ANSIBLE_VAULT;1.1;AES256;foo\nbar,baz")

    # AnsibleVaultEncryptedUnicode (encryption text)
    assert ansible_native_concat

# Generated at 2022-06-23 13:13:29.601768
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([text_type(1), text_type(2), text_type(3)]) == 123
    assert ansible_native_concat([text_type(1), text_type(2), text_type(3), text_type('x')]) == '123x'
    assert ansible_native_concat([text_type('foo')]) == 'foo'
    assert ansible_native_concat([text_type('foo'), text_type('bar')]) == 'foobar'
    assert ansible_native_concat([]) == ''
    assert ansible_native_concat([text_type('foo'), text_type(2)]) == 'foo2'
    assert ansible_native_concat([text_type(1), text_type('bar')]) == '1bar'
    assert ans

# Generated at 2022-06-23 13:13:41.628714
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(["FOO", "BAR"]) == "FOO"
    assert ansible_native_concat(["FOO", "BAR", "", "BAR"]) == "FOOBARBAR"
    assert ansible_native_concat(["FOO", 42, "BAR"]) == "FOO42BAR"
    assert ansible_native_concat(["FOO", 42, "BAR", []]) == "FOO42BAR[]"
    assert ansible_native_concat(["FOO", 42, "BAR", {}]) == "FOO42BAR{}"
    assert ansible_native_concat(["FOO", 42, "BAR", [1], True, None, False]) == "FOO42BAR[1]TrueNoneFalse"
   

# Generated at 2022-06-23 13:13:50.457898
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([[u'a', u'b', u'c'], [u'd', u'e', u'f'], [u'g']]) == u'abcdefg'
    assert ansible_native_concat([u'a', u'b', u'c']) == u'abc'
    assert ansible_native_concat([u'a']) == u'a'
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([u'', u'', u'']) == u''
    assert ansible_native_concat([u'1', u'2', u'3']) == 123
    assert ansible_native_concat([u'[1, 2, 3]']) == [1, 2, 3]
    assert ansible_

# Generated at 2022-06-23 13:14:01.297746
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    ansible_native_concat(['a', 'b'])
    ansible_native_concat(['a'])
    ansible_native_concat(['1', '2'])
    ansible_native_concat(['a', 1])
    ansible_native_concat(['a', 1, 'b', 2])
    ansible_native_concat([1, 2, 3])
    ansible_native_concat([1])
    ansible_native_concat([1, 2])
    ansible_native_concat([{}, {}, {}])
    ansible_native_concat([[], [], []])
    ansible_native_concat([{'a': 1}, {'b': 2}, {'c': 3}])

# Generated at 2022-06-23 13:14:11.812393
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(["foo", "bar"]) == u"foobar"
    assert ansible_native_concat(["foobar"]) == u"foobar"
    assert ansible_native_concat([1, "foo"]) == u"1foo"
    assert ansible_native_concat(["foo", 1]) == u"foo1"
    assert ansible_native_concat(["foo", True]) == u"fooTrue"
    assert ansible_native_concat([True, "foo"]) == u"Truefoo"
    assert ansible_native_concat([True, False]) == u"TrueFalse"

# Generated at 2022-06-23 13:14:17.449389
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test literal_eval conversion
    assert ansible_native_concat([10]) == 10
    assert ansible_native_concat([True]) is True

    # Test invalid literal_eval conversion
    assert ansible_native_concat(['10a']) == '10a'
    assert ansible_native_concat(['True']) == 'True'

    # Test string/representation conversion
    assert ansible_native_concat([10]) == 10
    assert ansible_native_concat([True]) is True

    # Test concatenation of results
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat([10, 20]) == 30
    assert ansible_native_concat([10, True]) == 11
    assert ansible_

# Generated at 2022-06-23 13:14:26.825821
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert 'foo' == ansible_native_concat([])
    assert 'foo' == ansible_native_concat(['foo'])
    assert 'foo' == ansible_native_concat(['f', 'oo'])
    assert 'foo' == ansible_native_concat(['fo', 'o'])
    assert 'foo' == ansible_native_concat(['foo'])
    assert 'foo bar baz' == ansible_native_concat(['foo ', 'bar ', 'baz'])
    assert 'foo bar baz' == ansible_native_concat(['foo ', 'bar ', 'baz'])

    assert 3 == ansible_native_concat(['1', '+', '2'])

# Generated at 2022-06-23 13:14:35.053489
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils import basic

    def check_func(nodes, expected):
        actual = ansible_native_concat(nodes)
        basic.fail_json_in_debug(actual=actual, expected=expected)
        assert actual == expected

    # non-string types
    check_func([1, 2], 3)
    check_func([1.5, 2.5], 4.0)
    check_func([True, False], 1)
    check_func(['1', 2], '12')
    check_func(['1.5', 2.5], '1.52.5')
    check_func(['True', False], 'TrueFalse')

    # sequence types
    check_func([['ab', 'cd'], 'ef'], 'abcdef')

# Generated at 2022-06-23 13:14:42.124593
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # literal_eval will not parse a string starting with a space
    assert ansible_native_concat([" "]) == " "
    assert ansible_native_concat([" ", ""]) == " "
    assert ansible_native_concat([" ", " "]) == "  "
    assert ansible_native_concat(["", " "]) == " "
    assert ansible_native_concat(["", "", " "]) == " "
    assert ansible_native_concat(["a", " ", "b"]) == "a b"
    assert ansible_native_concat(["a", "", "b"]) == "ab"
    assert ansible_native_concat(["", "b", "c", ""]) == "bc"

# Generated at 2022-06-23 13:14:49.051125
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import platform
    import math
    def test_data_generator():
        yield dict(
            expected_result="HelloWorld",
            result=ansible_native_concat(('Hello', 'World')),
            comment="Test concat of two strings",
        )
        yield dict(
            expected_result=5,
            result=ansible_native_concat((5,)),
            comment="Test concat of an integer",
        )
        yield dict(
            expected_result="5",
            result=ansible_native_concat((5,)) if platform.python_version_tuple() < ('3', '10', '0') else 5,
            comment="Test concat of an integer when literal_eval is used",
        )

# Generated at 2022-06-23 13:14:59.584497
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import container_to_text

    # Test for correct jinja env creation
    env = jinja2.Environment(trim_blocks=True, lstrip_blocks=True)
    env.filters['ansible_native_concat'] = ansible_native_concat

    # Test if concat takes care of undefined variables
    template = env.from_string('{{ "---" | ansible_native_concat }} {{ unknown_var }}')
    result = template.render()
    assert isinstance(result, string_types)
    assert result == u'--- UNDEFINED!'

    # Test if concat takes care of undefined variables in a list

# Generated at 2022-06-23 13:15:09.680180
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import pytest

    # Test method with ansible str types
    assert ansible_native_concat([u'abc']) == u'abc'
    assert ansible_native_concat([b'abc']) == b'abc'
    assert ansible_native_concat((b'abc', b'def')) == b'abcdef'

    # Test method with ansible text type
    assert ansible_native_concat([text_type('abc')]) == text_type('abc')

    # Test method with ansible sequence types
    assert ansible_native_concat([[u'abc']]) == [u'abc']
    assert ansible_native_concat([[u'abc', u'def']]) == [u'abc', u'def']

# Generated at 2022-06-23 13:15:19.833097
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([False]) is False
    assert ansible_native_concat([True, True]) == 'TrueTrue'
    assert ansible_native_concat(['a', True, 'b']) == 'aTrueb'
    assert ansible_native_concat([1, 'a', True, False, [2, 3], {'a': 'b'}]) == '[2, 3]'

# Generated at 2022-06-23 13:15:25.776964
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import Template

    test_template = Template(
        '{{ [1, 2, 3] + ["string", [4, 5, 6], "string"] + { a: 1, b: 2 } }}')

    def assert_concat_value(test_str, expected_value):
        """Container to text needs to be used to ensure that Python 3 syntax
        for dictionary constructors is used when necessary.
        """
        assert container_to_text(test_template.root_render_func(test_str)) == \
            container_to_text(expected_value)

    assert_concat_value({}, '1string[4, 5, 6]string[\'a\', \'b\']')

# Generated at 2022-06-23 13:15:34.470558
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class Test:
        def __repr__(self):
            return 'test'

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['1']) == '1'
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([Test(), Test(), Test()]) == 'testtesttest'
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([[]]) == []
    assert ansible_native_concat([[], []]) == []
    assert ansible_native_concat(['[', ']']) == '[]'
    assert ansible_native_concat(['{', '}']) == '{}'
    assert ansible_native

# Generated at 2022-06-23 13:15:44.989572
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def test_native_concat(input_list, expected):
        assert ansible_native_concat(input_list) == expected
    def test_native_concat_list(list_args, expected):
        test_native_concat([NativeJinjaText('[')] + list_args + [NativeJinjaText(']')], expected)

    # Concatenate two items
    test_native_concat([NativeJinjaText('foo'), NativeJinjaText('bar')], 'foobar')

    # Concatenate multiple items
    test_native_concat([NativeJinjaText('foo'), NativeJinjaText(u'bar'), NativeJinjaText(u'baz\u20ac')], u'foobarbaz\u20ac')

    # Concatenate to a list
   

# Generated at 2022-06-23 13:15:57.044880
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    for test in [
        # Ensure that when literal_eval does not raise an exception
        # the original value is returned.
        # https://github.com/pallets/jinja/issues/1217
        (False, 'False'),
        (True, 'True'),
        (None, 'None'),
    ]:
        assert test[0] == ansible_native_concat([test[1]])

    for test in [
        # literal_eval should not be called on non-strings
        # https://github.com/pallets/jinja/pull/1218
        (1, 1),
        (2.0, 2.0),
    ]:
        assert test[0] == ansible_native_concat([test[1]])


# Generated at 2022-06-23 13:16:07.769330
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = [1, 2, 3]
    assert ansible_native_concat(nodes) == to_text("1, 2, 3")

    nodes = [1, 2, 3, 4]
    nodes = islice(nodes, 2)
    assert ansible_native_concat(nodes) == 1

    nodes = [1, 2, 3, 4]
    nodes = islice(nodes, 1)
    assert ansible_native_concat(nodes) == 1

    nodes = ["1", "2", "3"]
    assert ansible_native_concat(nodes) == to_text("1, 2, 3")

    nodes = ["1", "2", "3", "4"]
    nodes = islice(nodes, 2)

# Generated at 2022-06-23 13:16:16.837036
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat(['a', 'b', 'c']) == u'abc'
    assert ansible_native_concat([None, 'b', 'c']) == None
    assert ansible_native_concat(['a', 'b', None]) == None
    assert ansible_native_concat(['a', [1, 2, 3], 'c']) == [1, 2, 3]
    assert ansible_native_concat(['a', [1, 2, 3], 'c']) == u'a[1, 2, 3]c'

# Generated at 2022-06-23 13:16:25.693691
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import Environment
    from ansible.module_utils.common.text.converters import to_native

    env = Environment()
    env.globals.update(
        native_concat=ansible_native_concat,
        to_native=to_native,
    )

    template = '{{ [1,2] + [3,4] }}'
    assert env.from_string(template).render() == '1 2 3 4'

    template = '{{ to_native([1, 2]) + [3, 4] }}'
    assert env.from_string(template).render() == '[1, 2]3 4'

    template = '{{ [1,2] + to_native([3,4]) }}'
    assert env.from_string(template).render() == '1 23 4'

   

# Generated at 2022-06-23 13:16:36.652660
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    '''test for function ansible_native_concat'''
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_unicode
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([2]) == 2
    assert ansible_native_concat([-2]) == -2
    assert ansible_native_concat([2.2]) == 2.2
    assert ansible_native_concat([-2.2]) == -2.2
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([False]) is False

# Generated at 2022-06-23 13:16:43.875189
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    assert ansible_native_concat(["1"]) == 1
    assert ansible_native_concat(["x"]) == "x"
    assert ansible_native_concat(["1", "2"]) == "12"
    assert ansible_native_concat(["1", "2", "3"]) == "123"
    assert ansible_native_concat(lazy_repeat(3, "x")) == "xxx"
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == "12"
    assert ansible_native_concat([1, "2"]) == "12"

# Generated at 2022-06-23 13:16:52.645180
# Unit test for function ansible_native_concat

# Generated at 2022-06-23 13:17:02.290796
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(["foo", "bar"]) == "foobar"
    assert ansible_native_concat([b"foo", b"bar"]) == "foobar"
    assert ansible_native_concat([u"foo", u"bar"]) == u"foobar"
    assert ansible_native_concat([u"foo", "bar"]) == u"foobar"
    assert ansible_native_concat([u"foo", "{'bar': 'baz'}"]) == u"foo{'bar': 'baz'}"

# Generated at 2022-06-23 13:17:12.746303
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # pylint: disable=too-many-branches, too-many-statements
    from ansible.template import Templar
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.vars.hostvars import HostVars
    import jinja2
    # Setup
    set_hostvars_ansible_vars = HostVars(dict(ansible_vars=dict()), 'localhost')
    set_hostvars_ansible_vars_var = HostVars(dict(ansible_vars=dict(var='var')), 'localhost')
    set_hostvars_simple_var = HostVars(dict(simple_var=dict()), 'localhost')

# Generated at 2022-06-23 13:17:20.739754
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat((1, 2, 3)) == 1
    assert ansible_native_concat(['foo', 'bar', 1, 2, 3]) == 'foobar123'
    assert ansible_native_concat(('foo', 'bar', 1, 2, 3)) == 'foobar123'
    assert ansible_native_concat([1, 'foo', 'bar', 2, 3]) == 1
    assert ansible_native_concat([1, 'foo', 2, 'bar', 3]) == 1
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'

# Generated at 2022-06-23 13:17:30.586692
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import collections
    import pytest

    # Generators and iterators
    assert ansible_native_concat(iter((1, 2, 3))) == u'123'
    assert ansible_native_concat(x for x in (1, 2, 3)) == u'123'
    assert ansible_native_concat((x for x in (1, 2, 3))) == u'123'

    # Strings and unicode strings
    assert ansible_native_concat([u"Hello ", "world", "!"]) == u'Hello world!'
    assert ansible_native_concat([u"Hello ", "world!", 42]) == u'Hello world!42'
    assert ansible_native_concat([u"Hello ", "world!", 42]) == u'Hello world!42'

    # Boolean
    assert ansible_native_con

# Generated at 2022-06-23 13:17:40.176907
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2

# Generated at 2022-06-23 13:17:45.432257
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    two = '2'
    three = '3'
    four = '4'
    five = '5'
    six = '6'

    # test for empty list
    assert ansible_native_concat([]) is None

    # test for single item list
    assert ansible_native_concat([two]) == 2

    # test for multi item list
    assert ansible_native_concat([two, three, four, five, six]) == '23456'

    # test for strings
    assert ansible_native_concat(['1', '2', '3']) == '123'

    # test for generator items
    assert ansible_native_concat(s for s in ('1', '2', '3')) == '123'

    # test for generator items with single item
    assert ansible_native_concat

# Generated at 2022-06-23 13:17:55.649857
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.six import PY2
    input = [u'a', u'b', u'c', u'd', u'e']
    expected = u'abcde'
    # TODO: Enable the tests
    #assert ansible_native_concat(input) == expected

    input = [u'a', [u'b', u'c'], u'd', u'e', [u'f', [u'g'], u'h']]
    expected = u'abcdefgh'
    # TODO: Enable the tests
    #assert ansible_native_concat(input) == expected

    input = u"a\nb"
    expected = u'a\nb'
    # TODO: Enable the tests
    #assert ansible_native_concat(input) == expected


# Generated at 2022-06-23 13:18:04.936994
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Literal Tests
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([2, 3]) == 5

    # String Tests
    assert isinstance(ansible_native_concat(['']), string_types)
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b', 1, '\u20ac']) == 'ab1€'

    # Mapping Tests
    assert ansible_native_concat([{'a': 1, 'b': 2}]) == {'a': 1, 'b': 2}

    # Sequence Tests
    assert ansible_native_concat([['a', 'b']]) == ['a', 'b']

    # None Tests
    assert ansible_native_con

# Generated at 2022-06-23 13:18:14.889052
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'

    assert ansible_native_concat([['a', 'b']]) == ['a', 'b']
    assert ansible_native_concat([['a', 'b'], ['c']]) == '[a, b]c'

    assert ansible_native_concat([['a'], 'b']) == 'ab'
    assert ansible_native_concat([['a', 'b'], 'c']) == '[a, b]c'


# Generated at 2022-06-23 13:18:25.221995
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Sourced from https://github.com/pallets/jinja/blob/master/tests/test_nativetypes.py
    val = [1, 2, 3]
    assert ansible_native_concat(val) == val

    val = "foo"
    assert ansible_native_concat(val) == val

    val = [True, False]
    assert ansible_native_concat(val) == val

    val = (True, False)
    assert ansible_native_concat(val) == val

    val = "foo"
    assert ansible_native_concat([val]) == val

    val = "{% set foo = 'foo' %}"
    assert ansible_native_concat([val]) == val

    val = "{{ x }}"
    assert ansible_native_concat([val])

# Generated at 2022-06-23 13:18:35.276435
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Start with some basic tests
    assert ansible_native_concat(["abc", "def"]) == "abcdef"

# Generated at 2022-06-23 13:18:44.515150
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def assert_eval(text, result):
        native_result = ansible_native_concat([NativeJinjaText(text)])
        assert native_result == result, 'Failed converting: %s' % text

    assert_eval('', '')
    assert_eval(' ', ' ')
    assert_eval('abc', 'abc')
    assert_eval(' ', ' ')
    assert_eval('\t', '\t')
    assert_eval('\t\t', '\t\t')
    assert_eval('\n', '\n')
    assert_eval('\n\n', '\n\n')
    assert_eval('{}', '{}')
    assert_eval('[]', '[]')
    assert_eval('[] \n', '[] \n')

# Generated at 2022-06-23 13:18:55.237853
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['1', '2']) == 12
    assert ansible_native_concat(['1', '2', '3']) == '123'
    assert ansible_native_concat([NativeJinjaText('1'), '2', '3']) == '123'
    assert ansible_native_concat(['1']) == '1'
    assert ansible_native_concat(['a' * 30000]) == 'a' * 30000

# Generated at 2022-06-23 13:19:04.912527
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat([u'']) == u''
    assert ansible_native_concat([u'42']) == 42
    assert ansible_native_concat(iter([u'4', u'2'])) == 42
    assert ansible_native_concat(iter([u'42'])) == 42
    assert ansible_native_concat([u'True']) is True
    assert ansible_native_concat([u'False']) is False

    assert ansible_native_concat([u'42', u'43']) == u'4243'
    assert ansible_native_concat(iter([u'4', u'2', u'4', u'3']))

# Generated at 2022-06-23 13:19:14.845035
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    sequence = 'hello'

    element = container_to_text(None, 'hi')
    num = container_to_text(None, 3)
    str_num = container_to_text(None, '3')
    num_str = container_to_text(None, '3d')
    str_num_str = container_to_text(None, '3d1')
    list_num = container_to_text(None, [2])
    list_str = container_to_text(None, ['2'])
    list_sequence = container_to_text(None, ['2', '3'])
    dict_num = container_to_text(None, {'a': 2})
    dict_str = container_to_text(None, {'a': '2'})
    dict_sequence = container_to_

# Generated at 2022-06-23 13:19:19.845089
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(["a", "b", "c"]) == "abc"
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat([1.1, 2, 3]) == 1.1
    assert ansible_native_concat(["1.1", 2, 3]) == "1.1"
    assert ansible_native_concat(["[1, 2]", 2, 3]) == "[1, 2]"
    assert ansible_native_concat(["1+2", 2, 3]) == "1+2"
    assert ansible_native_concat(["1.1", "[1, 2]", "3"]) == "1.1[1, 2]3"
    assert ansible_native_concat([True, False])

# Generated at 2022-06-23 13:19:30.673096
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat((1, 2)) == '12'

    assert ansible_native_concat([1, '2']) == [1, '2']

    assert ansible_native_concat([1, 2]) == [1, 2]

    assert ansible_native_concat([True, False]) == 'TrueFalse'

    assert ansible_native_concat([(1, '2')]) == '(1, \'2\')'

    assert ansible_native_concat([[1, 2]]) == '[1, 2]'

    assert ansible_native_concat([{'1': 2}]) == "{'1': 2}"

    assert ansible_native_concat([1, '2']) == [1, '2']


# Generated at 2022-06-23 13:19:42.235826
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert ansible_native_concat(['1', 3]) == '13'
    assert ansible_native_concat([1, '3']) == ['1', '3']
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['&']) == '&'
    assert ansible_native_concat([' " ', " ' "]) == ' " \' '
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat(['None']) == 'None'

# Generated at 2022-06-23 13:19:53.826269
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.native_jinja import NativeJinjaText

    assert ansible_native_concat((1,)) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat((2, 3)) == '23'
    assert ansible_native_concat((1, 2, 3)) == '123'
    assert ansible_native_concat((1, 2, 3, 4)) == '1234'
    assert ansible_native_concat((1, 2, 3, 4, 5)) == '12345'
    assert ansible_native_concat((1, 2, 3, 4, 5, 6)) == '123456'
    assert ansible_

# Generated at 2022-06-23 13:20:02.795299
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat([123]) == 123
    assert ansible_native_concat([u'abc']) == u'abc'
    assert ansible_native_concat([u'abc', u'def']) == u'abcdef'
    assert ansible_native_concat([u'abc', AnsibleVaultEncryptedUnicode(u'def')]) == u'abcdef'
    assert ansible_native_concat([u'abc', 123]) == u'abc123'
    assert ansible_native_concat([123, u'abc']) == u'123abc'
    assert ansible_native_concat([123, u'abc', 456]) == u'123abc456'

# Generated at 2022-06-23 13:20:13.727163
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Test strings
    assert ansible_native_concat(['foo', 'bar', 'quux']) == 'foobarquux'
    assert ansible_native_concat(['foo', u'bar', u'quux']) == 'foobarquux'
    assert ansible_native_concat([u'foo', u'bar', u'quux']) == 'foobarquux'
    assert ansible_native_concat([u'foo', u'bar', u'quux']) == 'foobarquux'
    assert ansible_native_concat(['foo', u'bar', u'quux']) == 'foobarquux'
    assert ansible_native_concat(['foo', 'bar', u'quux']) == 'foobarquux'
    assert ansible_native_concat

# Generated at 2022-06-23 13:20:24.791386
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import Environment
    from ansible.module_utils.common.text.converters import to_native

    def to_jinja_expr(expr):
        return Environment().from_string(expr).root

    # Basic operations
    assert ansible_native_concat(to_jinja_expr('{{ 1 | string }}')) == '1'
    assert ansible_native_concat(to_jinja_expr('{{ 1 + 2 }}')) == 3
    assert ansible_native_concat(to_jinja_expr('{{ [1, 2, 3] + [4, 5] }}')) == [1, 2, 3, 4, 5]

# Generated at 2022-06-23 13:20:35.337766
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_native

    assert ansible_native_concat([]) == None
    assert ansible_native_concat(["foo"]) == "foo"
    assert ansible_native_concat(["foo", "bar"]) == "foobar"
    assert ansible_native_concat(["1", "2"]) == "12"
    assert ansible_native_concat(["1", 2]) == "12"
    assert ansible_native_concat(["foo", ["bar"]]) == "foo['bar']"
    assert isinstance(ansible_native_concat(["[1, 2, 3]"]), list)
    assert ansible_native_concat(["[1, 2, 3]"]) == [1, 2, 3]


# Generated at 2022-06-23 13:20:43.120071
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(('one', 'two')) == 'onetwo'
    assert ansible_native_concat(('one',)) == 'one'
    assert ansible_native_concat(()) is None
    assert ansible_native_concat(('one', 42)) == 'one42'
    assert ansible_native_concat(('one', 42, 'two')) == 'one42two'

    # literal eval
    assert ansible_native_concat(('1',)) == 1
    assert ansible_native_concat(('1', 2)) == '12'
    assert ansible_native_concat(('  1',)) == '1'

    # containers
    assert ansible_native_concat(('1', [2], '3')) == '1[2]3'
   

# Generated at 2022-06-23 13:20:54.032523
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    string = 'this is a string'
    list = [1, 2, 3, 4]
    dict = {'key': 'value'}
    bool_true = True
    bool_false = False
    float = 1.0
    int = 1
    unicode = u'unicode'
    vault_obj = AnsibleVaultEncryptedUnicode(u'c2VjcmV0\n')
    bytes = b'bytes'

    vault_txt = to_text(AnsibleDumper().represent_unicode(vault_obj))


# Generated at 2022-06-23 13:21:05.093250
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.six import moves
    import pytest


# Generated at 2022-06-23 13:21:15.975270
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(["a"]) == "a"
    assert ansible_native_concat(["a", "b", "c"]) == "abc"
    assert ansible_native_concat([u"a", u"b", u"c"]) == "abc"
    assert ansible_native_concat([5]) == 5
    assert ansible_native_concat([3, u"4"]) == "34"
    assert ansible_native_concat([u"123", u"456"]) == "123456"
    assert ansible_native_concat([[1], [2], [3]]) == "[1, 2, 3]"
    assert ansible_native_concat([[1], 2, [3]]) == "[1, 2, 3]"
    assert ansible_native_con

# Generated at 2022-06-23 13:21:27.430043
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat(['foo', 'bar', 'baz']) == 'foobarbaz'
    assert ansible_native_concat([1, 2, 3, 4]) == 10
    assert ansible_native_concat([1, 2, '3', 4]) == '1234'
    assert ansible_native_concat(['1', 2, 3, 4]) == '1234'
    assert ansible_native_concat(['1', 2, '3', '4']) == 1 + 2 + 3 + 4
    assert ansible_native_concat([1, 2, '3', '4'])

# Generated at 2022-06-23 13:21:37.343493
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from collections import namedtuple
    TestCase = namedtuple('TestCase', ['nodes', 'expected_result'])

# Generated at 2022-06-23 13:21:42.097575
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # check that ansible_native_concat is identical to the one used in Jinja
    from jinja2.nativetypes import native_concat as jinja_native_concat
    from jinja2.nodes import List, template_helper
    from jinja2.utils import Markup

    nodes_list = [template_helper(data) for data in [1, None, 'string', u'unicode', b'binary', Markup('escaped')]]

    assert ansible_native_concat(nodes_list) == jinja_native_concat(nodes_list)

    assert ansible_native_concat(nodes_list[:1]) == 1
    assert ansible_native_concat(nodes_list[:2]) == [1, None]
    assert ansible_native_

# Generated at 2022-06-23 13:21:53.577340
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = ['a', 'b', 'c']
    assert ansible_native_concat(nodes) == 'abc'
    assert ansible_native_concat(iter(nodes)) == 'abc'
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['1.0']) == 1.0

    # The result is wrapped in AnsibleJinjaText, because it is
    # a string that cannot be treated as a literal.
    assert ansible_native_concat(['1.0.0']) == '1.0.0'
    assert ansible_native_concat([1.0]) == 1.0

# Generated at 2022-06-23 13:22:02.494552
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 1]) == u'11'
    assert ansible_native_concat([1, [1, 2]]) == u'11, 2'
    assert ansible_native_concat([1, [1, 2], 3]) == u'11, 2, 3'
    assert ansible_native_concat(['1', [1, 2], 3]) == u'1, 11, 2, 3'
    assert ansible_native_concat([1, {'a': 1}, 3]) == u'1, {a=1}, 3'

# Generated at 2022-06-23 13:22:07.589984
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == 12
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat([1, 2, 3, 4]) == 1234
    assert ansible_native_concat([1, 2, 3, 4, 5]) == 12345

    assert ansible_native_concat([1, u'2']) == 12
    assert ansible_native_concat([1, '2']) == 12
    assert ansible_native_concat([1, '2', u'3']) == 123
    assert ansible_native_concat([1, u'2', 3]) == 123
    assert ansible_native_concat([u'1', '2', 3])

# Generated at 2022-06-23 13:22:19.713746
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat(['42']) == '42'

    assert ansible_native_concat(['42', '20']) == '4220'
    assert ansible_native_concat(['42', 20]) == '4220'

    assert ansible_native_concat(['42', '"20"']) == '42"20"'
    assert ansible_native_concat(['42', '[]']) == '42[]'

    assert ansible_native_concat(['42', ['20']]) == '42[20]'
    assert ansible_native_concat(['42', [20]]) == '42[20]'


# Generated at 2022-06-23 13:22:31.709365
# Unit test for function ansible_native_concat