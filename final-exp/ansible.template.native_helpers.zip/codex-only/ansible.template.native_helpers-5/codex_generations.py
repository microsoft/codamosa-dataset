

# Generated at 2022-06-23 13:12:38.547797
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    nodes = [
        'hello',
        ' ',
        'world',
        '!',
    ]
    assert ansible_native_concat(nodes) == 'hello world!'

    nodes = [
        AnsibleVaultEncryptedUnicode(u'hello'),
        ' ',
        AnsibleVaultEncryptedUnicode(u'world'),
        '!',
    ]
    assert ansible_native_concat(nodes) == 'hello world!'

    nodes = [
        'hello',
        ' ',
        'world',
        '!',
        42,
        ' ',
        24.0,
    ]

# Generated at 2022-06-23 13:12:46.735582
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    ansible_native_concat(None)

# Generated at 2022-06-23 13:12:55.273925
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    def test(r):
        assert isinstance(r, (int, float, string_types, dict, list, tuple, type(None)))

    # empty
    test(ansible_native_concat([]))

    # single native
    test(ansible_native_concat([1]))

    # single string
    test(ansible_native_concat(["1"]))

    # string concat
    test(ansible_native_concat(["1", "2"]))

    # string to numeric
    test(ansible_native_concat(["1", "2", "3"]))

    # single dict
    test(ansible_native_concat([{'foo': 'bar'}]))

    # dict concat

# Generated at 2022-06-23 13:13:05.555425
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    inputs = [
        (['a', 'b'], 'ab'),
        ([1, 2], '12'),
        ([1, 2, 3], '123'),
        (['', 'a', 'b', [], {}, ''], 'ab{}'),
        (['', 'a', 'b', [], {}, '', '123'], 'ab{}123'),
        (['123', '456'], 579),
        (['123', '456', '789'], '123456789'),
        ([None], None),
        ([42, None], 42),
    ]

    for inp, res in inputs:
        nodes = [NativeJinjaText(type(v), v) for v in inp]
        assert ansible_native_concat(nodes) == res


# Generated at 2022-06-23 13:13:17.814697
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Unit test for function ansible_native_concat
    # Test all combinations of single/double quotes.
    # Note that all tests encode unicode by default.
    assert ansible_native_concat([u"'a'"
                                  ]) == u'a'
    assert ansible_native_concat([u'"a"'
                                  ]) == u'a'
    assert ansible_native_concat([u"'a'b"
                                  ]) == u'a'
    assert ansible_native_concat([u'"a"b'
                                  ]) == u'a'
    assert ansible_native_concat([u'a"b"'
                                  ]) == u'ab'
    assert ansible_native_concat([u'a"b'
                                  ]) == u'ab'
    assert ansible_native_con

# Generated at 2022-06-23 13:13:28.346348
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([['a']]) == ['a']
    assert ansible_native_concat([u'a']) == u'a'
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat([['a'], ['b']]) == ['a', 'b']
    assert ansible_native_concat([u'a', u'b']) == u'ab'

# Generated at 2022-06-23 13:13:39.189521
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # test for literal_eval parsing
    # TODO: fix this when literal_eval is actually called in conjunction with ansible_native_concat
    # assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    # assert ansible_native_concat([1, '*', 2, 3]) == [1, 2, 3]
    # assert ansible_native_concat(['[', 1, '*', 2, ']', '+', '[', 3, ']']) == [1, 2, 3]

    # test for string concatenation
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([1, '*', 2, 3]) == '1*23'

# Generated at 2022-06-23 13:13:49.123000
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, '2', 3]) == '123'
    assert ansible_native_concat([1, '2']) == 12
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['hello']) == 'hello'
    assert ansible_native_concat(['hello', 'world']) == 'helloworld'

# Generated at 2022-06-23 13:14:00.775247
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.collections import is_sequence

    # Verify we return the single non-string value as-is
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([True]) == True
    assert ansible_native_concat([None]) is None
    x = dict(a=1)
    assert ansible_native_concat([x]) == x
    x = ['a', 'b']
    assert ansible_native_concat([x]) == x

    # Verify we return the single string values as-is

# Generated at 2022-06-23 13:14:11.477930
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, 'a']) == '1a'
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([1, 'a', 2, 'b']) == '1a2b'
    assert ansible_native_concat([1, 2, 'a', 3, 'b']) == '12a3b'
    assert ansible_native_concat([1, 2, 'a', 'b', 3]) == '12ab3'

    assert ansible_native_concat(['a']) == 'a'

# Generated at 2022-06-23 13:14:15.205093
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'foo', u'bar', u'baz']) == u'foobarbaz'

    assert ansible_native_concat([u'foo', b'bar', u'baz']) == u'foobarbaz'



# Generated at 2022-06-23 13:14:24.954906
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2
    from ansible.module_utils.six.moves import StringIO

    # Python 2 requires unicode literals to be raw
    def _u(s):
        return s.decode('unicode_escape') if isinstance(s, str) else s

    env = jinja2.Environment()
    env.filters['repr'] = repr
    env.filters['container_to_text'] = container_to_text

    def _test(input_str, expected):
        assert env.compile(input_str).root_render_func() == expected

    _test(u'"\u2603"'              , u'u\'\u2603\'')
    _test(u'"{% raw %}\u2603{% endraw %}"', u'u\'\\u2603\'')

# Generated at 2022-06-23 13:14:33.420862
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(["foo"]) == "foo"
    assert ansible_native_concat(["foo", "bar"]) == "foobar"
    assert ansible_native_concat(["foo", 1, 2, 3]) == "foo123"
    assert ansible_native_concat(["foo", 1, 2, [3, 4]]) == "foo12[3, 4]"
    assert ansible_native_concat(["foo", 1, 2, {"3": 4}]) == "foo12{'3': 4}"
    assert ansible_native_concat(["foo", 1, 2, True, False, None]) == "foo12TrueFalseNone"
    assert ansible_native_concat(["foo", 1, 2, True, False, None]) == "foo12TrueFalseNone"
   

# Generated at 2022-06-23 13:14:41.007746
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.six import PY3, PY2

    # A single NativeJinjaText
    node_1 = NativeJinjaText('hello')
    result_1 = ansible_native_concat(iter([node_1]))
    assert isinstance(result_1, NativeJinjaText)
    assert result_1 == 'hello'

    # Two NativeJinjaTexts
    node_2 = NativeJinjaText('hello')
    node_3 = NativeJinjaText(', world')
    result_2 = ansible_native_concat(iter((node_2, node_3)))
    if PY3:
        assert isinstance(result_2, text_type)
    else:
        assert isinstance(result_2, NativeJinjaText)
    assert result_2

# Generated at 2022-06-23 13:14:47.875196
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2]) == u"12"
    assert ansible_native_concat([NativeJinjaText("Hello"), " "]) == u"Hello "
    assert ansible_native_concat([NativeJinjaText("Hello"), " "]) == u"Hello "
    assert ansible_native_concat([NativeJinjaText("Hello"), " ", NativeJinjaText("world")]) == u"Hello world"
    assert ansible_native_concat([NativeJinjaText("Hello"), " ", NativeJinjaText("'world'")]) == u"Hello 'world'"
    assert ansible_native_concat([NativeJinjaText("Hello"), " ", "world"]) == u"Hello world"

# Generated at 2022-06-23 13:14:58.645816
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat([3]) == 3

    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(['a']) == 'a'

    assert ansible_native_concat(['[', 1, 2, 3, ']']) == [1, 2, 3]
    assert ansible_native_concat(['(', 1, 2, 3, ')']) == (1, 2, 3)
    assert ansible_native_concat(['[1, 2, 3, ]']) == [1, 2, 3]

# Generated at 2022-06-23 13:15:09.282955
# Unit test for function ansible_native_concat

# Generated at 2022-06-23 13:15:16.583574
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(('1', '2')) == [u'1', u'2']
    assert ansible_native_concat(('1', '2', '3')) == [u'1', u'2', u'3']
    assert ansible_native_concat(('1', '2', '3', '4')) == u'1234'
    assert ansible_native_concat(('1', '2', '3', '4', '5')) == u'12345'

# Generated at 2022-06-23 13:15:25.857059
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # test simple string concat
    assert ansible_native_concat(['first', ' second']) == 'first second'
    # test list concat
    assert ansible_native_concat(['first', [' second']]) == 'first second'
    assert ansible_native_concat([['first'], ' second']) == 'first second'
    # test dict concat
    assert ansible_native_concat(['first', {'bar': ' second'}]) == 'first second'
    assert ansible_native_concat([{'bar': 'first'}, ' second']) == 'first second'
    # test secret concat
    assert isinstance(ansible_native_concat(['first', AnsibleVaultEncryptedUnicode(' second')]), string_types)

# Generated at 2022-06-23 13:15:32.871822
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = ['this', ' ', 'is', ' ', 'a', ' ', 'test']
    assert ansible_native_concat(nodes) == 'this is a test'
    nodes = ['this-is-a-test']
    assert ansible_native_concat(nodes) == 'this-is-a-test'
    # See https://github.com/pallets/jinja/issues/1200#issuecomment-665479751
    nodes = ['this', 'isa', 'test', 'var']
    assert ansible_native_concat(nodes) == 'thisisatestvar'

# Generated at 2022-06-23 13:15:44.057041
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(()) is None
    assert ansible_native_concat(['None']) == 'None'
    assert ansible_native_concat(['None', 'None']) == 'NoneNone'
    assert ansible_native_concat(['None', 'None', 'None']) == 'NoneNoneNone'
    assert ansible_native_concat(['2', '2', '2']) == 222

# Generated at 2022-06-23 13:15:50.544126
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(iter([])) is None

    assert ansible_native_concat("a") == "a"
    assert ansible_native_concat("a") == to_text("a")

    assert ansible_native_concat([]) == ""
    assert ansible_native_concat(iter([])) == ""

    assert ansible_native_concat(["a"]) == "a"
    assert ansible_native_concat(iter(["a"])) == "a"

    assert ansible_native_concat(['a', 'b']) == "ab"
    assert ansible_native_concat(iter(['a', 'b'])) == "ab"


# Generated at 2022-06-23 13:15:59.626844
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat(range(10)) == '0123456789'
    assert ansible_native_concat([1, 2.0]) == 1.0
    assert ansible_native_concat([1, '2.0']) == 1.0
    assert ansible_native_concat(['1.0', 2]) == 1.0
    assert ansible_native_concat([1, 2, '3']) == '123'
    assert ansible_native_concat(map(str, range(10))) == '0123456789'

# Generated at 2022-06-23 13:16:07.448216
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Tests for ansible_native_concat function which implements the
    native_concat method of the jinja2.NativeEnvironment.

    The tests follow:
    https://github.com/pallets/jinja/blob/master/src/jinja2/tests/test_env.py#L1413-L1425
    """
    def check(expected, data):
        assert expected == ansible_native_concat(data)

    # A single string
    check('foo', ['foo'])

    # A single integer
    check(123, [123])

    # A single boolean
    check(True, [True])

    # A single float
    check(123.456, [123.456])

    # Two strings
    check('foobar', ['foo', 'bar'])

    # String and integer
    check

# Generated at 2022-06-23 13:16:16.645434
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test basic types
    assert ansible_native_concat(123) == 123
    assert ansible_native_concat(1.2) == 1.2
    assert ansible_native_concat(False) is False
    assert ansible_native_concat(None) is None
    assert ansible_native_concat("foo") == "foo"
    assert ansible_native_concat("foo bar") == "foo bar"
    assert ansible_native_concat("foo\n") == "foo\n"
    assert ansible_native_concat("\nbar") == "\nbar"
    assert ansible_native_concat("\nbar\n") == "\nbar\n"
    assert ansible_native_concat("{foo}") == "{foo}"
    assert ansible_native_concat

# Generated at 2022-06-23 13:16:24.785099
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Testing the function:
    # 1) with a mixture of sequence types
    # 2) with a mixture of values which are and are not literal_eval-able
    # 3) with empty sequences
    # 4) with literal_eval-able sequences
    seq1 = [1, 2, 3]
    seq2 = {'a': 1, 'b': 2}
    seq3 = [('a', 1), ('b', 2)]
    seq4 = {'a': [1, 2, 3], 'b': ('a', 1), 'c': {'d': (1, 2, 3)}}
    seq5 = ['a', 2, [3, 4]]
    seq6 = [1, 2.0, 3j, False, u"str", b"str", None]

# Generated at 2022-06-23 13:16:35.583006
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Python 3.9 adds a new function, ast.parse, that removes
    # leading spaces/tabs from the given string to be parsed.
    # This is causing tests in LiteralEval to fail in Python 3.9
    # due to the difference in behavior. Hence we are not testing
    # the LiteralEval functionality here.
    out = ansible_native_concat([])
    assert out is None
    # Test with a string
    out = ansible_native_concat(['test'])
    assert out == 'test'
    # Test with a number
    out = ansible_native_concat([10])
    assert out == 10
    out = ansible_native_concat(['test1', 'test2'])
    assert out == 'test1test2'

# Generated at 2022-06-23 13:16:43.348976
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([None, None, None]) is None
    assert ansible_native_concat([1, None, None]) == 1
    assert ansible_native_concat([None, 2, None]) == 2
    assert ansible_native_concat([None, None, 3]) == 3
    assert ansible_native_concat([[], None, 3]) == [3]
    assert ansible_native_concat([[], '', 3]) == [3]
    assert ansible_native_concat([[], 'a', 3]) == ['a', 3]
    assert ansible_native_concat(['a', None, 'b']) == 'ab'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_con

# Generated at 2022-06-23 13:16:52.316817
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils import basic
    from ansible.template import Templar
    from ansible.parsing.yaml import objects

    from ansible.parsing.yaml.loader import AnsibleLoader as YamlLoader

    from ansible.parsing.vault import VaultLib, VaultSecret

    def fake_get_vault_secret(path):
        """Fake get_vault_secret function that returns a static secret."""
        return VaultSecret('vault_secret', VaultLib('vault_password'))

    loader = YamlLoader()

# Generated at 2022-06-23 13:17:02.086118
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = [{}, ['abc'], b'', None]
    assert ansible_native_concat(nodes) == [{}, ['abc'], b'', None]

    nodes = [{}, ['abc'], {'a': 1}]
    assert ansible_native_concat(nodes) == [{}, ['abc'], {'a': 1}]

    nodes = ['1', '2']
    assert ansible_native_concat(nodes) == '12'

    nodes = ['1', '2', 3]
    assert ansible_native_concat(nodes) == '123'

    nodes = ['1', '2', 3, {'a': 1}]
    assert ansible_native_concat(nodes) == '123{'


# Generated at 2022-06-23 13:17:11.136696
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes, AnsibleUnsafeText

    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['test']) == 'test'
    assert ansible_native_concat(['test', 'test2']) == 'testtest2'
    assert ansible_native_concat([AnsibleUnsafeText('test'), 'test2']) == 'testtest2'
    assert ansible_native_concat([AnsibleUnsafeBytes('test'), 'test2']) == 'testtest2'

# Generated at 2022-06-23 13:17:17.441730
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test reduce with an empty list
    assert ansible_native_concat([]) == None

    # Test reduce with a single element
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([None]) == None
    assert ansible_native_concat([True]) == True
    assert ansible_native_concat([False]) == False
    assert ansible_native_concat([""]) == ""
    assert ansible_native_concat(["a"]) == "a"
    assert ansible_native_concat([[]]) == []
    assert ansible_native_concat([[1]]) == [1]
    assert ansible_native_concat([{}]) == {}

# Generated at 2022-06-23 13:17:27.149715
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.template import Templar

    # Add a mock module to set Jinja env
    class TestModule(object):
        def __init__(self):
            self.params = {}
            self.tmpdir = '/tmp'
            self.module_specific_vars = {}
            self.module_specific_facts = {}
            self.templar = Templar(loader=None, variables=self.params)

    # Comparison data

# Generated at 2022-06-23 13:17:38.491338
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2.nodes as nodes
    from jinja2.nodes import NativeJinjaText, StrictUndefined

    variables = {
        'x': 1,
        'y': StrictUndefined,
        'z': 'z',
        'ansible_vault': AnsibleVaultEncryptedUnicode('test', b'test'),
        'a': 'a',
        'b': 2
    }

    assert ansible_native_concat([nodes.Const(1)]) == 1
    assert ansible_native_concat([nodes.Name('x', 'load'), nodes.Name('y', 'load')]) is None

    # check with an undefined value

# Generated at 2022-06-23 13:17:48.749020
# Unit test for function ansible_native_concat

# Generated at 2022-06-23 13:17:59.953418
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(["a", "b"]) == "ab"
    assert ansible_native_concat([1, 2]) == 3
    assert ansible_native_concat([1, "2"]) == "12"
    assert ansible_native_concat([{'a': 1}, {'b': 2}]) == '{\'b\': 2, \'a\': 1}'
    assert ansible_native_concat(["1", 2]) == "12"
    assert ansible_native_concat(["a b", 2]) == "a b2"
    assert ansible_native_concat([AnsibleVaultEncryptedUnicode("a"), 2]) == "a"
    assert ansible_native_concat([NativeJinjaText("a"), 2]) == "a"
   

# Generated at 2022-06-23 13:18:08.120001
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat([]).__class__ == type(None)
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat([1, 2]) == u'12'
    assert ansible_native_concat('12') == u'12'
    assert ansible_native_concat([1, '2']) == u'12'
    assert ansible_native_concat([1, 2.0]) == u'12.0'
    assert ansible_native_concat([1, 2.0, 3.0]) == u'123.0'
    assert ansible_native_concat([1, 2.0, '3'])

# Generated at 2022-06-23 13:18:14.057399
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert ansible_native_concat([]) is None

    # The result is a single node
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([2]) == 2

    # The result is not a string
    assert ansible_native_concat([['foo', 'bar']]) == ['foo', 'bar']

    # The result is a string
    assert ansible_native_concat(['foo', 2, 'bar']) == 'foo2bar'

    # The result can be parsed
    assert ansible_native_concat(['foo', 1, 'bar']) == 'foo1bar'
    assert ansible_native_concat(['foo', True, 'bar']) == 'foobar'

    # The result cannot be parsed
    assert ansible_native

# Generated at 2022-06-23 13:18:24.715085
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    with open('test_ansible_native_concat.py') as test_file:
        data = test_file.read()


# Generated at 2022-06-23 13:18:34.924033
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Check with one input node
    v = {'a': [1, 2, 3]}
    node_list = ansible_native_concat([v])
    assert v == node_list

    # Check with a string
    v = 'hello world'
    node_list = ansible_native_concat([v])
    assert v == node_list

    # Check with multiple input nodes
    v = 'hello'
    node_list = ansible_native_concat(['1', v, '3', '4'])
    assert '143' == node_list

    # Check with literal_eval
    node_list = ansible_native_concat(['1', '2', '3', '4'])
    assert 1234 == node_list

    # Check with literal_eval
    v = '"hello"'
    node

# Generated at 2022-06-23 13:18:43.903170
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import pytest
    from ansible.module_utils.six import PY3

    node = lambda v: (v, to_text(v))
    nodes = [
        node(42),
        node(u'foo'),
        node(43),
        node(44),
        node(u'bar'),
        node(u'foo'),
        node(u'bar'),
    ]

    assert ansible_native_concat(nodes) == u'foobarfoobar'
    assert ansible_native_concat(iter(nodes)) == u'foobarfoobar'
    assert ansible_native_concat([node(u'42')]) == 42
    assert ansible_native_concat([node(u"'foo'")]) == u'foo'

# Generated at 2022-06-23 13:18:54.794945
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    example = "['This is ', 'a test']"
    result = ansible_native_concat(ast.literal_eval(example))
    assert result == 'This is a test'

    example = "['This is ', 'a test', ' ']"
    result = ansible_native_concat(ast.literal_eval(example))
    assert result == 'This is a test '

    example = "['This is ', 'a test', ' ']"
    result = ansible_native_concat(ast.literal_eval(example))
    assert result == 'This is a test '

    example = "['This is ', 'a test']"
    result = ansible_native_concat(ast.literal_eval(example))
    assert result == 'This is a test'


# Generated at 2022-06-23 13:19:04.529360
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.native_jinja import NativeJinjaText

    def _generate_nodes():
        for item in ['1', '2', '3']:
            yield text_type(item)

    class DummyNode:
        def __init__(self, value):
            self.value = value

    assert ansible_native_concat(['1']) == '1'
    assert ansible_native_concat(['True']) is True
    assert ansible_native_concat(['1', '2', '3']) == '123'

# Generated at 2022-06-23 13:19:14.623100
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.j2 import ansible_native_concat_jinja_filter
    from ansible.module_utils.common.text.j2 import ansible_native_concat_jinja_test
    from ansible.module_utils.common.text.j2 import ansible_native_concat

    node_generator = (ast.Expression(ast.Str(v)) for v in 'abc')

    class Node:
        pass

    node = Node()
    node.nodes = node_generator

    assert ansible_native_concat(node.nodes) == 'abc'

    def _fail_on_undefined(*args):
        raise RuntimeError('undefined')


# Generated at 2022-06-23 13:19:25.062629
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([0, 1, 2]) == "0102"
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat([1, 2, 3.0]) == '123.0'
    assert ansible_native_concat([1, 2, 3j]) == u'123j'
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat([1, 2, 3]) == (1, 2, 3)
    assert ansible_native_concat([1, 2, 3]) == {1, 2, 3}
    assert ansible_native_concat([1, 2, 3]) == {1: 1, 2: 2, 3: 3}
    assert ans

# Generated at 2022-06-23 13:19:33.658691
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = [123, 456]
    assert ansible_native_concat(nodes) == 123456

    nodes = ["123", 456]
    assert ansible_native_concat(nodes) == "123456"

    nodes = [123, "456"]
    assert ansible_native_concat(nodes) == 123456

    nodes = ["123", "456"]
    assert ansible_native_concat(nodes) == "123456"

    nodes = [123, "abc", 456]
    assert ansible_native_concat(nodes) == "123abc456"

    nodes = [u"\u043f", u"\u0440\u0438\u0432\u0435\u0442"]

# Generated at 2022-06-23 13:19:43.583983
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['test']) == u'test'
    assert ansible_native_concat(['test', 'ing']) == u'testing'
    assert ansible_native_concat(['123']) == 123
    assert ansible_native_concat(['123', '456']) == u'123456'
    assert ansible_native_concat(['[']) == u'['
    assert ansible_native_concat(['{"a":1}']) == {u'a': 1}
    assert ansible_native_concat(['{"a":1}', '{"b":2}']) == u'{"a":1}{"b":2}'

# Generated at 2022-06-23 13:19:55.463197
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([5]) == 5
    assert ansible_native_concat([u'some string']) == u'some string'
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([False]) is False
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([[1, 2, 3]]) == [1, 2, 3]
    assert ansible_native_concat([(1, 2, 3)]) == (1, 2, 3)
    assert ansible_native_concat([{'this': 'is', 'a': 'dict'}]) == {'this': 'is', 'a': 'dict'}
    assert ansible_native_

# Generated at 2022-06-23 13:20:04.030577
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2

    from . import test_data_loader

    env = jinja2.Environment(loader=test_data_loader)

    t = env.get_template('ansible-native-concat.j2')

    # result is str
    assert isinstance(t.render(), string_types)

    # result is int
    assert isinstance(t.render(x=1, y=2), int)

    # result is list
    assert isinstance(t.render(x="[1, 2]", y="['a', 'b']"), list)

    # result is dict
    assert isinstance(t.render(x="{'a': 'b'}", y="{'c': 'd'}"), dict)

    # result is str

# Generated at 2022-06-23 13:20:14.658502
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    assert ansible_native_concat([NativeJinjaText('foo')]) == 'foo'
    assert ansible_native_concat([NativeJinjaText('foo'), NativeJinjaText('bar')]) == 'foobar'
    assert ansible_native_concat([NativeJinjaText('foo'), 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', NativeJinjaText('bar')]) == 'foobar'

    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'

    assert ansible_native_concat([1]) == 1

# Generated at 2022-06-23 13:20:26.884631
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    old_concat = NativeJinjaText.__add__


# Generated at 2022-06-23 13:20:36.593908
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    # Creating a native jinja2.environment.Environment
    scoped_env = AnsibleConstructor.scope
    # Load the module to access its globals, etc.
    scoped_env.loader.load_module('ansible.parsing.jinja2.filters.native')
    # Register our function
    scoped_env.filters['ansible_native_concat'] = ansible_native_concat


# Generated at 2022-06-23 13:20:48.150347
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common.text.converters import to_bytes

    if PY3:
        assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
        if to_bytes is not to_text:
            # If we're not running in text mode, ansible_native_concat should
            # return a native string (bytes in Python 3).
            assert ansible_native_concat(['a', 'b', 'c']) == b'abc'
    else:
        assert ansible_native_concat(['a', 'b', 'c']) == u'abc'

    assert ansible_native_concat

# Generated at 2022-06-23 13:20:53.728088
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import Environment
    from ansible.module_utils.common.text.converters import container_to_text
    from ansible.module_utils.six import text_type

    def test_native_concat(template_string, expected):
        env = Environment(extensions=['jinja2.ext.do'])
        env.globals['ansible_native_concat'] = ansible_native_concat
        template = env.from_string(template_string)
        result = template.render().strip()
        assert result == container_to_text(expected)

    test_native_concat('{{ ansible_native_concat() }}', '')
    test_native_concat('{{ ansible_native_concat(True) }}', True)

# Generated at 2022-06-23 13:21:04.876158
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([u'a']) == u'a'
    assert ansible_native_concat([b'a']) == b'a'

    assert ansible_native_concat([1, 2]) == 3
    assert ansible_native_concat([1, 2.0]) == 3.0
    assert ansible_native_concat([1.0, 2]) == 3.0

    assert ansible_native_concat([u'a', u'b']) == u'ab'
    assert ansible_native_concat([b'a', b'b']) == b'ab'
    assert ansible_native_concat([1, 2, 3]) == 6

# Generated at 2022-06-23 13:21:15.976504
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test that function ansible_native_concat returns
    # the same result as ansible native concatenation.
    #
    # This is achieved by listing all possible combinations of 1, 2, and 3 input
    # elements. The input elements are dictionaries, lists (both empty and not
    # empty, and scalars. For each combination, the function ansible_native_concat
    # is applied and the result compared with the expected result which is computed
    # as the result of ansible native concatenation.

    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    def _concat(*args):
        loader = DataLoader()
        tests = list(range(len(args)))
        for i in tests:
            # prepare the jinja2 environment
            env = Templar._new_jin

# Generated at 2022-06-23 13:21:27.429993
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(["one"]) == "one"
    assert ansible_native_concat([1, ['two']]) == "[1, ['two']]"
    assert ansible_native_concat([1, 'two']) == "[1, u'two']"
    assert ansible_native_concat([1, "two"]) == "[1, 'two']"
    assert ansible_native_concat([1, 3]) == "[1, 3]"
    assert ansible_native_concat(["one", ["two"]]) == "['one', ['two']]"

# Generated at 2022-06-23 13:21:33.574891
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # test ast.literal_eval
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['foobar']) == 'foobar'
    assert ansible_native_concat(['[1, 2, 3]']) == [1, 2, 3]
    assert ansible_native_concat(['{"a": "b"}']) == {'a': 'b'}
    assert ansible_native_concat(['(1, 2, 3)']) == (1, 2, 3)

    # test failure as expected
    assert ansible_native_concat(['"foobar"']) == '"foobar"'
    assert ansible_native_concat(['[1, 2, 3']) == '[1, 2, 3'

# Generated at 2022-06-23 13:21:44.899309
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # literal_eval should be used for string concatenations
    assert ansible_native_concat(["1", "2"]) == "12"
    assert ansible_native_concat(["1.2", "2"]) == "1.22"
    assert ansible_native_concat(["1.2", "2"]) == 1.22
    assert ansible_native_concat(["1.2", "2", "2"]) == "1.222"
    assert ansible_native_concat(["1.2", "2", "2"]) == 1.222
    assert ansible_native_concat(["1.2", "2", "x"]) == "1.222x"

# Generated at 2022-06-23 13:21:56.526746
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def test_str(value):
        """Assert that the value evaluates to str"""
        assert isinstance(value, string_types)

    test_str(ansible_native_concat([]))
    test_str(ansible_native_concat([u'1', None]))
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([u'a', u'b']) == u'ab'
    assert ansible_native_concat([u'a', u'b', u'', u'c']) == u'abc'
    assert ansible_native_concat([dict(a=1), u'b', None, u'c']) == u'abc'



# Generated at 2022-06-23 13:22:08.431307
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Test case where there is no argument
    # (i.e. to check that there are no IndexErrors)
    assert ansible_native_concat([]) is None

    # Test case where there is a single argument
    # (i.e. to check that there is no type conversion of the argument)
    assert ansible_native_concat(["test"]) == "test"

    # Test case where the arguments convert to a single int
    assert ansible_native_concat(["1", "2"]) == 3

    # Test case where the arguments convert to a single float
    assert ansible_native_concat(["1.1", "2.2"]) == 3.3

    # Test case where the arguments convert to a single string

# Generated at 2022-06-23 13:22:20.370062
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test the function with a test jinja2 environment
    # https://github.com/pallets/jinja/blob/master/src/jinja2/testsuite.py
    from jinja2.environment import Environment

    env = Environment(undefined=StrictUndefined)
    env.filters['ansible_native_concat'] = ansible_native_concat

# Generated at 2022-06-23 13:22:32.762007
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.native_jinja import MarkedUndefined
    try:
        from ansible.parsing.yaml.loader import AnsibleLoader
    except ImportError:
        AnsibleLoader = None

    def render(s):
        from ansible.parsing.yaml.dumper import AnsibleDumper
        from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
        yaml = AnsibleDumper()
        return container_to_text(yaml.represent_data(s), keep_unsafe=True)

    class String(object):
        def __init__(self, value):
            self.value = value
