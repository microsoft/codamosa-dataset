

# Generated at 2022-06-25 12:19:15.234525
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '\\q:d+#7EcfzFg(%'
    var_0 = ansible_native_concat(str_0)
    assert var_0 is None


# Unit tests for functions in jinja2/nativetypes.py

# Generated at 2022-06-25 12:19:18.257412
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()

# Generated at 2022-06-25 12:19:20.524009
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert str_0 == '\\q:d+#7EcfzFg(%'
    assert var_0 == '\\q:d+#7EcfzFg(%'

# Generated at 2022-06-25 12:19:31.107933
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    res = ansible_native_concat(['A', 'B'])
    assert isinstance(res, text_type)
    assert res == 'AB'

    res = ansible_native_concat(['A', '', 'B'])
    assert isinstance(res, text_type)
    assert res == 'AB'

    res = ansible_native_concat(['A', 1, 'B'])
    assert isinstance(res, text_type)
    assert res == 'A1B'

    res = ansible_native_concat(['A', True, 'B'])
    assert isinstance(res, text_type)
    assert res == 'ATrueB'

    res = ansible_native_concat(['A', False, 'B'])
    assert isinstance(res, text_type)


# Generated at 2022-06-25 12:19:37.503803
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert to_text(container_to_text(ansible_native_concat(container_to_text('\\q:d+#7EcfzFg(%')))) == '\\q:d+#7EcfzFg(%'
    assert to_text(container_to_text(ansible_native_concat([container_to_text("/G'/c%l"), container_to_text('*T7[Y-y')]))) == "/G'/c%l*T7[Y-y"
    assert to_text(container_to_text(ansible_native_concat([container_to_text('+F1=dD'), container_to_text('[:}*8a')]))) == '+F1=dD[:}*8a'

# Generated at 2022-06-25 12:19:47.087216
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '\\q:d+#7EcfzFg(%'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == '\\q:d+#7EcfzFg(%'
    str_0 = 'Hey, you - what do you want?'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'Hey, you - what do you want?'
    str_0 = ['126', '126', '126']
    var_0 = ansible_native_concat(str_0)
    assert var_0 == '126126126'
    str_0 = ['Hello ', 'World', '!']
    var_0 = ansible_native_concat(str_0)

# Generated at 2022-06-25 12:19:51.461683
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '\\q:d+#7EcfzFg(%'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == '\\q:d+#7EcfzFg(%'


# Generated at 2022-06-25 12:19:59.824507
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert to_text(ansible_native_concat('\\q:d+#7EcfzFg(%')) == '\\q:d+#7EcfzFg(%'
    assert ansible_native_concat(to_text('\\q:d+#7EcfzFg(%')) == '\\q:d+#7EcfzFg(%'
    assert to_text(ansible_native_concat('\\q:d+#7EcfzFg(%')) == '\\q:d+#7EcfzFg(%'
    assert to_text(ansible_native_concat(to_text('\\q:d+#7EcfzFg(%'))) == '\\q:d+#7EcfzFg(%'
    assert to

# Generated at 2022-06-25 12:20:01.671355
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '\\q:d+#7EcfzFg(%'
    var_0 = ansible_native_concat(str_0)
    assert var_0 is not None

# Generated at 2022-06-25 12:20:05.389227
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert callable(ansible_native_concat)
    assert isinstance(ansible_native_concat(['abc']), str)
    assert ansible_native_concat(['abc']) == 'abc'
    assert ansible_native_concat([1]) == 1

# Generated at 2022-06-25 12:20:17.611874
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = ';/bS&A\\g/E/:\\H]{Fwq,4N'
    str_1 = 'x;|tP!nXh#%'
    str_2 = '\\n#>k)[h'
    str_3 = 'T*S'
    str_4 = 'E]gF'
    str_5 = 'c'
    str_6 = 'xUOq^`Y'
    str_7 = '|{A\\w'
    str_8 = '<N@g'
    str_9 = 'p:\\@'
    str_10 = 'v'
    str_11 = '_m'
    str_12 = ','
    str_13 = 'o'
    str_14 = 'I?~'
    str_15

# Generated at 2022-06-25 12:20:26.914508
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat(['1', '1']) == 2
    assert ansible_native_concat(['1', '1.0']) == '11.0'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat(['1', '1']) == 2

# Generated at 2022-06-25 12:20:32.026246
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert '\\q:d+#7EcfzFg(%' == ansible_native_concat('\\q:d+#7EcfzFg(%')
    assert 'foo' == ansible_native_concat('foo')
    assert 'foo bar' == ansible_native_concat('foo bar')
    assert 'foo bar' == ansible_native_concat('foo bar')
    assert 'foo bar' == ansible_native_concat('foo bar')
    assert 'foo bar' == ansible_native_concat('foo bar')
    assert 'foo bar' == ansible_native_concat('foo bar')
    assert 'foo' == ansible_native_concat('foo')
    assert {'foo': 'bar'} == ansible_native_concat('foo=bar')

# Generated at 2022-06-25 12:20:41.870406
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert type(ansible_native_concat([])) is None
    assert type(ansible_native_concat([1,2,3])) is int
    assert type(ansible_native_concat([1.1,2.2,3.3])) is float
    assert type(ansible_native_concat(['hello', 'world'])) is str
    assert type(ansible_native_concat(['hello', 'world'])) is str
    assert type(ansible_native_concat(['hello', 2, 3])) is str
    assert type(ansible_native_concat([2, 3])) is int
    assert type(ansible_native_concat(['hello'])) is str
    assert type(ansible_native_concat(['hello', 'wor'])) is str
    assert type

# Generated at 2022-06-25 12:20:50.717288
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '\\q:d+#7EcfzFg(%'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == '\\q:d+#7EcfzFg(%'

    str_1 = '*hf)0}$x0#j+.@.w'
    str_2 = 'Hq\\}Q\\r'
    var_1 = ansible_native_concat(chain(str_1, str_2))
    assert var_1 == '*hf)0}$x0#j+.@.wHq\\}Q\\r'

    str_3 = '*hf)0}$x0#j+.@.w'
    str_4 = 'Hq\\}Q\\r'

# Generated at 2022-06-25 12:20:51.868880
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert test_case_0() == "\x7FcfzFg(%"

# Generated at 2022-06-25 12:20:54.558278
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '\\q:d+#7EcfzFg(%'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == '\\q:d+#7EcfzFg(%'



# Generated at 2022-06-25 12:20:58.441292
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '\\q:d+#7EcfzFg(%'
    var_0 = ansible_native_concat(str_0)

    assert var_0 == '\\q:d+#7EcfzFg(%'

# Generated at 2022-06-25 12:21:02.607277
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '\\q:d+#7EcfzFg(%'
    assert container_to_text(ansible_native_concat(str_0)) == '\\q:d u7EcfzFg(%'



# Generated at 2022-06-25 12:21:10.446959
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('1234') == '1234'
    assert ansible_native_concat('0012') == '12'
    assert ansible_native_concat('E0') == 'E0'
    assert ansible_native_concat('') == ''
    assert ansible_native_concat('1') == '1'
    assert ansible_native_concat('1.2') == '1.2'
    assert ansible_native_concat('{}') == '{}'
    assert ansible_native_concat('{}') == '{}'
    assert ansible_native_concat('{a}') == '{a}'
    assert ansible_native_concat('{a,}') == '{a,}'
    assert ansible_native_con

# Generated at 2022-06-25 12:21:16.647716
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Target function:
    #     ansible_native_concat
    # Input:
    str_0 = '\\q:d+#7EcfzFg(%'
    # Expected result:
    str_0_expected = '\q:d+#7EcfzFg(%'
    assert str_0_expected == str_0


# Generated at 2022-06-25 12:21:27.073162
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # We need to test with a non text value to ensure literal_eval is
    # not used. This example is a list with a single str element, so
    # it would be parsable with literal_eval.
    nodes = container_to_text(['foo'])
    assert ansible_native_concat(nodes) == 'foo'

    node = container_to_text('foo')
    # literal_eval can not parse this.
    assert ansible_native_concat(node) == 'foo'

    # StrictUndefined is used by Jinja2 to differentiate with the
    # undefined type used by the Jinja2 sandbox.
    undefined = StrictUndefined()
    with pytest.raises(StrictUndefined):
        ansible_native_concat([undefined])

    # We don't care about the number of elements in

# Generated at 2022-06-25 12:21:35.598455
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Getting the function reference
    function_under_test = ansible_native_concat

    # Testing the type of an if condition (line 35)
    if isinstance(str_0, string_types):
        # Testing the type of an if condition (line 36)
        if not isinstance(str_0, string_types):
            # Getting the type of 'out' (line 36)
            out_0 = type(str_0)
            
            # Call to assertTrue(...): (line 36)
            # Processing the call arguments (line 36)
            # Getting the type of 'out' (line 36)
            out_0 = type(str_0)
            # Processing the call keyword arguments (line 36)
            kwargs_0 = {}
            # Getting the type of 'TestAnsibleNativeTypes' (line 36)
           

# Generated at 2022-06-25 12:21:37.103335
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert isinstance(test_case_0(), text_type)

# Generated at 2022-06-25 12:21:37.638619
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    pass

# Generated at 2022-06-25 12:21:39.130464
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = ansible_native_concat(str_0)
    assert str_0 is not ''

# Generated at 2022-06-25 12:21:42.549497
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert ansible_native_concat('') == None
    assert ansible_native_concat('foo') == 'foo'
    assert ansible_native_concat('foo', 'bar') == 'foobar'



# Generated at 2022-06-25 12:21:52.107222
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test ansible_native_concat function"""
    result = ansible_native_concat()
    assert result is None
    assert result == None
    result = ansible_native_concat("")
    assert result is None
    assert result == None
    result = ansible_native_concat(123)
    assert result is None
    assert result == None
    result = ansible_native_concat(False)
    assert result is None
    assert result == None
    result = ansible_native_concat("")
    assert result is None
    assert result == None
    result = ansible_native_concat([""])
    assert result is None
    assert result == None
    result = ansible_native_concat([])
    assert result is None
    assert result == None
    result = ansible_native_

# Generated at 2022-06-25 12:22:02.269371
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    task_1 = None

    # 1. Test with arguments that should fail with a TypeError
    with pytest.raises(TypeError):
        task_1 = ansible_native_concat(1)


    # Test with arguments that should not fail
    task_2 = ansible_native_concat('a')
    task_3 = ansible_native_concat('')
    task_4 = ansible_native_concat('\t')
    task_5 = ansible_native_concat(-100)
    task_6 = ansible_native_concat(123)
    task_7 = ansible_native_concat('123')
    task_8 = ansible_native_concat({'a': 'b'})

# Generated at 2022-06-25 12:22:11.527335
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '\\q:d+#7EcfzFg(%'
    str_1 = 'foobar'
    str_2 = 'baz'
    str_3 = 'bar'
    var_0 = ansible_native_concat(str_0)
    var_1 = ansible_native_concat([str_1, str_2])
    var_2 = ansible_native_concat([str_1, str_2, str_3])
    # expected output: '\\q:d+#7EcfzFg(%'
    print(var_0)
    # expected output: 'foobarbaz'
    print(var_1)
    # expected output: 'foobarbazbar'
    print(var_2)

# Generated at 2022-06-25 12:22:16.718826
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = str_1 = '\\q:d+#7EcfzFg(%'
    var_0 = var_1 = ansible_native_concat(str_0)


# Generated at 2022-06-25 12:22:19.876596
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    str_0 = '\\q:d+#7EcfzFg(%'

    assert isinstance(ansible_native_concat(str_0), (text_type,))



# Generated at 2022-06-25 12:22:29.085388
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # simple test case
    assert ansible_native_concat([1, 3, 5]) == '135'

    # ensure that the result can be parsed with ast.literal_eval
    assert ansible_native_concat([1, '+', 5]) == 6

    # ast.literal_eval raises ValueError when passed non-literal values
    assert ansible_native_concat(['1', '+', 5]) == '1+5'

    # ensure that the result can be parsed with ast.literal_eval
    assert (
        ansible_native_concat([1, '+', "5"])
        == '1+5'
    )

    # ast.literal_eval raises ValueError when passed non-literal values

# Generated at 2022-06-25 12:22:34.616214
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('\\q:d+#7EcfzFg(%') == '\\q:d+#7EcfzFg(%'



# Generated at 2022-06-25 12:22:36.771939
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()


# Generated at 2022-06-25 12:22:39.451307
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '\\q:d+#7EcfzFg(%'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == str_0

# Generated at 2022-06-25 12:22:42.198356
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '\\q:d+#7EcfzFg(%'
    str_1 = '\\q:d+#7EcfzFg(%'
    result = ansible_native_concat(str_0)
    assert result == str_1



# Generated at 2022-06-25 12:22:45.506392
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '\\q:d+#7EcfzFg(%'
    var_0 = ansible_native_concat(str_0)
    # assert var_0 == ...


# Generated at 2022-06-25 12:22:49.152077
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '\\q:d+#7EcfzFg(%'
    assert container_to_text(ansible_native_concat(str_0)) == u'\\q:d+#7EcfzFg(%'


# Generated at 2022-06-25 12:22:50.428835
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    pass


# Generated at 2022-06-25 12:22:54.339017
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert '\\q:d+#7EcfzFg(%' == ansible_native_concat('\\q:d+#7EcfzFg(%')


# Generated at 2022-06-25 12:23:00.956870
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '\\s}\\e&)K(xR\\oEXd@Dh\\'
    str_1 = '&tFp\\L*1]x(\\o]&g3{'
    str_2 = 'R7,uL0\\0\\2V'
    str_3 = 'A}\\o\\I7Oz1c\\'
    str_4 = 'ai\\Y6U\\jKxW{r\\/K'
    var_0 = ansible_native_concat([str_0, str_1, str_2, str_3, str_4])

# Generated at 2022-06-25 12:23:02.077332
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    pass


# Generated at 2022-06-25 12:23:11.947173
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # For example
    # assert callable(ansible_native_concat)
    assert ansible_native_concat(['f']) == 'f'
    assert ansible_native_concat(['f', 'o', 'o']) == 'foo'
    assert ansible_native_concat(['f', 42, 'o', 'o'], bar=1) == 'foo'
    assert ansible_native_concat(['foo', {'x': 'y'}]) == 'foo{x: y}'
    assert ansible_native_concat(['foo', {'x': 'y'}, 'bar']) == 'foo{x: y}bar'

# Generated at 2022-06-25 12:23:18.315900
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = ansible_native_concat('\\q:d+#7EcfzFg(%')
    str_0 = '\\q:d+#7EcfzFg(%'
    if var_0 != str_0:
        raise Exception('base_concat failed')

    var_1 = ansible_native_concat('\\q:d+#7EcfzFg(%', '\\q:d+#7EcfzFg(%')
    str_1 = '\\q:d+#7EcfzFg(%\\q:d+#7EcfzFg(%'
    if var_1 != str_1:
        raise Exception('base_concat failed')


# Generated at 2022-06-25 12:23:20.279625
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == '\\q:d+#7EcfzFg(%', 'Expectation failed.'

# Generated at 2022-06-25 12:23:28.982330
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ast.literal_eval(ansible_native_concat('\\q:d+#7EcfzFg(%')) == '\\q:d+#7EcfzFg(%'
    assert ast.literal_eval(ansible_native_concat('\\q:d+#7EcfzFg(%')) == '\\q:d+#7EcfzFg(%'
    assert ast.literal_eval(ansible_native_concat(u'\\q:d+#7EcfzFg(%')) == u'\\q:d+#7EcfzFg(%'
    assert ast.literal_eval(ansible_native_concat(text_type(u'\\q:d+#7EcfzFg(%'))) == text_type

# Generated at 2022-06-25 12:23:29.912703
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert var_0 == '\\q:d+#7EcfzFg(%'

# Generated at 2022-06-25 12:23:33.431390
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Define arguments and result
    str_0 = '\\q:d+#7EcfzFg(%'
    result = '\\q:d+#7EcfzFg(%'

    # Call the function
    result = ansible_native_concat(str_0)

    # Evaluate the result
    assert isinstance(result, text_type)
    assert result == result



# Generated at 2022-06-25 12:23:37.241677
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_cases = [
        (0, )
    ]
    for index, test_case in enumerate(test_cases):
        yield run_ansible_native_concat, test_case, index


# Generated at 2022-06-25 12:23:39.678575
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert 'q:d+#7EcfzFg' in var_0



# Generated at 2022-06-25 12:23:44.692476
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    assert ansible_native_concat('foo') == 'foo'
    assert ansible_native_concat('foo' + 'bar') == 'foobar'
    assert ansible_native_concat(u'füü' + 'bar') == u'füübar'
    assert ansible_native_concat(u'füü' + b'bar') == u'füübar'
    assert ansible_native_concat(u'füü' + u'bär') == u'füübär'

    assert ansible_native_concat(123) == 123
    assert ansible_native_concat(123 + 456) == 579

# Generated at 2022-06-25 12:23:47.489871
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert_equals(test_case_0(), "\\q:d+#7EcfzFg(%")

# Generated at 2022-06-25 12:23:50.874908
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    string_list = ['\\q:d+#7EcfzFg(%']
    assert ansible_native_concat(string_list) == '\\q:d+#7EcfzFg(%'

# Generated at 2022-06-25 12:23:58.677249
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # First two tests are examples of the native_concat function from
    # https://github.com/pallets/jinja/blob/master/src/jinja2/tests/test_nativetypes.py
    # which we want to test against in our tests.
    string = ansible_native_concat(['foo', 'bar'])
    assert container_to_text(string) == 'foobar'

    integer = ansible_native_concat(['23', '42'])
    assert integer == 2342

    # Now to test against our fixtures
    assert ansible_native_concat(test_case_0()) == '\\q:d+#7EcfzFg(%'

    # These tests are considered bad practice, as they are not robust enough
    # to pass in different values
    assert ansible_native_con

# Generated at 2022-06-25 12:24:09.786529
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    arg_0 = '\\q:d+#7EcfzFg(%'
    arg_1 = '\\q:d+#7EcfzFg(%'
    arg_2 = '\\q:d+#7EcfzFg(%'
    arg_3 = '\\q:d+#7EcfzFg(%'
    arg_4 = '\\q:d+#7EcfzFg(%'
    arg_5 = '\\q:d+#7EcfzFg(%'
    arg_6 = '\\q:d+#7EcfzFg(%'
    arg_7 = '\\q:d+#7EcfzFg(%'
    arg_8 = '\\q:d+#7EcfzFg(%'
   

# Generated at 2022-06-25 12:24:19.032152
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '\\q:d+#7EcfzFg(%'
    var_0 = ansible_native_concat(str_0)
    assert str_0 == var_0

    str_0 = '\\q:d+#7EcfzFg(%'
    str_1 = '\\q:d+#7EcfzFg(%'
    var_0 = ansible_native_concat([str_0, str_1])
    assert var_0 == '\\q:d+#7EcfzFg(%\\q:d+#7EcfzFg(%'
    assert isinstance(var_0, string_types)

    str_0 = '\\q:d+#7EcfzFg(%'
    int_0 = 1234
    var

# Generated at 2022-06-25 12:24:23.595103
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '\\q:d+#7EcfzFg(%'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == '\\q:d+#7EcfzFg(%', "ansible_native_concat does not return the expected value"


# Generated at 2022-06-25 12:24:24.416241
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()

# Generated at 2022-06-25 12:24:27.922118
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '\\q:d+#7EcfzFg(%'
    var_0 = ansible_native_concat(str_0)
    var_1 = ansible_native_concat(var_0)
    assert var_1 == '\\q:d+#7EcfzFg(%'

# Generated at 2022-06-25 12:24:31.739124
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == '\\q:d+#7EcfzFg(%'

# Generated at 2022-06-25 12:24:32.666088
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert id(test_case_0)

# Generated at 2022-06-25 12:24:37.536480
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '\\q:d+#7EcfzFg(%'
    var_0 = ansible_native_concat(str_0)
    # assert var_0 == expected_value, \
    #     'Expected: {}, Actual: {}'.format(expected_value, var_0)

# vim: set filetype=python set foldmethod=marker commentstring=\ #\ %s :

# Generated at 2022-06-25 12:24:44.490881
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Replace this with the code you need to test.
    assert(ansible_native_concat('\\q:d+#7EcfzFg(%') == '\\q:d+#7EcfzFg(%')
    assert(ansible_native_concat('8W') == '8W')
    assert(ansible_native_concat('5OI_e1') == '5OI_e1')
    assert(ansible_native_concat('4)SC.#') == '4)SC.#')
    assert(ansible_native_concat(',;^l') == ',;^l')
    # assert(ansible_native_concat('Szk') == 'Szk')
    # assert(ansible_native_concat('iF') == 'iF')
    # assert

# Generated at 2022-06-25 12:24:46.096086
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '\\q:d+#7EcfzFg(%'
    var_0 = ansible_native_concat(str_0)

# Generated at 2022-06-25 12:24:48.119424
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '\\q:d+#7EcfzFg(%'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == '\\q:d+#7EcfzFg(%'


# Generated at 2022-06-25 12:24:52.734561
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '\\q:d+#7EcfzFg(%'
    assert container_to_text(ansible_native_concat(str_0)) == '\\q:d+#7EcfzFg(%'
    list_0 = [
        '\\q:d+#7EcfzFg(%',
        '\\q:d+#7EcfzFg(%',
    ]
    assert container_to_text(ansible_native_concat(list_0)) == '\\\\q:d+#7EcfzFg(%\\\\q:d+#7EcfzFg(%'
    dict_0 = {
        'item': '\\q:d+#7EcfzFg(%',
    }

# Generated at 2022-06-25 12:24:53.280670
# Unit test for function ansible_native_concat

# Generated at 2022-06-25 12:24:56.667281
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert True == False, "Test not implemented"

## Unit test for function ansible_safe_yaml_dump
#def test_ansible_safe_yaml_dump():
#    assert True == False, "Test not implemented"


# Generated at 2022-06-25 12:25:01.612371
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    input_data = '\\q:d+#7EcfzFg(%'
    output_data = ansible_native_concat(input_data)
    expected_data = "\\q:d+#7EcfzFg(%"
    assert output_data == expected_data, 'output_data = {}, expected_data = {}'.format(output_data, expected_data)


# Generated at 2022-06-25 12:25:11.293076
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'qm^M@yJHeVX'
    str_1 = 'gw*'
    str_2 = '\\'
    str_3 = '\\*'
    str_4 = '*'
    str_5 = '?'
    str_6 = '?*'
    str_7 = ';'
    str_8 = '%'
    str_9 = '%'
    str_10 = '*'
    str_11 = '\\'
    str_12 = '*'
    str_13 = '?*'
    str_14 = '\\'
    str_15 = '\\*'
    str_16 = '*'
    str_17 = '\\\\'
    str_18 = '\\*'
    str_19 = '?"?*'
    str

# Generated at 2022-06-25 12:25:18.999382
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Check for invalid data type"""
    try:
        str_0 = '\\q:d+#7EcfzFg(%'
        var_0 = ansible_native_concat(str_0)
    except Exception as err:
        print('Exception raise for "list" data type: '+str(err))

    """Check for missing parameter"""
    try:
        var_0 = ansible_native_concat()
    except Exception as err:
        print('Exception raise for "missing parameter": '+str(err))

    """Check for presence of extra parameters"""

# Generated at 2022-06-25 12:25:24.330837
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'x'
    str_1 = 'y'
    var_0 = ansible_native_concat(str_0)
    var_1 = ansible_native_concat(str_1)

    # Tests:
    assert var_0 == 'x', "ansible_native_concat returned incorrect results."
    assert var_1 == 'y', "ansible_native_concat returned incorrect results."


# Generated at 2022-06-25 12:25:25.717435
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Assertions
    assert (test_case_0()) is None

# Generated at 2022-06-25 12:25:33.292528
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '\\q:d+#7EcfzFg(%'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == '\\q:d+#7EcfzFg(%'

# Generated at 2022-06-25 12:25:34.516974
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert(ansible_native_concat(None) == None)

# Generated at 2022-06-25 12:25:35.717930
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert var_0 == 'q:d+#7EcfzFg(%'

# Generated at 2022-06-25 12:25:38.279006
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert to_text(ansible_native_concat) == 'ansible_native_concat'



# Generated at 2022-06-25 12:25:38.645029
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert True

# Generated at 2022-06-25 12:25:39.788974
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert to_text(test_case_0) == '\\q:d+#7EcfzFg(%'



# Generated at 2022-06-25 12:25:44.748045
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert callable(ansible_native_concat)
    assert native_concat(["ansible"]) == "ansible","If your machine doesn't support unicode, this test may fail"

# Assume that if the content is not a string, the concat function will return the same object.

# Generated at 2022-06-25 12:25:45.889152
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert False, "Test not implemented"

# vim: ansible-parser

# Generated at 2022-06-25 12:25:48.204532
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = '\\q:d+#7EcfzFg(%'
    assert isinstance(var_0, string_types), "Value is not a string type: %r" % var_0



# Generated at 2022-06-25 12:25:50.863807
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    for var_name, var_value in globals().copy().items():
        if var_name.startswith('str_') and isinstance(var_value, str):
            print('%s = %s' % (var_name, repr(var_value)))
            test_case_0(var_value)
            print()



# Generated at 2022-06-25 12:25:56.672755
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '\\q:d+#7EcfzFg(%'
    var_0 = ansible_native_concat(str_0)
    # assert var_0 == '\\q:d+#7EcfzFg(%'
    assert container_to_text(var_0) == '\\q:d+#7EcfzFg(%'

    str_1 = '&\\"9V8W\\"+Ovw/'
    var_1 = ansible_native_concat(str_1)
    # assert var_1 == '&\\"9V8W\\"+Ovw/'
    assert container_to_text(var_1) == '&\\"9V8W\\"+Ovw/'


# Generated at 2022-06-25 12:26:06.752726
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '\\q:d+#7EcfzFg(%'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == '\\q:d+#7EcfzFg(%'
    str_1 = '1'
    var_1 = ansible_native_concat(str_1)
    assert var_1 == 1
    str_2 = 'false'
    var_2 = ansible_native_concat(str_2)
    assert var_2 == 'false'
    str_3 = ""
    var_3 = ansible_native_concat(str_3)
    assert var_3 == ""

# Generated at 2022-06-25 12:26:09.050578
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert type(ansible_native_concat(container_to_text([1, 2, 3]))) == text_type

# Generated at 2022-06-25 12:26:15.643810
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # use python -m pytest tests/test_module_utils.py to run this test

    str_0 = '11, False'
    str_1 = '11, True'
    str_2 = ''

    var_0 = ansible_native_concat(str_0)
    #from debug_brk import debug_breakpoint as brk
    #brk()
    assert var_0 == (11, False)

    var_1 = ansible_native_concat(str_1)
    assert var_1 == (11, True)

    var_2 = ansible_native_concat(str_2)
    assert var_2 == None

# Generated at 2022-06-25 12:26:21.196194
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '\\q:d+#7EcfzFg(%'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == '\\q:d+#7EcfzFg(%'

    str_1 = container_to_text(['\\q:d+#7EcfzFg(%'])
    var_1 = ansible_native_concat(str_1)
    assert var_1 == '\\q:d+#7EcfzFg(%'

    str_2 = 'a str'
    var_2 = ansible_native_concat(str_2)
    assert var_2 == 'a str'

    str_3 = u'test <test>\xf0'
    var_3 = ansible_native_con

# Generated at 2022-06-25 12:26:23.725994
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '\\q:d+#7EcfzFg(%'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == str_0

# Generated at 2022-06-25 12:26:30.790114
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test case 0
    str_0 = '\\q:d+#7EcfzFg(%'
    var_0 = ansible_native_concat(str_0)
    assert container_to_text(var_0) == '\\q:d+#7EcfzFg(%'



# Generated at 2022-06-25 12:26:34.959738
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    '''
    Ansible native concat unit test
    '''

    var_1 = '\\q:d+#7EcfzFg(%'
    var_1_1 = container_to_text(var_1)
    var_2 = ansible_native_concat(var_1_1)
    assert var_2 == '\\q:d+#7EcfzFg(%'

# Generated at 2022-06-25 12:26:35.983000
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert callable(ansible_native_concat)


# Generated at 2022-06-25 12:26:45.335453
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    strlist = ['a', 'b', 'c']
    assert ansible_native_concat(strlist) == 'abc'

    intlist = [1, 2, 3]
    assert ansible_native_concat(intlist) == [1, 2, 3]

    dict_list = [{'a': 1}, {'b': 2}, {'c': 3}]
    assert ansible_native_concat(dict_list) == [{'a': 1}, {'b': 2}, {'c': 3}]

    var_0 = 'a'
    var_1 = 'b'
    var_2 = 'c'
    var_3 = ansible_native_concat((var_0, var_1, var_2))
    assert var_3 == 'abc'

    str_0 = 'abc'

# Generated at 2022-06-25 12:26:47.837038
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('\\q:d+#7EcfzFg(%') == '\\q:d+#7EcfzFg(%'

# Generated at 2022-06-25 12:26:49.480397
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert type(ansible_native_concat('\\q:d+#7EcfzFg(%')) is str

# Generated at 2022-06-25 12:26:51.458297
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    try:
        test_case_0()
    except Exception as e:
        print('Exception: \n{}\n'.format(e))
        raise
    


# Generated at 2022-06-25 12:26:55.243455
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_cases = [
        {
            'data': '\\q:d+#7EcfzFg(%',
            'expected_result': "\\q:d+#7EcfzFg(%"
        }
    ]

    for test_case in test_cases:
        data = test_case['data']
        expected_result = test_case['expected_result']

        result = ansible_native_concat(data)

        if is_sequence(result):
            result = container_to_text(result)

        assert result == expected_result



# Generated at 2022-06-25 12:26:56.867418
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    res = ansible_native_concat()
    assert res is None

# Unit test with no exception

# Generated at 2022-06-25 12:26:59.462859
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert to_text(test_case_0()) == '\\q:d+#7EcfzFg(%'

# Generated at 2022-06-25 12:27:03.217672
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert isinstance(ansible_native_concat(str_0), string_types) is True


# Generated at 2022-06-25 12:27:11.158837
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '\\q:d+#7EcfzFg(%'
    var_0 = ansible_native_concat(str_0)
    str_1 = '\\q:d+#7EcfzFg(%'
    var_1 = ansible_native_concat(str_1)
    str_2 = '\\q:d+#7EcfzFg(%'
    var_2 = ansible_native_concat(str_2)
    str_3 = '\\q:d+#7EcfzFg(%'
    var_3 = ansible_native_concat(str_3)
    str_4 = '\\q:d+#7EcfzFg(%'
    var_4 = ansible_native_concat(str_4)

# Generated at 2022-06-25 12:27:20.433921
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = '^'
    func_0 = ansible_native_concat(var_0)
    assert func_0 == '^'
    var_1 = 'b'
    func_1 = ansible_native_concat(var_1)
    assert func_1 == 'b'
    var_2 = '\\'
    func_2 = ansible_native_concat(var_2)
    assert func_2 == '\\'
    var_3 = '\x04'
    func_3 = ansible_native_concat(var_3)
    assert func_3 == '\x04'
    var_4 = '\x02'
    func_4 = ansible_native_concat(var_4)
    assert func_4 == '\x02'

# Generated at 2022-06-25 12:27:29.669017
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    text = """
    This is a text string
    with two lines
    """
    assert ansible_native_concat('string') == 'string'
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert isinstance(ansible_native_concat('[1, 2, 3]'), string_types)
    assert ansible_native_concat('[1, 2, 3]') == '[1, 2, 3]'
    assert ansible_native_concat('True') is True
    assert ansible_native_concat('False') is False
    assert ansible_native_concat('None') is None
    assert ansible_native_concat("'{0}'".format(text)) == text

# Generated at 2022-06-25 12:27:30.442534
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()

# Generated at 2022-06-25 12:27:32.446700
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '\\q:d+#7EcfzFg(%'
    var_0 = ansible_native_concat(str_0)

test_ansible_native_concat()

# Generated at 2022-06-25 12:27:43.002195
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '| string'
    var_1 = ansible_native_concat(str_0)
    assert var_1 == '| string'

    str_1 = 'Hello world!\n'
    var_2 = ansible_native_concat(str_1)
    assert var_2 == 'Hello world!\n'

    str_2 = 'https://hello_world.com'
    var_3 = ansible_native_concat(str_2)
    assert var_3 == 'https://hello_world.com'

    str_3 = 'https://github.com/ansible/ansible/issues/70831'
    var_4 = ansible_native_concat(str_3)
    assert var_4 == 'https://github.com/ansible/ansible/issues/70831'

# Generated at 2022-06-25 12:27:52.133125
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '\\q:d+#7EcfzFg(%'
    var_0 = ansible_native_concat(str_0)
    if var_0 != "\\q:d+#7EcfzFg(%":
        raise AssertionError("mismatch on expected, got {0} expected {1}".format(var_0, "\\q:d+#7EcfzFg(%"))

    str_1 = 'q3\\q:d+#7EcfzFg(%'
    var_1 = ansible_native_concat(str_1)

# Generated at 2022-06-25 12:27:52.971567
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert var_0 != str_0


# Generated at 2022-06-25 12:27:54.315278
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    with pytest.raises(ParseError):
        test_case_0()

# Generated at 2022-06-25 12:28:01.537010
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test function with a single argument
    str_0 = '\\q:d+#7EcfzFg(%'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == "\\q:d+#7EcfzFg(%"

    # Test function with a multiple arguments
    str_0 = '\\q:d+#7EcfzFg(%'
    var_0 = ansible_native_concat(str_0, "second argument")
    assert var_0 == '\\q:d+#7EcfzFg(%second argument'

    # Test function with list of list
    var_0 = ansible_native_concat([[1, 2], ["a", "b"]])

# Generated at 2022-06-25 12:28:02.389476
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert True

# Generated at 2022-06-25 12:28:11.186461
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert list(islice(range(1, 6), 2)) == [1, 2]
    assert ansible_native_concat(('3', '3', '3', '3', '3')) == '3'
    assert ansible_native_concat(('3', '3', '3', '3', '3')) == 3
    assert ansible_native_concat(('3', '3', '3', '3', '3')) == '3'
    assert ansible_native_concat(('3', '3', '3', '3', '3')) == 3
    assert ansible_native_concat(('3', '3', '3', '3', '3')) == '3'
    assert ansible_native_concat(('3', '3', '3', '3', '3'))

# Generated at 2022-06-25 12:28:13.919168
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    print('var_0: ' + var_0)
    assert (var_0 == '\\q:d+#7EcfzFg(%')


# Generated at 2022-06-25 12:28:17.361728
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    print("START - test_ansible_native_concat")
    test_case_0()
    print("END - test_ansible_native_concat")

if __name__ == '__main__':
    test_ansible_native_concat()

# Generated at 2022-06-25 12:28:25.639300
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(container_to_text([{'foo': 'bar'}, {'bar': 'baz'}])) == [{'foo': 'bar'}, {'bar': 'baz'}]
    assert ansible_native_concat(container_to_text('oJBq6ycQi')) == 'oJBq6ycQi'
    assert ansible_native_concat(container_to_text([{'foo': 'bar'}, {'bar': 'baz'}])) == [{'foo': 'bar'}, {'bar': 'baz'}]
    assert ansible_native_concat(container_to_text([{'foo': 'bar'}])) == [{'foo': 'bar'}]

# Generated at 2022-06-25 12:28:26.249295
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert True



# Generated at 2022-06-25 12:28:35.337020
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '\\q:d+#7EcfzFg(%'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == '\\q:d+#7EcfzFg(%'
    str_1 = 'N8De:W;Gv[-5pFZB'
    var_1 = ansible_native_concat(str_1)
    assert var_1 == 'N8De:W;Gv[-5pFZB'
    str_2 = ':W;Gv[-5pFZBN8De'
    var_2 = ansible_native_concat(str_2)
    assert var_2 == ':W;Gv[-5pFZBN8De'

# Generated at 2022-06-25 12:28:45.852191
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_1 = '#s=(B_Y'
    var_1 = ansible_native_concat(str_1)
    assert var_1 == '#s=(B_Y'

    str_2 = '"Jn<G)%'
    var_2 = ansible_native_concat(str_2)
    assert var_2 == '"Jn<G)%'

    str_3 = 'UP5h5}f>G'
    var_3 = ansible_native_concat(str_3)
    assert var_3 == 'UP5h5}f>G'

    str_4 = '$*'
    var_4 = ansible_native_concat(str_4)
    assert var_4 == '$*'

    str_5 = '{T@Q}C'

# Generated at 2022-06-25 12:28:55.161780
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Testing result of Single-Quoted String Literal
    # with embedded newline - \"Cisco
    # IOS\"\"\"
    assert (ansible_native_concat('\nCisco\nIOS\n') == '\nCisco\nIOS\n')
    # Testing result of Single-Quoted String Literal
    # with embedded newline - \"Cisco
    # IOS\"\"\"
    assert (ansible_native_concat('\rCisco\rIOS\r') == '\rCisco\rIOS\r')
    # Testing result of Single-Quoted String Literal
    # with embedded newline - \"Cisco
    # IOS\"\"\"

# Generated at 2022-06-25 12:29:08.282205
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = '\\q:d+#7EcfzFg(%'
    var_1 = ansible_native_concat(var_0)
    assert var_1 == '\\q:d+#7EcfzFg(%'
    var_2 = '<|*Z>'
    var_3 = ansible_native_concat(var_2)
    assert var_3 == '<|*Z>'
    var_4 = 'c%1t(C/'
    var_5 = ansible_native_concat(var_4)
    assert var_5 == 'c%1t(C/'
    var_6 = '$(Y*L!-'
    var_7 = ansible_native_concat(var_6)

# Generated at 2022-06-25 12:29:10.848341
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '\\q:d+#7EcfzFg(%'
    var_0 = ansible_native_concat(str_0)
    expected = '\\q:d+#7EcfzFg(%'
    assert var_0 == expected
