

# Generated at 2022-06-25 12:19:23.540857
# Unit test for function ansible_native_concat

# Generated at 2022-06-25 12:19:31.466238
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    li = [1.0, 1.0, 1.0, 'a', 0.0]
    assert ansible_native_concat(li) == [1.0, 1.0, 1.0, 'a', 0.0]

    assert ansible_native_concat([1.0, 1.0, 1.0, 'a', 0.0]) == [1.0, 1.0, 1.0, 'a', 0.0]

    assert ansible_native_concat(1.0) == 1.0

    assert ansible_native_concat(1.0) == 1.0


# Generated at 2022-06-25 12:19:32.414391
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == -280.615

# Generated at 2022-06-25 12:19:43.494185
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    float_0 = -280.615
    var_0 = ansible_native_concat(float_0)
    if var_0 != -280.615:
        raise AssertionError('unexpected result, got {}'.format(var_0))
    int_0 = -2147483648
    var_1 = ansible_native_concat(int_0)
    if var_1 != -2147483648:
        raise AssertionError('unexpected result, got {}'.format(var_1))
    str_0 = u'foo'
    var_2 = ansible_native_concat(str_0)
    if var_2 != u'foo':
        raise AssertionError('unexpected result, got {}'.format(var_2))
    str_1 = u'bar'
    var_

# Generated at 2022-06-25 12:19:54.881909
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Generator defined in nativetypes.py
    # def concat():
    #     yield 1
    #     yield 2
    #     yield 3

    # assert ansible_native_concat(concat()) == 123
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat([1, 2, '+', 3]) == "+"
    assert ansible_native_concat([1, 2, '+', 3, 4]) == "+"
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['"foo"']) == '"foo"'
    assert ansible_native_concat(['"foo', '"bar"']) == '"foo"bar"'

# Generated at 2022-06-25 12:20:02.386174
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert to_text(ansible_native_concat('some_key')) == 'some_key'
    assert 'type' in ansible_native_concat({'some_key': 'some_value'})
    assert not ansible_native_concat(['some_key', 'some_value'])
    assert 'some_key' in ansible_native_concat(['some_key', {}])
    assert isinstance(ansible_native_concat(['some_key', {'some_key': 'some_value'}]), dict)
    assert ansible_native_concat({'some_key': 'some_value'})[0] == 'some_key'
    assert isinstance(ansible_native_concat({'some_key': 'some_value'}), dict)
    assert ansible_native_

# Generated at 2022-06-25 12:20:13.349009
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Passes the variable which should be a number to the ansible_native_concat()
    # function, if the result is not equal to the original variable then return
    # an error
    def test_ansible_native_concat_valid(var):
        value = ansible_native_concat(var)
        if value != var:
            return "Error: " + str(var)

    # Passes the variable which should be a string to the ansible_native_concat()
    # function, if the result is not a string then return an error
    def test_ansible_native_concat_invalid(var):
        value = ansible_native_concat(var)
        if isinstance(value, string_types):
            return "Error: " + str(var)

    # Attempt to pass a number to the ansible

# Generated at 2022-06-25 12:20:14.286750
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == -280.615

# Generated at 2022-06-25 12:20:22.546892
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    float_0 = -280.615
    var_0 = ansible_native_concat(float_0)
    assert var_0 == -280.615
    var_1 = ansible_native_concat(var_0)
    assert var_1 == -280.615
    float_1 = -280.615
    float_2 = float_1
    var_2 = -280.615
    assert var_2 == float_2
    str_0 = ansible_native_concat("abc")
    str_1 = "abc"
    str_2 = str_1
    assert str_0 == str_2
    list_0 = ["abc"]
    list_1 = list_0
    assert type(list_1) is list
    list_2 = ansible_native_concat(list_0)
   

# Generated at 2022-06-25 12:20:23.927321
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert text_type(test_case_0()) == container_to_text(-280.615)

# Generated at 2022-06-25 12:20:28.326880
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Test case 0
    try:
        ansible_native_concat(str_0)
    except Exception as e:
        print("Test case 0 failed.")
        print(e.args)


# Generated at 2022-06-25 12:20:29.890252
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(test_case_0()) == str_0

# these should all be string types (no eval() based conversion)

# Generated at 2022-06-25 12:20:41.007252
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Scenario #1
    # unit case 1

    str_0 = 'Error: '
    str_1 = 'message'
    str_2 = ''
    str_3 = 'module_stdout'
    str_4 = ''
    str_5 = 'result'
    str_6 = 'failed'
    str_7 = 'stdout'
    str_8 = ''
    str_9 = 'msg'
    str_10 = ''
    str_11 = 'module_stderr'
    str_12 = 'BECOME-SUCCESS-dvvmoteejcxjxmhuyudhwcwhfvuscwa'
    str_13 = 'module_stdout'
    str_14 = 'module_stderr'

# Generated at 2022-06-25 12:20:42.876227
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # This test should fail, since this is a test of an error message.
    assert ansible_native_concat(str_0) == 'Error: '

# Generated at 2022-06-25 12:20:45.269691
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(str_0) == 'Error: '


# Generated at 2022-06-25 12:20:50.103260
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'Unable to find the requested server, '
    str_1 = '"'
    str_2 = 'tomcat'
    str_3 = '". Please check cloud provider documentation and try again.'
    with open("test_data/test_jinja_undefined.txt", "r") as fd:
        test_data = fd.read()
    assert ansible_native_concat([str_0, str_1, str_2, str_3]) == test_data

# Generated at 2022-06-25 12:20:51.083553
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(test_case_0) == test_case_0

# Generated at 2022-06-25 12:20:52.148033
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    f = ansible_native_concat()
    return f

# Generated at 2022-06-25 12:20:56.100825
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'Error: '
    # Testing function ansible_native_concat, with the following parameters:
    #     nodes: [str_0]
    # Expected result: str_0

    assert ansible_native_concat([str_0]) == str_0


# Generated at 2022-06-25 12:21:06.590472
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'Error: '
    str_1 = 'Must pass a string to string.split()'
    str_2 = 'Error: '
    str_3 = 'int is not callable'
    str_4 = 'Error: '
    str_5 = 'int is not iterable'
    str_6 = 'Error: '
    str_7 = 'int is not JSON serializable'
    str_8 = 'Error: '
    str_9 = 'int is not a valid key'
    str_10 = 'Error: '
    str_11 = 'int is not subscriptable'
    str_12 = 'Error: '
    str_13 = 'int is not subscriptable'
    str_14 = 'Error: '
    str_15 = 'int is undefined'
    str_16 = 'Error: '
   

# Generated at 2022-06-25 12:21:12.377115
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    out_1 = ansible_native_concat(str_0)
    assert out_1 == str_0


# Generated at 2022-06-25 12:21:16.869066
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert isinstance(test_case_0(), string_types)
    assert ansible_native_concat([test_case_0()]) == 'Error: '

# Generated at 2022-06-25 12:21:19.191661
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    out = ansible_native_concat(str_0)
    assert out == {"results": [{"msg": "Abc Fdfg Gfh"}]}


# Generated at 2022-06-25 12:21:20.435628
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(str_0) == 'Error: '

# Generated at 2022-06-25 12:21:31.024947
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ..common.yaml import YAMLCompiler
    from ..common.codegen import Generator
    from ..common.templatetypes import ASTExtension

    # Create a jinja2 compiler to test on
    yaml_compiler = YAMLCompiler()
    yaml_compiler.environment.tests['ansible_native_concat'] = ansible_native_concat

    # Test to ensure that the ansible_native_concat funciton works
    # as expected.

# Generated at 2022-06-25 12:21:32.813056
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert not ansible_native_concat(test_case_0)
    assert ansible_native_concat(str_0) == 'Error: '

# Generated at 2022-06-25 12:21:40.267833
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # If a single node is passed, it should be returned.
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([b'foo']) == b'foo'

    # If multiple nodes are passed, they should be returned as a list.
    assert ansible_native_concat([1, 2]) == '1 2'
    assert ansible_native_concat([1, 'foo']) == '1 foo'
    assert ansible_native_concat(['foo', 1]) == 'foo 1'
    assert ansible_native_concat(['foo', 1, 'bar']) == 'foo 1 bar'

    # If the result can be parsed with ast.literal_eval, the parsed value
    # should

# Generated at 2022-06-25 12:21:50.657609
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    '''
    Test function for ansible_native_concat
    '''
    str_0 = 'Error: '
    str_1 = 'Incorrect username or password'
    str_2 = 'Error: '
    str_3 = 'Incorrect username or password'
    str_4 = 'Error: '
    str_5 = 'Incorrect username or password'
    str_6 = 'Error: '
    str_7 = 'Incorrect username or password'
    str_8 = 'Error: '
    str_9 = 'Incorrect username or password'
    str_10 = 'Error: '
    str_11 = 'Incorrect username or password'
    str_12 = 'Error: '
    str_13 = 'Incorrect username or password'
    str_14 = 'Error: '

# Generated at 2022-06-25 12:21:52.003125
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(str_0) == 'Error: '


# Generated at 2022-06-25 12:22:02.222782
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    setattr(str_0, 'as_safe_str', str_0)
    setattr(str_0, '__html__', str_0)
    setattr(str_0, '__str__', str_0)
    setattr(str_0, '__add__', str_0)
    setattr(str_0, '__mod__', str_0)
    setattr(str_0, '__mul__', str_0)
    setattr(str_0, '__radd__', str_0)
    setattr(str_0, '__rmod__', str_0)
    setattr(str_0, '__rmul__', str_0)
    setattr(str_0, '__div__', str_0)

# Generated at 2022-06-25 12:22:10.802392
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test function for function ansible_native_concat"""

    try:
        str_0 = to_text(test_case_0(nodes))
        msg = 'Expected: {}, Actual: {}'.format(str_0, out)
        assert str_0 == out, msg
    except AssertionError as e:
        print(e)
        status = False

    return status


# Generated at 2022-06-25 12:22:14.115775
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'Error: '
    str_1 = ': '
    str_2 = 'unexpected parameter'
    assert ansible_native_concat([str_0, str_1, str_2]) == 'Error: : unexpected parameter'

# Generated at 2022-06-25 12:22:14.902338
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()



# Generated at 2022-06-25 12:22:20.232373
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert 'this is a simple string' == ansible_native_concat([ 'this',  ' is a ',  'simple ',  'string' ])
    assert 'this 1 + 2 = 3' == ansible_native_concat([ 'this ',  '1 + 2 = ',  '3' ])

# Generated at 2022-06-25 12:22:21.232505
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert False



# Generated at 2022-06-25 12:22:22.550866
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['Error: ']) == 'Error: '

# Generated at 2022-06-25 12:22:31.151930
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # simple string values
    assert ansible_native_concat([NativeJinjaText(u"foobar"), u"bar"]) == "foobarbar", ("simple string values")

    # non-string values remain unchanged
    assert ansible_native_concat([123, 456]) == 123, ("non-string values remain unchanged")
    assert ansible_native_concat([True]) == True, ("non-string values remain unchanged")

    # literal evaluation
    assert ansible_native_concat([u"1"]) == 1, ("literal evaluation")
    assert ansible_native_concat([u"[1, 2, 3]"]) == [1, 2, 3], ("literal evaluation")

# Generated at 2022-06-25 12:22:33.902242
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    expected_result = [['Error: ']]
    ansible_native_concat(test_case_0())
    actual_result = container_to_text(ansible_native_concat(test_case_0()))
    assert expected_result == actual_result

# Generated at 2022-06-25 12:22:41.519200
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Function ansible_native_concat was called with args
    # (u'Error: ', ansible.vars.hostvars.HostVarsVars object)
    str_1 = 'Error: '
    obj_2 = HostVarsVars()

# Generated at 2022-06-25 12:22:47.048177
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    str_0 = 'Error: '
    str_1 = 'some error message'
    str_2 = 'Error: ' + 'some error message'
    if isinstance(str_1, string_types):
        str_1 = str(str_1)
    else:
        str_1 = container_to_text(str_1, options=ast.literal_eval('{}'), format='string')
    if isinstance(str_0, string_types):
        str_0 = str(str_0)
    else:
        str_0 = container_to_text(str_0, options=ast.literal_eval('{}'), format='string')
    if isinstance(str_0, AnsibleVaultEncryptedUnicode):
        str_0 = str_0.data

# Generated at 2022-06-25 12:22:59.854347
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # TODO test for a case when the result of ansible_native_concat is a dict/list/tuple

    # Test empty string
    str_0 = ''
    var_0 = ansible_native_concat(str_0)
    assert to_text(var_0) == '', "ansible_native_concat's result is incorrect"

    # Test an integer
    str_0 = '<9np\nozN~'
    var_0 = ansible_native_concat(str_0)
    assert to_text(var_0) == '-', "ansible_native_concat's result is incorrect"

    # Test a boolean
    str_0 = '<9np\nozN~'
    var_0 = ansible_native_concat(str_0)
    assert to_text

# Generated at 2022-06-25 12:23:02.341070
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['<9np\nozN~']) == '<9np\nozN~'

# Generated at 2022-06-25 12:23:04.975400
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = ansible_native_concat(str_0)
    assert var_0 == b'<9np\nozN~'

# Generated at 2022-06-25 12:23:06.773419
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert text_type(test_case_0()) == text_type(container_to_text(str_0))

# Generated at 2022-06-25 12:23:08.305515
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test for the case where we pass a string
    test_case_0()



# Generated at 2022-06-25 12:23:20.577544
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert '{"a": 1, "b": 2}' == container_to_text(ansible_native_concat(u'{"a": 1, "b": 2}'))
    assert '{"a": 1, "b": 2}' == container_to_text(ansible_native_concat(['{"a": 1, "b": 2}']))
    assert '{"a": 1, "b": 2}' == container_to_text(ansible_native_concat('{"a": 1, "b": 2}'))
    assert '{"a": 1, "b": 2}' == container_to_text(ansible_native_concat(['{"a": 1, "b": 2}']))

# Generated at 2022-06-25 12:23:22.193407
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    try:
        test_case_0()
    except SystemExit:
        pass


# Generated at 2022-06-25 12:23:23.089088
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test case 0
    test_case_0()

# Generated at 2022-06-25 12:23:24.002810
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert type(test_case_0()) == str

# Generated at 2022-06-25 12:23:32.042879
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '<9np\nozN~'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == '<9np\nozN~'
    var_1 = ansible_native_concat(to_text(str_0))
    assert var_1 == '<9np\nozN~'
    str_1 = '{{ var }}'
    var_2 = ansible_native_concat(str_1)
    assert var_2 == '{{ var }}'
    var_3 = ansible_native_concat(to_text(str_1))
    assert var_3 == '{{ var }}'
    dict_0 = {'var_4': 'value'}
    var_4 = ansible_native_concat(dict_0)


# Generated at 2022-06-25 12:23:38.328351
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    try:
        test_case_0()
    except Exception:
        print("Exception in Test Case")
test_ansible_native_concat()

# Generated at 2022-06-25 12:23:40.257198
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '<9np\nozN~'
    var_0 = ansible_native_concat(str_0)
    print(container_to_text(var_0))



# Generated at 2022-06-25 12:23:43.197987
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    result = container_to_text(ansible_native_concat(test_case_0)) + "\r\n"
    assert result == "9np\nozN~\r\n"



# Generated at 2022-06-25 12:23:47.427159
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '<9np\nozN~'
    var_0 = ansible_native_concat(str_0)
    var_1 = container_to_text(var_0)
    assert(var_1 == '<9np\nozN~')

# Generated at 2022-06-25 12:23:56.766671
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'V7Zk0'
    var_0 = ansible_native_concat(str_0)
    str_1 = 'J7Vu}'
    var_1 = ansible_native_concat(str_1)
    str_2 = '=d {/'
    var_2 = ansible_native_concat(str_2)
    str_3 = 'J}_+8'
    var_3 = ansible_native_concat(str_3)
    str_4 = 'L$~2W'
    var_4 = ansible_native_concat(str_4)
    str_5 = 'CxT.{'
    var_5 = ansible_native_concat(str_5)
    str_6 = '8t/y]'
    var

# Generated at 2022-06-25 12:24:07.517145
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '<9np\nozN~'
    var_0 = str_0
    var_1 = ansible_native_concat(var_0)
    assert var_1 == var_0

    str_0 = 'fGYCwK4s<'
    var_0 = str_0
    var_1 = ansible_native_concat(var_0)
    assert var_1 == var_0

    var_0 = ""
    var_1 = ansible_native_concat(var_0)
    assert var_1 == var_0

    var_0 = ""
    var_1 = ansible_native_concat(var_0)
    assert isinstance(var_1, string_types)

    var_0 = "/+LQN=Y$"
    var_1

# Generated at 2022-06-25 12:24:08.404159
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # TODO: implement this
    return True

# Generated at 2022-06-25 12:24:09.555182
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var = ansible_native_concat()
    assert not var



# Generated at 2022-06-25 12:24:18.789562
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '<9np\nozN~'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == '<9np\nozN~'
    str_1 = '\x01\x02'
    var_1 = ansible_native_concat(str_1)
    assert var_1 == '\x01\x02'
    str_2 = '\x00\x01\x02'
    var_2 = ansible_native_concat(str_2)
    assert var_2 == '\x00\x01\x02'
    str_3 = '\x00\x01\x02'
    var_3 = ansible_native_concat(str_3)

# Generated at 2022-06-25 12:24:23.358858
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Assert that the result is a string
    assert isinstance(str_0, unicode) or isinstance(str_0, text_type)

    # Assert that the result is equal to the expected result
    assert str_0 == var_0

# Test 2 - If the result is a string, assert that the output is equal to the input

# Generated at 2022-06-25 12:24:38.909309
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Write your code here to test ansible_native_concat
    # assert(result == expected)
    # assert(isinstance(result, expected_type))
    # assert(result.attribute == expected_value)

    str_0 = '<9np\nozN~'
    var_0 = ansible_native_concat(str_0)
    print("{}".format(var_0))

    str_1 = 'a'
    var_1 = ansible_native_concat(str_1)
    print("{}".format(var_1))

    str_2 = '\na'
    var_2 = ansible_native_concat(str_2)
    print("{}".format(var_2))

    str_3 = '\na\nb'
    var_3 = ansible

# Generated at 2022-06-25 12:24:43.074683
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '<9np\nozN~'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == '<9np\nozN~'
    str_0 = '<9np\nozN~'
    var_1 = ansible_native_concat(str_0)
    assert var_1 == '<9np\nozN~'


# Generated at 2022-06-25 12:24:45.165278
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('<9np\nozN~') == '<9np\nozN~'
    assert ansible_native_concat('/') == '/'
    assert ansible_native_concat('') == None


# Generated at 2022-06-25 12:24:50.317249
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Testing branch of function ansible_native_concat with
    # 1st branch, where branch condition is: (head and len(head) == 1)
    str_0 = '<9np\nozN~'
    get_ansible_native_concat = ansible_native_concat(str_0)
    test_case_0()
    # Testing branch of function ansible_native_concat with
    # 3rd branch, where branch condition is: not isinstance(out, string_types)
    str_0 = '<9np\nozN~'
    get_ansible_native_concat = ansible_native_concat(str_0)
    test_case_0()
    # Testing branch of function ansible_native_concat with
    # 1st branch, where branch condition is: (head and

# Generated at 2022-06-25 12:24:59.288988
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # ansible_native_concat(str)

    str_0 = '<9np\nozN~'
    var_0 = ansible_native_concat(str_0)
    var_1 = ansible_native_concat([str_0])
    assert var_0 == var_1

    # ansible_native_concat(str1, str2, ...)

    str_0 = '<9np\nozN~'
    str_1 = 'Ok\r{pk:1c'
    var_2 = ansible_native_concat(str_0, str_1)
    assert var_2 == '<9np\nozN~Ok\r{pk:1c'

    str_2 = 'F-L!M'
    var_3 = ansible_native_con

# Generated at 2022-06-25 12:25:09.007619
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert u'Hello World!' == ansible_native_concat(u'Hello')
    assert True == ansible_native_concat(True, u' ')
    assert u'-1' == ansible_native_concat(1, u' ', True)
    assert u'-2' == ansible_native_concat(1, u' ', True, u' ')
    assert u'-3' == ansible_native_concat(1, u' ', True, u' ', False)
    assert u'-4' == ansible_native_concat(1, u' ', True, u' ', False, u' ')
    assert u'-5' == ansible_native_concat(1, u' ', True, u' ', False, u' ', None)

# Generated at 2022-06-25 12:25:12.095166
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Assert if test_case_0 function throws any exception
    result = test_case_0()

    # Returned result should be of type test_case_0
    assert isinstance(result, test_case_0)

# Generated at 2022-06-25 12:25:13.650071
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    try:
        test_case_0()
    except Exception:
        assert False, 'unexpected failure'
    else:
        assert True

# Generated at 2022-06-25 12:25:14.966852
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert False, ('Failed to import ansible_native_concat from __main__')



# Generated at 2022-06-25 12:25:17.931680
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '<9np\nozN~'
    var_0 = ansible_native_concat(str_0)

    assert var_0 == '<9np\nozN~'


# Generated at 2022-06-25 12:25:31.519988
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Set up test values
    str_0 = '<9np\nozN~'
    str_3 = '}l1yX'
    str_4 = '3wC'
    str_6 = 'k-_2'
    str_9 = '#'

    # Call function to test
    assert ansible_native_concat(str_0) == str_0, 'Expected str_0 as output, but got ' + container_to_text(ansible_native_concat(str_0))
    assert ansible_native_concat([str_3, str_4]) == str_3 + str_4, 'Expected str_3 + str_4 as output, but got ' + container_to_text(ansible_native_concat([str_3, str_4]))
    assert ansible_

# Generated at 2022-06-25 12:25:41.922589
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = '<9np\nozN~'
    u'<9np\nozN~'
    assert ansible_native_concat(var_0) == u'<9np\nozN~'
    var_1 = 'a\ta'
    u'a\ta'
    assert ansible_native_concat(var_1) == u'a\ta'
    var_2 = 'a'
    u'a'
    assert ansible_native_concat(var_2) == u'a'
    var_3 = 'a\t'
    u'a\t'
    assert ansible_native_concat(var_3) == u'a\t'
    var_4 = 'a  \t'
    u'a  \t'
    assert ansible_

# Generated at 2022-06-25 12:25:43.226408
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """ ansible_native_concat"""
    assert True



# Generated at 2022-06-25 12:25:45.967054
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test case provided by Ansible"""
    var_0 = ansible_native_concat(container_to_text([u'<9np\nozN~\n']))
    assert var_0 == '<9np\nozN~\n'

# Generated at 2022-06-25 12:25:52.879014
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # See https://github.com/ansible/ansible/issues/70831
    assert ansible_native_concat('foo') == 'foo'
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo ', '"bar"']) == 'foo "bar"'
    assert ansible_native_concat(['foo', '"bar"']) == 'foo"bar"'
    assert ansible_native_concat('foo', 'bar') == 'foobar'
    assert ansible_native_concat('foo', '"bar"') == 'foo"bar"'
    assert ansible_native_concat('foo ', '"bar"') == 'foo "bar"'
    assert ansible_native

# Generated at 2022-06-25 12:26:03.598607
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_1 = ansible_native_concat('test')
    assert var_1 == 'test'

    var_2 = ansible_native_concat(('{', 'a', '}'))
    assert var_2 == '{a}'

    var_3 = ansible_native_concat(ansible_native_concat)
    assert var_3 == ansible_native_concat

    var_4 = ansible_native_concat(NativeJinjaText('{'))
    assert var_4 == '{'

    var_5 = ansible_native_concat(NativeJinjaText('{')) == '{'
    assert var_5

    var_6 = ansible_native_concat(NativeJinjaText('{')) == '{'
    assert var_6

    var

# Generated at 2022-06-25 12:26:05.082755
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()

# Generated at 2022-06-25 12:26:07.299214
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    arg_0 = '<9np\nozN~'

    # Call ansible_native_concat
    ansible_native_concat(arg_0)



# Generated at 2022-06-25 12:26:13.501758
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_cases = (
        (("c'est", "l'hiver"), "c'est l'hiver"),
        (('this', 'is', 'a', 'test'), 'this is a test'),
        (('this', 'is', 'a', 'test'), 'this is a test'),
    )
    for case, expected in test_cases:
        assert ansible_native_concat(case) == expected


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 12:26:17.015289
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '<9np\nozN~'
    var_0 = ansible_native_concat(str_0)
    print('# str_0 {0!r}'.format(str_0))
    print('# var_0 {0!r}'.format(var_0))
    assert var_0 is None



# Generated at 2022-06-25 12:26:29.218863
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Remove this line:
    str_0 = 'j/2I@\t$\x0c'
    var_0 = ansible_native_concat(str_0)

    # Remove this line:
    str_2 = "m\x1d'\x0c\t\n"
    var_2 = ansible_native_concat(str_2)

    # Remove this line:
    str_o = 'vG^\t{'
    var_o = ansible_native_concat(str_o)

    # Remove this line:
    str_i = 'w\x0bU\x1dRZ'
    var_i = ansible_native_concat(str_i)

    # Remove this line:

# Generated at 2022-06-25 12:26:37.198131
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat([u'a', u'b', u'c']) == u'abc'
    assert ansible_native_concat([u'a', u'', u'c']) == u'ac'
    assert ansible_native_concat([123, 'b', 'c']) == u'123bc'
    assert ansible_native_concat([123, {'a': 1}, 'c']) == u'123{a=1}c'
    assert ansible_native_concat([123, {'a': 1}, [1, 'a']]) == u'123{a=1}[1, a]'

# Generated at 2022-06-25 12:26:47.673861
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '<9np\nozN~'
    var_0 = ansible_native_concat(str_0)
    assert type(var_0) == bytes
    assert var_0 == b'<9np\x0cozN~'
    dict_0 = dict(a=1, b=2)
    dict_1 = dict(x=3, y=4)
    dict_2 = dict(z=5, w=6)
    dict_3 = dict(zz=7, ww=8)
    dict_4 = dict(zzz=9, www=10)
    dict_5 = dict(zzzz=11, wwww=12)
    dict_6 = dict(zzzzz=13, wwwww=14)

# Generated at 2022-06-25 12:26:54.529019
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    src = '''
    #!/usr/bin/python
    str_0 = '<9np\nozN~'
    var_0 = ansible_native_concat(str_0)
    '''
    ast_tree = ast.parse(src)
    convertor = AnsibleNatives()
    mod = convertor.visit(ast_tree)
    codeobj = compile(mod, '<string>', 'exec')
    ns = {}
    exec(codeobj, ns)
    assert ns['var_0'] == '<9np\nozN~'



# Generated at 2022-06-25 12:27:02.119805
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert to_text('test') == ansible_native_concat(['test'])
    assert 'test' == ansible_native_concat(['test'])
    assert to_text('test') == ansible_native_concat([u'test'])
    assert to_text('test') == ansible_native_concat([u'test'])
    assert to_text('test') == ansible_native_concat(['te', 'st'])
    assert u'test' == ansible_native_concat(['te', 'st'])
    assert u'test' == ansible_native_concat([u'te', u'st'])
    assert u'test' == ansible_native_concat([u'te', u'st'])
    assert to_text('test') == ansible_native_

# Generated at 2022-06-25 12:27:07.385085
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = '<9np\nozN~'
    # expect: "abcd"
    var_1 = ansible_native_concat(var_0)
    # expect: "abcd"
    var_2 = ansible_native_concat(to_text(var_0))
    # expect: "abcd"
    var_3 = ansible_native_concat(to_text(str(var_0)))
    # expect: "abcd"
    var_4 = ansible_native_concat(container_to_text(var_0))
    # expect: "abcd"
    var_5 = ansible_native_concat(container_to_text(str(var_0)))
    # expect: "abcd"

# Generated at 2022-06-25 12:27:18.131443
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test with a string input.
    str_0 = '42'
    result = ansible_native_concat(str_0)
    assert isinstance(result, text_type)
    assert result == '42'

    # Test with a native Python type input.
    var_0 = 42
    result = ansible_native_concat(var_0)
    assert isinstance(result, int)
    assert result == 42

    # Test with a template input.
    # This should raise an exception.
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    template = AnsibleUnsafeText('{{ foo }}')
    result = ansible_native_concat(template)
    assert isinstance(result, text_type)
    assert result == '{{ foo }}'

    # Test with another template input.

# Generated at 2022-06-25 12:27:19.604263
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # the plain text value is encrypted
    assert '9np\nozN~' == test_case_0()

# Generated at 2022-06-25 12:27:21.598023
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = '<9np\nozN~'
    var_1 = ansible_native_concat(var_0)
    assert var_1 == var_0

# Generated at 2022-06-25 12:27:30.693250
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Testing the function with a constant value
    str_0 = '<9np\nozN~'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == '<9np\nozN~'

    # Testing the function with a constant value (some byte string)
    str_0 = '\x5c@\xa8\xbf\x05\xbe'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == '\\@¤¿\\x05¾'

    # Testing the function with a constant value (some Unicode)
    str_0 = u'Î'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == u'Î'

    # Testing the function

# Generated at 2022-06-25 12:27:46.526601
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(['a', 'b', 'c', 'd']) == 'abcd'
    assert ansible_native_concat(['a', 'b', 'c', 'd', 'e']) == 'abcde'
    assert ansible_native_concat(['a', 'b', 'c', 'd', 'e', 'f']) == 'abcdef'

# Generated at 2022-06-25 12:27:55.915585
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert to_text('some_string') == ansible_native_concat(to_text('some_string'))
    assert to_text('some_string') == ansible_native_concat((to_text('some_string'),))
    assert [to_text('some_string'), to_text('some_string')] == ansible_native_concat((to_text('some_string'), to_text('some_string')))
    assert to_text('some_string some_string') == ansible_native_concat((to_text('some_string'), to_text(' '), to_text('some_string')))
    assert to_text('some_string some_string') == ansible_native_concat((to_text('some_string'), to_text(' '), to_text('some_string'),))

# Generated at 2022-06-25 12:28:00.213241
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Set up mock for test_case_0
    # TODO: Add a test for an AnsibleVaultEncryptedUnicode string

    str_0 = '<9np\nozN~'
    var_0 = ansible_native_concat(str_0)

    # The expected value of the variable is pulled from the mock
    assert var_0 == str_0

# Generated at 2022-06-25 12:28:09.393693
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('<9np\nozN~') == '<9np\nozN~'
    assert ansible_native_concat(3) == 3
    assert ansible_native_concat(0.0) == 0.0
    assert ansible_native_concat(None) is None
    assert ansible_native_concat(['hi', ' ', 'bye']) == 'hi bye'
    assert ansible_native_concat({'hi': 'bye'}) == {'hi': 'bye'}
    assert ansible_native_concat({'hi': 'bye'}) == {'hi': 'bye'}
    assert ansible_native_concat(['hi', ' ', 'bye']) == 'hi bye'

# Generated at 2022-06-25 12:28:15.296986
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = ansible_native_concat()
    assert var_0 == None, "Expected: %s\nGot: %s" % (None, var_0)

    str_0 = '<9np\nozN~'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == u'\u003c9np\u000aozN~', "Expected: %s\nGot: %s" % (u'\u003c9np\u000aozN~', var_0)

# Generated at 2022-06-25 12:28:18.863495
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test 'str_0'
    str_0 = '<9np\nozN~'
    var_0 = ansible_native_concat(str_0)


if __name__ == '__main__':
    test_case_0()
    test_ansible_native_concat()

# Generated at 2022-06-25 12:28:27.282996
# Unit test for function ansible_native_concat

# Generated at 2022-06-25 12:28:32.866612
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert var_0 == '<9np\nozN~'
    assert var_0 == '<9np\nozN~'
    assert var_0 == '<9np\nozN~'
    assert var_0 == '<9np\nozN~'
    str_1 = 'I"\x0c6^]\x1f'
    var_1 = ansible_native_concat(str_1)


# Generated at 2022-06-25 12:28:33.461991
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert True


# Generated at 2022-06-25 12:28:38.606648
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    c = ansible_native_concat(['a', 'b'])
    assert c == 'ab'
    c = ansible_native_concat(('a', 'b'))
    assert c == 'ab'
    c = ansible_native_concat(str_0)
    assert c == '<9np\nozN~'
    c = ansible_native_concat(var_0)
    assert c == '<9np\nozN~'

# Generated at 2022-06-25 12:28:49.593409
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Check that ansible_native_concat() returns the expected result for several inputs"""

    # Test with input 1
    str_0 = '<9np\nozN~'
    var_0 = ansible_native_concat(str_0)

    assert var_0 == "<9np\nozN~"


# Generated at 2022-06-25 12:28:54.668912
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_cases = [
        {
            'inputs': [
                # one item
                '<9np\nozN~',
                # two items
                'H\x04\x08\r\nx', '\x02\x00\x00\x00\x08\x00\x00\x00'
            ],
            'want': '<9np\nozN~H\x04\x08\r\nx\x02\x00\x00\x00\x08\x00\x00\x00',
        }
    ]

    for test_case in test_cases:
        got = ansible_native_concat(test_case['inputs'])


# Generated at 2022-06-25 12:28:57.034246
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'k"rZa`U"9mW'

    # Verify that the function returns the correct result
    assert ansible_native_concat(str_0) == 'k"rZa`U"9mW'


# Generated at 2022-06-25 12:29:06.845318
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    list_0 = [48, -72, 60.1, '''$W8Sv&i[zC''', '''\x00\xff\n''', '''\x00\xff\n''']
    str_0 = '\x00'
    str_1 = '\xff'
    str_2 = '\n'
    str_3 = '''\x00\xff\n'''
    str_4 = '\xff'
    str_5 = '\n'
    str_6 = '\x00'
    list_1 = [-71, -72, '\x00', '\x00']
    list_2 = ['\x00', '\xff', '\n']
    str_7 = '\x00'
    str_8 = '\xff'

# Generated at 2022-06-25 12:29:10.285058
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    with open('./test/units/parsing/converter/test_ansible_native_concat.yml') as infile:
        yamlin = yaml.safe_load(infile)

    for test in yamlin:
        if 'in' in test:
            ansible_native_concat(test['in'])

