

# Generated at 2022-06-25 12:19:11.022961
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Print statements are shown while executing some code, if they are not commented out
    #print ('{}'.format(ansible_native_concat()))
    assert True


# Generated at 2022-06-25 12:19:13.189353
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    result = ansible_native_concat()
    assert isinstance(result, None)
    result = ansible_native_concat(int_0)
    assert isinstance(result, int)


# Generated at 2022-06-25 12:19:19.098618
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # these should be True
    assert(test_case_0() == 1870)


list_0 = ([{'a': 1, 'b': 2}, {'a': 1, 'b': 2}])
var_0 = ansible_native_concat(list_0)

# Generated at 2022-06-25 12:19:30.229604
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Result is an int
    assert test_case_0() == 1870

    # Result is a list
    nodes = [
        {'url': {'http': True}},
        {'username': 'test-user'},
        {'password': 'test-password'},
    ]
    assert ansible_native_concat(nodes) == [
        {'url': {'http': True}},
        {'username': 'test-user'},
        {'password': 'test-password'},
    ]

    # Result is a dict
    nodes = [{
        'url': {
            'http': True,
            'host': 'test-host',
            'port': 465,
        },
        'username': 'test-user',
        'password': 'test-password',
    }]
    assert ans

# Generated at 2022-06-25 12:19:31.632282
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    int_0 = 1870
    var_0 = ansible_native_concat(int_0)



# Generated at 2022-06-25 12:19:37.612936
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(string_0) == string_0
    assert ansible_native_concat(string_0) == string_0
    assert ansible_native_concat(list_0) == u'Hello\nWorld\n'
    assert ansible_native_concat(list_1) == u'Hello\nWorld\n'
    assert ansible_native_concat(var_0) == string_0
    assert ansible_native_concat(var_1) == string_0
    assert ansible_native_concat(var_2) == string_0
    assert ansible_native_concat(var_3) == string_0
    assert ansible_native_concat(var_4) == string_0
    assert ansible_native_concat(var_5) == string

# Generated at 2022-06-25 12:19:38.870867
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == '1870'



# Generated at 2022-06-25 12:19:47.982368
# Unit test for function ansible_native_concat

# Generated at 2022-06-25 12:19:57.598377
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    int_0 = 1870
    var_0 = ansible_native_concat(int_0)
    assert 1870 == var_0


# BEGIN generated code

# testing generated code with the following cmd:
# python -c "import types; import test_native_types; print(types.ModuleType('test_native_types').__dict__.keys())"
# ['arg',
# '__name__',
# 'test_case_0',
# '__file__',
# 'AnsibleVaultEncryptedUnicode',
# 'ansible_native_concat',
# 'ansible_native_to_text',
# 'ansible_native_override_safe',
# 'AnsibleNativeToText_AnsibleVaultEncryptedUnicode',
# 'NativeJinjaText',
# 'unicode

# Generated at 2022-06-25 12:20:00.341372
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(1870) == 1870
    assert ansible_native_concat('foo') == 'foo'
    assert ansible_native_concat(None) == None
    assert ansible_native_concat(['foo', 'bar', 'baz']) == 'foobarbaz'


# Generated at 2022-06-25 12:20:03.496814
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == 'siD18=\tN&P^y'

# Generated at 2022-06-25 12:20:07.956000
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert(None == ansible_native_concat(''))
    assert('10' == ansible_native_concat('10'))
    assert('10' == ansible_native_concat('1', '0'))
    assert('10' == ansible_native_concat('1', 0))
    assert('a1b' == ansible_native_concat('a', 1, 'b'))
    assert('a1b' == ansible_native_concat('a', 1.0, 'b'))
    assert('abc' == ansible_native_concat('a', 'b', 'c'))
    assert('' == ansible_native_concat())
    assert('1' == ansible_native_concat(1))
    assert(10 == ansible_native_concat(10))

# Generated at 2022-06-25 12:20:09.553505
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'siD18=\tN&P^y'
    var_0 = ansible_native_concat(str_0)
    print("ansible_native_concat(str_0): ", var_0)
    assert var_0 == 'siD18=\tN&P^y'

# Generated at 2022-06-25 12:20:12.882412
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert var_0 == None, "The function ansible_native_concat() did not return expected value"

if __name__ == "__main__":
    test_ansible_native_concat()

# Generated at 2022-06-25 12:20:13.776289
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == None



# Generated at 2022-06-25 12:20:17.878177
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Input parameters
    # nodes: (Iterable[Node])
    str_0 = 'siD18=\tN&P^y'

    # Output
    str_out = 'siD18=\tN&P^y'

    # Unit test
    assert ansible_native_concat(str_0) == str_out

# Generated at 2022-06-25 12:20:19.728825
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert 'ocla' == ansible_native_concat(u'ocla')


# Generated at 2022-06-25 12:20:20.226126
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert 1 == 0

# Generated at 2022-06-25 12:20:27.169046
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    result = ansible_native_concat('a string')
    assert isinstance(result, string_types)
    assert result == 'a string'

    result = ansible_native_concat(42)
    assert isinstance(result, int)
    assert result == 42

    result = ansible_native_concat(['a', 'string'])
    assert isinstance(result, string_types)
    assert result == 'a string'

    result = ansible_native_concat(['a', 42])
    assert isinstance(result, string_types)
    assert result == 'a 42'



# Generated at 2022-06-25 12:20:30.048036
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Print function's docstring
    print(ansible_native_concat.__doc__)

    # Print information about the function
    print("ansible_native_concat is instance of %s\n" % type(ansible_native_concat))

    # Invoke the function
    ansible_native_concat(str_0)



# Generated at 2022-06-25 12:20:33.274758
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert var_0 == 'N&P^y'



# Generated at 2022-06-25 12:20:36.184947
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('siD18=\tN&P^y') == 'siD18=\tN&P^y'


# Generated at 2022-06-25 12:20:43.578486
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['siD18=\tN&P^y']) == 'siD18=\tN&P^y'
    assert ansible_native_concat(['siD18=', '\tN&P^y']) == 'siD18=\tN&P^y'
    assert ansible_native_concat('siD18=\tN&P^y') == 'siD18=\tN&P^y'
    assert ansible_native_concat('siD18=\tN&P^y'.split('=')) == 'siD18=\tN&P^y'

# Generated at 2022-06-25 12:20:46.517606
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'siD18=\tN&P^y'
    var_0 = ansible_native_concat(str_0)



# Generated at 2022-06-25 12:20:46.969113
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert True

# Generated at 2022-06-25 12:20:48.699518
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['siD18=\tN&P^y']) == 'siD18=\tN&P^y'

# Generated at 2022-06-25 12:20:50.779683
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    #str_0 = 'siD18=\tN&P^y'
    #var_0 = ansible_native_concat(str_0)

    assert True

# Generated at 2022-06-25 12:20:52.614839
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'siD18=\tN&P^y'
    var_0 = ansible_native_concat(str_0)



# Generated at 2022-06-25 12:20:59.898487
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'siD18=\tN&P^y'
    str_1 = 'jJb~;r{_'
    str_2 = 'h(X$'
    var_0 = ansible_native_concat([str_0, str_1, str_2])
    var_1 = ansible_native_concat(str_0)
    assert var_0 is not None
    assert var_0 == 4.423853642374349e-05
    assert var_1 == str_0


# Generated at 2022-06-25 12:21:09.080678
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_1 = ['L', '\n', ' ', 'N']
    var_1 = ansible_native_concat(var_1)
    assert var_1 == 'L\n N'
    var_2 = ['h', '9', '.']
    var_2 = ansible_native_concat(var_2)
    assert var_2 == 'h9.'
    var_3 = 'Vb\n'
    var_3 = ansible_native_concat(var_3)
    assert var_3 == 'Vb\n'
    str_0 = 'siD18=\tN&P^y'
    var_4 = ansible_native_concat(str_0)
    assert var_4 == 'siD18=\tN&P^y'

# Generated at 2022-06-25 12:21:19.046552
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Random test with uuid
    str_0 = container_to_text(ansible_native_concat(None))
    assert isinstance(str_0, text_type)

    # Random test with uuid
    str_0 = container_to_text(ansible_native_concat(None))
    assert isinstance(str_0, text_type)

    # Random test with uuid
    str_0 = container_to_text(ansible_native_concat(None))
    assert isinstance(str_0, text_type)

    # Random test with uuid
    str_0 = container_to_text(ansible_native_concat(None))
    assert isinstance(str_0, text_type)

    # Random test with uuid

# Generated at 2022-06-25 12:21:29.767576
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Supported cases
    # Make sure we have a string
    assert isinstance(ansible_native_concat('foo'), str)
    # Make sure we have a dictionary
    assert isinstance(ansible_native_concat(dict(a='foo', b='bar')), dict)
    # Make sure we have a list
    assert isinstance(ansible_native_concat(['a', 'b', 'c']), list)
    # Make sure we have a tuple
    assert isinstance(ansible_native_concat(('a', 'b', 'c')), tuple)
    # Make sure we have a set
    assert isinstance(ansible_native_concat(set(['a', 'b'])) == set(['a', 'b'])) is True
    # Make sure we have None
    assert ansible_native_concat

# Generated at 2022-06-25 12:21:31.627786
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    test_case_0()

if __name__ == '__main__':
    test_ansible_native_concat()

# Generated at 2022-06-25 12:21:34.596168
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
  # Create test data
  str_0 = 'siD18=\tN&P^y'

  # Test the function
  result = ansible_native_concat(str_0)
  assert result == ansible_native_concat(str_0)


# Generated at 2022-06-25 12:21:42.468251
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'siD18=\tN&P^y'
    var_0 = ansible_native_concat(str_0)
    str_1 = '^E6:L'
    var_1 = ansible_native_concat(str_1)
    str_2 = 'y2S:*'
    var_2 = ansible_native_concat(str_2)
    str_3 = 'mfM'
    var_3 = ansible_native_concat(str_3)
    str_4 = 'X&e'
    var_4 = ansible_native_concat(str_4)
    str_5 = 'A3;=\tG:L'
    var_5 = ansible_native_concat(str_5)

# Generated at 2022-06-25 12:21:52.115519
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert "siD18=\tN&P^y" == ansible_native_concat("siD18=\tN&P^y")
    assert "siD18=\tN&P^y" == ansible_native_concat("siD18=\tN&P^y")
    assert "siD18=\tN&P^y" == ansible_native_concat("siD18=\tN&P^y")
    assert "siD18=\tN&P^y" == ansible_native_concat("siD18=\tN&P^y")
    assert "siD18=\tN&P^y" == ansible_native_concat("siD18=\tN&P^y")
    assert 0.23876524208037304 == ans

# Generated at 2022-06-25 12:21:54.852476
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = '^e@+'
    var_1 = ansible_native_concat(var_0)
    assert var_1 == '^e@+'


# Generated at 2022-06-25 12:21:56.502474
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # TODO: Implement test_ansible_native_concat
    assert True



# Generated at 2022-06-25 12:21:59.661974
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    pass

# Source Ansible's Jinja2 filters
from ansible.parsing.yaml.objects import AnsibleSequence
from ansible.parsing.yaml.objects import AnsibleUnicode


# Generated at 2022-06-25 12:22:09.643378
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'siD18=\tN&P^y'
    str_1 = 'm6nJ3qwz+'
    str_2 = 'siD18=\tN&P^y'
    str_3 = 'm6nJ3qwz+'
    str_4 = 'siD18=\tN&P^y'
    str_5 = 'm6nJ3qwz+'
    str_6 = 'siD18=\tN&P^y'
    str_7 = 'm6nJ3qwz+'
    str_8 = 'siD18=\tN&P^y'
    str_9 = 'm6nJ3qwz+'
    str_10 = 'siD18=\tN&P^y'


# Generated at 2022-06-25 12:22:14.231829
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # create the expected/desired output

    # use the function under test
    actual = ansible_native_concat(tokens)

    # assert that the expected and the actual are the same
    assert expected == actual


# Generated at 2022-06-25 12:22:18.914707
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Native JinjaText
    assert ansible_native_concat('siD18=\tN&P^y') == 'siD18=\tN&P^y'

    # Literal
    assert ansible_native_concat(1) == 1

    # List
    assert ansible_native_concat([[1, 'siD18=\tN&P^y'], [2, 'siD18=\tN&P^y']]) == [[1, 'siD18=\tN&P^y'], [2, 'siD18=\tN&P^y']]

    # Dict

# Generated at 2022-06-25 12:22:26.384599
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    expected_result = None
    actual_result = ansible_native_concat('siD18=\tN&P^y')
    assert actual_result == expected_result, "'siD18=\tN&P^y' is expected to return %s, but got %s" % (expected_result, actual_result)
    actual_result = ansible_native_concat('sleQ,\tN&P^y')
    assert actual_result == expected_result, "'sleQ,\tN&P^y' is expected to return %s, but got %s" % (expected_result, actual_result)

# Generated at 2022-06-25 12:22:30.291921
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'siD18=\tN&P^y'
    var_0 = ansible_native_concat(str_0)
    assert isinstance(var_0, AnsibleVaultEncryptedUnicode)
    assert var_0.data == 'siD18=\tN&P^y'


# Generated at 2022-06-25 12:22:32.928354
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == True

# Generated at 2022-06-25 12:22:43.253111
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'LcC'
    var_1 = ansible_native_concat(str_0)
    assert var_1 == "LcC"

    str_1 = '\t'
    var_2 = ansible_native_concat(str_1)
    assert var_2 == "\t"

    str_2 = '8wNj+RE~'
    var_3 = ansible_native_concat(str_2)
    assert var_3 == "8wNj+RE~"

    str_3 = 'M)~'
    var_4 = ansible_native_concat(str_3)
    assert var_4 == "M)~"

    str_4 = ''
    var_5 = ansible_native_concat(str_4)
    assert var_5

# Generated at 2022-06-25 12:22:45.497018
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == 'siD18=\tN&P^y'


# Generated at 2022-06-25 12:22:48.749267
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'siD18=\tN&P^y'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'siD18=\tN&P^y'

# Generated at 2022-06-25 12:22:57.586595
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('Test') == 'Test'
    assert ansible_native_concat('Test', 'Case') == 'TestCase'
    assert ansible_native_concat('Test', 'Case', '0') == 'TestCase0'
    assert ansible_native_concat('Test', 'Case', '0', '', '42') == 'TestCase042'
    assert ansible_native_concat('Test', 'Case', '0', '', '42', None) == 'TestCase042'
    assert ansible_native_concat('Test', 'Case', '0', '', '42', '') == 'TestCase042'
    assert ansible_native_concat('Test', 'Case', '0', '', '42', '/') == 'TestCase042/'
    assert ansible_

# Generated at 2022-06-25 12:22:58.364715
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()

# Generated at 2022-06-25 12:23:05.650779
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert type(ansible_native_concat) == type(test_case_0)

# Test case for function ansible_native_concat.

# Generated at 2022-06-25 12:23:13.617881
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat() == None
    assert ansible_native_concat(0.3) == 0.3
    assert ansible_native_concat(1.225) == 1.225
    assert ansible_native_concat(-0.13) == -0.13
    assert ansible_native_concat(0.2) == 0.2
    assert ansible_native_concat(1.1) == 1.1
    assert ansible_native_concat(0.22) == 0.22
    assert ansible_native_concat(3) == 3
    assert ansible_native_concat(0) == 0
    assert ansible_native_concat(17) == 17
    assert ansible_native_concat(15) == 15

# Generated at 2022-06-25 12:23:22.205369
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('siD18=\tN&P^y') == ansible_native_concat('siD18=\tN&P^y')
    assert ansible_native_concat('siD18=\tN&P^y') == ansible_native_concat('siD18=\tN&P^y')
    assert ansible_native_concat('siD18=\tN&P^y') == ansible_native_concat('siD18=\tN&P^y')
    assert ansible_native_concat('siD18=\tN&P^y') == ansible_native_concat('siD18=\tN&P^y')

# Generated at 2022-06-25 12:23:30.664001
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # NativeJinjaText, None
    str_0 = 'siD18=\tN&P^y'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'siD18=\tN&P^y'
    # NativeJinjaText, NativeJinjaText
    str_0 = "'{{var1}}'"
    str_1 = '{{ var2 }}'
    var_0 = ansible_native_concat(str_0, str_1)
    assert var_0 == "'{{var1}}'{{ var2 }}"
    # NativeJinjaText, bool
    str_0 = 'true'
    bool_0 = True
    var_0 = ansible_native_concat(str_0, bool_0)

# Generated at 2022-06-25 12:23:38.327505
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    ##################################################################################
    # If a file is provided, the test cases in the file are used
    # else the module unit test will be called.
    result_0 = test_case_0()
    if type(result_0) is not bool:
        raise ValueError("The output of process_test_case_0 need to be of type bool. The current returned type is: " + type(result_0))
    if result_0:
        return True
    else:
        return False


# Generated at 2022-06-25 12:23:40.397704
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    func_call = ansible_native_concat('test_string')
    assert func_call == 'test_string'



# Generated at 2022-06-25 12:23:42.478639
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert container_to_text(test_case_0()) == "siD18=\tN&P^y"

# Generated at 2022-06-25 12:23:42.898989
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    pass



# Generated at 2022-06-25 12:23:53.532215
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    print(ansible_native_concat([u'foo', u'bar']))
    print(ansible_native_concat([1, 2, 3]))
    print(ansible_native_concat([u'foo', u'bar', u'baz']))
    print(ansible_native_concat([u'foo', u'bar', u'baz']))
    print(ansible_native_concat([u'foo', u'bar', u'baz', u'{% if foo.bar %}', u'baz', u'{% endif %}']))
    print(ansible_native_concat([u'foo', u'bar', u'baz', u'{% if foo.bar %}', u'baz', u'{% endif %}']))

# Generated at 2022-06-25 12:23:55.647927
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(('hghg\t', 'hghghg\t')) == 'hghg\thghghg\t'

# Generated at 2022-06-25 12:24:08.265590
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    func = ansible_native_concat
    func(['qLbX', 'Ft_\t]'])
    func(['G|', '}', '\r'])
    func(['XRe', 'e', ')l'])
    func(['O', '', '>r'])
    func(['T', 'D', '[8'])
    func([container_to_text([0, 1, 2]), '\x00', 'V\n'])
    func(['\x19', 'Q', '.'])
    func(['\x1a', '.bk'])
    func(['\n', '_', 'c%:'])
    func([container_to_text([5]), '\x1d', '\x1a'])

# Generated at 2022-06-25 12:24:17.206816
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Tests to ensure that ansible_natives_concat returns the correct type
    assert(type(ansible_native_concat([0])) == type(0))
    assert(type(ansible_native_concat([1.0])) == type(1.0))
    assert(type(ansible_native_concat(['1.0'])) == type(1.0))
    assert(type(ansible_native_concat([True])) == type(True))
    assert(type(ansible_native_concat([None])) == type(None))
    assert(type(ansible_native_concat(['test'])) == type('test'))
    assert(type(ansible_native_concat([{}])) == type({}))

# Generated at 2022-06-25 12:24:24.613919
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() is not False

# For the unit test to be valid, this needs to be defined in a separate file
# and imported into the test file.
try:
    import ansible_collections.other.not_a_real_collection.plugins.modules.fail_json
except ImportError:
    from ansible.module_utils.basic import fail_json

    fail_json_func = fail_json
else:
    fail_json_func = ansible_collections.other.not_a_real_collection.plugins.modules.fail_json.fail_json


# Generated at 2022-06-25 12:24:26.348319
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['siD18=\tN&P^y']) == 'siD18=\tN&P^y'

# Generated at 2022-06-25 12:24:34.200811
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('siD18=\tN&P^y') == 'siD18=\tN&P^y'
    # TODO depending on whether the vault secret is correct, it could either
    # return an empty string or the decrypted string.
    # assert ansible_native_concat('!vault |') == ''
    assert ansible_native_concat('') == None
    assert ansible_native_concat(False) == False
    assert ansible_native_concat(10) == 10
    assert ansible_native_concat('10') == 10
    assert ansible_native_concat(10) == 10
    assert ansible_native_concat(b'10') == b'10'

# Generated at 2022-06-25 12:24:41.739958
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert ansible_native_concat(False) is False
    assert ansible_native_concat(True) is True
    assert ansible_native_concat(True) is True
    assert ansible_native_concat(True) is True
    assert ansible_native_concat(True) is True
    assert ansible_native_concat(True) is True
    assert ansible_native_concat(True) is True
    assert ansible_native_concat(True) is True
    assert ansible_native_concat(True) is True
    assert ansible_native_concat(True) is True
    assert ansible_native_concat(True) is True
    assert ansible_native_concat(True) is True
    assert ansible_native_concat(True) is True
    assert ansible

# Generated at 2022-06-25 12:24:43.621898
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert 'siD18=\tN&P^y' == ansible_native_concat('siD18=\tN&P^y')


# Generated at 2022-06-25 12:24:45.055627
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert callable(ansible_native_concat), "ansible_native_concat is not a function"


# Generated at 2022-06-25 12:24:46.407034
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()


if __name__ == '__main__':
    test_ansible_native_concat()

# Generated at 2022-06-25 12:24:48.244999
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0  = 'siD18=\tN&P^y'
    expected = 'siD18=\tN&P^y'
    actual = ansible_native_concat(var_0)
    assert actual == expected


# Generated at 2022-06-25 12:24:55.903222
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'siD18=\tN&P^y'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'siD18=\tN&P^y'



# Generated at 2022-06-25 12:24:59.577203
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'foo'
    str_1 = 'bar'
    var_0 = ansible_native_concat(str_0)
    var_1 = ansible_native_concat(str_1)
    assert 'foo' == container_to_text(var_0)
    assert 'bar' == container_to_text(var_1)


# Generated at 2022-06-25 12:25:01.975429
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    out = ansible_native_concat('siD18=\tN&P^y')
    assert out is None

# Generated at 2022-06-25 12:25:02.814015
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()

# Generated at 2022-06-25 12:25:04.012426
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    func = globals()['ansible_native_concat']
    assert func



# Generated at 2022-06-25 12:25:11.879448
# Unit test for function ansible_native_concat

# Generated at 2022-06-25 12:25:19.908162
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    ret_0 = ansible_native_concat('siD18=\tN&P^y')
    assert ret_0 == 'siD18=\tN&P^y', "Expected: %s, Actual: %s" % ('siD18=\tN&P^y', ret_0)


    ret_1 = ansible_native_concat('siD18=\tN&P^y')
    assert ret_1 == 'siD18=\tN&P^y', "Expected: %s, Actual: %s" % ('siD18=\tN&P^y', ret_1)


    ret_2 = ansible_native_concat('siD18=\tN&P^y')

# Generated at 2022-06-25 12:25:22.778911
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'j*!Jw%cZ2b'
    lst_0 = [ 'A3H' ]
    var_0 = ansible_native_concat(lst_0)


# Generated at 2022-06-25 12:25:26.891904
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'siD18=\tN&P^y'
    var_0 = ansible_native_concat(str_0)

# Generated at 2022-06-25 12:25:30.373820
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0(test_case_0)
    test_case_1(test_case_1)
    test_case_2(test_case_2)
    test_case_3(test_case_3)
    test_case_4(test_case_4)
    test_case_5(test_case_5)


# Generated at 2022-06-25 12:25:43.698556
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'siD18=\tN&P^y'
    var_0 = ansible_native_concat(str_0)
    assert var_0 is None

    str_1 = 'z.ZU#[Kj'
    var_1 = ansible_native_concat(str_1)
    assert var_1 is None

    str_2 = 'r_M>}H~&'
    var_2 = ansible_native_concat(str_2)
    assert var_2 is None

    str_3 = 'q3>G!zt]'
    var_3 = ansible_native_concat(str_3)
    assert var_3 is None

    str_4 = '{Mw`0%>H'

# Generated at 2022-06-25 12:25:45.460429
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert True

if __name__ == "__main__":
    test_case_0()

# Test ansible_native_concat

# Generated at 2022-06-25 12:25:47.794906
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert callable(ansible_native_concat)
    str_0 = 'siD18=\tN&P^y'
    var_0 = ansible_native_concat(str_0)


# Generated at 2022-06-25 12:25:53.996045
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '|Mt|~f?}Y'
    assert type(ansible_native_concat(str_0)) == str
    str_0 = 'NyQdRn{^'
    assert type(ansible_native_concat(str_0)) == str
    str_0 = '{d1,I4CX'
    assert type(ansible_native_concat(str_0)) == str
    str_0 = 'O,H9;#hx'
    assert type(ansible_native_concat(str_0)) == str
    str_0 = ';X7A,ojN'
    assert type(ansible_native_concat(str_0)) == str
    str_0 = 'xDf|G1|H'

# Generated at 2022-06-25 12:26:04.519082
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'siD18=\tN&P^y'
    var_1 = ansible_native_concat(str_0)
    assert var_1 == str_0

    str_0 = 'siD18=\tN&P^y'
    var_1 = ansible_native_concat(str_0)
    assert var_1 == str_0

    str_0 = 'siD18=\tN&P^y'
    var_2 = 'siD18=\tN&P^y'
    var_1 = ansible_native_concat(str_0)
    assert var_1 == var_2

    str_0 = 'siD18=\tN&P^y'
    var_2 = 'siD18=\tN&P^y'
   

# Generated at 2022-06-25 12:26:13.701371
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '\u20ac\x00\n\x7f\u00b2'
    str_1 = '\x00\n\x7f\u00b2,\x7f\u20ac'
    str_2 = ':&<>\u0001'
    str_3 = 'siD18=\tN&P^y'
    list_0 = AnsibleVaultEncryptedUnicode('siD18=\tN&P^y')
    list_1 = 'siD18=\tN&P^y'
    assert ansible_native_concat(str_0) == str_0
    assert ansible_native_concat(list_0) == list_1

# Generated at 2022-06-25 12:26:22.668540
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = 'siD18=\tN&P^y'
    var_1 = ansible_native_concat(var_0)
    assert var_1 == 'siD18=\tN&P^y', "'siD18=\tN&P^y' != '%s'" % var_1
    var_2 = 'b_[)'
    var_3 = len(var_2)
    var_4 = var_3
    var_5 = var_4
    var_6 = var_4
    var_7 = var_6
    var_8 = var_7
    var_9 = var_8
    var_10 = var_9
    var_11 = var_10
    var_12 = var_11
    var_13 = var_12
    var_14 = var_

# Generated at 2022-06-25 12:26:33.174783
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str0 = 'siD18=\tN&P^y'
    var0 = ansible_native_concat(str0)
    expected = 'siD18=\tN&P^y'
    assert var0 == expected
    expected_stderr = "ansible-test integer"
    assert stderr == expected_stderr
    str0 = '\tvHbj#/xD5'
    var0 = ansible_native_concat(str0)
    expected = '\tvHbj#/xD5'
    assert var0 == expected
    expected_stderr = "ansible-test integer"
    assert stderr == expected_stderr
    str0 = '\tN[=_z0cR!|9j'

# Generated at 2022-06-25 12:26:39.375503
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    #
    # Test 1: do not modifiy the list
    #
    nodes = [1, 2, 3]
    out = ansible_native_concat(nodes)
    assert out == u'123'
    assert nodes == [1, 2, 3]

    #
    # Test 2: skip undefined values
    #
    nodes = [1, StrictUndefined(), 2, 3]
    out = ansible_native_concat(nodes)
    assert out == u'123'

    #
    # Test 3: first value is undefined
    #
    nodes = [StrictUndefined(), 1, 2, 3]
    out = ansible_native_concat(nodes)
    assert out == u'123'

    #
    # Test 4: last value is undefined
    #

# Generated at 2022-06-25 12:26:49.886026
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test function with fixed values

    # Test string of length 12
    str_0 = 'siD18=\tN&P^y'
    assert ansible_native_concat(str_0) == 'siD18=\tN&P^y'

    # Test string of length 12
    str_0 = 'o%\x0b\x16\x1eUY\x1d'
    assert ansible_native_concat(str_0) == 'o%\x0b\x16\x1eUY\x1d'

    # Test string of length 24

# Generated at 2022-06-25 12:26:58.324045
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'siD18=\tN&P^y'
    var_0 = ansible_native_concat(str_0)
    assert isinstance(var_0, container_to_text)

# Generated at 2022-06-25 12:27:01.154797
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'siD18=\tN&P^y'
    var_0 = ansible_native_concat(str_0)
    assert container_to_text(var_0) == 'siD18=\tN&P^y'

# Generated at 2022-06-25 12:27:01.773432
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert 1 == 1

# Generated at 2022-06-25 12:27:06.603958
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'siD18=\tN&P^y'
    var_0 = ansible_native_concat(str_0)
    var_array = []
    var_array.append(var_0)
    var_0 = var_array[0]
    str_1 = to_text(var_0)
    assert str_1 == str_0

# Generated at 2022-06-25 12:27:17.072672
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    cmd_0 = b''
    cmd_1 = b''
    cmd_2 = b''

    with open('test/test_native_types.txt', 'rb') as fp:
        cmd_0 = fp.read()

    with open('test/test_native_types_2.txt', 'rb') as fp:
        cmd_1 = fp.read()

    with open('test/test_native_types_3.txt', 'rb') as fp:
        cmd_2 = fp.read()

    test_case_0(cmd_0)
    test_case_0(cmd_1)
    test_case_0(cmd_2)


if __name__ == "__main__":
    test_ansible_native_concat()

# Generated at 2022-06-25 12:27:20.660274
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '3.14 3.14 3.14 3.14'
    var_0 = ansible_native_concat(str_0)
    test_assertion(var_0 == '3.14 3.14 3.14 3.14')


# Generated at 2022-06-25 12:27:21.486849
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()

# Generated at 2022-06-25 12:27:30.658333
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test to ensure that the provided concat function behaves as
    # expected with a variety of input types.

    # Basic string concatentation.
    assert ansible_native_concat([u'foo', u'foo', u'foo']) == u'foofoofoo'

    # Basic concatenation with a mix of unicode and str strings.
    assert ansible_native_concat([u'foo', 'foo', u'foo']) == u'foofoofoo'

    # String concatenation with numbers.
    assert ansible_native_concat([u'1', u'2']) == '12'

    # String concatenation with booleans.
    assert ansible_native_concat([u'True']) == 'True'

# Generated at 2022-06-25 12:27:40.732283
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'siD18=\tN&P^y'
    var_0 = ansible_native_concat(str_0)
    assert 'siD18=\tN&P^y' == container_to_text(var_0)
    str_1 = 'p^]C\t:'
    var_1 = ansible_native_concat(str_1)
    assert 'p^]C\t:' == container_to_text(var_1)
    str_2 = ':*]\tNgK\t^'
    var_2 = ansible_native_concat(str_2)
    assert ':*]\tNgK\t^' == container_to_text(var_2)

# Generated at 2022-06-25 12:27:42.951193
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'siD18=\tN&P^y'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'siD18=\tN&P^y'


# Generated at 2022-06-25 12:27:47.663633
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert var_0 == 'siD18=\tN&P^y'

# Generated at 2022-06-25 12:27:53.405269
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # 1. Setup input variables
    n_0 = 'siD18=\tN&P^y'
    # 2. Test function
    out = ansible_native_concat(n_0)
    # 3. Print result of test
    print("Result of test ansible_native_concat: {0}".format(out))

if __name__ == '__main__':
    test_ansible_native_concat()

# Generated at 2022-06-25 12:28:02.192041
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Matching objects are always equal
    assert ansible_native_concat('') == ''
    assert ansible_native_concat('a') == 'a'
    assert ansible_native_concat('abc') == 'abc'
    assert ansible_native_concat('abc\n') == 'abc\n'
    assert ansible_native_concat('abc\n1') == 'abc\n1'
    assert ansible_native_concat('abc\n1\n') == 'abc\n1\n'
    # Matching objects are always equal
    assert ansible_native_concat(42) == 42
    assert ansible_native_concat(42.0) == 42.0
    assert ansible_native_concat('42') == '42'

# Generated at 2022-06-25 12:28:07.224951
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = 'siD18=\tN&P^y'
    var_0 = ansible_native_concat(var_0)
    var_1 = list()
    var_1.append('siD18=\tN&P^y')
    var_1 = ansible_native_concat(var_1)
    assert var_0 == var_1



# Generated at 2022-06-25 12:28:14.381787
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert "siD18=\tN&P^y" == ansible_native_concat(
        'siD18=\tN&P^y'
    )

    assert "siD18=\tN&P^y" == ansible_native_concat(
        'siD18=\tN&P^y'
    )

    assert "siD18= N&P^y" == ansible_native_concat(
        'siD18= ',
        'N&P^y'
    )

    assert "siD18= N&P^y" == ansible_native_concat(
        'siD18= ' + 'N&P^y'
    )

    assert "siD18= N&P^y siD18= N&P^y" == ansible_native_

# Generated at 2022-06-25 12:28:19.592157
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    func = types.FunctionType(ansible_native_concat.__code__, {})
    program_ast, _ = parse_to_ast("""
    test_case_0()
    """)
    visitor = AnsibleNativeConcatVisitor()
    visitor.visit(program_ast)
    assert visitor.functions == {func: 1}, "Failed to find ansible_native_concat"



# Generated at 2022-06-25 12:28:27.924532
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'siD18=\tN&P^y'
    var_0 = ansible_native_concat(str_0)
    assert var_0 is not None
    assert isinstance(var_0, text_type)
    str_1 = b'siD18=\tN&P^y'
    var_1 = ansible_native_concat(str_1)
    assert var_1 is not None
    assert isinstance(var_1, text_type)
    str_2 = container_to_text(container_to_text)
    var_2 = ansible_native_concat(str_2)
    assert var_2 is not None
    assert isinstance(var_2, text_type)
    str_3 = '123'
    var_3 = ansible_native_

# Generated at 2022-06-25 12:28:37.031741
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test for the function ansible_native_concat"""

    test_cases = [
        {"input": "siD18=\tN&P^y", "expected": "siD18=\tN&P^y"}
        # {"input": ["", ""], "expected": ""},
        # {"input": [1, 2], "expected": 3},
        # {"input": ["hello", ""], "expected": "hello"},
        # {"input": ["", "hello"], "expected": "hello"},
        # {"input": ["hello", "world"], "expected": "helloworld"},
        # {"input": [1, "hello"], "expected": "1hello"},
        # {"input": ["hello", 1], "expected": "hello1"},
    ]


# Generated at 2022-06-25 12:28:39.505706
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'siD18=\tN&P^y'
    var_0 = ansible_native_concat(str_0)

# Generated at 2022-06-25 12:28:43.350250
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = container_to_text(['siD18=\tN&P^y'])
    str_1 = 'siD18=\tN&P^y'
    var_0 = ansible_native_concat(str_0)
    var_1 = ansible_native_concat(str_1)
    assert str_0 == str_1 and str_1 == var_0 and var_0 == var_1


# Generated at 2022-06-25 12:28:47.769928
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    with pytest.raises(AnsibleUndefinedVariable):
        test_case_0()



# Generated at 2022-06-25 12:28:56.409138
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'siD18=\tN&P^y'
    var_0 = ansible_native_concat(str_0)

    assert var_0 == 'siD18=\tN&P^y'
    str_0 = 'siD18=\tN&P^y'
    str_1 = 'P:}V7Y=nhneu}K'
    var_0 = ansible_native_concat(str_0)
    var_1 = ansible_native_concat(str_1)
    var_2 = ansible_native_concat(var_0)
    var_3 = ansible_native_concat(var_1)
    var_4 = ansible_native_concat(var_2, var_3)


# Generated at 2022-06-25 12:28:57.529162
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()
    test_case_1()



# Generated at 2022-06-25 12:29:01.010904
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Check that ansible_native_concat function is not changed."""
    assert ansible_native_concat != container_to_text
    assert ansible_native_concat != ansible_native_concat_old

# Generated at 2022-06-25 12:29:09.542945
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    try:
        assert ansible_native_concat('siD18=\tN&P^y') == 'siD18=\tN&P^y'
    except AssertionError as e:
        print('AssertionError: %s' % e)
    try:
        assert ansible_native_concat('\tP\x0e') == '\tP\x0e'
    except AssertionError as e:
        print('AssertionError: %s' % e)
    try:
        assert ansible_native_concat('\n\tN') == '\n\tN'
    except AssertionError as e:
        print('AssertionError: %s' % e)