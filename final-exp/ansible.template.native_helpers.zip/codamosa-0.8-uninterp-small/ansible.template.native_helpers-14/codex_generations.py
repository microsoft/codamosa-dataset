

# Generated at 2022-06-25 12:19:14.580521
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    out = ansible_native_concat(['&[`8dIh>XsF<a=o'])
    assert out == "&[`8dIh>XsF<a=o"

# Generated at 2022-06-25 12:19:15.338907
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert callable(ansible_native_concat)

# Generated at 2022-06-25 12:19:25.584882
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert isinstance(test_case_0(), string_types)
    assert isinstance(test_case_1(), NativeJinjaText)
    assert isinstance(test_case_2(), NativeJinjaText)
    assert isinstance(test_case_3(), NativeJinjaText)
    assert isinstance(test_case_4(), NativeJinjaText)
    assert isinstance(test_case_5(), NativeJinjaText)
    assert isinstance(test_case_6(), string_types)
    assert isinstance(test_case_7(), string_types)
    assert isinstance(test_case_8(), string_types)
    assert isinstance(test_case_9(), string_types)


# Generated at 2022-06-25 12:19:28.057660
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == '&[`8dIh>XsF<a=o'

# Generated at 2022-06-25 12:19:37.375278
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert '&[`8dIh>XsF<a=o' == ansible_native_concat('&[`8dIh>XsF<a=o')
    assert '&[`8dIh>XsF<a=o' == ansible_native_concat(['&[`8dIh>XsF<a=o'])
    assert '123&[`8dIh>XsF<a=o' == ansible_native_concat(['123', '&[`8dIh>XsF<a=o'])
    assert '123&[`8dIh>XsF<a=o456' == ansible_native_concat(['123', '&[`8dIh>XsF<a=o', '456'])
   

# Generated at 2022-06-25 12:19:46.988245
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    result = ansible_native_concat('O4]d:jgZ_z+lH')
    assert isinstance(result, str)
    assert result == 'O4]d:jgZ_z+lH'

    result = ansible_native_concat(['O4]d:jgZ_z+lH', 'O4]d:jgZ_z+lH'])
    assert isinstance(result, str)
    assert result == 'O4]d:jgZ_z+lHO4]d:jgZ_z+lH'


# Generated at 2022-06-25 12:19:56.941235
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Ensure that the jinja2 to_native filter and ansible_native_concat
    return the same value.
    """
    jinja2_env = {
        'to_native': ansible_native_concat,
    }
    ansible_env = {
        'ansible_native_concat': ansible_native_concat,
    }

# Generated at 2022-06-25 12:19:58.094450
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # These tests provide examples of the function usage
    assert True == True

# Generated at 2022-06-25 12:19:59.950509
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    output = ansible_native_concat('&[`8dIh>XsF<a=o')
    assert output == '&[`8dIh>XsF<a=o'

# Generated at 2022-06-25 12:20:05.618612
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test if the ansible_native_concat returns the expected value."""
    # Test case 0 from above unit test.
    str_0 = '&[`8dIh>XsF<a=o'
    expected_result_0 = "&[`8dIh>XsF<a=o"
    var_0 = ansible_native_concat(str_0)
    assert var_0 == expected_result_0

    # Test case 1 from above unit test.
    str_1 = "&[`8dIh>XsF<a=o"
    expected_result_1 = "&[`8dIh>XsF<a=o"
    var_1 = ansible_native_concat(str_1)
    assert var_1 == expected_result_1

    #

# Generated at 2022-06-25 12:20:10.552701
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('&[`8dIh>XsF<a=o') == '&[`8dIh>XsF<a=o'

# Generated at 2022-06-25 12:20:16.422565
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # type: () -> None
    str_0 = '&[`8dIh>XsF<a=o'
    var_0 = ansible_native_concat(str_0)

    assert var_0 is not None
    # These two lines are equivalent
    assert is_sequence(var_0)
    assert isinstance(var_0, string_types)
    assert not isinstance(var_0, (int, float))

# Generated at 2022-06-25 12:20:19.418536
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '>|'
    var_0 = ansible_native_concat(str_0)



# Generated at 2022-06-25 12:20:21.018686
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == "&[`8dIh>XsF<a=o"

# Generated at 2022-06-25 12:20:23.920665
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Variable: result
    result = ansible_native_concat([u"hello", u"world"])
    assert result == u"hello world"



# Generated at 2022-06-25 12:20:26.190802
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert '&[`8dIh>XsF<a=o' == ansible_native_concat('&[`8dIh>XsF<a=o')


# Generated at 2022-06-25 12:20:33.742925
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = 'B@I~)x'
    var_1 = ansible_native_concat(var_0)
    assert(var_1 == 'B@I~)x')
    var_2 = 'W]_Z?*V'
    var_3 = ansible_native_concat(var_2)
    assert(var_3 == 'W]_Z?*V')
    var_4 = 'iE{f*V'
    var_5 = ansible_native_concat(var_4)
    assert(var_5 == 'iE{f*V')
    var_6 = '[M@F4+g'
    var_7 = ansible_native_concat(var_6)
    assert(var_7 == '[M@F4+g')

# Generated at 2022-06-25 12:20:36.088782
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Example run of the function
    ansible_native_concat(str_0)


# Test example that checks that the function throws an error

# Generated at 2022-06-25 12:20:39.004255
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert 'string' == type(ansible_native_concat(['foo', 'bar']))
    assert 'string' == type(ansible_native_concat(['baz', ansible_native_concat(['foo', 'bar'])]))

# Generated at 2022-06-25 12:20:47.829120
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # In case ansible_native_concat raises an exception it will be propagated to
    # the outer try-except-finally block.

    assert ansible_native_concat(('[', '1', ',', '2', ',', '3', ']')) == [1, 2, 3]
    assert ansible_native_concat(('1', '2', '3')) == 123
    assert ansible_native_concat(('[', '1', ',', '2', ',', ']', '3')) == '[1, 2,]3'
    try:
        assert ansible_native_concat(('[', '1', ',', '2', ',', ')')) == ValueError
    except ValueError:
        pass



# Generated at 2022-06-25 12:20:50.448903
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert True



# Generated at 2022-06-25 12:21:00.644700
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test with a string
    ansible_native_concat('string')
    # Test with an integer
    ansible_native_concat(1)
    # Test with a float
    ansible_native_concat(1.0)
    # Test with an expression
    ansible_native_concat('{{ foo }}')
    ansible_native_concat('[{{ foo }}, {{ bar }}]')
    # Test with a list
    ansible_native_concat(['foo', 'bar', 1, 1.0])
    ansible_native_concat(['{{ foo }}', '{{ bar }}'])
    ansible_native_concat(['{{ foo }}', 1])
    ansible_native_concat(['{{ foo }}', 1.0])
    # Test with a dict
    ansible_native_

# Generated at 2022-06-25 12:21:09.374638
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '&[`8dIh>XsF<a=o'
    assert str_0 == ansible_native_concat(str_0)

    try:
        str_1 = u'\u0041'
        assert str_1 == ansible_native_concat(str_1)
    except Exception:
        assert False, 'could not evaluate unicode string'

    str_2 = "&[`8dIh>XsF<a=o"
    assert str_2 == ansible_native_concat(str_2)

    try:
        str_3 = u'\u0041'
        assert str_3 == ansible_native_concat(str_3)
    except Exception:
        assert False, 'could not evaluate unicode string'


# Generated at 2022-06-25 12:21:18.801354
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = "&[`8dIh>XsF<a=o"
    var_0 = ansible_native_concat(str_0)
    assert var_0 == '&[`8dIh>XsF<a=o'

    str_0 = "xMy1 (x)C`FJf|"
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'xMy1 (x)C`FJf|'

    str_0 = "B+eW2uV4IfoG@w?"
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'B+eW2uV4IfoG@w?'


# Generated at 2022-06-25 12:21:27.123936
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert '`8dIh>XsF<a=o' == '&[`8dIh>XsF<a=o'
    assert 'depl1' == 'depl1'
    assert 'depl1' == 'depl1'
    assert 'depl1' == 'depl1'
    assert 'depl1' == 'depl1'
    assert 'depl1' == 'depl1'
    assert 'depl1' == 'depl1'
    assert 'depl1' == 'depl1'
    assert 'depl1' == 'depl1'

# Generated at 2022-06-25 12:21:35.637024
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '<h0ZIR'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == '<h0ZIR'

    str_1 = 'N-.'
    var_1 = ansible_native_concat(str_1)
    assert var_1 == 'N-.'

    str_2 = '7*'
    var_2 = ansible_native_concat(str_2)
    assert var_2 == '7*'

    int_3 = -7
    var_3 = ansible_native_concat(int_3)
    assert var_3 == -7

    bool_4 = False
    var_4 = ansible_native_concat(bool_4)
    assert var_4 == False

    str_5 = ','


# Generated at 2022-06-25 12:21:37.470213
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = None
    assert ansible_native_concat(var_0) == None, 'Assertion Error'

# Generated at 2022-06-25 12:21:39.875625
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'Zq"3v]4WJ'
    var_0 = ansible_native_concat(str_0)

    assert var_0 == str_0



# Generated at 2022-06-25 12:21:50.223546
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.collections import is_sequence
    assert callable(ansible_native_concat)
    assert isinstance(ansible_native_concat('test'), string_types)
    assert ansible_native_concat(('test',)) == 'test'
    assert isinstance(ansible_native_concat(('test', 'test')), string_types)
    assert ansible_native_concat((1,)) == 1
    assert ansible_native_concat((None,)) is None
    assert ansible_native_concat(('test', 1)) == 'test1'
    assert ansible_native_concat(('test', 2)) == 'test2'
    assert isinstance(ansible_native_concat(('test', 2)), string_types)
    assert ansible_native

# Generated at 2022-06-25 12:21:51.888829
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(str_0) == var_0

# Generated at 2022-06-25 12:21:55.107587
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert str_0 == var_0

# Generated at 2022-06-25 12:22:05.778287
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # First test when the function is called with a single string
    f = ansible_native_concat('ansible')
    assert f == 'ansible', 'Test failed'
    # Second test when the function is called with multiple strings
    f = ansible_native_concat('ansible', 'works')
    assert f == 'ansibleworks', 'Test failed'
    # Third test when the function is called with a single number
    f = ansible_native_concat(5)
    assert f == 5, 'Test failed'
    # Fourth test when the function is called with multiple numbers
    f = ansible_native_concat(5, 6)
    assert f == 56, 'Test failed'
    # Fifth test when the function is called with a single list
    f = ansible_native_concat([1, 2, 3])
   

# Generated at 2022-06-25 12:22:07.828533
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    '''
    Unit test for function ansible_native_concat
    '''
    test_case_0()


# Generated at 2022-06-25 12:22:15.708384
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    out = ansible_native_concat([1, 2])
    assert out == '12'

    out = ansible_native_concat([1, 2, 3])
    assert out == '123'

    out = ansible_native_concat([1, 'b', 3])
    assert out == '1b3'

    out = ansible_native_concat([1, 'b', 3, 'd'])
    assert out == '1b3d'

    out = ansible_native_concat([1, 'b', [3, 4, 5], 'd'])
    assert out == '1b345d'

    out = ansible_native_concat([1, 2, [3, 4, 5], 'd'])
    assert out == '12345d'

    out = ansible_native_concat

# Generated at 2022-06-25 12:22:17.658606
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert True


# Generated at 2022-06-25 12:22:24.862143
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert '0X9' == ansible_native_concat('0X9')
    assert '&[`8dIh>XsF<a=o' == ansible_native_concat('&[`8dIh>XsF<a=o')
    assert '0X9' == ansible_native_concat('0X9')
    assert '&[`8dIh>XsF<a=o' == ansible_native_concat('&[`8dIh>XsF<a=o')


# Generated at 2022-06-25 12:22:30.373591
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '&[`8dIh>XsF<a=o'
    assert ansible_native_concat(str_0) is not None


# Generated at 2022-06-25 12:22:33.821390
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    func_result = None

    # Assign the results of a function to a variable
    func_result = ansible_native_concat(str_0)

    assert type(func_result) is text_type

# Unit tests for function ansible_native_concat

# Generated at 2022-06-25 12:22:43.833741
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'hi \n i\'m\n a string'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == str_0

    str_1 = 'hi \n i\'m\n a string'
    var_0 = ansible_native_concat(str_1)
    assert var_0 == str_1

    str_2 = 'hi \n i\'m\n a string'
    var_0 = ansible_native_concat(str_2)
    assert var_0 == str_2

    int_4 = 3
    var_0 = ansible_native_concat(int_4)
    assert var_0 == int_4

    int_5 = -1
    var_0 = ansible_native_concat(int_5)


# Generated at 2022-06-25 12:22:54.141097
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '&[`8dIh>XsF<a=o'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == '&[`8dIh>XsF<a=o'
    str_1 = '6[`1:%~C;fz&;4x'
    var_1 = ansible_native_concat(str_1)
    assert var_1 == '6[`1:%~C;fz&;4x'
    str_2 = '^|}.v>Bj d#=@C'
    var_2 = ansible_native_concat(str_2)
    assert var_2 == '^|}.v>Bj d#=@C'

# Generated at 2022-06-25 12:23:02.045202
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '&[`8dIh>XsF<a=o'
    var_0 = ansible_native_concat(str_0)
    assert isinstance(var_0, string_types)
    assert var_0 == str_0
    list_0 = ['T', 'b', 'Z', 'q', '|', 'E', 'M', 'C', 'B']
    var_1 = ansible_native_concat(list_0)
    assert isinstance(var_1, string_types)
    assert var_1 == container_to_text(list_0)
    dict_0 = {'a': 1, 'b': '2', 'c': [3, 4, 5]}
    var_2 = ansible_native_concat(dict_0)

# Generated at 2022-06-25 12:23:11.944946
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '&[`8dIh>XsF<a=o'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == '&[`8dIh>XsF<a=o'

    str_0 = '!sJ&yU6VpU@}d'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == '!sJ&yU6VpU@}d'

    str_0 = 'G9$P}ZHG+C_'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'G9$P}ZHG+C_'

    str_0 = '''```'''
    var_0

# Generated at 2022-06-25 12:23:14.261724
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '&[`8dIh>XsF<a=o'
    assert '&[`8dIh>XsF<a=o' == ansible_native_concat(str_0)


# Generated at 2022-06-25 12:23:22.789831
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '&[`8dIh>XsF<a=o'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == '&[`8dIh>XsF<a=o'

    str_0 = 'o<aXsF>hI8d`&['
    var_0 = ansible_native_concat(reversed(str_0))
    assert var_0 == '&[`8dIh>XsF<a=o'

    # Use the 'repr' filter to prevent native_concat from parsing the result
    # of the concatenation.
    str_0 = 'a'
    str_1 = 'b'
    str_2 = 'c'
    var_0 = ansible_native_con

# Generated at 2022-06-25 12:23:31.109480
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    tuple_1 = (1, 2, 3)
    assert ansible_native_concat(tuple_1) == 123


# Generated at 2022-06-25 12:23:41.515233
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('foobar') == 'foobar'
    assert ansible_native_concat(u'foobar') == u'foobar'
    assert ansible_native_concat('foobar') == 'foobar'
    assert ansible_native_concat('foobar') == 'foobar'
    assert ansible_native_concat('foobar') == 'foobar'
    assert ansible_native_concat('foobar') == 'foobar'
    assert ansible_native_concat('foobar') == 'foobar'
    assert ansible_native_concat('foobar') == 'foobar'
    assert ansible_native_concat('foobar') == 'foobar'
    assert ansible_native_concat('foobar') == 'foobar'
    assert ansible_native

# Generated at 2022-06-25 12:23:42.278705
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # TODO: Implement unit tests
    assert True

# Generated at 2022-06-25 12:23:43.769869
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert callable(ansible_native_concat), "function 'ansible_native_concat' not defined"


# Test with a simple string

# Generated at 2022-06-25 12:23:45.717952
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert 'o=' == ansible_native_concat('&[`8dIh>XsF<a=')



# Generated at 2022-06-25 12:23:56.151056
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '&[`8dIh>XsF<a=o'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == "&[`8dIh>XsF<a=o"

    str_0 = '&[`8dIh>XsF<a=o'
    str_1 = 'w>Op<oV#_'
    var_0 = ansible_native_concat(str_0, str_1)
    assert var_0 == "&[`8dIh>XsF<a=ow>Op<oV#_"

    str_0 = 'tu1H6^'
    int_0 = 6
    var_0 = ansible_native_concat(str_0, int_0)


# Generated at 2022-06-25 12:24:07.433883
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert ansible_native_concat(['r']) == "r"
    assert ansible_native_concat(['r', 'o']) == "ro"
    assert ansible_native_concat(chain(['r', 'o'], ['m'], ['a'])) == "roma"

    assert ansible_native_concat(['123']) == 123
    assert ansible_native_concat(['123', '45']) == 123

    assert ansible_native_concat(['']) is None
    assert ansible_native_concat([]) is None



# Generated at 2022-06-25 12:24:09.334371
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    try:
        test_case_0()
    except Exception as e:
        print('Exception: ' + str(e))


# Generated at 2022-06-25 12:24:14.310851
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert callable(ansible_native_concat)
    assert ansible_native_concat('&[`8dIh>XsF<a=o') == '&[`8dIh>XsF<a=o'
    __salt__ = {}
    assert ansible_native_concat('&[`8dIh>XsF<a=o') == '&[`8dIh>XsF<a=o'

# Generated at 2022-06-25 12:24:18.410926
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Assert the result of function ansible_native_concat is equal to the result of function ansible_native_concat.
    assert ansible_native_concat(["123", "456"]) == ansible_native_concat(["123", "456"])


# Generated at 2022-06-25 12:24:20.678341
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert True

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 12:24:28.622908
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ('[`8dIh>XsF<a=o' == ansible_native_concat('&[`8dIh>XsF<a=o')), \
        "'&[`8dIh>XsF<a=o' should be equal to '[`8dIh>XsF<a=o'"
    assert ('AuKoy8zagv7o' == ansible_native_concat('&AuKoy8zagv7o')), \
        "'&AuKoy8zagv7o' should be equal to 'AuKoy8zagv7o'"

# Generated at 2022-06-25 12:24:36.920918
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert 'ansible_native_concat' in globals(), "You should declare ansible_native_concat function"
    assert 'str' in globals(), "You should declare str function"
    assert 'list' in globals(), "You should declare list function"
    assert 'dict' in globals(), "You should declare dict function"
    assert 'int' in globals(), "You should declare int function"
    assert 'float' in globals(), "You should declare float function"
    assert 'bool' in globals(), "You should declare bool function"
    assert 'None' in globals(), "You should declare None variable"
    assert ansible_native_concat(str_0) == var_0


# Generated at 2022-06-25 12:24:40.115275
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert True
    #assert test_case_0() == 'abc'

ansible_native_concat.__doc__ = """\
This is a autogenerated function docstring.
The function implementation is in :py:mod:`__main__`
"""

if __name__ == "__main__":
    test_ansible_native_concat()

# Generated at 2022-06-25 12:24:46.788823
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # First step is to run the actual ansible code to generate the expected results.
    # This could be done by running the playbooks (if the relevant test cases are
    # already present in the playbooks), by creating the test cases directly.

    # Input data for the function is created here
    str_0 = 'Z,Q[f!j@7V~0vB,E#cec%A=e\\K'

    # Expected output from running the ansible module code.
    expected_results = {'value': 'Z,Q[f!j@7V~0vB,E#cec%A=e\\K'}

    # Running the ansible module code
    results = ansible_native_concat(str_0)

    # Verifying the expected results

# Generated at 2022-06-25 12:24:49.796358
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Clean up after previous tests
    if 'var_0' in locals():
        del var_0

    str_0 = '&[`8dIh>XsF<a=o'
    var_0 = ansible_native_concat(str_0)

    assert var_0 == '&[`8dIh>XsF<a=o'



# Generated at 2022-06-25 12:24:53.353045
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == None

# Generated at 2022-06-25 12:24:58.418166
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '&[`8dIh>XsF<a=o'
    expected_0 = '&[`8dIh>XsF<a=o'
    var_0 = ansible_native_concat(str_0)
    assert expected_0 == var_0, 'Expected \'{0}\', got \'{1}\''.format(expected_0, var_0)


# Generated at 2022-06-25 12:25:08.107735
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert _fail_on_undefined(ansible_native_concat([])) is None
    assert _fail_on_undefined(ansible_native_concat([123])) == 123
    assert _fail_on_undefined(ansible_native_concat(['123'])) == 123
    assert _fail_on_undefined(ansible_native_concat([-123])) == -123
    assert _fail_on_undefined(ansible_native_concat(['-123'])) == -123
    assert _fail_on_undefined(ansible_native_concat([123.456])) == 123.456
    assert _fail_on_undefined(ansible_native_concat(['123.456'])) == 123.456

# Generated at 2022-06-25 12:25:12.493418
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '&[`8dIh>XsF<a=o'

    # Call function 'ansible_native_concat'
    var_0 = ansible_native_concat(str_0)
    ansible_native_concat(str_0)

# Generated at 2022-06-25 12:25:20.791902
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_1 = '%c`x7VuB'
    var_1 = ansible_native_concat(str_1)
    assert var_1 == '%c`x7VuB'

    str_2 = 'S7CZl^[@fKw%&/'
    var_2 = ansible_native_concat(str_2)
    assert var_2 == 'S7CZl^[@fKw%&/'

    str_3 = '>_f<_gC|PY|'
    var_3 = ansible_native_concat(str_3)
    assert var_3 == '>_f<_gC|PY|'

    str_4 = 't}#XlMi^r'
    var_4 = ansible_native_concat

# Generated at 2022-06-25 12:25:21.402370
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert True

# Generated at 2022-06-25 12:25:29.888156
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test modules with no arguments
    assert ansible_native_concat('') is None
    assert ansible_native_concat(None) is None
    assert ansible_native_concat([]) is None

    assert ansible_native_concat('blah') == 'blah'

    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([False]) is False
    assert ansible_native_concat([123]) == 123
    assert ansible_native_concat([123.45]) == 123.45
    assert ansible_native_concat(['blah']) == 'blah'
    assert ansible_native_concat(['blah', 'blah2']) == 'blahblah2'

# Generated at 2022-06-25 12:25:33.790262
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '&[`8dIh>XsF<a=o'
    var_0 = ansible_native_concat(str_0)
    assert str_0 == var_0



# Generated at 2022-06-25 12:25:34.632869
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert str_0 == var_0

# Generated at 2022-06-25 12:25:40.539388
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    result1 = ansible_native_concat(['test'])
    assert result1 == 'test'
    result2 = ansible_native_concat([1])
    assert result2 == 1
    result3 = ansible_native_concat(['1', '2'])
    assert result3 == 12
    result4 = ansible_native_concat([1, 2])
    assert result4 == 3

# Generated at 2022-06-25 12:25:50.396474
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert 'aaa' == ansible_native_concat(['aa', 'a'])
    assert [1, 2, 3] == ansible_native_concat(['[1', ', 2', ', 3]'])
    assert {'a': 1, 'b': 2} == ansible_native_concat(['{a: 1', ', b: 2}'])
    assert [1, 2, 3] == ansible_native_concat(['[1', ', 2', ', 3]'])
    assert [1, 2, 3] == ansible_native_concat([1, ', 2', ', 3]'])
    assert [] == ansible_native_concat(['[', ']'])
    assert {'a': {'b': 1}} == ansible_native_concat(['{a: {b: 1}}'])
   

# Generated at 2022-06-25 12:25:56.344948
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat("") == ''
    assert ansible_native_concat("a") == 'a'
    assert ansible_native_concat("b", "c") == 'bc'

    assert ansible_native_concat("", "") == ''
    assert ansible_native_concat("a", "") == 'a'
    assert ansible_native_concat("", "a") == 'a'
    assert ansible_native_concat("a", "a") == 'aa'
    assert ansible_native_concat("a", "b") == 'ab'
    assert ansible_native_concat("b", "a") == 'ba'

    assert ansible_native_concat("", "", "") == ''
    assert ansible_native_concat("a", "", "")

# Generated at 2022-06-25 12:25:57.041987
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    pass

# Generated at 2022-06-25 12:25:59.234796
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert cmp(str_0,var_0) == 0

# Generated at 2022-06-25 12:26:08.974601
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert ansible_native_concat("A") == "A"
    assert ansible_native_concat("A", "B") == "AB"
    assert ansible_native_concat("A") == "A"
    assert ansible_native_concat("A", "B", "C") == "ABC"
    assert ansible_native_concat("A", "B", "C", "D") == "ABCD"
    assert ansible_native_concat(None, "A") == "A"
    assert ansible_native_concat(None, "A", "B") == "AB"
    assert ansible_native_concat(None, "A", "B", "C") == "ABC"

# Generated at 2022-06-25 12:26:11.185451
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '&[`8dIh>XsF<a=o'
    var_0 = ansible_native_concat(str_0)



# Generated at 2022-06-25 12:26:18.452957
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'X8W{<G?Qo5u5'
    var_0 = ansible_native_concat(str_0)
    assert isinstance(var_0, text_type) == True

    str_1 = '\n`S1DF['
    var_1 = ansible_native_concat(str_1)
    assert isinstance(var_1, text_type) == True

    str_2 = 'eC5|'
    var_2 = ansible_native_concat(str_2)
    assert isinstance(var_2, text_type) == True

    str_3 = '[Odv@?>ot'
    var_3 = ansible_native_concat(str_3)
    assert isinstance(var_3, text_type) == True

    str

# Generated at 2022-06-25 12:26:22.167323
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert "something" == ansible_native_concat("something")
    assert ["somewhere", "something", "somewhere"] == ansible_native_concat(["somewhere", "something", "somewhere"])



# Generated at 2022-06-25 12:26:30.873284
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'hello'
    str_1 = 'world'
    str_2 = '!'
    list_sample = ["hello","world"]
    assert ansible_native_concat([str_0, str_1, str_2]) == 'helloworld!'
    assert ansible_native_concat([str_0, str_1]) == 'helloworld'
    assert ansible_native_concat([str_0]) == 'hello'
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(list_sample) == "helloworld"

# Generated at 2022-06-25 12:26:35.302259
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '&[`8dIh>XsF<a=o'
    var_0 = ansible_native_concat(str_0)

    assert var_0 == "&[`8dIh>XsF<a=o", "ansible_native_concat() returned '{}' but was expected to return '&[`8dIh>XsF<a=o'".format(var_0)

# Generated at 2022-06-25 12:26:40.043185
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Dummy test
    ansible_native_concat('foo')



# Generated at 2022-06-25 12:26:42.778187
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert not isinstance(test_case_0(), string_types)
    assert str(test_case_0()) == '&[`8dIh>XsF<a=o'

# Generated at 2022-06-25 12:26:45.059264
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == '&[`8dIh>XsF<a=o'

# Generated at 2022-06-25 12:26:47.196080
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    try:
        test_case_0()
    except Exception as e:
        print('Error: ' + str(e))
        raise

# Generated at 2022-06-25 12:26:48.736946
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert 'd3jh24FJsJ' == ansible_native_concat('d3jh24FJsJ')

# Generated at 2022-06-25 12:26:50.672610
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    f1 = '&[`8dIh>XsF<a=o'
    assert ansible_native_concat(f1) == f1

# Generated at 2022-06-25 12:26:59.519180
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '&[`8dIh>XsF<a=o'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == '&[`8dIh>XsF<a=o'
    str_1 = '\xab\x17\x06\xf8\xb1\xe3\x92\xce\xba\x9a\x96\x05\xda\xe8\x1e\xaf\xeb'
    var_1 = ansible_native_concat(str_1)

# Generated at 2022-06-25 12:27:04.869724
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    try:
        assert '<j[G&O2:v-8V@Wj83u' == ansible_native_concat('<j[G&O2:v-8V@Wj83u')
    except AssertionError:
        raise AssertionError(str(ansible_native_concat('<j[G&O2:v-8V@Wj83u')))


# Generated at 2022-06-25 12:27:12.056962
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_1 = ansible_native_concat('#I$r{')

    # Test AnsibleVaultEncryptedUnicode
    var_2 = ansible_native_concat('+}C<0g?1')

    # Test NativeJinjaText
    var_3 = ansible_native_concat('-y:Tn')

    # Test literal_eval on string
    var_4 = ansible_native_concat('L-r}r')

    # Test literal_eval on non-string
    var_5 = ansible_native_concat('P5i5zS')

    # Test literal_eval on tuple
    var_6 = ansible_native_concat('-c%h')

    # Test literal_eval on dict

# Generated at 2022-06-25 12:27:13.922626
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    ansible_native_concat("&[`8dIh>XsF<a=o")

# Generated at 2022-06-25 12:27:26.490655
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(['V']) == 'V'
    assert ansible_native_concat(['V', 'I']) == 'VI'
    assert ansible_native_concat(['V', 'I', 'n']) == 'VIn'
    assert ansible_native_concat(['V', 'I', 'n']) == 'VIn'
    assert ansible_native_concat(['V', 'I', 'n']) == 'VIn'
    assert ansible_native_concat(['V', 'I', 'n']) == 'VIn'
    assert ansible_native_concat(['V', 'I', 'n']) == 'VIn'

# Generated at 2022-06-25 12:27:33.617515
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '&[`8dIh>XsF<a=o'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == str_0

    str_1 = '`8dIh>XsF<a=o'
    var_1 = ansible_native_concat(str_1)
    assert var_1 == str_1

    str_2 = '-E%?y:0R}'
    var_2 = ansible_native_concat(str_2)
    assert var_2 == str_2

    str_3 = 'X!$Hc%}E'
    var_3 = ansible_native_concat(str_3)
    assert var_3 == str_3


# Generated at 2022-06-25 12:27:39.774372
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = ('output of a Unix command', 'of', 'a', 'an')
    var_1 = 'output'
    var_2 = '|&@>NzTL,%c'
    var_3 = None
    var_4 = '\'#R>xKFYr6U'
    var_5 = True
    var_6 = test_case_0



# Generated at 2022-06-25 12:27:43.777513
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    cases = [
        {'in': '&[`8dIh>XsF<a=o', 'out': '&[`8dIh>XsF<a=o'},  # test case 0
    ]
    for case in cases:
        assert case['out'] == ansible_native_concat(case['in'])

# Generated at 2022-06-25 12:27:52.892836
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # test for ansible_native_concat when arg 1 is a string
    assert True == to_text(ansible_native_concat('foo'))
    # test for ansible_native_concat when arg 1 is an int
    assert 123 == to_text(ansible_native_concat(123))
    # test for ansible_native_concat when arg 1 is a float
    assert 1.0 == to_text(ansible_native_concat(1.0))
    # test for ansible_native_concat when arg 1 is a dict
    assert {'a': 'b'} == to_text(ansible_native_concat({'a': 'b'}))
    # test for ansible_native_concat when arg 1 is a list

# Generated at 2022-06-25 12:27:55.843929
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    output = container_to_text(ansible_native_concat('dfs', 'fds', 'fds'))
    target = 'dfsfdsfds'
    assert output == target

# Test for function ansible_native_concat

# Generated at 2022-06-25 12:27:57.463364
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '&[`8dIh>XsF<a=o'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == str_0



# Generated at 2022-06-25 12:27:58.902168
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert type(test_case_0()) == text_type
    assert container_to_text(test_case_0()) == 'FOO'

# Generated at 2022-06-25 12:28:05.583103
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test case 0
    str_0 = '&[`8dIh>XsF<a=o'
    var_0 = ansible_native_concat(str_0)

    # Test case 1
    str_1 = 'zq'
    var_1 = ansible_native_concat(str_1)

    # Test case 2
    str_2 = 'W8Zv_9?Y2'
    var_2 = ansible_native_concat(str_2)

# Generated at 2022-06-25 12:28:06.428299
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert callable(ansible_native_concat)

# Generated at 2022-06-25 12:28:16.595537
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '&[`8dIh>XsF<a=o'
    str_0 = container_to_text(str_0)
    assert ansible_native_concat(str_0) == '&[`8dIh>XsF<a=o'
    str_0 = container_to_text('&[`8dIh>XsF<a=o') + container_to_text('n v+k$%H#N(%%')
    assert ansible_native_concat(str_0) == '&[`8dIh>XsF<a=on v+k$%H#N(%%'
    str_0 = container_to_text('&[`8dIh>XsF<a=on v+k$%H#N(%%')

# Generated at 2022-06-25 12:28:25.111429
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    out1 = ansible_native_concat()
    assert out1 == None

    out2 = ansible_native_concat(8)
    assert out2 == 8


# Generated at 2022-06-25 12:28:27.640945
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(to_text('&[`8dIh>XsF<a=o')) == to_text('&[`8dIh>XsF<a=o')

# Generated at 2022-06-25 12:28:30.690894
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '&[`8dIh>XsF<a=o'
    assert ansible_native_concat(str_0) == '&[`8dIh>XsF<a=o'


# Generated at 2022-06-25 12:28:32.376548
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert var_0 == '&[`8dIh>XsF<a=o'


# Generated at 2022-06-25 12:28:33.688736
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert callable(ansible_native_concat)
    test_case_0()

# Generated at 2022-06-25 12:28:37.897904
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '&[`8dIh>XsF<a=o'
    var_0 = ansible_native_concat(str_0)
    assert var_0 is not None
    assert type(var_0) == str
    assert var_0 == '&[`8dIh>XsF<a=o'


# Generated at 2022-06-25 12:28:38.674137
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert True == False


# Generated at 2022-06-25 12:28:46.391837
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(container_to_text('ccQfhO^>kZ')) == 'ccQfhO^>kZ'
    assert ansible_native_concat(container_to_text("*'1(ZX$fH'nW")) == "*'1(ZX$fH'nW"
    assert ansible_native_concat(container_to_text('b0y3qg^6RI')) == 'b0y3qg^6RI'
    assert ansible_native_concat(container_to_text('pN/E\x1c4/9')) == 'pN/E\x1c4/9'

# Generated at 2022-06-25 12:28:49.192775
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = b'ae?g<@+Rz2X$H'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'ae?g<@+Rz2X$H'


# Generated at 2022-06-25 12:28:56.141186
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert repr(test_case_0()) == repr("&[`8dIh>XsF<a=o")
    assert repr(ansible_native_concat("&[`8dIh>XsF<a=o")) == repr("&[`8dIh>XsF<a=o")
    assert repr(ansible_native_concat("&[`8dIh>XsF<a=o")) == repr("&[`8dIh>XsF<a=o")
    assert repr(ansible_native_concat("`chq^Hb<a=o")) == repr("`chq^Hb<a=o")

# Generated at 2022-06-25 12:29:01.851555
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = 't'
    var_1 = 'e'
    var_2 = 's'
    var_3 = 't'

    assert var_0 == 't'
    assert var_1 == 'e'
    assert var_2 == 's'
    assert var_3 == 't'

    assert ansible_native_concat([var_0, var_1, var_2, var_3]) == 'test'



# Generated at 2022-06-25 12:29:02.350083
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert True



# Generated at 2022-06-25 12:29:10.527758
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test with good data.
    str_0 = '&[`8dIh>XsF<a=o'
    var_0 = ansible_native_concat(str_0)
    assert len(var_0) > 0
    assert var_0 == "&[`8dIh>XsF<a=o"

    # Test with missing data.
    str_1 = "Hutwylma!!!"
    var_1 = ansible_native_concat(str_1)
    assert len(var_1) > 0
    assert var_1 == "Hutwylma!!!"

    # Test with bad data.
    str_2 = "Hjsujxy!!!"
    var_2 = ansible_native_concat(str_2)