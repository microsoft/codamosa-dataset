

# Generated at 2022-06-25 12:19:13.149070
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == '-4482'


# Generated at 2022-06-25 12:19:24.107420
# Unit test for function ansible_native_concat

# Generated at 2022-06-25 12:19:32.268505
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """
    Unit test for function ansible_native_concat
    """
    var_0 = ansible_native_concat("0123456789")
    assert var_0 == '0123456789'

    var_1 = ansible_native_concat("abc")
    assert var_1 == 'abc'

    var_2 = ansible_native_concat(True)
    assert var_2 is True

    var_3 = ansible_native_concat(False)
    assert var_3 is False

    var_4 = ansible_native_concat(-81)
    assert var_4 == -81

    var_5 = ansible_native_concat(26)
    assert var_5 == 26

    var_6 = ansible_native_concat(0)
    assert var_6 == 0

# Generated at 2022-06-25 12:19:43.357319
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    #
    # Testcases from https://github.com/pallets/jinja/blob/master/tests/testsuite/filters/test_nativetypes.py
    #
    test_case_0()

    #
    # Testcases from https://github.com/pallets/jinja/blob/master/tests/testsuite/tests/nativetypes.py
    #
    var_0 = ansible_native_concat("\n")
    var_0 = ansible_native_concat("   ")
    var_0 = ansible_native_concat("------\n")
    var_0 = ansible_native_concat("")
    var_0 = ansible_native_concat("")
    var_0 = ansible_native_concat("")
    var_0 = ansible_native

# Generated at 2022-06-25 12:19:45.921695
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    int_0 = -4482
    var_0 = ansible_native_concat(int_0)

    assert var_0 == -4482, 'concat did not return -4482'


# Generated at 2022-06-25 12:19:56.323367
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = ansible_native_concat(['foo', 'bar'])
    _fail_on_undefined(var_0)
    assert isinstance(var_0, str)
    assert var_0 == 'foobar'

    var_1 = ansible_native_concat([['foo', 'b', 'ar']])
    _fail_on_undefined(var_1)
    assert isinstance(var_1, str)
    assert var_1 == 'foobar'
    try:
        var_2 = ansible_native_concat([2j, 'foo'])
        _fail_on_undefined(var_2)
        fail("Failed to fail on concatenating incompatible types")
    except TypeError:
        pass


# Generated at 2022-06-25 12:19:57.176577
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() is None

# Generated at 2022-06-25 12:19:58.563051
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # TODO: Probably need some more tests here
    # test_case_0()
    pass

# Generated at 2022-06-25 12:20:00.715701
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Because of the specialization of the case function,
    # this test just verify that the function can run
    int_0 = -4482
    var_0 = ansible_native_concat(int_0)



# Generated at 2022-06-25 12:20:06.146618
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    int_0 = -4482
    str_0 = "NN7Vp_c%RjJIU$?m*;rXQ'{z("
    str_1 = '+f4QJw<"a,6'
    str_2 = "Hj\"l ,;]@yDpFs[(eW8'w"
    str_3 = "ky,^>W8#vjP"
    str_4 = 'jwGk<^T>T%x'
    var_0 = ansible_native_concat(int_0, str_0, str_1, str_2, str_3, str_4)
    assert var_0 == '-4482+f4QJw<"a,6'

if __name__ == "__main__":
    test_ans

# Generated at 2022-06-25 12:20:08.571009
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert 'user_dir' == ansible_native_concat('user_dir')


# Generated at 2022-06-25 12:20:18.317301
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    with pytest.raises(StrictUndefined) as execinfo:
        str_0 = 'user_dir'
        var_0 = ansible_native_concat(str_0)

# Generated at 2022-06-25 12:20:23.669103
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    fixture_0 = [
        'etc',
        'lib'
    ]
    # str_0 = ''.join([fixture_0[0], fixture_0[1]])
    str_0 = 'etclib'
    var_0 = ansible_native_concat(fixture_0)

    assert var_0 == str_0



# Generated at 2022-06-25 12:20:25.386250
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'user_dir'
    var_0 = ansible_native_concat(str_0)



# Generated at 2022-06-25 12:20:33.338007
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = ansible_native_concat(['user_dir'])
    assert var_0 == 'user_dir'

    var_1 = ansible_native_concat([None])
    assert var_1 is None

    var_2 = ansible_native_concat([9])
    assert var_2 == 9

    var_3 = ansible_native_concat([None, 9])
    assert var_3 == 'None9'

    var_4 = ansible_native_concat(['user_dir'])
    assert var_4 == 'user_dir'

    var_5 = ansible_native_concat(['user_dir'])
    assert var_5 == 'user_dir'

    var_6 = ansible_native_concat([None])
    assert var_6 is None

    var

# Generated at 2022-06-25 12:20:42.917266
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_1 = ansible_native_concat(['user_dir', '+', 'asd'])
    assert var_1 == 'user_dir+asd'
    var_2 = ansible_native_concat([{'key1': 'value1'}, '+', 123])
    assert var_2 == '''{'key1': 'value1'}+123'''
    var_3 = ansible_native_concat(['user_dir'])
    assert var_3 == 'user_dir'
    var_4 = ansible_native_concat([[1, 'a']])
    assert var_4 == [1, 'a']
    var_5 = ansible_native_concat([{1: 123}, '+', 123])

# Generated at 2022-06-25 12:20:44.626035
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() is not None

# Generated at 2022-06-25 12:20:52.042032
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = ansible_native_concat('user_dir')
    assert var_0 == 'user_dir'
    var_1 = ansible_native_concat('{{user_dir}}')
    assert var_1 == '{{user_dir}}'
    var_2 = ansible_native_concat('{{user_dir}}/{{user}}')
    assert var_2 == '{{user_dir}}/{{user}}'
    var_3 = ansible_native_concat('{{user_dir}}/{{user}}/{{user}}')
    assert var_3 == '{{user_dir}}/{{user}}/{{user}}'

    var_4 = ansible_native_concat('user_dir/{{user}}/{{user}}')

# Generated at 2022-06-25 12:21:02.432644
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert callable(ansible_native_concat)
    source_str = '''
    def user_dir(user_name):
        return '/home/' + user_name
    '''
    ast_tree = ast.parse(source_str)
    ast_str = container_to_text(ast_tree)
    ast_str = text_type(ast_tree)
    ast_tree = ast.parse(ast_str)
    var_0 = ansible_native_concat(ast_tree)
    assert isinstance(var_0, dict)
    var_1 = ansible_native_concat(ast_tree['body'])
    assert isinstance(var_1, list)
    var_2 = ansible_native_concat(ast_tree['body'][0])

# Generated at 2022-06-25 12:21:05.147061
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'user_dir'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'user_dir'

# Generated at 2022-06-25 12:21:16.636604
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'user_dir'
    expected_0 = 'user_dir'
    out_0 = ansible_native_concat(str_0)
    assert out_0 == expected_0

    str_1 = 'user_dir'
    expected_1 = 'user_dir'
    out_1 = ansible_native_concat(str_1)
    assert out_1 == expected_1

    str_2 = 'user_dir'
    expected_2 = 'user_dir'
    out_2 = ansible_native_concat(str_2)
    assert out_2 == expected_2

    str_3 = 'user_dir'
    expected_3 = 'user_dir'
    out_3 = ansible_native_concat(str_3)
    assert out_3 == expected_3

# Generated at 2022-06-25 12:21:27.137337
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Tests for function with args, tuple
    str_0 = 'user_dir'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'user_dir'

    str_0 = 'user_dir'
    str_1 = ' /etc'
    str_2 = '/ansible'
    str_3 = '/.ansible.cfg'
    var_0 = ansible_native_concat((str_0, str_1, str_2, str_3))
    assert var_0 == 'user_dir /etc/ansible/.ansible.cfg'

    str_0 = 'user_dir'
    str_1 = ' /etc/ansible/.ansible.cfg'
    var_0 = ansible_native_concat((str_0, str_1))
   

# Generated at 2022-06-25 12:21:35.635490
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == 123
    assert isinstance(ansible_native_concat(['foo', 4]), text_type)
    assert ansible_native_concat(['foo', 4]) == 'foo4'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert isinstance(ansible_native_concat(['foo', 'bar']), text_type)
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([1, 2, 3]) == 123
    assert isinstance(ansible_native_concat(['1', [2, 3]]), text_type)
    assert ansible_native_concat(['1', [2, 3]])

# Generated at 2022-06-25 12:21:37.144873
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert var_0 == 'user_dir'



# Generated at 2022-06-25 12:21:38.006067
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()

# Generated at 2022-06-25 12:21:44.497131
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('user_dir') == 'user_dir'
    assert ansible_native_concat(Container(items=['ansible_connection', 'local'])) == 'ansible_connection'
    assert ansible_native_concat(Container(items=['ansible_python_interpreter', '{{ ansible_play_hosts[0] }}'])) == 'ansible_python_interpreter'

# Generated at 2022-06-25 12:21:53.215577
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert isinstance(ansible_native_concat(), AnsibleVaultEncryptedUnicode)
    assert isinstance(ansible_native_concat(None, None), AnsibleVaultEncryptedUnicode)
    assert isinstance(ansible_native_concat(None, None, None, None), AnsibleVaultEncryptedUnicode)
    assert isinstance(ansible_native_concat(None, None, None, None, None, None), AnsibleVaultEncryptedUnicode)
    assert isinstance(ansible_native_concat(None, None, None, None, None, None, None, None), AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-25 12:21:56.754644
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'user_dir'

    # Call ansible_native_concat using test data
    var_0 = ansible_native_concat(str_0)

    assert (var_0 == 'user_dir'), 'var_0 is incorrect'

# Generated at 2022-06-25 12:21:59.525504
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_1 = 'user_dir'
    var_1 = ansible_native_concat(str_1)
    assert var_1 == "user_dir"



# Generated at 2022-06-25 12:22:01.948279
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = ansible_native_concat(['test', '1'])
    assert 'test' in var_0
    assert isinstance(var_0, text_type)

# Generated at 2022-06-25 12:22:10.024124
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Get the path to the data file
    test_case = './data_files/test_case_0.txt'

    # Get the expected output
    f = open(test_case)
    out_str = f.readline().rstrip()
    out_str = ast.literal_eval(out_str)

    # Call the function
    ansible_native_concat(str_0)

    # Check if the function output matches with the expected output
    assert var_0 == out_str

# Generated at 2022-06-25 12:22:10.632011
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()

# Generated at 2022-06-25 12:22:12.509154
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    for case in [test_case_0]:
        case()

# Generated at 2022-06-25 12:22:17.430837
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Pass a tuple of lists, the function should return a list of the concatenated values
    assert ansible_native_concat((('a', 'b', 'c', 'd'), ('e', 'f', 'g', 'h'))) == ['abcdefgh']

    assert ansible_native_co

# Generated at 2022-06-25 12:22:19.102090
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # evaluation of case 0
    assert test_case_0() == 'user_dir'


# Generated at 2022-06-25 12:22:21.175262
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert type(ansible_native_concat('me_dir')) is string_types



# Generated at 2022-06-25 12:22:30.111602
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(str) == None

    str = '{% set a = True %}{{ a | bool | native }},{{ a | bool | string | native }},{{ a | bool | int | native }},{{ a | bool | float | native }},{{ a | bool | list | native }},{{ a | bool | dict | native }}'
    assert ansible_native_concat(str) == 'True,True,1,1.0,[True],{True: True}'

    str = '{% set a = False %}{{ a | bool | native }},{{ a | bool | string | native }},{{ a | bool | int | native }},{{ a | bool | float | native }},{{ a | bool | list | native }},{{ a | bool | dict | native }}'
    assert ansible_native_concat

# Generated at 2022-06-25 12:22:34.157709
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'user_dir'
    var_0 = ansible_native_concat(str_0)
    str_1 = 'data'
    var_1 = ansible_native_concat(str_1)
    assert var_0 == 'user_dir'
    assert var_1 == 'data'


# Generated at 2022-06-25 12:22:37.813521
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'user_dir'
    var_0 = ansible_native_concat(str_0)

    assert var_0 == 'user_dir'



# Generated at 2022-06-25 12:22:46.904776
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    result = ansible_native_concat(['user_dir'])
    assert result == 'user_dir'
    result = ansible_native_concat([['user_dir']])
    assert result == 'user_dir'
    result = ansible_native_concat([['user_dir'], ['test']])
    assert result == 'user_dir test'
    result = ansible_native_concat([['user_dir'], ['test'], ['test']])
    assert result == 'user_dir test test'
    result = ansible_native_concat([['user_dir'], ['test'], ['test'], ['test']])
    assert result == 'user_dir test test test'

# Testing for function ansible_native_concat

# Generated at 2022-06-25 12:22:51.744083
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_text
    assert to_text(ansible_native_concat('user_dir')) == 'user_dir'


# Generated at 2022-06-25 12:22:58.906937
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'user_dir'
    var_0 = ansible_native_concat(str_0)
    assert type(var_0) == str
    assert var_0 == 'user_dir'
    str_1 = u'user_dir'
    var_1 = ansible_native_concat(str_1)
    assert type(var_1) == str
    assert var_1 == 'user_dir'
    str_2 = 'user_dir'
    str_3 = u'user_dir'
    var_2 = ansible_native_concat([str_2, str_3])
    assert type(var_2) == str
    assert var_2 == 'user_diruser_dir'



# Generated at 2022-06-25 12:23:00.490720
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0()



# Generated at 2022-06-25 12:23:10.982947
# Unit test for function ansible_native_concat

# Generated at 2022-06-25 12:23:18.041414
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert to_text(ansible_native_concat('foo\n')) == 'foo\n'
    assert to_text(ansible_native_concat('foo', 'bar')) == 'foobar'
    assert to_text(ansible_native_concat('foo', '\n', 'bar')) == 'foo\nbar'
    assert ansible_native_concat('True') is True
    assert ansible_native_concat('False') is False
    assert ansible_native_concat('0') == 0
    assert ansible_native_concat('-1') == -1
    assert ansible_native_concat('1') == 1
    assert ansible_native_concat("'1'") == '1'
    assert ansible_native_concat("'a'") == 'a'


# Generated at 2022-06-25 12:23:19.731252
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'user_dir'
    var_0 = ansible_native_concat(str_0)

# Generated at 2022-06-25 12:23:20.359667
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()

# Generated at 2022-06-25 12:23:29.115738
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Example from the documentation
    a = [1, 2, 3]
    b = [4, 5, 6]
    result = ':'.join(ansible_native_concat([a, b]))

    # Example from the documentation
    c = 'foo'
    d = {'some': 'value'}
    e = 'bar'
    result = '-'.join(ansible_native_concat([c, d, e]))

    # Example from the documentation
    f = [1, 2, 3]
    result = '-'.join(ansible_native_concat([f]))

    # Example from the documentation
    g = 'foo'
    h = {'some': 'value'}
    i = 'bar'

# Generated at 2022-06-25 12:23:32.562942
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_1 = to_text(ansible_native_concat('user_dir') + ansible_native_concat('/'))
    assert var_1 == '/home/user/'
    var_2 = to_text(ansible_native_concat(ansible_native_concat('user_dir')) + ansible_native_concat('/'))
    assert var_2 == '/home/user/'


# Generated at 2022-06-25 12:23:42.576722
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # test cases
    test_cases = []
    test_cases.append([
        'user_dir',
        'user_dir'
    ])
    test_cases.append([
        [
            'user_dir'
        ],
        'user_dir'
    ])
    test_cases.append([
        [
            'user_dir',
            '',
            'my_dir'
        ],
        'user_dirmy_dir'
    ])
    test_cases.append([
        [
            [
                'user_dir',
                '',
                'my_dir'
            ]
        ],
        'user_dirmy_dir'
    ])

# Generated at 2022-06-25 12:23:47.906866
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert str(test_case_0()) == str('user_dir')

# Generated at 2022-06-25 12:23:57.071235
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'user_dir'
    var_0 = ansible_native_concat(str_0)

    assert 'user_dir' == var_0
    assert '[\'a\', \'b\', \'c\']' == str(list(ansible_native_concat(list('abc'))))
    assert 'a' == str(ansible_native_concat(['a']))
    assert '[1, 2, 3]' == str(ansible_native_concat(['1', '', '2', '', '3']))
    assert '1' == str(ansible_native_concat(['1']))
    assert '3' == str(ansible_native_concat(['', '', '3']))
    assert 'True' == str(ansible_native_concat(['True']))


# Generated at 2022-06-25 12:24:03.082792
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'user_dir'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == str_0
    str_0 = 'user_dir'
    var_0 = ansible_native_concat([str_0])
    assert var_0 == str_0

# Generated at 2022-06-25 12:24:06.450591
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert callable(ansible_native_concat)
    assert isinstance(ansible_native_concat(test_case_0.var_0), string_types)
    assert 'user_d' in ansible_native_concat(test_case_0.var_0)

# Generated at 2022-06-25 12:24:08.391063
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    native_str_0 = ansible_native_concat(str_0)

    assert native_str_0 is str_0

# Generated at 2022-06-25 12:24:09.554634
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['user_dir']) == 'user_dir'

# Generated at 2022-06-25 12:24:18.788876
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Here we can test if ansible_native_concat() works as expected

    undefined = StrictUndefined
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['test']) == 'test'
    assert ansible_native_concat(['1', '2']) == 12
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['False', 'False']) is False
    assert ansible_native_concat(['True', 'True']) is True
    assert ansible_native_concat(['1', '2', '3']) == 123
    assert ansible_native_concat(['test', undefined]) == 'test'

# Generated at 2022-06-25 12:24:21.078428
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('user_dir') == 'user_dir'



# Generated at 2022-06-25 12:24:22.299208
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat is not None



# Generated at 2022-06-25 12:24:29.842780
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Testing multiple cases.
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()

        # TODO send unvaulted data to literal_eval?

# Generated at 2022-06-25 12:24:33.425809
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert True == False

# Generated at 2022-06-25 12:24:35.236317
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('user_dir') == 'user_dir'



# Generated at 2022-06-25 12:24:42.074988
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test with simple string
    str_0 = 'user_dir'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'user_dir'

    # Test with string containing Jinja variable
    str_0 = '{{ user_dir }}'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == '{{ user_dir }}'

    # Test with list of strings
    str_0 = [
        '#!/usr/bin/python',
        '',
        'import sys',
        '',
        'total_bytes_read = 0',
    ]
    var_0 = ansible_native_concat(str_0)

# Generated at 2022-06-25 12:24:47.658309
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_arg_0 = 'username'
    var_arg_1 = '-'
    var_arg_2 = 'id'
    var_arg_3 = 1
    var_arg_4 = 'user'
    var_arg_5 = 'dir'
    var_arg_6 = var_arg_0
    var_arg_7 = var_arg_1
    var_arg_8 = var_arg_2
    var_arg_9 = var_arg_3
    var_arg_10 = var_arg_4
    var_arg_11 = var_arg_5

    var_0 = ansible_native_concat(var_arg_0)
    var_0 = ansible_native_concat(var_arg_1)

# Generated at 2022-06-25 12:24:48.700683
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['user_dir']) == 'user_dir'

# Generated at 2022-06-25 12:24:52.822540
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    change_dir_0 = 'user_dir'
    change_dir_1 = 'user_dir'
    change_dir_2 = 'user_dir'

    test_case_0(change_dir_0, change_dir_1, change_dir_2)

# Generated at 2022-06-25 12:24:59.687115
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    curr_path = os.path.dirname(os.path.abspath(__file__)) + '/test_cases/'
    filenames = ['test_case_0']
    for i in range(len(filenames)):
        filename = curr_path + filenames[i] + '.txt'
        fp = open(filename, 'r')
        code_obj = compile(fp.read(), filename, 'exec')
        fp.close()
        exec(code_obj)
        assert(globals()['var_' + str(i)] == globals()['str_' + str(i)])


# Generated at 2022-06-25 12:25:09.257355
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert to_text(ansible_native_concat(('a'))) == 'a'
    assert to_text(ansible_native_concat(('a', 'b'))) == 'ab'
    assert to_text(ansible_native_concat(('a', 'b', 'c'))) == 'abc'

    assert to_text(ansible_native_concat(('a', True, 'b', 'c'))) == 'abc'

    assert ansible_native_concat(('a', 'a')) == ['a', 'a']
    assert ansible_native_concat(('a', 'b', 'a')) == 'aba'

    assert ansible_native_concat(('a', 'a', ['b', 'b'])) == ['a', 'a', 'bb']
    assert ansible_native

# Generated at 2022-06-25 12:25:11.557465
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert 'user_dir' == ansible_native_concat('user_dir')


# Generated at 2022-06-25 12:25:13.343258
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert 'user_dir' == ansible_native_concat('user_dir')
    assert 'user_dir' == ansible_native_concat('user_')



# Generated at 2022-06-25 12:25:17.544168
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat() == 'None'

# Generated at 2022-06-25 12:25:23.937704
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Create mock object for args
    mock_args = ['arg1', 'arg2']

    # Create mock object for kwargs
    mock_kwargs = {'keyword_arg1': ['value_1', 'value_2'],
                   'keyword_arg2': 'value_3'}

    # Attempt to call function
    # This will fail and print the stacktrace
    config_data = {}
    try:
        ansible_native_concat(config_data)
    except Exception:
        assert False
    return True

# Generated at 2022-06-25 12:25:30.090640
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert callable(ansible_native_concat)
    assert isinstance(ansible_native_concat(str_0), string_types)
    assert ansible_native_concat(str_0) == 'user_dir'


str_1 = 'plugin_0'
str_2 = 'plugins'
str_3 = '_filter'
str_4 = '_textfilter'
str_5 = '_map'
str_6 = 'yaml'
str_7 = 'yaml_dict'
str_8 = 'dictsort'
str_9 = 'sort'


# Generated at 2022-06-25 12:25:33.202518
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    data = 'user_dir'
    expected = 'user_dir'
    output = ansible_native_concat(data)
    assert output == expected

# Generated at 2022-06-25 12:25:34.821803
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == 'user_dir', 'The expected return is not coming back'


# Generated at 2022-06-25 12:25:37.548451
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # assert function return
    assert ansible_native_concat()

    # assert function call
    assert ansible_native_concat()

# Generated at 2022-06-25 12:25:38.654236
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()



# Generated at 2022-06-25 12:25:40.398945
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['user_dir']) == 'user_dir'


# Generated at 2022-06-25 12:25:48.720153
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """
    Verify that ansible_native_concat returns the first value if there is only one value in nodes
    and returns a concatenation of the values if there are multiple values in nodes
    :return: none
    """
    str_0 = 'user_dir'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'user_dir'
    int_0 = 1
    var_1 = ansible_native_concat(int_0)
    assert var_1 == 1
    str_1 = 'some string'
    var_2 = ansible_native_concat(str_0 + str_1)
    assert var_2 == 'user_dirsome string'
    str_2 = 'another string'
    int_1 = 2
    var_3 = ansible_native

# Generated at 2022-06-25 12:25:50.226699
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'user_dir'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == str_0



# Generated at 2022-06-25 12:25:55.072375
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == [('user_dir', "user_dir")]

# Generated at 2022-06-25 12:25:56.279915
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('user_dir') == 'user_dir'

# Generated at 2022-06-25 12:25:59.329983
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['user_dir']) == 'user_dir', 'Expected value \'user_dir\' not returned'

# Generated at 2022-06-25 12:26:01.679333
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # This is a placeholder so that we can test some random things
    # to help development.
    test_case_0()

    # TODO generate random strings for str_0



# Generated at 2022-06-25 12:26:11.308370
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = 'user_dir'
    var_1 = ansible_native_concat(var_0)
    assert var_0 == var_1
    var_0 = 'path'
    var_1 = ansible_native_concat(var_0)
    assert var_0 == var_1
    var_0 = 'subkey'
    var_1 = ansible_native_concat(var_0)
    assert var_0 == var_1
    var_0 = 'subsubkey'
    var_1 = ansible_native_concat(var_0)
    assert var_0 == var_1
    var_0 = 'subsubsubkey'
    var_1 = ansible_native_concat(var_0)
    assert var_0 == var_1

# Generated at 2022-06-25 12:26:15.243377
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Mock function and variables
    my_dummy_text = 'dummy text'
    my_dummy_type = type(my_dummy_text)

    # Set up mock
    # Run function
    my_result = ansible_native_concat(my_dummy_type)

    # Verify results
    assert my_result == my_dummy_type

# Generated at 2022-06-25 12:26:16.329701
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(str_0) == var_0

# Generated at 2022-06-25 12:26:26.375786
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    str_0 = 'yum'
    str_1 = 'user_dir'
    str_2 = '/etc/yum.conf'
    dict_0 = {}
    dict_0['x'] = 'x'
    dict_0['y'] = 'y'
    dict_0['z'] = 'z'
    dict_0['j'] = str_2
    dict_0['k'] = str_1
    list_0 = {}
    list_0['a'] = 'a'
    list_0['b'] = 'b'
    list_0['c'] = 'c'
    list_0['d'] = str_2
    list_0['e'] = str_1
    list_1 = {}
    list_1['a'] = dict_0
    list_1['b'] = list_0

# Generated at 2022-06-25 12:26:35.782257
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from unittest import TestCase

    # Ansible UndefinedError
    assert_ansible_undefined_error = lambda msg, method, *args: TestCase().assertRaisesRegexp(
        AnsibleUndefinedVariable, msg, method, *args
    )

    # Assert AnsibleUndefinedError
    assert_ansible_undefined_error('"msg"', assert_ansible_undefined_error, '"msg"', lambda: None)

    # Assert Method
    assert_ansible_method = lambda expected, method, *args: TestCase().assertEqual(method(*args), expected)

    # Assert TypeError undefined
    assert_ansible_type_error = lambda msg, method, *args: TestCase().assertRaisesRegexp(
        TypeError, msg, method, *args
    )

    # Ass

# Generated at 2022-06-25 12:26:39.564184
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var = ansible_native_concat('user_dir')
    assert var == 'user_dir'


# Generated at 2022-06-25 12:26:52.330873
# Unit test for function ansible_native_concat

# Generated at 2022-06-25 12:26:59.980985
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'user_dir'
    var_0 = ansible_native_concat(str_0)
    val_0 = 'user_dir'
    assert var_0 == val_0
    dict_0 = {'user_dir': '/usr/home'}
    val_0 = dict_0
    assert dict_0 == val_0
    dict_0 = {'user_dir': '/usr/home'}
    val_0 = dict_0
    assert dict_0 == val_0
    dict_0 = {'user_dir': '/usr/home'}
    val_0 = dict_0
    assert dict_0 == val_0


# Generated at 2022-06-25 12:27:03.131721
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Unit test for function ansible_native_concat
    str_0 = 'user_dir'
    var_0 = ansible_native_concat(str_0)

# Generated at 2022-06-25 12:27:05.497276
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test the ansible_native_concat function."""
    assert ansible_native_concat(['user_dir']) == 'user_dir'



# Generated at 2022-06-25 12:27:18.015428
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'user_dir'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'user_dir'
    str_0 = "{{ inventory_dir }}"
    var_0 = ansible_native_concat(str_0)
    assert var_0 == "{{ inventory_dir }}"
    str_0 = "{{ facts_dir }}"
    var_0 = ansible_native_concat(str_0)
    assert var_0 == "{{ facts_dir }}"
    str_0 = "{% raw %}{{ stone_age }}{% endraw %}"
    var_0 = ansible_native_concat(str_0)
    assert var_0 == "{% raw %}{{ stone_age }}{% endraw %}"

# Generated at 2022-06-25 12:27:18.821415
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert(type(test_case_0()) == str)

# Generated at 2022-06-25 12:27:27.999778
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    datadir = os.path.dirname(os.path.dirname(__file__))

    unitdir = os.path.join(datadir, "unit")
    testdir = os.path.join(datadir, "test")

    funcname = "ansible_native_concat"

    data = json.load(open(os.path.join(unitdir, funcname + ".json")))

    for testcase in data:
        test_id = testcase["test_id"]
        in_ = testcase["in"]
        expected = testcase["expected"]

        out = ansible_native_concat(in_)

        print("Testcase {}: out = {}, expected = {}".format(test_id, out, expected))

# Generated at 2022-06-25 12:27:34.976366
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_cases = [{'args': ["'var'", 'var_', 't'],
                   'kwargs': {"kw_0": 'var_',
                              "kw_1": 't'},
                   'expected': "vart"},
                  {'args': [],
                   'kwargs': {},
                   'expected': None}
                  ]

    for test_case in test_cases:
        assert ansible_native_concat(*test_case['args'], **test_case['kwargs']) == test_case['expected']

# Generated at 2022-06-25 12:27:36.024068
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    pass


# Generated at 2022-06-25 12:27:45.402264
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(None) is None
    assert ansible_native_concat('user_dir') == 'user_dir'
    assert ansible_native_concat('user_dir', 's_dir') == 'user_dirs_dir'
    assert ansible_native_concat('user_dir', 's_dir', 'break') == 'user_dirs_dirbreak'
    assert ansible_native_concat('user', '_dir', 's_dir', 'break') == 'user_dirs_dirbreak'
    assert ansible_native_concat('user_dir', 's_dir', 'break') == 'user_dirs_dirbreak'

# Generated at 2022-06-25 12:27:57.385512
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = 'user_dir'
    var_1 = ansible_native_concat(var_0)
    assert isinstance(var_1, str)

    var_2 = "Invalid"
    var_3 = ansible_native_concat(var_2)
    assert var_3 == "Invalid"

    class Var_4:
        def __init__(self, value):
            self.value = value

    var_4 = Var_4(1)
    var_5 = ansible_native_concat(var_4)
    assert var_5 is var_4

    var_6 = True
    var_7 = ansible_native_concat(var_6)
    assert var_7 is var_6

    var_8 = False

# Generated at 2022-06-25 12:27:59.265035
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Setup
    str_0 = 'user_dir'

    # Exercise
    var_0 = ansible_native_concat(str_0)

    # Verify
    assert var_0 == 'user_dir'

# Generated at 2022-06-25 12:28:08.640946
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['user_dir']) == 'user_dir'
    assert ansible_native_concat(['user_dir', '=', u"{{ lookup('env', 'HOME') }}"]) == 'user_dir={{ lookup(\'env\', \'HOME\') }}'
    assert ansible_native_concat([-2.039001867770856]) == -2.039001867770856
    assert ansible_native_concat(['0.0']) == 0.0
    # assert ansible_native_concat([True]) == True
    assert ansible_native_concat(['192.168.0.1']) == '192.168.0.1'
    assert ansible_native_concat('user_dir') == 'user_dir'
    assert ans

# Generated at 2022-06-25 12:28:09.400862
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert var_0 == str_0, 'test_ansible_native_concat failed'

# Generated at 2022-06-25 12:28:10.415179
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'user_dir'
    var_0 = ansible_native_concat(str_0)

# Generated at 2022-06-25 12:28:11.401712
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert 'user_dir' == ansible_native_concat('user_dir')

# Generated at 2022-06-25 12:28:15.005232
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert callable(ansible_native_concat)
    # Test case 0
    str_0 = 'user_dir'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == u'user_dir'



# Generated at 2022-06-25 12:28:23.754563
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'user_dir'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'user_dir'

    str_0 = 'user_dir'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'user_dir'

    str_0 = 'user_dir'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'user_dir'

    str_0 = 'user_dir'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'user_dir'

    str_0 = 'user_dir'
    var_0 = ansible_native_concat(str_0)

# Generated at 2022-06-25 12:28:32.519054
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_1 = 'user_dir'
    var_1 = ansible_native_concat(str_1)
    print(var_1)
    str_2 = 'user_dir'
    str_3 = '/tmp'
    var_2 = ansible_native_concat(str_2, str_3)
    print(var_2)
    str_4 = 'user_dir'
    str_5 = 'is'
    str_6 = 'now'
    str_7 = '/tmp'
    var_3 = ansible_native_concat(str_4, str_5, str_6, str_7)
    print(var_3)
    obj_4 = 'foo'
    var_4 = ansible_native_concat(obj_4)
    print(var_4)
   

# Generated at 2022-06-25 12:28:40.458283
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Test case for ansible native concat
    # Test case for ansible native concat with dict
    try:
        dict_0 = {'user_dir': '/Users/ansible'}
        var_0 = ansible_native_concat(dict_0)
        assert var_0 == dict_0
    except AssertionError:
        raise AssertionError(container_to_text(dict_0))

    # Test case for ansible native concat with list
    try:
        list_0 = ['user_dir', '/Users/ansible']
        var_0 = ansible_native_concat(list_0)
        assert var_0 == list_0
    except AssertionError:
        raise AssertionError(container_to_text(list_0))

    # Test case for ansible native concat

# Generated at 2022-06-25 12:28:54.421115
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'user_dir'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'user_dir'

    str_1 = 'user_dir'
    str_2 = ' '

    var_1 = ansible_native_concat(str_1)
    var_2 = ansible_native_concat(str_2)

    var_3 = ansible_native_concat(var_1)
    var_4 = ansible_native_concat(var_2)

    var_5 = ansible_native_concat(var_3)
    var_6 = ansible_native_concat(var_4)

    var_7 = ansible_native_concat(var_5)

# Generated at 2022-06-25 12:29:04.637629
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'user_dir'
    var_0 = ansible_native_concat(str_0)
    str_1 = var_0
    assert str_1 == 'user_dir'

    str_2 = '{{ var_0 }}'
    var_1 = ansible_native_concat(str_2)
    assert isinstance(var_1, str) and var_1 == '{{ var_0 }}'

    str_3 = '{{ var_0 }}'
    var_2 = ansible_native_concat(str_3)
    assert isinstance(var_2, str) and var_2 == '{{ var_0 }}'

    str_4 = ''
    var_3 = ansible_native_concat(str_4)
    str_5 = var_3

# Generated at 2022-06-25 12:29:11.884744
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'user_dir'
    var_0 = ansible_native_concat(str_0)
    assert type(var_0) == str
    assert var_0 == 'user_dir'

    str_0 = 'user_dir'
    str_1 = ':'
    str_2 = '/home/foo'
    var_0 = ansible_native_concat(str_0, str_1, str_2)
    assert type(var_0) == str
    assert var_0 == 'user_dir:/home/foo'

    str_0 = 'user_dir'
    str_1 = ':'
    str_2 = '/home/foo'
    var_0 = ansible_native_concat(str_0, str_1, str_2)
    assert type(var_0)