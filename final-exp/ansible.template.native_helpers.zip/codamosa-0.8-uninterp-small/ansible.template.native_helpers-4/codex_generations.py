

# Generated at 2022-06-25 12:19:18.173578
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    text1 = to_text("This is a text")
    text2 = to_text("This is another text")
    concat_text = ansible_native_concat([text1, text2])
    assert to_text(concat_text) == to_text("This is a textThis is another text")

    int1 = 42
    int2 = 1
    concat_int = ansible_native_concat([int1, int2])
    assert concat_int == "421"

    list = [int1, int2]
    concat_list = ansible_native_concat(list)
    assert concat_list == "421"

    dict = { 'a' : int1 }
    concat_dict = ansible_native_concat(dict)

# Generated at 2022-06-25 12:19:29.334704
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(int(2167)) == container_to_text(2167)
    assert ansible_native_concat(int('2336')) == container_to_text(int('2336'))
    assert isinstance(ansible_native_concat(int('2336')), text_type)
    assert ansible_native_concat(int('1731')) == container_to_text(int('1731'))
    assert isinstance(ansible_native_concat(int('1731')), text_type)
    assert ansible_native_concat(int('2941')) == container_to_text(int('2941'))
    assert isinstance(ansible_native_concat(int('2941')), text_type)

# Generated at 2022-06-25 12:19:38.695630
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    result = ansible_native_concat(2)
    assert isinstance(result, (int, long))
    assert result == 2

    result = ansible_native_concat(2.0)
    assert isinstance(result, float)
    assert result == 2.0

    result = ansible_native_concat("string")
    assert isinstance(result, string_types)
    assert result == "string"

    result = ansible_native_concat("{ 'a' : 2 }")
    assert isinstance(result, Mapping)
    assert result == { 'a' : 2 }

    result = ansible_native_concat("[ 1, 2, 3 ]")

# Generated at 2022-06-25 12:19:47.878840
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2]) == "12"
    assert ansible_native_concat([1, 2, 3]) == "123"
    assert ansible_native_concat([1, 2, 3, 4]) == "1234"
    assert ansible_native_concat([1, 2, 3, 4, 5]) == "12345"
    assert ansible_native_concat([1, 2, 3, 4, 5, 6]) == "123456"
    assert ansible_native_concat([1, 2, 3, 4, 5, 6, 7]) == "1234567"
    assert ansible_native_concat([1, 2, 3, 4, 5, 6, 7, 8]) == "12345678"

# Generated at 2022-06-25 12:19:52.775011
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    int_0 = 2167
    int_1 = 4122
    str_0 = u'\x25'
    tuple_0 = (int_0, int_1, str_0)
    var_0 = ansible_native_concat(tuple_0)
    assert var_0 == u'21674122%'



# Generated at 2022-06-25 12:19:56.468850
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert callable(ansible_native_concat)
    assert isinstance(ansible_native_concat(test_case_0()), int)
    assert test_case_0() == 2167
    assert ansible_native_concat(test_case_0()) == test_case_0()

# Generated at 2022-06-25 12:20:03.412489
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Basic tests for function ansible_native_concat
    assert ansible_native_concat(None) is None
    assert ansible_native_concat([]) is None

    int_0 = 2167
    var_0 = ansible_native_concat(int_0)
    assert var_0 == 2167
    assert type(var_0) == int
    assert container_to_text(var_0) == u'2167'

    # str_0 = '-0.03'
    str_0 = u'-0.03'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == -0.03
    assert type(var_0) == float
    assert container_to_text(var_0) == u'-0.03'

    str_0 = u

# Generated at 2022-06-25 12:20:14.731586
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = ansible_native_concat('hello')
    assert var_0 == 'hello'
    var_0 = ansible_native_concat([1, 2, 3, 4, 5])
    assert var_0 == [1, 2, 3, 4, 5]
    var_0 = ansible_native_concat([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
    assert var_0 == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    var_0 = ansible_native_concat([1, 2, 3, 4, 5, 6, 7, 8, 9])
    assert var_0 == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    var_0 = ansible_native_con

# Generated at 2022-06-25 12:20:16.628462
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    int_0 = 2167
    var_0 = ansible_native_concat(int_0)
    assert type(var_0) == int

# Generated at 2022-06-25 12:20:26.598306
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('foo') == 'foo'
    assert ansible_native_concat('foo', 'bar') == 'foobar'
    assert ansible_native_concat(u'fo\u00f6') == u'fo\u00f6'
    assert ansible_native_concat('fo', u'\u00f6') == u'fo\u00f6'
    assert ansible_native_concat(123, 'foo') == '123foo'
    assert ansible_native_concat('foo', 123) == 'foo123'
    assert ansible_native_concat(u'foo', 123) == u'foo123'
    assert ansible_native_concat(123, u'foo') == u'123foo'

# Generated at 2022-06-25 12:20:41.254705
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    int_0 = 2167
    var_0 = ansible_native_concat(int_0)
    assert var_0 == 2167
    str_0 = 'GtH'
    var_1 = ansible_native_concat(str_0)
    assert var_1 == 'GtH'
    int_1 = 2
    int_2 = 5
    var_2 = ansible_native_concat(int_1, int_2)
    assert var_2 == '25'
    list_0 = [1, 2, 3]
    var_3 = ansible_native_concat(list_0)
    assert var_3 == '[1, 2, 3]'
    str_1 = 'x0B'
    str_2 = 'j'
    var_4 = ansible_native_concat

# Generated at 2022-06-25 12:20:42.432458
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert container_to_text(test_case_0()) == text_type(2167)

# Generated at 2022-06-25 12:20:42.961135
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    pass


# Generated at 2022-06-25 12:20:45.355631
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """
    Passing an integer will return the integer.
    """
    assert test_case_0() == 2167


# Generated at 2022-06-25 12:20:52.930714
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    int_0 = 2167
    var_0 = ansible_native_concat(int_0)
    assert var_0 == 2167

    dict_0 = {
        "k0": "v0",
        "k1": "v1",
        "k2": "v2",
        "k3": "v3",
    }
    var_1 = ansible_native_concat(dict_0)
    assert var_1 == dict_0

    list_0 = [
        "myvar",
        "myvar1",
        "myvar2",
        "myvar3",
        "myvar4",
        "myvar5"
    ]
    var_2 = ansible_native_concat(list_0)
    assert var_2 == list_0

    bool_0 = True


# Generated at 2022-06-25 12:20:53.831630
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() is None

# Generated at 2022-06-25 12:20:56.454862
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    int_0 = 2167
    var_0 = ansible_native_concat(int_0)
    assert var_0 == 2167



# Generated at 2022-06-25 12:20:58.858683
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    int_0 = 2167
    var_0 = ansible_native_concat(int_0)


test_ansible_native_concat()

# Generated at 2022-06-25 12:21:01.201369
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == 2167, 'Expected and actual values do not match'

# Generated at 2022-06-25 12:21:03.459342
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    int_0 = 2167
    out_0 = ansible_native_concat(int_0)
    assert out_0 == 2167


# Generated at 2022-06-25 12:21:17.407813
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(b'foo') == 'foo'
    assert ansible_native_concat(b'foo\xe2\x80\x99') == 'foo\u2019'
    assert ansible_native_concat(b'foo\xe2\x80\x9c') == 'foo\u201c'
    assert ansible_native_concat(b'foo\xe2\x80\x9d') == 'foo\u201d'
    assert ansible_native_concat(b'foo\xe2\x80\x98') == 'foo\u2018'
    assert ansible_native_concat(b'foo\xe2\x80\x93') == 'foo\u2013'

# Generated at 2022-06-25 12:21:19.190886
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    args = {}
    retval = ansible_native_concat(args)
    print(retval)


# Generated at 2022-06-25 12:21:22.211478
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(b'$\x80+u\x9a\x10\xef{_"<') == b'$\x80+u\x9a\x10\xef{_"<'

# Generated at 2022-06-25 12:21:24.688961
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == b'$\x80+u\x9a\x10\xef{_"<'

# Generated at 2022-06-25 12:21:25.713129
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # TODO Add tests for this function
    pass

# Generated at 2022-06-25 12:21:28.415685
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    print('in test_ansible_native_concat')
    test_case_0()



# Generated at 2022-06-25 12:21:29.344403
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == bytes_0

# Generated at 2022-06-25 12:21:32.812943
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    source = b'$\x80+u\x9a\x10\xef{_"<'
    result = ansible_native_concat(source)
    assert result == b'$\x80+u\x9a\x10\xef{_"<'



# Generated at 2022-06-25 12:21:33.619484
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0()



# Generated at 2022-06-25 12:21:34.296358
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() is None

# Generated at 2022-06-25 12:21:39.322522
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('some string') == 'some string'

# Generated at 2022-06-25 12:21:43.933555
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    input_1 = b'$\x80+u\x9a\x10\xef{_"<'
    result_1 = ansible_native_concat(input_1)
    assert result_1 == '$\x80+u\x9a\x10\xef{_"<'



# Generated at 2022-06-25 12:21:52.971569
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Check that ansible_native_concat works on its own."""
    # Test cases
    # Argument: bytes_0
    bytes_0 = b'$\x80+u\x9a\x10\xef{_"<'
    var_0 = ansible_native_concat(bytes_0)
    assert container_to_text(var_0) == '$\x80+u\x9a\x10\xef{_"<'
    # Argument: dict_0
    dict_0 = {"param": "value"}
    var_1 = ansible_native_concat(dict_0)
    assert var_1 == {u'param': u'value'}
    # Argument: int_0
    int_0 = -67

# Generated at 2022-06-25 12:21:55.020644
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == b'$\x80+u\x9a\x10\xef{_"<'



# Generated at 2022-06-25 12:21:56.704549
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert isinstance(test_case_0(), bytes) == True



# Generated at 2022-06-25 12:21:58.818092
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    result = ansible_native_concat()
    assert isinstance(result, NoneType)



# Generated at 2022-06-25 12:22:08.802115
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    text = u'$\x80+u\x9a\x10\xef{_"<'

    converted = ansible_native_concat(text)
    assert isinstance(converted, text_type), 'conversion test with str type failed'
    assert converted == text, 'conversion test with str type failed'

    converted = ansible_native_concat(NativeJinjaText(text))
    assert isinstance(converted, NativeJinjaText), 'conversion test with NativeJinjaText type failed'
    assert converted == text, 'conversion test with NativeJinjaText type failed'

    converted = ansible_native_concat(True)
    assert isinstance(converted, bool), 'conversion test with bool type failed'
    assert converted is True, 'conversion test with bool type failed'

    converted

# Generated at 2022-06-25 12:22:16.212508
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    bytes_0 = b'$\x80+u\x9a\x10\xef{_"<'
    var_0 = ansible_native_concat(bytes_0)
    assert (var_0 == '$\x80+u\x9a\x10\xef{_"<')



# Generated at 2022-06-25 12:22:21.778705
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Assert that the result is a bytes object
    assert isinstance(test_case_0(), bytes)

    # Assert that the result is equal to the expected value
    expected_result = b'$\x80+u\x9a\x10\xef{_"<'
    result = test_case_0()
    assert result == expected_result



# Generated at 2022-06-25 12:22:30.588256
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert to_text(ansible_native_concat(b'abcd')) == 'abcd'
    assert to_text(ansible_native_concat(b'abcd')) == ansible_native_concat('abcd')
    assert to_text(ansible_native_concat(b'abcd', b'efgh')) == 'abcdefgh'
    assert to_text(ansible_native_concat(b'abcd', b'efgh')) == ansible_native_concat('abcd', 'efgh')
    assert ansible_native_concat(b'abcd', b'efgh') == b'abcdefgh'
    assert ansible_native_concat('abcd', 'efgh') == 'abcdefgh'

    assert ansible_native_concat() is None
   

# Generated at 2022-06-25 12:22:42.027456
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    bytes_0 = b'\x80 + u\x9a\x10\xef{_"<'
    var_0 = ansible_native_concat(bytes_0)
    assert not var_0

# Generated at 2022-06-25 12:22:45.012670
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = [1, 2, 3, 4, 5]
    with pytest.raises(StrictUndefined):
        assert ansible_native_concat(nodes)

# Generated at 2022-06-25 12:22:54.580967
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    result = ansible_native_concat(None)
    assert result == None
# Test for ansible_native_concat
#
# Example usage:
#
# from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
# from ansible_collections.notstdlib.moveitallout.plugins.module_utils.common.text.converters import ansible_native_concat as func
#
# class TestAnsibleNativeConcat(unittest.TestCase):
#     def test_ansible_native_concat(self):
#         result = func(parsed, expect)
#         self.assertEqual(result, expect)
#         self.assertTrue(isinstance(result, RealExpectedClass))
#         self.assertEqual(result.

# Generated at 2022-06-25 12:22:58.937183
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    comment_0 = '$\x80+u\x9a\x10\xef{_"<'
    value_0 = b'$\x80+u\x9a\x10\xef{_"<'
    bytes_0 = b'$\x80+u\x9a\x10\xef{_"<'
    var_0 = ansible_native_concat(bytes_0)


# Generated at 2022-06-25 12:23:09.608378
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """
    Test function to verify the functionality of ansible_native_concat function
    """
    # Bytes
    bytes_0 = b'$\x80+u\x9a\x10\xef{_"<'
    var_0 = ansible_native_concat(bytes_0)
    assert var_0 is not None
    assert var_0 == bytes_0

    # Strings
    string_0 = '$\x80+u\x9a\x10\xef{_"<'
    var_1 = ansible_native_concat(string_0)
    assert var_1 is not None
    assert var_1 == string_0

    # List of strings

# Generated at 2022-06-25 12:23:15.799900
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Raw bytes as input
    bytes_input_0 = b'$\x80+u\x9a\x10\xef{_"<'
    expected_result = b'$\x80+u\x9a\x10\xef{_"<'
    actual_result = ansible_native_concat(bytes_input_0)
    assert container_to_text(actual_result) == container_to_text(expected_result)
    # Unicode string as input
    bytes_input_1 = u'$\x80+u\x9a\x10\xef{_"<'
    expected_result = u'$\x80+u\x9a\x10\xef{_"<'
    actual_result = ansible_native_concat(bytes_input_1)
   

# Generated at 2022-06-25 12:23:18.677112
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert callable(ansible_native_concat)
    assert isinstance(ansible_native_concat(b'$\x80+u\x9a\x10\xef{_"<'), bytes)



# Generated at 2022-06-25 12:23:20.883925
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    bytes_0 = b'$\x80+u\x9a\x10\xef{_"<'
    var_0 = ansible_native_concat(bytes_0)

# Generated at 2022-06-25 12:23:29.572105
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test for string input.
    string_0 = '$\x80+u\x9a\x10\xef{_"<'
    var_0 = ansible_native_concat([string_0])
    assert var_0 == string_0

    # Test for bytes input.
    bytes_0 = b'$\x80+u\x9a\x10\xef{_"<'
    var_0 = ansible_native_concat(bytes_0)
    assert var_0 == string_0

    # Test for list input.
    list_0 = [b'$\x80+u\x9a\x10\xef{_"<']
    var_0 = ansible_native_concat(list_0)
    assert var_0 == string_0

    # Test for

# Generated at 2022-06-25 12:23:32.880191
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Test case 0
    ret_val = test_case_0()

    # Check that it returns something
    assert ret_val is not None

    print("Success: test_ansible_native_concat")



# Generated at 2022-06-25 12:23:38.414846
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert isinstance(ansible_native_concat(None), text_type)


# Generated at 2022-06-25 12:23:47.858879
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test with 0 parameters

    # Test with 1 parameters
    ret = ansible_native_concat(b"")
    assert ret == ""

    # Test with 2 parameters
    ret = ansible_native_concat([b"foo", b""])
    assert ret == "foo"

    # Test with 3 parameters
    a = [b"foo", b"bar", b""]
    ret = ansible_native_concat(a)
    assert ret == "foobar"

    # Test with 4 parameters
    a = [b"foo", b"bar", b"baz", b""]
    ret = ansible_native_concat(a)
    assert ret == "foobarbaz"

    # Test with 5 parameters

# Generated at 2022-06-25 12:23:57.082164
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes_0 = [None, None]
    var_0 = ansible_native_concat(nodes_0)
    assert isinstance(var_0, type(None))

    nodes_1 = [None, None]
    var_1 = ansible_native_concat(nodes_1)
    assert isinstance(var_1, type(None))

    nodes_2 = [False, 'python']
    var_2 = ansible_native_concat(nodes_2)
    assert isinstance(var_2, text_type)
    assert var_2 == 'Falsepython'

    nodes_3 = [{'name': {'first': 'Joe', 'last': 'Smith'}},
               {'name': {'last': 'Smith', 'first': 'Joe'}}]
    var_3 = ansible_

# Generated at 2022-06-25 12:24:07.975119
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Pass
    bytes_0 = b'$\x80+u\x9a\x10\xef{_"<'
    var_0 = ansible_native_concat(bytes_0)
    assert var_0 == b'$\x80+u\xa0\x10\xef{_"<'

    # Pass
    bytes_0 = b'\x0b\x8a\xac"\xac'
    var_0 = ansible_native_concat(bytes_0)
    assert var_0 == b'\x0b\x8a\xac"\xac'

    # Pass
    boolean_0 = True
    pstr_0 = 'n>'
    var_0 = ansible_native_concat(boolean_0, pstr_0)

# Generated at 2022-06-25 12:24:10.806653
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = b'$\x80+u\x9a\x10\xef{_"<'
    var_1 = ansible_native_concat(var_0)
    assert var_1 == var_0

# Generated at 2022-06-25 12:24:20.762103
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert isinstance(ansible_native_concat(""), string_types)
    assert isinstance(ansible_native_concat("list"), string_types)
    assert isinstance(ansible_native_concat("dict"), string_types)
    assert isinstance(ansible_native_concat("str"), string_types)
    assert isinstance(ansible_native_concat(["key1", "val1", "key2", "val2"]), string_types)
    assert isinstance(ansible_native_concat(["key1", "str", "key2", "dict"]), string_types)
    assert isinstance(ansible_native_concat(["key1", "dict", "key2", "list"]), string_types)

# Generated at 2022-06-25 12:24:26.387313
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_result = ansible_native_concat("$\x80+u\x9a\x10\xef{_\"<")
    assert test_result == "$\x80+u\x9a\x10\xef{_\"<"

    test_result = ansible_native_concat("$\x80+u\x9a\x10\xef{_\"<")
    assert test_result == "$\x80+u\x9a\x10\xef{_\"<"


# Generated at 2022-06-25 12:24:34.236845
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = b'$\x80+u\x9a\x10\xef{_"<'

# Generated at 2022-06-25 12:24:36.759231
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()

if __name__ == "__main__":
    test_ansible_native_concat()

# Generated at 2022-06-25 12:24:43.657141
# Unit test for function ansible_native_concat

# Generated at 2022-06-25 12:24:57.129096
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    x = b'$\x80+u\x9a\x10\xef{_"<'

    assert ansible_native_concat(x) == b"$\x80+u\x9a\x10\xef{_\"<"
    assert ansible_native_concat(b'\x80\xef') == b'\x80\xef'
    assert ansible_native_concat(b'\x80') == b'\x80'
    assert ansible_native_concat(b'\x80\n') == b'\x80\n'
    assert ansible_native_concat(b'True') == b'True'
    assert ansible_native_concat(b'\x80abc') == b'\x80abc'



# Generated at 2022-06-25 12:25:06.289636
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    result = ansible_native_concat(['1'])
    assert result == 1
    assert not isinstance(result, string_types)
    assert not isinstance(result, Mapping)
    assert isinstance(result, int)
    result = ansible_native_concat([1, 2])
    assert result == '12'
    assert isinstance(result, string_types)
    assert not isinstance(result, Mapping)
    assert not isinstance(result, int)
    result = ansible_native_concat([1, '2'])
    assert result == '12'
    assert isinstance(result, string_types)
    assert not isinstance(result, Mapping)
    assert not isinstance(result, int)
    result = ansible_native_concat(['1', 2])

# Generated at 2022-06-25 12:25:11.299290
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_ansible_native_concat.__name__ == 'test_ansible_native_concat'
    test_case_0()

# Generated at 2022-06-25 12:25:18.996520
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert container_to_text(ansible_native_concat(ast.literal_eval("[b'foo']"))) == u'foo'
    assert container_to_text(ansible_native_concat(ast.literal_eval("[b'foo', b'bar']"))) == u'foobar'
    assert container_to_text(ansible_native_concat(ast.literal_eval("[b'foo', 'bar']"))) == u'foobar'
    assert container_to_text(ansible_native_concat(ast.literal_eval("[b'foo', 123]"))) == u'foo123'


if __name__ == '__main__':
    from ansible.utils.profile import run_callprofiler
    run_callprofiler(globals())

# Generated at 2022-06-25 12:25:19.985400
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    print(test_case_0())

# Generated at 2022-06-25 12:25:27.084483
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_cases = [
        (0, b'$\x80+u\x9a\x10\xef{_"<', b'$\x80+u\x9a\x10\xef{_"<'),
        (1, [AnsibleVaultEncryptedUnicode(b'4')], b'4'),
    ]
    for index, inp, should_be in test_cases:
        with SetTest(index):
            # Call the function
            res = ansible_native_concat(inp)

            # Check if result is as expected
            assert_equal(res, should_be)

# Generated at 2022-06-25 12:25:35.060498
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    bytes_0 = b'$\x80+u\x9a\x10\xef{_"<'
    var_0 = ansible_native_concat(bytes_0)

    assert var_0 == '$\x80+u\x9a\x10\xef{\'_"<'

    var_1 = ansible_native_concat([])
    assert var_1 == None



# Generated at 2022-06-25 12:25:45.056749
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert b'$\x80+u\x9a\x10\xef{_"<' == ansible_native_concat(b'$\x80+u\x9a\x10\xef{_"<')
    assert u'$\x80+u\x9a\x10\xef{_"<' == ansible_native_concat(u'$\x80+u\x9a\x10\xef{_"<')
    assert b'$\x80+u\x9a\x10\xef{_"<' == ansible_native_concat(b'$\x80+u\x9a\x10\xef{_"<')
    assert b'$\x80+u\x9a\x10\xef{_"<'

# Generated at 2022-06-25 12:25:45.577362
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0()


# Generated at 2022-06-25 12:25:46.752861
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test function"""
    # Test case:
    test_case_0()

# Generated at 2022-06-25 12:26:02.300405
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import pytest
    # Input parameters
    nodes = b'$\x80+u\x9a\x10\xef{_"<'

    # Output
    output = None

    # Unit test
    with pytest.raises(Exception):
        assert ansible_native_concat(nodes) == output

# Generated at 2022-06-25 12:26:11.670786
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    unicode_0 = ansible_native_concat(u'\u03cd')
    unicode_1 = ansible_native_concat(u'\u03cd')
    assert unicode_0 == unicode_1

    assert ansible_native_concat(3) == 3
    assert ansible_native_concat(3.0) == 3.0

    result = ansible_native_concat(u'\u03cd' u'\u03cd')
    assert result == u'\u03cd\u03cd'

    result = ansible_native_concat(u'\u03cd' u'\u03cd', u'\u03cd')
    assert result == u'\u03cd\u03cd\u03cd'


# Generated at 2022-06-25 12:26:18.335084
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()


# Collect tests into test classes
ansible_native_concat_class = type('TestAnsibleNativeConcat', (object,), dict(test_ansible_native_concat=test_ansible_native_concat))

# Assign test classes/methods to test suites
ansible_native_concat_suite = unittest.TestLoader().loadTestsFromModule(ansible_native_concat_class())

# Collect test suites into test cases
ansible_native_concat_cases = unittest.TestSuite([ansible_native_concat_suite])

# Run test cases
unittest.TextTestRunner(verbosity=2).run(ansible_native_concat_cases)

# Generated at 2022-06-25 12:26:23.903769
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    actual = ansible_native_concat('$\x80+u\x9a\x10\xef{_"<')
    expected = b'$\x80+u\x9a\x10\xef{_"<'
    assert actual == expected

# Test generated from: ansible-base/lib/ansible/module_utils/common/text/converters.py

# Generated at 2022-06-25 12:26:28.481953
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert isinstance(
        ansible_native_concat('foo'),
        text_type
    ), 'Failed to create text_type with ansible_native_concat '  # noqa pylint: disable=line-too-long
    assert container_to_text(
        ansible_native_concat(42)
    ) == '42', 'Failed to create int with ansible_native_concat'
    assert container_to_text(
        ansible_native_concat(True)
    ) == 'True', 'Failed to create bool with ansible_native_concat'
    assert container_to_text(
        ansible_native_concat(1.2)
    ) == '1.2', 'Failed to create float with ansible_native_concat'

# Generated at 2022-06-25 12:26:37.173167
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # NativeJinjaText
    args = {
          'a': 'literal string',
    }
    result = ansible_native_concat(args)
    assert result == args
    result = container_to_text(result)
    assert result == '{"a": "literal string"}'

    # str
    args = {
          'a': 'literal string',
          'b': b"b'\xef\x83\xab\x0f\x1d\x0c\xd1",
    }
    result = ansible_native_concat(args)
    assert isinstance(result, text_type)

# Generated at 2022-06-25 12:26:43.420491
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Testing the type returned by ansible_native_concat
    assert_type = isinstance(test_case_0(), text_type)

    # Testing the value returned by ansible_native_concat
    assert_value = container_to_text(test_case_0())

    assert assert_type
    assert assert_value == '$\x80+u\x9a\x10\xef{_"<'



# Generated at 2022-06-25 12:26:47.757830
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    bytes_0 = b'$\x80+u\x9a\x10\xef{_"<'
    var_0 = ansible_native_concat(bytes_0)
    if bytes_0 != var_0:
        raise AssertionError("'bytes_0' is not equal to 'var_0'")


# Generated at 2022-06-25 12:26:48.668551
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == bytes_0

# Generated at 2022-06-25 12:26:50.815522
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    result = ansible_native_concat([])
    assert result == None

if __name__ == '__main__':
    test_ansible_native_concat()

# Generated at 2022-06-25 12:27:01.881934
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert False


# Generated at 2022-06-25 12:27:10.592617
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    out = ansible_native_concat(container_to_text(
        "string",
        b"string",
        to_text(u"string"),
        u"string",
    ))
    assert isinstance(out, string_types)
    assert out == "stringstringstringstring"

    out = ansible_native_concat(container_to_text(
        b"bytestring",
        b"bytestring",
    ))
    assert isinstance(out, string_types)
    assert out == "bytestringbytestring"

    out = ansible_native_concat(container_to_text(
        1,
        b'2',
        u"3",
        u"4",
        u"5",
        6,
        7,
        8,
    ))

# Generated at 2022-06-25 12:27:19.907421
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    bytes_0 = b'$\x80+u\x9a\x10\xef{_"<'
    bytes_1 = b'[\xd0\x9c\xd1\x87\xd0\xb0\xd1\x80\xd0\xb4\xd0\xb0\xd0\xb8\xd1\x80]'
    bytes_2 = b'\xbe\x17\xfe,\x9f'
    bytes_3 = b'."\xef\x89\x1a\x15\x05'
    bytes_4 = b'\\\x05'

# Generated at 2022-06-25 12:27:23.949111
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # TODO
    # assert run_ansible_native_concat(bytes_0) == b'$\x80+u\x9a\x10\xef{_"<'
    assert False


# TODO: Combine with similar function in module_utils.common.validation.

# Generated at 2022-06-25 12:27:32.048715
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(b'$\x80+u\x9a\x10\xef{_"<') == b'$\x80+u\x9a\x10\xef{_"<'
    assert ansible_native_concat(b'$\x80+u\x9a\x10\xef{_"<'.decode('utf-8')) == b'$\x80+u\x9a\x10\xef{_"<'
    assert ansible_native_concat([]) is None
    assert ansible_native_concat('\ufeff') == '\ufeff'

# Generated at 2022-06-25 12:27:42.564936
# Unit test for function ansible_native_concat

# Generated at 2022-06-25 12:27:51.717718
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Source data
    # Arguments
    bytes_0 = b'\x00\x10\x00\x80'
    # Arguments
    bytes_1 = b'\x00\x10\x00\x80\x00\x10\x00\x80'
    # Arguments
    bytes_2 = b'\x00\x10\x00\x80\x00\x10\x00\x80\x00\x10\x00\x80'
    # Arguments
    bytes_3 = b'\x00\x10\x00\x80\x00\x10\x00\x80\x00\x10\x00\x80\x00\x10\x00\x80'
    # Arguments

# Generated at 2022-06-25 12:28:00.289102
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    bits = container_to_text([1, 2, 3, 4, 5])
    assert ansible_native_concat(bits) == '12345'

    assert ansible_native_concat([]) is None

    assert ansible_native_concat([123]) == 123

    assert ansible_native_concat([123, 'a']) == '123a'

    assert ansible_native_concat(['a', 123]) == 'a123'

    bytes_0 = b'$\x80+u\x9a\x10\xef{_"<'

    assert ansible_native_concat(bytes_0) == b'$\x80+u\x9a\x10\xef{_"<'


# Generated at 2022-06-25 12:28:03.887634
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat("foobar".encode("base64", "strict")) == "foobar"
    assert ansible_native_concat("foobar".decode("base64", "strict")) == "foobar"

# Generated at 2022-06-25 12:28:04.742815
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0()



# Generated at 2022-06-25 12:28:14.610874
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert bytes_0 == b'$\x80+u\x9a\x10\xef{_"<'
    assert var_0 == b'$\x80+u\x9a\x10\xef{_"<'

# Generated at 2022-06-25 12:28:15.652845
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()



# Generated at 2022-06-25 12:28:17.320420
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """
    Fake test due to decryption with AnsibleVaultEncryptedUnicode
    """
    assert True

# Generated at 2022-06-25 12:28:25.606142
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    result = ansible_native_concat(b'A')
    assert result == 'A'

    result = ansible_native_concat(b'A', b'B')
    assert result == 'AB'

    result = ansible_native_concat(b'True')
    assert result is True

    result = ansible_native_concat(b'False')
    assert result is False

    result = ansible_native_concat(b'None')
    assert result is None

    result = ansible_native_concat(b'text')
    assert result == 'text'

    # Can't be parsed as bool
    result = ansible_native_concat(b'strue')
    assert result == 'strue'

    # Can't be parsed as int

# Generated at 2022-06-25 12:28:34.806349
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(b'\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00') == b'\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    assert ansible_native_concat(bytearray(b'\x02\x80\x00\x00')) == bytearray(b'\x02\x80\x00\x00')
    assert ansible_native_concat(b'\x01\x10\x00\x00\x00\x00\x00\x00') == b'\x01\x10\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-25 12:28:36.642884
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == b'$\x80+u\x9a\x10\xef{_"<'



# Generated at 2022-06-25 12:28:43.268155
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([[]]) is None

# Generated at 2022-06-25 12:28:48.190646
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(b'$\x80+u\x9a\x10\xef{_"<') == b'$\x80+u\x9a\x10\xef{_"<'


# Generated at 2022-06-25 12:28:51.908515
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    bytes_0 = b'$\x80+u\x9a\x10\xef{_"<'
    var_0 = ansible_native_concat(bytes_0)
    assert type(var_0) == bytes
    assert var_0 == b'$\x80+u\x9a\x10\xef{_"<'



# Generated at 2022-06-25 12:28:53.875304
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() is None


# Generated at 2022-06-25 12:29:09.951566
# Unit test for function ansible_native_concat