

# Generated at 2022-06-25 12:19:17.164306
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'D[}\x0cBxib~'

# Function ansible_native_concat may differ in behavior between Python 2 and Python 3
# because they use different versions of the jinja2 library.
# The Python 2 jinja2 library does not support Python 3 `yield from` syntax
# See https://github.com/ansible/ansible/issues/70894
# This test covers all cases for Python 2.
# In Python 3, it will only execute the first branch of the conditional.
# FIXME: Change test_ansible_native_concat to be identical in Python 2 and Python 3.
    if (1 != 0):
        if (1 != 0):
            if (1 != 0):
                if isinstance(str_0, str):
                    ansible_native_concat(str_0)
               

# Generated at 2022-06-25 12:19:28.315715
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = ansible_native_concat('')
    assert var_0 == ''
    var_1 = ansible_native_concat('1f2a')
    assert var_1 == '1f2a'
    var_2 = ansible_native_concat('c25a')
    assert var_2 == 'c25a'
    var_3 = ansible_native_concat('q3a4')
    assert var_3 == 'q3a4'
    var_4 = ansible_native_concat('a')
    assert var_4 == 'a'
    var_5 = ansible_native_concat('b')
    assert var_5 == 'b'
    var_6 = ansible_native_concat('c')
    assert var_6 == 'c'
    var_

# Generated at 2022-06-25 12:19:37.627188
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'D[}\x0cBxib~'
    var_0 = ansible_native_concat(str_0)
    str_1 = 'C\xc3k\x84\xcbZM\xddU'
    var_1 = ansible_native_concat(str_1)
    str_2 = '\xed\x0e\xff\x86\x8a\x1b\xc4\x90B+\x8b\xce)\x99\x1d\xfb'
    var_2 = ansible_native_concat(str_2)
    str_3 = '\x96\xd1\x82\x0e\x02\x18\x89\xdf\xfb\xca\x15W{K\x13'
   

# Generated at 2022-06-25 12:19:38.906131
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == 'D[}\x0cBxib~'

# Generated at 2022-06-25 12:19:40.859936
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == 'D[}\x0cBxib~'

# Generated at 2022-06-25 12:19:42.229926
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_ansible_native_concat()
    test_case_0()

# Generated at 2022-06-25 12:19:46.618852
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str0 = 'j'
    str1 = 'z'
    var0 = ansible_native_concat([str0, str1])
    assert var0 == 'jz'

    str0 = 'i'
    str1 = 'g'
    var1 = ansible_native_concat([str0, str1])
    assert var1 == 'ig'

# Generated at 2022-06-25 12:19:54.238405
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('D[}\x0cBxib~') == 'D[}\x0cBxib~'
    assert ansible_native_concat('D[}') == 'D[}'
    assert ansible_native_concat('Bxib~') == 'Bxib~'
    assert ansible_native_concat('') == None
    try:
        ansible_native_concat(None)
    except NameError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 12:19:58.636955
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(u'') == None
    assert ansible_native_concat(u'["foo"]') == [u"foo"]
    assert ansible_native_concat(u'1.0') == 1.0
    assert ansible_native_concat(u'1.0') == 1.0
    assert ansible_native_concat(u'foo') == u"foo"

# Generated at 2022-06-25 12:20:04.573881
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat("x00x") == "x00x"
    assert ansible_native_concat("x00x", "y00y") == "x00xy00y"
    assert ansible_native_concat(1, 2) == "12"
    assert ansible_native_concat(1, 2, 3) == "123"
    assert ansible_native_concat("1", "2") == "12"
    assert ansible_native_concat("1", "2", "3") == "123"
    assert ansible_native_concat(1, 2, 3, 4) == "1234"
    assert ansible_native_concat("1", "2", "3", "4") == "1234"

# Generated at 2022-06-25 12:20:09.962307
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'D[}\x0cBxib~'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == str_0

# Generated at 2022-06-25 12:20:12.552454
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = 'g\x14\x1c'
    assert ansible_native_concat(var_0) == var_0

# Generated at 2022-06-25 12:20:21.265470
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'D[}\x0cBxib~'
    var_0 = ansible_native_concat(str_0)
    str_1 = '@f\x0e\x17\x0b\x0cU\x1ble\r9\x12\nqV5D\x02\x02\x12'
    var_1 = ansible_native_concat(str_1)
    str_2 = 'u\x0bx|\x0b\x1d\x0bzip\x1a\x02\x04\x04\x0b\x00'
    var_2 = ansible_native_concat(str_2)

# Generated at 2022-06-25 12:20:23.346193
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_1 = 'D[}\x0cBxib~'
    var_1 = ansible_native_concat(str_1)

    assert var_1

# Generated at 2022-06-25 12:20:30.048108
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('D[}\x0cBxib~') == 'D[}\x0cBxib~'
    assert ansible_native_concat('D[}\x0cBxib~', 'D[}\x0cBxib~') == 'D[}\x0cBxib~D[}\x0cBxib~'
    assert ansible_native_concat(1) == 1
    assert ansible_native_concat(1, 2, 3) == '123'
    try:
        assert ansible_native_concat(1, [1, 2])
    except TypeError:
        pass

    assert ansible_native_concat(("E'\x13$\x14",)) == "E'\x13$\x14"
    assert ansible_

# Generated at 2022-06-25 12:20:41.174726
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    data_0 = True
    data_1 = b'\x12\x00\x00_\x00\x00\x00'

# Generated at 2022-06-25 12:20:42.029490
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert not test_case_0()

# Generated at 2022-06-25 12:20:50.887697
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Simple test case to check if native_concat correct with a string input
    str_0 = 'D[}\x0cBxib~'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'D[}\x0cBxib~'
    # Simple test case to check if native_concat correct with a integer input
    int_0 = 1139466426
    var_1 = ansible_native_concat(int_0)
    assert var_1 == 1139466426
    # Simple test case to check if native_concat correct with a float input
    float_0 = 1.3784327017636666e+293
    var_2 = ansible_native_concat(float_0)
    assert var_2 == 1.37843270176

# Generated at 2022-06-25 12:21:00.845428
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert 0 == (ansible_native_concat(()) is None)
    assert 1 == ((ansible_native_concat((('H4G\x15\n\t', 'RK\x16S\x0b\x15', 'i2\x1e\x10W['),)) == 'H4G\x15\n\tRK\x16S\x0b\x15i2\x1e\x10W[') is True)
    assert 0 == (ansible_native_concat(('H4G\x15\n\t', 'RK\x16S\x0b\x15', 'i2\x1e\x10W[')) is None)

# Generated at 2022-06-25 12:21:08.715783
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'D[}\x0cBxib~'
    var_1 = ansible_native_concat(str_0)
    assert var_1 == str_0
    str_0 = 'r\r\r'
    var_1 = ansible_native_concat(str_0)
    assert var_1 == str_0
    str_0 = '\x0b{'
    var_1 = ansible_native_concat(str_0)
    assert var_1 == str_0
    str_0 = '$ $\x00\x00H'
    var_1 = ansible_native_concat(str_0)
    assert var_1 == str_0


# Generated at 2022-06-25 12:21:15.188937
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()



# Generated at 2022-06-25 12:21:18.697324
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'D[}\x0cBxib~'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'D[}\x0cBxib~'
    var_1 = ansible_native_concat(var_0)
    assert var_1 == 'D[}\x0cBxib~'


# Generated at 2022-06-25 12:21:19.898228
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert isinstance(test_case_0(), string_types)

# Generated at 2022-06-25 12:21:20.839848
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert 1, test_case_0()

# Generated at 2022-06-25 12:21:31.436254
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = ansible_native_concat({})
    var_1 = ansible_native_concat('abcd')
    var_2 = ansible_native_concat('abcd', 1234)
    var_3 = ansible_native_concat('abcd', 1234, False, 1.2)
    var_4 = ansible_native_concat(['a', 'b', 'c', 'd'])
    assert var_0 is None
    assert var_1 == 'abcd'
    assert var_2 == 'abcd1234'
    assert var_3 == 'abcd1234False1.2'
    assert var_4 == 'abcd'
    with pytest.raises(NameError):
        ansible_native_concat(None)

# Generated at 2022-06-25 12:21:36.311868
# Unit test for function ansible_native_concat

# Generated at 2022-06-25 12:21:43.505520
# Unit test for function ansible_native_concat

# Generated at 2022-06-25 12:21:52.623187
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('test') == 'test'
    assert ansible_native_concat(('te', 'st')) == 'test'
    assert ansible_native_concat(0) == 0
    assert ansible_native_concat(('t', 'est')) == 'test'
    assert ansible_native_concat(123) == 123
    assert ansible_native_concat(['te', 'st']) == 'test'
    assert ansible_native_concat(False) == False
    assert ansible_native_concat(('te', 'st', 'abc')) == 'testabc'
    assert ansible_native_concat(['te', 'st', 'abc']) == 'testabc'
    assert ansible_native_concat(3) == 3
    assert ansible

# Generated at 2022-06-25 12:21:55.020920
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('D[}\x0cBxib~') == 'D[}\x0cBxib~'



# Generated at 2022-06-25 12:21:57.119525
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == "D[}\x0cBxib~"



# Generated at 2022-06-25 12:22:01.372706
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([True]) == True, 'Failed ansible_native_concat'


# ansible/module_utils/common/collections.py

# Generated at 2022-06-25 12:22:03.236410
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == 'D[}\x0cBxib~'

# Generated at 2022-06-25 12:22:05.956616
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['D[}\x0cBxib~']) == 'D[}\x0cBxib~'



# Generated at 2022-06-25 12:22:06.922724
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Shouldn't be implemented yet
    pass



# Generated at 2022-06-25 12:22:09.771543
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'D[}\x0cBxib~'
    var_0 = ansible_native_concat(str_0)
    assert var_0 is not None


# Generated at 2022-06-25 12:22:16.915972
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '~'
    assert ansible_native_concat(str_0) is None
    str_1 = 'A[\x06\x10B'
    var_1 = ansible_native_concat(str_1)
    str_2 = '[\x04\x07'
    str_3 = '!E3\x07\x0f\x00'
    str_4 = '+-=+$@1'
    str_5 = 'X\x01\x0c\x13'
    str_6 = '\x04A\x12\x0f'
    str_7 = '\\'
    str_8 = '\\'
    str_9 = '$'
    str_10 = '\x1f;F\x10\x13'
    str_

# Generated at 2022-06-25 12:22:26.670966
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    #assert test_case_0() == 'D[}\x0cBxib~'
    assert test_case_0() == 'D'
    assert ansible_native_concat(True) == True
    assert ansible_native_concat(0) == 0
    assert ansible_native_concat(1.0) == 1.0
    assert ansible_native_concat([]) == []
    assert ansible_native_concat(()) == ()
    assert ansible_native_concat({}) == {}
    assert ansible_native_concat('1') == 1
    assert ansible_native_concat('"1"') == "1"
    assert ansible_native_concat('{}') == {}
    assert ansible_native_concat('[]') == []
    assert ansible_native_

# Generated at 2022-06-25 12:22:33.855266
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert 'D[}\x0cBxib~' == ansible_native_concat('D[}\x0cBxib~')
    assert 'D[}\x0cBxib~' == ansible_native_concat(u'D[}\x0cBxib~')

    # TODO: This test shows that the output of the function is not
    # deterministic if the input is an encrypted string and there is
    # no vault password provided. We need to decide if this is a bug
    # or a feature, as you cannot call this function without a vault
    # password
    assert 'D[}\x0cBxib~' == ansible_native_concat(AnsibleVaultEncryptedUnicode('D[}\x0cBxib~'))
    assert 1 == ansible_native_concat

# Generated at 2022-06-25 12:22:43.873445
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    text = u"abc"
    assert ansible_native_concat([text]) == text

    var = {u"a": u"b"}
    assert ansible_native_concat([var]) == var

    var = [u"a", u"b"]
    assert ansible_native_concat([var]) == var

    var = (u"a", u"b")
    assert ansible_native_concat([var]) == var

    var = set([u"a", u"b"])
    assert ansible_native_concat([var]) == var

    var = frozenset([u"a", u"b"])
    assert ansible_native_concat([var]) == var

    var = 1
    assert ansible_native_concat([var]) == var

    var = 1.1
    assert ans

# Generated at 2022-06-25 12:22:54.216321
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    res = ansible_native_concat()
    assert res is None
    str_0 = 'D[}\x0cBxib~'
    var_0 = ansible_native_concat(str_0)
    assert container_to_text(var_0) == 'D[}\x0cBxib~'
    str_1 = '\xc4?\x9d@\x1d\x82\xd2'
    var_1 = ansible_native_concat(str_1)
    assert container_to_text(var_1) == '\xc4?\x9d@\x1d\x82\xd2'
    str_2 = '\xe1\xcd\x91\xbc\x12\xa2U'
    var_2 = ansible_native_concat

# Generated at 2022-06-25 12:23:01.916046
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Asserts that strings are properly handled
    str_1 = 'foo'
    var_1 = ansible_native_concat(str_1)
    assert var_1 == 'foo'

    str_2 = 'f'
    str_2 += 'o'
    str_2 += 'o'
    var_2 = ansible_native_concat(str_2)
    assert var_2 == 'foo'

    # Asserts that numbers are properly handled
    num_1 = '5'
    var_3 = ansible_native_concat(num_1)
    assert var_3 == 5

    num_2 = '5'
    num_2 += '0'
    var_4 = ansible_native_concat(num_2)
    assert var_4 == 50

    # Asserts that

# Generated at 2022-06-25 12:23:02.900638
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()

# Generated at 2022-06-25 12:23:12.478401
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert isinstance(ansible_native_concat('foo'), string_types)

    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['{{foo}}']) == '{{foo}}'
    assert ansible_native_concat(['{{foo', 'bar}}']) == '{{foo bar}}'
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['foo', '{{bar}}']) == u'foo{{bar}}'
    assert isinstance(ansible_native_concat(['foo', '{{bar}}']), text_type)


# Generated at 2022-06-25 12:23:18.871195
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'D[}\x0cBxib~'
    str_1 = 'D[}\x0cBxib~'
    str_2 = 'D[}\x0cBxib~'
    param_0 = ['Hi']
    param_1 = ['Hi']
    param_2 = ['Hi']
    param_3 = ['Hi']

    assert ansible_native_concat(str_0) == 'D[}\x0cBxib~'
    assert ansible_native_concat(str_1) == 'D[}\x0cBxib~'
    assert ansible_native_concat(str_0) == 'D[}\x0cBxib~'

# Generated at 2022-06-25 12:23:27.632897
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'D[}\x0cBxib~'
    var_0 = ansible_native_concat(str_0)
    assert isinstance(var_0, string_types)
    assert var_0 == 'D[}\x0cBxib~'

    str_0 = '^$yI\x17\x1b\\'
    var_0 = ansible_native_concat(str_0)
    assert isinstance(var_0, string_types)
    assert var_0 == '^$yI\x17\x1b\\'

    str_0 = 'H\x12\x17\x00>D'
    var_0 = ansible_native_concat(str_0)
    assert isinstance(var_0, string_types)
    assert var_0

# Generated at 2022-06-25 12:23:28.943172
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == 'D[}\x0cBxib~'



# Generated at 2022-06-25 12:23:34.554960
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'A\x18\x1e\r\r'
    var_0 = ansible_native_concat(str_0)

    assert var_0 == 'A\x18\x1e\x0d\x0d'

    str_0 = '\x1c\n\x06\x1f\x13\x18\x13\x14\t\x16'
    var_0 = ansible_native_concat(str_0)

    assert var_0 == '\x1c\n\x06\x1f\x13\x18\x13\x14\t\x16'

    str_0 = '\x14\x1e\x04\x18\x13\x06\x15\x09\x1e'
    var_0

# Generated at 2022-06-25 12:23:40.315795
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = '~ch\x0c\x14\x1b\x1bV\x15\x13'
    out_0 = '~ch\x0c\x14\x1b\x1bV\x15\x13'
    assert ansible_native_concat(var_0) == out_0



# Generated at 2022-06-25 12:23:42.719067
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert 'D[}\x0cBxib~' == ansible_native_concat('D[}\x0cBxib~')



# Generated at 2022-06-25 12:23:52.237642
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # This will be the variable used to store the result of the call to
    # the function
    result = None

    # This will store the result of the test. If we get an exception
    # then the test case fails, in all other cases it passes.
    is_pass = True

    try:
        # Call the function
        test_case_0()
    except Exception:
        # If an exception happens we need to check that it's an
        # AssertionError. If not, the test case fails
        is_pass = False
        # Get the traceback
        import traceback
        info = traceback.format_exc()

    # Assert that the result we got is what we expected
    assert result == expected_result, info

# Generated at 2022-06-25 12:24:02.500657
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'D[}\x0cBxib~'
    var_0 = ansible_native_concat(str_0)

# Generated at 2022-06-25 12:24:05.161630
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # str_0 = 'D[}\x0cBxib~'
    # var_0 = ansible_native_concat(str_0)
    # assert(var_0 == str_0)

    pass

# Generated at 2022-06-25 12:24:10.098470
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'D[}\x0cBxib~'
    str_1 = 'D[}\x0cBxib~'
    var_0 = ansible_native_concat(str_0)
    var_1 = container_to_text(var_0)
    try:
        assert var_1 == str_1
    except AssertionError:
        raise AssertionError(var_1)

# Generated at 2022-06-25 12:24:19.403533
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Example for function ansible_native_concat
    str_0 = 'D[}\x0cBxib~'
    str_1 = 'P\x1b\x02a\x0f'
    str_2 = '}\x1c\x1a\x0c{'
    str_3 = '\x01\x06\x1d\x1b'
    str_4 = '\x0e'
    str_5 = '\x02\x0ej\x0b'
    str_6 = '\x1d\x06\x07\x0f'
    var_0 = ansible_native_concat(str_0)
    var_1 = '\x1f\x0f\x02\x0c'

# Generated at 2022-06-25 12:24:22.378467
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'D[}\x0cBxib~'
    assert var_0 == 'D[}\x0cBxib~'


# Generated at 2022-06-25 12:24:26.348291
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Define a var with a string
    str_0 = 'D[}\x0cBxib~'

    # Define a call to the function
    call_0 = container_to_text(ansible_native_concat, str_0)
    assert text_type(call_0) == "\'D[}\x0cBxib~\'"

# Generated at 2022-06-25 12:24:27.705451
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Verify that no exceptions are raised by test_case_0()
    test_case_0()

# Generated at 2022-06-25 12:24:33.646795
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert '\x0c' == ansible_native_concat(bytes('\x0c', 'utf-8'))
    assert 'D[}\x0cBxib~' == ansible_native_concat('D[}\x0cBxib~')
    assert {} == ansible_native_concat('{}')
    assert [] == ansible_native_concat('[]')
    assert None is ansible_native_concat(None)
    assert 'ab' == ansible_native_concat(['a', 'b'])
    assert ['a', 'b'] == ansible_native_concat('["a", "b"]')
    assert 123 == ansible_native_concat(['1', '2', '3'])
    assert '123' == ansible_native_concat('123')


# Generated at 2022-06-25 12:24:34.750927
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert str_0 == var_0

test_ansible_native_concat()

# Generated at 2022-06-25 12:24:42.050972
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('a') == 'a'
    assert ansible_native_concat(1) == 1
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat({}) == {}
    assert ansible_native_concat(x=[1, 2, 3]) == {'x': [1, 2, 3]}

    str_0 = 'D[}\x0cBxib~'
    var_0 = ansible_native_concat(str_0)
    assert isinstance(var_0, text_type)
    assert not isinstance(var_0, (int, bool, list, dict, tuple))

    str_0 = 'D[}\x0cBxib~'

# Generated at 2022-06-25 12:24:46.475099
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test
    test_case_0()

# Generated at 2022-06-25 12:24:54.291492
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test to check whether the "ansible_native_concat" function returns the
    # correct value for the given input
    str_0 = '2Zd-LF4C'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == '2Zd-LF4C'

    str_0 = 'B[}\x0cBxib~'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'B[}\x0cBxib~'

    str_0 = 'D[j\nBxib~'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'D[j\nBxib~'


# Generated at 2022-06-25 12:25:03.757384
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """
    TODO: Description
    """
    str_0 = 'D[}\x0cBxib~'

    var_0 = ansible_native_concat(str_0)
    assert container_to_text(var_0) == str_0

    var_1 = ansible_native_concat(ansible_native_concat(str_0))
    assert container_to_text(var_1) == str_0


# Generated at 2022-06-25 12:25:06.533568
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'D[}\x0cBxib~'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'D[}\x0cBxib~'

# Generated at 2022-06-25 12:25:08.635255
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'D[}\x0cBxib~'
    var_0 = ansible_native_concat(str_0)



# Generated at 2022-06-25 12:25:12.365388
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
  arg_0 = "D[}\x0cBxib~"
  out_0 = ansible_native_concat(arg_0)
  out_1 = ansible_native_concat(arg_0)
  assert out_0 == out_1


# Generated at 2022-06-25 12:25:14.792182
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_1 = 'D\x0cBxib~'
    var_2 = ansible_native_concat(var_1)
    assert var_2 == 'D[}\x0cBxib~'


# Generated at 2022-06-25 12:25:17.011710
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_0 = ansible_native_concat('D[}\x0cBxib~')
    assert test_0 == container_to_text(test_0)

# Generated at 2022-06-25 12:25:25.995736
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'D[}\x0cBxib~'
    assert(ansible_native_concat(str_0) == 'D[}\x0cBxib~')

    str_0 = True
    assert(ansible_native_concat(str_0) == True)

    str_0 = 'e\xf1\xc0\x15\x1d\xa3\x0b\x8b'
    assert(ansible_native_concat(str_0) == 'e\xf1\xc0\x15\x1d\xa3\x0b\x8b')

    str_0 = 0.3
    assert(ansible_native_concat(str_0) == 0.3)


# Generated at 2022-06-25 12:25:32.495427
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_1 = 'D[}\x0cBxib~'
    var_1 = ansible_native_concat(str_1)
    assert var_1 == 'D[}\rBxib~'

    str_2 = None
    var_2 = ansible_native_concat(str_2)
    assert var_2 == None

    str_3 = 'T-T\u0005i'
    var_3 = ansible_native_concat(str_3)
    assert var_3 == 'T-T\u0005i'

    str_4 = "\u000cD[}\rBxib~"
    var_4 = ansible_native_concat(str_4)
    assert var_4 == "\u000cD[}\rBxib~"


# Generated at 2022-06-25 12:25:41.145397
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    string_0 = 'test string'
    assert ansible_native_concat([string_0]) == string_0, "Expected: %s, Got: %s" % (string_0, ansible_native_concat([string_0]))

    assert ansible_native_concat([1, 2]) == '12', "Expected: '12', Got: %s" % ansible_native_concat([1, 2])
    assert ansible_native_concat([1, 2, 3]) == '123', "Expected: '123', Got: %s" % ansible_native_concat([1, 2, 3])


# Generated at 2022-06-25 12:25:43.817479
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'D[}\x0cBxib~'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'D[}\x0cBxib~'

# Generated at 2022-06-25 12:25:51.401964
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert type(ansible_native_concat('codeWarrior')) == str
    assert ansible_native_concat(['[', 'a', ']', 'b']) == 'a'
    assert ansible_native_concat(['[', 'b', ']']) == 'b'
    assert ansible_native_concat([1, 'b']) == '1b'
    assert ansible_native_concat(['[', 'c', ']']) == 'c'
    assert ansible_native_concat('c') == 'c'
    assert ansible_native_concat('c') == 'c'
    assert ansible_native_concat(['[', 'a', ']', 'b']) == 'a'
    assert ansible_native_concat(['[', 'b', ']'])

# Generated at 2022-06-25 12:25:52.680618
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'D[}\x0cBxib~'
    var_0 = ansible_native_concat(str_0)

# Generated at 2022-06-25 12:25:55.476802
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'D[}\x0cBxib~'
    var_0 = ansible_native_concat(str_0)

    assert var_0 == 'xib'

# Generated at 2022-06-25 12:26:01.332123
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'D[}\x0cBxib~'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == "D[}\\x0cBxib~"
    var_1 = ansible_native_concat([str_0])
    assert var_1 == "D[}\\x0cBxib~"


# Generated at 2022-06-25 12:26:10.981843
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert '\u00c4\u00a4' == ansible_native_concat('"\xc4\xa4"')
    assert 2 == ansible_native_concat('1+1')
    assert 'a' == ansible_native_concat('"a"')
    assert 'true' == ansible_native_concat('true')
    assert '\u00c4\u00a4' == ansible_native_concat('"\xc4\xa4"')
    assert 2 == ansible_native_concat('1+1')
    assert 'a' == ansible_native_concat('"a"')
    assert 'true' == ansible_native_concat('true')

# Generated at 2022-06-25 12:26:15.332579
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Test case 0
    str_0 = 'D[}\x0cBxib~'
    var_0 = ansible_native_concat(str_0)
    assert container_to_text(var_0) == 'D[}\x0cBxib~', "Expected to get 'D[}\x0cBxib~', but got: %s" % container_to_text(var_0)

# Generated at 2022-06-25 12:26:25.197381
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_1 = u"some string"
    str_2 = u"another string"
    var_0 = ansible_native_concat([str_1, str_2])
    assert var_0 == u"some stringanother string"

    int_1 = 1
    int_2 = 2
    var_1 = ansible_native_concat([int_1, int_2])
    assert var_1 == u"12"

    # When passed a single element, the result is identical to the input
    var_2 = ansible_native_concat([int_1])
    assert var_2 == int_1

    # When passed an empty collection, None is returned
    var_3 = ansible_native_concat([])
    assert var_3 is None

    # When passed a mixed collection of lists and strings, the strings are

# Generated at 2022-06-25 12:26:28.064363
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = "v\x1b\x09\x0b'"
    var_0 = ansible_native_concat(str_0)
    assert var_0 == str_0



# Generated at 2022-06-25 12:26:34.857406
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert 'D[}\x0cBxib~' == ansible_native_concat('D[}\x0cBxib~')

    assert 'D[}\x0cBxib~' == ansible_native_concat('D[}\x0cBxib~')

# Generated at 2022-06-25 12:26:36.877354
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'D[}\x0cBxib~'
    var_0 = ansible_native_concat(str_0)


test_case_1()
test_ansible_native_concat()

# Generated at 2022-06-25 12:26:37.852349
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()



# Generated at 2022-06-25 12:26:43.157071
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == 'D[}\x0cBxib~'
    assert ansible_native_concat('test') == 'test'
    assert ansible_native_concat('test', 'test2') == 'testtest2'
    assert ansible_native_concat('test', 'test2') == 'testtest2'
    assert ansible_native_concat('test', 'test2') == 'testtest2'
    assert ansible_native_concat('test', 'test2') == 'testtest2'
    assert ansible_native_concat('test', 'test2') == 'testtest2'
    assert ansible_native_concat('test', 'test2') == 'testtest2'
    assert ansible_native_concat('test', 'test2') == 'testtest2'

# Generated at 2022-06-25 12:26:52.332007
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('D[}\x0cBxib~') == 'D[}\x0cBxib~'
    assert ansible_native_concat('%0a') == '%0a'
    assert ansible_native_concat('\a') == '\a'
    assert ansible_native_concat('G\f') == 'G\f'
    assert ansible_native_concat('\v') == '\v'
    assert ansible_native_concat('2{') == '2{'
    assert ansible_native_concat('@') == '@'
    assert ansible_native_concat('') == None
    assert ansible_native_concat('9') == '9'

# Generated at 2022-06-25 12:26:54.010716
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0()

# Generated at 2022-06-25 12:27:01.760335
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    answer = 'D[}\x0cBxib~'
    assert ansible_native_concat(answer) == answer
    answer = ''
    assert ansible_native_concat(answer) == answer

# Generated at 2022-06-25 12:27:04.918407
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'D[}\x0cBxib~'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'D[}\x0cBxib~'

# Generated at 2022-06-25 12:27:12.076671
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    ret = ansible_native_concat(ast.literal_eval(''))
    assert isinstance(ret, types.NoneType)

    ret = ansible_native_concat(ast.literal_eval('9'))
    assert isinstance(ret, int)
    assert ret == 9

    ret = ansible_native_concat(ast.literal_eval('"abc"'))
    assert isinstance(ret, text_type)
    assert ret == 'abc'

    ret = ansible_native_concat(ast.literal_eval('"abc" "def"'))
    assert isinstance(ret, text_type)
    assert ret == 'abcdef'

    ret = ansible_native_concat(ast.literal_eval('9 "def"'))
    assert isinstance(ret, text_type)
   

# Generated at 2022-06-25 12:27:14.860984
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    print('Test: test_ansible_native_concat')

    assert container_to_text(test_case_0()) == 'D[}\x0cBxib~'
    print('Test success')

# Generated at 2022-06-25 12:27:27.920912
# Unit test for function ansible_native_concat

# Generated at 2022-06-25 12:27:37.880896
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat("D[}\x0cBxib~") == 'D[}\x0cBxib~'
    assert ansible_native_concat("3") == 3
    assert ansible_native_concat("3.14") == 3.14
    assert ansible_native_concat("1J") == 1j
    assert ansible_native_concat("[1, 2, 3]") == [1, 2, 3]
    assert ansible_native_concat("{'x': 3, 'y': 4}") == {'x': 3, 'y': 4}
    assert ansible_native_concat("'''foo'''") == 'foo'
    assert ansible_native_concat("'''''foo''") == "'''foo"
    assert ansible_native_con

# Generated at 2022-06-25 12:27:47.020638
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(1) == 1
    assert ansible_native_concat(1.0) == 1.0
    assert ansible_native_concat(True) is True
    assert ansible_native_concat(False) is False
    assert ansible_native_concat(None) is None
    assert ansible_native_concat(str(1)) == 1
    assert ansible_native_concat(str(1.0)) == 1.0
    assert ansible_native_concat(str(True)) is True
    assert ansible_native_concat(str(False)) is False
    assert ansible_native_concat(str(None)) is None
    assert ansible_native_concat(10 * 'test') == 'test' * 10
    assert ansible_native_concat

# Generated at 2022-06-25 12:27:56.425092
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'D[}\x0cBxib~'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'D[}\x0cBxib~'
    str_0 = '5/'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == '5/'
    str_0 = 'c\x1bXbm-P'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'c\x1bXbm-P'
    str_0 = 'g{$'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'g{$'
    str_0 = 'T|'
   

# Generated at 2022-06-25 12:28:05.752588
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert 'a' == ansible_native_concat(['a'])
    assert 123 == ansible_native_concat([123])
    assert ['a', 'b'] == ansible_native_concat(['[', 'a', ',', 'b', ']'])
    assert {'key': 'value'} == ansible_native_concat(['{', '"key"', ':', '"value"', '}'])
    assert 'abc' == ansible_native_concat(['a', 'b', 'c'])
    assert 123 == ansible_native_concat(['1', '2', '3'])
    assert 'ab3' == ansible_native_concat(['a', 'b', 3])

# Generated at 2022-06-25 12:28:13.399121
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # concatenates an empty list with a string. Expected outcome should be a
    # string.
    str_0 = 'D[}\x0cBxib~'
    var_0 = ansible_native_concat(str_0)
    assert isinstance(var_0, text_type)

    # concatenates an empty tuple with a string. Expected outcome should be a
    # string.
    str_1 = '(Z\x12g\x1e#Q'
    var_1 = ansible_native_concat(str_1)
    assert isinstance(var_1, text_type)

    # concatenates a string with an int. Expected outcome should be a string.
    str_2 = 'A^'
    int_2 = 68

# Generated at 2022-06-25 12:28:20.642712
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'A\n'
    str_1 = 'B\n'
    tuple_0 = (str_0, str_1)
    var_0 = ansible_native_concat(tuple_0)
    assert repr(var_0) == "'A\\nB\\n'"

    dict_0 = {'key_1': 'A\n', 'key_0': 'B\n'}
    var_1 = ansible_native_concat(dict_0)
    assert repr(var_1) == "{'key_0': 'B\\n', 'key_1': 'A\\n'}"

# Generated at 2022-06-25 12:28:26.163634
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('\t~%c') == '\t~%c'
    assert ansible_native_concat('  F\x14&p4`\'\n') == '  F\x14&p4`\'\n'
    assert ansible_native_concat('\fQl1') == '\fQl1'
    assert ansible_native_concat('\fQl1') == '\fQl1'
    assert ansible_native_concat('\fQl1') == '\fQl1'
    assert ansible_native_concat('\fQl1') == '\fQl1'
    assert ansible_native_concat('\fQl1') == '\fQl1'

# Generated at 2022-06-25 12:28:27.641263
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """
    This function tests if the ansible_native_concat function
    """
    test_case_0()

# Generated at 2022-06-25 12:28:31.070757
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'D[}\x0cBxib~'
    var_0 = ansible_native_concat(str_0)
    print("%r" % var_0)



# Tests for function ansible_native_concat

# Generated at 2022-06-25 12:28:46.221935
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'D[}\x0cBxib~'
    var_0 = ansible_native_concat(str_0)
    str_1 = "D[}\x0cBxib~"
    var_1 = ansible_native_concat(str_1)
    str_2 = u'D[}\x0cBxib~'
    var_2 = ansible_native_concat(str_2)
    int_0 = -2
    var_3 = ansible_native_concat(int_0)
    int_1 = 0
    var_4 = ansible_native_concat(int_1)
    int_2 = 2
    var_5 = ansible_native_concat(int_2)
    long_0 = long(11)
    var_6

# Generated at 2022-06-25 12:28:55.454516
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    obj = 123
    var_0 = ansible_native_concat(obj)
    assert var_0 == 123
    obj = '123'
    var_0 = ansible_native_concat(obj)
    assert var_0 == 123
    obj = 'abc'
    var_0 = ansible_native_concat(obj)
    assert var_0 == 'abc'
    obj = 'foo'
    var_0 = ansible_native_concat(obj)
    assert var_0 == 'foo'
    obj = 'foo'
    var_0 = ansible_native_concat(obj)
    assert var_0 == 'foo'
    obj = '12'
    var_0 = ansible_native_concat(obj)
    assert var_0 == 12
    obj = 'leftside'
   

# Generated at 2022-06-25 12:28:57.564048
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'D[}\x0cBxib~'
    var_0 = ansible_native_concat(str_0)

# Generated at 2022-06-25 12:28:59.988358
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ast.literal_eval('D[}\x0cBxib~') == 'D[}\x0cBxib~'



# Generated at 2022-06-25 12:29:01.445728
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() is not None


# Generated at 2022-06-25 12:29:09.838825
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(container_to_text('a') + container_to_text('b')) == u'ab'
    assert ansible_native_concat([u'a', u'b']) == u'ab'
    assert ansible_native_concat(u'a' + u'b') == u'ab'
    assert ansible_native_concat(u'a') == u'a'
    assert ansible_native_concat(1) == 1
    assert ansible_native_concat(False) is False
    assert ansible_native_concat([1, 2]) == [1, 2]
    assert ansible_native_concat([u'a', u'b', 1, 2]) == [u'a', u'b', 1, 2]