

# Generated at 2022-06-25 12:19:18.619177
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = True
    var_1 = False
    var_2 = True
    var_3 = False
    var_0 = ansible_native_concat(var_0)
    var_1 = ansible_native_concat(var_1)
    var_2 = ansible_native_concat(var_2)
    var_3 = ansible_native_concat(var_3)
    args = [var_1, var_2, var_3]
    var_4 = ansible_native_concat(args)
    args = []
    var_5 = ansible_native_concat(args)
    args = ['hosts', 'localhost']
    var_6 = ansible_native_concat(args)
    args = ['', 'localhost']
    var_7 = ansible_native

# Generated at 2022-06-25 12:19:22.053623
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    args = [42]
    # FIXME: should be AnsibleTypeError
    kwargs = {}
    # FIXME: should be AnsibleUndefinedVariable
    out = ansible_native_concat(*args, **kwargs)
    assert out is None

# Generated at 2022-06-25 12:19:26.514541
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() is True

# Generated at 2022-06-25 12:19:32.131924
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = True
    var_1 = False
    var_2 = NativeJinjaText(u'0')
    var_3 = NativeJinjaText(u'1')
    var_4 = ansible_native_concat(var_0)
    # FIXME:
    #assert var_4 == True
    var_5 = ansible_native_concat(var_1)
    # FIXME:
    #assert var_5 == False
    var_6 = ansible_native_concat(var_2)
    assert var_6 == u'0'
    var_7 = ansible_native_concat(var_3)
    assert var_7 == u'1'



# Generated at 2022-06-25 12:19:36.565265
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    a = 1
    b = 2
    c = 3
    Object = ansible_native_concat([a, b, c])
    Object2 = ansible_native_concat([a, b])
    Object3 = ansible_native_concat([a, b, c])
    Object4 = ansible_native_concat([a, b])
    Object5 = ansible_native_concat([a, b, c])
    assert Object == Object2
    assert Object == Object3
    assert Object == Object4
    assert Object == Object5



# Generated at 2022-06-25 12:19:46.290671
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    bool_0 = True
    var_0 = ansible_native_concat(bool_0)
    assert var_0 is True

    str_0 = 'foo'
    var_1 = ansible_native_concat(str_0)
    assert var_1 == 'foo'

    str_0 = 'foo'
    str_1 = '{bar}'
    var_2 = ansible_native_concat(str_0)
    var_3 = ansible_native_concat(str_1)
    var_4 = ansible_native_concat(var_2)
    var_5 = ansible_native_concat(var_3)
    var_6 = ansible_native_concat(var_4)
    var_7 = ansible_native_concat(var_5)
   

# Generated at 2022-06-25 12:19:53.213969
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()


# Generated at 2022-06-25 12:19:54.496523
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test case 0
    assert test_case_0() is not None

# Generated at 2022-06-25 12:20:02.156579
# Unit test for function ansible_native_concat

# Generated at 2022-06-25 12:20:03.531064
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert container_to_text(test_case_0()) == 'True'

# Generated at 2022-06-25 12:20:07.949538
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()

# Generated at 2022-06-25 12:20:17.889086
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # function_examples
    assert to_text(ansible_native_concat(['1', '2'])) == '12'
    assert to_text(ansible_native_concat(['foo', 'bar'])) == 'foobar'
    assert to_text(ansible_native_concat(['foo', '', 'bar'])) == 'foobar'
    # function_examples_1
    assert to_text(ansible_native_concat([1, 2])) == '12'
    # function_examples_2
    assert to_text(ansible_native_concat([1, '2'])) == '12'
    # function_examples_3
    assert to_text(ansible_native_concat([1, 2])) == '12'
    # function_examples_4
   

# Generated at 2022-06-25 12:20:18.800306
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == None

# Generated at 2022-06-25 12:20:21.727958
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test with list
    ansible_native_concat(['abc', 123])

    # Test with Str
    ansible_native_concat('abc123')

# Generated at 2022-06-25 12:20:29.640875
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(u'subtree') == u'subtree'
    assert ansible_native_concat(u"{{['sub', 'tree'] | join(' ') }}") == u'sub tree'
    assert ansible_native_concat(u"{{['sub', 'tree'] | join(' ') }} {{['sub', 'tree'] | join(' ') }}") == u'sub tree sub tree'
    assert ansible_native_concat(u"{{['sub', 'tree'] | join(' ') }} {{1 + 1}}") == u'sub tree 2'

# Generated at 2022-06-25 12:20:38.278751
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Run Unittest for the function ansible_native_concat by using the function 'test_case_0' which
    # contains the example data for the function ansible_native_concat defined in the OpenAPI spec.
    # Convert json output back to python objects by using the 'container_to_text' function from
    # ansible.module_utils.common.text.converters
    # Evaluate the output of the function ansible_native_concat to the expected value.
    assert container_to_text(ansible_native_concat(test_case_0())) == True



# Generated at 2022-06-25 12:20:44.982094
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test case 0:
    bool_0 = True
    var_0 = ansible_native_concat(bool_0)
    assert var_0 is True

    # Test case 1:
    bool_1 = True
    float_0 = 0.0
    str_0 = "abc"
    str_1 = "123"
    var_1 = ansible_native_concat(bool_1, float_0, str_0, str_1)
    assert var_1 is "True0.0abc123"

    # Test case 2:
    bool_2 = False
    float_1 = 1.0
    str_2 = "Hello"
    str_3 = "World"
    var_2 = ansible_native_concat(bool_2, float_1, str_2, str_3)

# Generated at 2022-06-25 12:20:48.733694
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import Template
    env = dict(ansible_native_concat=ansible_native_concat)
    template = Template('''
{%- set var = {"test": ansible_native_concat(test)} -%}
{%- set var = ansible_native_concat(var.test) -%}
''', extensions=[])
    template_vars = dict(test=True)
    rendered = container_to_text(template.render(template_vars, **env))
    return rendered


if __name__ == '__main__':
    print(test_ansible_native_concat())

# Generated at 2022-06-25 12:20:55.976910
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.collections import Mapping
    from ansible.module_utils.common.text.converters import to_text, to_bytes
    from ansible.module_utils.common.text.converters import container_to_text
    from ansible.module_utils.six import string_types, integer_types
    from ansible.module_utils.six import text_type, binary_type
    from ansible.module_utils.six import PY3

    # This function could potentially be used with
    # non-sequence types. We need to accept those as
    # well.
    # See:
    # https://github.com/ansible/ansible/issues/70831#issuecomment-664190894
    bool_0 = True
    var_0 = ansible_native_concat

# Generated at 2022-06-25 12:21:06.476920
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    bool_0 = True
    var_0 = ansible_native_concat(bool_0)
    assert var_0 is True

    dict_0 = {'a': 'b', 'c': 'd'}
    var_1 = ansible_native_concat(dict_0)
    assert var_1 == dict_0

    int_0 = 1
    var_2 = ansible_native_concat(int_0)
    assert var_2 is 1

    list_0 = [1, 2, 3]
    var_3 = ansible_native_concat(list_0)
    assert var_3 == [1, 2, 3]

    str_0 = 'abc'
    var_4 = ansible_native_concat(str_0)
    assert var_4 == 'abc'

    # multiple

# Generated at 2022-06-25 12:21:18.561353
# Unit test for function ansible_native_concat

# Generated at 2022-06-25 12:21:21.546224
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    arg = 0

# Generated at 2022-06-25 12:21:24.346899
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    result_0 = ansible_native_concat(test_case_0)
    assert result_0 == 'test_case_0'
    pass


# Generated at 2022-06-25 12:21:28.649495
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Case 0
    try:
        if not True:
            raise AssertionError
        assert ansible_native_concat(list) == []
    except AssertionError:
        raise AssertionError("Case 0 failed")



# Generated at 2022-06-25 12:21:29.461582
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(test_case_0()) == test_case_0


# Generated at 2022-06-25 12:21:31.212728
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    print("\n############################################################\n")
    print("\n# This is the test case for function 'ansible_native_concat'\n")
    print("\n############################################################\n")
    assert ansible_native_concat(test_case_0) == True

# Generated at 2022-06-25 12:21:36.128840
# Unit test for function ansible_native_concat

# Generated at 2022-06-25 12:21:41.671778
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    data = {'bool_0': True, 'bool_1': True, 'bool_2': True, 'bool_3': True, 'bool_4': True, 'bool_5': True, 'bool_6': True, 'bool_7': True, 'bool_8': True, 'bool_9': True}
    res = False
    if data['bool_0']:
        res = ansible_native_concat(data)
    assert type(res) is bool


# Generated at 2022-06-25 12:21:43.338675
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert True == test_case_0()

# Generated at 2022-06-25 12:21:52.489150
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert callable(ansible_native_concat)

    assert ansible_native_concat([False]) == False
    assert ansible_native_concat([True]) == True
    assert ansible_native_concat([None]) == None
    assert ansible_native_concat([0]) == 0
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['']) == ''
    assert ansible_native_concat(['0']) == '0'
    assert ansible_native_concat(['1']) == '1'
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([0, 1]) == '01'
    assert ansible_native_concat([1, 0]) == '10'


# Generated at 2022-06-25 12:22:04.870181
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    s = 'test_string'
    i = 4
    f = 3.14
    # Compare native Python object test
    assert s == ansible_native_concat(s)
    assert i == ansible_native_concat(i)
    assert f == ansible_native_concat(f)
    true_0 = ansible_native_concat(True)
    assert true_0

    assert False is ansible_native_concat(False)
    assert 0 == ansible_native_concat(0)
    assert -1 == ansible_native_concat(-1)
    assert -2 == ansible_native_concat(-2)
    assert 0.0 == ansible_native_concat(0.0)
    assert 1.0 == ansible_native_concat(1.0)

# Generated at 2022-06-25 12:22:09.899203
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    try:
        assert ansible_native_concat(None)
        assert False
    except:
        assert True
    try:
        assert ansible_native_concat([])
        assert False
    except:
        assert True
    try:
        assert ansible_native_concat([test_case_0(test_case_0.__dict__)])
        assert False
    except:
        assert True

# Generated at 2022-06-25 12:22:14.198235
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    bool_0 = True
    int_0 = -1
    string_0 = "1x4iFj"
    string_1 = "&"
    string_2 = "l]!z"
    string_list_0 = [bool_0, int_0, string_0, string_1, string_2]
    tuple_0 = (string_list_0,)
    dict_0 = dict(zip(tuple_0, tuple_0))

    # run tested function
    # x is a list
    x = [string_1,string_0,string_2]
    result = ansible_native_concat(x)

    # assert return code
    assert result == "%s%s%s" % (string_1, string_0, string_2)

# Generated at 2022-06-25 12:22:18.913094
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['simple string']) == 'simple string'

    assert ansible_native_concat([123]) == 123
    assert ansible_native_concat([123, '456']) == u'123456'
    assert ansible_native_concat([123, '456']) == u'123456'
    assert ansible_native_concat([123, 123.0]) == u'123123.0'

    assert ansible_native_concat(['123', 123]) == 123
    assert ansible_native_concat(['123 ', 123]) == u'123 '
    assert ansible_native_concat(['123 ', '123']) == 123
    assert ansible_native_concat(['123 ', ' 123']) == 123

# Generated at 2022-06-25 12:22:23.955131
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Checking if the function is defined
    assert callable(ansible_native_concat)
    # Calling the function
    result = ansible_native_concat(bool_0)
    # Verifying the type of the output
    assert isinstance(result, bool)
    # Checking if the output value is the one expected
    assert str(result) == 'True'


# Generated at 2022-06-25 12:22:25.252480
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    ansible_native_concat(test_case_0)

# Generated at 2022-06-25 12:22:31.369261
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    s = "['test1', 'test2', 'test3']"
    actual = ansible_native_concat(s)
    expected = ['test1', 'test2', 'test3']
    assert actual == expected

# Generated at 2022-06-25 12:22:33.567909
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(test_case_0()) == True


# Generated at 2022-06-25 12:22:42.997088
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    bool_0 = True
    bool_1 = False
    str_0 = "test string"
    num_0 = 37
    seq_0 = [ 'a', 'b', 'c', 'd' ]
    seq_1 = [ bool_0, bool_1, str_0, num_0, seq_0 ]
    seq_2 = [ seq_0, seq_1 ]
    map_0 = { str_0 : seq_0, str_0 : seq_2 }
    map_1 = { seq_0 : map_0, num_0 : map_1 }
    bool_0 = ansible_native_concat([bool_0, bool_1, bool_0, bool_1])
    assert(bool_0)


# Generated at 2022-06-25 12:22:46.304110
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    print(2)
    assert ansible_native_concat([True]) == True

if __name__ == '__main__':
    test_ansible_native_concat()

# Generated at 2022-06-25 12:22:52.566615
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    text_0 = "abc" + "def"
    container_to_text(text_0)

if __name__ == '__main__':
    test_ansible_native_concat()

# Generated at 2022-06-25 12:22:54.871439
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    x = 'A'
    y = 'B'
    z = ansible_native_concat([x, y])
    assert z == 'AB'

# unit test for function container_to_text

# Generated at 2022-06-25 12:23:01.270850
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    out = ansible_native_concat('')
    assert 'None'

    out = ansible_native_concat('bob')
    assert 'str'

    bool_0 = bool(0)
    out = ansible_native_concat(bool_0)
    assert 'bool'

    out = ansible_native_concat(123)
    assert 'int'

    out = ansible_native_concat(1.1)
    assert 'float'

    out = ansible_native_concat(['a', 'b'])
    assert 'list'

    out = ansible_native_concat({'a': 'b'})
    assert 'dict'

    out = ansible_native_concat(('a', 'b'))
    assert 'tuple'

    out = ansible_native_

# Generated at 2022-06-25 12:23:11.423136
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    dict0 = dict(
        name = 'Joe',
        age = 22
    )
    dict1 = dict(
        name = 'Mary',
        age = 26
    )
    dict2 = dict(
        name = 'Joe',
        age = 26
    )
    dict3 = dict(
        name = 'Mary',
        age = 22
    )
    dict_list0 = [ dict0, dict1, dict2, dict3 ]
    dict_list1 = [ dict1, dict3, dict0, dict2 ]
    dict_list2 = [ dict2, dict1, dict0, dict3 ]
    dict_list3 = [ dict3, dict0, dict1, dict2 ]
    int0 = 33
    str0 = 'test_string'
    str1 = 'test_string'

# Generated at 2022-06-25 12:23:13.731689
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    data = ['{\n    ', 'boo\n', '}']
    expected_result = '{\n    boo\n}'
    result = ansible_native_concat(data)
    assert result == expected_result


# Generated at 2022-06-25 12:23:15.908881
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    list_0 = [1, 2, 3]
    assert ansible_native_concat(list_0) == 1
# Define test_case_1

# Generated at 2022-06-25 12:23:24.554855
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # FIXME: Test the actual return value

    # FIXME: Test exceptions
    pass

# FIXME: add tests for pbkdf2_hex

# FIXME: add tests for order_objects_list

# FIXME: add tests for to_native

# FIXME: add tests for username_validate

# FIXME: add tests for list_subsets

# FIXME: add tests for is_subset

# FIXME: add tests for is_equal

# FIXME: add tests for list_difference

# FIXME: add tests for list_union

# FIXME: add tests for list_intersection

# FIXME: add tests for mk_boolean

# FIXME: add tests for is_container

# FIXME: add tests for list_to_bytes

# FIXME: add tests

# Generated at 2022-06-25 12:23:31.903492
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    bool_0 = True
    list_0 = list()
    list_1 = list()

    ansible_native_concat(list_1)

    byte_0 = b'\x00'
    byte_1 = b'\x00'

    ansible_native_concat(list_0)

    byte_literal_0 = b''
    byte_literal_1 = b''

    ansible_native_concat(list_1)

    byte_literal_2 = b''
    byte_literal_3 = b''

    ansible_native_concat(list_0)
# END OF TEMPLATE

if __name__ == '__main__':
    test_ansible_native_concat()

# Generated at 2022-06-25 12:23:32.826596
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # TODO add tests
    pass

# Generated at 2022-06-25 12:23:42.814898
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert callable(ansible_native_concat)
    bool_0 = ansible_native_concat(False)
    bool_1 = ansible_native_concat(None)
    num_0 = ansible_native_concat(1)
    str_0 = ansible_native_concat('ab')
    str_1 = ansible_native_concat('abdc')
    str_2 = ansible_native_concat('abcd')
    str_3 = ansible_native_concat('bb')
    str_4 = ansible_native_concat('d')
    tuple_0 = ansible_native_concat((1, 2, 3))
    list_0 = ansible_native_concat([1, 2, 3])
    assert_equal(bool_0, False)
    assert_

# Generated at 2022-06-25 12:23:48.861820
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    bytes_0 = b'a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd'
    var_0 = ansible_native_concat(bytes_0)

    assert container_to_text(var_0) == u"a\u00e7o\u000e\u00e2\u00d3\u00d9\u0002;\u00e8\u00dd"



# Generated at 2022-06-25 12:23:57.569202
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(b'a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd') == 'a\xe7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd'
    assert ansible_native_concat(u'a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd') == u'a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd'

# Generated at 2022-06-25 12:24:04.314264
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    bytes_0 = b'a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd'
    var_0 = ansible_native_concat(bytes_0)
    assert var_0 == b'a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd'


# Generated at 2022-06-25 12:24:12.994753
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    bytes_0 = b'a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd'
    out_0 = ansible_native_concat(bytes_0)
    var_0 = isinstance(out_0, text_type)

    int_0 = 892
    list_0 = [int_0, int_0, int_0, int_0, int_0]
    out_1 = ansible_native_concat(list_0)
    var_1 = isinstance(out_1, list)

    int_0 = 961
    list_0 = [int_0, int_0, int_0, int_0, int_0]
    out_2 = ansible_native_concat(list_0)

# Generated at 2022-06-25 12:24:23.044766
# Unit test for function ansible_native_concat

# Generated at 2022-06-25 12:24:26.045582
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Bytes as input
    # Pass
    bytes_0 = b'a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd'
    var_0 = ansible_native_concat(bytes_0)


# Generated at 2022-06-25 12:24:31.222382
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert_equal(ansible_native_concat('a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd'), 'a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd')
    assert_equal(ansible_native_concat(['a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd']), 'a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd')

# Generated at 2022-06-25 12:24:39.567327
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    bytes_0 = b'a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd'
    assert type(ansible_native_concat(bytes_0)) == str
    bytes_0 = b'\xfb\xa3\x94A\x89'
    assert ansible_native_concat(bytes_0) == '\xfb\xa3\x94A\x89'
    bytes_0 = b'\xac\x12\xb8\xbd\xa7\xdb\xc1\x8f\xee\xab'
    assert type(ansible_native_concat(bytes_0)) == str
    var_0 = ansible_native_concat(bytes_0)

# Generated at 2022-06-25 12:24:42.931913
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Create the mocks of objects that would be needed to test this function

    # Attempt to execute function without any required objects
    try:
        ansible_native_concat()
    except NameError as e:
        # The above function should throw a NameError
        assert True
    # An exception should have been raised above
    assert False



# Generated at 2022-06-25 12:24:48.771250
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import yaml

# Generated at 2022-06-25 12:25:01.974019
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert 'a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd' == ansible_native_concat(b'a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd')
    assert 'a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd' == ansible_native_concat('a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd')

# Generated at 2022-06-25 12:25:02.813285
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() is None

# Generated at 2022-06-25 12:25:05.581141
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert to_text(test_case_0()) == to_text(u'a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd')


# Generated at 2022-06-25 12:25:09.514411
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    bytes_0 = b'a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd'
    var_0 = ansible_native_concat(bytes_0)
    print(var_0)


if __name__ == "__main__":
    test_ansible_native_concat()

# Generated at 2022-06-25 12:25:11.204396
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    b"This test needs to be implemented"

# Generated at 2022-06-25 12:25:18.877730
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert isinstance(ansible_native_concat(b'a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd'), text_type)
    assert ansible_native_concat(b'a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd') == u'a\u015co\x0e\xe2\xd3\xd9\x02;\xe8\xdd'
    assert isinstance(ansible_native_concat(u'a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd'), text_type)

# Generated at 2022-06-25 12:25:23.896602
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    try:
        assert 'aÇo\x0eâÓÙ\x02;èÝ'.encode('utf-8') == ansible_native_concat('aÇo\x0eâÓÙ\x02;èÝ'.encode('utf-8'))
    except Exception as e:
        print('Caught this error: ' + repr(e))



# Generated at 2022-06-25 12:25:31.309206
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert ansible_native_concat([]) == None
    assert ansible_native_concat([u'a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd']) == u'a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd'
    assert container_to_text(ansible_native_concat([u'a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd'])) == 'a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd'
    assert container_to_text(ansible_native_concat([u'a', u'b'])) == 'ab'

# Generated at 2022-06-25 12:25:41.881965
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    bytes_0 = b'a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd'
    assert ansible_native_concat(bytes_0) == b'a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd'

    bytes_1 = b'a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd'
    assert ansible_native_concat(bytes_1) == b'a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd'


# Generated at 2022-06-25 12:25:42.866739
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert True



# Generated at 2022-06-25 12:25:49.889096
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    bytes_0 = b'a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd'
    var_0 = ansible_native_concat(bytes_0)

    assert type(var_0) == text_type
    assert container_to_text(var_0) == "aço\x0eâÓÙ\x02;èÝ"

# Generated at 2022-06-25 12:25:55.948663
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    bytes_0 = b'a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd'
    assert ansible_native_concat(bytes_0) == u'a\xe7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd'



# Generated at 2022-06-25 12:26:06.289524
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1,2]) == '12'
    assert ansible_native_concat([1,2,'3']) == '123'
    assert ansible_native_concat([1,[2,'3']]) == '123'
    assert ansible_native_concat([1,[2,'3'],[4,5]]) == '12345'
    assert ansible_native_concat([1,[2,'3'],[4,5],'6']) == '123456'
    assert ansible_native_concat([1,[2,3],4]) == '1234'
    assert ansible_native_concat([1,'2',3,4]) == '1234'

    assert ansible_native_concat([1,2]) == '12'
    assert ansible_native_concat

# Generated at 2022-06-25 12:26:15.371740
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Encrypted bytes
    out = b'a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd'

    # Check that ansible_native_concat produces (mocked) bytes
    assert isinstance(ansible_native_concat(out), bytes)

# Line coverage
# Executing all possible paths in function_utils.py#ansible_native_concat,
# but fails as a result of not being able to iterate through a bytestring
# with multiple bytes. The following is commented out because it fails
# because it is not possible to iterate through a bytestring with multiple
# bytes.

# def test_case_0():
#     bytes_0 = b'a\xc7o\x0e\xe2\xd3\xd9\x02;\

# Generated at 2022-06-25 12:26:16.643860
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # NOTE: function is not a good candidate for testcases, it is just a decorator
    pass

# Generated at 2022-06-25 12:26:19.818335
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert b'a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd' == test_case_0()

# Generated at 2022-06-25 12:26:20.897907
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()

# Generated at 2022-06-25 12:26:25.643496
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert 'test_case_0' in globals(), 'test_case_0 is not defined'
    assert 'bytes_0' in globals(), 'bytes_0 is not defined'
    assert 'var_0' in globals(), 'var_0 is not defined'
    assert hasattr(var_0, '__call__'), "var_0 is not callable"

# Generated at 2022-06-25 12:26:34.648651
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ast.literal_eval("a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd") == u'a\u00c7o\u000e\u00e2\u00d3\u00d9\u0002;\u00e8\u00dd'
    assert ansible_native_concat(ast.literal_eval("a\xc7o\x0e\xe2\xd3\xd9\x02;\u00e8\xdd")) == u'a\u00c7o\u000e\u00e2\u00d3\u00d9\u0002;\u00e8\u00dd'



# Generated at 2022-06-25 12:26:40.093104
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # No arguments
    try:
        ansible_native_concat()
    except TypeError:
        pass
    else:
        # Should have raised TypeError
        assert False

    # Bad arguments
    try:
        ansible_native_concat(1)
    except TypeError:
        pass
    else:
        # Should have raised TypeError
        assert False

    assert ansible_native_concat('a\xc7o') == 'a\xc7o'
    assert ansible_native_concat('99') == '99'
    assert ansible_native_concat('9.9') == '9.9'
    assert ansible_native_concat('a') == 'a'

# Generated at 2022-06-25 12:26:46.095578
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Make sure the function accepts bytes
    assert ansible_native_concat(b'abc') == 'abc'



# Generated at 2022-06-25 12:26:55.412115
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('\n') == '\n'
    assert ansible_native_concat('\n', '\n') == '\n\n'
    assert ansible_native_concat('\n', '\n', '\n') == '\n\n\n'
    assert ansible_native_concat('\n', '\n', '\n', '\n') == '\n\n\n\n'
    assert ansible_native_concat('\n', '\n', '\n', '\n', '\n') == '\n\n\n\n\n'

# Generated at 2022-06-25 12:27:05.712365
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    bytes_0 = b'a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd'
    var_0 = ansible_native_concat(bytes_0)

    # assert isinstance(var_0, string_types)
    assert var_0 == "a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd"

    dict_0 = dict([(0, 'z'), (1, 1), (2, 2), (3, 'x'), (4, 4)])
    var_1 = ansible_native_concat(dict_0)

    assert isinstance(var_1, dict)

# Generated at 2022-06-25 12:27:09.250431
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
   bytes_0 = b'a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd'
   var_0 = ansible_native_concat(bytes_0)
   assert var_0 == container_to_text(bytes_0, nonstring='passthru')

# Generated at 2022-06-25 12:27:10.193745
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert True


# Generated at 2022-06-25 12:27:19.642019
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(b'\x00\xb2\x1c\xbf\x0e\x01\xc6\x0c\x88') == b'\x00\xb2\x1c\xbf\x0e\x01\xc6\x0c\x88'
    assert ansible_native_concat(b'\x8d\x1a\xc3\x1d\x9e\x8a\x89\x11') == b'\x8d\x1a\xc3\x1d\x9e\x8a\x89\x11'

# Generated at 2022-06-25 12:27:28.827364
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    out = ansible_native_concat()
    assert out is None

    out = ansible_native_concat(b'Test')
    assert out == u'Test'
    assert isinstance(out, text_type)

    out = ansible_native_concat([1, 2, 3])
    assert out == u'123'
    assert isinstance(out, text_type)

    out = ansible_native_concat([1, 2, [3, 4, 5]])
    assert out == u'12345'
    assert isinstance(out, text_type)

    out = ansible_native_concat([1, 2, {'a': 3, 'b': 4}])
    assert out == u'12{b: 4, a: 3}'
    assert isinstance(out, text_type)

   

# Generated at 2022-06-25 12:27:30.655572
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test a bytes value of ansible_native_concat
    var_1 = ansible_native_concat(bytes_0)



# Generated at 2022-06-25 12:27:40.691501
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('a') == 'a'
    assert ansible_native_concat('') == None
    assert ansible_native_concat(b'a') == 'a'
    assert ansible_native_concat(b'\xc3\xa9') == 'é'
    assert ansible_native_concat(b'a\xc3\xa9') == 'aé'
    assert ansible_native_concat(b'\xc3\xa9a') == 'éa'
    assert ansible_native_concat(b'\xc3\xa9\xc3\xa9') == 'éé'
    assert ansible_native_concat(container_to_text(b'a')) == 'a'

# Generated at 2022-06-25 12:27:42.337805
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Input parameters
    nodes = b'\xc3\xad'

    # Output validation
    assert isinstance(ansible_native_concat(nodes), str)


# Generated at 2022-06-25 12:27:55.421016
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = ansible_native_concat(ast.literal_eval(b'a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd'))
    assert isinstance(var_0, text_type)
    var_1 = ansible_native_concat(ast.literal_eval(b'a b  .  c d'))
    assert isinstance(var_1, text_type)
    var_2 = ansible_native_concat(ast.literal_eval(b'a b    c d'))
    assert isinstance(var_2, text_type)
    var_3 = ansible_native_concat(ast.literal_eval(b'a b  .  c d{}'))

# Generated at 2022-06-25 12:27:56.494978
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert isinstance(test_case_0(), text_type)

# Generated at 2022-06-25 12:27:59.240687
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    out = to_text(b'a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd')
    assert ansible_native_concat(b'a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd') == out


# Generated at 2022-06-25 12:28:06.909979
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('abc') == 'abc'
    assert ansible_native_concat('abc', 'def') == 'abcdef'
    assert ansible_native_concat('abc', '123') == 'abc123'
    assert ansible_native_concat('abc', '123', '456', '789') == 'abc123456789'
    assert ansible_native_concat(['abc', 'def']) == 'abcdef'
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['abc', 123]) == 'abc123'


# Generated at 2022-06-25 12:28:09.777408
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    bytes_0 = b'a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd'
    assert ansible_native_concat(bytes_0)



# Generated at 2022-06-25 12:28:18.351969
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_1 = ansible_native_concat('FOO')
    assert var_1 == 'FOO'

    var_2 = ansible_native_concat('FOO', u'BAR')
    assert var_2 == 'FOOBAR'

    var_3 = ansible_native_concat(u'FOO', 'BAR', 'BAZ')
    assert var_3 == 'FOOBARBAZ'

    var_4 = ansible_native_concat('FOO', [b'BAR', b'BAZ'])
    assert var_4 == 'FOOBARBAZ'

    var_5 = ansible_native_concat('FOO', '', 'BAR')
    assert var_5 == 'FOOBAR'


# Generated at 2022-06-25 12:28:20.269748
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """
    Test function ansible_native_concat
    """
    # Test case 0
    test_case_0()



# Generated at 2022-06-25 12:28:25.010566
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    bytes_0 = b'a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd'
    var_0 = ansible_native_concat(bytes_0)
    assert container_to_text(var_0) == b'a\xc3\x87o\x0e\xe2\xd3\xd9\x02;\xe8\xdd'


# Generated at 2022-06-25 12:28:26.285676
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert callable(ansible_native_concat)



# Generated at 2022-06-25 12:28:35.377467
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    bytes_0 = b'a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd'
    var_0 = ansible_native_concat(bytes_0)
    assert var_0 == 'a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd'
    var_1 = ansible_native_concat(['first', 'second', 'third'])
    assert var_1 == 'firstsecondthird'
    var_2 = ansible_native_concat(['first', u'\u1234', 'third'])
    assert var_2 == 'first\u1234third'
    var_3 = ansible_native_concat([['1', 2]])

# Generated at 2022-06-25 12:28:46.334255
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    dict_data = dict()
    dict_data['str_0'] = str()
    dict_data['str_1'] = str()
    dict_data['str_2'] = str()
    dict_data['dict_0'] = dict()
    dict_data['dict_1'] = dict()
    dict_data['list_0'] = list()
    dict_data['list_1'] = list()
    dict_data['list_2'] = list()
    dict_data['float_0'] = 0.0423498
    dict_data['float_1'] = 0.788224
    dict_data['float_2'] = 0.72324
    dict_data['float_3'] = 0.510905
    dict_data['float_4'] = 9.70098

# Generated at 2022-06-25 12:28:55.485903
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd'
    bytes_0 = b'a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd'
    str_1 = '\x18\x05\xe6\x1a\x11\x18\x07\x84\x0c\x1d'
    bytes_1 = b'\x18\x05\xe6\x1a\x11\x18\x07\x84\x0c\x1d'
    str_2 = '\x03\x0a\x11\x01\x1d\x1c\x04\x0b\x18\x00'
   

# Generated at 2022-06-25 12:28:56.722108
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Set up test values

    # Call the function
    try:
        ansible_native_concat(data)
    except Exception:
        pass

# Generated at 2022-06-25 12:29:06.555294
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    bytes_0 = b'a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd'
    var_0 = ansible_native_concat(bytes_0)
    assert to_text(var_0) == 'aÇo\x0eâÓÙ\x02;èÝ'


# Generated at 2022-06-25 12:29:12.360888
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    bytes_0 = b'a\xc7o\x0e\xe2\xd3\xd9\x02;\xe8\xdd'
    var_0 = ansible_native_concat(bytes_0)

    var_1 = ansible_native_concat(u'\U000f6c29\U000f7ad8\U000f7bd6\U000f7b7e\U000f7b7f\U000f7bd4\U000f7b27')
    var_2 = ansible_native_concat(123456)
    var_3 = ansible_native_concat(123)
    var_4 = ansible_native_concat(100)