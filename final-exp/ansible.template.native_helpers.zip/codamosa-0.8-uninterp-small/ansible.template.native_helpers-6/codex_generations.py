

# Generated at 2022-06-25 12:19:12.829665
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert AnsibleVaultEncryptedUnicode('"XYF=4dH') == ansible_native_concat('"XYF=4dH')

# Generated at 2022-06-25 12:19:23.770430
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    result_0 = ansible_native_concat(['"XYF=4dH'])
    assert result_0 == 'XYF=4dH'

    result_1 = ansible_native_concat(["XYF=4dH"])
    assert result_1 == "XYF=4dH"

    result_2 = ansible_native_concat(["""XYF=4dH"""])
    assert result_2 == "XYF=4dH"

    result_3 = ansible_native_concat(['{"XYF=4dH": "XYF=4dH"}'])
    assert result_3 == {"XYF=4dH": "XYF=4dH"}


# Generated at 2022-06-25 12:19:27.652046
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert isinstance(ansible_native_concat("foo"), native_types.str)
    assert ansible_native_concat("foo") == "foo"
    assert isinstance(ansible_native_concat("foo" "bar"), native_types.str)
    assert ansible_native_concat("foo" "bar") == "foobar"
    assert ansible_native_concat("foo" "bar" "baz") == "foobarbaz"
    assert isinstance(ansible_native_concat(["foo"]), native_types.str)
    assert ansible_native_concat(["foo"]) == "foo"
    assert isinstance(ansible_native_concat(["foo", "bar"]), native_types.str)
    assert ansible_native_concat(["foo", "bar"])

# Generated at 2022-06-25 12:19:29.467730
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert type(test_case_0()) == str

# Generated at 2022-06-25 12:19:31.466650
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    seq1 = [1, 2, 3, 4]
    seq2 = [5, 6, 7, 8]

    assert ansible_native_concat(seq1) == 1
    assert ansible_native_concat(seq2) == 5
    assert ansible_native_concat(seq1 + seq2) == '12345678'

# Generated at 2022-06-25 12:19:33.009263
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat("XYF=4dH") == "XYF=4dH"

# Generated at 2022-06-25 12:19:44.203108
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Store and compare result for function ansible_native_concat with input
    # {str_0 = '"XYF=4dH'}
    str_0 = '"XYF=4dH'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == '"XYF=4dH'

    # Store and compare result for function ansible_native_concat with input
    # {var_0 = ansible_native_concat(str_0)}
    str_0 = '"XYF=4dH'
    var_0 = ansible_native_concat(str_0)
    var_1 = ansible_native_concat(var_0)
    assert var_1 == '"XYF=4dH'

    # Store and compare result for function ans

# Generated at 2022-06-25 12:19:45.092675
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert True, 'Test is expired'



# Generated at 2022-06-25 12:19:55.812892
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test if we can concat a list of nodes
    node_list = []
    node_list.append("Foo")
    node_list.append("Bar")
    node_list.append("Baz")
    result = ansible_native_concat(node_list)
    assert result == 'FooBarBaz'
    # Test if we can concat a generator
    def generate():
        for i in range(0, 3):
            yield i
    result = ansible_native_concat(generate())
    assert result == "012"
    # Test if we can parse a integer literal
    result = ansible_native_concat("123")
    assert result == 123
    # Test if we can parse a float literal
    result = ansible_native_concat("123.4")
    assert result == 123.4

# Generated at 2022-06-25 12:20:02.976703
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert isinstance(ansible_native_concat, types.FunctionType)
    assert isinstance(ansible_native_concat(u"no"), text_type)
    assert container_to_text(ansible_native_concat(123, 456)) == u"123456"
    assert isinstance(ansible_native_concat(False), bool)
    assert isinstance(ansible_native_concat(123.456), float)
    assert isinstance(ansible_native_concat(u"a", u"bc", u"def"), text_type)
    assert container_to_text(ansible_native_concat(u"{0}", u"a")) == u"a"
    assert container_to_text(ansible_native_concat(123j)) == u"123j"

# Generated at 2022-06-25 12:20:08.737240
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat == 'XYF=4dH'

# Generated at 2022-06-25 12:20:18.419125
# Unit test for function ansible_native_concat

# Generated at 2022-06-25 12:20:22.385009
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Testing for d0c9ccb
    try:
        test_case_0()
    except:
        assert False, "An exception occurred while testing 'ansible_native_concat'"


# Unit test function list_duplicates

# Generated at 2022-06-25 12:20:25.125692
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '"XYF=4dH'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == str_0
    assert container_to_text(var_0) == str_0

# Generated at 2022-06-25 12:20:26.766346
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '"XYF=4dH'
    var_0 = ansible_native_concat(str_0)



# Generated at 2022-06-25 12:20:38.237923
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # check data from test case 0
    str_0 = '"XYF=4dH'
    var_str_0 = ansible_native_concat(str_0)
    assert var_str_0 == '"XYF=4dH'
    # check data from test case 1
    str_1 = '7n8YrZrF'
    var_str_1 = ansible_native_concat(str_1)
    assert var_str_1 == '7n8YrZrF'
    # check data from test case 2
    str_2 = 'n/A6wY/Y'
    var_str_2 = ansible_native_concat(str_2)
    assert var_str_2 == 'n/A6wY/Y'
    # check data from test case 3


# Generated at 2022-06-25 12:20:39.583502
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == 'XYF=4dH'

# Generated at 2022-06-25 12:20:41.909494
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert "h" == ansible_native_concat("  'h'")

if __name__ == '__main__':
    test_ansible_native_concat()

# Generated at 2022-06-25 12:20:50.752730
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'H2h0aHVtdQ=='
    var_0 = ansible_native_concat(str_0)
    assert container_to_text(var_0) == "H2h0aHVtdQ=="

    str_1 = '"H2h0aHVtdQ=="'
    var_1 = ansible_native_concat(str_1)
    assert container_to_text(var_1) == "H2h0aHVtdQ=="

    str_2 = '''
        "SGVsbG8sIHdvcmxkIQ==
        "
        '''
    var_2 = ansible_native_concat(str_2)

# Generated at 2022-06-25 12:21:00.744867
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert (ansible_native_concat('a') == 'a')

    assert ansible_native_concat('a', 'b') == 'ab'
    assert ansible_native_concat('a', 'b', 'c') == 'abc'

    assert ansible_native_concat(1, 'b') == '1b'
    assert ansible_native_concat(1, 2, 3) == 6
    assert ansible_native_concat(1, 2, '3') == '123'

    assert ansible_native_concat(True, False) == 'TrueFalse'
    assert ansible_native_concat(True, False, True) == 'TrueFalseTrue'

    assert ansible_native_concat(True, 1, 'b') == 'True1b'


# Generated at 2022-06-25 12:21:06.456690
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('A') == 'A'

# Generated at 2022-06-25 12:21:07.602477
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '"XYF=4dH'
    assert var_0 == 'XYF=4dH'


# Generated at 2022-06-25 12:21:17.914817
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '"XYF=4dH'
    var_0 = ansible_native_concat(str_0)
    try:
        assert var_0 == '"XYF=4dH'
    except AssertionError:
        raise AssertionError('Unexpected Result:', var_0)


    str_1 = '<'
    str_2 = 'script>alert()</'
    str_3 = 'script>'
    var_1 = ansible_native_concat([str_1, str_2, str_3])
    try:
        assert var_1 == '<script>alert()</script>'
    except AssertionError:
        raise AssertionError('Unexpected Result:', var_1)



# Generated at 2022-06-25 12:21:28.506124
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '"XYF=4dH'
    assert ansible_native_concat(str_0) == '"XYF=4dH'
    str_0 = '"XYF=4dH'
    assert ansible_native_concat(str_0) == '"XYF=4dH'
    str_0 = '"XYF=4dH'
    assert ansible_native_concat(str_0) == '"XYF=4dH'
    str_0 = '"XYF=4dH'
    assert ansible_native_concat(str_0) == '"XYF=4dH'
    str_0 = '"XYF=4dH'
    assert ansible_native_concat(str_0) == '"XYF=4dH'

# Generated at 2022-06-25 12:21:33.117212
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # For now just test that the function does not fail
    ansible_native_concat("ABC")
    ansible_native_concat("ABC", "DEF") # 2 args
    str_0 = '"XYF=4dH'
    ansible_native_concat(str_0)


# import module snippets
from ansible.module_utils.basic import AnsibleModule
from ansible.module_utils.common.collections import is_sequence
from ansible.module_utils.connection import Connection
from ansible.module_utils.six import iteritems
from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
import traceback
import re
from ansible.module_utils.six import iteritems
from ansible.module_utils.six.moves.urllib.parse import urlencode

# Generated at 2022-06-25 12:21:34.195858
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Calling ansible_native_concat(data)
    test_case_0()

# Generated at 2022-06-25 12:21:34.928338
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()

# Generated at 2022-06-25 12:21:38.698212
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Call function to convert string to integer
    str_0 = '"XYF=4dH'
    var_0 = ansible_native_concat(str_0)

    # Verify function returns expected result
    assert var_0 == '"XYF=4dH'


# Generated at 2022-06-25 12:21:39.514160
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()

# Generated at 2022-06-25 12:21:49.938333
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ast.literal_eval('"XYF=4dH') == ansible_native_concat('XYF=4dH')
    assert "XYF=4dH" == ansible_native_concat('XYF=4dH')
    assert ast.literal_eval("'XYF=4dH'") == ansible_native_concat("'XYF=4dH'")
    assert "XYF=4dH" == ansible_native_concat("'XYF=4dH'")
    assert ast.literal_eval("'XYF=4dH'") == ansible_native_concat("'XYF=4dH'")
    assert "XYF=4dH" == ansible_native_concat("'XYF=4dH'")
    assert ast.literal

# Generated at 2022-06-25 12:22:03.139663
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    str_0 = 'Y=3dX'
    var_0 = ansible_native_concat(str_0)

    str_1 = 'Y=3dX'
    int_0 = 2
    int_1 = 2
    list_0 = [
        str_1,
        int_0,
        int_1
    ]
    var_1 = ansible_native_concat(list_0)
    #assert var_1 == '"Y=3dXY=3dX2'

    str_2 = 'Y=3dX'
    str_3 = '2'
    str_4 = 'X'
    str_5 = 'Y=3dX'
    str_6 = 'Y=3dX'
    int_2 = 2

# Generated at 2022-06-25 12:22:06.270725
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    str_0 = '"XYF=4dH'
    var_0 = ansible_native_concat(str_0)

    for item in var_0:
        print(item)

    assert False

# Generated at 2022-06-25 12:22:07.600724
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert not ansible_native_concat(str_0)


# Generated at 2022-06-25 12:22:15.618418
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '"XYF=4dH'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == '"XYF=4dH'
    str_1 = '{{ var1 + var2 }}'
    var_1 = ansible_native_concat(str_1)
    assert var_1 == '{{ var1 + var2 }}'
    str_2 = '{{ "foo" + "bar" }}'
    var_2 = ansible_native_concat(str_2)
    assert var_2 == 'foobar'
    str_3 = '{{ "foo" + "bar" if True else "foobar" }}'
    var_3 = ansible_native_concat(str_3)
    assert var_3 == 'foobar'
    str

# Generated at 2022-06-25 12:22:18.259406
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Try to use the function to make sure it's callable
    assert ansible_native_concat is not None



# Generated at 2022-06-25 12:22:27.940129
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'Y9-&z'
    str_1 = '"iF<u'
    str_2 = 'xyiH'
    str_3 = '"5qF'
    str_4 = '"&Q6'
    str_5 = '"R_h'
    str_6 = '"Br|'
    str_7 = '"@<C'
    str_8 = '"nbt'
    str_9 = '"4W4'
    str_10 = '"YE%'
    str_11 = '"1Y9'
    str_12 = '"7%g'
    str_13 = '"pEu'
    str_14 = '"P6E'
    str_15 = '"P6E'
    var_1 = ansible_native

# Generated at 2022-06-25 12:22:29.122739
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert type(test_case_0()) == text_type



# Generated at 2022-06-25 12:22:30.023620
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert False


# Generated at 2022-06-25 12:22:42.470074
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Try to concatenate string and int
    str_0 = '"XYF=4dH'
    int_0 = 86063
    assert ansible_native_concat([str_0, int_0]) == "\"XYF=4dH86063"

    # Try to concatenate bool and string
    bool_0 = False
    assert ansible_native_concat([bool_0, str_0]) == "False\"XYF=4dH"

    # Try to concatenate bool and int
    bool_1 = False
    int_1 = 86063
    assert ansible_native_concat([bool_1, int_1]) == "False86063"

    # Try to concatenate bool, string and int

# Generated at 2022-06-25 12:22:52.852441
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '\'"q'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == '\'"q'

    str_0 = '"XYF=4dH'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == '"XYF=4dH'

    str_0 = '\'{"sample": "to_string_filter"}\''
    var_0 = ansible_native_concat(str_0)
    assert var_0 == '\'{"sample": "to_string_filter"}\''

    str_0 = '"{\"sample\": \"to_string_filter\"}"'
    var_0 = ansible_native_concat(str_0)

# Generated at 2022-06-25 12:23:01.685515
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(42) == 42
    assert ansible_native_concat(42) is not 42

    assert ansible_native_concat(float(42)) == float(42)
    assert ansible_native_concat(float(42)) is not float(42)

    assert ansible_native_concat(u'foo') == u'foo'
    assert ansible_native_concat(u'foo') is not u'foo'

    assert ansible_native_concat(u'4') == 4
    assert ansible_native_concat(u'4') is not 4

    assert ansible_native_concat(u'4.0') == 4.0
    assert ansible_native_concat(u'4.0') is not 4.0

    assert ansible_native_con

# Generated at 2022-06-25 12:23:11.715232
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = '/home/vagrant/docs/f0.txt'
    var_1 = ansible_native_concat(var_0)
    assert var_1 == '/home/vagrant/docs/f0.txt'
    var_2 = 'ABC'
    var_3 = ansible_native_concat(var_2)
    assert var_3 == 'ABC'
    var_4 = '"B!8D!#'
    var_5 = ansible_native_concat(var_4)
    assert var_5 == '"B!8D!#'
    var_6 = '~/src/f0.txt'
    var_7 = ansible_native_concat(var_6)
    assert var_7 == '~/src/f0.txt'
  
    str_

# Generated at 2022-06-25 12:23:18.462529
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '"XYF=4dH'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == "XYF=4dH"
    str_0 = 'ZXjlL'
    str_1 = 'DjKg0'
    str_2 = '"'
    var_0 = ansible_native_concat(str_0, str_1, str_2)
    assert var_0 == "ZXjlLDjKg0"
    str_0 = 'B'
    str_1 = 'e'
    str_2 = '9'
    str_3 = '6'
    str_4 = 'v'
    str_5 = 'o'
    str_6 = 's'
    str_7 = 'H'

# Generated at 2022-06-25 12:23:20.360887
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    output = "XYF=4dH"
    var_0 = ansible_native_concat(output)


# Generated at 2022-06-25 12:23:29.103754
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '"XYF=4dH'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'XYF=4dH'

    str_1 = '"sAM32.sAMAccountName"'
    var_1 = ansible_native_concat(str_1)
    assert var_1 == 'sAM32.sAMAccountName'

    str_2 = '"%s:%s"'
    var_2 = ansible_native_concat(str_2)
    assert var_2 == '%s:%s'

    str_3 = '{"name": "abcd", "groups": ["exampleng:Cloud_app_team", "exampleng:Cloud_app_admin"]}'
    var_3 = ansible_native_

# Generated at 2022-06-25 12:23:30.271277
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['"XYF=4dH']) == '"XYF=4dH'

# Generated at 2022-06-25 12:23:32.929220
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '6UH<hU#@gB/'
    str_1 = '\n'
    var_1 = ansible_native_concat(str_0)
    var_2 = ansible_native_concat(str_1)
    print(var_1)
    print(var_2)

# Generated at 2022-06-25 12:23:42.931804
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # str_0
    str_0 = '"XYF=4dH'

    # var_0
    var_0 = ansible_native_concat(str_0)
    assert var_0 == "\"XYF=4dH"
    assert isinstance(var_0, text_type)

    # str_1
    str_1 = 'aD+qr'
    var_1 = ansible_native_concat(str_1)
    assert var_1 == "aD+qr"
    assert isinstance(var_1, text_type)

    # str_2
    str_2 = '"  "0f'
    var_2 = ansible_native_concat(str_2)
    assert var_2 == "\"  \"0f"

# Generated at 2022-06-25 12:23:43.975203
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == 'XYF=4dH'

# Generated at 2022-06-25 12:23:48.808952
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '"XYF=4dH'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == '"XYF=4dH', "output of ansible_native_concat should be '\"XYF=4dH'"

# Generated at 2022-06-25 12:23:58.768213
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Note: We use a simple string here instead of using ansible_native_concat,
    # because ansible_native_concat calls ast.literal_eval, that in turn
    # raises an exception for multiline strings.
    str_0 = "XYF=4dH"
    var_0 = ansible_native_concat(str_0)
    assert var_0 == "XYF=4dH"

    str_1 = '"XYF=4dH'
    # var_1 = ansible_native_concat(str_1)
    # assert var_1 == "XYF=4dH"

    str_2 = "XYF=4dH]"
    var_1 = ansible_native_concat(str_2)
    assert var_1 == "XYF=4dH]"

# Generated at 2022-06-25 12:24:02.379285
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == "XYF=4dH"

# Generated at 2022-06-25 12:24:11.166002
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '"XYF=4dH'
    var_0 = ansible_native_concat(str_0)

    str_1 = '{\"\\\\'
    var_1 = ansible_native_concat(str_1)

    str_2 = 'F*m\'M'
    var_2 = ansible_native_concat(str_2)

    str_3 = '\'\', \'2\''
    var_3 = ansible_native_concat(str_3)

    str_4 = ']1+D)'
    var_4 = ansible_native_concat(str_4)

    str_5 = '\'\', \'2\', \'\''
    var_5 = ansible_native_concat(str_5)


# Generated at 2022-06-25 12:24:13.893967
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat("tests/test_template_module/test_case_0/input/input_0.txt") == "tests/test_template_module/test_case_0/output/output_0.txt"

# Generated at 2022-06-25 12:24:17.418782
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('"XYF=4dH') == '"XYF=4dH'
    assert ansible_native_concat('XYF=4dH') == 'XYF=4dH'


# Generated at 2022-06-25 12:24:26.536893
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test case 0
    test_case_0()
    # Test case 1
    str_0 = 'svc.method'
    var_0 = ansible_native_concat(str_0)
    # Test case 2
    str_0 = 'svc.method'
    var_0 = ansible_native_concat(str_0)
    # Test case 3
    str_0 = 'svc.method'
    var_0 = ansible_native_concat(str_0)
    # Test case 4
    str_0 = 'svc.method'
    var_0 = ansible_native_concat(str_0)
    # Test case 5
    str_0 = 'svc.method'
    var_0 = ansible_native_concat(str_0)
    # Test case 6

# Generated at 2022-06-25 12:24:34.274513
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_1 = ansible_native_concat(['"', 'X', 'Y', 'F', '=', '4', 'd', 'H'])
    assert var_1 == 'XYF=4dH'

    var_2 = ansible_native_concat(['4', 'd'])
    assert var_2 == '4d'

    var_3 = ansible_native_concat(['X', 'Y', 'F', '=', '"', '4', 'd', 'H'])
    assert var_3 == 'XYF="4dH'

    var_4 = ansible_native_concat(['X', '"', 'Y', 'F', '=', '4', 'd', 'H', '"'])
    assert var_4 == 'X"YF=4dH"'

   

# Generated at 2022-06-25 12:24:41.778904
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_1 = '"XYF=4dH'
    var_1 = ansible_native_concat(str_1)
    str_2 = '\n'
    var_2 = ansible_native_concat(str_2)
    str_3 = 'Y=7\n'
    var_3 = ansible_native_concat(str_3)
    str_4 = 'XYF=4dH'
    var_4 = ansible_native_concat(str_4)
    str_5 = 'XYF=4dH'
    var_5 = ansible_native_concat(str_5)
    str_6 = 'Y=7'
    var_6 = ansible_native_concat(str_6)
    str_7 = 'Y'

# Generated at 2022-06-25 12:24:47.357454
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test with single argument.
    var_1 = ansible_native_concat('Example string')
    assert(var_1 == 'Example string')

    # Test with two arguments.
    var_2 = ansible_native_concat('Example string', 42)
    assert(var_2 == 'Example string42')

    # Test with 3 arguments
    var_3 = ansible_native_concat(1, 2, 3)
    assert(var_3 == 123)

    # Test with list of arguments
    var_4 = ansible_native_concat([1, 2, 3])
    assert(var_4 == 123)

    # Test with dictionary of arguments
    var_5 = ansible_native_concat({'a':1, 'b':2, 'c':3})

# Generated at 2022-06-25 12:24:51.542967
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert None == ansible_native_concat(None)
    assert 'a' == ansible_native_concat('a')
    assert 'a' == ansible_native_concat(['a'])
    assert 'ab' == ansible_native_concat(['a', 'b'])
    assert 'a' == ansible_native_concat(['a', 'b', 'c'])
    assert 'a' == ansible_native_concat('a', 'b')
    assert 'ab' == ansible_native_concat(['a'], 'b')
    assert 'abc' == ansible_native_concat(['a'], 'b', 'c')


# Generated at 2022-06-25 12:24:59.467000
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test with original values
    str_0 = '"XYF=4dH'
    test_case_0()

    # Test with post-parsing values
    str_0 = '"XYF=4dH'
    test_case_0()

    # Test with post-evaluation values
    str_0 = '"XYF=4dH'
    test_case_0()



# Generated at 2022-06-25 12:25:01.248572
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()


# Generated at 2022-06-25 12:25:03.667287
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '"XYF=4dH'
    var_0 = ansible_native_concat(str_0)

    assert var_0 == 'XYF=4dH'

# Generated at 2022-06-25 12:25:11.638469
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert 'XYF=4dH' == ansible_native_concat('"XYF=4dH')
    assert "XYF=4dH" == ansible_native_concat('XYF=4dH')
    assert "XYF=4dH" == ansible_native_concat('"XYF=4dH"')
    assert "ZG94bmV0d29ya3MuY29tLzEuMC9zVHlwZS9TdHJpbmcv" == ansible_native_concat('ZG94bmV0d29ya3MuY29tLzEuMC9zVHlwZS9TdHJpbmcv')

# Generated at 2022-06-25 12:25:19.430131
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert callable(ansible_native_concat)
    assert isinstance(ansible_native_concat('"XYF=4dH'), text_type)
    assert ansible_native_concat('"XYF=4dH') == '"XYF=4dH'
    assert isinstance(ansible_native_concat(container_to_text('"XYF=4dH')), text_type)
    assert ansible_native_concat(container_to_text('"XYF=4dH')) == '"XYF=4dH'
    assert isinstance(ansible_native_concat(['"XYF=4dH']), text_type)
    assert ansible_native_concat(['"XYF=4dH']) == '"XYF=4dH'

# Generated at 2022-06-25 12:25:28.233113
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    '''
    Test function ansible_native_concat
    '''
    # Get the module object
    from ansible.module_utils.common.text.native_concat import ansible_native_concat as function

    # Test function with two string input parameters
    print("\nTesting {} with two string input parameters".format(function.__name__))
    str_0 = '"XYF=4dH'
    str_1 = '"XYF=4dH'
    var_0 = ansible_native_concat(str_0)
    print("Expected {}".format(str_0))
    print("Actual {}".format(var_0))
    assert var_0 == str_0


if __name__ == '__main__':
    test_ansible_native_concat()

# Generated at 2022-06-25 12:25:34.112954
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '"XYF=4dH'
    var_0 = ansible_native_concat(str_0)



# Generated at 2022-06-25 12:25:44.205314
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # xfail: py2.6 doesn't understand string
    assert u"XYF=4dH" == ansible_native_concat(unicode("XYF=4dH"))

    # xfail: py2.6 doesn't understand string
    assert u"XYF=4dH" == ansible_native_concat(text_type("XYF=4dH"))

    # xfail: py2.6 doesn't understand string
    assert u"XYF=4dH" == ansible_native_concat(u"XYF=4dH")

    assert u"XYF=4dH" == ansible_native_concat("XYF=4dH")

    assert u"" == ansible_native_concat(u"")

    assert u"" == ansible_native_concat("")


# Generated at 2022-06-25 12:25:45.381831
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == 'XYF=4dH'

# Generated at 2022-06-25 12:25:52.509319
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = ansible_native_concat(
        [
            '"XYF=4dH',
            '"XYF=4dH"',
            '"XYF=4dH'
        ])
    assert var_0 == 'XYF=4dHXYF=4dHXYF=4dH'
    var_0 = ansible_native_concat(
        [
            '"XYF=4',
            'dH"',
            '"XYF=4dH'
        ])
    assert var_0 == 'XYF=4dHXYF=4dH'
    var_0 = ansible_native_concat(
        [
            '"XYF=4',
            '"XYF=4',
            'dH"',
            'dH"'
        ])

# Generated at 2022-06-25 12:25:58.348253
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '"XYF=4dH'
    var_0 = ansible_native_concat(str_0)



# Generated at 2022-06-25 12:26:01.159999
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = 'XYF=4dH'
    var_0 = var_0.encode('utf-8')
    var_1 = ansible_native_concat(var_0)

# Generated at 2022-06-25 12:26:07.727206
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    try:
        from ansible.module_utils.common.text import to_text
    except ImportError:
        from ansible.module_utils.common.text import to_text

    assert to_text("this is a test") == ansible_native_concat(["this", " ", "is", " ", "a", " ", "test"])
    # TODO: verify the deprecation warning is emitted.
    from ansible.utils.hashing import md5s, checksum_s

    assert checksum_s("this is a test") == md5s("this is a test")

# Generated at 2022-06-25 12:26:16.489671
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    input_0 = u'hi'
    output_0 = ansible_native_concat(input_0)
    assert output_0 == 'hi'
    input_1 = u'23'
    output_1 = ansible_native_concat(input_1)
    assert output_1 == 23
    input_2 = u'4.5'
    output_2 = ansible_native_concat(input_2)
    assert output_2 == 4.5
    input_3 = u'true'
    output_3 = ansible_native_concat(input_3)
    assert output_3 is True
    input_4 = u'false'
    output_4 = ansible_native_concat(input_4)
    assert output_4 is False
    input_5 = u'[]'
    output_

# Generated at 2022-06-25 12:26:23.727228
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(argument_spec={})
    module.exit_json = test_case_0
    import ansible.module_utils.basic
    ansible.module_utils.basic.ANSIBLE_MODULE_STDERR = '-'
    import builtins
    builtins.module = module
    import ansible_collections.ansible.builtin.plugins.filter.json_query
    ansible_collections.ansible.builtin.plugins.filter.json_query._fail_on_undefined(None)

# Generated at 2022-06-25 12:26:26.180852
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    f = ansible_native_concat(['test_val_0'])
    assert f == 'test_val_0'


# Generated at 2022-06-25 12:26:35.678659
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # If a single value is provided, this value is returned.
    assert ansible_native_concat("123") == "123"

    # Multiple values are concatenated using ansible.utils.native_jinja_concat
    assert ansible_native_concat("4", "56", "78") == "45678"

    # If the result can be parsed with ast.literal_eval it is.
    assert ansible_native_concat("'apple'", "", " + 1") == "apple + 1"
    assert ansible_native_concat("'apple'", "", " + 1") == "apple + 1"
    assert ansible_native_concat("'a'", " + '", "b'") == "ab"
    assert ansible_native_concat("4", " + ", "2") == 6


# Generated at 2022-06-25 12:26:44.736072
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'simple string'
    var_0 = ansible_native_concat(str_0)

    assert var_0 == 'simple string'

    str_1 = '{{ a|default(b) }}'
    str_2 = 'any string'
    var_1 = ansible_native_concat(str_1, str_2)

    assert var_1 == 'any string'

    # test that it works with list as well as strings
    var_2 = ansible_native_concat([str_1, str_2])

    assert var_2 == 'any string'

    str_1 = '{{ a|default(b) }}'
    str_2 = 'any string'
    str_3 = '123'

# Generated at 2022-06-25 12:26:47.552368
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    str_0 = '"XYF=4dH'
    var_0 = ansible_native_concat(str_0)

    assert var_0 == 'XYF=4dH'




# Generated at 2022-06-25 12:26:48.413568
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()

# Generated at 2022-06-25 12:26:58.775868
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Is type(ansible_native_concat(<data type>)) == <type>
    assert(isinstance(ansible_native_concat('"XYF=4dH'), text_type))
    assert(isinstance(ansible_native_concat(['"XYF=4dH']), text_type))

    # Test that ansible_native_concat raises an exception when the input
    # contains an undefined value

    def _fail_on_undefined(data):
        """Recursively find an undefined value in a nested data structure
        and properly raise the undefined exception.
        """
        if isinstance(data, Mapping):
            for value in data.values():
                _fail_on_undefined(value)
        elif is_sequence(data):
            for item in data:
                _fail_on_

# Generated at 2022-06-25 12:27:08.263936
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_2 = '{"testcase_0": "XYF=4dH"}'
    var_3 = ansible_native_concat(var_2)
    if container_to_text(var_3) != '{"testcase_0": "XYF=4dH"}':
        print('Failed: testcase_0')
        exit(1)
    var_4 = ansible_native_concat('')
    if container_to_text(var_4) != '':
        print('Failed: testcase_1')
        exit(1)
    var_5 = ansible_native_concat('str')
    if container_to_text(var_5) != 'str':
        print('Failed: testcase_2')
        exit(1)
    var_6 = ansible_native_

# Generated at 2022-06-25 12:27:09.005311
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == 'XYF=4dH'



# Generated at 2022-06-25 12:27:11.117036
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('b7cwTZaQV') == 'b7cwTZaQV'


# Generated at 2022-06-25 12:27:14.284685
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '"XYF=4dH'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == '"XYF=4dH'

    



# Generated at 2022-06-25 12:27:23.828704
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '"XYF=4dH/e'
    str_1 = 'Zo0C/fE\x7f"'
    str_2 = '''['
    '''
    var_0 = u"'.join([to_text(_fail_on_undefined(v)) for v in chain(str_0, str_1, str_2)])"
    str_0 = "'.join([to_text(_fail_on_undefined(v)) for v in chain(str_0, str_1, str_2)])"
    capped = container_to_text(str_0, truncate=50)

    assert capped == "'.join([to_text(_fail_on_undefined(v)) for v in chain(str_0, str_1, str_2)])"

    # Test _fail

# Generated at 2022-06-25 12:27:25.005589
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert isinstance(test_case_0(), string_types)

# Generated at 2022-06-25 12:27:27.142537
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert type(test_case_0()) == text_type
    assert 'XYF=4dH' == test_case_0()

# Generated at 2022-06-25 12:27:34.034304
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # FIXME: replace with proper unit test
    from ansible.module_utils._text import to_text
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.common.text.converters import to_int, to_float
    from ansible.module_utils.six import string_types, integer_types, PY2

    def test(in_val, out_val, out_type):
        assert ansible_native_concat(in_val) == out_val
        if out_type:
            assert isinstance(ansible_native_concat(in_val), out_type)

    # Test basic types
    test("'Hello'", 'Hello', string_types)
    test("'Hello' + 'World'", 'HelloWorld', string_types)

# Generated at 2022-06-25 12:27:43.978410
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # noinspection PyUnusedLocal
    test_cases = [
        # (Exception, (args,), {kwargs}),
        (ValueError, ('ansible_native_concat() takes exactly one argument (0 given)',), {}),
        (ValueError, ('ansible_native_concat() takes exactly one argument (2 given)',), {}),
        # ('XYF=4dH',),
    ]

    for test_case, args, kwargs in test_cases:
        try:
            ansible_native_concat(*args, **kwargs)
        except test_case as exc:
            assert str(exc) == container_to_text(args[0]), 'Got {0} exception with message {1}, expected {2}'.format(
                type(exc), str(exc), args[0]
            )

# Generated at 2022-06-25 12:27:56.704368
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    func = ansible_native_concat
    func('2\x00\x00')
    # assert func(str_0) == var_0
    # assert func(str_1) == var_1
    # assert func(str_2) == var_2
    # assert func(str_3) == var_3
    # assert func(str_4) == var_4
    # assert func(str_5) == var_5
    # assert func(str_6) == var_6
    # assert func(str_7) == var_7
    # assert func(str_8) == var_8
    # assert func(str_9) == var_9
    # assert func(str_10) == var_10
    # assert func(str_11) == var_11
    # assert func(str_12

# Generated at 2022-06-25 12:27:57.767312
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # xfail - raises ValueError: malformed string
    test_case_0()



# Generated at 2022-06-25 12:28:02.908182
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    arg_0 = []
    assert ansible_native_concat(arg_0) is None

    arg_1 = ['test', 'val']
    assert ansible_native_concat(arg_1) == "testval"

    arg_2 = ['test', 'val', 'test']
    assert ansible_native_concat(arg_2) == "testvaltest"

    arg_3 = [1, 2]
    assert ansible_native_concat(arg_3) == 3

    arg_4 = ['1', 2]
    assert ansible_native_concat(arg_4) == "12"

    arg_5 = ['1', '2', 3]
    assert ansible_native_concat(arg_5) == "123"

    arg_6 = ['1', 1]
    assert ansible_

# Generated at 2022-06-25 12:28:11.229679
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test cases from the YAML spec
    assert ansible_native_concat('123') == 123
    assert ansible_native_concat('123 456') == '123 456'
    assert ansible_native_concat('"123"') == '123'
    assert ansible_native_concat('"123" "456"') == '123 456'
    assert ansible_native_concat('123 "456"') == '123 456'
    assert ansible_native_concat('"123" 456') == '123 456'

    # Additional tests
    assert ansible_native_concat(123) == 123
    assert ansible_native_concat('123') == 123
    assert ansible_native_concat('"123"') == 123

# Generated at 2022-06-25 12:28:12.302866
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert isinstance(ansible_native_concat(None), str)



# Generated at 2022-06-25 12:28:16.290078
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '"XYF=4dH'
    var_0 = ansible_native_concat(str_0)
    assert isinstance(var_0, str) is True
    expected = 'XYF=4dH'
    assert var_0 == expected

# Generated at 2022-06-25 12:28:21.140686
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Test with this list of arguments
    arg0 = ["Hello World!"]

    # These are the test results
    res0 = "Hello World!"

    # Call the function
    result = ansible_native_concat(arg0)

    # Check with these values
    assert result == res0, "Incorrect return value for ansible_native_concat('Hello World!')"


# Generated at 2022-06-25 12:28:29.401113
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('abc') == 'abc'
    assert ansible_native_concat('abc', 'def') == 'abcdef'
    assert ansible_native_concat('a', 'b', 'c', 'd', 'e', 'f') == 'abcdef'
    assert ansible_native_concat('a', 'b', 'c', 'd', 'e', 'f', 'g') == 'abcdefg'
    assert ansible_native_concat('a', 'b', 'c', 'd', 'e', 'f', 'g', 'h') == 'abcdefgh'
    assert ansible_native_concat('a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i') == 'abcdefghi'
    assert ansible_native_

# Generated at 2022-06-25 12:28:38.344065
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test with one argument
    var_0 = '\'"XYF=4dH'
    str_0 = ansible_native_concat(var_0)
    assert type(str_0) == text_type
    assert str_0 is var_0

    # Test with two arguments
    var_1 = '\'"XYF=4dH'
    var_2 = '\'"XYF=4dH'
    str_0 = ansible_native_concat(var_1, var_2)
    assert type(str_0) == text_type
    assert str_0 == container_to_text(var_1) + container_to_text(var_2)

    # Test with three arguments
    var_3 = '\'"XYF=4dH'

# Generated at 2022-06-25 12:28:46.265931
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'XYF=4dH'
    var_0 = ansible_native_concat(str_0)
    assert str(var_0) == 'XYF=4dH'

    str_1 = 'ABCD'
    var_1 = ansible_native_concat((str_0, str_1))
    assert str(var_1) == 'XYF=4dHABCD'

    str_2 = '"""XYF=4dH'
    str_3 = '"""XYF=4dH'
    var_2 = ansible_native_concat((str_2, str_3))
    assert str(var_2) == '"""XYF=4dH"""XYF=4dH'

    var_3 = ansible_native_concat(str_2)
   

# Generated at 2022-06-25 12:28:54.424068
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(["test", "test2"]) == "testtest2"
    assert ansible_native_concat(["test1", "test2"]) == "test1test2"
    assert ansible_native_concat(["test1", "test2"]) == "test1test2"
    assert ansible_native_concat(["test1", "test2"]) == "test1test2"
    assert ansible_native_concat(["test1", "test2"]) == "test1test2"
    assert ansible_native_concat(["test1", "test2"]) == "test1test2"
    assert ansible_native_concat(["test1", "test2"]) == "test1test2"

# Generated at 2022-06-25 12:28:57.800124
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Compile with python optimization level 0
    flags = ['-O0']

    # Load the native module
    native_module = types.ModuleType(__name__)
    native_module.ansible_native_concat = ansible_native_concat
    exec(compile('\n'.join(inspect.getsourcelines(ansible_native_concat)[0]),
                 '<test_code>',
                 'exec',
                 flags, 1),
         {},
         native_module.__dict__)

    # Run test case
    test_case_0()
    print_results(native_module)

# Generated at 2022-06-25 12:28:58.638260
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert ansible_native_concat('"XYF=4dH') == '"XYF=4dH'

# Generated at 2022-06-25 12:29:08.283771
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Unit test for ansible_native_concat
    assert test_case_0() == u'XYF=4dH', 'failing example'

    # Not implemented:
    # assert test_case_1() == u'failing example', 'failing example'
    # assert test_case_2() == u'failing example', 'failing example'
    # assert test_case_3() == u'failing example', 'failing example'
    # assert test_case_4() == u'failing example', 'failing example'
    # assert test_case_5() == u'failing example', 'failing example'
    # assert test_case_6() == u'failing example', 'failing example'
    # assert test_case_7() == u'failing example', 'failing example'
    #