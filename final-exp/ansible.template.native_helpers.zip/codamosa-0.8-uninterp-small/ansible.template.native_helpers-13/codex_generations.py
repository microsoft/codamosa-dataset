

# Generated at 2022-06-25 12:19:24.398379
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
	string = 'Test ansible_native_concat function'
	str_0 = 'Test'
	var_0 = ansible_native_concat(str_0)
	string1 = 'Test is : ' + container_to_text(var_0)
	if var_0 == 'Test':
		pass
	else:
		raise Exception('Failed: {}'.format(string1))
	str_1 = 'Test ansible_native_concat function'
	var_1 = ansible_native_concat(str_1)
	string2 = 'Test ansible_native_concat function is : ' + container_to_text(var_1)
	if var_1 == 'Test ansible_native_concat function':
		pass

# Generated at 2022-06-25 12:19:27.958085
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert 'current_action' in locals()
    assert 'current_action' not in globals()

    assert test_case_0() == 'current_action'
# END OF FILE

# Generated at 2022-06-25 12:19:37.294169
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a', 'b', 'c']) == "abc"
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(('a', 'b', 'c')) == "abc"
    assert ansible_native_concat(set(['a', 'b', 'c'])) == "abc"
    assert ansible_native_concat(['a', 'b', 'c'], ['d', 'e', 'f']) == "abcdef"
    assert ansible_native_concat(['a', 'b', 'c'], ['d', 'e', 'f'], ['g', 'h', 'i']) == "abcdefghi"

# Generated at 2022-06-25 12:19:38.556154
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test PoC that illustrates the problem
    test_case_0()

# Generated at 2022-06-25 12:19:40.057741
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()

# Generated at 2022-06-25 12:19:48.286431
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    str_0 = "a"
    var_0 = ansible_native_concat(str_0)
    assert var_0 == "a"
    str_0_0 = "a"
    str_1 = "b"
    var_0_0 = ansible_native_concat([str_0_0, str_1])
    assert var_0_0 == "ab"
    str_0_1 = "a"
    str_1_0 = "b"
    str_2 = "c"
    var_0_1 = ansible_native_concat([str_0_1, str_1_0, str_2])
    assert var_0_1 == "abc"
    str_0_

# Generated at 2022-06-25 12:19:53.388695
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_1 = 'ansible_native_concat'
    str_2 = str_1
    var_1 = ansible_native_concat(str_2)
    str_3 = 'expected type'
    str_4 = str_3
    var_2 = isinstance(var_1, str_4)
    assert var_2 == True


# Generated at 2022-06-25 12:19:58.527450
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    '''
    Tests for ansible_native_concat
    '''
    s = "Hello, World!"
    c = ansible_native_concat(s)
    assert c == s
    s = [1, 2, 3]
    c = ansible_native_concat(s)
    assert c == s
    s = {'a': 1, 'b': 2}
    c = ansible_native_concat(s)
    assert c == s



# Generated at 2022-06-25 12:20:00.681688
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Arguments for function ansible_native_concat
    str_0 = ''
    var_0 = ansible_native_concat(str_0)
    assert var_0 == None


# Generated at 2022-06-25 12:20:06.234431
# Unit test for function ansible_native_concat

# Generated at 2022-06-25 12:20:18.419892
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_1 = 'foo ,bar'
    var_1 = ansible_native_concat(str_1)
    assert var_1 == 'foo ,bar'

    str_2 = ' foo , bar '
    var_2 = ansible_native_concat(str_2)
    assert var_2 == ' foo , bar '

    str_3 = [u"foo", u"bar"]
    var_3 = ansible_native_concat(str_3)
    assert var_3 == u'foobar'

    str_4 = [u"foo", u"\n \n bar"]
    var_4 = ansible_native_concat(str_4)
    assert var_4 == u'foo\n \n bar'

    str_5 = [u"foo", u"{{ bar }}"]
    var

# Generated at 2022-06-25 12:20:27.541543
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = ''
    var_1 = 'foo'
    var_2 = 'bar'
    var_5 = [var_1, var_2]
    var_3 = '[' + var_1 + ', ' + var_2 + ']'
    var_4 = [var_5, var_5]
    assert container_to_text(ansible_native_concat(var_0)) == var_0
    assert container_to_text(ansible_native_concat(var_1)) == var_1
    assert container_to_text(ansible_native_concat(var_2)) == var_2
    assert container_to_text(ansible_native_concat(var_3)) == var_3
    assert container_to_text(ansible_native_concat(var_4)) == var

# Generated at 2022-06-25 12:20:28.442855
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = ansible_native_concat


# Generated at 2022-06-25 12:20:40.033990
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Function should return str type when string is provided
    str_0 = "hello"
    str_1 = "'hello'"
    str_2 = '"hello"'
    str_3 = "hello" "world"

    str_4 = """hello"""
    str_5 = """hello""" """world"""

    str_6 = """
    hello"""
    str_7 = """
    hello""" """
    world"""

    str_8 = """
    hello
    """
    str_9 = """
    hello
    """ """
    world
    """

    str_10 = """
             hello"""
    str_11 = """
             hello""" """
             world"""

    str_12 = """
             hello
             """
    str_13 = """
             hello
             """ """
             world
             """


# Generated at 2022-06-25 12:20:49.314138
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Convert a value to a native Python type if possible, otherwise
    return the value unchanged. This function is registered as a filter
    in a Jinja environment and is used to test expressions.
    """
    test = [
        {
            'input': '',
            'expected': None
        },
        {
            'input': '0',
            'expected': 0
        },
        {
            'input': '"0"',
            'expected': '0'
        },
        {
            'input': '"a" ~ "b"',
            'expected': 'ab'
        },
        {
            'input': 'a ~ "b"',
            'expected': 'ab'
        }
    ]

    for x in test:
        input_data = x['input']
        expected = x['expected']

        result

# Generated at 2022-06-25 12:20:50.081725
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() is None



# Generated at 2022-06-25 12:20:53.261383
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('abc') == 'abc'
    assert ansible_native_concat('abc') != 'cba'
    assert ansible_native_concat('a') == 'a'
    assert ansible_native_concat('a' + 'b' + 'c') == 'abc'
    assert ansible_native_concat(['a', 'bb', 'ccc']) == 'abbccc'


# Generated at 2022-06-25 12:20:58.897462
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    str_0 = 'str_0'
    str_1 = 'str_1'
    str_2 = 'str_2'
    str_3 = 'str_3'
    str_4 = 'str_4'
    str_5 = 'str_5'
    str_6 = 'str_6'
    str_7 = 'str_7'
    str_8 = 'str_8'
    str_9 = 'str_9'
    str_10 = 'str_10'
    str_11 = 'str_11'
    str_12 = 'str_12'
    str_13 = 'str_13'
    str_14 = 'str_14'
    str_15 = 'str_15'
    str_16 = 'str_16'
    str_17 = 'str_17'
   

# Generated at 2022-06-25 12:21:01.662506
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # TODO implementation
    pass
# end of test_ansible_native_concat


# Generated at 2022-06-25 12:21:02.883167
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    out = ansible_native_concat(test_case_0)

# Generated at 2022-06-25 12:21:12.813326
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    try:
        test_case_0()
    except AssertionError as e:
        print(container_to_text(e.args[0]))
        raise


#
# ansible-playbook --syntax-check test_jinja_native_types.yml -v

# idempotent:
#   - name: test jinja native types
#     debug:
#       msg: "{{ (1 + 1) | int | string }}"
#   - name: test jinja native types
#     debug:
#       msg: "{{ 'ishikawa2018' | int }}"

# Generated at 2022-06-25 12:21:14.978556
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '~'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == str_0


# Generated at 2022-06-25 12:21:21.668777
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_1 = '~'
    var_1 = ansible_native_concat(str_1)
    assert isinstance(var_1, string_types)

    str_2 = '7'
    var_2 = ansible_native_concat(str_2)
    assert isinstance(var_2, int)

    str_3 = 'str'
    var_3 = ansible_native_concat(str_3)
    assert isinstance(var_3, string_types)

    str_4 = "'str'"
    var_4 = ansible_native_concat(str_4)
    assert isinstance(var_4, string_types)

    str_5 = '{'
    var_5 = ansible_native_concat(str_5)

# Generated at 2022-06-25 12:21:23.494354
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Validate ansible_native_concat function"""
    test_case_0()



# Generated at 2022-06-25 12:21:25.916148
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = '~'
    var_1 = ansible_native_concat(var_0)
    assert var_1 == '~'

# Generated at 2022-06-25 12:21:29.637179
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    for i in range(100):
        test_case_0()


if __name__ == '__main__':
    for i in range(100):
        test_ansible_native_concat()

# Generated at 2022-06-25 12:21:30.861550
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert type(test_case_0()) == str



# Generated at 2022-06-25 12:21:39.247835
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '~'
    var_0 = ansible_native_concat(str_0)
    ansible_native_concat([])
    ansible_native_concat(['', '', '', ''])
    var_1 = ansible_native_concat(['abc', 'def'])
    var_2 = ansible_native_concat(['123', '456'])
    var_3 = ansible_native_concat(['123', '456'])
    var_4 = ansible_native_concat(['123.5', '456.7'])
    var_5 = ansible_native_concat(['123.5', '456.7'])
    var_6 = ansible_native_concat(['123.5', '456'])
    var_7 = ansible

# Generated at 2022-06-25 12:21:49.733948
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(None) == None
    assert ansible_native_concat('') == ''
    assert ansible_native_concat('1') == '1'
    assert ansible_native_concat('1 2') == '1 2'
    assert ansible_native_concat('a b c') == 'a b c'
    assert container_to_text(ansible_native_concat("a b c")) == "a b c"
    assert ansible_native_concat('1 2 3') == "1 2 3"
    assert container_to_text(ansible_native_concat("1 2 3")) == "1 2 3"
    assert ansible_native_concat('1 2') == "1 2"

# Generated at 2022-06-25 12:21:54.342725
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    result = ansible_native_concat()
    assert result == undefined  # Default return value, if not supplied. Result can be arbitrary.
    result = ansible_native_concat(
        '~'
    )
    assert result == undefined  # Default return value, if not supplied. Result can be arbitrary.

# Generated at 2022-06-25 12:22:00.390612
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == "~"



# Generated at 2022-06-25 12:22:01.681033
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['~']) == '~'

# Generated at 2022-06-25 12:22:03.186114
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('~') == '~'

# Generated at 2022-06-25 12:22:12.556810
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Case 1: string
    str_0 = '~'
    str_1 = "Ansible is a radically simple IT automation platform that makes your applications and systems easier to deploy. Avoid writing scripts or custom code to deploy and update your applications \u2013 automate in a language that approaches plain English, using SSH, with no agents to install on remote systems."
    str_2 = "Ansible is a radically simple IT automation platform that makes your applications and systems easier to deploy."
    str_3 = "Ansible is a radically simple IT automation platform that makes your applications and systems easier to deploy."

    # Case 2: string (with leading space)
    str_sp_0 = ' ~'

# Generated at 2022-06-25 12:22:23.365533
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # concatenate native Python types, including strings
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat((1, 2, 3)) == [1, 2, 3,]
    assert ansible_native_concat(['foo', u'bar']) == to_text(u'foobar')
    assert ansible_native_concat([to_text(u'foo'), u'bar']) == to_text(u'foobar')
    assert ansible_native_concat([to_text(u'foo'), u'bar', True]) == to_text(u'foobarTrue')

# Generated at 2022-06-25 12:22:30.102770
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Function to setup the test case
    def test_case_setup(test_params_0):
        str_0 = '~'
        str_1 = '^'
        str_2 = '='
        str_3 = '~'
        str_4 = '!'
        var_0 = ansible_native_concat(str_0, str_1, str_2, str_3, str_4)
    
    # Setup variables for the tests
    test_case_setup(test_params_0)
    
    # Test the function output
    assert var_0 == '~'

# Generated at 2022-06-25 12:22:34.788680
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['hello', 'world']) == 'helloworld'
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat([1, '2', 3]) == '123'
    assert ansible_native_concat([[1, 2, 3], [4, 5, 6]]) == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-25 12:22:45.450702
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_input_0 = '~'
    str_input_1 = '~/.'
    str_input_2 = '~/../.'
    str_input_3 = '/a/b/c'
    str_input_4 = './'
    str_input_5 = '../'
    str_input_6 = 'file.txt'
    str_input_7 = '/a/b/c'
    str_input_8 = 'file.txt'
    str_input_9 = './'
    str_input_10 = '../'
    str_input_11 = '123'
    str_input_12 = '123-1.2'
    str_input_13 = '123.4'
    str_input_14 = '123.4.1'

# Generated at 2022-06-25 12:22:47.499767
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '~'
    var_0 = ansible_native_concat(str_0)
    assert var_0 is None



# Generated at 2022-06-25 12:22:50.735612
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '~'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == '~'



# Generated at 2022-06-25 12:23:09.644162
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = ansible_native_concat('~')
    print(var_0)
    print(type(var_0))
    var_1 = ansible_native_concat(['~'])
    print(var_1)
    print(type(var_1))
    var_2 = ansible_native_concat(['~', '~'])
    print(var_2)
    print(type(var_2))
    var_3 = ansible_native_concat(['~', '~'])
    print(var_3)
    print(type(var_3))
    print(ansible_native_concat(['~', '~']))
    print(type(ansible_native_concat(['~', '~'])))


# Generated at 2022-06-25 12:23:17.659369
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '~'
    var_0 = ansible_native_concat(str_0)
    str_1 = '0.0'
    var_1 = ansible_native_concat(str_1)
    str_2 = 'baz'
    var_2 = ansible_native_concat(str_2)
    str_3 = 'True'
    var_3 = ansible_native_concat(str_3)

    list_0 = [var_1, var_3]
    var_4 = ansible_native_concat(list_0)

    dict_0 = {'baz': var_0, 'foo': var_1, 'foobar': var_2, 'fooz': var_2}
    var_5 = ansible_native_concat(dict_0)

# Generated at 2022-06-25 12:23:19.052043
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var = ansible_native_concat('foo')
    assert var == 'foo'

# Generated at 2022-06-25 12:23:20.556437
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = test_case_0()
    assert var_0 == '~'



# Generated at 2022-06-25 12:23:21.454680
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() is None

# Generated at 2022-06-25 12:23:22.362268
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == '~'

# Generated at 2022-06-25 12:23:29.340826
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '~'
    var_0 = ansible_native_concat(str_0)
    assert var_0 is None

    str_1 = ''''~'\n'''
    var_1 = ansible_native_concat(str_1)
    assert var_1 is None

    str_2 = ''''~'\n'''
    var_2 = ansible_native_concat(str_2)
    assert var_2 is None

    str_3 = '~'
    var_3 = ansible_native_concat(str_3)
    assert var_3 == '~'

# Generated at 2022-06-25 12:23:34.825497
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert type(ansible_native_concat()) == types.NoneType
    assert type(ansible_native_concat(None)) == types.NoneType
    assert type(ansible_native_concat(1)) == int
    assert type(ansible_native_concat([1, 2, 3])) == list
    assert type(ansible_native_concat(('a', 'b', 'c'))) == tuple
    assert type(ansible_native_concat({'a': 1, 'b': 2, 'c': 3})) == dict
    assert type(ansible_native_concat("abc")) == str
    assert type(ansible_native_concat("abc", "def")) == str
    assert type(ansible_native_concat("abc", "def", None)) == str



# Generated at 2022-06-25 12:23:38.843133
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '~'
    assert ansible_native_concat(str_0) == '~', "The function ansible_native_concat returned value is not the expected one"

# Test runner

# Generated at 2022-06-25 12:23:41.634016
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert u''.join(['~']) == ansible_native_concat(u'~')
    assert '~'.join([u'~']) == ansible_native_concat(u'~'.join(['~']))

# Generated at 2022-06-25 12:23:51.235142
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()



# Generated at 2022-06-25 12:23:58.858001
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test cases from real Ansible code
    # I'm just using static data as input because I don't want to test
    # Jinja2 which compiles the nodes into Python code

    # Test converted from
    # test/units/parsers/argspec/test_native_concat_undefined.py
    # in Ansible
    # (Test case 0)
    str_0 = '~'
    var_0 = ansible_native_concat(str_0)
    assert_equals(var_0, '~')

    # Test converted from
    # test/units/parsers/argspec/test_native_concat_undefined.py
    # in Ansible
    # (Test case 1)
    str_0 = '{foo}'

# Generated at 2022-06-25 12:24:09.994107
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat("0") == 0
    assert ansible_native_concat("0.0") == 0.0
    assert ansible_native_concat("0.0.0") == "0.0.0"
    assert ansible_native_concat("1") == 1
    assert ansible_native_concat("1.1") == 1.1
    assert ansible_native_concat("1.1.1") == "1.1.1"
    assert ansible_native_concat("FALSE") == "FALSE"
    assert ansible_native_concat("FALSE") == "FALSE"
    assert ansible_native_concat("NONE") == "NONE"
    assert ansible_native_concat("NONE") == "NONE"
    assert ansible_

# Generated at 2022-06-25 12:24:12.200892
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '~'
    var_0 = ansible_native_concat(str_0)

    assert var_0 == '~'



# Generated at 2022-06-25 12:24:13.031781
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()

# Generated at 2022-06-25 12:24:14.334575
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '~'
    var_0 = ansible_native_concat(str_0)


# Generated at 2022-06-25 12:24:16.216122
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert u'~' == ansible_native_concat(u'~')

# Generated at 2022-06-25 12:24:25.541321
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Concatenate a sequence of compiled nodes to a string
    """
    # Test cases for function ansible_native_concat
    assert ansible_native_concat('~') == '~'
    assert ansible_native_concat('~', '~') == '~~'
    assert ansible_native_concat(ast.parse('True'), ast.parse('False')) == 'TrueFalse'
    assert ansible_native_concat(ast.parse('True'), ast.parse('False')).__class__ == str
    assert ansible_native_concat('~', ast.parse('True'), ast.parse('False')) == '~TrueFalse'
    assert ansible_native_concat('~', ast.parse('True'), ast.parse('False')).__class__ == str
    assert ansible_native_concat

# Generated at 2022-06-25 12:24:32.192058
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # assert test_case_0() == '~', 'Test failed.'

    # assert len(module_return) == 2, 'Test failed.'

    # assert module_return[0] == None, 'Test failed.'
    assert module_return == None, 'Test failed.'
    # assert module_return[1] == None, 'Test failed.'
    # assert module_return[1] == ansible_doc, 'Test failed.'

    print(module_return)
    # print(module_return[1])

    # assert module_return == ansible_return, 'Test failed.'
    # pprint(module_return)
    # pprint(ansible_return)

    # assert module_return.args == ansible_return.args, 'Test failed.'

    # assert module_return == ansible_return, 'Test failed.'



# Generated at 2022-06-25 12:24:33.385073
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == '~'



# Generated at 2022-06-25 12:24:45.793610
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'str'
    str_1 = 'ing'
    str_2 = 'str'
    generator = (str_0, str_1, str_2)
    expected = 'string'
    actual = ansible_native_concat(generator)
    assert expected == actual



# Generated at 2022-06-25 12:24:50.806787
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '~'
    var_0 = ansible_native_concat(str_0)
    assert var_0 is '~'

    str_1 = """
    {% for i in v %}
    {{ i }}
    {% endfor %}"""
    var_1 = ansible_native_concat(str_1)
    assert var_1 is """
    {% for i in v %}
    {{ i }}
    {% endfor %}"""

    str_2 = """
    {% for i in v %}
{{ i }}
{% endfor %}"""
    var_2 = ansible_native_concat(str_2)
    assert var_2 is """
    {% for i in v %}
{{ i }}
{% endfor %}"""

    str_3

# Generated at 2022-06-25 12:24:59.506454
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    str_0 = '~'
    var_0 = ansible_native_concat(str_0)
    print('var_0 is: {}'.format(var_0))

    str_1 = '~'
    var_1 = ansible_native_concat(str_1)
    print('var_1 is: {}'.format(var_1))

    str_2 = '~'
    var_2 = ansible_native_concat(str_2)
    print('var_2 is: {}'.format(var_2))

    str_3 = '~'
    var_3 = ansible_native_concat(str_3)
    print('var_3 is: {}'.format(var_3))

    str_4 = '~'

# Generated at 2022-06-25 12:25:01.290020
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()

# Generated at 2022-06-25 12:25:03.039575
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '~'
    var_0 = ansible_native_concat(str_0)



# Generated at 2022-06-25 12:25:03.968721
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert None == ansible_native_concat(None)

# Generated at 2022-06-25 12:25:11.848866
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '~'
    var_0 = ansible_native_concat(str_0)
    var_1 = ansible_native_concat(str_0, str_0)
    var_2 = ansible_native_concat(str_0, str_0, str_0)
    var_3 = ansible_native_concat(str_0, str_0, str_0, str_0)
    var_4 = ansible_native_concat(str_0, str_0, str_0, str_0, str_0)
    var_5 = ansible_native_concat(str_0, str_0, str_0, str_0, str_0, str_0)

# Generated at 2022-06-25 12:25:19.986471
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('~') == '~'
    assert ansible_native_concat('~', '~') == '~~'
    assert ansible_native_concat(u'~') == u'~'
    assert ansible_native_concat(1) == 1
    assert ansible_native_concat(1, 2) == '12'
    assert ansible_native_concat(1, 2, 3) == '123'
    assert ansible_native_concat({'k': 'v'}) == {'k': 'v'}
    assert ansible_native_concat(['a', 'b']) == ['a', 'b']
    assert ansible_native_concat([1, 2]) == [1, 2]

# Generated at 2022-06-25 12:25:23.895413
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible_collections.ansible.builtin.plugins.filter.native import ansible_native_concat

    # Test case 0
    str_0 = '~'
    var_0 = ansible_native_concat(str_0)

    print(var_0)


# Generated at 2022-06-25 12:25:31.308465
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('~') is None
    assert ansible_native_concat('') is None
    assert ansible_native_concat('~') is None
    assert ansible_native_concat('~') is None
    assert ansible_native_concat('~') is None
    assert ansible_native_concat('~') is None
    assert ansible_native_concat('~') is None
    assert ansible_native_concat('~') is None
    assert ansible_native_concat('~') is None
    assert ansible_native_concat('~') is None
    assert ansible_native_concat('~') is None
    assert ansible_native_concat('~') is None
    assert ansible_native_concat('~') is None
    assert ansible

# Generated at 2022-06-25 12:25:43.862677
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert container_to_text(test_case_0(str_0, var_0)) == repr(str_0)

# Test case from https://github.com/pallets/jinja/blob/master/src/jinja2/tests/test_nativetypes.py


# Generated at 2022-06-25 12:25:51.435347
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('~') == '~'
    assert ansible_native_concat('~') == '~'
    assert ansible_native_concat('~') == '~'
    assert ansible_native_concat('') == None
    assert ansible_native_concat('') == None
    assert ansible_native_concat('~') == '~'
    assert ansible_native_concat('~') == '~'
    assert ansible_native_concat('~') == '~'
    assert ansible_native_concat('~') == '~'
    assert ansible_native_concat('~') == '~'
    assert ansible_native_concat('~') == '~'
    assert ansible_native_concat('') == None
   

# Generated at 2022-06-25 12:25:56.001793
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('~') == '~'
    result = ansible_native_concat(['~', '~'])
    assert result == '~~'
    result = ansible_native_concat(['~', '~', '~'])
    assert result == '~~~'

# Generated at 2022-06-25 12:25:59.786972
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """
    Test for the function ansible_native_concat
    """
    assert ansible_native_concat('~') == '~'
    assert ansible_native_concat(2) == 2

# Generated at 2022-06-25 12:26:09.529629
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('~') == '~'
    assert ansible_native_concat([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert ansible_native_concat([[1, 2], [3, 4]]) == [[1, 2], [3, 4]]
    assert ansible_native_concat(['abc', 123]) == 'abc123'
    assert ansible_native_concat('abc', 123) == 'abc123'
    assert ansible_native_concat('abc', '123') == 'abc123'
    assert ansible_native_concat('abc', 123, 456) == 'abc123456'
    assert ansible_native_concat('123', 456, 'abc') == '123456abc'
    assert ansible_native_concat

# Generated at 2022-06-25 12:26:17.263289
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Case 1
    str_0 = '~'
    expected_result_0 = '~'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == expected_result_0, "ansible_native_concat returns '{}' but expected '{}'".format(var_0, expected_result_0)

    # Case 2
    str_0 = '~'
    str_1 = '~'
    expected_result_0 = '~~'
    var_0 = ansible_native_concat([str_0, str_1])
    assert var_0 == expected_result_0, "ansible_native_concat returns '{}' but expected '{}'".format(var_0, expected_result_0)

    # Case 3

# Generated at 2022-06-25 12:26:28.025961
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Testing for '~'
    str_0 = '~'
    var_0 = ansible_native_concat(str_0)

    # Testing for '~'
    str_0 = '~'
    var_0 = ansible_native_concat(str_0)

    # Testing for '~'
    str_0 = '~'
    var_0 = ansible_native_concat(str_0)

    # Testing for '~'
    str_0 = '~'
    var_0 = ansible_native_concat(str_0)

    # Testing for '~'
    str_0 = '~'
    var_0 = ansible_native_concat(str_0)

    # Testing for '~'
    str_0 = '~'
    var_0 = ansible

# Generated at 2022-06-25 12:26:36.819038
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '~'
    var_0 = ansible_native_concat(str_0)

# Generated at 2022-06-25 12:26:47.033941
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = '~'
    # Following line should not get translated
    var_1 = ansible_native_concat(var_0)
    # Following line should get translated
    var_2 = ansible_native_concat(var_0)
    assert var_2 == '~'
    var_3 = '~'
    var_4 = '~'
    # Following line should not get translated
    var_5 = ansible_native_concat(var_3)
    # Following line should get translated
    var_6 = ansible_native_concat(var_5)
    assert var_6 == '~~'
    var_7 = [
        '~',
        '~',
        '~'
    ]
    # Following line should not get translated
    var_8 = ansible_native_concat

# Generated at 2022-06-25 12:26:49.684227
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()  
    str_0 = '~'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == '~'


# Generated at 2022-06-25 12:27:09.178808
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(["(('foo') + (',') + ('bar'))"]) == "(('foo') + (',') + ('bar'))"
    assert ansible_native_concat(["('foo')"]) == "('foo')"
    assert ansible_native_concat(["('foo')"]) == "('foo')"
    assert ansible_native_concat(["('foo')"]) == "('foo')"
    assert ansible_native_concat(["('foo')"]) == "('foo')"
    assert ansible_native_concat(["('foo')"]) == "('foo')"
    assert ansible_native_concat(["('foo')"]) == "('foo')"

# Generated at 2022-06-25 12:27:11.781434
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    str_0 = '~'
    test_case_0(str_0)
    """
    str_0 = '~'
    test_case_0(str_0)
    """

# Generated at 2022-06-25 12:27:21.070476
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # https://github.com/pallets/jinja/blob/master/src/jinja2/nativetypes.py
    str_0 = '~'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == '~'
    str_1 = '123'
    var_1 = ansible_native_concat(str_1)
    assert var_1 == 123

    str_2 = '0'
    var_2 = ansible_native_concat(str_2)
    assert var_2 == 0
    str_3 = '-0'
    var_3 = ansible_native_concat(str_3)
    assert var_3 == -0
    str_4 = '-8'

# Generated at 2022-06-25 12:27:25.875078
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # obj_0 == isinstance(var_0, string_types)
    # assert not obj_0, "AssertionError: "
    str_1 = '~'
    var_1 = ansible_native_concat(str_1)
    assert var_1 == '~', "AssertionError: "


# Generated at 2022-06-25 12:27:27.060047
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('~') == '~'

# Generated at 2022-06-25 12:27:29.174361
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '~'
    var_0 = ansible_native_concat(str_0)
    #assert var_0 == 'bar'

    #assert True

# Generated at 2022-06-25 12:27:30.745488
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # The following exceptions were generated during the unit test:
    # Exception Message:
    # SyntaxError: unexpected EOF while parsing
    pass

# Generated at 2022-06-25 12:27:31.755039
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == '~', 'should be "~"'



# Generated at 2022-06-25 12:27:36.881734
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_a = '~'
    str_b = '~'
    str_c = '~'
    str_list = list()
    str_list.append(str_a)
    str_list.append(str_b)
    str_list.append(str_c)
    var_0 = ansible_native_concat(str_list)


# Generated at 2022-06-25 12:27:39.520457
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '~'
    var_0 = ansible_native_concat(str_0)
    assert var_0 is None

# Generated at 2022-06-25 12:27:57.767661
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Concatenate three string variables
    var_0 = u'foo'
    var_1 = u'bar'
    var_2 = u'baz'
    assert u''.join([var_0, var_1, var_2]) == ansible_native_concat([var_0, var_1, var_2])
    # Concatenate three integer variables
    var_3 = 1
    var_4 = 2
    var_5 = 3
    assert u''.join([str(var_3), str(var_4), str(var_5)]) == ansible_native_concat([var_3, var_4, var_5])
    # Concatenate three boolean variables
    var_6 = True
    var_7 = False
    var_8 = False

# Generated at 2022-06-25 12:27:59.428538
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_1 = '~'
    var_1 = ansible_native_concat(str_1)
    assert var_1 == '~'



# Generated at 2022-06-25 12:28:05.624405
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """
    Test for ansible_native_concat

    ansible_native_concat(nodes)

    Returns a native Python type from the list of compiled nodes. If the
    result is a single node, its value is returned. Otherwise, the nodes are
    concatenated as strings. If the result can be parsed with
    :func:`ast.literal_eval`, the parsed value is returned. Otherwise, the
    string is returned.
    """
    assert ansible_native_concat(u'~') == None


# Generated at 2022-06-25 12:28:13.277863
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('~') == '~'
    assert ansible_native_concat('~', '~') == '~~'
    assert ansible_native_concat(1, '~') == '1~'
    assert ansible_native_concat(['~']) == '~'
    assert ansible_native_concat(['~', '~']) == '~~'
    assert ansible_native_concat([1, '~']) == '1~'
    assert ansible_native_concat(['~'], ['~']) == '~~'
    assert ansible_native_concat(['~'], [1, '~']) == '~1~'
    assert ansible_native_concat({'a': '~'}) == '~'
    assert ansible_

# Generated at 2022-06-25 12:28:22.269601
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '~'
    str_1 = '~'
    var_0 = ansible_native_concat(str_0)
    var_1 = ansible_native_concat(str_1)
    str_2 = '~'
    str_3 = '~'
    var_2 = ansible_native_concat(str_2)
    var_3 = ansible_native_concat(str_3)
    str_4 = '~'
    str_5 = '~'
    var_4 = ansible_native_concat(str_4)
    var_5 = ansible_native_concat(str_5)
    str_6 = '~'
    var_6 = ansible_native_concat(str_6)
    str_7 = '~'
   

# Generated at 2022-06-25 12:28:27.543637
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(u'foo') == u'foo'
    assert ansible_native_concat(u'foo', u'bar') == u'foobar'
    assert ansible_native_concat(u'foo', u'', u'bar') == u'foobar'
    assert ansible_native_concat(u'', u'foo', u'', u'bar') == u'foobar'
    assert ansible_native_concat(u'', u'foo', u'', u'bar', u'', u'') == u'foobar'
    assert ansible_native_concat(u'', u'foo', u' ', u'bar', u'', u'') == u'foo bar'

# Generated at 2022-06-25 12:28:28.729105
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == '~'

# Generated at 2022-06-25 12:28:37.787878
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # AnsibleVaultEncryptedUnicode
    str_0 = '~'
    var_0 = ansible_native_concat(str_0)
    assert to_text(var_0) == '~', "Variable value is not '~' as expected"

    # not string
    str_0 = '~'
    var_0 = ansible_native_concat(str_0)
    assert to_text(var_0) == '~', "Variable value is not '~' as expected"

    # complex string
    str_0 = '~'
    var_0 = ansible_native_concat(str_0)
    assert to_text(var_0) == '~', "Variable value is not '~' as expected"

    # not really a string
    str_0 = '~'
    var

# Generated at 2022-06-25 12:28:44.051560
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = ast.literal_eval("'~'")
    var_0 = ansible_native_concat(str_0)
    assert var_0 == ast.literal_eval("'~'")
    str_0 = [ast.literal_eval("'~'"), ast.literal_eval("'~'")]
    var_0 = ansible_native_concat(str_0)
    assert var_0 == ast.literal_eval("'~~'")
    str_0 = [ast.literal_eval("'~'"), ast.literal_eval("'~'"), ast.literal_eval("'~'")]
    var_0 = ansible_native_concat(str_0)
    assert var_0 == ast.literal_eval("'~~~'")
    str

# Generated at 2022-06-25 12:28:54.382034
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert callable(ansible_native_concat)
    assert isinstance(test_case_0(), text_type)
    assert ansible_native_concat(1.0) == 1.0
    assert ansible_native_concat(1.0, 1.0) == 2.0
    assert ansible_native_concat([1, 2], [3]) == [1, 2, 3]
    assert ansible_native_concat([1, 2], 3) == [1, 2, 3]
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat('a', 'b', 'c') == 'abc'
    assert ansible_native_concat(1.0, 1.0) == 2.0


# Generated at 2022-06-25 12:29:07.096005
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # TODO: Implement test_ansible_native_concat() function.
    assert True



# Generated at 2022-06-25 12:29:08.795534
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var = ansible_native_concat(['a', 'b'])
    assert var == 'ab'



# Generated at 2022-06-25 12:29:09.750379
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    for v in range(2):
        yield test_case_0


# Generated at 2022-06-25 12:29:12.689360
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '~'
    var_0 = ansible_native_concat(str_0)
    assert isinstance(str_0, AnsibleVaultEncryptedUnicode)
