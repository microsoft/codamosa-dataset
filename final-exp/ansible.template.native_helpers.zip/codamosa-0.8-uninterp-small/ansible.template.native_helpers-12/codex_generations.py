

# Generated at 2022-06-25 12:19:14.821894
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'xzcjepbcpn^5lW8n&w'
    str_1 = 'mho97_zX!S21M[U'
    var_0 = ansible_native_concat(str_0)
    var_1 = ansible_native_concat(str_1)

    assert var_0 == 'xzcjepbcpn^5lW8n&w'
    assert var_1 == 'mho97_zX!S21M[U'

# Generated at 2022-06-25 12:19:16.682847
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(' +O(z3`Of<1)W\r6eYv~') == ' +O(z3`Of<1)W\r6eYv~'


# Generated at 2022-06-25 12:19:27.443529
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert to_text(ansible_native_concat('foo')) == u'foo'
    assert to_text(ansible_native_concat('foo\x00bar')) == u'foobar'
    assert to_text(ansible_native_concat([u'f', u'o', u'o'])) == u'foo'
    assert to_text(ansible_native_concat([u'f', u'o', u'o', u'\u263a'])) == u'foo\u263a'
    assert to_text(ansible_native_concat([u'f', u'o\x00', u'o', u'\u263a'])) == u'foo\u263a'

# Generated at 2022-06-25 12:19:29.631449
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = ' +O(z3`Of<1)W\r6eYv~'
    var_0 = ansible_native_concat(str_0)




# Generated at 2022-06-25 12:19:33.778490
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'A\x16\x0fm\x05\x1f\x16'
    str_1 = '+\x1c\r\x1c\x1e+'
    str_2 = '\x04$\x11\x1cR'
    str_3 = '\x1f^\x19)X\x1e\x0f\x04'
    str_4 = '\x1c@N\x15\x01'
    str_5 = '\x1fy\x1c\x12\x1bI\x06\x03\x04\x1d'
    str_6 = '\x08\x0e\x04\x1c\x1fR\x1d\x1f\x0f'
    str_10

# Generated at 2022-06-25 12:19:36.760387
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'd'
    var_0 = ansible_native_concat([str_0, ''])
    assert var_0 == 'd'



# Generated at 2022-06-25 12:19:46.471038
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = 'U'
    var_1 = 'P'
    var_2 = 'a'
    var_3 = 'W'
    var_4 = 'u'
    var_5 = 'h'
    var_6 = 'w'
    var_7 = '`'
    var_8 = '\x1d'
    var_9 = '0'
    var_10 = 'E'
    var_11 = 'X'
    var_12 = 'f'
    var_13 = 'B'
    var_14 = 'g'
    var_15 = 'E'
    var_16 = 'G'
    var_17 = '8'
    var_18 = 'n'
    var_19 = 'J'
    var_20 = 'n'

# Generated at 2022-06-25 12:19:49.038689
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert isinstance(test_ansible_native_concat(), (types.FunctionType, types.LambdaType))

# Generated at 2022-06-25 12:19:54.626349
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Unit tests for function 'ansible_native_concat'
    # Example
    try:
        str_0 = ' +O(z3`Of<1)W\r6eYv~'
        var_0 = ansible_native_concat(str_0)
    except NameError:
        var_0 = "Error"
    assert var_0 == ' +O(z3`Of<1)W\r6eYv~'

# Generated at 2022-06-25 12:19:59.240158
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'm7'
    str_1 = "Vx['(F"
    dict_2 = dict(t=str_0, U=str_1)
    var_0 = ansible_native_concat(dict_2)
    str_3 = 'f'
    str_4 = "O.\x1c"
    dict_5 = dict(A=str_3, N=str_4)
    var_1 = ansible_native_concat(dict_5)
    str_6 = 'P'
    str_7 = 'a'
    dict_8 = dict(a=str_6, U=str_7)
    var_2 = ansible_native_concat(dict_8)
    str_10 = 'd'
    str_9 = str_10
    var_

# Generated at 2022-06-25 12:20:06.439704
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = ' +O(z3`Of<1)W\r6eYv~'
    var_0 = ansible_native_concat(str_0)
    str_1 = " {'z.S' '+nNy:f0pc|k9' 'P[)Y*?-,0w'}'\r5gDl3y!*'"
    var_1 = ansible_native_concat(str_1)
    str_2 = '1.0661736890737843'
    var_2 = ansible_native_concat(str_2)
    str_3 = 'Qyh.Nn;fQ\r5*G'
    var_3 = ansible_native_concat(str_3)

# Generated at 2022-06-25 12:20:11.675248
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    inp_var = ' +O(z3`Of<1)W\r6eYv~'
    out_var = ' +O(z3`Of<1)W\r6eYv~'
    assert ansible_native_concat(inp_var) == out_var


# Generated at 2022-06-25 12:20:12.931119
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert True == True



# Generated at 2022-06-25 12:20:21.501756
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = ''.join([chr(x) for x in range(128, 256)]) + '\r\r\r\r'
    assert isinstance(ansible_native_concat(str_0), str)

    str_1 = ''.join([chr(x) for x in range(256, 512)]) + '\r\r\r\r'
    assert isinstance(ansible_native_concat(str_1), str)

    str_2 = ''.join([chr(x) for x in range(512, 768)]) + '\r\r\r\r'
    assert isinstance(ansible_native_concat(str_2), str)


# Generated at 2022-06-25 12:20:29.389553
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert isinstance(ansible_native_concat(container_to_text(u'abc')), text_type) is True
    assert isinstance(ansible_native_concat(container_to_text(u'abc')), int) is False
    assert isinstance(ansible_native_concat(container_to_text(u'3')), int) is True
    assert isinstance(ansible_native_concat(container_to_text(u'3')), text_type) is False
    assert ansible_native_concat(container_to_text(u'3.1415926535')) == 3.1415926535
    assert ansible_native_concat(container_to_text(u'3')) == 3

# Generated at 2022-06-25 12:20:33.358439
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test case 0"""
    test_case_0()


###############################################################################
# Check that function can raise a SyntaxError exception
###############################################################################



# Generated at 2022-06-25 12:20:34.459317
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
  assert callable(ansible_native_concat)

# Generated at 2022-06-25 12:20:37.893677
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(('a', 1, u'c')) == 'a1c'
    assert ansible_native_concat(iter(('a', 1, u'c'))) == 'a1c'

# Generated at 2022-06-25 12:20:40.946986
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    try:
        assert test_case_0() == ' +O(z3`Of<1)W\r6eYv~'
    except AssertionError:
        print(to_text(test_case_0()))
        ansible_native_concat(str_0)


# Generated at 2022-06-25 12:20:47.267543
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert isinstance(ansible_native_concat('foo'), str)
    assert ansible_native_concat('foo') == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert isinstance(ansible_native_concat(['foo', 'bar']), str)
    assert ansible_native_concat('foo', 'bar') == 'foobar'
    assert isinstance(ansible_native_concat('foo', 'bar'), str)

# Generated at 2022-06-25 12:20:56.168405
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import json
    import sys

    from ansible.module_utils.common.text.converters import to_text

    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    ##############
    # Replace this call by something more appropriate
    #
    # display.display(ansible_native_concat(sys.argv[1]))
    #
    ##############

    ret_val = None


# Generated at 2022-06-25 12:21:06.668637
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    str_0 = 'foo'
    str_1 = 'bar'
    str_2 = ''
    int_0 = 123
    int_1 = 456
    float_0 = 0.0
    float_1 = 1.23
    float_2 = 4.567
    float_3 = -7.89
    float_4 = 8.901e2
    dict_0 = dict()
    dict_1 = dict()
    dict_0['key'] = 'value'
    dict_1['key'] = 'value'
    dict_0['key'] = dict_1
    dict_2 = dict()
    dict_2['key'] = 'value'
    dict_2['key'] = dict_0
    list_0 = list()
    list_1 = list()
    list_0.append('value')


# Generated at 2022-06-25 12:21:11.464983
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = ' +O(z3`Of<1)W\r6eYv~'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == ' +O(z3`Of<1)W\r6eYv~'



# Generated at 2022-06-25 12:21:16.347042
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var = ansible_native_concat(nodes)


# Generated at 2022-06-25 12:21:22.474647
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = ' +O(z3`Of<1)W\r6eYv~'
    var_0 = ansible_native_concat(var_0)
    if var_0 is None:
        print(var_0)
    else:
        print(container_to_text(var_0))
    var_1 = '*7$uJk-m+7VuTn.8'
    var_2 = 'w3q1^<Dk{#4h4~B'
    var_3 = '*7$uJk-m+7VuTn.8'
    var_4 = 'w3q1^<Dk{#4h4~B'
    var_0 = ansible_native_concat([var_1, var_2])

# Generated at 2022-06-25 12:21:25.813775
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = ' +O(z3`Of<1)W\r6eYv~'
    var_0 = ansible_native_concat(str_0)


# Generated at 2022-06-25 12:21:35.255731
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = """az59m<<-B9t'<#PDOWUN]D
WG;f0xPa`EzYI\rVpNl}
     XP|O/~`#SJ*"""
    var_0 = ansible_native_concat(str_0)
    assert var_0 == """az59m<<-B9t'<#PDOWUN]D
WG;f0xPa`EzYI\rVpNl}
     XP|O/~`#SJ*"""
    str_1 = """JN<c`6N`Z+B?@b)e;x*
(d\n=Sn_CKj.!X*q3:RW:m"""

# Generated at 2022-06-25 12:21:43.000627
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['hello']) == 'hello'
    assert ansible_native_concat(['hello', 'world']) == 'hello world'
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_

# Generated at 2022-06-25 12:21:46.863953
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_1 = ansible_native_concat(['+O(z3`Of<1)W\r6eYv~'])
    assert var_1 == '+O(z3`Of<1)W\r6eYv~'


# Generated at 2022-06-25 12:21:47.736372
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert str == type(test_case_0())

# Generated at 2022-06-25 12:21:56.003147
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(" +O(z3`Of<1)W\r6eYv~") == " +O(z3`Of<1)W\r6eYv~"
    assert ansible_native_concat(" +O(z3`Of<1)W\r6eYv~") == " +O(z3`Of<1)W\r6eYv~"



# Generated at 2022-06-25 12:22:01.415441
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_test = ' +O(z3`Of<1)W\r6eYv~'
    var_test = ansible_native_concat(str_test)
    # And the result is...
    assert var_test == ' +O(z3`Of<1)W\r6eYv~'
    # Now functions that use ansible_native_concat can be tested.


# Generated at 2022-06-25 12:22:04.736079
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = ' +O(z3`Of<1)W\r6eYv~'
    var_0 = ansible_native_concat(str_0)



# Generated at 2022-06-25 12:22:05.326544
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert True

# Generated at 2022-06-25 12:22:14.022563
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'T8.'
    str_1 = '@6F+I%'
    str_2 = 'p.ku'
    str_3 = 'C9c!+'
    str_4 = 'OM_'
    str_5 = '~Cf'
    str_6 = 'f_'
    str_7 = '>@'
    str_8 = '0}'
    str_9 = '4/n'
    str_10 = 'G)'
    str_11 = 'n'
    str_12 = 'z'
    str_13 = 'p'
    str_14 = 'w['
    str_15 = 'y^'
    str_16 = 'Gv'
    str_17 = 'P'
    str_18 = 'Pg'

# Generated at 2022-06-25 12:22:16.385226
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = ast.literal_eval('())#Dw5lJb<"lL9&')
    assert not var_0
    var_1 = ast.literal_eval('\)WgN~Fv"`_I"H"')
    assert not var_1

# Generated at 2022-06-25 12:22:18.398397
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert type(ansible_native_concat(' ')) == text_type


# Generated at 2022-06-25 12:22:23.455361
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'foo'
    str_1 = 'bar'
    str_2 = 'baz'
    list_0 = [str_0, str_1, str_2]

    assert ansible_native_concat(str_0) == str_0
    assert ansible_native_concat(list_0) == 'foobarbaz'

# Generated at 2022-06-25 12:22:31.760951
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    arg_0 = ' +O(z3`Of<1)W\r6eYv~'
    arg_1 = 'O3q;6Y'
    arg_2 = 'O3q;6Y'
    arg_3 = 'O3q;6Y'
    arg_4 = 'O3q;6Y'
    arg_5 = 'O3q;6Y'
    arg_6 = 'O3q;6Y'
    arg_7 = 'O3q;6Y'
    arg_8 = 'O3q;6Y'
    arg_9 = 'O3q;6Y'
    arg_10 = 'O3q;6Y'
    arg_11 = 'O3q;6Y'
    arg_12 = 'O3q;6Y'

# Generated at 2022-06-25 12:22:34.742226
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = ' +O(z3`Of<1)W\r6eYv~'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == ' +O(z3`Of<1)W\r6eYv~', 'ansible_native_concat returned a wrong value'

# Generated at 2022-06-25 12:22:45.954159
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """
      This test will check the ansible_native_concat function
      in module_utils.common.collections
    """

# Generated at 2022-06-25 12:22:55.322777
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # py27-py36
    str_1 = '3/r]}Y`c%T'
    var_1 = ansible_native_concat(str_1)

    str_2 = 'f\n\t'
    var_2 = ansible_native_concat(str_2)

    str_3 = 'y\n\t '
    var_3 = ansible_native_concat(str_3)

    str_4 = 'Bt\r'
    var_4 = ansible_native_concat(str_4)

    str_5 = 'b\n'
    var_5 = ansible_native_concat(str_5)

    str_6 = ' l\t\n'
    var_6 = ansible_native_concat(str_6)

    str_7

# Generated at 2022-06-25 12:22:58.841303
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = ' +O(z3`Of<1)W\r6eYv~'
    var_0 = ansible_native_concat(str_0)
    var_1 = container_to_text(var_0)
    assert var_1 == ' +O(z3`Of<1)W\r6eYv~'

# Generated at 2022-06-25 12:23:09.608272
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = 'VuRuKj?/`d'
    var_0 = ansible_native_concat(var_0)

    var_1 = 'H|P5oDg5Q5z49j'
    var_1 = ansible_native_concat(var_1)

    var_2 = 'L5Q`?Jz'
    var_2 = ansible_native_concat(var_2)

    var_3 = '{Fn\r'
    var_3 = ansible_native_concat(var_3)

    var_4 = 's'
    var_4 = ansible_native_concat(var_4)

    var_5 = 'W)X8\'v'
    var_5 = ansible_native_concat(var_5)

    var

# Generated at 2022-06-25 12:23:10.619839
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    pass


# Generated at 2022-06-25 12:23:17.721365
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Tests for string
    str_0 = 'abc'
    ansible_native_concat(str_0)
    str_1 = 'def'
    ansible_native_concat(str_1)
    str_2 = 'ghi'
    ansible_native_concat(str_2)
    str_3 = 'ghi'
    ansible_native_concat(str_3)

    # Tests for bool
    bool_0 = True
    ansible_native_concat(bool_0)
    bool_1 = False
    ansible_native_concat(bool_1)
    bool_2 = True
    ansible_native_concat(bool_2)

    # Tests for int
    int_0 = -865
    ansible_native_concat(int_0)
   

# Generated at 2022-06-25 12:23:19.153299
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert isinstance(test_case_0(), text_type)

# Generated at 2022-06-25 12:23:19.693554
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert True


# Generated at 2022-06-25 12:23:22.345006
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Create the sequence
    seq = [x for x in range(10)]
    # Verify the output
    assert ansible_native_concat(seq) == '0123456789'



# Generated at 2022-06-25 12:23:23.616732
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert callable(ansible_native_concat)


# Generated at 2022-06-25 12:23:32.514510
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'Iq+3q[|tY'
    str_1 = '|T+Tv'
    str_2 = 'y@'
    str_3 = 't'
    str_4 = 'I,T+Tv'
    str_5 = 'C_'
    str_6 = '=0}/'
    str_7 = '5)'
    str_8 = 'j'
    list_0 = [str_0, str_1, str_2, str_3, str_4, str_5, str_6, str_7, str_8]
    var_0 = ansible_native_concat(list_0)
    assert var_0 is not None


# Generated at 2022-06-25 12:23:35.237484
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    exp_0 = ' +O(z3`Of<1)W\r6eYv~'
    assert ansible_native_concat(exp_0) == exp_0

# Generated at 2022-06-25 12:23:44.599494
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'dQ(M)m_]h&'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'dQ(M)m_]h&'
    str_0 = '+O`crw1F\rVK'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == '+O`crw1F\rVK'
    str_0 = '+O`crw1F'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == '+O`crw1F'
    str_0 = 'q"%z\x0ey&J'
    var_0 = ansible_native_concat(str_0)
    assert var_

# Generated at 2022-06-25 12:23:49.209252
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    print("Testing ansible_native_concat...")
    test0 = test_case_0()
    print("Success: {0}".format(test0["result"]))

# Execute function
test_ansible_native_concat()

# Generated at 2022-06-25 12:23:52.766015
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = ' +O(z3`Of<1)W\r6eYv~'
    var_0 = ansible_native_concat(str_0)
    assert isinstance(var_0, basestring)



# Generated at 2022-06-25 12:23:54.614072
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == ' +O(z3`Of<1)W\r6eYv~'


# Generated at 2022-06-25 12:24:00.692179
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # pylint: disable=line-too-long
    assert ansible_native_concat('this is a') == 'this is a'
    assert ansible_native_concat(1) == 1
    assert ansible_native_concat([1]) == [1]
    assert ansible_native_concat({'a': 1}) == {'a': 1}
    assert ansible_native_concat([1, 2]) == [1, 2]
    assert ansible_native_concat({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert ansible_native_concat((1, 2)) == (1, 2)
    assert ansible_native_concat(set([1, 2])) == set([1, 2])
    assert ansible_native_concat

# Generated at 2022-06-25 12:24:04.110700
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = ' +O(z3`Of<1)W\r6eYv~'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == ' +O(z3`Of<1)W\r6eYv~'



# Generated at 2022-06-25 12:24:12.797295
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'XmJ_^Z'
    var_0 = ansible_native_concat(str_0)
    str_1 = '#]\x1c'
    var_1 = ansible_native_concat(str_1)
    str_2 = 'm8\t51'
    var_2 = ansible_native_concat(str_2)
    str_3 = 'J}C&'
    var_3 = ansible_native_concat(str_3)
    str_4 = '}i,~'
    var_4 = ansible_native_concat(str_4)
    str_5 = '3rI,i'
    var_5 = ansible_native_concat(str_5)

# Generated at 2022-06-25 12:24:21.209471
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    b = 'abc'
    var_0 = ansible_native_concat(b)
    assert var_0 == b
    str_0 = ' +O(z3`Of<1)W\r6eYv~'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == str_0

    a = 'test'
    d = 'sdfsdf'
    c = '{0} {1}'.format(a, d)
    var_1 = ansible_native_concat(a, d)
    assert var_1 == c
    assert var_1 != a

# Generated at 2022-06-25 12:24:30.288162
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Test with string argument
    result = ansible_native_concat('some string')
    assert type(result) == text_type
    assert result == 'some string'

    # Test with dict argument
    result = ansible_native_concat({'key': 'value'})
    assert type(result) == dict
    assert result == {'key': 'value'}

    # Test with list argument
    result = ansible_native_concat(['ansible', 'is', 'awesome'])
    assert type(result) == text_type
    assert result == 'ansible,is,awesome'

    # Test with non-evaluable string argument
    result = ansible_native_concat('some string')
    assert type(result) == text_type
    assert result == 'some string'

    # Test with set argument


# Generated at 2022-06-25 12:24:39.242193
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = ' +O(z3`Of<1)W\r6eYv~'
    var_0 = ansible_native_concat(str_0)

    str_1 = '\tX(E\x0b;D\t'
    str_2 = '\\\x1c'
    str_3 = '\x09z(i\\`M\t'
    var_1 = ansible_native_concat(str_1)
    var_2 = ansible_native_concat(str_2)
    var_3 = ansible_native_concat(str_3)
    var_4 = ansible_native_concat(str_3)
    var_5 = ansible_native_concat(str_3)
    var_6 = ansible_native_concat

# Generated at 2022-06-25 12:24:39.981535
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0()



# Generated at 2022-06-25 12:24:40.627279
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert True

# Generated at 2022-06-25 12:24:41.640567
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat is not None


# Generated at 2022-06-25 12:24:43.245391
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    try:
        test_case_0()
    except Exception as e:
       assert True, e
    else:
       assert False

# Generated at 2022-06-25 12:24:48.979954
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    out = ansible_native_concat(' +O(z3`Of<1)W\r6eYv~')
    assert isinstance(out, string_types)
    assert out == ' +O(z3`Of<1)W\r6eYv~'

    out = ansible_native_concat([' +O(z3`Of<1)W\r6eYv~', 'p7jcU\\<c:C7y'])
    assert isinstance(out, string_types)
    assert out == ' +O(z3`Of<1)W\r6eYv~p7jcU\\<c:C7y'

    out = ansible_native_concat([' +O(z3`Of<1)W\r6eYv~', 5])

# Generated at 2022-06-25 12:24:55.094022
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'var_0'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'var_0'

    str_0 = ' +O(z3`Of<1)W\r6eYv~'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == ' +O(z3`Of<1)W\r6eYv~'
   	

# Generated at 2022-06-25 12:25:04.546334
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = ' +O(z3`Of<1)W\r6eYv~'
    var_0 = ansible_native_concat(str_0)
    str_1 = '\r'
    var_1 = ansible_native_concat(str_1)
    str_2 = 'qqy|\n'
    var_2 = ansible_native_concat(str_2)
    str_3 = '| B\\+\x0b9qV`'
    var_3 = ansible_native_concat(str_3)
    str_4 = 'O9\x0b'
    var_4 = ansible_native_concat(str_4)
    str_5 = '+9\r'

# Generated at 2022-06-25 12:25:12.181668
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_1 = ansible_native_concat('mV\x0c\x0b5U')
    var_2 = ansible_native_concat('mV\x0c\x0b5U')
    var_3 = ansible_native_concat('mV\x0c\x0b5U')
    var_4 = ansible_native_concat('mV\x0c\x0b5U')
    assert var_1 == var_2 == var_3 == var_4

    var_5 = ansible_native_concat('mV\x0c\x0b5U')
    var_6 = ansible_native_concat('mV\x0c\x0b5U')

# Generated at 2022-06-25 12:25:22.825033
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = ' +O(z3`Of<1)W\r6eYv~'
    var_0 = ansible_native_concat(str_0)
    if var_0 != ' +O(z3`Of<1)W\r6eYv~':
        raise AssertionError('var_0 should equal to " +O(z3`Of<1)W\r6eYv~", but now equal to: ' + container_to_text(var_0))

    str_0 = ' +O(z3`Of<1)W\r6eYv~'
    tuple_0 = (str_0, ' +O(z3`Of<1)W\r6eYv~')
    var_0 = ansible_native_concat(tuple_0)
   

# Generated at 2022-06-25 12:25:25.353567
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = ' +O(z3`Of<1)W\r6eYv~'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == str_0

# Generated at 2022-06-25 12:25:29.912057
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert True


# Generated at 2022-06-25 12:25:35.179490
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test case 0
    str_0 = ' +O(z3`Of<1)W\r6eYv~'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == ' +O(z3`Of<1)W\r6eYv~'



# Generated at 2022-06-25 12:25:36.802464
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()

# Generated at 2022-06-25 12:25:44.089577
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = ' +O(z3`Of<1)W\r6eYv~'
    str_1 = {'v': str_0}
    str_2 = [str_0, str_1]
    var_0 = ansible_native_concat(str_0)
    var_1 = ansible_native_concat(str_1)
    var_2 = ansible_native_concat(str_2)
    print(var_0)
    print(var_1)
    print(var_2)
test_ansible_native_concat()

# Generated at 2022-06-25 12:25:46.163806
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    string_0 = 'xyz'
    result = ansible_native_concat(string_0)
    assert result == 'xyz'


# Generated at 2022-06-25 12:25:47.572337
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert str == type(ansible_native_concat(""))

# Simple test with a single string

# Generated at 2022-06-25 12:25:53.871503
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    data = {
        "test_0": {
            "str_0": ' +O(z3`Of<1)W\r6eYv~',
            "var_0": ansible_native_concat(' +O(z3`Of<1)W\r6eYv~'),
        }
    }
    for test_name, test_data in data.items():
        test_id = 'test_0'
        test_func = locals().get('test_case_' + test_id)
        for k, v in test_data.items():
            globals()[k] = v
        test_func()

# Generated at 2022-06-25 12:26:04.397184
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_cases = [
        # (expected, args),
        ('foo', 'foo'),
        ('foo{0}', ('foo',)),
        ('foo{0}', ['foo']),
        ('foo{0}', {'0': 'foo'}),
        ('1{0}2{1}3', '123'),
        ('1{0}2{1}3', ('123',)),
        ('1{0}2{1}3', ['123']),
        ('1{0}2{1}3', {'0': 1, '1': 2, '2': 3}),
    ]

    for test_case in test_cases:
        expected, args = test_case

        try:
            result = ansible_native_concat(args)
        except:
            pass

# Generated at 2022-06-25 12:26:09.268545
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Check type of variable
    assert isinstance(ansible_native_concat, types.FunctionType)

    # Test function ansible_native_concat
    test_case_0()

# Generated at 2022-06-25 12:26:15.514739
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = ' +O(z3`Of<1)W\r6eYv~'
    var_0 = ansible_native_concat(str_0)
    str_1 = '9vf<xgjzFUY-hWR:5H]\x0b@\x0e\x19\x0f\x18\x16'
    var_1 = ansible_native_concat(str_1)
    str_2 = '%cjA~\x1b\x1d-s\x03m}p\x0c'
    var_2 = ansible_native_concat(str_2)

# Generated at 2022-06-25 12:26:22.806331
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'f'
    var_0 = ansible_native_concat(str_0)
    print(var_0)

    list_0 = [1, 2, 3, 4]
    var_1 = ansible_native_concat(list_0)
    print(var_1)

    str_1 = ' [12, 23]'
    var_2 = ansible_native_concat(str_1)
    print(var_2)

    int_0 = 123
    var_3 = ansible_native_concat(int_0)
    print(var_3)


test_ansible_native_concat()

# Generated at 2022-06-25 12:26:23.904354
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert isinstance(test_case_0(), str)

# Generated at 2022-06-25 12:26:24.794973
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['1', '2']) == '12'

# Generated at 2022-06-25 12:26:25.780582
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert callable(ansible_native_concat), "Function ansible_native_concat does not exist."



# Generated at 2022-06-25 12:26:28.606300
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(' +O(z3`Of<1)W\r6eYv~') == " +O(z3`Of<1)W\r6eYv~"

# Generated at 2022-06-25 12:26:37.179656
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = ' +O(z3`Of<1)W\r6eYv~'
    assert str_0 == ansible_native_concat(str_0)
    assert ' +O(z3`Of<1)W\r6eYv~databadcred' == ansible_native_concat([' +O(z3`Of<1)W\r6eYv~', 'data', 'badcred'])
    assert '[ +O(z3`Of<1)W\r6eYv~data, \'bad\', "cred"]' == ansible_native_concat(['[ +O(z3`Of<1)W\r6eYv~data, \'bad\', "cred"]'])

# Generated at 2022-06-25 12:26:39.125443
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = ' +O(z3`Of<1)W\r6eYv~'
    var_0 = ansible_native_concat(str_0)

# Generated at 2022-06-25 12:26:40.362960
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert var_0 == ' +O(z3`Of<1)W\r6eYv~'


# Generated at 2022-06-25 12:26:52.022391
# Unit test for function ansible_native_concat

# Generated at 2022-06-25 12:26:56.206587
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = ' +O(z3`Of<1)W\r6eYv~'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == ' +O(z3`Of<1)W\r6eYv~'



# Generated at 2022-06-25 12:26:59.253870
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = ' +O(z3`Of<1)W\r6eYv~'
    var_0 = ansible_native_concat(str_0)



# Generated at 2022-06-25 12:27:02.528867
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    func_name = "ansible_native_concat"
    tests = [('str_0', " ' +O(z3`Of<1)W\\r6eYv~'", " +O(z3`Of<1)W\r6eYv~")]
    return test_native_types_fct(func_name, tests)



# Generated at 2022-06-25 12:27:10.790961
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = ''
    str_1 = 'p[%vk8\x0eQz'
    str_2 = 'Y8\x0bk%cR'
    str_3 = '6w[*><3>|y'
    str_4 = 'o?l7'
    str_5 = 'N/1N'
    str_6 = '0$Q/'
    str_7 = 'hM^'
    str_8 = '+pw'
    str_9 = 'nV'
    str_10 = 'x%'
    str_11 = '6'
    var_0 = ansible_native_concat(str_0)
    var_1 = ansible_native_concat(str_1)

# Generated at 2022-06-25 12:27:14.327628
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    ansible_native_concat(str_0)



if __name__ == "__main__":
    # Run the unit tests with:
    # python -m unittest test_ansible_native_concat
    import unittest
    unittest.main()

# Generated at 2022-06-25 12:27:23.869957
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    str_0 = ' +O(z3`Of<1)W\r6eYv~'

    assert_equal(ansible_native_concat(str_0), ' +O(z3`Of<1)W\r6eYv~')
    assert_equal(ansible_native_concat(str_0), ' +O(z3`Of<1)W\r6eYv~')
    assert_equal(ansible_native_concat(str_0), ' +O(z3`Of<1)W\r6eYv~')
    assert_equal(ansible_native_concat(str_0), ' +O(z3`Of<1)W\r6eYv~')

# Generated at 2022-06-25 12:27:31.986829
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '}'
    str_1 = '-@'
    str_2 = 'g'
    str_3 = '%c'
    str_4 = 'n'
    str_5 = 'Y'
    str_6 = '|\x17'
    str_7 = 'd'
    str_8 = '$'
    str_9 = '?_'
    str_10 = ','
    str_11 = 'f'
    str_12 = 'A'
    str_13 = 'R'
    str_14 = '\x11'
    str_15 = '\x0e'
    str_16 = "'"
    str_17 = '*'
    str_18 = 'T'
    str_19 = '\x03'
    str_20 = 'j'

# Generated at 2022-06-25 12:27:32.757518
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert var_0 is str_0


# Generated at 2022-06-25 12:27:43.355307
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_1 = ansible_native_concat([1, 2])
    assert var_1 == 3
    var_2 = ansible_native_concat(["1", "2"])
    assert var_2 == u'12'
    var_3 = ansible_native_concat([1, [2, 3]])
    assert var_3 == u'13'
    var_4 = ansible_native_concat([1, '2'])
    assert var_4 == u'12'
    var_5 = ansible_native_concat(['1', '2'])
    assert var_5 == u'12'
    var_6 = ansible_native_concat([[1, '2'], '3'])
    assert var_6 == u'13'


# Generated at 2022-06-25 12:27:54.763216
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = b' ,0pT;7rK?'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == ' ,0pT;7rK?'

    str_0 = ' ,0pT;7rK?'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == ' ,0pT;7rK?'

    str_0 = ' ,0pT;7rK?'
    str_1 = ' ,0pT;7rK?'
    str_2 = ' ,0pT;7rK?'
    var_0 = ansible_native_concat([str_0, str_1, str_2])

# Generated at 2022-06-25 12:27:56.622317
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = ' +O(z3`Of<1)W\r6eYv~'
    expected_0 = ' +O(z3`Of<1)W\r6eYv~'
    actual_0 = ansible_native_concat(str_0)
    assert actual_0 == expected_0


# Generated at 2022-06-25 12:28:02.061986
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert _fail_on_undefined(ansible_native_concat([1, 2, 3])) == 123
    assert _fail_on_undefined(ansible_native_concat(["1", "2", "3"])) == 123
    assert _fail_on_undefined(ansible_native_concat(["1", 2, "3"])) == '123'
    assert _fail_on_undefined(ansible_native_concat(["1", "2", 3])) == '123'
    assert _fail_on_undefined(ansible_native_concat(["1", 2, 3])) == '123'
    assert _fail_on_undefined(ansible_native_concat(["1 1", "2", 3])) == '1 123'

# Generated at 2022-06-25 12:28:10.930562
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert isinstance(ansible_native_concat(to_text(u'')), basestring)
    assert isinstance(ansible_native_concat(to_text(u'1')), int)
    assert isinstance(ansible_native_concat(to_text(u'-1')), int)
    assert isinstance(ansible_native_concat(to_text(u'1.1')), float)
    assert isinstance(ansible_native_concat(to_text(u'-1.1')), float)
    assert isinstance(ansible_native_concat(to_text(u'1e1')), float)
    assert isinstance(ansible_native_concat(to_text(u'-1e1')), float)

# Generated at 2022-06-25 12:28:16.185665
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test with 1 string argument as input
    res = ansible_native_concat("Hello")
    assert res == "Hello"

    # Test with 2 string arguments as input
    res = ansible_native_concat("Hello", "World")
    assert res == "HelloWorld"

    # Test with boundary string
    boundary_string = ":)"
    res = ansible_native_concat("Hello", boundary_string)
    assert res == "Hello:)"

    # Test with empty string as input
    res = ansible_native_concat("")
    assert res == ""

    # Test with string as input
    with pytest.raises(Exception):
        ansible_native_concat(123)

    # Test with unicode string as input

# Generated at 2022-06-25 12:28:24.740075
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = '-@U6<sU;lIp'
    var_1 = '\'8i,N$9Xj1'
    var_2 = var_1 + ' ' + var_0
    var_3 = var_2 + ' ' + var_1
    var_4 = var_2 + ' ' + var_0
    var_5 = var_3 + ' ' + var_2
    var_6 = var_3 + ' ' + var_3
    str_0 = var_0 + ' ' + var_3
    var_7 = var_0 + ' ' + var_2
    var_8 = var_4 + ' ' + var_5
    str_1 = var_4 + ' ' + var_4
    var_9 = var_0 + ' ' + var_3
    var

# Generated at 2022-06-25 12:28:27.242198
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = '~I'
    str_0 = ' ~I'
    var_1 = ansible_native_concat(str_0)

    assert var_0 == var_1


# Generated at 2022-06-25 12:28:31.354716
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = '$$Q+f%Cq@MhBzU#\rF_Xb'
    var_1 = ansible_native_concat(var_0)
    assert container_to_text(var_1) == '$$Q+f%Cq@MhBzU#\rF_Xb'


# Generated at 2022-06-25 12:28:39.650147
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = ' vh*\n8_|'
    assert ansible_native_concat(var_0) == ' vh*\n8_|'
    assert ansible_native_concat(var_0) == ' vh*\n8_|'
    assert ansible_native_concat(var_0) == ' vh*\n8_|'

    var_1 = 'N]bx<^kXC5~\r5i,6'
    assert ansible_native_concat(var_1) == 'N]bx<^kXC5~\r5i,6'
    assert ansible_native_concat(var_1) == 'N]bx<^kXC5~\r5i,6'

# Generated at 2022-06-25 12:28:40.360157
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    pass



# Generated at 2022-06-25 12:28:48.153608
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    try:
        ansible_native_concat(None)
        assert False, "ansible.module_utils.common.text.converters.ansible_native_concat(): Fail"
    except NotImplementedError:
        pass

# Generated at 2022-06-25 12:28:56.655008
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = ' +O(z3`Of<1)W\r6eYv~'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == ' +O(z3`Of<1)W\r6eYv~'

    str_0 = 'XCvQ^TF:W@lH;>'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'XCvQ^TF:W@lH;>'

    str_0 = 'lBm\tI'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'lBm\tI'

    str_0 = '-/H>x'
    var_0 = ansible

# Generated at 2022-06-25 12:28:57.166229
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert True



# Generated at 2022-06-25 12:29:04.804090
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert hasattr(ansible_native_concat, '__call__')
    assert isinstance(ansible_native_concat, types.FunctionType)

    assert test_ansible_native_concat.__doc__ == """Return a native Python type from the list of compiled nodes. If the
    result is a single node, its value is returned. Otherwise, the nodes are
    concatenated as strings. If the result can be parsed with
    :func:`ast.literal_eval`, the parsed value is returned. Otherwise, the
    string is returned.

    https://github.com/pallets/jinja/blob/master/src/jinja2/nativetypes.py"""



# Generated at 2022-06-25 12:29:06.277124
# Unit test for function ansible_native_concat

# Generated at 2022-06-25 12:29:08.004352
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # TODO: define test inputs
    # TODO: define test outputs
    # TODO: assert test outputs

    assert True  # TODO: update