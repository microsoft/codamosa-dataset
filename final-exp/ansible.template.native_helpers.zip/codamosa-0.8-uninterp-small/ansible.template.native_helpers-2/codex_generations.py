

# Generated at 2022-06-25 12:19:17.940560
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """
    ansible.module_utils.basic.basic.ansible_native_concat  test cases
    """
    test_cases = {
        # Test (1)
        "TestCase_0": test_case_0,
    }
    for key, val in test_cases.items():
        val()

# Test code for ansible_native_concat

# Generated at 2022-06-25 12:19:18.874131
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    ansible_native_concat(None)

# Generated at 2022-06-25 12:19:30.083200
# Unit test for function ansible_native_concat

# Generated at 2022-06-25 12:19:35.567217
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'
    var_0 = ansible_native_concat(b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5')
    assert not var_0

# Generated at 2022-06-25 12:19:36.397355
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert False  # please, implement your test

# Generated at 2022-06-25 12:19:44.893881
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(b"a") == "a"
    assert ansible_native_concat(b"", b"") == ""
    assert ansible_native_concat(b"abc") == "abc"
    assert ansible_native_concat(b"def") == "def"
    assert ansible_native_concat(b"def", b"") == "def"
    assert ansible_native_concat(b"", b"def") == "def"
    assert ansible_native_concat(b"abc", b"def") == "abcdef"
    # import pytest
    # pytest.skip()



# Generated at 2022-06-25 12:19:46.209772
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert False


# Generated at 2022-06-25 12:19:47.730946
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()

# Generated at 2022-06-25 12:19:51.510381
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Test cases for function ansible_native_concat
    for test_case in range(0, 0):
        test_case()


if __name__ == "__main__":
    test_ansible_native_concat()

# Generated at 2022-06-25 12:19:54.237652
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == '\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'


# Generated at 2022-06-25 12:20:03.634349
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert callable(ansible_native_concat)
    assert to_text(ansible_native_concat([b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'])) == to_text('â,œlTË\x7fúÞ­_¤0\x15Å')

# Generated at 2022-06-25 12:20:14.982114
# Unit test for function ansible_native_concat

# Generated at 2022-06-25 12:20:18.875861
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5') == b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'



# Generated at 2022-06-25 12:20:27.804542
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Concat byte arrays that have the same size and a leading byte value of 10
    bytes_0 = b'\n\x17\xc5\xf1\x16\n\x88\xd6\x10b\x00\xad\xbd\x04\xdd'
    bytes_1 = b'\n\x1b\xe0\x95\x12\x10\xb3\x90\xd3\x11\x9c\xde\xe8\xef'
    bytes_2 = b'\n\x01\x91]\xf4\x17\xab\x8e\x03\x13\x07\xdd\xaa\x80\xd5'

# Generated at 2022-06-25 12:20:28.630147
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0()

# Generated at 2022-06-25 12:20:40.342446
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Testing with a bytes string
    bytes_0 = b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'
    assert ansible_native_concat(bytes_0) == '\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'

    # Testing with a complex list
    list_0 = [[1], [2], [3], [4]]
    assert list_0 == ansible_native_concat(list_0)

    # Testing with a complex list
    list_0 = [[1], [2], [3], [4]]
    assert list_0 == ansible_native_concat(list_0)

    # Testing with

# Generated at 2022-06-25 12:20:46.830315
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert True


if __name__ == '__main__':
    # POC testing.
    bytes_0 = b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'
    var_0 = ansible_native_concat(bytes_0)
    # Not much to test here since this is a wrapper around Python's ast module.
    # Just assert that the function doesn't raise an exception.
    assert True

# Generated at 2022-06-25 12:20:54.528858
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert container_to_text(ansible_native_concat([b'4'])) == "4"
    assert container_to_text(ansible_native_concat([b'foo', b'+', b'bar'])) == "foo+bar"
    assert container_to_text(ansible_native_concat([b'foo', b'+', b'bar'])) == "foo+bar"
    assert container_to_text(ansible_native_concat([b'foo', b'+', b'bar'])) == "foo+bar"
    assert container_to_text(ansible_native_concat([b'foo', b'+', b'bar'])) == "foo+bar"
    assert container_to_text(ansible_native_concat([b'foo', b'+', b'bar']))

# Generated at 2022-06-25 12:21:03.626642
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_cases = [
        {"nodes": b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5', "expected": '\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'}
    ]

    for test_case in test_cases:
        nodes = test_case["nodes"]
        expected = test_case["expected"]
        actual = ansible_native_concat(nodes)
        assert actual == expected

# Generated at 2022-06-25 12:21:05.355881
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Well-defined case where the input string is valid
    test_case_0()



# Generated at 2022-06-25 12:21:09.002923
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert True

# Generated at 2022-06-25 12:21:18.781880
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5' == ansible_native_concat(b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5')
    assert b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5' == ansible_native_concat(b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5')

# Generated at 2022-06-25 12:21:29.463514
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Assert that we are working with native types
    assert isinstance(ansible_native_concat, types.BuiltinFunctionType)

    # No type coercion
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([False]) is False
    assert ansible_native_concat([True]) is True

    # No type coercion
    assert ansible_native_concat(['False']) == 'False'
    assert ansible_native_concat(['True']) == 'True'

    # Even if literal_eval() can be used
    assert ansible_native_concat(['None']) == 'None'
    assert ansible_native_concat(['[]']) == '[]'
    assert ansible_native_concat(['True']) == 'True'
    assert ans

# Generated at 2022-06-25 12:21:33.246567
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    bytes_0 = b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'

    # Call function ansible_native_concat
    local_result = ansible_native_concat(bytes_0)
    assert type(local_result) == bytes

# Generated at 2022-06-25 12:21:41.352594
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # The following string is base64-encoded bytes.
    # It is used to demonstrate that the behavior of the native
    # concat function is the same across Python versions.
    test_data = '\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'
    expected_return = u"\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5"

    # b64decode returns bytes in Python 3 which has to be converted to text for comparison
    if isinstance(expected_return, bytes):
        expected_return = expected_return.decode('utf-8')

    assert ansible_native_concat(test_data) == expected_return

# Generated at 2022-06-25 12:21:51.411683
# Unit test for function ansible_native_concat

# Generated at 2022-06-25 12:22:01.592680
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = ansible_native_concat([])
    assert container_to_text(var_0) == "None"

    var_1 = ansible_native_concat([35])
    assert container_to_text(var_1) == "35"

    var_2 = ansible_native_concat([35, 71])
    assert container_to_text(var_2) == "3571"

    var_3 = ansible_native_concat(["test", "case"])
    assert container_to_text(var_3) == "testcase"

    bytes_0 = b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'

# Generated at 2022-06-25 12:22:05.277921
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_1 = to_text(u'\xe4,\u009clT\u0007\xfa\xde\xad_\xa20\x15\xc5')
    assert var_1 == test_case_0()

# Generated at 2022-06-25 12:22:07.690654
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == '\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'

# Generated at 2022-06-25 12:22:15.690958
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5') == b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'
    assert ansible_native_concat(b'\xc3\xbcber') == b'\xc3\xbcber'
    assert ansible_native_concat(b'\x00\x01\x02\x03\x04\x05\x06\x07') == b'\x00\x01\x02\x03\x04\x05\x06\x07'

# Generated at 2022-06-25 12:22:26.792405
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # These vars are already defined in the caller's scope.
    # Do not edit. Want to preserve this auto-generated block for posterity.
    bytes_0 = b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'
    var_0 = ansible_native_concat(bytes_0)

    assert var_0 == 'ä,ülTË\x7fúÞ­_¦0\x15Å'
    assert container_to_text(var_0) == 'ä,ülTË\x7fúÞ­_¦0\x15Å'


# Generated at 2022-06-25 12:22:30.061056
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'
    var_1 = ansible_native_concat(var_0)
    test_case_0()

# Generated at 2022-06-25 12:22:40.011862
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert var_0 == "ä,ülTË\u007ffáÞ\u007fad_ª20\u0015Å"
    bytes_0 = b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'
    var_0 = ansible_native_concat(bytes_0)
    assert var_0 == "ä,ülTË\u007ffáÞ\u007fad_ª20\u0015Å"

# Generated at 2022-06-25 12:22:46.075587
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    result = ansible_native_concat(b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5')
    assert result is not None
    assert isinstance(result, bytes)
    assert result == b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'


# Generated at 2022-06-25 12:22:51.433014
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    arg1 = ansible_native_concat(ast.literal_eval(container_to_text(b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5')))
    
    # Call the real function
    check_ansible_native_concat(arg1)


# Generated at 2022-06-25 12:22:52.617428
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    result = ansible_native_concat(None)
    
    assert result is None

# Generated at 2022-06-25 12:22:56.522828
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5' == bytes_0
    assert var_0 == b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'


# Generated at 2022-06-25 12:22:58.968274
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """
    Unit test for function: ansible_native_concat
    """
    print(">>> testing function: ansible_native_concat")
    test_case_0()
    print("--- function: ansible_native_concat ran successfully")

# Generated at 2022-06-25 12:23:02.719194
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test function ansible_native_concat
    # TODO: Implement testcases
    """
    failure_exception = AssertionError()
    # TODO: Implement testcase
    raise failure_exception

# Generated at 2022-06-25 12:23:03.286460
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    pass

# Generated at 2022-06-25 12:23:13.837083
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'
    assert var_0 == ansible_native_concat(var_0)
    var_1 = 127
    assert var_1 == ansible_native_concat(var_1)
    var_2 = 13
    assert var_2 == ansible_native_concat(var_2)

# Generated at 2022-06-25 12:23:16.610484
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()

# /home/vagrant/.ansible/tmp/ansible-local-160740xgLfJfi/ansible-tmp-1607409E0f9r9r/source (deleted)


# Generated at 2022-06-25 12:23:25.322134
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert(ansible_native_concat([b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5']) == b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5')


# Test function "ansible_native_concat" with the following data:
ansible_native_concat_data_0 = (
    [
        [
            'key_0',
            'value_0'
        ]
    ],
    {
        'key_0': [
            'value_0'
        ]
    }
)

# Test function "ansible_native_concat" with the following data:
ansible_native_

# Generated at 2022-06-25 12:23:27.920966
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == '\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'


# Generated at 2022-06-25 12:23:29.726010
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    for a in range(100):
        assert test_case_0()
# vim: set ft=python ts=4 sw=4 tw=79 et:

# Generated at 2022-06-25 12:23:30.631775
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() is not False

# Generated at 2022-06-25 12:23:33.995280
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'


# Generated at 2022-06-25 12:23:43.845499
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # fmt: off
    BYTES_0 = b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'
    # fmt: on
    TEXT_0 = to_text(BYTES_0)

    # fmt: off
    BYTES_1 = b'.g\x11(h2\xb2\x08\x15\xc5\x88\xa0\x1c\xde'
    # fmt: on
    TEXT_1 = to_text(BYTES_1)

    # fmt: off
    BYTES_2 = b'\x8a\xdc\xf2\x1e\x81\x9f9\x9f\xbc\x8a,\xce'


# Generated at 2022-06-25 12:23:44.624360
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert isinstance(test_case_0(), str)

# Generated at 2022-06-25 12:23:47.376943
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    out = ansible_native_concat([])
    assert(out is None)

    # TODO: add test cases here

# Generated at 2022-06-25 12:23:52.907063
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Assert that the result of the function is equal to the
    # stored result
    assert ansible_native_concat(var_0) == var_1
# Unit test end


# Generated at 2022-06-25 12:23:56.624604
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    bytes_0 = b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'
    var_0 = ansible_native_concat(bytes_0)
    assert var_0 == b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'

# Generated at 2022-06-25 12:23:58.130787
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() is not None


# ansible-base/ansible/parsing/yaml/loader.py

# Generated at 2022-06-25 12:23:58.924038
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert callable(ansible_native_concat)

# Generated at 2022-06-25 12:24:02.007940
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert True


# Generated at 2022-06-25 12:24:07.933582
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'
    var_1 = '\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'
    assert var_1 == ansible_native_concat(var_0), 'Expected and actual values do not match'


# Generated at 2022-06-25 12:24:08.482840
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert False

# Generated at 2022-06-25 12:24:16.790036
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_1 = 'abc'
    var_2 = 'def'
    var_3 = ansible_native_concat(var_1, var_2)
    assert var_3 == 'abcdef'
    var_4 = '0'
    var_3 = ansible_native_concat(var_3, var_4)
    assert var_3 == 'abcdef0'
    var_5 = '001'
    var_6 = '-07'
    var_7 = '18'
    var_8 = '5'
    var_9 = ansible_native_concat(var_5, var_6, var_7, var_8)
    assert var_9 == '00100-07185'


# Generated at 2022-06-25 12:24:18.577610
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    with pytest.raises(UnicodeDecodeError):
        test_case_0()

# Generated at 2022-06-25 12:24:27.454908
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    out = ansible_native_concat(["hello", " ", "world"])
    assert out == u'hello world'

    out = ansible_native_concat([1, 2, 3])
    assert out == u'123'

    out = ansible_native_concat([{'test': 'item'}])
    assert out == u"{'test': 'item'}"

    out = ansible_native_concat([[1], [2], 1])
    assert out == u'[1][2]1'

    out = ansible_native_concat([])
    assert out is None

    out = ansible_native_concat(['1', '2', '3'])
    assert out == 123

    out = ansible_native_concat([True, False])
    assert out is False

    out

# Generated at 2022-06-25 12:24:32.327558
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    bytes_0 = b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'
    var_0 = ansible_native_concat(bytes_0)


# Generated at 2022-06-25 12:24:40.348096
# Unit test for function ansible_native_concat

# Generated at 2022-06-25 12:24:41.094398
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert isinstance(test_case_0(), bytes)

# Generated at 2022-06-25 12:24:47.473257
# Unit test for function ansible_native_concat

# Generated at 2022-06-25 12:24:52.862448
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    try:
        test_case_0()
    except Exception as e:
        print("Exception occurred in ansible_native_concat() in test/test_test_utils.py.")
        raise e
    else:
        print("test_ansible_native_concat() in test/test_test_utils.py ran without exceptions.")


# Unit tests for this file.
if __name__ == '__main__':
    test_ansible_native_concat()

# Generated at 2022-06-25 12:25:02.226203
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test for a string
    bytes_0 = b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'
    var_0 = ansible_native_concat(bytes_0)
    assert isinstance(var_0, bytes)
    assert var_0 == bytes_0
    # Test for an integer
    int_1 = 7
    var_1 = ansible_native_concat(int_1)
    assert isinstance(var_1, int)
    assert var_1 == int_1
    # Test for a boolean
    bool_2 = True
    var_2 = ansible_native_concat(bool_2)
    assert isinstance(var_2, bool)
    assert var_2 == bool_2


# Generated at 2022-06-25 12:25:10.638569
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    print()
    print("BEFORE:", end=' ')
    print(to_text(b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5', nonstring='passthru'), to_text(b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5', nonstring='passthru'))
    print("AFTER:", end=' ')

# Generated at 2022-06-25 12:25:11.464753
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    #pass
    pass



# Generated at 2022-06-25 12:25:12.963657
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        assert False



# Generated at 2022-06-25 12:25:13.993361
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert callable(ansible_native_concat)



# Generated at 2022-06-25 12:25:25.955909
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = test_case_0()
    assert var_0 == u'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'
    var_1 = ansible_native_concat([])
    assert var_1 is None
    var_2 = ansible_native_concat([None])
    assert var_2 is None
    var_3 = ansible_native_concat(['foo'])
    assert var_3 == u'foo'
    var_4 = ansible_native_concat(['foo', 'bar'])
    assert var_4 == u'foobar'
    var_5 = ansible_native_concat([10, 20])
    assert var_5 == 30
    var_6 = ansible

# Generated at 2022-06-25 12:25:28.020869
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    ansible_native_concat('\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5')

# Generated at 2022-06-25 12:25:30.720862
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert callable(ansible_native_concat)



# Generated at 2022-06-25 12:25:32.502475
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert type(test_case_0()) is bytes

# Generated at 2022-06-25 12:25:42.664672
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    num_bytes = 100000

    bytes_0 = b''.join(
        bytes([(i % 128) for i in range(0, num_bytes)])
    )
    var_0 = ansible_native_concat(bytes_0)
    assert isinstance(var_0, string_types)

    bytes_1 = b'\xff' * num_bytes
    var_1 = ansible_native_concat(bytes_1)
    assert isinstance(var_1, string_types)

    bytes_2 = b'\xff' * num_bytes
    bytes_3 = b'\x00' * num_bytes
    bytes_4 = b''.join(
        bytes([(i % 128) for i in range(0, num_bytes)])
    )

# Generated at 2022-06-25 12:25:44.204249
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert True, "Test is not implemented."
    # TODO: Add implementation test
    pass



# Generated at 2022-06-25 12:25:51.461536
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """
    Ensure that ansible_native_concat returns the same as
    container_to_text
    """

    assert ansible_native_concat(['abc']) == container_to_text(['abc'])

    assert ansible_native_concat(['ab', 'cd']) == container_to_text(['ab', 'cd'])
    assert ansible_native_concat(['ab', 'cd', 'ef']) == container_to_text(['ab', 'cd', 'ef'])

    assert ansible_native_concat([1, 2, 3]) == container_to_text([1, 2, 3])
    assert ansible_native_concat([1, 2, 3, 4]) == container_to_text([1, 2, 3, 4])



# Generated at 2022-06-25 12:26:01.463841
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # This test will fail.
    # assert test_case_0() == '\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'

    bytes_1 = b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'
    var_1 = ansible_native_concat(bytes_1)

    # TODO
    assert var_1 == '\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'



# Generated at 2022-06-25 12:26:11.105510
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = 'this'
    var_1 = 'that'
    var_2 = u''
    var_3 = u'\u043a'
    var_4 = [u'\u043a']
    var_5 = {u'\u043a': None}
    var_6 = (u'\u043a',)
    var_7 = ' '.join([u'\u043a'])
    var_8 = 10
    var_9 = [u'\u043a', u'b']

    # Example from doc string
    assert ansible_native_concat(var_3) == u'\u043a'
    # Concat two strings
    assert ansible_native_concat([var_0, var_1]) == 'this that'
    # Concat two strings for unicode strings


# Generated at 2022-06-25 12:26:11.633941
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    pass

# Generated at 2022-06-25 12:26:26.029783
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'
    var_1 = ansible_native_concat(var_0)
    assert var_1 == 'ä,ölTË\x7ffáÞ\xad_¤0\x15Å'


from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.utils import (
    get_socket_path, load_provider, socket_path_exists
)

from ansible.module_utils.six.moves.configparser import ConfigParser

# Generated at 2022-06-25 12:26:27.592958
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Test case for native concatenation with a single object
    test_case_0()

# Generated at 2022-06-25 12:26:34.613663
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    bytes_0 = b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'
    var_0 = ansible_native_concat(bytes_0)
    bytes_1 = b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'
    var_1 = ansible_native_concat(bytes_1)

    assert var_0 == var_1


# Generated at 2022-06-25 12:26:41.422561
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Case 0 of 1
    bytes_0 = b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'
    var_0 = ansible_native_concat(bytes_0)
    assert container_to_text(var_0) == 'ä,ülTË\x7ffáÞ\xad_¦0\x15Å'

# Generated at 2022-06-25 12:26:42.819200
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()



# Generated at 2022-06-25 12:26:52.291104
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test no argument
    assert ansible_native_concat() is None

    # Test one argument
    assert ansible_native_concat(b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5') == b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'

    # Test two arguments, concatenated and parsed

# Generated at 2022-06-25 12:27:00.984782
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert None == ansible_native_concat([])
    assert None == ansible_native_concat([None])
    assert b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5' == ansible_native_concat([b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'])
    assert b'0' == ansible_native_concat([b'0'])
    assert '0' == ansible_native_concat(['0'])
    assert '0' == ansible_native_concat(['0', '1'])

# Generated at 2022-06-25 12:27:01.976329
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert not test_case_0()

# Generated at 2022-06-25 12:27:05.497421
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert type(ansible_native_concat(b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5')) is bytes


# Generated at 2022-06-25 12:27:18.015042
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(u'a,b') == u'a,b'
    assert ansible_native_concat(u'a') == u'a'
    expected = u'{{a}} {% set b = 1 %}{% if True %}{{b}}{% endif %}'
    assert ansible_native_concat([u'{{a}} ', u'{% set b = 1 %}', u'{% if True %}', u'{{b}}', u'{% endif %}']) == expected
    assert ansible_native_concat(u'a') == u'a'
    assert ansible_native_concat([u'a', u'b']) == u'ab'
    assert ansible_native_concat(u'') is None
    assert ansible_native_concat

# Generated at 2022-06-25 12:27:30.151192
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(((b'vault: $ANSIBLE_VAULT;1.1;AES256',),)) == u'vault: $ANSIBLE_VAULT;1.1;AES256'
    assert ansible_native_concat(((b'vault: $ANSIBLE_VAULT;1.1;AES256', b'\n'),)) == u'vault: $ANSIBLE_VAULT;1.1;AES256\n'

# Generated at 2022-06-25 12:27:32.199574
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'

# Generated at 2022-06-25 12:27:34.386493
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Run function ansible_native_concat with argument ['foo', 'bar']
    test_case_0()

# Generated at 2022-06-25 12:27:44.127735
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    b_0 = b'G?\xc5w\xa8\x89\xcf\xcc\x1f\x9d\x05O\x90\xcf\x98'
    var_0 = ansible_native_concat(b_0)
    b_1 = b'\xc3\x8a\xef\x97\x10\x91\x9d\xcclJ\xcdA\xf8\xc8\xe0\xee\x97'
    var_1 = ansible_native_concat(b_1)
    b_2 = b'\xd4\x02\x15\xd8\x9b\xab\xf3\xa2\xc8\xdc\xb4\x12\xa4|\x9a>'
    var_2

# Generated at 2022-06-25 12:27:45.293304
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
  assert to_text(ansible_native_concat([None])) == 'None'

# Generated at 2022-06-25 12:27:49.782754
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test with basic arguments
    bytes_0 = b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'
    var_0 = ansible_native_concat(bytes_0)
    assert var_0 == bytes_0



# Generated at 2022-06-25 12:27:54.879774
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.common.text.converters import container_to_text
    assert container_to_text(ansible_native_concat('foobar')) == 'foobar'
    assert container_to_text(ansible_native_concat(b'foobar')) == 'foobar'
    assert ansible_native_concat(1) == 1

# Generated at 2022-06-25 12:27:57.601804
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Check to see if the expected output is obtained.
    assert test_case_0() == bytearray(b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5')


# Generated at 2022-06-25 12:27:59.735110
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert True == True

# test for ansible_native_concat with multiple input strings

# Generated at 2022-06-25 12:28:02.346637
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert var_0 == b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'


# Generated at 2022-06-25 12:28:12.049191
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    for test in [test_case_0]:
        test()

# Boilerplate code for standalone testing
if __name__ == '__main__':
    from ansible.module_utils.basic import *  # basic.ANSIBLE_ARGS
    from ansible.module_utils.common.text.converters import to_bytes

    ansible_native_concat(ansible_native_concat(ansible_native_concat((
        container_to_text(
            container_to_text(
                container_to_text(to_bytes(u"\x00\x00\x00\x00\x00\x00\x00\x00"))))))))

    test_ansible_native_concat()

# Generated at 2022-06-25 12:28:13.544933
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() is not None

# Generated at 2022-06-25 12:28:19.975472
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_cases = {
        "0": {
            "args": [
                b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'
            ],
            "test_id": "0"
        }
    }

    for test_id, test_case in test_cases.items():
        args = test_case['args']
        test_id = test_case['test_id']
        if test_id=="0":
            test_case_0()

# Generated at 2022-06-25 12:28:21.949587
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # TODO: update tests to reflect new native_extract and native_concat
    assert 0 == 0  # noqa: E712

# Generated at 2022-06-25 12:28:26.560708
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert 'str' in globals(), "You must define 'str' for this test to work."
    assert 'bytes' in globals(), "You must define 'bytes' for this test to work."
    assert 'int' in globals(), "You must define 'int' for this test to work."
    test_case_0()


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 12:28:34.666658
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    bytes_0 = b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'
    var_0 = ansible_native_concat(bytes_0)
    var_1 = ansible_native_concat(var_0)
    var_2 = ansible_native_concat(var_1)
    var_3 = ansible_native_concat(var_2)
    var_4 = ansible_native_concat(var_3)
    var_5 = ansible_native_concat(var_4)
    var_6 = ansible_native_concat(var_5)


# Generated at 2022-06-25 12:28:39.864463
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    try:
        assert test_case_0()
    except AssertionError:
        print("Failure in: test_ansible_native_concat()")
        exit(1)


# Generated at 2022-06-25 12:28:41.057631
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()

# Utility function to format the input and output of function ansible_native_concat

# Generated at 2022-06-25 12:28:43.589391
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    bytes_0 = b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'
    var_0 = ansible_native_concat(bytes_0)
    assert var_0 == bytes_0

# Generated at 2022-06-25 12:28:48.775841
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test for case: 0
    bytes_0 = b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'
    var_0 = ansible_native_concat(bytes_0)



# Generated at 2022-06-25 12:28:52.372564
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert type(test_case_0()) == bytes

# Generated at 2022-06-25 12:28:57.631513
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_1 = 'undef'
    var_0 = ansible_native_concat(var_1)
    assert var_0 is None


# Generated at 2022-06-25 12:29:02.346510
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = b'\xe4,\x9clT\xcb\x7f\xfa\xde\xad_\xa20\x15\xc5'

    assert var_0.decode('utf-8') == 'ä,ślTË¿úÞ­_ª20Å'


# Generated at 2022-06-25 12:29:10.527693
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    '''
    Ensure that the plugin's native concat behaves the same as Jinja2
    '''

    from jinja2.nativetypes import native_concat

    from ansible.module_utils.common.text.converters import to_native
