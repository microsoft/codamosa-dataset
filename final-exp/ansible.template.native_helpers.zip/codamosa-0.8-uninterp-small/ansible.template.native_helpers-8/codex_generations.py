

# Generated at 2022-06-25 12:19:15.666004
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'S7TL"xZYm]1,)'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'S7TL"xZYm]1,)'

    str_1 = 'pX+5yrh&!pJ{w]5<$r5%xh2B$J|duD+#'
    var_1 = ansible_native_concat(str_1)
    assert var_1 == 'pX+5yrh&!pJ{w]5<$r5%xh2B$J|duD+#'


# Generated at 2022-06-25 12:19:17.954225
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    pass

# Generated at 2022-06-25 12:19:29.166952
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = b'\x00'
    dict_0 = dict(var_0=str_0)
    dict_1 = dict(false='abc', var_0=ansible_native_concat(str_0))
    str_1 = '\n'
    str_2 = '[test]\nhosts=localhost\n'
    str_3 = '\n'
    str_4 = '[test]\nhosts=localhost\n'
    str_5 = '\n'
    str_6 = '[test]\nhosts=localhost\n'
    str_7 = '\n'
    str_8 = '[test]\nhosts=localhost\n'

# Generated at 2022-06-25 12:19:31.812900
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert 'S7TL"xZYm]1,)' == ansible_native_concat(str_0)
    assert 'S7TL"xZYm]1,)' == ansible_native_concat(str_1)
    assert 'S7TL"xZYm]1,)' == ansible_native_concat(str_2)

# Generated at 2022-06-25 12:19:37.688120
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'S7TL"xZYm]1,)'
    var_0 = ansible_native_concat(str_0)
    str_1 = 'S7TL"xZYm]1,)'
    var_1 = ansible_native_concat(str_1)
    str_2 = 'z>$F|oK~x8l1,n9Z5Y5K5a5w5]5n5'
    var_2 = ansible_native_concat(str_2)
    str_3 = 'z>$F|oK~x8l1,n9Z5Y5K5a5w5]5n5'
    var_3 = ansible_native_concat(str_3)

# Generated at 2022-06-25 12:19:47.228766
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    t = []
    str_0 = 'S7TL"xZYm]1,)'
    var_0 = ansible_native_concat(str_0)
    t.append(var_0)
    str_1 = 'n\x1bA-]\x1a\x11p6\x17\x13\x14\x19s\x1c\x1b3\n\x19\x1cT\x12\x1e'
    var_1 = ansible_native_concat(str_1)
    t.append(var_1)
    str_2 = '\x1c\x1e'
    var_2 = ansible_native_concat(str_2)
    t.append(var_2)

# Generated at 2022-06-25 12:19:57.096632
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'U6*73'
    out_0 = 'U6*73'
    assert out_0 == ansible_native_concat(str_0)
    str_1 = '`"&Lw'
    out_1 = '`"&Lw'
    assert out_1 == ansible_native_concat(str_1)
    str_2 = 'Fuc;0$'
    out_2 = 'Fuc;0$'
    assert out_2 == ansible_native_concat(str_2)
    str_3 = '4>|2n/I'
    out_3 = '4>|2n/I'
    assert out_3 == ansible_native_concat(str_3)
    str_4 = 'x@,W#\\~'
    out

# Generated at 2022-06-25 12:20:03.805046
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'S7TL"xZYm]1,)'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'S7TL"xZYm]1,)'

# Generated at 2022-06-25 12:20:15.191501
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('S7TL"xZYm]1,)',) == 'S7TL"xZYm]1,)'
    assert ansible_native_concat('S7TL"xZYm]1,),',) == 'S7TL"xZYm]1,),'
    assert ansible_native_concat('S7TL"xZYm]1,),', 'S7TL"xZYm]1,),',) == 'S7TL"xZYm]1,),'

# Generated at 2022-06-25 12:20:18.785429
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert "p='/etc/passwd'" == ansible_native_concat("p='/etc/passwd'")
    assert "a=1 b=2" == ansible_native_concat("a=1 b=2")
    assert "/etc/passwd" == ansible_native_concat("/etc/passwd")

# Generated at 2022-06-25 12:20:28.928683
# Unit test for function ansible_native_concat

# Generated at 2022-06-25 12:20:30.569334
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # TODO: This is a stub.
    pass

# Generated at 2022-06-25 12:20:32.044297
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    pass

# Generated at 2022-06-25 12:20:35.146693
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'S7TL"xZYm]1,)'
    assert ansible_native_concat(str_0) == 'S7TL"xZYm]1,)'

# Generated at 2022-06-25 12:20:45.239511
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert str == type(ansible_native_concat(str))
    assert 'S7TL' == ansible_native_concat(str)
    assert str == type(ansible_native_concat(str))
    assert 'S7TLxZYm12' == ansible_native_concat(str)
    assert str == type(ansible_native_concat(str))
    assert 'S7TLxZYm1,)' == ansible_native_concat(str)
    assert str == type(ansible_native_concat(str))
    assert 'S7TLxZYm1,)' == ansible_native_concat(str)
    assert str == type(ansible_native_concat(str))
    assert 'S7TLxZYm1,)' == ansible_native_concat

# Generated at 2022-06-25 12:20:49.243323
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_1 = ansible_native_concat(["foo", "bar"])
    var_2 = ansible_native_concat([1, 2])
    var_3 = ansible_native_concat(["foo", "123"])
    assert var_1 == "foobar"
    assert var_2 == 3
    assert var_3 == "foo123"



# Generated at 2022-06-25 12:20:51.320929
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    with ansible_native_concat.style.override('native'):
        default_test_case_0()
        test_case_0()



# Generated at 2022-06-25 12:20:54.139510
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test for the ansible_native_concat function"""

    # Call ansible_native_concat
    var_res = ansible_native_concat(var_in)

    # Check that the result is as expected
    assert var_res == var_out

# Generated at 2022-06-25 12:20:57.982536
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'S7TL"xZYm]1,)'
    var_1 = ansible_native_concat(str_0)
    assert var_1 == 'S7TL"xZYm]1,)'



# Generated at 2022-06-25 12:21:01.767399
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    with pytest.raises(UndefinedError):
        str_0 = 'S7TL"xZYm]1,)'
        var_0 = ansible_native_concat(str_0)

# Generated at 2022-06-25 12:21:10.828182
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # noinspection PyUnresolvedReferences
    result = container_to_text(ansible_native_concat('S7TL"xZYm]1,)'))
    assert result == 'S7TL"xZYm]1,)'

    # noinspection PyUnresolvedReferences
    result = container_to_text(ansible_native_concat(['S7TL"xZYm]1,)' for i in range(4)]))
    assert result == 'S7TL"xZYm]1,)'

    # noinspection PyUnresolvedReferences
    result = container_to_text(ansible_native_concat(x for x in ['S7TL"xZYm]1,)' for i in range(4)]))
    assert result == 'S7TL"xZYm]1,)'

# Generated at 2022-06-25 12:21:16.854166
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert callable(ansible_native_concat)
    assert type(ansible_native_concat('')) == text_type

# Generated at 2022-06-25 12:21:27.345186
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = 'S7TL"xZYm]1,)'
    var_1 = '<!DOCTYPE html>\n<html>\n\t<head>\n\t\t<title>Test Page</title>\n\t</head>\n\t<body>\n\t\t<h1>Test</h1>\n\t\t<p>Hello</p>\n\t</body>\n</html>'
    var_2 = '3.14159265359'
    var_3 = '1.234'
    var_4 = '0.718281828459045'
    var_5 = '1.6'
    var_6 = '-1.6'
    var_7 = '-1.6'

# Generated at 2022-06-25 12:21:35.825132
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """
    Test for ansible_native_concat function
    """
    # Test 1: String
    str_1 = "Hello World!"
    var_1 = ansible_native_concat(str_1)
    assert var_1 == "Hello World!"

    # Test 2: Number
    num_2 = 12345
    var_2 = ansible_native_concat(num_2)
    assert var_2 == 12345

    # Test 3: Negative Number
    num_3 = -12345
    var_3 = ansible_native_concat(num_3)
    assert var_3 == -12345

    # Test 4: String
    str_4 = "12345"
    var_4 = ansible_native_concat(str_4)
    assert var_4 == 12345

    # Test 5

# Generated at 2022-06-25 12:21:38.006265
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test examples

    assert callable(ansible_native_concat)
    # Test case 0
    test_case_0()



# Generated at 2022-06-25 12:21:39.928416
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'S7TL"xZYm]1,)'
    var_0 = ansible_native_concat(str_0)

# Generated at 2022-06-25 12:21:41.960975
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat("S7TL\"xZYm]1,)") == 'S7TL"xZYm]1,)'

# Generated at 2022-06-25 12:21:44.590332
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert type(ansible_native_concat('')) is text_type


# Generated at 2022-06-25 12:21:52.224873
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Skip this test if the import of native_jinja2 is failing.
    try:
        from ansible.utils.native_jinja import native_concat
    except ImportError:
        return
    assert native_concat
    assert container_to_text

    # Test 'str_0' in function 'test_case_0'
    assert native_concat('S7TL"xZYm]1,)') == b'S7TL"xZYm]1,)'
    assert container_to_text(native_concat('S7TL"xZYm]1,)')) == 'S7TL"xZYm]1,)'



# Generated at 2022-06-25 12:22:02.432370
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '1.0'
    str_1 = '2.0'
    var_0 = ansible_native_concat(str_0)
    var_1 = ansible_native_concat(str_1)
    var_2 = True
    var_3 = False
    var_4 = 'true'
    var_5 = 'false'
    dict_0 = {}
    dict_1 = {'a': 'x', 'b': 'y'}
    dict_2 = {'a': 'x', 'b': 'y'}
    dict_3 = {'a': 'x', 'b': 'y'}
    dict_4 = {'a': 'x', 'b': 'y'}
    dict_5 = {'a': 'x', 'b': 'y'}
    dict

# Generated at 2022-06-25 12:22:13.161661
# Unit test for function ansible_native_concat

# Generated at 2022-06-25 12:22:24.047030
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_foo = 'foo'
    str_bar = 'bar'
    str_baz = 'baz'
    result = ansible_native_concat(str_foo)
    assert result == 'foo'
    result = ansible_native_concat(str_bar ,str_foo)
    assert result == 'foobar'
    result = ansible_native_concat(str_bar, str_foo, str_baz)
    assert result == 'foobarbaz'
    result = ansible_native_concat(str_foo, 4)
    assert result == 'foo4'
    result = ansible_native_concat(str_foo, 4, str_foo)
    assert result == 'foo4foo'

# Generated at 2022-06-25 12:22:32.135296
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_1 = 'S7TL"xZYm]1,)'
    var_2 = ansible_native_concat(var_1)
    var_3 = 'xZYm]1,)'
    var_4 = ansible_native_concat(var_3)
    var_5 = 'xZYm]1,)T'
    var_6 = ansible_native_concat(var_5)
    var_7 = ('S7TL"xZYm]1,)T', 'xZYm]1,)T')
    var_8 = ansible_native_concat(var_7)
    var_9 = 'S7TL"xZYm]1,)T'
    var_10 = ansible_native_concat(var_9)

# Generated at 2022-06-25 12:22:38.000309
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'Pk-E: &Ap!\x0c\x06\x1f\x1eX\x1c'
    str_1 = 'C#o?\x19\x0b\x1b\x15\x19\x1f^uV'
    int_0 = ansible_native_concat([str_0, str_1])

# Generated at 2022-06-25 12:22:41.442570
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # AssertionError: got 'S7TL"xZYm]1,)' instead of 'S7TL"xZYm]1,)'
    assert ansible_native_concat('S7TL"xZYm]1,)') == 'S7TL"xZYm]1,)'


# Generated at 2022-06-25 12:22:46.973906
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert 'S7TL"xZYm]1,)' == ansible_native_concat('S7TL"xZYm]1,)'), "ansible_native_concat('S7TL\"xZYm]1,)') should be 'S7TL\"xZYm]1,)' but is: %s" % ansible_native_concat('S7TL\"xZYm]1,)')
    assert '0' == ansible_native_concat('0'), "ansible_native_concat('0') should be '0' but is: %s" % ansible_native_concat('0')

# Definition of test cases and their expected results

# Generated at 2022-06-25 12:22:50.514532
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Try calling function with args
    assert ansible_native_concat(['S7TL"xZYm]1,)']) == 'S7TL"xZYm]1,)'



# Generated at 2022-06-25 12:22:58.448422
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'a9bm"I5)nP5o5N'
    str_1 = 'gR{&57N:(1]jVuY4=!<7&u}6[!]jwM'
    # Test with a single variable
    var_0 = ansible_native_concat(str_0)
    if var_0 != str_0:
        raise AssertionError('Expected {}, got {}.'.format(str_0, var_0))

    # Test with two variables
    var_1 = ansible_native_concat([str_0, str_1])
    if var_1 != 'a9bm"I5)nP5o5NgR{&57N:(1]jVuY4=!<7&u}6[!]jwM':
        raise

# Generated at 2022-06-25 12:23:02.858161
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '"%s"'
    str_result = '"%s"'
    var_1 = ansible_native_concat(str_0)
    assert str_result == var_1




# Generated at 2022-06-25 12:23:12.479703
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('S7TL"xZYm]1,)') == 'S7TL"xZYm]1,)'
    assert ansible_native_concat('0f]F&') == '0f]F&'
    assert ansible_native_concat('n r') == 'n r'
    assert ansible_native_concat('!QF")') == '!QF")'
    assert ansible_native_concat('W`[^') == 'W`[^'
    assert ansible_native_concat('Dj?9?') == 'Dj?9?'
    assert ansible_native_concat('R') == 'R'
    assert ansible_native_concat(',WQ5#') == ',WQ5#'
    assert ansible_native_

# Generated at 2022-06-25 12:23:16.432171
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()
    print("TEST SUCCESSFUL")

if __name__ == '__main__':
    test_ansible_native_concat()

# Generated at 2022-06-25 12:23:21.009783
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    try:
        str_0 = 'S7TL"xZYm]1,)'
        var_0 = ansible_native_concat(str_0)
    except (SyntaxError, ValueError, MemoryError):
        var_0 = 'S7TL"xZYm]1,)'

    assert var_0 == 'S7TL"xZYm]1,)'



# Generated at 2022-06-25 12:23:29.685587
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(('S7TL"xZYm]1,)', )) == 'S7TL"xZYm]1,)'
    assert ansible_native_concat(('6U"HJTAFhA', 'Z6g,x(vn"f]`(P', '8zF}q7,q')) == '6U"HJTAFhAZ6g,x(vn"f]`(P8zF}q7,q'
    assert ansible_native_concat((':N\rjh', 'O', '8:y6)wU')) == ':N\rjhO8:y6)wU'

# Generated at 2022-06-25 12:23:31.566966
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(0) == 0



# Generated at 2022-06-25 12:23:35.038799
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Testing parameters
    str_0 = 'S7TL"xZYm]1,)'
    var_0 = ansible_native_concat(str_0)


if __name__ == '__main__':
    test_ansible_native_concat()

# Generated at 2022-06-25 12:23:44.451779
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    output = ansible_native_concat('foobar')
    assert output == 'foobar'

    output = ansible_native_concat('foo' + 'bar')
    assert output == 'foobar'

    output = ansible_native_concat(1 + 2)
    assert output == 3

    output = ansible_native_concat(1 + 2 + 3)
    assert output == '5'

    output = ansible_native_concat(1 + "a" + 2 + 3 + "a" + "b" + "c")
    assert output == '1a23abc'

    output = ansible_native_concat("a" + [1, 2] + "b" + ["a", "b", "c"])
    assert output == "[1, 2]ab['a', 'b', 'c']"



# Generated at 2022-06-25 12:23:55.318145
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'S7TL"xZYm]1,)'
    var_0 = ansible_native_concat(str_0)
    var_1 = str_0
    assert var_0 == var_1
    str_1 = '7TL"xZYm]1,)'
    var_2 = ansible_native_concat(str_1)
    var_3 = str_1
    assert var_2 == var_3
    str_2 = '7TL"xZYm]1,)'
    var_4 = ansible_native_concat(str_2)
    var_5 = str_2
    assert var_4 == var_5
    str_3 = 'L"xZYm]1,)'

# Generated at 2022-06-25 12:24:01.060980
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_1 = 'S7TL"xZYm]1,)'
    var_1 = ansible_native_concat(str_1)

    str_2 = 'S7TL{}xZYm{}1,{}'
    var_2 = ansible_native_concat(str_2)

    int_0 = 255
    var_3 = ansible_native_concat(int_0)

    dict_0 = {'key_0': 'value_0', 'key_1': 'value_1'}
    var_4 = ansible_native_concat(dict_0)

    list_0 = ['0', '1', '2', '3', '4', '5']
    var_5 = ansible_native_concat(list_0)


# Generated at 2022-06-25 12:24:10.650009
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = ''
    str_1 = ' '
    str_2 = '   '
    str_3 = ' a'
    str_4 = ' A '
    str_5 = 'a '
    str_6 = 'a  '
    str_7 = ' abc'
    str_8 = ' abc '
    str_9 = 'a  b '
    str_10 = 'abc  '
    str_11 = 'abc   '
    str_12 = 'abc  '
    str_13 = '0'
    str_14 = '00'
    str_15 = '0.0'
    str_16 = '000.000'
    str_17 = '0.0.0'
    str_18 = '0.0.0.0'

# Generated at 2022-06-25 12:24:12.441307
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # TODO: Implement test for function ansible_native_concat
    # assert ansible_native_concat() == 'It works!'
    pass

# Generated at 2022-06-25 12:24:16.046851
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert isinstance(test_case_0(), text_type), "Did not return a string"

# Generated at 2022-06-25 12:24:21.252650
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    environ_vault_password = os.environ["ANSIBLE_VAULT_PASSWORD"]
    os.environ["ANSIBLE_VAULT_PASSWORD"] = "test"
    # Execute the function under test
    test_case_0()
    # Restore the environ
    os.environ["ANSIBLE_VAULT_PASSWORD"] = environ_vault_password

# Generated at 2022-06-25 12:24:29.056427
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'S7TL"xZYm]1,)'
    var_0 = ansible_native_concat(str_0)
    var_0 = ansible_native_concat(var_0)
    assert var_0 == 'S7TL"xZYm]1,)'

    container_0 = 'abcdefghijklmnopqrstuvwxyz0123456789'
    var_1 = ansible_native_concat(container_0)
    assert var_1 == 'abcdefghijklmnopqrstuvwxyz0123456789'

    container_1 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
    var_2 = ansible_native_concat(container_1)
    assert var_2

# Generated at 2022-06-25 12:24:31.411159
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    val = 'S7TL"xZYm]1,)'
    assert ansible_native_concat(val) == val

# Generated at 2022-06-25 12:24:33.506839
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert to_text(u'S7TLxZYm]1,)') == ansible_native_concat(u'S7TL"xZYm]1,)')

# Generated at 2022-06-25 12:24:41.252398
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Simple validation of ansible_native_concat function
    str_0 = 'S7TL"xZYm]1,)'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'S7TL"xZYm]1,)'
    str_1 = 'z;|>&rF/zt~5\tX\x0f\x1a\x06'
    var_1 = ansible_native_concat(str_1)
    assert var_1 == 'z;|>&rF/zt~5\tX\x0f\x1a\x06'
    str_2 = '\'{}\',c%<>S_'
    var_2 = ansible_native_concat(str_2)
    assert var_2

# Generated at 2022-06-25 12:24:42.017651
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() is not None



# Generated at 2022-06-25 12:24:43.622713
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    result = ansible_native_concat(var_0)
    assert result == 'S7TL"xZYm]1,)'

# Generated at 2022-06-25 12:24:48.213883
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert str is ansible_native_concat('zm_8QvC[[m"KkU6{')
    assert callable is ansible_native_concat('pY\x7f"$s,i')
    assert int is ansible_native_concat('g"83\x7fR')
    assert set is ansible_native_concat('5\x7fZ,]\x7f!X')
    assert dict is ansible_native_concat('H\x7f"IZ^\x7f,\\N')
    assert list is ansible_native_concat('PR!K4\x7fV,s')



# Generated at 2022-06-25 12:24:57.726883
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test with string
    str_0 = "abcde"
    var_0 = ansible_native_concat(str_0)
    assert var_0 == "abcde"

    # Test with integer
    int_0 = 1234
    var_0 = ansible_native_concat(int_0)
    assert var_0 == 1234

    # Test with boolean
    bool_0 = True
    var_0 = ansible_native_concat(bool_0)
    assert var_0

    # Test with bool_0 is False
    bool_0 = False
    var_0 = ansible_native_concat(bool_0)
    assert var_0 is False

    # Test with list
    # TODO: add more tests to ensure list is properly handled

# Generated at 2022-06-25 12:25:01.974913
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    res = ansible_native_concat(arg_0)
    assert res == str_0



# Generated at 2022-06-25 12:25:05.705605
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'S7TL"xZYm]1,)'
    var_0 = ansible_native_concat(
        ast.literal_eval(
            ast.parse(
                str_0, mode='eval'
            )
        )
    )

    assert str_0 == var_0

# Generated at 2022-06-25 12:25:06.987250
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    global changed_0
    ansible_native_concat(changed_0)



# Generated at 2022-06-25 12:25:14.431343
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_cases = [
        (['foo'], 'foo'),
        (['foo', 'bar'], 'foobar'),
        (['"foo"'], 'foo'),
        (["'foo'"], 'foo'),
        (['foo', 123], 'foo123'),
        (['foo', 'true'], 'footrue'),
        (['1', '2', '3'], '123'),
        (['{', '"foo"', ':', '"bar"'], '{"foo": "bar"}')
    ]

    for case in test_cases:
        assert(ansible_native_concat(case[0]) == case[1])

# Generated at 2022-06-25 12:25:17.429394
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'S7TL"xZYm]1,)'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'S7TL"xZYm]1,)'



# Generated at 2022-06-25 12:25:21.117027
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Argument str_0 is an encrypted string
    str_0 = 'S7TL"xZYm]1,)'
    var_0 = ansible_native_concat(str_0)
    assert container_to_text(var_0) == '"foo"', 'Test Failed'


# Generated at 2022-06-25 12:25:29.686657
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert "S7TLxZYm]1,)" == ansible_native_concat('S7TL"xZYm]1,)')
    assert "S7TLxZYm]1,)" == ansible_native_concat('S7TLxZYm]1,)')
    assert "S7TLxZYm]1,)" == ansible_native_concat('S7TLxZYm]1,)'+'""')
    assert "S7TLxZYm]1,)" == ansible_native_concat('S7TLxZYm]1,)'+'""'+'""')
    assert "S7TLxZYm]1,)" == ansible_native_concat('S7TLxZYm]1,)'+'""'+'""'+'""')

# Generated at 2022-06-25 12:25:41.112782
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    expected = "S7TLxZYm]1,)"
    assert ansible_native_concat("S7TL\"xZYm]1,)\x00") == expected
    assert ansible_native_concat("S7TL\"xZYm]1,)\x00") == expected
    assert ansible_native_concat("S7TL\"xZYm]1,)\x00") == expected
    assert ansible_native_concat("S7TL\"xZYm]1,)\x00") == expected
    assert ansible_native_concat("S7TL\"xZYm]1,)\x00") == expected
    assert ansible_native_concat("S7TL\"xZYm]1,)\x00") == expected

# Generated at 2022-06-25 12:25:45.014540
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'S7TL"xZYm]1,)'
    var_0 = ansible_native_concat(str_0)
    assert type(var_0) == ansible_native_concat(str_0).__class__
    assert var_0 == 'S7TL"xZYm]1,)'

# Generated at 2022-06-25 12:25:46.163145
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert len(ansible_native_concat([])) == 0

# Generated at 2022-06-25 12:25:48.666377
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()

# Generated at 2022-06-25 12:25:49.295127
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    pass


# Generated at 2022-06-25 12:25:51.175046
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'S7TL"xZYm]1,)'
    var_0 = ansible_native_concat(str_0)


# Generated at 2022-06-25 12:25:52.051253
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # This function might need a more in depth test
    pass


# Generated at 2022-06-25 12:26:03.427252
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ast.literal_eval("'f'") == 'f'
    str_0 = 'f'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'f'
    assert ast.literal_eval("'g'") == 'g'
    str_1 = 'g'
    var_0 = ansible_native_concat(str_1)
    assert var_0 == 'g'
    str_2 = 'h'
    var_0 = ansible_native_concat(str_2)
    assert var_0 == 'h'
    str_3 = 'a'
    str_4 = 'b'
    var_0 = ansible_native_concat(str_3 + str_4)
    assert var_0 == 'ab'
    str

# Generated at 2022-06-25 12:26:08.474854
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    t = ansible_native_concat(["foo"])
    assert t is not None

    t = ansible_native_concat(["foo", "bar"])
    assert t is not None

    t = ansible_native_concat(["foo", "bar", "baz"])
    assert t is not None

    t = ansible_native_concat(["foo", "bar", "baz", "qux"])
    assert t is not None

    t = ansible_native_concat(["foo", "bar"])
    assert t is not None

    t = ansible_native_concat(["foo", "bar", "baz"])
    assert t is not None

    t = ansible_native_concat(["foo", "bar", "baz", "qux"])
    assert t

# Generated at 2022-06-25 12:26:16.740303
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('S7TL"xZYm]1,)') == 'S7TL"xZYm]1,)'
    assert ansible_native_concat('S7TL"xZYm]1,)\x9c\x07\x92\xbeP\x81\xbeY\xa4\x19') == 'S7TL"xZYm]1,)\x9c\x07\x92\xbeP\x81\xbeY\xa4\x19'

# Generated at 2022-06-25 12:26:17.922923
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    for test_case_number in range(0):
        test_case_0()



# Generated at 2022-06-25 12:26:21.551601
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = 'S7TL"xZYm]1,)'
    var_0 = ansible_native_concat(var_0)



# Generated at 2022-06-25 12:26:32.073419
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'S7TL"xZYm]1,)'
    var_0 = ansible_native_concat(str_0)
    str_1 = None
    var_1 = ansible_native_concat(str_1)
    str_2 = 'AEyocWlV7D^$#'
    var_2 = ansible_native_concat(str_2)
    str_3 = 'JT@e'
    var_3 = ansible_native_concat(str_3)
    str_4 = 'f@k-z'
    var_4 = ansible_native_concat(str_4)
    str_5 = 'Y_|+F'
    var_5 = ansible_native_concat(str_5)

# Generated at 2022-06-25 12:26:41.553432
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Example of function call
    str_0 = 'S7TL"xZYm]1,)'
    var_0 = ansible_native_concat(str_0)

    assert str(var_0) == 'S7TL"xZYm]1,)', 'Did not get expected value for variable var_0. Got "{0}", expecting "{1}"'.format(str(var_0), 'S7TL"xZYm]1,)')


# Generated at 2022-06-25 12:26:42.512453
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert True

# Generated at 2022-06-25 12:26:45.018801
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    out = ansible_native_concat(["{'e': 'f'}"])
    assert out == "{'e': 'f'}"

# Generated at 2022-06-25 12:26:54.490636
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert str(ansible_native_concat('S7TL"xZYm]1,)')) == 'S7TL"xZYm]1,)'
    assert str(ansible_native_concat(('ZK\nR', 'O8(M'))) == 'ZK\nRO8(M'
    assert str(ansible_native_concat(('r', '5#'))) == 'r5#'
    assert str(ansible_native_concat(('S', '\n'))) == 'S\n'
    assert str(ansible_native_concat(('cKm', '&,}'))) == 'cKm&,}'
    assert str(ansible_native_concat((9, 'N'))) == '9N'

# Generated at 2022-06-25 12:27:02.119563
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'S7TL"xZYm]1,)'
    var_0 = ansible_native_concat(str_0)
    assert type(var_0) == str, "The expected return type does not match the returned type"
    assert var_0 == str_0, "The expected return value does not match the returned value"

    str_0 = 'a0oa}'
    var_0 = ansible_native_concat(str_0)
    assert type(var_0) == str, "The expected return type does not match the returned type"
    assert var_0 == str_0, "The expected return value does not match the returned value"

    str_0 = 'L1:S~C/oZ=I'
    var_0 = ansible_native_concat(str_0)
   

# Generated at 2022-06-25 12:27:10.735335
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert 9 == ansible_native_concat('S7TL"xZYm]1,)')
    assert 9 == ansible_native_concat('S7TL"xZYm]1,)')
    assert '\u00f1' == ansible_native_concat('\u00f1')
    assert '\u00f1' == ansible_native_concat('n\u0303')
    assert 'h\u0303' == ansible_native_concat('\u0068\u0303')

    # Test with a generator
    assert 'foobar' == ansible_native_concat(('foo', 'bar'))
    assert 'foobar' == ansible_native_concat((v for v in ('foo', 'bar')))
    assert 'foobar' == ansible_native_concat

# Generated at 2022-06-25 12:27:12.337914
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == 'S7TL"xZYm]1,)'


# Generated at 2022-06-25 12:27:15.822904
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert type(ansible_native_concat('S7TL"xZYm]1,)')) == str
    assert container_to_text(ansible_native_concat('S7TL"xZYm]1,)')) == "S7TL\"xZYm]1,)"

# Generated at 2022-06-25 12:27:17.719767
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()
    test_case_0()

# Generated at 2022-06-25 12:27:20.734372
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'S7TL"xZYm]1,)'
    var_0 = ansible_native_concat(str_0)
    assert container_to_text(var_0) == 'S7TL"xZYm]1,)'

# Generated at 2022-06-25 12:27:31.618466
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'a'
    str_1 = 'A'
    str_2 = '1'
    str_3 = '1'
    str_4 = 'A'
    str_5 = 'A'
    str_6 = '1'
    str_7 = '1'
    str_8 = 'A'
    str_9 = '1'
    str_10 = '1'
    str_11 = 'A'
    str_12 = 'A'
    str_13 = '1'
    var_0 = ansible_native_concat(str_0)
    assert isinstance(var_0, str)
    var_1 = ansible_native_concat(str_1)
    assert isinstance(var_1, str)

# Generated at 2022-06-25 12:27:36.063416
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'S', u'7', u'T', u'L', u'"', u'x', u'Z', u'Y', u'm', u']', u'1', u',', u')']) == u"S7TL\"xZYm]1,)"



# Generated at 2022-06-25 12:27:42.610389
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Runs a test by calling the ansible_native_concat
    #   function with the arguments provided in the dictionary and
    #   returns the value that the call returns.

    # Calls the function
    out = ansible_native_concat(test_input_0)

    # Checks the correctness of the results of
    #   the ansible_native_concat function.
    print(test_input_0)
    print(out)


test_input_0 = dict(test_input_0=test_case_0)

# Generated at 2022-06-25 12:27:51.720088
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0() 

# Generated at 2022-06-25 12:27:53.522866
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert('S7TL"xZYm]1,)' == ansible_native_concat(str_0))


# Generated at 2022-06-25 12:28:02.271143
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_1 = '-1.1e-5'
    var_1 = ansible_native_concat(str_1)

    assert var_1 == -1.1e-5

    str_2 = 'Infinity'
    var_2 = ansible_native_concat(str_2)

    assert var_2 == float('Inf')

    str_3 = '-Infinity'
    var_3 = ansible_native_concat(str_3)

    assert var_3 == float('-Inf')

    str_4 = 'True'
    var_4 = ansible_native_concat(str_4)

    assert var_4 is True

    str_5 = 'False'
    var_5 = ansible_native_concat(str_5)

    assert var_5 is False

    str

# Generated at 2022-06-25 12:28:06.669929
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'S7TL"xZYm]1,)'
    var_0 = ansible_native_concat(str_0)
    var_1 = ansible_native_concat(var_0)
    assert var_1 == 'S7TL"xZYm]1,)'


# Generated at 2022-06-25 12:28:14.032464
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = 'X?a;I!oD0d!Oy$:8)'
    var_1 = ansible_native_concat([var_0, var_0])
    assert var_1 == 'X?a;I!oD0d!Oy$:8)X?a;I!oD0d!Oy$:8)'

    var_2 = 'M\x1a|\x10x\x0b\x1bN\x1b\x0f\x0b\x10t\x1a\x1c;\x1a\x1c\x0b\x15'
    var_3 = ansible_native_concat([var_2, var_2])

# Generated at 2022-06-25 12:28:19.821971
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.compat import PY3

    expected = {
        '0': 'S7TL"xZYm]1,)',
        '1': ['foo', 'bar']
    }
    actual = {
        '0': ansible_native_concat('S7TL"xZYm]1,)'),
        '1': ansible_native_concat(['foo', 'bar'])
    }

    assert actual == expected



# Generated at 2022-06-25 12:28:24.248390
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    curstr =  "Failed to convert this string to native type"
    curstr_concat = ansible_native_concat(curstr)
    var_0 = ansible_native_concat(curstr_concat)
    # print(curstr_concat)

if __name__ == "__main__":
    # test_case_0()
    test_ansible_native_concat()

# Generated at 2022-06-25 12:28:37.185913
# Unit test for function ansible_native_concat

# Generated at 2022-06-25 12:28:43.644058
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    this_dir = path.dirname(path.abspath(__file__))
    mock_file_path = path.join(this_dir, './fixtures/mock_data_0_ansible_native_concat.json')
    with open(mock_file_path, 'r') as mock_data_file:
        data = mock_data_file.read()
        mock_data_file.close()

    result = ansible_native_concat(data)
    assert result == 'S7TL"xZYm]1,)'


# Generated at 2022-06-25 12:28:54.379834
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'S7TL"xZYm]1,)'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'S7TL"xZYm]1,)'
    str_1 = 'NuVt'
    var_1 = ansible_native_concat(str_1)
    assert var_1 == 'NuVt'
    str_2 = 'g6bL'
    var_2 = ansible_native_concat(str_2)
    assert var_2 == 'g6bL'
    str_3 = 'UZ)w]x'
    var_3 = ansible_native_concat(str_3)
    assert var_3 == 'UZ)w]x'

# Generated at 2022-06-25 12:29:04.638109
# Unit test for function ansible_native_concat

# Generated at 2022-06-25 12:29:08.795367
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'S7TL"xZYm]1,)'
    var_0 = ansible_native_concat(str_0)

if __name__ == "__main__":
    test_case_0()
    test_ansible_native_concat()