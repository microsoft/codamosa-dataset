

# Generated at 2022-06-25 12:19:16.284140
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['test_value_0']) == 'test_value_0'
    assert ansible_native_concat(['test_value_1', 'test_value_2']) == 'test_value_1test_value_2'
    assert ansible_native_concat(['test_value_3', 'test_value_4', 'test_value_5']) == 'test_value_3test_value_4test_value_5'
    assert ansible_native_concat(['test_value_6', 'test_value_7', 'test_value_8', 'test_value_9']) == 'test_value_6test_value_7test_value_8test_value_9'

# Generated at 2022-06-25 12:19:26.960228
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_1 = ansible_native_concat(['a'])
    assert var_1 == 'a'

    var_2 = ansible_native_concat(['a', 'b'])
    assert var_2 == 'a' + 'b'

    var_3 = ansible_native_concat(['a', 'b', 'c'])
    assert var_3 == 'a' + 'b' + 'c'

    var_4 = ansible_native_concat(['1', '2', '3'])
    assert var_4 == 1 + 2 + 3

    var_5 = ansible_native_concat(['1', '2', '3.0'])
    assert var_5 == '1' + '2' + '3.0'

    var_6 = ansible_native_concat

# Generated at 2022-06-25 12:19:32.559569
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = {
        'foo': 'bar',
        'baz': 42,
    }
    assert ansible_native_concat(var_0) == var_0

    var_1 = 42
    assert ansible_native_concat([var_1]) == var_1

    var_2 = (1, 2, 3)
    assert ansible_native_concat(var_2) == var_2

    var_3 = 'foo'
    assert ansible_native_concat([var_3]) == var_3

    var_4 = False
    assert ansible_native_concat([var_4]) == var_4

    var_5 = 'foo'
    var_6 = 'bar'
    var_7 = 'baz'

# Generated at 2022-06-25 12:19:38.121793
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert isinstance(ansible_native_concat([u'foo', u'bar']), text_type) == True
    assert isinstance(ansible_native_concat(map(container_to_text, [u'foo', u'bar'])), text_type) == True
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'

# Generated at 2022-06-25 12:19:47.519599
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    set_0 = {
        'foo': 'bar',
        'baz': 'qux',
    }

    var_0 = ansible_native_concat(set_0)
    assert var_0 == set_0

    set_1 = {
        'baz': 'qux',
        'foo': 'bar',
    }

    var_1 = ansible_native_concat(set_1)
    assert var_1 == set_1

    set_2 = {}

    var_2 = ansible_native_concat(set_2)
    assert var_2 == set_2


# Generated at 2022-06-25 12:19:48.805330
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() is None


# Generated at 2022-06-25 12:19:54.796439
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None, 'Expected None'
    assert ansible_native_concat(['bar']) == 'bar', 'Expected bar'
    assert ansible_native_concat(['bar', 'foo']) == 'barfoo', 'Expected barfoo'
    assert ansible_native_concat(['bar', 'baz', 'foo']) == 'barbazfoo', 'Expected barbazfoo'


# Generated at 2022-06-25 12:20:02.329008
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(set()) == None

    assert ansible_native_concat(set(['ab'])) == 'ab'

    assert isinstance(ansible_native_concat(set(['ab', 'c'])), text_type)

    assert ansible_native_concat(set(['ab', 'c'])) == 'abc'

    assert isinstance(ansible_native_concat(set(['ab', 'c', 'd', 'ef'])), text_type)

    assert ansible_native_concat(set(['ab', 'c', 'd', 'ef'])) == 'abcdef'

    assert ansible_native_concat(set(['ab', 'c', 'd', 'ef', 'ghij'])) == 'abcdefghij'


# Generated at 2022-06-25 12:20:13.359166
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # TODO: move this test to ansible/test/units/utils/native/test_jinja2_native.py
    # and possibly convert it to a pytest fixture

    # Generated with the following Python snippet.
    #
    # import json
    # with open('test_case_0.json', 'w') as output:
    #     json.dump([], output)
    data = {}

    set_0 = set()
    var_0 = ansible_native_concat(set_0)

    assert var_0 == None

    # Generated with the following Python snippet.
    #
    # import json
    # with open('test_case_1.json', 'w') as output:
    #     json.dump([1], output)
    data = {}

    set_0 = set()
    set_0

# Generated at 2022-06-25 12:20:14.286384
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # TODO: Implement test
    assert True

# Generated at 2022-06-25 12:20:18.245664
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'lu'
    var_0 = ansible_native_concat(str_0)
    ret = container_to_text(var_0)
    assert ret == 'lu'

# Generated at 2022-06-25 12:20:24.522088
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """ ansible_native_concat: Return a native Python type from the list of compiled nodes. If the result is a single node, its value is returned. Otherwise, the nodes are concatenated as strings. If the result can be parsed with ``ast.literal_eval``, the parsed value is returned. Otherwise, the string is returned. https://github.com/pallets/jinja/blob/master/src/jinja2/nativetypes.py
    """
    assert test_case_0() == 'lu'

# Generated at 2022-06-25 12:20:25.228615
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == 'lu'

# Generated at 2022-06-25 12:20:26.637787
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'lu'
    assert ansible_native_concat(str_0) == 'lu'

# Generated at 2022-06-25 12:20:30.048036
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test ansible_native_concat function with given inputs."""
    var_0 = 'foo bar'
    var_1 = u'foo bar'
    var_2 = ansible_native_concat(var_0)
    assert var_2 == u'foo bar'
    var_3 = ansible_native_concat(var_1)
    assert var_3 == u'foo bar'
    test_case_0()

# Generated at 2022-06-25 12:20:41.174540
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('lu') == 'lu'
    assert ansible_native_concat('lud') == 'lud'
    assert ansible_native_concat('lucy') == 'lucy'
    assert ansible_native_concat('lucy j') == 'lucy j'
    assert ansible_native_concat('lucy jon') == 'lucy jon'
    assert ansible_native_concat('lucy jones') == 'lucy jones'
    assert ansible_native_concat('lucy jones') == 'lucy jones'
    assert ansible_native_concat('bobby') == 'bobby'
    assert ansible_native_concat('bobby ') == 'bobby '

# Generated at 2022-06-25 12:20:50.172345
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'lu'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'lu'
    str_1 = 'lu'
    str_2 = 'cy'
    str_3 = 'ck'
    var_1 = ansible_native_concat(str_1, str_2, str_3)
    assert var_1 == 'lucky'
    str_4 = 'cy'
    var_2 = ansible_native_concat(str_0, str_4)
    assert var_2 == 'lucky'
    str_5 = 'y'
    str_6 = 't'
    var_3 = ansible_native_concat(str_5, str_6)
    assert var_3 == 'yt'

# Generated at 2022-06-25 12:20:55.113855
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # 1
    assert ansible_native_concat([1, 2]) is None
    # 2
    assert ansible_native_concat([3]) is None
    # 3
    assert ansible_native_concat([4, 5]) == 9
    # 4
    assert ansible_native_concat([6, 7, 8]) == 21
    # 5
    assert ansible_native_concat([9, 10, 11, 12, 13, 14, 15, 16, 17, 18]) == 90
    # 6
    assert ansible_native_concat([u'l', u'u']) == u'lu'
    # 7
    assert ansible_native_concat([u'c', u'a', u'n', u'i']) == u'cani'
    # 8
    assert ansible_native_

# Generated at 2022-06-25 12:20:57.819102
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'lu'
    ret_0 = ansible_native_concat(str_0)

    assert ret_0 == str_0


# Generated at 2022-06-25 12:21:07.976285
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    text = 'foo bar'
    text_result = ansible_native_concat(text)
    assert text_result == text

    text_list = ['foo', 'bar']
    text_list_result = ansible_native_concat(text_list)
    assert text_list_result == ''.join(text_list)

    text_dict = {'text': 'foo bar'}
    text_dict_result = ansible_native_concat(text_dict)
    assert text_dict_result == ansible_native_concat(text)

    text_list_dict = ['foo', {'text': 'bar'}]
    text_list_dict_result = ansible_native_concat(text_list_dict)
    assert text_list_dict_result == ansible_native_concat(text)

# Generated at 2022-06-25 12:21:14.977899
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('lu') == 'lu'
    assert ansible_native_concat('lu') == 'lu'
    assert ansible_native_concat('') == None
    assert ansible_native_concat('') is None
    assert ansible_native_concat([True]) == True
    assert ansible_native_concat([True]) == True

# Generated at 2022-06-25 12:21:16.058860
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert isinstance(ansible_native_concat(str_0), str)



# Generated at 2022-06-25 12:21:22.361481
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert(ansible_native_concat('lu') == 'lu')
    assert(ansible_native_concat(u'lu') == u'lu')
    assert(ansible_native_concat(b'lu') == b'lu')
    assert(ansible_native_concat(u'1') == u'1')
    assert(ansible_native_concat(u'1') == u'1')
    assert(ansible_native_concat(u'1') == u'1')
    assert(ansible_native_concat(u'1') == u'1')
    assert(ansible_native_concat(u'1') == u'1')
    assert(ansible_native_concat(False) == False)
    assert(ansible_native_concat(True) == True)


# Generated at 2022-06-25 12:21:25.269876
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'lu'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'lu'


# Generated at 2022-06-25 12:21:27.800043
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'lu'
    var_0 = ansible_native_concat(str_0)

# Generated at 2022-06-25 12:21:30.193580
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'lu'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'lu'



# Generated at 2022-06-25 12:21:31.065641
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == 'lu'

# Generated at 2022-06-25 12:21:32.537935
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert _fail_on_undefined(var_0) == 'lu'


# Generated at 2022-06-25 12:21:40.716857
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'lu'
    var_0 = ansible_native_concat(str_0)
    str_1 = 'w'
    str_2 = 'v'
    var_1 = ansible_native_concat(var_0, str_1, str_2)
    str_3 = 'zg'
    str_4 = '.'
    var_2 = ansible_native_concat(var_0, var_1, str_3, str_4)
    str_5 = 'i'
    str_6 = '2'
    var_3 = ansible_native_concat(var_0, var_1, var_2, str_5, str_6)
    str_7 = '4'

# Generated at 2022-06-25 12:21:44.662602
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    str_0 = 'lu'
    var_0 = ansible_native_concat(str_0)

    assert var_0 == 'lu'
    assert container_to_text(var_0) == '"lu"'


# Generated at 2022-06-25 12:21:47.171547
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test case 0
    str_0 = 'lu'
    var_0 = ansible_native_concat(str_0)

    assert var_0 == str_0

# Generated at 2022-06-25 12:21:54.679311
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert to_text(ansible_native_concat([])) == to_text(None)
    assert to_text(ansible_native_concat('lu')) == to_text('lu')
    assert to_text(ansible_native_concat('lud')) == to_text(None)
    assert to_text(ansible_native_concat('lu', '')) == to_text('lu')
    assert to_text(ansible_native_concat('lu', 'd')) == to_text('lud')
    assert to_text(ansible_native_concat('l', True, 'd')) == to_text('lTrued')
    assert to_text(ansible_native_concat('l', True, 'd', 42, '!')) == to_text('lTrued42!')

# Generated at 2022-06-25 12:21:58.115242
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'lu'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'lu', 'ansible_native_concat should return the str_0 value "lu"'

# Generated at 2022-06-25 12:22:07.690837
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()

# print 'Foo:', repr(foo)
# import ast
# node = ast.parse('[1, 2, 3]')
# ast.dump(node)
# ansible_native_concat(ast.parse('[1, 2, 3'))
# ansible_native_concat(ast.parse('[1, 2, 3]'))
# ast.literal_eval('[1, 2, 3]')


# Generated at 2022-06-25 12:22:12.485352
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(['foo']) == u'foo'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([['foo']]) == u'foo'
    assert ansible_native_concat([[1]]) == 1
    assert ansible_native_concat([[1, 'foo']]) == u'1foo'
    assert ansible_native_concat([[1, ['foo', 'bar']]]) == u'1foo,bar'
    assert ansible_native_concat(['foo', 'bar']) == u'foobar'
    assert ansible_native_concat([1, 2]) == 1, 2

# Generated at 2022-06-25 12:22:14.269508
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    try:
        test_case_0()
    except Exception as e:
        assert False, f"Exception thrown: {e}"

# Generated at 2022-06-25 12:22:15.364693
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert 'lu' == ansible_native_concat('lu')



# Generated at 2022-06-25 12:22:18.878571
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'lu'
    var_0 = ansible_native_concat(str_0)

    assert var_0 == 'lu'



# Generated at 2022-06-25 12:22:28.487124
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # 1
    assert ansible_native_concat('lu') == 'lu'
    # 2
    assert ansible_native_concat(['lu']) == 'lu'
    # 3
    assert ansible_native_concat([None]) == None
    # 4
    assert ansible_native_concat([None, None]) == 'NoneNone'
    # 5
    assert ansible_native_concat(['lu', 'la']) == 'lula'
    # 6
    assert ansible_native_concat([1, 'lu']) == '1lu'
    # 7
    assert ansible_native_concat(['lu', 1]) == 'lu1'
    # 8
    assert ansible_native_concat([1, 'lu', None]) == '1luNone'
    # 9

# Generated at 2022-06-25 12:22:34.971075
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    tested_functions_list = [
        test_case_0
    ]

    for test_case in tested_functions_list:
        test_case()


test_ansible_native_concat()

# Generated at 2022-06-25 12:22:42.502747
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'lu'
    var_0 = ansible_native_concat(str_0)
    str_1 = 'm'
    str_2 = 'b'
    var_1 = ansible_native_concat(str_1, str_2)
    str_3 = 'e_'
    str_4 = 's'
    str_5 = 'o'
    str_6 = 'l'
    str_7 = 'u'
    str_8 = 't'
    str_9 = 'i'
    str_10 = 'o'
    str_11 = 'n'
    var_2 = ansible_native_concat(str_3, str_4, str_5, str_6, str_7, str_8, str_9, str_10, str_11)


# Generated at 2022-06-25 12:22:44.964405
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('lu') == 'lu'


# Test case for function ansible_native_concat

# Generated at 2022-06-25 12:22:45.908927
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert var_0 == "lu"



# Generated at 2022-06-25 12:22:48.463048
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    try:
        test_case_0()
    except AssertionError:
        assert False, "Unable to execute test case for function 'ansible_native_concat'"


# Generated at 2022-06-25 12:22:57.402583
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    func = ansible_native_concat

    # TODO: Mock some objects to test this function.
    #
    # ansible_native_concat(nodes_0)
    # assert func(nodes_0) == {'ansible_os_family': 'Debian', 'ansible_distribution_version': '7.0', 'ansible_distribution_release': 'wheezy/updates', 'ansible_distribution_major_version': '7'}

    # ansible_native_concat(nodes_1)
    # assert func(nodes_1) == {'ansible_os_family': 'Debian', 'ansible_distribution_version': '7.0', 'ansible_distribution_release': 'wheezy/updates', 'ansible_distribution_major_version': '7

# Generated at 2022-06-25 12:22:58.124379
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == 'lu'

# Generated at 2022-06-25 12:23:00.272454
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    ansible_native_concat(test_case_0)



# Generated at 2022-06-25 12:23:10.781722
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'luke'
    str_1 = 'skywalker'
    var_0 = ansible_native_concat(str_0, str_1)
    assert var_0 == 'lukeskywalker'
    int_0 = 16
    int_1 = 28
    var_1 = ansible_native_concat(int_0, int_1)
    assert var_1 == 44
    bool_0 = True
    bool_1 = False
    var_2 = ansible_native_concat(bool_0, bool_1)
    assert var_2 == 'TrueFalse'
    dict_0 = dict(a=1, b=2)
    dict_1 = dict(x=1, y=2)
    var_3 = ansible_native_concat(dict_0, dict_1)

# Generated at 2022-06-25 12:23:17.873042
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """
    Test function ansible_native_concat
    """
    str_0 = 'lu'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'lu'

    str_0 = 'N'
    list_0 = ('lo', 'ng', '_', 'li', 'st')
    var_0 = ansible_native_concat((str_0, list_0))
    assert var_0 == 'Nlogn_li_st'

    list_0 = ('l', 'on', 'g', '_', 'li', 'st')
    str_0 = 'N'
    var_0 = ansible_native_concat((str_0, list_0))
    assert var_0 == 'Nlogn_li_st'



# Generated at 2022-06-25 12:23:18.936143
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert (test_case_0() is not None)

# Generated at 2022-06-25 12:23:27.716513
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'lu'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'lu', "Expected {}, Got {}".format('lu', var_0)

    str_0 = 'c'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'c', "Expected {}, Got {}".format('c', var_0)

    str_0 = 'y'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'y', "Expected {}, Got {}".format('y', var_0)


# Generated at 2022-06-25 12:23:37.725632
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert 'lu' == ansible_native_concat('lu')
    assert 'luc' == ansible_native_concat('luc')
    assert 'luci' == ansible_native_concat('luci')
    assert 'lucien' == ansible_native_concat('lucien')
    assert 'lucien ' == ansible_native_concat('lucien ')
    assert ' lucien' == ansible_native_concat(' lucien')
    assert 'lucien b' == ansible_native_concat('lucien b')
    assert 'lucien be' == ansible_native_concat('lucien be')
    assert 'lucien bea' == ansible_native_concat('lucien bea')
    assert 'lucien beau'

# Generated at 2022-06-25 12:23:45.387500
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['lu']) == 'lu'
    assert ansible_native_concat(['lus']) == 'lus'
    assert ansible_native_concat(['l0']) == 'l0'
    assert ansible_native_concat(['l1']) == 'l1'
    assert ansible_native_concat(['l2']) == 'l2'
    assert ansible_native_concat(['l3']) == 'l3'
    assert ansible_native_concat(['l4']) == 'l4'
    assert ansible_native_concat(['l5']) == 'l5'
    assert ansible_native_concat(['l6']) == 'l6'

# Generated at 2022-06-25 12:23:56.017289
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # There is no return value. Instead, this is evaluated as a string.
    str_0 = 'lu'
    var_0 = ansible_native_concat(str_0)
    # assert var_0 == 'lu'

    # There is no return value. Instead, this is evaluated as a string.
    str_0 = 'lu'
    var_0 = ansible_native_concat(str_0)
    # assert var_0 == 'lu'

    # There is no return value. Instead, this is evaluated as a string.
    str_0 = 'lu'
    var_0 = ansible_native_concat(str_0)
    # assert var_0 == 'lu'

    # There is no return value. Instead, this is evaluated as a string.
    str_0 = 'lu'
    var_0

# Generated at 2022-06-25 12:23:57.568949
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var = 'lu'
    var_0 = ansible_native_concat(var)
    assert var_0 == 'lu'

# Generated at 2022-06-25 12:24:02.275543
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Testing the type of a string value
    var_1 = ansible_native_concat(u'lu')

    assert isinstance(var_1, text_type)
    assert var_1 == u'lu'

    # Testing the type of a list value
    var_2 = ansible_native_concat([u'l', u'u'])

    assert isinstance(var_2, text_type)
    assert var_2 == u'lu'

    # Testing the type of a dictionary value
    var_3 = ansible_native_concat({u'a': u'l', u'b': u'u'})

    assert isinstance(var_3, text_type)
    assert var_3 == u'{u\'a\': u\'l\', u\'b\': u\'u\'}'

    #

# Generated at 2022-06-25 12:24:04.720160
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    function_name = "ansible_native_concat"

    # str_0
    str_0 = 'lu'
    var_0 = ansible_native_concat(str_0)

    # Check type of var_0
    assert isinstance(var_0, text_type)

    # Check value of var_0
    assert var_0 == 'lu'


# Generated at 2022-06-25 12:24:13.295927
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('string') == 'string'
    assert ansible_native_concat(['string', 'string']) == 'stringstring'
    assert ansible_native_concat('string', 'string') == 'stringstring'
    assert ansible_native_concat(['string', 'string', 3, 4, 4.0]) == u'stringstring3444.0'

    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat(['1', '2', 3]) == 123

    assert ansible_native_concat([1, 2, 3, 4.0]) == 1234.0
    assert ansible_native_concat(['1', '2', 3, 4.0]) == 1234.0

    assert ansible_native_con

# Generated at 2022-06-25 12:24:17.987053
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert (ansible_native_concat(u'lu') == b'lu')
    assert (ansible_native_concat(u'lu') == 'lu')
    assert (ansible_native_concat('lu') == b'lu')
    assert (ansible_native_concat('lu') == 'lu')



# Generated at 2022-06-25 12:24:20.589292
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    for test_case in [0, 1]:
        func = globals()[f"test_case_{test_case}"]
        func()

# Generated at 2022-06-25 12:24:28.168695
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('lu') is 'lu'
    assert ansible_native_concat('lun') is 'lun'
    assert ansible_native_concat('luna') is 'luna'
    assert ansible_native_concat('lunan') is 'lunan'
    assert ansible_native_concat('lunana') is 'lunana'
    assert ansible_native_concat('lunanan') is 'lunanan'
    assert ansible_native_concat('lunanana') is 'lunanana'

# Generated at 2022-06-25 12:24:29.178384
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['lu']) == 'lu'



# Generated at 2022-06-25 12:24:34.511891
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = ansible_native_concat('a')
    assert str_0 == "a"

    str_1 = ansible_native_concat('b', 'c')
    assert str_1 == "bc"

    str_2 = ansible_native_concat('b', 'c', 'd')
    assert str_2 == "bcd"

    str_3 = ansible_native_concat('', 'c', 'd')
    assert str_3 == "cd"

    str_4 = ansible_native_concat('', 'c', 'd', 'e')
    assert str_4 == "cde"

    str_5 = ansible_native_concat('a', 'b', 'c', 'd', 'e', 'f')
    assert str_5 == "abcdef"

    str_

# Generated at 2022-06-25 12:24:40.130803
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Assert that the first item in node_0 is equal to '1'
    assert node_0.body[0].value.n == '1'
    # Assert that the first item in node_1 is equal to '2'
    assert node_1.body[0].value.n == '2'
    # Assert that the value of ansible_native_concat(node_0, node_1) is equal to '12'
    assert ansible_native_concat(node_0, node_1) == '12'



# Generated at 2022-06-25 12:24:45.821399
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'lu'
    var_0 = ansible_native_concat(str_0)  # var_0 : str
    assert isinstance(var_0, string_types)

    str_1 = 'a'
    int_0 = 1
    var_1 = ansible_native_concat(str_1, int_0)  # int
    assert isinstance(var_1, int)

    str_2 = 'a'
    str_3 = 'b'
    str_4 = 'c'
    var_2 = ansible_native_concat(str_2, str_3, str_4)  # var_2 : str
    assert isinstance(var_2, string_types)

    str_5 = 'a'
    str_6 = 'b'

# Generated at 2022-06-25 12:24:46.426631
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == 'lu'

# Generated at 2022-06-25 12:24:54.182450
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'lu'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'lu'

    str_0 = 'f'
    str_1 = 'o'
    str_2 = 'o'
    var_0 = ansible_native_concat([str_0, str_1, str_2])
    assert var_0 == 'foo'

    str_0 = 'f'
    str_1 = 'oo'
    str_2 = 'o'
    var_0 = ansible_native_concat([str_0, str_1, str_2])
    assert var_0 == 'fooo'

    str_0 = '1'
    str_1 = '2'
    str_2 = '3'
    var_0 = ansible_

# Generated at 2022-06-25 12:24:56.092886
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    ansible_native_concat('lu') == 'lu'

# Generated at 2022-06-25 12:24:58.006367
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_actual = ansible_native_concat(str_0)
    var_expected = to_text(str_0)
    assert var_actual == var_expected



# Generated at 2022-06-25 12:25:00.858124
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'lu'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'lu'



# Generated at 2022-06-25 12:25:06.127084
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    try:
        str_0 = 'lu'
        expected = 'lu'
        actual = ansible_native_concat(str_0)
        assert expected == actual
    except AssertionError:
        print('Expected: {}\nActual: {}'.format(expected, actual))
        raise



# Generated at 2022-06-25 12:25:07.075619
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()

# Generated at 2022-06-25 12:25:09.257563
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'wf'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'wf'



# Generated at 2022-06-25 12:25:14.241946
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # assertRaisesRegex(exception,regexp,callable,*args,**kwds)
    # Regexp must match the error message generated
    with pytest.raises(RuntimeError) as test_case:
        test_case_0()
    regexp = "error message"
    test_case.match(regexp)


import ansible_vault
from ansible_collections.community.crypto.plugins.module_utils.encryption.ansible_vault.vault import VaultLib



# Generated at 2022-06-25 12:25:17.156165
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'lucy'
    list_0 = [str_0]
    int_0 = ansible_native_concat(list_0)
    def function_0(val_0):
        return val_0
    list_1 = [int_0, function_0(1), function_0(2)]
    dict_0 = dict.fromkeys(list_1, function_0(2))
    assert dict_0[1] == 2
    assert dict_0[2] == 2

# Generated at 2022-06-25 12:25:26.033826
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_1 = ansible_native_concat('lu')
    assert var_1 == 'lu'
    var_2 = ansible_native_concat('lulu')
    assert var_2 == 'lulu'
    var_3 = ansible_native_concat('08')
    assert var_3 == '08'
    var_4 = ansible_native_concat('09')
    assert var_4 == '09'
    var_5 = ansible_native_concat('lam')
    assert var_5 == 'lam'
    var_6 = ansible_native_concat('lamb')
    assert var_6 == 'lamb'
    var_7 = ansible_native_concat('lambo')
    assert var_7 == 'lambo'
    var_8 = ansible_native_con

# Generated at 2022-06-25 12:25:32.495682
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'lu'
    var_0 = ansible_native_concat(str_0)
    str_1 = 'luke'
    var_1 = ansible_native_concat(str_1)
    str_2 = '\nl\tuke'
    var_2 = ansible_native_concat(str_2)
    assert var_0 == 'lu', 'ansible_native_concat() returned {0}, expected {1}'.format(var_0, 'lu')
    assert var_1 == 'luke', 'ansible_native_concat() returned {0}, expected {1}'.format(var_1, 'luke')

# Generated at 2022-06-25 12:25:41.882955
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var = ansible_native_concat([b'a'])
    assert var == b'a'
    var = ansible_native_concat([b'a', b'b'])
    assert var == b'ab'
    var = ansible_native_concat([107, 48, 74, 66, 74, 97])
    assert var == 7031
    var = ansible_native_concat([b'107', b'48', b'74', b'66', b'74', b'97'])
    assert var == 7031
    var = ansible_native_concat([b'x107x48x74x66x74x97'])
    assert var == b'x107x48x74x66x74x97'

# Generated at 2022-06-25 12:25:49.924767
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'lu'
    var_0 = ansible_native_concat(str_0)
    assert isinstance(var_0, string_types)
    assert var_0 == 'lu'
    assert isinstance(var_0, text_type)

    str_1 = 'ast'
    var_1 = ansible_native_concat(str_1)
    assert isinstance(var_1, string_types)
    assert var_1 == 'ast'
    assert isinstance(var_1, text_type)
    out = ansible_native_concat(var_0 + var_1)
    assert isinstance(out, string_types)
    assert out == 'ludicrous'
    assert isinstance(out, text_type)

# Generated at 2022-06-25 12:25:50.832576
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'

# Generated at 2022-06-25 12:25:54.496698
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Test function
    assert ansible_native_concat(str_0) == None



# Generated at 2022-06-25 12:25:58.724119
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    func_name = "ansible_native_concat"
    func_args = [str_0]
    func_result = ansible_native_concat(str_0)
    assert func_result == "lu"


# Generated at 2022-06-25 12:26:00.052293
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat == 'lu'



# Generated at 2022-06-25 12:26:01.722661
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()
    test_case_1()
    test_case_2()



# Generated at 2022-06-25 12:26:03.599091
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'lu'
    assert ansible_native_concat(str_0) == 'lu'



# Generated at 2022-06-25 12:26:05.266572
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    ansible_native_concat(test_case_0())



# Generated at 2022-06-25 12:26:06.130863
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()

# Generated at 2022-06-25 12:26:15.218679
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'lu'
    var_0 = ansible_native_concat(str_0)
    assert not var_0

    str_0 = 'ascii'
    var_0 = ansible_native_concat([str_0])
    assert var_0 == 'ascii'

    str_0 = 'ascii'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'ascii'

    str_0 = 'ascii'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'ascii'

    str_0 = 'ascii'
    var_0 = ansible_native_concat([str_0])
    assert var_0 == 'ascii'

   

# Generated at 2022-06-25 12:26:25.159519
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Testing for when str_0 = 'lu'
    str_0 = 'lu'
    ret_1 = ansible_native_concat(str_0)
    assert ret_1 == 'lu'

    str_2 = u'lu'
    ret_3 = ansible_native_concat(str_2)
    assert ret_3 == u'lu'

    str_4 = 'lu'
    ret_5 = ansible_native_concat(str_4)
    assert ret_5 == 'lu'

    str_6 = u'lu'
    ret_7 = ansible_native_concat(str_6)
    assert ret_7 == u'lu'

    str_8 = 'lu'
    ret_9 = ansible_native_concat(str_8)

# Generated at 2022-06-25 12:26:26.333537
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert 'l' in ansible_native_concat('l')


# Generated at 2022-06-25 12:26:31.436740
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # For the following test data, the return value was generated like this:
    #   ansible_native_concat(str_0)

    test_case_0()



# Generated at 2022-06-25 12:26:33.066999
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    list_0 = [b'l', 'u']
    assert(ansible_native_concat(list_0) == 'lu')

# Generated at 2022-06-25 12:26:34.613497
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'lu'
    var_0 = ansible_native_concat(str_0)



# Generated at 2022-06-25 12:26:40.270103
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'lu'
    var_0 = ansible_native_concat(str_0)
    assert container_to_text(var_0) == str_0



# Generated at 2022-06-25 12:26:43.008271
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'lu'
    var_0 = ansible_native_concat(str_0)

    assert var_0 == 'lu'



# Generated at 2022-06-25 12:26:52.330335
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_1 = 'x'
    var_1 = ansible_native_concat(str_1)
    assert var_1 == 'x'

    str_2 = 'x'
    var_2 = ansible_native_concat(str_2)
    assert var_2 == 'x'

    str_3 = 'x'
    var_3 = ansible_native_concat(str_3)
    assert var_3 == 'x'

    str_4 = 'x'
    var_4 = ansible_native_concat(str_4)
    assert var_4 == 'x'

    str_5 = 'x'

    var_5 = ansible_native_concat(str_5)
    assert var_5 == 'x'

    str_6 = 'x'

# Generated at 2022-06-25 12:26:53.928524
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() is None

# Generated at 2022-06-25 12:27:01.700374
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('lu') == 'lu'
    assert ansible_native_concat('lu') == 'lu'
    assert ansible_native_concat('lu') == 'lu'
    assert ansible_native_concat('lut') == 'lut'
    assert ansible_native_concat('lut') == 'lut'
    assert ansible_native_concat('lu' + 't') == 'lut'
    assert ansible_native_concat('lu' + '') == 'lu'
    assert ansible_native_concat('' + 'lu') == 'lu'
    assert ansible_native_concat('q' + 'lut') == 'qlut'
    assert ansible_native_concat('qlut') == 'qlut'
    assert ansible_native

# Generated at 2022-06-25 12:27:10.268131
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert ansible_native_concat('lu') == 'lu'
    assert ansible_native_concat(1) == 1
    assert ansible_native_concat(['l', 'u']) == 'lu'
    assert ansible_native_concat('l') == 'l'
    assert ansible_native_concat(['l', 'u']) == 'lu'

    assert ansible_native_concat('lu') == 'lu'
    assert ansible_native_concat(1) == 1
    assert ansible_native_concat(['l', 'u']) == 'lu'
    assert ansible_native_concat('l') == 'l'
    assert ansible_native_concat(['l', 'u']) == 'lu'

# Generated at 2022-06-25 12:27:19.642655
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(u"") is None, \
        "ansible_native_concat with empty list should return None"
    assert ansible_native_concat(u"", 1) is None, \
        "ansible_native_concat with empty list should return None"

    assert ansible_native_concat([u""]) is None, \
        "ansible_native_concat with empty list and list should return None"
    assert ansible_native_concat([u"", 1]) is None, \
        "ansible_native_concat with empty list and list should return None"

    assert ansible_native_concat([u""]) is None, \
        "ansible_native_concat with empty list and list should return None"

# Generated at 2022-06-25 12:27:24.190540
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    with pytest.raises(SyntaxError) as excinfo:
        test_case_0()
    assert str(excinfo.value) == 'invalid syntax'

# Generated at 2022-06-25 12:27:32.240520
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'lu'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'lu'
    str_0 = 'a0'
    str_1 = '<---'
    var_0 = ansible_native_concat(str_0, str_1)
    assert var_0 == 'a0<---'
    str_0 = 'lu'
    str_1 = '0a'
    var_0 = ansible_native_concat(str_0, str_1)
    assert var_0 == 'lu0a'
    str_0 = 'a0'
    str_1 = '<---'
    str_2 = 'c'
    var_0 = ansible_native_concat(str_0, str_1, str_2)

# Generated at 2022-06-25 12:27:34.976070
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'lu'
    var_0 = ansible_native_concat(str_0)
    assert var_0 is None

# Generated at 2022-06-25 12:27:44.547394
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'lu'
    var_0 = ansible_native_concat(str_0)
    assert type(var_0) == text_type
    str_1 = 'ma'
    var_1 = ansible_native_concat(str_1)
    assert type(var_1) == text_type
    str_2 = 'hu'
    var_2 = ansible_native_concat(str_2)
    assert type(var_2) == text_type
    str_3 = 'j'
    var_3 = ansible_native_concat(str_3)
    assert type(var_3) == text_type
    str_4 = 'la'
    var_4 = ansible_native_concat(str_4)
    assert type(var_4) == text_type

# Generated at 2022-06-25 12:27:53.679471
# Unit test for function ansible_native_concat

# Generated at 2022-06-25 12:27:55.954694
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'lu'
    var_0 = ansible_native_concat(str_0)
    assert 'lu' == var_0



# Generated at 2022-06-25 12:28:01.513947
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    result = ansible_native_concat()

    assert result is None

    result = ansible_native_concat([])

    assert result is None

    result = ansible_native_concat('abc')

    assert result == 'abc'

    result = ansible_native_concat(('abc', 'def'))

    assert result == 'abcdef'

    result = ansible_native_concat(['abc', 'def'])

    assert result == 'abcdef'

    result = ansible_native_concat('abc', ['d', 'e', 'f'])

    assert result == 'abcdef'

    result = ansible_native_concat('abc', iter(['d', 'e', 'f']))

    assert result == 'abcdef'


# Generated at 2022-06-25 12:28:03.930157
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == 'lu', "ansible_native_concat() returns 'lu'"

# Generated at 2022-06-25 12:28:05.745238
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assertion = 'lu'
    var_0 = ansible_native_concat(assertion)
    assert var_0 == 'lu'

# Generated at 2022-06-25 12:28:09.587608
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'lu'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'lu'
    str_1 = 'lul'
    var_1 = ansible_native_concat(str_1)
    assert var_1 == 'lul'



# Generated at 2022-06-25 12:28:12.713263
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    try:
        assert test_case_0()
    except AssertionError as ae:
        raise AssertionError(ae)

# Generated at 2022-06-25 12:28:14.547495
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # test cases
    test_case_0()



# Generated at 2022-06-25 12:28:23.343705
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    import ansible.modules.network.eos.eos_facts
    import ansible.modules.network.eos.eos_command
    import ansible.modules.network.eos.eos_config
    from ansible.module_utils.network.eos.facts.facts import Facts
    from ansible.module_utils.network.common.utils import dict_merge
    from ansible.module_utils.network.eos.config.config import Config
    from ansible.module_utils.network.eos.argspec.facts.facts import FactsArgs
    from ansible.module_utils.network.eos.argspec.config.config import ConfigArgs
    from ansible.module_utils.network.eos.argspec.command.command import CommandArgs

# Generated at 2022-06-25 12:28:27.041600
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # TODO: Test case with an undefined List item
    # TODO: Test case with an undefined Dict value
    # TODO: Test case with an undefined Iterator item
    test_case_0()

# TODO: Mock ast.literal_eval to properly test ansible_native_concat
# TODO: Test case with an undefined StrictUndefined valued

# Generated at 2022-06-25 12:28:36.209562
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'lu'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'lu'

    str_0 = 'c'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'c'

    str_0 = 'ce'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'ce'

    str_0 = 'cen'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'cen'

    str_0 = 'cent'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'cent'

    str_0 = 'cento'
    var

# Generated at 2022-06-25 12:28:38.268579
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test without argument
    str_0 = 'lu'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'lu'

# Generated at 2022-06-25 12:28:46.224073
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Testing with string type
    str_0 = 'lu'
    var_0 = container_to_text(ansible_native_concat(str_0))
    assert var_0 == 'lu'

    # Testing with string type
    str_0 = 'lu'
    var_0 = container_to_text(ansible_native_concat(str_0))
    assert var_0 == 'lu'

    # Testing with string type
    str_0 = 'lu'
    var_0 = container_to_text(ansible_native_concat(str_0))
    assert var_0 == 'lu'

    # Testing with string type
    str_0 = 'lu'
    var_0 = container_to_text(ansible_native_concat(str_0))
    assert var_0 == 'lu'

# Generated at 2022-06-25 12:28:55.454534
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([text_type('lu')]) == 'lu'
    assert ansible_native_concat([text_type('lu')]*7) == 'lululululululu'
    assert ansible_native_concat([text_type('lu')]*7, text_type('a')) == 'lululululululua'

    assert ansible_native_concat([text_type('7')]) == '7'
    assert ansible_native_concat([text_type('7')]*7) == '7777777'
    assert ansible_native_concat([text_type('7')]*7, text_type('8')) == '77777778'

    assert ansible_native_concat([text_type('7'), text_type('1')])

# Generated at 2022-06-25 12:28:56.687168
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    ansible_native_concat('lu')



# Generated at 2022-06-25 12:29:06.475292
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert str(ansible_native_concat([u'lu'])) == str(u'lu')
    assert str(ansible_native_concat([u'lu', u'lut'])) == str(u'lulut')
    assert str(ansible_native_concat([u'foobar', u'baz'])) == str(u'foobarbaz')
    assert ansible_native_concat([u'foobar', u'baz']) == u'foobarbaz'
    assert container_to_text(ansible_native_concat([u'foobar', u'baz'])) == u'foobarbaz'
    assert str(ansible_native_concat([u'foobar', u'baz', u'blah'])) == str(u'foobarbazblah')
   