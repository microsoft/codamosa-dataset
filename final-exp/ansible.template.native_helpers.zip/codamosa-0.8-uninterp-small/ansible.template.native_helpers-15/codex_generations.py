

# Generated at 2022-06-25 12:19:15.423223
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    try:
        test_case_0()
    except (Exception) as e:
        print('Exception: {}'.format(e))
        assert False
    else:
        assert True


if __name__ == '__main__':
    test_ansible_native_concat()

# Generated at 2022-06-25 12:19:19.628549
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    bool_0 = True
    var_0 = ansible_native_concat(bool_0)
    assert type(var_0) is bool
    assert var_0 is True



# Generated at 2022-06-25 12:19:20.223939
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert True

# Generated at 2022-06-25 12:19:21.129219
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert var_0 == True


# Generated at 2022-06-25 12:19:31.415760
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.loader import AnsibleLoader

    var_0 = set()
    var_0.add('[ str_0 ]')
    var_0.add(' ')
    var_0.add('[ str_1 ]')
    str_0 = '{0} is'.format(container_to_text(var_0))
    str_1 = 'output of the ansible_native_concat function'
    str_2 = '{0}\n{1}\n'.format(str_0, str_1)
    str_2_yaml = '\n{0}\n'.format(str_2)
    dict_0 = AnsibleLoader(str_2_yaml).get_single_data()

# Generated at 2022-06-25 12:19:33.523231
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    bool_0 = True
    var_0 = ansible_native_concat(bool_0)

    # Asserts equality
    assert var_0 == True

# Generated at 2022-06-25 12:19:34.837960
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    args = {"nodes": "foo"}
    result = ansible_native_concat(*args)
    assert result == "foo"

# Generated at 2022-06-25 12:19:37.660567
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = ansible_native_concat([])
    assert len(var_0) == 0
    var_1 = ansible_native_concat(['a', 'b', 'c'])
    assert var_1 == 'abc'

# Generated at 2022-06-25 12:19:38.906434
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    expected = True
    actual = test_case_0()
    assert actual == expected

# Generated at 2022-06-25 12:19:48.009033
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Function defs
    results = [
        (True, True),
        ("abc", "abc"),
        (123, 123),
        ((1, 2, 3), [1, 2, 3]),
        ([1, 2, 3], [1, 2, 3]),
        ({'a': 1}, {'a': 1}),
        (None, None),
    ]

    for args, expected in results:
        assert ansible_native_concat(args) == expected

    # Test literal_eval
    assert ansible_native_concat(None) == None
    assert ansible_native_concat((None, None, None)) == None
    assert ansible_native_concat((True, True, True)) == True
    assert ansible_native_concat((True, 'a', True)) == True
    assert ansible_

# Generated at 2022-06-25 12:19:58.780926
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Assert that str_0 equals str_1 after running ansible_native_concat
    str_0 = '-)~BPm$e4'
    str_1 = ansible_native_concat(str_0)
    assert str_0 == str_1
    # Assert that str_2 equals str_3 after running ansible_native_concat
    str_2 = ''
    str_3 = ansible_native_concat(str_2)
    assert str_2 == str_3
    # Assert that str_4 equals str_5 after running ansible_native_concat
    str_4 = 'e)N@8-uS~-'
    str_5 = ansible_native_concat(str_4)
    assert str_4 == str_5
    # Assert that str_6 equals str

# Generated at 2022-06-25 12:20:04.698964
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    string_0 = ansible_native_concat('-|\t&Y')
    assert string_0 == '-|\t&Y'

    string_1 = ansible_native_concat(['~#F', 'sf$h', '/)=,&$'])
    assert string_1 == '~#Fsf$h/)=,&$'

    string_2 = ansible_native_concat(['Qw', '-/', 'Qm'])
    assert string_2 == 'Qw-/Qm'

    string_3 = ansible_native_concat(['B$6', '}CW', 'Xc'])
    assert string_3 == 'B$6}CWXc'

    string_4 = ansible_native_concat(['gNZ', 'bI+'])
    assert string

# Generated at 2022-06-25 12:20:09.438913
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '-)~BPm$e4'
    var_0 = ansible_native_concat(str_0)
    if var_0 == '-)~BPm$e4':
        raise AssertionError('Var 0 is wrong')


# Generated at 2022-06-25 12:20:10.896702
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_1 = ansible_native_concat(str_0)

# Generated at 2022-06-25 12:20:19.678344
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert 'foo' == ansible_native_concat('foo')
    assert 'foo' == ansible_native_concat('f', 'o', 'o')
    assert 'foo' == ansible_native_concat(['f', 'o', 'o'])
    assert 'foo' == ansible_native_concat({'1': 'f', '2': 'o', '3': 'o'})
    assert 'foo' == ansible_native_concat(('f', 'o', 'o'))
    assert 'foo' == ansible_native_concat(('f', 'o', {'foo': 'o'}))
    assert 'foo' == ansible_native_concat({'1': 'f', '2': {'foo': 'o'}, '3': 'o'})

    # test concatenation

# Generated at 2022-06-25 12:20:23.743341
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(str_0) == str_0.__str__()


# We need a test case that uses a proper variable name so that the result is
# not optimized in the generated code.
var_0 = '-)~BPm$e4'


# Generated at 2022-06-25 12:20:26.266148
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Should succeed
    try:
        test_case_0()
    except Exception:
        assert False
    # Should fail
    try:
        test_case_1()
        assert False
    except:
        assert True


# Generated at 2022-06-25 12:20:33.776556
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = ':)'
    var_0 = ansible_native_concat(str_0)
    assert(var_0 == str_0)

    str_0 = '*&%^$pj~d'
    var_0 = ansible_native_concat(str_0)
    assert(var_0 == str_0)

    str_0 = 'dfs~%^&*'
    var_0 = ansible_native_concat(str_0)
    assert(var_0 == str_0)

    str_0 = '03-17-2020'
    var_0 = ansible_native_concat(str_0)
    assert(var_0 == str_0)

    str_0 = ')%$#@#$'
    var_0 = ansible_native_con

# Generated at 2022-06-25 12:20:43.152141
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '-)~BPm$e4'
    assert (ansible_native_concat(str_0) is None)

    dict_0 = dict([('nest_1', dict([('nest_2', 'str_0')]))])
    assert (ansible_native_concat(dict_0) == dict_0)

    list_1 = []
    list_1.append('str_0')
    list_1.append(dict([('nest_1', dict([('nest_2', 'str_1')]))]))
    assert (ansible_native_concat(list_1) == list_1)

    dict_1 = dict([('nest_1', dict([('nest_2', dict([('nest_3', 'str_0')]))]))])
   

# Generated at 2022-06-25 12:20:51.649454
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'cR'
    str_1 = "6xm^B3yi'z#"
    dict_0 = { 'ybI': '|P', '7v^8WJ': 'jE', '-5$#+M': str_0, 'yAp': 'hGj+', '-': str_1, 'Ez': 'P' }
    str_2 = 'Fq*'
    dict_1 = { 'a': dict_0, 's': '39G', 'H': '7Vu)', 'M': 'V', '6x': str_2 }
    list_0 = [dict_1, 'D', 'Pd', 'Iy']
    list_1 = [dict_0, '5L-', 'M', list_0, '0Y2']
   

# Generated at 2022-06-25 12:20:58.232832
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    ansible_native_concat(var_0)
    #assert True
    #assert False
    #assert var_0[0] == ')'
    #assert var_0[1] == '>'

# Generated at 2022-06-25 12:21:03.624963
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '-)~BPm$e4'

    # Call function 'ansible_native_concat'
    var_0 = ansible_native_concat(str_0)

    # Evaluations

    assert var_0 == "-)~BPm$e4", 'str_0 == str(-)~BPm$e4)'



# Generated at 2022-06-25 12:21:06.627305
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_1 = 'v)0?R.fHX'
    var_0 = ansible_native_concat(str_1)
    assert var_0 == 'v)0?R.fHX'


# Generated at 2022-06-25 12:21:16.488538
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Tests passing a string
    str_0 = '-)~BPm$e4'
    var_0 = ansible_native_concat(str_0)
    # Tests passing an int
    str_1 = 5
    var_1 = ansible_native_concat(str_1)
    # Tests passing a float
    str_2 = 5.0
    var_2 = ansible_native_concat(str_2)
    # Tests passing a list
    str_3 = ['d', 0, 'Sx0m']
    var_3 = ansible_native_concat(str_3)
    # Tests passing a dict
    str_4 = {'A': 'O', 'B': '5i5', 'C': '3'}

# Generated at 2022-06-25 12:21:22.548316
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert callable(ansible_native_concat), 'Function ansible_native_concat is not callable.'
    assert isinstance(ansible_native_concat('-)~BPm$e4'), string_types), 'The returned value should be of type string_types'
    assert isinstance(ansible_native_concat('KyM5Z5' + 'Yd5' + '7Vu' + 'k1I' + 'io' + 'g'), string_types), 'The returned value should be of type string_types'
    assert isinstance(ansible_native_concat(':' + 'SKc' + 'qW' + 'n' + 'Xy' + 'QlA0'), string_types), 'The returned value should be of type string_types'

# Generated at 2022-06-25 12:21:25.070967
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test case
    str_0 = '-)~BPm$e4'
    ansible_native_concat(str_0)
    assert True

# Generated at 2022-06-25 12:21:34.667102
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('-)~BPm$e4') == '-)~BPm$e4'
    assert ansible_native_concat(u'-)~BPm$e4') == u'-)~BPm$e4'
    assert ansible_native_concat(['-)~BPm$e4', 'v% )gA']) == '-)~BPm$e4v% )gA'
    assert ansible_native_concat(['-)~BPm$e4', u'v% )gA']) == u'-)~BPm$e4v% )gA'

# Generated at 2022-06-25 12:21:42.499043
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = ""
    str_1 = "s"
    str_2 = "str"
    str_3 = "str3"
    str_4 = "str4"
    str_5 = "str5"
    str_list_0 = [str_0, str_1, str_2, str_3, str_4, str_5]
    int_1 = 1
    int_2 = 2
    int_3 = 3
    int_4 = 4
    int_5 = 5
    int_6 = 6
    int_list_0 = [int_1, int_2, int_3, int_4, int_5, int_6]
    float_0 = 0.0
    float_1 = 1.1
    float_2 = 2.2
    float_3 = 3.3


# Generated at 2022-06-25 12:21:45.977053
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '-)~BPm$e4'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == '-)~BPm$e4'


# Generated at 2022-06-25 12:21:54.009940
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '-)~BPm$e4'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == str_0

    int_0 = 123
    var_1 = ansible_native_concat(int_0)
    assert var_1 == int_0

    list_0 = [
        'f7EQ4h4~V7+N',
        '-LK{$S]^',
        '^U6b+1WPpvbnE'
    ]
    var_2 = ansible_native_concat(list_0)
    assert var_2 == list_0

    tuple_0 = ('L-B~8Nv+[,',)
    var_3 = ansible_native_concat(tuple_0)

# Generated at 2022-06-25 12:21:58.472340
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()


# Generated at 2022-06-25 12:22:01.280620
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '-)~BPm$e4'
    var_0 = ansible_native_concat(str_0)

    assert '-)~BPm$e4' == var_0

# Generated at 2022-06-25 12:22:05.325385
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '-)~BPm$e4'
    # expected result: '-)~BPm$e4'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == '-)~BPm$e4'


# Generated at 2022-06-25 12:22:14.024694
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = '#'
    var_1 = None
    var_2 = '@'
    out = ansible_native_concat([var_0, var_1, var_2])
    assert out == '#@'

    var_1 = 'X'
    out = ansible_native_concat([var_0, var_1, var_2])
    assert out == '#X@'

    var_0 = u'\u2295'
    out = ansible_native_concat([var_0, var_1, var_2])
    assert out == u'\u2295X@'

    var_1 = 'hello '
    var_2 = 'world!'
    var_3 = 'once'

# Generated at 2022-06-25 12:22:15.870711
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        assert False
    else:
        assert True



# Generated at 2022-06-25 12:22:26.343659
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    src_0 = 'Hello World!'
    dst_0 = 'Hello World!'
    assert ansible_native_concat(src_0) == dst_0

    src_1 = ['Hello', ' ', 'World', '!']
    dst_1 = 'Hello World!'
    assert ansible_native_concat(src_1) == dst_1

    src_2 = ['1', '+', '2']
    dst_2 = 3
    assert ansible_native_concat(src_2) == dst_2

    src_3 = []
    dst_3 = None
    assert ansible_native_concat(src_3) == dst_3

    src_4 = [1]
    dst_4 = 1
    assert ansible_native_concat(src_4) == dst_4


# Generated at 2022-06-25 12:22:35.820210
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = '-'
    var_1 = ')'
    var_2 = '~'
    var_3 = 'B'
    var_4 = 'P'
    var_5 = 'm'
    var_6 = '$'
    var_7 = 'e'
    var_8 = '4'

    var_9 = ansible_native_concat([var_0, var_1, var_2, var_3, var_4, var_5, var_6, var_7, var_8])
    assert var_9 == '-){~BPm$e4'
    var_10 = ansible_native_concat(var_9)
    assert var_10 == '-){~BPm$e4'

    # Tested functions
    # --------------- #
    # ansible_native

# Generated at 2022-06-25 12:22:45.724765
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var = ansible_native_concat([])
    assert var is None

    # In Python3.8+ container_to_text does not return unicode objects.
    # Since we are using ast.literal_eval above and in Python3.7
    # ast.literal_eval raises a SyntaxError for str(bytes) objects and
    # we need to mimic this behavior.
    if to_text(u'') != b'':
        # Skip these tests because we want to mimic Python3.7 behavior
        # and call ast.literal_eval on str(bytes) objects.
        skip('Test does not run on Python < 3.8')
    else:
        assert ansible_native_concat([b'a']) == b'a'
        assert ansible_native_concat([bytearray(b'a')])

# Generated at 2022-06-25 12:22:48.630789
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '-)~BPm$e4'
    var_1 = ansible_native_concat(str_0)

    assert str_0 == var_1


# Generated at 2022-06-25 12:22:57.549632
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Testing with a string as input
    input1 = "this is a test"
    assert ansible_native_concat(input1) == "this is a test"

    # Testing with a list as input
    input2 = [1, 2, 3, 4]
    assert ansible_native_concat(input2) == [1, 2, 3, 4]

    # Testing with a dict as input
    input3 = {"test1": 1, "test2": 2}
    assert ansible_native_concat(input3) == {"test1": 1, "test2": 2}

    # Testing with a tuple as input
    input4 = (1, 2, 3, 4, 5)
    assert ansible_native_concat(input4) == (1, 2, 3, 4, 5)

# Generated at 2022-06-25 12:23:11.422908
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    data = [
        ('-)~BPm$e4', '-)~BPm$e4'),
        ('#z5', '#z5'),
        (')^9K', ')^9K'),
        ('D-+', 'D-+'),
        ('', ''),
        ('!tZ*', '!tZ*'),
        ('NhP', 'NhP'),
        ('w', 'w'),
        ('/~+<', '/~+<'),
        ('|>h', '|>h'),
        ('', ''),
        ('*bQ', '*bQ'),
        ('3', '3'),
        ('%', '%'),
        ('LP', 'LP'),
        ('H', 'H'),
        ('#', '#'),
    ]

    for answer, value in data:
        assert container

# Generated at 2022-06-25 12:23:18.312242
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Case 0
    str_0 = '-)~BPm$e4'
    var_0 = ansible_native_concat(str_0)

    assert container_to_text(var_0) == text_type('-)~BPm$e4')

    # Case 1
    str_0 = '8s+ly'
    var_0 = ansible_native_concat(str_0)

    assert container_to_text(var_0) == text_type('8s+ly')

    # Case 2
    str_0 = 'gv#'
    var_0 = ansible_native_concat(str_0)

    assert container_to_text(var_0) == text_type('gv#')

    # Case 3
    str_0 = '4hkg'

# Generated at 2022-06-25 12:23:20.837006
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import ansible_native_concat as ansible_native_concat_m

    # Arguments:
    str_0 = '-)~BPm$e4'

    # Call function:
    ret_val = ansible_native_concat_m.ansible_native_concat(str_0)

    # Tests:
    assert isinstance(ret_val, string_types)

# Generated at 2022-06-25 12:23:29.532086
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = '-)~BPm$e4'
    var_1 = None
    var_2 = 9.840579773287585e+229
    var_3 = False
    var_4 = {0: 'xoA', 1: 5.01, 2: [4.69, 'e_X'], 3: -6.17, 4: '-6.17'}
    var_5 = ['6 (AFT#', -9.65, 1.0, 6.49]
    var_6 = (1e+296, 'KjyQX')

# Generated at 2022-06-25 12:23:35.573392
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = '-()~BPm$e4'
    var_1 = '5D(;$&o`<'
    var_2 = '(((\n)'
    var_3 = '`V7}uX9I#'
    var_4 = 'V~U(:A_?='
    var_5 = 'pi{s/'
    var_6 = ''
    var_7 = '1N:HD8WzF'
    var_8 = 's9s8s7s6s5s4s3s2s1s0'
    var_9 = 's7s6s5s4s3s2s1s0s9'
    var_10 = 's4s3s2s1s0s9s8s7s6'

# Generated at 2022-06-25 12:23:38.338391
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '-)~BPm$e4'
    var_0 = ansible_native_concat(str_0)


# Generated at 2022-06-25 12:23:47.670433
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    str_0 = '-)~BPm$e4'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == str_0


# Generated at 2022-06-25 12:23:49.939966
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ')' in var_0, 'Could not find a substring in var_0 with value: ")"'

# Generated at 2022-06-25 12:23:58.123284
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '-)~BPm$e4'
    var_0 = ansible_native_concat(str_0)
    print(var_0)
    str_0 = ' j&Lz'
    var_1 = ansible_native_concat(str_0)
    print(var_1)
    str_0 = '^~YX+'
    var_2 = ansible_native_concat(str_0)
    print(var_2)
    str_0 = '~<'
    var_3 = ansible_native_concat(str_0)
    print(var_3)
    str_0 = ')'
    var_4 = ansible_native_concat(str_0)
    print(var_4)
    str_0 = 'k'
    var

# Generated at 2022-06-25 12:24:09.206774
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat("0") == "0"
    assert ansible_native_concat("''") == ""
    assert ansible_native_concat("'1'") == "1"
    assert ansible_native_concat("'0'") == "0"
    assert ansible_native_concat("'1.0'") == "1.0"
    assert ansible_native_concat("'1.1'") == "1.1"
    assert ansible_native_concat("'0.0'") == "0.0"
    assert ansible_native_concat("'0.1'") == "0.1"
    assert ansible_native_concat("'0.01'") == "0.01"
    assert ansible_native_concat("'True'")

# Generated at 2022-06-25 12:24:25.694535
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['/home/vagrant/ansible-docs/_build/html/', '.buildinfo']) == '/home/vagrant/ansible-docs/_build/html/.buildinfo'
    assert ansible_native_concat(['"a"', '"b"']) == '"ab"'
    assert ansible_native_concat(['b', '"a"']) == 'ba'
    assert ansible_native_concat(['"a"', 'b']) == 'ab'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['[', 'a', ']', 'b']) == '[a]b'

# Generated at 2022-06-25 12:24:27.131545
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = []
    out = ansible_native_concat(nodes)
    assert out is None



# Generated at 2022-06-25 12:24:28.475336
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ast.parse(ansible_native_concat).body[0].value.func.id == 'ansible_native_concat'

# Generated at 2022-06-25 12:24:29.388036
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert '-)~BPm$e4' == ansible_native_concat(str)

# Generated at 2022-06-25 12:24:31.551795
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert 'HjYAhl4g4' == ansible_native_concat('HjYAhl4g4')

# Generated at 2022-06-25 12:24:32.030309
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert True



# Generated at 2022-06-25 12:24:40.159929
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '-)~BPm$e4'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == str_0

    str_0 = '\'~;l~\'l~\'*\n'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == str_0

    str_0 = '\'~#s~\'o~\'\\n\n'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == str_0

    str_0 = '\'~;l~\'l~\'*\n'
    str_1 = '\'~#s~\'o~\'\\n\n'

# Generated at 2022-06-25 12:24:45.847429
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = ('^![yh#(A:{g', 'B6')
    var_0 = ansible_native_concat(str_0)
    str_0 = '('
    str_1 = ')'
    var_0 = ansible_native_concat(str_0, str_1)
    str_0 = '|'
    str_1 = '+'
    str_2 = '-'
    var_0 = ansible_native_concat(str_0, str_1, str_2)
    str_0 = 'a'
    str_1 = 'b'
    str_2 = 'c'
    var_0 = ansible_native_concat(str_0, str_1, str_2)
    str_0 = 'a'

# Generated at 2022-06-25 12:24:53.313963
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = '6'
    var_1 = 'y'
    var_2 = 'c'
    var_3 = '8'
    str_0 = '6'
    str_1 = 'y'
    str_2 = 'c'
    str_3 = '8'
    var_4 = str_0 + str_1 + str_2 + str_3
    assert var_0 + var_1 + var_2 + var_3 == var_4
    str_0 = '-9F'
    str_1 = 'w'
    str_2 = 'Y'
    str_3 = 'E'
    str_4 = 's'
    str_5 = 'd'
    var_5 = str_0 + str_1 + str_2 + str_3 + str_4 + str_5

# Generated at 2022-06-25 12:24:54.740813
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('-)~BPm$e4') == '-)~BPm$e4'

# Generated at 2022-06-25 12:25:04.059660
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert callable(ansible_native_concat)



# Generated at 2022-06-25 12:25:14.169501
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([u'foo', u' ', u'bar']) == u'foo bar'
    assert ansible_native_concat([u'foo', u'\n', u'bar']) == u'foo\nbar'
    assert ansible_native_concat([u'foo', u' ', u'bar']) == u'foo bar'
    assert ansible_native_concat([u'foo', u'\n', u'bar']) == u'foo\nbar'
    assert ansible_native_concat([u'foo', u' ', u'bar']) == u'foo bar'

# Generated at 2022-06-25 12:25:18.289858
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '-)~BPm$e4'
    var_0 = ansible_native_concat(str_0)
    str_1 = ':-)~BPm$e4'
    var_1 = ansible_native_concat(str_1)
    str_2 = ':-)~BPm$e4$'
    var_2 = ansible_native_concat(str_2)
    str_3 = ':-)~BPm$e4$a'
    var_3 = ansible_native_concat(str_3)
    str_4 = ':-)~BPm$e4$a!'
    var_4 = ansible_native_concat(str_4)
    str_5 = ':-)~BPm$e4$a!a'

# Generated at 2022-06-25 12:25:27.161012
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '-)~BPm$e4'
    var_1 = ansible_native_concat(str_0)
    assert var_1 == '-)~BPm$e4'
    # TODO assert type
    str_1 = '_JNr3{&LK'
    var_2 = ansible_native_concat(str_1)
    assert var_2 == '_JNr3{&LK'
    # TODO assert type
    str_2 = '/<j/Q@|]f'
    var_3 = ansible_native_concat(str_2)
    assert var_3 == '/<j/Q@|]f'
    # TODO assert type
    str_3 = 'H2[j<~hmF'
    var_4 = ansible_native

# Generated at 2022-06-25 12:25:33.057724
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    s = u'abcdefghijklmnopqrstu\u611b'
    assert ansible_native_concat(s) == u'abcdefghijklmnopqrstu\u611b'

    s = u'{{foo}}'
    assert ansible_native_concat(s) == u'{{foo}}'

    s = u'{{foo}}bar'
    assert ansible_native_concat(s) == u'{{foo}}bar'

    s = u'x{{foo}}y{{bar}}z'
    assert ansible_native_concat(s) == u'x{{foo}}y{{bar}}z'

    s = u'abc123'
    assert ansible_native_concat(s) == u'abc123'

    s = u'#!/bin/bash'

# Generated at 2022-06-25 12:25:37.099722
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    #assert ansible_native_concat('abc') == u'abc'
    #assert ansible_native_concat(False) is False
    #assert ansible_native_concat(True) is True
    test_case_0()


# Generated at 2022-06-25 12:25:38.611131
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('-') == '-'



# Generated at 2022-06-25 12:25:47.314033
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    result = ansible_native_concat()
    assert result is None

    result = ansible_native_concat(['test_string'])
    assert result == 'test_string'

    str_0 = '-)~BPm$e4'
    result = ansible_native_concat(str_0)
    assert result == '-)~BPm$e4'

    with pytest.raises(ValueError):
        ansible_native_concat((('h', 'e', 'l'), ('l', 'o')))

    result = ansible_native_concat(['(', '1', '+', '2', ')'])
    assert result == 3

    result = ansible_native_concat(('(', '1', '+', '2', ')'))
    assert result == 3

    result = ans

# Generated at 2022-06-25 12:25:48.183209
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert isinstance(test_case_0(), string_types)

# Generated at 2022-06-25 12:25:49.270470
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == '-)~BPm$e4'

# Generated at 2022-06-25 12:26:06.875588
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test with a string
    str_0 = '-)~BPm$e4'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == '-)~BPm$e4'

    # Test with a byte string
    byte_str = b'foo'
    var_1 = ansible_native_concat(byte_str)
    assert var_1 == b'foo'

    # Test with multiple input nodes
    var_2 = ansible_native_concat(['foo', 'bar'])
    assert var_2 == 'foobar'

    # Test with non-strings
    var_3 = ansible_native_concat(['foo', 123, 'bar'])
    assert var_3 == 'foo123bar'

    # Test with mapping
    var_4 = ansible

# Generated at 2022-06-25 12:26:10.534329
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '-)~BPm$e4'

    # Call function
    var_0 = ansible_native_concat(str_0)
    assert container_to_text(var_0) == '-)~BPm$e4'

# Generated at 2022-06-25 12:26:11.711256
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    with pytest.raises(Exception):
        test_case_0()


# Generated at 2022-06-25 12:26:18.796944
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '0'
    str_1 = '1'
    assert ansible_native_concat([str_0]) == 0
    str_2 = '-'
    assert ansible_native_concat([str_1, str_2, str_0]) == -1
    str_3 = 'c'
    str_4 = 'h'
    str_5 = 'a'
    str_6 = 'n'
    str_7 = 'g'
    str_8 = 'e'
    str_9 = 'd'
    str_10 = ' '
    str_11 = 's'
    str_12 = 't'
    str_13 = 'r'
    str_14 = 'i'
    str_15 = 'n'
    str_16 = 'g'

# Generated at 2022-06-25 12:26:21.478484
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert type(test_case_0()) is str
    assert not isinstance(test_case_0(), NativeJinjaText)


# Generated at 2022-06-25 12:26:22.563327
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert isinstance(ansible_native_concat(str_0), text_type)

# Generated at 2022-06-25 12:26:25.521366
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '-)~BPm$e4'
    var_0 = str_0
    # assert var_0 == '-)~BPm$e4'


# Generated at 2022-06-25 12:26:27.711914
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    func = ansible_native_concat

    # Uncomment this to run one of the tests above
    # test_case_0()



# Generated at 2022-06-25 12:26:34.148090
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'A'
    str_1 = 'B'
    str_2 = 'C'
    result = [str_0, str_1, str_2]
    var_0 = ansible_native_concat(str_0)
    var_1 = ansible_native_concat(str_1)
    var_2 = ansible_native_concat(str_2)
    var_3 = ansible_native_concat((var_0,var_1,var_2))

# Generated at 2022-06-25 12:26:40.611996
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_0 = '!\''
    test_1 = '!\''
    result_0 = ansible_native_concat(test_0)
    try:
        assert result_0 == test_1
    except AssertionError:
        raise



# Generated at 2022-06-25 12:26:50.815219
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'dhi1e$mU6'
    var_0 = ansible_native_concat(str_0)


# Generated at 2022-06-25 12:26:52.437769
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '+FqIwv6PHGzW'
    var_0 = ansible_native_concat(str_0)
    assert var_0 is not None


# Generated at 2022-06-25 12:27:01.119798
# Unit test for function ansible_native_concat

# Generated at 2022-06-25 12:27:02.915092
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert _ansible_native_concat(str_0) ==  var_0

# Generated at 2022-06-25 12:27:10.975245
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('-)~BPm$e4') == '-)~BPm$e4'
    assert ansible_native_concat('Rpf') == 'Rpf'
    assert ansible_native_concat('Jw6/') == 'Jw6/'
    assert ansible_native_concat('N@| ') == 'N@| '
    assert ansible_native_concat('_jMg') == '_jMg'
    assert ansible_native_concat('l@yjJs') == 'l@yjJs'
    assert ansible_native_concat('d1CW') == 'd1CW'
    assert ansible_native_concat('1M!17') == '1M!17'

# Generated at 2022-06-25 12:27:20.243691
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    str_0 = '-$`F|&o>+'
    str_1 = 'JN8W+#p1v'
    str_2 = '+][PQ/~yu'
    str_3 = 'dT^a)&@Fa'
    str_4 = 's\\tL_pD!\\'
    str_5 = '15Z>0_Zj$'

    var_0 = ansible_native_concat((str_0, str_1, str_2))
    assert var_0 == '-$`F|&o>+JN8W+#p1v+][PQ/~yu'

    var_1 = ansible_native_concat((str_3, str_4))

# Generated at 2022-06-25 12:27:21.332693
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(str_0) == var_0

# Generated at 2022-06-25 12:27:30.514441
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '-)~BPm$e4'
    var_0 = ansible_native_concat(str_0)
    assert isinstance(var_0, str)

    str_0 = '-)~BPm$e4'
    var_0 = ansible_native_concat(str_0)
    assert isinstance(var_0, str)

    str_0 = '-)~BPm$e4'
    var_0 = ansible_native_concat(str_0)
    assert isinstance(var_0, str)

    str_0 = '-)~BPm$e4'
    var_0 = ansible_native_concat(str_0)
    assert isinstance(var_0, str)

    str_0 = '-)~BPm$e4'
    var_0

# Generated at 2022-06-25 12:27:32.334657
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_string = 'The quick brown fox jumped over the lazy dogs.'
    value = ansible_native_concat(test_string)
    assert value == test_string

# Generated at 2022-06-25 12:27:42.884229
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert isinstance(test_ansible_native_concat.__annotations__, dict)
    str_0 = 'FV7za~y5'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'FV7za~y5'
    str_0 = 'YJ:vf+j'
    var_1 = ansible_native_concat(str_0)
    assert var_1 == 'YJ:vf+j'
    str_0 = 'a>LDMw'
    var_2 = ansible_native_concat(str_0)
    assert var_2 == 'a>LDMw'
    str_0 = '}W8fJ'
    var_3 = ansible_native_concat(str_0)

# Generated at 2022-06-25 12:27:52.174596
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == '-)~BPm$e4'

# Generated at 2022-06-25 12:28:00.737660
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ast.literal_eval(ansible_native_concat("'ok'")) == 'ok'
    assert ast.literal_eval(ansible_native_concat("'ok' 'ok'")) == 'ok ok'
    assert ast.literal_eval(ansible_native_concat("'ok' 'ok' 'ok'")) == 'ok ok ok'
    assert ast.literal_eval(ansible_native_concat("'ok' 'ok' 'ok' 'ok'")) == 'ok ok ok ok'
    assert ast.literal_eval(ansible_native_concat("'ok' 'ok' 'ok' 'ok' 'ok'")) == 'ok ok ok ok ok'

# Generated at 2022-06-25 12:28:09.929063
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = '-)~BPm$e4'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == '-)~BPm$e4'
    str_0 = '*q3pb)9XC'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == '*q3pb)9XC'
    str_0 = '-:-:-:-:-'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == '-:-:-:-:-'
    str_0 = 'lF|&{9T0v'
    var_0 = ansible_native_concat(str_0)
    assert var_0 == 'lF|&{9T0v'
   

# Generated at 2022-06-25 12:28:11.039664
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert(test_case_0() == '-)~BPm$e4')

# Generated at 2022-06-25 12:28:20.349776
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = 'ABC'
    str_1 = 'DEF'
    str_2 = 'GHI'
    var_0 = ansible_native_concat(str_0)
    var_1 = ansible_native_concat(str_0)
    var_2 = ansible_native_concat(str_0)
    var_3 = ansible_native_concat(str_0)
    var_4 = ansible_native_concat(str_0)
    var_5 = ansible_native_concat(str_0)
    var_6 = ansible_native_concat(str_0)
    var_7 = ansible_native_concat(str_0)
    var_8 = ansible_native_concat(str_0)
    var_9 = ansible_native

# Generated at 2022-06-25 12:28:25.736261
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == u'foobar'
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat(['[1, 2, 3]', '', None]) == u'[1, 2, 3]'
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['string']) == u'string'
    assert ansible_native_concat(['["foo", "bar"]']) == ['foo', 'bar']
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([None, None]) is None

# Generated at 2022-06-25 12:28:34.806650
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert _fail_on_undefined('str') == 'str'
    assert _fail_on_undefined([1, 2, 3]) == [1, 2, 3]
    assert _fail_on_undefined(['a', None, 'b']) == ['a', None, 'b']

    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat([1.0, 2.0, 3.0]) == [1.0, 2.0, 3.0]
    assert ansible_native_concat(['a', 'b']) == 'ab'

# Generated at 2022-06-25 12:28:36.681649
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('-0') == -0
    assert ansible_native_concat('-(-0)') == 0

# Generated at 2022-06-25 12:28:43.294778
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
  # Check without argument
  out = ansible_native_concat()
  assert out == None

  # Check with valid single string argument
  str_0 = '-)~BPm$e4'
  var_0 = ansible_native_concat(str_0)
  assert isinstance(var_0, str)
  assert var_0 == '-)~BPm$e4'

  # Check with valid multiple string arguments
  str_0 = '-)~BPm$e4'
  str_1 = 'K*Bm@wZ#l'
  var_0 = ansible_native_concat(str_0, str_1)
  assert isinstance(var_0, str)
  assert var_0 == '-)~BPm$e4K*Bm@wZ#l'

  # Check with valid

# Generated at 2022-06-25 12:28:54.344641
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    str_0 = to_text(')Aa]F80')
    var_0 = ansible_native_concat(str_0)
    assert var_0 == str_0

    str_0 = to_text('B5Hkmw5')
    str_1 = to_text('dj_KM&X[')
    var_0 = ansible_native_concat(str_0, str_1)
    assert var_0 == to_text(str_0) + to_text(str_1)

    str_0 = to_text('yvmRi,Xm')
    str_1 = to_text('&/]U7x')
    str_2 = to_text('H9Q^Nz')
    str_3 = to_text('H!V7$u')
    str_4