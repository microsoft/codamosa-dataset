

# Generated at 2022-06-25 12:19:15.821519
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test with a range of values for list
    # Test with a range of values for list
    list_0 = [a for a in range(0, 10)]
    var_0 = ansible_native_concat(list_0)
    assert var_0
    # Test with a range of values for list
    list_1 = [a for a in range(0, 10)]
    var_1 = ansible_native_concat(list_1)
    assert var_1



# Generated at 2022-06-25 12:19:19.130053
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert False, "Failed to find expected value for test_ansible_native_concat"


# Generated at 2022-06-25 12:19:30.258181
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    list_0 = ["hello"]
    out_0 = ansible_native_concat(list_0)
    assert out_0 == "hello"

    list_1 = ["hello", "world"]
    out_1 = ansible_native_concat(list_1)
    assert out_1 == "helloworld"

    list_2 = ["hello", " ", "world"]
    out_2 = ansible_native_concat(list_2)
    assert out_2 == "hello world"

    list_3 = ['bacon', " ", "and", " ", 'eggs']
    out_3 = ansible_native_concat(list_3)
    assert out_3 == 'bacon and eggs'

    list_4 = ["one", " ", 'two', " ", 'three']
    out_4 = ans

# Generated at 2022-06-25 12:19:35.723215
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert callable(ansible_native_concat)


# Build a list of tuples containing test case data
test_cases = [
    # [input, expected_output]
    #
    ([], None),
    (['a'], 'a'),
    (['a', 'b'], u'ab'),
]



# Generated at 2022-06-25 12:19:38.949769
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    for func_arg in yaml_data()['ansible_native_concat']:
        try:
            var_0 = ansible_native_concat(func_arg)
        except Exception as err:
            print("Error: {0}".format(err))



# Generated at 2022-06-25 12:19:45.050346
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert "some string" == ansible_native_concat(["some string"])

    assert ["some list"] == ansible_native_concat([["some list"]])

    assert ["some list", "some string"] == ansible_native_concat([["some list"], "some string"])

    assert ["some list", ["some string", "another one"]] == ansible_native_concat([["some list"], ["some string", "another one"]])

# Generated at 2022-06-25 12:19:55.777088
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Setup test data
    list_0 = []
    var_1 = 'foo'
    list_1 = []
    list_1.append(var_1)
    var_2 = 'bar'
    list_1.append(var_2)
    var_3 = 'baz'
    list_1.append(var_3)
    num_1 = 1
    list_2 = []
    list_2.append(num_1)
    num_2 = 2
    list_2.append(num_2)
    num_3 = 3
    list_2.append(num_3)
    str_1 = 'qux'
    list_2.append(str_1)
    list_2 = "".join(list_2)
    list_3 = []

# Generated at 2022-06-25 12:19:57.858605
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    list_0 = ['VARIABLE IS NOT DEFINED!']
    var_0 = ansible_native_concat(list_0)


# Generated at 2022-06-25 12:20:02.862382
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['A', 'B']) == 'AB'
    assert ansible_native_concat(['A', 'B', 'C']) == 'ABC'
    assert ansible_native_concat(['A', 1, 'C']) == 'A1C'
    assert ansible_native_concat(['A', ['B', 'C'], 'D']) == 'ABCD'
    assert ansible_native_concat([['A', 'B'], ['C', 'D'], 'E']) == 'ABCDE'

# Generated at 2022-06-25 12:20:03.937544
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    result = ansible_native_concat([])
    assert result == None



# Generated at 2022-06-25 12:20:17.026335
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    string_0 = "foo"

# Generated at 2022-06-25 12:20:26.629744
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    stdin_0_0 = b'\x9fmt\x04'
    stdin_0_1 = b'\x9fmt\x04'
    stdin_0_2 = b'\x9fmt\x04'
    stdin_0_3 = b'\x9fmt\x04'
    stdin_0 = [stdin_0_0, stdin_0_1, stdin_0_2, stdin_0_3]
    var_0 = ansible_native_concat(stdin_0)
    assert var_0 == '\x9fmt\x04\x9fmt\x04\x9fmt\x04\x9fmt\x04'
    stdin_1_0 = 'hi'

# Generated at 2022-06-25 12:20:38.239483
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    text_0 = '\\'
    bytes_0 = b'\x9fmt\x04'
    var_0 = ansible_native_concat(text_0)
    var_1 = ansible_native_concat(bytes_0)
    bytes_1 = b'SPHL\x00\x00\x00\x00\x00\x01\x00<\x00\x00\x00]\x01|\x01\x00\x00\x00\x01\x00\x00\x00'
    var_2 = ansible_native_concat(bytes_1)
    text_1 = '\U000fcfb4'
    var_3 = ansible_native_concat(text_1)

# Generated at 2022-06-25 12:20:44.953663
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(('"', '"')) == ''
    assert ansible_native_concat(('\\"', '\\"')) == '"'
    assert ansible_native_concat((None, 'hello')) == 'hello'
    assert ansible_native_concat(('hello', None)) == 'hello'
    assert ansible_native_concat((None, 'hello', None)) == 'hello'
    assert ansible_native_concat(('foo', 'bar')) == 'foobar'
    assert ansible_native_concat((None, 'a', 'b', 'c', None)) == 'abc'
    assert ansible_native_concat((None, 'a', None, 'b', None)) == 'ab'

# Generated at 2022-06-25 12:20:50.412141
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Tests for results of the user's correct inputs
    assert ansible_native_concat(b'\x9fmt\x04') == b'\x9fmt\x04'
    assert ansible_native_concat(b'\x9fmt\x04') == b'\x9fmt\x04'
    assert ansible_native_concat(b'\x9fmt\x04') == b'\x9fmt\x04'

    # Tests for results of the user's invalid inputs



# Generated at 2022-06-25 12:21:00.652977
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_1 = ansible_native_concat([b'\x9fmt\x04'])
    assert var_1 == None

    var_2 = ansible_native_concat(['Hello', ' ', 'world'])
    assert var_2 == 'Hello world'

    var_3 = ansible_native_concat('This is a test')
    assert var_3 == 'This is a test'

    var_4 = ansible_native_concat(['Hello', ' ', 'world', '!'])
    assert var_4 == 'Hello world!'

    var_5 = ansible_native_concat(['Hello', ' ', 'world', '!', '!'])
    assert var_5 == 'Hello world!!'

    var_6 = ansible_native_concat([1, 2, 3, 4, 5])

# Generated at 2022-06-25 12:21:09.375120
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['text']) == 'text'
    assert ansible_native_concat(['1', '2', '3']) == '123'
    assert ansible_native_concat(['1', '2', '3']) == '123'
    assert isinstance(ansible_native_concat(['1', '2', '3']), str)
    assert ansible_native_concat(['1', '2', '3']) != 123
    assert ansible_native_concat(['1', '2', '3']) != True
    assert ansible_native_concat(['text', 'text', 'text']) == 'texttexttext'

# Generated at 2022-06-25 12:21:13.324465
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Tests.
    bytes_0 = b'test_value'
    var_0 = ansible_native_concat(bytes_0)

    # Assert.
    assert var_0 == 'test_value'

# Generated at 2022-06-25 12:21:14.159572
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() == None

# Generated at 2022-06-25 12:21:21.127588
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_1 = {'a': b'\x9fmt\x04', 'b': b'\x9fmt\x04', 'c': {'d': b'\x9fmt\x04', 'e': b'\x9fmt\x04', 'f': {'g': b'\x9fmt\x04', 'h': b'\x9fmt\x04'}}, 'i': {'j': b'\x9fmt\x04', 'k': b'\x9fmt\x04', 'l': {'m': b'\x9fmt\x04', 'n': b'\x9fmt\x04', 'o': {'p': b'\x9fmt\x04', 'q': b'\x9fmt\x04'}}}}


# Generated at 2022-06-25 12:21:23.792120
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert True

# Generated at 2022-06-25 12:21:33.847232
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    bytes_0 = b'3U\x10\xf4\x1a'
    var_0 = ansible_native_concat(bytes_0)
    bytes_1 = b'\x00\r\n\r\n'
    var_1 = ansible_native_concat(bytes_1)
    assert isinstance(var_1, str)

    assert isinstance(var_0, str)


# Generated at 2022-06-25 12:21:35.219370
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert type(test_case_0()) != bytes
    assert test_case_0() == '\x9fmt\x04'


# Generated at 2022-06-25 12:21:42.944449
# Unit test for function ansible_native_concat

# Generated at 2022-06-25 12:21:52.214104
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert ansible_native_concat('') == None

    # Example with an undefined value
    # https://github.com/ansible/ansible/issues/52158
    assert ansible_native_concat(StrictUndefined()) == StrictUndefined

    # Example with a native type
    assert ansible_native_concat('string') == 'string'
    assert ansible_native_concat(True) is True
    assert ansible_native_concat(0) == 0
    assert ansible_native_concat(1) == 1

    # Example with a generator
    # https://github.com/pallets/jinja/blob/master/src/jinja2/nativetypes.py
    assert ansible_native_concat(x for x in ('a', 'b', 'c')) == 'abc'



# Generated at 2022-06-25 12:21:54.976174
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test case for function:
    # ansible_native_concat
    #
    # Write a test case here.
    assert True
    #  TODO: implement your test case here.



# Generated at 2022-06-25 12:21:58.078924
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    bytes_0 = b'\x9fmt\x04'
    assert ansible_native_concat(bytes_0) == '\u009fmt\x04'

# Generated at 2022-06-25 12:22:08.156150
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert type(ansible_native_concat(b'\x9fmt\x04')) == text_type
    assert type(ansible_native_concat(b'\x04\x00\x00\x00s\x00\x00\x00t\x00\x00\x00r\x00\x00\x00i\x00\x00\x00n\x00\x00\x00g\x00\x00\x00\x00\x00\x00\x00\x9fmt\x04')) == text_type

# Generated at 2022-06-25 12:22:08.841750
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert len(test_case_0()) == 4



# Generated at 2022-06-25 12:22:15.879348
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test function ansible_native_concat"""

    byte_0 = b'\x9fmt\x04'
    byte_1 = b'\x9fmt\x05'
    byte_2 = b'\x9fmt\x06'
    bytes_0 = (byte_0, byte_1, byte_2)

    var_0 = ansible_native_concat(bytes_0)
    var_1 = ansible_native_concat(byte_0)

    # Check function output
    assert var_0 == b'\x9fmt\x04\x9fmt\x05\x9fmt\x06'
    assert var_1 == b'\x9fmt\x04'

# Generated at 2022-06-25 12:22:28.559959
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    bytes_0 = b'\x9fmt\x04'
    var_0 = ansible_native_concat(bytes_0)
    assert var_0 == b'\x9fmt\x04'
    bytes_1 = b'\x9fmt\x05'
    var_1 = ansible_native_concat(bytes_1)
    assert var_1 == b'\x9fmt\x05'
    bytes_2 = b'\x9fmt\x07'
    var_2 = ansible_native_concat(bytes_2)
    assert var_2 == b'\x9fmt\x07'
    bytes_3 = b'\x9fmt\x08'
    var_3 = ansible_native_concat(bytes_3)
    assert var_3

# Generated at 2022-06-25 12:22:42.172261
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    bytes_0 = b'\x9fmt\x04'
    var_0 = ansible_native_concat(bytes_0)
    bytes_1 = b'\x00\x00\x00\x00\x00'
    var_1 = ansible_native_concat(bytes_1)
    bytes_2 = b'\x00\x00\x00\x00\x00'
    var_2 = ansible_native_concat(bytes_2)
    bytes_3 = b'\x00\x00\x00\x00\x00'
    var_3 = ansible_native_concat(bytes_3)
    bytes_4 = b'\x00\x00\x00\x00\x00'

# Generated at 2022-06-25 12:22:48.948810
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_2 = u'\u2713'
    var_3 = ansible_native_concat(var_2)
    bytes_1 = b'\x9fmt\x04'
    var_4 = ansible_native_concat(bytes_1)
    assert var_3 == u'\u2713'
    assert var_4.__class__.__name__ == 'unicode'

# Generated at 2022-06-25 12:22:57.761944
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert isinstance(ansible_native_concat(b'\x9fmt\x04'), text_type)
    assert ansible_native_concat(b'\x9fmt\x04') == container_to_text(b'True')
    assert isinstance(ansible_native_concat(b'\x9f\x00\x00\x00\x04\xed\x13\xd2\xb2\xe2'), text_type)
    assert ansible_native_concat(b'\x9f\x00\x00\x00\x04\xed\x13\xd2\xb2\xe2') == container_to_text(b'-3.4028234663852886e+38')

# Generated at 2022-06-25 12:23:08.704531
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(b'\x9fmt\x04') == '\x9fmt\x04'
    assert ansible_native_concat(b'{yI\x02\x00\x00\x00\x08\x00\x00') == '{yI\x02\x00\x00\x00\x08\x00\x00'
    assert ansible_native_concat(b'\x08\x00\x00\x00\x06\x00\x00\x00') == '\x08\x00\x00\x00\x06\x00\x00\x00'

# Generated at 2022-06-25 12:23:20.637315
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert(ansible_native_concat(b'foobar') == 'foobar')
    assert(ansible_native_concat([b'foo', b'bar']) == 'foobar')
    assert(ansible_native_concat([['foo'], 'bar']) == [['foo'], 'bar'])
    assert(ansible_native_concat([[1, 2], 'bar']) == [[1, 2], 'bar'])
    assert(ansible_native_concat([['3', 3], 'bar']) == ['3', 3, 'bar'])
    assert(ansible_native_concat([[b'3', 3], 'bar']) == '3', 3, 'bar')

# Generated at 2022-06-25 12:23:21.902050
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert 1 == 1, "Unimplemented"


# Generated at 2022-06-25 12:23:30.393369
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # byte strings
    bytes_0 = b'\x9fmt\x04'  # b'\x9fmt\x04'
    var_0 = ansible_native_concat(bytes_0)
    assert type(var_0) == str

    # strings with prefixes
    bytes_0 = b'u\x9fmt\x04'  # b'u\x9fmt\x04'
    var_1 = ansible_native_concat(bytes_0)
    assert type(var_1) == str
    bytes_0 = b'U\x9fmt\x04'  # b'U\x9fmt\x04'
    var_2 = ansible_native_concat(bytes_0)
    assert type(var_2) == str
    bytes_0 = b

# Generated at 2022-06-25 12:23:41.172079
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['1', 2, 3]) == '123'
    assert ansible_native_concat([1, 2, 3]) == 1
    assert ansible_native_concat([1.0, 2.0, 3.0]) == 1.0
    assert ansible_native_concat([True, False, True]) == True
    assert ansible_native_concat(['1']) == '1'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1.0]) == 1.0
    assert ansible_native_concat([True]) == True
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(['abc', 'abc', 0]) == 'abcabc0'
    assert ansible_

# Generated at 2022-06-25 12:23:45.364679
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    bytes_0 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    var_0 = ansible_native_concat(bytes_0)
    assert container_to_text(var_0) == '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'


# Generated at 2022-06-25 12:23:57.408819
# Unit test for function ansible_native_concat

# Generated at 2022-06-25 12:24:03.182391
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    calls = {
        (b'\x9fmt\x04', ): b'\x9fmt\x04',
    }

    def check(data):
        r = ansible_native_concat(data)
        return r == calls[data]

    assert all(map(check, calls))

# Generated at 2022-06-25 12:24:11.844996
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    _test_ansible_native_concat = ansible_native_concat

    test_cases = [
        # test_case_0
        {
            'inv': {
                'nodes': [b'\x9fmt\x04'],
            },
            'assert': {
                'var_0': {
                    'type': 'str',
                    'value': '_mt',
                },
            },
        },

    ]
    for test_case in test_cases:
        args_0 = test_case['inv']['nodes']
        assert test_case['assert']['var_0']['type'] == type(_test_ansible_native_concat(args_0)).__name__

# Generated at 2022-06-25 12:24:16.216565
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    str_0 = ">="
    list_0 = [str_0, str_0, str_0]
    str_1 = container_to_text(ansible_native_concat(list_0))

    assert str_1 == '>= >= >='
    assert isinstance(ansible_native_concat(list_0), text_type)

# Generated at 2022-06-25 12:24:17.071135
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var1 = test_case_0()

# Generated at 2022-06-25 12:24:26.349687
# Unit test for function ansible_native_concat

# Generated at 2022-06-25 12:24:28.594599
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # ():
    #     bytes_0 = b'\x9fmt\x04'
    #     var_0 = ansible_native_concat(bytes_0)
    assert False # FIXME

# Generated at 2022-06-25 12:24:29.266856
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0() is not None

# Generated at 2022-06-25 12:24:38.501647
# Unit test for function ansible_native_concat

# Generated at 2022-06-25 12:24:45.403353
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """
    Test function
    :func:`~ansible.module_utils.common.text.converters.ansible_native_concat`
    without assertions. This is used in a performance test example with lots of
    different parameters.
    """
    ansible_native_concat(u'')
    ansible_native_concat(u'foo')
    ansible_native_concat(u'foo', u'bar')
    ansible_native_concat(u'foo', u'bar', u'bar')
    ansible_native_concat(u'foo', u'bar', u'bar', u'foo')
    ansible_native_concat(u'foo', u'bar', u'bar', u'foo', u'foo')

# Generated at 2022-06-25 12:24:51.200009
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert True


# Generated at 2022-06-25 12:24:52.167083
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert(test_case_0())

# Generated at 2022-06-25 12:24:53.696614
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    try:
        test_case_0()
    except Exception as exception:
        assert False



# Generated at 2022-06-25 12:24:56.488196
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert (container_to_text(ansible_native_concat(b'\x9fmt\x04')) == "b'\\x9fmt\\x04'")

# Generated at 2022-06-25 12:25:05.531752
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert '\x9fmt\x04' == ansible_native_concat(b'\x9fmt\x04')
    assert '\x9fmt\x04' == ansible_native_concat(b'\x9fmt\x04')
    assert '\x9fmt\x04' == ansible_native_concat('\x9fmt\x04')
    assert '\x9fmt\x04' == ansible_native_concat('\x9fmt\x04')
    assert '\x9fmt\x04' == ansible_native_concat(['\x9fmt\x04'])
    assert '\x9fmt\x04' == ansible_native_concat(['\x9fmt\x04'])

# Generated at 2022-06-25 12:25:12.897194
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # BEGIN

    assert ansible_native_concat([u'p', u'y']) == u'py'
    assert ansible_native_concat([u'p', u'y', u't', u'h', u'o', u'n']) == u'python'
    assert ansible_native_concat([u'p', u'y', u't', u'h', u'o', u'n\n']) == u'python\n'
    assert ansible_native_concat([u'p', u'y', u't', u'h', u'o', u'n\n', u'\n', u'R', u'o', u'c', u'k', u's']) == u'python\n\nRocks'

# Generated at 2022-06-25 12:25:13.924636
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert str(test_case_0()) == 'émt'

# Generated at 2022-06-25 12:25:14.967440
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    for func in (test_case_0, ):
        func()

# Generated at 2022-06-25 12:25:18.248466
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = ['\u009fmt\u0004']
    var_0 = ansible_native_concat(nodes)
    ansible_native_concat(nodes)
    assert var_0 == [15, 109, 116, 4]



# Generated at 2022-06-25 12:25:27.159451
# Unit test for function ansible_native_concat

# Generated at 2022-06-25 12:25:34.982731
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert test_case_0()



# Generated at 2022-06-25 12:25:41.278746
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_data = [
        (b'\x9fmt\x04', False),
        (b'\x9fmt\x04', False),
    ]

    for index, test_case in enumerate(test_data):
        actual = ansible_native_concat(*test_case[0])
        assert actual == test_case[1], 'Test case {}: actual = {}'.format(index + 1, actual)


# Generated at 2022-06-25 12:25:49.418737
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    bytes_0 = b'\x9fmt\x04'
    var_0 = ansible_native_concat(bytes_0)
    assert isinstance(var_0, bytes)
    assert var_0 == b'\x9fmt\x04'

    bytes_0 = b'\xdd\xed\xad\x9a\x68;\x8d\xbf\xe6\xdd\xed\xad\x9a\x68;\x8d\xbf\xe6'
    var_1 = ansible_native_concat(bytes_0)
    assert isinstance(var_1, bytes)

# Generated at 2022-06-25 12:25:52.899846
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # type: () -> None
    # Verify that the function is a generator
    assert isinstance(ansible_native_concat(b'\x9fmt\x04'), types.GeneratorType)

    # Verify that the list of compiled nodes was consumed
    assert b'\x9fmt\x04' == ansible_native_concat(b'\x9fmt\x04').send(None)

# Generated at 2022-06-25 12:25:56.688226
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # This can be modified to test different variants of the data
    data = b''

    res = ansible_native_concat(data)

    assert container_to_text(res) == 'foo', \
        "Did not get the expected result from ansible_native_concat!"

# Generated at 2022-06-25 12:26:06.794287
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    stub = SimpleNamespace(msg = 'bar')
    # No initial value
    assert ansible_native_concat(['foo', stub, 'bar']) == 'foobar'
    # Initial value
    assert ansible_native_concat(['foo', stub, 'bar'], 15) == 'foobar15'
    # Noise on string is ignored
    str_t = '{"foo": "bar"}'
    assert ansible_native_concat([str_t, str_t]) == str_t
    assert ansible_native_concat([str_t, str_t]) == str_t
    # Noise on numeric is ignored
    numeric_t = 1234
    assert ansible_native_concat([numeric_t, numeric_t]) == numeric_t

# Generated at 2022-06-25 12:26:09.096172
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert to_text(test_case_0()) == to_text("\x9fmt\x04")

# Generated at 2022-06-25 12:26:15.120678
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ast.literal_eval(ast.parse('mt')) == ansible_native_concat(b'\x9fmt\x04')
    assert ast.literal_eval(ast.parse('mt')) == ansible_native_concat(b'\x9fmt\x04\x00\x00')
    assert ast.literal_eval(ast.parse('1')) == ansible_native_concat(b'\x9f1\x04')
    assert ast.literal_eval(ast.parse('1.0')) == ansible_native_concat(b'\x9f1.0\x04')
    assert ast.literal_eval(ast.parse('1e2')) == ansible_native_concat(b'\x9f1e2\x04')


# Generated at 2022-06-25 12:26:15.873364
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert 1 == 1


# Generated at 2022-06-25 12:26:18.306490
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    bytes_0 = b'\x9fmt\x04'
    var_0 = ansible_native_concat(bytes_0)
    assert var_0 is not None
    assert var_0 == b'\x9fmt\x04'


# Generated at 2022-06-25 12:26:30.081017
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    bytes_0 = b'\x9fmt\x04'
    assert var_0 == str()

if __name__ == '__main__':
    test_ansible_native_concat()

# Generated at 2022-06-25 12:26:32.326030
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    bytes_0 = b'\x9fmt\x04'

    assert ansible_native_concat(bytes_0) == b'\x9fmt\x04'

# Generated at 2022-06-25 12:26:33.103677
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert test_case_0()

# Generated at 2022-06-25 12:26:39.329561
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    var_0 = u'\u00ff'
    var_1 = u'\u00fe'
    var_2 = ansible_native_concat([var_0, var_1])

    assert var_2 == '\xff\xfe'
    assert isinstance(var_2, text_type)

    var_0 = u'\u00ff'
    list_0 = [var_0, u'\u00ff']
    var_1 = ansible_native_concat(list_0)

    assert var_1 == u'\u00ff\u00ff'
    assert isinstance(var_1, text_type)

    string_0 = 'foobar'
    string_1 = "foo\rbar"
    list_0 = [string_0, string_1]

# Generated at 2022-06-25 12:26:49.845946
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert callable(ansible_native_concat)
    # Make sure the following call does not raise any exception
    # assert isinstance(ansible_native_concat(nodes), _fail_on_undefined)
    # assert ansible_native_concat(None) == None
    assert ansible_native_concat([]) == None
    assert isinstance(ansible_native_concat([1]), _fail_on_undefined)
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1.0, 2.0]) == 1.0
    assert ansible_native_concat([1, 2]) == 1
    assert ansible_native_concat(['1', '2']) == '1'

# Generated at 2022-06-25 12:26:58.706139
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(None) == None
    assert ansible_native_concat('') == ''
    assert ansible_native_concat('a') == 'a'
    assert ansible_native_concat('a', 'b') == 'ab'
    assert ansible_native_concat(None, 'b') == 'b'
    assert ansible_native_concat(None, 'b', 'c') == 'bc'
    assert ansible_native_concat('a', None, 'c') == 'ac'
    assert ansible_native_concat('a', 'b', None) == 'ab'
    assert ansible_native_concat(None, None, None) == None
    assert ansible_native_concat(None, None) == None


# Generated at 2022-06-25 12:27:08.186738
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Testing different types using assert_equal
    string_0 = 'Zli'
    string_1 = ansible_native_concat(string_0)
    assert_equal(string_1, 'Zli')
    string_2 = '_$\x87\xbb\x99>\x92'
    string_3 = ansible_native_concat(string_2)
    assert_equal(string_3, '_$\x87\xbb\x99>\x92')
    string_4 = '\xcd\x0bw\x89\xa4\x1c\xa2\x9d\xef\x1e\x99\xa7\xe3'
    string_5 = ansible_native_concat(string_4)

# Generated at 2022-06-25 12:27:12.374169
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    bytes_0 = b'\x9fmt\x04'
    var_0 = ansible_native_concat(bytes_0)


if __name__ == "__main__":
    b'\x9fmt\x04'
    test_ansible_native_concat()

# Generated at 2022-06-25 12:27:15.271582
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test parameters
    nodes = b'\x9fmt\x04'

    # Execution of the function
    result = ansible_native_concat(nodes)

    # Verification of the result
    assert result == 'hello'



# Generated at 2022-06-25 12:27:16.367146
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert isinstance(test_case_0(), text_type)

# Generated at 2022-06-25 12:27:33.007360
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    f = open('/tmp/ansible_native_concat.txt', 'r')
    assert f != ''
    assert not f.closed

    # TODO: test using mock

    # TODO: test using crypted data

# Generated at 2022-06-25 12:27:43.622962
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert isinstance(test_case_0(), str)
    assert isinstance(ansible_native_concat(b'\x9fmt\x04'), str)
    assert ansible_native_concat(b'\x9fmt\x04') == "@\xff\x04"
    assert isinstance(ansible_native_concat(b'\x9fmt\x04'), str)
    assert ansible_native_concat(b'\x9fmt\x04') == "@\xff\x04"
    assert isinstance(ansible_native_concat(b"\x9fmt\x04"), str)
    assert ansible_native_concat(b"\x9fmt\x04") == "@\xff\x04"

# Generated at 2022-06-25 12:27:45.104381
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(u'\udcc3')==u'\udcc3'

# Generated at 2022-06-25 12:27:46.183786
# Unit test for function ansible_native_concat

# Generated at 2022-06-25 12:27:46.984306
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()

# Generated at 2022-06-25 12:27:55.766589
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    bytes_0 = b'\x9fmt\x04'
    assert ansible_native_concat(bytes_0) == b'\x9fmt\x04'
    bytes_0 = b'\xf7\xdb\xbc\x93\x83\x8a\x1c\xaf\xcd\xbf\xa7\x1f\x97'
    assert ansible_native_concat(bytes_0) == b'\xf7\xdb\xbc\x93\x83\x8a\x1c\xaf\xcd\xbf\xa7\x1f\x97'
    bytes_0 = None
    assert ansible_native_concat(bytes_0) is None

# Generated at 2022-06-25 12:28:01.299500
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # the executable code for this test is generated at the end of this function
    # and extracted using a regex.
    #
    # This is necessary because the test cases are generated at run time,
    # depending on the Python version being used to run the test.
    # This prevents an issue where some test cases are different between
    # Python 2 and 3, but jenkins would only test with one or the other.
    # This makes it possible to test with both versions of Python.
    #
    # The test cases are generated by the test_gen function.

    # Case 0
    bytes_0 = b'\x9fmt\x04'

    var_0 = ansible_native_concat(bytes_0)
    assert isinstance(var_0, text_type)
    assert var_0 == '\x9fmt\x04'



# Generated at 2022-06-25 12:28:10.488921
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import collections

    bytes_0 = b"\x01\xff"
    byte_0 = b'test'

# Generated at 2022-06-25 12:28:15.769907
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    try:
        import __pypy__
        has_pypy = True
    except ImportError:
        has_pypy = False

    cmd = {u'command': u'mt -f /dev/sdc weof 1'}
    assert container_to_text(cmd) == u'command=mt -f /dev/sdc weof 1'

    if not has_pypy:
        test_case_0()

# Generated at 2022-06-25 12:28:18.073565
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # FIXME: only run these if AnsibleVaultEncryptedUnicode is present
    # FIXME: none of these should fail
    test_case_0()

# Generated at 2022-06-25 12:28:33.079039
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert type(ansible_native_concat('abc')) == text_type

# Generated at 2022-06-25 12:28:40.852416
# Unit test for function ansible_native_concat

# Generated at 2022-06-25 12:28:46.301134
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_numbers = [test_case_0]
    failed_numbers = []
    number_count = 0
    for test_number in test_numbers:
        try:
            print('Running unit test %s' % number_count)
            test_number()
        except Exception as e:
            failed_numbers.append(str(number_count))
            print('Unit test %s failed with error: %s' % (number_count, str(e)))
        finally:
            number_count += 1
    if failed_numbers:
        raise AssertionError('Unit test(s) %s failed' % ', '.join(failed_numbers))

# Boilerplate for running ansible_native_concat

# Generated at 2022-06-25 12:28:55.483929
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    #
    # We want to raise UndefinedError.
    #
    # TODO fix this test.
    #
    # bytes_0 = b'\x9fmt\x04'
    # var_0 = ansible_native_concat(bytes_0)
    # assert isinstance(var_0, int)

    #
    # We want to raise UndefinedError.
    #
    # TODO fix this test.
    #
    # bytes_1 = b'\x9fmt\x04'
    # var_1 = ansible_native_concat(bytes_1)
    # assert isinstance(var_1, int)

    bytes_2 = u"\u7460\u746d\u7470"
    var_2 = ansible_native_concat(bytes_2)
   

# Generated at 2022-06-25 12:28:59.334452
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = [1, 2, 3]
    actual = ansible_native_concat(nodes)
    assert actual == u'123'

    nodes = [1, 2, 3, ast.literal_eval(u'0b111010')]
    actual = ansible_native_concat(nodes)
    assert actual == ast.literal_eval(u'0b111010110')

    nodes = [1, 2, 3, ast.literal_eval(u'0xFF')]
    actual = ansible_native_concat(nodes)
    assert actual == ast.literal_eval(u'0xff123')



# Generated at 2022-06-25 12:29:01.011672
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_case_0()

# Generated at 2022-06-25 12:29:06.037986
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Assert with valid args
    bytes_0 = b'\x9fmt\x04'
    var_0 = ansible_native_concat(bytes_0)

    # Assert with invalid args
    runner = CliRunner()
    result = runner.invoke(ansible_native_concat, [])
    assert result.exit_code == 2
    #TODO: write test

# Generated at 2022-06-25 12:29:08.075077
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    arg0_0 = b'\x9fmt\x04'

    # Call function
    # Output:
    var_0 = '\u009fmt\x04'