

# Generated at 2022-06-21 21:13:24.984615
# Unit test for function random_string
def test_random_string():
    assert len(random_string(9)) == 9

# Generated at 2022-06-21 21:13:27.336603
# Unit test for function uuid
def test_uuid():
    assert(len(uuid()) == 36)
    assert(len(uuid(as_hex=True)) == 32)


# Generated at 2022-06-21 21:13:32.050535
# Unit test for function uuid
def test_uuid():
    uid_hex = uuid(as_hex=True)
    assert isinstance(uid_hex, str), 'Invalid uid_hex type: {}'.format(type(uid_hex))
    assert len(uid_hex) == 32, 'Invalid uid_hex length: {}'.format(len(uid_hex))

    uid_standard = uuid()
    assert isinstance(uid_standard, str), 'Invalid uid_standard type: {}'.format(type(uid_standard))
    assert len(uid_standard) == 36, 'Invalid uid_standard length: {}'.format(len(uid_standard))


# Generated at 2022-06-21 21:13:37.084975
# Unit test for function secure_random_hex
def test_secure_random_hex():
    """
    Check if the random generated string has the correct length and if it's different from the previous run
    """
    string_length = 10
    string = secure_random_hex(string_length)
    assert len(string) == string_length * 2
    assert string != secure_random_hex(string_length)


# Generated at 2022-06-21 21:13:39.888016
# Unit test for function uuid

# Generated at 2022-06-21 21:13:42.745138
# Unit test for function uuid
def test_uuid():
    assert len(uuid()) == 36
    assert type(uuid()) is str
    assert len(uuid(as_hex=True)) == 32
    assert type(uuid(as_hex=True)) is str


# Generated at 2022-06-21 21:13:45.667491
# Unit test for function random_string
def test_random_string():
    chars = string.ascii_letters + string.digits
    assert random_string(5) in chars
    assert random_string(6) in chars
    assert random_string(7) in chars
    assert random_string(8) in chars
    assert random_string(9) in chars

# Generated at 2022-06-21 21:13:47.575818
# Unit test for function roman_range
def test_roman_range():
    # Test range function
    my_range = roman_range(stop = 3)
    assert list(my_range) == ['I', 'II', 'III']


# Generated at 2022-06-21 21:13:49.440444
# Unit test for function uuid
def test_uuid():
    assert uuid()
    assert not uuid() == uuid()
    assert uuid(as_hex=True)


# Generated at 2022-06-21 21:13:52.491297
# Unit test for function uuid
def test_uuid():
    uid = uuid()
    assert len(uid) == 36
    assert isinstance(uid, str)

    uid = uuid(as_hex=True)
    assert len(uid) == 32
    assert isinstance(uid, str)



# Generated at 2022-06-21 21:13:58.259505
# Unit test for function roman_range

# Generated at 2022-06-21 21:14:02.412183
# Unit test for function secure_random_hex
def test_secure_random_hex():
    result = secure_random_hex(15)
    assert len(result) == 30
    for i in result:
        assert(i >= 'a' and i <= 'f') or (i >= '0' and i <= '9')

# Generated at 2022-06-21 21:14:12.191929
# Unit test for function roman_range
def test_roman_range():

    # test forward iteration
    assert ''.join(roman_range(7)) == 'I II III IV V VI VII'

    # test backward iteration
    assert ''.join(roman_range(stop=7, start=1, step=-1)) == 'VII VI V IV III II I'

    # test zero step
    try:
        roman_range(stop=7, start=1, step=0)
        assert False
    except ValueError:
        assert True

    # test non-valid stop value
    try:
        roman_range(stop=4000, start=1, step=1)
        assert False
    except ValueError:
        assert True

    # test non-valid start value

# Generated at 2022-06-21 21:14:15.145965
# Unit test for function random_string
def test_random_string():
    for count in range(1, 16):
        print(count, random_string(count))


# Generated at 2022-06-21 21:14:17.637413
# Unit test for function secure_random_hex
def test_secure_random_hex():
    output = secure_random_hex(9)
    print(output)

if __name__ == '__main__':
    test_secure_random_hex()
    pass

# Generated at 2022-06-21 21:14:29.885262
# Unit test for function roman_range
def test_roman_range():
    assert list(roman_range(1)) == ['I']
    assert list(roman_range(2)) == ['I', 'II']
    assert list(roman_range(3)) == ['I', 'II', 'III']
    assert list(roman_range(4)) == ['I', 'II', 'III', 'IV']
    assert list(roman_range(5)) == ['I', 'II', 'III', 'IV', 'V']
    assert list(roman_range(6)) == ['I', 'II', 'III', 'IV', 'V', 'VI']
    assert list(roman_range(7)) == ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII']

# Generated at 2022-06-21 21:14:38.887574
# Unit test for function random_string
def test_random_string():
    # Create a string with many random characters, and check if the number of characters is the same as the string size
    string = random_string(9)
    assert len(string) == 9
    # Create a string with random characters in supported range, and check if all characters are in the supported range
    string2 = random_string(26)
    test = lambda c: c in string.ascii_letters + string.digits
    assert all(map(test, string2))
    # Create a string with unsupported size, and check if the function returns an error
    try:
        string3 = random_string(-5)
    except ValueError:
        assert True

# Generated at 2022-06-21 21:14:40.534007
# Unit test for function random_string
def test_random_string():
    assert(len(random_string(9)) == 9)

# Generated at 2022-06-21 21:14:42.348453
# Unit test for function roman_range
def test_roman_range():
    print ("testing roman_range")
    counter = 0

# Generated at 2022-06-21 21:14:43.888515
# Unit test for function secure_random_hex
def test_secure_random_hex():
    assert isinstance(secure_random_hex(50), str)
    assert len(secure_random_hex(50)) == 2 * 50


# Generated at 2022-06-21 21:14:51.332299
# Unit test for function uuid
def test_uuid():
    # test default string
    uid = uuid()
    assert isinstance(uid, str)
    assert len(uid) == 36

    # test hex string
    uid = uuid(as_hex=True)
    assert isinstance(uid, str)
    assert len(uid) == 32


# Generated at 2022-06-21 21:15:03.486755
# Unit test for function roman_range
def test_roman_range():
    # test normal behavior
    assert list(roman_range(3, step=3)) == ['I', 'IV']

    # test invalid start
    with pytest.raises(ValueError, match="start must be an integer in the range 1-3999"):
        list(roman_range(stop=100, start=4000))

    # test invalid stop
    with pytest.raises(ValueError, match="stop must be an integer in the range 1-3999"):
        list(roman_range(stop=4000, start=100))

    # test invalid step
    with pytest.raises(ValueError, match="step must be an integer in the range 1-3999"):
        list(roman_range(stop=100, start=50, step=4000))

    # test overflow error

# Generated at 2022-06-21 21:15:06.511292
# Unit test for function roman_range
def test_roman_range():
    for i in roman_range(start = 10, stop = 0, step = -1):
        print(i)

test_roman_range()

# Generated at 2022-06-21 21:15:08.112185
# Unit test for function random_string
def test_random_string():
    size = 9
    assert len(random_string(size)) == size


# Generated at 2022-06-21 21:15:10.991907
# Unit test for function random_string
def test_random_string():

    for size in [1, 10, 100, 1000]:
        for _ in range(10):
            s = random_string(size)

            assert len(s) == size

# Generated at 2022-06-21 21:15:21.413684
# Unit test for function roman_range

# Generated at 2022-06-21 21:15:22.760322
# Unit test for function random_string
def test_random_string():
    assert len(random_string(20)) == 20

# Generated at 2022-06-21 21:15:30.842705
# Unit test for function roman_range
def test_roman_range():
    assert list(roman_range(10)) == ['I','II','III','IV','V','VI','VII','VIII','IX','X']

    assert list(roman_range(1, 3)) == ['I','II']

    assert list(roman_range(10, 1, -1)) == ['X','IX','VIII','VII','VI','V','IV','III','II','I']

    assert list(roman_range(32, 1, 3)) == ['I','IV','VII','X','XIII','XVI','XIX','XXII','XXV','XXVIII']

    assert list(roman_range(14, 15, -1)) == []

    assert list(roman_range(15, 13, 3)) == ['XIII','XVI']

    assert list(roman_range(10, 10)) == ['X']

# Generated at 2022-06-21 21:15:35.411829
# Unit test for function uuid
def test_uuid():
    assert isinstance(uuid(), str)
    assert len(uuid()) == 36
    assert uuid(as_hex=True) == uuid().replace('-', '')
    assert len(uuid(as_hex=True)) == 32



# Generated at 2022-06-21 21:15:43.739242
# Unit test for function secure_random_hex
def test_secure_random_hex():
    """
    Tests the secrue_random_hex function on the following aspects:
       - The output is of the correct size
       - The output does not contain any characters other than hexadecimal numbers
       - The output does not contain any whitespace
    """
    for i in range(1, 100): # Test size from 1 byte to 100 bytes
        rand = secure_random_hex(byte_count = i)
        assert len(rand) == i * 2
        assert not any(c not in "0123456789ABCDEF" for c in rand)
        assert not any(c in " \t" for c in rand)


# Generated at 2022-06-21 21:15:52.779652
# Unit test for function uuid
def test_uuid():
    assert len(uuid()) == 36
    assert len(uuid(as_hex=True)) == 32


# Generated at 2022-06-21 21:16:01.918345
# Unit test for function secure_random_hex
def test_secure_random_hex():
    assert len(secure_random_hex(9)) == 18
    assert len(secure_random_hex(1)) == 2
    assert len(secure_random_hex(2)) == 4
    assert len(secure_random_hex(0)) == 0
    assert len(secure_random_hex(9)) == 18
    assert len(secure_random_hex(10)) == 20
    assert len(secure_random_hex(24)) == 48
    assert len(secure_random_hex(25)) == 50
    assert len(secure_random_hex(26)) == 52


# Generated at 2022-06-21 21:16:08.389595
# Unit test for function uuid
def test_uuid():
    print("\nFunction: uuid\n")
    print("Test 1")
    print("Input: uuid()")
    print("Output: ",uuid())
    print("\nTest 2")
    print("Input: uuid(as_hex=True)")
    print("Output: ",uuid(as_hex=True))


# Generated at 2022-06-21 21:16:12.226384
# Unit test for function random_string
def test_random_string():

    n = 5

    expected_size = n

    value = random_string(n)
    actual_size = len(value)

    assert actual_size == expected_size, "Expected random string size of %s but got %s" % (expected_size, actual_size)



# Generated at 2022-06-21 21:16:14.008586
# Unit test for function uuid
def test_uuid():
    assert len(uuid()) == 36
    assert len(uuid(as_hex=True)) == 32


# Generated at 2022-06-21 21:16:21.459166
# Unit test for function roman_range
def test_roman_range():
    assert list(roman_range(7)) == ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII']
    assert list(roman_range(7, 1, 2)) == ['I', 'III', 'V']
    assert list(roman_range(7, 1, -2)) == []
    assert list(roman_range(7, 2, -2)) == ['II']
    assert list(roman_range(7, 2, -1)) == ['II', 'I']
    assert list(roman_range(7, 1, -1)) == []
    assert list(roman_range(7, 7, -2)) == ['VII']
    assert list(roman_range(7, 7, -1)) == ['VII']
    assert list(roman_range(7, 7)) == ['VII']

# Generated at 2022-06-21 21:16:29.799815
# Unit test for function roman_range
def test_roman_range():
    rrange = roman_range(7, 1, 1)
    assert next(rrange) == 'I'
    assert next(rrange) == 'II'
    assert next(rrange) == 'III'
    assert next(rrange) == 'IV'
    assert next(rrange) == 'V'
    assert next(rrange) == 'VI'
    assert next(rrange) == 'VII'
    assert next(rrange, None) == None
    
    
    rrange = roman_range(7, 7, -1)
    assert next(rrange) == 'VII'
    assert next(rrange) == 'VI'
    assert next(rrange) == 'V'
    assert next(rrange) == 'IV'
    assert next(rrange) == 'III'

# Generated at 2022-06-21 21:16:31.024178
# Unit test for function random_string
def test_random_string():
    for n in range(10):
        assert len(random_string(16))==16

# Generated at 2022-06-21 21:16:32.924189
# Unit test for function random_string
def test_random_string():
    assert len(random_string(9)) == 9


# Generated at 2022-06-21 21:16:34.765776
# Unit test for function uuid
def test_uuid():
    print(uuid())


# Generated at 2022-06-21 21:16:54.417764
# Unit test for function roman_range
def test_roman_range():
    assert all((i == n) for i, n in enumerate(roman_range(10), 1))
    assert all((i == n) for i, n in enumerate(roman_range(start=10, stop=1, step=-1), 10))

# Generated at 2022-06-21 21:16:55.281502
# Unit test for function roman_range
def test_roman_range():
    assert roman_range(10) == range(10)

# Generated at 2022-06-21 21:17:03.574040
# Unit test for function roman_range
def test_roman_range():
    lrange = [i for i in roman_range(10)]
    assert lrange == ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"]
    lrange = [i for i in roman_range(10,3,3)]
    assert lrange == ["III", "VI", "IX"]
    lrange = [i for i in roman_range(3999)]
    assert lrange == ["MMMCMXCIX"]
    lrange = [i for i in roman_range(1,10,-2)]
    assert lrange == ["I", "III", "V", "VII", "IX"]
    lrange = [i for i in roman_range(1,1)]
    assert lrange == ["I"]

# Generated at 2022-06-21 21:17:06.369413
# Unit test for function secure_random_hex
def test_secure_random_hex():
    hex_string = secure_random_hex(9)
    assert isinstance(hex_string, str)
    assert len(hex_string) == 18


# Generated at 2022-06-21 21:17:11.759490
# Unit test for function uuid
def test_uuid():
    assert uuid() == '4e4a084c-3ec4-4a1a-99bc-469d21ccd6e0'
    assert uuid(as_hex=True) == '4e4a084c3ec44a1a99bc469d21ccd6e0'
    assert len(uuid()) == 36
    assert len(uuid(as_hex=True)) == 32


# Generated at 2022-06-21 21:17:23.198600
# Unit test for function roman_range
def test_roman_range():
    assert[x for x in roman_range(7)]==['I','II','III','IV','V','VI','VII']
    assert[x for x in roman_range(start=7, stop=1, step=-1)]==['VII','VI','V','IV','III','II','I']
    try:
        assert [x for x in roman_range(start=-1, stop=-1, step=-1)]
    except ValueError:
        print("start, stop and step must be in range 1-3999")
    try:
        assert [x for x in roman_range(stop=300000)]
    except ValueError:
        print("start, stop and step must be in range 1-3999")

# Generated at 2022-06-21 21:17:25.583352
# Unit test for function secure_random_hex
def test_secure_random_hex():
    for i in range(100):
        assert len(secure_random_hex(i)) == i*2

# Generated at 2022-06-21 21:17:29.871702
# Unit test for function random_string
def test_random_string():
    try:
        random_string('f')
    except ValueError:
        print("random_string: Test passed")
    else:
        print("random_string: Test failed")


# Generated at 2022-06-21 21:17:40.446767
# Unit test for function roman_range
def test_roman_range():
    # forward_exceed
    assert roman_range(10, 15, 2).count() == 0
    # backward_exceed
    assert roman_range(5, 1, -2).count() == 0
    # forward
    assert roman_range(10, 5, 2).count() == 3
    # backward
    assert roman_range(5, 9, -2).count() == 3
    # invalid start
    try:
        roman_range(10, 1205).count()
        assert False
    except ValueError as e:
        assert str(e) == '"start" must be an integer in the range 1-3999'
    # invalid stop

# Generated at 2022-06-21 21:17:42.311790
# Unit test for function random_string
def test_random_string():
    output = random_string(9)
    assert len(output) == 9


# Generated at 2022-06-21 21:18:24.892768
# Unit test for function roman_range
def test_roman_range():
    # Check if all numbers are generated
    s = list(roman_range(7))
    assert len(s) == 7
    assert s == ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII']

    # Check if negative numbers are properly intepreted and generated
    s = list(roman_range(6, 3, -1))
    assert len(s) == 3
    assert s == ['IV', 'III', 'II']

    # Check if negative numbers are properly intepreted and generated
    s = list(roman_range(4, 7, -1))
    assert len(s) == 3
    assert s == ['VII', 'VI', 'V']

    # Check if negative numbers are properly intepreted and generated
    s = list(roman_range(1, 4, -1))
   

# Generated at 2022-06-21 21:18:27.003150
# Unit test for function random_string
def test_random_string():
    assert random_string(1)
    assert random_string(9)
    assert random_string(16)
    assert random_string(32)
    assert random_string(64)
    assert random_string(128)
    assert random_string(256)
    assert random_string(512)


# Generated at 2022-06-21 21:18:30.049214
# Unit test for function uuid
def test_uuid():
    r = uuid()
    assert len(r) > 0, 'case: uuid()'
    r = uuid(True)
    assert len(r) > 0, 'case: uuid(True)'


# Generated at 2022-06-21 21:18:37.397136
# Unit test for function roman_range
def test_roman_range():
    assert roman_range(35).__next__() == 'I', 'case 1'
    assert roman_range(35).__next__() == 'I', 'case 2'
    assert roman_range(12,25).__next__() == 'XII', 'case 3'
    assert roman_range(25,12).__next__() == 'XXV', 'case 4'
    assert roman_range(35,12).__next__() == 'XII', 'case 5'
    assert roman_range(12,35).__next__() == 'XII', 'case 6'
    assert roman_range(3999,2).__next__() == 'II', 'case 7'
    assert roman_range(2,3999).__next__() == 'II', 'case 8'
    assert roman_

# Generated at 2022-06-21 21:18:39.525586
# Unit test for function secure_random_hex
def test_secure_random_hex():
    for i in range(10):
        print(secure_random_hex(4))

# Script to test roman_range

# Generated at 2022-06-21 21:18:49.730417
# Unit test for function uuid
def test_uuid():
    uuid_str1 = uuid()
    assert isinstance(uuid_str1, str)
    assert len(uuid_str1) == 36
    assert uuid_str1[14] == '4'  # the hyphen at index 14 should always be a '4' according to the UUID v4 rfc
    assert len(uuid_str1.split('-')) == 5  # uuid v4 rfc states that there should be 5 groups of characters
    # separated by hyphens

    uuid_str2 = uuid(True)
    assert isinstance(uuid_str2, str)
    assert len(uuid_str2) == 32
    assert uuid_str2.isalnum()
    assert not ('-' in uuid_str2)  # hyphens are dropped in hex mode



# Generated at 2022-06-21 21:18:52.794611
# Unit test for function random_string
def test_random_string():
    assert len(random_string(6)) == 6
    assert len(random_string(9)) == 9
    assert len(random_string(30)) == 30


if __name__ == '__main__':
    test_random_string()

# Generated at 2022-06-21 21:19:05.040357
# Unit test for function roman_range
def test_roman_range():
    a = list(roman_range(100, step=10))
    b = list(roman_range(100, step=10, start=10))
    c = list(roman_range(100, step=10, start=90))
    d = list(roman_range(100))
    e = list(roman_range(100, start=10))
    f = list(roman_range(100, start=90))
    g = list(roman_range(100, start=10, step=10))
    h = list(roman_range(100, start=10, step=-10))
    i = list(roman_range(100, start=90, step=-10))
    j = list(roman_range(100, step=-10))
    k = list(roman_range(100, start=90, step=-10))

# Generated at 2022-06-21 21:19:08.647362
# Unit test for function random_string
def test_random_string():
    assert len(random_string(10)) == 10
    # Checks if each string is indeed random.
    # (Note that this test could fail once in a while if the random choice of
    # chars happens to return the same value every time)
    assert random_string(10) != random_string(10)



# Generated at 2022-06-21 21:19:12.581804
# Unit test for function secure_random_hex
def test_secure_random_hex():
    assert isinstance(secure_random_hex(4), str) == True
    assert len(secure_random_hex(4)) == 8


# Generated at 2022-06-21 21:20:17.458904
# Unit test for function random_string
def test_random_string():
    assert len(random_string(20)) == 20
    assert len(random_string(1)) == 1

# Generated at 2022-06-21 21:20:21.658266
# Unit test for function uuid
def test_uuid():
    assert uuid()
    assert uuid().__class__ == str
    assert uuid().__len__() == 36
    assert uuid(as_hex=True)
    assert uuid(as_hex=True).__class__ == str
    assert uuid(as_hex=True).__len__() == 32


# Generated at 2022-06-21 21:20:23.715212
# Unit test for function random_string
def test_random_string():
    random_string(10)
    assert True == True

# Generated at 2022-06-21 21:20:32.164029
# Unit test for function random_string
def test_random_string():
    import sys
    import string

    if sys.version_info[0] != 3:
        print("This program requires python version 3")
        exit(1)

    output = random_string(10)
    print(output)
    status = True
    for i in output:
        if i not in string.ascii_letters or i not in string.digits:
            status = False
            break
    if status:
        print("test_random_string: test passed.")
    else:
        print("test_random_string: test failed.")


if __name__ == "__main__":
    test_random_string()

# Generated at 2022-06-21 21:20:38.972543
# Unit test for function random_string
def test_random_string():
    str=random_string(9)
    print(str)
    return str

# -*- coding: utf-8 -*-

# public api to export
__all__ = [
    'uuid',
    'random_string',
    'secure_random_hex',
    'roman_range',
]

import binascii
import os
import random
import string
from typing import Generator
from uuid import uuid4

from libtools import manipulation



# Generated at 2022-06-21 21:20:43.075676
# Unit test for function uuid
def test_uuid():
    print('Test Function uuid()')
    uuidString = uuid()
    print('Return:', uuidString)
    if (len(uuidString) == 36) and ('-' in uuidString):
        print('Test Passed!')
    else:
        print('Test Failed!')


# Generated at 2022-06-21 21:20:47.155629
# Unit test for function secure_random_hex
def test_secure_random_hex():
    """
    Unit test function
    Check if the function random_string returns a string and if it is of the length specified
    """
    assert isinstance(secure_random_hex(9), str)
    assert len(secure_random_hex(9)) == 18


# Generated at 2022-06-21 21:20:52.929535
# Unit test for function secure_random_hex
def test_secure_random_hex():
    try:
        # check if many return values are different
        out_1 = secure_random_hex(9)
        out_2 = secure_random_hex(9)

        assert isinstance(out_1, str)
        assert isinstance(out_2, str)
        assert len(out_1) == 18
        assert len(out_2) == 18
        assert out_1 != out_2
    except AssertionError:
        raise AssertionError('secure_random_hex() failed!')

# Generated at 2022-06-21 21:20:54.720618
# Unit test for function random_string
def test_random_string():
    for i in range(0, 10):
        random_string(9)

if __name__ == "__main__":
    test_random_string()

# Generated at 2022-06-21 21:20:55.343525
# Unit test for function secure_random_hex
def test_secure_random_hex():
    assert len(secure_random_hex(300)) == 600

# Generated at 2022-06-21 21:23:09.084377
# Unit test for function random_string
def test_random_string():
    facteur = 0.25
    test_str = random_string(int(facteur * 100))
    while test_str == random_string(int(facteur * 100)):
        facteur = facteur + 0.25

    assert len(test_str) == int(facteur * 100)

    facteur = 0.25
    test_str = random_string(int(facteur * 100))
    while test_str == random_string(int(facteur * 100)):
        facteur = facteur + 0.25

    assert len(test_str) == int(facteur * 100)
