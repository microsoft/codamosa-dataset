

# Generated at 2022-06-21 21:13:31.920259
# Unit test for function roman_range
def test_roman_range():
    string = ''
    for i in roman_range(3):
        string += i
    assert string == 'III'

    string = ''
    for i in roman_range(1,10,2):
        string += i
    assert string == 'VIIII'

    string = ''
    for i in roman_range(30,2,-2):
        string += i
    assert string == 'XX'

    string = ''
    for i in roman_range(39999):
        assert len(i) <= 4
    
    return

# Generated at 2022-06-21 21:13:34.685745
# Unit test for function uuid
def test_uuid():
    uid = uuid()
    print(uid)


# Generated at 2022-06-21 21:13:40.861344
# Unit test for function random_string
def test_random_string():
    assert len(random_string(10)) == 10
    assert len(random_string(100)) == 100
    assert len(random_string(1000)) == 1000
    assert len(random_string(10000)) == 10000
    #assert random_string(1) == "c"
    #assert random_string(1) == "p"
    #assert random_string(1) == "N"
    #assert random_string(1) == "E"
    #assert random_string(1) == "2"
    #assert random_string(1) == "3"


# Generated at 2022-06-21 21:13:49.086954
# Unit test for function roman_range
def test_roman_range():
    assert [n for n in roman_range(7)] == ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII']
    assert [n for n in roman_range(start=7, stop=1, step=-1)] == ['VII', 'VI', 'V', 'IV', 'III', 'II', 'I']

    try:
        [n for n in roman_range(2, 1, -1)]
        assert False
    except OverflowError:
        assert True

    try:
        [n for n in roman_range(4040, 1)]
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-21 21:13:52.222978
# Unit test for function random_string
def test_random_string():
    assert(len(random_string(9)) == 9)
    assert(''.join([str(type(_)) for _ in random_string(9)]) == "<class 'str'>")
    assert(len(random_string(9)) == 9)
    assert(len(random_string(9)) == 9)


# Generated at 2022-06-21 21:13:59.563435
# Unit test for function uuid
def test_uuid():
    """
    Test for function uuid
    """
    for _ in range(100):
        assert uuid() != uuid() # checks if different UUIDs are generated
        assert len(uuid()) == len(uuid(as_hex=True)) - 4 # checks if both hex/default formats have matching lengths
        assert len(uuid()) == 36
        assert len(uuid(as_hex=True)) == 32


# Generated at 2022-06-21 21:14:10.156441
# Unit test for function roman_range
def test_roman_range():

    def check_generator(generator):
        """
        Checks that the generator returns the expected values.

        :param generator: Generator to check.
        :type generator: Generator
        """
        expected = [
            'I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X',
            'XI', 'XII', 'XIII', 'XIV', 'XV', 'XVI', 'XVII', 'XVIII', 'XIX', 'XX',
            'XXI', 'XXII', 'XXIII', 'XXIV', 'XXV', 'XXVI', 'XXVII', 'XXVIII', 'XXIX', 'XXX',
        ]
        iter_gen = iter(generator)

        for i, expected_value in enumerate(expected):
            current = next

# Generated at 2022-06-21 21:14:15.785588
# Unit test for function uuid
def test_uuid():
    assert uuid() == '94903ccb-0d1a-4e86-8278-d54f9cee1c3e'
    assert uuid() == '1c69ba12-24f8-4d47-9b54-87c07bf4a8ff'
    assert uuid(as_hex=True) == 'e4d4112c9e9b47e3bbbd15b8e68c377c'
    assert uuid(as_hex=True) == '9a5d5e5b5d8e4a5bab7abcb4b4ca4f66'


# Generated at 2022-06-21 21:14:18.843562
# Unit test for function random_string
def test_random_string():
    f = open("D:/python_training/test.txt","w+")
    for i in range(100):
        str = random_string(9)
        f.write("%s\n" %str)
    f.close()

# Generated at 2022-06-21 21:14:28.762695
# Unit test for function roman_range
def test_roman_range():
    test_vectors = [
        dict(stop=7, expected=['I', 'II', 'III', 'IV', 'V', 'VI', 'VII']),
        dict(start=7, stop=1, step=-1, expected=['VII', 'VI', 'V', 'IV', 'III', 'II', 'I']),
        dict(stop=1, expected=['I']),
    ]

    for test in test_vectors:
        gernerator = roman_range(**test)
        values = list(gernerator)
        expected = test['expected']
        assert values == expected

# Generated at 2022-06-21 21:14:43.092534
# Unit test for function roman_range
def test_roman_range():
    start, stop, step = 1, 10, 1
    roman_range_generator = list(roman_range(stop=stop, start=start, step=step))
    assert roman_range_generator == ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X']

    start, stop, step = 100, 110, 1
    roman_range_generator = list(roman_range(stop=stop, start=start, step=step))
    assert roman_range_generator == ['C', 'CI', 'CII', 'CIII', 'CIV', 'CV', 'CVI', 'CVII', 'CVIII', 'CIX', 'CX']

    start, stop, step = 1, 10, 3
    roman_range_generator = list

# Generated at 2022-06-21 21:14:44.497634
# Unit test for function uuid
def test_uuid():
    # Test if the function generates a string
    uuid_str = uuid()
    assert isinstance(uuid_str, str)


# Generated at 2022-06-21 21:14:56.407234
# Unit test for function roman_range
def test_roman_range():
    success = True
    try:
        for n in roman_range(7):
            pass
    except:
        success = False
    assert success, "Error in roman_range"

    success = True
    try:
        for n in roman_range(start=7, stop=1, step=-1):
            pass
    except:
        success = False
    assert success, "Error in roman_range"

    success = True
    try:
        for n in roman_range(start=1, stop=7, step=1):
            pass
    except:
        success = False
    assert success, "Error in roman_range"

    try:
        for n in roman_range(start=7, stop=1, step=1):
            success = False
    except:
        pass
    assert success

# Generated at 2022-06-21 21:14:59.403857
# Unit test for function secure_random_hex
def test_secure_random_hex():
    random_str10 = secure_random_hex(10)
    assert isinstance(random_str10, str) and len(random_str10) == 10 * 2, 'Random string of 10 bytes should have len 20'


# Generated at 2022-06-21 21:15:03.061281
# Unit test for function random_string
def test_random_string():
    """
    Test function random_string.
    """
    assert len(random_string(100)) == 100
    assert len(random_string(99)) == 99
    assert len(random_string(1)) == 1
    assert len(random_string(0)) == 0



# Generated at 2022-06-21 21:15:08.057631
# Unit test for function random_string
def test_random_string():
    a = random_string(5)
    b = random_string(5)
    assert (len(a) == 5)
    assert (a != b)
    print(a)
    print(b)
    print("random_string test passed")


# Generated at 2022-06-21 21:15:11.342619
# Unit test for function uuid
def test_uuid():
    uuid_string = uuid()
    assert len(uuid_string) == 36

    uuid_string = uuid(as_hex=True)
    assert len(uuid_string) == 32


# Generated at 2022-06-21 21:15:13.655584
# Unit test for function secure_random_hex
def test_secure_random_hex():
    while True:
        x = secure_random_hex(16)
        if x != "00":
            break
    return x


# Generated at 2022-06-21 21:15:16.722233
# Unit test for function roman_range
def test_roman_range():
    index = 1
    for n in roman_range(50):
        assert index == roman_encode(n)
        index += 1

if __name__ == "__main__":
    test_roman_range()

# Generated at 2022-06-21 21:15:22.530961
# Unit test for function random_string
def test_random_string():
    import unittest

    class TestRandomString(unittest.TestCase):

        def test_string_length(self):
            self.assertEqual(len(random_string(0)), 0)

        def test_string_value_is_random(self):
            import sys

            self.assertEqual(len(set(random_string(sys.maxsize))), sys.maxsize)

    unittest.main()


# Generated at 2022-06-21 21:15:32.640748
# Unit test for function uuid
def test_uuid():
    assert isinstance(uuid(), str)

    assert uuid(as_hex=True) != uuid(as_hex=True)

    hex_uuid = uuid(as_hex=True).lower()
    assert len(hex_uuid) == 32
    assert all(c in string.hexdigits for c in hex_uuid)


# Generated at 2022-06-21 21:15:34.147304
# Unit test for function secure_random_hex
def test_secure_random_hex():
    assert isinstance(secure_random_hex(1), str)

# Generated at 2022-06-21 21:15:44.478267
# Unit test for function roman_range
def test_roman_range():
    # test passing invalid params
    invalid_params = [
        {'stop': 0},
        {'stop': 4000},
        {'stop': 10, 'start': 20},
        {'stop': 5, 'start': 4, 'step': 0},
        {'stop': 5, 'start': 4, 'step': 1},
        {'stop': 5, 'start': 6, 'step': -1},
    ]
    for param in invalid_params:
        try:
            roman_range(**param)
            raise AssertionError('Invalid params not detected: {}'.format(param))
        except (ValueError, OverflowError) as e:
            pass
    # test valid params with step 1

# Generated at 2022-06-21 21:15:47.803537
# Unit test for function roman_range
def test_roman_range():
    obj = roman_range(7,1)
    assert isinstance(obj, Generator)
    output = []
    for i in range(7):
        output.append(next(obj))

# Generated at 2022-06-21 21:15:55.981082
# Unit test for function roman_range
def test_roman_range():
    assert list(roman_range(7)) == [roman_encode(i) for i in range(1, 8)]
    assert list(roman_range(1, 7)) == [roman_encode(i) for i in range(1, 8)]
    assert list(roman_range(1, 7, 2)) == [roman_encode(i) for i in range(1, 8, 2)]
    assert list(roman_range(6, 2, -1)) == [roman_encode(i) for i in range(6, 0, -1)]
    assert list(roman_range(6, 2, -2)) == [roman_encode(i) for i in range(6, 0, -2)]

# Generated at 2022-06-21 21:16:01.757741
# Unit test for function uuid
def test_uuid():
    assert uuid() == 'f6b0d1b1-8e30-4b65-a3f7-e3c8f8ed83b4'
    assert uuid(as_hex=True) == 'f6b0d1b18e304b65a3f7e3c8f8ed83b4'


# Generated at 2022-06-21 21:16:02.798381
# Unit test for function secure_random_hex
def test_secure_random_hex():
    assert len(secure_random_hex(9)) == 18

# Generated at 2022-06-21 21:16:08.000576
# Unit test for function random_string
def test_random_string():
    for size in range(1, 100):
        out = random_string(size)
        assert len(out) == size
        assert isinstance(out, str)


if __name__ == '__main__':
    test_random_string()

# Generated at 2022-06-21 21:16:10.056328
# Unit test for function secure_random_hex
def test_secure_random_hex():
    byte_count = 100
    hex_str = secure_random_hex(byte_count)
    assert len(hex_str) == byte_count * 2

# Generated at 2022-06-21 21:16:12.959446
# Unit test for function roman_range
def test_roman_range():
    range_list=[]
    for n in roman_range(3):
        range_list.append(n)
    print(range_list)
    assert range_list == ['I', 'II', 'III']

if __name__ == "__main__":
    test_roman_range()

# Generated at 2022-06-21 21:16:24.283013
# Unit test for function uuid
def test_uuid():
    uid = uuid(as_hex=False)
    assert isinstance(uid, str) and len(uid) == 36
    assert uuid(as_hex=True)
    assert not uuid(as_hex=True) == uuid(as_hex=False)



# Generated at 2022-06-21 21:16:28.598586
# Unit test for function secure_random_hex
def test_secure_random_hex():

    value = secure_random_hex(10)
    hex_reg_ex = re.compile(r'[0-9a-fA-F]+')

    assert len(value) == 20
    assert re.match(hex_reg_ex, value) is not None


# Generated at 2022-06-21 21:16:29.800967
# Unit test for function uuid
def test_uuid():
    uuid()
    uuid(True)


# Generated at 2022-06-21 21:16:32.701743
# Unit test for function secure_random_hex
def test_secure_random_hex():
    for i in range(1, 1024):
        secure_random_hex(i)
        assert len(secure_random_hex(i)) == (2 * i)

# Generated at 2022-06-21 21:16:44.650035
# Unit test for function roman_range
def test_roman_range():
    import traceback
    # test forward configuration
    try:
        print('TEST: roman_range(stop=7)')
        roman_values = roman_range(stop=7)
        for roman_value in roman_values:
            print(roman_value)
        print('TEST PASSED!')
    except Exception as e:
        print('TEST FAILED:')
        traceback.print_tb(e.__traceback__)
        print(e)

    # test backward configuration

# Generated at 2022-06-21 21:16:46.071768
# Unit test for function random_string
def test_random_string():
    assert isinstance(random_string(6), str)
    assert len(random_string(6)) == 6

# Generated at 2022-06-21 21:16:58.652267
# Unit test for function roman_range
def test_roman_range():
    assert list(roman_range(7)) == ["I", "II", "III", "IV", "V", "VI", "VII"]
    assert list(roman_range(start=7, stop=1, step=-1)) == ["VII", "VI", "V", "IV", "III", "II", "I"]
    with pytest.raises(ValueError):
        list(roman_range(0))
    with pytest.raises(ValueError):
        list(roman_range(start=0))
    with pytest.raises(ValueError):
        list(roman_range(step=0))
    with pytest.raises(ValueError):
        list(roman_range(step=-1))
    with pytest.raises(OverflowError):
        list(roman_range(stop=1))

# Generated at 2022-06-21 21:17:10.838147
# Unit test for function roman_range
def test_roman_range():
    assert list(roman_range(7)) == ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII']
    assert list(roman_range(start=7, stop=1, step=-1)) == ['VII', 'VI', 'V', 'IV', 'III', 'II', 'I']
    try:
        assert list(roman_range(1, 7, 2)) == ['I', 'III', 'V']
    except OverflowError:
        assert False
    try:
        assert list(roman_range(1, 7, -2)) == ['I', 'III', 'V']
    except OverflowError:
        assert True
    try:
        assert list(roman_range(7, 1, 2)) == ['II', 'IV', 'VI']
    except OverflowError:
        assert False

# Generated at 2022-06-21 21:17:14.395870
# Unit test for function random_string
def test_random_string():
    assert type(random_string(1)) is str
    assert len(random_string(1)) == 1
    assert len(random_string(1)) == 1
    assert len(random_string(10)) == 10


# Generated at 2022-06-21 21:17:17.567446
# Unit test for function uuid
def test_uuid():
    uuid = uuid()
    assert(len(uuid) == 36)


# Generated at 2022-06-21 21:17:32.934844
# Unit test for function uuid
def test_uuid():
    assert len(uuid()) > 0
    assert len(uuid(as_hex=True)) > 0
    assert len(uuid()) > len(uuid(as_hex=True))


# Generated at 2022-06-21 21:17:37.307865
# Unit test for function roman_range
def test_roman_range():
    assert ["I", "II", "III", "IV", "V", "VI", "VII"] == list(roman_range(7))
    assert ["VII", "VI", "V", "IV", "III", "II", "I"] == list(roman_range(7, 1, -1))

# Generated at 2022-06-21 21:17:41.254697
# Unit test for function secure_random_hex
def test_secure_random_hex():
    assert isinstance(secure_random_hex(4), str)
    assert len(secure_random_hex(4)) == 8
    assert isinstance(secure_random_hex(10), str)
    assert len(secure_random_hex(10)) == 20
    assert isinstance(secure_random_hex(42), str)
    assert len(secure_random_hex(42)) == 84

# Generated at 2022-06-21 21:17:42.311680
# Unit test for function random_string
def test_random_string():
    assert len(random_string(9)) == 9

# Generated at 2022-06-21 21:17:46.317959
# Unit test for function random_string
def test_random_string():
    random_generator = random_string(9)
    if random_generator.islower():
        return True
    else:
        return False


# Generated at 2022-06-21 21:17:50.610709
# Unit test for function secure_random_hex
def test_secure_random_hex():
    import pytest
    assert isinstance(secure_random_hex(10), str)
    with pytest.raises(ValueError):
        secure_random_hex(0)
        secure_random_hex(-1)
        secure_random_hex(3.14)

# Generated at 2022-06-21 21:18:00.984591
# Unit test for function roman_range
def test_roman_range():
    """
    Unit test for function roman_range to check that it returns the expected results
    """
    import itertools

    assert list(roman_range(6)) == ['I', 'II', 'III', 'IV', 'V', 'VI']
    assert (list(itertools.islice(roman_range(40), 10))) == ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X']
    assert list(roman_range(5,3)) == ['III', 'IV', 'V']
    assert (list(itertools.islice(roman_range(3,15), 3))) == ['III', 'IV', 'V']
    assert list(roman_range(1,4,2)) == ['I', 'III']

# Generated at 2022-06-21 21:18:02.964408
# Unit test for function uuid
def test_uuid():
    assert len(uuid()) == 36
    assert len(uuid(True)) == 32


# Generated at 2022-06-21 21:18:10.061767
# Unit test for function uuid
def test_uuid():
    for _ in range(100):
        generated_value = uuid()
        assert isinstance(generated_value, str)
        assert len(generated_value) == 36

        generated_value = uuid(as_hex=True)
        assert isinstance(generated_value, str)
        assert len(generated_value) == 32

        assert generated_value == uuid(as_hex=True)



# Generated at 2022-06-21 21:18:14.389481
# Unit test for function random_string
def test_random_string():
    from string import printable
    import string
    for i in range(100, 10000):
        assert isinstance(random_string(i), str)
        assert len(random_string(i)) == i
        for char in random_string(i):
            assert char in string.ascii_letters or char in string.digits


# Generated at 2022-06-21 21:18:44.528497
# Unit test for function random_string
def test_random_string():
    cases = [
        ("size must be >= 1", -5),
        ("size must be >= 1", 0),
        ("size must be >= 1", 1.5),
        ("size must be >= 1", "2")
    ]
    for case in cases:
        try:
            random_string(case[1])
        except ValueError as e:
            assert str(e) == case[0]


# Generated at 2022-06-21 21:18:53.961115
# Unit test for function roman_range
def test_roman_range():
    """
    Tests function roman_range.
    :return:
    """
    stop=100
    start=1
    step=1


# Generated at 2022-06-21 21:18:57.833898
# Unit test for function secure_random_hex
def test_secure_random_hex():
    random_number=secure_random_hex(9)
    print(random_number)


if __name__ == '__main__':
    test_secure_random_hex()

# Generated at 2022-06-21 21:19:00.276495
# Unit test for function secure_random_hex
def test_secure_random_hex():
    assert len(secure_random_hex(7)) == 14
    assert len(secure_random_hex(20)) == 40



# Generated at 2022-06-21 21:19:03.095144
# Unit test for function uuid
def test_uuid():
    uid = uuid()
    assert len(uid) == 36

    hex_uid = uuid(as_hex=True)
    assert len(hex_uid) == 32



# Generated at 2022-06-21 21:19:08.992039
# Unit test for function uuid
def test_uuid():
    u = uuid()
    assert len(u) == 36
    assert u[14] == '4'
    assert u[19] == '8'
    assert u[24] == 'b'
    assert u[9] == '-'
    assert u[14] == '4'
    assert u[19] == '8'
    assert u[24] == 'b'
    # Hex vals
    u = uuid(True)
    assert len(u) == 32


# Generated at 2022-06-21 21:19:19.473735
# Unit test for function roman_range
def test_roman_range():
    print("Running test_roman_range...")
    assert [n for n in roman_range(7)] == ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII']
    assert [n for n in roman_range(start=7, stop=1, step=-1)] == ['VII', 'VI', 'V', 'IV', 'III', 'II', 'I']
    assert [n for n in roman_range(start=7, stop=5)] == []

if __name__ == '__main__':
    test_roman_range()

# Generated at 2022-06-21 21:19:22.815475
# Unit test for function random_string
def test_random_string():
    size = 9
    random_string(size)



# Generated at 2022-06-21 21:19:25.419843
# Unit test for function secure_random_hex
def test_secure_random_hex():
    byte_len = 16
    random_string_len = byte_len * 2
    random_hex = secure_random_hex(byte_len)
    assert len(random_hex) == random_string_len

# Generated at 2022-06-21 21:19:27.631088
# Unit test for function random_string
def test_random_string():
    rs = random_string(9)
    assert len(rs) == 9
    assert isinstance(rs, str)

# Generated at 2022-06-21 21:20:22.665813
# Unit test for function secure_random_hex
def test_secure_random_hex():
    # This function will generate a random string of 20 hex digits
    str_len = 20
    random_string = secure_random_hex(10)

    # Check if str_len = 20
    if len(random_string) != str_len:
        print("String length is not 20!")

    # Check if ths hexadecimal string has correct format
    try:
        assert random_string.isalnum()
    except AssertionError:
        print("random_string is not in correct hexadecimal format")

# Generated at 2022-06-21 21:20:31.257446
# Unit test for function random_string
def test_random_string():
    # Test if the type is a string
    assert isinstance(random_string(100), str)
    # Test if the output is of a specific length
    assert len(random_string(100)) == 100
    # Test if the output contains characters only
    assert random_string(10).isalnum()
    # Test if the output contains upper and lower case letters
    assert any(c.isupper() for c in random_string(100))
    assert any(c.islower() for c in random_string(100))
    # Test if the output contains digits
    assert any(c.isdigit() for c in random_string(100))


# Generated at 2022-06-21 21:20:34.940333
# Unit test for function secure_random_hex
def test_secure_random_hex():
    assert len(secure_random_hex(8)) == 16
    assert len(secure_random_hex(16)) == 32
    assert len(secure_random_hex(32)) == 64


# Generated at 2022-06-21 21:20:43.075363
# Unit test for function random_string
def test_random_string():
    for i in range(1000):
        assert len(random_string(9)) == 9    # Test if generated string is 9 characters long

    count_letter = 0
    count_digit = 0
    random_str = random_string(9)

    for i in random_str:
        if i.isdigit():
            count_digit += 1
        if i.isalpha():
            count_letter += 1

    assert count_letter == 5    # Test if generated string is 5 letters long
    assert count_digit == 4    # Test if generated string is 4 digits long


if __name__ == '__main__':
    test_random_string()

# Generated at 2022-06-21 21:20:44.092350
# Unit test for function random_string
def test_random_string():
    assert(random_string(15) != random_string(15))


# Generated at 2022-06-21 21:20:46.781840
# Unit test for function random_string
def test_random_string():
    assert len(random_string(5)) == 5
    assert len(random_string(0)) == 0


# Generated at 2022-06-21 21:20:52.240348
# Unit test for function roman_range
def test_roman_range():
    step = 1
    for n in roman_range(3, step=step):
        assert n == roman_encode(step), "test_roman_range(): Failed at iteration step="+str(step)
        step += 1
    step = 10
    for n in roman_range(30, step=step):
        assert n == roman_encode(step), "test_roman_range(): Failed at iteration step="+str(step)
        step += 10

# Generated at 2022-06-21 21:20:55.806132
# Unit test for function secure_random_hex
def test_secure_random_hex():
    n = 10101
    nb_bytes = int(n/2)
    random_string = secure_random_hex(nb_bytes)
    length_ok = len(random_string) == n
    if length_ok:
        print('The length of the random string is ok :)')
    else:
        print('The length of the random string is NOT ok!')


# Generated at 2022-06-21 21:20:57.160149
# Unit test for function secure_random_hex
def test_secure_random_hex():
    a=secure_random_hex(1)
    b=secure_random_hex(2)
    assert len(a)==2
    assert len(b)==4

# Generated at 2022-06-21 21:21:00.609656
# Unit test for function secure_random_hex
def test_secure_random_hex():
    assert(len(secure_random_hex(9)) == 18)
if __name__ == '__main__':
    import pytest
    pytest.main([__file__])
    test_secure_random_hex()

# Generated at 2022-06-21 21:22:50.298969
# Unit test for function random_string
def test_random_string():
    s = random_string(9)
    assert isinstance(s, str)
    assert len(s) == 9

    try:
        random_string(-9)
        assert False
    except ValueError:
        pass  # OK

    try:
        random_string(0)
        assert False
    except ValueError:
        pass  # OK

    try:
        random_string(1.1)
        assert False
    except ValueError:
        pass  # OK



# Generated at 2022-06-21 21:22:52.269347
# Unit test for function secure_random_hex
def test_secure_random_hex():
    size = 64
    result = secure_random_hex(size)
    assert len(result) == size * 2

# Generated at 2022-06-21 21:22:55.443335
# Unit test for function random_string
def test_random_string():
    assert len(random_string(60)) == 60
    assert len(random_string(300)) == 300
    assert len(random_string(1)) == 1

# Generated at 2022-06-21 21:23:06.071815
# Unit test for function uuid
def test_uuid():
    _uuid = uuid()
    assert isinstance(_uuid, str)
    # check that the generated UUID has the right length
    assert len(_uuid) == str(uuid4()).__len__()
    # check that it is all lower case
    assert _uuid.islower()
    # check that it contains only alphanumeric or "-" symbols
    assert _uuid.isalnum() or '-' in _uuid

    _uuid = uuid(as_hex=True)
    assert isinstance(_uuid, str)
    # check that the generated hex UUID has the right length
    assert len(_uuid) == uuid4().hex.__len__()
    # check that it is all lower case
    assert _uuid.islower()
    # check that it contains only hexadecimal digits