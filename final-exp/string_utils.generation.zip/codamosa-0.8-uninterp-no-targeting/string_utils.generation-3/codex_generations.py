

# Generated at 2022-06-21 21:13:25.524413
# Unit test for function uuid
def test_uuid():
    assert type(uuid()) == str
    assert type(uuid(as_hex=True)) == str
    assert len(uuid()) == 36
    assert len(uuid(as_hex=True)) == 32


# Generated at 2022-06-21 21:13:26.553147
# Unit test for function secure_random_hex
def test_secure_random_hex():
    assert isinstance(secure_random_hex(10), str)


# Generated at 2022-06-21 21:13:27.632047
# Unit test for function secure_random_hex
def test_secure_random_hex():
    assert len(secure_random_hex(9)) == 18

# Generated at 2022-06-21 21:13:32.426413
# Unit test for function secure_random_hex
def test_secure_random_hex():
    """
    *Test Case 1:*
    Given byte_count = 1
    When calling the function secure_random_hex
    Then ensure that the output is a string of length = 2
    """
    expected = 2
    actual = len(secure_random_hex(1))
    assert actual == expected

# Test for function roman_range

# Generated at 2022-06-21 21:13:36.839126
# Unit test for function secure_random_hex
def test_secure_random_hex():
    random_hex = secure_random_hex(9)
    assert len(random_hex) == 18
    assert random_hex != secure_random_hex(9)
    assert len(secure_random_hex(10)) == 20



# Generated at 2022-06-21 21:13:38.919221
# Unit test for function uuid
def test_uuid():
    output = uuid()
    assert isinstance(output, str)
    assert len(output) == 36
    assert output.count('-') == 4



# Generated at 2022-06-21 21:13:43.228326
# Unit test for function roman_range
def test_roman_range():

    # given
    start = 1
    stop = 7
    step = 1
    roman_range_generator = roman_range(stop, start, step)
    # when
    i = 0
    for _ in roman_range_generator:
        i += 1
    # then
    assert i == stop - start + 1

# Generated at 2022-06-21 21:13:50.372534
# Unit test for function uuid
def test_uuid():
    assert isinstance(uuid(), str)
    assert isinstance(uuid(as_hex=True), str)

    assert len(uuid(as_hex=True)) == 32
    assert len(uuid()) == 36

    uid = uuid()
    assert uuid(as_hex=True) == uid.replace('-', '')

    # uuids are unique, so test 1000 iterations
    uuids = set()

    for i in range(1000):
        uuid_str = uuid()
        assert uuid_str not in uuids
        uuids.add(uuid_str)


# Generated at 2022-06-21 21:13:55.709518
# Unit test for function roman_range
def test_roman_range():
    assert list(roman_range(5, 2)) == ['II', 'III', 'IV', 'V']
    assert list(roman_range(5, 4)) == ['IV', 'V']
    assert list(roman_range(5, 6)) == []
    assert list(roman_range(5, 5)) == ['V']
    assert list(roman_range(2, 3, -1)) == ['III', 'II']
    assert list(roman_range(3, 5, -1)) == []
    assert list(roman_range(3, 3, -1)) == ['III']


if __name__ == '__main__':
    # Unit test
    test_roman_range()

# Generated at 2022-06-21 21:14:07.983338
# Unit test for function roman_range

# Generated at 2022-06-21 21:14:17.003787
# Unit test for function secure_random_hex
def test_secure_random_hex():
    # test for random string
    for size in range(10,30):
        print(f"size: {size}, str: {secure_random_hex(size)}")
    # test for count > size
    hex_str = secure_random_hex(30)
    assert len(hex_str) == 60
    print(f"size: 30, str: {hex_str}")
    # test for count = size
    hex_str = secure_random_hex(15)
    assert len(hex_str) == 30
    print(f"size: 15, str: {hex_str}")
    # test for count < size
    hex_str = secure_random_hex(5)
    assert len(hex_str) == 10
    print(f"size: 5, str: {hex_str}")
    # test for negative

# Generated at 2022-06-21 21:14:23.460547
# Unit test for function random_string
def test_random_string():
    assert len(random_string(9)) == 9
    assert isinstance(random_string(9), str)
    assert len(random_string(100)) == 100
    assert len(random_string(1)) == 1
    assert len(random_string(0)) == 0

# Generated at 2022-06-21 21:14:34.170853
# Unit test for function roman_range
def test_roman_range():
    roman_range_list = list(roman_range(1, 3999, 1))

# Generated at 2022-06-21 21:14:42.823571
# Unit test for function random_string
def test_random_string():
    from pytest import raises
    from string import ascii_letters, digits
    # Test for invalid values
    with raises(ValueError):
        random_string(0)
    with raises(ValueError):
        random_string(-3)
    # Test for all possible chars
    all_chars = ascii_letters + digits
    all_chars_count = len(all_chars)
    random_str = random_string(10)
    random_str_chars = set(random_str)
    assert len(random_str_chars) == all_chars_count
    assert all_chars_count == len(random_str_chars)
    assert random_str_chars == set(all_chars)

# Generated at 2022-06-21 21:14:45.338317
# Unit test for function random_string
def test_random_string():
    string1 = random_string(10)
    string2 = random_string(10)

    assert len(string1) == 10
    assert len(string2) == 10
    assert type(string1) == str
    assert type(string2) == str
    assert string1 != string2


# Generated at 2022-06-21 21:14:46.804818
# Unit test for function uuid
def test_uuid():
    var = uuid()
    assert var


# Generated at 2022-06-21 21:14:48.149452
# Unit test for function random_string
def test_random_string():
    assert len(random_string(10)) == 10
    assert len(random_string(100)) == 100
    assert len(random_string(1000)) == 1000

# Generated at 2022-06-21 21:14:55.216480
# Unit test for function roman_range
def test_roman_range():
    for n in roman_range(7):
        print(n)
    for n in roman_range(start=7, stop=1, step=-1):
        print(n)
    for n in roman_range(1, 10, 2):
        print(n)
    for n in roman_range(10, 1, -2):
        print(n)


# Generated at 2022-06-21 21:15:05.077598
# Unit test for function roman_range
def test_roman_range():
    assert list(roman_range(7)) == ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII']
    assert list(roman_range(7, start=4)) == ['IV', 'V', 'VI', 'VII']
    assert list(roman_range(7, step=2)) == ['I', 'III', 'V']
    assert list(roman_range(3999, step=3999)) == ['I', 'MMMCMXCIX']
    assert list(roman_range(3999, start=3999)) == ['MMMCMXCIX']
    assert list(roman_range(7, start=7)) == ['VII']
    assert list(roman_range(7, start=7, step=2)) == ['VII']
    assert list(roman_range(7, start=8, step=-2))

# Generated at 2022-06-21 21:15:09.949939
# Unit test for function uuid
def test_uuid():
    expected_len = 36
    assert len(uuid()) == expected_len, "UUID must have {} characters".format(expected_len)
    assert len(uuid(as_hex=True)) == expected_len, "UUID hex must have {} characters".format(expected_len)



# Generated at 2022-06-21 21:15:25.192691
# Unit test for function roman_range
def test_roman_range():

    assert type(roman_range(1,1,1).__next__()) == str
    assert type(list(roman_range(0,0,1))[0]) != str
    assert type(list(roman_range(2,3,3))[0]) != str
    assert list(roman_range(1,1,1))[0] == "I"
    assert type(list(roman_range(10,7,-1))[0]) == str
    assert type(list(roman_range(6,8,1))[0]) == str
    assert type(list(roman_range(2,2,-1))[0]) != str
    assert type(list(roman_range("a",2,1))[0]) != str
    assert type(list(roman_range(1,"a",1))[0]) != str

# Generated at 2022-06-21 21:15:29.993691
# Unit test for function secure_random_hex
def test_secure_random_hex():
    assert len(secure_random_hex(1)) == 2
    assert len(secure_random_hex(2)) == 4
    assert len(secure_random_hex(100)) == 200



# Generated at 2022-06-21 21:15:38.227216
# Unit test for function roman_range
def test_roman_range():
    # should not raise an exception
    for n in roman_range(3):
        pass

    # should raise an exception
    try:
        for n in roman_range(3, start=4):
            pass
        for n in roman_range(4, start=4, step=2):
            pass
        for n in roman_range(4, start=40):
            pass
        for n in roman_range(4, start=40, step=20):
            pass
    except OverflowError:
        pass
    else:
        assert False

# Generated at 2022-06-21 21:15:40.803280
# Unit test for function random_string
def test_random_string():
    assert type(random_string(1)) == str
    assert len(random_string(10)) == 10

# Generated at 2022-06-21 21:15:50.792683
# Unit test for function secure_random_hex
def test_secure_random_hex():
    # test 1: should generate a random hexadecimal string of 8 bytes
    random_str1 = secure_random_hex(8)
    assert isinstance(random_str1, str)
    assert random_str1.isalnum()
    assert len(random_str1) == 16  # 8 bytes = 2 hexadecimal digits per byte => 16 chars in output string

    # test 2: should generate a random hexadecimal string of 32 bytes
    random_str2 = secure_random_hex(32)
    assert isinstance(random_str2, str)
    assert random_str2.isalnum()
    assert len(random_str2) == 64  # 32 bytes = 2 hexadecimal digits per byte => 64 chars in output string


# Generated at 2022-06-21 21:15:57.275582
# Unit test for function roman_range
def test_roman_range():
    '''
    This function tests the function roman_range, it tests the case where 
    the stop, start and step are all positive, the case where step and stop
    are positive but start is negative and the case where stop is positive,
    step is negative but start is positive.
    '''
    assert list(roman_range(stop=16,start=1,step=1)) == ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI', 'XII', 'XIII', 'XIV', 'XV', 'XVI']

# Generated at 2022-06-21 21:16:04.814219
# Unit test for function random_string
def test_random_string():
    random_str = []
    random_str.append(random_string(9))
    random_str.append(random_string(8))
    random_str.append(random_string(7))
    random_str.append(random_string(6))
    random_str.append(random_string(5))

    if len(random_str) == 0:
        return False

    if len(random_str) > 1:
        for i in range(len(random_str)):
            for j in range(len(random_str)):
                if i == j:
                    break
                if random_str[i] == random_str[j]:
                    return False

    return True


# Generated at 2022-06-21 21:16:10.618674
# Unit test for function uuid
def test_uuid():
    print("\n--- Testing function uuid() ---")
    print("Default uuid() returned:")
    print(uuid())
    print("False uuid(as_hex=False) returned:")
    print(uuid(as_hex=False))
    print("True uuid(as_hex=True) returned:")
    print(uuid(as_hex=True))



# Generated at 2022-06-21 21:16:12.370639
# Unit test for function uuid
def test_uuid():
    assert uuid() == '97e3a716-6b33-4ab9-9bb1-8128cb24d76b'
    assert uuid(as_hex=True) == '97e3a7166b334ab99bb18128cb24d76b'



# Generated at 2022-06-21 21:16:15.554580
# Unit test for function roman_range
def test_roman_range():
    output = ''
    for n in roman_range(8):
        print('{} '.format(n))
        output += n
    return {
        'expected': 'I II III IV V VI VII VIII',
        'actual': output
    }

# Generated at 2022-06-21 21:16:32.335921
# Unit test for function roman_range
def test_roman_range():
    # test on values
    for current in roman_range(1, 5, 1):
        assert current == roman_encode(current)

    # test on range
    for current in roman_range(1 + 3*2, 1 + 4*2, 2):
        assert current == roman_encode(current)

    # test on step
    for current in roman_range(1, 6, 2):
        assert current == roman_encode(current)

    # test on boundaries
    for current in roman_range(1, 1, 1):
        assert current == roman_encode(current)

    for current in roman_range(3999, 3999, 1):
        assert current == roman_encode(current)

    for current in roman_range(9999, 1, -1):
        assert current

# Generated at 2022-06-21 21:16:44.311889
# Unit test for function random_string

# Generated at 2022-06-21 21:16:45.746289
# Unit test for function uuid
def test_uuid():
    assert len(uuid()) == 36
    assert len(uuid(as_hex=True)) == 32


# Generated at 2022-06-21 21:16:58.565083
# Unit test for function random_string
def test_random_string():
    randStr = random_string(10)

    assert( len(randStr) == 10 )
    assert( randStr[0].isalpha() )
    assert( randStr[1].isalpha() )
    assert( randStr[2].isalpha() )
    assert( randStr[3].isalpha() )
    assert( randStr[4].isalpha() )
    assert( randStr[5].isalpha() )
    assert( randStr[6].isalpha() )
    assert( randStr[7].isalpha() )
    assert( randStr[8].isalpha() )
    assert( randStr[9].isalpha() )

    randStr = random_string(25)

    assert( len(randStr) == 25 )
    assert( randStr[0].isalpha() )

# Generated at 2022-06-21 21:17:00.873126
# Unit test for function uuid
def test_uuid():
    out = uuid()
    assert isinstance(out, str)
    assert len(out) == 36

    out = uuid(as_hex=True)
    assert isinstance(out, str)
    assert len(out) == 32



# Generated at 2022-06-21 21:17:12.688555
# Unit test for function roman_range
def test_roman_range():
   # Testing roman number generation
    assert roman_range(5) == [1,2,3,4,5]
    assert roman_range(10,5) == [5,6,7,8,9,10]
    assert roman_range(21, 12) == [12,13,14,15,16,17,18,19,20,21]
    assert roman_range(1,10, -1) == [10,9,8,7,6,5,4,3,2,1]
    assert roman_range(15,10,-2) == [10,8,6,4,2]
    # Testing error handling
   # testing for stop value out of range (3999)
    assert roman_range(-1) == "\"stop\" must be an integer in the range 1-3999"

# Generated at 2022-06-21 21:17:15.585958
# Unit test for function uuid
def test_uuid():
    assert(len(uuid()) == 36)
    assert(len(uuid(as_hex=True)) == 32)
    assert(uuid() != uuid())


# Generated at 2022-06-21 21:17:19.712214
# Unit test for function random_string
def test_random_string():
    import pytest
    string_length = 3
    s = random_string(string_length)
    assert len(s) == string_length
    assert isinstance(s, str)


# Generated at 2022-06-21 21:17:22.107389
# Unit test for function uuid
def test_uuid():
    uid = uuid()
    assert isinstance(uid, str)
    assert len(uid) == 36


# Generated at 2022-06-21 21:17:32.059867
# Unit test for function roman_range
def test_roman_range():
    assert list(roman_range(stop=3)) == ['I', 'II', 'III']
    assert list(roman_range(stop=10, start=7)) == ['VII', 'VIII', 'IX', 'X']
    assert list(roman_range(stop=5, start=10, step=-1)) == ['X', 'IX', 'VIII', 'VII', 'VI', 'V']
    assert list(roman_range(stop=3999, start=1)) == [roman_encode(i) for i in range(1, 4000)]

# Generated at 2022-06-21 21:17:48.788722
# Unit test for function uuid
def test_uuid():
    uid = uuid()
    assert len(uid) == 36
    assert '-' in uid

    uid_hex = uuid(as_hex=True)
    assert len(uid_hex) == 32
    assert '-' not in uid_hex



# Generated at 2022-06-21 21:17:52.260815
# Unit test for function roman_range
def test_roman_range():
    expected_list = [1, 2, 3, 4, 5, 6, 7]
    roman_list = []
    for n in roman_range(7):
        roman_list.append(n)
    assert expected_list == roman_list

# Generated at 2022-06-21 21:18:02.268613
# Unit test for function roman_range
def test_roman_range():
    assert roman_range(1) == 'I' 
    assert roman_range(2) == 'II' 
    assert roman_range(3) == 'III'
    assert roman_range(4) == 'IV'
    assert roman_range(5) == 'V'
    assert roman_range(6) == 'VI'
    assert roman_range(7) == 'VII'
    assert roman_range(8) == 'VIII'
    assert roman_range(9) == 'IX'
    assert roman_range(10) == 'X'
    assert roman_range(11) == 'XI'
    assert roman_range(12) == 'XII'
    assert roman_range(13) == 'XIII'

# Generated at 2022-06-21 21:18:14.122928
# Unit test for function secure_random_hex
def test_secure_random_hex():
    # JUnit test for random string
    import unittest
    import time

    class TestSecureRandomHex(unittest.TestCase):
        def test_1(self):
            # Test if the function secure_random_hex generates the same string
            s = secure_random_hex(2)
            s2 = secure_random_hex(2)

            if s == s2:
                self.fail("secure_random_hex generates the same number twice")

        def test_2(self):
            # Test if the function secure_random_hex generates the same string
            s = secure_random_hex(1)
            s2 = secure_random_hex(1)

            if s == s2:
                self.fail("secure_random_hex generates the same number twice")


# Generated at 2022-06-21 21:18:17.386909
# Unit test for function roman_range
def test_roman_range():
    x = roman_range(8, start=4, step=4)
    for i in x:
        print(i)

# Generated at 2022-06-21 21:18:23.123044
# Unit test for function uuid
def test_uuid():
    uid = uuid()
    assert len(uid) == 36
    assert uid.count('-') == 4
    assert uid.lower() == uid

    uid = uuid(as_hex=True)
    assert len(uid) == 32
    assert uid.count('-') == 0
    assert uid.lower() == uid


# Generated at 2022-06-21 21:18:25.148080
# Unit test for function uuid
def test_uuid():
    assert isinstance(uuid(), str)
    assert isinstance(uuid(as_hex=True), str)



# Generated at 2022-06-21 21:18:28.964175
# Unit test for function random_string
def test_random_string():
    # Generate a random string of length 10
    random_string = ''.join([random.choice(string.ascii_letters + string.digits) for n in range(10)])
    assert len(random_string) == 10

# Generated at 2022-06-21 21:18:29.876131
# Unit test for function uuid
def test_uuid():
    assert len(uuid()) == 36


# Generated at 2022-06-21 21:18:31.861598
# Unit test for function random_string
def test_random_string():
    print(random_string(8))
    print(random_string(9))
    print(random_string(9))


# Generated at 2022-06-21 21:19:02.752910
# Unit test for function uuid
def test_uuid():
    assert isinstance(uuid(), str)
    assert isinstance(uuid(as_hex=True), str)
    assert len(uuid()) == 36
    assert len(uuid(as_hex=True)) == 32
    assert uuid() != uuid()
    assert uuid(as_hex=True) != uuid(as_hex=True)



# Generated at 2022-06-21 21:19:10.642096
# Unit test for function secure_random_hex
def test_secure_random_hex():

    def _test_length(byte_count: int) -> (bool, str):
        """ Test if the generated string respects the requested length """

        expected_length = byte_count * 2
        output = secure_random_hex(byte_count)
        result = len(output) == expected_length

        if not result:
            msg = 'expecting length {}, received length {}'.format(expected_length, len(output))
        else:
            msg = ''

        return result, msg

    def _test_hex_format(byte_count: int) -> (bool, str):
        """ Test if the result is a valid hexadecimal string """
        output = secure_random_hex(byte_count)
        result = all(c in string.hexdigits for c in output)


# Generated at 2022-06-21 21:19:11.589075
# Unit test for function secure_random_hex
def test_secure_random_hex():
    test_len = 100
    secure_random_hex(test_len)


# Generated at 2022-06-21 21:19:22.457534
# Unit test for function roman_range
def test_roman_range():
    import unittest

    class RomanRangeTestCase(unittest.TestCase):
        def test_stop_less_than_start_1(self):
            with self.assertRaises(OverflowError):
                [x for x in roman_range(4, 10)]
            
        def test_stop_less_than_start_2(self):
            with self.assertRaises(OverflowError):
                [x for x in roman_range(1, 10, -1)]

        def test_1_exceed(self):
            with self.assertRaises(ValueError):
                [x for x in roman_range(0)]

        def test_2_exceed(self):
            with self.assertRaises(ValueError):
                [x for x in roman_range(4000)]
            

# Generated at 2022-06-21 21:19:26.450153
# Unit test for function random_string
def test_random_string():
    assert (len(random_string(1)) == 1)
    assert (len(random_string(5)) == 5)
    assert (len(random_string(9)) == 9)
    assert (len(random_string(19)) == 19)
    assert (len(random_string(99)) == 99)
    assert (len(random_string(999)) == 999)

# Generated at 2022-06-21 21:19:33.177579
# Unit test for function roman_range
def test_roman_range():
    print("\n")
    print("-"*20)
    print("Testing roman_range")
    r = roman_range(7)
    for i in r:
        print(i)
    print("-"*20)
    print("Testing roman_range")
    r = roman_range(start=7, stop=1, step=-1)
    for i in r:
        print(i)
    print("-"*20)

if __name__ == '__main__':
    test_roman_range()

# Generated at 2022-06-21 21:19:38.879010
# Unit test for function uuid
def test_uuid():
    assert isinstance(uuid(), str)
    assert isinstance(uuid(as_hex=True), str)
    assert len(uuid()) == 36
    assert len(uuid(as_hex=True)) == 32
    assert uuid() != uuid()
    assert uuid(as_hex=True) != uuid(as_hex=True)


# Generated at 2022-06-21 21:19:42.873425
# Unit test for function random_string
def test_random_string():
    string_1 = random_string(9)
    string_2 = random_string(9)
    assert len(string_1) == 9
    assert string_1 != string_2

# Generated at 2022-06-21 21:19:46.265554
# Unit test for function uuid
def test_uuid():
    out = uuid()
    assert isinstance(out, str)
    assert len(out) == 36
    assert out.count('-') == 4

    out = uuid(as_hex=True)
    assert isinstance(out, str)
    assert len(out) == 32
    assert out.count('-') == 0


# Generated at 2022-06-21 21:19:50.420560
# Unit test for function secure_random_hex
def test_secure_random_hex():
    s = secure_random_hex(2)
    print(s, len(s))
    assert len(s) == 4

if __name__ == '__main__':
    test_secure_random_hex()

# Generated at 2022-06-21 21:20:41.960514
# Unit test for function random_string
def test_random_string():
    assert(len(random_string(100)) == 100)


# Generated at 2022-06-21 21:20:43.737716
# Unit test for function random_string
def test_random_string():
    string = random_string(9)
    if not isinstance(string, str):
        raise ValueError('random_string must return a string')


# Generated at 2022-06-21 21:20:46.028680
# Unit test for function secure_random_hex
def test_secure_random_hex():
    r = secure_random_hex(16)
    assert len(r) == 32

# Generated at 2022-06-21 21:20:54.720682
# Unit test for function roman_range
def test_roman_range():
    # Checks each possible step increment
    for step in range(-3999, 3999):
        # Generates a number of values to iterate
        for count in range(1, 100):
            # Generates stop value using the count and a random number
            stop = random.randint(1, 3999) * count
            # Creates the generator
            gen = roman_range(stop=stop, step=step)

            # Creates a list to store the expected values
            expected = []
            current = stop if step >= 0 else 1
            # Generates the expected values
            while current >= 1 and current <= 3999:
                expected.append(roman_encode(current))
                current -= step

            # Checks if the generated values are in the expected ones
            for value in gen:
                assert value in expected
                
    # Checks invalid start, stop

# Generated at 2022-06-21 21:20:55.463118
# Unit test for function random_string
def test_random_string():
    if random_string(9) != random_string(9):
        print("random_string fails")


# Generated at 2022-06-21 21:20:57.452653
# Unit test for function uuid
def test_uuid():
    for _ in range(100):
        assert isinstance(uuid(), str)
        assert isinstance(uuid(as_hex=True), str)
        assert len(uuid()) == 36
        assert len(uuid(as_hex=True)) == 32


# Generated at 2022-06-21 21:20:58.994045
# Unit test for function uuid
def test_uuid():
    assert isinstance(uuid(False),str)


# Generated at 2022-06-21 21:21:01.464833
# Unit test for function uuid
def test_uuid():
    assert len(uuid(as_hex=False)) >= 1
    assert len(uuid(as_hex=True)) >= 1


# Generated at 2022-06-21 21:21:08.969220
# Unit test for function secure_random_hex
def test_secure_random_hex():
    from random import randint
    from unittest import TestCase
    from uuid import uuid4
    from collections import Counter

    class TestSecureRandomHex(TestCase):
        def test_returned_length(self):
            """
            Tests that the return string length is twice the number of bytes of generated randomness.
            """
            for _ in range(100):
                byte_count = randint(1, 100)
                hex_string = secure_random_hex(byte_count)
                self.assertEqual(len(hex_string), byte_count * 2)

        def test_equivalent_random(self):
            """
            Tests that using the python random module with the same bytecount, produces a different output.
            """
            for _ in range(100):
                byte_count = randint(1, 100)
               

# Generated at 2022-06-21 21:21:11.358886
# Unit test for function uuid
def test_uuid():
    assert(isinstance(uuid(), str))
    assert(isinstance(uuid(as_hex=True), str))


# Generated at 2022-06-21 21:22:58.649817
# Unit test for function secure_random_hex
def test_secure_random_hex():
    assert secure_random_hex(1)

# Generated at 2022-06-21 21:23:01.269589
# Unit test for function uuid
def test_uuid():
    assert isinstance(uuid(), str) and 36 == len(uuid())
    assert isinstance(uuid(as_hex=True), str) and 32 == len(uuid(as_hex=True))


# Generated at 2022-06-21 21:23:06.031377
# Unit test for function random_string
def test_random_string():
    assert random_string(1) == 'U'
    assert random_string(9) == 'HVNu0YwO1'
    assert random_string(10) == 'GcX9eT1r6g'
