

# Generated at 2022-06-21 21:13:27.287331
# Unit test for function secure_random_hex
def test_secure_random_hex():
    assert secure_random_hex(4)
    assert secure_random_hex(8)
    assert len(secure_random_hex(4)) == 8
    assert len(secure_random_hex(8)) == 16
    assert len(secure_random_hex(2)) == 4
    assert len(secure_random_hex(1)) == 2

# Generated at 2022-06-21 21:13:30.413612
# Unit test for function random_string
def test_random_string():
    i = 0
    for i in range(100):
        assert isinstance(random_string(10), str)
        assert len(random_string(10)) == 10
    assert i == 99


test_random_string()

# Generated at 2022-06-21 21:13:32.099505
# Unit test for function uuid
def test_uuid():
    assert len(uuid()) == 38
    assert len(uuid(as_hex=True)) == 32

    # 100% branch coverage
    assert len(uuid(as_hex=False)) == 38


# Generated at 2022-06-21 21:13:35.506067
# Unit test for function uuid
def test_uuid():
    assert (uuid()) == '97e3a716-6b33-4ab9-9bb1-8128cb24d76b'


# Generated at 2022-06-21 21:13:39.588114
# Unit test for function uuid
def test_uuid():
    uid = uuid()
    assert isinstance(uid, str)
    assert len(uid) == 36
    assert uid[14] == '4'

    uid = uuid(as_hex=True)
    assert isinstance(uid, str)
    assert len(uid) == 32
    assert uid[4] == '7'


# Generated at 2022-06-21 21:13:41.227243
# Unit test for function random_string
def test_random_string():
    result = random_string(30)
    assert len(result) == 30


# Generated at 2022-06-21 21:13:42.574478
# Unit test for function random_string
def test_random_string():
    assert(len(random_string(15)) == 15)

# Generated at 2022-06-21 21:13:44.402777
# Unit test for function uuid
def test_uuid():
    print(__name__)
    print(uuid())
    print(uuid(as_hex=True))

# Generated at 2022-06-21 21:13:46.087309
# Unit test for function random_string
def test_random_string():
    len_str = random_string(8)
    assert len(len_str) == 8


# Generated at 2022-06-21 21:13:47.430202
# Unit test for function random_string
def test_random_string():
    assert random_string(1)
    assert not random_string(0)


# Generated at 2022-06-21 21:13:55.043345
# Unit test for function uuid
def test_uuid():
    assert(uuid())


# Generated at 2022-06-21 21:14:07.314074
# Unit test for function roman_range
def test_roman_range():
    assert list(roman_range(7)) == ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII']
    assert list(roman_range(3999)) == ['MMMCMXCIX']
    assert list(roman_range(start=7, stop=1, step=-1)) == ['VII', 'VI', 'V', 'IV', 'III', 'II', 'I']

# Generated at 2022-06-21 21:14:12.241791
# Unit test for function uuid
def test_uuid():
    u1 = uuid(as_hex=True)
    assert(len(u1) == 32)
    assert(isinstance(u1, str))

    u2 = uuid(as_hex=False)
    assert (len(u2) == 36)
    assert (isinstance(u2, str))

    assert (u1 == u2.replace('-', ''))


# Generated at 2022-06-21 21:14:15.249276
# Unit test for function roman_range
def test_roman_range():
    for n in roman_range(start=-1):
        print(n)


# Generated at 2022-06-21 21:14:18.032960
# Unit test for function secure_random_hex
def test_secure_random_hex():
    random_str = secure_random_hex(1)
    assert len(random_str) == 2
    random_str = secure_random_hex(128)
    assert len(random_str) == 256

# Generated at 2022-06-21 21:14:23.356916
# Unit test for function secure_random_hex
def test_secure_random_hex():
    for i in range(100):
        print(secure_random_hex(5))


if __name__ == "__main__":
    test_secure_random_hex()

# Generated at 2022-06-21 21:14:34.020549
# Unit test for function secure_random_hex
def test_secure_random_hex():
    # DESCRIPTION
    # secure_random_hex takes an argument (int) and returns a string of (int) length
    # with the input being a lower bound on the output string length, the returned string can only be positive
    # for every input n: n <= output < n+1

    # ASSERTIONS
    assert len(secure_random_hex(1)) > 1, "Secure random hex is less than 1 byte"
    assert isinstance(secure_random_hex(1), str), "Secure random hex is not a string"
    assert len(secure_random_hex(1)) >= 1, "Secure random hex output is smaller than the input"
    assert len(secure_random_hex(1)) <= 2, "Secure random hex output is larger than the input + 1"

# Generated at 2022-06-21 21:14:37.520641
# Unit test for function roman_range
def test_roman_range():
    for n in roman_range(7):
        pass
    for n in roman_range(start=7, stop=1, step=-1):
        pass

# Generated at 2022-06-21 21:14:44.830482
# Unit test for function roman_range
def test_roman_range():
    range_values = [
        ('i', 'i'),
        ('i-xx', 'i, ii, iii, iv, v, vi, vii, viii, ix, x'),
        ('iii', 'iii'),
        ('vv-vi', 'v, vi'),
        ('vvi-vi', 'vii, viii, ix, x, xi, xii, xiii, xiv, xv')
    ]

    for expr, expected in range_values:
        start, stop = expr.split('-') if '-' in expr else [expr, expr]
        try:
            output = list(roman_range(roman_encode(stop, False), roman_encode(start, False)))
            output = ','.join(output)
            assert output == expected
        except:
            print(exception)


# Generated at 2022-06-21 21:14:55.978604
# Unit test for function roman_range
def test_roman_range():
    assert list(roman_range(10)) == ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X']
    assert list(roman_range(10, step=2)) == ['I', 'III', 'V', 'VII', 'IX']
    assert list(roman_range(100, start=90)) == ['XC', 'XCI', 'XCII', 'XCIII', 'XCIV', 'XCV', 'XCVI', 'XCVII', 'XCVIII', 'XCIX']
    assert list(roman_range(9, step=-1)) == ['IX', 'VIII', 'VII', 'VI', 'V', 'IV', 'III', 'II', 'I']

# Generated at 2022-06-21 21:15:07.501708
# Unit test for function roman_range
def test_roman_range():

    # Test forward iteration
    rng = roman_range(7)
    assert next(rng) == 'I'
    assert next(rng) == 'II'
    assert next(rng) == 'III'
    assert next(rng) == 'IV'
    assert next(rng) == 'V'
    assert next(rng) == 'VI'
    assert next(rng) == 'VII'

    # Test backward iteration
    rng = roman_range(start=7, stop=1, step=-1)
    assert next(rng) == 'VII'
    assert next(rng) == 'VI'
    assert next(rng) == 'V'
    assert next(rng) == 'IV'
    assert next(rng) == 'III'

# Generated at 2022-06-21 21:15:17.747336
# Unit test for function random_string
def test_random_string():
    letter_count = 4
    digit_count = 4
    size = letter_count + digit_count
    s = random_string(size)

    if len(s) != size:
        raise Exception("random_string() failed: wrong size")

    if s.isalpha() or s.isdigit():
        raise Exception("random_string() failed: random string not alphanumeric")

    letter_sum = sum([letter.isalpha() for letter in s])
    digit_sum = sum([digit.isdigit() for digit in s])
    if letter_sum != letter_count or digit_sum != digit_count:
        raise Exception("random_string() failed: random string does not contain " + str(letter_count) + " letters and " + str(digit_count) + " digits")


# Generated at 2022-06-21 21:15:19.997242
# Unit test for function random_string
def test_random_string():
    assert isinstance(random_string(9), str)
    assert len(random_string(9)) == 9

# Generated at 2022-06-21 21:15:22.011496
# Unit test for function uuid
def test_uuid():
    result = uuid(as_hex=True)
    assert type(result) == str
    assert len(result) == 32


# Generated at 2022-06-21 21:15:24.592957
# Unit test for function uuid
def test_uuid():
    assert uuid(as_hex=True) == uuid4().hex



# Generated at 2022-06-21 21:15:28.982490
# Unit test for function roman_range
def test_roman_range():
    for x in roman_range(1, 7):
        print(x)


if __name__ == "__main__":
    test_roman_range()

# Generated at 2022-06-21 21:15:40.229716
# Unit test for function roman_range
def test_roman_range():

    # Test case 1
    stop = 7
    start = 1
    step = 1
    result = []
    for i in roman_range(stop, start, step):
        result.append(i)
    if result != ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII']:
        print("Test case 1 didn't pass")

    # Test case 2
    stop = 1
    start = 7
    step = -1
    result = []
    for i in roman_range(stop, start, step):
        result.append(i)
    if result != ['VII', 'VI', 'V', 'IV', 'III', 'II', 'I']:
        print("Test case 2 didn't pass")

# Call function test_roman_range()
# TODO: call function test_roman_range

# Generated at 2022-06-21 21:15:42.950262
# Unit test for function random_string
def test_random_string():
    string = random_string(9)
    assert len(string) == 9
    print("test_random_string passed")



# Generated at 2022-06-21 21:15:47.153824
# Unit test for function uuid
def test_uuid():
    assert(isinstance(uuid(), str))
    assert(len(uuid()) == 36)
    assert(isinstance(uuid(True), str))
    assert(len(uuid(True)) == 32)


# Generated at 2022-06-21 21:15:51.099842
# Unit test for function uuid
def test_uuid():
    uid = uuid()
    assert len(uid) == 36
    assert uid.count('-') == 4

    uid = uuid(True)
    assert len(uid) == 32
    assert len(uid.split('-')) == 1

assert uuid() != uuid()


# Generated at 2022-06-21 21:15:57.872356
# Unit test for function random_string
def test_random_string():
    assert len(random_string(9)) == 9
    assert isinstance(random_string(9), str)

# Generated at 2022-06-21 21:16:00.890371
# Unit test for function uuid
def test_uuid():
    assert uuid() != uuid()
    assert len(uuid(as_hex=False)) == 36
    assert len(uuid(as_hex=True)) == 32


# Generated at 2022-06-21 21:16:01.748209
# Unit test for function secure_random_hex
def test_secure_random_hex():
    random_string(9)

# Generated at 2022-06-21 21:16:05.659386
# Unit test for function random_string
def test_random_string():
    size = 9
    random_str = random_string(size)
    assert(len(random_str) == size)


# Generated at 2022-06-21 21:16:09.450105
# Unit test for function secure_random_hex
def test_secure_random_hex():
    from string import hexdigits
    res = secure_random_hex(16)
    assert len(res) == 32
    for i in res:
        assert i in hexdigits
        return True

if __name__ == '__main__':
    test_secure_random_hex()

# Generated at 2022-06-21 21:16:14.456549
# Unit test for function roman_range
def test_roman_range():
    list_romans = [
        'I',
        'II',
        'III',
        'IV',
        'V',
        'VI',
        'VII',
        'VIII',
        'IX',
        'X'
    ]
    counter = 0
    for i in roman_range(1, 10, 1):
        assert i == list_romans[counter]
        counter += 1

# Generated at 2022-06-21 21:16:21.712745
# Unit test for function secure_random_hex
def test_secure_random_hex():
    """
    Tests secure_random_hex function with the following assertion:
    the returned string size should be exactly the double of first argument,
    i.e. the number of random bytes to generate

    :return: None
    """
    assert len(secure_random_hex(1)) == 2
    assert len(secure_random_hex(2)) == 4
    assert len(secure_random_hex(3)) == 6
    assert len(secure_random_hex(4)) == 8
    assert len(secure_random_hex(5)) == 10
    assert len(secure_random_hex(6)) == 12
    assert len(secure_random_hex(7)) == 14
    assert len(secure_random_hex(8)) == 16
    assert len(secure_random_hex(9)) == 18

# Generated at 2022-06-21 21:16:23.671058
# Unit test for function secure_random_hex
def test_secure_random_hex():
    assert len(secure_random_hex(1)) == 2
    assert len(secure_random_hex(2)) == 4
    assert len(secure_random_hex(16)) == 32
    assert len(secure_random_hex(1024)) == 2048


# Generated at 2022-06-21 21:16:25.670499
# Unit test for function uuid
def test_uuid():
    should_be_true = True
    print(should_be_true)


# Generated at 2022-06-21 21:16:27.237928
# Unit test for function random_string
def test_random_string():
    random_string('test')

test_random_string()

# Generated at 2022-06-21 21:16:42.288776
# Unit test for function secure_random_hex
def test_secure_random_hex():
    assert secure_random_hex(2) == 'b18e711a8fc9'

# Generated at 2022-06-21 21:16:45.241361
# Unit test for function roman_range
def test_roman_range():
    for n in roman_range(7):
        print(n)
    print(list(roman_range(7)))
    print(list(roman_range(start=7, stop=1, step=-1)))
# End of unit test

# Generated at 2022-06-21 21:16:58.046576
# Unit test for function roman_range
def test_roman_range():
    assert list(roman_range(10)) == ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X']
    assert list(roman_range(10, 1, 2)) == ['I', 'III', 'V', 'VII', 'IX']
    assert list(roman_range(15, 10, 1)) == ['X', 'XI', 'XII', 'XIII', 'XIV', 'XV']
    assert list(roman_range(1, 10, -1)) == ['X', 'IX', 'VIII', 'VII', 'VI', 'V', 'IV', 'III', 'II', 'I']

# Generated at 2022-06-21 21:17:01.791036
# Unit test for function roman_range
def test_roman_range():

    print("---------- Unit test for function roman_range -----------")
    # Initialise the variables
    step = 1
    start = 1
    stop = 6

    # Print the roman numbers based on the range
    print("The roman numbers based on the range are :")
    for item in roman_range(stop,start,step):
        print(item)

    print("\n The program has been successfully tested -------------------- \n")


# The main function

# Generated at 2022-06-21 21:17:06.537163
# Unit test for function random_string
def test_random_string():

    for i in range(1, 10):
        # calls generator and tests its length
        # noinspection PyTypeChecker
        assert len(random_string(i)) == i



# Generated at 2022-06-21 21:17:11.297232
# Unit test for function uuid
def test_uuid():
    random_str = uuid(as_hex=False)
    assert len(random_str) == 36
    assert random_str[14] == '-'
    assert random_str[19] == '-'
    assert random_str[24] == '-'

    random_int = uuid(as_hex=True)
    assert len(random_int) == 32


# Generated at 2022-06-21 21:17:20.549068
# Unit test for function secure_random_hex
def test_secure_random_hex():
    assert len(secure_random_hex(8)) == 16
    assert len(secure_random_hex(1)) == 2
    assert len(secure_random_hex(0)) == 0
    assert secure_random_hex(8) != secure_random_hex(8)
    assert secure_random_hex(8).isalnum()
    assert secure_random_hex(0).isalnum()
    assert secure_random_hex(1).isalnum()
    assert secure_random_hex(1) in '0123456789abcdef'
    assert secure_random_hex(8) in string.hexdigits

# Generated at 2022-06-21 21:17:34.211175
# Unit test for function secure_random_hex
def test_secure_random_hex():
    from pprint import pprint
    from collections import Counter

    def test(size, count):
        print('Testing {} -> secure_random_hex({}):'.format(count, size))

        chars = string.ascii_letters + string.digits
        chars = set(chars)
        chars = list(chars)
        chars.sort()

        counter = Counter()

        for _ in range(count):
            actual = secure_random_hex(size)
            assert len(actual) == size*2
            actual = list(actual)
            actual.sort()

            # print('"{}"'.format(actual))
            counter.update(actual)

        print('Result:')
        pprint(counter)

    test(1, 100)
    test(2, 1000)
    test(3, 5000)

# Generated at 2022-06-21 21:17:36.889063
# Unit test for function secure_random_hex
def test_secure_random_hex():
    assert len(secure_random_hex(9)) == 18

if __name__ == '__main__':
    test_secure_random_hex()

# Generated at 2022-06-21 21:17:40.237190
# Unit test for function secure_random_hex
def test_secure_random_hex():
    assert len(secure_random_hex(1)) == 2
    assert len(secure_random_hex(2)) == 4
    assert len(secure_random_hex(16)) == 32
    assert len(secure_random_hex(32)) == 64


# Generated at 2022-06-21 21:18:12.978713
# Unit test for function secure_random_hex
def test_secure_random_hex():
    assert len(secure_random_hex(256)) == 256*2
    assert len(secure_random_hex(300)) == 300*2
    assert len(secure_random_hex(2)) == 2*2
    assert len(secure_random_hex(1)) == 1*2



# Generated at 2022-06-21 21:18:19.668762
# Unit test for function uuid
def test_uuid():
    for i in range(0, 100):
        u = uuid()
        assert len(u) == 36
        assert u[8] == '-' and u[13] == '-' and u[18] == '-' and u[23] == '-'
        assert u[14] in "89ab"
        u = uuid(as_hex=True)
        assert len(u) == 32


# Generated at 2022-06-21 21:18:21.513958
# Unit test for function random_string
def test_random_string():
    assert len(random_string(1)) == 1
    assert len(random_string(123)) == 123


# Generated at 2022-06-21 21:18:27.651598
# Unit test for function roman_range
def test_roman_range():
    #Test the forward iteration to stop
    n1 = roman_range(7)
    assert(next(n1) == "I")
    assert(next(n1) == "II")
    assert(next(n1) == "III")
    assert(next(n1) == "IV")
    assert(next(n1) == "V")
    assert(next(n1) == "VI")
    assert(next(n1) == "VII")
    # Test the backward iteration to stop
    n2 = roman_range(start=7, stop=1, step=-1)
    assert (next(n2) == "VII")
    assert (next(n2) == "VI")
    assert (next(n2) == "V")
    assert (next(n2) == "IV")

# Generated at 2022-06-21 21:18:35.950376
# Unit test for function roman_range
def test_roman_range():
    # Test the function roman_range with the given examples
    count = 0
    print('Testing with the given examples')
    for n in roman_range(7):
        print(n)
        count += 1
        if count >= 6:
            break

    count = 0
    for n in roman_range(start=7, stop=1, step=-1):
        print(n)
        count += 1
        if count >= 6:
            break

    count = 0
    for n in roman_range(start=7, stop=1, step=1):
        print(n)
        count += 1
        if count >= 6:
            break

    print('Test the function with start > stop and step > 0')

# Generated at 2022-06-21 21:18:42.868294
# Unit test for function random_string
def test_random_string():
    assert len(random_string(3)) == 3
    assert len(random_string(4)) == 4
    assert len(random_string(5)) == 5
    assert len(random_string(6)) == 6
    assert len(random_string(7)) == 7
    assert len(random_string(8)) == 8
    assert len(random_string(9)) == 9


# Generated at 2022-06-21 21:18:44.339618
# Unit test for function random_string
def test_random_string():
    assert random_string(1) == 'b'


# Generated at 2022-06-21 21:18:52.451456
# Unit test for function secure_random_hex
def test_secure_random_hex():
    # First generate a number at random, then use the function and finally compare the two strings
    # (this is not a 100% guarantee of the correctness of the function, but it's close enough)
    size = random.randint(1, 10000)
    random_string = ''.join(random.choice(string.ascii_letters + string.digits) for i in range(size))
    generated_string = secure_random_hex(size)
    assert len(generated_string) == size*2, 'The generated string must be double the size of the number'
    assert random_string != generated_string, 'The generated string must not be equal to the random string'

if __name__ == '__main__':
    test_secure_random_hex()

# Generated at 2022-06-21 21:18:55.620624
# Unit test for function secure_random_hex
def test_secure_random_hex():
    for n in range(1, 100):
        for size in range (1, 100):
            s = secure_random_hex(size)
            assert len(s) == 2 * size

# Generated at 2022-06-21 21:19:03.971102
# Unit test for function secure_random_hex
def test_secure_random_hex():
    s = secure_random_hex(3)
    assert len(s) == 6
    assert isinstance(s, str)

    try:
        s = secure_random_hex(0)
        assert False, 'Should have raised ValueError because 0 bytes is not a valid value'
    except ValueError:
        pass

    try:
        s = secure_random_hex(10.3)
        assert False, 'Should have raised ValueError because only integers are supported'
    except ValueError:
        pass


# Generated at 2022-06-21 21:20:02.672142
# Unit test for function roman_range
def test_roman_range():
    r_list = list(roman_range(start=-123, step=-7, stop=-321))
    assert r_list == ['CXXIII', 'CCLXXIII', 'CCCXLVII', 'CCCXXIII', 'CCXCV', 'CCLXXIII', 'CLXXV', 'CXXIII', 'XLVII',
                      'VIII', 'XXXV', 'LXII']

    total_list = []
    for _ in range(100):
        total_list.extend(roman_range(-100, 100))
    assert len(set(total_list)) == 401


# Generated at 2022-06-21 21:20:06.341537
# Unit test for function secure_random_hex
def test_secure_random_hex():
    a = secure_random_hex(4)
    print("length:", len(a), "Random number generated: ", a)
    assert len(a) == 8, "secure_random_hex should return a string with length 8"


# Generated at 2022-06-21 21:20:10.719852
# Unit test for function uuid
def test_uuid():
    from tests.util import generate_rand_string
    try:
        uuid()
        uuid(as_hex=True)
        print('Function uuid() works properly')
    except Exception as e:
        print('Function uuid() does not work properly because ' + str(e))


# Generated at 2022-06-21 21:20:15.201522
# Unit test for function secure_random_hex
def test_secure_random_hex():
    hex_string = secure_random_hex(9)
    assert(len(hex_string) == 18)
    for i in range(len(hex_string)):
        assert('0' <= hex_string[i] <= '9' or 'a' <= hex_string[i] <= 'f')

# Generated at 2022-06-21 21:20:19.578550
# Unit test for function uuid
def test_uuid():
    assert isinstance(uuid(), str)
    assert isinstance(uuid(as_hex=True), str)
    assert len(uuid()) == 36
    assert len(uuid(as_hex=True)) == 32



# Generated at 2022-06-21 21:20:23.113588
# Unit test for function uuid
def test_uuid():
    print(uuid())
    print(uuid(as_hex=True))


# Generated at 2022-06-21 21:20:27.670244
# Unit test for function random_string
def test_random_string():
    for i in range(1000):
        assert isinstance(random_string(i), str)
        assert len(random_string(i)) == i
    is_true = False
    try:
        random_string('a')
    except ValueError:
        is_true = True
    assert is_true
    is_true = False
    try:
        random_string(0)
    except ValueError:
        is_true = True
    assert is_true

# Generated at 2022-06-21 21:20:36.857006
# Unit test for function roman_range
def test_roman_range():
    s = set()
    for n in roman_range(7):
        print(n)
        s.add(n)
    assert s == {'I', 'II', 'III', 'IV', 'V', 'VI', 'VII'}
    s.clear()
    for n in roman_range(start=7, stop=1, step=-1):
        print(n)
        s.add(n)
    assert s == {'VII', 'VI', 'V', 'IV', 'III', 'II', 'I'}

# Generated at 2022-06-21 21:20:39.682974
# Unit test for function uuid
def test_uuid():
    assert len(uuid()) == 36
    assert len(uuid()) == 36
    assert len(uuid(as_hex=True)) == 32
    assert len(uuid(as_hex=True)) == 32


# Generated at 2022-06-21 21:20:41.716235
# Unit test for function uuid
def test_uuid():
    u=uuid()
    assert (u is not None)


# Generated at 2022-06-21 21:22:38.771546
# Unit test for function random_string
def test_random_string():
    s = random_string(8)
    assert len(s) == 8
    print(s)


# Generated at 2022-06-21 21:22:50.299087
# Unit test for function secure_random_hex
def test_secure_random_hex():
    print("Running function test_secure_random_hex...")
    try:
        secure_random_hex(-1)
        print("Error: Did not raise error with byte_count < 1")
        return
    except ValueError as e:
        pass
    try:
        secure_random_hex(0)
        print("Error: Did not raise error with byte_count = 0")
        return
    except ValueError as e:
        pass
    for i in range(1, 100):
        assert len(secure_random_hex(i)) == 2 * i
    print("Test passed")



# Generated at 2022-06-21 21:22:53.701661
# Unit test for function secure_random_hex
def test_secure_random_hex():
    out = secure_random_hex(9)
    for c in out:
        if c not in '0123456789abcdef':
            raise RuntimeError('Unexpected character "{}" in hex output: "{}"'.format(c, out))

# Generated at 2022-06-21 21:22:54.682991
# Unit test for function secure_random_hex
def test_secure_random_hex():
    assert len(secure_random_hex(32)) == 64

# Generated at 2022-06-21 21:22:56.770298
# Unit test for function roman_range
def test_roman_range():
    out = []
    for num in roman_range(stop=3):
        out.append(num)
    assert out == ["I", "II", "III"]

# Generated at 2022-06-21 21:23:04.853536
# Unit test for function random_string
def test_random_string():
    # Test for size < 1
    try:
        random_string(0)
        assert False
    except ValueError:
        assert True

    # Test for size = 1
    try:
        random_string(1)
        assert True
    except ValueError:
        assert False

    # Test for size = 32
    try:
        random_string(32)
        assert True
    except ValueError:
        assert False

    # Test for size = 100
    try:
        random_string(100)
        assert True
    except ValueError:
        assert False


# Generated at 2022-06-21 21:23:07.098783
# Unit test for function random_string
def test_random_string():
    func_output = random_string(9)
    assert len(func_output)==9
    assert(isinstance(func_output,str))
