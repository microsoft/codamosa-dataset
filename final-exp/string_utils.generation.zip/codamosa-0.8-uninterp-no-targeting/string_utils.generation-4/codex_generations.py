

# Generated at 2022-06-21 21:13:33.103616
# Unit test for function uuid
def test_uuid():
    assert str(uuid()) == '65a1b5c5-2876-428f-b9e6-8c571d0daaef'
    assert str(uuid()) == '1ca7de33-d810-40cd-9b21-800d739c64e6'
    assert str(uuid()) == 'e1c65d2e-7a04-45a9-9e0b-a039cb59dcf3'


# Generated at 2022-06-21 21:13:36.606829
# Unit test for function secure_random_hex
def test_secure_random_hex():
    assert len(secure_random_hex(1)) == 2
    assert len(secure_random_hex(20)) == 40
    assert len(secure_random_hex(100)) == 200

# Generated at 2022-06-21 21:13:45.348295
# Unit test for function roman_range
def test_roman_range():
    roman_list = list(roman_range(10, 1, 2))
    assert len(roman_list) == 5 and roman_list[0] == 'I' and roman_list[-1] == 'IX'

    roman_list = list(roman_range(1, 10, -3))
    assert len(roman_list) == 4 and roman_list[0] == 'X' and roman_list[-1] == 'I'

    roman_list = list(roman_range(1, 10, 1))
    assert len(roman_list) == 10 and roman_list[0] == 'I' and roman_list[-1] == 'X'

    roman_list = list(roman_range(10, 1, -1))
    assert len(roman_list) == 10 and roman

# Generated at 2022-06-21 21:13:49.086256
# Unit test for function secure_random_hex
def test_secure_random_hex():
    first_result = secure_random_hex(1)
    assert len(first_result) == 2

    second_result = secure_random_hex(2)
    assert len(second_result) == 4

# Generated at 2022-06-21 21:13:54.700035
# Unit test for function random_string
def test_random_string():
    # Test case 1
    assert random_string(9) == 'cx3QQbzYg'
    # Test case 2
    assert random_string(9) != 'cx3QQbzYg'
    # Test case 3
    assert random_string(6) == 'Qlj8lg'
    # Test case 4
    assert random_string(6) != 'Qlj8lg'
    # Test case 5
    assert random_string(4) == 'YwY8'


# Generated at 2022-06-21 21:13:56.046358
# Unit test for function random_string
def test_random_string():
    assert isinstance(random_string(9), str)
    assert len(random_string(9)) == 9


# Generated at 2022-06-21 21:14:00.615884
# Unit test for function random_string
def test_random_string():
    size = 9
    buffer = random_string(size)
    assert len(buffer) == size
    assert buffer.isalnum()
    return buffer == "cx3QQbzYg"

# Generated at 2022-06-21 21:14:10.994641
# Unit test for function roman_range

# Generated at 2022-06-21 21:14:14.786826
# Unit test for function random_string
def test_random_string():
    rstr = random_string(9)
    assert len(rstr) == 9
    print('random_string() unit test passed')


# Generated at 2022-06-21 21:14:17.681030
# Unit test for function uuid
def test_uuid():
    print("Expected length: 36")
    print("Output: " + uuid())
    print("Expected length: 32")
    print("Output: " + uuid(as_hex=True))


# Generated at 2022-06-21 21:14:22.427363
# Unit test for function random_string
def test_random_string():
    assert(len(random_string(200)) == 200)

# Generated at 2022-06-21 21:14:29.125807
# Unit test for function secure_random_hex
def test_secure_random_hex():
    import pytest

    with pytest.raises(ValueError):
        secure_random_hex(0)

    with pytest.raises(ValueError):
        secure_random_hex(-1)

    with pytest.raises(ValueError):
        secure_random_hex('1')

    with pytest.raises(ValueError):
        secure_random_hex(1.0)

    s = secure_random_hex(1)
    assert(isinstance(s, str))
    assert(len(s) == 2)

# Generated at 2022-06-21 21:14:30.388472
# Unit test for function uuid
def test_uuid():
    assert len(uuid()) == 36
    assert len(uuid(as_hex=True)) == 32



# Generated at 2022-06-21 21:14:41.547605
# Unit test for function roman_range
def test_roman_range():
    # Test with step=1
    for i in roman_range(11):
        print(i)

    for i in roman_range(start=5, stop=11):
        print(i)

    for i in roman_range(start=5, stop=11, step=1):
        print(i)

    # Not valid
    # for i in roman_range(start=5, stop=11, step=1):
    #     print(i)

    # Test with step>1
    for i in roman_range(start=5, stop=11, step=2):
        print(i)

    # Test with step<0
    for i in roman_range(start=5, stop=1, step=-1):
        print(i)
    pass

# Generated at 2022-06-21 21:14:45.101103
# Unit test for function random_string
def test_random_string():
    assert isinstance(random_string(9), str)
    assert len(random_string(9)) == 9
    assert isinstance(random_string(1), str)
    assert len(random_string(1)) == 1


# Generated at 2022-06-21 21:14:48.225105
# Unit test for function secure_random_hex
def test_secure_random_hex():
    """
    Python's binascii.hexlify does not seem to properly handle empty bytes, raising a binascii.Error exception.
    """
    b = secure_random_hex(0)
    assert b == ''

# Generated at 2022-06-21 21:14:51.288887
# Unit test for function random_string
def test_random_string():
    assert len(random_string(10)) == 10
    assert len(random_string(20)) == 20
    assert isinstance(random_string(10), str)
    assert random_string(10) != random_string(10)
    return True

# Generated at 2022-06-21 21:14:56.227639
# Unit test for function uuid
def test_uuid():
    uid = uuid()
    assert type(uid) == str
    assert len(uid) == 36
    assert uuid(as_hex=True) == uid.replace('-','')



# Generated at 2022-06-21 21:15:05.877029
# Unit test for function roman_range
def test_roman_range():
    assert list(roman_range(2)) == ['I', 'II']
    assert list(roman_range(2, start=1)) == ['I', 'II']
    assert list(roman_range(2, step=2)) == ['I', 'II']
    assert list(roman_range(2, start=1, step=2)) == ['I', 'II']
    assert list(roman_range(1, 2)) == ['I']
    assert list(roman_range(1, 2, step=2)) == ['I']
    assert list(roman_range(1, 2, start=1)) == ['I']
    assert list(roman_range(1, 2, start=1, step=2)) == ['I']
    assert list(roman_range(2, 3)) == ['II']

# Generated at 2022-06-21 21:15:15.986045
# Unit test for function random_string
def test_random_string():
    char_min_size = 0
    char_max_size = 1000
    num_tests = 100

    for i in range(num_tests):
        size = random.randint(char_min_size, char_max_size)
        s = random_string(size)
        assert len(s) == size

    # now test with a few fixed values
    full_size = random_string(char_max_size)
    assert len(full_size) == char_max_size

    medium_size = random_string(char_max_size / 10)
    assert len(medium_size) == int(char_max_size / 10)

# Generated at 2022-06-21 21:15:23.053528
# Unit test for function uuid
def test_uuid():
    uid = uuid()
    assert isinstance(uid, str)
    assert len(uid) == 36
    assert uid.count('-') == 4

    uid = uuid(as_hex=True)
    assert isinstance(uid, str)
    assert len(uid) == 32
    assert uid.count('-') == 0



# Generated at 2022-06-21 21:15:25.851886
# Unit test for function random_string
def test_random_string():
    assert random_string(9) == 'cx3QQbzYg'


# Generated at 2022-06-21 21:15:27.565159
# Unit test for function uuid
def test_uuid():
    uuid()


# Generated at 2022-06-21 21:15:39.028362
# Unit test for function roman_range
def test_roman_range():

    # If no values are passed to roman_range, it returns empty list
    assert list(roman_range()) == []

    # If only stop value is passed, it returns list of roman numbers starting from 1 to stop
    assert list(roman_range(5)) == ['I', 'II', 'III', 'IV', 'V']

    # If only stop value is passed and it is equal to 1, it returns list of roman number as 1
    assert list(roman_range(1)) == ['I']

    # If only stop value is passed and it is equal to 0, it returns empty list
    assert list(roman_range(0)) == []

    # If start value is passed, it returns list of roman numbers starting from start to stop
    assert list(roman_range(7,4)) == ['IV', 'V', 'VI', 'VII']

   

# Generated at 2022-06-21 21:15:43.832698
# Unit test for function uuid
def test_uuid():
    uid = uuid()
    assert isinstance(uid, str)

    uid = uuid(as_hex=True)
    assert isinstance(uid, str)

    try:
        uuid(as_hex='invalid')
        assert True == False  # force assertion error
    except ValueError:
        pass



# Generated at 2022-06-21 21:15:47.262196
# Unit test for function uuid
def test_uuid():
    assert type(uuid()) is str
    assert len(uuid()) == 36
    assert type(uuid(as_hex=True)) is str



# Generated at 2022-06-21 21:15:49.781608
# Unit test for function secure_random_hex
def test_secure_random_hex():
    assert len(secure_random_hex(10)) == 20
    assert len(secure_random_hex(15)) == 30


# Generated at 2022-06-21 21:15:57.240149
# Unit test for function uuid
def test_uuid():
    import unittest
    import re

    class TestUUID(unittest.TestCase):

        def test_uuid(self):
            """
            Tests uuid
            """

            for i in range(1000):
                result = uuid()
                self.assertRegex(result, '^[0-9a-f]{8}\-[0-9a-f]{4}\-[0-9a-f]{4}\-[0-9a-f]{4}\-[0-9a-f]{12}$')
                self.assertEqual(len(result), 36)

                result = uuid(as_hex=True)
                self.assertRegex(result, '^[0-9a-f]{32}')
                self.assertEqual(len(result), 32)


# Generated at 2022-06-21 21:15:59.452058
# Unit test for function uuid
def test_uuid():
    print('Testing uuid')
    print (uuid())
    print (uuid(as_hex=True))


# Generated at 2022-06-21 21:16:02.598099
# Unit test for function random_string
def test_random_string():
    result = random_string(8)
    assert len(result) == 8
    assert result.isalnum()
    assert result.isupper() or result.islower() or result.isdigit()

# Generated at 2022-06-21 21:16:08.853591
# Unit test for function random_string
def test_random_string():
    a = random_string(9)
    assert len(a) == 9
    assert isinstance(a, str)


# Generated at 2022-06-21 21:16:15.296622
# Unit test for function uuid
def test_uuid():
    uid = uuid()
    assert isinstance(uid, str)
    assert len(uid) == 36
    assert uid[8] == '-'
    assert uid[13] == '-'
    assert uid[18] == '-'
    assert uid[23] == '-'

    uid_hex = uuid(as_hex=True)
    assert isinstance(uid_hex, str)
    assert len(uid_hex) == 32
    assert len(uid) == len(uid_hex) * 2



# Generated at 2022-06-21 21:16:18.375339
# Unit test for function uuid
def test_uuid():
    print('')
    print('Testing uuid() function')
    print(uuid())
    print(uuid(True)) # hex representation


# Generated at 2022-06-21 21:16:30.217718
# Unit test for function roman_range
def test_roman_range():
    assert list(roman_range(1)) == ['I']
    assert list(roman_range(start=5, stop=10)) == ['V', 'VI', 'VII', 'VIII', 'IX']
    assert list(roman_range(5, 10)) == ['V', 'VI', 'VII', 'VIII', 'IX']
    assert list(roman_range(5, 10, 2)) == ['V', 'VII', 'IX']
    assert list(roman_range(5, 10, step=2)) == ['V', 'VII', 'IX']
    assert list(roman_range(10, 5, -2)) == ['X', 'VIII', 'VI']
    assert list(roman_range(10, 5, step=-2)) == ['X', 'VIII', 'VI']

# Generated at 2022-06-21 21:16:31.796868
# Unit test for function secure_random_hex
def test_secure_random_hex():
    hex = secure_random_hex(8)

    assert hex[3] == '2'

# Generated at 2022-06-21 21:16:34.468182
# Unit test for function random_string
def test_random_string():
    assert len(random_string(9)) == 9
    assert len(random_string(1)) == 1


# Generated at 2022-06-21 21:16:36.968323
# Unit test for function uuid
def test_uuid():
    assert isinstance(uuid(), str)
    assert isinstance(uuid(as_hex=True), str)


# Generated at 2022-06-21 21:16:41.000038
# Unit test for function uuid
def test_uuid():
    uuid_ = uuid()
    uuid_hex = uuid(as_hex=True)
    assert len(uuid_) == 36
    assert len(uuid_hex) == 32



# Generated at 2022-06-21 21:16:44.435991
# Unit test for function roman_range
def test_roman_range():
    for n in roman_range(7):
        print(n)
    for n in roman_range(start=7, stop=1, step=-1):
        print(n)

if __name__ == "__main__":
    test_roman_range()

# Generated at 2022-06-21 21:16:48.798318
# Unit test for function roman_range
def test_roman_range():
    # test positive values
    step = 2
    for i in range(1, 3999, step):
        for x in roman_range(i, step=step):
            pass
        assert roman_encode(i) == x
    # test negative values
    step = -2
    for i in range(3999, 1, step):
        for x in roman_range(i, step=step):
            pass
        assert roman_encode(i) == x

# Generated at 2022-06-21 21:16:57.636966
# Unit test for function uuid
def test_uuid():
    assert isinstance(uuid(), str) and len(uuid()) == 36
    assert uuid(as_hex=True) == uuid().replace('-', '')


# Generated at 2022-06-21 21:17:05.242874
# Unit test for function roman_range
def test_roman_range():
    # Test Step 1: Simple Case
    roman_range_simple = roman_range(7)
    assert next(roman_range_simple) == 'I'
    assert next(roman_range_simple) == 'II'
    assert next(roman_range_simple) == 'III'
    assert next(roman_range_simple) == 'IV'
    assert next(roman_range_simple) == 'V'
    assert next(roman_range_simple) == 'VI'
    assert next(roman_range_simple) == 'VII'

    # Test Step 2: Change start, stop and step parameters
    roman_range_parameters = roman_range(stop=7, start=5, step=2)
    assert next(roman_range_parameters) == 'V'

# Generated at 2022-06-21 21:17:14.349624
# Unit test for function roman_range
def test_roman_range():
    failed = 0
    num_test_casess = 100
    import random
    for i_ in range(num_test_casess):
        start = random.randrange(1,3999,1)
        step  = random.randrange(1,3999,1)
        stop = start+step
        if stop > 3999: stop = 3999
        start_ = start
        stop_ = stop

# Generated at 2022-06-21 21:17:25.239213
# Unit test for function roman_range
def test_roman_range():
    # Tests with right values
    assert list(roman_range(3)) == ['I', 'II', 'III']
    assert list(roman_range(5, start=2)) == ['II', 'III', 'IV', 'V']
    assert list(roman_range(7, start=2, step=2)) == ['II', 'IV', 'VI']
    assert list(roman_range(3999, start=3998, step=2)) == ['MMMCMXCVIII', 'MMMCMXCIX']
    assert list(roman_range(7, start=7, step=-1)) == ['VII', 'VI', 'V', 'IV', 'III', 'II', 'I']

    # Tests with wrong values
    try:
        list(roman_range(4000))
        print('1')
    except ValueError:
        pass

   

# Generated at 2022-06-21 21:17:30.368708
# Unit test for function secure_random_hex
def test_secure_random_hex():
    r = secure_random_hex(9)
    assert (len(r) == 18)
    r = secure_random_hex(10)
    assert (len(r) == 20)
    r = secure_random_hex(11)
    assert (len(r) == 22)

# Generated at 2022-06-21 21:17:37.305085
# Unit test for function random_string
def test_random_string():
    try:
        random_string(-1)
        assert False, "random_string() is not working, 'size' argument must be equal or bigger than 1"
    except ValueError:
        assert True
    try:
        random_string(0)
        assert False, "random_string() is not working, 'size' argument must be equal or bigger than 1"
    except ValueError:
        assert True
    try:
        random_string("1")
        assert False, "random_string() is not working, 'size' argument must be equal or bigger than 1"
    except ValueError:
        assert True
    try:
        random_string("dasda")
        assert False, "random_string() is not working, 'size' argument must be equal or bigger than 1"
    except ValueError:
        assert True

# Generated at 2022-06-21 21:17:39.384423
# Unit test for function random_string
def test_random_string():
    for i in range(100):
        x = random_string(9)
        assert len(x) == 9
        assert x.isalnum()


# Generated at 2022-06-21 21:17:42.262356
# Unit test for function random_string
def test_random_string():
    assert len(random_string(5)) == 5
    assert len(random_string(7)) == 7
    assert len(random_string(10)) == 10
    

# Generated at 2022-06-21 21:17:45.024140
# Unit test for function random_string
def test_random_string():
    k = random_string(9)
    assert len(k) == 9

# Generated at 2022-06-21 21:17:46.949085
# Unit test for function random_string
def test_random_string():
    output = "cx3QQbzYg"
    assert random_string(9) == output, "No match"

# Generated at 2022-06-21 21:18:08.933572
# Unit test for function secure_random_hex
def test_secure_random_hex():
    hex_str_0 = secure_random_hex(0)
    hex_str_1 = secure_random_hex(1)
    hex_str_4 = secure_random_hex(4)
    hex_str_8 = secure_random_hex(8)

    assert isinstance(hex_str_0, str)
    assert isinstance(hex_str_1, str)
    assert isinstance(hex_str_4, str)
    assert isinstance(hex_str_8, str)

    assert len(hex_str_0) == 0
    assert len(hex_str_1) == 2
    assert len(hex_str_4) == 8
    assert len(hex_str_8) == 16



# Generated at 2022-06-21 21:18:12.437033
# Unit test for function roman_range
def test_roman_range():
    rr = roman_range(17)
    res = "I, II, III, IV, V, VI, VII, VIII, IX, X, XI, XII, XIII, XIV, XV, XVI, XVII"
    assert(str(rr)==res)

# Generated at 2022-06-21 21:18:13.918698
# Unit test for function uuid
def test_uuid():
    assert len(uuid()) == 36
    assert len(uuid(as_hex=True)) == 32



# Generated at 2022-06-21 21:18:18.150720
# Unit test for function uuid
def test_uuid():
    assert len(uuid()) == 36
    assert len(uuid(as_hex=True)) == 32
    assert uuid().isupper() is False
    assert uuid().islower() is False


# Generated at 2022-06-21 21:18:22.204947
# Unit test for function uuid
def test_uuid():
    assert len(uuid()) == 36
    assert len(uuid(as_hex=True)) == 32
    assert uuid() != uuid()
    assert uuid(as_hex=True) != uuid(as_hex=True)


# Generated at 2022-06-21 21:18:25.340597
# Unit test for function roman_range
def test_roman_range():
    if __name__ == '__main__':
        for numb in roman_range(stop=7):
            print(numb)
        for numb in roman_range(start=7, stop=1, step=-1):
            print(numb)

# Generated at 2022-06-21 21:18:34.844815
# Unit test for function secure_random_hex
def test_secure_random_hex():
    assert len(secure_random_hex(1)) == 2
    assert len(secure_random_hex(2)) == 4
    assert len(secure_random_hex(3)) == 6
    assert len(secure_random_hex(4)) == 8
    assert len(secure_random_hex(5)) == 10
    assert len(secure_random_hex(6)) == 12
    assert len(secure_random_hex(7)) == 14
    assert len(secure_random_hex(8)) == 16
    assert len(secure_random_hex(9)) == 18
    assert len(secure_random_hex(10)) == 20
    # assert len(secure_random_hex(11)) == 22
    # assert len(secure_random_hex(12)) == 24
    # assert len(secure_random_hex(13)) == 26
   

# Generated at 2022-06-21 21:18:42.389052
# Unit test for function secure_random_hex
def test_secure_random_hex():
    assert len(secure_random_hex(16)) == 32

    random_elements = []
    count = 10000
    for _ in range(count):
        random_elements.append(secure_random_hex(16))

    # if no element is repeated, the count of all elements must be equal to 
    # the number of iterations
    assert len(set(random_elements)) == count

# Generated at 2022-06-21 21:18:45.725978
# Unit test for function random_string
def test_random_string():
    from uuid import uuid4
    import my_module
    assert isinstance(my_module.random_string(9), str)
    assert my_module.random_string(9) != "cx3QQbzYg"


# Generated at 2022-06-21 21:18:50.489813
# Unit test for function secure_random_hex
def test_secure_random_hex():
    """
    Testing function secure_random_hex
    """
    for i in range(10):
        assert len(secure_random_hex(10)) == 10 * 2


# Generated at 2022-06-21 21:19:23.744348
# Unit test for function secure_random_hex
def test_secure_random_hex():
    assert(len(secure_random_hex(16))==32 and len(secure_random_hex(256))==512)


# Generated at 2022-06-21 21:19:29.653018
# Unit test for function roman_range
def test_roman_range():
    #Test case 1
    ret = roman_range(5)
    assert next(ret) == 'I'
    assert next(ret) == 'II'
    assert next(ret) == 'III'
    assert next(ret) == 'IV'
    assert next(ret) == 'V'
    try:
        assert next(ret)
    except StopIteration:
        pass
    #Test case 2
    ret = roman_range(1, 5)
    assert next(ret) == 'II'
    assert next(ret) == 'III'
    assert next(ret) == 'IV'
    assert next(ret) == 'V'
    try:
        assert next(ret)
    except StopIteration:
        pass
    #Test case 3
    ret = roman_range(5, 1)
    assert next

# Generated at 2022-06-21 21:19:40.912834
# Unit test for function roman_range

# Generated at 2022-06-21 21:19:45.703435
# Unit test for function random_string
def test_random_string():
    size = random.randint(1, 100)
    output = random_string(size)
    # assert the size of the string matches the given input
    assert len(output) == size
    # assert the generated string is made of only acceptable characters
    chars = string.ascii_letters + string.digits
    assert all(char in chars for char in output)


# Generated at 2022-06-21 21:19:54.344545
# Unit test for function roman_range
def test_roman_range():
    assert list(roman_range(12)) == ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI', 'XII']
    assert list(roman_range(25, 17)) == ['XVII', 'XVIII', 'XIX', 'XX', 'XXI', 'XXII', 'XXIII', 'XXIV', 'XXV']


if __name__ == '__main__':
    test_roman_range()

# Generated at 2022-06-21 21:19:56.338373
# Unit test for function secure_random_hex
def test_secure_random_hex():
    for i in range(50):
        for j in range(1, 50):
            secure_random_hex(j)

# Generated at 2022-06-21 21:20:00.664500
# Unit test for function secure_random_hex
def test_secure_random_hex():
    """
    Test for function secure_random_hex
    """
    assert isinstance(secure_random_hex(16), str)
    assert len(secure_random_hex(16)) == 32

# Generated at 2022-06-21 21:20:03.108491
# Unit test for function uuid
def test_uuid():
    u_id = uuid()
    if isinstance(u_id, str):
        return True
    else:
        return False


# Generated at 2022-06-21 21:20:13.370605
# Unit test for function roman_range
def test_roman_range():
    assert list(roman_range(3, 1, 1)) == ['I', 'II', 'III']
    assert list(roman_range(8, 1, 1)) == ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII']
    assert list(roman_range(1, 8, -1)) == ['VIII', 'VII', 'VI', 'V', 'IV', 'III', 'II', 'I']
    assert list(roman_range(441, 442, 1)) == ['CDXLI']
    assert list(roman_range(441, 442, -1)) == ['CDXLI']
    assert list(roman_range(1, 1, 1)) == ['I']
    assert list(roman_range(0, 1, 1)) == []

# Generated at 2022-06-21 21:20:18.709474
# Unit test for function random_string
def test_random_string():
    assert isinstance(random_string(10), str)
    assert isinstance(random_string(10), type(''))
    assert len(random_string(10)) == 10
    assert random_string(10) != random_string(10)


# Generated at 2022-06-21 21:21:22.127790
# Unit test for function uuid
def test_uuid():
    result = uuid(as_hex=True)
    assert len(result) == 32
    assert isinstance(result, str)
    assert result.isalnum()


# Generated at 2022-06-21 21:21:24.104934
# Unit test for function random_string
def test_random_string():
    assert type(random_string(10)) is str
    print("random_string function passed")

# Unit testing for function secure_random_hex

# Generated at 2022-06-21 21:21:25.564569
# Unit test for function random_string
def test_random_string():
    assert len(random_string(9)) == 9
    # for i in range(1000):
    #     assert len(random_string(9)) == 9

# Generated at 2022-06-21 21:21:29.253696
# Unit test for function roman_range
def test_roman_range():
    for n in roman_range(7):
        assert n
    for n in roman_range(start=7, stop=1, step=-1):
        assert n

# Generated at 2022-06-21 21:21:32.710132
# Unit test for function secure_random_hex
def test_secure_random_hex():
    r = secure_random_hex(9)
    assert len(r) == 2*9
    assert isinstance(r, str)

# Generated at 2022-06-21 21:21:34.231980
# Unit test for function secure_random_hex
def test_secure_random_hex():
    assert len(secure_random_hex(9)) == 2*9



# Generated at 2022-06-21 21:21:40.919310
# Unit test for function random_string
def test_random_string():
    for i in range(10):
        ls = random_string(256)
        assert len(ls)==256
        for i in ls:
            assert i in string.ascii_letters+string.digits
    with pytest.raises(ValueError) as excinfo:
        random_string(0)
    assert excinfo.type == ValueError
    assert str(excinfo.value).find('size must be >= 1')


# Generated at 2022-06-21 21:21:45.004225
# Unit test for function uuid
def test_uuid():
    assert uuid() == '97e3a716-6b33-4ab9-9bb1-8128cb24d76b'
    assert uuid(as_hex=True) == '97e3a7166b334ab99bb18128cb24d76b'



# Generated at 2022-06-21 21:21:55.222637
# Unit test for function random_string
def test_random_string():
    import unittest

    class RandomStringTestCase(unittest.TestCase):
        @staticmethod
        def test_size():
            with self.assertRaises(ValueError):
                random_string(0)

            with self.assertRaises(ValueError):
                random_string(-1)

        @staticmethod
        def test_returned_string_size():
            for i in range(1, 20):
                string = random_string(i)
                self.assertEqual(len(string), i)

        @staticmethod
        def test_randomness():
            a = random_string(100)
            b = random_string(100)
            self.assertNotEqual(a, b)

    unittest.main()


# Generated at 2022-06-21 21:21:57.328475
# Unit test for function secure_random_hex
def test_secure_random_hex():
    random = secure_random_hex(17)
    assert len(random) == 34