

# Generated at 2022-06-21 21:13:22.649555
# Unit test for function random_string
def test_random_string():
    # check success
    assert len(random_string(9)) == 9
    # check failure
    try:
        random_string(0)
    except ValueError as e:
        assert True
    else:
        assert False


# Generated at 2022-06-21 21:13:27.084430
# Unit test for function random_string
def test_random_string():
    assert len(random_string(5)) == 5, "The output should be a string of 5 characters"
    for i in range(100):
        assert len(random_string(5)) == 5, "The output should be a string of 5 characters"

# Generated at 2022-06-21 21:13:30.201480
# Unit test for function uuid
def test_uuid():
    for _ in range(100):
        # Make sure it does not return an empty string
        assert len(uuid()) != 0
        assert len(uuid(as_hex=True)) != 0


# Generated at 2022-06-21 21:13:32.159576
# Unit test for function random_string
def test_random_string():
    array = random_string(9)
    assert (len(array) == 9)


# Generated at 2022-06-21 21:13:35.908357
# Unit test for function random_string
def test_random_string():
    out=random_string(9)
    if(len(out) == 9):
        print("Passed")
    else:
        print("Failed")


# Generated at 2022-06-21 21:13:39.664397
# Unit test for function uuid
def test_uuid():
    assert isinstance(uuid(), str)
    assert isinstance(uuid(as_hex=True), str)
    assert len(uuid()) == len(uuid(as_hex=True))
    assert uuid().count('-') == 4
    assert uuid(as_hex=True).count('-') == 0


# Generated at 2022-06-21 21:13:42.556452
# Unit test for function random_string
def test_random_string():
    assert random_string(0) == ""
    assert len(random_string(1)) == 1
    assert len(random_string(10)) == 10
    for i in range(1000):
        assert len(random_string(i)) == i

# Generated at 2022-06-21 21:13:49.330956
# Unit test for function roman_range
def test_roman_range():
    test_list= ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII']
    test_list2= ['VII', 'VI', 'V', 'IV', 'III', 'II', 'I']
    gen = roman_range(1)
    gen2 = roman_range(1,7)
    gen3 = roman_range(7,1,-1)
    assert next(gen) == test_list[0]
    assert next(gen2) == test_list[0]
    assert next(gen3) == test_list2[0]
    next(gen)
    next(gen)
    next(gen)
    next(gen)
    next(gen)
    next(gen)
    assert next(gen) == test_list[6]

# Generated at 2022-06-21 21:13:51.806305
# Unit test for function random_string
def test_random_string():
    print("-------------------------")
    print("Testing random_string")
    randomString = random_string(10)
    print(len(randomString))
    print(randomString)


# Generated at 2022-06-21 21:13:54.856362
# Unit test for function roman_range
def test_roman_range():
    r = roman_range(stop=7, start=1, step=1)
    assert next(r) == 'I'
    print(next(r))
    print(next(r))
    print(next(r))
    print(next(r))
    print(next(r))
    print(next(r))
    print(next(r))

# Generated at 2022-06-21 21:14:00.043502
# Unit test for function random_string
def test_random_string():
    assert len(random_string(9))==9
    assert isinstance(random_string(9),str)


# Generated at 2022-06-21 21:14:10.533618
# Unit test for function roman_range
def test_roman_range():
    assert list(roman_range(5)) == ['I', 'II', 'III', 'IV', 'V']
    assert list(roman_range(5, 1)) == ['I', 'II', 'III', 'IV', 'V']
    assert list(roman_range(10, 5)) == ['V', 'VI', 'VII', 'VIII', 'IX', 'X']
    assert list(roman_range(5, 1, 2)) == ['I', 'III', 'V']
    assert list(roman_range(5, 1, -1)) == []
    assert list(roman_range(25, 1, 4)) == ['I', 'V', 'IX', 'XIII', 'XVII', 'XXI']
    assert list(roman_range(6, 2, 1)) == ['II', 'III', 'IV', 'V', 'VI']

# Generated at 2022-06-21 21:14:12.610326
# Unit test for function secure_random_hex
def test_secure_random_hex():
    """
    Unit test for function secure_random_hex
    :return: boolean
    """
    if not isinstance(secure_random_hex(9),str):
        return False
    return True



# Generated at 2022-06-21 21:14:23.466795
# Unit test for function roman_range
def test_roman_range():
    # test the error case
    # start is smaller than stop and the step is greater than 0
    try:
        start = 4
        stop = 1
        step = 1
        for i in roman_range(start, stop, step):
            print(i)
    except Exception as e:
        print("Expected error: " + str(e))
    # start is greater than stop and the step is less than 0
    try:
        start = 1
        stop = 4
        step = -1
        for i in roman_range(start, stop, step):
            print(i)
    except Exception as e:
        print("Expected error: " + str(e))
    # value out of bound

# Generated at 2022-06-21 21:14:27.409489
# Unit test for function random_string
def test_random_string():
    assert len(random_string(1)) == 1
    assert len(random_string(9)) == 9
    assert random_string(0) == ''
    assert random_string(1) == random_string(1)


# Generated at 2022-06-21 21:14:38.506103
# Unit test for function random_string
def test_random_string():
    import random
    import string
    import binascii
    from random import Random
    from Crypto.Hash import SHA256, SHA512
    import hashlib

    # Entropy pool
    entropy = []

    # Gather some system data
    entropy.append(os.urandom(128))
    entropy.append(os.times())
    entropy.append(os.times())
    entropy.append(os.getloadavg())
    entropy.append(os.uname())

    # Setup the hash objects
    hashObject_256 = SHA256.new()
    hashObject_512 = SHA512.new()
    hashObject_md5 = hashlib.md5()

    # Hash the data in the entropy array
    for x in entropy:
        hashObject_256.update(str(x).encode('utf-8'))
        hash

# Generated at 2022-06-21 21:14:42.439091
# Unit test for function random_string
def test_random_string():
    const_string = "1234567890"
    for i in range(len(const_string)):
        assert( len(random_string(i)) == i )

# Generated at 2022-06-21 21:14:44.655802
# Unit test for function uuid
def test_uuid():
    assert(len(uuid()) == 36)
    assert(len(uuid(as_hex=True)) == 32)

# Generated at 2022-06-21 21:14:48.229442
# Unit test for function uuid
def test_uuid():
    assert isinstance(uuid(), str)
    assert isinstance(uuid(as_hex=True), str)
    assert len(uuid(as_hex=True)) == 32
    assert len(uuid()) == 36



# Generated at 2022-06-21 21:14:54.845677
# Unit test for function roman_range
def test_roman_range():
    # Test to check that the function works if the number of steps to execute is not multiple of the step number
    assert len([i for i in roman_range(10, 1, 2)]) == 5
    assert [i for i in roman_range(10, 1, 2)] == ['I', 'III', 'V', 'VII', 'IX']

    # Test that the function works if the step number is negative
    assert len([i for i in roman_range(4, 7, -1)]) == 4
    assert [i for i in roman_range(4, 7, -1)] == ['IV', 'V', 'VI', 'VII']

    # Test that the function works if the step number is positive
    assert len([i for i in roman_range(5, 2, 1)]) == 3

# Generated at 2022-06-21 21:14:59.083516
# Unit test for function random_string
def test_random_string():
    for i in range(25):
        result = random_string(7)
        assert len(result) == 7


# Generated at 2022-06-21 21:15:03.366911
# Unit test for function random_string
def test_random_string():
    # You can implement here some test code to ensure your function works as expected
    print(random_string(9))



# Generated at 2022-06-21 21:15:14.609085
# Unit test for function uuid

# Generated at 2022-06-21 21:15:16.498088
# Unit test for function uuid
def test_uuid():
    assert len(uuid()) == 36
    assert len(uuid(as_hex=True)) == 32



# Generated at 2022-06-21 21:15:19.463066
# Unit test for function secure_random_hex
def test_secure_random_hex():
    byte_count = 0
    out = secure_random_hex(byte_count)
    assert out == ""


# Unit Test for function roman_range

# Generated at 2022-06-21 21:15:23.002052
# Unit test for function uuid
def test_uuid():
    str1 = uuid(as_hex=True)
    print(str1)
    str2 = uuid()
    print(str2)
    assert (len(str1) == 32)
    assert (str2[-1] == 'b')


# Generated at 2022-06-21 21:15:27.251296
# Unit test for function secure_random_hex
def test_secure_random_hex():
    print(secure_random_hex(32))
    if secure_random_hex(32) == secure_random_hex(32):
        return True
    else:
        return False

print(secure_random_hex(32))
print(test_secure_random_hex())

# Generated at 2022-06-21 21:15:29.236737
# Unit test for function uuid
def test_uuid():
    print(uuid())
    print(uuid(as_hex=True))
    print()


# Generated at 2022-06-21 21:15:40.397313
# Unit test for function secure_random_hex
def test_secure_random_hex():
    from hashlib import sha256
    import string

    hash = []
    count_time = 100
    key = string.ascii_letters + string.digits + string.punctuation
    for i in range(1000):
        rand_hex = secure_random_hex(i)
        # 对返回的十六进制字符串进行HASH值拼接，因为此操作可以将字符串变换为1024bits的分布均匀的二进制数据
        # 通过重复此操作，再次拼接H

# Generated at 2022-06-21 21:15:42.311354
# Unit test for function random_string
def test_random_string():
    assert random_string(10) == 'jhc5osZ2Dh'

# Generated at 2022-06-21 21:15:49.340601
# Unit test for function uuid
def test_uuid():
    uid = uuid()
    assert (len(uid.split('-')) == 5)
    uid = uuid(as_hex=True)
    assert (len(uid) == 32)



# Generated at 2022-06-21 21:15:52.200914
# Unit test for function secure_random_hex
def test_secure_random_hex():
    # if function raise any exception, the test will fail
    secure_random_hex(0)
    secure_random_hex(1)
    secure_random_hex(10)
    secure_random_hex(100)
    secure_random_hex(1000)

# Generated at 2022-06-21 21:15:53.675576
# Unit test for function uuid
def test_uuid():
    assert uuid()
    assert uuid(as_hex=True)


# Generated at 2022-06-21 21:16:02.794206
# Unit test for function uuid
def test_uuid():
    # Generate a UUID
    uuid_result = uuid()
    uuid_result_hex = uuid(True)
    # Use the assertion statement to verify the result
    assert isinstance(uuid_result, str)
    assert isinstance(uuid_result_hex, str)
    # The result should be a valid UUID string
    assert len(uuid_result) == 36
    assert len(uuid_result_hex) == 32
    assert uuid_result.count('-') == 4
    assert uuid_result_hex.isalnum()


# Generated at 2022-06-21 21:16:14.274547
# Unit test for function roman_range
def test_roman_range():
    assert list(roman_range(1,step=1)) == ['I']
    assert list(roman_range(5,step=1)) == ['I', 'II', 'III', 'IV', 'V']
    assert list(roman_range(3,start=3,step=1)) == ['III']
    assert list(roman_range(start=3,step=1)) == []
    assert list(roman_range(5,start=5,step=1)) == ['V']
    assert list(roman_range(5,step=-1)) == []
    assert list(roman_range(5,start=5,step=-1)) == ['V']
    assert list(roman_range(3,start=3,step=-1)) == ['III']

# Generated at 2022-06-21 21:16:15.886487
# Unit test for function random_string
def test_random_string():
    random_string(56)
    print("passed the test of random_string")



# Generated at 2022-06-21 21:16:18.883508
# Unit test for function secure_random_hex
def test_secure_random_hex():
    for i in range(0, 20):
        print(secure_random_hex(8))

if __name__ == '__main__':
    test_secure_random_hex()

# Generated at 2022-06-21 21:16:24.063258
# Unit test for function uuid
def test_uuid():
    assert(len(uuid()) == 36)
    assert(len(uuid(as_hex=True)) == 32)
    assert(uuid().count('-') == 4)
    assert(uuid(as_hex=True).count('-') == 0)


# Generated at 2022-06-21 21:16:26.053432
# Unit test for function secure_random_hex
def test_secure_random_hex():
    a = secure_random_hex(5)
    print(a)
    print(len(a))


# Generated at 2022-06-21 21:16:30.558638
# Unit test for function roman_range
def test_roman_range():
    count = 0
    test_num = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 20, 50, 100, 500, 1000]
    for n in roman_range(3999):
        assert roman_encode(test_num[count]) == n
        count += 1

# Generated at 2022-06-21 21:16:47.298097
# Unit test for function roman_range
def test_roman_range():
    # valid configuration
    # stop > start, step > 0
    res = list(roman_range(7))
    assert res == ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII']

    # stop > start, step < 0
    res = list(roman_range(7, start=11))
    assert res == ['XI', 'X', 'IX', 'VIII', 'VII', 'VI', 'V']

    # start > stop, step > 0
    res = list(roman_range(7, start=11))
    assert res == []

    # start > stop, step < 0
    res = list(roman_range(7, start=11, step=-1))
    assert res == ['XI', 'X', 'IX', 'VIII', 'VII', 'VI', 'V']

    #

# Generated at 2022-06-21 21:16:55.022650
# Unit test for function secure_random_hex
def test_secure_random_hex():
    import string
    s = secure_random_hex(8)
    # Check length of string
    if not (len(s) == 16):
        raise ValueError('generate string of wrong length')
    # Check if all characters are valid hex digits
    for c in s:
        if not (c in string.hexdigits):
            raise ValueError('char {} not valid hex'.format(c))

test_secure_random_hex()

# Generated at 2022-06-21 21:16:57.569597
# Unit test for function random_string
def test_random_string():
    for size in range(1, 5000):
        rs = random_string(size)

        assert isinstance(rs, str)
        assert len(rs) == size



# Generated at 2022-06-21 21:16:59.092390
# Unit test for function secure_random_hex
def test_secure_random_hex():
    for i in range(1,129):
        assert len(secure_random_hex(i)) == i*2

# Generated at 2022-06-21 21:17:05.896207
# Unit test for function uuid
def test_uuid():
    assert uuid(as_hex=True) == "4db4a4d44f374e9592ba9de558907e78" and uuid() == \
           "4db4a4d4-4f37-4e95-92ba-9de558907e78"



# Generated at 2022-06-21 21:17:08.486323
# Unit test for function secure_random_hex
def test_secure_random_hex():
    for i in range(10000):
        assert isinstance(secure_random_hex(8), str)
        assert len(secure_random_hex(8)) == 16


# Generated at 2022-06-21 21:17:14.376506
# Unit test for function uuid
def test_uuid():
    import pytest
    uid = uuid()
    assert len(uid) == 36
    assert uid[8] == '-' and uid[13] == '-' and uid[18] == '-' and uid[23] == '-'

    uid = uuid(as_hex=True)
    assert len(uid) == 32
    assert uid[8] != '-' and uid[13] != '-' and uid[18] != '-' and uid[23] != '-'

    with pytest.raises(ValueError):
        uuid(as_hex='not a bool')


# Generated at 2022-06-21 21:17:17.511985
# Unit test for function random_string
def test_random_string():
    string_length = 9
    assert len(random_string(string_length)) == string_length


# Generated at 2022-06-21 21:17:19.609890
# Unit test for function uuid
def test_uuid():
    assert(len(uuid())==36)
    assert(len(uuid(as_hex=True))==32)

# Generated at 2022-06-21 21:17:21.294434
# Unit test for function random_string
def test_random_string():
    for i in range(10):
        print(random_string(i))

# Generated at 2022-06-21 21:17:41.154913
# Unit test for function random_string
def test_random_string():
    print("Test random_string()")
    letter = 'abcdefghijklmnopqrstuvwxyz'
    uppcase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    number = '0123456789'
    all_string = letter + uppcase + number
    for i in range(1,10):
        randString = random_string(i)
        assert len(randString) == i
        for eachChar in randString:
            assert eachChar in all_string
    print("Test random_string() PASS")

test_random_string()

# Generated at 2022-06-21 21:17:46.428493
# Unit test for function secure_random_hex
def test_secure_random_hex():
    for i in range(1000):
        assert len(secure_random_hex(1)) == 2
        assert len(secure_random_hex(10)) == 20
        assert len(secure_random_hex(100)) == 200
        assert len(secure_random_hex(1000)) == 2000

# Generated at 2022-06-21 21:17:50.741368
# Unit test for function uuid
def test_uuid():
    assert uuid() == "97e3a716-6b33-4ab9-9bb1-8128cb24d76b"
    assert uuid(True) == "97e3a7166b334ab99bb18128cb24d76b"


# Generated at 2022-06-21 21:17:51.959118
# Unit test for function random_string
def test_random_string():
    assert len(random_string(9)) == 9


# Generated at 2022-06-21 21:17:53.788451
# Unit test for function uuid
def test_uuid():
    assert isinstance(uuid(), str)
    assert isinstance(uuid(as_hex=True), str)


# Generated at 2022-06-21 21:17:56.875466
# Unit test for function uuid
def test_uuid():
    assert len(uuid()) == 36
    assert len(uuid(as_hex=True)) == 32

# Generated at 2022-06-21 21:17:58.590572
# Unit test for function uuid
def test_uuid():
    tmp = uuid()

    assert isinstance(tmp, str)
    assert len(tmp) == 36



# Generated at 2022-06-21 21:18:03.751511
# Unit test for function secure_random_hex
def test_secure_random_hex():
    assert(len(secure_random_hex(32)) == 64)
    assert(len(secure_random_hex(12)) == 24)
    assert(len(secure_random_hex(1)) == 2)
    assert(len(secure_random_hex(0)) == 0)

# Generated at 2022-06-21 21:18:12.396914
# Unit test for function random_string
def test_random_string():
    from string import ascii_letters, digits
    from random import randint
    from itertools import product

    def _test_basics():
        assert len(random_string(1)) == 1
        assert len(random_string(9)) == 9

    def _test_possible_chars():
        for _ in range(10):
            size = randint(1,20)
            gen_string = random_string(size)
            possible_chars = ascii_letters + digits
            for char in gen_string:
                assert char in possible_chars

    def _test_all_possible_char_combinations():
        combinations = product(list(ascii_letters + digits), repeat=2)
        for comb in combinations:
            gen_string = random_string(2)
            assert comb in gen_

# Generated at 2022-06-21 21:18:20.566405
# Unit test for function secure_random_hex
def test_secure_random_hex():
    """
    Unit test for function secure_random_hex().

    :return: True if test is successful, False otherwise.
    """
    # just a simple test, the real check is done by a statistical test in test_utils.py
    n = random.randint(10, 50)
    random_bytes = os.urandom(n)
    hex_bytes = binascii.hexlify(random_bytes)
    hex_string = hex_bytes.decode()
    assert len(hex_string) == n*2
    return True

# Generated at 2022-06-21 21:18:51.954950
# Unit test for function random_string
def test_random_string():
    print("First output of random string: ", random_string(10))
    print("First output of random string: ", random_string(10))
    print("First output of random string: ", random_string(10))
    print("First output of random string: ", random_string(10))


# Generated at 2022-06-21 21:18:55.352439
# Unit test for function random_string
def test_random_string():
    assert type(random_string(9)) == str
    assert len(random_string(9)) == 9
    assert random_string(9).isalnum()


# Generated at 2022-06-21 21:18:59.668614
# Unit test for function random_string
def test_random_string():
    size = int(input("Enter size of random string: "))
    print("Random string of size", size, "is:")
    print(random_string(size))


# Generated at 2022-06-21 21:19:03.970330
# Unit test for function secure_random_hex
def test_secure_random_hex():
    for i in range(10):
        for j in range(1, 100):
            rnd = secure_random_hex(j)
            assert 0 == len(rnd) % 2
            assert j * 2 == len(rnd)
            assert True == all(c in string.hexdigits for c in rnd)

# Generated at 2022-06-21 21:19:08.719072
# Unit test for function roman_range
def test_roman_range():
    assert roman_range(1)         == ['I']
    assert roman_range(6, 2)      == ['II', 'III', 'IV', 'V', 'VI']
    assert roman_range(2, 6, -1)  == ['VI', 'V', 'IV', 'III', 'II']
    assert roman_range(3, 1, 2)   == ['I', 'III']
    assert roman_range(100, 3, 11)== ['III','XIV','XXV','XXXVI','XLVII','LVIII','LXIX','LXXX','XCI','CII']

# Generated at 2022-06-21 21:19:17.173510
# Unit test for function roman_range
def test_roman_range():
    expected_result = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"]
    actual_result = list(roman_range(10))
    assert expected_result == actual_result
    assert type(roman_range(10)) == type(iter([]))
    assert expected_result != list(roman_range(5))


# Generated at 2022-06-21 21:19:19.080550
# Unit test for function secure_random_hex
def test_secure_random_hex():
	for i in range(0,10):
		print(secure_random_hex(9))

# Generated at 2022-06-21 21:19:21.014844
# Unit test for function secure_random_hex
def test_secure_random_hex():
    assert len(secure_random_hex(10)) == 20
    assert secure_random_hex(10) != secure_random_hex(10)

# Generated at 2022-06-21 21:19:22.382895
# Unit test for function random_string
def test_random_string():
    for i in range(100):
        random_string(100)

test_random_string()

# Generated at 2022-06-21 21:19:24.695859
# Unit test for function random_string
def test_random_string():

    for i in range(100):
        assert len(random_string(64)) == 64
        assert len(random_string(12)) == 12

# Generated at 2022-06-21 21:20:18.901629
# Unit test for function random_string
def test_random_string():
    size = 9
    
    assert len(random_string(size)) == size

if __name__ == "__main__":
    test_random_string()

# Generated at 2022-06-21 21:20:20.183496
# Unit test for function random_string
def test_random_string():
    assert len(random_string(9)) == 9



# Generated at 2022-06-21 21:20:28.629820
# Unit test for function roman_range
def test_roman_range():
    # Test for each argument
    for arg1 in range(1, 4000):
        for arg2 in range(1, 4000):
            for arg3 in range(-4000, 4000):
                roman_range(arg1, arg2, arg3)
    # Test for all combination of arguments
    for arg1 in range(1, 4000):
        for arg2 in range(1, 4000):
            for arg3 in range(1, 4000):
                roman_range(arg1, arg2, arg3)

# Generated at 2022-06-21 21:20:33.755435
# Unit test for function random_string
def test_random_string():
    assert len(random_string(5)) == 5
    assert len(random_string(10)) == 10
    assert len(random_string(15)) == 15
    assert len(random_string(25)) == 25

# Test for function uuid

# Generated at 2022-06-21 21:20:37.017313
# Unit test for function uuid
def test_uuid():
    # this test is not completed
    assert len(uuid()) == 36
    assert len(uuid(as_hex=True)) == 32


# Generated at 2022-06-21 21:20:38.567969
# Unit test for function random_string
def test_random_string():
    size = 100
    if len(random_string(size))<100:
        assert False


# Generated at 2022-06-21 21:20:40.484511
# Unit test for function uuid
def test_uuid():
    result = uuid()
    assert isinstance(result, str)
    assert len(result) == 36


# Generated at 2022-06-21 21:20:46.648347
# Unit test for function roman_range
def test_roman_range():
    """ Unit test for function roman_range """
    print('testing roman_range')
    result = list(roman_range(7))
    assert result == ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII'], 'romans from 1 to 7 not correctly computed'
    result = list(roman_range(7, step=2))
    assert result == ['I', 'III', 'V'], 'romans from 1 to 7 with step 2 not correctly computed'
    result = list(roman_range(7, 3, 1))
    assert result == ['III', 'IV', 'V', 'VI', 'VII'], 'romans from 3 to 7 not correctly computed'

    result = list(roman_range(7, 7, 1))

# Generated at 2022-06-21 21:20:55.133934
# Unit test for function secure_random_hex
def test_secure_random_hex():
    assert len(secure_random_hex(1)) == 2
    assert len(secure_random_hex(2)) == 4
    assert len(secure_random_hex(3)) == 6
    assert len(secure_random_hex(4)) == 8
    assert len(secure_random_hex(5)) == 10
    assert len(secure_random_hex(6)) == 12
    assert len(secure_random_hex(7)) == 14
    assert len(secure_random_hex(8)) == 16
    assert len(secure_random_hex(9)) == 18
    assert len(secure_random_hex(10)) == 20
    assert len(secure_random_hex(11)) == 22
    assert len(secure_random_hex(12)) == 24
    assert len(secure_random_hex(13)) == 26

# Generated at 2022-06-21 21:20:58.939999
# Unit test for function random_string
def test_random_string():
    assert len(random_string(9)) == 9
    assert len(random_string(0)) == 0
    assert len(random_string(-9)) == 0


# Generated at 2022-06-21 21:22:47.366965
# Unit test for function uuid
def test_uuid():
    assert len(uuid(as_hex=True)) == 32



# Generated at 2022-06-21 21:22:52.079753
# Unit test for function uuid
def test_uuid():
    assert uuid() == '7c80f257-0aa7-4c27-9f39-d8a89a8e1b50'
    assert uuid(as_hex=True) == '7c80f2570aa74c279f39d8a89a8e1b50'

# Generated at 2022-06-21 21:22:55.274125
# Unit test for function secure_random_hex
def test_secure_random_hex():
    random_string = secure_random_hex(18)
    assert len(random_string) == 18 * 2
    
    

# Generated at 2022-06-21 21:22:56.648527
# Unit test for function uuid
def test_uuid():
    assert isinstance(uuid(), str)
    assert len(uuid()) == 36


# Generated at 2022-06-21 21:22:58.103963
# Unit test for function secure_random_hex
def test_secure_random_hex():
    assert random_string(9) != random_string(9)



# Generated at 2022-06-21 21:23:02.034368
# Unit test for function secure_random_hex
def test_secure_random_hex():
    assert len(secure_random_hex(1)) == 2
    assert len(secure_random_hex(5)) == 10
    assert len(secure_random_hex(8)) == 16


if __name__ == '__main__':
    import doctest
    print(doctest.testmod())