

# Generated at 2022-06-25 07:41:40.329291
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_base_0 = ActionBase()
    action_module_0 = ActionModule()
    action_module_0.run(tmp=None, task_vars=None)


# Generated at 2022-06-25 07:41:49.884836
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_args = {'per_host': True, 'data': {bool_0: bool_0, bool_0: bool_0, str_0: bool_0, bool_0: str_0}, 'aggregate': bool_0}
    tmp = None
    task_vars = None
    my_obj = ActionModule(task=tmp, connection=tmp, play_context=tmp, loader=tmp, templar=tmp, shared_loader_obj=tmp)
    del tmp
    stats = {'aggregate': True, 'per_host': False, 'data': {}}

# Generated at 2022-06-25 07:41:54.242315
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()


# Generated at 2022-06-25 07:41:56.120139
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    result = action_module.run()

test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 07:41:59.546045
# Unit test for constructor of class ActionModule
def test_ActionModule():
  obj = ActionModule()


# Generated at 2022-06-25 07:42:02.757563
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True


# Generated at 2022-06-25 07:42:04.885007
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj = ActionModule()
    obj.run()

if __name__ == '__main__':
    test_ActionModule_run()
    test_case_0()

# Generated at 2022-06-25 07:42:13.710123
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(action_base_0)
    assert action_module_0.local_action is action_base_0.local_action
    assert action_module_0.noop_action is action_base_0.noop_action
    assert action_module_0.runner is action_base_0.runner
    assert action_module_0.play_context is action_base_0.play_context
    assert action_module_0.task_vars is action_base_0.task_vars
    assert action_module_0.task_vars_temp is action_base_0.task_vars_temp
    assert action_module_0.task_name is action_base_0.task_name
    assert action_module_0.task_uuid is action_base_0.task_uu

# Generated at 2022-06-25 07:42:14.920515
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule()


# Generated at 2022-06-25 07:42:17.941815
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module._task = set_0
    action_module._templar = dict_1
    action_module.run()

# Generated at 2022-06-25 07:42:31.807222
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b"b'k\x8aE\xd4"
    set_0 = {bytes_0, bytes_0}
    tuple_0 = ()
    str_0 = 'h#F`$"V7)!f'
    float_0 = -270.11
    list_0 = [bytes_0, bytes_0, bytes_0, str_0, bytes_0, bytes_0, bytes_0, bytes_0, bytes_0, bytes_0, bytes_0, bytes_0]
    bool_0 = False
    action_module_0 = ActionModule(set_0, tuple_0, str_0, float_0, list_0, bool_0)
    var_0 = action_run()
    tuple_1 = (float_0,)

# Generated at 2022-06-25 07:42:41.466765
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b''
    set_0 = {bytes_0, bytes_0, bytes_0}
    tuple_0 = ()
    str_0 = 'x'
    float_0 = -0.9579
    list_0 = [float_0, str_0]
    bool_0 = True
    action_module_0 = ActionModule(set_0, tuple_0, str_0, float_0, list_0, bool_0)
    str_1 = ''
    str_2 = 'n'
    float_1 = -2162.7815
    float_2 = -0.9579
    list_1 = [bytes_0, float_0]

# Generated at 2022-06-25 07:42:46.782167
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = {'var_0': None}
    action_module_0 = ActionModule(task_vars)
    assert action_module_0.action == '', 'ActionModule(task_vars), action property is not empty'
    assert action_module_0.action_loader is None, 'ActionModule(task_vars), action_loader property is not None'
    assert action_module_0.action_shell is None, 'ActionModule(task_vars), action_shell property is not None'
    assert action_module_0.action_wrappers is None, 'ActionModule(task_vars), action_wrappers property is not None'
    assert action_module_0.args == {}

# Generated at 2022-06-25 07:42:50.688687
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -7.5036
    int_0 = -878
    float_1 = 11.51517
    int_1 = -2987
    class_0 = ActionModule(str, float_1, int_0, float_0, float_0, float_1)
    var_0 = class_0.run()
    assert var_0 is None


# Generated at 2022-06-25 07:42:57.111392
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = frozenset()
    tuple_0 = ()
    str_0 = 'J'
    float_0 = -29.97733
    list_0 = []
    bool_0 = True
    action_module_0 = ActionModule(set_0, tuple_0, str_0, float_0, list_0, bool_0)
    action_module_0.run()
    action_module_0.run()


# Generated at 2022-06-25 07:43:06.294358
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b''
    set_0 = {bytes_0, bytes_0, bytes_0}
    tuple_0 = ()
    str_0 = '\\bL\\(([^)]+), *([^)]+)\\)'
    float_0 = 918.17327
    list_0 = [bytes_0, float_0]
    bool_0 = True
    action_module_0 = ActionModule(set_0, tuple_0, str_0, float_0, list_0, bool_0)
    tuple_1 = (bytes_0,)
    set_1 = {tuple_1, tuple_1, tuple_1, tuple_1}
    str_1 = '/6 '
    float_1 = -4542.92

# Generated at 2022-06-25 07:43:07.004341
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:43:15.794309
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b''
    set_0 = {bytes_0, bytes_0, bytes_0}
    tuple_0 = ()
    str_0 = '\\bL\\(([^)]+), *([^)]+)\\)'
    float_0 = 918.17327
    list_0 = [bytes_0, float_0]
    bool_0 = True
    action_module_0 = ActionModule(set_0, tuple_0, str_0, float_0, list_0, bool_0)
    tuple_1 = (bytes_0,)
    set_1 = {tuple_1, tuple_1, tuple_1, tuple_1}
    str_1 = '/6 '
    float_1 = -4542.92

# Generated at 2022-06-25 07:43:16.848544
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert action_run()


# Generated at 2022-06-25 07:43:17.522501
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    assert True

# Generated at 2022-06-25 07:43:30.660516
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == "__main__":
    # Unit test for constructor of class ActionModule
    test_ActionModule()

# Generated at 2022-06-25 07:43:39.130457
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = None
    bool_0 = True
    int_0 = -850
    dict_0 = {None: None}
    str_0 = 'hB$[#g&_lNe'
    set_0 = {list_0, str_0, int_0}
    float_0 = -55.46087
    action_module_0 = ActionModule(list_0, bool_0, int_0, dict_0, str_0, set_0, float_0)
    assert action_module_0.transfers_files == False
    str_0 = '&K_'
    bytes_0 = b'J*'
    bool_0 = True
    float_0 = -5.5

# Generated at 2022-06-25 07:43:50.159110
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b''
    set_0 = {bytes_0, bytes_0, bytes_0}
    tuple_0 = ()
    str_0 = '\\bL\\(([^)]+), *([^)]+)\\)'
    float_0 = 918.17327
    list_0 = [bytes_0, float_0]
    bool_0 = True
    action_module_0 = ActionModule(set_0, tuple_0, str_0, float_0, list_0, bool_0)
    var_0 = action_run()
    set_1 = {tuple_1, tuple_1, tuple_1, tuple_1}
    str_1 = '/6 '
    float_1 = -4542.92
    dict_0 = {float_1: str_2}
    list_1

# Generated at 2022-06-25 07:44:01.291134
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:44:05.771508
# Unit test for constructor of class ActionModule
def test_ActionModule():
  # testing
  test_case_0()
  test_ActionModule()
  test_run()
  test_case_0()

# Generated at 2022-06-25 07:44:14.382565
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'5H^F5f'
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0}
    tuple_0 = (bytes_0,)
    str_0 = 'k{93gX5}5[H3q'
    float_0 = -3363.67
    list_0 = [bytes_0, float_0]
    bool_0 = False
    action_module_0 = ActionModule(set_0, tuple_0, str_0, float_0, list_0, bool_0)
    var_0 = action_run()
    tuple_1 = (bytes_0,)
    set_1 = {set_0, tuple_0}
    str_1 = '2'
    float_1 = 1695.9

# Generated at 2022-06-25 07:44:24.362297
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b''
    set_0 = {bytes_0, bytes_0, bytes_0}
    tuple_0 = ()
    str_0 = '\\bL\\(([^)]+), *([^)]+)\\)'
    float_0 = 918.17327
    list_0 = [bytes_0, float_0]
    bool_0 = True
    action_module_0 = ActionModule(set_0, tuple_0, str_0, float_0, list_0, bool_0)
    assert action_module_0._VALID_ARGS == frozenset({'per_host', 'aggregate', 'data'})
    assert action_module_0._task.action == set_0
    assert action_module_0._task.args == tuple_0
    assert action_module_0._task

# Generated at 2022-06-25 07:44:25.581899
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # test that the class can be instantiated
    tmp = None
    task_vars = dict()
    action_module = ActionModule(tmp, task_vars)


# Generated at 2022-06-25 07:44:36.000970
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = bytes(10)
    set_0 = {bytes_0, bytes_0, bytes_0, bytes_0, bytes_0}
    tuple_0 = ()
    str_0 = '\\bL\\(([^)]+), *([^)]+)\\)'
    float_0 = -918.17327
    list_0 = [bytes_0, float_0]
    bool_0 = True
    action_module_0 = ActionModule(set_0, tuple_0, str_0, float_0, list_0, bool_0)
    var_0 = '\\bL\\(([^)]+), *([^)]+)\\)'
    int_0 = -406
    dict_0 = {bytes_0: var_0}

# Generated at 2022-06-25 07:44:42.960452
# Unit test for constructor of class ActionModule
def test_ActionModule():
  set_2 = {}
  tuple_2 = ()
  str_3 = '~'
  float_2 = -711.8
  list_2 = [tuple_2]
  bool_1 = False
  action_module_3 = ActionModule(set_2, tuple_2, str_3, float_2, list_2, bool_1)


# Generated at 2022-06-25 07:45:10.451815
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    str_0 = 'd1f#^(pmm:Z%t_46X[8'
    float_0 = -79.30
    list_0 = [tuple_0, float_0]
    action_module_0 = ActionModule(tuple_0, tuple_0, str_0, float_0, list_0)
    tmp = test_case_0()
    task_vars = test_case_0()
    var_0 = action_module_0.run(tmp, task_vars)
    var_1 = action_module_0.run(tmp, task_vars)
    var_2 = action_module_0.run(tmp, task_vars)

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 07:45:15.952614
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = frozenset({''})
    tuple_0 = ()
    str_0 = '\\bL\\(([^)]+), *([^)]+)\\)'
    float_0 = 918.17327
    list_0 = ['']
    bool_0 = True
    action_module_0 = ActionModule(set_0, tuple_0, str_0, float_0, list_0, bool_0)
    tmp = None
    task_vars = None
    result = action_module_0.run(tmp, task_vars)
    assert isinstance(result, dict)
    assert len(result) == 3
    assert 'msg' in result
    assert 'ansible_stats' in result
    assert 'failed' in result

# Code for 'run' method of class ActionModule

# Generated at 2022-06-25 07:45:26.443775
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = {b''}
    tuple_0 = ()
    str_0 = ''
    float_0 = 0.0
    list_0 = []
    bool_0 = False
    action_module_0 = ActionModule(set_0, tuple_0, str_0, float_0, list_0, bool_0)
    set_1 = {b''}
    tuple_1 = ()
    str_1 = ''
    float_1 = 0.0
    list_1 = []
    bool_1 = False
    action_module_1 = ActionModule(set_1, tuple_1, str_1, float_1, list_1, bool_1)
    set_2 = {b''}
    tuple_2 = ()
    str_2 = ''
    float_2 = 0.0
    list

# Generated at 2022-06-25 07:45:36.113599
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = action_run()
    tuple_0 = (b'Y',)
    set_0 = {tuple_0, tuple_0, tuple_0, tuple_0}
    str_0 = 'j7n<`N/|t7'
    float_0 = -8453.18
    list_0 = [tuple_0, float_0]
    bool_0 = True
    action_module_0 = ActionModule(tuple_0, set_0, str_0, float_0, list_0, bool_0)
    int_0 = -211
    list_1 = [b'', -8453.18]
    bytes_0 = b'aX0z^%T'

# Generated at 2022-06-25 07:45:45.490817
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    data_0 = 'X'
    set_2 = {bytes_0, bytes_0, bytes_0}
    tuple_2 = ()
    str_3 = '\\bL\\(([^)]+), *([^)]+)\\)'
    float_2 = 918.17327
    list_2 = [bytes_0, float_2]
    bool_1 = True
    action_module_3 = ActionModule(set_2, tuple_2, str_3, float_2, list_2, bool_1)
    str_4 = 'C=!-6X'
    dict_1 = {str_4: list_0}
    action_module_3.run(data_0, dict_1)



# Generated at 2022-06-25 07:45:55.716529
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'v!u>5\xe8\x03=\x16\x15\x00\x17\xac\xcc-\x82\xa0\x8b\xec\xae\x1c\xaa\xfb\x14\x0c\x8c#\xfb\x9b\x1b>\x8b\xe2\x10\xbb'
    str_0 = '\'\"\\9'
    float_0 = 8.88817
    list_0 = [bytes_0]
    bool_0 = True
    action_module_0 = ActionModule(None, None, str_0, float_0, list_0, bool_0)
    # Test that .run() is invoked properly

# Generated at 2022-06-25 07:45:58.942312
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {'action_module': 'ActionModule', 'data': 'data'}
    action_module_0 = ActionModule(dict_0)


# Generated at 2022-06-25 07:46:09.175720
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = {float_1, float_1, float_0}
    float_2 = -124.927
    str_3 = '\\bL\\(([^)]+), *([^)]+)\\)'
    float_3 = 4417.7
    float_4 = -7.5
    list_2 = [float_2, str_3, str_1, float_1, dict_0, list_1, bytes_0]
    list_3 = [dict_0, float_0, float_2, float_2, float_4, float_4, float_0, float_1, float_0]
    action_module_3 = ActionModule(set_0, list_3, set_1, float_3, list_2, list_1)

# Generated at 2022-06-25 07:46:11.293734
# Unit test for constructor of class ActionModule
def test_ActionModule():
    Args_0 = {'per_host': False, 'data': {}, 'aggregate': True}
    assert not ActionModule.run('tmp', 'task_vars')

test_case_0()

# Generated at 2022-06-25 07:46:15.979183
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(set_0, tuple_0, str_0, float_0, list_0, bool_0)
    assert action_module.tmp == set_0
    assert action_module.task_vars == tuple_0
    assert action_module.play_context == str_0
    assert action_module.loader_name == float_0
    assert action_module.per_host == list_0
    assert action_module.task_vars == bool_0

# Generated at 2022-06-25 07:47:02.667525
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test number of arguments and argument names
    bytes_0 = b''
    set_0 = {bytes_0, bytes_0, bytes_0}
    tuple_0 = ()
    str_0 = '\\bL\\(([^)]+), *([^)]+)\\)'
    float_0 = 918.17327
    list_0 = [bytes_0, float_0]
    bool_0 = True
    action_module_0 = ActionModule(set_0, tuple_0, str_0, float_0, list_0, bool_0)
    assert len(action_module_0.__dict__) == 6
    assert list(action_module_0.__dict__.keys())[0] == "_task"

# Generated at 2022-06-25 07:47:07.256237
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: Implement this test for ActionModule.__init__(self, args, tmp, task_vars, module_name, module_args, task_include)
    assert True


# Generated at 2022-06-25 07:47:17.598661
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b''
    set_0 = {bytes_0, bytes_0, bytes_0}
    tuple_0 = ()
    str_0 = '\\bL\\(([^)]+), *([^)]+)\\)'
    float_0 = 918.17327
    list_0 = [bytes_0, float_0]
    bool_0 = True
    action_module_0 = ActionModule(set_0, tuple_0, str_0, float_0, list_0, bool_0)
    var_0 = action_run()
    tuple_1 = (bytes_0,)
    set_1 = {tuple_1, tuple_1, tuple_1, tuple_1}
    str_1 = '/6 '
    float_1 = -4542.92
    action_module_1 = Action

# Generated at 2022-06-25 07:47:27.945459
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = {'\\W\\B8', '\\W\\B8', '\\W\\B8', '\\W\\B8'}
    tuple_0 = ()
    str_0 = ' #'
    float_0 = 0.12
    list_0 = []
    bool_0 = False
    action_module_0 = ActionModule(set_0, tuple_0, str_0, float_0, list_0, bool_0)
    var_0 = action_run()
    tuple_1 = ('^\\S(\\S+\\S+)',)
    set_1 = set()
    str_1 = '5'
    float_1 = -4798.3
    list_1 = []
    bool_1 = True

# Generated at 2022-06-25 07:47:30.226221
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Initialize an instance of `ActionModule` class
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-25 07:47:31.280018
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:47:33.118534
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:47:43.306708
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'kC+^N;'
    set_0 = {bytes_0, bytes_0, bytes_0}
    tuple_0 = (set_0, set_0, set_0)
    str_0 = '\\bL\\(([^)]+), *([^)]+)\\)'
    float_0 = 918.17327
    list_0 = [bytes_0, float_0]
    bool_0 = True
    action_module_0 = ActionModule(set_0, tuple_0, str_0, float_0, list_0, bool_0)
    var_0 = action_run()
    dict_0 = {str_0: tuple_0}
    list_1 = [bool_0, bytes_0, action_module_0]
    action_module_1 = Action

# Generated at 2022-06-25 07:47:46.579457
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_run = action_module_0.run()
    assert isinstance(action_run, dict)


# Generated at 2022-06-25 07:47:55.089116
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = {'(', '/[:^)`', 'h{0M^nizvJ8Z'}
    str_0 = '\\P[(])'
    float_0 = -3.69
    list_0 = [str_0, -2.6, float_0]
    bool_0 = True
    action_module_0 = ActionModule(set_0, set_0, float_0, float_0, list_0, bool_0)
    float_1 = -1.37
    str_1 = '0e[v'
    dict_0 = {str_0: str_0, str_1: str_1, 'ztcqg]p': float_1, float_1: str_0, str_1: float_0}

# Generated at 2022-06-25 07:49:34.778256
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x_0 = {bytes_0, bytes_0}
    action_module_0 = ActionModule(x_0, str_0, str_1, set_1, dict_0, list_1)
    assert memoized_func_0(dict_0, action_module_2) == (None, set_1, str_1, dict_0)
    action_module_2.run()


# Generated at 2022-06-25 07:49:42.257532
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    float_1 = float_0
    tuple_1 = (1, float_1, float_0)
    set_2 = {tuple_1}
    set_1 = {tuple_0, float_0, float_1, set_2}
    set_0 = {tuple_0, float_0, float_1, set_1}
    float_2 = float_0
    action_module_0 = ActionModule(set_0, tuple_0, str_1, float_2, list_1, bool_0)

    task_vars = {}
    action_module_0.run(None, task_vars)


# Generated at 2022-06-25 07:49:44.988873
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = {}
    set_1 = {}
    str_2 = '`'
    float_3 = -0.00038
    list_4 = []
    bool_5 = False
    action_module_6 = ActionModule(tuple_0, set_1, str_2, float_3, list_4, bool_5)
    assert isinstance(action_module_6, ActionModule) == True


# Generated at 2022-06-25 07:49:50.384622
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'='
    set_0 = {bytes_0, bytes_0, bytes_0}
    tuple_0 = ()
    str_0 = '+'
    float_0 = 794.89073
    list_0 = []
    bool_0 = False
    action_module_0 = ActionModule(set_0, tuple_0, str_0, float_0, list_0, bool_0)
    tuple_1 = (bytes_0,)
    set_1 = {tuple_1, tuple_1}
    str_1 = '0z'
    float_1 = -0.0023451218
    action_module_1 = ActionModule(tuple_1, set_1, str_1, float_1, set_1, str_1)

# Generated at 2022-06-25 07:50:00.650853
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b''
    set_0 = {bytes_0, bytes_0, bytes_0}
    tuple_0 = ()
    str_0 = '\\bL\\(([^)]+), *([^)]+)\\)'
    float_0 = 918.17327
    list_0 = [bytes_0, float_0]
    bool_0 = True
    action_module_0 = ActionModule(set_0, tuple_0, str_0, float_0, list_0, bool_0)
    str_1 = 'f~G'
    bool_1 = True
    action_module_0._task.args = {'data': {str_1: bool_1}, 'per_host': bool_0, 'aggregate': bool_1}

# Generated at 2022-06-25 07:50:07.316223
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b''
    set_0 = {bytes_0, bytes_0, bytes_0}
    tuple_0 = ()
    str_0 = '\\bL\\(([^)]+), *([^)]+)\\)'
    float_0 = 918.17327
    list_0 = [bytes_0, float_0]
    bool_0 = True
    action_module_0 = ActionModule(set_0, tuple_0, str_0, float_0, list_0, bool_0)
    var_0 = action_run()
    tuple_1 = (bytes_0,)
    set_1 = {tuple_1, tuple_1, tuple_1, tuple_1}
    str_1 = '/6 '
    float_1 = -4542.92
    action_module_1 = Action

# Generated at 2022-06-25 07:50:08.265441
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 1 == 1


# Generated at 2022-06-25 07:50:08.931078
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule = ActionModule()


# Generated at 2022-06-25 07:50:12.834158
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, object)
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 07:50:22.607436
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b''
    set_0 = {bytes_0, bytes_0, bytes_0}
    tuple_0 = ()
    str_0 = '\\bL\\(([^)]+), *([^)]+)\\)'
    float_0 = 918.17327
    list_0 = [bytes_0, float_0]
    bool_0 = True
    action_module_0 = ActionModule(set_0, tuple_0, str_0, float_0, list_0, bool_0)
    var_0 = action_run()
    tuple_1 = (bytes_0,)
    set_1 = {tuple_1, tuple_1, tuple_1, tuple_1}
    str_1 = '/6 '
    float_1 = -4542.92
    action_module_1 = Action