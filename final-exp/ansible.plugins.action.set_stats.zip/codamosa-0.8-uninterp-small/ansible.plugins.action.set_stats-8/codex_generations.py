

# Generated at 2022-06-25 07:41:47.977186
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 512.0
    tuple_0 = (b'\x0c\xee\x96', b'\x0c\xee\x96', float_0, float_0, float_0, float_0, float_0)
    set_0 = {'aW6vyo\r%};+BhKJ\x0b`DZ', 'aW6vyo\r%};+BhKJ\x0b`DZ', 'aW6vyo\r%};+BhKJ\x0b`DZ', 512.0}
    str_0 = 'aW6vyo\r%};+BhKJ\x0b`DZ'
    bytes_0 = b'\x0c\xee\x96'
    dict_0 = {}
    dict

# Generated at 2022-06-25 07:41:54.423246
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '&h`7}|'
    float_0 = 1309.522025
    set_0 = {'y,Ti\x0f', float_0}
    str_1 = 'i,F4f'
    bytes_0 = b'\xf1\xdf\x11G'
    float_1 = 917.86834
    set_1 = {float_1, '<=i'}
    action_module_0 = ActionModule(str_0, str_0, set_0, bytes_0, str_1, float_1, set_1)
    # TODO: Should not have any asserts.
    assert action_module_0.run() == True

# Generated at 2022-06-25 07:42:01.506446
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    global str_0
    global float_0
    global set_0
    global bytes_0
    global action_module_0
    str_0 = 'aW6vyo\r%};+BhKJ\x0b`DZ'
    float_0 = 512.0
    set_0 = {str_0, str_0, float_0}
    bytes_0 = b'\x0c\xee\x96'
    action_module_0 = ActionModule(str_0, str_0, set_0, bytes_0, str_0, float_0)
    tmp = None
    task_vars = None
    result = action_module_0.run(tmp, task_vars)
    print(result)

test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 07:42:07.016472
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'I[m@lYwD)m'
    float_0 = 97.35
    set_0 = {float_0, str_0, str_0, float_0}
    bytes_0 = chr(61) + chr(103) + chr(41)
    action_module_0 = ActionModule(str_0, str_0, set_0, bytes_0, str_0, float_0)
    action_module_0.run(None, None)


# Generated at 2022-06-25 07:42:14.346712
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create object
    str_0 = 'I6S%<'
    list_0 = [type('', (), {'__init__': (lambda self: self.__setattr__('wa0I', 0)), '__repr__': (lambda self: repr(getattr(self, 'wa0I'))), '__str__': (lambda self: str(getattr(self, 'wa0I')))})(), dict(__defaults__={'\x17': 0.0})]
    set_0 = {str_0, str_0, str_0, float}
    bytes_0 = b'\x0c\xee\x96'
    str_2 = 'Fhu~'
    float_1 = 512.0

# Generated at 2022-06-25 07:42:25.338662
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = ')#3`b#f=\x0cN\x17\'A.\x19;U6'
    tuple_0 = (182.3, 58.0, False, 658.859, 128.0)
    assert type(tuple_0) == tuple

# Generated at 2022-06-25 07:42:29.654656
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Yi.9XA;m?_\x1bZ#\x1c/\x18}'
    int_0 = 8
    str_1 = 'Nr\r\x16F\x1c\x14\x10\x16\x1e'
    float_0 = 424.0
    str_2 = 'T\x0f\x1e\x0eW\xa8\x00\x1a\x06\x01\x05\x19\n'
    str_3 = 'W8aX*j\x03{\x06\x19\x0b\x10\x01\x00)N\x1d]|'
    set_0 = {str_3}
    float_1 = 2.0

# Generated at 2022-06-25 07:42:33.743107
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'p'
    float_0 = 865.828194969
    set_0 = {float_0, float_0, float_0}
    bytes_0 = b'\x17\x9e\x01'
    action_module_0 = ActionModule(str_0, str_0, set_0, bytes_0, str_0, float_0)


# Generated at 2022-06-25 07:42:39.018512
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "\x30\x3b\x27\x2e\x55\x2c\x0b\x49\x6f\x6e\x6e\x6f\x75\x67\x68\x26\x74\x69"
    action_module_0 = ActionModule(str_0, str_0, set(), bytes(), str_0)
    str_0 = "\x74\x68\x69\x73\x20\x69\x73\x20\x61\x20\x74\x65\x73\x74\x20\x6e\x6f\x74\x65"

# Generated at 2022-06-25 07:42:44.532532
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test case from the documentation
    str_0 = '0=TgT\x7f:w\x1b[\x15\x00\x11Mz\x1c\x0exA\x12\x08m\x0b'
    float_0 = 0.0
    set_0 = {str_0, str_0, str_0, str_0, str_0}
    bytes_0 = b'\x96\x0e\x08'
    action_module_0 = ActionModule(str_0, float_0, float_0, float_0, float_0, float_0)
    # Test case from the documentation
    str_0 = '\x06\x10\x1d\x08\x1d\x1a'
    float_0 = 5.8559

# Generated at 2022-06-25 07:42:52.293250
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:43:02.361877
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    str_0 = "\x0e\r\r\x1b\\N\x12\x1f\\"
    str_1 = '\x1c^\x1b\x18\x12\x1a\x1c\x12\x16\x11\x13O\x1c\x1a\x1d\x1e\x11\x17\x01\x13\x0c\x1b\r\r\r\x1f\x0e'
    str_2 = "!\x1d\x0cS\x1b\x0dB\x1d\x1f\x18V\x1c\x1d\x1c\x0c\x05R"

# Generated at 2022-06-25 07:43:08.450201
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "KkN;V3q<&*\x0c"
    str_1 = "z4b\x15"
    str_2 = "5\n"
    str_3 = "data"
    str_4 = "per_host"
    argv_0 = {str_3: {str_0: {str_1: str_2}, str_4: 'true'}}
    str_5 = "smmmmsm"
    str_6 = "smmmmsm"
    str_7 = "smmmmsm"
    str_8 = "smmmmsm"
    str_9 = "smmmmsm"
    str_10 = "smmmmsm"
    str_11 = "smmmmsm"
    str_12 = "smmmmsm"
    str

# Generated at 2022-06-25 07:43:09.294292
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:43:15.885745
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "0;'.U,\x0bIonnough&ti"
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, str_0)
    str_1 = 'this is a test note'
    action_module_0._task.args = {}
    str_2 = 'data'
    action_module_0._task.args[str_2] = str_1
    str_3 = 'aggregate'
    str_4 = 'False'
    action_module_0._task.args[str_3] = str_4
    str_5 = 'per_host'
    str_6 = 'True'
    action_module_0._task.args[str_5] = str_6

# Generated at 2022-06-25 07:43:18.907544
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "0;'.U,\x0bIonnough&ti"
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 07:43:23.736513
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        str_0 = "0;'.U,\x0bIonnough&ti"
        action_module_0 = ActionModule(str_0, str_0, str_0, str_0, str_0)
        str_1 = 'this is a test note'
    except Exception as exception:
        print('Caught an exception when testing the constructor of class ActionModule:\n' + exception.__str__())
    else:
        print('The constructor of class ActionModule works fine!')


# Generated at 2022-06-25 07:43:27.319579
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "0;'.U,\x0bIonnough&ti"
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, str_0)
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:43:36.524701
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test execution of ActionModule.run(tmp, task_vars)
    # Create an instance of the class
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, str_0)

    # Create an instance for parameter 'tmp'
    tmp_0 = '/etc'

    # Create an instance of class 'dict'
    dict_0 = dict()

    task_vars_0 = dict_0
    # Call method 'run' of 'ActionModule' with arguments (tmp_0, task_vars_0)
    result_0 = action_module_0.run(tmp_0, task_vars_0)



# Generated at 2022-06-25 07:43:45.689648
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'foo'
    str_1 = 'bar'
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, str_0)
    dict_0 = {}
    dict_0['data'] = str_1
    dict_0['aggregate'] = str_0
    dict_0['per_host'] = str_0

# Generated at 2022-06-25 07:43:55.048175
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:44:02.365468
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host_name_0 = 'host_name_0'
    connection_0 = 'connection_0'
    task_vars_0 = dict()
    loader_0 = 'loader_0'
    play_context_0 = 'play_context_0'
    task_name_0 = 'task_name_0'
    action_module_0 = ActionModule(host_name_0, connection_0, task_vars_0, loader_0, play_context_0, task_name_0)
    action_module_0 = ActionModule(host_name_0, connection_0, task_vars_0, loader_0, play_context_0)
    action_module_0 = ActionModule(host_name_0, connection_0, task_vars_0, loader_0)

# Generated at 2022-06-25 07:44:04.251616
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-25 07:44:07.477029
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '83Ym,\x18RxJ'
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, str_0)
    assert isinstance(action_module_0, ActionModule) == True


# Generated at 2022-06-25 07:44:13.160535
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "A[{3#r*1L7\x0b+e\x0b"
    str_1 = "iq\x0b&K~Jg\\\x0b"
    str_2 = ";\x0bir\x0cH\x0b,\x0b\x0c"
    str_3 = "3\x0bF~\x0c\x0c'\x0b\x0b"
    str_4 = "u2X\x0c^\x0c"
    action_module_0 = ActionModule(str_0, str_1, str_2, str_3, str_4)
    action_module_1 = ActionModule(str_2, str_2, str_1, str_0, str_2)
    str

# Generated at 2022-06-25 07:44:21.071248
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "*>3@|\x0b]\x0c\x0b\x15\x1d\x1f\x15\x1f\x15\x11\n(*(L$\n/"
    str_1 = "=\'k8\x04\x15\x19\x15\x1f\x00\x1f\x1d\x1f\x15\x10\x01xd\x01\x17B\x15\x1f\x15\x1f\x15\x1f"

# Generated at 2022-06-25 07:44:25.964707
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    string_0 = 'Y'
    string_1 = '|'
    string_2 = '5'
    string_3 = '9'
    string_4 = 'p'
    string_5 = 'M'
    string_6 = 'i'
    string_7 = '{'
    string_8 = '>'
    string_9 = 'r'
    string_10 = '('
    string_11 = ']'
    string_12 = 'K'
    string_13 = 'P'
    string_14 = 'q'
    string_15 = '&'
    string_16 = '>'
    string_17 = 'K'
    string_18 = ','
    string_19 = 'j'
    string_20 = 'O'
    string_21 = 'c'
    string_22

# Generated at 2022-06-25 07:44:36.026142
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "0;'.U,\x0bIonnough&ti"
    str_1 = "4'\x12\x15\x0e;P\x11A\x03\x0f:5\x1f\x1a\x15]"
    str_2 = "=\x0f\x1ci\x1a\x14\x0c\x0eF\x1d\x1a\x15\t\x0c\x00\x0f\x15\x1c\x0e\x0e\x1c\x1a\x0e."

# Generated at 2022-06-25 07:44:36.595552
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-25 07:44:40.459384
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # test case 0
    test_case_0()

# Generated at 2022-06-25 07:44:51.205160
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        ActionModule()
    except Exception as ex:
        assert isinstance(ex, NotImplementedError)


# Generated at 2022-06-25 07:45:03.072849
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -2019

# Generated at 2022-06-25 07:45:12.955812
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -2019

# Generated at 2022-06-25 07:45:22.770235
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -2019

# Generated at 2022-06-25 07:45:29.194585
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    int_0 = -2019

# Generated at 2022-06-25 07:45:37.629128
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -2019

# Generated at 2022-06-25 07:45:47.890040
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -2019

# Generated at 2022-06-25 07:45:51.471412
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test constructor of class ActionModule
    # TODO: assert stuff
    str_0 = ''
    dict_0 = {}
    str_1 = ''
    set_0 = set()
    int_0 = 0
    list_0 = []
    var_0 = ActionModule(str_0, dict_0, str_1, set_0, int_0, list_0)



# Generated at 2022-06-25 07:46:01.830370
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -2019

# Generated at 2022-06-25 07:46:09.742892
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -2019

# Generated at 2022-06-25 07:46:35.289980
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:46:39.727896
# Unit test for constructor of class ActionModule
def test_ActionModule():
  action_module_0 = ActionModule("", {}, "", "", "", "")


# Generated at 2022-06-25 07:46:45.924820
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "n\xe2\xbd\xff\x82\x1d\xa5\xcf\xd5\xca\xcf\x7f\x10\x93\x8a\xf5\x7f\xec\x84\xca\xcf\x7f\x10\x93\x8a\xf5\x7f\xec\x84\xca\xcf\x7f\x10\x93\x8a\xf5\x7f\xec\x84\xca"
    dict_0 = {str_0: str_0, str_0: str_0}

# Generated at 2022-06-25 07:46:54.813578
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  int_0 = -2019

# Generated at 2022-06-25 07:47:03.125276
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -2019

# Generated at 2022-06-25 07:47:08.069351
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -2019

# Generated at 2022-06-25 07:47:17.654688
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_1 = -1718
    dict_1 = {"R\x9f\x0e\xb3\xdfi": "R\x9f\x0e\xb3\xdfi", b's': "R\x9f\x0e\xb3\xdfi", "R\x9f\x0e\xb3\xdfi": "R\x9f\x0e\xb3\xdfi"}
    set_1 = set()
    int_0 = -2019
    list_1 = [int_0, dict_1, b'\xbc\x0f\xdf\x1b\xc1\xfe\xd6\x0b\x92\xd1\xe9\x89\xec\xbd\xce\xbb\x17o\xe2']

# Generated at 2022-06-25 07:47:27.996101
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        from ansible.module_utils.parsing.convert_bool import boolean
    except ImportError:
        print("SKIP: missing module (convert_bool) required for this test")
        return

    int_2 = 3
    str_1 = ""
    str_2 = "{'failed': True, 'msg': 'The variable name '%s' is not valid. Variables must start with a letter or underscore character, and contain only letters, numbers and underscores.'}"
    str_3 = "/bin/false"
    int_3 = 0
    str_4 = "changed"
    int_4 = -1907
    int_5 = 1
    int_6 = -1836
    str_5 = "ls cannot access foo: No such file or directory"

# Generated at 2022-06-25 07:47:35.572054
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def mock_run_0(self, tmp=None, task_vars=None):
        dict_0 = {}
        str_0 = '\x89\xe0\xd1\x8c\xe5\xa2\xaf\xf2'
        dict_0[str_0] = str_0
        return dict_0

    ActionModule_run_ret_0 = mock_run_0(0)
    ActionModule_run_ret_1 = mock_run_0(0)
    ActionModule_run_ret_2 = mock_run_0(0)
    ActionModule_run_ret_3 = mock_run_0(0)
    ActionModule_run_ret_4 = mock_run_0(0)
    ActionModule_run_ret_5 = mock_run_0(0)
    ActionModule

# Generated at 2022-06-25 07:47:45.777409
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:48:27.924965
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    action_module = ActionModule()


    # Preparation
    def run(tmp, task_vars):
        return tmp, task_vars

    # Exercise
    ret = action_module.run()

    # Verify
    tmp = ret[0]
    task_vars = ret[1]
    assert tmp is None
    assert task_vars == {}


# Testing method run of class ActionModule

# Generated at 2022-06-25 07:48:36.627483
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -2019

# Generated at 2022-06-25 07:48:45.771709
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with valid arguments
    a = ActionModule(action_name = "test",
                     task_name = "test",
                     task_args = {},
                     task_vars = {},
                     loader = "loader",
                     templar = "templar",
                     shared_loader_obj = None)

    assert a._task.action == "test"
    assert a._task.name == "test"
    assert a._task.args == {}
    assert a._task.action_args == {}
    assert a._loader == "loader"
    assert a._templar == "templar"
    assert a._shared_loader_obj is None



# Generated at 2022-06-25 07:48:54.683570
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -2019

# Generated at 2022-06-25 07:49:01.288398
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -2019

# Generated at 2022-06-25 07:49:07.790050
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = bool()
    bool_1 = bool()
    str_0 = str()
    dict_0 = dict()
    set_0 = set()
    int_0 = int()
    list_0 = list()
    action_module_0 = ActionModule(str_0, dict_0, str_0, set_0, int_0, list_0)
    action_run(str_0, list_0 < str_0, str_0, dict_0, set_0, int_0, list_0)

# Generated at 2022-06-25 07:49:16.464406
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -2019

# Generated at 2022-06-25 07:49:20.432683
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 9014
    str_0 = '\x1e\xab\x0c'
    set_0 = set()
    int_1 = -1633
    list_0 = [int_1, str_0, str_0]
    action_module_0 = ActionModule(str_0, str_0, str_0, set_0, int_1, list_0)

    # Call the method
    method = getattr(action_module_0, "run")
    result = method(int_0)


# Generated at 2022-06-25 07:49:31.572593
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Default input parameters
    tmp = None
    task_vars = None

    action_module_0 = ActionModule('str', {'str': 'str'}, 'str', set(), -25625, [78, {'str': 'str'}, b'U\xba\x8c\xa6\xe2\xde\x1a\x8d\xab\x14\xbf', -25625, {'str': 'str'}])

    # Action
    var_0 = action_module_0.run(tmp, task_vars)

    # Test the results
    assert var_0['ansible_stats']['per_host'] == False
    assert isinstance(var_0['ansible_stats']['data']['str'], string_types)

# Generated at 2022-06-25 07:49:42.866808
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -2019

# Generated at 2022-06-25 07:51:25.262085
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:51:31.893416
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    int_0 = -2019