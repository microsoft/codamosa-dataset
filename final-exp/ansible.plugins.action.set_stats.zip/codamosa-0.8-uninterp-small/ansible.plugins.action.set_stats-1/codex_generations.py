

# Generated at 2022-06-25 07:41:47.149568
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_arg_0 = {}
    int_arg_0 = -159
    str_arg_0 = 'g\xd1-\xc7\xaf\xed\x83\xee\xf6\x9d\xba\xc8'

# Generated at 2022-06-25 07:41:54.488318
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -6
    dict_0 = dict()
    dict_0['0'] = list()
    dict_0['0'].append('<')
    dict_0['0'].append('')
    dict_0['0'].append('_')
    dict_0['1'] = list()
    dict_0['1'].append('7m')
    dict_0['1'].append('W')
    dict_0['1'].append(')')
    dict_1 = dict()
    dict_0['2'] = list()
    dict_0['2'].append('J')
    dict_0['2'].append('4')
    dict_0['2'].append('b')
    dict_1['0'] = dict_0
    dict_0['3'] = list()
   

# Generated at 2022-06-25 07:41:55.411528
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:42:03.301344
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Dw\x8f\xe1\x82\x10\xcc<\x1f\x05&f\xee\xfe\xbf'
    dict_0 = {str_0: str_0}
    str_1 = '\xee\xd3A\xb7\xfe\xa2\x1f'
    int_0 = -210
    bytes_0 = b'\xdd\xf4\xb4\xdbGSb~?j\xbe\xc3\xa51'
    list_0 = [str_0, str_0]
    action_module_0 = ActionModule(dict_0, int_0, str_0, bytes_0, list_0, dict_0)

    # call the method run
    assert not action_module_0.run()

# Generated at 2022-06-25 07:42:09.178772
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Test run')
    str_0 = '+\xeb'
    bool_0 = False
    task_vars_0 = {}
    tmp_0 = '\x1a\xdd'
    int_0 = 8
    list_0 = [tmp_0, str_0]
    action_module_0 = ActionModule(task_vars_0, tmp_0, int_0, str_0, list_0, {str_0: bool_0, tmp_0: tmp_0})
    action_module_0.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 07:42:09.944336
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:42:11.489789
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:42:12.097710
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:42:16.573652
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Copy argument specification
    args = {}
    args.update(ActionModule._VALID_ARGS)

    # Initialize method data
    data = {}

    # Initialize module arguments
    aggregate = False
    per_host = True

    # Initialize object attributes
    result = {'ansible_stats': {}}
    result['ansible_stats']['data'] = data
    result['ansible_stats']['aggregate'] = aggregate
    result['ansible_stats']['per_host'] = per_host

    # Mock default value for result
    result.update({'ansible_stats': None})

    # Invoke method
    set_stats_0 = ActionModule(result, tmp, task_vars)

# Mocking of variables


# Generated at 2022-06-25 07:42:27.314508
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = dict({'REQUEST_METHOD': 'GET', 'QUERY_STRING': '', 'REMOTE_ADDR': '127.0.0.1', 'HTTP_USER_AGENT': '', 'PATH_INFO': '/run'})
    int_0 = 10
    str_0 = '|>&\x0b\x12<m\x97\x84\x00\x0b\x1b\x81\x94\x8c\x84\x8c\x88\x88'
    bytes_0 = b'\xff\xe5\xb4\xf6\x82w\x80\xa5\x94\xb5\x8e\xf1\xbe\xc3\x01\xbe'

# Generated at 2022-06-25 07:42:32.727928
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:42:34.086092
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = ActionModule()
    assert result.TRANSFERS_FILES == False
    assert result._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-25 07:42:34.700200
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule()
    a.run()

# Generated at 2022-06-25 07:42:35.705615
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:42:41.594423
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = {}
    int_0 = -159
    str_0 = 'gÑ-Ç¯í\x83îö\x9dºÈ'
    var_1 = {int_0: str_0}

    obj = ActionModule()

    return obj


# Generated at 2022-06-25 07:42:44.099800
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    if action_module_0.data is None:
        print("data of action_module_0 is None")
    else:
        print("data of action_module_0 is", action_module_0.data)


# Generated at 2022-06-25 07:42:49.195441
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # variable 'host_0' assigned type <class 'str'> with value 'G'
    host_0 = 'G'
    # variable 'task_vars_0' assigned type <class 'dict'> with value '{}'
    task_vars_0 = {}
    # variable 'result_0' assigned type <class 'dict'> with value '{}'
    result_0 = {}
    # variable 'self_0' assigned type <class 'ansible.plugins.action.ActionModule'> with value
    # variable 'self_0' assigned type <class 'ansible.plugins.action.ActionModule'> with value
    self_0 = unittest.mock.create_autospec(ansible.plugins.action.ActionModule, instance=True)
    self_0.run.return_value = result_0
    # variable 'tmp

# Generated at 2022-06-25 07:42:55.925122
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Testing ActionModule.run')
    host_0 = Dummy()
    set_stats_0 = ActionModule(host_0, {}, {}, {}, {})
    
    # Test nesting of method test_case_0
    print('Testing ActionModule.run.test_case_0')
    var_0 = {}
    int_0 = -159
    str_0 = 'gÑ-Ç¯í\x83îö\x9dºÈ'


# Generated at 2022-06-25 07:42:57.200511
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule()
    assert a.run() == "Function not yet implemented"

# Generated at 2022-06-25 07:43:01.216250
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = {}
    int_1 = -159
    str_1 = 'gÑ-Ç¯í\x83îö\x9dºÈ'
    obj_0 = ActionModule(var_1, tmp=None, task_vars=None)


# Generated at 2022-06-25 07:43:07.452055
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:43:08.615540
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert test_case_0() == None


# Generated at 2022-06-25 07:43:15.330630
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case for when aggregate is a boolean type, and per_host is string type
    stats = {'data': {}, 'per_host': False, 'aggregate': True}
    data = {'aggregate': 'True', 'per_host': 'False', 'data': {'test': {'test1': 'test2'}}}
    tmp = None
    task_vars = {}
    action_module_1 = ActionModule()
    action_module_1.run(tmp, task_vars)
    assert action_module_1._task.args == stats


# Generated at 2022-06-25 07:43:16.337839
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:43:18.970936
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_stats = ['ansible_stats','changed','failed','msg','parsed','skipped','user_data']
    x = ActionModule()
    assert len(x.__dict__) == len(set_stats)
    for key in x.__dict__:
        assert key in set_stats

# Unittest to check the constructor

# Generated at 2022-06-25 07:43:20.197145
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None


# Generated at 2022-06-25 07:43:23.039299
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Call method run of ActionModule
    # Use of command <ansible> is not implemented
    # assert action_module_0.run() == 'shell'
    assert True



# Generated at 2022-06-25 07:43:24.938748
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

    assert hasattr(action_module_0, '_VALID_ARGS')
    assert callable(action_module_0.run)


# Generated at 2022-06-25 07:43:27.796067
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert 'ActionBase' in str(ActionBase.__bases__), 'test_ActionModule failed!'


test_case_0()
test_ActionModule()

# Generated at 2022-06-25 07:43:30.105003
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()


# Generated at 2022-06-25 07:43:41.233278
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    action_module_0 = ActionModule(tmp, task_vars)
    try:
        var_0 = action_module_0.run()
        assert var_0
    except AssertionError:
        raise AssertionError('test_ActionModule_run assertion error')



# Generated at 2022-06-25 07:43:49.593037
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {'int_0': -201, 'str_0': '@8x<.5', 'list_0': ['@8x<.5', '@8x<.5'], 'bytes_0': b'\xdd\xf4\xb4\xdbGLb~\x02j\xbe\xc3\xa5W'}
    action_module_0 = ActionModule(dict_0, dict_0['int_0'], dict_0['str_0'], dict_0['bytes_0'], dict_0['list_0'], dict_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:43:54.728719
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True == True


# Generated at 2022-06-25 07:43:58.505623
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Inside test_ActionModule")
    obj = ActionModule("run", "/root", "/tmp", "Ansible", "test", {})
    print("TEST ACTION MODULE: ", obj)
    obj.run("/root", "/tmp","Ansible", "test")
    print("TEST ACTION RUN: ", obj)



# Generated at 2022-06-25 07:44:04.364141
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -4500
    list_0 = [int_0, int_0, int_0, int_0, int_0]
    dict_0 = {int_0: int_0}
    str_0 = '`\xea\xd1\x9a\x13\x07\x1b\x03\x99\x89\x83\x17K{\xf9\x1f\xb1\xc7\x1e2\x8a\xe2\x0f\x1d\xc9\x19\xc0\x07\x94i\xa1\x80'
    bytes_0 = b'\xc3\x9b\xde\xd2'

# Generated at 2022-06-25 07:44:10.923301
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '@8x<.5'
    dict_0 = {str_0: str_0}
    int_0 = -201
    bytes_0 = b'\xdd\xf4\xb4\xdbGLb~\x02j\xbe\xc3\xa5W'
    list_0 = [str_0, str_0]
    assert_raises(TypeError, ActionModule, dict_0, int_0, str_0, bytes_0, list_0, dict_0)
    assert_raises(TypeError, ActionModule, dict_0, int_0, str_0, bytes_0, list_0, dict_0, dict_0)


# Generated at 2022-06-25 07:44:20.449934
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\xa5\x0b\xd9\x1e4\xec\xbb\x0ea\x1d:\xcc\xac\x04\x9a\xd3\x1d\x88f\xdd>\x1a'
    bool_0 = True

# Generated at 2022-06-25 07:44:30.353724
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'h:\x9d\xd8\x9a\xe0\x96\x18\x8e\x0c\xba\xe5\x04'
    dict_0 = {str_0: str_0}
    int_0 = -201
    bytes_0 = b'z\xb3\x1a\x80\x0f\x92\x97\x96\xf6\xaf\xbc\x9f\x0f'
    list_0 = [int_0, int_0]
    action_module_0 = ActionModule({int_0: int_0}, int_0, {int_0: int_0}, bytes_0, list_0, dict_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:44:36.835101
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\xa2\x8e\xaf\xd6\x9b\xd1\x8a\x0f\xed\xcb\x84\xac'
    dict_0 = {str_0: str_0}
    int_0 = -1751765511
    bytes_0 = b'\x0f\x9e>\x8b\xab\xe2\xbd\xf2\x8d'
    list_0 = [str_0, str_0]
    action_module_0 = ActionModule(dict_0, int_0, str_0, bytes_0, list_0, dict_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:44:43.075080
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    data = ('4', 's', '4', 's', 't')
    boolean(data)
    # AssertionError
    # AssertionError
    # AssertionError
    # AssertionError
    # AssertionError
    # AssertionError
    return var_0

# Generated at 2022-06-25 07:44:58.444771
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("test_ActionModule_run")
    try:
        assert True
        if True:
            raise Exception("test_ActionModule_run")
    except AssertionError as e:
        print("AssertionError")
    except Exception as e:
        print("Exception")
    finally:
        print("Finally")
    return


# Generated at 2022-06-25 07:45:03.073123
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    int_0 = 3
    str_0 = '4'
    bytes_0 = b'5'
    list_0 = []
    dict_1 = {}
    action_module_0 = ActionModule(dict_0, int_0, str_0, bytes_0, list_0, dict_1)

# Generated at 2022-06-25 07:45:12.953239
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:45:21.196132
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '@8x<.5'
    dict_0 = {str_0: str_0}
    int_0 = -201
    bytes_0 = b'\xdd\xf4\xb4\xdbGLb~\x02j\xbe\xc3\xa5W'
    list_0 = [str_0, str_0]
    action_module_0 = ActionModule(dict_0, int_0, str_0, bytes_0, list_0, dict_0)
    var_0 = action_module_0.run(size=size(), task_vars=dict())
    return var_0

# Generated at 2022-06-25 07:45:22.769475
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionModule()
    assert var_0.TRANSFERS_FILES == False

# Generated at 2022-06-25 07:45:25.111613
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()

    var_1 = True
    var_2 = True
    res = OneOrMore(cssSelector('#login-form-submit')).click()
    var_0 = var_0 + var_2
    assert var_1 == var_0


# Generated at 2022-06-25 07:45:31.296182
# Unit test for constructor of class ActionModule
def test_ActionModule():
    def __init__(self, args=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None):
        self._load_params()
        self._task.action = self._task.action or 'set_stats'
        if args is None:
            args = dict()
        self._task.args = self._load_args(args)

    return


# Generated at 2022-06-25 07:45:34.127565
# Unit test for constructor of class ActionModule
def test_ActionModule():

    expected_results = {}

    # expected_results['ret_value'] = {}
    ret_value = ActionModule.__init__()
    # assert (ret_value == expected_results['ret_value'])

    return None


# Generated at 2022-06-25 07:45:40.912671
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    int_0 = 0
    str_0 = ''
    bytes_0 = b''
    list_0 = []
    dict_2 = {}
    action_module_1 = ActionModule(dict_0, int_0, str_0, bytes_0, list_0, dict_2)
    assert action_module_1.action_name == 'set_stats'
    assert action_module_1.task_execv_dir == None
    assert action_module_1.task_vars == {}
    assert action_module_1.action_loader == None
    assert action_module_1.task_loader == None
    assert action_module_1.default_vars == {}
    assert action_module_1.module_name == 'set_stats'
    assert action_module_1.return_

# Generated at 2022-06-25 07:45:50.403931
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_2 = {'data': 'data'}
    int_0 = -201
    str_0 = '@8x<.5'
    bytes_0 = b'\xdd\xf4\xb4\xdbGLb~\x02j\xbe\xc3\xa5W'
    list_0 = [str_0, str_0]
    dict_1 = {'aggregate': 'aggregate'}
    tmp = None
    action_module_0 = ActionModule(dict_0, int_0, str_0, bytes_0, list_0, dict_0)
    # .run method 3 call
    task_vars = None
    action_module_0.run(tmp, task_vars)

# Generated at 2022-06-25 07:46:18.876214
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = dict()
    int_0 = 1
    str_0 = ''
    bytes_0 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    list_0 = list()
    dict_1 = dict()
    action_module_0 = ActionModule(dict_0, int_0, str_0, bytes_0, list_0, dict_1)



# Generated at 2022-06-25 07:46:29.903480
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}
    int_0 = 1
    str_0 = 'example'
    bytes_0 = b'\x81\xf8\xdd\xf4\xb4\xdbGLb~\x02j\xbe\xc3\xa5W'
    list_0 = [int_0, int_0, int_0, int_0]
    dict_1 = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}
    action_module_0 = ActionModule(dict_0, int_0, str_0, bytes_0, list_0, dict_1)
    str_1 = 'monkeys'
    bool_0 = action_

# Generated at 2022-06-25 07:46:36.909334
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'PVW\xb0\x19\x9b\xba\x8c\xeb\xf4\xb6\xaf\xe0\xf5\xd6\x00\x0f\x8c\xaa'
    dict_0 = {str_0: str_0}
    int_0 = -201
    bytes_0 = b'\xdd\xf4\xb4\xdbGLb~\x02j\xbe\xc3\xa5W'
    list_0 = [str_0, str_0]
    action_module_0 = ActionModule(dict_0, int_0, str_0, bytes_0, list_0, dict_0)
    var_0 = action_run(action_module_0, dict_0, dict_0)

# Generated at 2022-06-25 07:46:38.782417
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_run_0 = ActionModule({}, {}, {}, {}, {}, True, False)
    assert not action_run_0.action_run()


# Generated at 2022-06-25 07:46:45.618249
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {'wIa': 'E.='}
    int_0 = -124
    str_0 = 'j$\x1e"q\x7f/'
    bytes_0 = b'X\x19\x0e\x1f\x07\x0f\x12\xc5\x08\xb5\x1e\x01'
    list_0 = ['`Zhv\x7f', '`Zhv\x7f']
    dict_1 = {'wIa': 'E.='}
    action_module_0 = ActionModule(dict_0, int_0, str_0, bytes_0, list_0, dict_1)

# Generated at 2022-06-25 07:46:54.737741
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '!@#$%^&*()_+{}[]<>?:;\\"'
    dict_0 = {str_0: str_0}
    int_0 = -201
    bytes_0 = b'\xdd\xf4\xb4\xdbGLb~\x02j\xbe\xc3\xa5W'
    list_0 = [str_0, str_0]
    action_module_0 = ActionModule(dict_0, int_0, str_0, bytes_0, list_0, dict_0)
    result = action_module_0.run(dict_0, dict_0)

# Generated at 2022-06-25 07:47:03.062936
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    int_0 = 0
    str_0 = 'mYT'
    bytes_0 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    list_0 = []
    action_module_0 = ActionModule(dict_0, int_0, str_0, bytes_0, list_0, dict_0)
    assert isinstance(action_module_0._task.action, str)

# Generated at 2022-06-25 07:47:11.667580
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert_0 = ActionModule(str_0, str_0, bytes_0, str_0, dict_0, list_0)
    str_0 = 'foo'
    dict_0 = {str_0: str_0}
    str_1 = 'bar'
    bytes_0 = b''
    list_0 = [str_0, str_0]
    assert_1 = ActionModule(str_0, str_0, bytes_0, str_0, dict_0, list_0)
    str_0 = 'baz'
    str_2 = 'qux'
    dict_0 = {str_0: str_0}
    list_0 = [str_2, str_0]

# Generated at 2022-06-25 07:47:14.344051
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args_0 = {}
    args_0['data'] = ({})
    kwargs_0 = {}
    vars_0 = {}
    module_0 = ActionModule(args_0, kwargs_0)
    var_0 = module_run(**vars_0)
    kwargs_1 = {}
    kwargs_1['vars'] = (var_0)
    var_1 = module_run(**kwargs_1)
    return var_1

# Generated at 2022-06-25 07:47:23.362473
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 1
    dict_0 = {}
    action_module_0 = ActionModule(int_0, dict_0)
    var_0 = action_module_run(dict_0)


if __name__ == '__main__':
    import sys
    import os
    import pytest
    # Change the default cwd() to the program main directory
    os.chdir('/Users/asaw/Dropbox/GitHub/Network/yamllint/tests')
    sys.path.append('/Users/asaw/Dropbox/GitHub/Network/yamllint/tests')

    # unit test
    pytest.main()

# Generated at 2022-06-25 07:48:08.956731
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert not False, "Test if the test_case_0 implementation of test_ActionModule_run is correct."



# Generated at 2022-06-25 07:48:12.924752
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Test: test_ActionModule_run')
    dict_0 = {'data': {'my_var': 'foobar'}}
    action_module_0 = ActionModule(dict_0)
    print(action_module_0)

# Generated at 2022-06-25 07:48:14.225124
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 07:48:24.048801
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {'i,IW': 'i,IW'}
    int_0 = -74
    str_0 = 'Vn.o(uKx`\x1a\xa7'
    bytes_0 = b'\xed\xf5\x96\xdc\x90\x05\x9b\xd0\x83\x8a\x0e\xa0\xdc\x89'
    list_0 = ['Vn.o(uKx`\x1a\xa7', 'Vn.o(uKx`\x1a\xa7']
    dict_1 = {'i,IW': 'i,IW'}

# Generated at 2022-06-25 07:48:27.910370
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = ')sI]\x91'
    dict_0 = {str_0: str_0}
    int_0 = -161
    bytes_0 = b'\xb1\x9b\xcd'
    list_0 = [str_0, str_0]
    action_module_0 = ActionModule(dict_0, int_0, str_0, bytes_0, list_0, dict_0)


# Generated at 2022-06-25 07:48:36.627385
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test 1
    str_1 = 't|Xm\x1c\\\xed\xdf\xb3'
    dict_1 = {str_1: str_1}
    int_1 = 2
    bytes_1 = b'^\x1b\xdb'
    list_1 = [str_1, str_1]
    str_2 = '\x8f\xa6$\x03\x1c\xfe\xc9UG\xfb\x84\x8f\x98\xce\x08\xcaI\xa0\x9f\x89\x86\x19\xe2\xa5N\xdf'
    dict_2 = {str_2: str_2}

# Generated at 2022-06-25 07:48:43.691478
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_1 = {'data': {'aggregate': True, 'per_host': False, 'aggregate': True}}
    int_1 = -3
    str_1 = '\u10e0\ue7c0\u37c0'
    bytes_1 = b'C\xaf\x97\xcd\xd3\x0e\x0f\x9a\xab\x99\xa4\xcc\xb4\xf4\x83\\\xc8\x88\x0c'
    list_1 = [True, False, True]
    dict_2 = {False: False, False: True}
    action_module_1 = ActionModule(dict_1, int_1, str_1, bytes_1, list_1, dict_2)
    assert action_module_1.task

# Generated at 2022-06-25 07:48:49.211843
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = ';\x0b\x1c\x03\x00\x1c\x0f\x10\x18\x14\x0c\x10\x06\n\x05\x06\x18\x14\n\x0c\x18\x00\x01\x1e\x0c\x18\x04\x0f\x0e\x06'
    dict_0 = {str_0: str_0}
    int_0 = -485

# Generated at 2022-06-25 07:48:54.578425
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:49:01.094360
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    int_0 = -1
    str_0 = '`'
    bytes_0 = b'o\xb5\x81\x88P\xad\x8b\xbb\xdb\x9c\xc7\xac\xb1\x1b'
    list_0 = [int_0]
    dict_1 = {}
    action_module_0 = ActionModule(dict_0, int_0, str_0, bytes_0, list_0, dict_1)
    attr_0 = 'run'
    var_0 = action_run((dict_0, -9), dict_0, dict_1)
    assert isinstance(var_0, dict)
    assert var_0 == dict_0


# Generated at 2022-06-25 07:50:49.194726
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing ActionModule.py")

    str_0 = ""
    dict_0 = {str_0: str_0}
    int_0 = -201
    bytes_0 = b'\xdd\xf4\xb4\xdbGLb~\x02j\xbe\xc3\xa5W'
    list_0 = [str_0, str_0]
    action_module_0 = ActionModule(dict_0, int_0, str_0, bytes_0, list_0, dict_0)
    set_stats_0 = action_module_0.run()

# Generated at 2022-06-25 07:50:54.456665
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = dict()
    int_0 = 0
    str_0 = ''
    bytes_0 = b''
    list_0 = ['list_item_0', 'list_item_1', 'list_item_2']
    dict_1 = {'dict_key_0': 'dict_value_0', 'dict_key_1': 'dict_value_1', 'dict_key_2': 'dict_value_2'}
    action_module_0 = ActionModule(dict_0, int_0, str_0, bytes_0, list_0, dict_0)
    action_module_0.action_base_run(dict_0, dict_0)
    var_1 = action_module_0.action_module_run()

# Generated at 2022-06-25 07:51:01.504313
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'r&-^h'
    dict_0 = {str_0: str_0}
    int_0 = -173
    bytes_0 = b'w\xae\xb2\x90\x00\x8a\x936\x07\x1f\xf8\xfb'
    list_0 = [str_0, str_0]
    action_module_0 = ActionModule(dict_0, int_0, str_0, bytes_0, list_0, dict_0)
    assert isinstance(action_module_0, ActionModule)
    # constructor with 0 args
    action_module_1 = ActionModule()
    assert isinstance(action_module_1, ActionModule)


# Generated at 2022-06-25 07:51:02.417612
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert action_module_0 is not None



# Generated at 2022-06-25 07:51:07.737107
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test method run of class ActionModule
    int_0 = -201
    test_module_0 = ActionModule(int_0, int_0)
    test_module_0.run(int_0, int_0)


# Generated at 2022-06-25 07:51:10.714772
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars_0 = {}
    tmp_0 = None
    action_module_0 = ActionModule(task_vars_0, tmp_0)
    action_module_0.run()


# Generated at 2022-06-25 07:51:17.845136
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "AA/Dw"
    dict_0 = {str_0: str_0}
    int_0 = 100
    bytes_0 = b'\xdd\xf4\xb4\xdbGLb~\x02j\xbe\xc3\xa5W'
    list_0 = [str_0, str_0]
    action_module_0 = ActionModule(dict_0, int_0, str_0, bytes_0, list_0, dict_0)
    print(action_module_0)
    action_module_0.run()



# Generated at 2022-06-25 07:51:26.920427
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '@8x<.5'
    dict_0 = {str_0: str_0}
    int_0 = -201
    bytes_0 = b'\xdd\xf4\xb4\xdbGLb~\x02j\xbe\xc3\xa5W'
    list_0 = [str_0, str_0]
    action_module_0 = ActionModule(dict_0, int_0, str_0, bytes_0, list_0, dict_0)
    dict_1 = dict()
    dict_1['data'] = dict_0
    dict_1['aggregate'] = True
    dict_1['per_host'] = True
    dict_1['boolean'] = False

# Generated at 2022-06-25 07:51:35.313525
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {'_host': 'ansible-2', '_task': 'set_stats', '_delegate_to': 'ansible-6', '_ansible_no_log': False, '_ansible_module_name': 'set_stats', '_ansible_verbosity': 0, '_ansible_selection_pattern': '*', '_ansible_debug': False, '_ansible_diff': False, '_ansible_remote_tmp': '/tmp/ansible-tmp-1518533278.20923-107520664151326', '_ansible_keep_remote_files': False, '_ansible_module_set_name': 'statistics'}
    int_0 = -201
    str_0 = '@8x<.5'