

# Generated at 2022-06-25 07:41:41.099797
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(test_case_0(), ActionModule), " test_case_0 failed"

# Generated at 2022-06-25 07:41:47.448403
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # set_0 = None
    # list_0 = []
    # bool_0 = False
    # int_0 = None
    # bytes_0 = b''
    # action_module_0 = ActionModule(set_0, list_0, bool_0, set_0, int_0, bytes_0)
    assert True # TODO: implement your test here


# Generated at 2022-06-25 07:41:54.694850
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = None
    list_0 = []
    bool_0 = False
    int_0 = None
    bytes_0 = b''
    action_module_0 = ActionModule(set_0, list_0, bool_0, set_0, int_0, bytes_0)
    # Test the case where the result of the run is a dictionary
    assert isinstance(action_module_0.run(), dict)
    assert isinstance(action_module_0.run(set_0), dict)
    assert isinstance(action_module_0.run(set_0, set_0), dict)
    assert isinstance(action_module_0.run(set_0, set_0, set_0), dict)
    # Test the case where the result of the run is a list

# Generated at 2022-06-25 07:42:00.122707
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = None
    list_0 = []
    bool_0 = True
    int_0 = None
    bytes_0 = b''
    action_module_0 = ActionModule(set_0, list_0, bool_0, set_0, int_0, bytes_0)

    # Parameters
    tmp = "N/A"
    task_vars = dict()

    # Return value
    result = dict()

    result = action_module_0.run(tmp, task_vars)
    assert result == dict()
    pass


# Generated at 2022-06-25 07:42:07.709548
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = None
    list_0 = []
    bool_0 = False
    int_0 = None
    bytes_0 = b''
    action_module_0 = ActionModule(set_0, list_0, bool_0, set_0, int_0, bytes_0)

    tmp_0 = None
    task_vars_0 = {}
    # Execution of method run from class ActionModule
    result_0 = action_module_0.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 07:42:15.193874
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert callable(ActionModule)

    try:
        action_module_1 = ActionModule()
    except TypeError as e:
        print(e)

    list_2 = []
    set_2 = None
    bool_2 = True
    action_module_3 = ActionModule(set_2, list_2, bool_2, set_2, None, None)



# Generated at 2022-06-25 07:42:20.981208
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_1 = set()
    list_1 = []
    bool_1 = True
    int_1 = 6
    bytes_1 = b'\x00\x01'
    action_module_1 = ActionModule(set_1, list_1, bool_1, set_1, int_1, bytes_1)


# Generated at 2022-06-25 07:42:25.247984
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = None
    list_0 = []
    bool_0 = False
    int_0 = None
    bytes_0 = b''
    action_module_0 = ActionModule(set_0, list_0, bool_0, set_0, int_0, bytes_0)
    # Should not throw an exception!


# Generated at 2022-06-25 07:42:31.411568
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = None
    list_0 = []
    bool_0 = False
    int_0 = None
    bytes_0 = b''
    action_module_0 = ActionModule(set_0, list_0, bool_0, set_0, int_0, bytes_0)

    assert not action_module_0.TRANSFERS_FILES


# Generated at 2022-06-25 07:42:37.482552
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = None
    list_0 = []
    bool_0 = False
    int_0 = None
    bytes_0 = b''
    action_module_0 = ActionModule(set_0, list_0, bool_0, set_0, int_0, bytes_0)


# Generated at 2022-06-25 07:42:52.736246
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'G\x12\x1e\xbbgE\xa8=N\x94\xb0'
    # Created a instance of class ActionModule with arguments
    action_module_0 = ActionModule(bytes_0, int_0, float_0, float_1, str_0, int_0, dict_0)

    # Created a instance of class ActionBase with arguments
    action_base_0 = ActionBase(bytes_0, int_0, float_0, float_1, str_0, int_0, dict_0)

    # Instances should be equal
    assert action_module_0 == action_base_0

    # Instances should be equal
    assert action_base_0 == action_module_0

    # Created a instance of class ActionModule with arguments
    action_module_1 = Action

# Generated at 2022-06-25 07:42:58.353295
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 518
    float_0 = 811.0
    float_1 = 889.82
    str_0 = 'B'
    int_1 = 739
    dict_0 = {float_0: float_1}
    action_module_0 = ActionModule(int_0, float_0, float_1, str_0, int_0, dict_0)


# Generated at 2022-06-25 07:43:05.727275
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule.TRANSFERS_FILES, bool)
    assert isinstance(ActionModule._VALID_ARGS, frozenset)
    int_0 = 739
    float_0 = 512.0
    float_1 = 592.1703
    str_0 = 'r!5'
    int_1 = 739
    dict_0 = {float_0: float_1}
    action_module_0 = ActionModule(int_0, float_0, float_1, str_0, int_1, dict_0)
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:43:12.390651
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 638
    float_0 = 163.0
    float_1 = 511.0153
    str_0 = 'm!2'
    int_1 = 835
    dict_0 = {float_0: float_1}
    action_module_0 = ActionModule(int_0, float_0, float_1, str_0, int_1, dict_0)
    int_0 = 0
    assert action_module_0.run(int_0) == 0
    int_0 = 0
    assert action_module_0.run(int_0) == 0

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:43:19.064938
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'G\x12\x1e\xbbgE\xa8=N\x94\xb0'
    int_0 = 739
    float_0 = 512.0
    float_1 = 592.1703
    str_0 = 'r!5'
    dict_0 = {float_0: float_1}
    action_module_0 = ActionModule(int_0, float_0, float_1, str_0, int_0, dict_0)
    var_0 = action_run(bytes_0)

# Generated at 2022-06-25 07:43:25.439596
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # No exceptions raised.
    bytes_0 = b'G\x12\x1e\xbbgE\xa8=N\x94\xb0'
    str_0 = 'E'
    dict_0 = {str_0: str_0}
    action_module_0 = ActionModule(str_0, str_0, str_0, str_0, str_0, dict_0, str_0)
    var_0 = action_module_0.run(dict_0)

# Generated at 2022-06-25 07:43:29.161848
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(int_0, float_0, float_1, str_0, int_0, dict_0)
    bytes_0 = b'G\x12\x1e\xbbgE\xa8=N\x94\xb0'
    dict_0 = action_module_0.run(bytes_0)


# Generated at 2022-06-25 07:43:33.975717
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # 1.0: Setup test environment
    # 1.0: Setup test environment
    dict_0 = dict()
    dict_1 = dict()
    dict_1['data'] = dict_0
    dict_2 = dict()
    dict_2['aggregate'] = dict_1
    dict_3 = dict()
    dict_3['per_host'] = dict_2
    dict_4 = dict()
    dict_5 = dict()
    dict_5['data'] = dict_4
    dict_6 = dict()
    dict_6['aggregate'] = dict_5
    dict_7 = dict()
    dict_7['per_host'] = dict_6
    dict_8 = dict()
    dict_8['msg'] = dict_7
    dict_9 = dict()
    dict_9['changed'] = dict

# Generated at 2022-06-25 07:43:36.869465
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:43:41.408579
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor.
    bytes_0 = b'G\x12\x1e\xbbgE\xa8=N\x94\xb0'
    int_0 = 739
    float_0 = 512.0
    float_1 = 592.1703
    str_0 = 'r!5'
    dict_0 = {float_0: float_1}
    action_module_0 = ActionModule(int_0, float_0, float_1, str_0, int_0, dict_0)
    assert action_module_0 != None


# Generated at 2022-06-25 07:43:53.305883
# Unit test for constructor of class ActionModule
def test_ActionModule():
  tmp = None
  task_vars = None
  action_module = ActionModule(tmp, task_vars)
  assert action_module
  print("ActionModule unit test passed")


# Generated at 2022-06-25 07:44:01.030256
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'G\x12\x1e\xbbgE\xa8=N\x94\xb0'
    int_0 = 739
    float_0 = 512.0
    float_1 = 592.1703
    str_0 = 'r!5'
    dict_0 = {float_0: float_1}
    action_module_0 = ActionModule(int_0, float_0, float_1, str_0, int_0, dict_0)
    var_0 = float_0
    var_0 = action_module_0.run(var_0)
    var_0 = action_module_0.run(var_0, var_0)


# Generated at 2022-06-25 07:44:08.972641
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'G\x12\x1e\xbbgE\xa8=N\x94\xb0'
    int_0 = 739
    float_0 = 512.0
    float_1 = 592.1703
    str_0 = 'r!5'
    dict_0 = {float_0: float_1}
    action_module_0 = ActionModule(int_0, float_0, float_1, str_0, int_0, dict_0)


# Generated at 2022-06-25 07:44:14.685112
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Init an object of class ActionModule
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:44:24.584969
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    var_1 = '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    var_2 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-25 07:44:35.815471
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'm\x93\xbc\x06\x91\t\x8e\x1e\xe3\xc3\xa3\x87\xe1\x92\xdc\xec\x1c\xc9\x94\xb9\xfe\xaa\x97Q\x1c\xa1'
    int_0 = 464
    float_0 = 128.0
    float_1 = 704.03
    str_0 = 'MQ\x86\x1c\x9a\x1c'
    list_0 = [float_0, float_1]
    set_0 = set(list_0)
    dict_0 = {list_0: dir(list_0)}
    dict_1 = dict(list_0)

# Generated at 2022-06-25 07:44:41.181708
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_0 = ActionModule()
    float_0 = float()
    float_1 = float()
    float_2 = float()
    float_3 = float()
    test_case_0(module_0)

# Generated at 2022-06-25 07:44:51.140934
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'G\x12\x1e\xbbgE\xa8=N\x94\xb0'
    int_0 = 739
    float_0 = 512.0
    float_1 = 592.1703
    str_0 = 'r!5'
    dict_0 = {float_0: float_1}
    action_module_0 = ActionModule(int_0, float_0, float_1, str_0, int_0, dict_0)
    action_module_0.action_name
    action_module_0.action_loader
    action_module_0.task_vars
    action_module_0.loader
    action_module_0.play_context
    action_module_0.shared_loader_obj
    action_module_0.connection
   

# Generated at 2022-06-25 07:45:03.072717
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'G\x12\x1e\xbbgE\xa8=N\x94\xb0'
    int_0 = 739
    float_0 = 512.0
    float_1 = 592.1703
    str_0 = 'r!5'
    dict_0 = {float_0: float_1}
    action_module_0 = ActionModule(int_0, float_0, float_1, str_0, int_0, dict_0)
    bytes_1 = b'\x00\x0b\x81\xc8\x15\x9c\xca\x0f\x03\xce\xc5\x11R'
    dict_1 = {bytes_1: dict_0}

# Generated at 2022-06-25 07:45:08.093805
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Test case 0: ")
    test_case_0()

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 07:45:29.793194
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Test_Case1: Test case for the constructor of class ActionModule")
    test_case_0()
    print("Test Case Passed\n")
    

# Generated at 2022-06-25 07:45:33.520425
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'G\x12\x1e\xbbgE\xa8=N\x94\xb0'
    int_0 = 739
    float_0 = 512.0
    float_1 = 592.1703
    str_0 = 'r!5'
    dict_0 = {float_0: float_1}
    action_module_0 = ActionModule(int_0, float_0, float_1, str_0, int_0, dict_0)
    del action_module_0


# Generated at 2022-06-25 07:45:40.108801
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x9e\xda\xaa\x83\xbf\xe0\x0e\x0c'
    int_0 = -34
    float_0 = -487344.839
    float_1 = 48.0
    str_0 = '6'
    int_1 = -14
    dict_0 = {float_1: float_1}
    action_module_0 = ActionModule(int_0, float_0, float_1, str_0, int_1, dict_0)
    str_1 = '-v1'
    str_2 = 'aggregate'
    str_3 = 'module'
    str_4 = 'per_host'
    str_5 = 'data'
    str_6 = '0'

# Generated at 2022-06-25 07:45:50.543896
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'z\xfd\xaf\xd1\x8c\x9f\x86\x98\xab\xf1\xed\x1a\x1d\xb3\x8b\xa9\xef\xcc\xed\xd8\x0b\xd1\xee\x1a\xb6\x9f\xbf\xbe\x8c\xbe\xae'
    int_0 = 3257
    float_0 = 21.3440
    float_1 = 520.0
    str_0 = 'R*'
    int_1 = 789
    dict_0 = {}
    dict_0[float_0] = list([int_0, int_1, bytes_0, list([for_0]), str_0, dict_0])

# Generated at 2022-06-25 07:45:59.436458
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'G\x12\x1e\xbbgE\xa8=N\x94\xb0'
    int_0 = 739
    float_0 = 512.0
    float_1 = 592.1703
    str_0 = 'r!5'
    dict_0 = {float_0: float_1}
    action_module_0 = ActionModule(int_0, float_0, float_1, str_0, int_0, dict_0)
    var_0 = action_module_0.run(bytes_0)

# Generated at 2022-06-25 07:46:09.200970
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test in_0 is initialized to False
    assert ActionModule.in_0 is False
    # Test in_1 is initialized to 739
    assert ActionModule.in_1 == 739
    # Test in_2 is initialized to 512.0
    assert ActionModule.in_2 == 512.0
    # Test in_3 is initialized to 592.1703
    assert ActionModule.in_3 == 592.1703
    # Test in_4 is initialized to 'r!5'
    assert ActionModule.in_4 == 'r!5'
    # Test in_5 is initialized to 739
    assert ActionModule.in_5 == 739
    # Test in_6 is initialized to {512.0: 592.1703}
    assert ActionModule.in_6 == {512.0: 592.1703}



# Generated at 2022-06-25 07:46:13.989240
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'G\x12\x1e\xbbgE\xa8=N\x94\xb0'
    int_0 = 739
    float_0 = 512.0
    float_1 = 592.1703
    str_0 = 'r!5'
    dict_0 = {float_0: float_1}
    return ActionModule(int_0, float_0, float_1, str_0, int_0, dict_0)


# Generated at 2022-06-25 07:46:21.084791
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xe9\x0f\x15\x8b\xf2\xf4\xb3\xc9\x8a\xab\x0f\xb4\xf5\xcd5\xbd'
    int_0 = 785
    float_0 = 288.0
    float_1 = 912.0913
    str_0 = 'E#n'
    int_1 = 578
    dict_0 = {float_0: float_1}
    action_module_0 = ActionModule(int_0, float_0, float_1, str_0, int_1, dict_0)


# Generated at 2022-06-25 07:46:23.843479
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    result = action_module_0.run()
    assert result == None, "Unexpected result of ActionModule.run"

# Generated at 2022-06-25 07:46:32.812773
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x02\x85\x15\xbe\xb5\x1c\x00\x82\xe6\xbc\x00\xfe\xce\xc7'
    int_0 = 1154
    str_0 = '0m\x9a'
    str_1 = '\xfc\xd3z\x9c'
    float_0 = 944.1004
    str_2 = '\x8e'
    dict_0 = {bytes_0: float_0}
    action_module_0 = ActionModule(int_0, str_0, str_1, str_0, int_0, dict_0)

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:47:14.141007
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'G\x12\x1e\xbbgE\xa8=N\x94\xb0'
    int_0 = 739
    float_0 = 512.0
    float_1 = 592.1703
    str_0 = 'r!5'
    dict_0 = {float_0: float_1}
    action_module_0 = ActionModule(int_0, float_0, float_1, str_0, int_0, dict_0)


# Generated at 2022-06-25 07:47:16.610502
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # No fail state
    var_0 = ActionModule(action_module_0)
    var_0.run(action_module_0, action_module_0)
    assert var_0 == 0


# Generated at 2022-06-25 07:47:23.359813
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'G\x12\x1e\xbbgE\xa8=N\x94\xb0'
    int_0 = 739
    float_0 = 512.0
    float_1 = 592.1703
    str_0 = 'r!5'
    dict_0 = {float_0: float_1}
    action_module_0 = ActionModule(int_0, float_0, float_1, str_0, int_0, dict_0)
    var_0 = action_run(bytes_0)

# Assertion with expected value having attribute __call__

# Generated at 2022-06-25 07:47:27.686975
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'G\x12\x1e\xbbgE\xa8=N\x94\xb0'
    int_0 = 739
    float_0 = 512.0
    float_1 = 592.1703
    str_0 = 'r!5'
    dict_0 = {float_0: float_1}
    action_module_0 = ActionModule(int_0, float_0, float_1, str_0, int_0, dict_0)
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:47:35.447339
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    result = ActionModule.run(tmp, task_vars)
    assert result == {'changed': False, 'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}}
    # test with per_host, aggregate and data set
    self._task.args = {'per_host': 'yes', 'aggregate': 'no', 'data': {'test_1': 5, 'test_2': 'yay'}}
    result = ActionModule.run(tmp, task_vars)
    expected = {'changed': False, 'ansible_stats': {'data': {'test_1': 5, 'test_2': 'yay'}, 'per_host': True, 'aggregate': False}}
    assert result == expected

# Generated at 2022-06-25 07:47:42.422666
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -4
    float_0 = -74.0
    float_1 = -24.1703
    str_0 = 'Z'
    int_1 = -3
    dict_0 = {float_0: float_1}
    action_module_0 = ActionModule(int_0, float_0, float_1, str_0, int_1, dict_0)


# Generated at 2022-06-25 07:47:53.561398
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x8e\x05;'

# Generated at 2022-06-25 07:48:02.882425
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'G\x12\x1e\xbbgE\xa8=N\x94\xb0'
    int_0 = 739
    float_0 = 512.0
    float_1 = 592.1703
    str_0 = 'r!5'
    dict_0 = {float_0: float_1}
    action_module_0 = ActionModule(int_0, float_0, float_1, str_0, int_0, dict_0)
    dict_1 = {str_0: dict_0}
    dict_2 = {str_0: dict_1}
    bool_0 = True
    bool_1 = True

# Generated at 2022-06-25 07:48:05.571400
# Unit test for constructor of class ActionModule
def test_ActionModule():
  action_module_0 = ActionModule(739, 512.0, 592.1703, 'r!5', 739, {512.0: 592.1703})


# Generated at 2022-06-25 07:48:09.469262
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'G\x12\x1e\xbbgE\xa8=N\x94\xb0'
    int_0 = 739
    float_0 = 512.0
    float_1 = 592.1703
    str_0 = 'r!5'
    dict_0 = {float_0: float_1}
    action_module_0 = ActionModule(int_0, float_0, float_1, str_0, int_0, dict_0)
    action_module_0.run()

# Generated at 2022-06-25 07:49:49.498871
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = dict()
    bool_0 = boolean(dict_0)
    bool_1 = boolean(dict_0)
    bool_2 = boolean(dict_0)
    str_0 = '!r'
    dict_1 = dict()
    dict_1[bool_0] = bool_1
    int_0 = 526
    float_0 = 592.01
    float_1 = 3
    action_module_0 = ActionModule(dict_0, dict_0, dict_0, dict_0, dict_0, dict_0, dict_0, dict_1, int_0, float_0, float_1, str_0, int_0, dict_1)


# Generated at 2022-06-25 07:49:53.532151
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Running test_ActionModule_run')

    bytes_0 = b'\xff\x82\x9d\xcc\xa7\x17e\x00\x01\x11\x10'
    int_0 = 214
    float_0 = 512.0
    float_1 = 592.1703
    str_0 = 'r!5'
    dict_0 = {float_0: float_1}
    action_module_0 = ActionModule(int_0, float_0, float_1, str_0, int_0, dict_0)
    var_0 = action_run(bytes_0)
    return int_0


# Generated at 2022-06-25 07:50:00.565613
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xb6\x98\x00\x00\xa2\xee\x00\x00\xcc\xaa\x00\x00\x9a\xaa\x00\x00'
    int_0 = 0
    float_0 = -23.3
    float_1 = -512.342
    str_0 = 'I'
    int_1 = 860
    dict_0 = {str_0: int_0}
    action_module_0 = ActionModule(int_0, float_0, float_1, str_0, int_1, dict_0)
    test_0 = action_module_0.run()
    assert test_0 is None


# Generated at 2022-06-25 07:50:08.833689
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Function run called')
    bytes_0 = b'G\x12\x1e\xbbgE\xa8=N\x94\xb0'
    int_0 = 739
    float_0 = 512.0
    float_1 = 592.1703
    str_0 = 'r!5'
    dict_0 = {float_0: float_1}
    action_module_0 = ActionModule(int_0, float_0, float_1, str_0, int_0, dict_0)
    var_0 = action_run(bytes_0)

# Generated at 2022-06-25 07:50:16.501031
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'B4P8qJhU]'
    list_0 = [str_0, str_0, str_0, str_0]
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: list_0}
    action_module_0 = ActionModule(list_0, str_0, dict_0, dict_0, dict_0, dict_0, dict_0)
    dict_1 = dict_0
    dict_2 = dict_1
    dict_1 = {dict_1: dict_2}
    dict_3 = dict_0
    dict_1[dict_3] = dict_2
    dict_2 = dict_2
    dict_4 = dict_1
    dict_4 = dict_2

# Generated at 2022-06-25 07:50:20.161027
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    print(action_module_0.__module__)
    print(action_module_0.__class__)
    print(action_module_0.__doc__)
    print(action_module_0.__init__)
    print(action_module_0.__init__.__class__)

# Generated at 2022-06-25 07:50:30.987060
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup fixture
    bytes_0 = b'G\x12\x1e\xbbgE\xa8=N\x94\xb0'
    int_0 = 739
    float_0 = 512.0
    float_1 = 592.1703
    str_0 = 'r!5'
    dict_0 = {float_0: float_1}
    action_module_0 = ActionModule(int_0, float_0, float_1, str_0, int_0, dict_0)

    # Method under test
    var_0 = action_module_0.run(bytes_0)

    # Verify results
    assert isinstance(var_0, dict) == True
    assert var_0 == {'failed': False, 'msg': '', 'changed': False}

    # Tests completed
   

# Generated at 2022-06-25 07:50:39.280785
# Unit test for constructor of class ActionModule
def test_ActionModule():
    arg_0 = b'G\x12\x1e\xbbgE\xa8=N\x94\xb0'
    arg_1 = 739
    arg_2 = 512.0
    arg_3 = 592.1703
    arg_4 = 'r!5'
    arg_5 = 739
    arg_6 = {512.0: 592.1703}
    action_module_0 = ActionModule(arg_0, arg_1, arg_2, arg_3, arg_4, arg_5, arg_6)
    assert action_module_0.is_safe_for_context(6)


# Generated at 2022-06-25 07:50:48.733539
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'G\x12\x1e\xbbgE\xa8=N\x94\xb0'
    int_0 = 739
    float_0 = 512.0
    float_1 = 592.1703
    str_0 = 'r!5'
    dict_0 = {float_0: float_1}
    action_module_0 = ActionModule(int_0, float_0, float_1, str_0, int_0, dict_0)
    assert(action_module_0._play_context.vars == dict_0)
    assert(action_module_0._loader.path_exists(str_0) == bool(1))
    assert(action_module_0._task.loop is None)

# Generated at 2022-06-25 07:50:50.471338
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule)
