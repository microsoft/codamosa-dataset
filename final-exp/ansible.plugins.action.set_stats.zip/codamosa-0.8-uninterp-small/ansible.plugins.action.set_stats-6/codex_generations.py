

# Generated at 2022-06-25 07:41:41.266991
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:41:49.295622
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  list_0 = []
  dict_0 = {}
  set_0 = set()
  int_0 = 20
  str_0 = '\x0c,Czr'
  action_module_0 = ActionModule(list_0, dict_0, set_0, int_0, str_0, set_0)
  # FIXME: use assert_equals instead, but it is not allowed in python3
  assert action_module_0.run(dict_0, dict_0) == ({'changed': False, 'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}}, None)

# Generated at 2022-06-25 07:41:54.209419
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:41:56.846062
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = []
    dict_0 = {}
    set_0 = set()
    int_0 = 20
    str_0 = '\x0c,Czr'
    action_module_0 = ActionModule(list_0, dict_0, set_0, int_0, str_0, set_0)
    # TODO: implement this test, or delete test_ActionModule_run()
    raise NotImplementedError

# Generated at 2022-06-25 07:42:06.479501
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    (list_0, dict_0, set_0, int_0, str_1, set_1, set_2) = (list(), dict(), set(), int(), str(), set(), set())
    dict_1 = dict()
    dict_2 = dict()
    dict_1['per_host'] = False
    dict_1['data'] = dict_2
    dict_1['aggregate'] = True
    (dict_2['one'], dict_2['two'], dict_2['three']) = (1, 2, 3)
    dict_1_1 = dict()
    dict_1_2 = dict()
    dict_1_3 = dict()

# Generated at 2022-06-25 07:42:12.969084
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = ['\n', '_', '_', '\r']
    dict_0 = {}
    set_0 = set()
    int_0 = 20
    str_0 = '\x0c,Czr'
    list_1 = ['\n', '_', '_', '\r']
    dict_1 = {}
    set_1 = set()
    int_1 = 20
    str_1 = '\x0c,Czr'
    list_2 = []
    dict_2 = {}
    set_2 = set()
    int_2 = 20
    str_2 = '\x0c,Czr'
    set_3 = set()
    str_3 = '\x0c,Czr'

# Generated at 2022-06-25 07:42:16.206088
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = []
    dict_0 = {}
    set_0 = set()
    int_0 = 20
    str_0 = '\x0c,Czr'
    action_module_0 = ActionModule(list_0, dict_0, set_0, int_0, str_0, set_0)


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:42:22.237311
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  list_0 = []
  dict_0 = {}
  set_0 = set()
  int_0 = 20
  str_0 = 'ir]gR'
  action_module_0 = ActionModule(list_0, dict_0, set_0, int_0, str_0, set_0)

  # TODO: implement your test here
  raise NotImplementedError()

# Generated at 2022-06-25 07:42:26.733706
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = []
    dict_0 = {}
    set_0 = set()
    int_0 = 20
    str_0 = '\x0c,Czr'
    action_module_0 = ActionModule(list_0, dict_0, set_0, int_0, str_0, set_0)
    action_module_0.run(dict_0)

# Generated at 2022-06-25 07:42:29.610914
# Unit test for constructor of class ActionModule
def test_ActionModule():
    list_0 = []
    dict_0 = {}
    set_0 = set()
    int_0 = 20
    str_0 = '\x0c,Czr'
    test_case_0()

# Generated at 2022-06-25 07:42:42.958563
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_run_instance = ActionModule(task=test_case_0(), connection=test_case_0(), play_context=test_case_0(), loader=test_case_0(), templar=test_case_0(), shared_loader_obj=test_case_0())
    result_run_instance = action_module_run_instance._execute_module(task_vars=test_case_0())
    assert(result_run_instance == {'changed': False, 'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}})

# Generated at 2022-06-25 07:42:49.012744
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    test_case_0()


# Generated at 2022-06-25 07:42:53.028829
# Unit test for constructor of class ActionModule
def test_ActionModule():
    act = ActionModule()
    assert act._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))
    assert act.TRANSFERS_FILES == False
    assert hasattr(act, 'run')


# Generated at 2022-06-25 07:43:00.871263
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'H\xaf\x17\xd2\x81?\x15\x9cM1`\xc2\xfe-\xd5\x14T\x04\xa0]'
    set_0 = {bytes_0, bytes_0, bytes_0}
    ActionBase_0 = ActionBase()
    #ActionModule_0 = ActionModule(ActionBase_0, set_0)
    ActionModule_0 = ActionModule(ActionBase_0, set_0)


if __name__ == '__main__':
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 07:43:01.794495
# Unit test for constructor of class ActionModule
def test_ActionModule():
    config_data = {}
    a = ActionModule(task_vars=config_data)


# Generated at 2022-06-25 07:43:08.110430
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    args_0 = {
        '_ansible_parsed': True,
        '_ansible_no_log': False,
        '_ansible_check_mode': False,
        '_ansible_verbosity': 2,
        '_ansible_version': {
            'full': '2.1.3.0',
            'major': 2,
            'minor': 1,
            'revision': 3,
            'string': '2.1.3.0'
        },
        '_ansible_module_name': 'set_stats',
        '_ansible_forks': 5,
        '_ansible_remote_tmp': '~/.ansible/tmp',
        '_ansible_keep_remote_files': True
    }


# Generated at 2022-06-25 07:43:09.109352
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create default ActionModule instance
    action_module = ActionModule()


# Generated at 2022-06-25 07:43:10.530631
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = set()
    b = set()

    # TODO: Test the constructor

    return True


# Generated at 2022-06-25 07:43:19.859182
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create mock module
    from ansible.utils.vars import combine_vars
    from ansible.utils import template
    from ansible.template import Templar
    from ansible.vars import VariableManager
    module = type('module', (object,), dict(template = template, VariableManager = VariableManager, Templar = Templar, combine_vars = combine_vars))()
    templar = Templar(loader=None, variables={})
    def path_dwim_relative(name, basedir, follow, filter=None):
        assert name == 'my_module'
        return '/path/to/my_module'
    templar.set_available_variables({'loader': module.loader, 'path_dwim_relative': path_dwim_relative})

# Generated at 2022-06-25 07:43:28.882443
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_1 = {842, None, '', True, 'delta'}
    dict_2 = {'b': '1', 'a': '0'}
    str_5 = 'hostvars[inventory_hostname]'

# Generated at 2022-06-25 07:43:35.339874
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module = ActionModule()

    action_module.run()

# Generated at 2022-06-25 07:43:36.329388
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:43:41.917361
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    stats_0 = { }
    stats_0['data'] = { }
    task_vars_0 = { }
    tmp_0 = None
    action_module_0.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 07:43:49.737608
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # An action module must have a run that returns data.
    assert hasattr(action_module_0, 'run'), ('must have run')
    assert callable(getattr(action_module_0, 'run')), ('run must be callable')
    assert hasattr(action_module_0.run(), '__getitem__'), ('return value of run must be a dictionary')
    assert callable(getattr(action_module_0.run(), '__getitem__')), ('__getitem__ must be callable')

# Generated at 2022-06-25 07:43:57.383753
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test_case_0
    set_stats = {'data': {'foo': 'bar'}, 'per_host': True, 'aggregate': False}
    assert ActionModule().run(task_vars={'test': 'test_val'}) == {'ansible_stats': set_stats, 'changed': False}

# Generated at 2022-06-25 07:44:03.703420
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    result = action_module_0.run(None, {'ansible_module_installed_packages': {'module_package_name': {'module_package_version': 'module_package_summary'}}})
    assert result is not None
    assert 'changed' in result
    assert result['changed'] is False
    assert 'ansible_stats' in result
    assert 'data' in result['ansible_stats']
    assert result['ansible_stats']['data'] is not None
    assert 'package_stats' in result['ansible_stats']['data']
    assert isinstance(result['ansible_stats']['data']['package_stats'], dict)
    assert 'aggregate' in result['ansible_stats']

# Generated at 2022-06-25 07:44:10.280563
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create some test data 'args'
    args = {'data':{},'per_host':False,'aggregate':True}

    # Create the class instance
    action_module = ActionModule()

    # Call the method with args
    # TODO: create a test for this method
    # result = action_module.run(args)
    # print(result)

# Generated at 2022-06-25 07:44:14.145371
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:44:14.991344
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert callable(ActionModule)

# Generated at 2022-06-25 07:44:19.395529
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    assert action_module_0.run() == {'ansible_stats': {'per_host': False, 'aggregate': True, 'data': {}}, 'changed': False}


# Generated at 2022-06-25 07:44:31.140922
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    tmp = None
    task_vars = None

    #run method being tested:
    result = ActionModule.run(tmp, task_vars)
    assert result == {}, "Unexpected result from ActionModule.run: %s" % result


# Generated at 2022-06-25 07:44:37.051082
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -6589.0
    list_0 = [float_0, float_0]
    action_module_0 = ActionModule(float_0, list_0)
    action_module_0.run()


# Generated at 2022-06-25 07:44:40.543223
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:44:41.416049
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:44:50.008299
# Unit test for constructor of class ActionModule
def test_ActionModule():
    complex_0 = complex(10.0, 11.0)
    float_0 = -2532.3
    int_0 = -1819
    float_1 = -764.25
    bool_0 = True
    str_0 = '!c%'
    action_module_0 = ActionModule(complex_0, float_0, int_0, float_1, bool_0, str_0)
    assert action_module_0._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))
    assert action_module_0.TRANSFERS_FILES == False

# Generated at 2022-06-25 07:45:01.365004
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -2030.5
    list_0 = [float_0, float_0, float_0, float_0]
    bool_0 = True
    int_0 = 485
    int_1 = -2543
    bytes_0 = b'\xbb\xa0\x86\xf6\xd1\xe32\n\x9e\x93\x8c\xeb\xc3\x01\x1f\xba\x1a\xb9'
    tuple_0 = (list_0, bytes_0)
    str_0 = 'ansible.executor.powershell'
    complex_0 = None
    int_2 = 2436

# Generated at 2022-06-25 07:45:10.102837
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -2509.8
    list_0 = [float_0, float_0, float_0, float_0]
    bool_0 = True
    int_0 = 1593
    int_1 = -2536
    bytes_0 = b'\n\xeb-\xe1\xaa\x95%\x82\x9c\xc40'
    tuple_0 = (list_0, bytes_0)
    str_0 = 'ansible.executor.powershell'
    complex_0 = None
    int_2 = 2438
    action_module_0 = ActionModule(float_0, tuple_0, str_0, float_0, complex_0, int_2)

# Generated at 2022-06-25 07:45:15.778218
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -248.6
    list_0 = [float_0, float_0]
    str_0 = 'ansible.playbook.block'
    int_0 = -1413
    dict_0 = {float_0: str_0, list_0: int_0}
    action_module_0 = ActionModule(float_0, list_0, str_0, float_0, float_0, dict_0)
    var_0 = action_module_0.run()
    assert var_0 == None, """The value of var_0 should be None, but actually it is '%s'""" % var_0


# Generated at 2022-06-25 07:45:20.862397
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # test for method run
    float_0 = -2509.8
    list_0 = [float_0, float_0, float_0, float_0]
    bool_0 = True
    int_0 = 1593
    int_1 = -2536
    bytes_0 = b'\n\xeb-\xe1\xaa\x95%\x82\x9c\xc40'
    tuple_0 = (list_0, bytes_0)
    str_0 = 'ansible.executor.powershell'
    complex_0 = None
    int_2 = 2438
    action_module_0 = ActionModule(float_0, tuple_0, str_0, float_0, complex_0, int_2)

    # test for method run of class ActionModule

# Generated at 2022-06-25 07:45:29.584580
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -2509.8
    list_0 = [float_0, float_0, float_0, float_0]
    bool_0 = True
    int_0 = 1593
    int_1 = -2536
    bytes_0 = b'\n\xeb-\xe1\xaa\x95%\x82\x9c\xc40'
    tuple_0 = (list_0, bytes_0)
    str_0 = 'ansible.executor.powershell'
    complex_0 = None
    int_2 = 2438
    action_module_0 = ActionModule(float_0, tuple_0, str_0, float_0, complex_0, int_2)

# Generated at 2022-06-25 07:45:50.350511
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -2509.8
    list_0 = [float_0, float_0, float_0, float_0]
    bool_0 = True
    int_0 = 1593
    int_1 = -2536
    bytes_0 = b'\n\xeb-\xe1\xaa\x95%\x82\x9c\xc40'
    tuple_0 = (list_0, bytes_0)
    str_0 = 'ansible.executor.powershell'
    complex_0 = None
    int_2 = 2438
    action_module_0 = ActionModule(float_0, tuple_0, str_0, float_0, complex_0, int_2)

# Generated at 2022-06-25 07:45:53.337995
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -1398
    list_0 = [int_0, int_0, int_0, int_0]
    action_module = ActionModule(int_0, list_0, int_0, int_0, int_0, list_0)
    action_module.run()
    del action_module


# Generated at 2022-06-25 07:45:58.066322
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -2509.8
    list_0 = [float_0, float_0, float_0, float_0]
    bool_0 = True
    int_0 = 1593
    int_1 = -2536
    bytes_0 = b'\n\xeb-\xe1\xaa\x95%\x82\x9c\xc40'
    tuple_0 = (list_0, bytes_0)
    str_0 = 'ansible.executor.powershell'
    complex_0 = None
    int_2 = 2438
    action_module_0 = ActionModule(float_0, tuple_0, str_0, float_0, complex_0, int_2)

# Generated at 2022-06-25 07:46:09.122281
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -2509.8
    list_0 = [float_0, float_0, float_0, float_0]
    bool_0 = True
    int_0 = 1593
    int_1 = -2536
    bytes_0 = b'\n\xeb-\xe1\xaa\x95%\x82\x9c\xc40'
    tuple_0 = (list_0, bytes_0)
    str_0 = 'ansible.executor.powershell'
    complex_0 = None
    int_2 = 2438
    action_module_0 = ActionModule(float_0, tuple_0, str_0, float_0, complex_0, int_2)

# Generated at 2022-06-25 07:46:18.439523
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -2509.8
    list_0 = [float_0, float_0, float_0, float_0]
    bool_0 = True
    int_0 = 1593
    int_1 = -2536
    bytes_0 = b'\n\xeb-\xe1\xaa\x95%\x82\x9c\xc40'
    tuple_0 = (list_0, bytes_0)
    str_0 = 'ansible.executor.powershell'
    complex_0 = None
    int_2 = 2438
    action_module_0 = ActionModule(float_0, tuple_0, str_0, float_0, complex_0, int_2)

# Generated at 2022-06-25 07:46:29.574117
# Unit test for method run of class ActionModule
def test_ActionModule_run():
 
    from ansible.module_utils.basic import AnsibleModule, env_fallback, return_values
    from ansible.module_utils._text import to_text

    # import module snippets
    from ansible.module_utils.basic import *

    # Combine stdout and stderr
    def combine_stderr(r):
        if r['rc'] != 0 and r['stdout']:
            r['stdout'] = r['stdout'] + "\n" + r['stderr']
        return r


# Generated at 2022-06-25 07:46:36.755912
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test adding a number to a string
    assert ActionModule(1.2, 'string', 'some_class', 1, None, 1).run() == 2.2, \
        "ActionModule(1.2, 'string', 'some_class', 1, None, 1).run() should be 2.2"
    # Test adding two numbers
    assert ActionModule(1.2, [1.2, 1.2, 1.2], True, -1, 1, dict(float_0=1)).run() == 2.4, \
        "ActionModule(1.2, [1.2, 1.2, 1.2], True, -1, 1, dict(float_0=1)).run() should be 2.4"
    # Test adding a string and a number

# Generated at 2022-06-25 07:46:42.919544
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 0.987485271824
    bool_0 = False
    int_0 = -138
    complex_0 = None
    action_module_0 = ActionModule(float_0, int_0, bool_0, None, int_0, complex_0)
    action_module_0.run()


if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:46:50.372257
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Input arguments testing
    # Case 1
    float_0 = -2509.8
    list_0 = []
    bool_0 = False
    int_0 = 1272
    int_1 = -1210
    dict_0 = {float_0: list_0, bool_0: list_0, int_0: int_1}
    action_module_0 = ActionModule(float_0, list_0, bool_0, int_0, int_1, dict_0)


# Generated at 2022-06-25 07:47:01.743660
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -2509.8
    list_0 = [float_0, float_0, float_0, float_0]
    bool_0 = True
    int_0 = 1593
    int_1 = -2536
    bytes_0 = b'\n\xeb-\xe1\xaa\x95%\x82\x9c\xc40'
    tuple_0 = (list_0, bytes_0)
    str_0 = 'ansible.executor.powershell'
    complex_0 = None
    int_2 = 2438
    action_module_0 = ActionModule(float_0, tuple_0, str_0, float_0, complex_0, int_2)

# Generated at 2022-06-25 07:47:27.759384
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -2509.8
    list_0 = [float_0, float_0, float_0, float_0]
    bool_0 = True
    int_0 = 1593
    int_1 = -2536
    bytes_0 = b'\n\xeb-\xe1\xaa\x95%\x82\x9c\xc40'
    tuple_0 = (list_0, bytes_0)
    str_0 = 'ansible.executor.powershell'
    complex_0 = None
    int_2 = 2438
    action_module_0 = ActionModule(float_0, tuple_0, str_0, float_0, complex_0, int_2)

# Generated at 2022-06-25 07:47:35.524916
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -2509.8
    list_0 = [float_0, float_0, float_0, float_0]
    bool_0 = True
    int_0 = 1593
    int_1 = -2536
    bytes_0 = b'\n\xeb-\xe1\xaa\x95%\x82\x9c\xc40'
    tuple_0 = (list_0, bytes_0)
    str_0 = 'ansible.executor.powershell'
    complex_0 = None
    int_2 = 2438
    action_module_0 = ActionModule(float_0, tuple_0, str_0, float_0, complex_0, int_2)

# Generated at 2022-06-25 07:47:36.757044
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Testing error reporting
    # test_case_0()
    pass

# Generated at 2022-06-25 07:47:46.486404
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -2509.8
    list_0 = [float_0, float_0, float_0, float_0]
    bool_0 = True
    int_0 = 1593
    int_1 = -2536
    bytes_0 = b'\n\xeb-\xe1\xaa\x95%\x82\x9c\xc40'
    tuple_0 = (list_0, bytes_0)
    str_0 = 'ansible.executor.powershell'
    complex_0 = None
    int_2 = 2438
    action_module_0 = ActionModule(float_0, tuple_0, str_0, float_0, complex_0, int_2)

# Generated at 2022-06-25 07:47:53.477381
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 981.9
    bool_0 = True
    int_0 = -1335
    list_0 = [float_0, bool_0, int_0]
    str_0 = 'ansible.executor.powershell'
    int_1 = -2223
    dict_0 = {int_0: list_0, float_0: int_0}
    action_module_0 = ActionModule(float_0, list_0, str_0, int_1, bool_0, dict_0)

if (__name__ == '__main__'):
    test_case_0()
    test_ActionModule()

# Generated at 2022-06-25 07:48:02.832250
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -2509.8
    list_0 = [float_0, float_0, float_0, float_0]
    bool_0 = True
    int_0 = 1593
    int_1 = -2536
    bytes_0 = b'\n\xeb-\xe1\xaa\x95%\x82\x9c\xc40'
    tuple_0 = (list_0, bytes_0)
    str_0 = 'ansible.executor.powershell'
    complex_0 = None
    int_2 = 2438
    action_module_0 = ActionModule(float_0, tuple_0, str_0, float_0, complex_0, int_2)
    assert str(action_module_0).find('ActionModule') != -1, 'Constructor test failed'

# Generated at 2022-06-25 07:48:15.584107
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -2509.8
    list_1 = [float_0, float_0, float_0, float_0]
    dict_1 = {float_0: list_1, bool_0: list_1, action_module_0: int_0}
    action_module_0 = ActionModule(float_0, list_0, bool_0, int_0, int_1, dict_0)
    var_0 = action_module_1.run() # Should raise exception when 'action_module_1' is None
    var_1 = action_module_0.run()

if (__name__ == '__main__'):
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:48:16.876122
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('test_ActionModule - Begin')
    test_case_0()
    print('test_ActionModule - End')

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:48:25.006203
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -2509.8
    list_0 = [float_0, float_0, float_0, float_0]
    bool_0 = True
    int_0 = 1593
    int_1 = -2536
    bytes_0 = b'\n\xeb-\xe1\xaa\x95%\x82\x9c\xc40'
    tuple_0 = (list_0, bytes_0)
    str_0 = 'ansible.executor.powershell'
    complex_0 = None
    int_2 = 2438
    action_module_0 = ActionModule(float_0, tuple_0, str_0, float_0, complex_0, int_2)

# Generated at 2022-06-25 07:48:26.911260
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_3 = ActionModule()
    assert isinstance(action_module_3._task, object)
    assert action_module_3._task.action == 'set_stats'


# Generated at 2022-06-25 07:49:30.074551
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -949.8
    list_0 = [float_0, float_0, float_0, float_0]
    str_0 = 'ansible.executor.powershell'
    float_1 = -7157.3
    complex_0 = None
    int_0 = -4038
    action_module_0 = ActionModule(float_0, list_0, str_0, float_1, complex_0, int_0)
    var_0 = action_module_0.run()


test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 07:49:36.962410
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -2347
    action_module_0 = ActionModule(int_0, int_0, int_0, int_0, int_0, int_0)
    var_0 = action_module_0.run()
    assert var_0['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True}
    assert var_0['failed'] == False
    assert var_0['changed'] == False
    int_1 = -943
    float_0 = -1580.3
    str_0 = 'ansible.executor.powershell'
    action_module_1 = ActionModule(int_1, float_0, str_0, float_0, int_0, int_0)
    var_1 = action_module_1.run()

# Generated at 2022-06-25 07:49:40.822845
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        test_case_0()
        print('\nPASSED: test_ActionModule_run')
    except Exception as e:
        print(e)
        print('\nFAILED: test_ActionModule_run')
if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 07:49:48.856469
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -2359.8
    list_0 = [float_0, float_0]
    int_0 = -2089
    bytes_0 = b'\xd8\x9d\x10\xbd\x8d\x1f\x89\x80\xec\x86\x9d\x03\x87\x1c\xca\xcf\xe7\xf4\xc4\xbc\x8f'
    tuple_0 = (int_0, bytes_0)
    str_0 = 'ansible.plugins.action.ActionBase'
    action_module_0 = ActionModule(float_0, list_0, str_0, float_0, tuple_0)


# Generated at 2022-06-25 07:50:00.593651
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -2509.8
    list_0 = [float_0, float_0, float_0, float_0]
    bool_0 = True
    int_0 = 1593
    int_1 = -2536
    bytes_0 = b'\n\xeb-\xe1\xaa\x95%\x82\x9c\xc40'
    tuple_0 = (list_0, bytes_0)
    str_0 = 'ansible.executor.powershell'
    complex_0 = None
    int_2 = 2438
    action_module_0 = ActionModule(float_0, tuple_0, str_0, float_0, complex_0, int_2)

# Generated at 2022-06-25 07:50:10.075806
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -2509.8
    list_0 = [float_0, float_0, float_0, float_0]
    bool_0 = True
    int_0 = 1593
    int_1 = -2536
    bytes_0 = b'\n\xeb-\xe1\xaa\x95%\x82\x9c\xc40'
    tuple_0 = (list_0, bytes_0)
    str_0 = 'ansible.executor.powershell'
    complex_0 = None
    int_2 = 2438
    action_module_0 = ActionModule(float_0, tuple_0, str_0, float_0, complex_0, int_2)

# Generated at 2022-06-25 07:50:15.634600
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -2509.8
    list_0 = [float_0, float_0, float_0, float_0]
    bool_0 = True
    int_0 = 1593
    int_1 = -2536
    bytes_0 = b'\n\xeb-\xe1\xaa\x95%\x82\x9c\xc40'
    tuple_0 = (list_0, bytes_0)
    complex_0 = None
    int_2 = 2438
    action_module_0 = ActionModule(float_0, tuple_0, bool_0, int_0, int_1, complex_0)
    print('Testing constructor for class ActionModule')
    print('Expected result: ActionModule')
    print('Actual result:', type(action_module_0))

# Generated at 2022-06-25 07:50:22.790649
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -1507.6
    list_0 = [float_0, float_0, float_0, float_0]
    str_0 = 'ansible.playbook.play'
    action_module_1 = ActionModule(float_0, list_0, str_0, float_0, float_0)
    assert action_module_1._display.verbosity == 2
    assert isinstance(action_module_1._connection, ansible.plugins.action.ActionBase)
    assert action_module_1._task.action == 'action_mock'
    assert action_module_1._task.args == {}
    assert isinstance(action_module_1._loader, ansible.parsing.dataloader.DataLoader)

# Generated at 2022-06-25 07:50:32.108679
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -2509.8
    list_0 = [float_0, float_0, float_0, float_0]
    bool_0 = True
    int_0 = 1593
    int_1 = -2536
    bytes_0 = b'\n\xeb-\xe1\xaa\x95%\x82\x9c\xc40'
    tuple_0 = (list_0, bytes_0)
    str_0 = 'ansible.executor.powershell'
    complex_0 = None
    int_2 = 2438
    action_module_0 = ActionModule(float_0, tuple_0, str_0, float_0, complex_0, int_2)

# Generated at 2022-06-25 07:50:37.976124
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor test
    bool_0 = True
    list_0 = ['n', 'f', '6', '1j', '&', '_', 'o', '^', 'x', 'z%', 'e', '#', 'Z', 'J', '1', 'T', 'e', 'q', 'E', '9', 'O', 'P', '@', 'u', '=', '7', 'w', 'S', '_', 'D', 'V', 'k', '.', '+', 'Z', '@', 'w', 'T', 's', 'b', 'f', '9', 'De', 'f', 'P', 'u', '!', 'n', 'I']
    int_0 = 1023
    complex_0 = complex(int_0, list_0)