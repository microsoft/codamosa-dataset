

# Generated at 2022-06-25 07:41:43.504510
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    str_0 = 'P>IT\\V\\##'
    tmp = str_0
    task_vars = {}
    result = action_module_0.run(tmp, task_vars)
    assert result


# Generated at 2022-06-25 07:41:51.401451
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # str a
    str_a = '\x1f\xc9\x0f\x0e\xfa\xbd'
    # bytes b
    bytes_b = b'K\xcf\xc2\xe8\x01\x96\xde\xdb\x8c\xbc\x90\x9d\x86\xf4\xab\xe2\xcc\x1d\x8e&\x04\x13\xc9{\xd3\xc5\xde\x1fz\xdb'
    # str c
    str_c = '\x1f\xc9\x0f\x0e\xfa\xbd'
    # int d
    int_d = 0
    # bytes e

# Generated at 2022-06-25 07:41:52.676602
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0 = ActionModule(None, None, None, None, None, None)


# Generated at 2022-06-25 07:42:01.580204
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'p%c#'
    bytes_0 = b'\x87\x9ak\x81\x14\f\x80\x1d\x97\xe4\x8d\xd4\xc4'
    float_0 = -981.17626
    float_1 = -5.5365
    action_module_0 = ActionModule(str_0, bytes_0, str_0, float_0, bytes_0, float_1)

# Generated at 2022-06-25 07:42:07.371468
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '9}Q\\,*Ypj{[\x0c<ak'
    bytes_0 = b'\xe2\x1c\xe0Y\xc8z\xc1Hn)\x06Yxh\xa1\xdfZ\xea'
    float_0 = -459.71745
    float_1 = -110.45
    action_module_0 = ActionModule(str_0, bytes_0, str_0, float_0, bytes_0, float_1)


# Generated at 2022-06-25 07:42:14.397095
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '9}Q\\,*Ypj{[\x0c<ak'
    bytes_0 = b'\xe2\x1c\xe0Y\xc8z\xc1Hn)\x06Yxh\xa1\xdfZ\xea'
    float_0 = -459.71745
    float_1 = -110.45
    action_module_0 = ActionModule(str_0, bytes_0, str_0, float_0, bytes_0, float_1)
    str_1 = 'x\x8d\x02\x9aO\xed\xee\x97\xf82\x05'

# Generated at 2022-06-25 07:42:25.339478
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '$w&jk\x0c*\x0c\x0c%'
    float_0 = 0.093
    str_1 = 'Z|t\x0c,*\x0cK'
    float_1 = 1.802
    str_2 = '4KZzf'
    float_2 = 2.072
    str_3 = '+%e\x0c6Y'
    float_3 = -506.6
    str_4 = 'f^\x0c\x0c\x01,Y'
    float_4 = 6.3
    str_5 = 'e9\x0cf,@l>'
    float_5 = 9.96

# Generated at 2022-06-25 07:42:33.743077
# Unit test for constructor of class ActionModule
def test_ActionModule():
    arg0 = '\x02\x0e\x12\t\r\t\r\t\r'
    arg1 = b'}o\xc3\xef\x13\x92\x93r\x00\x8f\xe3\x04\x91\xeb\xce\x9f\x0f\x86\xe1\xe1\xce\xcf\xa7\xc5\x95\x82\x9a\x98\xde\x84\x04\xd0\xb2&'
    arg2 = '\x01\x07\x0f\x0b\x0f\x0b\x0f\x0b'
    arg3 = -534.988

# Generated at 2022-06-25 07:42:38.951178
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '^[@I\x1c\x1c\x1c0\x12F#MK\x1c\x1c\x1c\x1c\x1c\x1c\x1c'
    bytes_0 = b'\xf6\x14\x05\xf5\xe8\x874\x0f0\xb6\x1a\xdd\xf1\xe4'
    float_0 = -298.7075
    float_1 = -58.140113
    action_module_0 = ActionModule(str_0, bytes_0, str_0, float_0, bytes_0, float_1)
    task_0 = Task(action_module_0, float_0)

# Generated at 2022-06-25 07:42:47.185529
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # boilerplate test setup
    task_vars = {
        'ansible_verbosity': "verbose",
        'ansible_stats': {
            'data': {
                'myvar': 'foo'
            },
            'aggregate': True,
            'per_host': False
        }
    }
    inventory = 'foo'
    loader = 'bar'
    task = 'baz'

    # should fail when no data is given
    module = ActionModule(task, inventory, loader, None, None, None)
    result = module.run(task_vars=task_vars)
    assert result.get('failed') is True
    assert result.get('msg') == "The 'data' option needs to be a dictionary/hash"

    # should fail when data is not a dictionary

# Generated at 2022-06-25 07:42:53.566003
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Default arguments
    pass



# Generated at 2022-06-25 07:43:03.180083
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None
    var_1 = dict()
    var_2 = dict()
    var_3 = dict()
    var_3['ok'] = 'ok'
    var_3['failed'] = False
    var_3['changed'] = False
    var_2['rc'] = 0
    var_2['stderr_lines'] = list()
    var_2['stdout_lines'] = list()
    var_1['result'] = var_3

    # Just a test to create an object of ActionModule
    try:
        test_case_0()
    except NameError:
        print('test_case_0() failed')

    assert var_1['result'] == action_module_0.run(var_0, var_0)

    # Test with arguments
    var_4 = dict()
    var

# Generated at 2022-06-25 07:43:08.292450
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    try:
        test_case_0()
    except(TypeError, AssertionError):
        # test expected failure
        pass
    else:
        raise AssertionError(var_6)


# Generated at 2022-06-25 07:43:13.075272
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    var_1 = None
    var_2 = None

    # Init of object of class ActionModule
    action_module_0 = ActionModule(var_0, var_1, var_2, var_2, var_2, var_2)

    # Call of method run of object action_module_0
    action_module_0.run(var_1, var_2)

# Generated at 2022-06-25 07:43:17.053794
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = None
    var_2 = None
    tmp = None
    task_vars = None
    obj = ActionModule(var_1, var_2, var_2, var_2, var_2, var_2)
    result = obj.run(tmp, task_vars)
    print(result)

# Generated at 2022-06-25 07:43:24.577483
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = None
    action_module_0 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = tmp = None
    var_2 = task_vars = None
    try:
        var_3 = None
    except Exception as e:
        var_6 = e
    else:
        var_6 = None
    finally:
        var_5 = var_6
    try:
        var_4 = action_module_0.run(tmp=var_1, task_vars=var_2)
    except Exception as e:
        var_8 = e
    else:
        var_8 = None
    finally:
        var_7 = var_8

# Generated at 2022-06-25 07:43:31.098677
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(None, None, None, None, None, None)
    # tmp not used.
    tmp = None
    # task_vars not used.
    task_vars = None
    result = action_module_0.run(tmp, task_vars)
    print("Result: " + str(result))


# Generated at 2022-06-25 07:43:36.704300
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = None
    var_1 = None
    action_module_0 = ActionModule(var_0, var_0, var_0, var_0, var_0, var_0)
    var_1 = action_module_0.get_action_args()
    assert var_1 == None


# Generated at 2022-06-25 07:43:40.672163
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test for support for options - aggregate, data, per_host
    args_0 = {}
    args_0["aggregate"] = "aggregate"
    args_0["data"] = "data"
    args_0["per_host"] = "per_host"
    action_module_0 = ActionModule(var_0, var_0, args_0, var_0, var_0, var_0)
    action_module_0.run()


# Generated at 2022-06-25 07:43:43.650816
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, '__init__') is True
    assert isinstance(ActionModule.__init__, types.MethodType)

# Generated at 2022-06-25 07:43:51.210833
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -565
    str_0 = 'WJ6SYvrWE9\\v%'
    bool_0 = False
    list_0 = [bool_0]
    action_module_0 = ActionModule(str_0, bool_0, list_0, int_0, list_0, int_0)
    var_0 = action_run(int_0)

# Generated at 2022-06-25 07:43:56.301848
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -565
    str_0 = 'WJ6SYvrWE9\\v%'
    bool_0 = False
    list_0 = [bool_0]
    action_module_0 = ActionModule(str_0, bool_0, list_0, int_0, list_0, int_0)
    if (action_module_0._VALID_ARGS == frozenset({'aggregate', 'per_host', 'data'})):
        assert False
    if (not action_module_0.TRANSFERS_FILES):
        assert False


# Generated at 2022-06-25 07:44:02.170733
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -565
    str_0 = 'WJ6SYvrWE9\\v%'
    bool_0 = False
    list_0 = [bool_0]
    action_module_0 = ActionModule(str_0, bool_0, list_0, int_0, list_0, int_0)


# Generated at 2022-06-25 07:44:10.098661
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -176
    str_0 = 'WJ6SYvrWE9\\v%'
    bool_0 = False
    list_0 = [bool_0]
    action_module_0 = ActionModule(str_0, bool_0, list_0, int_0, list_0, int_0)
    if (action_module_0.TRANSFERS_FILES != True):
        print('Test failed')
    elif (action_module_0._VALID_ARGS != frozenset(('aggregate', 'data', 'per_host'))):
        print('Test failed')


# Generated at 2022-06-25 07:44:20.352357
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -200
    str_0 = 'Q`\\D'
    bool_0 = False
    list_0 = [False]
    tuple_0 = (str_0, bool_0, list_0, bool_0, bool_0, bool_0)
    str_1 = '^'
    list_1 = [str_1, bool_0]
    str_2 = 'b'

# Generated at 2022-06-25 07:44:27.497630
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -765
    str_0 = 'XNvL8C\\W\\i%'
    bool_0 = True
    list_0 = [bool_0]
    action_module_0 = ActionModule(str_0, bool_0, list_0, int_0, list_0, int_0)
    test_case_0()

# Generated at 2022-06-25 07:44:36.566039
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 3
    str_0 = 'I8Cvj[zOi'
    bool_0 = True
    list_0 = [bool_0, '5MZ[8']
    dict_0 = {'Gw\x7f': bool_0, str_0: int_0}
    action_module_0 = ActionModule(str_0, dict_0, list_0, dict_0, dict_0, 'jK8@nC#')

    #Test code for method run
    int_0 = -38
    str_0 = 'HZ,F[|g'
    bool_0 = True
    dict_0 = {'J4X|': int_0, 'CZ\x7f*': 'it0@Duh'}
    var_0 = action_module_0._

# Generated at 2022-06-25 07:44:47.025415
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = dict()
    dict_0['data'] = dict()
    dict_0['data'] = dict()
    dict_0['data']['ansible_facts'] = dict()
    dict_0['data']['ansible_facts']['ansible_processor_count'] = '1'
    dict_0['per_host'] = True
    action = ActionModule('/etc/ansible/ansible.cfg', '', '1', '1', '1', '1', '1', '1', dict_0, '1', '1', '1', '1')
    assert isinstance(action, ActionModule)

    dict_0['data'] = dict()
    dict_0['data']['ansible_facts'] = dict()

# Generated at 2022-06-25 07:44:50.415936
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -437
    str_0 = '-p'
    bool_0 = False
    list_0 = [str_0]
    list_1 = [str_0]
    int_1 = -425
    action_module_0 = ActionModule(str_0, bool_0, list_0, int_0, list_1, int_1)


# Generated at 2022-06-25 07:44:55.488333
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    for _ in range(10):
        try:
            test_case_0()
        except SystemExit:
            continue



if __name__ == '__main__':
    # Unit test for method run of class ActionModule
    test_ActionModule_run()

# Generated at 2022-06-25 07:45:09.593445
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 91
    str_0 = '0f{F}%'
    bool_0 = False
    list_0 = [str_0]
    list_1 = [None]
    int_1 = 521
    action_module_0 = ActionModule(str_0, bool_0, list_0, int_0, list_0, int_1)

# Generated at 2022-06-25 07:45:17.616591
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -565
    str_0 = 'WJ6SYvrWE9\\v%'
    bool_0 = False
    list_0 = [bool_0]
    action_module_0 = ActionModule(str_0, bool_0, list_0, int_0, list_0, int_0)
    int_1 = -44
    dict_0 = {'data': {}, 'per_host': False, 'aggregate': True}
    dict_1 = {'data': {}, 'per_host': True, 'aggregate': False}
    set_stats_0 = action_module_0.set_stats(dict_1)
    var_0 = action_module_0.run(int_1, dict_0)

# Generated at 2022-06-25 07:45:24.322900
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 0
    str_0 = 'eZ\\IwZ8\\Q\\'
    bool_0 = True
    list_0 = [int_0]
    action_module_0 = ActionModule(str_0, bool_0, list_0, int_0, list_0, int_0)
    action_run(int_0)

# Generated at 2022-06-25 07:45:35.088433
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = 'tZ@\\t\\4'
    var_1 = '$D}7I'
    var_3 = False
    var_4 = True
    var_5 = {'QdI:F&#cQ': [var_4, var_4, var_4], 'Z`4t<C_': False, 'p(=w55*$': 'rvF8+%\\J', 'Ne*?': False, 's`+}l': '&hJH_k', 'R': [False, var_1, False, var_0, False], 'gqWXL': 'i~Pw`C', 'B)Y=Y#': '9-Ue'}

# Generated at 2022-06-25 07:45:40.539289
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'Se`t9h"t'
    bool_0 = False
    list_0 = [bool_0, bool_0]
    int_0 = -460
    list_1 = [list_0, list_0]
    int_1 = -535
    action_module_0 = ActionModule(str_0, bool_0, list_0, int_0, list_1, int_1)
    int_2 = -122
    list_2 = [list_1, list_1]
    var_0 = action_module_0.run(list_2, int_2)

# Python 2.7 requirement

# Generated at 2022-06-25 07:45:48.195784
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = ''
    boolean_0 = boolean(result)
    list_0 = []
    data_var = result
    per_host_var = result
    aggregate_var = result
    action_module_0 = ActionModule(data_var, per_host_var, aggregate_var, result, list_0, result)
    action_module_1 = ActionModule(data_var, per_host_var, aggregate_var, result, list_0, result)


# Generated at 2022-06-25 07:45:53.000427
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -565
    str_0 = 'WJ6SYvrWE9\\v%'
    bool_0 = False
    list_0 = [bool_0]
    action_module_0 = ActionModule(str_0, bool_0, list_0, int_0, list_0, int_0)


# Generated at 2022-06-25 07:45:58.766147
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 0
    str_0 = '-565'
    bool_0 = False
    list_0 = [True]
    action_module_0 = ActionModule(str_0, bool_0, list_0, int_0, list_0, int_0)
    assert isinstance(action_module_0, ActionModule)

# Generated at 2022-06-25 07:46:05.888741
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -565
    str_0 = 'WJ6SYvrWE9\\v%'
    bool_0 = False
    list_0 = [bool_0]
    action_module_0 = ActionModule(str_0, bool_0, list_0, int_0, list_0, int_0)
    var_0 = action_run(int_0)


# Generated at 2022-06-25 07:46:06.816710
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:46:29.653492
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(arg_1, arg_2, arg_3, arg_4, arg_5, arg_6)


# Generated at 2022-06-25 07:46:34.159273
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -596
    str_0 = 'WJ6SYvrWE9\\v%'
    bool_0 = False
    list_0 = [bool_0]
    action_module_0 = ActionModule(str_0, bool_0, list_0, int_0, list_0, int_0)
    var_0 = action_module_0.run(int_0)
    assert var_0 == False

# Generated at 2022-06-25 07:46:38.667038
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -565
    str_0 = 'WJ6SYvrWE9\\v%'
    bool_0 = False
    list_0 = [bool_0]
    action_module_0 = ActionModule(str_0, bool_0, list_0, int_0, list_0, int_0)
    int_0 = -565
    var_0 = action_run(int_0)
    assert var_0 == True

# Generated at 2022-06-25 07:46:47.801245
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -565
    str_0 = 'WJ6SYvrWE9\\v%'
    bool_0 = False
    list_0 = [bool_0]
    action_module_0 = ActionModule(str_0, bool_0, list_0, int_0, list_0, int_0)
    str_1 = 'Xqm0Ua'
    bool_1 = True
    list_1 = [bool_1]
    int_1 = -9
    action_module_1 = ActionModule(str_1, bool_1, list_1, int_1, list_1, int_1)
    str_2 = '~V8s'
    bool_2 = True
    list_2 = [str_0]
    int_2 = -50

# Generated at 2022-06-25 07:46:48.459548
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 0


# Generated at 2022-06-25 07:46:52.554181
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -565
    str_0 = 'WJ6SYvrWE9\\v%'
    bool_0 = False
    list_0 = [bool_0]
    action_module_0 = ActionModule(str_0, bool_0, list_0, int_0, list_0, int_0)
    var_0 = action_run(int_0)

# Generated at 2022-06-25 07:46:57.288182
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -10010
    str_0 = 'b!W$_+Qg '
    bool_0 = False
    list_0 = [int_0]
    action_module_0 = ActionModule(str_0, bool_0, list_0, int_0, list_0, int_0)


# Generated at 2022-06-25 07:47:04.679747
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -788
    str_0 = 'VGe!tpb;-)7,u'
    bool_0 = True
    list_0 = [int_0]
    int_1 = 143
    action_module_0 = ActionModule(str_0, bool_0, list_0, int_0, list_0, int_1)
    assert action_module_0.is_connection_based is bool_0
    assert action_module_0._task.action == str_0
    assert action_module_0.inject is list_0
    assert action_module_0._task.loop_control.loop_var == str_0
    assert action_module_0._task.always_run is list_0
    assert action_module_0._task.have_task_vars is int_1

# Generated at 2022-06-25 07:47:11.292627
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 6
    str_0 = 'pP'
    bool_0 = True
    list_0 = [bool_0]
    test_obj = ActionModule(str_0, bool_0, list_0, int_0, list_0, int_0)
    assert isinstance(test_obj, ActionModule)


# Generated at 2022-06-25 07:47:16.877013
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize host_args and argspec
    argspec = [
        'tmp',
        'task_vars'
    ]
    host_args = {}

    # Mock the module and its method
    m_module = MagicMock(spec=['run'])
    m_module.run.return_value = var_run
    with patch.object(ActionModule, '_debug', return_value=var_debug):
        # Call the method
        res = ActionModule().run(host_args, argspec)
        # Check the result
        assert res == var_retval


# Generated at 2022-06-25 07:48:03.525257
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -565
    str_0 = 'WJ6SYvrWE9\\v%'
    bool_0 = False
    list_0 = [bool_0]
    action_module_0 = ActionModule(str_0, bool_0, list_0, int_0, list_0, int_0)
    var_0 = action_module_0.run('WJ6SYvrWE9\\v%', 'WJ6SYvrWE9\\v%')


# Generated at 2022-06-25 07:48:16.218284
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -565
    str_0 = 'WJ6SYvrWE9\\v%'
    bool_0 = False
    list_0 = [bool_0]
    action_module_0 = ActionModule(str_0, bool_0, list_0, int_0, list_0, int_0)
    assert action_module_0._task.action == str_0
    assert action_module_0._task.args == list_0
    assert action_module_0._task.task_vars == int_0
    assert action_module_0._task.tmpdir == list_0
    assert action_module_0._task.any_errors_fatal == int_0
    assert action_module_0._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-25 07:48:23.299688
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'hXp1^%'
    bool_0 = False
    list_0 = [str_0, bool_0]
    int_0 = -261
    action_module_0 = ActionModule(str_0, bool_0, list_0, int_0, list_0, int_0)
    int_1 = 0
    data_0 = {}
    str_1 = 'I'
    str_2 = 'x8~pW'
    bool_1 = True
    var_1 = action_run(int_1, data_0, str_1, str_2, bool_1)
    print(var_1)

# Generated at 2022-06-25 07:48:26.876335
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    dict_0 = {'key_1': 'value_1', 'key_0': 'value_0'}
    action_module_0 = ActionModule('default', bool_0, dict_0, dict_0, dict_0, dict_0)
    var_0 = action_module_0.run()



# Generated at 2022-06-25 07:48:35.744844
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    string_0 = ' '
    boolean_0 = True
    list_0 = []
    integer_0 = -495
    list_1 = []
    integer_1 = -19
    action_module_0 = ActionModule(string_0, boolean_0, list_0, integer_0, list_1, integer_1)
    dictionary_0 = {'to': u'1', 'or': u'1', 'is': u'1', 'true': u'1', 'false': u'1', 'and': u'1'}
    boolean_1 = False
    boolean_2 = True
    integer_2 = -64
    integer_3 = -64

# Generated at 2022-06-25 07:48:41.986317
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -922
    str_0 = '`'
    bool_0 = True
    list_0 = [str_0]
    action_module_0 = ActionModule(str_0, bool_0, list_0, int_0, list_0, int_0)
    assert (action_module_0.TRANSFERS_FILES == False)
    assert (action_module_0.msg != 'dxW8JvK}o0b+>')
    assert (action_module_0._task.action != 'XzgC:PqK0-')


# Generated at 2022-06-25 07:48:46.873952
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars_0 = '-565'
    tmp_0 = 'wB%J1~Q,(8WtETb_v('
    int_0 = -565
    str_0 = 'WJ6SYvrWE9\\v%'
    bool_0 = False
    list_0 = [bool_0]
    action_module_0 = ActionModule(str_0, bool_0, list_0, int_0, list_0, int_0)
    var_0 = action_module_0.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 07:48:58.248903
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -812
    str_0 = 'u88N0BV7xu0'
    bool_0 = False
    list_0 = [bool_0]
    action_module_0 = ActionModule(str_0, bool_0, list_0, int_0, list_0, int_0)
    int_1 = -812
    var_0 = action_module_0.run(int_1)
    temp_hash_0 = ['Nz`', "Kj_Z", "Y/t", 'J?ej', bool_0, bool_0, bool_0]
    temp_hash_1 = ['Nz`', "Kj_Z", "Y/t", 'J?ej', bool_0, bool_0, bool_0]

# Generated at 2022-06-25 07:48:58.702806
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:49:07.230257
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -565
    str_0 = 'WJ6SYvrWE9\\v%'
    bool_0 = False
    list_0 = [bool_0]
    action_module_0 = ActionModule(str_0, bool_0, list_0, int_0, list_0, int_0)
    int_1 = -534
    str_1 = 'OZi-XbPW-h%#'
    var_0 = action_module_0.action_run(int_1, str_1)
    assert not isinstance(var_0, string_types), '%s is invalid' % type(var_0)


# Generated at 2022-06-25 07:50:55.686439
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("\n\nUnit test for method run of class ActionModule")

    result = action_module_0.run()
    print(result)


test_case_0()

# Generated at 2022-06-25 07:51:03.170319
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -400068
    str_0 = 'f2m;iV'
    bool_0 = True
    list_0 = [str_0]
    action_module_0 = ActionModule(str_0, bool_0, list_0, int_0, list_0, int_0)
    str_1 = 'H'
    bool_1 = True
    list_1 = ['C', 'c', 'J', 'E', 'R', ':', '{', 'y', 'M', '8', 'Q', '=']
    action_module_0 = ActionModule(str_1, bool_1, list_1, int_0, list_1, int_0)

# Generated at 2022-06-25 07:51:11.651666
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -895
    str_0 = 'zJ6'
    bool_0 = True
    list_0 = [str_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0, bool_0]
    action_module_0 = ActionModule(str_0, bool_0, list_0, int_0, list_0, int_0)
    var_0 = action_module_0.run(int_0)
    assert var_0 == None
    # print(var_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:51:16.131421
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -565
    str_0 = 'WJ6SYvrWE9\\v%'
    bool_0 = False
    list_0 = [bool_0]
    action_module_0 = ActionModule(str_0, bool_0, list_0, int_0, list_0, int_0)



# Generated at 2022-06-25 07:51:22.622579
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -565
    str_0 = 'WJ6SYvrWE9\\v%'
    bool_0 = False
    list_0 = [bool_0]
    action_module_0 = ActionModule(str_0, bool_0, list_0, int_0, list_0, int_0)
    bool_0 = bool_0
    list_1 = []
    bool_1 = bool_0
    action_module_0.run(list_1, list_1)
    var_0 = action_run(int_0)

# Generated at 2022-06-25 07:51:26.608970
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = -565
    str_0 = 'WJ6SYvrWE9\\v%'
    bool_0 = False
    list_0 = [bool_0]
    action_module_0 = ActionModule(str_0, bool_0, list_0, int_0, list_0, int_0)


# Generated at 2022-06-25 07:51:33.434481
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = -13886
    str_0 = 'M{"'
    bool_0 = False
    list_0 = [bool_0]
    action_module_0 = ActionModule(str_0, bool_0, list_0, int_0, list_0, int_0)
    var_0 = action_module_0.run(int_0, str_0)
    assert var_0 is None
