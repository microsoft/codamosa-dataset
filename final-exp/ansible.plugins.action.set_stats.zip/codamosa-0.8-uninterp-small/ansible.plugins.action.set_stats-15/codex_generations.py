

# Generated at 2022-06-25 07:41:45.351719
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # self, module, tmp=None, task_vars=None

    #
    # Initialize test environment
    #
    float_0 = 0.1143
    str_0 = 'k{O'
    bool_0 = False
    action_module_0 = ActionModule(float_0, float_0, str_0, bool_0, str_0, str_0)

    #
    # Initialize request parameters
    #
    tmp = None
    task_vars = None

    #
    # Make request
    #
    retval = action_module_0.run(tmp, task_vars)

    #
    # Evaluation of results
    #
    success = retval['changed']
    assert success == False

# Generated at 2022-06-25 07:41:50.539360
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule({'fail_on_undefined': False, 'no_log': False, 'data': '', 'task_vars': {}, 'tmp': '', 'remote_user': '', 'per_host': False, 'aggregate': True})

if __name__ == '__main__':
    test_case_0()
    # test_ActionModule()

# Generated at 2022-06-25 07:41:55.621684
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 0.0001
    str_0 = '(.>y#ux'
    bool_0 = False
    action_module_0 = ActionModule(float_0, float_0, str_0, bool_0, str_0, str_0)
    action_module_0.set_task('l7q,_')
    tmp = dict()
    task_vars = dict()
    action_module_0.run(tmp, task_vars)

# NOTE: test can be executed only in isolation because of the availability of the module
# #Unit test for method run from class ActionModule
# def test_run():
#     float_0 = 0.0001
#     str_0 = '(.>y#ux'
#     bool_0 = False
#     action_module_0 = ActionModule(float_0,

# Generated at 2022-06-25 07:41:56.434423
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:42:01.941831
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 0.8456796862723952
    str_0 = 'ZW8j@E'
    bool_0 = False
    action_module_0 = ActionModule(float_0, float_0, str_0, bool_0, str_0, str_0)
    # TODO: add test case


# Generated at 2022-06-25 07:42:07.788867
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 0.09414255811410443
    str_0 = '~'
    bool_0 = True
    action_module_0 = ActionModule(float_0, float_0, str_0, bool_0, str_0, str_0)
    action_module_1 = ActionModule(float_0, float_0, str_0, bool_0, str_0, str_0)
    assert action_module_0.loader == action_module_1.loader
    assert action_module_0.playbook == action_module_1.playbook

# Generated at 2022-06-25 07:42:13.755107
# Unit test for constructor of class ActionModule
def test_ActionModule():

    assert(isinstance(ActionModule.__name__, str))
    assert(isinstance(ActionModule.__doc__, str))

    test_case_0()


# Generated at 2022-06-25 07:42:21.066055
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 0.0001
    str_0 = 'addtiop'
    str_1 = 'on'
    str_2 = '_AK'
    bool_0 = False
    str_3 = 'b5^?,E'
    str_4 = '&Y1'
    bool_1 = True
    action_module_0 = ActionModule(float_0, float_0, str_0, bool_0, str_1, str_2)
    action_module_0.STACK_NAME = str_3
    action_module_0.CLIENT_ID = str_4
    action_module_0.start = bool_1
    task_vars_0 = dict()

    result = action_module_0.run(task_vars=task_vars_0)
    assert key_in_result

# Generated at 2022-06-25 07:42:30.292627
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 0.0001
    str_0 = '(.>y#ux'
    bool_0 = False
    action_module_0 = ActionModule(float_0, float_0, str_0, bool_0, str_0, str_0)

    str_1 = 'W1[MZv)s'
    str_2 = 'fP&e'
    dict_0 = {
        'data': {
            str_1: str_2
        },
        'per_host': True,
        'aggregate': False
    }

    dict_1 = {}
    dict_1 = action_module_0.run(dict_0, dict_1)
    assert dict_1['changed'] == False

# Generated at 2022-06-25 07:42:36.931896
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 0.0001
    str_0 = '(.>y#ux'
    bool_0 = False
    action_module_0 = ActionModule(float_0, float_0, str_0, bool_0, str_0, str_0)
    float_1 = 0.0001
    dict_0 = dict()
    dict_1 = {
        'msg': "The variable name '%s' is not valid. Variables must start with a letter or underscore character, and contain only "
               "letters, numbers and underscores.",
        'failed': True
    }
    dict_2 = dict()
    dict_2['per_host'] = True
    dict_2['aggregate'] = True
    dict_2['data'] = dict()
    dict_3 = dict()
    dict_3['data'] = dict()


# Generated at 2022-06-25 07:42:43.197891
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:42:48.177625
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True == True

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:42:54.833485
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_obj = ActionModule()
    assert isinstance(action_module_obj,ActionModule)
    action_module_obj.set_loader(test_case_0)
    assert action_module_obj.set_loader(test_case_0) == None
    result = action_module_obj.run(tmp=None,task_vars=None)
    # assert result == 'print hello'
    return result

# Generated at 2022-06-25 07:42:58.665697
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    result = action_module_1.run(tmp='tmp', task_vars='task_vars')
    assert isinstance(result, dict)
    assert "failed" in result.keys()
    assert result.get('failed') is True


# Generated at 2022-06-25 07:43:00.381811
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_class = ActionModule()
    assert isinstance(action_module_class, ActionModule)


# Generated at 2022-06-25 07:43:03.402166
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    (result, ) = action_module_0.run()
    assert result.get('ansible_stats', {}).get('data', {}) == {}
    assert result.get('ansible_stats', {}).get('aggregate', True) == True
    assert result.get('ansible_stats', {}).get('per_host', False) == False

# Generated at 2022-06-25 07:43:07.442720
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    assert action_module_0.run(tmp=None, task_vars=None) == {'ansible_stats': {'per_host': False, 'data': {}, 'aggregate': True}, 'changed': False}

if __name__ == "__main__":
    test_ActionModule_run()

# Generated at 2022-06-25 07:43:08.164271
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:43:09.172914
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert action_module_0.__class__ is ActionModule


# Generated at 2022-06-25 07:43:10.013773
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert not ActionModule().run()

# Generated at 2022-06-25 07:43:23.265544
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -3291.0
    float_1 = 543.766374
    tuple_0 = (float_0, float_1, float_1)
    dict_0 = {}
    set_0 = {float_0, tuple_0, tuple_0, tuple_0}
    float_2 = -53.64
    str_0 = 'rF'
    action_module_0 = ActionModule(tuple_0, dict_0, set_0, float_2, str_0, set_0)
    var_0 = tmp()
    var_1 = task_vars()
    # Call method run of class ActionModule with args (var_0, var_1)
    action_module_0.run(var_0, var_1)


# Generated at 2022-06-25 07:43:27.806031
# Unit test for constructor of class ActionModule
def test_ActionModule():
    data = {'test': 'foo'}
    args = {'data': data}
    action_module = ActionModule({'args': args, 'task': {'args': args}}, {}, {})
    # This will fail if the constructor fails.
    action_module.run()
    action_module.run(task_vars={'ansible_facts': {'hostname': 'host'}})

# Generated at 2022-06-25 07:43:31.135469
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    #assert action_module_0.true  # TODO: implement test



# Generated at 2022-06-25 07:43:39.891247
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 0.0
    float_1 = -0.0
    tuple_0 = (float_0, float_1, float_1)
    dict_0 = {}
    set_0 = {float_0, tuple_0, tuple_0, tuple_0}
    float_2 = 0.0
    str_0 = 'rF'
    action_module_0 = ActionModule(tuple_0, dict_0, set_0, float_2, str_0, set_0)
    str_1 = ''
    boolean_0 = boolean(str_1, strict=False)
    boolean_1 = boolean(str_1, strict=True)
    str_2 = ''
    boolean_2 = boolean(str_2, strict=False)

# Generated at 2022-06-25 07:43:50.447212
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = dict
    dict_0['data'] = dict
    dict_0['per_host'] = dict
    dict_0['aggregate'] = dict
    dict_0 = dict
    dict_0['data'] = dict
    dict_0['per_host'] = dict
    dict_0['aggregate'] = dict
    tuple_0 = (dict_0, dict_0, dict_0)
    dict_0 = dict
    dict_0['data'] = dict
    dict_0['per_host'] = dict
    dict_0['aggregate'] = dict
    set_2 = {dict_0, tuple_0, tuple_0, tuple_0}
    float_0 = -524.62
    str_0 = 'o_'

# Generated at 2022-06-25 07:43:58.577071
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = (float_0, float_1, float_1)
    dict_0 = {}
    set_0 = {float_0, tuple_0, tuple_0, tuple_0}
    float_2 = -53.64
    str_0 = 'rF'
    action_module_0 = ActionModule(tuple_0, dict_0, set_0, float_2, str_0, set_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:44:03.146073
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -1430.5270768796043
    float_1 = -6456.0
    tuple_0 = (float_0, float_0, float_0, float_1)
    dict_0 = {}
    set_0 = {float_1, float_0, tuple_0}
    float_2 = -44.04187
    str_0 = 'krA$'
    action_module_0 = ActionModule(tuple_0, dict_0, set_0, float_2, str_0, set_0)

test_case_0()

# Generated at 2022-06-25 07:44:11.220636
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -57.49
    float_1 = -2176.0
    tuple_0 = (float_1, float_1, float_0)
    dict_0 = {}
    set_0 = {float_1, float_1, float_1}
    float_2 = 981.17
    str_0 = 'yM&tBGx'
    action_module_0 = ActionModule(tuple_0, dict_0, set_0, float_1, str_0, set_0)
    assert action_module_0._task.action == str_0
    assert action_module_0._task.loop is set_0
    assert action_module_0._task.args is dict_0
    assert action_module_0._task.deferred_to_host is tuple_0
    assert action_

# Generated at 2022-06-25 07:44:20.448491
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -3291.0
    float_1 = 543.766374
    tuple_0 = (float_0, float_1, float_1)
    dict_0 = {}
    set_0 = {float_0, tuple_0, tuple_0, tuple_0}
    float_2 = -53.64
    str_0 = 'rF'
    action_module_0 = ActionModule(tuple_0, dict_0, set_0, float_2, str_0, set_0)
    assert(action_module_0.tmp == tuple_0)
    assert(action_module_0.task_vars == dict_0)
    assert(action_module_0.connection == set_0)
    assert(action_module_0.play_context == float_2)

# Generated at 2022-06-25 07:44:28.939220
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -3291.0
    float_1 = 543.766374
    tuple_0 = (float_0, float_1, float_1)
    dict_0 = {}
    set_0 = {float_0, tuple_0, tuple_0, tuple_0}
    float_2 = -53.64
    str_0 = 'rF'
    action_module_0 = ActionModule(tuple_0, dict_0, set_0, float_2, str_0, set_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:44:41.502480
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {}
    tmp = '$HOME'
    action_module_0 = ActionModule(tmp, task_vars)
    action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 07:44:50.531097
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -3291.0
    float_1 = 543.766374
    tuple_0 = (float_0, float_1, float_1)
    dict_0 = {}
    set_0 = {float_0, tuple_0, tuple_0, tuple_0}
    float_2 = -53.64
    str_0 = 'rF'
    action_module_0 = ActionModule(tuple_0, dict_0, set_0, float_2, str_0, set_0)
    var_0 = action_module_0.run()
    var_0 = action_module_0.TRANSFERS_FILES

# Generated at 2022-06-25 07:45:00.169555
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test case #0
    float_0 = -3291.0
    float_1 = 543.766374
    tuple_0 = (float_0, float_1, float_1)
    dict_0 = {}
    set_0 = {float_0, tuple_0, tuple_0, tuple_0}
    float_2 = -53.64
    str_0 = 'rF'
    action_module_0 = ActionModule(tuple_0, dict_0, set_0, float_2, str_0, set_0)
    var_0 = action_run()
    return var_0


# Generated at 2022-06-25 07:45:07.201926
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_1 = -3291.0
    float_2 = 543.766374
    tuple_1 = (float_1, float_2, float_2)
    dict_1 = {}
    set_1 = {float_1, tuple_1, tuple_1, tuple_1}
    float_3 = -53.64
    str_1 = 'rF'
    action_module_1 = ActionModule(tuple_1, dict_1, set_1, float_3, str_1, set_1)
    assert action_module_1.run(None, None) == None


# Generated at 2022-06-25 07:45:14.771015
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -129.87
    str_0 = '# mF'
    tuple_0 = ()
    float_1 = 89.774872783
    float_2 = -64.708925
    float_3 = -8.0
    str_1 = 'VuZ'
    set_0 = {tuple_0, tuple_0, tuple_0, tuple_0, tuple_0, tuple_0, tuple_0, tuple_0, tuple_0, tuple_0}
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {}
   

# Generated at 2022-06-25 07:45:19.555447
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = set()
    var_1 = dict()
    var_2 = set()
    var_3 = -87.1
    var_4 = '\x0f'
    var_5 = set()
    action_module_0 = ActionModule(var_0, var_1, var_2, var_3, var_4, var_5)


# Generated at 2022-06-25 07:45:24.000885
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_2 = ActionModule(set_0, set_0, float_0, str_0, set_0, str_0)
    var_0 = ActionModule.run(action_module_2)
    assert var_0 == "The 'data' option needs to be a dictionary/hash"

# Generated at 2022-06-25 07:45:26.194134
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:45:33.598093
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -3291.0
    float_1 = 543.766374
    tuple_0 = (float_0, float_1, float_1)
    dict_0 = {}
    set_0 = {float_0, tuple_0, tuple_0, tuple_0}
    float_2 = -53.64
    str_0 = 'rF'
    action_module_0 = ActionModule(tuple_0, dict_0, set_0, float_2, str_0, set_0)
    var_0 = action_run()



# Generated at 2022-06-25 07:45:35.647898
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    var_1 = 87
    var_0 = action_module_0.run(var_1)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:46:01.309577
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -3291.0
    float_1 = 543.766374
    tuple_0 = (float_0, float_1, float_1)
    dict_0 = {}
    set_0 = {float_0, tuple_0, tuple_0, tuple_0}
    float_2 = -53.64
    str_0 = 'rF'
    action_module_0 = ActionModule(tuple_0, dict_0, set_0, float_2, str_0, set_0)


# Generated at 2022-06-25 07:46:07.632989
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -3291.0
    float_1 = 543.766374
    tuple_0 = (float_0, float_1, float_1)
    dict_0 = {}
    set_0 = {float_0, tuple_0, tuple_0, tuple_0}
    float_2 = -53.64
    str_0 = 'rF'
    action_module_0 = ActionModule(tuple_0, dict_0, set_0, float_2, str_0, set_0)
    del action_module_0


# Generated at 2022-06-25 07:46:11.740893
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:46:19.828171
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -2335.0
    float_1 = 32.43
    float_2 = 17.6
    tuple_0 = (float_0, float_2, float_2, float_1)
    dict_0 = {}
    set_0 = {float_2, tuple_0, float_0}
    str_0 = 'U@'
    action_module_0 = ActionModule(tuple_0, dict_0, set_0, float_2, str_0, set_0)
    assert action_module_0._task.args == {'data': {}, 'per_host': False, 'aggregate': True}
    assert action_module_0.TRANSFERS_FILES == False

# Generated at 2022-06-25 07:46:25.105783
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    v = {}
    a = ActionModule(v)
    b = a.run(0)
    assert b == 0
    b = a.run()
    assert b == 0
    b = a.run(tmp=0)
    assert b == 0
    b = a.run(task_vars=0)
    assert b == 0

# Generated at 2022-06-25 07:46:32.671958
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -1281.0
    float_1 = -3937.513575
    float_2 = -3937.513575
    tuple_0 = (float_0, float_1, float_2)
    dict_0 = {}
    set_0 = {float_0, tuple_0, tuple_0, tuple_0}
    float_3 = -53.64
    str_0 = 'rF'
    action_module_0 = ActionModule(tuple_0, dict_0, set_0, float_3, str_0, set_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:46:36.085986
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Setup
    __main__ = ActionModule()

    # Invoke method
    result = __main__.run()

    # Verify results
    assert result == None

# Generated at 2022-06-25 07:46:43.748264
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -3291.0
    float_1 = 543.766374
    tuple_0 = (float_0, float_1, float_1)
    dict_0 = {}
    set_0 = {float_0, tuple_0, tuple_0, tuple_0}
    float_2 = -53.64
    str_0 = 'rF'
    action_module_0 = ActionModule(tuple_0, dict_0, set_0, float_2, str_0, set_0)
    action_module_0.run(None, None)

# Generated at 2022-06-25 07:46:52.991314
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -3291.0
    float_1 = 543.766374
    tuple_0 = (float_0, float_1, float_1)
    dict_0 = {}
    set_0 = {float_0, tuple_0, tuple_0, tuple_0}
    float_2 = -53.64
    str_0 = 'rF'
    action_module_0 = ActionModule(tuple_0, dict_0, set_0, float_2, str_0, set_0)
    var_0 = action_module_0.run()

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:47:01.980342
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 1.233815161875
    list_0 = [float_0, float_0]
    str_0 = ''.join(map(str, list_0))
    int_0 = 3
    dict_0 = dict()
    dict_1 = dict()
    dict_0['foo'] = str_0
    dict_0['bar'] = int_0
    dict_1['defaults'] = dict_0
    dict_2 = dict()
    dict_2['module_name'] = 'foo'
    dict_2['module_args'] = dict_1
    dict_0['0'] = dict_2
    dict_1['1'] = dict_0
    dict_2['2'] = dict_1
    dict_0['3'] = dict_2

# Generated at 2022-06-25 07:47:45.832926
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Testing run')



# Generated at 2022-06-25 07:47:47.940634
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Test case 0
    dict_0 = {}
    dict_0['template'] = 'rF'

    action_module = ActionModule(template=dict_0)


# Generated at 2022-06-25 07:47:56.210286
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    dict_0['_task'] = {}
    dict_0['_task']['args'] = {}
    dict_0['_task']['args']['data'] = {}
    dict_0['_task']['args']['data']['foo'] = '{{ comp }}'
    dict_0['_task']['args']['per_host'] = True
    dict_0['_task']['args']['aggregate'] = False
    dict_0['_loader'] = {}
    dict_0['_connection'] = {}
    dict_0['_templar'] = {}
    dict_0['_templar']['template'] = mock.MagicMock()
    dict_0['_templar']['template'].return_value = '1'

# Generated at 2022-06-25 07:48:00.720573
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action_module_0 = ActionModule()
    except NameError as err:
        assert False, "constructor raised NameError unexpectedly: " + str(err)
    except TypeError as err:
        assert False, "constructor raised TypeError unexpectedly: " + str(err)


# Generated at 2022-06-25 07:48:04.743936
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor call with arguments
    action_module_0 = ActionModule(float_0, dict_0, set_0, float_2, str_0, set_0)


# Generated at 2022-06-25 07:48:11.724614
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    param_0 = 't2'
    param_1 = {'z': {'x': 'y', 'x2': 'y2'}, 'z2': {'x': 'y', 'x2': 'y2'}}
    set_stats_result_0 = ActionModule_run('t2', param_1)
    assert (set_stats_result_0.get('failed') == False)

# Generated at 2022-06-25 07:48:16.296304
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 95.1168
    float_1 = -33.4
    tuple_0 = (float_0, float_1, float_1)
    dict_0 = {}
    set_0 = {float_0, tuple_0, tuple_0, tuple_0}
    float_2 = 13.0
    str_0 = 'rM'
    action_module_0 = ActionModule(tuple_0, dict_0, set_0, float_2, str_0, set_0)

# Generated at 2022-06-25 07:48:22.517237
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -3291.0
    float_1 = 543.766374
    tuple_0 = (float_0, float_1, float_1)
    dict_0 = {}
    set_0 = {float_0, tuple_0, tuple_0, tuple_0}
    float_2 = -53.64
    str_0 = 'rF'
    action_module_0 = ActionModule(tuple_0, dict_0, set_0, float_2, str_0, set_0)
    # Test function run of class ActionModule



# Generated at 2022-06-25 07:48:27.361414
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -3291.0
    float_1 = 543.766374
    tuple_0 = (float_0, float_1, float_1)
    dict_0 = {}
    set_0 = {float_0, tuple_0, tuple_0, tuple_0}
    float_2 = -53.64
    str_0 = 'rF'
    action_module_0 = ActionModule(tuple_0, dict_0, set_0, float_2, str_0, set_0)
    action_module_0.run()

# Generated at 2022-06-25 07:48:29.189832
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(None, None, None, None, None, None)
    assert action_module_0.run() == __

# Generated at 2022-06-25 07:50:21.552889
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 476.0
    map_0 = {'Ff': float_0, 'g': 'K', '_': float_0, 'S': float_0, '^': float_0, '1': float_0, 'f': float_0, '$': float_0, 'G': '', 't': 'j'}
    tuple_0 = (float_0, float_0, float_0)
    action_module_0 = ActionModule(tuple_0, tuple_0, tuple_0, float_0, float_0, map_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 07:50:29.949739
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -3291.0
    float_1 = 543.766374
    tuple_0 = (float_0, float_1, float_1)
    dict_0 = {}
    set_0 = {float_0, tuple_0, tuple_0, tuple_0}
    float_2 = -53.64
    str_0 = 'rF'
    action_module_0 = ActionModule(tuple_0, dict_0, set_0, float_2, str_0, set_0)
    assert(action_module_0._templar == 543.766374)


# Generated at 2022-06-25 07:50:39.880145
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:50:42.084984
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule.run()


# Generated at 2022-06-25 07:50:43.241168
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert run() == expected

# Generated at 2022-06-25 07:50:48.812070
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -3291.0
    float_1 = 543.766374
    tuple_0 = (float_0, float_1, float_1)
    dict_0 = {}
    set_0 = {float_0, tuple_0, tuple_0, tuple_0}
    float_2 = -53.64
    str_0 = 'rF'
    action_module_0 = ActionModule(tuple_0, dict_0, set_0, float_2, str_0, set_0)
    var_0 = action_module_0.run()

# vim:ft=python

# Generated at 2022-06-25 07:50:51.058516
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # This action is only used to generate data to be
    # consumed by set_stats.py which is in a separate module
    # so unit tests should not be used on it.
    pass


# Generated at 2022-06-25 07:50:51.899545
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert action_run == ActionRun(context, args)


# Generated at 2022-06-25 07:50:58.845445
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    arg_0 = {}
    arg_1 = {}
    arg_2 = {}
    arg_3 = {}
    arg_4 = {}
    arg_5 = {}
    arg_6 = {}
    ret_0 = ActionModule.run(arg_0, arg_1, arg_2, arg_3, arg_4, arg_5, arg_6)
    assert isinstance(ret_0, dict)
    assert ret_0['msg']
    assert ret_0['failed']

# Generated at 2022-06-25 07:51:08.463143
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -3291.0
    float_1 = 543.766374
    tuple_0 = (float_0, float_1, float_1)
    dict_0 = {}
    set_0 = {float_0, tuple_0, tuple_0, tuple_0}
    float_2 = -53.64
    str_0 = 'rF'
    action_module_0 = ActionModule(tuple_0, dict_0, set_0, float_2, str_0, set_0)
    tmp_0 = None
    task_vars_0 = None
    var_0 = action_module_0.run(tmp_0, task_vars_0)

