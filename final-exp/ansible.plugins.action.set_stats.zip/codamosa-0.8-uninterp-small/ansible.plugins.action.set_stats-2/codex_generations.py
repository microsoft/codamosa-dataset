

# Generated at 2022-06-25 07:41:43.617525
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create an instance of the class
    action_module_0 = ActionModule()
    # set values for its attributes
    action_module_0.name = 'set_stats'
    action_module_0.no_log = True
    action_module_0.task_vars = dict(display='setup', definition='setup', past_tense='set up', boot=True)

    # access the instance's attributes
    action_module_0.name
    action_module_0.no_log
    action_module_0.task_vars


# Generated at 2022-06-25 07:41:49.167953
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "hG'R#7x`-c`w{8K"
    action_module_0 = ActionModule()

if __name__ == '__main__':
    import sys
    import os
    
    sys.path.append(os.getcwd())
    #import pdb
    #pdb.set_trace()

    test_ActionModule()

# Generated at 2022-06-25 07:41:49.914712
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod_0 = ActionModule()


# Generated at 2022-06-25 07:41:55.915235
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Default arguments of constructor
    action_module_0 = ActionModule()
    # Arguments with either a default or None
    action_module_0 = ActionModule(action_module_0)

# Generated at 2022-06-25 07:42:06.374256
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_1 = ActionModule()
    dict_0 = dict()
    dict_1 = dict()
    dict_0['msg'] = "The 'data' option needs to be a dictionary/hash"
    dict_0['failed'] = True
    dict_1['data'] = dict_0
    dict_1['per_host'] = True
    dict_1['aggregate'] = False
    dict_0 = dict()
    dict_0['msg'] = "The variable name '%s' is not valid. Variables must start with a letter or underscore character, and contain only letters, numbers and underscores."
    dict_0['failed'] = True
    dict_1['msg'] = dict_0['msg']
    dict_1['failed'] = dict_0['failed']
    dict_0

# Generated at 2022-06-25 07:42:07.509578
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert test_case_0() == None


# Generated at 2022-06-25 07:42:17.985494
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "'$F1"
    int_0 = -143
    set_0 = {"D#'b"}
    bytes_0 = b'\x13\x00\x00\x00\x00\x04\x00\x00\x00\x00\x00\x00\x00\x00\x10\x00\x00\x00\x00\x10\x00\x00\x00\x00\x03\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    float_0 = 0.308919289017
    str_1 = "gA3"


# Generated at 2022-06-25 07:42:28.331997
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_task = MagicMock()
    mock_task.args = {'data': {'str_0': 'str_0', 'str_1': 'str_1'}, 'aggregate': False, 'per_host': False}
    mock_play_context = MagicMock(module_name = 'action_module_0')
    mock_play_context.module_name = 'action_module_0'
    mock_play_context.connection = 'local'
    mock_loader = MagicMock()
    mock_templar = MagicMock()
    mock_task_vars = {'str_0': 'str_0', 'str_1': 'str_1', 'str_2': 'str_2', 'str_3': 'str_3'}
    mock_tmp = '/tmp/path'
    dummy_

# Generated at 2022-06-25 07:42:32.574644
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()


# Generated at 2022-06-25 07:42:36.691113
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import collections
    # Test with default args
    tmp = None
    task_vars = None
    ActionModule_1 = ActionModule(tmp, task_vars)
    ActionModule_1._task = collections.namedtuple('Task', 'args')
    ActionModule_1._task.args = ""
    ActionModule_1._templar = collections.namedtuple('Templar', 'template')
    ActionModule_1._templar.template = None
    ActionModule_1.run()


if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:42:47.884823
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Task instance to be passed to action module
    # Creation of task instance with invalid action
    assert_raises(Exception, ActionModule, 'invalid-action', 'localhost', 'invalid-playbook')

    # Create task instance with valid action
    task_instance = ActionModule('action', 'localhost', 'invalid-playbook')

    # Test for class variables
    assert task_instance.name == 'action'
    assert task_instance.action == 'action'
    assert task_instance.args == {}
    assert task_instance.delegate_to == 'localhost'
    assert task_instance.noop_task is True
    assert task_instance.notify is []
    assert task_instance.run_once is False
    assert task_instance.transport == 'ssh'
    assert task_instance._role is None
    assert task_instance

# Generated at 2022-06-25 07:42:55.611436
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    data = {'data' :{'test_data' : 'test'}, 'per_host' : False, 'aggregate' : True}
    result = {'changed' : False, 'ansible_stats' : data}
    action_module_1.run(1, {'data': {'test_data' : 'test'}, 'per_host' : False, 'aggregate' : True})
    assert result == {'changed' : False, 'ansible_stats' : data}


# Generated at 2022-06-25 07:42:57.995007
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test the constructor of class ActionModule
    action_module_0 = ActionModule()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:43:06.077083
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    action_module_0 = ActionModule()
    result = action_module_0.run(tmp, task_vars)
    assert(result == 'ActionModule')


if __name__ == "__main__":
    test_file = os.path.splitext(os.path.basename(__file__))[0]
    logfile = './test_' + test_file + '.log'
    with open(logfile, 'w') as fp:
        runner = unittest.TextTestRunner(stream=fp, verbosity=2)
        unittest.main(testRunner=runner)
    sys.exit(not result.wasSuccessful())

# Generated at 2022-06-25 07:43:07.315520
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-25 07:43:14.476971
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_module_1 = ActionModule()
    assert 'ActionModule' == action_module_1.__class__.__name__
    assert 'action_plugin.py'   == action_module_1.__module__
    assert action_module_1._task is None
    assert action_module_1._play_context is None
    assert action_module_1._loader is None
    assert action_module_1._templar is None
    assert action_module_1._shared_loader_obj is None
    assert action_module_1._connection is None
    assert action_module_1._play is None
    assert action_module_1._clear_loaders is None
    assert action_module_1._task_vars is None
    assert action_module_1._iterator is None
    assert action_module_1._last_task_

# Generated at 2022-06-25 07:43:18.656719
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock class object of class ActionModule and assign a return value of run method.
    action_module_mock = ActionModule()
    action_module_mock.run.return_value = dict(changed=False, msg='')
    # Test case for ActionModule run method
    assert isinstance(action_module_mock.run(), dict)

# Generated at 2022-06-25 07:43:25.608149
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    tmp = "/tmp/test"

# Generated at 2022-06-25 07:43:29.951831
# Unit test for constructor of class ActionModule
def test_ActionModule():

  # create object of the class ActionModule
  action_module = ActionModule()

  # check if the object is an instance of the class ActionModule
  assert isinstance(action_module, ActionModule)

# Generated at 2022-06-25 07:43:31.174332
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert action_module_0 != None

# Generated at 2022-06-25 07:43:42.522835
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:43:44.901001
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  action_module_1 = ActionModule()
  tmp = None
  task_vars = None
  action_module_1.run(tmp, task_vars)

# Generated at 2022-06-25 07:43:46.025834
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 1 == 1

# Generated at 2022-06-25 07:43:46.762547
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:43:49.278198
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert_equals(ActionModule._VALID_ARGS,frozenset(('aggregate', 'data', 'per_host')))
    assert_equals(ActionModule.TRANSFERS_FILES,False)

# Generated at 2022-06-25 07:43:54.621041
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.run()

# Generated at 2022-06-25 07:43:58.366750
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert not hasattr(action_module_0, 'run')
    assert action_module_0.TRANSFERS_FILES == False
    assert action_module_0._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))


# Generated at 2022-06-25 07:43:59.146889
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True == True



# Generated at 2022-06-25 07:44:04.706441
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Instantiate class

    arguments_1 = {'data': {'a': 5, 'b': 3}, 'per_host': False, 'aggregate': True}

    action_module_1 = ActionModule(module_name='module_name_0', module_args=arguments_1, task_vars='task_vars_0', tmp='tmp_0')

    result = action_module_1.run()

    assert result == {'changed': False, 'ansible_stats': {'data': {'a': 5, 'b': 3}, 'per_host': False, 'aggregate': True}}

    # run() method


# Generated at 2022-06-25 07:44:10.359459
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    # TODO: Implement test_ActionModule_run
    assert action_module_0

# NOTE: Now that we have all the unit tests for all methods of class ActionModule,
#       we could go ahead and implement unit test for class ActionModule itself.
#       But that would be an overkill.
#
#       The only thing the class ActionModule does is to set the attributes, so we
#       shall simply call test_case_0() that tries to instantiate an object of class
#       ActionModule.
if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:44:29.522213
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'a'
    str_1 = 'A'
    dict_0 = {str_1: str_0}
    str_2 = 'a'
    str_3 = 'a'
    str_4 = 'a'
    dict_1 = {str_2: str_0, str_3: str_4}
    set_0 = {str_3, str_3, str_3}
    action_module_0 = ActionModule(set_0, str_2, dict_1, str_2, str_0, dict_0)
    assert action_module_0.run() == 0


# Generated at 2022-06-25 07:44:34.830113
# Unit test for constructor of class ActionModule
def test_ActionModule():
  set_0 = set()
  str_0 = get_random_string(7, 15)
  dict_0 = {}
  str_1 = get_random_string(7, 15)
  str_2 = get_random_string(7, 15)
  set_1 = set()
  action_module_0 = ActionModule(set_0, str_0, dict_0, str_1, str_2, set_1)
  assert isinstance(action_module_0, ActionModule)

# Generated at 2022-06-25 07:44:39.262648
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_1 = 'P3\rD'
    list_0 = [str_1]
    str_0 = ''
    dict_0 = {}
    action_module_0 = ActionModule(list_0, str_0, dict_0, str_1, str_0, list_0)
    assert action_module_0 != None

# Generated at 2022-06-25 07:44:47.782888
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = ']#nk; JvY"z0\\'
    set_0 = {str_0, str_0, str_0}
    str_1 = 'P3\rD'
    dict_0 = {str_1: set_0, str_0: str_0}
    str_2 = ''
    action_module_0 = ActionModule(set_0, str_1, dict_0, str_2, str_1, set_0)
    assert isinstance(action_module_0, ActionModule)
    action_module_0.run()


# Generated at 2022-06-25 07:44:54.673663
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_run()
    set_0 = {'\uF4C4x\u43c9', '\uF4C4x\u43c9', '\uF4C4x\u43c9'}
    str_0 = '\uF4C4x\u43c9'
    dict_0 = {str_0: set_0, str_0: str_0}
    str_1 = '\uF4C4x\u43c9'
    action_module_0 = ActionModule(set_0, str_1, dict_0, str_1, str_0, set_0)


# Generated at 2022-06-25 07:44:55.735097
# Unit test for constructor of class ActionModule
def test_ActionModule():
	pass


# Generated at 2022-06-25 07:44:58.070769
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    assert type(ActionModule.run(tmp, task_vars)) == dict

# Generated at 2022-06-25 07:45:03.780923
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = ']'
    set_0 = {str_0}
    str_1 = '['
    dict_0 = {str_1: set_0, str_0: str_0}
    str_2 = '}'
    action_module_0 = ActionModule(set_0, str_1, dict_0, str_2, str_1, set_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:45:09.145828
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    str_0 = ''
    dict_0 = {str_0: str_0}
    str_1 = '{"'
    action_module_0 = ActionModule(dict_0, str_0, dict_0, str_0, str_1, dict_0)

# Generated at 2022-06-25 07:45:16.251216
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'z(Y'
    dict_0 = {str_0: str_0, '\x15': str_0, str_0: set()}
    set_0 = {str_0, str_0, '*T'}
    str_1 = '.\x0b'
    action_module_0 = ActionModule(set_0, str_0, dict_0, str_0, str_1, set_0)
    del action_module_0
    str_2 = '7'
    set_1 = {str_2, 'cH', str_0}
    dict_1 = {str_0: dict(), str_0: set()}
    str_3 = 'D'

# Generated at 2022-06-25 07:45:46.382196
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = ']#nk; JvY"z0\\'
    set_0 = {str_0, str_0, str_0}
    str_1 = 'P3\rD'
    dict_0 = {str_1: set_0, str_0: str_0}
    str_2 = ''
    action_module_0 = ActionModule(set_0, str_1, dict_0, str_2, str_1, set_0)
    dict_1 = {}
    str_3 = 'h"*dJ'
    dict_2 = {str_3: dict_0, str_1: dict_0}
    dict_3 = {str_3: dict_0, str_1: dict_1}
    str_4 = 'aggregate'
    # Backup the value of

# Generated at 2022-06-25 07:45:56.453447
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = ']#nk; JvY"z0\\'
    set_0 = {str_0, str_0, str_0}
    str_1 = 'P3\rD'
    dict_0 = {str_1: set_0, str_0: str_0}
    str_2 = ''
    action_module_0 = ActionModule(set_0, str_1, dict_0, str_2, str_1, set_0)
    action_module_0.run()
    str_3 = '\\'
    dict_1 = {}
    dict_2 = {str_3: dict_0, str_0: dict_1}
    dict_1[str_1] = dict_2
    action_module_0.run(dict_1)

# Generated at 2022-06-25 07:46:01.118623
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    global action_module_0
    # global var_0
    result = action_module_0.run(False, {'hi': 'there'})
    assert result[''] == False
    assert result[''] == False
    assert result['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True}

test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 07:46:09.341393
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    # Run the method and validate the results
    set_0 = {'\n3q', '\n3q', '\n3q'}
    str_0 = '-1='
    dict_0 = {str_0: set_0, 'dFD\x0c': 'L-XeU'}
    str_1 = '`'
    str_2 = 'f/b'
    action_module_0 = ActionModule(set_0, str_0, dict_0, str_1, str_0, set_0)
    result = action_module_0.run(tmp, task_vars)
    assert isinstance(result, dict)
    assert result['msg'] == "The 'data' option needs to be a dictionary/hash"
    assert result

# Generated at 2022-06-25 07:46:14.251378
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # str_0 = ']#nk; JvY"z0\\'
    # set_0 = {str_0, str_0, str_0}
    # str_1 = 'P3\rD'
    # dict_0 = {str_1: set_0, str_0: str_0}
    # str_2 = ''
    # action_module_0 = ActionModule(set_0, str_1, dict_0, str_2, str_1, set_0)
    assert True


# Generated at 2022-06-25 07:46:16.048251
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print(ActionModule.run())

if __name__ == "__main__":
    if test_ActionModule_run() == '__main__':
        test_case_0()

# Generated at 2022-06-25 07:46:18.873616
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_2 = ActionModule(set_0, str_1, dict_0, str_2, str_1, set_0)
    assert_equal(action_module_2.run(), set_0)


# Generated at 2022-06-25 07:46:23.369830
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    action_module_0 = ActionModule(tmp, task_vars)
    tmp = None
    assert action_module_0.run(tmp, task_vars) == None

# Generated at 2022-06-25 07:46:32.777059
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'ld_'
    int_0 = 4
    str_1 = 'BUDC#=I\n<Rx'
    float_0 = float()
    bytes_0 = b"'W\xff\xd4\x14\xcb\xae\xe1\x1c\xeda\x07@\x13Z\x11\xf9\x90\xbd\x7f\x1a?\x1f\xaeh\x95\x9f\xf9\xa1\x95\xcf\xd0\x93\xa5\x03"
    dict_1 = {str_0: int_0, str_1: float_0}
    dict_2 = {str_0: bytes_0}
    dict_3 = dict()

# Generated at 2022-06-25 07:46:37.112574
# Unit test for constructor of class ActionModule
def test_ActionModule():
    u'This is a unit test for constructor of class ActionModule'
    set_0 = set()
    str_0 = '-'
    dict_0 = {str_0: set_0}
    str_1 = 'min'
    action_module_0 = ActionModule(set_0, str_1, dict_0, str_0, str_1, set_0)
    var_0 = action_run()
    if set_1 == {str_1}:
        return True
    else:
        return False


# Generated at 2022-06-25 07:47:18.635554
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-25 07:47:29.489761
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Modify function to return values that came from method run of class ActionModule
    action_module_0 = ActionModule()
    str_0 = ']#nk; JvY"z0\\'
    set_0 = {str_0, str_0, str_0}
    str_1 = 'P3\rD'
    dict_0 = {str_1: set_0, str_0: str_0}
    str_2 = ''
    action_module_1 = ActionModule(set_0, str_1, dict_0, str_2, str_1, set_0)
    action_run(action_module_1)
    return

test_case_0()
print('Unit test for method run of class ActionModule')
test_ActionModule_run()

# Generated at 2022-06-25 07:47:34.659756
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = ']#nk; JvY"z0\\'
    set_0 = {str_0, str_0, str_0}
    str_1 = 'P3\rD'
    dict_0 = {str_1: set_0, str_0: str_0}
    str_2 = ''
    action_module_0 = ActionModule(set_0, str_1, dict_0, str_2, str_1, set_0)
    assert action_module_0 != None


# Generated at 2022-06-25 07:47:36.582005
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    action_module_run_0 = ActionModule(tmp, task_vars)


# Generated at 2022-06-25 07:47:40.838886
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Not sure how to test this, since it is not a standalone module
    pass




# Generated at 2022-06-25 07:47:42.422909
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(set(['']), '', dict(), '', '', set([]))



# Generated at 2022-06-25 07:47:45.730402
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # code
    return None


# Generated at 2022-06-25 07:47:52.903796
# Unit test for constructor of class ActionModule
def test_ActionModule():
    l_0 = List([102, 53, 41, 111])
    l_1 = "^!mZlC'I"
    d_0 = {"%c`P7[": l_0, l_1: l_1}
    l_2 = ""
    l_3 = "o$U6y"
    l_4 = Set([l_0, l_1, l_3])
    l_5 = "y[-hF"
    action_module_0 = ActionModule(l_4, l_3, d_0, l_2, l_5, l_4)

# Generated at 2022-06-25 07:47:58.222653
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_1 = 'Mn\x7fWn;v'
    dict_0 = {str_1: str_1, str_1: str_1}
    str_2 = ''
    dict_2 = {str_2: dict_0, str_1: dict_0}
    set_0 = {dict_2, str_2, dict_2}
    str_3 = '='
    action_module_0 = ActionModule(set_0, str_2, dict_0, str_1, str_2, set_0)
    dict_7 = {str_1: dict_0, str_1: dict_0}
    dict_6 = {str_2: str_2, str_3: set_0}

# Generated at 2022-06-25 07:48:03.673211
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = ']#nk; JvY"z0\\'
    set_0 = {str_0, str_0, str_0}
    str_1 = 'P3\rD'
    dict_0 = {str_1: set_0, str_0: str_0}
    str_2 = ''
    action_module_0 = ActionModule(set_0, str_1, dict_0, str_2, str_1, set_0)
    action_module_0 = ActionModule(set_0, str_1, dict_0, str_2, str_1, set_0)
    action_module_0 = ActionModule(set_0, str_1, dict_0, str_2, str_1, set_0)

# Generated at 2022-06-25 07:49:50.872666
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass_0 = 'f\"0\x0e!0'
    str_0 = 'Z.n}"5\x0c'
    pass_1 = '!@\n\n"'
    str_1 = 'Z.n}"5\x0c'
    str_2 = 'Z.n}"5\x0c'
    pass_2 = '!@\n\n"'
    str_3 = 'Z.n}"5\x0c'
    str_5 = 'Z.n}"5\x0c'
    str_6 = 'Z.n}"5\x0c'
    str_7 = 'Z.n}"5\x0c'
    str_8 = 'Z.n}"5\x0c'
    str_9 = 'Z.n}"5\x0c'
   

# Generated at 2022-06-25 07:50:00.666437
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = {'`', 'q', '`', '`'}
    str_0 = 'q'
    dict_0 = {str_0: set_0, str_0: str_0}
    str_1 = ''
    action_module_0 = ActionModule(set_0, str_0, dict_0, str_0, str_1, set_0)
    str_2 = '8W"^t'
    dict_1 = {str_1: str_1}
    str_3 = '9]a'
    dict_2 = {'per_host': False, 'data': dict_0, 'aggregate': False}
    var_0 = action_module_0._merge_kv(str_0, dict_1)

# Generated at 2022-06-25 07:50:07.316678
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = ']#nk; JvY"z0\\'
    set_0 = {str_0, str_0, str_0}
    str_1 = 'P3\rD'
    dict_0 = {str_1: set_0, str_0: str_0}
    str_2 = ''
    str_3 = 'P3\rD'
    set_1 = {str_0, str_0, str_0}
    action_module_0 = ActionModule(set_0, str_3, dict_0, str_2, str_1, set_1)
    if not isinstance(action_module_0, ActionModule):
        print("Failed: Constructor of class ActionModule")
    else:
        print("Success: Constructor of class ActionModule")

# Generated at 2022-06-25 07:50:15.453697
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # self, runner_queue, connection, play_context, loader, templar, shared_loader_obj
    str_0 = 'jZ'
    str_1 = 'P3\rD'
    str_2 = 'w'
    set_0 = {str_1, str_1, str_0, str_0, str_0, str_0, str_0, str_1, str_0, str_0, str_1, str_2, str_0, str_2, str_0, str_2, str_2, str_1, str_1, str_0, str_1, str_0, str_1, str_1}
    dict_0 = {str_2: set_0, str_0: str_0}
    str_3 = ''
    str_4 = ''
   

# Generated at 2022-06-25 07:50:22.793896
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = {"+XC=l'vfB2x$'#"}
    str_0 = 'vZ(t.>|:p'
    dict_0 = {"y; qV" : "n!Z!'43w{5'5}", '7%u2)1': set_0, str_0: set_0, "3PZ#w" : set_0}
    str_1 = 'y:\'9.E(aR;&*z'
    str_2 = 's^:<>T'
    var_0 = ActionModule(set_0, str_0, dict_0, str_1, str_2, set_0)

# Generated at 2022-06-25 07:50:28.788565
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = ''
    set_0 = {str_0, str_0, str_0, str_0}
    str_1 = ''
    dict_0 = {str_0: set_0, str_1: str_0, str_0: str_1, str_1: str_0}
    str_2 = ''
    action_module_0 = ActionModule(set(), str_1, dict_0, str_0, str_1, set_0)



# Generated at 2022-06-25 07:50:38.668325
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '._,n:_e]$'
    set_0 = {str_0, str_0, str_0}
    str_1 = 'P3\rD'
    dict_0 = {str_1: set_0, str_0: str_0}
    str_2 = ''
    action_module_0 = ActionModule(set_0, str_1, dict_0, str_2, str_1, set_0)
    str_3 = ''
    assert action_module_0.run(str_3) == {'failed': True, 'msg': 'The \x27data\x27 option needs to be a dictionary/hash'}
test_ActionModule()

# Generated at 2022-06-25 07:50:48.510828
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:50:58.159095
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'v0t?M'
    set_0 = {str_0, str_0, str_0}
    str_1 = '_<'
    dict_0 = {str_0: set_0, str_1: str_0}
    str_2 = '-?G<oH'
    action_module_0 = ActionModule(set_0, str_1, dict_0, str_0, str_1, set_0)
    var_0 = action_run()

if __name__ == '__main__':
    str_0 = 'f#e'
    set_0 = {str_0, str_0, str_0}
    str_1 = 'm\\6'
    dict_0 = {str_0: set_0, str_1: str_0}

# Generated at 2022-06-25 07:51:04.692766
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'p.y'
    set_0 = {str_0}
    str_1 = '$'
    str_2 = 'f'
    str_3 = 'X-['
    str_4 = 'h%c'
    dict_0 = {str_4: str_4, str_3: str_4, str_1: str_0, str_2: str_4}
    str_5 = 'o-}'
    str_6 = 'N'
    str_7 = '==0'
    action_module_0 = ActionModule(str_0, set_0, dict_0, str_7, str_2, str_7)
    var_0 = action_run(str_1, str_4)
