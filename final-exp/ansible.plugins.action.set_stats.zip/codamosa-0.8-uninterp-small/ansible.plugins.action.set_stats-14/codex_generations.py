

# Generated at 2022-06-25 07:41:47.829845
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {}
    tmp = None

    action_module_0 = ActionModule(None, None, None, None, None, None)

    result = action_module_0.run(tmp, task_vars)
    assert result['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True}

    task_vars = {}
    tmp = None

    action_module_0 = ActionModule(None, None, None, None, None, None)

    result = action_module_0.run(tmp, task_vars)
    assert result['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True}

    task_vars = {}
    tmp = None


# Generated at 2022-06-25 07:41:54.951529
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_1 = False
    list_1 = []
    str_1 = '9hTgT-?|m'
    bool_2 = False
    bytes_1 = b'\xd4\x87\x83\xb1\xfd\xb8\x87\xd7\x96\xa3\x8b\x99\x9b\x9b\x8e\x92'
    str_2 = '`'
    bool_1 = bool_1
    list_1 = list_1
    str_1 = str_1
    bool_2 = bool_2
    bytes_1 = bytes_1
    str_2 = str_2
    test_case_0(bool_1, list_1, str_1, bool_2, bytes_1, str_2)


# Generated at 2022-06-25 07:42:01.755505
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None
    bool_0 = True
    list_0 = []
    bytes_0 = b'\x85\x17\x9e\x00\xdd\xdf\x83\xf6'
    str_0 = 'Em(<i*)Y(|n5| '
    action_module_0 = ActionModule(bool_0, list_0, str_0, bool_0, bytes_0, str_0)
    action_module_0.action = None
    action_module_0.action_loader = None
    action_module_0._display = None
    action_module_0._task = None
    action_module_0._shared_loader_obj = None
    action_module_0._config_module = None
    action_module_0._module_cache

# Generated at 2022-06-25 07:42:09.298361
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_1 = False
    list_1 = []
    bytes_1 = b'\xaa\xec\x15\x10\x88\x9b\x8a\xab'
    str_1 = 'eB8+\x7f\xee#Z\x0f\x17\x04\x1e'
    str_2 = 'U6}x\x0c\\\x19\x1a\x1c\x00\x13\x00\x1d\x06\x1f\n/\x16\x1b\x7f\n\x13\x1b\t\r\t\x1f\x05'
    bool_2 = True
    bool_3 = False

# Generated at 2022-06-25 07:42:09.981602
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:42:15.922539
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    list_0 = []
    bytes_0 = b'\xa9\x9e\x16\x8e\x17\x19\xf4\x87'
    str_0 = '+LCnS[H'
    bool_1 = True
    action_module_0 = ActionModule(bool_0, list_0, str_0, bool_1, bytes_0, str_0)


# Generated at 2022-06-25 07:42:26.260169
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    list_0 = []
    str_0 = '\x00\n\x00\x02\x00\x05\x00\x07'
    bool_1 = False
    bytes_0 = b'\xad\x88\xc1\xd7V\xc6'
    str_1 = '\x00\n\x00\x04\x00\x06'
    action_module_0 = ActionModule(bool_0, list_0, str_0, bool_1, bytes_0, str_1)
    result = action_module_0.run()
    print(result)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:42:34.223603
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    list_0 = ['\rq', 'xHuLc%9X', '', '\x83']
    bytes_0 = b'^\x18\x05\x8b\x88\xd4\xbf\xb3\xb2'
    str_0 = 'V\xed\x12'
    bool_1 = True
    bytes_1 = b'\x01\xf2\xbe\n\xbe\xbc\xde\x17\x93'
    str_1 = '6'
    action_module_0 = ActionModule(bool_0, list_0, str_0, bool_1, bytes_1, str_1)
    action_module_0.run()


# Generated at 2022-06-25 07:42:34.963042
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:42:42.315178
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    list_0 = []
    bytes_0 = b'\x85\x17\x9e\x00\xdd\xdf\x83\xf6'
    str_0 = 'Em(<i*)Y(|n5| '
    action_module_0 = ActionModule(bool_0, list_0, str_0, bool_0, bytes_0, str_0)
    action_module_0.run()


# Generated at 2022-06-25 07:42:50.620946
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = dict()

# Generated at 2022-06-25 07:43:00.870869
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    bool_0 = True
    bytes_0 = b'\x81\x9e\x07\x92\x93\xb5\xf1\x83'
    str_0 = 'hqo-?xM\x0e'
    action_module_0.set_task(bool_0, str_0, str_0, str_0, str_0, bytes_0, str_0)
    bytes_1 = b'\xed\x9e\x0e\x8f\x93\xa3\xfe\x85'
    str_1 = 'R;XeI\x0b'
    assertion_failed = False

# Generated at 2022-06-25 07:43:09.537902
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    bytes_0 = b'\x98\xad\x8e\xa2\x17\xc7\x1f\x9e\x14\xab\x91\x97\xb8\xba\xd3\xbd\xcc\x8b\xf3\x97\xad\x87\xdd\xcc\xd7\x93'

# Generated at 2022-06-25 07:43:19.024414
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    bytes_0 = b'\xa9\x9e\x16\x8e\x17\x19\xf4\x87'
    str_0 = 'O`\x19\x93\x84+\xf6\x03\xadp\xbb\xad\x9a\x00\xf7\xcf\xd0^\x8c\x15\x13'
    action_module_0 = ActionModule(bool_0, bool_0, str_0, bool_0, bytes_0, str_0)

# Generated at 2022-06-25 07:43:19.893962
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:43:22.447625
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except AssertionError:
        print('Test case 0 failed.')


# Generated at 2022-06-25 07:43:23.212236
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:43:24.173964
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 07:43:31.119169
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    bool_1 = False
    bytes_0 = b'\xa9\x9e\x16\x8e\x17\x19\xf4\x87'
    str_0 = '+CnSH'
    action_module_0 = ActionModule(bool_0, bool_0, str_0, bool_0, bytes_0, str_0)
    tmp = dict()
    task_vars = dict()
    try:
        action_module_0.run(tmp, task_vars)
        raise RuntimeError()
    except Exception:
        pass
    else:
        raise RuntimeError()
    try:
        action_module_0.run(tmp, task_vars)
        raise RuntimeError()
    except Exception:
        pass
    else:
        raise RuntimeError

# Generated at 2022-06-25 07:43:32.104442
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:43:42.272257
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Method to test presence of asserts in test case

# Generated at 2022-06-25 07:43:45.024711
# Unit test for constructor of class ActionModule
def test_ActionModule():
    t = ActionModule()
    assert t.TRANSFERS_FILES == False
    assert t._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))


# Generated at 2022-06-25 07:43:53.691331
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args = {
        'aggregate': False,
        'data': {
            'ansible_debug_var': {
                'foo': 'bar',
                'count': 1,
            }
        },
        'per_host': False,
    }

    action_module = ActionModule(task=dict(action=dict(module='set_stats', args=args)))
    action_module._task.action = 'set_stats'
    result = action_module.run(tmp=None, task_vars=None)

# Generated at 2022-06-25 07:44:01.554184
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_name = 'module_name'

    action = ActionModule(task=Test_ActionBase_task(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action._task.args = {'arg1':'val1', 'arg2':'val2'}
    action._task.action = 'action_name'
    action._task.action_name = 'action_name'
    action._task.module_name = module_name
    action._task.module_vars = {'modvar1': 'val1', 'modvar2': 'val2'}
    action._task.no_log = False
    action._task.notify = []
    action._task.tags = []
    action._task.when = []

    # Check returns/values of

# Generated at 2022-06-25 07:44:11.123886
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Add tests for the per_host=False and aggregate=False case
    # TODO: Add non-trivial data value tests
    # TODO: Add tests that should cause errors
    # TODO: Add tests that should cause warnings

    # BEGIN TESTS

    # Test 1: Using the set_stats module to set a single value
    # --------------------------------------------------------
    data = dict()
    data['ansible_stats'] = dict()
    data['ansible_stats']['aggregate'] = True
    data['ansible_stats']['data'] = dict()
    data['ansible_stats']['per_host'] = False
    data['ansible_stats']['data']['testvar'] = True

    data1 = dict()
    data1['ansible_stats'] = dict()
    data1

# Generated at 2022-06-25 07:44:13.559886
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert type(ActionModule()) == ActionModule


# Generated at 2022-06-25 07:44:16.161772
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    tmp = ""
    task_vars = None
    result = action_module.run(tmp, task_vars)
    assert result['ansible_stats'] == {'per_host': False, 'data': {}, 'aggregate': True}


# Generated at 2022-06-25 07:44:21.098793
# Unit test for constructor of class ActionModule
def test_ActionModule():
    default_0 = '\x86\xf1\x9b\xb2\x9f\xac\xc8\x83\x98\xcf\xa9\x04\x9a\xaa\xa5\x96\xa5\xdd\xaa\x83\xdc\xd2\xdb\xcf\xd1\xb1\xab\xbd\xbd\xca\xcb\x9d\x9e\x9e\x99\xd3\x93'


# Generated at 2022-06-25 07:44:30.672571
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    bytes_0 = b'\x98\xad\x8e\xa2\x17\xc7\x1f\x9e\x14\xab\x91\x97\xb8\xba\xd3\xbd\xcc\x8b\xf3\x97\xad\x87\xdd\xcc\xd7\x93'
    float_0 = 6.548258008555671
    float_1 = 2.64805414642338e-09
    float_2 = 8.091752116679073e-06
    float_3 = 0.09024989484028684
    float_4 = 6.717517215520503
    int_0 = 899
    int_1 = 102
    int_2 = 12

# Generated at 2022-06-25 07:44:35.870254
# Unit test for constructor of class ActionModule
def test_ActionModule():
  d = {'msg': None,'invocation': None,'failed': None,'warnings': ['DEPRECATED_MSG: Configuration for module_setup has been deprecated in favor of using include_role/include_tasks so we will end up loading it from the action plugin directory instead.  This feature will be removed in a future release.  Please consult the documentation for more details.'],'skipped': None,'changed': None,'deprecations': None}
  task_var = dict()
  actionmodule = ActionModule(d, task_var)
  assert actionmodule != None


# Generated at 2022-06-25 07:44:48.352847
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(
        task=dict(args=dict(per_host=True)),
        connection=dict(class_name='Connection', module_name='paramiko_ssh'),
        task_vars={}
    )

    action_module.run()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:44:51.512697
# Unit test for constructor of class ActionModule
def test_ActionModule():
    act_mod = ActionModule()


# Generated at 2022-06-25 07:44:54.415708
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert isinstance(action, ActionModule)



# Generated at 2022-06-25 07:44:56.383752
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()
    assert action_module_1 is not None


# Generated at 2022-06-25 07:45:06.097456
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    num_0 = 0
    str_1 = '\x86ñ\x9b²\x9f¬È\x83\x98Ï©\x04\x9aª¥\x96¥Ýª\x83ÜÒÛÏÑ±«½½ÊË\x9d\x9e\x9e\x99Ó\x93'
    str_2 = '\x86ñ\x9b²\x9f¬È\x83\x98Ï©\x04\x9aª¥\x96¥Ýª\x83ÜÒÛÏÑ±«½½ÊË\x9d\x9e\x9e\x99Ó\x93'
    dict_0

# Generated at 2022-06-25 07:45:13.855460
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:45:19.689831
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    # Call method run with args
    str_0 = 'õ\x83\x9d\x80\x9aà\x9eêª\x8f\x89\x81\x84\x9e\x04\x9fù\x99\x83'
    action.run(task_vars=dict(tmp=str_0))

# Generated at 2022-06-25 07:45:25.317815
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module.TRANSFERS_FILES == False
    assert action_module._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))


# Generated at 2022-06-25 07:45:26.389234
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:45:36.026061
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj_0 = ActionModule(0, 1, {})
    obj_0.templar = Templar(0, int_0, {}, 0)
    obj_0.run(int_0, 0)
    str_0 = '«½ÊËÓ\x93'
    int_0 = obj_0.loop
    int_1 = obj_0.connection
    obj_0.HOST_KEY_CHECKING = True
    str_1 = str_0[:-1]
    str_2 = str_1[::-1]

# Generated at 2022-06-25 07:45:44.432625
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj_0 = ActionModule()
    assert obj_0 is not None


# Generated at 2022-06-25 07:45:45.027601
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule()


# Generated at 2022-06-25 07:45:51.489220
# Unit test for constructor of class ActionModule
def test_ActionModule():
    cls_1 = {}
    cls_2 = {}
    cls_3 = Data()
    cls_3.set_content(str_0)
    cls_3.set_key(b'\x03\n\x00\x00\x01', 32, 16)

# Generated at 2022-06-25 07:45:59.665142
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with valid inputs
    # mock = MagicMock()
    tmp = None
    task_vars = None
    obj = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert(obj != None)

    # Test with no inputs
    try:
        obj = ActionModule()
    except Exception as e:
        assert(e.args[0] == "missing required argument: task")



# Generated at 2022-06-25 07:46:06.804765
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Unit test for constructor of class ActionModule')
    str_0 = '\x86ñ\x9b²\x9f¬È\x83\x98Ï©\x04\x9aª¥\x96¥Ýª\x83ÜÒÛÏÑ±«½½ÊË\x9d\x9e\x9e\x99Ó\x93'
    obj_0 = ActionModule()


# Generated at 2022-06-25 07:46:09.290239
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_obj =  ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    return action_module_obj


# Generated at 2022-06-25 07:46:10.056658
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert callable(ActionModule)


# Generated at 2022-06-25 07:46:14.406597
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action = ActionModule()

    result = action.run(tmp='tmp', task_vars='task_vars')

    assert result['changed'] == False
    assert result['msg'] == None
    assert result['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True}

# Generated at 2022-06-25 07:46:15.139297
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-25 07:46:25.062193
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    params = {}
    obj = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    ret_obj = obj.run(tmp=None, task_vars=None)
    assert str(type(ret_obj)) == "<type 'dict'>"
    assert 'ansible_stats' in ret_obj
    assert not ret_obj['changed']
    #assert ret_obj['ansible_facts']['data'] == {}
    assert ret_obj['ansible_stats']['per_host'] == False
    assert ret_obj['ansible_stats']['aggregate'] == True
    assert 'failed' not in ret_obj['ansible_facts']
    #assert 'msg' not in ret_obj['ansible_facts']



# Generated at 2022-06-25 07:46:39.516881
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    list_0 = []
    str_0 = '-c`-\x1c\x83 '
    bool_1 = True
    bytes_0 = b'\x99\x05ZB\xb0\x88\xfc'
    bytes_1 = b'\x83\xa2\xfc\xd9\x00S'
    action_module_0 = ActionModule(bool_0, list_0, str_0, bool_0, bytes_0, bytes_1)
    var_0 = action_run(action_module_0, str_0, list_0)

# Generated at 2022-06-25 07:46:42.024078
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Get required parameters from action
    task_vars = None

    # Initlize the class
    action_module = ActionModule()

    # Call action run method
    result = action_module.run(task_vars)

# Generated at 2022-06-25 07:46:42.998945
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:46:53.222491
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {'Dk1\x00\x00\x00\x00\x00': 'M"\\e}N3Yr\\i2\x7f\x1fR\x0c\x1b', '0\x02s]\x04': 'e_\x7f\x17\x1c\x1a\x1c\x1d\x83\x96\x1d', "T|14\x001\x1c": '\x1a\x1b\x1b\x9e\x94\x1c\x1a\x1c', '\x00\x00\x00\x00\x00\x00\x00\x00': '\x0c\x1b'}

# Generated at 2022-06-25 07:46:58.310410
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    list_0 = []
    bytes_0 = b'~\xea\xbd\x90\t\x18\xd4\x1bS\x0b'
    str_0 = '1j^[\x80R'
    action_module_0 = ActionModule(bool_0, list_0, str_0, bool_0, bytes_0, str_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:46:59.249395
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:47:04.725893
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    list_0 = []
    bytes_0 = b'\xf9\x98\x95\xbf'
    str_0 = 'y$\xab'
    action_module_0 = ActionModule(bool_0, list_0, str_0, bool_0, bytes_0, str_0)
    bytes_1 = b'\xce\x8bN\xf7\xcc\xa7\x13'
    var_0 = action_run(bytes_1, list_0)
    print(var_0)

# Generated at 2022-06-25 07:47:05.825939
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 07:47:08.484911
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    list_0 = []
    action_module_0 = ActionModule(bool_0, list_0)


# Generated at 2022-06-25 07:47:11.030985
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass


# Generated at 2022-06-25 07:47:32.753642
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Declare arguments for the constructor
    bool_0 = True
    list_0 = []
    str_0 = 'E=Rl'
    bool_1 = True
    bytes_0 = b'\x85\x17\x9e\x00\xdd\xdf\x83\xf6'
    str_1 = 'em+lU'
    action_module_0 = ActionModule(bool_0, list_0, str_0, bool_1, bytes_0, str_1)
    # Make condition to check the constructor is working correctly or not.
    if action_module_0()==false:
        print("constructor is working correctly")
    else:
        print("constructor is not working correctly")


# Generated at 2022-06-25 07:47:38.042080
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class MockActionOptions:

        def __init__(self, data=None, per_host=None, aggregate=None):
            self.data = data
            self.per_host = per_host
            self.aggregate = aggregate

    class MockTemplar:

        def template(self, source, strict=False, convert_bare=False, fail_on_undefined=True):
            return source

    class MockTask:

        def __init__(self, args=None):
            self.args = args

    # TODO: Add correct values for these variables
    task_vars = {'temp_var': 'value'}
    tmp = {'temp_tmp': 'value'}

    _task = MockTask(args=MockActionOptions())

    _templar = MockTemplar()

    action_module = ActionModule

# Generated at 2022-06-25 07:47:45.650459
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    arg0 = {}

    arg_dict = {}
    arg_dict["arg0"] = arg0

    with patch.multiple(ActionModule, run=mock.DEFAULT) as mocks:
        with patch.multiple(ActionBase, run=mock.DEFAULT) as mocks2:
            mocks["run"].return_value = True
            mocks2["run"].return_value = True
            result = ActionModule.run(arg_dict)
            assert result == True

            mocks["run"].assert_called_once_with(arg_dict)
            mocks2["run"].assert_called_once_with(arg_dict)

# Generated at 2022-06-25 07:47:52.417794
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Method run of class ActionModule
    # Unit test for run() function
    bool_0 = True
    list_0 = []
    bytes_0 = b'\x85\x17\x9e\x00\xdd\xdf\x83\xf6'
    str_0 = 'Em(<i*)Y(|n5| '
    action_module_0 = ActionModule(bool_0, list_0, str_0, bool_0, bytes_0, str_0)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 07:47:56.225723
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    list_0 = []
    bytes_0 = b'\x85\x17\x9e\x00\xdd\xdf\x83\xf6'
    str_0 = 'Em(<i*)Y(|n5| '
    action_module_0 = ActionModule(bool_0, list_0, str_0, bool_0, bytes_0, str_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:48:03.936081
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    list_0 = []
    bytes_0 = b'\x85\x17\x9e\x00\xdd\xdf\x83\xf6'
    str_0 = 'Em(<i*)Y(|n5| '
    action_module_0 = ActionModule(bool_0, list_0, str_0, bool_0, bytes_0, str_0)
    var_0 = action_run()
    if var_0:
        print('ERROR: action_run returned %r' % var_0)
    else:
        print('SUCCESS: action_run returned %r' % var_0)



# Generated at 2022-06-25 07:48:13.576953
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    list_0 = []
    bytes_0 = b'\x85\x17\x9e\x00\xdd\xdf\x83\xf6'
    str_0 = 'Em(<i*)Y(|n5| '
    action_module_0 = ActionModule(bool_0, list_0, str_0, bool_0, bytes_0, str_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:48:22.152669
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    list_0 = []
    bytes_0 = b'\x85\x17\x9e\x00\xdd\xdf\x83\xf6'
    str_0 = 'Em(<i*)Y(|n5| '
    action_module_0 = ActionModule(bool_0, list_0, str_0, bool_0, bytes_0, str_0)
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:48:24.573489
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # var_0 = AggregateDict()
    # var_1 = TaskExecutor()
    var_2 = ActionModule(aggregate=AggregateDict(), executor=TaskExecutor())
    del var_2


# Generated at 2022-06-25 07:48:25.548572
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:49:13.897626
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    list_0 = []
    bytes_0 = b'\x83\x0a\x85\x19\xc9\xd7\x90\xf1'
    str_0 = '&W(|vkc%+QKb9R'
    action_module_0 = ActionModule(bool_0, list_0, str_0, bool_0, bytes_0, str_0)
    assert action_module_0.action_name == 'set_stats'
    assert action_module_0.bypass_checks
    assert action_module_0.connection == 'local'
    assert action_module_0.delegate_to is None
    assert action_module_0.module_name == 'set_stats'
    assert action_module_0.no_log
    assert action_

# Generated at 2022-06-25 07:49:20.035762
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    list_0 = []
    bytes_0 = b'\x91'
    str_0 = 'X@u'
    action_module_1 = ActionModule(bool_0, list_0, str_0, bool_0, bytes_0, str_0)
    action_module_1.run()

# Generated at 2022-06-25 07:49:23.707447
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 07:49:24.989420
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Testing ActionModule::__init__()')
    test_case_0()



# Generated at 2022-06-25 07:49:33.870138
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    list_0 = []
    bytes_0 = b'\x85\x17\x9e\x00\xdd\xdf\x83\xf6'
    str_0 = 'Em(<i*)Y(|n5| '
    action_module_0 = ActionModule(bool_0, list_0, str_0, bool_0, bytes_0, str_0)
    assert isinstance(action_module_0, ActionModule)
    assert action_module_0.aggregate == True
    assert action_module_0.per_host == False
    assert action_module_0.data == {}
    assert action_module_0._connection._shell.DEFAULT_EXEC_ENV == 'c'


# Generated at 2022-06-25 07:49:41.898334
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    list_0 = []
    bytes_0 = b'\x85\x17\x9e\x00\xdd\xdf\x83\xf6'
    str_0 = 'Em(<i*)Y(|n5| '
    action_module_0 = ActionModule(bool_0, list_0, str_0, bool_0, bytes_0, str_0)
    var_0 = action_module_0.run(None, None)
    assert var_0.failed == False


# Generated at 2022-06-25 07:49:49.162460
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        if (((not not None) and ((((str is not None) and (not not None)) and (not not None)) and (not not None)))):
            assert (((not not None) and ((not not None) and (not not None))) is False)
        else:
            assert (not not None)
    except AssertionError as e:
        print('---------------FAILED-----------------')

# Generated at 2022-06-25 07:49:55.559410
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    list_0 = []
    bytes_0 = b'\x85\x17\x9e\x00\xdd\xdf\x83\xf6'
    str_0 = 'Em(<i*)Y(|n5| '
    action_module_0 = ActionModule(bool_0, list_0, str_0, bool_0, bytes_0, str_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:49:59.203792
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert type(action_module_0.run()) is dict


# Generated at 2022-06-25 07:50:05.504372
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    list_0 = []
    bytes_0 = b'\x85\x17\x9e\x00\xdd\xdf\x83\xf6'
    str_0 = 'Em(<i*)Y(|n5| '
    action_module_0 = ActionModule(bool_0, list_0, str_0, bool_0, bytes_0, str_0)
    if (len(action_module_0._task.args) == 0):
        print('\n')
    action_module_0.run()
    return 0

if (__name__ == '__main__'):
    print(test_ActionModule())

# Generated at 2022-06-25 07:51:31.706711
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    list_0 = []
    bytes_0 = b'\x85\x17\x9e\x00\xdd\xdf\x83\xf6'
    str_0 = 'Em(<i*)Y(|n5| '
    action_module_0 = ActionModule(bool_0, list_0, str_0, bool_0, bytes_0, str_0)