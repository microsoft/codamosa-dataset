

# Generated at 2022-06-25 07:41:39.855580
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        test_case_0()
    except NameError:
        assert False

# Generated at 2022-06-25 07:41:44.680440
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except(NameError, TypeError, ValueError):
        print('Failed test: test_case_0()')


# Generated at 2022-06-25 07:41:46.196425
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Instance of ActionModule
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:41:54.702821
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -74.1
    str_0 = 'd@z'
    str_1 = 'C'
    str_2 = '\u6268'
    str_3 = '\U000b5ee6'
    bytes_0 = b'\x13\xc4\x8f\x9d'
    bytes_1 = b'W8\x86'
    bytes_2 = b'\x3aP\x9c\xd4\x01\xa7'
    bytes_3 = b'b'
    int_0 = -79
    int_1 = -401
    int_2 = -320
    int_3 = -6627
    float_1 = -9.9
    float_2 = -76.3
    float_3 = -2.1

# Generated at 2022-06-25 07:41:58.487459
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_1 = -420.7
    bytes_1 = b'\xf9\xea^\x8a\xd0'
    dict_1 = {bytes_1: bytes_1}
    set_1 = {bytes_1, bytes_1, float_1}
    str_1 = 'Cr.lP<"Qa`VvG+Y'
    action_module_1 = ActionModule(float_1, dict_1, dict_1, set_1, dict_1, str_1)


# Generated at 2022-06-25 07:42:06.496294
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -420.7
    bytes_0 = b'\xf9\xea^\x8a\xd0'
    dict_0 = {bytes_0: bytes_0}
    set_0 = {bytes_0, bytes_0, float_0}
    str_0 = 'Cr.lP<"Qa`VvG+Y'
    action_module_0 = ActionModule(float_0, dict_0, dict_0, set_0, dict_0, str_0)

    action_module_0.run('Cr.lP<"Qa`VvG+Y', dict_0)

# Generated at 2022-06-25 07:42:11.204189
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -420.7
    bytes_0 = b'\xf9\xea^\x8a\xd0'
    dict_0 = {bytes_0: bytes_0}
    set_0 = {bytes_0, bytes_0, float_0}
    str_0 = 'Cr.lP<"Qa`VvG+Y'
    action_module_0 = ActionModule(float_0, dict_0, dict_0, set_0, dict_0, str_0)



# Generated at 2022-06-25 07:42:18.483237
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:42:27.146307
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -1.838336
    bytes_0 = b'\xc4\x9c\x9e\x7f\x93\x98\xb0'
    dict_0 = {bytes_0: bytes_0}
    set_0 = {float_0, float_0, float_0}
    str_0 = '@T2d\x9b\xed\x10\x1d\x8c'
    action_module_0 = ActionModule(float_0, dict_0, dict_0, set_0, dict_0, str_0)
    assert isinstance(action_module_0, ActionModule) is True # test if action_module_0 is instance of ActionModule

# Generated at 2022-06-25 07:42:34.429365
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = -434.088897566
    bytes_0 = b'\x93\x8fw\xdb\xb3\xbe'
    dict_0 = {bytes_0: bytes_0}
    set_0 = {bytes_0, bytes_0, float_0}
    str_0 = '2[\xba\xe9X\x03\xc7\xfe\xc1\x86\x18\xed\x9b'
    action_module_0 = ActionModule(float_0, dict_0, dict_0, set_0, dict_0, str_0)

    result = action_module_0.run()
    assert result == dict_0

# Generated at 2022-06-25 07:42:47.226709
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0, object)
    assert action_module_0.TRANSFERS_FILES is False
    assert action_module_0._VALID_ARGS is frozenset(('aggregate', 'data', 'per_host'))
    assert action_module_0.aliases == []
    assert action_module_0.always_run is False
    assert action_module_0.BYPASS_HOST_LOOP is True
    assert action_module_0.NO_TARGET_SYSLOG is False
    assert action_module_0.NO_TARGET_CHANGED is False
    assert action_module_0.BYPASS_HANDLER is False
    assert action_module_0.NO_LOG is False
    assert action_module_0.DE

# Generated at 2022-06-25 07:42:48.610433
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ansible_stats = {'aggregate': True, 'data': {}, 'per_host': False}
    # Test constructor
    assert ansible_stats == ActionModule._VALID_ARGS

# Generated at 2022-06-25 07:42:51.484298
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp = None
    task_vars = None
    action_module_0.run(tmp, task_vars)



# Generated at 2022-06-25 07:42:54.537754
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    res = action_module.run()
    assert res['ansible_stats']['data'] == {}, 'Failed to test case 0'

# Generated at 2022-06-25 07:42:56.586073
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write test cases
    #assert action_module_0.run( ) == "Test cases not implemented"
    pass

# Generated at 2022-06-25 07:43:05.772752
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_module_0 = ActionModule()
    assert isinstance(action_module_0, ActionModule)

    # Test exception for class instantiated with wrong arguments
    # TODO: write unit test for this exception
    # args = (action_module_0.__class__, 1, False)
    # self.assertRaisesRegexp(TypeError, "argument 1 must be an object, not int", *args)

    # Test exception for class instantiated without arguments
    # TODO: write unit test for this exception
    # args = (action_module_0.__class__, )
    # self.assertRaisesRegexp(TypeError, "__init__() missing 1 required positional argument: 'task'", *args)

    # Test exception for class instantiated with invalid arguments
    # TODO: write unit test for this exception
    # args

# Generated at 2022-06-25 07:43:07.509874
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()

if __name__ == '__main__':
    test_ActionModule()
    test_case_0()

# Generated at 2022-06-25 07:43:09.140487
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_1 = ActionModule()


# Generated at 2022-06-25 07:43:09.973578
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(test_case_0())

# Generated at 2022-06-25 07:43:11.036969
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:43:24.232581
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = " JFn'\rxj4h))M\r"
    float_0 = -3049.29
    bool_0 = False
    set_0 = {bool_0}
    list_0 = []
    float_1 = -4946.4
    str_1 = '53'
    action_module_0 = ActionModule(float_0, bool_0, set_0, list_0, float_1, str_1)
    var_0 = action_run(str_0)

if __name__ == '__main__':
    print('Running test for class ActionModule')
    test_case_0()
    print('Running tests for method run of class ActionModule')
    test_ActionModule_run()    

# Testing ability to workaround type union via annotation
# @type: int
test

# Generated at 2022-06-25 07:43:29.479925
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = " JFn'\rxj4h))M\r"
    float_0 = -3049.29
    bool_0 = False
    set_0 = {bool_0}
    list_0 = []
    float_1 = -4946.4
    str_1 = '53'
    action_module_0 = ActionModule(float_0, bool_0, set_0, list_0, float_1, str_1)
    var_0 = action_run(str_0)



# Generated at 2022-06-25 07:43:32.665216
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	try:
		# First test method run of class ActionModule
		# TODO: Write the test method
		pass
		# Second test method run of class ActionModule
		# TODO: Write the test method
		pass
		# Third test method run of class ActionModule
		# TODO: Write the test method
		pass
	except Exception as e:
		print(e)
		pass

# Generated at 2022-06-25 07:43:38.344849
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '2'
    float_0 = -4388.4
    bool_0 = True
    set_0 = set()
    list_0 = []
    float_1 = 4746.5
    str_1 = '1'
    action_module_0 = ActionModule(float_0, bool_0, set_0, list_0, float_1, str_1)
    var_0 = action_run(str_0)
    print(var_0)


# Generated at 2022-06-25 07:43:40.681209
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 3849
    bool_0 = True
    set_0 = {int_0}
    list_0 = [float_0]
    float_0 = -45939.03
    str_0 = 'O\r'
    action_module_0 = ActionModule(int_0, bool_0, set_0, list_0, float_0, str_0)


# Generated at 2022-06-25 07:43:47.405490
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -2581.0
    bool_0 = True
    set_0 = {float_0, bool_0}
    list_0 = [5402.15, False, float_0]
    float_1 = float_0
    str_0 = '77'
    action_module_0 = ActionModule(float_1, bool_0, set_0, list_0, float_0, str_0)


# Generated at 2022-06-25 07:43:50.311902
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = " JFn'\rxj4h))M\r"
    float_0 = -3049.29
    bool_0 = False
    set_0 = {bool_0}
    list_0 = []
    float_1 = -4946.4
    str_1 = '53'
    action_module_0 = ActionModule(float_0, bool_0, set_0, list_0, float_1, str_1)


# Generated at 2022-06-25 07:43:56.864251
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp_0 = 'tmp_0'
    task_vars_0 = 'task_vars_0'
    action_module_0 = ActionModule(tmp_0, task_vars_0)
    action_module_1 = action_module_0.run()


# Generated at 2022-06-25 07:44:02.405614
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -3049.29
    bool_0 = False
    set_0 = {bool_0}
    list_0 = []
    float_1 = -4946.4
    str_0 = '53'
    action_module_0 = ActionModule(float_0, bool_0, set_0, list_0, float_1, str_0)

# Generated at 2022-06-25 07:44:08.537194
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "z6'Ho\x0b\x0c\x1a\x0c(y"
    float_0 = -6.82
    bool_0 = False
    set_0 = {bool_0}
    list_0 = []
    float_1 = -8021.1
    str_1 = '=\n'
    action_module_0 = ActionModule(float_0, bool_0, set_0, list_0, float_1, str_1)


# Generated at 2022-06-25 07:44:22.441454
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -2.29
    bool_0 = True
    set_0 = {float_0, bool_0}
    list_0 = [None]
    float_1 = 965.5
    str_0 = 'XZF*zj6/]S'
    action_module_0 = ActionModule(float_0, bool_0, set_0, list_0, float_1, str_0)



# Generated at 2022-06-25 07:44:27.203084
# Unit test for constructor of class ActionModule
def test_ActionModule():
    if __name__ == '__main__':
        test_ActionModule()

# Generated at 2022-06-25 07:44:35.254818
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    tmp = dict()
    tmp['per_host'] = False
    tmp['aggregate'] = True
    task_vars['data'] = dict()
    action_base_0 = ActionBase(tmp, bool_0)
    action_module_0 = ActionModule(float_0, bool_0, set_0, list_0, float_1, str_1)
    action_module_0.run(tmp, task_vars)
    assert isinstance(action_module_0.run(tmp, task_vars), dict) == True
    

# Generated at 2022-06-25 07:44:35.878441
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-25 07:44:46.412921
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = " JFn'\rxj4h))M\r"
    float_0 = -3049.29
    bool_0 = False
    set_0 = {bool_0}
    list_0 = []
    float_1 = -4946.4
    str_1 = '53'
    action_module_0 = ActionModule(float_0, bool_0, set_0, list_0, float_1, str_1)
    bool_1 = True
    str_2 = "q\n[`"
    bool_2 = False
    str_3 = 'q\n[`'
    bool_3 = True
    var_0 = action_module_0.run(str_2, bool_2, str_3, bool_3)


# Generated at 2022-06-25 07:44:51.065703
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()



# Generated at 2022-06-25 07:45:00.210888
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = " JFn'\rxj4h))M\r"
    float_0 = -3049.29
    bool_0 = False
    set_0 = {bool_0}
    list_0 = []
    float_1 = -4946.4
    str_1 = '53'
    action_module_0 = ActionModule(float_0, bool_0, set_0, list_0, float_1, str_1)
    var_0 = action_run(str_0)
    assert var_0 == -966.8


# Generated at 2022-06-25 07:45:05.945036
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = " JFn'\rxj4h))M\r"
    float_0 = -3049.29
    bool_0 = False
    set_0 = {bool_0}
    list_0 = []
    float_1 = -32605.5
    str_1 = '12'
    action_module_0 = ActionModule(float_0, bool_0, set_0, list_0, float_1, str_1)


# Generated at 2022-06-25 07:45:06.762396
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert action_module_0.run() == None

# Generated at 2022-06-25 07:45:09.553930
# Unit test for constructor of class ActionModule
def test_ActionModule():
    int_0 = 35
    dict_0 = {"P" : int_0, "J$" : "9", "n$" : ")wJ"}
    action_module_0 = ActionModule(dict_0)
    test_case_0()

# Generated at 2022-06-25 07:45:36.809768
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = {-2074.940366476}
    list_0 = [(16), (17), (-91), (35)]
    str_0 = "gy`\x1bAY\x0e\x1a"
    float_0 = -872.07
    bool_0 = True
    float_1 = -7279.995
    str_1 = '9'
    action_module_0 = ActionModule(float_0, bool_0, set_0, list_0, float_1, str_1)
    var_0 = action_run(str_0)


# Generated at 2022-06-25 07:45:44.561795
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "y_r\x16t'\wa2"
    float_0 = -2927.0
    bool_0 = True
    set_0 = {str_0}
    list_0 = [str_0]
    float_1 = -6303.9
    str_1 = ';6'
    action_module_0 = ActionModule(float_0, bool_0, set_0, list_0, float_1, str_1)



# Generated at 2022-06-25 07:45:49.791273
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "Xc%jYz{bIq3B4"
    float_0 = -7324.59
    bool_0 = True
    set_0 = {str_0, float_0}
    list_0 = [float_0]
    float_1 = 0.0
    str_1 = 'totol'
    action_module_0 = ActionModule(float_0, bool_0, set_0, list_0, float_1, str_1)
    action_module_0.run()


# Generated at 2022-06-25 07:45:54.459239
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dictionary_0 = { }
    dictionary_1 = {'a': True, 'b': False, 'c': 1}

    class MockTask:
        args = {'data': dictionary_0}

    action = ActionModule(MockTask(), '')
    assert action.run()['ansible_stats']['data'] == dictionary_0

    class MockTask:
        args = {'data': dictionary_1}

    action = ActionModule(MockTask(), '')
    assert action.run()['ansible_stats']['data'] == dictionary_1

# Generated at 2022-06-25 07:46:01.627011
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "t\x1c~J\x1f\x0b'\x17{\x1c"
    float_0 = 4821.2
    bool_0 = True
    set_0 = {float_0}
    list_0 = []
    int_0 = -8
    str_1 = '@\r'
    action_module_0 = ActionModule(float_0, bool_0, set_0, list_0, int_0, str_1)
    var_0 = action_module_0.run(str_0)
    var_1 = StringIO(str_0)
    var_2 = ActionModule.run(action_module_0, var_1)

# Generated at 2022-06-25 07:46:08.524371
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = " JFn'\rxj4h))M\r"
    float_0 = -3049.29
    bool_0 = False
    set_0 = {bool_0}
    list_0 = []
    float_1 = -4946.4
    str_1 = '53'
    action_module_0 = ActionModule(float_0, bool_0, set_0, list_0, float_1, str_1)
    var_0 = action_module_0.run(str_0)

if __name__ == "__main__":
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:46:14.806886
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.utils.vars
    import ansible.plugins.action
    tmp = None
    task_vars = None
    action_module_0 = ActionModule(tmp, task_vars)
    str_0 = " JFn'\rxj4h))M\r"
    var_0 = action_module_0.run(str_0)

# Generated at 2022-06-25 07:46:21.690682
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    
    # Test type if 0
    
    action_module_0 = ActionModule(str_0, list_0, int_0, var_0, var_1, list_1, int_1)
    assert type(action_module_0.run()) == dict
    
    # Test result if 1
    
    action_module_0 = ActionModule(int_0, bool_0, int_1, dict_0, dict_1)
    test_case_0()
    assert hash(action_module_0.run()) == hash(var_0)
    



# Generated at 2022-06-25 07:46:31.670019
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '|%lzsE6U\n6-C'
    float_0 = 2327.37
    bool_0 = False
    set_0 = {float_0}
    list_0 = []
    float_1 = -8584.5
    str_1 = '53'
    action_module_0 = ActionModule(float_0, bool_0, set_0, list_0, float_1, str_1)
    var_0 = action_module_0.run(str_0)
    assert isinstance(var_0, dict) == True
    assert 'changed' in var_0
    assert var_0['changed'] == False
    assert 'ansible_stats' in var_0
    assert 'aggregate' in var_0['ansible_stats']
    assert var_0

# Generated at 2022-06-25 07:46:37.569656
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = -1.65
    bool_0 = False
    set_0 = set()
    list_0 = []
    float_1 = -1.41
    str_0 = 'F'
    assert_expect(ActionModule(float_0, bool_0, set_0, list_0, float_1, str_0), None)


# Generated at 2022-06-25 07:47:26.004857
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = " hT'\x8fT](Zs"
    float_0 = -46.2
    bool_0 = True
    set_0 = {float_0}
    list_0 = []
    float_1 = -182.9
    str_1 = '^V7'
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:47:29.938818
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '1'
    float_0 = -5893.8
    bool_0 = False
    set_0 = {bool_0}
    list_0 = []
    float_1 = -1514.24
    str_1 = '5'
    action_module_0 = ActionModule(float_0, bool_0, set_0, list_0, float_1, str_1)
    action_module_0._action = set_0
    var_0 = action_module_0.run()

test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 07:47:31.556504
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Assert inherit from ActionBase
    assert issubclass(ActionModule, ActionBase)



# Generated at 2022-06-25 07:47:34.488475
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        str_1 = "\t\f?A\x7f"
        action_module_0 = ActionModule(str_1)
        test_case_0()
    except Exception as var_7:
        print('exception: ' + str(var_7))

test_ActionModule_run()

# Generated at 2022-06-25 07:47:44.562808
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    _action_module = ActionModule(10, 20, 30, 40, 50, 60)
    _action_base = ActionBase(10, 20, 30, 40, 50)
    _action_run = _action_module.run(10, 20)
    _action_module.run(10, 20)
    _action_base.run(10, 20)
    _action_module.run(10, 20)
    _action_module.run(10, 20)
    _action_module.run(10, 20)
    _action_module.run(10, 20)
    _action_module.run(10, 20)
    _action_module.run(10, 20)
    _action_module.run(10, 20)



# Generated at 2022-06-25 07:47:45.259253
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:47:52.418059
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    true = True
    false = False
    str_0 = " JFn'\rxj4h))M\r"
    float_0 = -3049.29
    bool_0 = False
    set_0 = {bool_0}
    list_0 = []
    float_1 = -4946.4
    str_1 = '53'
    action_module_0 = ActionModule(float_0, bool_0, set_0, list_0, float_1, str_1)
    var_0 = action_module_0.run(str_0)
    test_case_0()

# Generated at 2022-06-25 07:47:57.590290
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:47:59.076212
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.set_stats import ActionModule
    assert callable(ActionModule.run)


# Generated at 2022-06-25 07:48:07.509448
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = ";W8\nkV7_\rR>lDt\r<tT\r"
    float_0 = -9677.8
    bool_0 = True
    set_0 = {(float_0, bool_0), bool_0}
    list_0 = [bool_0, str_0, (float_0, bool_0, bool_0)]
    float_1 = -9647.15
    str_1 = '\"w.8)C|Oj[*E\n/'
    action_module_0 = ActionModule(float_1, bool_0, set_0, list_0, float_0, str_1)


# Generated at 2022-06-25 07:50:00.350501
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "z\n"
    float_0 = -2213.26
    bool_0 = True
    set_0 = {bool_0}
    list_0 = []
    float_1 = -3735.99
    str_1 = 'RH'
    action_module_0 = ActionModule(float_0, bool_0, set_0, list_0, float_1, str_1)
    assert (action_module_0.TRANSFERS_FILES == 0)
    assert (action_module_0._VALID_ARGS == frozenset({'aggregate', 'data', 'per_host'}))


# Generated at 2022-06-25 07:50:07.915530
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = " JFn'\rxj4h))M\r"
    float_0 = -3049.29
    bool_0 = False
    set_0 = {bool_0}
    list_0 = []
    float_1 = -4946.4
    str_1 = '53'
    action_module_0 = ActionModule(float_0, bool_0, set_0, list_0, float_1, str_1)

# Generated at 2022-06-25 07:50:08.534432
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:50:13.001528
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        raise Exception
    finally:
        str_0 = " JFn'\rxj4h))M\r"
        float_0 = -3049.29
        bool_0 = False
        set_0 = {bool_0}
        list_0 = []
        float_1 = -4946.4
        str_1 = '53'
        action_module_0 = ActionModule(float_0, bool_0, set_0, list_0, float_1, str_1)
        var_0 = action_run(str_0)

# Generated at 2022-06-25 07:50:22.631423
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    float_0 = 54.73
    bool_0 = True
    set_0 = {bool_0}
    list_0 = []
    float_1 = 1868.3
    str_0 = 'amodule'
    action_module_0 = ActionModule(float_0, bool_0, set_0, list_0, float_1, str_0)
    str_1 = "=fS\"K0\tCS[\x1c"
    dict_0 = {'Kjq$': str_1}
    dict_1 = {str_0: {'per_host': bool_0, 'data': dict_0, 'aggregate': False}}
    str_2 = 'sjZJc%4?'

# Generated at 2022-06-25 07:50:31.988642
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Initialize task args
    str_1 = "mwI\r{0t\rYtZ\r"
    float_1 = 1285.81
    bool_1 = True
    set_1 = {str_1, bool_1}
    list_1 = [float_1, bool_1]
    float_2 = 4658.98
    str_2 = 'x7'
    # Initialize task args with another action module class
    action_module_0 = ActionModule(float_1, bool_1, set_1, list_1, float_2, str_2)
    # Call method run with args
    str_2 = "e7"
    float_2 = -2113.69
    bool_2 = True
    set_2 = {str_2, bool_2}
    list_2

# Generated at 2022-06-25 07:50:37.925589
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = " JFn'\rxj4h))M\r"
    float_0 = -3049.29
    bool_0 = False
    set_0 = {bool_0}
    list_0 = []
    float_1 = -4946.4
    str_1 = '53'
    action_module_0 = ActionModule(float_0, bool_0, set_0, list_0, float_1, str_1)


# Generated at 2022-06-25 07:50:46.830060
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = " JFn'\rxj4h))M\r"
    float_0 = -3049.29
    bool_0 = False
    set_0 = {bool_0}
    list_0 = []
    float_1 = -4946.4
    str_1 = '53'
    action_module_0 = ActionModule(float_0, bool_0, set_0, list_0, float_1, str_1)
    var_0 = action_module_0.name


# Generated at 2022-06-25 07:50:49.646782
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = " JFn'\rxj4h))M\r"
    float_0 = -3049.29
    bool_0 = False
    set_0 = {bool_0}
    list_0 = []
    float_1 = -4946.4
    str_1 = '53'


# Generated at 2022-06-25 07:50:54.884652
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "cJ\x7f6\x16\x1c?\x0eT+\x14J2"
    float_0 = -2580.82
    bool_0 = False
    set_0 = {False}
    list_0 = []
    float_1 = -3377.55
    str_1 = 'v8L'
    action_module_0 = ActionModule(float_0, bool_0, set_0, list_0, float_1, str_1)
    dict_0 = dict()
    dict_0['data'] = dict()
    str_1 = 'A'
    dict_0['data']['A'] = 'B'
    dict_0['per_host'] = False
    dict_0['aggregate'] = True
    dict_1 = dict()