

# Generated at 2022-06-25 07:41:37.371533
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


if __name__ == '__main__':
    test_ActionModule()
    test_case_0()

# Generated at 2022-06-25 07:41:43.855928
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    dict_1 = {}
    dict_1['data'] = dict_0
    action_module_0 = ActionModule(None, dict_1, True, 0, '', '')
    action_module_0.run(dict_0)
    action_module_0.run(dict_0, dict_0,)

# Generated at 2022-06-25 07:41:51.655805
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 363.0
    dict_0 = {}
    bool_0 = False
    int_0 = None
    str_0 = '@i\\SUh'
    action_module_0 = ActionModule(float_0, dict_0, bool_0, int_0, str_0, str_0)
    assert((action_module_0._task.args.get('data', {}) == {}))
    assert((action_module_0._task.args.get('per_host', False) == False))
    assert((action_module_0._task.args.get('aggregate', True) == True))
    assert((action_module_0.templar._fail_on_lookup_errors == False))
    assert((action_module_0.templar._fail_on_undefined_errors == False))

# Generated at 2022-06-25 07:41:55.009436
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    task_vars_0 = dict_0

    action_module_0 = ActionModule(dict_0, task_vars_0)
    tmp_0 = None
    task_vars_1 = task_vars_0
    result_0 = action_module_0.run(tmp_0, task_vars_1)


if __name__ == '__main__':
    test_case_0()
    test_ActionModule()
    print('Test completed')

# Generated at 2022-06-25 07:41:55.728400
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(363.0)


# Generated at 2022-06-25 07:41:59.187174
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 07:42:04.857358
# Unit test for constructor of class ActionModule
def test_ActionModule():
    float_0 = 10000.0
    dict_0 = {}
    bool_0 = False
    int_0 = None
    str_0 = 'q'
    ActionModule(float_0, dict_0, bool_0, int_0, str_0, str_0)


# Generated at 2022-06-25 07:42:11.635057
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Arguments:
    # Data Type      Variable Name  Location
    # number         float_0        363.0
    # dictionary     dict_0         {}
    # boolean        bool_0         False
    # number         int_0          None
    # string         str_0          '@i\\SUh'
    # string         str_1          '@i\\SUh'
    action_module_0 = ActionModule(float_0, dict_0, bool_0, int_0, str_0, str_0)
    return


# Generated at 2022-06-25 07:42:16.031096
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: i/o stubs here
    str_0 = u'%\x1a'
    dict_0 = {}
    float_0 = 363.0
    bool_0 = False
    int_0 = None
    str_1 = '@i\\SUh'
    action_module_0 = ActionModule(float_0, dict_0, bool_0, int_0, str_0, str_1)
    action_module_0.run(str_1, str_1)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:42:16.776589
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()



# Generated at 2022-06-25 07:42:23.836862
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not hasattr(ActionModule, 'TRANSFERS_FILES')
    assert ActionModule().TRANSFERS_FILES is False


# Generated at 2022-06-25 07:42:25.504377
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj_action_module = ActionModule()
    obj_action_module.run('tmp', 'task_vars')

# Generated at 2022-06-25 07:42:29.369290
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module._task.args = dict()
    action_module._task.args['data'] = dict()
    action_module._task.args['data']['a'] = "{% if True %}1{% else %}0{% endif %}"


# Generated at 2022-06-25 07:42:33.507556
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

# unit tests end here

if __name__ == '__main__':
    import sys
    # begin test code
    print("Beginning unit tests")
    print("additional test code goes here")
    # Uncomment next line so test will fail if no tests written
    #sys.exit(1)
    # end test code
    sys.exit(0)

# Generated at 2022-06-25 07:42:37.789407
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    tmp_1 = None
    task_vars_1 = None
    result_1 = action_module_1.run(tmp_1, task_vars_1)
    assert isinstance(result_1, dict)
    assert 'ansible_stats' in result_1
    assert result_1['ansible_stats']['data']['test'] == 'foo'
    assert result_1['ansible_stats']['per_host'] == False
    assert result_1['ansible_stats']['aggregate'] == True


# Generated at 2022-06-25 07:42:41.704414
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    :return:
    '''
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:42:46.221309
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # In this test case the defaults for options per_host and aggregate are false
    test_case_0_stats = {'data': {'x': 'y'}, 'per_host': False, 'aggregate': False}
    test_case_0_data = {'x': 'y'}

    action_module = ActionModule()

    test_case_0_result = action_module.run(None, None, x=test_case_0_data)

    # asserts that test case 0 result is equal to test 1 result
    assert test_case_0_result['ansible_stats'] == test_case_0_stats

# Generated at 2022-06-25 07:42:50.088508
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # No args, no task_vars
    result_0 = action_module_0.run(tmp=None, task_vars=None)
    assert result_0['changed'] == False
    assert isinstance(result_0['ansible_stats'], dict)


if __name__ == "__main__":

    test_ActionModule()

# Generated at 2022-06-25 07:42:53.338895
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

    assert(not action_module_0._connection.connected)
    assert_equals("ActionModule", action_module_0.__class__.__name__)



# Generated at 2022-06-25 07:42:55.474074
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert callable(ActionModule), "Failed: 'ActionModule' is not callable"



# Generated at 2022-06-25 07:43:10.890550
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    set_stats_result = action_module.run()
    assert 'ansible_stats' in set_stats_result
    assert 'data' in set_stats_result['ansible_stats']
    assert 'per_host' in set_stats_result['ansible_stats']
    assert 'aggregate' in set_stats_result['ansible_stats']
    assert set_stats_result['ansible_stats']['per_host'] == False
    assert set_stats_result['ansible_stats']['aggregate'] == True


# Generated at 2022-06-25 07:43:12.428996
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # create an object for ActionModule class
    test_case_0()

# Generated at 2022-06-25 07:43:13.324734
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement this test
    pass

# Generated at 2022-06-25 07:43:14.699627
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    assert(action_module.run() is None)

# Generated at 2022-06-25 07:43:16.849533
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert (action_module.TRANSFERS_FILES == False)



# Generated at 2022-06-25 07:43:24.436108
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    data_dict_0 = {}
    data_dict_0['common_return'] = {'foo': 'bar'}
    data_dict_0['common_return']['parsed'] = True
    data_dict_0['common_return']['invocation'] = {}
    data_dict_0['common_return']['invocation']['module_args'] = {}
    data_dict_0['common_return']['invocation']['module_args']['data'] = {'success': True}
    data_dict_0['common_return']['invocation']['module_args']['per_host'] = True
    data_dict_0['common_return']['invocation']['module_args']['aggregate'] = False

# Generated at 2022-06-25 07:43:25.952384
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    print("Testing constructor of class ActionModule")


# Generated at 2022-06-25 07:43:30.818096
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp_0 = None
    task_vars_0 = {u'var_test': True}
    result = action_module_0.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 07:43:34.400056
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Test class constructor for action_module.ActionModule"""
    action_module_1 = ActionModule(loader = None, variable_manager = None,
                                   templar = None, shared_loader_obj = None)
    assert(isinstance(action_module_1, ActionModule))


# Generated at 2022-06-25 07:43:41.458738
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

    # from ansible.module_utils.six import iteritems, string_types
    # from ansible.module_utils.parsing.convert_bool import boolean
    # from ansible.plugins.action import ActionBase
    # from ansible.utils.vars import isidentifier


    # ActionModule._VALID_ARGS = frozenset(('aggregate', 'data', 'per_host'))
    # ActionModule.run = ActionModule.run
    # dict tmp=None, dict task_vars=None

    # TODO: fix this
    # if task_vars is None:
    #     task_vars = dict()

    # result = super(ActionModule, self).run(tmp, task_vars)
    # del tmp  # tmp no longer has any effect

# Generated at 2022-06-25 07:43:59.108967
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xfa]\x1b\x9b\xdc\xfb\xe1\xf4\xb5\x03\xe2\x12\xb3\x17@\xa2'
    set_0 = {bytes_0}
    str_0 = 'hr_8(cAQ7c??4B\t'
    float_0 = -2570.501
    tuple_0 = ()
    str_1 = 'View vault encrypted file'
    bytes_1 = None
    bool_0 = False
    bytes_2 = b'\x93^\x96\xfb'
    tuple_1 = (str_1, bytes_1, bool_0, bytes_2)
    set_1 = {str_0, tuple_0, str_1, tuple_1}
    float

# Generated at 2022-06-25 07:44:08.596930
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xfa]\x1b\x9b\xdc\xfb\xe1\xf4\xb5\x03\xe2\x12\xb3\x17@\xa2'
    set_1 = {bytes_0}
    str_0 = 'hr_8(cAQ7c??4B\t'
    float_0 = -2570.501
    tuple_0 = ()
    str_1 = 'View vault encrypted file'
    bytes_1 = None
    bool_0 = False
    bytes_2 = b'\x93^\x96\xfb'
    tuple_1 = (str_1, bytes_1, bool_0, bytes_2)
    set_2 = {str_0, tuple_0, str_1, tuple_1}
    float

# Generated at 2022-06-25 07:44:14.895984
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xfa]\x1b\x9b\xdc\xfb\xe1\xf4\xb5\x03\xe2\x12\xb3\x17@\xa2'
    set_0 = {bytes_0}
    str_0 = 'hr_8(cAQ7c??4B\t'
    float_0 = -2570.501
    tuple_0 = ()
    str_1 = 'View vault encrypted file'
    bytes_1 = None
    bool_0 = False
    bytes_2 = b'\x93^\x96\xfb'
    tuple_1 = (str_1, bytes_1, bool_0, bytes_2)
    set_1 = {str_0, tuple_0, str_1, tuple_1}
    float

# Generated at 2022-06-25 07:44:21.969998
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x9f\x10\xcb\xdf\xd3\x1ag\x0f\x05\x9f\x9e\x11A\x1c\x1b\xeb'
    double_0 = -0.04381489228933274
    int_0 = 0
    str_0 = '-\x1f\x1a\x00\x17\x00\n\x00\x00\x00\x00\n'
    bytes_1 = b'\xa7\xbb\x8c\xd1\x9c\x9a\x8cP'
    float_0 = -0.38957732867202204
    str_1 = 'y'

# Generated at 2022-06-25 07:44:31.202623
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xfa]\x1b\x9b\xdc\xfb\xe1\xf4\xb5\x03\xe2\x12\xb3\x17@\xa2'
    set_0 = {bytes_0}
    str_0 = 'hr_8(cAQ7c??4B\t'
    float_0 = -2570.501
    tuple_0 = ()
    str_1 = 'View vault encrypted file'
    bytes_1 = None
    bool_0 = False
    bytes_2 = b'\x93^\x96\xfb'
    tuple_1 = (str_1, bytes_1, bool_0, bytes_2)
    set_1 = {str_0, tuple_0, str_1, tuple_1}
    float

# Generated at 2022-06-25 07:44:41.461001
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xfa]\x1b\x9b\xdc\xfb\xe1\xf4\xb5\x03\xe2\x12\xb3\x17@\xa2'
    set_0 = {bytes_0}
    str_0 = 'hr_8(cAQ7c??4B\t'
    float_0 = -2570.501
    tuple_0 = ()
    str_1 = 'View vault encrypted file'
    bytes_1 = None
    bool_0 = False
    bytes_2 = b'\x93^\x96\xfb'
    tuple_1 = (str_1, bytes_1, bool_0, bytes_2)
    set_1 = {str_0, tuple_0, str_1, tuple_1}
    float

# Generated at 2022-06-25 07:44:51.413500
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'hr_8(cAQ7c??4B\t'
    float_0 = -2570.501
    tuple_0 = ()
    str_1 = 'View vault encrypted file'
    bytes_0 = None
    bool_0 = False
    bytes_1 = b'\x93^\x96\xfb'
    tuple_1 = (str_1, bytes_0, bool_0, bytes_1)
    set_0 = {str_0, tuple_0, str_1, tuple_1}
    float_1 = 119.105
    action_module_0 = ActionModule(str_0, float_0, tuple_0, tuple_1, set_0, float_1)
    assert action_module_0.TRANSFERS_FILES

# Generated at 2022-06-25 07:45:03.242728
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set((b'0\x8a\\', b'T\xdf\xdf@\x80\xd4\x92\xb4\xceD\x03\x9dX', ))
    str_0 = 'Y\x8d\x8c5f\x1a\xe2\x9e\xab\xb3\xed\xcc\xd5\x91\x86\xae\x1b\x9d\x93\xbe\x89\x85\x00'
    float_0 = -0.5094
    tuple_0 = (float_0, str_0, 0.8579922, str_0, )
    str_1 = 'aV\xbdQ\x1f\xfa\x8d\xce'
    bytes_

# Generated at 2022-06-25 07:45:12.973153
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xfa]\x1b\x9b\xdc\xfb\xe1\xf4\xb5\x03\xe2\x12\xb3\x17@\xa2'
    set_0 = {bytes_0}
    str_0 = 'hr_8(cAQ7c??4B\t'
    float_0 = -2570.501
    tuple_0 = ()
    str_1 = 'View vault encrypted file'
    bytes_1 = None
    bool_0 = False
    bytes_2 = b'\x93^\x96\xfb'
    tuple_1 = (str_1, bytes_1, bool_0, bytes_2)
    set_1 = {str_0, tuple_0, str_1, tuple_1}
    float

# Generated at 2022-06-25 07:45:22.771490
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert (action_module_0.tablename is None)
    assert (action_module_0.saved_attrs is None)
    assert (action_module_0._task_fields is None)
    assert (action_module_0._task is None)
    assert (action_module_0.action_loader is None)
    assert (action_module_0.name is None)
    assert (action_module_0.aliases is None)
    assert (action_module_0.connection_info is None)
    assert (action_module_0.action is None)
    assert (action_module_0.action_name is None)
    assert (action_module_0.action_context is None)
    assert (action_module_0.action_explanation is None)

# Generated at 2022-06-25 07:45:47.648541
# Unit test for constructor of class ActionModule
def test_ActionModule():
 
    # Test action run

    assert var_0.changed == False
    assert var_0.failed == False
    assert var_0.msg == 'Non-zero return code'
    # assert var_0.rc==255
    assert var_0.result.state == 'absent'
    assert var_0.result.group == 'root'
    assert var_0.result.user == 'root'
    assert var_0.stderr == 'bash: /opt/test: Permission denied\n'
    assert var_0.stderr_lines == ['/opt/test: Permission denied']
    assert var_0.stdout == '\n'
    assert var_0.stdout_lines == ['']

# Generated at 2022-06-25 07:45:50.668086
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:45:57.239731
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = {b'\xfa]\x1b\x9b\xdc\xfb\xe1\xf4\xb5\x03\xe2\x12\xb3\x17@\xa2'}
    str_0 = 'hr_8(cAQ7c??4B\t'
    float_0 = -2570.501
    tuple_0 = ()
    str_1 = 'View vault encrypted file'
    bytes_0 = None
    bool_0 = False
    bytes_1 = b'\x93^\x96\xfb'
    tuple_1 = (str_1, bytes_0, bool_0, bytes_1)
    set_1 = {str_0, tuple_0, str_1, tuple_1}
    float_1 = 119.105
    action

# Generated at 2022-06-25 07:46:01.642702
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-25 07:46:08.775790
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_1 = 'View vault encrypted file'
    bytes_1 = None
    bool_0 = False
    bytes_2 = b'\x93^\x96\xfb'
    tuple_1 = (str_1, bytes_1, bool_0, bytes_2)
    set_1 = {str_0, tuple_0, str_1, tuple_1}
    float_1 = 119.105
    action_module_0 = ActionModule(str_0, tuple_0, tuple_1, set_1, float_1)

if __name__ == '__main__':
    test_case_0()
    
    test_ActionModule()

# Generated at 2022-06-25 07:46:18.403522
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xfa]\x1b\x9b\xdc\xfb\xe1\xf4\xb5\x03\xe2\x12\xb3\x17@\xa2'
    set_0 = {bytes_0}
    str_0 = 'hr_8(cAQ7c??4B\t'
    float_0 = -2570.501
    tuple_0 = ()
    str_1 = 'View vault encrypted file'
    bytes_1 = None
    bool_0 = False
    bytes_2 = b'\x93^\x96\xfb'
    tuple_1 = (str_1, bytes_1, bool_0, bytes_2)
    set_1 = {str_0, tuple_0, str_1, tuple_1}
    float

# Generated at 2022-06-25 07:46:24.501339
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = set()
    str_0 = "test"
    float_0 = float()
    tuple_0 = tuple()
    set_1 = set()
    float_1 = float()
    action_module_0 = ActionModule(set_0, str_0, float_0, tuple_0, set_1, float_1)
    assert action_module_0 is not None

# Generated at 2022-06-25 07:46:33.592117
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xfa]\x1b\x9b\xdc\xfb\xe1\xf4\xb5\x03\xe2\x12\xb3\x17@\xa2'
    set_0 = {bytes_0}
    str_0 = 'hr_8(cAQ7c??4B\t'
    float_0 = -2570.501
    tuple_0 = ()
    str_1 = 'View vault encrypted file'
    bytes_1 = None
    bool_0 = False
    bytes_2 = b'\x93^\x96\xfb'
    tuple_1 = (str_1, bytes_1, bool_0, bytes_2)
    set_1 = {str_0, tuple_0, str_1, tuple_1}
    float

# Generated at 2022-06-25 07:46:37.922252
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # try:
    #     action_module_0 = ActionModule(str_0, float_0, tuple_0, tuple_1, set_1, float_1)
    # except Exception as e:
    #     print(e)
    # else:
    #     print('ExpectedExceptionNotFound')
    #     exit(1)
    pass


# Generated at 2022-06-25 07:46:45.265780
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with string arguments
    action_module_0 = ActionModule('A', 'b', 'c', 'd', 'e', 'f')
    assert action_module_0.name == 'A'
    assert action_module_0._shared_loader_obj == 'b'
    assert action_module_0._task == 'c'
    assert action_module_0._play_context == 'd'
    assert action_module_0._loaded_from == 'e'
    assert action_module_0._task_vars == 'f'

    # Test with integers
    action_module_1 = ActionModule(1, 2, 3, 4, 5, 6)
    assert action_module_1.name == 1
    assert action_module_1._shared_loader_obj == 2
    assert action_module_1._task == 3


# Generated at 2022-06-25 07:47:27.675808
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False


# Generated at 2022-06-25 07:47:30.593518
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('')
    print('Testing method run of class ActionModule...')
    print('')
    test_case_0()
    print('')


# Run unit tests
if __name__ == '__main__':
    print('')
    print('Testing ansible.module_utils.parsing.convert_bool...')
    print('')
    test_ActionModule_run()
    print('')

# Generated at 2022-06-25 07:47:39.223917
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\xfa]\x1b\x9b\xdc\xfb\xe1\xf4\xb5\x03\xe2\x12\xb3\x17@\xa2'
    bool_0 = False
    action_module_0 = ActionModule(bool_0)
    tmp_0 = None
    task_vars_0 = dict()
    action_module_0.run(tmp_0, task_vars_0)
    var_0 = action_module_0.run(tmp_0, task_vars_0)
    del var_0
    del action_module_0
    del task_vars_0
    del tmp_0
    del bool_0
    del bytes_0


# Generated at 2022-06-25 07:47:46.683754
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:47:48.946451
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: add code here
    pass


# Generated at 2022-06-25 07:47:56.933009
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xfa]\x1b\x9b\xdc\xfb\xe1\xf4\xb5\x03\xe2\x12\xb3\x17@\xa2'
    set_0 = {bytes_0}
    str_0 = 'hr_8(cAQ7c??4B\t'
    float_0 = -2570.501
    tuple_0 = ()
    str_1 = 'View vault encrypted file'
    bytes_1 = None
    bool_0 = False
    bytes_2 = b'\x93^\x96\xfb'
    tuple_1 = (str_1, bytes_1, bool_0, bytes_2)
    set_1 = {str_0, tuple_0, str_1, tuple_1}
    float

# Generated at 2022-06-25 07:48:00.238677
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'\x88\xce\xd4'
    int_0 = 20027143
    set_0 = {bytes_0}
    str_0 = '\x88\xce\xd4'
    float_0 = 17.5
    set_1 = {str_0, float_0}
    float_1 = 21.3
    action_module_0 = ActionModule(str_0, float_0, set_0, set_1, float_1)
    var_0 = action_module_0.run(int_0)

# Generated at 2022-06-25 07:48:08.022306
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xfa]\x1b\x9b\xdc\xfb\xe1\xf4\xb5\x03\xe2\x12\xb3\x17@\xa2'
    dict_0 = None
    set_0 = {bytes_0}
    str_0 = 'hr_8(cAQ7c??4B\t'
    float_0 = -2570.501
    tuple_0 = ()
    str_1 = 'View vault encrypted file'
    bytes_1 = None
    bool_0 = False
    bytes_2 = b'\x93^\x96\xfb'
    tuple_1 = (str_1, bytes_1, bool_0, bytes_2)

# Generated at 2022-06-25 07:48:12.414511
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule('tV', -4.2714, (), ('sudo', None, True, b'\xfa]\x1b\x9b\xdc\xfb\xe1\xf4\xb5\x03\xe2\x12\xb3\x17@\xa2'),
                                   {'hr_8(cAQ7c??4B\t', (), 'View vault encrypted file', ('View vault encrypted file', None, True,
                                                                                          b'\x93^\x96\xfb')}, -6.5675)
    assert action_module_0._task.data == {'action': 'set_stats'}

# Generated at 2022-06-25 07:48:15.501634
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    bytes_0 = b'\x00\x00'
    tuple_0 = (bytes_0, bytes_0)
    set_0 = {tuple_0}
    # Test __init__
    test_case_0()
    action_module_0._connection.get_links(tuple_0, set_0)

test_ActionModule()

# Generated at 2022-06-25 07:49:57.104696
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:50:06.012948
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a dummy class for ActionBase
    class DummyClass:
        pass

    # Create a dummy ActionBase instance
    object_0 = DummyClass()

    # Create a dummy task
    class DummyTask:
        def __init__(self):
            self.args = None

    # Create a dummy task instance and assign the args
    object_1 = DummyTask()
    object_1.args = {'data': {'ARG_1': 'INPUT_1', 'ARG_2': 'INPUT_2'},
                     'per_host': True, 'aggregate': True}

    # Create a dummy templar object
    class DummyTemplar:
        def template(self, arg_0, arg_1=None, arg_2=None):
            return arg_0

    float_0 = 1.

# Generated at 2022-06-25 07:50:14.956228
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b'8'
    set_0 = {bytes_0}
    str_0 = 'connection'
    float_0 = -0.00462257547
    tuple_0 = ()
    str_1 = 'async'
    bytes_1 = b'[\x18\x1c\x8d\xeb\x9f'
    bool_0 = False
    bytes_2 = b'\x85\xba\x8a\xfe'
    tuple_1 = (str_1, bytes_1, bool_0, bytes_2)
    set_1 = {str_0, tuple_0, str_1, tuple_1}
    float_1 = -0.00462257547

# Generated at 2022-06-25 07:50:19.811218
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins import TestModule
    test_module_0 = TestModule(mutable_default_args=mutable_default_arg, connection='ssh', no_log=('no_log' in self._task.args), become=False, become_method='sudo', become_user=None, check=False, diff=True)


# Generated at 2022-06-25 07:50:22.753978
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 07:50:24.461198
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(action_module_0 is not None)


# Generated at 2022-06-25 07:50:32.983577
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xfa]\x1b\x9b\xdc\xfb\xe1\xf4\xb5\x03\xe2\x12\xb3\x17@\xa2'
    set_0 = {bytes_0}
    str_0 = 'hr_8(cAQ7c??4B\t'
    float_0 = -2570.501
    tuple_0 = ()
    str_1 = 'View vault encrypted file'
    bytes_1 = None
    bool_1 = False
    bytes_2 = b'\x93^\x96\xfb'
    tuple_1 = (str_1, bytes_1, bool_1, bytes_2)
    set_1 = {str_0, tuple_0, str_1, tuple_1}
    float

# Generated at 2022-06-25 07:50:38.177420
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    stats = {'data': {}, 'per_host': False, 'aggregate': True}
    data = {}
    self._task.args.args['data'] = data
    # Function call.
    ActionModule_run(stats, data)
    # TODO: Use another way to verify the result.
    verify_ActionModule_run(stats, data)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 07:50:48.698851
# Unit test for constructor of class ActionModule
def test_ActionModule():
  set_0 = {b'\xfa]\x1b\x9b\xdc\xfb\xe1\xf4\xb5\x03\xe2\x12\xb3\x17@\xa2'}
  str_0 = 'hr_8(cAQ7c??4B\t'
  float_0 = -2570.501
  tuple_0 = ()
  str_1 = 'View vault encrypted file'
  bytes_0 = None
  bool_0 = False
  bytes_1 = b'\x93^\x96\xfb'
  tuple_1 = (str_1, bytes_0, bool_0, bytes_1)
  set_1 = {str_0, tuple_0, str_1, tuple_1}
  float_1 = 119.105
  #

# Generated at 2022-06-25 07:50:50.409583
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	#Test if the return value is a dictionary
	assert (type(ActionModule.run()) == dict)