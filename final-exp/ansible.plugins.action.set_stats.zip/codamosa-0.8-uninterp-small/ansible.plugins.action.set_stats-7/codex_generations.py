

# Generated at 2022-06-25 07:41:47.077287
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    str_0 = '-'
    bytes_0 = b'\x84;\x0e\xa0Y\xe3\xdd\xd0\x05\x06Q\x1a@\xda\xfc\xe6'
    bool_0 = True
    action_module_0 = ActionModule(tuple_0, str_0, bytes_0, tuple_0, bool_0, tuple_0)
    tuple_1 = ()
    tuple_2 = ()
    dict_0 = {}
    dict_0['data'] = 'test'
    dict_1 = {}
    dict_1['item'] = dict_0
    dict_2 = {}
    dict_2['item'] = dict_1
    tuple_3 = ()
    dict_3 = {}

# Generated at 2022-06-25 07:41:52.626444
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    str_0 = '@'
    bytes_0 = b'\x9e\x99&\xed.'
    bool_0 = True
    action_module_0 = ActionModule(tuple_0, str_0, bytes_0, tuple_0, bool_0, tuple_0)
    tuple_0 = ()
    str_1 = 'W'
    bytes_1 = b'\x9e\x99&\xed.'
    bool_1 = True
    action_module_1 = ActionModule(tuple_0, str_1, bytes_1, tuple_0, bool_1, tuple_0)
    tuple_0 = ()
    str_2 = 'V'
    bytes_2 = b'\x9e\x99&\xed.'

# Generated at 2022-06-25 07:41:58.398574
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    str_0 = '\xdd\x16\xad+'
    bytes_0 = b'\xdb\xc5\xaa\xac\x81\x80\xb3\x9d\x9e\x99&\xed.'
    bool_0 = True
    action_module_0 = ActionModule(tuple_0, str_0, bytes_0, tuple_0, bool_0, tuple_0)
    str_1 = 'r\x9c\x0b\xb2\x1d\x1f)\x8c\x17d\xf6\x95\xf8\x8c\xdb\xc5\xaa\xac\x81\x80\xb3\x9d\x9e\x99&\xed.'
   

# Generated at 2022-06-25 07:42:08.357132
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_1 = ()

# Generated at 2022-06-25 07:42:18.009007
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print(ActionModule.run.__doc__)
    tuple_1 = ()
    str_1 = '$'
    bytes_1 = b'\x9e\x99&\xed.'
    bool_1 = True
    action_module_1 = ActionModule(tuple_1, str_1, bytes_1, tuple_1, bool_1, tuple_1)
    str_2 = '$'
    str_3 = '='
    bytes_2 = b'\x9e\x99&\xed.'
    bool_2 = True
    str_4 = '{}'
    str_5 = '.n'
    str_6 = '\x10'
    str_7 = '\x18'
    str_8 = '\x0e'

# Generated at 2022-06-25 07:42:28.371861
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Assigning tuple to 'tuple_0' (line 106)
    tuple_0 = ()
    # Assigning str to 'str_0' (line 107)
    str_0 = '$'
    # Assigning bytes to 'bytes_0' (line 108)
    bytes_0 = b'\x9e\x99&\xed.'
    # Assigning tuple to 'tuple_1' (line 109)
    tuple_1 = ()
    # Assigning bool to 'bool_0' (line 110)
    bool_0 = True
    # Assigning tuple to 'tuple_2' (line 111)
    tuple_2 = ()
    # Calling __init__(args, kwargs) (line 105)
    #__init__(args, kwargs)

# Generated at 2022-06-25 07:42:35.761948
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tuple_0 = ()
    str_0 = ''
    bytes_0 = b'\xdc\x16\x0b&O\xa7\x9d\x1e\xab'
    tuple_1 = ()
    bool_0 = True
    tuple_2 = ()
    action_module_0 = ActionModule(tuple_0, str_0, bytes_0, tuple_1, bool_0, tuple_2)
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_2['data'] = dict_1
    dict_0['ansible_stats'] = dict_2
    dict_0['changed'] = True
    dict_0['msg'] = ''
    dict_3 = dict()
    dict_3['per_host'] = False
    dict

# Generated at 2022-06-25 07:42:45.732318
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    str_0 = '5-i\xfd\xef'
    bytes_0 = b'\x9e\x99&\xed.'
    bool_0 = True
    action_module_0 = ActionModule(tuple_0, str_0, bytes_0, tuple_0, bool_0, tuple_0)
    str_1 = '~\xab\x08\x9c'
    dict_0 = dict()
    dict_0['\xbbE\xdf\x0bx'] = 'Wr\x8b\x87\x0e\x04\x8a\xe2\x0f'

# Generated at 2022-06-25 07:42:52.953083
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tuple_0 = ()
    str_0 = '\xfc\x01\xc9'
    bytes_0 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    dict_0 = dict()
    dict_1 = dict()

# Generated at 2022-06-25 07:42:54.436683
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:43:01.260839
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = ActionModule()
    # TODO: [rb] run()


# Generated at 2022-06-25 07:43:09.895214
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = (((('ANSIBLE_HOST_KEY_CHECKING', 'False'),),),)
    var_1 = (((('ANSIBLE_HOST_KEY_CHECKING', 'False'),),),)
    var_2 = (((('ANSIBLE_HOST_KEY_CHECKING', 'False'),),),)
    var_3 = (((('ANSIBLE_HOST_KEY_CHECKING', 'False'),),),)
    var_4 = (((('ANSIBLE_HOST_KEY_CHECKING', 'False'),),),)
    var_5 = (((('ANSIBLE_HOST_KEY_CHECKING', 'False'),),),)
    var_6 = (((('ANSIBLE_HOST_KEY_CHECKING', 'False'),),),)

# Generated at 2022-06-25 07:43:10.962502
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # pass: True
    # fail: False
    assert True



# Generated at 2022-06-25 07:43:12.509822
# Unit test for constructor of class ActionModule
def test_ActionModule():
    fixture = ActionModule()
    return fixture


# Generated at 2022-06-25 07:43:13.701115
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.run()

# Generated at 2022-06-25 07:43:14.699688
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule()


# Generated at 2022-06-25 07:43:17.544544
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    return (action_module)


# Generated at 2022-06-25 07:43:18.745533
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    return action_module


# Generated at 2022-06-25 07:43:20.232608
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert str(type(var_0)) == "<class 'ansible.plugins.action.ActionModule'>"

# Generated at 2022-06-25 07:43:25.004650
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args = dict()
    kwargs = dict()
    # set up object
    obj = ActionModule(args, kwargs)
    # set up parameters and execute the run method
    result = obj.run()
    assert result == None, "Expected None, but got: %s" % repr(result)
# end of test_ActionModule_run

# Generated at 2022-06-25 07:43:36.602755
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "Q:Ge(ennl6gB6pC'R"
    set_0 = {str_0, str_0}
    int_0 = 6
    dict_0 = {str_0: set_0}
    float_0 = -1350.693319
    int_1 = 1864
    # Call constructor
    action_module_0 = ActionModule(str_0, set_0, int_0, dict_0, float_0, int_1)
    print("Executing ActionModule constructor")


# Generated at 2022-06-25 07:43:40.796607
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "Q:Ge(ennl6gB6pC'R"
    set_0 = {str_0, str_0}
    int_0 = 6
    dict_0 = {str_0: set_0}
    float_0 = -1350.693319
    int_1 = 1864
    action_module_0 = ActionModule(str_0, set_0, int_0, dict_0, float_0, int_1)


# Generated at 2022-06-25 07:43:48.059223
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "Q:Ge(ennl6gB6pC'R"
    set_0 = {str_0, str_0}
    int_0 = 6
    dict_0 = {str_0: set_0}
    float_0 = -1350.693319
    int_1 = 1864
    action_module_0 = ActionModule(str_0, set_0, int_0, dict_0, float_0, int_1)
    var_0 = action_run()

# Generated at 2022-06-25 07:43:48.816361
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()



# Generated at 2022-06-25 07:43:52.518270
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "l"
    set_0 = {str_0, str_0}
    int_0 = 6
    dict_0 = {str_0: set_0}
    float_0 = -1350.693319
    int_1 = 1864
    action_module_0 = ActionModule(str_0, set_0, int_0, dict_0, float_0, int_1)
    var_0 = action_module_0.run()
    assert isinstance(var_0, dict)
    assert var_0['msg'] == "An unexpected error occurred while running the module"

# Generated at 2022-06-25 07:44:01.660865
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "p8oE!S{h$[Z]%@koIz$`}4'^`=Yyw<&+_)pJ-S]H)~{!+:!TPA9XFt~,]JY@#n#%cBxeyNiQs(s*#nq"
    set_0 = {str_0, str_0}
    int_0 = -90
    dict_0 = {str_0: set_0}
    float_0 = -5086.444444444444
    int_1 = 1656
    assert isinstance(type(ActionModule(str_0, set_0, int_0, dict_0, float_0, int_1)))

# Generated at 2022-06-25 07:44:05.495336
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    print(action_module_0)



# Generated at 2022-06-25 07:44:12.729931
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "Kj(&A8S+~13(J"
    set_0 = {str_0, str_0}
    int_0 = 4
    dict_0 = {str_0: set_0}
    float_0 = 3.2174
    int_1 = -718
    action_module_0 = ActionModule(str_0, set_0, int_0, dict_0, float_0, int_1)


# Generated at 2022-06-25 07:44:18.406866
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "Q:Ge(ennl6gB6pC'R"
    set_0 = {str_0, str_0}
    int_0 = 6
    dict_0 = {str_0: set_0}
    float_0 = -1350.693319
    int_1 = 1864
    action_module_0 = ActionModule(str_0, set_0, int_0, dict_0, float_0, int_1)
    var_0 = action_run()

# Generated at 2022-06-25 07:44:25.322970
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = ''
    set_0 = {str_0}
    int_0 = 0
    dict_0 = {}
    float_0 = 0.0
    int_1 = 0
    action_module_0 = ActionModule(str_0, set_0, int_0, dict_0, float_0, int_1)

    dict_1 = {}
    dict_1['data'] = {}
    dict_1['per_host'] = False
    dict_1['aggregate'] = True
    dict_1['data']['foo'] = 'bar'

    var_0 = action_run(dict_1)

# Generated at 2022-06-25 07:44:42.199505
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Local variable init section
    str_0 = "Q:Ge(ennl6gB6pC'R"
    set_0 = {str_0, str_0}
    int_0 = 6
    dict_0 = {str_0: set_0}
    float_0 = -1350.693319
    int_1 = 1864
    action_module_0 = ActionModule(str_0, set_0, int_0, dict_0, float_0, int_1)
    object_0 = {}

    # Local variable section
    str_0 = "Q:Ge(ennl6gB6pC'R"

    # Calling method run of object action_module_0 with arguments object_0
    var_0 = action_module_0.run(object_0)

# Generated at 2022-06-25 07:44:45.587143
# Unit test for constructor of class ActionModule
def test_ActionModule():
	assert True


# Generated at 2022-06-25 07:44:46.978940
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    action_module_0.run()


# Generated at 2022-06-25 07:44:53.122006
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up test environment
    str_0 = "Q:Ge(ennl6gB6pC'R"
    set_0 = {str_0, str_0}
    int_0 = 6
    dict_0 = {str_0: set_0}
    float_0 = -1350.693319
    int_1 = 1864
    action_module_0 = ActionModule(str_0, set_0, int_0, dict_0, float_0, int_1)
    tmp_0 = None
    task_vars_0 = None
    # Invoke method
    var_0 = ActionModule.run(action_module_0, tmp_0, task_vars_0)
    # Assert return type
    assert isinstance(var_0, dict)
    # Assert return value


# Generated at 2022-06-25 07:44:55.092056
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()



# Generated at 2022-06-25 07:45:05.218034
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "Q:Ge(ennl6gB6pC'R"
    set_0 = {str_0, str_0}
    int_0 = 6
    dict_0 = {str_0: set_0}
    float_0 = -1350.693319
    int_1 = 1864
    action_module_0 = ActionModule(str_0, set_0, int_0, dict_0, float_0, int_1)
    list_0 = list({str_0, str_0})
    str_1 = "Ure(0U6,i'ZaM"
    float_1 = -1892.0
    dict_1 = {str_1: float_1}
    tuple_0 = (set_0, list_0, dict_1)
    list_

# Generated at 2022-06-25 07:45:06.021904
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print(ActionModule.run())

# Generated at 2022-06-25 07:45:08.462388
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set param
    task_vars = {}
    # Instance to test
    action_module = ActionModule(task_vars=task_vars)
    # Execute the run function
    action_module.run()

# Generated at 2022-06-25 07:45:15.946722
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Testing constructor of class ActionModule')
    str_0 = "Q:Ge(ennl6gB6pC'R"
    set_0 = {str_0, str_0}
    int_0 = 6
    dict_0 = {str_0: set_0}
    float_0 = -1350.693319
    int_1 = 1864
    action_module_0 = ActionModule(str_0, set_0, int_0, dict_0, float_0, int_1)
    var_0 = action_run()



# Generated at 2022-06-25 07:45:24.638621
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "Q:Ge(ennl6gB6pC'R"
    set_0 = {str_0, str_0}
    int_0 = 6
    dict_0 = {str_0: set_0}
    float_0 = -1350.693319
    int_1 = 1864
    action_module_0 = ActionModule(str_0, set_0, int_0, dict_0, float_0, int_1)
    # print(action_module_0)


# Generated at 2022-06-25 07:45:50.431062
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert(isinstance(ActionModule().run(), dict))


# Generated at 2022-06-25 07:46:01.084056
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "W8K'il;*A,f"
    set_0 = {str_0}
    int_0 = 6
    dict_0 = {str_0: set_0}
    float_0 = -1485.577143
    int_1 = 1783
    action_module_0 = ActionModule(str_0, set_0, int_0, dict_0, float_0, int_1)
    var_0 = action_module_0._transform_name(str_0)
    var_1 = action_module_0._load_tmp_path('tmp', str_0)
    var_2 = action_module_0.display.display(str_0)
    var_3 = action_module_0.display.deprecated(str_0, str_0)
    var_4

# Generated at 2022-06-25 07:46:07.207725
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "O8-q'ZI93e5/5B"
    set_0 = {str_0, str_0}
    float_0 = 0.65422984606
    dict_0 = {str_0: set_0}
    int_0 = 6
    int_1 = 1864
    action_module_0 = ActionModule(str_0, set_0, int_0, dict_0, float_0, int_1)
    action_module_0.run()


# Generated at 2022-06-25 07:46:10.804814
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    first_param_0 = None
    second_param_0 = None
    action_module_0 = ActionModule(first_param_0, second_param_0)
    res_0 = action_module_0.run(None, None)
    assert (res_0["ansible_stats"] == {"data": {}, "per_host": False, "aggregate": True})

# Generated at 2022-06-25 07:46:16.091327
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "k3qr\x12+\u0ac2?\x7f\x19"
    set_0 = {str_0, str_0}
    int_0 = 6
    dict_0 = {str_0: set_0}
    float_0 = -1286.620319
    int_1 = 1614
    action_module_0 = ActionModule(str_0, set_0, int_0, dict_0, float_0, int_1)


# Generated at 2022-06-25 07:46:16.813805
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 07:46:19.006006
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:46:29.944037
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "X5qFE4F4_Gj=m2B*(#?+MZS8gR<tg^5#5@BX~qy+8n$K(wB_H,_J:tK%^t+W,!JBF[*nyXjKvF8+zWwJ@,?h*aNPe-7p<"
    set_0 = {str_0, str_0}
    int_0 = 201
    dict_0 = {str_0: set_0}
    float_0 = -1350.693319
    int_1 = 1864
    action_module_0 = ActionModule(str_0, set_0, int_0, dict_0, float_0, int_1)


# Generated at 2022-06-25 07:46:31.668908
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert_raises(None, ActionModule.run, {}, {}, {}, {})


# Generated at 2022-06-25 07:46:40.769333
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "P:Ky(uX7VIGh%c"
    set_0 = {str_0, str_0}
    int_0 = 6
    dict_0 = {str_0: set_0}
    float_0 = -45.5
    int_1 = 1864
    test_ActionModule_0 = ActionModule(str_0, set_0, int_0, dict_0, float_0, int_1)
    assert test_ActionModule_0.fail_json_d
    assert test_ActionModule_0._result['ansible_facts'] == {}
    assert test_ActionModule_0.run() == {}
    assert test_ActionModule_0.strip_comments_after_shebang
    assert test_ActionModule_0.no_log_values == []
    assert test_Action

# Generated at 2022-06-25 07:47:24.466584
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    arg_0 = None
    arg_1 = None
    var_0 = action_run(arg_0, arg_1)

# Generated at 2022-06-25 07:47:34.722598
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "8>v:NzI7ZuBtl]sB8;#ilbQ^ix7Y<T\T|d8Vv1O>p.ZD~&H^O%"
    set_0 = set()
    int_0 = -1
    dict_0 = {}
    float_0 = -1611.175835
    int_1 = 61455
    action_module_0 = ActionModule(str_0, set_0, int_0, dict_0, float_0, int_1)

    # Default value
    assert action_module_0.default_args is None

    # Default value
    assert action_module_0.no_log is False

    # Default value
    assert action_module_0.minimum_ansible_version == '2.1'

   

# Generated at 2022-06-25 07:47:40.411545
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    action_module_0 = ActionModule(task_vars)
    tmp = None
    task_vars = None
    
    # Call method
    run(action_module_0, tmp, task_vars)

# Generated at 2022-06-25 07:47:42.584145
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except NameError:
        print("NameError")
    except IndexError:
        print("IndexError")
    except:
        print("SyntaxError")

# Generated at 2022-06-25 07:47:48.909245
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_0 = ActionModule(action_host, action_path, action_args, action_name, action_async, action_poll)
    tmp_0 = None
    task_vars_0 = None
    var_0 = module_0.run(tmp_0, task_vars_0)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 07:47:56.913342
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    stats = {'data': {}, 'per_host': False, 'aggregate': True}
    str_0 = "Q:Ge(ennl6gB6pC'R"
    set_0 = {str_0, str_0}
    int_0 = 6
    dict_0 = {str_0: set_0}
    float_0 = -1350.693319
    int_1 = 1864
    action_module_0 = ActionModule(str_0, set_0, int_0, dict_0, float_0, int_1)

    # Test

    marks_0 = add_marks(stats, 'data')
    stats['data'] = marks_0

    marks_1 = add_marks(stats['data'], 'per_host')

# Generated at 2022-06-25 07:48:02.733161
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "pI-LnS]Jp"
    set_0 = {str_0, str_0}
    int_0 = 6
    dict_0 = {str_0: set_0}
    float_0 = -27.861628
    int_1 = 1864
    action_module_0 = ActionModule(str_0, set_0, int_0, dict_0, float_0, int_1)


# Generated at 2022-06-25 07:48:16.216585
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "Q:Ge(ennl6gB6pC'R"
    set_0 = {str_0, str_0}
    int_0 = 6
    dict_0 = {str_0: set_0}
    float_0 = -1350.693319
    int_1 = 1864
    action_module_0 = ActionModule(str_0, set_0, int_0, dict_0, float_0, int_1)
    tmp = None
    task_vars = None
    content_0 = {action_module_0.run(tmp, task_vars)}
    for str_2 in content_0:
        print(str_2)
    exit(0)

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 07:48:17.454706
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule, object)


# Generated at 2022-06-25 07:48:24.284146
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = frozenset({'_c,8=g', 'kZ^K\'v@Hx,\J', '*fxYdX_:D'})
    dict_0 = {'0\':': set_0}
    int_0 = -81
    int_1 = 33
    str_0 = '6'
    action_module_0 = ActionModule(set_0, dict_0, int_0, int_1, str_0)
    result = action_module_0.run()
    assert result == 'nX9fs4|n(>'
    assert result == '%zI7nk/R!u'


# Generated at 2022-06-25 07:50:14.809703
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {'data': {}, 'per_host': False, 'aggregate': True}
    str_0 = "Q:Ge(ennl6gB6pC'R"
    int_0 = 6
    var_0 = action_run(str_0, dict_0)

# Generated at 2022-06-25 07:50:15.402816
# Unit test for constructor of class ActionModule
def test_ActionModule():
    do_test()


# Generated at 2022-06-25 07:50:18.847353
# Unit test for constructor of class ActionModule
def test_ActionModule():
    if not True:
        print('Invalid number of arguments:')
        print('  - expected minimum 5 and maximum 6')
        print('  - got 6')
        print(str_0)


# Generated at 2022-06-25 07:50:23.897323
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = "CDfH9^vF[-L(MgA$f@"
    set_0 = {str_0, str_0}
    int_0 = 6
    dict_0 = {str_0: set_0}
    float_0 = -1350.693319
    int_1 = 1864
    action_module_0 = ActionModule(str_0, set_0, int_0, dict_0, float_0, int_1)
    var_0 = action_run(action_module_0)
    return var_0


# Generated at 2022-06-25 07:50:31.261649
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "Q:Ge(ennl6gB6pC'R"
    set_0 = {str_0, str_0}
    int_0 = 6
    dict_0 = {str_0: set_0}
    float_0 = -1350.693319
    int_1 = 1864
    action_module_0 = ActionModule(str_0, set_0, int_0, dict_0, float_0, int_1)
    action_run(action_module_0)


# Generated at 2022-06-25 07:50:34.781385
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()



# Generated at 2022-06-25 07:50:39.570338
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("test_ActionModule")
    str_0 = "Q:Ge(ennl6gB6pC'R"
    set_0 = {str_0, str_0}
    int_0 = 6
    dict_0 = {str_0: set_0}
    float_0 = -1350.693319
    int_1 = 1864
    action_module_0 = ActionModule(str_0, set_0, int_0, dict_0, float_0, int_1)
    print(type(action_module_0))


# Generated at 2022-06-25 07:50:47.386576
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # test the constructor
    set_0 = {'le[iY', 'a5ªc^lC@S'}
    dict_0 = {'{!4Qe1Vw*': set_0}
    float_0 = -1536.332783
    action_module_0 = ActionModule('>|*A^Gtóh', set_0, 16, dict_0, float_0, 1076)

if __name__ == "__main__":

    # test constructor of class ActionModule
    test_ActionModule()

# Generated at 2022-06-25 07:50:51.565070
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "Q:Ge(ennl6gB6pC'R"
    set_0 = {str_0, str_0}
    int_0 = 6
    dict_0 = {str_0: set_0}
    float_0 = -1350.693319
    int_1 = 1864
    try:
        action_module_0 = ActionModule(str_0, set_0, int_0, dict_0, float_0, int_1)
    except Exception as e:
        print(e)


# Generated at 2022-06-25 07:51:00.262040
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "Q:Ge(ennl6gB6pC'R"
    set_0 = {str_0, str_0}
    int_0 = 6
    dict_0 = {str_0: set_0}
    float_0 = -1350.693319
    int_1 = 1864
    action_module_0 = ActionModule(str_0, set_0, int_0, dict_0, float_0, int_1)
    assert isinstance(action_module_0, ActionModule)

# def test():
#     print("Running module test")
#     assert action_module_0.run() == False
#     print("module test successful")
#     assert action_module_0.run() == True
#     print("module test successful")

# Run
#test()