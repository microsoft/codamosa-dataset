

# Generated at 2022-06-25 07:41:48.302436
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bytes_0 = b''
    list_0 = [bytes_0, bytes_0, bytes_0, bytes_0]
    str_0 = 'Aoy,\\vBN%/LUM\r5'
    set_0 = {str_0, list_0, list_0}

    # Interface test
    instance = ActionModule(None)
    assert isinstance(instance.run(), dict)

    # Basic test
    instance = ActionModule(None)
    assert instance.run() == {'ansible_stats': {'aggregate': True, 'per_host': False, 'data': {}}, 'changed': False}

    # Basic test
    instance = ActionModule(None)

# Generated at 2022-06-25 07:41:49.701900
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  # TODO: implement unit test for run
  pass

# Generated at 2022-06-25 07:41:55.915891
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:41:59.820589
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Testing constructor of class ActionModule
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 07:42:09.264849
# Unit test for constructor of class ActionModule
def test_ActionModule():
    results = []
    uid = '{}-{}-{}'.format('result', 'default', 'f5d5b5a5b5a5a5f5')
    task_vars = {'ansible_check_mode': False, 'ansible_no_log': False, 'ansible_play_hosts': ['xgfdsffsdfsdsfdsf'], 'ansible_task_name': 'f5d5b5a5b5a5a5f5', 'ansible_verbosity': 0, 'no_log': False, 'results': results, 'server_id': '', 'skip_conditions': []}

    assert test_case_0() == 'test_case_0'

test_ActionModule()

# Generated at 2022-06-25 07:42:10.182378
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Testing run')
    ActionModule.run()


# Generated at 2022-06-25 07:42:18.281001
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:42:20.783605
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = dict()
    dict_0['data'] = dict_0

    obj_0 = ActionModule(dict_0)
    obj_0.run(None, None)

    obj_1 = ActionModule(dict_0)
    obj_1.run(dict_0, dict() is dict())
    
    dict_0['data']['per_host'] = False
    
    obj_2 = ActionModule(dict_0)
    obj_2.run(dict_0, dict() is dict_0)

# Generated at 2022-06-25 07:42:30.053417
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    arg_config = {'file': '06', 'path': 'val_0', 'role': 'val_1', 'vars': 'path', 'include': 'fqdn'}
    arg_tmp = 'str_0'
    arg_task_vars = {'hostname': 'hostname', 'group_names': ['group_names', 'group_names'], 'inventory_hostname': 'inventory_hostname', 'inventory_dir': 'inventory_dir', 'play_hosts': 'play_hosts', 'playbook_dir': 'playbook_dir', 'groups': {'k':'v'}, 'play_hosts_all': 'play_hosts_all', 'playbook_file': 'playbook_file', '_raw_params': '_raw_params'}

# Generated at 2022-06-25 07:42:36.792523
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    list_0 = ['Iw&<2', b'l%0,f\xc9\x1f', 'AI', 'Iw&<2', 'AI', 'AI', ('',), ('',), ('',), ('',)]
    list_1 = [list_0, b'']
    list_2 = [list_1, '', 'AI']
    tuple_0 = (b'', list_0, 'AI', 'Iw&<2', b'', list_2, 'AI')
    dict_0 = {}
    set_0 = {'Iw&<2', list_2}
    set_1 = {tuple_0}
    set_2 = {'Iw&<2'}
    set_3 = {list_0, tuple_0}

# Generated at 2022-06-25 07:42:43.790649
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    ansible_stats = {}
    ansible_stats = action_module_0.run()


if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-25 07:42:50.089450
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # set up test values
    tmp = ''
    task_vars = {}

    expected = {}
    expected['failed'] = False
    expected['changed'] = False
    expected['ansible_stats'] = {}

    # execute the run() method
    actual = run(tmp, task_vars)

    print(actual)

    # verify the results
    # assert(actual == expected)

# Generated at 2022-06-25 07:42:57.768251
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    str_0 = "'sj9+\x0c^|],= "
    int_0 = 2974
    bytes_0 = b''
    tuple_0 = (bytes_0,)
    bool_1 = False
    action_module_0 = ActionModule(bool_0, dict_0, str_0, int_0, tuple_0, bool_1)
    return True

# Generated at 2022-06-25 07:43:06.207020
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    str_0 = "'sj9+\x0c^|],= "
    int_0 = 2974
    bytes_0 = b''
    tuple_0 = (bytes_0,)
    bool_1 = False
    action_module_0 = ActionModule(bool_0, dict_0, str_0, int_0, tuple_0, bool_1)

    # test for var_0 = action_module_0.run(tmp = None, task_vars = None)
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 07:43:13.407468
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    str_0 = 'y|r(d\xe7'
    int_0 = 9476
    bytes_0 = b''
    tuple_0 = (bytes_0,)
    bool_1 = False
    action_module_0 = ActionModule(bool_0, dict_0, str_0, int_0, tuple_0, bool_1)
    var_0 = action_run()

if __name__ == '__main__':
    run_common_tests()
    test_ActionModule_run()

# Generated at 2022-06-25 07:43:20.906911
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Test of constructor ActionModule')
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    str_0 = "'sj9+\x0c^|],= "
    int_0 = 2974
    bytes_0 = b''
    tuple_0 = (bytes_0,)
    bool_1 = False
    action_module_0 = ActionModule(bool_0, dict_0, str_0, int_0, tuple_0, bool_1)
    var_0 = action_run()


# Generated at 2022-06-25 07:43:28.206007
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    dict_0 = {bool_0: bool_0}
    str_0 = 'hQU@$#Z5B5`'
    int_0 = 996
    bytes_0 = b''
    tuple_0 = (bytes_0,)
    bool_1 = True
    action_module_0 = ActionModule(bool_0, dict_0, str_0, int_0, tuple_0, bool_1)
    dict_0 = {}
    test_case_0(dict_0, action_module_0)
    dict_0 = {}
    test_case_0(dict_0, action_module_0)



# Generated at 2022-06-25 07:43:31.097003
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        __init__()
        return True
    except:
        return False


# Generated at 2022-06-25 07:43:39.413010
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    dict_0 = {int_0: bool_0, bool_0: bytes_0, bool_0: bool_0, bool_0: bytes_0, bool_0: bool_0, bool_0: bytes_0, bool_0: bool_0, bool_0: bytes_0}
    str_0 = ":hb~\x10\x00\x00\x00\x00\x0c49\xa1\x0c\x0c\x02\x02\x02"
    int_0 = 2433
    bytes_0 = b'\x15\x03\x11\x11\x10\x02\x17\x11\x00\x0b\x16\x03\x04'
    tuple_0 = (bool_0,)
   

# Generated at 2022-06-25 07:43:49.709311
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #bool_0 = True
    #dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    #str_0 = "*h\x1aB\x1c\nF\x1d\x1d"
    #int_0 = 792
    #bytes_0 = b''
    #tuple_0 = (bytes_0,)
    #bool_1 = True
    #action_module_0 = ActionModule(bool_0, dict_0, str_0, int_0, tuple_0, bool_1)
    #assert action_module_0.run() == None
    pass



# Generated at 2022-06-25 07:44:04.388277
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    str_0 = "'sj9+\x0c^|],= "
    int_0 = 2974
    bytes_0 = b''
    tuple_0 = (bytes_0,)
    bool_1 = False
    action_module_0 = ActionModule(bool_0, dict_0, str_0, int_0, tuple_0, bool_1)

# Generated at 2022-06-25 07:44:12.933199
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    str_0 = "'sj9+\x0c^|],= "
    int_0 = 2974
    bytes_0 = b''
    tuple_0 = (bytes_0,)
    # Error: Unable to find any applicable overload for 'ActionModule'
    #action_module_0 = ActionModule(bool_0, dict_0, str_0, int_0, tuple_0, tuple_0)


# Generated at 2022-06-25 07:44:14.226781
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 07:44:21.521834
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    import tempfile
    import shutil
    import json

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # create a text file 'test.yml'
    yaml_file = os.path.join(tmpdir, 'test.yml')
    with open(yaml_file, 'w') as yaml:
        json.dump({'tasks': [{'name': 'foo', 'action': 'add_host', 'args': {'name': 'localhost'}}]}, yaml)
    yaml.close()

    # create a text file 'test.j2'
    j2_file = os.path.join(tmpdir, 'test.j2')

# Generated at 2022-06-25 07:44:29.676858
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    str_0 = "'sj9+\x0c^|],= "
    int_0 = 2974
    bytes_0 = b''
    tuple_0 = (bytes_0,)
    bool_1 = False
    action_module_0 = ActionModule(bool_0, dict_0, str_0, int_0, tuple_0, bool_1)


# Generated at 2022-06-25 07:44:35.696538
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    str_0 = "}*<Ej)Gw/'D;.J_r"
    int_0 = 7600
    bytes_0 = b''
    tuple_0 = (bytes_0,)
    bool_1 = False
    action_module_0 = ActionModule(bool_0, dict_0, str_0, int_0, tuple_0, bool_1)
    var_0 = action_run()

# Generated at 2022-06-25 07:44:41.198521
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    str_0 = "'sj9+\x0c^|],= "
    int_0 = 2974
    bytes_0 = b''
    tuple_0 = (bytes_0,)
    bool_1 = False
    action_module_0 = ActionModule(bool_0, dict_0, str_0, int_0, tuple_0, bool_1)
    var_0 = action_run()

# Generated at 2022-06-25 07:44:47.051280
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Input parameters:
    tmp = null
    task_vars = null

    # Output parameters:
    result = null

    # Act:
    result = ActionModule_run(tmp, task_vars)
    
    assert result

    # Assert:
    assert result




# Generated at 2022-06-25 07:44:51.692198
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    str_0 = "'sj9+\x0c^|],= "
    int_0 = 2974
    bytes_0 = b''
    tuple_0 = (bytes_0,)
    bool_1 = False
    action_module_0 = ActionModule(bool_0, dict_0, str_0, int_0, tuple_0, bool_1)
    var_0 = action_run()


# Generated at 2022-06-25 07:44:54.218001
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True



# Generated at 2022-06-25 07:45:16.894122
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True is True

# Generated at 2022-06-25 07:45:27.727935
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    str_0 = "'sj9+\x0c^|],= "
    int_0 = 2974
    bytes_0 = b''
    tuple_0 = (bytes_0,)
    bool_1 = False
    action_module_0 = ActionModule(bool_0, dict_0, str_0, int_0, tuple_0, bool_1)
    assert action_module_0._VALID_ARGS.__contains__("aggregate")
    assert action_module_0._VALID_ARGS.__contains__("data")

# Generated at 2022-06-25 07:45:31.520871
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    dict_0 = {'data': {'1': 1, '2': 2, '3': 3, '4': 4}, 'per_host': True, 'aggregate': True}
    str_0 = "module_utils"
    int_0 = 169
    tuple_0 = ('\n', 'f', '_', ')')
    bool_1 = False
    action_module_0 = ActionModule(bool_0, dict_0, str_0, int_0, tuple_0, bool_1)
    var_0 = action_module_0.run()


# Generated at 2022-06-25 07:45:39.186612
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    str_0 = "'sj9+\x0c^|],= "
    int_0 = 2974
    bytes_0 = b''
    tuple_0 = (bytes_0,)
    bool_1 = False
    action_module_0 = ActionModule(bool_0, dict_0, str_0, int_0, tuple_0, bool_1)
    str_1 = "ansible_stats"
    var_0 = action_module_0.run()
    var_1 = var_0.get(str_1)

# Set to unit test only!
test_case_0()
test_ActionModule_run

# Generated at 2022-06-25 07:45:49.792705
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:45:50.861452
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(action_module_0)


# Generated at 2022-06-25 07:45:55.015734
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Testing run of class ActionModule')
    runner_facts_cacheable = True
    loader = None
    templar = None
    shared_loader_obj = None
    # Call method run of class ActionModule
    result = ActionModule.run(runner_facts_cacheable, loader, templar, shared_loader_obj)
    # Test if the execution of method run of class ActionModule raised any exceptions
    assert result == test_case_0()

test_ActionModule_run()

# Generated at 2022-06-25 07:45:59.339770
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = dict()
    dict_0 = {dict_0: dict_0, dict_0: dict_0}
    str_0 = "The 'data' option needs to be a dictionary/hash"
    int_1 = 0
    tuple_0 = ()
    bool_0 = True
    action_module_0 = ActionModule(bool_0, dict_0, str_0, int_1, tuple_0, bool_0)
    try:
        # TEST PASS
        #assert action_module_0.run() == {}
        print("pass")
    except AssertionError as exc:
        print("fail")


# Generated at 2022-06-25 07:46:08.226999
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = False
    dict_0 = {'a': bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    str_1 = "f^#t%c*o`xl'u<a\x12q3>\nw"
    int_0 = 1323
    tuple_0 = (False,)
    bool_1 = False
    action_module_0 = ActionModule(False, dict_0, str_1, int_0, tuple_0, bool_1)
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-25 07:46:13.481736
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Instantiate ActionModule class with args.
    action_module_0 = ActionModule()

    # Call run function of action_module_0.
    action_module_0.run()


# Generated at 2022-06-25 07:47:01.980305
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}

# Generated at 2022-06-25 07:47:06.121654
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  pass




# Generated at 2022-06-25 07:47:16.110945
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Unit test for method run of class ActionModule")
    data = False
    dict_0 = {data: data, data: data, data: data, data: data}
    str_0 = "\tI\x02\x18\x0e\x06\t"
    int_0 = 2892
    tuple_0 = (b'{K\x16',)
    var_1 = True
    action_module_0 = ActionModule(data, dict_0, str_0, int_0, tuple_0, var_1)
    var_1 = set_stats()
    action_module_0.set_stats(var_1)
    var_2 = action_run()
    print(var_2)


# Generated at 2022-06-25 07:47:16.817652
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    run()


# Generated at 2022-06-25 07:47:20.686538
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_1 = True
    dict_0 = {bool_1: bool_1, bool_1: bool_1, bool_1: bool_1, bool_1: bool_1}
    str_0 = "'sj9+\x0c^|],= "
    int_0 = 2974
    bytes_2 = b''
    tuple_2 = (bytes_2,)
    bool_0 = False
    action_module_4 = ActionModule(bool_1, dict_0, str_0, int_0, tuple_2, bool_0)


# Generated at 2022-06-25 07:47:26.612485
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    str_0 = "'sj9+\x0c^|],= "
    int_0 = 2974
    bytes_0 = b''
    tuple_0 = (bytes_0,)
    bool_1 = False
    action_module_0 = ActionModule(bool_0, dict_0, str_0, int_0, tuple_0, bool_1)
    assert (action_module_0._task is bool_0)
    assert (action_module_0._play_context is dict_0)
    assert (action_module_0._loader is str_0)

# Generated at 2022-06-25 07:47:31.439857
# Unit test for constructor of class ActionModule
def test_ActionModule():
  bool_0 = False
  dict_0 = {}
  int_0 = -892
  bytes_0 = b'\x0e'
  tuple_0 = (bytes_0,)
  bool_1 = False
  str_0 = 'b"\x1e'
  action_module_0 = ActionModule(bool_0, dict_0, str_0, int_0, tuple_0, bool_1)
  assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:47:36.215255
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Check instance success
    if action_module_0.run():
        print('Success')
    else:
        print('Failure')

# Generated at 2022-06-25 07:47:40.492784
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # param 0 is instance of class ActionModule
    param_0 = test_case_0()


# Generated at 2022-06-25 07:47:41.030524
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-25 07:49:16.642647
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    dict_0 = {False: False, False: False, False: False, False: False}
    str_0 = "'\t.\x1c:yFn\x17\x04"
    int_0 = 2197
    bytes_0 = b'\x7f'
    tuple_0 = (bytes_0, None, None, None)
    bool_1 = True
    action_module_0 = ActionModule(bool_0, dict_0, str_0, int_0, tuple_0, bool_1)
    s_0 = action_module_0.get_val()
    assert len(s_0) == 0


# Generated at 2022-06-25 07:49:22.018635
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    str_0 = "'sj9+\x0c^|],= "
    int_0 = 2974
    bytes_0 = b''
    tuple_0 = (bytes_0,)
    bool_1 = False
    action_module_0 = ActionModule(bool_0, dict_0, str_0, int_0, tuple_0, bool_1)
    assert action_module_0.connection_info == 'b\'\''
    assert action_module_0.display.backend == 'default'
    assert action_module_0.runner.templar.defaults == {}



# Generated at 2022-06-25 07:49:31.667721
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # if self._task.args:
    if self._task.args:
        # data = self._task.args.get('data', {})
        data = self._task.args.get('data', {})
        # if not isinstance(data, dict):
        if not isinstance(data, dict):
            # data = self._templar.template(data, convert_bare=False, fail_on_undefined=True)
            data = self._templar.template(data, convert_bare=False, fail_on_undefined=True)
        # if not isinstance(data, dict):
        if not isinstance(data, dict):
            # result['failed'] = True
            result['failed'] = True
            # result['msg'] = "The 'data' option needs to be a dictionary/hash"

# Generated at 2022-06-25 07:49:42.418011
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    str_0 = "jK'\x0c,\x16\x00\x1b"
    int_0 = 4605
    bytes_0 = b''
    tuple_0 = (bytes_0,)
    bool_1 = False
    action_module_0 = ActionModule(bool_0, dict_0, str_0, int_0, tuple_0, bool_1)
    assert action_module_0.__dict__ == dict_0
    assert action_module_0.__dict__ == dict_0


# Generated at 2022-06-25 07:49:44.591725
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    r = run()
    if (r):
        print("Test successful")
    else:
        print("Test unsuccessful")


# Generated at 2022-06-25 07:49:45.313690
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: write test
    pass

# Generated at 2022-06-25 07:49:46.421057
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # (self, tmp=None, task_vars=None):
    pass


# Generated at 2022-06-25 07:49:50.207110
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    str_0 = "'sj9+\x0c^|],= "
    int_0 = 2974
    bytes_0 = b''
    tuple_0 = (bytes_0,)
    bool_1 = False
    action_module_0 = ActionModule(bool_0, dict_0, str_0, int_0, tuple_0, bool_1)
    var_0 = action_module_0.run()

# Generated at 2022-06-25 07:49:52.174585
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = ActionModule()
    var_2 = ActionModule(var_1)

# Generated at 2022-06-25 07:50:02.037061
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp = None
    task_vars = None

    result = super(ActionModule, self).run(tmp, task_vars)
    del tmp  # tmp no longer has any effect

    stats = {'data': {}, 'per_host': False, 'aggregate': True}

    if self._task.args:
        data = self._task.args.get('data', {})

        if not isinstance(data, dict):
            data = self._templar.template(data, convert_bare=False, fail_on_undefined=True)

        if not isinstance(data, dict):
            result['failed'] = True
            result['msg'] = "The 'data' option needs to be a dictionary/hash"
            return result

        # set boolean options, defaults are set above in stats init