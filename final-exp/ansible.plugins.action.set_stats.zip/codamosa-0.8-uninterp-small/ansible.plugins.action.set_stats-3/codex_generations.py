

# Generated at 2022-06-25 07:41:46.638185
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xfa]\xa3\x17\xc4t\xe1\x16\x14\x0f\x02\xbb\x0f\x8c\xc4\xee\xd4\xb2\x8f\xa9'
    str_0 = 'iT'
    list_0 = ['>', 'H', 'G', '3', ')Xz']
    set_0 = {'sam3.5', '2.0.0', '3.5.7'}
    list_1 = ['3.5.7', '.7.0', '2.7']
    str_1 = '*^poge9'

# Generated at 2022-06-25 07:41:54.569521
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class Mock_run:
        def __init__(self):
            self.failed = None
            self.msg = None

        def run(self, tmp=None, task_vars=None):
            if task_vars is None:
                task_vars = dict()
            self.failed = False
            self.msg = 'action module passed.'
            return self

    yaml_str_0 = '\n'
    action_module_1 = ActionModule(yaml_str_0)
    action_module_1._task.args = dict()
    mock_run_0 = Mock_run()
    ansible_stats_1 = mock_run_0.run()
    assert (ansible_stats_1.failed == False)
    assert (ansible_stats_1.msg == 'action module passed.')

    y

# Generated at 2022-06-25 07:42:01.600758
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    UUID = '2fb51a00-cff0-46e9-bffd-a29b54649cef'
    module_name = 'command'
    module_args = "ls /tmp"
    task_vars = {
        'play_uuid': UUID,
        'ansible_play_hosts': [
            'a',
            'b'
        ],
        'ansible_play_hosts_all': [
            'a',
            'b',
            'c'
        ],
        'ansible_play_batch': [
            'a',
            'b'
        ],
        'ansible_play_batch_size': 2
    }
    templar = Templar(loader=None, variables=task_vars)

# Generated at 2022-06-25 07:42:10.012888
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xf0\xe6\x97\x81R\xbcs\x9fXXbU\x8a\xd5'
    bool_0 = True
    str_0 = 'RTW1F:c%'
    str_1 = 'D8x;h'
    bytes_1 = b'\x96'
    set_0 = {100.1, 100.1, 100.1, 0.0, 100.1, 100.1, 100.1}
    list_0 = [str_0, str_0, str_0, bytes_0, str_0, str_1, str_0, str_0]
    set_1 = set()
    float_0 = 0.0

# Generated at 2022-06-25 07:42:18.240938
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()
    test_case_23()
    test_case_24()

# Generated at 2022-06-25 07:42:26.097470
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xf0\xe6\x97\x81R\xbcs\x9fXXbU\x8a\xd5'
    str_0 = '#+%\\&M_0c]oa`@R26RFG'
    list_0 = [str_0, str_0, bytes_0, str_0]
    set_0 = None
    str_1 = 'tCSo4s'
    action_module_0 = ActionModule(bytes_0, str_0, list_0, set_0, list_0, str_1)


# Generated at 2022-06-25 07:42:33.145843
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xff\xfa0\xfa\x80\xf9\xcd\xfa\xb5\xfe1\x82\xe3\x8c\xfa\xc5\x9a\x8c'
    str_0 = '4ZkP'
    list_0 = [bytes_0, bytes_0, str_0, str_0]
    set_0 = set(list_0)
    dict_0 = dict()
    list_1 = [set_0, set_0, dict_0, dict_0]
    str_1 = 'ui6[MTU5JILUjK'
    set_1 = frozenset(list_1)
    dict_1 = dict()
    dict_1['data'] = str_0

# Generated at 2022-06-25 07:42:34.136574
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    action_module_0.run()

# Generated at 2022-06-25 07:42:35.545469
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp = None
    task_vars = None
    action_module_0 = ActionModule(tmp, task_vars)


# Generated at 2022-06-25 07:42:41.835055
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\xf0\xe6\x97\x81R\xbcs\x9fXXbU\x8a\xd5'
    str_0 = '#+%\\&M_0c]oa`@R26RFG'
    list_0 = [str_0, str_0, bytes_0, str_0]
    set_0 = None
    str_1 = 'tCSo4s'
    action_module_0 = ActionModule(bytes_0, str_0, list_0, set_0, list_0, str_1)
    action_module_0.run()

    # The following assertions are related to the class initialization
    assert action_module_0._task.args == None

# Generated at 2022-06-25 07:42:53.106201
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Test 'action_loader'
    # assert action_module_1.action_loader == action_loader_0
    pass

    # Test 'connection'
    # assert not hasattr(action_module_1, 'connection')

    # Test '_config_plugin_version'
    # assert action_module_1._config_plugin_version == '2'


# Generated at 2022-06-25 07:42:56.011745
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    tmp = None
    task_vars = None
    var = action_module.run(tmp, task_vars)
    assert var is None

# Generated at 2022-06-25 07:43:01.090096
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing constructor of class ActionModule")

    # Test 1
    print("Testing if result is an instance of dict")
    action_module_1 = ActionModule()
    var_1 = action_module_1.run()

    result_1 = isinstance(var_1, dict)
    assert result_1 is True
    print("Variable var_1 is an instance of dict = OK")


# Generated at 2022-06-25 07:43:03.815370
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock = MagicMock()
    mock.return_value = None
    with patch.dict(sys.modules, {'ActionBase': mock}):
      ActionModule_0 = ActionModule()
      ActionModule_0.run()
      ActionModule_0.run().assert_called_with()


# Generated at 2022-06-25 07:43:05.047028
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()



# Generated at 2022-06-25 07:43:12.918811
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:43:16.117553
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

    #---- test the method run ----
    run_result = action_module_0.run()
    assert False == run_result
    #---- end test of method run ----


# Generated at 2022-06-25 07:43:18.450293
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    var_0 = action_module_0.run()

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 07:43:19.932806
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    var_1 = action_run()


# Generated at 2022-06-25 07:43:28.882103
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up mock
    action_module_test_0 = ActionModule()
    action_module_test_0.action_service = mock.Mock()
    action_module_test_0.action_service.get_registered_var_providers = mock.Mock()
    action_module_test_0.action_service.get_registered_var_providers.return_value = {}
    var_0 = action_run()
    assert var_0 == {}

    # Mock AnsibleModule
    action_module_mock_0 = mock.MagicMock(name='ActionModule')
    action_module_test_0.action_loader = mock.Mock(name='ActionLoader')
    action_module_test_0.action_loader.get('_perform_module_operation', None).return_value = action_module_m

# Generated at 2022-06-25 07:43:41.041274
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # This test will pass if class constructor is defined
    action_module = ActionModule('task', 'play_context', 'loader', 'templar', 'shared_loader_obj', 'action_basedir')


# Generated at 2022-06-25 07:43:51.156726
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Make sure that no arguments were assigned to the ActionModule instance
    def test_ActionModule_instance():
        assert action_module_1.remote_name == 0

    # Make sure that the instance has the correct type
    def test_ActionModule_type():
        assert action_module_1.type == type(action_module_1)

    class ActionModule_0(ActionModule):
        def run(self, tmp, task_vars):
            return super(ActionModule_0, self).run(tmp, task_vars)

    str_0 = None
    bytes_0 = b'\x1f\x9f\xea\xe4CK\xac'
    set_0 = {
        bytes_0
    }
    bool_0 = True

# Generated at 2022-06-25 07:44:00.327073
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = {'data': 'C', 'per_host': True, 'aggregate': False}
    action_plugin = 'set_stats'
    task = {'action': action_plugin, 'args': task_vars}
    task_vars, templar = {}, {'test': 'test', 'test2': 'test2'}
    loader = {'test': 'test', 'test2': 'test2'}
    connection = 'test'
    play_context = {'test': 'test', 'test2': 'test2'}
    action_module_0 = ActionModule(task, connection, play_context, loader, templar)


# Generated at 2022-06-25 07:44:08.630077
# Unit test for constructor of class ActionModule
def test_ActionModule():
    for i in range(10):
        str_0 = None
        str_1 = None
        str_2 = None
        str_3 = None
        str_4 = None
        set_0 = {str_3, str_2, str_0, str_1, str_4}
        set_1 = set()
        ActionModule(str_0, set_0, bool, str_1, str_2, set_1)
        assert(False)


# Generated at 2022-06-25 07:44:10.583564
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    tmp_0 = None
    task_vars_0 = None
    action_module_1.run(tmp_0, task_vars_0)


# Generated at 2022-06-25 07:44:17.312289
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('\n')
    str_0 = "redhat"
    bytes_0 = b'\x00\x9f\xea\xe4CK\xac'
    set_0 = {bytes_0}
    bool_0 = True
    action_module_0 = ActionModule(bytes_0, set_0, bool_0, bytes_0, str_0, set_0)
    print('\n')


# Generated at 2022-06-25 07:44:24.486270
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bytes_0 = b'\x1a\x17\x9d\xdf\xb5\xeb\xc1\x95\xba'
    set_0 = {bytes_0}
    bool_0 = False
    str_0 = None
    action_module_0 = ActionModule(bytes_0, set_0, bool_0, bytes_0, str_0, set_0)
    action_module_0.run(str_0)
    # UNREACHABLE


# Generated at 2022-06-25 07:44:32.063980
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = None
    bytes_0 = b'\x1f\x9f\xea\xe4CK\xac'
    set_0 = {bytes_0}
    bool_0 = True
    action_module_0 = ActionModule(bytes_0, set_0, bool_0, bytes_0, str_0, set_0)


# Generated at 2022-06-25 07:44:40.317853
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = None
    bytes_0 = b'\x1f\x9f\xea\xe4CK\xac'
    set_0 = {bytes_0}
    bool_0 = True
    action_module_1 = ActionModule(bytes_0, set_0, bool_0, bytes_0, str_0, set_0)
    var_0 = action_run(str_0)
    if var_0:
        print("")
    else:
        print("")


# Generated at 2022-06-25 07:44:49.305024
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = dict()
    answer = dict()
    answer['failed'] = False
    answer['changed'] = False
    answer['ansible_stats'] = dict()
    answer['ansible_stats']['data'] = dict()
    answer['ansible_stats']['per_host'] = False
    answer['ansible_stats']['aggregate'] = True
    ActionModule_0 = ActionModule(tmp, task_vars)
    ActionModule_1 = ActionModule_0.run(tmp, task_vars)
    if ActionModule_1 == answer :
        return 1
    else:
        return 0


# Generated at 2022-06-25 07:45:11.111051
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = None
    bytes_0 = b'\x1f\x9f\xea\xe4CK\xac'
    set_0 = {bytes_0}
    bool_0 = True
    action_module_0 = ActionModule(bytes_0, set_0, bool_0, bytes_0, str_0, set_0)
    assert isinstance(action_module_0, ActionModule)
    del action_module_0
    # TODO: actually check for the classes that are returned

# Generated at 2022-06-25 07:45:20.604934
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 's0t8T_WZ%vT'
    set_0 = {'p\x1c\xb4\t\xc6t\x8b\x95\xeaM\x1e'}
    str_1 = 'S\xf4\x89\xc1\xf5"\x93\x9c'
    bytes_3 = b'\xd0\x10\xc6U\x0c$\xdb\x95\xe9\x9e\x0c\xe2\xda\xb0'
    bool_0 = True
    action_module_0 = ActionModule(str_0, set_0, bool_0, str_1, str_0, set_0)

# Generated at 2022-06-25 07:45:25.888575
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = '\U000a88c6'
    bytes_0 = b'\xd5\x96\x0b'
    set_0 = {bytes_0, str_0}
    bool_0 = False
    action_module_0 = ActionModule(bytes_0, set_0, bool_0, bytes_0, str_0, set_0)
    assert action_module_0._connection == 'network_cli'


# Generated at 2022-06-25 07:45:32.644453
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_0 = {'\x1f\x9f\xea\xe4CK\xac'}
    str_0 = None
    bytes_0 = b'\x1f\x9f\xea\xe4CK\xac'
    bool_0 = True
    action_module_0 = ActionModule(bytes_0, set_0, bool_0, bytes_0, str_0, set_0)
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:45:33.476487
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert [ActionBase, ActionModule]


# Generated at 2022-06-25 07:45:35.496100
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule("str_0", set("str_0"), False, "str_0", "str_0", set("str_0"))
    print(str(x))

set_0 = {test_case_0}

# Generated at 2022-06-25 07:45:39.531997
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = None
    bytes_0 = b'\x1f\x9f\xea\xe4CK\xac'
    set_0 = {bytes_0}
    bool_0 = True
    action_module_0 = ActionModule(bytes_0, set_0, bool_0, bytes_0, str_0, set_0)
    # assert action_module_0.__dict__ == {}


# Generated at 2022-06-25 07:45:45.130371
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = b"\x12\x9c\x0b\xdc\x3f\xfe\x8c\xc0"
    var_1 = {var_0}
    var_2 = True
    var_3 = bytes.fromhex("66")
    var_4 = None
    var_5 = {var_3}
    var_6 = ActionModule(var_0, var_1, var_2, var_3, var_4, var_5)
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = {var_7: var_8}
    var_11 = var_6.run(var_7, var_9)
    var_12 = var_11.get("ansible_stats")
    var_13 = var_

# Generated at 2022-06-25 07:45:51.521391
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    res = None
    arg0 = None
    arg1 = None
    arg2 = None
    arg3 = None
    arg4 = None
    arg5 = None
    arg6 = None
    arg7 = None
    arg8 = None
    arg9 = None
    arg10 = None
    arg11 = None
    arg12 = None
    arg13 = None
    arg14 = None
    arg15 = None
    arg16 = None
    arg17 = None
    arg18 = None

    am = ActionModule(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11, arg12, arg13, arg14, arg15,
                      arg16, arg17, arg18)
    res = am.run(arg0, arg1)

# Generated at 2022-06-25 07:45:59.697067
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = None
    bytes_0 = b'\x1f\x9f\xea\xe4CK\xac'
    set_0 = {bytes_0}
    bool_0 = True
    action_module_0 = ActionModule(bytes_0, set_0, bool_0, bytes_0, str_0, set_0)

if __name__ == '__main__':
    import sys
    import pytest

    pytest.main(sys.argv[1:])

# Generated at 2022-06-25 07:46:33.040705
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = None
    bytes_0 = b'\x1f\x9f\xea\xe4CK\xac'
    set_0 = {bytes_0}
    bool_0 = True
    action_module_0 = ActionModule(bytes_0, set_0, bool_0, bytes_0, str_0, set_0)
    assert isinstance(action_module_0, ActionModule)
    assert action_module_0.TRANSFERS_FILES is False


# Generated at 2022-06-25 07:46:38.607711
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_1 = None
    bytes_1 = b'\x1f\x9f\xea\xe4CK\xac'
    set_1 = {bytes_1}
    bool_1 = True
    action_module_1 = ActionModule(bytes_1, set_1, bool_1, bytes_1, str_1, set_1)
    return_value = action_module_1.run()
    return return_value


# Generated at 2022-06-25 07:46:41.849215
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = None
    bytes_0 = b'\x1f\x9f\xea\xe4CK\xac'
    set_0 = {bytes_0}
    bool_0 = True
    action_module_0 = ActionModule(bytes_0, set_0, bool_0, bytes_0, str_0, set_0)
    var_0 = action_run(str_0)

# Generated at 2022-06-25 07:46:48.850686
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = None
    bytes_0 = b'\x1f\x9f\xea\xe4CK\xac'
    set_0 = {bytes_0}
    bool_0 = True
    action_module_0 = ActionModule(bytes_0, set_0, bool_0, bytes_0, str_0, set_0)
    assert isinstance(action_module_0, ActionModule)



# Generated at 2022-06-25 07:46:54.064623
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test for the case where there is no arguments
    str_1 = None
    bytes_1 = b'\x1f\x9f\xeac\x9a\xdb'
    set_1 = {bytes_1}
    bool_1 = False
    action_module_1 = ActionModule(bytes_1, set_1, bool_1, bytes_1, str_1, set_1)
    var_1 = action_run(str_1)
    # TODO: Fix the return value!!


# Generated at 2022-06-25 07:46:59.503965
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = None
    bytes_0 = b'\x1f\x9f\xea\xe4CK\xac'
    set_0 = {bytes_0}
    bool_0 = True
    action_module_0 = ActionModule(bytes_0, set_0, bool_0, bytes_0, str_0, set_0)
    assert isinstance(action_module_0, ActionModule)
    assert isinstance(action_module_0, ActionBase)


# Generated at 2022-06-25 07:47:03.721394
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = None
    bytes_0 = b'\x03iC\xdf\xb8'
    set_0 = {bytes_0}
    bool_0 = True
    action_module_0 = ActionModule(bytes_0, set_0, bool_0, bytes_0, str_0, set_0)
    var_0 = action_run(str_0)


# Generated at 2022-06-25 07:47:11.688726
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    var_0 = action_module_0.run()
    stats = {'data': {}, 'per_host': False, 'aggregate': True}
# parse stats options
    data = action_module_0.args.get('data', {})
    data = str(data)
    action_module_0.template(data, convert_bare=False, fail_on_undefined=True)
    if action_module_0.type(data) is not dict:
        action_module_0.failed = True
        action_module_0.msg = "The 'data' option needs to be a dictionary/hash"
        action_module_0.run()


# Generated at 2022-06-25 07:47:13.683813
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    action_module_0.run()


# Generated at 2022-06-25 07:47:18.616891
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = None
    bytes_0 = b'\x1f\x9f\xea\xe4CK\xac'
    set_0 = {bytes_0}
    bool_0 = True
    action_module_0 = ActionModule(bytes_0, set_0, bool_0, bytes_0, str_0, set_0)
    var_0 = action_module_0.run(str_0, str_0)
    assert isinstance(var_0, dict)

# Test case for method run of class ActionModule

# Generated at 2022-06-25 07:48:22.062849
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = None
    str_1 = None
    bytes_0 = b'\x1f\x9f\xea\xe4CK\xac'
    set_0 = {bytes_0}
    bool_0 = True
    action_module_0 = ActionModule(bytes_0, set_0, bool_0, bytes_0, str_1, set_0)
    action_module_0.run(str_0)


# Generated at 2022-06-25 07:48:28.528456
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = None
    bytes_0 = b'\x1f\x9f\xea\xe4CK\xac'
    set_0 = {bytes_0}
    bool_0 = True
    action_module_0 = ActionModule(bytes_0, set_0, bool_0, bytes_0, str_0, set_0)
    var_0 = action_module_0.run()
    # Test for equality with a True value
    assert var_0 is True, "Expected True, got " + str(var_0)
    # Test for equality with a False value
    assert var_0 is not True
    # Test for equality with a False value
    assert var_0 != True
    # Test for equality with a False value
    assert var_0 is False, "Expected False, got " + str

# Generated at 2022-06-25 07:48:34.393290
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #str_0 = None
    #bytes_0 = b'\x1f\x9f\xea\xe4CK\xac'
    #set_0 = {bytes_0}
    #bool_0 = True
    #action_module_0 = ActionModule(bytes_0, set_0, bool_0, bytes_0, str_0, set_0)
    #var_0 = action_run(str_0)
    assert True



# Generated at 2022-06-25 07:48:42.657102
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_0 = {'Z\xa2\xce\x19t\xf0\x96\xfa\x9a\x9f\x1a\xa4\x01\x17', b'\xd5\x7f\xec\x97', b'\xaf\xf6\xfc\x8e', b'\x03o\xdd*'}
    bytes_0 = b'\xde\x1a\xac\x15\xeb\xa6\x90\x82\xdf r\x15\x0c\x12\x86\xc0\xe5\x7f\x01\x9aV\x0e\x87\xba\xe8\xdc\t\x98I\x12\xd5'
    str_0 = None
   

# Generated at 2022-06-25 07:48:46.524950
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = None
    bytes_0 = b'\x1f\x9f\xea\xe4CK\xac'
    set_0 = {bytes_0}
    bool_0 = True
    action_module_0 = ActionModule(bytes_0, set_0, bool_0, bytes_0, str_0, set_0)
    action_module_0.run(str_0)

# Generated at 2022-06-25 07:48:55.703124
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = None
    bytes_0 = b'\xa9\xce\xa7\x1b\x10\xb4\x80\xbd'
    set_0 = {bytes_0}
    bool_0 = False
    action_module_0 = ActionModule(bytes_0, set_0, bool_0, bytes_0, str_0, set_0)
    var_0 = action_module_0.run(str_0)

# Generated at 2022-06-25 07:49:05.934478
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    arg0 = 'hello'
    arg1 = {'foo'}
    arg2 = True
    arg3 = b'hello'
    arg4 = 'hello'
    arg5 = {'foo'}
    action_module_0 = ActionModule(arg0, arg1, arg2, arg3, arg4, arg5)
    str_0 = 'hello'
    set_0 = {'foo'}
    bool_0 = True
    action_module_0.run(str_0, set_0, bool_0)

# Generated at 2022-06-25 07:49:13.599639
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = '\x1a08\xb4\xa4r\x83A\x9f'
    bytes_0 = b'\xd6\xfc\x94\xf2\xe6\xe2D\xbe\x8c\x97\xbf\xca\xe3\x1f\xcc\xbf\xf9\x93\x8c\x04\xcd'
    set_0 = {bytes_0, str_0}
    bool_0 = True
    action_module_0 = ActionModule(str_0, set_0, bool_0, bytes_0, str_0, set_0)
    var_0 = action_run(str_0)


if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run

# Generated at 2022-06-25 07:49:22.321843
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {
        'foo': 'bar',
        'my_data': {'items': [1, 2, 3]}
    }
    task_vars = task_vars or dict()

    result = super(ActionModule, self).run(tmp, task_vars)
    del tmp  # tmp no longer has any effect

    stats = {'data': {}, 'per_host': False, 'aggregate': True}

    if self._task.args:
        data = self._task.args.get('data', {})

        if not isinstance(data, dict):
            data = self._templar.template(data, convert_bare=False, fail_on_undefined=True)

        if not isinstance(data, dict):
            result['failed'] = True

# Generated at 2022-06-25 07:49:23.911196
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert len(test_ActionModule.__dict__.items()) == 1
