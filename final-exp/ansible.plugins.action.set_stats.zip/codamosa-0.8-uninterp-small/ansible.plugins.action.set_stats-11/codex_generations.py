

# Generated at 2022-06-25 07:41:41.581604
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule('A', 'B', 'C', 'D', 'E', 'F')
    assert x.run() == x.run()

test_ActionModule()

# Generated at 2022-06-25 07:41:50.466640
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'W_'
    int_0 = -311
    bool_0 = False
    str_1 = 'y'
    list_0 = [str_1, int_0, str_1]
    dict_0 = {'O`q': str_0, str_0: int_0, int_0: bool_0}
    tmp = 'p['
    task_vars = {
        'H': 'z',
        'K|f': 'b',
        '<\x7f': str_1,
        'H': 'Jl'
    }
    action_module_0 = ActionModule(str_0, int_0, bool_0, str_0, list_0, dict_0)
    action_module_0.run(tmp, task_vars)

# Unit test

# Generated at 2022-06-25 07:42:00.910669
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    int_0 = 0
    str_0 = 'J'
    int_1 = -621
    bool_0 = False
    list_0 = ['h', 'm', 'M']
    dict_0 = {str_0: int_1, int_1: list_0, bool_0: bool_0}
    action_module_0 = ActionModule(str_0, int_1, bool_0, str_0, list_0, dict_0)
    str_1 = '9'
    str_2 = 'w'
    list_1 = list()
    dict_1 = dict()
    dict_2 = dict(A=bool_0, B=32)
    dict_3 = dict({'a': bool_0, str_2: bool_0, 'c': bool_0})
    dict_4

# Generated at 2022-06-25 07:42:05.383054
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp = None
    task_vars = dict()
    result = None
    set_stats_0 = ActionModule(tmp, task_vars)
    assert not set_stats_0
    print("Test for constructor of class ActionModule done")


# Generated at 2022-06-25 07:42:09.256801
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # check list of valid arguments
    assert(ActionModule._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host')))

    # test for constructor method 
    test_case_0()

# Generated at 2022-06-25 07:42:12.432366
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None

    try:
        # Check if the 'run' method of class ActionModule was called
        assert action_module_0.run(tmp, task_vars)

    except AssertionError:
        # Abort the Unit Test
        print('Aborting Unit Test')


# Generated at 2022-06-25 07:42:16.840435
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'example'
    int_0 = -133
    bool_0 = True
    list_0 = [str_0, int_0, str_0]
    dict_0 = {str_0: int_0, int_0: list_0, bool_0: bool_0}
    action_module_0 = ActionModule(str_0, int_0, bool_0, str_0, list_0, dict_0)
    tmp_0 = None
    task_vars_0: dict = {'TEST': 'TEST'}
    action_module_0.run(tmp_0, task_vars_0)



# Generated at 2022-06-25 07:42:25.504540
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = 'j'
    int_0 = -1349
    bool_0 = True
    list_0 = [str_0, int_0, str_0]
    dict_0 = {str_0: int_0, int_0: list_0, bool_0: bool_0}
    action_module_0 = ActionModule(str_0, int_0, bool_0, str_0, list_0, dict_0)
    tmp_0 = 'n'
    dict_1 = dict_0
    action_module_0.run(tmp_0, dict_1)


# Generated at 2022-06-25 07:42:29.764550
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # print('Testing constructor of class ActionModule...')
    action_module_0 = ActionModule('A', 2, True, 'B', [1, 0, 1], {'A': 2, 2: [1, 0, 1], True: True})
    assert action_module_0.TRANSFERS_FILES == False
    assert action_module_0._VALID_ARGS == frozenset({'per_host', 'aggregate', 'data'})
    assert action_module_0._task.name == 'A'
    assert isinstance(action_module_0._task.args, dict)
    assert action_module_0._task.delegate_to == 2
    assert action_module_0._task.delegate_facts == True
    assert action_module_0._task.action == 'B'
    assert action_module_

# Generated at 2022-06-25 07:42:36.621188
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule('arg_0', -1349, True, 'arg_3', ['-1349', 'arg_0', 'arg_3'], {'-1349': True, 'arg_3': True, 'arg_0': '-1349'})
    tmp = 'tmp'
    task_vars = {'arg_0': 'arg_3', 'arg_3': 'arg_0'}
    result = action_module_0.run(tmp, task_vars)
    assert result['failed'] == False
    assert result['ansible_stats']['aggregate'] == False
    assert result['ansible_stats']['per_host'] == True
    assert result['ansible_stats']['data']['-1349'] == True

# Generated at 2022-06-25 07:42:43.173086
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # parameters
    task_vars = None

    # instantiate a class
    module = ActionModule(task_vars=task_vars)
    rc = module.run()

    return rc

# Generated at 2022-06-25 07:42:48.178145
# Unit test for constructor of class ActionModule
def test_ActionModule():
    for i in range(0, 10):
        var_0 = ActionModule()
        assert var_0 is not None


# Generated at 2022-06-25 07:42:58.975810
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_2 = dict({"data": var_0, "per_host": None, "aggregate": None})
    var_3 = None
    var_4 = ActionModule()
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = dict({"data": var_3, "per_host": None, "aggregate": None})
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22 = None
    var_23 = None
   

# Generated at 2022-06-25 07:43:01.044695
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj_ActionModule = None
    test_case_0()
    assert (obj_ActionModule is None)


# Generated at 2022-06-25 07:43:09.700339
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionModule()
    assert var_0 is not None, "Failed to instantiate ActionModule"

    var_1 = [None]
    var_2 = [None]
    var_0.replace_results(var_1, *var_2)

    var_1 = [None]
    var_2 = [None]
    var_0.add_cleanup_file(var_1, *var_2)

    var_1 = [None]
    var_2 = [None]
    var_0.notify_handler(var_1, *var_2)

    var_1 = [None]
    var_2 = [None]
    var_3 = [None]
    var_4 = [None]

# Generated at 2022-06-25 07:43:11.802773
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # No check of result['failed'], result['changed'] and result['msg']
    # No check of stats['data']
    pass


# Generated at 2022-06-25 07:43:13.073271
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()
    assert False


# Generated at 2022-06-25 07:43:16.292634
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create instance
    am = ActionModule()

    # check instance attributes
    assert am.TRANSFERS_FILES == False
    assert am._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-25 07:43:17.252307
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = True


# Generated at 2022-06-25 07:43:19.496716
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # var_0 = None

    # case 0
    test_case_0()


if __name__ == '__main__':
    # test case 0
    test_case_0()

# Generated at 2022-06-25 07:43:29.479203
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_0 = AnsibleModule(ActionModule, (), False)
    module_0.check_mode = True
    result = module_0.run(ActionModule)
    assert result['failed'] == False
    assert result['changed'] == False
    assert result['ansible_stats']['aggregate'] == True
    assert result['ansible_stats']['data'] is not None
    assert result['ansible_stats']['per_host'] == False
# End of unit test for method run of class ActionModule

# Generated at 2022-06-25 07:43:33.727035
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    str_0 = '|m*0|'
    str_1 = 'format'
    bytes_0 = b'\x90\x89[\x18\x9e\xc7\xfa\xb6(\xe2\x1e\xfc{\x98|\xb1U6m\xda'
    tuple_0 = ()
    action_module_0 = ActionModule(dict_0, str_0, str_1, bytes_0, tuple_0, bytes_0)
    var_0 = action_run()
    print(var_0)

# Generated at 2022-06-25 07:43:37.243604
# Unit test for constructor of class ActionModule
def test_ActionModule():
  try:
      action_module_0 = ActionModule(dict_0, str_0, str_1, bytes_0, tuple_0, bytes_0)
      if (1):
          raise Exception('Assertion failed')
  except Exception as e:
      pass


# Generated at 2022-06-25 07:43:39.574360
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tmp = None # TODO: initialize tmp
    task_vars = None # TODO: initialize task_vars
    action_module_0 = ActionModule(tmp, task_vars)
    var_0 = action_run()


# Generated at 2022-06-25 07:43:49.159791
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    str_0 = '|m*0|'
    str_1 = 'format'
    bytes_0 = b'\x90\x89[\x18\x9e\xc7\xfa\xb6(\xe2\x1e\xfc{\x98|\xb1U6m\xda'
    tuple_0 = ()
    action_module_0 = ActionModule(dict_0, str_0, str_1, bytes_0, tuple_0, bytes_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:43:53.410395
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {'name': 'ansible'}
    str_0 = '|m*0|'
    str_1 = 'format'
    bytes_0 = b'\x90\x89[\x18\x9e\xc7\xfa\xb6(\xe2\x1e\xfc{\x98|\xb1U6m\xda'
    tuple_0 = ()
    action_module_0 = ActionModule(dict_0, str_0, str_1, bytes_0, tuple_0, bytes_0)
    #AssertionError: none
    action_module_1 = ActionModule()
    dict_1 = {}
    dict_2 = {dict_1: dict_0, dict_1: dict_1, dict_1: dict_0}

# Generated at 2022-06-25 07:43:59.561974
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {0:0, 0: 0, 0: 0}
    str_0 = '|m*0|'
    str_1 = 'format'
    bytes_0 = b'\x90\x89[\x18\x9e\xc7\xfa\xb6(\xe2\x1e\xfc{\x98|\xb1U6m\xda'
    tuple_0 = ()
    assert action_module_0 == action_module_0, "ActionModule constructor failed"

# Generated at 2022-06-25 07:44:10.359707
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    str_0 = '|m*0|'
    str_1 = 'format'
    bytes_0 = b'\x90\x89[\x18\x9e\xc7\xfa\xb6(\xe2\x1e\xfc{\x98|\xb1U6m\xda'
    tuple_0 = ()
    action_module_0 = ActionModule(dict_0, str_0, str_1, bytes_0, tuple_0, bytes_0)
    action_module_0.run



# Generated at 2022-06-25 07:44:13.034462
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True



# Generated at 2022-06-25 07:44:16.227158
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert 'tmp' in action_module_0._task.args.keys()
    assert 'task_vars' in action_module_0._task.args.keys()
    
    

# Generated at 2022-06-25 07:44:31.517798
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp = None
    task_vars = None
    var_0 = action_module_0.run(tmp, task_vars)
    # TODO: implement test_ActionModule_run::test_0
    assert False

# Generated at 2022-06-25 07:44:41.094727
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_1 = True
    dict_0 = {bool_1: bool_1, bool_1: bool_1, bool_1: bool_1}
    str_0 = 'z'
    str_1 = 'deprecation'
    bytes_0 = b'\x90\x89[\x18\x9e\xc7\xfa\xb6(\xe2\x1e\xfc{\x98|\xb1U6m\xda'
    tuple_1 = ()
    action_module_0 = ActionModule(dict_0, str_0, str_1, bytes_0, tuple_1, bytes_0)
    var_0 = action_run()


# Generated at 2022-06-25 07:44:48.118729
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    str_0 = '|m*0|'
    str_1 = 'format'
    bytes_0 = b'\x90\x89[\x18\x9e\xc7\xfa\xb6(\xe2\x1e\xfc{\x98|\xb1U6m\xda'
    tuple_0 = ()
    action_module_0 = ActionModule(dict_0, str_0, str_1, bytes_0, tuple_0, bytes_0)

# Generated at 2022-06-25 07:44:55.574533
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = dict()
    str_0 = 'C'
    str_1 = '|o8\x86\x1f\xac\x13\x1b\xd6\x8d\x8c\xba\xc7\x9a\x09*\x87\xa6\xf1'
    bytes_0 = b'\xca\xea\xce\x9d\x19\x93\xa3\x98\xbf\x08\xae\x1f\x12\x9f\xf6\xb5\x08\xe0W8\xdf\xb2\x1e]\xf9\x9b'
    tuple_0 = ()

# Generated at 2022-06-25 07:45:05.560041
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    data = 'Csd7V'
    per_host = True
    aggregate = True
    dict_0 = {data: per_host, data: aggregate, data: per_host}
    str_0 = 'Jj|(5'
    str_1 = '%c^;'
    bytes_0 = b'\x8e\x0e\xba\xa9\x01\x1a\x13\x91\xa5\xb6\x97\xc1\x84\x1fI\x94\x16\xebd'
    tuple_0 = ()
    action_module_0 = ActionModule(dict_0, str_0, str_1, bytes_0, tuple_0, bytes_0)
    action_module_0.task_vars_0 = dict_0
    action_

# Generated at 2022-06-25 07:45:10.217797
# Unit test for constructor of class ActionModule
def test_ActionModule():
    vars = {'foo': 'bar'}
    tmp = '/path/to/tmp'
    task_vars = {'ansible_check_mode': True}

    a = ActionModule(vars, tmp, 'foo', 'bar', 'baz', task_vars=task_vars)
    assert a.env == {'ANSIBLE_CHECK_MODE': 'True'}
    assert a.task_vars == task_vars

# Generated at 2022-06-25 07:45:16.972174
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = dict()

# Generated at 2022-06-25 07:45:22.495819
# Unit test for constructor of class ActionModule
def test_ActionModule():
	try:
		ActionModule()
		print('ActionModule constructor test successful')
	except:
		print('ActionModule constructor test failed.')
		print(traceback.format_exc())

# Generated at 2022-06-25 07:45:29.605570
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionBase_0 = ActionBase()
    dict_0 = {}
    dict_0['dependencies'] = {}
    dict_0['task_vars'] = dict_0['dependencies']
    dict_0['module_name'] = 'ansible.module_utils.basic.json_dict'
    dict_0['task_name'] = 'tmux'
    # dict_0['_host'] = 'host'
    dict_0['task_args'] = dict_0['task_vars']

    action_module_0 = ActionModule(actionBase_0)
    int_0 = action_module_0.run(dict_0['task_vars'])

# Generated at 2022-06-25 07:45:37.530458
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    str_0 = '|m*0|'
    str_1 = 'format'
    bytes_0 = b'\x90\x89[\x18\x9e\xc7\xfa\xb6(\xe2\x1e\xfc{\x98|\xb1U6m\xda'
    tuple_0 = ()
    action_module_0 = ActionModule(dict_0, str_0, str_1, bytes_0, tuple_0, bytes_0)
    var_0 = action_run()
    var_0 = action_run(dict_0)

# Generated at 2022-06-25 07:46:01.971374
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_1 = False
    dict_1 = {bool_1: bool_1, bool_1: bool_1, bool_1: bool_1}
    str_2 = '|m*0|'
    str_3 = 'format'
    bytes_1 = b'\x90\x89[\x18\x9e\xc7\xfa\xb6(\xe2\x1e\xfc{\x98|\xb1U6m\xda'
    tuple_1 = ()
    action_module_1 = ActionModule(dict_1, str_2, str_3, bytes_1, tuple_1, bytes_1)
    assert isinstance(action_module_1, ActionModule) is True

# Generated at 2022-06-25 07:46:11.427875
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    str_0 = '\xdb['
    str_1 = '\xdb['
    bytes_0 = b'\x90\x89[\x18\x9e\xc7\xfa\xb6(\xe2\x1e\xfc{\x98|\xb1U6m\xda'
    tuple_0 = ()
    action_module_0 = ActionModule(dict_0, str_0, str_1, bytes_0, tuple_0, bytes_0)


# Generated at 2022-06-25 07:46:19.451150
# Unit test for constructor of class ActionModule
def test_ActionModule():
    foo_0 = {'dgfhfb': 'bfgbfgb'}
    foo_1 = '|m*0|'
    foo_2 = 'format'
    foo_3 = b'\x90\x89[\x18\x9e\xc7\xfa\xb6(\xe2\x1e\xfc{\x98|\xb1U6m\xda'
    foo_4 = ()
    foo_5 = b'\x90\x89[\x18\x9e\xc7\xfa\xb6(\xe2\x1e\xfc{\x98|\xb1U6m\xda'
    action_module_0 = ActionModule(foo_0, foo_1, foo_2, foo_3, foo_4, foo_5)

# Generated at 2022-06-25 07:46:27.094908
# Unit test for constructor of class ActionModule
def test_ActionModule(): 
    action_module_0 = ActionModule('|m*0|', 'register', '|m*0|', b'\x90\x89[\x18\x9e\xc7\xfa\xb6(\xe2\x1e\xfc{\x98|\xb1U6m\xda', (), b'\x90\x89[\x18\x9e\xc7\xfa\xb6(\xe2\x1e\xfc{\x98|\xb1U6m\xda')


# Generated at 2022-06-25 07:46:33.946813
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    str_0 = '|m*0|'
    str_1 = 'format'
    bytes_0 = b'\x90\x89[\x18\x9e\xc7\xfa\xb6(\xe2\x1e\xfc{\x98|\xb1U6m\xda'
    tuple_0 = ()
    action_module_0 = ActionModule(dict_0, str_0, str_1, bytes_0, tuple_0, bytes_0)


# Generated at 2022-06-25 07:46:34.659967
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert (ActionBase.run())


# Generated at 2022-06-25 07:46:40.744175
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    str_0 = '|m*0|'
    str_1 = 'format'
    bytes_0 = b'\x90\x89[\x18\x9e\xc7\xfa\xb6(\xe2\x1e\xfc{\x98|\xb1U6m\xda'
    tuple_0 = ()
    action_module_0 = ActionModule(dict_0, str_0, str_1, bytes_0, tuple_0, bytes_0)
    action_module_0.run()


# Generated at 2022-06-25 07:46:43.061045
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Input parameters:
    #   tmp: None
    #   task_vars: dict()

    action_module_1 = ActionModule()
    var_0 = action_run()

# Generated at 2022-06-25 07:46:51.395943
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        action_module_0 = ActionModule()
        str_0 = '|m*0|'
        str_1 = 'format'
        bytes_0 = b'\x90\x89[\x18\x9e\xc7\xfa\xb6(\xe2\x1e\xfc{\x98|\xb1U6m\xda'
        tuple_0 = ()
        action_module_0.run(str_0, str_1, bytes_0, tuple_0, bytes_0)
    except:
        pass


# Generated at 2022-06-25 07:47:01.824388
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = dict()
    dict_1 = dict()
    dict_1['data'] = dict_0
    dict_2 = dict()
    dict_2['aggregate'] = dict_0
    dict_1['per_host'] = dict_0
    dict_2['data'] = dict_1
    dict_3 = dict()
    dict_3['per_host'] = dict_0
    dict_3['aggregate'] = dict_1
    dict_1['aggregate'] = dict_0
    dict_1['per_host'] = dict_2
    str_0 = 'format'
    dict_4 = dict()
    dict_4['data'] = dict_1
    dict_4['aggregate'] = dict_2
    dict_4['per_host'] = dict_1
    bytes_0 = b

# Generated at 2022-06-25 07:47:41.146757
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert act_module_0.run() == 'var_0'

# Generated at 2022-06-25 07:47:52.773155
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    str_0 = '|m*0|'
    str_1 = 'format'
    bytes_0 = b'\x90\x89[\x18\x9e\xc7\xfa\xb6(\xe2\x1e\xfc{\x98|\xb1U6m\xda'
    tuple_0 = ()
    action_module_0 = ActionModule(dict_0, str_0, str_1, bytes_0, tuple_0, bytes_0)
    var_0 = action_module_0.run(tuple_0)
    print(var_0)

# Generated at 2022-06-25 07:47:54.829152
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    input_0 = {}
    action_module_0 = ActionModule(input_0, None)
    assert action_module_0.run(None, None) == {}

# Generated at 2022-06-25 07:48:01.653454
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = False
    dict_0 = {False: None, True: set(), True: frozenset()}
    str_0 = 'up'
    str_1 = 'mJF$k'
    bytes_0 = b'"/\xea\x1b\x05\x00\xa7\xbb\xf8\xa4\xbd\x02\x9f\xed\xe7'
    tuple_0 = ()
    action_module_0 = ActionModule(dict_0, str_0, str_1, bytes_0, tuple_0, bytes_0)



# Generated at 2022-06-25 07:48:04.807068
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(dict_0, str_0, str_1, bytes_0, tuple_0, bytes_0)
    print('Class name is ' + str(action_module_0.__class__.__name__))
    print('Instance id is :' + str(id(action_module_0)))
    print('Test case passed !!')


# Generated at 2022-06-25 07:48:14.597178
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: Temporary, for the case when we have empty test_case_0, in order to prevent warning message of no tests
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    str_0 = '|m*0|'
    str_1 = 'format'
    bytes_0 = b'\x90\x89[\x18\x9e\xc7\xfa\xb6(\xe2\x1e\xfc{\x98|\xb1U6m\xda'
    tuple_0 = ()
    action_module_0 = ActionModule(dict_0, str_0, str_1, bytes_0, tuple_0, bytes_0)

# Generated at 2022-06-25 07:48:24.072427
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    str_0 = 'f'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    str_1 = 'lQ`'
    str_2 = '_'
    bytes_0 = b'\x91\x8bv\x0e\x15\xc6\xfe\xc1\x82\xe3\xca\xe2\x90\x8b\xef\xf4\xab4'
    tuple_0 = ()
    action_module_0 = ActionModule(dict_0, str_1, str_2, bytes_0, tuple_0, bytes_0)
    temp_0 = None
    task_vars_0 = None

# Generated at 2022-06-25 07:48:33.040467
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(action_module_0) == object
    assert isinstance(action_module_0.action) == object
    assert isinstance(action_module_0.action.__name__) == str
    assert isinstance(action_module_0.action.__doc__) == str
    assert isinstance(action_module_0.action._valid_args) == frozenset
    assert isinstance(action_module_0.action.TRANSFERS_FILES) == bool
    assert isinstance(action_module_0.action.DEFAULT_CONFIG) == dict
    assert isinstance(action_module_0.action.DEFAULT_SHARED_FILE) == str
    assert isinstance(action_module_0.action.DEFAULT_USE_TMP_PATH) == bool

# Generated at 2022-06-25 07:48:38.998645
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    str_0 = '|m*0|'
    str_1 = 'format'
    bytes_0 = b'\x90\x89[\x18\x9e\xc7\xfa\xb6(\xe2\x1e\xfc{\x98|\xb1U6m\xda'
    tuple_0 = ()
    action_module_0 = ActionModule(dict_0, str_0, str_1, bytes_0, tuple_0, bytes_0)
    action_module_0.run()


# Generated at 2022-06-25 07:48:48.212211
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    str_0 = '|m*0|'
    str_1 = 'format'
    bytes_0 = b'\x90\x89[\x18\x9e\xc7\xfa\xb6(\xe2\x1e\xfc{\x98|\xb1U6m\xda'
    tuple_0 = ()
    action_module_0 = ActionModule(dict_0, str_0, str_1, bytes_0, tuple_0, bytes_0)
    var_0 = action_run()

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 07:50:33.385255
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    str_0 = '|m*0|'
    str_1 = 'format'
    bytes_0 = b'\x90\x89[\x18\x9e\xc7\xfa\xb6(\xe2\x1e\xfc{\x98|\xb1U6m\xda'
    tuple_0 = ()
    action_module_0 = ActionModule(dict_0, str_0, str_1, bytes_0, tuple_0, bytes_0)
    action_module_0.action_run()


test_case_0()

# Generated at 2022-06-25 07:50:39.972229
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    str_0 = '|m*0|'
    str_1 = 'format'
    bytes_0 = b'\x90\x89[\x18\x9e\xc7\xfa\xb6(\xe2\x1e\xfc{\x98|\xb1U6m\xda'
    tuple_0 = ()
    action_module_0 = ActionModule(dict_0, str_0, str_1, bytes_0, tuple_0, bytes_0)
    assert action_module_0._valid_args == action_module_0.VALID_ARGS

# Generated at 2022-06-25 07:50:47.873707
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    str_0 = '|m*0|'
    str_1 = 'format'
    bytes_0 = b'\x90\x89[\x18\x9e\xc7\xfa\xb6(\xe2\x1e\xfc{\x98|\xb1U6m\xda'
    tuple_0 = ()
    action_module_0 = ActionModule(dict_0, str_0, str_1, bytes_0, tuple_0, bytes_0)
    assert(isinstance(action_module_0, ActionModule))


# Generated at 2022-06-25 07:50:49.273003
# Unit test for constructor of class ActionModule
def test_ActionModule():
    del str_0
    act_mod = ActionModule(str_1, dict_0, dict_0)


# Generated at 2022-06-25 07:50:58.603253
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)
    assert len(action_module_0.transfers) == 0
    assert action_module_0.transfers_files == False
    assert type(action_module_0.action_loader) == str
    assert type(action_module_0._shared_loader_obj) == str
    assert type(action_module_0._connection) == str
    assert type(action_module_0.no_log) == bool
    assert action_module_0.enable_async == False
    assert action_module_0.task == task

# Generated at 2022-06-25 07:51:02.370658
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 07:51:12.387683
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    str_0 = '|m*0|'
    str_1 = 'format'
    bytes_0 = b'\x90\x89[\x18\x9e\xc7\xfa\xb6(\xe2\x1e\xfc{\x98|\xb1U6m\xda'
    tuple_0 = ()
    action_module_0 = ActionModule(dict_0, str_0, str_1, bytes_0, tuple_0, bytes_0)
    var_0 = None
    result = action_module_0.run(var_0)
    print(result)


# Generated at 2022-06-25 07:51:19.843382
# Unit test for constructor of class ActionModule
def test_ActionModule():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    str_0 = '|m*0|'
    str_1 = 'format'
    bytes_0 = b'\x90\x89[\x18\x9e\xc7\xfa\xb6(\xe2\x1e\xfc{\x98|\xb1U6m\xda'
    tuple_0 = ()
    action_module_0 = ActionModule(dict_0, str_0, str_1, bytes_0, tuple_0, bytes_0)
    assert isinstance(action_module_0._task, dict)
    assert isinstance(action_module_0._connection, str)

# Generated at 2022-06-25 07:51:20.790410
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 07:51:28.102343
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    str_0 = '|m*0|'
    str_1 = 'format'
    bytes_0 = b'\x90\x89[\x18\x9e\xc7\xfa\xb6(\xe2\x1e\xfc{\x98|\xb1U6m\xda'
    tuple_0 = ()
    action_module_0 = ActionModule(dict_0, str_0, str_1, bytes_0, tuple_0, bytes_0)
    var_0 = action_run()