

# Generated at 2022-06-25 07:41:41.604216
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_1 = {}
    int_1 = 2099
    bool_1 = True
    str_1 = "B/J*]qiw>lA#`cD'Lx8P"
    action_module_1 = ActionModule(dict_1, dict_1, int_1, int_1, bool_1, str_1)

# Generated at 2022-06-25 07:41:48.101911
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # this is a basic test
    dict_0 = {
        'changed' : True,
        'ansible_stats' : {
            'data' : {
                'var1' : 'val1',
                'var2' : 'val2'
            }
        }
    }
    action_module_0 = ActionModule({})
    result = action_module_0.run()
    assert result == dict_0, 'Test failed'

# Generated at 2022-06-25 07:41:50.106709
# Unit test for constructor of class ActionModule
def test_ActionModule():
  action_module_0 = ActionModule()
  assert isinstance(action_module_0, ActionModule) is True


# Generated at 2022-06-25 07:41:54.312650
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()


# Generated at 2022-06-25 07:42:00.153148
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    int_0 = 2099
    bool_0 = True
    str_0 = "B/J*]qiw>lA#`cD'Lx8P"
    action_module_0 = ActionModule(dict_0, dict_0, int_0, int_0, bool_0, str_0)
    assert action_module_0.run(dict_0, dict_0) == {"ansible_stats": {'per_host': False, 'aggregate': True, 'data': {}}, 'changed': False}

test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 07:42:08.252700
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    dict_1 = {}
    int_0 = 2099
    int_1 = 2099
    bool_0 = True
    str_0 = "B/J*]qiw>lA#`cD'Lx8P"
    action_module_0 = ActionModule(dict_0, dict_1, int_0, int_1, bool_0, str_0)
    assert isinstance(action_module_0, ActionModule)
    assert action_module_0.TRANSFERS_FILES == False

# Generated at 2022-06-25 07:42:14.953709
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    int_0 = 2099
    bool_0 = True
    str_0 = "B/J*]qiw>lA#`cD'Lx8P"
    action_module_0 = ActionModule(dict_0, dict_0, int_0, int_0, bool_0, str_0)
    dict_1 = {}
    dict_1 = action_module_0.run(dict_0, dict_0)
    assert dict_1['failed'] == False
    assert dict_1['ansible_stats']['aggregate'] == True
    assert dict_1['ansible_stats']['per_host'] == False
    assert dict_1['ansible_stats']['data'] == {}
    assert dict_1['changed'] == False


# Generated at 2022-06-25 07:42:22.500673
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    dict_1 = {}
    int_0 = 2099
    bool_0 = True
    str_0 = "B/J*]qiw>lA#`cD'Lx8P"
    action_module_0 = ActionModule(dict_0, dict_0, int_0, int_0, bool_0, str_0)

    if str_0 == "B/J*]qiw>lA#`cD'Lx8P":
        test_case_0()

# Generated at 2022-06-25 07:42:31.541982
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    dict_1 = {}
    dict_1['data'] = dict_0
    int_0 = 2099
    bool_0 = True
    str_0 = "B/J*]qiw>lA#`cD'Lx8P"
    action_module_0 = ActionModule(dict_0, dict_0, int_0, int_0, bool_0, str_0)
    tmp_0 = None
    task_vars_0 = dict_0
    dict_2 = action_module_0.run(tmp_0, task_vars_0)
    assert(dict_2['msg'] == "The 'data' option needs to be a dictionary/hash")

    dict_0 = {}
    dict_1 = {}
    dict_1['data'] = dict_0
   

# Generated at 2022-06-25 07:42:38.121910
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    int_0 = 2099
    bool_0 = True
    str_0 = "B/J*]qiw>lA#`cD'Lx8P"
    action_module_0 = ActionModule(dict_0, dict_0, int_0, int_0, bool_0, str_0)
    test_case_0()

# Generated at 2022-06-25 07:42:47.171752
# Unit test for constructor of class ActionModule
def test_ActionModule():
    my_action_module = ActionModule()


# Generated at 2022-06-25 07:42:48.358386
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:42:49.592132
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert action_module_0

# Generated at 2022-06-25 07:42:50.217603
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-25 07:42:51.702650
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:42:54.345600
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.set_stats import ActionModule
    action_module = ActionModule()
    assert action_module is not None


# Generated at 2022-06-25 07:43:01.603461
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test call when no cache present
    action_module = ActionModule()

    # Test call when cache present
    action_module_1 = ActionModule()

    # Test _supports_check_mode and _supports_async
    assert (action_module._supports_check_mode() == True)
    assert (action_module._supports_async() == True)

    # Test _supports_check_mode and _supports_async when cache present
    assert (action_module._supports_check_mode() == True)
    assert (action_module._supports_async() == True)


# Generated at 2022-06-25 07:43:04.827260
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_obj = ActionModule()
    assert isinstance(action_module_obj, ActionModule)
    result = action_module_obj.run()
    (result['changed'], result['ansible_stats']['aggregate']) == (False, True)



# Generated at 2022-06-25 07:43:11.230900
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.module_utils.basic import AnsibleModule
    mod = AnsibleModule(
        argument_spec=dict(
            aggregate=dict(type='bool', required=False),
            data=dict(type='dict', required=False),
            per_host=dict(type='bool', required=False),
        ),
        supports_check_mode=False,
    )

    set_stats = ActionModule(mod)

    result = set_stats.run(task_vars=dict())
    assert result['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True}

# Generated at 2022-06-25 07:43:13.874545
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(action_module_0.__class__.__name__ == 'ActionModule')
    print("test_ActionModule - constructor test PASSED")

test_ActionModule()

# Generated at 2022-06-25 07:43:28.370008
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_0 = ActionModule()
    assert isinstance(action_module_0.tmp, )
    assert isinstance(action_module_0.task_vars, )
    assert action_module_0.task_id == 2094
    assert action_module_0.play_context == 2094
    assert action_module_0.new_stdin == False
    assert action_module_0.connection == "B(/J*]qiw>lA#`cD'Lx8"
    assert isinstance(action_module_0.loader, )
    assert isinstance(action_module_0.templar, )
    assert isinstance(action_module_0.shared_loader_obj, )
    assert isinstance(action_module_0.default_vars, )

# Generated at 2022-06-25 07:43:35.458240
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    int_0 = 2094
    bool_0 = False
    str_0 = "B(/J*]qiw>lA#`cD'Lx8"
    action_module_0 = ActionModule(dict_0, dict_0, int_0, int_0, bool_0, str_0)
    assert action_module_0.run(dict_0, dict_0)

test_ActionModule_run()

    # TODO: Add more tests here

# Generated at 2022-06-25 07:43:43.954274
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {'per_host': True, 'data': {'var1': 'value1'}}
    dict_1 = {'changed': False}
    dict_1['ansible_stats'] = {'aggregate': True, 'per_host': False, 'data': {'var1': 'value1'}}
    int_0 = 1294
    bool_0 = True
    str_0 = "&y12]#K_vt96B-k!jZ"
    action_module_0 = ActionModule(dict_0, dict_0, int_0, int_0, bool_0, str_0)
    assert var_0 == dict_1


# Generated at 2022-06-25 07:43:48.893440
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    int_0 = 7576
    bool_0 = False
    str_0 = "0y0Jr)Gx7'*a5!5+LmnZ"
    action_module_0 = ActionModule(dict_0, dict_0, int_0, int_0, bool_0, str_0)



# Generated at 2022-06-25 07:43:52.567799
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    int_0 = 4193
    bool_0 = False
    str_0 = "H(I`&K[LIW)q8U]{-<pA"
    action_module_0 = ActionModule(dict_0, dict_0, int_0, int_0, bool_0, str_0)


# Generated at 2022-06-25 07:43:54.979595
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_6 = {}
    int_0 = 2094
    bool_0 = False
    str_0 = "B(/J*]qiw>lA#`cD'Lx8"
    action_module_0 = ActionModule(dict_6, dict_6, int_0, int_0, bool_0, str_0)
    test_case_0()

# Generated at 2022-06-25 07:43:59.326648
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    int_0 = 2094
    bool_0 = False
    str_0 = "B(/J*]qiw>lA#`cD'Lx8"
    action_module_0 = ActionModule(dict_0, dict_0, int_0, int_0, bool_0, str_0)
    action_module_0.run(dict_0, dict_0)

# Generated at 2022-06-25 07:44:03.590147
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    int_0 = 1814
    bool_0 = False
    str_0 = "n7gFnP$D-LQ[H]?e/`"
    action_module_0 = ActionModule(dict_0, dict_0, int_0, int_0, bool_0, str_0)
    var_0 = action_run()
    print(var_0)

# Generated at 2022-06-25 07:44:09.716276
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    int_0 = 2460
    bool_0 = True
    str_0 = "YV1+^q3D0"
    action_module_0 = ActionModule(dict_0, dict_0, int_0, int_0, bool_0, str_0)
    assert dict_0 == dict_0
    assert int_0 == int_0
    assert bool_0 == bool_0
    assert str_0 == str_0
    assert action_module_0.get_name() == str_0


# Generated at 2022-06-25 07:44:15.027726
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    action_module_0 = ActionModule(dict_0, dict_0, int_0, int_0, bool_0, str_0)
    var_0 = action_run()

# Generated at 2022-06-25 07:44:36.026842
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    int_0 = 2094
    bool_0 = False
    str_0 = "B(/J*]qiw>lA#`cD'Lx8"
    action_module_0 = ActionModule(dict_0, dict_0, int_0, int_0, bool_0, str_0)
    assert(action_module_0.TRANSFERS_FILES == False)
    assert(action_module_0._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host')))
    dict_0 = {}
    int_0 = 2094
    bool_0 = False
    str_0 = "B(/J*]qiw>lA#`cD'Lx8"

# Generated at 2022-06-25 07:44:36.496313
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-25 07:44:46.967002
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # We create the test case
    dict_0 = {}

    action_module_0 = ActionModule(dict_0, dict_0, -2094, -2094, False, "B(/J*]qiw>lA#`cD'Lx8")
    outcome = action_module_0.run()

    assert isinstance(outcome, dict)
    assert bool(outcome['failed']) is True
    assert isinstance(outcome['msg'], string_types) and len(outcome['msg']) > 6
    assert bool(outcome['changed']) is False
    assert isinstance(outcome['ansible_stats'], dict)
    assert isinstance(outcome['ansible_stats']['aggregate'], bool)

# Generated at 2022-06-25 07:44:52.731172
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    int_0 = 1066
    bool_0 = False
    str_0 = "S!y?M9fR|+"
    action_module_0 = ActionModule(dict_0, dict_0, int_0, int_0, bool_0, str_0)

# Generated at 2022-06-25 07:44:58.396818
# Unit test for constructor of class ActionModule
def test_ActionModule():
   dict_0 = {}
   int_0 = 2094
   bool_0 = False
   str_0 = "B(/J*]qiw>lA#`cD'Lx8"
   action_module_0 = ActionModule(dict_0, dict_0, int_0, int_0, bool_0, str_0)


# Generated at 2022-06-25 07:45:07.696558
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    dict_0 = {}
    int_0 = 2124
    int_0 = 2180
    bool_0 = False
    str_0 = "mF]+ A(`8{q0k<)"
    action_module_0 = ActionModule(dict_0, dict_0, int_0, int_0, bool_0, str_0)
    bool_0 = True
    action_module_0.add_path(bool_0)
    bool_0 = True
    action_module_0.add_path(bool_0)
    bool_0 = True
    dict_0 = {}
    dict_0 = {}
    int_0 = 2174
    int_0 = 2296
    bool_0 = True

# Generated at 2022-06-25 07:45:16.245268
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    dict_0['0'] = "*a"
    dict_0['1'] = "&"
    dict_0['2'] = "Yq6"
    dict_0['3'] = "2"
    dict_0['4'] = "D"
    dict_0['5'] = "$"
    dict_0['6'] = "s"
    dict_0['7'] = "K"
    dict_0['8'] = "tMms"
    dict_0['9'] = ">"
    action_module_0 = ActionModule(dict_0, dict_0)
    var_0 = action_run(dict_0)
    assert var_0 == dict_0
    pass

# Generated at 2022-06-25 07:45:18.599782
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: Ensure that the unit test actually tests the constructor
    assert True == True

# Generated at 2022-06-25 07:45:27.183184
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    int_0 = 2094
    bool_0 = False
    str_0 = "B(/J*]qiw>lA#`cD'Lx8"
    action_module_0 = ActionModule(dict_0, dict_0, int_0, int_0, bool_0, str_0)
    tmp_0 = 1484
    task_vars_0 = None
    var_0 = action_module_0.run(tmp_0, task_vars_0)

# Generated at 2022-06-25 07:45:36.289182
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {'uuid': 'bd6f7d1b-003e-4313-bba2-eb17ff72e33d', 'ansible_stats': '134'}
    dict_1 = {'uuid': '550bfc43-6f5c-4766-9ee9-3ab3f6c17f8e', 'ansible_stats': '49'}
    dict_2 = {'uuid': '1a7a62ad-bc2e-4b4b-b7d1-c35a0fddd9e9', 'ansible_stats': '188'}

# Generated at 2022-06-25 07:46:09.092555
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Check if instance created successfully
    bool_1 = bool()
    bool_0 = bool()
    bool_0 = bool()
    bool_1 = bool()
    bool_0 = bool()
    bool_0 = bool()
    action_module_0 = ActionModule(bool_1, bool_0, bool_0, bool_1, bool_0, bool_0)
    assert action_module_0.action == bool_1
    assert action_module_0.task == bool_0
    assert action_module_0.connection == bool_0
    assert action_module_0.play_context == bool_1
    assert action_module_0.loader == bool_0
    assert action_module_0.templar == bool_0

    # Check __doc__
    # self.assertIsNotNone(action_module_

# Generated at 2022-06-25 07:46:14.871079
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    int_0 = -2041927145
    bool_0 = True
    str_0 = "=j4*]"
    # 2.28.2
    action_module_0 = ActionModule(dict_0, dict_0, int_0, int_0, bool_0, str_0)
    var_0 = action_run()
    pass

# Generated at 2022-06-25 07:46:18.917313
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    int_0 = 174
    bool_0 = False
    str_0 = "zH2tUR(-'9ws)@;x)"
    action_module_0 = ActionModule(dict_0, dict_0, int_0, int_0, bool_0, str_0)
    var_0 = action_run(dict_0)


# Generated at 2022-06-25 07:46:25.662886
# Unit test for constructor of class ActionModule
def test_ActionModule():
  dict_0 = {}
  int_0 = 2147
  bool_0 = False
  str_0 = "u_7h|J1>ZS:@$2T3;^]w"
  action_module_0 = ActionModule(dict_0, dict_0, int_0, int_0, bool_0, str_0)
  assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:46:30.759800
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    int_0 = 2094
    bool_0 = False
    str_0 = "B(/J*]qiw>lA#`cD'Lx8"
    action_module_0 = ActionModule(dict_0, dict_0, int_0, int_0, bool_0, str_0)
    # not implemented yet


# Generated at 2022-06-25 07:46:34.288198
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    int_0 = 2094
    bool_0 = False
    str_0 = "B(/J*]qiw>lA#`cD'Lx8"
    action_module_0 = ActionModule(dict_0, dict_0, int_0, int_0, bool_0, str_0)


# Generated at 2022-06-25 07:46:38.766934
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    int_0 = 2094
    bool_0 = False
    str_0 = "B(/J*]qiw>lA#`cD'Lx8"
    action_module_0 = ActionModule(dict_0, dict_0, int_0, int_0, bool_0, str_0)
    action_module_0.run(dict_0, dict_0)


# Generated at 2022-06-25 07:46:40.152507
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 07:46:46.159562
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    int_0 = 2094
    bool_0 = False
    str_0 = "B(/J*]qiw>lA#`cD'Lx8"

# Generated at 2022-06-25 07:46:54.838213
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    int_0 = 2670
    int_1 = 2780
    bool_0 = True
    str_0 = "aF-%p+x/!:=1'}fh@o:M"
    str_1 = "ElZU^F;G6Q;U6[AtC6IY"
    action_module_0 = ActionModule(dict_0, dict_1, int_0, int_1, bool_0, str_0)
    action_module_1 = ActionModule(dict_2, dict_3, int_0, int_1, bool_0, str_1)

# Generated at 2022-06-25 07:47:41.258291
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    try:
        assert False
    except AssertionError:
        pass


# Generated at 2022-06-25 07:47:49.691533
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    int_0 = 2134
    bool_0 = False
    str_0 = "%-/!8W-ow*}vME(~N'D"
    action_module_0 = ActionModule(dict_0, dict_0, int_0, int_0, bool_0, str_0)
    var_0 = action_run()


if __name__ == "__main__":
    print("Do not invoke this script directly")

# Generated at 2022-06-25 07:48:00.025889
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    task_vars = dict_0
    int_0 = 1878
    int_1 = 2119
    bool_0 = False
    bool_1 = True
    str_0 = "E"
    str_1 = "C!%tCL?I^7Zc%m`#-7:C"
    dict_1 = {'per_host': False, 'aggregate': True, 'data': {}}
    dict_2 = {}
    dict_3 = {'per_host': True, 'aggregate': False, 'data': {}}
    dict_4 = {}
    dict_5 = {'per_host': True, 'aggregate': True, 'data': {}}
    dict_6 = {}

# Generated at 2022-06-25 07:48:06.923819
# Unit test for constructor of class ActionModule
def test_ActionModule():
    str_0 = "B(/J*]qiw>lA#`cD'Lx8"
    str_1 = "B(/J*]qiw>lA#`cD'Lx8"
    int_0 = 2094
    int_1 = 2094
    bool_0 = False
    bool_1 = False
    action_module_0 = ActionModule(str_0, str_1, int_0, int_1, bool_0, bool_1)
    # assert action_module_0._VALID_ARGS


# Generated at 2022-06-25 07:48:12.259003
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import module_utils.parsing.convert_bool as convert_bool
    import module_utils.six as six
    import ansible.utils.vars as vars
    import ansible.plugins.action as action
    
    action_base_0 = action.ActionBase(dict(), dict())
    
    
    
    action_module_0 = ActionModule(action_base_0)

# Generated at 2022-06-25 07:48:16.026768
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    str_0 = "H)\\X"
    str_1 = "/0pF(ipI>6y"
    action_module_0 = ActionModule(dict_0, dict_1, dict_2, str_0, str_1)
    var_0 = action_module_0.run()
    assert var_0 == 0

# Generated at 2022-06-25 07:48:18.164539
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_0 = ActionModule({}, {}, {}, {}, {}, {})
    # print(var_0) # no output
    # print(var_2) # no output
    # print(var_4) # no output
    # print(var_6) # no output
    # print(var_8) # no output
    # print(var_10) # no output


# Generated at 2022-06-25 07:48:18.824911
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-25 07:48:26.121406
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {'vault_password': '', 'no_log': False, '_ansible_module_name': 'setup', '_ansible_no_log': False, '_ansible_verbosity': 0}
    int_0 = -5171
    bool_0 = False
    str_0 = 'ansible.plugins.action.setup'
    action_module_0 = ActionModule(dict_0, dict_0, int_0, int_0, bool_0, str_0)

    action_run()
    var_0 = {'msg': "Z|?L#iQLo2`~M`1+[X1U(x.i@.:", 'ansible_facts': {}, 'failed': False, 'changed': False}



# Generated at 2022-06-25 07:48:26.664863
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-25 07:50:20.358783
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    dict_1 = {}
    int_0 = 2094
    int_1 = 2094
    bool_0 = False
    str_0 = "B(/J*]qiw>lA#`cD'Lx8"
    action_module_0 = ActionModule(dict_0, dict_1, int_0, int_1, bool_0, str_0)
    action_module_0.run()

# Generated at 2022-06-25 07:50:30.987763
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    dict_1 = {}
    dict_0 = {}
    dict_1 = {}
    bool_0 = False
    bool_1 = True
    str_0 = "B(/J*]qiw>lA#`cD'Lx8"
    str_1 = "I%C@9j#|;i>S"
    str_2 = "xB&3GA=YS4i:51d(^]0"
    str_3 = "rZpM^o<b5o&_n.YhnR"
    str_4 = "D$1-6_[UeZ`#odhBx(V"
    str_5 = ")ov^lh9/6;f8[UHVh*"

# Generated at 2022-06-25 07:50:38.289074
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    dict_1 = {}
    int_0 = 2038
    int_1 = 2079
    bool_0 = False
    str_0 = "B(/J*]qiw>lA#`cD'Lx8"
    action_module_0 = ActionModule(dict_0, dict_0, int_0, int_0, bool_0, str_0)
    var_0 = action_run()
    assert var_0 == dict_1

# Generated at 2022-06-25 07:50:40.802903
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        dict_0 = {}
        int_0 = 2094
        bool_0 = False
        str_0 = "B(/J*]qiw>lA#`cD'Lx8"
        action_module_0 = ActionModule(dict_0, dict_0, int_0, int_0, bool_0, str_0)
        print("Successfully created an instance of class ActionModule")
    except Exception:
        print("Unable to create an instance of class ActionModule")


# Generated at 2022-06-25 07:50:48.447071
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    dict_1 = {"asd": "fgh"}
    dict_2 = {"per_host": True}
    dict_3 = {}
    dict_4 = {"aggregate": True}
    dict_5 = {"per_host": True}
    dict_6 = {"asd": "f"}
    dict_7 = {"asd": "fgh"}
    dict_8 = {"asd": "fgh"}
    dict_9 = {"data": dict_4}
    dict_10 = {"asd": "fgh"}
    dict_11 = {}
    dict_12 = {"asd": "fgh"}
    dict_13 = {"data": dict_4}
    dict_14 = {"asd": "f"}
    dict_15 = {"asd": "fgh"}
    dict_16

# Generated at 2022-06-25 07:50:58.133239
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    int_0 = 6139
    bool_0 = False
    str_0 = "*h8`{-`aUkZ"
    action_module_0 = ActionModule(dict_0, dict_0, int_0, int_0, bool_0, str_0)
    assert action_module_0.data['task'] == dict_0
    assert action_module_0.task_vars == dict_0
    assert action_module_0.play_context['remote_addr'] == int_0
    assert action_module_0.play_context['port'] == int_0
    assert action_module_0.play_context['become'] == bool_0
    assert action_module_0.play_context['become_user'] == str_0

# Generated at 2022-06-25 07:51:00.691383
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class_ActionModule_0 = ActionModule()
    assert class_ActionModule_0.TRANSFERS_FILES == False
    assert class_ActionModule_0._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))


# Generated at 2022-06-25 07:51:06.683932
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dict_0 = {}
    int_0 = 2094
    bool_0 = False
    str_0 = "B(/J*]qiw>lA#`cD'Lx8"
    action_module_0 = ActionModule(dict_0, dict_0, int_0, int_0, bool_0, str_0)


# Generated at 2022-06-25 07:51:14.104796
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = {}
    int_0 = 2094
    bool_0 = False
    str_0 = "B(/J*]qiw>lA#`cD'Lx8"
    action_module_0 = ActionModule(dict_0, dict_0, int_0, int_0, bool_0, str_0)
    action_run_0 = action_module_0.run()
    if action_run_0 is None:
        raise ValueError("Expected action_run_0 to be of type dict and the value to be not None")
    if action_run_0.get("ansible_stats") is None:
        raise ValueError("Expected action_run_0 to contain a key named ansible_stats")

# Generated at 2022-06-25 07:51:15.648528
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        ActionModule()
    except Exception as e:
        print(e)
        assert False
