

# Generated at 2022-06-17 09:43:48.347541
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    am = ActionModule()

    # Create an instance of class TaskExecutor
    te = TaskExecutor()

    # Create an instance of class Task
    t = Task()

    # Create an instance of class PlayContext
    pc = PlayContext()

    # Create an instance of class Play
    p = Play()

    # Create an instance of class Playbook
    pb = Playbook()

    # Create an instance of class Runner
    r = Runner()

    # Create an instance of class Connection
    c = Connection()

    # Create an instance of class VariableManager
    vm = VariableManager()

    # Create an instance of class Inventory
    i = Inventory()

    # Create an instance of class Host
    h = Host()

    # Create an instance of class TaskVars
    tv = TaskVars()

    #

# Generated at 2022-06-17 09:43:51.255815
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:44:01.824027
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = type('', (), {})()
    mock_task.args = {'data': {'foo': 'bar'}, 'per_host': True, 'aggregate': False}

    # Create a mock action module
    mock_action_module = type('', (), {})()
    mock_action_module._task = mock_task
    mock_action_module._templar = type('', (), {})()
    mock_action_module._templar.template = lambda x: x

    # Call method run of class ActionModule
    result = ActionModule.run(mock_action_module)

    # Assertions
    assert result['ansible_stats']['data']['foo'] == 'bar'
    assert result['ansible_stats']['per_host'] == True
   

# Generated at 2022-06-17 09:44:03.481979
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-17 09:44:04.379938
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:44:05.803458
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 09:44:13.297398
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict(
        action=dict(
            module_name='set_stats',
            module_args=dict(
                data=dict(
                    foo='bar'
                ),
                per_host=True,
                aggregate=False
            )
        )
    )

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock tmp
    tmp = None

    # Create a mock result
    result = dict(
        ansible_stats=dict(
            data=dict(
                foo='bar'
            ),
            per_host=True,
            aggregate=False
        ),
        changed=False
    )

    # Create a mock ActionBase
    action_base = ActionBase()

    # Create a mock ActionModule

# Generated at 2022-06-17 09:44:24.948624
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:44:33.456610
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:44:37.768950
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-17 09:44:49.808102
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule(None, None, None, None, None, None)
    assert action_module.run() == {'changed': False, 'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}}

    # Test with valid arguments
    action_module = ActionModule(None, None, None, None, None, {'data': {'a': 1, 'b': 2}, 'per_host': True, 'aggregate': False})
    assert action_module.run() == {'changed': False, 'ansible_stats': {'data': {'a': 1, 'b': 2}, 'per_host': True, 'aggregate': False}}

    # Test with invalid arguments

# Generated at 2022-06-17 09:44:58.373735
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test with no args
    am = ActionModule(None, None, None, None, None, None, None, None)
    assert am.run() == {'changed': False, 'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}}

    # test with args
    am = ActionModule(None, None, None, None, None, None, None, {'data': {'foo': 'bar'}, 'per_host': True, 'aggregate': False})
    assert am.run() == {'changed': False, 'ansible_stats': {'data': {'foo': 'bar'}, 'per_host': True, 'aggregate': False}}

# Generated at 2022-06-17 09:45:09.749753
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
   

# Generated at 2022-06-17 09:45:11.406129
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:45:21.405872
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'data': {'key1': 'value1', 'key2': 'value2'}, 'per_host': True, 'aggregate': False}

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock action_base
    action_base = MockActionBase()

    # Create an instance of ActionModule
    action_module = ActionModule(task, templar, module_utils, action_base)

    # Call method run
    result = action_module.run()

    # Assert the result
    assert result['changed'] == False

# Generated at 2022-06-17 09:45:22.621381
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:45:33.690875
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_host_vars
    from ansible.utils.vars import load_vars

# Generated at 2022-06-17 09:45:34.568994
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict())

# Generated at 2022-06-17 09:45:45.555233
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_host_vars
    from ansible.utils.vars import load_vars

    loader = DataLoader()
    variable_

# Generated at 2022-06-17 09:45:54.702455
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for method run of class ActionModule
    """
    # Initialize the class object
    action_module = ActionModule()

    # Initialize the task object
    task = dict()

    # Initialize the task_vars object
    task_vars = dict()

    # Initialize the args object
    args = dict()

    # Initialize the data object
    data = dict()

    # Initialize the result object
    result = dict()

    # Initialize the tmp object
    tmp = None

    # Initialize the stats object
    stats = dict()

    # Initialize the k object
    k = None

    # Initialize the v object
    v = None

    # Initialize the opt object
    opt = None

    # Initialize the val object
    val = None

    # Initialize the data object
    data

# Generated at 2022-06-17 09:46:10.685418
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'data': {'test': 'test'}}
    # Create a mock action module
    action_module = MockActionModule()
    action_module._task = task
    # Create a mock templar
    templar = MockTemplar()
    action_module._templar = templar
    # Create a mock result
    result = MockResult()
    # Create a mock task_vars
    task_vars = MockTaskVars()
    # Call the run method of the action module
    action_module.run(task_vars=task_vars)
    # Check the result
    assert result.changed == False

# Generated at 2022-06-17 09:46:11.874115
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:46:19.384306
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.action.set_stats import ActionModule
    from ansible.utils.vars import isidentifier
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars

    # Create a mock task object
    class MockTask:
        def __init__(self):
            self.args = {}
            self.action = 'set_stats'

    # Create a mock play context
    class MockPlayContext:
        def __init__(self):
            self.connection = 'local'
            self.network_os = 'default'
            self.remote_addr = '192.168.1.1'
            self.port = 22
            self.remote_user = 'root'


# Generated at 2022-06-17 09:46:20.685234
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:46:22.229202
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:46:34.683352
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:46:40.608453
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule(None, None)
    assert action_module is not None

    # Test with arguments
    action_module = ActionModule(None, None, {'data': {'test_key': 'test_value'}})
    assert action_module is not None
    assert action_module.run({}, {}) is not None


# Generated at 2022-06-17 09:46:41.477081
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:46:49.589095
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test the method run of class ActionModule
    """
    # Create a mock task
    mock_task = MockTask()
    mock_task.args = {'data': {'a': 1, 'b': 2}, 'per_host': True, 'aggregate': False}

    # Create a mock play context
    mock_play_context = MockPlayContext()

    # Create a mock templar
    mock_templar = MockTemplar()

    # Create a mock module_utils
    mock_module_utils = MockModuleUtils()

    # Create a mock action base
    mock_action_base = MockActionBase()

    # Create a ActionModule object
    action_module = ActionModule(mock_task, mock_play_context, mock_templar, mock_module_utils, mock_action_base)

   

# Generated at 2022-06-17 09:47:00.098876
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict()
    task['action'] = 'set_stats'
    task['args'] = dict()
    task['args']['data'] = dict()
    task['args']['data']['foo'] = 'bar'
    task['args']['data']['baz'] = 'qux'
    task['args']['per_host'] = False
    task['args']['aggregate'] = True

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock tmp
    tmp = None

    # Create a mock ActionBase
    action_base = ActionBase()

    # Create a mock ActionModule
    action_module = ActionModule(task, action_base._connection, tmp, task_vars)

    # Run the method run of

# Generated at 2022-06-17 09:47:31.175809
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:47:36.196778
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    am = ActionModule(None, None)
    assert am.run(None, None) == {'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}, 'changed': False}

    # Test with args
    am = ActionModule(None, dict(data=dict(foo='bar'), aggregate=True, per_host=False))
    assert am.run(None, None) == {'ansible_stats': {'data': {'foo': 'bar'}, 'per_host': False, 'aggregate': True}, 'changed': False}

# Generated at 2022-06-17 09:47:37.338604
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 09:47:39.452684
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 09:47:50.510581
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text
    from ansible.plugins.action import ActionBase

    class TestActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            return super(TestActionModule, self).run(tmp, task_vars)

    class TestActionBase(ActionBase):
        def run(self, tmp=None, task_vars=None):
            return super(TestActionBase, self).run(tmp, task_vars)

    class TestTemplar:
        def __init__(self):
            self.template_data = {'test_var': 'test_value'}


# Generated at 2022-06-17 09:47:57.441190
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'data': {'test_key': 'test_value'}}

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action module
    action_module = MockActionModule(task, templar)

    # Run the method
    result = action_module.run()

    # Assert the result
    assert result['ansible_stats']['data']['test_key'] == 'test_value'


# Generated at 2022-06-17 09:48:01.068328
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of ActionModule
    action_module = ActionModule()
    # Assert that the instance is an instance of ActionModule
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-17 09:48:02.545594
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:48:13.523389
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = type('task', (object,), {'args': {'data': {'foo': 'bar'}}})()

    # Create a mock templar
    templar = type('templar', (object,), {'template': lambda x, **kwargs: x})()

    # Create a mock action module
    action_module = type('action_module', (object,), {'_task': task, '_templar': templar})()

    # Call the run method of the action module
    result = action_module.run()

    # Assert the result
    assert result == {'changed': False, 'ansible_stats': {'data': {'foo': 'bar'}, 'per_host': False, 'aggregate': True}}

# Generated at 2022-06-17 09:48:17.401450
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:49:10.229176
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_host_vars

# Generated at 2022-06-17 09:49:17.953630
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module._task = {'args': {'data': {'a': 1, 'b': 2}, 'per_host': True, 'aggregate': False}}
    action_module._templar = {'template': lambda x, y, z: x}
    assert action_module.run() == {'changed': False, 'ansible_stats': {'data': {'a': 1, 'b': 2}, 'per_host': True, 'aggregate': False}}

# Generated at 2022-06-17 09:49:20.220581
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:49:25.758893
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=dict(action=dict(module_name='set_stats', module_args=dict(data=dict(a=1, b=2)))))

# Generated at 2022-06-17 09:49:30.823603
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.module_utils._text import to_text
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import IncludeRole
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action

# Generated at 2022-06-17 09:49:38.908051
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_vars_from_inventory

# Generated at 2022-06-17 09:49:40.973021
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:49:44.428418
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 09:49:45.267003
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:49:56.028890
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.utils.vars import merge_hash

    module = AnsibleModule(
        argument_spec=dict(
            aggregate=dict(type='bool', default=True),
            data=dict(type='dict', default={}),
            per_host=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )

    action = ActionModule(module, {})
    action.datastore = {'hostvars': {'host1': {'ansible_host': 'host1'}, 'host2': {'ansible_host': 'host2'}}}
    action

# Generated at 2022-06-17 09:51:58.564411
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.action.set_stats import ActionModule
    from ansible.utils.vars import isidentifier
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block


# Generated at 2022-06-17 09:52:01.735784
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test for method run of class ActionModule
    assert True

# Generated at 2022-06-17 09:52:10.977472
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.set_stats import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-17 09:52:12.360064
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-17 09:52:16.754436
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:52:19.598714
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None, None, None)
    assert action._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))
    assert action.TRANSFERS_FILES == False

# Generated at 2022-06-17 09:52:33.387235
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    am = ActionModule(dict(name='test'))
    assert am.run() == {'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}, 'changed': False}

    # Test with args
    am = ActionModule(dict(name='test', args=dict(data=dict(a=1, b=2), per_host=True, aggregate=False)))
    assert am.run() == {'ansible_stats': {'data': {'a': 1, 'b': 2}, 'per_host': True, 'aggregate': False}, 'changed': False}

    # Test with args with templating

# Generated at 2022-06-17 09:52:38.587914
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    action_module = ActionModule(None, None, None, None, None, None, None, None, None, None)
    assert action_module.run() == {'changed': False, 'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}}

    # Test with args
    action_module = ActionModule(None, None, None, None, None, None, None, None, None, {'data': {'test': 'test'}})
    assert action_module.run() == {'changed': False, 'ansible_stats': {'data': {'test': 'test'}, 'per_host': False, 'aggregate': True}}

# Generated at 2022-06-17 09:52:42.018662
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test the constructor of class ActionModule
    # Create an instance of class ActionModule
    action_module = ActionModule()
    # Assert that the instance is created successfully
    assert action_module is not None


# Generated at 2022-06-17 09:52:47.079664
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=dict(action=dict(module_name='set_stats')))