

# Generated at 2022-06-17 09:43:34.020057
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:43:36.336111
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:43:43.537063
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    action._task = {'args': {'data': {'test': 'test'}}}
    action._templar = {'template': lambda x, y, z: x}
    assert action.run() == {'changed': False, 'ansible_stats': {'data': {'test': 'test'}, 'per_host': False, 'aggregate': True}}

# Generated at 2022-06-17 09:43:45.912818
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:43:48.897272
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am.TRANSFERS_FILES == False
    assert am._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-17 09:43:50.991584
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:43:58.364501
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict()
    task['args'] = dict()
    task['args']['data'] = dict()
    task['args']['data']['test'] = 'test'
    task['args']['per_host'] = True
    task['args']['aggregate'] = False

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock templar
    templar = dict()
    templar['template'] = lambda x, convert_bare=False, fail_on_undefined=True: x

    # Create a mock self
    self = dict()
    self['_task'] = task
    self['_templar'] = templar

    # Create a mock result
    result = dict()
    result['changed'] = False

# Generated at 2022-06-17 09:44:01.486944
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor test
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module

# Generated at 2022-06-17 09:44:11.537993
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.utils.vars import isidentifier

    # Test with no args
    action = ActionModule(dict(name='test_action', action='set_stats'))
    result = action.run(task_vars=dict())
    assert result['changed'] == False
    assert result['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True}

    # Test with args
    action = ActionModule(dict(name='test_action', action='set_stats', args=dict(data=dict(a=1, b=2, c=3))))
    result = action.run(task_vars=dict())

# Generated at 2022-06-17 09:44:16.072254
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Check if the instance is an instance of class ActionModule
    assert isinstance(action_module, ActionModule)

    # Check if the instance is an instance of class ActionBase
    assert isinstance(action_module, ActionBase)

# Generated at 2022-06-17 09:44:26.228610
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:44:36.641755
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task object
    task = dict(
        action=dict(
            module_name='set_stats',
            module_args=dict(
                data=dict(
                    a=1,
                    b=2,
                    c=3
                ),
                per_host=True,
                aggregate=False
            )
        )
    )

    # Create a mock task_vars object
    task_vars = dict()

    # Create a mock tmp object
    tmp = None

    # Create a mock ansible_vars object
    ansible_vars = dict()

    # Create a mock loader object
    loader = None

    # Create a mock play_context object
    play_context = None

    # Create a mock templar object
    templar = None

    # Create a mock connection object

# Generated at 2022-06-17 09:44:41.524629
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:44:44.110365
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:44:50.675839
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import isidentifier
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import is_complex_data
    from ansible.utils.vars import is_sequence
    from ansible.utils.vars import is_scalar
    from ansible.utils.vars import is_unsafe_proxy
    from ansible.utils.vars import is_list_of_strings
    from ansible.utils.vars import is_iterable
    from ansible.utils.vars import is_binary

# Generated at 2022-06-17 09:44:54.265292
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:45:03.183762
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.run() == {'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}, 'changed': False}

    # Test with invalid arguments
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.run(task_vars={'data': 'test'}) == {'msg': "The 'data' option needs to be a dictionary/hash", 'failed': True}

    # Test with valid arguments

# Generated at 2022-06-17 09:45:15.371459
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.process.worker import WorkerProcess
    from ansible.executor.process.result import ResultProcess

# Generated at 2022-06-17 09:45:22.838356
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:45:33.730482
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no args
    task_args = {}
    task_vars = {}
    tmp = None
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action_module.run(tmp, task_vars)
    assert result['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True}
    assert result['changed'] == False

    # Test with args
    task_args = {'data': {'test1': 'test1', 'test2': 'test2'}, 'per_host': True, 'aggregate': False}
    task_vars = {}
    tmp = None

# Generated at 2022-06-17 09:45:40.528625
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:45:50.922883
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:46:02.917029
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict()
    task['args'] = dict()
    task['args']['data'] = dict()
    task['args']['data']['a'] = 1
    task['args']['data']['b'] = 2
    task['args']['data']['c'] = 3
    task['args']['per_host'] = True
    task['args']['aggregate'] = False

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock templar
    templar = dict()
    templar['template'] = lambda x, y, z: x

    # Create a mock ActionBase
    action_base = dict()
    action_base['run'] = lambda x, y: dict()

    # Create an

# Generated at 2022-06-17 09:46:14.570896
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action module
    action_module = ActionModule(task, templar)

    # Create a mock result
    result = MockResult()

    # Create a mock task_vars
    task_vars = MockTaskVars()

    # Create a mock tmp
    tmp = MockTmp()

    # Create a mock args
    args = MockArgs()

    # Set the args of the task
    task.args = args

    # Set the result of the action module
    action_module.result = result

    # Test the run method of the action module
    action_module.run(tmp, task_vars)

    # Assert the result
    assert result.changed == False
   

# Generated at 2022-06-17 09:46:26.420709
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:46:27.304619
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:46:32.041960
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test_ActionModule_run: tests run method of class ActionModule
    module = ActionModule()
    assert module.run() == {'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}, 'changed': False}

# Generated at 2022-06-17 09:46:42.029739
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'data': {'test': 'test'}, 'per_host': False, 'aggregate': True}
    # Create a mock connection
    connection = MockConnection()
    # Create a mock module
    module = MockModule()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock action plugin
    action_plugin = ActionModule(task, connection, loader, templar, module)
    # Run the method run of the action plugin
    result = action_plugin.run()
    # Test the result
    assert result['changed'] == False

# Generated at 2022-06-17 09:46:49.835767
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_v

# Generated at 2022-06-17 09:47:00.277070
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:47:12.105023
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:47:14.451728
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement this unit test
    pass

# Generated at 2022-06-17 09:47:16.632336
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:47:18.857260
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:47:28.189906
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:47:34.744551
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    am = ActionModule()
    assert am.run() == {'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}, 'changed': False}

    # Test with valid arguments
    am = ActionModule()
    assert am.run(task_vars={'test_var': 'test_value'}) == {'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}, 'changed': False}

    # Test with invalid arguments
    am = ActionModule()
    assert am.run(task_vars={'test_var': 'test_value'}) == {'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}, 'changed': False}

# Generated at 2022-06-17 09:47:36.278780
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test for ActionModule.run
    pass

# Generated at 2022-06-17 09:47:44.650085
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'data': {'foo': 'bar'}}

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action module
    action_module = ActionModule(task, templar)

    # Run the method
    result = action_module.run()

    # Check the result
    assert result['ansible_stats']['data']['foo'] == 'bar'


# Generated at 2022-06-17 09:47:46.929976
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:47:57.294746
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with empty task
    task = dict()
    action = ActionModule(task, dict())
    assert action._task == task
    assert action._connection is None
    assert action._play_context is None
    assert action._loader is None
    assert action._templar is None
    assert action._shared_loader_obj is None

    # Test with non-empty task
    task = dict(action=dict(module_name='set_stats', module_args=dict(data=dict(a=1, b=2))))
    action = ActionModule(task, dict())
    assert action._task == task
    assert action._connection is None
    assert action._play_context is None
    assert action._loader is None
    assert action._templar is None
    assert action._shared_loader_obj is None


# Generated at 2022-06-17 09:48:26.513990
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    am = ActionModule(None, None)
    assert am._task.args == {}

    # Test with args
    am = ActionModule(None, None, {'data': {'foo': 'bar'}})
    assert am._task.args == {'data': {'foo': 'bar'}}

# Generated at 2022-06-17 09:48:29.652955
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:48:40.588788
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule(None, None)
    assert action_module.run() == {'changed': False, 'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}}

    # Test with valid arguments
    action_module = ActionModule(None, {'data': {'a': 'b'}, 'per_host': True, 'aggregate': False})
    assert action_module.run() == {'changed': False, 'ansible_stats': {'data': {'a': 'b'}, 'per_host': True, 'aggregate': False}}

    # Test with invalid arguments
    action_module = ActionModule(None, {'data': 'a'})
    assert action_module.run()['failed'] == True
    assert action_module.run()

# Generated at 2022-06-17 09:48:48.171443
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = {
        'args': {
            'data': {
                'test': '{{ test }}'
            },
            'per_host': True,
            'aggregate': False
        }
    }

    # Create a mock task_vars
    task_vars = {
        'test': 'test'
    }

    # Create a mock result
    result = {
        'changed': False,
        'ansible_stats': {
            'data': {
                'test': 'test'
            },
            'per_host': True,
            'aggregate': False
        }
    }

    # Create a mock ActionModule
    action_module = ActionModule(task, task_vars)

    # Run the method run of class ActionModule

# Generated at 2022-06-17 09:48:57.833816
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import isidentifier
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import is_complex_data
    from ansible.utils.vars import is_sequence
    from ansible.utils.vars import is_scalar

    class ActionModule(ActionBase):

        TRANSFERS_FILES = False
        _VALID_ARGS = frozenset(('aggregate', 'data', 'per_host'))

        def run(self, tmp=None, task_vars=None):
            if task_vars is None:
                task_vars

# Generated at 2022-06-17 09:49:08.841338
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:49:19.755939
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class AnsibleModule:
        def __init__(self, argument_spec, bypass_checks=False):
            self.argument_spec = argument_spec
            self.params = {}
            self.check_mode = bypass_checks

    class AnsibleTask:
        def __init__(self, args):
            self.args = args

    class AnsiblePlay:
        def __init__(self, connection, remote_user, become, become_method, become_user, check_mode, diff):
            self.connection = connection
            self.remote_user = remote_user
            self.become = become
            self.become_method = become_method
            self.become_user = become_user
            self.check_mode = check_mode
            self.diff = diff


# Generated at 2022-06-17 09:49:22.451678
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-17 09:49:23.917228
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:49:34.825912
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    action_module = ActionModule(None, None)
    assert action_module.run() == {'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}, 'changed': False}

    # Test with args
    action_module = ActionModule(None, {'data': {'foo': 'bar'}, 'per_host': True, 'aggregate': False})
    assert action_module.run() == {'ansible_stats': {'data': {'foo': 'bar'}, 'per_host': True, 'aggregate': False}, 'changed': False}

# Generated at 2022-06-17 09:50:32.094866
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = MockTask()
    task.args = {'data': {'a': 1, 'b': 2}, 'aggregate': True, 'per_host': False}

    # Create a mock templar object
    templar = MockTemplar()

    # Create a mock action module
    action_module = ActionModule(task, templar)

    # Run the action module
    result = action_module.run()

    # Assert the result
    assert result['ansible_stats']['data'] == {'a': 1, 'b': 2}
    assert result['ansible_stats']['aggregate'] == True
    assert result['ansible_stats']['per_host'] == False


# Generated at 2022-06-17 09:50:36.196359
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:50:39.942921
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:50:48.412836
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import isidentifier
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

# Generated at 2022-06-17 09:50:51.230216
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None, None, None, None, None, None)

# Generated at 2022-06-17 09:50:52.124532
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:50:53.581612
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:51:00.040684
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.utils.vars import isidentifier

    # Test with no args
    action_module = ActionModule(dict(action=dict(module_name='set_stats')))
    result = action_module.run(task_vars=dict())
    assert result['changed'] == False
    assert result['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True}

    # Test with args
    action_module = ActionModule(dict(action=dict(module_name='set_stats', args=dict(data=dict(a=1, b=2), per_host=True, aggregate=False))))
    result = action_module.run

# Generated at 2022-06-17 09:51:03.885202
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:51:06.552019
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of class ActionModule
    action_module = ActionModule()
    # Check if the instance is an instance of class ActionModule
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-17 09:52:53.850210
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.action.set_stats import ActionModule
    from ansible.utils.vars import isidentifier
    from ansible.utils.vars import merge_hash

    # test for method run of class ActionModule
    # test for valid data
    # test for valid data
    # test for valid data
    # test for valid data
    # test for valid data
    # test for valid data
    # test for valid data
    # test for valid data
    # test for valid data
    # test for valid data
    # test for valid data
    # test for valid data
    # test for valid data
    # test for valid data
    # test for valid data
    # test for valid data
    # test for valid data
    # test for valid

# Generated at 2022-06-17 09:53:03.191434
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:53:03.953294
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:53:09.568982
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_host_vars
    from ansible.utils.vars import load_vars

# Generated at 2022-06-17 09:53:13.050718
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None, None)
    assert action is not None

# Generated at 2022-06-17 09:53:20.538285
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:53:31.720489
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of class ActionModule
    action_module = ActionModule()
    # Check if the instance is an instance of class ActionModule
    assert isinstance(action_module, ActionModule)
    # Check if the instance is an instance of class ActionBase
    assert isinstance(action_module, ActionBase)
    # Check if the instance has the attribute TRANSFERS_FILES
    assert hasattr(action_module, 'TRANSFERS_FILES')
    # Check if the instance has the attribute _VALID_ARGS
    assert hasattr(action_module, '_VALID_ARGS')
    # Check if the instance has the attribute run
    assert hasattr(action_module, 'run')
    # Check if the instance has the attribute _load_params
    assert hasattr(action_module, '_load_params')
    # Check