

# Generated at 2022-06-17 09:43:36.015797
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Check if the instance is an instance of class ActionModule
    assert isinstance(action_module, ActionModule)

    # Check if the instance is an instance of class ActionBase
    assert isinstance(action_module, ActionBase)

# Generated at 2022-06-17 09:43:39.230020
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-17 09:43:42.813634
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-17 09:43:43.840673
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 09:43:50.853941
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:43:51.859815
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 09:43:53.914483
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:44:02.496676
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no args
    task = dict(action=dict(module='set_stats', args=dict()))
    action = ActionModule(task, dict())
    result = action.run(None, dict())
    assert result['ansible_stats'] == dict(data=dict(), per_host=False, aggregate=True)

    # Test with args
    task = dict(action=dict(module='set_stats', args=dict(data=dict(foo='bar'), per_host=True, aggregate=False)))
    action = ActionModule(task, dict())
    result = action.run(None, dict())
    assert result['ansible_stats'] == dict(data=dict(foo='bar'), per_host=True, aggregate=False)

    # Test with args

# Generated at 2022-06-17 09:44:03.866861
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:44:05.403686
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict())

# Generated at 2022-06-17 09:44:20.613786
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule class
    action_module = ActionModule()

    # Create an instance of AnsibleModule class
    ansible_module = AnsibleModule(
        argument_spec = dict(
            data=dict(type='dict', required=True),
            aggregate=dict(type='bool', required=False),
            per_host=dict(type='bool', required=False),
        ),
        supports_check_mode=True
    )

    # Set the data option to a valid dictionary
    ansible_module.params['data'] = dict(
        test_key1='test_value1',
        test_key2='test_value2',
    )

    # Set the aggregate option to a valid boolean value
    ansible_module.params['aggregate'] = True

    # Set the per_host option to a valid boolean value

# Generated at 2022-06-17 09:44:21.657561
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:44:26.170900
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-17 09:44:27.698275
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:44:37.638967
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import isidentifier
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import is_complex_data
    from ansible.utils.vars import is_list_of_strings

    class ActionModule(ActionBase):
        TRANSFERS_FILES = False
        _VALID_ARGS = frozenset(('aggregate', 'data', 'per_host'))

        def run(self, tmp=None, task_vars=None):
            if task_vars is None:
                task_vars = dict()


# Generated at 2022-06-17 09:44:44.370759
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object of class ActionModule
    mock_ActionModule = ActionModule()

    # Create a mock object of class Task
    mock_Task = Task()

    # Create a mock object of class AnsibleModule
    mock_AnsibleModule = AnsibleModule()

    # Create a mock object of class AnsibleModule
    mock_AnsibleModule = AnsibleModule()

    # Create a mock object of class AnsibleModule
    mock_AnsibleModule = AnsibleModule()

    # Create a mock object of class AnsibleModule
    mock_AnsibleModule = AnsibleModule()

    # Create a mock object of class AnsibleModule
    mock_AnsibleModule = AnsibleModule()

    # Create a mock object of class AnsibleModule
    mock_AnsibleModule = AnsibleModule()

    # Create a mock object of class Ansible

# Generated at 2022-06-17 09:44:50.771808
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import isidentifier
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import is_complex_data
    from ansible.utils.vars import is_sequence
    from ansible.utils.vars import is_scalar
    from ansible.utils.vars import is_traversable
    from ansible.utils.vars import is_iterable
    from ansible.utils.vars import is_list_of_strings
    from ansible.utils.vars import is_hashable
    from ansible.utils.vars import is_boolean

# Generated at 2022-06-17 09:45:01.674980
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:45:10.581166
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'data': {'a': 'b'}}

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock action_base
    action_base = MockActionBase()

    # Create an instance of ActionModule
    action_module = ActionModule(task, templar, module_utils, action_base)

    # Call method run
    result = action_module.run()

    # Check result
    assert result == {'changed': False, 'ansible_stats': {'data': {'a': 'b'}, 'per_host': False, 'aggregate': True}}



# Generated at 2022-06-17 09:45:22.117727
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:45:41.812383
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = {'args': {'data': {'a': 1, 'b': 2}, 'per_host': True, 'aggregate': False}}
    # Create a mock task_vars
    task_vars = {}
    # Create a mock ansible_vars
    ansible_vars = {}
    # Create a mock templar
    templar = {}
    # Create a mock module_vars
    module_vars = {}
    # Create a mock loader
    loader = {}
    # Create a mock play_context
    play_context = {}
    # Create a mock shared_loader_obj
    shared_loader_obj = {}
    # Create a mock connection
    connection = {}
    # Create a mock action_base

# Generated at 2022-06-17 09:45:46.422596
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test constructor of class ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:45:51.016980
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:45:53.614384
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create a class instance
    am = ActionModule()
    # check if the class instance is created successfully
    assert am is not None

# Generated at 2022-06-17 09:46:05.602235
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock action module
    action_module = MockActionModule(task)
    # Create a mock templar
    templar = MockTemplar()
    # Set the templar in the action module
    action_module._templar = templar
    # Create a mock result
    result = MockResult()
    # Set the result in the action module
    action_module._result = result
    # Create a mock task vars
    task_vars = MockTaskVars()
    # Set the task vars in the action module
    action_module._task_vars = task_vars

    # Set the args in the task

# Generated at 2022-06-17 09:46:16.297818
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:46:19.937042
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action is not None

# Generated at 2022-06-17 09:46:28.918643
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:46:29.649862
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    assert False

# Generated at 2022-06-17 09:46:38.045412
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.utils.vars import isidentifier
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.set_stats import ActionModule
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

# Generated at 2022-06-17 09:47:09.089249
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import isidentifier
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import is_complex_data
    from ansible.utils.vars import is_iterable
    from ansible.utils.vars import is_list_of_strings
    from ansible.utils.vars import is_sequence
    from ansible.utils.vars import is_scalar
    from ansible.utils.vars import is_unsafe_proxy
    from ansible.utils.vars import is_traversable
    from ansible.utils.vars import is_

# Generated at 2022-06-17 09:47:16.039616
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test with no args
    am = ActionModule(None, None, None, None, None, None)
    assert am.run() == {'changed': False, 'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}}

    # test with args
    am = ActionModule(None, None, None, None, None, {'data': {'foo': 'bar'}, 'per_host': True, 'aggregate': False})
    assert am.run() == {'changed': False, 'ansible_stats': {'data': {'foo': 'bar'}, 'per_host': True, 'aggregate': False}}

# Generated at 2022-06-17 09:47:19.441003
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None, None, None, None, None)

# Generated at 2022-06-17 09:47:21.606915
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:47:27.408169
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, None, None, None, None, None, None)
    assert am._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-17 09:47:28.317340
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: implement
    assert False

# Generated at 2022-06-17 09:47:36.930605
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    action_module = ActionModule(None, None, None, None, None)
    assert action_module.run() == {'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}, 'changed': False}

    # Test with args
    action_module = ActionModule(None, None, None, None, None)
    assert action_module.run(task_vars={'test_var': 'test_val'}) == {'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}, 'changed': False}

    # Test with args
    action_module = ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:47:39.036425
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict())

# Generated at 2022-06-17 09:47:41.002867
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, None, None)
    assert am is not None

# Generated at 2022-06-17 09:47:49.634453
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    am = ActionModule()

    # Create a test task
    task = {
        'args': {
            'data': {
                'test_key': 'test_value'
            }
        }
    }

    # Create a test result
    result = {
        'changed': False,
        'ansible_stats': {
            'data': {
                'test_key': 'test_value'
            },
            'per_host': False,
            'aggregate': True
        }
    }

    # Run the method run of class ActionModule
    assert am.run(task_vars=task) == result

# Generated at 2022-06-17 09:48:41.128999
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:48:45.446998
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:48:47.350409
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:48:57.780953
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.run() == {'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}, 'changed': False}

    # Test with args
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module._task.args = {'data': {'a': 1, 'b': 2}, 'per_host': True, 'aggregate': False}

# Generated at 2022-06-17 09:49:00.448173
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:49:09.341857
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import builtins
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import isidentifier

    # Mock class for module_utils.basic.AnsibleModule
    class MockAnsibleModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            AnsibleModule.__init__(self, *args, **kwargs)
            self.params = {'data': {'a': '1', 'b': '2'}, 'per_host': 'yes', 'aggregate': 'no'}

   

# Generated at 2022-06-17 09:49:16.799009
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no arguments
    action = ActionModule()
    action._task = {'args': {}}
    result = action.run()
    assert result['ansible_stats']['data'] == {}
    assert result['ansible_stats']['per_host'] == False
    assert result['ansible_stats']['aggregate'] == True

    # Test with arguments
    action = ActionModule()
    action._task = {'args': {'data': {'foo': 'bar'}, 'per_host': True, 'aggregate': False}}
    result = action.run()
    assert result['ansible_stats']['data'] == {'foo': 'bar'}
    assert result['ansible_stats']['per_host'] == True
    assert result['ansible_stats']['aggregate'] == False

# Generated at 2022-06-17 09:49:26.348764
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class TaskExecutor
    task_executor = TaskExecutor()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class DataLoader
    data_loader = DataLoader()

    # Create an instance of class VariableManager
    variable_manager = VariableManager()

    # Create an instance of class Play
    play = Play()

    # Create an instance of class Playbook
    playbook = Playbook()

    # Create an instance of class Runner
    runner = Runner()

    # Create an instance of class Connection
    connection = Connection()

    # Create an instance of class ShellModule
    shell_module = ShellModule()

    # Create an instance

# Generated at 2022-06-17 09:49:35.395257
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task and action module
    task = MockTask()
    action_module = ActionModule(task, MockConnection())

    # Create a mock templar
    templar = MockTemplar()

    # Set the templar attribute of the action module to the mock templar
    action_module._templar = templar

    # Create a mock task args
    task_args = {'data': {'foo': 'bar'}}

    # Set the args attribute of the mock task to the mock task args
    task.args = task_args

    # Call the run method of the action module
    result = action_module.run(None, None)

    # Assert that the result is as expected

# Generated at 2022-06-17 09:49:36.111374
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:51:32.078593
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of ActionModule
    action_module = ActionModule()
    # Check that the instance is an instance of ActionModule
    assert isinstance(action_module, ActionModule)
    # Check that the instance is an instance of ActionBase
    assert isinstance(action_module, ActionBase)

# Generated at 2022-06-17 09:51:42.349325
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text

    # Test with no args
    am = ActionModule(dict(ANSIBLE_MODULE_ARGS={}), dict())
    result = am.run(None, None)
    assert result['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True}

    # Test with args
    am = ActionModule(dict(ANSIBLE_MODULE_ARGS=dict(data=dict(a=1, b=2), per_host=True, aggregate=False)), dict())
    result = am.run(None, None)

# Generated at 2022-06-17 09:51:48.213262
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_vars_from_inventory

# Generated at 2022-06-17 09:51:58.202144
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.set_stats import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import isidentifier
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-17 09:52:10.103081
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a task
    task = Task()

    # Create a variable manager
    variable_manager = VariableManager()

    # Create a templar
    templar = Templar(loader=None, variables=variable_manager)

    # Create an action module
    action_module = ActionModule(task, templar, variable_manager)

    # Create a result
    result = dict()

    # Create a tmp
    tmp = None

    # Create a task_vars
    task_vars = dict()

    # Test the run method
    action_module.run(tmp, task_vars)

    #

# Generated at 2022-06-17 09:52:20.144653
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    variable_manager._extra_vars = {'foo': 'bar'}


# Generated at 2022-06-17 09:52:33.551246
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_vars_from_inventory

# Generated at 2022-06-17 09:52:34.534295
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:52:46.730910
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    action_module = ActionModule(task=dict(action=dict(module_name='set_stats', module_args=dict())))
    assert action_module.run() == {'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}, 'changed': False}

    # Test with args
    action_module = ActionModule(task=dict(action=dict(module_name='set_stats', module_args=dict(data=dict(a=1, b=2, c=3)))))
    assert action_module.run() == {'ansible_stats': {'data': {'a': 1, 'b': 2, 'c': 3}, 'per_host': False, 'aggregate': True}, 'changed': False}

    # Test with args
    action_module

# Generated at 2022-06-17 09:52:51.455991
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(action=dict(module_name='set_stats', module_args=dict(data=dict(a=1, b=2), per_host=True, aggregate=False))),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert action_module