

# Generated at 2022-06-17 09:43:43.700643
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:43:54.587301
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_vars_from_inventory

# Generated at 2022-06-17 09:44:01.100904
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None


# Generated at 2022-06-17 09:44:09.336915
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock object for the module_utils/parsing/convert_bool.py
    # boolean function
    class MockBoolean(object):
        def __init__(self, value):
            self.value = value

        def __nonzero__(self):
            return self.value

    # Create a mock object for the module_utils/vars.py isidentifier function
    class MockIsIdentifier(object):
        def __init__(self, value):
            self.value = value

        def __nonzero__(self):
            return self.value

    # Create a mock object for the templar.template function
    class MockTemplate(object):
        def __init__(self, value):
            self.value = value


# Generated at 2022-06-17 09:44:20.536375
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = MockTask()
    # Create a mock play context
    play_context = MockPlayContext()
    # Create a mock connection
    connection = MockConnection()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock action base
    action_base = ActionBase(task, connection, play_context, loader, templar)
    # Create an instance of ActionModule
    action_module = ActionModule(task, connection, play_context, loader, templar)
    # Check if the instance is an instance of ActionBase
    assert isinstance(action_module, ActionBase)
    # Check if the instance is an instance of ActionModule
    assert isinstance(action_module, ActionModule)

# Unit test

# Generated at 2022-06-17 09:44:31.635667
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no parameters
    am = ActionModule(None, None)
    assert am.run(None, None) == {'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}, 'changed': False}

    # Test with parameters
    am = ActionModule(None, {'data': {'foo': 'bar'}, 'per_host': 'yes', 'aggregate': 'no'})
    assert am.run(None, None) == {'ansible_stats': {'data': {'foo': 'bar'}, 'per_host': True, 'aggregate': False}, 'changed': False}

# Generated at 2022-06-17 09:44:38.474462
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = type('MockTask', (object,), {'args': {'data': {'a': 'b'}}})()
    # Create a mock templar
    mock_templar = type('MockTemplar', (object,), {'template': lambda x: x})()
    # Create a mock action module
    mock_action_module = type('MockActionModule', (ActionModule,), {'_task': mock_task, '_templar': mock_templar})()
    # Run the method
    result = mock_action_module.run()
    # Assert the result
    assert result['ansible_stats']['data']['a'] == 'b'

# Generated at 2022-06-17 09:44:49.106665
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of class ActionModule
    action_module = ActionModule()
    # Test if the instance is an instance of class ActionModule
    assert isinstance(action_module, ActionModule)
    # Test if the instance is an instance of class ActionBase
    assert isinstance(action_module, ActionBase)
    # Test if the instance is an instance of class object
    assert isinstance(action_module, object)
    # Test if the instance has the attribute _VALID_ARGS
    assert hasattr(action_module, '_VALID_ARGS')
    # Test if the instance has the attribute TRANSFERS_FILES
    assert hasattr(action_module, 'TRANSFERS_FILES')
    # Test if the instance has the attribute run
    assert hasattr(action_module, 'run')
    # Test if the instance has the

# Generated at 2022-06-17 09:44:59.049697
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = dict()
    task['args'] = dict()
    task['args']['data'] = {'foo': 'bar'}
    task['args']['per_host'] = True
    task['args']['aggregate'] = False

    # Create a mock templar
    templar = dict()
    templar['template'] = lambda x: x

    # Create a mock action module
    action_module = ActionModule(task, templar)

    # Run the action module
    result = action_module.run()

    # Check the result
    assert result['ansible_stats']['data']['foo'] == 'bar'
    assert result['ansible_stats']['per_host'] == True

# Generated at 2022-06-17 09:45:08.363393
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(
            args=dict(
                aggregate=True,
                data=dict(
                    foo='bar'
                ),
                per_host=True
            )
        ),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert action_module.run() == dict(
        ansible_stats=dict(
            aggregate=True,
            data=dict(
                foo='bar'
            ),
            per_host=True
        ),
        changed=False
    )

# Generated at 2022-06-17 09:45:14.912640
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module.run()

# Generated at 2022-06-17 09:45:17.918370
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:45:24.600606
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:45:28.650365
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task and action module
    task = MockTask()
    action_module = ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create a mock result
    result = MockResult()

    # Create a mock task_vars
    task_vars = {}

    # Call the run method of the action module
    action_module.run(tmp=None, task_vars=task_vars)

    # Assert that the result is correct
    assert result.changed == False
    assert result.ansible_stats == {'data': {}, 'per_host': False, 'aggregate': True}


# Generated at 2022-06-17 09:45:40.828214
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:45:51.136707
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_vars_from_inventory

# Generated at 2022-06-17 09:46:03.023991
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_vars
    from ansible.utils.vars import combine_facts
   

# Generated at 2022-06-17 09:46:14.702755
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:46:17.021527
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Unit test for constructor of class ActionModule
    """
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-17 09:46:18.487278
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:46:32.985006
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-17 09:46:34.856870
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:46:36.788283
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-17 09:46:37.803603
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:46:47.139433
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test_ActionModule: create an instance of the class with its important input parameters
    module = ActionModule(task=dict(action=dict(module_name='set_stats', module_args=dict(data=dict(a=1, b=2), aggregate=True, per_host=False))),
                          connection=None,
                          play_context=None,
                          loader=None,
                          templar=None,
                          shared_loader_obj=None)

    # test_ActionModule: test the run function of the class
    result = module.run(tmp=None, task_vars=dict())
    assert result['ansible_stats']['data'] == {'a': 1, 'b': 2}
    assert result['ansible_stats']['per_host'] == False

# Generated at 2022-06-17 09:46:56.127360
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.utils.vars import isidentifier

    # create a mock task
    task = type('task', (object,), {})()
    task.args = {'data': {'a': 1, 'b': 2}, 'per_host': 'yes', 'aggregate': 'no'}

    # create a mock templar
    templar = type('templar', (object,), {})()
    templar.template = lambda x, convert_bare=False, fail_on_undefined=True: x

    # create a mock module
    module = type('module', (object,), {})()

# Generated at 2022-06-17 09:47:03.742213
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.ansible_modlib.module_common import AnsibleModule
    from ansible.module_utils.ansible_modlib.module_common import ModuleFailException
    from ansible.module_utils.ansible_modlib.module_common import ModuleExitException
    from ansible.module_utils.ansible_modlib.module_common import ModuleReturnValue
    from ansible.module_utils.ansible_modlib.module_common import ModuleSuccessException
    from ansible.module_utils.ansible_modlib.module_common import ModuleSkippedException
    from ansible.module_utils.ansible_modlib.module_common import ModuleAnsibleFailException
    from ansible.module_utils.ansible_modlib.module_common import AnsibleModule

# Generated at 2022-06-17 09:47:14.555158
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:47:16.387407
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:47:18.381757
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement test
    pass

# Generated at 2022-06-17 09:47:49.210596
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.action.set_stats import ActionModule
    from ansible.utils.vars import isidentifier
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.play_executor import PlayExecutor

# Generated at 2022-06-17 09:47:50.185148
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement test
    pass

# Generated at 2022-06-17 09:47:59.428582
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock task_vars
    task_vars = dict()
    # Create a mock tmp
    tmp = None
    # Create a mock ActionBase
    action_base = MockActionBase()
    # Create a mock ActionModule
    action_module = ActionModule(task, action_base._connection, tmp, task_vars)
    # Create a mock result
    result = dict()
    # Create a mock stats
    stats = dict()
    # Create a mock data
    data = dict()
    # Create a mock k
    k = 'k'
    # Create a mock v
    v = 'v'
    # Create a mock opt
    opt = 'opt'
    # Create a mock val
    val = 'val'
    # Create a mock boolean
    boolean

# Generated at 2022-06-17 09:48:00.285076
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:48:12.984274
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_vars_from_inventory

# Generated at 2022-06-17 09:48:16.455020
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 09:48:21.880394
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    action_module = ActionModule()

    # Create a task
    task = dict()

    # Create a task_vars
    task_vars = dict()

    # Create a result
    result = dict()

    # Create a tmp
    tmp = None

    # Call method run of class ActionModule
    result = action_module.run(tmp, task_vars)

    # Assertion: result['ansible_stats'] is not None
    assert result['ansible_stats'] is not None

    # Assertion: result['ansible_stats']['data'] is not None
    assert result['ansible_stats']['data'] is not None

    # Assertion: result['ansible_stats']['per_host'] is not None

# Generated at 2022-06-17 09:48:32.605695
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:48:34.192332
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None, None)
    assert action._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-17 09:48:41.763379
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = dict(
        action=dict(
            module_name='set_stats',
            module_args=dict(
                data=dict(
                    foo='bar',
                    baz='qux'
                ),
                per_host=True,
                aggregate=False
            )
        )
    )

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock loader
    loader = dict()

    # Create a mock templar
    templar = dict()

    # Create a mock display
    display = dict()

    # Create a mock action_base
    action_base = dict()

    # Create a mock connection
    connection = dict()

    # Create a mock play_context
    play_context = dict()

    # Create a mock AnsibleModule

# Generated at 2022-06-17 09:49:30.764856
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of class ActionModule
    action_module = ActionModule()
    # Check if the instance is an instance of class ActionModule
    assert isinstance(action_module, ActionModule)
    # Check if the instance is an instance of class ActionBase
    assert isinstance(action_module, ActionBase)
    # Check if the instance is an instance of class object
    assert isinstance(action_module, object)

# Generated at 2022-06-17 09:49:37.678028
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    module = ActionModule(None, None)
    assert module.run(None, None) == {'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}, 'changed': False}

    # Test with arguments
    module = ActionModule(None, {'data': {'a': 1}, 'per_host': True, 'aggregate': False})
    assert module.run(None, None) == {'ansible_stats': {'data': {'a': 1}, 'per_host': True, 'aggregate': False}, 'changed': False}

# Generated at 2022-06-17 09:49:49.098005
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a mock task
    task = MockTask()
    task.args = {'data': {'a': 1, 'b': 2}, 'per_host': True, 'aggregate': False}

    # create a mock templar
    templar = MockTemplar()

    # create a mock module_utils
    module_utils = MockModuleUtils()

    # create a mock action base
    action_base = MockActionBase()

    # create an instance of ActionModule
    action_module = ActionModule(task, templar, module_utils, action_base)

    # call run method of ActionModule
    result = action_module.run()

    # assert the result
    assert result['changed'] == False

# Generated at 2022-06-17 09:49:59.294399
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    action_module = ActionModule(None, None, None, None, None)
    assert action_module.run() == {'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}, 'changed': False}

    # Test with args
    action_module = ActionModule(None, None, None, None, None)
    action_module._task.args = {'data': {'test': 'test'}, 'per_host': True, 'aggregate': False}
    assert action_module.run() == {'ansible_stats': {'data': {'test': 'test'}, 'per_host': True, 'aggregate': False}, 'changed': False}

    # Test with args
    action_module = ActionModule(None, None, None, None, None)


# Generated at 2022-06-17 09:50:07.452360
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import isidentifier
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

# Generated at 2022-06-17 09:50:08.018089
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-17 09:50:09.106413
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:50:20.322669
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock module
    module = MockModule()

    # Create a mock action plugin
    action_plugin = ActionModule(task, connection, play_context, loader, templar, module)

    # Create a mock task result
    task_result = MockTaskResult()

    # Create a mock task vars
    task_vars = MockTaskVars()

    # Create a mock tmp
    tmp = MockTmp()

    # Test the run method of the action plugin

# Generated at 2022-06-17 09:50:22.138953
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-17 09:50:24.006486
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-17 09:52:10.475291
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-17 09:52:20.202787
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_bytes

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_context.network_os

# Generated at 2022-06-17 09:52:24.200209
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:52:36.270849
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:52:40.414117
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:52:41.544225
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:52:49.651420
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.set_stats import ActionModule
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_host_vars
    from ansible.utils.vars import load_vars
    from ansible.utils.vars import load_

# Generated at 2022-06-17 09:52:55.554402
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'data': {'test': 'test'}, 'per_host': True, 'aggregate': False}

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action module
    action_module = ActionModule(task, templar)

    # Call method run of class ActionModule
    result = action_module.run()

    # Check result
    assert result['changed'] == False
    assert result['ansible_stats']['data']['test'] == 'test'
    assert result['ansible_stats']['per_host'] == True
    assert result['ansible_stats']['aggregate'] == False



# Generated at 2022-06-17 09:52:56.353974
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 09:53:05.183062
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import isidentifier
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
   