

# Generated at 2022-06-17 09:43:38.780512
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:43:48.211094
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    action_module = ActionModule(None, None, None, None, None)
    assert action_module.run() == {'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}, 'changed': False}

    # Test with args
    action_module = ActionModule(None, None, None, None, {'data': {'a': 1}, 'per_host': True, 'aggregate': False})
    assert action_module.run() == {'ansible_stats': {'data': {'a': 1}, 'per_host': True, 'aggregate': False}, 'changed': False}

# Generated at 2022-06-17 09:43:57.672317
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'data': {'test': 'test'}}

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action module
    action_module = ActionModule(task, templar)

    # Call method run
    result = action_module.run()

    # Assert that the result is correct
    assert result['changed'] == False
    assert result['ansible_stats'] == {'data': {'test': 'test'}, 'per_host': False, 'aggregate': True}


# Generated at 2022-06-17 09:44:00.109525
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-17 09:44:11.431177
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action base
    action_base = MockActionBase()

    # Create a mock action module
    action_module = ActionModule(task, play_context, loader, templar, action_base)

    # Test with no data
    result = action_module.run()
    assert result['changed'] == False
    assert result['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True}

    # Test with data

# Generated at 2022-06-17 09:44:12.946121
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:44:15.982655
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-17 09:44:17.236323
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:44:26.160592
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:44:33.536359
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:44:44.463892
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am.run() == {'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}, 'changed': False}

    # Test with args
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    am._task.args = {'data': {'a': 'b'}}
    assert am.run() == {'ansible_stats': {'data': {'a': 'b'}, 'per_host': False, 'aggregate': True}, 'changed': False}

    # Test with

# Generated at 2022-06-17 09:44:47.834927
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:44:53.928424
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    # Create a mock task_vars
    task_vars = MockTaskVars()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock ActionBase
    action_base = MockActionBase()
    # Create a mock ActionModule
    action_module = ActionModule(task, templar, action_base)
    # Create a mock result
    result = MockResult()
    # Create a mock stats
    stats = MockStats()
    # Create a mock data
    data = MockData()
    # Create a mock per_host
    per_host = MockPerHost()
    # Create a mock aggregate
    aggregate = MockAggregate()
    # Create a mock val
    val = MockVal()
    # Create a mock k
   

# Generated at 2022-06-17 09:45:01.378619
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:45:04.540964
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:45:05.426551
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:45:15.951144
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load

# Generated at 2022-06-17 09:45:19.464535
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:45:23.081240
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-17 09:45:24.668752
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:45:35.720115
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-17 09:45:36.606408
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:45:47.267248
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:45:57.622416
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY3
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import isidentifier

    class ActionModule(ActionBase):

        TRANSFERS_FILES = False
        _VALID_ARGS = frozenset(('aggregate', 'data', 'per_host'))

        def run(self, tmp=None, task_vars=None):
            if task_vars is None:
                task_vars = dict()

            result = super(ActionModule, self).run(tmp, task_vars)
            del tmp  # tmp no longer has any effect


# Generated at 2022-06-17 09:46:09.623579
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'data': {'foo': 'bar'}}

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock action base
    action_base = MockActionBase()

    # Create a mock action module
    action_module = ActionModule(task, templar, module_utils, action_base)

    # Run the method
    result = action_module.run()

    # Assert that the result is correct
    assert result == {'changed': False, 'ansible_stats': {'data': {'foo': 'bar'}, 'per_host': False, 'aggregate': True}}


# Generated at 2022-06-17 09:46:11.102803
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-17 09:46:19.021016
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a fake task object
    task = type('Task', (object,), {})()
    task.args = {'data': {'test_key': 'test_value'}}
    task.args['per_host'] = True
    task.args['aggregate'] = False

    # Create a fake action module object
    action_module = type('ActionModule', (object,), {})()
    action_module._task = task

    # Create a fake action base object
    action_base = type('ActionBase', (object,), {})()
    action_base.run = lambda *args, **kwargs: {'changed': False}

    # Create a fake templar object
    templar = type('Templar', (object,), {})()

# Generated at 2022-06-17 09:46:33.721252
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'data': {'foo': 'bar'}}

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock action base
    action_base = MockActionBase()

    # Create a new instance of ActionModule
    action_module = ActionModule(task, templar, module_utils, action_base)

    # Call method run of class ActionModule
    result = action_module.run()

    # Assert that the result is correct
    assert result == {'changed': False, 'ansible_stats': {'data': {'foo': 'bar'}, 'per_host': False, 'aggregate': True}}

# Unit test

# Generated at 2022-06-17 09:46:35.077552
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict())

# Generated at 2022-06-17 09:46:36.789695
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    assert False

# Generated at 2022-06-17 09:47:09.025645
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:47:10.328334
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:47:17.936194
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict()
    task['args'] = dict()
    task['args']['data'] = dict()
    task['args']['data']['test_key'] = 'test_value'
    task['args']['per_host'] = False
    task['args']['aggregate'] = True

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock ansible_stats
    ansible_stats = dict()
    ansible_stats['data'] = dict()
    ansible_stats['data']['test_key'] = 'test_value'
    ansible_stats['per_host'] = False
    ansible_stats['aggregate'] = True

    # Create a mock result
    result = dict()

# Generated at 2022-06-17 09:47:18.929105
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    assert False

# Generated at 2022-06-17 09:47:21.913007
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test for method run of class ActionModule
    pass


# Generated at 2022-06-17 09:47:32.990424
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.plugins.action import ActionBase

    class TestActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            return super(TestActionModule, self).run(tmp, task_vars)

    class TestActionBase(ActionBase):
        def run(self, tmp=None, task_vars=None):
            return super(TestActionBase, self).run(tmp, task_vars)


# Generated at 2022-06-17 09:47:45.730034
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'data': {'foo': 'bar'}}

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock action base
    action_base = MockActionBase()

    # Create an instance of ActionModule
    action_module = ActionModule(task, templar, module_utils, action_base)

    # Call method run
    result = action_module.run()

    # Assert that the result is correct
    assert result['changed'] == False
    assert result['ansible_stats']['data']['foo'] == 'bar'
    assert result['ansible_stats']['per_host'] == False

# Generated at 2022-06-17 09:47:55.744710
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = MockTask()
    task.args = {'data': {'foo': 'bar'}}
    # Create a mock AnsibleModule object
    mock_ansible_module = MockAnsibleModule()
    # Create a mock AnsibleModule object
    mock_templar = MockTemplar()
    # Create a mock ActionBase object
    action_base_obj = ActionBase(mock_ansible_module, task, connection=None, play_context=None, loader=None, templar=mock_templar, shared_loader_obj=None)
    # Create a ActionModule object

# Generated at 2022-06-17 09:48:05.064971
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no args
    task_args = {}
    task_vars = {}
    tmp = None
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action_module.run(tmp, task_vars)
    assert result['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True}
    assert result['changed'] == False

    # Test with args
    task_args = {'data': {'test_key': 'test_value'}, 'per_host': True, 'aggregate': False}
    task_vars = {}
    tmp = None

# Generated at 2022-06-17 09:48:08.122798
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:48:56.318777
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:49:03.141116
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None, None, None)
    assert action._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))
    assert action.TRANSFERS_FILES == False

# Generated at 2022-06-17 09:49:06.818506
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 09:49:15.744095
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.action.set_stats import ActionModule
    from ansible.utils.vars import isidentifier
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import is_complex_data
    from ansible.utils.vars import is_sequence
    from ansible.utils.vars import is_scalar
    from ansible.utils.vars import is_list_of_strings
    from ansible.utils.vars import is_list_of_hashes
    from ansible.utils.vars import is_list_of_sequences
    from ansible.utils.vars import is_list_of_scal

# Generated at 2022-06-17 09:49:20.685759
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule(None, None)
    assert action_module is not None

    # Test with arguments
    action_module = ActionModule(None, None, {'data': {'test': 'test'}})
    assert action_module is not None

# Generated at 2022-06-17 09:49:25.601098
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:49:31.001355
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None


# Generated at 2022-06-17 09:49:32.393355
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:49:33.727131
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-17 09:49:45.733645
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict()
    task['action'] = dict()
    task['action']['__ansible_module__'] = 'set_stats'
    task['action']['__ansible_arguments__'] = dict()
    task['action']['__ansible_arguments__']['data'] = dict()
    task['action']['__ansible_arguments__']['data']['foo'] = 'bar'
    task['action']['__ansible_arguments__']['per_host'] = False
    task['action']['__ansible_arguments__']['aggregate'] = True

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock tmp
    tmp = None

    # Create a mock module_name

# Generated at 2022-06-17 09:51:41.981314
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:51:49.131105
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:51:50.948745
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())

# Generated at 2022-06-17 09:51:52.139356
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test for ActionModule.run
    pass

# Generated at 2022-06-17 09:51:56.804095
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None)

# Generated at 2022-06-17 09:52:01.355034
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = MockTask()
    task.args = {'data': {'foo': 'bar'}}

    # Create a mock templar object
    templar = MockTemplar()

    # Create a mock action module object
    action_module = ActionModule(task, templar)

    # Call the run method
    result = action_module.run()

    # Check the result
    assert result['changed'] == False
    assert result['ansible_stats'] == {'data': {'foo': 'bar'}, 'per_host': False, 'aggregate': True}


# Generated at 2022-06-17 09:52:10.728547
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:52:11.820455
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    assert False

# Generated at 2022-06-17 09:52:13.889872
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:52:16.573134
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None, None)
    assert action is not None
