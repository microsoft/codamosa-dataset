

# Generated at 2022-06-17 09:43:43.957186
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import string_types
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import isidentifier
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import is_complex_data
    from ansible.utils.vars import is_sequence
    from ansible.utils.vars import is_list_of_strings
    from ansible.utils.vars import is_list_of_hashes
    from ansible.utils.vars import is_hash_of_hashes

# Generated at 2022-06-17 09:43:50.943765
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    import tempfile
    import shutil
    import json
    import pytest
    import ansible.utils.vars
    import ansible.plugins.action
    import ansible.module_utils.parsing.convert_bool
    import ansible.module_utils.six
    import ansible.utils.vars
    import ansible.utils.vars
    import ansible.utils.vars
    import ansible.utils.vars
    import ansible.utils.vars
    import ansible.utils.vars
    import ansible.utils.vars
    import ansible.utils.vars
    import ansible.utils.vars
    import ansible.utils.vars
    import ansible.utils.vars
    import ansible.utils.vars
    import ansible

# Generated at 2022-06-17 09:43:58.343205
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import isidentifier

    # Create a mock task object
    class MockTask:
        def __init__(self):
            self.args = {}

    # Create a mock module object
    class MockModule:
        def __init__(self):
            self.params = {}

    # Create a mock PlayContext object
    class MockPlayContext:
        def __init__(self):
            self.connection = 'local'
            self.network_os = 'default'
            self.remote_addr = None
            self.port = None
            self.remote_user = None
            self.password = None
            self.private_key_file = None

# Generated at 2022-06-17 09:44:06.907231
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'data': {'foo': 'bar'}}

    # Create a mock play
    play = MockPlay()

    # Create a mock loader
    loader = MockLoader()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock connection
    connection = MockConnection()

    # Create a mock action plugin
    action_plugin = ActionModule(task, connection, play, loader, templar, None)

    # Run the method
    result = action_plugin.run(None, None)

    # Check the result
    assert result['ansible_stats']['data']['foo'] == 'bar'


# Generated at 2022-06-17 09:44:12.844603
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.action.set_stats import ActionModule
    from ansible.utils.vars import isidentifier
    from ansible.utils.vars import merge_hash

    # test with no args
    am = ActionModule(dict(name='test', action='set_stats'))
    result = am.run(None, None)
    assert result['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True}

    # test with args
    am = ActionModule(dict(name='test', action='set_stats', args=dict(data=dict(a=1, b=2), per_host=True, aggregate=False)))
    result = am.run(None, None)
    assert result

# Generated at 2022-06-17 09:44:13.701755
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:44:25.018955
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = {
        'args': {
            'data': {
                'foo': 'bar'
            }
        }
    }

    # Create a mock task_vars
    task_vars = {}

    # Create a mock tmp
    tmp = None

    # Create a mock templar
    templar = {
        'template': lambda x, convert_bare=False, fail_on_undefined=True: x
    }

    # Create a mock ActionBase
    action_base = {
        'run': lambda x, y: {
            'changed': False,
            'ansible_stats': {
                'data': {
                    'foo': 'bar'
                },
                'per_host': False,
                'aggregate': True
            }
        }
    }

   

# Generated at 2022-06-17 09:44:33.457206
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:44:38.621223
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    mock_task = type('', (), {})()
    mock_task.args = {'data': {'test': 'test'}}

    # Create a mock module
    mock_module = type('', (), {})()
    mock_module.params = {'data': {'test': 'test'}}

    # Create a mock templar
    mock_templar = type('', (), {})()
    mock_templar.template = lambda x: x

    # Create a mock action module
    mock_action_module = type('', (), {})()
    mock_action_module._task = mock_task
    mock_action_module._templar = mock_templar

    # Create a mock action base
    mock_action_base = type('', (), {})()
    mock_action_

# Generated at 2022-06-17 09:44:44.514012
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:44:59.123167
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:45:04.071788
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:45:07.317641
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:45:18.241794
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    am = ActionModule(None, None)
    assert am.run() == {'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}, 'changed': False}

    # Test with valid arguments
    am = ActionModule(None, {'data': {'foo': 'bar'}, 'per_host': True, 'aggregate': False})
    assert am.run() == {'ansible_stats': {'data': {'foo': 'bar'}, 'per_host': True, 'aggregate': False}, 'changed': False}

    # Test with invalid arguments
    am = ActionModule(None, {'data': 'foo', 'per_host': 'yes', 'aggregate': 'no'})
    assert am.run()['failed'] == True
    assert am.run

# Generated at 2022-06-17 09:45:20.076689
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of ActionModule
    action_module = ActionModule()

    # Check if the instance is an instance of ActionModule
    assert isinstance(action_module, ActionModule)

    # Check if the instance is an instance of ActionBase
    assert isinstance(action_module, ActionBase)

# Generated at 2022-06-17 09:45:23.671970
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:45:25.257879
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement
    pass

# Generated at 2022-06-17 09:45:34.271892
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_host_vars
    from ansible.utils.vars import load_vars

# Generated at 2022-06-17 09:45:45.330962
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = mock.Mock()
    task.args = {'data': {'a': 1, 'b': 2}, 'per_host': True, 'aggregate': False}
    # Create a mock templar
    templar = mock.Mock()
    templar.template.return_value = {'a': 1, 'b': 2}
    # Create a mock ActionModule
    action_module = ActionModule(task, templar)
    # Create a mock result
    result = mock.Mock()
    result.changed = False
    result.ansible_stats = {'data': {'a': 1, 'b': 2}, 'per_host': True, 'aggregate': False}
    # Assert the result of the run method is the same as the mock result
    assert action_module

# Generated at 2022-06-17 09:45:46.320836
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-17 09:45:56.898414
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:46:08.583749
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a test object
    am = ActionModule()

    # Test the run method
    assert am.run() == {'changed': False, 'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}}
    assert am.run(task_vars={'foo': 'bar'}) == {'changed': False, 'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}}
    assert am.run(tmp='/tmp/foo', task_vars={'foo': 'bar'}) == {'changed': False, 'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}}

# Generated at 2022-06-17 09:46:17.882957
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = dict(
        action=dict(
            module_name='set_stats',
            module_args=dict(
                data=dict(
                    foo='bar',
                    baz=42
                ),
                per_host=True,
                aggregate=False
            )
        )
    )

    # Create a mock play context

# Generated at 2022-06-17 09:46:28.468508
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:46:37.977891
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.action.set_stats import ActionModule
    from ansible.utils.vars import isidentifier
    from ansible.utils.vars import merge_hash

    # Create a mock task object
    task = MockTask()

    # Create a mock play context
    play_context = MockPlayContext()

    # Create a mock templar object
    templar = MockTemplar()

    # Create a mock loader object
    loader = MockLoader()

    # Create a mock variable manager object
    variable_manager = MockVariableManager()

    # Create a mock module_utils object
    module_utils = MockModuleUtils()

    # Create a mock connection object
    connection = MockConnection()

    # Create a mock action base object
    action

# Generated at 2022-06-17 09:46:44.424387
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:46:54.654919
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create a mock task object
    task = dict(
        action=dict(
            module_name='set_stats',
            module_args=dict(
                data=dict(
                    foo='bar',
                    baz='qux'
                ),
                per_host=True,
                aggregate=False
            )
        )
    )

    # create a mock play context

# Generated at 2022-06-17 09:47:02.798062
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:47:03.967965
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None) is not None

# Generated at 2022-06-17 09:47:10.372307
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    action_module = ActionModule(None, None, None, None, None, None)
    assert action_module.TRANSFERS_FILES == False
    assert action_module._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

    # Test with args
    action_module = ActionModule(None, None, None, None, None, None, {'data': {'foo': 'bar'}})
    assert action_module.TRANSFERS_FILES == False
    assert action_module._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-17 09:47:30.563348
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:47:39.668042
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no data
    action = ActionModule()
    action._task = {'args': {}}
    action._templar = None
    result = action.run()
    assert result['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True}

    # Test with data
    action = ActionModule()
    action._task = {'args': {'data': {'foo': 'bar'}}}
    action._templar = None
    result = action.run()
    assert result['ansible_stats'] == {'data': {'foo': 'bar'}, 'per_host': False, 'aggregate': True}

    # Test with data and per_host
    action = ActionModule()

# Generated at 2022-06-17 09:47:48.286957
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:47:57.537920
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict()
    task['args'] = dict()
    task['args']['data'] = dict()
    task['args']['data']['foo'] = 'bar'
    task['args']['data']['baz'] = 'qux'
    task['args']['per_host'] = True
    task['args']['aggregate'] = False

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock templar
    templar = dict()
    templar['template'] = lambda x, convert_bare=False, fail_on_undefined=True: x

    # Create a mock ActionBase
    action_base = dict()
    action_base['run'] = lambda x, task_vars=None: dict

# Generated at 2022-06-17 09:48:05.171943
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'data': {'test': 'test'}}

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock action_base
    action_base = MockActionBase()

    # Create a mock module
    module = MockModule()

    # Create a mock connection
    connection = MockConnection()

    # Create an instance of ActionModule
    action_module = ActionModule(task, connection, templar, module_utils, action_base, module)

    # Run the method run of class ActionModule
    result = action_module.run()

    # Check the result
    assert result['changed'] == False

# Generated at 2022-06-17 09:48:08.219540
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:48:17.890462
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task and action module
    task = MockTask()
    action_module = ActionModule(task, MockConnection())

    # Create a mock result
    result = MockResult()

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock templar
    templar = MockTemplar()

    # Set the templar attribute of the action module
    action_module._templar = templar

    # Create a mock data
    data = dict()
    data['test'] = 'test'

    # Create a mock args
    args = dict()
    args['data'] = data

    # Set the args attribute of the task
    task.args = args

    # Call the run method of the action module
    action_module.run(task_vars=task_vars)

# Generated at 2022-06-17 09:48:30.676242
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import isidentifier
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import is_complex_data
    from ansible.utils.vars import is_sequence
    from ansible.utils.vars import is_scalar
    from ansible.utils.vars import is_list_of_strings
    from ansible.utils.vars import is_list_of_hashes
    from ansible.utils.vars import is_list_of_sequences
    from ansible.utils.vars import is_list_of_scalars

# Generated at 2022-06-17 09:48:36.062829
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:48:46.849729
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock action_base
    action_base = MockActionBase()

    # Create a mock action_module
    action_module = ActionModule(task, action_base.connection, action_base._play_context, action_base._loader, action_base._templar, action_base._shared_loader_obj)

    # Test with no args
    result = action_module.run(task_vars=task_vars)
    assert result['changed'] == False
    assert result['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True}

    # Test with args

# Generated at 2022-06-17 09:49:27.300938
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:49:29.422375
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:49:36.165075
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

    # Test with args
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:49:36.903849
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 09:49:48.542159
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    class MockTask:
        def __init__(self):
            self.args = {}
    task = MockTask()

    # Create a mock play context object
    class MockPlayContext:
        def __init__(self):
            self.connection = 'local'
            self.network_os = 'ios'
            self.remote_addr = '127.0.0.1'
            self.port = 22
            self.remote_user = 'test'
            self.password = None
            self.private_key_file = None
            self.timeout = 10
            self.become = False
            self.become_method = None
            self.become_user = None
            self.check_mode = False
            self.diff = False
            self.gather_facts = None

# Generated at 2022-06-17 09:49:49.402889
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-17 09:49:59.612939
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no args
    module = ActionModule()
    result = module.run(task_vars={})
    assert result['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True}

    # Test with args
    module = ActionModule()
    result = module.run(task_vars={}, tmp=None, task_vars={'test_var': 'test_value'})
    assert result['ansible_stats'] == {'data': {'test_var': 'test_value'}, 'per_host': False, 'aggregate': True}

    # Test with args
    module = ActionModule()
    result = module.run(task_vars={}, tmp=None, task_vars={'test_var': 'test_value'})

# Generated at 2022-06-17 09:50:07.614990
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_host_vars
    from ansible.utils.vars import load_vars

# Generated at 2022-06-17 09:50:08.764691
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 09:50:09.652057
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement test
    pass

# Generated at 2022-06-17 09:52:09.561788
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'data': {'test': 'test'}, 'per_host': True, 'aggregate': False}

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action module
    action_module = ActionModule(task, templar)

    # Run the method
    result = action_module.run()

    # Check the result
    assert result['changed'] == False
    assert result['ansible_stats']['data']['test'] == 'test'
    assert result['ansible_stats']['per_host'] == True
    assert result['ansible_stats']['aggregate'] == False


# Generated at 2022-06-17 09:52:10.750240
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:52:13.153909
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:52:17.133747
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None, None)
    assert action._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-17 09:52:24.325541
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:52:31.292480
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    am = ActionModule(None, None, None, None, None, None, None)
    assert am.run() == {'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}, 'changed': False}

    # Test with args
    am = ActionModule(None, None, None, None, None, None, {'data': {'a': 1, 'b': 2}, 'per_host': True, 'aggregate': False})
    assert am.run() == {'ansible_stats': {'data': {'a': 1, 'b': 2}, 'per_host': True, 'aggregate': False}, 'changed': False}

# Generated at 2022-06-17 09:52:33.800270
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:52:34.717115
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:52:46.730068
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO

    if PY3:
        from io import StringIO
    else:
        from StringIO import StringIO

    # Create a mock task object
    task = type('Task', (object,), {'args': {'data': {'foo': 'bar'}, 'per_host': 'yes', 'aggregate': 'no'}})()

    # Create a mock templar object
    templar = type('Templar', (object,), {'template': lambda self, x: x})()

    # Create a mock module_utils object
    module_utils

# Generated at 2022-06-17 09:52:52.395376
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.utils.vars import isidentifier

    # test with valid data
    action_module = ActionModule()
    action_module._task = {'args': {'data': {'foo': 'bar'}}}
    result = action_module.run()
    assert result['ansible_stats']['data']['foo'] == 'bar'
    assert result['ansible_stats']['per_host'] == False
    assert result['ansible_stats']['aggregate'] == True

    # test with invalid data
    action_module = ActionModule()
    action_module._task = {'args': {'data': 'foo'}}