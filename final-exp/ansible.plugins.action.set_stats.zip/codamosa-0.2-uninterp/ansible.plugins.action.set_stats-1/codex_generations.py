

# Generated at 2022-06-17 09:43:39.956281
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None)
    assert action.TRANSFERS_FILES == False
    assert action._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))


# Generated at 2022-06-17 09:43:52.043020
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.utils.vars import isidentifier
    from ansible.plugins.action import ActionBase
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.play_executor import PlayExecutor

# Generated at 2022-06-17 09:44:01.886051
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = type('task', (object,), {'args': {'data': {'foo': 'bar'}}})()
    # Create a mock play
    play = type('play', (object,), {'name': 'play', 'hosts': 'hosts'})()
    # Create a mock loader
    loader = type('loader', (object,), {'get_basedir': lambda self: 'basedir'})()
    # Create a mock variable manager
    variable_manager = type('variable_manager', (object,), {'get_vars': lambda self: {}})()
    # Create a mock templar
    templar = type('templar', (object,), {'template': lambda self, x: x})()
    # Create a mock connection

# Generated at 2022-06-17 09:44:02.927099
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-17 09:44:11.673197
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'data': {'foo': 'bar'}}

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock ActionBase
    action_base = MockActionBase()

    # Create an instance of ActionModule
    action_module = ActionModule(task, templar, module_utils, action_base)

    # Call method run of class ActionModule
    result = action_module.run()

    # Assert that the result is correct
    assert result == {'changed': False, 'ansible_stats': {'data': {'foo': 'bar'}, 'per_host': False, 'aggregate': True}}


# Generated at 2022-06-17 09:44:21.612676
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.utils.vars import isidentifier
    from ansible.plugins.action import ActionBase
    from ansible.plugins.action.set_stats import ActionModule
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.display import Display
    from ansible.utils.vars import load_extra

# Generated at 2022-06-17 09:44:22.971909
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 09:44:27.413447
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:44:30.042966
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:44:35.906046
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:44:42.045214
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 09:44:52.310473
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:44:59.258294
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class TaskExecutor
    task_executor = TaskExecutor()

    # Create an instance of class Task
    task = Task()

    # Set the attributes of the class Task
    task.args = {'data': {'test': 'test'}}

    # Set the attributes of the class TaskExecutor
    task_executor.task = task

    # Set the attributes of the class ActionModule
    action_module._task = task_executor.task

    # Test the method run of class ActionModule
    result = action_module.run()

    # Assertion for the method run of class ActionModule
    assert result['ansible_stats']['data']['test'] == 'test'

# Generated at 2022-06-17 09:45:02.464966
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:45:11.263246
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'data': {'a': 1, 'b': 2}, 'per_host': True, 'aggregate': False}

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create an instance of ActionModule
    action_module = ActionModule(task, templar, module_utils)

    # Call method run
    result = action_module.run()

    # Assert that the result is correct
    assert result['ansible_stats'] == {'data': {'a': 1, 'b': 2}, 'per_host': True, 'aggregate': False}


# Generated at 2022-06-17 09:45:18.276441
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule(None, None, None, None, None, None)
    assert action_module.run() == {'changed': False, 'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}}

    # Test with arguments
    action_module = ActionModule(None, None, None, None, None, {'data': {'foo': 'bar'}, 'per_host': True, 'aggregate': False})
    assert action_module.run() == {'changed': False, 'ansible_stats': {'data': {'foo': 'bar'}, 'per_host': True, 'aggregate': False}}

# Generated at 2022-06-17 09:45:21.908736
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(action=dict(module_name='set_stats', module_args=dict(data=dict(a=1, b=2, c=3), per_host=True, aggregate=False))),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)
    assert action_module.run() == dict(changed=False, ansible_stats=dict(data=dict(a=1, b=2, c=3), per_host=True, aggregate=False))

# Generated at 2022-06-17 09:45:29.029458
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_host_vars
    from ansible.utils.vars import load_vars

# Generated at 2022-06-17 09:45:40.869003
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import PY3

    class FakeModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception('FAIL')

    class FakeTemplar(object):
        def __init__(self, module):
            self.module = module

        def template(self, data, convert_bare=False, fail_on_undefined=True):
            if isinstance(data, string_types):
                return data
            return data


# Generated at 2022-06-17 09:45:42.264125
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:45:53.175087
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:45:56.278671
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of ActionModule
    am = ActionModule()
    # Check if the instance is created
    assert am is not None


# Generated at 2022-06-17 09:45:57.250256
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-17 09:45:59.729479
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=dict(action=dict(module_name='set_stats', module_args=dict(data=dict(foo='bar')))))

# Generated at 2022-06-17 09:46:09.952765
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:46:18.747115
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:46:33.648277
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:46:35.386091
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:46:36.788958
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 09:46:39.144763
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:47:09.154060
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class TaskExecutor
    task_executor = TaskExecutor()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class Play
    play = Play()

    # Create an instance of class PlaybookExecutor
    playbook_executor = PlaybookExecutor()

    # Create an instance of class Playbook
    playbook = Playbook()

    # Create an instance of class Runner
    runner = Runner()

    # Create an instance of class Connection
    connection = Connection()

    # Create an instance of class VariableManager
    variable_manager = VariableManager()

    # Create an instance of class Inventory
    inventory = Inventory()

    # Create an

# Generated at 2022-06-17 09:47:12.289837
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action is not None


# Generated at 2022-06-17 09:47:19.273827
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:47:21.562525
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:47:26.502241
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:47:35.415671
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class TaskExecutor
    task_executor = TaskExecutor()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class Runner
    runner = Runner()

    # Create an instance of class Play
    play = Play()

    # Create an instance of class Playbook
    play_book = Playbook()

    # Create an instance of class PlaybookExecutor
    play_book_executor = PlaybookExecutor()

    # Create an instance of class PlaybookCLI
    play_book_cli = PlaybookCLI()

    # Create an instance of class Options
    options = Options()

    # Create an instance of class VariableManager

# Generated at 2022-06-17 09:47:37.630706
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test method run of class ActionModule
    """
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:47:39.906277
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:47:41.176669
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None)

# Generated at 2022-06-17 09:47:42.273316
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:48:33.729154
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:48:41.554870
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    am = ActionModule(dict(action='set_stats'))
    assert am.run(None, None) == {'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}, 'changed': False}

    # Test with args
    am = ActionModule(dict(action='set_stats', args=dict(data=dict(foo='bar'), per_host=True, aggregate=False)))
    assert am.run(None, None) == {'ansible_stats': {'data': {'foo': 'bar'}, 'per_host': True, 'aggregate': False}, 'changed': False}

    # Test with args and templating

# Generated at 2022-06-17 09:48:48.858378
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.utils.vars import isidentifier

    # test with no args
    action_module = ActionModule()
    result = action_module.run(task_vars={})
    assert result['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True}

    # test with args
    action_module = ActionModule()
    result = action_module.run(task_vars={}, tmp=None)
    assert result['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True}

    # test with args
    action_module = ActionModule()
    result = action_module.run

# Generated at 2022-06-17 09:48:50.521679
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:48:58.388898
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.loader import action_loader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

# Generated at 2022-06-17 09:49:00.927149
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:49:09.533217
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = MockTask()
    task.args = {'data': {'foo': 'bar'}}

    # Create a mock templar object
    templar = MockTemplar()

    # Create a mock module_utils object
    module_utils = MockModuleUtils()

    # Create a mock action base object
    action_base = MockActionBase()

    # Create an instance of ActionModule
    action_module = ActionModule(task, templar, module_utils, action_base)

    # Call method run of class ActionModule
    result = action_module.run()

    # Assert that the result is as expected
    assert result == {'changed': False, 'ansible_stats': {'data': {'foo': 'bar'}, 'per_host': False, 'aggregate': True}}


# Generated at 2022-06-17 09:49:15.791825
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create an instance of the class
    action_module = ActionModule()
    # check if the instance is an instance of the class
    assert isinstance(action_module, ActionModule)
    # check if the instance is an instance of the super class
    assert isinstance(action_module, ActionBase)


# Generated at 2022-06-17 09:49:26.044936
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = dict(
        action=dict(
            module_name='set_stats',
            module_args=dict(
                data=dict(
                    foo='bar',
                    baz='qux'
                ),
                per_host=True,
                aggregate=False
            )
        )
    )

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock loader
    loader = dict()

    # Create a mock play context
    play_context = dict()

    # Create a mock connection
    connection = dict()

    # Create a mock templar
    templar = dict()

    # Create a mock action plugin

# Generated at 2022-06-17 09:49:35.367979
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule(None, None)
    assert action_module.run(None, None) == {'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}, 'changed': False}

    # Test with empty arguments
    action_module = ActionModule(None, None)
    assert action_module.run(None, None, {'args': {}}) == {'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}, 'changed': False}

    # Test with non-empty arguments
    action_module = ActionModule(None, None)

# Generated at 2022-06-17 09:51:25.939507
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: implement
    pass

# Generated at 2022-06-17 09:51:35.906079
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:51:37.358688
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:51:48.196534
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule class
    action_module = ActionModule()

    # Create an instance of AnsibleTask class
    ansible_task = AnsibleTask()

    # Create an instance of AnsibleModule class
    ansible_module = AnsibleModule()

    # Create an instance of AnsibleModuleUtils class
    ansible_module_utils = AnsibleModuleUtils()

    # Create an instance of AnsibleModuleUtils class
    ansible_module_utils = AnsibleModuleUtils()

    # Create an instance of AnsibleModuleUtils class
    ansible_module_utils = AnsibleModuleUtils()

    # Create an instance of AnsibleModuleUtils class
    ansible_module_utils = AnsibleModuleUtils()

    # Create an instance of AnsibleModuleUtils class
    ansible_module_utils = AnsibleModule

# Generated at 2022-06-17 09:51:57.629818
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    action_module = ActionModule(None, None, None, None, None, None, None, None, None, None)
    assert action_module.run() == {'changed': False, 'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}}

    # Test with args
    action_module = ActionModule(None, None, None, None, None, None, None, None, None, {'data': {'a': 1, 'b': 2}, 'per_host': True, 'aggregate': False})
    assert action_module.run() == {'changed': False, 'ansible_stats': {'data': {'a': 1, 'b': 2}, 'per_host': True, 'aggregate': False}}

# Generated at 2022-06-17 09:52:01.650869
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:52:03.594983
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None, None, None)
    assert action is not None

# Generated at 2022-06-17 09:52:11.786099
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_host_vars
    from ansible.utils.vars import load_

# Generated at 2022-06-17 09:52:20.881552
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    am = ActionModule()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class Connection
    connection = Connection()

    # Create an instance of class Play
    play = Play()

    # Create an instance of class Playbook
    playbook = Playbook()

    # Create an instance of class PlaybookExecutor
    pb_executor = PlaybookExecutor()

    # Create an instance of class Runner
    runner = Runner()

    # Create an instance of class TaskExecutor
    task_executor = TaskExecutor()

    # Create an instance of class TaskQueueManager
    task_queue_manager = TaskQueueManager()

    # Create an instance of class VariableManager
    variable_manager = Variable

# Generated at 2022-06-17 09:52:33.776069
# Unit test for constructor of class ActionModule