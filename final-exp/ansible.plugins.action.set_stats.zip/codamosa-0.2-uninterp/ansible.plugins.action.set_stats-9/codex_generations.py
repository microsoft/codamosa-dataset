

# Generated at 2022-06-17 09:43:48.804244
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:43:54.697162
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    am = ActionModule(None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None)
    assert am is not None
    assert am.TRANSFERS_FILES == False
    assert am._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))


# Generated at 2022-06-17 09:43:58.513506
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:44:06.187563
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'data': {'a': 'b'}}

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock action module
    action_module = ActionModule(task, templar)

    # Call the run method of the action module
    result = action_module.run()

    # Check the result
    assert result['changed'] == False
    assert result['ansible_stats'] == {'data': {'a': 'b'}, 'per_host': False, 'aggregate': True}


# Generated at 2022-06-17 09:44:06.942063
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:44:07.581790
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:44:14.048624
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import isidentifier
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import is_complex_data
    from ansible.utils.vars import is_sequence
    from ansible.utils.vars import is_scalar
    from ansible.utils.vars import is_iterable
    from ansible.utils.vars import is_list_of_strings
    from ansible.utils.vars import is_list_of_hashes
    from ansible.utils.vars import is_hashable

# Generated at 2022-06-17 09:44:25.054569
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_host_vars
    from ansible.utils.vars import load_vars

# Generated at 2022-06-17 09:44:29.211099
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None)
    assert action_module._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))
    assert action_module.TRANSFERS_FILES == False

# Generated at 2022-06-17 09:44:31.373762
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:44:43.494789
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:44:52.789637
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create a mock task
    task = MockTask()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock result
    result = MockResult()

    # Set the attributes of the mock task
    task.args = {'data': {'a': 'b'}, 'per_host': True, 'aggregate': False}

    # Set the attributes of the mock templar
    templar.template_data = {'a': 'b'}

    # Set the attributes of the mock result
    result.changed = False
    result.ansible_stats = {'data': {'a': 'b'}, 'per_host': True, 'aggregate': False}

    # Test the run method
    assert action

# Generated at 2022-06-17 09:45:00.803416
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task and action module
    task = MockTask()
    action_module = ActionModule(task, MockConnection())

    # Create a mock task result
    task_result = {'failed': False, 'msg': None, 'changed': False}

    # Test when no args are passed
    result = action_module.run(task_vars={})
    assert result == task_result

    # Test when args are passed
    task.args = {'data': {'foo': 'bar'}}
    result = action_module.run(task_vars={})
    assert result == task_result
    assert result['ansible_stats'] == {'data': {'foo': 'bar'}, 'per_host': False, 'aggregate': True}

    # Test when args are passed

# Generated at 2022-06-17 09:45:05.014172
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None)
    assert action.TRANSFERS_FILES == False
    assert action._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-17 09:45:06.192066
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict())

# Generated at 2022-06-17 09:45:18.141824
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:45:22.155518
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())

# Generated at 2022-06-17 09:45:33.537663
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import isidentifier
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars

    class ActionModule(ActionBase):

        TRANSFERS_FILES = False
        _VALID_ARGS = frozenset(('aggregate', 'data', 'per_host'))

        # TODO: document this in non-empty set_stats.py module
        def run(self, tmp=None, task_vars=None):
            if task_vars is None:
                task_vars = dict()

            result = super(ActionModule, self).run(tmp, task_vars)
            del tmp 

# Generated at 2022-06-17 09:45:44.664946
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create a dictionary of arguments to pass to run method
    args = {'data': {'a': 'b'}, 'per_host': True, 'aggregate': False}

    # Create a dictionary of task_vars to pass to run method
    task_vars = {'a': 'b'}

    # Create a dictionary of result to pass to run method
    result = {'changed': False, 'ansible_stats': {'data': {'a': 'b'}, 'per_host': True, 'aggregate': False}}

    # Test run method

# Generated at 2022-06-17 09:45:46.217175
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 09:46:07.833795
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am.run() == {'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}, 'changed': False}

    # Test with args
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    am._task.args = {'data': {'a': 'b'}, 'per_host': True, 'aggregate': False}

# Generated at 2022-06-17 09:46:10.280759
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:46:18.776684
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:46:23.804291
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None, None)
    assert action._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-17 09:46:25.273568
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:46:35.698452
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.run() == {'changed': False, 'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}}

    # Test with args
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module._task.args = {'data': {'foo': 'bar'}}

# Generated at 2022-06-17 09:46:42.109426
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test with no args
    action = ActionModule()
    result = action.run(task_vars={})
    assert result['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True}

    # test with args
    action = ActionModule()
    action._task.args = {'data': {'foo': 'bar'}, 'per_host': True, 'aggregate': False}
    result = action.run(task_vars={})
    assert result['ansible_stats'] == {'data': {'foo': 'bar'}, 'per_host': True, 'aggregate': False}

# Generated at 2022-06-17 09:46:52.033129
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.utils.vars import isidentifier

    # Test with no args
    action = ActionModule()
    result = action.run()
    assert result['changed'] == False
    assert result['ansible_stats']['data'] == {}
    assert result['ansible_stats']['per_host'] == False
    assert result['ansible_stats']['aggregate'] == True

    # Test with args
    action = ActionModule()
    action._task.args = {'data': {'test': 'test'}, 'per_host': 'yes', 'aggregate': 'no'}
    result = action.run()
    assert result['changed'] == False

# Generated at 2022-06-17 09:46:55.153529
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:47:03.119435
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class TaskExecutor
    task_executor = TaskExecutor()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class Play
    play = Play()

    # Create an instance of class Playbook
    play_book = Playbook()

    # Create an instance of class Runner
    runner = Runner()

    # Create an instance of class Connection
    connection = Connection()

    # Create an instance of class VariableManager
    variable_manager = VariableManager()

    # Create an instance of class Inventory
    inventory = Inventory()

    # Create an instance of class Host
    host = Host()

    # Create an instance of class Group
    group

# Generated at 2022-06-17 09:47:26.530142
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:47:27.969153
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None)

# Generated at 2022-06-17 09:47:29.689174
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:47:37.910126
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'data': {'foo': 'bar'}}

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock action_base
    action_base = MockActionBase()

    # Create an instance of ActionModule
    action_module = ActionModule(task, templar, module_utils, action_base)

    # Call method run of ActionModule
    result = action_module.run()

    # Assert that the result is correct
    assert result == {'changed': False, 'ansible_stats': {'data': {'foo': 'bar'}, 'per_host': False, 'aggregate': True}}


# Generated at 2022-06-17 09:47:41.002252
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:47:52.374201
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict()
    task['args'] = dict()
    task['args']['data'] = dict()
    task['args']['data']['test'] = 'test'
    task['args']['per_host'] = True
    task['args']['aggregate'] = False

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock templar
    templar = dict()
    templar['template'] = lambda x, convert_bare=False, fail_on_undefined=True: x

    # Create a mock ActionBase
    action_base = dict()
    action_base['run'] = lambda tmp=None, task_vars=None: dict()

    # Create a mock ActionModule
    action_module = dict()


# Generated at 2022-06-17 09:47:53.238743
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-17 09:47:55.412721
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:47:56.250855
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: add unit test
    pass

# Generated at 2022-06-17 09:48:05.108619
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:48:58.744933
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock action base
    action_base = MockActionBase()

    # Create a mock action module
    action_module = ActionModule(task, templar, module_utils, action_base)

    # Create a mock result
    result = {'changed': False, 'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}}

    # Test with no args
    assert action_module.run() == result

    # Test with args
    task.args = {'data': {'test': 'test'}}
    result['ansible_stats']['data']

# Generated at 2022-06-17 09:49:09.153495
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import reload_module
    from ansible.utils.vars import isidentifier

    # Mock module
    module = AnsibleModule(
        argument_spec=dict(
            aggregate=dict(type='bool', default=True),
            data=dict(type='dict', default={}),
            per_host=dict(type='bool', default=False),
        ),
        supports_check_mode=True
    )

    # Mock action module

# Generated at 2022-06-17 09:49:13.019277
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None, None, None, None)

# Generated at 2022-06-17 09:49:20.448370
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import isidentifier
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.playbook.task import Task

# Generated at 2022-06-17 09:49:23.865909
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None, None)

# Generated at 2022-06-17 09:49:36.607880
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task_obj = MockTask()
    # Create a mock task result object
    task_result = MockTaskResult()
    # Create a mock action module object
    action_module = ActionModule(task_obj, task_result)
    # Create a mock templar object
    templar_obj = MockTemplar()
    # Set the templar object to the action module object
    action_module._templar = templar_obj
    # Create a mock task args object
    task_args = {'data': {'test_var': 'test_val'}, 'per_host': True, 'aggregate': False}
    # Set the task args to the task object
    task_obj.args = task_args
    # Call the run method of the action module object
    action_module.run()

# Generated at 2022-06-17 09:49:48.147302
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import builtins
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import isidentifier

    class ActionModule(ActionBase):
        def run(self, tmp=None, task_vars=None):
            if task_vars is None:
                task_vars = dict()

            result = super(ActionModule, self).run(tmp, task_vars)
            del tmp  # tmp no longer has any effect

            stats = {'data': {}, 'per_host': False, 'aggregate': True}


# Generated at 2022-06-17 09:49:55.835244
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:49:56.577585
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: implement
    pass

# Generated at 2022-06-17 09:49:58.220058
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:51:54.164705
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-17 09:51:58.574544
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    import tempfile
    import shutil
    import json

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary playbook
    playbook_path = os.path.join(tmpdir, 'playbook.yml')

# Generated at 2022-06-17 09:52:10.135229
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a fake task object
    task = dict(
        action=dict(
            module_name='set_stats',
            module_args=dict(
                data=dict(
                    foo='bar',
                    baz='qux'
                ),
                per_host=True,
                aggregate=False
            )
        )
    )

    # Create a fake play context

# Generated at 2022-06-17 09:52:10.996528
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:52:20.560471
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class Runner
    runner = Runner()

    # Create an instance of class Connection
    connection = Connection()

    # Create an instance of class Play
    play = Play()

    # Create an instance of class Playbook
    play_book = Playbook()

    # Create an instance of class DataLoader
    data_loader = DataLoader()

    # Create an instance of class InventoryManager
    inventory_manager = InventoryManager()

    # Create an instance of class VariableManager
    variable_manager = VariableManager()

    # Set attributes of object 'play_context'
    play_context.remote_addr = None
    play

# Generated at 2022-06-17 09:52:31.470307
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule(None, None)
    assert action_module.run(None, None) == {'changed': False, 'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}}

    # Test with invalid data
    action_module = ActionModule(None, None)
    assert action_module.run(None, None) == {'changed': False, 'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}}

# Generated at 2022-06-17 09:52:38.727436
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:52:46.279421
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a mock task
    task = MockTask()
    task.args = {'data': {'test': 'test'}}
    # create a mock module
    module = MockModule()
    # create a mock templar
    templar = MockTemplar()
    # create a mock action module
    action_module = ActionModule(task, templar, module)
    # run the method
    result = action_module.run()
    # assert the result
    assert result['ansible_stats'] == {'data': {'test': 'test'}, 'per_host': False, 'aggregate': True}


# Generated at 2022-06-17 09:52:54.086929
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = MockTask()
    task.args = {'data': {'test': 'test'}}

    # Create a mock templar object
    templar = MockTemplar()

    # Create a mock module_utils object
    module_utils = MockModuleUtils()

    # Create a mock ActionBase object
    action_base = MockActionBase()

    # Create a ActionModule object
    action_module = ActionModule(task, connection=None, play_context=None, loader=None, templar=templar, shared_loader_obj=None)

    # Test the run method
    result = action_module.run(tmp=None, task_vars=None)

    # Assert the result

# Generated at 2022-06-17 09:53:01.829582
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a test object
    am = ActionModule()
    # Check the type of the object
    assert isinstance(am, ActionModule)
    # Check the type of the object
    assert isinstance(am, ActionBase)
    # Check the type of the object
    assert isinstance(am, object)
    # Check the type of the object
    assert isinstance(am._VALID_ARGS, frozenset)
    # Check the type of the object
    assert isinstance(am.TRANSFERS_FILES, bool)
    # Check the type of the object
    assert isinstance(am.run, object)
