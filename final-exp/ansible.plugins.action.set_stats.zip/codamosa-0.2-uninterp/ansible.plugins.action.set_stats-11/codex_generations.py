

# Generated at 2022-06-17 09:43:38.156464
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: write unit test
    pass

# Generated at 2022-06-17 09:43:42.463415
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action.TRANSFERS_FILES == False
    assert action._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-17 09:43:44.967047
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:43:45.958553
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:43:55.956942
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:44:07.118821
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:44:12.960928
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.action.set_stats import ActionModule
    from ansible.utils.vars import isidentifier
    from ansible.utils.vars import merge_hash
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.process.worker import WorkerProcess
    from ansible.inventory.manager import InventoryManager

# Generated at 2022-06-17 09:44:24.875794
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = MockTask()

    # Create a mock AnsibleModule object
    ansible_module = MockAnsibleModule()

    # Create a mock AnsibleModule object
    ansible_module_2 = MockAnsibleModule()

    # Create a mock AnsibleModule object
    ansible_module_3 = MockAnsibleModule()

    # Create a mock AnsibleModule object
    ansible_module_4 = MockAnsibleModule()

    # Create a mock AnsibleModule object
    ansible_module_5 = MockAnsibleModule()

    # Create a mock AnsibleModule object
    ansible_module_6 = MockAnsibleModule()

    # Create a mock AnsibleModule object
    ansible_module_7 = MockAnsibleModule()

    # Create a mock AnsibleModule object
   

# Generated at 2022-06-17 09:44:29.179240
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test for constructor of class ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:44:35.256391
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:44:50.788515
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock action_base
    action_base = MockActionBase()

    # Create an instance of ActionModule
    action_module = ActionModule(task, templar, task_vars, module_utils, action_base)

    # Create a mock result
    result = dict()

    # Create a mock tmp
    tmp = None

    # Call method run of class ActionModule
    action_module.run(tmp, task_vars)

    # Assert that method run of class ActionModule called method run of class ActionBase
   

# Generated at 2022-06-17 09:45:01.675349
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no args
    action = ActionModule()
    result = action.run(task_vars={})
    assert result['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True}
    assert result['changed'] == False

    # Test with args
    action = ActionModule()
    result = action.run(task_vars={}, tmp='/tmp', task_vars={'test_var': 'test_value'})
    assert result['ansible_stats'] == {'data': {'test_var': 'test_value'}, 'per_host': False, 'aggregate': True}
    assert result['changed'] == False

    # Test with args
    action = ActionModule()

# Generated at 2022-06-17 09:45:03.728837
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict())

# Generated at 2022-06-17 09:45:05.613163
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-17 09:45:06.640094
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-17 09:45:18.174380
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:45:19.561898
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-17 09:45:32.710375
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'data': {'foo': 'bar'}}

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock action_base
    action_base = MockActionBase()

    # Create an instance of ActionModule
    action_module = ActionModule(task, templar, module_utils, action_base)

    # Call the run method
    result = action_module.run()

    # Assert that the result is correct
    assert result == {'changed': False, 'ansible_stats': {'data': {'foo': 'bar'}, 'per_host': False, 'aggregate': True}}


# Generated at 2022-06-17 09:45:42.265020
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_bytes
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    # Create a task
    task = Task()
    task._role = None
    task.args = {'data': {'a': 1, 'b': 2}, 'per_host': 'yes', 'aggregate': 'no'}

    # Create a variable manager
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'a': 1, 'b': 2}

    # Create a templar
    templar = Templar(loader=None, variables=variable_manager)

    # Create an action module
    action_

# Generated at 2022-06-17 09:45:51.937695
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a mock task
    task = dict()
    task['args'] = dict()
    task['args']['data'] = dict()
    task['args']['data']['a'] = '{{ a }}'
    task['args']['data']['b'] = '{{ b }}'
    task['args']['data']['c'] = '{{ c }}'
    task['args']['data']['d'] = '{{ d }}'
    task['args']['data']['e'] = '{{ e }}'
    task['args']['data']['f'] = '{{ f }}'
    task['args']['data']['g'] = '{{ g }}'
    task['args']['data']['h'] = '{{ h }}'

# Generated at 2022-06-17 09:46:10.780941
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    am = ActionModule(None, None)
    assert am.run() == {'changed': False, 'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}}

    # Test with args
    am = ActionModule(None, {'data': {'test': 'test'}, 'per_host': True, 'aggregate': False})
    assert am.run() == {'changed': False, 'ansible_stats': {'data': {'test': 'test'}, 'per_host': True, 'aggregate': False}}

# Generated at 2022-06-17 09:46:18.925974
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:46:33.684272
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'data': {'test': '{{ test }}'}, 'per_host': '{{ per_host }}', 'aggregate': '{{ aggregate }}'}

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock action base
    action_base = MockActionBase()

    # Create an instance of the class to be tested
    action_module = ActionModule(task, templar, module_utils, action_base)

    # Create a mock result
    result = {'changed': False, 'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}}

    # Test the run method with a

# Generated at 2022-06-17 09:46:42.212146
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a mock task
    task = dict()
    task['args'] = dict()
    task['args']['data'] = dict()
    task['args']['data']['foo'] = 'bar'
    task['args']['data']['baz'] = 'qux'
    task['args']['per_host'] = True
    task['args']['aggregate'] = False

    # Create a mock task_vars
    task_vars = dict()

    # Create a mock templar
    templar = dict()
    templar['template'] = lambda x, convert_bare=False, fail_on_undefined=True: x

    # Create a mock ActionBase
    action_base = dict()
    action_base['run'] = lambda tmp, task_vars: dict()



# Generated at 2022-06-17 09:46:49.911852
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars
    from ansible.utils.vars import load_vars_from_inventory

# Generated at 2022-06-17 09:47:00.312967
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:47:09.342064
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'data': {'foo': 'bar'}}
    # Create a mock action module
    action_module = MockActionModule()
    action_module._task = task
    # Create a mock templar
    templar = MockTemplar()
    action_module._templar = templar
    # Create a mock result
    result = MockResult()
    # Create a mock task_vars
    task_vars = MockTaskVars()
    # Call the run method of the action module
    action_module.run(tmp=None, task_vars=task_vars)
    # Check the result
    assert result.changed == False

# Generated at 2022-06-17 09:47:10.412446
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-17 09:47:18.007565
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of class ActionModule
    action_module = ActionModule()
    # Check if the instance is an instance of class ActionModule
    assert isinstance(action_module, ActionModule)
    # Check if the instance is an instance of class ActionBase
    assert isinstance(action_module, ActionBase)
    # Check if the instance is an instance of class object
    assert isinstance(action_module, object)
    # Check if the instance has an attribute '_VALID_ARGS'
    assert hasattr(action_module, '_VALID_ARGS')
    # Check if the instance has an attribute 'TRANSFERS_FILES'
    assert hasattr(action_module, 'TRANSFERS_FILES')
    # Check if the instance has an attribute 'run'
    assert hasattr(action_module, 'run')
   

# Generated at 2022-06-17 09:47:27.113448
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = MockTask()
    # Create a mock task_vars object
    task_vars = MockTaskVars()
    # Create a mock templar object
    templar = MockTemplar()
    # Create a mock ActionModule object
    action_module = ActionModule(task, templar, task_vars)
    # Create a mock result object
    result = MockResult()
    # Call method run of class ActionModule
    action_module.run(result)
    # Check if the result object is as expected
    assert result.ansible_stats == {'data': {}, 'per_host': False, 'aggregate': True}
    assert result.changed == False
    # Create a mock task object
    task = MockTask()
    # Create a mock task_vars object
    task

# Generated at 2022-06-17 09:47:57.111985
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_vars_from_inventory

# Generated at 2022-06-17 09:48:04.606462
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no arguments
    action_module = ActionModule(None, None)
    assert action_module is not None
    assert action_module.TRANSFERS_FILES == False
    assert action_module._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

    # Test with arguments
    action_module = ActionModule(None, None, {'aggregate': True, 'data': {'test': 'test'}, 'per_host': False})
    assert action_module is not None
    assert action_module.TRANSFERS_FILES == False
    assert action_module._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-17 09:48:08.622249
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Generated at 2022-06-17 09:48:18.028441
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()

    # Create a mock templar
    templar = MockTemplar()

    # Create a mock module_utils
    module_utils = MockModuleUtils()

    # Create a mock action_base
    action_base = MockActionBase()

    # Create an instance of ActionModule
    action_module = ActionModule(task, templar, module_utils, action_base)

    # Create a mock tmp
    tmp = MockTmp()

    # Create a mock task_vars
    task_vars = MockTaskVars()

    # Call method run of class ActionModule
    result = action_module.run(tmp, task_vars)

    # Check the result

# Generated at 2022-06-17 09:48:19.354927
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test for method run of class ActionModule
    pass

# Generated at 2022-06-17 09:48:24.737608
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None, None, None)
    assert action._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-17 09:48:34.294202
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = MockTask()
    task.args = {'data': {'test_var': 'test_value'}}

    # Create a mock templar object
    templar = MockTemplar()

    # Create a mock module_utils object
    module_utils = MockModuleUtils()

    # Create a mock action_base object
    action_base = MockActionBase()

    # Create a ActionModule object
    action_module = ActionModule(task, templar, module_utils, action_base)

    # Test the run method
    result = action_module.run()

    # Assert that the result is correct

# Generated at 2022-06-17 09:48:35.080014
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement this unit test
    pass

# Generated at 2022-06-17 09:48:46.711320
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    task_args = {}
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action.run(task_vars=None)
    assert result['ansible_stats']['data'] == {}
    assert result['ansible_stats']['per_host'] == False
    assert result['ansible_stats']['aggregate'] == True

    # Test with args
    task_args = {'data': {'test_key': 'test_value'}, 'per_host': 'True', 'aggregate': 'False'}

# Generated at 2022-06-17 09:48:52.200777
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:49:38.984859
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:49:49.544737
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object
    task = MockTask()
    # Create a mock task_vars object
    task_vars = MockTaskVars()
    # Create a mock templar object
    templar = MockTemplar()
    # Create a mock action_base object
    action_base = MockActionBase()
    # Create a mock action_module object
    action_module = ActionModule(task, templar, action_base)
    # Create a mock result object
    result = MockResult()
    # Create a mock stats object
    stats = MockStats()
    # Create a mock data object
    data = MockData()
    # Create a mock per_host object
    per_host = MockPerHost()
    # Create a mock aggregate object
    aggregate = MockAggregate()
    # Create a mock tmp object
    tmp

# Generated at 2022-06-17 09:49:50.293170
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 09:50:00.135160
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:50:05.351700
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Check if the instance is an instance of class ActionModule
    assert isinstance(action_module, ActionModule)

    # Check if the instance is an instance of class ActionBase
    assert isinstance(action_module, ActionBase)

# Generated at 2022-06-17 09:50:14.000637
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_vars_files
    from ansible.utils.vars import load_vars_from_inventory

# Generated at 2022-06-17 09:50:20.069790
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 09:50:31.464371
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    action_module = ActionModule(None, None)
    assert action_module.run() == {'changed': False, 'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}}

    # Test with args
    action_module = ActionModule(None, {'data': {'a': 1, 'b': 2}, 'per_host': True, 'aggregate': False})
    assert action_module.run() == {'changed': False, 'ansible_stats': {'data': {'a': 1, 'b': 2}, 'per_host': True, 'aggregate': False}}

# Generated at 2022-06-17 09:50:41.899930
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = MockTask()
    task.args = {'data': {'test': 'test'}}
    # Create a mock PlayContext
    play_context = MockPlayContext()
    # Create a mock AnsibleModule
    ansible_module = MockAnsibleModule()
    # Create a mock ActionBase
    action_base = MockActionBase()
    # Create a mock ActionModule
    action_module = ActionModule(task, play_context, ansible_module, action_base)
    # Call the run method of class ActionModule
    result = action_module.run()
    # Assert the result
    assert result['ansible_stats'] == {'data': {'test': 'test'}, 'per_host': False, 'aggregate': True}


# Generated at 2022-06-17 09:50:51.193451
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_host_vars
    from ansible.utils.vars import load_vars

# Generated at 2022-06-17 09:52:37.451240
# Unit test for constructor of class ActionModule

# Generated at 2022-06-17 09:52:45.600037
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        task=dict(action=dict(module_name='set_stats', module_args=dict(data=dict(a=1, b=2), aggregate=False, per_host=True))),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action.run() == dict(
        changed=False,
        ansible_stats=dict(
            data=dict(a=1, b=2),
            aggregate=False,
            per_host=True
        )
    )

# Generated at 2022-06-17 09:52:48.790127
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=dict(action=dict(module_name='set_stats', module_args=dict(data=dict(a=1, b=2)))))

# Generated at 2022-06-17 09:52:55.366664
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import isidentifier
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import is_complex_data
    from ansible.utils.vars import is_sequence
    from ansible.utils.vars import is_scalar
    from ansible.utils.vars import is_unsafe_proxy
    from ansible.utils.vars import is_traversable
    from ansible.utils.vars import is_iterable
    from ansible.utils.vars import is_list_of

# Generated at 2022-06-17 09:53:04.325526
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.action.set_stats import ActionModule
    from ansible.utils.vars import isidentifier
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import is_complex_data
    from ansible.template import Templar
    from ansible.template import Templar
    from ansible.template import AnsibleEnvironment
    from ansible.template import AnsibleUndefinedVariable
    from ansible.template import AnsibleUndefinedVariable
    from ansible.template import AnsibleUndefinedVariable
    from ansible.template import AnsibleUndefinedVariable
    from ansible.template import AnsibleUndefinedVariable
    from ansible.template import AnsibleUnd

# Generated at 2022-06-17 09:53:04.695248
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-17 09:53:11.763203
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    am = ActionModule(dict(name='test'))
    assert am.run() == {'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}, 'changed': False}

    # Test with args
    am = ActionModule(dict(name='test', args=dict(data=dict(a=1, b=2), per_host=True, aggregate=False)))
    assert am.run() == {'ansible_stats': {'data': {'a': 1, 'b': 2}, 'per_host': True, 'aggregate': False}, 'changed': False}

# Generated at 2022-06-17 09:53:17.208453
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with no args
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.run() == {'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}, 'changed': False}

    # Test with args
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module._task.args = {'data': {'test_key': 'test_value'}, 'per_host': True, 'aggregate': False}

# Generated at 2022-06-17 09:53:18.043173
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: write unit test for constructor of class ActionModule
    assert True

# Generated at 2022-06-17 09:53:19.473595
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)