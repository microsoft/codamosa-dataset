

# Generated at 2022-06-21 03:00:23.614717
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()

    assert(action_module.TRANSFERS_FILES == False)

# Generated at 2022-06-21 03:00:36.114269
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Test the run method of ActionModule.
    '''
    # Test with no args
    stats = ActionModule.run(ActionModule(), {}, {}, {}, {})
    expected = {
        'aggregate': True,
        'data': {},
        'per_host': False
    }
    assert stats['ansible_stats'] == expected

    # Test with string args
    stats = ActionModule.run(ActionModule(), {}, {}, {}, {'data': 'foo'})
    assert stats['failed'] == True
    assert stats['msg'] == "The 'data' option needs to be a dictionary/hash"

    # Test with integer args
    del stats
    stats = ActionModule.run(ActionModule(), {}, {}, {}, {'data': 42})
    assert stats['failed'] == True
    assert stats

# Generated at 2022-06-21 03:00:44.889549
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup the ActionModule
    am = ActionModule()

    # Create test data
    task = dict()
    task_vars = None
    tmp = None

    # Test 1: No args
    # Expected result: data = {}, per_host = False, aggregate = True
    expected_result = {'changed': False, 'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}}
    result = am.run(tmp, task_vars)
    assert result['changed'] == expected_result['changed']
    assert result['ansible_stats']['data'] == expected_result['ansible_stats']['data']
    assert result['ansible_stats']['per_host'] == expected_result['ansible_stats']['per_host']

# Generated at 2022-06-21 03:00:55.564438
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    from ansible.plugins.task import TaskBase

    loader = DataLoader()
    options = dict(connection='local', module_path=['/to/mymodules'], forks=10, become=None,
                   become_method=None, become_user=None, check=False, diff=False)
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='')

# Generated at 2022-06-21 03:01:05.806560
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Success case.
    # Successful set-stats can be used to store per-host variables and
    # aggregate variables.
    # The data of a successful set-stats is a dictionary whose keys are the
    # names of the variables to set (and whose values are the values to set
    # those variables to), and whose 'aggregate' key is False if per-host
    # variables are desired; otherwise it is True.
    module = ActionModule(
        action_plugin=None,
        task_vars=None,
        task=dict(name=None, args=dict(data={"foo": "bar", "baz": "qux"}, aggregate=False))
    )
    res = module.run()
    assert not res['failed']
    # per_host is False because set_stats/aggregate is False

# Generated at 2022-06-21 03:01:07.353492
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True, "This should not throw an error"

# Generated at 2022-06-21 03:01:13.178375
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__doc__ is not None
    assert ActionModule._VALID_ARGS.__doc__ is not None
    assert ActionModule._VALID_ARGS is not None
    assert ActionModule._VALID_ARGS != set()
    assert ActionModule.run.__doc__ is not None
    assert ActionModule.run is not None
    assert ActionModule.run != 'ActionModule.run'


# Generated at 2022-06-21 03:01:23.590307
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    
    # Mock class
    class ParamikoConnection():
        def __init__(self):
            self.host = None
            self.port = None

    class Task():
        def __init__(self):
            self.args = dict()
            self.connection = "local"
        
        args = dict()
        connection = "local"

    class Connection():
        def __init__(self):
            self.host = None
            self.port = None
            self.transport = "local"
            self.remote_user = "username"
            self.remote_pass = "password"
            self.private_key_file = "~/.ssh/id_rsa"
            self.connection = ParamikoConnection()

    task_obj = Task()
    connection_obj = Connection()


# Generated at 2022-06-21 03:01:35.072591
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 03:01:43.482111
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tm = set(ActionModule._VALID_ARGS)
    assert tm.issuperset(set(['aggregate', 'data', 'per_host']))

    task_vars = {'control_plane': 'controller'}
    tmp = None
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    am.task_vars = task_vars
    am.run(tmp, task_vars)

# Generated at 2022-06-21 03:01:56.327507
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    from ansible.plugins.action.set_stats import ActionModule as action_module
    # Initialize the ansible module
    module = action_module(
        task=dict(
            action=dict(
                module_name='set_stats',
                module_args=dict(
                    per_host=True,
                    data=dict(
                        host='{{inventory_hostname}}',
                        result='{{result}}'
                    )
                )
            ),
            args=dict(
                per_host=True,
                data=dict(
                    host='{{inventory_hostname}}',
                    result='{{result}}'
                )
            )
        )
    )

    # Create test variables

# Generated at 2022-06-21 03:02:06.118692
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.ansible_modlib.test.result_fixture import result_fixture
    from ansible.module_utils.ansible_modlib.test.unit.module_framework import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='dict'),
            per_host=dict(type='dict'),
            aggregate=dict(type='dict')
        ),
        supports_check_mode=True
    )

    result = ActionModule(module, {}).run(task_vars={'initial_var': 'foo'})
    assert result == result_fixture
    module.exit_json.assert_called_once_with(**result_fixture)

# Generated at 2022-06-21 03:02:16.742397
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    def _get_templated_value(action_module, value, vars=None):
        templated = action_module._templar.template(value, priority=0, convert_bare=False, fail_on_undefined=True)
        return templated

    mock_task = dict(
        name='set_stats',
        action='set_stats'
    )

    module_params = dict(
        data=dict(
            foo='{{ value_for_foo }}',
            bar='{{ value_for_bar }}',
            baz='{{ value_for_baz }}'
        )
    )


# Generated at 2022-06-21 03:02:18.039267
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert(False), "Not implemented"

# Generated at 2022-06-21 03:02:29.286759
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 03:02:31.901302
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Test the constructor of class ActionModule.
    '''
    actionm = ActionModule('test_ActionModule', 'test_ActionBase')
    assert(actionm is not None)

# Generated at 2022-06-21 03:02:35.243761
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.TRANSFERS_FILES == False
    assert ActionModule._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-21 03:02:42.980570
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class AnsibleModule(object):
        def __init__(self, *args, **kwargs):
            pass

    class AnsibleVars(object):
        def __init__(self, *args, **kwargs):
            pass

    class AnsibleTask(object):
        def __init__(self, *args, **kwargs):
            self._task_args = {}

        def set_task_args(self, data):
            self._task_args = data

    task = AnsibleTask()
    am = AnsibleModule()
    stats = {'data': {}, 'per_host': False, 'aggregate': True}

    # Test 1: Test run method when task context is empty
    task.set_task_args({})
    instance = ActionModule(task, am)

# Generated at 2022-06-21 03:02:50.680945
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(task=dict(args=dict(data=dict(mem_used='1234', cpu='15'), per_host=True, aggregate=True)), connection=None, play_context=dict(), loader=None, templar=None, shared_loader_obj=None)
    assert a.run() == {u'changed': False, u'ansible_stats': {'per_host': True, 'data': {u'cpu': u'15', u'mem_used': u'1234'}, 'aggregate': True}}


# Generated at 2022-06-21 03:02:51.295315
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 03:03:09.702789
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TaskMock(object):
        def __init__(self):
            self.args = {'data': {'test': '{{test}}'}, 'per_host': True}

    class VarsMock(object):
        test = 'test'
        ansible_ssh_host = '127.0.0.1'

    class TaskVarsMock(object):
        def __init__(self):
            self.vars = VarsMock()

    task = TaskMock()
    action = ActionModule()
    action._task = task
    action._templar = VarsMock()
    action._loader = VarsMock()
    action._connection = VarsMock()
    action._play_context = VarsMock()
    action._shared_loader_obj = VarsMock()

    task

# Generated at 2022-06-21 03:03:19.645784
# Unit test for constructor of class ActionModule
def test_ActionModule():

    import unittest

    import ansible.plugins.action

    class MockTask(object):  # pylint: disable=too-few-public-methods
        """
        Mocking the Task class
        """
        def __init__(self, args):
            self.args = args

    class MockActionModule(ansible.plugins.action.ActionBase):  # pylint: disable=too-few-public-methods
        """
        Mocking the ActionBase class
        """
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            super(MockActionModule, self).__init__(task, connection, play_context, loader, templar, shared_loader_obj)
            self._task = task
            self._templar = templar



# Generated at 2022-06-21 03:03:29.712419
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.module_utils._text import to_bytes, to_text

    def _fixture_load(name):
        from os.path import dirname, join
        from yaml import safe_load
        with open(join(dirname(__file__), '../fixtures/', name + '.yml')) as f:
            return safe_load(f)

    def _templar_template(template, convert_bare=False, fail_on_undefined=False):
        template = to_bytes(template, errors='surrogate_or_strict')
        if template in (to_bytes('True'), b'True'):
            return True
        elif template in (to_bytes('False'), b'False'):
            return False

# Generated at 2022-06-21 03:03:39.353655
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Input data
    task_ref = {}
    task_ref['args'] = {}
    task_ref['args']['data'] = {}
    task_ref['args']['data']['iteration'] = 0  # test value
    task_ref['args']['per_host'] = True  # test value
    task_ref['args']['aggregate'] = True  # test value

    task_vars = {}

    # Action module input data
    mock_action_base = type('', (), {})
    mock_action_base.run = lambda self, tmp, task_vars: None
    mock_action_base.run.__name__ = 'ActionBase.run'
    mock_action_base.TRANSFERS_FILES = False
    mock_action_base._VALID_ARGS = fro

# Generated at 2022-06-21 03:03:47.570559
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # set up fake objects
    task = {'args': {'aggregate': True, 'per_host': False, 'data': {'foo': 1}}, 'name': 'test'}
    _shared_loader_obj = object()  # TODO: test this properly
    _task_vars = {'ansible_verbosity': 3}
    tmp = None  # TODO: test this properly
    loader = None  # TODO: test this properly
    play_context = None  # TODO: test this properly

    # test constructor
    action = ActionModule(_shared_loader_obj, task, _task_vars, tmp, loader, play_context)
    assert action



# Generated at 2022-06-21 03:03:53.200824
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert test_validate_run() == None
    assert test_validate_per_host_run() == None
    assert test_validate_aggregate_run() == None
    assert test_validate_data_run() == None
    assert test_validate_per_host_aggregate_run() == None
    assert test_validate_per_host_aggregate_data_run() == None


# Generated at 2022-06-21 03:03:58.405340
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor
    stats = {'data': {}, 'per_host': False, 'aggregate': True}
    data = {'ansible_stats': stats}

    task_vars = {}
    action_module = ActionModule(task=data, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert action_module



# Generated at 2022-06-21 03:04:03.527071
# Unit test for constructor of class ActionModule
def test_ActionModule():
    hosts = list()
    recursive = {'data': {'x': 1, 'y': 2}, 'aggregate': False, 'per_host': True}
    flat = {'data': {'z': 1}, 'aggregate': True, 'per_host': True}
    tasks = [{'name': 'test_recursive', 'action': {'module': 'set_stats', 'args': recursive}},
             {'name': 'test_flat', 'action': {'module': 'set_stats', 'args': flat}}]

    # Run the tasks and check that output is as expected
    for task in tasks:
        # Check that the action is of expected type ActionModule
        assert isinstance(ActionModule._task_to_action(task, hosts, loader=None), ActionModule), 'task did not return an instance of ActionModule'


# Generated at 2022-06-21 03:04:09.075834
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    action_plugin.ActionModule.run() is tested here.
    """
    module = ActionModule(load_builder_module('set_stats_defaults', action='test'))
    results = module.run(task_vars={})
    assert results['failed'] == False
    stats = results['ansible_stats']
    assert stats['aggregate'] == True
    assert stats['per_host'] == False
    assert 'data' in stats.keys()


# Generated at 2022-06-21 03:04:20.141837
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = {}
    task_name = 'test_actionmodule_run'
    task_args = {'data': {'abc': '123'}}

    task = Task()
    task.name = task_name
    task.args = task_args

    am = ActionModule(task, play_context, variable_manager, loader)

    result = am.run(task_vars=dict())


# Generated at 2022-06-21 03:04:46.616738
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Construct module object for testing
    module = ActionModule()
    module.loader.set_basedir("tests/dummy_module")
    module.noop = True

    # Construct task object for testing
    task = DummyTask()
    task.action = "set_stats"
    task.args = {
        "data": {"key_1": "value_1", "key_2": "value_2"},
        "per_host": True,
        "aggregate": False
    }

    # Construct the task execution variables
    task_vars = dict()

    # Construct the test result
    result = dict()
    result['failed'] = False
    result['changed'] = False

# Generated at 2022-06-21 03:04:51.453519
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Unit test for testing if correct object is created
    # It does not make sense to have a unit test for the run method
    # as it will depend on task vars from the playbook
    module = ActionModule(dict(), dict())
    assert module.TRANSFERS_FILES == False
    assert module._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))


# Generated at 2022-06-21 03:04:59.397752
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    actionModule = ActionModule(None, None)

    task_vars = {'test_task_vars1': 'A1'}
    tmp = actionModule.run(task_vars = task_vars)
    assert tmp['ansible_facts'] == {}

    task_vars = {}
    tmp = actionModule.run(task_vars = task_vars)
    assert tmp['ansible_facts'] == {}

# Test function
#def main():
#    test_ActionModule_run()
#
#if __name__ == '__main__':
#    main()

# Generated at 2022-06-21 03:05:00.218783
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-21 03:05:02.067308
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Unit test for class ActionModule
    """
    stats = ActionModule()

# Generated at 2022-06-21 03:05:11.677545
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils._text import to_bytes

    play_context = PlayContext()

    action = ActionModule(
        task=Task(),
        connection=None,
        play_context=play_context,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    # _load_params and _load_args methods are not tested here since
    # they are overridden in parent class and therefore, they are tested
    # using test_action_Base.py

    assert hasattr(action, 'run')
    assert action.TRANSFERS_FILES is False

    action._task = Task()

# Generated at 2022-06-21 03:05:20.503846
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Constructor for the ActionModule class should take
    :param task: An instance of a task to execute.
    :param connection: An instance of a ConnectionInfo class. 
    :param play_context: An instance of a PlayContext class.
    :param loader: An instance of a DataLoader class.
    :param templar: An instance of a Templar class.
    :param shared_loader_obj: ???
    """
    am = ActionModule({}, {"connection": "test"}, "test", "test", "test", "test")
    assert am.task == {}
    assert am.connection_info == "test"
    assert am.play_context == "test"
    assert am.loader == "test"
    assert am.templar == "test"
    assert am.shared_loader_obj == "test"

# Unit

# Generated at 2022-06-21 03:05:26.128227
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = dict(args=dict(per_host=True, data=dict(this_host=True, that_host=False)))
    action_module = ActionModule(task, {})

    assert action_module.TRANSFERS_FILES == False
    assert action_module._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))
    # In the above, _VALID_ARGS is not intended to be used
    # by end user.
    assert isinstance(action_module._VALID_ARGS, frozenset)


# Generated at 2022-06-21 03:05:29.196620
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module_class = ActionModule(None, None)
    current_task_vars = {'foo': 'bar'}
    action_module_class.run('/tmp', task_vars=current_task_vars)



# Generated at 2022-06-21 03:05:37.657478
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(load_params=dict(
        action=dict(
            module_name='test',
            module_args=dict(
                data=dict(
                    foo='bar',
                ),
                per_host=True,
                aggregate=False,
            )
        )
    ))
    result = module.run(task_vars=None)
    assert result == {
        'ansible_facts': {
            'ansible_stats': {
                'aggregate': False,
                'per_host': True,
                'data': {
                    'foo': 'bar',
                },
            },
        },
        'changed': False,
    }

# Generated at 2022-06-21 03:06:20.541090
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule('/tmp', dict())

    assert am._task.action == 'set_stats'
    assert am._task.args == dict()
    assert am._task.action == 'set_stats'
    assert am._task.supports_check_mode == False
    assert am.TRANSFERS_FILES == False

# Generated at 2022-06-21 03:06:25.434782
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        from ansible.plugins.action.set_stats import ActionModule
    except ImportError:
        raise SkipTest("Can't test set_stats without module")
    
    # Check that constructor creates correct class
    x = ActionModule(None, None, None, None, None, None)
    assert x.__class__.__name__ == 'ActionModule'

# Generated at 2022-06-21 03:06:35.171869
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task={'action': {'__ansible_arguments__': {'name': '_test_'}}})

    assert action_module._task.action == {'__ansible_arguments__': {'name': '_test_'}}

    # TODO: needs to be tested with complete task
    #action_module = ActionModule(task={'action': {'__ansible_arguments__': {'name': 'show',
    #                                                                       'interval': 3,
    #                                                                       'wait': 5,
    #                                                                       'prompt': 'INSERT MESSAGE HERE:',
    #                                                                       'answer': '42'}}})

    #assert action_module._task.action == {'__ansible_arguments__': {'name': 'show

# Generated at 2022-06-21 03:06:39.721625
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_bytes
    from json import dumps

    boolean(u'true', strict=False)

    result = dumps(ActionModule._VALID_ARGS)

    assert isinstance(result, string_types)
    assert isinstance(result, to_bytes)
    assert result == b'"aggregate", "data", "per_host"'

# Generated at 2022-06-21 03:06:43.941131
# Unit test for constructor of class ActionModule
def test_ActionModule():
  am = ActionModule(None, None, None, None)
  print(am)
  print(am.name)
  print(am.runner_name)
  print(am.templar)
  print(am.transport)
  print(am.transfer_strategy)
  print(am.action_write_locks)
  print(am.module_args)
  print(am.task_vars)


# Generated at 2022-06-21 03:06:45.369538
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not ActionModule(None, {})._templar
    task = dict(args=dict(per_host=True))
    assert ActionModule(task, {})._task == task

# Generated at 2022-06-21 03:06:53.545188
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.six import StringIO

    ansible_module_instance = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    ansible_module_instance._connection = "local"
    ansible_module_instance._loader = "loader"
    ansible_module_instance._templar = "templar"

    ansible_module_instance._task = ansible_module_instance

# Generated at 2022-06-21 03:06:58.767052
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_obj = ActionModule()
    assert hasattr(test_obj, '_VALID_ARGS')
    assert isinstance(test_obj._VALID_ARGS, frozenset)
    assert hasattr(test_obj, 'TRANSFERS_FILES')
    assert isinstance(test_obj.TRANSFERS_FILES, bool)
    assert hasattr(test_obj, 'run')
    assert callable(test_obj.run)


# Generated at 2022-06-21 03:07:05.604689
# Unit test for constructor of class ActionModule
def test_ActionModule():
  actionmodule = ActionModule(connection=None,
                              _task=None,
                              _connection_info=None,
                              loader=None,
                              templar=None,
                              shared_loader_obj=None)

  assert actionmodule._task.args == dict()
  assert not actionmodule.TRANSFERS_FILES

  assert actionmodule.run(tmp=None,
                          task_vars={'foo': 'bar'}) == {
                              'changed': False,
                              'ansible_stats': {
                                  'data': {},
                                  'per_host': False,
                                  'aggregate': True
                              }
                          }


# Generated at 2022-06-21 03:07:07.465194
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Test return type of run() is dict, only.

    """
    obj = ActionModule()
    result = obj.run()

    assert isinstance(result, dict)

# Generated at 2022-06-21 03:09:05.294125
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
                    task=dict(action=dict(module_name='test_module', module_args=dict(data={'test_data': 1}, per_host='yes', aggregate='no')))
                   )

    # Testing if the constructor of the class set the values correctly on class variables
    task = action.task
    assert task['action'] ==  {'module_name': 'test_module', 'module_args': {'data': {'test_data': 1}, 'per_host': 'yes', 'aggregate': 'no'}}

    # Testing for idempotency
    action = ActionModule(
                    task=dict(action=dict(module_name='test_module', module_args=dict(data={'test_data': 1}, per_host='yes', aggregate='no')))
                   )

# Generated at 2022-06-21 03:09:10.528655
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # This test is not working, as the ActionModule
    # uses a AnsibleRunner instead of the provided
    # ansible.plugins.action.ActionBase.run()
    # Therefor the ansible_stats is never populated
    # in the result dict.
    assert False

    # Create a ActionModule object
    am = ActionModule()

    # Creat a task object
    t = Task()
    t.action = 'set_stats'

    # Create a ansible_runner object
    from ansible.executor import runner
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    a_

# Generated at 2022-06-21 03:09:16.654060
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test
    """
    task = {
        'action': {
            '__ansible_module__': 'set_stats',
            'args': {
                'data': {
                    'foo': 'bar'
                }
            }
        }
    }
    action_module = ActionModule()

    result = action_module.run(task_vars=task)
    assert result['changed'] == False
    assert result['ansible_stats']['data'] == {'foo': 'bar'}

# Generated at 2022-06-21 03:09:25.285834
# Unit test for constructor of class ActionModule
def test_ActionModule():

    def test_valid_boolean_option(yaml_text, expected_result):
        from ansible.module_utils.parsing.convert_bool import boolean
        from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

        class FakeTask(object):
            def __init__(self):
                self.args = {}

        task = FakeTask()
        task.args['data'] = yaml_text
        task.args['per_host'] = '{{per_host}}'
        task.args['aggregate'] = '{{aggregate}}'


# Generated at 2022-06-21 03:09:33.466826
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Task module is a class, so first make an instance
    action_module = ActionModule()

    # Now make a dummy "task":
    # Set the attributes that are accessed in the method run

    # Set _task
    class Task:
        args = {'data': {'a': 1, 'b': 2}, 'per_host': True, 'aggregate': False}
    action_module._task = Task()

    # Set _templar
    class Templar:
        def template(self, some_string, convert_bare=False, fail_on_undefined=True):
            return some_string
    action_module._templar = Templar()

    # Pass an empty task_vars to run
    result = action_module.run(task_vars={})

    assert result['changed'] == False

# Generated at 2022-06-21 03:09:43.138779
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test that the constructor will fail without arguments
    # Should fail because "self" is not an argument
    try:
        am = ActionModule()
    except TypeError as err:
        assert(err.message == "__init__() takes at least 2 arguments (1 given)")
    else:
        assert(False) # Should have raised a TypeError

    # Test that the constructor will fail with only one argument
    # Should fail because only the module_utils parameter was passed
    try:
        am = ActionModule(module_utils='fake')
    except TypeError as err:
        assert(err.message == "__init__() takes at least 2 arguments (2 given)")
    else:
        assert(False) # Should have raised a TypeError

    # Test that the constructor will fail with only two arguments
    # Should fail because only the module_utils and

# Generated at 2022-06-21 03:09:45.942743
# Unit test for constructor of class ActionModule
def test_ActionModule():
    act = ActionModule(None, None, None, None)
    assert act._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))
    assert act.TRANSFERS_FILES == False

# Generated at 2022-06-21 03:09:53.603759
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup mocks:
    class MockTask():
        def __init__(self, args):
            self.args = args
    class MockTemplar():
        def template(self, template, convert_bare=False, fail_on_undefined=False):
            return template
    task = MockTask(args={'data': {'foo': '{{ bar }}'}, 'aggregate': 'True'})
    templar = MockTemplar()
    
    # Run test:
    action_module = ActionModule(task, templar)
    result = action_module.run()
    assert result == {'ansible_stats': {'data': {'foo': '{{ bar }}'}, 'per_host': False, 'aggregate': True}, 'changed': False}

# Generated at 2022-06-21 03:09:54.518926
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-21 03:10:03.755549
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # instantiate action module instance
    action_module = ActionModule()

    # reset info
    action_module._connection = None
    action_module._shell = None
    action_module._task = None
    action_module._low_level_shell = None
    action_module._loader = None
    action_module._templar = None
    action_module._shared_loader_obj = None
    action_module._host = None
    action_module._task_vars = None
    action_module._variable_manager = None
    action_module._task_vars = None

    # init params
    class connection:
        class _shell:
            def __init__(self):
                self.exec_command = "echo success"
            def close(self):
                pass

    task = dict()