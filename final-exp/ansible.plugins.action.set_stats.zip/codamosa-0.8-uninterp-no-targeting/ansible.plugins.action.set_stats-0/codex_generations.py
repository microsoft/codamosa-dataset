

# Generated at 2022-06-21 03:00:33.060767
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ############################################################################
    # Unit test for method run of class ActionModule
    ############################################################################

    # Method run() of class ActionModule is called to populate the standard
    # variables in the results dictionary.

    from ansible.module_utils.ansible_modlib.parsing.convert_bool import boolean as convert_bool
    import json

    # Mock Task class
    class Task(object):
        def __init__(self):
            self.args = {}

    # Mock PlayContext class
    class PlayContext(object):
        def __init__(self):
            self.check_mode = False

    # Mock Runner class
    class Runner(object):
        class Connection(object):
            class Transport(object):
                def __init__(self):
                    self.connection = 'local'


# Generated at 2022-06-21 03:00:43.884373
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())

    # check the value of _VALID_ARGS
    EXIST = False
    if isinstance(a._VALID_ARGS, set):
        if ('per_host' in a._VALID_ARGS) and ('aggregate' in a._VALID_ARGS) and ('data' in a._VALID_ARGS):
            EXIST = True
    assert EXIST

    # check the value of TRANSFERS_FILES
    assert not a.TRANSFERS_FILES

# Generated at 2022-06-21 03:00:55.203163
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Mock task, task_vars, tmp to run unit test
    import mock
    task = mock.MagicMock(return_value = 'task')
    task_vars = mock.MagicMock(return_value = 'task_vars')
    tmp = mock.MagicMock(return_value = 'tmp')

    # Setting up return values for test
    test_dict = {}
    # Replace original method 'run' for class ActionModule with method 'run_test' for unit test
    with mock.patch('ansible.plugins.action.set_stats.ActionModule.run') as run_test:
        am = set_stats.ActionModule(task, task_vars, tmp)
        run_test.return_value = test_dict
        assert am.run(tmp, task_vars) == test_dict

# Generated at 2022-06-21 03:01:00.624203
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class ActionModuleMock(ActionModule):
        def run(self, tmp=None, task_vars=None):
            super(ActionModuleMock, self).run(tmp, task_vars)
    assert hasattr(ActionModuleMock, 'run')


# Generated at 2022-06-21 03:01:03.030880
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_ActionModule_obj = ActionModule(None, None, None, None, None, None)
    return test_ActionModule_obj

test_ActionModule_output = test_ActionModule()

# Generated at 2022-06-21 03:01:14.338836
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from units.mock.path import mock_unfrackpath_success

    loader = DictDataLoader({})
    tmp_path = '/path/to/nowhere'
    task_vars = {
        'tmp': tmp_path,
        'ansible_facts': {'value': 0},
        'foo': 'bar',
        'answer': 42,
    }

    def mock_task_get_tmp_path(self, remote_tmp):
        return tmp_path

    def mock_templar_template(self, d, c, f):
        if isinstance(d, string_types):
            return d.replace('ANSIBLE_ANSIBLE_VAR_', '')


# Generated at 2022-06-21 03:01:15.364186
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not ActionModule(None, None, {})

# Generated at 2022-06-21 03:01:17.320621
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import pytest
    test = ActionModule()
    assert test.run() == []

# Generated at 2022-06-21 03:01:25.825827
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class TestVarsModule:
        def __init__(self, data=None, per_host=None, aggregate=None):
            self.args = {
                'data' : data,
                'per_host' : per_host,
                'aggregate' : aggregate
            }

        @property
        def task(self):
            return self
        
        @property
        def _task(self):
            return self

        @property
        def _templar(self):
            return self

    def boolean(boolean_string, strict=True):
        return boolean_string

    class TestActionBase:
        def __init__(self, tmp=None, task_vars=None):
            self.task_vars = task_vars


# Generated at 2022-06-21 03:01:36.076329
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    def ansible_module_run(tmp=None, task_vars=None):
        return ActionModule.run(ActionModule(), tmp, task_vars)

    def assert_run_result(result, data, per_host, aggregate):
        assert result.startswith("The variable") or \
            result['ansible_stats'] == {'data': data, 'per_host': per_host, 'aggregate': aggregate}

    def run_test(args, data, per_host, aggregate):
        return ansible_module_run(task_vars={'hostvars': {}}).run(args)

    assert_run_result(run_test({'data': ''}), {}, True, True)

# Generated at 2022-06-21 03:01:45.964687
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # constructor is tested by running a module
    # by convention, constructors in Ansible start with __init__()
    # and are not tested separately
    #
    # no need to test run()
    # run()'s code is not amenable to unit testing, it depends on
    # ansible and ansible plugins that are difficult to mock
    #
    # no need to test other methods
    # transfer_files and run are the only externally visible methods
    # so there is nothing for unit test to test
    assert(True)



# Generated at 2022-06-21 03:01:49.532139
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Test the method run call
    '''
    # Check the case when ansible_stats is not defined
    action_module = ActionModule()
    result = action_module.run()
    assert result['changed'] == False
    assert result['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True}


# Generated at 2022-06-21 03:01:56.867151
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import sys, os
    import unittest

    class TestActionModuleRun(unittest.TestCase):

        def test_valid_data(self):

            # Python 3
            if sys.version_info > (3,):
                long = int
                
            result = ActionModule.run(ActionModule, data=None, per_host=None, aggregate=None)
            self.assertFalse(result['changed'])
            self.assertEqual(result['ansible_stats']['data'], {})
            self.assertEqual(result['ansible_stats']['per_host'], False)
            self.assertEqual(result['ansible_stats']['aggregate'], True)

            # 1) Valid data
            data = {'var1': 1, 'var2': 'two'}

# Generated at 2022-06-21 03:01:58.138131
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module is not None

# Generated at 2022-06-21 03:02:07.572333
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test for invalid 'data' option
    args = {'data': '"test"'}
    task_vars = {}
    am = ActionModule(None, None, args, task_vars)
    res = am.run(None, task_vars)
    assert res['failed'] == True
    assert res['msg'] == "The 'data' option needs to be a dictionary/hash"

    # test for non-empty dictionary for 'data' option
    args = {'data': {'a': 1, 'b': '"string"'}}
    task_vars = {}
    am = ActionModule(None, None, args, task_vars)
    res = am.run(None, task_vars)
    assert res['failed'] == False

# Generated at 2022-06-21 03:02:12.633808
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=dict(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module.TRANSFERS_FILES == False
    assert module._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))


# Generated at 2022-06-21 03:02:19.561118
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: rewrite test_set_stats.py in test/units/plugins/action
    import os
    import sys
    from ansible.utils.vars import load_extra_vars
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import AllDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DarwinDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import SolarisDistributionFactCollector
    from ansible.module_utils.facts.system.distribution import BSDDistributionFactCollector

# Generated at 2022-06-21 03:02:21.022107
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None)
    assert action is not None

# Generated at 2022-06-21 03:02:29.417038
# Unit test for constructor of class ActionModule
def test_ActionModule():
    arg = {'data': 1, 'per_host': 0, 'aggregate': 1}
    obj = ActionModule(task=arg)
    assert (obj.run()['ansible_stats']['per_host'] == False)
    assert (obj.run()['ansible_stats']['aggregate'] == True)
    assert ('data' in obj.run()['ansible_stats'])
    assert (isinstance(obj.run()['ansible_stats']['data']['data'], int))
    assert (obj.run()['ansible_stats']['data']['data'] == 1)

# Generated at 2022-06-21 03:02:32.393601
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule(None, None)
    assert mod.TRANSFERS_FILES is False
    assert mod._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-21 03:02:53.164923
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test init
    #obj = AnsibleModule(argument_spec={"data": {'type': 'dict', 'default': {}}, 'per_host': {'type': 'bool', 'default': False}},
    #                    supports_check_mode=False)
    #TestClass = obj._task.action._shared_loader_obj.module_loader.get_module("set_stats").ActionModule("set_stats")
    TestClass = ActionModule("set_stats")
    TestClass.run({}, {'ansible_facts': {"network": "mgmt"}})
    assert TestClass.result == {'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True},
                                'ansible_facts': {'network': 'mgmt'}, 'changed': False}

    # Test run
   

# Generated at 2022-06-21 03:03:01.409499
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create a mock instance of task class
    _task = dict(
            args = dict(
                    data = dict(
                            key1 = 'value1',
                            key2 = 'value2'
                            ),
                    aggregate = False,
                    per_host = True
                    ),
            action = 'set_stats',
            tags = ['test']
            )

    # create a mock instance of play class
    _play = dict(
            hosts = 'all',
            vars = dict(
                    var1 = 'value1',
                    var2 = 'value2'
                    )
            )

    # create mock result

# Generated at 2022-06-21 03:03:10.241311
# Unit test for constructor of class ActionModule
def test_ActionModule():

    import ansible.plugins.action.set_stats as module
    yaml_str = '''
    tasks:
      - set_stats:
          aggregate: yes
          per_host: no
          data:
            key1: value1
            key2:
              - 1
              - 2
      - set_stats:
          aggregate: true
          per_host: false
          data:
            key1: value1
            key2:
              - 1
              - 2
    '''
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

# Generated at 2022-06-21 03:03:20.042472
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    task_args = {'data': {'test1': '1', 'test2': 2}}
    module._task = Mock(args=task_args)
    module._task.args = task_args

    mock_load = Mock(return_value='loaded')
    with patch.dict('sys.modules', {'ansible.utils.vars': Mock(vars=Mock(load=mock_load))}):
        result = module.run(tmp='/tmp', task_vars={'test_var': 'value'})

    assert mock_load.call_count == 1
    assert not 'failed' in result
    assert isinstance(result['ansible_stats'], dict)
    assert result['ansible_stats']['data']['test1'] == '1'

# Generated at 2022-06-21 03:03:20.507947
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()

# Generated at 2022-06-21 03:03:21.952697
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test construction of ActionModule class
    action_mod = ActionModule()
    assert isinstance(action_mod, ActionModule)


# Generated at 2022-06-21 03:03:32.636026
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))
    assert action.TRANSFERS_FILES == False
    assert action._task == None
    assert action._connection == None
    assert action._play_context == None
    assert action._loader == None
    assert action._templar == None
    assert action._shared_loader_obj == None
    assert action._add_cleanup_task == None
    assert action._delete_remote_tmp == True
    assert action._remote_tmp == None
    assert action._remote_tmp_base == None
    assert action._remote_tmp_path == None
    assert action

# Generated at 2022-06-21 03:03:35.213661
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()
    am.task = FakeModule()
    am.templar = FakeTemplar()
    am.run({}, dict(test='test'))
    assert am.run.called

# Generated at 2022-06-21 03:03:42.192658
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class FakeTask(object):
        data = {}
        def __init__(self, data):
            self.data = data

    dict1 = dict()
    dict1['args'] = dict()
    dict1['args']['aggregate'] = False
    dict1['args']['data'] = {'a':'b'}
    dict1['args']['per_host'] = True
    fake_task = FakeTask(data=dict1)
    # task = ActionModule(task=fake_task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # print(task.argspec)
    # print(task.run())

# Generated at 2022-06-21 03:03:47.837824
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # create an instance of class ActionModule
    mod = ActionModule(load_args=dict(), templar=None)
    # check whether it is instance of class ActionModule
    assert isinstance(mod, ActionModule)

    # create an instance of class ActionModule
    mod = ActionModule(load_args=dict(), templar=None, task_vars={})
    # check whether it is instance of class ActionModule
    assert isinstance(mod, ActionModule)

# Generated at 2022-06-21 03:04:17.447807
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not ActionModule.is_shell
    assert ActionModule.transfers_files is False
    from ansible.executor.playbook_iterator import PlaybookIterator
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    config = dict(FORKS=10)
    play_context = PlayContext()
    inventory = InventoryManager(loader=None, sources=["localhost"])
    variable_manager = VariableManager(loader=None, inventory=inventory)
    task = Task()
    task._role = Role()
    block = Block()
    host_vars = {}
   

# Generated at 2022-06-21 03:04:25.493552
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test for method run of class ActionModule
    '''
    from ansible.parsing.vault import VaultSecret
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.template import Templar
    from ansible.utils.vars import AnsibleVars
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action.set_stats import ActionModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.plugins.callback.default import CallbackModule
    from ansible.plugins.loader import action_loader
    import json
    import os

    #

# Generated at 2022-06-21 03:04:26.020520
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 03:04:30.199292
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    new_action = create_action_instance('set_stats', {})
    assert new_action.run() == {'changed': False, 'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}}


# Generated at 2022-06-21 03:04:31.059531
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 03:04:35.145077
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task_vars={'ANSIBLE_MODULE_ARGS': {'data': {}, 'aggregate': False}}) != None
    assert ActionModule(task_vars={'ANSIBLE_MODULE_ARGS': {'data': {'k': 'v'}, 'aggregate': False}}) != None

# Generated at 2022-06-21 03:04:44.136137
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Need to mock methods of class ActionBase and prepare arguments
    from ansible.executor.task_result import TaskResult
    from ansible.vars import VariableManager
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    # Mocking class TaskResult
    TaskResult.is_failed     = lambda x: False
    TaskResult.is_changed    = lambda x: False
    TaskResult.__init__      = lambda x, y, z: None
    TaskResult.update_task_result_stats = lambda x: None

    # Mocking class VariableManager
    VariableManager.__init__ = lambda x, y, z: None
    VariableManager.get_vars = lambda x, y, z: {}
    VariableManager.extra_vars = {}

    # Mocking class Task

# Generated at 2022-06-21 03:04:52.300627
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Verify result of run method of ActionModule class.
    """
    # Define test input data
    test_args = {'aggregate': True,
                 'data': {'foo': 'bar'},
                 'per_host': False}

    test_data = {'per_host': False}

    # Create test instance of class
    action_mod = ActionModule()

    # Set '_task' attribute of class instance for testing purpose
    action_mod._task = type('test_task', (object,), test_args)

    # Run test for method run
    result = action_mod.run(task_vars=test_data)

    # Test assert output
    assert result['ansible_stats']['data']['foo'] == 'bar'



# Generated at 2022-06-21 03:04:56.560127
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_task = type('mock_task', (object,), {'args': {'data': {'CONNECTION': 'local'}}})()
    mock_module = type('mock_module', (object,), {'_task': mock_task})()
    mock_task_vars = {'inventory_hostname': 'localhost'}

    result = ActionModule.run(mock_module, None, mock_task_vars)
    assert result.get('changed') is False
    assert result.get('ansible_stats').get('data').get('CONNECTION') is 'local'

# Generated at 2022-06-21 03:05:04.674138
# Unit test for constructor of class ActionModule
def test_ActionModule():

    def get_args():
        return dict(
            aggregate=True,
            data=dict(
                a=2
                ),
            per_host=False
            )

    def get_task(args):
        task = dict(
            action=dict(
                module="set_stats",
                args=args
            )
        )
        return task

    test_task = get_task(get_args())
    action = ActionModule(None, test_task, None, None)

    assert action.run(None, None) is not None

# Generated at 2022-06-21 03:05:54.186029
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule()
    assert x._VALID_ARGS == frozenset(['aggregate', 'data', 'per_host']), "The VALID_ARGS are not the same"
    

# Generated at 2022-06-21 03:06:02.807135
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    task_vars = {u'foo': u'bar', u'ansible_stats': {u'per_host': False, u'aggregate': True, u'data': {}}}
    tmp = None
    am = ActionModule(task=MagicMock(), connection=None, play_context=MagicMock(), loader=None, templar=MagicMock(), shared_loader_obj=None)
    am.runner = MagicMock()
    am.runner.get_original_task.return_value = am._task

# Generated at 2022-06-21 03:06:03.536774
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 03:06:13.567964
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create instance of class ActionModule
    action_module = ActionModule(task=None, connection=None, _play_context=None, loader=None, templar=None, shared_loader_obj=None)

    data = {'ansible_lsb': {'distcodename': 'jessie', 'distdescription': 'Debian GNU/Linux', 'distid': 'Debian', 'distrelease': '8.3', 'distshortid': 'debian', 'majdistrelease': '8', 'release': '8.3'}, 'ansible_machine': 'x86_64', 'ansible_os_family': 'Debian', 'ansible_pkg_mgr': '/usr/bin/apt-get'}
    result = action_module.run(task_vars=data)

# Generated at 2022-06-21 03:06:23.258687
# Unit test for constructor of class ActionModule
def test_ActionModule():
    current_task = None
    current_play = None
    current_loader = None
    current_templar = None

    # Create a AnsibleTask object
    current_task = AnsibleTask()

    # Set the args of AnsibleTask to the args of ActionModule
    current_task.args = {'test': 'test'}

    # Create an ActionModule instance
    action_module = ActionModule(current_task, current_play, current_loader, current_templar)

    # Assert module arguments
    assert action_module._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))
    assert action_module.TRANSFERS_FILES is False

# Generated at 2022-06-21 03:06:32.928647
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule"""
    # Initializing
    task_vars = dict()
    tmp = dict()
    tmp['failed'] = False
    tmp['changed'] = False
    tmp['ansible_stats'] = dict()
    tmp['ansible_stats']['data'] = dict()
    tmp['ansible_stats']['per_host'] = False
    tmp['ansible_stats']['aggregate'] = True

    # Case 1: we want to limit testing to set_stats.py
    # ActionModule.run(self, tmp, task_vars)
    # Testing
    assert(tmp == ActionModule(self, task_vars).run(tmp, task_vars))

    # Case 2: we want to limit testing to set_stats.py
    # ActionModule.run(self,

# Generated at 2022-06-21 03:06:34.471124
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_stats = ActionModule()
    # run()
    set_stats.run(None, None)

# Generated at 2022-06-21 03:06:42.590048
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # create a mock ActionModule object to test
    module = ActionModule(task=dict())

    # mock the AnsibleModule
    module_mock = MagicMock()
    module.ansible_module = module_mock

    # mock the _templar class
    templar = MagicMock()
    module._templar = templar

    # mock ActionBase variables
    task_vars = {}
    module._task_vars = task_vars

    # mock the options for the test
    args = dict(
        data={'success': '{{ success }}',
              'fail': '{{ fail }}',
              'aggregate': '{{ aggregate }}',
              'per_host': '{{ per_host }}'},
        per_host='{{ per_host }}',
        aggregate='{{ aggregate }}'
    )



# Generated at 2022-06-21 03:06:44.302071
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert ActionModule({}, {}).run() == dict(changed=False, ansible_stats=dict(data={},
                                                                                 per_host=False,
                                                                                 aggregate=True))

# Generated at 2022-06-21 03:06:52.371099
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class x(object): pass

    module = x()
    action = ActionModule()

    # configure the module with a good set of arguments
    module.params = { 'per_host': False, 'data': { 'key_1': '{{ test_var }}{{ test_var }}', 'key_2': 'value_2' }, 'aggregate': True }
    module.task = x()
    module.task.args = module.params
    module.task_vars = { 'test_var': 'foo' }
    module.play_context = x()
    module.playbook_basedir = '/'

    # run the method "run" of the ActionModule class
    result = action.run(module)

    # verify the result from run is as expected

# Generated at 2022-06-21 03:08:58.090123
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import ansible.utils.vars
    module = __import__('ansible.plugins.action.set_stats', fromlist=['ActionModule'])

    task = {}
    task['args'] = {}
    task['args']['data'] = {}
    task['args']['data']['foo'] = 'bar'

    # monkey patch the utils.vars so we don't need to import the utils module
    ansible.utils.vars.isidentifier_orig = ansible.utils.vars.isidentifier
    def _isidentifier(x):
      return True
    ansible.utils.vars.isidentifier = _isidentifier

    # monkey patch the utils.vars so we don't need to import the utils module
    ansible.utils.vars.boolean_orig = ansible

# Generated at 2022-06-21 03:08:59.588843
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ test module constructor """
    mod = ActionModule(None, dict())
    assert mod != None


# Generated at 2022-06-21 03:09:03.238229
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Unit Test for constructor of class ActionModule """
    action_module = ActionModule(load_ansible_json=False)
    assert isinstance(action_module, ActionBase)
    assert action_module._task is None
    assert isinstance(action_module._VALID_ARGS, frozenset)
    assert action_module.TRANSFERS_FILES is False


# Generated at 2022-06-21 03:09:09.439144
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task

    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    hosts = InventoryManager(host_list=[])
    variable_manager = VariableManager(hosts=hosts)
    variable_manager._extra_vars = {'test_extra_var': 'value of test_extra_var'}
    variable_manager._options_vars = {'test_options_var': 'value of test_options_var'}

# Generated at 2022-06-21 03:09:11.136213
# Unit test for constructor of class ActionModule
def test_ActionModule():
  am = ActionModule(None, dict(), dict())    
  return am.run()

# Generated at 2022-06-21 03:09:18.780775
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    action = ActionModule(None, task_vars=task_vars)

    import mock
    from ansible.module_utils.parsing.convert_bool import boolean

    with mock.patch.object(ActionModule, 'run', return_value=dict(
        ansible_stats=dict(
            data=dict(a=1),
            per_host=True,
            aggregate=False,
        )
    )):
        result = action.run()

    assert result.get('ansible_stats', {}) == dict(
        data=dict(a=1),
        per_host=True,
        aggregate=False,
    )

# Generated at 2022-06-21 03:09:22.832627
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule()
    a.data = "test"
    assert a.run(tmp=None, task_vars=None) == {
        'changed': False,
        'ansible_stats': {
            'data': {
            },
            'per_host': False,
            'aggregate': True
        }
    }


# Generated at 2022-06-21 03:09:25.788256
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module.run(None, None) == {
        "ansible_stats": {
            "data": {},
            "per_host": False,
            "aggregate": True},
        "changed": False}



# Generated at 2022-06-21 03:09:27.515390
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action
    am = ansible.plugins.action.ActionModule()
    assert am.TRANSFERS_FILES is False
    return

# Generated at 2022-06-21 03:09:32.979352
# Unit test for constructor of class ActionModule
def test_ActionModule():

    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook import Play
    from ansible.playbook.play import Playbook
    from ansible.utils.vars import merge_hash

    task = TaskInclude()

    from ansible.playbook.role_include import IncludeRole
    task._role = IncludeRole()

    task._role._role_name = "test_role"
    task._role._tasks_filename = "test_tasks"

    task._role._task_blocks = [{'block': ['block'], 'block_nested': ['block_nested'], 'rescue': ['rescue'], 'always': ['always'], 'tasks': ['tasks']}]

    task._role._tasks_path = "test_tasks"
    task._role._role_