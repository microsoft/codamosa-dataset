

# Generated at 2022-06-21 03:00:30.984216
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule(None, None, None, None)
    assert m._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))
    assert m.TRANSFERS_FILES == False



# Generated at 2022-06-21 03:00:40.625434
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude

    args = {'data': {'a':1, 'b':2}, 'per_host': True, 'aggregate': True}

    play_context = PlayContext()

    block = Block()
    task = Task()
    task._role = Role()
    task._block = block
    task._play = play_context
    task._parent = block

    am = ActionModule()
    am._task = task

    result = am.run(task_vars=dict())

    assert result['changed'] == False

# Generated at 2022-06-21 03:00:42.282986
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # This is a stub
    # There are no parameters to check; Ansible checks return values of run().
    assert True

# Generated at 2022-06-21 03:00:49.406653
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(load_utils_base=False)
    
    assert action_module.run({}) == {
                    'ansible_stats': {'per_host': False, 'data': {}, 'aggregate': True},
                    'changed': False
                }
    assert action_module.run({'data': '{flag: true}'}) == {
                    'ansible_stats': {
                        'per_host': False,
                        'data': {'flag': True},
                        'aggregate': True
                    },
                    'changed': False
                }

# Generated at 2022-06-21 03:00:59.041517
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Dummy class for unit testing "run" method of ActionModule class
    class DummyActionModule(ActionModule):
        def _execute_module(self, tmp=None, task_vars=None, wrap_async=None):
            return 10, "dummy"

    m = DummyActionModule()

    # Test with no stats and no args
    m.runner_on_failed = lambda x, y, z, msg: msg
    m._task.args = {}
    assert m.run() == {"changed": False, "ansible_stats": {"data": {}, "per_host": False, "aggregate": True}}

    # Test with stats and args

# Generated at 2022-06-21 03:01:00.854943
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	assert ActionModule.run == ActionBase.run
	

# Generated at 2022-06-21 03:01:07.624183
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = dict(
        action=dict(
            module='set_stats',
            args=dict(
                data=dict(
                    some_var='foo',
                    other_var=42,
                ),
                per_host=True,
                aggregate=False,
            )
        )
    )
    task_vars = dict()

    am = ActionModule(task, task_vars=task_vars)

    result = am.run(task_vars)

    assert 'ansible_stats' in result

    # test templates have been applied
    assert result['ansible_stats']['data']['some_var'] == 'foo'
    assert type(result['ansible_stats']['data']['some_var']) is str


# Generated at 2022-06-21 03:01:15.884475
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Check correctness of the method run of class ActionModule"""
    # Load the ActionModule in a custom way to be able to test non-public methods
    action_module = ActionModule()
    # Create the mock object
    action_module._templar = MockTemplar()

    result = action_module.run(tmp=None, task_vars=None)
    assert result['ansible_stats']['aggregate'] == False, "Unexpected value for result['ansible_stats']['aggregate']: %s" % result['ansible_stats']['aggregate']

# Generated at 2022-06-21 03:01:24.741892
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.module_utils import basic
    from ansible.module_utils.parsing.convert_bool import boolean

    task_vars = { "foo" : "bar" }

    # Test with no data
    mock_module = basic.AnsibleModule(
        argument_spec = dict()
    )

    action_module = ActionModule(mock_module)
    result = action_module.run(tmp='/tmp', task_vars=task_vars)
    stats = result.get('ansible_stats')
    assert stats == {'data': {}, 'per_host': False, 'aggregate': True}

    # Test with single variable
    mock_module = basic.AnsibleModule(
        argument_spec = dict(data={"foo": "bar"})
    )

# Generated at 2022-06-21 03:01:35.638476
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    def BadValue(value):
        raise Exception("bad value")

    class MockActionModule(ActionModule):

        def __init__(self,data = None):
            self._data = data

        def run(self, tmp=None, task_vars=None):
            return self._data

    class MockTask(object):

        def __init__(self,args):
            self.args = args


# Generated at 2022-06-21 03:01:48.028947
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from units.mock.loader import DictDataLoader
    from units.mock.path import MockPath
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader

    loader = DictDataLoader({})
    path_mock = MockPath()

# Generated at 2022-06-21 03:01:49.877247
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: add unit tests in set_stats.py module
    assert True == True

# Generated at 2022-06-21 03:01:52.177853
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule('test', 'test', 'test', 'test')
    assert not isinstance(action, ActionBase)



# Generated at 2022-06-21 03:02:05.155681
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.vars import read_vars_from_file
    import sys
    import os

    try:
        path = os.path.join(os.path.dirname(__file__), '..', '..', 'lib', 'ansible', 'utils', 'vars.py')
        vars_obj = read_vars_from_file(path)
    except FileNotFoundError:
        vars_obj = read_vars_from_file('/usr/lib/python3.6/site-packages/ansible/utils/vars.py')

    # Read the variable name from file vars.py
    isidentifier = vars_obj['isidentifier']

    # Read data from file ActionModule.yml using task.vars of TestModule

# Generated at 2022-06-21 03:02:10.212361
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.set_stats as set_stats
    am = set_stats.ActionModule(dict(name='test', action='test'), dict(test='test'), dict())
    assert am is not None

# Generated at 2022-06-21 03:02:11.274064
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule() is not None

# Generated at 2022-06-21 03:02:18.953128
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins .action import ActionModule
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    host_vars = HostVars(dict())
    variable_manager = VariableManager(loader=DataLoader(), inventory=InventoryManager(host_vars))
    action = ActionModule(dict(), variable_manager, loader=DataLoader())
    action.variable_manager.extra_vars = {'ansible_custom_key': 'ansible_custom_value'}
    action.variable_manager.options_vars = {'ansible_custom_key': 'ansible_custom_value'}

# Generated at 2022-06-21 03:02:21.254990
# Unit test for constructor of class ActionModule
def test_ActionModule():
# need to test several combinations of data, per_host, aggregate
    return None

# vim: expandtab tabstop=4 softtabstop=4 shiftwidth=4

# Generated at 2022-06-21 03:02:25.096738
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert isinstance(action._VALID_ARGS, frozenset)
    assert action._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))
    assert action.TRANSFERS_FILES == False


# Generated at 2022-06-21 03:02:25.929860
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:02:44.012313
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Unit test for method run of class ActionModule
    # First set up a mock task, with args. We're going to assume that
    # the task has already been validated elsewhere.
    task_args = dict()
    task_args['data'] = dict([('x', '{{ thing }}'), ('y', '2')])
    # Set up the task to be a mock task, so that the ActionModule does
    # not attempt to actually find an action plugin or transfer files
    task = dict()
    task['action'] = dict()
    task['action']['__ansible_module__'] = '__fake__'
    task['args'] = task_args
    # Set up a mock ActionModule
    action_mock = ActionModule(task, dict())
    # Set up a mock templar, which will have its method template called.
    #

# Generated at 2022-06-21 03:02:49.275922
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        # Create an instance of ActionModule and supply invalid value to __init__
        task = ActionModule.__new__(ActionModule)
        action_module = ActionModule.__init__(task)

        # If no exception is raised, pass the test
        assert True
    except Exception as e:
        # If any exception is raised, fail the test
        assert False, e

# Generated at 2022-06-21 03:02:59.068168
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action = ActionModule()

    action.task_vars = {}

    # test with aggregation
    action.task.args = {"data": {"key1": "val1", "key2": "val2"}, "aggregate": 1, "per_host": 1}
    response = action.run(tmp=None, task_vars=action.task_vars)

    assert response['ansible_stats']['per_host']
    assert response['ansible_stats']['aggregate']
    assert response['ansible_stats']['data']['key1'] == "val1"
    assert response['ansible_stats']['data']['key2'] == "val2"

    # test with aggregation

# Generated at 2022-06-21 03:03:04.475575
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    result = {'_ansible_verbose_override': False, '_ansible_no_log': False, '_ansible_debug': False, '_ansible_parsed': True, '_ansible_version': '2.8.0'}
    class fake_vars(object):
        def __init__(self):
            self.var1 = 12
            self.var2 = 'hello'
    class fake_templar(object):
        def __init__(self):
            self.var1 = 12
            self.var2 = 'hello'
        def template(self, var):
            if var == '{{ var1 }}':
                return 12
            if var == '{{ var2 }}':
                return 'hello'

# Generated at 2022-06-21 03:03:05.790012
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert hasattr(module, 'run')

# Generated at 2022-06-21 03:03:07.019763
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__bases__[0].__name__ == 'ActionBase'

# Generated at 2022-06-21 03:03:13.952894
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.common.dict import merge_dict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.formatters import boolean_from_string
    from ansible.module_utils.compat.ipaddress import ip_address
    from ansible.module_utils.compat.subprocess import getoutput
    from ansible.module_utils.common.validation import check_type_dict

# Generated at 2022-06-21 03:03:22.065450
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: unit test for method run of class ActionModule
    import sys
    import os
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.facts_util import FactsUtil
    from ansible.plugins.loader import action_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.module_utils.parsing.convert_bool import boolean
    import yaml
    loader = DataLoader()
    play_context = PlayContext()
    tmp = None
    task_vars = dict()
    task_vars['ansible_managed'] = 'Ansible managed'


# Generated at 2022-06-21 03:03:32.765131
# Unit test for constructor of class ActionModule
def test_ActionModule():
  import sys
  import contextlib

  #  Add the class directory to the python path so we can find the
  #  plugin utils
  sys.path.insert(0, '/home/ruan/workspaces/ansible/ansible/lib/ansible/plugins/action')
  from action_plugins.set_stats import ActionModule

  #  Create a dummy module as a mock so we can test

# Generated at 2022-06-21 03:03:40.776714
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = 'localhost'
    task = {
        'id': 'test',
        'name': 'test',
        'action': 'debug',
        'args': {
            'data': {'key': 'value'},
            'per_host': False,
            'aggregate': True
        }
    }
    task_vars = {'test': 0}

    action = ActionModule(task, task_vars, host)
    result = action.run()

    assert result['changed'] == False
    assert result['ansible_stats']['data']['key'] == 'value'
    assert result['ansible_stats']['per_host'] == False
    assert result['ansible_stats']['aggregate'] == True

# Generated at 2022-06-21 03:04:02.678980
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # TODO: Add some asserts

    # create an instance of class ActionModule
    obj = ActionModule()

    # Call the method run()
    result = obj.run()

    # Print the value of the result
    print(result)


# Generated at 2022-06-21 03:04:08.351086
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # The following code snippet is based on the top answer by user Martijn Pieters
    # from this stackoverflow thread:
    # https://stackoverflow.com/questions/28065965/python-how-to-test-a-class-that-has-a-method-that-prints-to-standard-output
    import contextlib
    import sys
    from io import StringIO
    from unittest import TestCase

    from ansible.plugins.action.set_stats import ActionModule

    # Override the stdout method of sys module
    @contextlib.contextmanager
    def stdout_as_stringio():
        old_stdout = sys.stdout
        sys.stdout = StringIO()
        yield sys.stdout  # return stdout as a string
        sys.stdout = old_stdout


# Generated at 2022-06-21 03:04:18.650708
# Unit test for constructor of class ActionModule
def test_ActionModule():
    
    # Tests for constructor of class ActionModule
    # create an instance of the class ActionModule
    test_ActionModule = ActionModule()
    assert test_ActionModule != None

    # get the static variable TRANSFERS_FILES from the class
    test_ActionModule_TRANSFERS_FILES = ActionModule.TRANSFERS_FILES
    # Value of TRANSFERS_FILES should be false
    assert test_ActionModule_TRANSFERS_FILES == False

    # get the static variable _VALID_ARGS from the class
    test_ActionModule__VALID_ARGS = ActionModule._VALID_ARGS
    # Value of _VALID_ARGS should be a frozenset
    assert isinstance(test_ActionModule__VALID_ARGS, frozenset)

# Generated at 2022-06-21 03:04:19.201116
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule()

# Generated at 2022-06-21 03:04:26.316176
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    class MyTaskQueueManager(TaskQueueManager):
        def _final_qd(self, result):
            return result.copy()
    task_queue_manager = MyTaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
    )

    class MyPlayContext(PlayContext):
        pass

    play_context = MyPlayContext()

    from ansible.task.task import Task
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoade

# Generated at 2022-06-21 03:04:36.489443
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins import action
    from ansible.module_utils.parsing.convert_bool import boolean
    tmp = None
    task_vars = None
    action = ActionModule(None, {})
    # assert that default values are initialized, True
    assert action.run(tmp, task_vars)['ansible_stats']['per_host'] == False
    assert action.run(tmp, task_vars)['ansible_stats']['aggregate'] == True
    assert action.run(tmp, task_vars)['ansible_stats']['data'] == {}
    # assert that default values are initialized, False
    action = ActionModule(None, {'aggregate': 'False'})
    assert action.run(tmp, task_vars)['ansible_stats']['per_host']

# Generated at 2022-06-21 03:04:45.200542
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    
    # test for successful run
    text = "{{ ansible_play_hosts | map('extract', hostvars, ['ansible_facts', 'localhost']) | sum(start=0) }}"
    m = ActionModule()
    m.run(task_vars={'ansible_facts': {'localhost': {'text': text}}}, tmp=None)
    assert m.run(task_vars={'ansible_facts': {'localhost': {'text': text}}}, tmp=None) == {'ansible_stats': {'per_host': False, 'data': {'text': text}, 'aggregate': True}, 'changed': False}

    # asserting the test for failed run

# Generated at 2022-06-21 03:04:54.808064
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule()

    data = {"some": "{{some_var}}", "other": "{{other_var}}"}
    action_args = {'data': data, 'per_host': True, 'aggregate': False}
    res = a.run(tmp=None, task_vars={"some_var": "foo", "other_var": "bar"})
    assert res == {"ansible_stats": {"data": {"some": "foo", "other": "bar"}, "per_host": True, "aggregate": False}, "changed": False}

    data = "{{some_var}}"
    action_args = {'data': data, 'per_host': True, 'aggregate': False}
    res = a.run(tmp=None, task_vars={"some_var": "foo"})
    assert res

# Generated at 2022-06-21 03:05:05.608788
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test code
    import mock

    # Module under test
    mod = ActionModule()

    # Fixture mocks
    task_mock = mock.MagicMock()
    task_mock.args = {
        'data': {
            'test': 'value'
        },
        'per_host': True,
        'aggregate': True
    }

    mod.run(task_vars = {})
    # Assertions
    assert mod.MSG_DATA_UNDEFINED == 'The data to store in Ansible stats.'
    assert mod.MSG_PER_HOST == "Retain specified data in per host ansible_facts"
    assert mod.MSG_AGGREGATE == "Retain specified data in aggregate stats for the play"
    assert mod.skeleton_action == 'store info'

    task

# Generated at 2022-06-21 03:05:06.512461
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: add test
    pass

# Generated at 2022-06-21 03:06:01.604365
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import tempfile

    a = ActionModule(task=dict(args=dict()), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=None)
    
    # Unit test for precondition 1: data must be a dictionary and must not be empty
    # Test case 1.1: data is not empty
    # data is a dictionary
    # data = a.run(tmp=None, task_vars=dict(var1='abc', var2='def'))
    # data = a.run(tmp=None, task_vars=dict(var1='abc', var2=dict(1:2, 3:4)))
    # data = a.run(tmp=None, task_vars=dict(var1=['abc', 'def'], var2=dict(1:2,

# Generated at 2022-06-21 03:06:12.341047
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tm = TaskModule()
    tm.load_data = {}
    tm.args = {'data': {}}

    tm._task.args = {'data': {'testvar1':5, 'testvar2':True, 'testvar3':'foo'}}
    result = tm.run(None, None)
    assert result['ansible_stats']['data']['testvar1'] == 5
    assert result['ansible_stats']['data']['testvar2'] is True
    assert result['ansible_stats']['data']['testvar3'] == 'foo'
    assert result['ansible_stats']['per_host'] == False
    assert result['ansible_stats']['aggregate'] == True


# Generated at 2022-06-21 03:06:15.160654
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("In test method")
    action_module = ActionModule()
    assert(type(action_module) == ActionModule)
    assert(dir(action_module) == dir())

test_ActionModule()

# Generated at 2022-06-21 03:06:18.257866
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_module = ActionModule()

    assert set_module._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))
    assert set_module.TRANSFERS_FILES == False

# Generated at 2022-06-21 03:06:21.516047
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am is not None

# Generated at 2022-06-21 03:06:24.428107
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.set_stats
    action_module = ansible.plugins.action.set_stats.ActionModule(None, {}, {})
    assert type(action_module) == ActionModule

# Generated at 2022-06-21 03:06:26.616944
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module is not None

# Generated at 2022-06-21 03:06:36.253939
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.vars import combine_vars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    def _get_vars(vars_list=None):
        if vars_list is None:
            vars_list = [{}]
        return combine_vars(HostVars(vars_list), VariableManager())

    # Test that specified options are followed.
    # Default options are per_host: False, aggregate: True
    module = ActionModule(task=dict(args=dict()), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert not module._task.args
   

# Generated at 2022-06-21 03:06:37.159231
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()


# Generated at 2022-06-21 03:06:44.487890
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    from ansible.utils.vars import merge_hash
    from ansible.plugins.action.set_stats import ActionModule
    from ansible.playbook.task import Task

    task_vars = dict()

    class TestActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            return super(TestActionModule, self).run(tmp, merge_hash(task_vars, self._task_vars))

    test_action_module = TestActionModule(
        Task(),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)

    test_action_module._task_vars = task_vars


# Generated at 2022-06-21 03:08:50.779138
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import sys
    import io
    import unittest
    import tempfile
    import json
    import os

    # Disable output
    sys.stdout = io.BytesIO()

    tmp_file = tempfile.NamedTemporaryFile()

    # Create new instance of class ActionModule:
    act_mod = ActionModule()

    # Create valid task object:
    task = object()
    task.action = {}
    task.action['__name__'] = 'set_stats'
    task.action['__line__'] = 0
    task.args = {}
    task.args['data'] = {'succeeded': 1}
    task.args['aggregate'] = True
    task.args['per_host'] = False
    act_mod.set_task(task)

    # Set valid task_vars:
   

# Generated at 2022-06-21 03:08:54.969396
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert am.TRANSFERS_FILES is False
    assert am._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-21 03:09:02.677866
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # test setting all three options
    task_copy = copy.deepcopy(task_vars)
    task_args = { 'data' : {'test_var': 'test string', 'test_int': 42}, 'aggregate': False, 'per_host': False }
    task_copy.update({'args': task_args})
    res = set_stats.run(tmp, task_copy)
    assert (res['ansible_stats']['data']['test_var'] == 'test string')
    assert (res['ansible_stats']['data']['test_int'] == 42)
    assert (res['ansible_stats']['aggregate'] == False)
    assert (res['ansible_stats']['per_host'] == False)

    # test setting two options

# Generated at 2022-06-21 03:09:03.265461
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert action_module == ActionModule

# Generated at 2022-06-21 03:09:04.656160
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(module_name='test', connection='test'), task_vars=dict(test='test'))

# Generated at 2022-06-21 03:09:05.195333
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  pass

# Generated at 2022-06-21 03:09:10.482444
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Testing action module run method
    """
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from utils import get_ansible_module_mock, get_ansible_playbook_mock
    # get the instance
    module_helper = get_ansible_module_mock()
    playbook_helper = get_ansible_playbook_mock()

    # get the ActionModule instance
    set_stats = ActionModule(task=module_helper, connection=playbook_helper)
    # declare needed variables
    result = dict()
    tmp = dict()
    task_vars = dict()

    # test with a simple task

# Generated at 2022-06-21 03:09:19.785572
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # generate obj instance of class ActionModule
    action_module_obj = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # execute method run
    arguments = {'task_vars' : None, 'tmp' : None}
    argument_spec = {'args' : {'default': {}, 'type': 'dict'}}
    task_params = {'args': None}
    results = action_module_obj.run(**arguments)
    assert results == {}

    task_params = {'args': {}}
    result = action_module_obj.run(**arguments)

# Generated at 2022-06-21 03:09:22.549631
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    This test shows how to construct a ActionModule
    """
    am = ActionModule('ActionModule', './data/set_stats.py', './data/set_stats.py')
    assert am is not None


# Generated at 2022-06-21 03:09:31.027979
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ##########################
    # Mock up the task object
    ##########################
    from ansible.task.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsV2

    class MockTemplar:
        @staticmethod
        def template(data, convert_bare=True, fail_on_undefined=True):
            if isidentifier(data) or data in ['True', 'False']:
                return data
            else:
                raise AttributeError

    # Initialize the class