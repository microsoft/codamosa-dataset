

# Generated at 2022-06-21 03:00:38.356126
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import constants as C
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.vault import VaultLib
    from ansible.vars import VariableManager
    from ansible.plugins.loader import fragment_loader

    test_task = dict(
        name = 'task1',
    )

    test_module_args = dict(
        data = dict(
            foo = '{{ some_key }}',
            bar = 'some value',
            baz = 'boo',
            sensitive_material = '{{ my_password }}',
        ),
        per_host = '{{ to_bool(per_host|default(false)) }}',
        aggregate = '{{ to_bool(aggregate|default(true)) }}',
    )


# Generated at 2022-06-21 03:00:39.214521
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 03:00:42.686065
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule()
    assert isinstance(obj, ActionModule)
    print('ActionModule Initialized')

'''
test_ActionModule()
'''

# Generated at 2022-06-21 03:00:47.358756
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule(None, None, None)
    assert 'action_plugins.' in obj.__module__
    assert "modules.async_wrapper" == obj._shared_loader_obj.name

# Generated at 2022-06-21 03:00:54.622804
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_task = type('task', (object,), {})
    mock_task.args = {}
    mock_task.args['data'] = {'a': 1, 'b': 'hello world'}

    tmp = "/tmp/ansible_test"

    test_action = ActionModule(mock_task, tmp)
    result = test_action.run(tmp, {})
    assert result['ansible_stats'] == {'data': {'a': 1, 'b': 'hello world'}, 'per_host': False, 'aggregate': True}

# Generated at 2022-06-21 03:00:56.711927
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module is not None

# Generated at 2022-06-21 03:01:06.205774
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Instantiate with all the default values (stubbing out the _execute_module method)
    results = ActionModule().run(None, None)
    assert results['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True}

    # Instantiate with a different value for data and per_host
    results = ActionModule().run(None, None, {'data': {'test': 1}, 'per_host': True})
    assert results['ansible_stats'] == {'data': {'test': 1}, 'per_host': True, 'aggregate': True}

    # Instantiate with a different value for data and aggregate
    results = ActionModule().run(None, None, {'data': {'test': 1}, 'aggregate': False})

# Generated at 2022-06-21 03:01:09.354228
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-21 03:01:16.426553
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule()

    # Test invalid data input
    task_data = {'args': {'data': ['test', 'test2'], 'aggregate': True}}
    tmp, task_vars = None, None
    res = m.run(tmp, task_vars, task_data)
    assert res['failed']
    assert 'The \'data\' option needs to be a dictionary/hash' == res['msg']

    # test invalid per_host input
    task_data = {'args': {'data': {}, 'per_host': 'yes'}}
    res = m.run(tmp, task_vars, task_data)
    assert res['ansible_stats']['per_host']

    # test invalid aggregate input

# Generated at 2022-06-21 03:01:20.170328
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not ActionModule(
        {'action': {
            'args': {
                'aggregate': False,
                'data': {'foo': 'bar'},
                'per_host': True,
            },
        }},
    )._task.args['data']['foo'] == 'bar'

# Generated at 2022-06-21 03:01:35.728475
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.set_stats
    from collections import namedtuple

    class FakeTask(object):
        def __init__(self, data):
            self.args = {'data': data}

    class FakePlayContext(object):
        def __init__(self, connection):
            self.connection = connection

    class FakeConnection(object):
        def __init__(self, host):
            self.host = host

    # If tmp is not None and task_vars is None -> raise exception
    action_module = ansible.plugins.action.set_stats.ActionModule(None, None, None, None)
    action_module._task = FakeTask({'x': 1})
    with raises(Exception):
        action_module.run(tmp='/tmp', task_vars=None)

    # If tmp is

# Generated at 2022-06-21 03:01:37.123966
# Unit test for constructor of class ActionModule
def test_ActionModule():
    c = ActionModule()
    assert c is not None

# Generated at 2022-06-21 03:01:39.169372
# Unit test for constructor of class ActionModule
def test_ActionModule():

    my_test = ActionModule()

    assert my_test == {}

# Generated at 2022-06-21 03:01:43.629096
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: sandbox + mocker
    from ansible.module_utils.parsing.convert_bool import boolean

    # TODO: need to mock modules.utils
    # TODO: need to mock task_vars for Templar
    # TODO: need to mock self.load_vars_files
    # TODO: need to mock self.task_vars
    # TODO: need to mock self._task.args possible args permutations
    # TODO: need to mock self._templar
    # TODO: need to mock TemplateError and do not forget it has an attribute message
    # TODO: need to mock meta, possibly the whole mapper
    pass

# Generated at 2022-06-21 03:01:50.530092
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(action=dict(module_name='set_stats', module_args=dict())),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module is not None

# Generated at 2022-06-21 03:01:56.803713
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def redirect_stdin(string):
        old_stdin = sys.stdin
        sys.stdin = StringIO(to_bytes(string, errors='surrogate_or_strict', encoding='utf-8'))
        try:
            yield
        finally:
            sys.stdin = old_stdin


# Generated at 2022-06-21 03:01:59.339606
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  set_stats = ActionModule({},{})
  assert set_stats.run() == {'changed': False, 'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}}
  assert set_stats.run(task_vars={"foo":"bar"}) == {'changed': False, 'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}}

# Generated at 2022-06-21 03:02:07.978165
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Patch some modules to avoid calling external modules
    import __builtin__
    import sys
    del sys.modules['ansible.plugins.action.set_stats']  # avoid circular import
    del sys.modules['ansible.plugins.action.vars']  # avoid circular import
    from ansible.plugins.action import vars
    from ansible.plugins.action import set_stats
    from ansible.module_utils.six import integer_types
    from types import ModuleType
    from ansible.module_utils.vars import isidentifier
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars


# Generated at 2022-06-21 03:02:08.577462
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-21 03:02:11.370592
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print ("Testing ActionModule constructor")
    action_module = ActionModule()
    assert action_module.TRANSFERS_FILES == False

# Generated at 2022-06-21 03:02:27.049747
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor test
    module = ActionModule(
        task=dict(action=dict(module='set_stats', args=dict(data=dict(a=1, b=1),
                                                            per_host=False,
                                                            aggregate=True))),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=None)
    assert module

# Generated at 2022-06-21 03:02:29.120307
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-21 03:02:39.550070
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    import sys
    import tempfile
    import yaml
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_text
    from ansible.parsing.vault import VaultLib

    class AnsibleModuleDummy(object):
        _tmp = None

        def __init__(self, *args, **kwargs):
            self.tmpdir = tempfile.gettempdir()
            self.ipsec_conf_path = None
            self.log = basic.AnsibleModuleLog()
            self.params = {}
            self.args = {}

        def get_bin_path(self, arg, required=False, opt_dirs=[]):
            return '/bin/' + arg


# Generated at 2022-06-21 03:02:44.536613
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json

    am = ActionModule()
    assert isinstance(am._VALID_ARGS, frozenset)
    assert not am._task
    assert not am._connection
    assert not am._play_context
    assert not am._loader
    assert not am._templar
    assert not am._shared_loader_obj

    # TODO: test run()

# Generated at 2022-06-21 03:02:55.227595
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task

    t = Task()
    t.args = {}
    t._task.args = {}
    t._task.args["data"] = {'blah': 'who'}
    t._task.args["aggregate"] = False
    t._task.args["per_host"] = False

    am = ActionModule(task=t, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert 'ansible_stats' in am.run()
    assert 'data' in am.run()['ansible_stats']
    assert 'aggregate' in am.run()['ansible_stats']
    assert 'per_host' in am.run()['ansible_stats']
    assert 'changed' in am.run()


# Generated at 2022-06-21 03:02:55.793274
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:03:08.052502
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import sys
    import io
    import ansible.utils.vars
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.role
    import ansible.playbook.block
    from ansible.template import Templar
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager

    mock_task = ansible.playbook.task.Task()
    mock_task._role = ansible.playbook.role.Role()
    mock_task._block = ansible.playbook.block.Block()
    mock

# Generated at 2022-06-21 03:03:12.247460
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = dict(args=dict(data=dict(foo=10, bar='20'), per_host=True, aggregate=True))
    task_vars = dict()
    tmp = None
    am = ActionModule(task, tmp, task_vars)
    print(am.run())

# Generated at 2022-06-21 03:03:13.944745
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Not a lot of testing value due to lack of mocking
    pass

# Generated at 2022-06-21 03:03:15.380504
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am.run is not None

# Generated at 2022-06-21 03:03:42.271830
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    fake_task = {'args':{'aggregate': False, 'data':{'name':'ansible', 'version':'1.9.4'}, 'per_host': True}}
    from ansible.executor.task_result import TaskResult
    a = ActionModule(task=fake_task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    task_res = TaskResult(host=None, task=None, task_fields=None, task_vars=None, play_context=None, new_facts=None, always_run=False, verbosity=None, connection=None)
    res = a.run(tmp=None, task_vars=None)

    assert res['ansible_stats']['aggregate'] == False

# Generated at 2022-06-21 03:03:52.398152
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test various option types
    tmplar = MockTemplar()
    task = MockTask({'data': {'str': 'foobar', 'int': '7', 'bool': 'yes'}, 'per_host': 'yes', 'aggregate': 'no'})
    amod = ActionModule(task, tmplar)
    result = amod.run()

    assert result['ansible_stats']['data']['str'] == 'foobar'
    assert result['ansible_stats']['data']['int'] == 7
    assert result['ansible_stats']['data']['bool'] == True
    assert result['ansible_stats']['per_host'] == True
    assert result['ansible_stats']['aggregate'] == False

    # Test variable names
    task = MockTask

# Generated at 2022-06-21 03:04:01.966469
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(load_fixture('set_stats_args.json'), None)
    result = module.run({'ansible_stats': {'per_host': True}}, {})
    assert result['ansible_stats'] == {'per_host': True, 'data': {'ip': '10.10.10.1', 'os': 'centos'}, 'aggregate': True}
    result = module.run({'ansible_stats': {'per_host': True, 'data': {'ip': '10.10.10.1', 'os': 'centos'}}}, {})
    assert result['ansible_stats'] == {'per_host': True, 'data': {'ip': '10.10.10.1', 'os': 'centos'}, 'aggregate': True}

# Generated at 2022-06-21 03:04:06.590278
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task

    mock_task = Task()
    mock_task.action = 'set_stats'
    mock_task.args = {'data': {'a': 'b'}}

    x = ActionModule(mock_task, None)
    assert x.run()['ansible_stats'] == {'data': {'a': 'b'}, 'per_host': False, 'aggregate': True}
    assert x.run()['ansible_stats']['data']['a'] == 'b'

# Generated at 2022-06-21 03:04:16.873204
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''
    # Load test data
    data = load_fixture('test_ActionModule_run.json')

    # Create a mock module object
    mock_module = MagicMock()
    mock_module.run.return_value = data

    # Create a mock task object
    mock_task = MagicMock()
    mock_task._task.args = {'aggregate': False, 'data': 'testdata'}

    # Create tmp and task_vars
    tmp = None
    task_vars = None

    # Create a action module object
    action_mod = ActionModule(mock_task, tmp)

    import pdb
    pdb.set_trace()

    # Run method run of class ActionModule

# Generated at 2022-06-21 03:04:25.351779
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test case 1
    args_dict = {'data': {}}
    args_dict['data']['test_key'] = 'test_value'
    args_dict['data']['_test_key'] = 'test_value'
    args_dict['data']['test-key'] = 'test_value'
    t_args = dict(
        module_args=args_dict,
    )
    action_module = ActionModule(task=dict(args=t_args))
    # set attributes of action_module has a temp variable
    tmp = {'failed': False}
    action_module.tmp = tmp
    # call run() method of ActionModule class
    result = action_module.run(task_vars={})
    # test data
    assert result['changed'] == False

# Generated at 2022-06-21 03:04:35.745913
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test - Pass the data option as a string
    my_task = dict(
        action=dict(
            module='set_stats',
            data='package_state:{{ package_state }}'
        ),
        args=dict(
            data='package_state:{{ package_state }}',
            per_host=True,
            aggregate=True
        )
    )

    my_result = dict(
        ansible_facts=dict(
            package_state='present'
        ),
        ansible_facts_cache=dict(),
        changed=False
    )

    my_task_vars = dict(
        package_state='present'
    )

    m = ActionModule()
    res = m.run(tmp=None, task_vars=my_task_vars, task=my_task)

    assert res

# Generated at 2022-06-21 03:04:41.125144
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule({})
    res = module._execute_module({'data': 'test_data'})
    assert res['ansible_stats']['data']['ansible_test_data'] == 'test_data'
    res = module._execute_module({'data': 'test_data1'})
    assert res['ansible_stats']['data']['ansible_test_data1'] == 'test_data1'

# Generated at 2022-06-21 03:04:43.002527
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(ActionModule._VALID_ARGS.issubset(set(('aggregate', 'data', 'per_host'))))

# Generated at 2022-06-21 03:04:49.542642
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.constants as C

    def _make_mock_task(task_vars = {}):
        mock_task = MagicMock()
        mock_task.args = {}
        mock_task._role = None
        mock_task.loop = None
        # mock_task.block is accessed during execution of a task, so setting it to None
        # causes some tests to fail.

# Generated at 2022-06-21 03:05:45.525854
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.loader import connection_loader, action_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.display import Display
    import json

    connection_loader.remove_all()
    action_loader.remove_all()
    action_loader.add('set_stats', ActionModule)


# Generated at 2022-06-21 03:05:49.207326
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(load_fixture('test_ActionModule_class.yml'),
                          load_fixture('test_ActionModule_class.yml'))
    results = module.run()
    assert results is not None

# Generated at 2022-06-21 03:05:53.533176
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None, None, None, {})
    assert action_module is not None, "ActionModule is not initialized"
    assert isinstance(action_module, ActionModule), "ActionModule is not of type ActionBase"

# Generated at 2022-06-21 03:05:57.961528
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # initialize class
    am = ActionModule(None, {})
    tmp = None
    task_vars = {}
    # initialize instance of class
    result = am.run(tmp, task_vars)
    assert result['changed'] == False
    assert result['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True}


# Generated at 2022-06-21 03:05:59.591912
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Call constructor of class ActionModule
    actionModule = ActionModule()
    assert(actionModule is not None)

# Generated at 2022-06-21 03:06:06.255140
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # with no args
    res = am.run()
    assert res['changed'] == False
    assert res['ansible_stats'] == {'data': {}, 'aggregate': True, 'per_host': False}

    # with per_host only
    res = am.run(task_vars={}, tmp='', inject={'ansible_stats': {'per_host': True}})
    assert res['changed'] == False
    assert res['ansible_stats'] == {'data': {}, 'aggregate': True, 'per_host': True}

# Generated at 2022-06-21 03:06:06.836069
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:06:11.235667
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(dict(), dict())

    stats = {'data': {}, 'per_host': False, 'aggregate': True}

    result = action.run(None, None)

    if result['ansible_stats'] != stats:
        raise AssertionError()


# Generated at 2022-06-21 03:06:17.143559
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = AnsibleModule(
        argument_spec=dict(
            aggregate=dict(type='bool', default='True'),
            data=dict(type='dict', required=True),
            per_host=dict(type='bool', default='True'),
        ),
        supports_check_mode=True
    )
    m_run = module.params['run'] = MagicMock()
    ac = ActionModule(m_run, module.params)
    res = ac.run(tmp='/tmp', task_vars=dict(a=1, b=2))
    assert res['changed'] is False
    assert res['ansible_stats']['data']['a'] == 1
    assert res['ansible_stats']['data']['b'] == 2

# Generated at 2022-06-21 03:06:27.167447
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.constants as C
    from ansible.parsing.dataloader import DataLoader

    mock_loader = DataLoader()
    mock_inventory = None
    mock_variable_manager = None

    fake_task = "set_stats"
    fake_action_plugin = "set_stats"
    fake_play = dict(name="play.")
    fake_play_context = dict(name="play_context", network_os="dummy_os")
    fake_task_vars = dict(key="value")


# Generated at 2022-06-21 03:08:27.940271
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = dict()
    task_vars = dict()

    #  test_ActionModule_run.get_action_plugin_result
    test = ActionModule(task=dict(), connection=dict(), play_context=dict())
    result = test.run(tmp=tmp, task_vars=task_vars)

    assert result['changed'] == False
    assert result['ansible_stats']['aggregate'] == True
    assert result['ansible_stats']['per_host'] == False
    assert result['ansible_stats']['data'] == dict()
    assert result['failed'] == False
    assert result['msg'] == ''

    #  test_ActionModule_run.get_action_plugin_result_data

# Generated at 2022-06-21 03:08:28.759616
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Hooray!')

# Generated at 2022-06-21 03:08:29.394350
# Unit test for constructor of class ActionModule
def test_ActionModule():
	a = ActionModule()


# Generated at 2022-06-21 03:08:32.109903
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None, None)
    assert isinstance(action_module, ActionModule)
    assert isinstance(action_module._VALID_ARGS, frozenset)


# Generated at 2022-06-21 03:08:32.957863
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # TODO: implement test
    pass

# Generated at 2022-06-21 03:08:34.116463
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.run is not None

# Generated at 2022-06-21 03:08:43.786532
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inv)
    action = ActionModule(
        {'name': 'test', 'args': {'data': {'baz': "{{ test }}"}}},
        variable_manager=variable_manager,
        loader=loader
    )

    variable_manager.set_host_variable('test', 'bar')
    result = action.run(None, variables={'test': to_bytes('foo')})

# Generated at 2022-06-21 03:08:52.506047
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    
    # Create action instance
    action_module = ActionModule(
        {},
        {'play': {'hosts': ['localhost'], 'name': 'test_ActionModule_run'}},
        {'ansible_connection': 'local'},
        30000,
        '/usr/lib/python2.7/dist-packages/ansible/plugins/action/set_stats.py',
        'set_stats',
        'localhost'
    )

    # Test for method run valid data
    data = {}
    data['test_ActionModule_run'] = 'test_ActionModule_run'
    result = {
        'failed': False,
        'changed': False,
        'ansible_stats': {}
    }
    result['ansible_stats']['data'] = {}

# Generated at 2022-06-21 03:09:01.216272
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create mocks
    import mock

    tmp = mock.MagicMock()
    task_vars = {'ansible_stats': {}}
    task = mock.MagicMock(args={})
    module_utils = mock.MagicMock()

    # Set up Mock objects
    type(task).args = task.args
    type(module_utils).WARNING_DEPRECATED = module_utils.WARNING_DEPRECATED
    module_utils.WARNING_DEPRECATED = mock.MagicMock()

    with mock.patch('ansible.module_utils.parsing.convert_bool.boolean') as boolean:
        boolean.return_value = True

        from ansible.plugins.action.set_stats import ActionModule
        am = ActionModule(task, tmp, task_vars, module_utils)

        # Test function


# Generated at 2022-06-21 03:09:07.536979
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test1
    tmp = None
    task_vars = dict()

    result = ActionModule.run(tmp, task_vars)
    #assert result
    assert result['changed'] == False
    assert result['ansible_stats']['data'] == {}
    assert result['ansible_stats']['per_host'] == False
    assert result['ansible_stats']['aggregate'] == True

    # test2
    tmp = None
    task_vars = dict()
    ActionModule._task.args = {'data': {'k1': 'v1'}, 'per_host': False, 'aggregate': True}

    result = ActionModule.run(tmp, task_vars)
    assert result['changed'] == False