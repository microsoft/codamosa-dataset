

# Generated at 2022-06-21 03:00:28.912076
# Unit test for constructor of class ActionModule
def test_ActionModule():
    AM = ActionModule(None, {}, False, None, None, None, None)
    assert AM.action == 'set_stats'

# Generated at 2022-06-21 03:00:30.306055
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()


# Generated at 2022-06-21 03:00:40.260632
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup TaskExecutor
    from ansible.task_executor.task_executor import TaskExecutor
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar

    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.unsafe_proxy import wrap_var
    import json

    class TaskExecutorMock(TaskExecutor):
        def __init__(self, host, task, play_context, shared_loader_obj, variable_manager):
            self._host = host
            self._task = task
            self._play_context = play_context
            self._shared

# Generated at 2022-06-21 03:00:40.790019
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 03:00:42.443955
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule('test_data')
    assert am.TRANSFERS_FILES == False

# Generated at 2022-06-21 03:00:43.409693
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Unit test for method run of class ActionModule
    # Returns True

    # Set up mock objects
    ansible_module = ActionModule()
    ansible_module.run()
    assert True

# Generated at 2022-06-21 03:00:55.017315
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins import action
    import ansible.plugins.action.set_stats
    import ansible.module_utils.parsing.convert_bool
    import sys
    import pytest

    action_module = ansible.plugins.action.set_stats.ActionModule()

    action_module._connection = MagicMock()
    action_module._task = MagicMock()
    action_module._task_vars = MagicMock()
    action_module._low_level_execute_command = MagicMock()
    action_module._display = MagicMock()
    action_module._templar = MagicMock()
    action_module._loader = MagicMock()

    # Valid result

# Generated at 2022-06-21 03:01:05.550578
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create test object, the super class will run the constructor
    # and the constructor will call the run method
    am = ActionModule()

    # variables to pass to the run method
    tmp = None
    task_vars = dict()

    # run the method under test to set the variables
    task_result = am.run(tmp, task_vars)

    # print the variable to see what the run method did
    # print("task_result %s" % task_result)
    # print("task_result data %s" % task_result['ansible_stats']['data'])
    assert task_result['ansible_stats']['data'] == {}
    assert task_result['ansible_stats']['per_host'] == False
    assert task_result['ansible_stats']['aggregate'] == True



# Generated at 2022-06-21 03:01:11.140322
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not issubclass(ActionModule, object)
    assert issubclass(ActionModule, ActionBase)
    assert ActionModule._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))
    assert not ActionModule.TRANSFERS_FILES

# Generated at 2022-06-21 03:01:15.228781
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test = ActionModule()
    stats = {'data': {'contacts': ['me@localhost']}, 'per_host': True, 'aggregate': True}
    assert test.run(task_vars={'ansible_stats': stats})['ansible_stats'] == stats

# Generated at 2022-06-21 03:01:27.965986
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #
    # Mock the run function of action base class, since we only
    #   want to test the run function of this class, ActionModule
    #
    actionBaseRun = ActionBase.run
    def run(self, tmp=None, task_vars=None):
        pass
    ActionBase.run = run

    #
    # Mock the _execute_module function of the action base class
    #
    actionBaseExecMod = ActionBase._execute_module
    def exeMod(self, connection=None, module_name=None, module_args=None, tmp=None, task_vars=None):
        pass
    ActionBase._execute_module = exeMod
    
    nonNamedArguments = {'data': {'name': 'ansible'}, 'per_host': False, 'aggregate': False}
    named

# Generated at 2022-06-21 03:01:31.428371
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))
    assert ActionModule.TRANSFERS_FILES == False

# Generated at 2022-06-21 03:01:33.190161
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionModule)

# Generated at 2022-06-21 03:01:44.881305
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Create instance with first required parameter
    task = dict()
    task['action'] = dict()
    task['action']['__ansible_module__'] = "set_stats"
    task['action']['__ansible_arguments__'] = {"data": {'z': 12}, "per_host": True}
    task['action']['module_name'] = "set_stats"
    task['action']['args'] = {"data": {'z': 12}, "per_host": True}

    # Create instance of an object of type ActionModule
    act = ActionModule(task, dict())

    # Check if attribute tmp is an empty string
    assert type(act.tmp) == str
    assert act.tmp == ""

    # Check if attribute tmp is of type string
    assert type(act._task) == dict
   

# Generated at 2022-06-21 03:01:55.107836
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a class object of type ActionModule
    am = ActionModule()

    # Create a class object of type TaskExecutor
    te = TaskExecutor()

    # Create a class object of type Task
    t = Task()
    t.args = {'per_host': 'True', 'aggregate': 'False'}

    # Assign valid values to the variables of class TaskExecutor
    te._task = t
    te._task_vars = {}
    te._shared_loader_obj = None
    te._loader = None
    te._templar = None
    te._connection = None

    # Assign valid values to the variables of class ActionModule
    am._task = t
    am._connection = None
    am._play_context = None
    am._loader = None
    am._templar = None
    am._

# Generated at 2022-06-21 03:01:59.664432
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils import basic
    from ansible.module_utils.six import string_types
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    action_module = ActionModule(task=Play().load(dict(name='test', hosts='all', gather_facts='yes', tasks=[dict(action='set_stats', args=dict(data=dict(n_users='{{ ansible_user_id|length }}')))])))


# Generated at 2022-06-21 03:02:01.731988
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None)
    assert type(action) == ActionModule

# Generated at 2022-06-21 03:02:12.157762
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = dict(
        action=dict(
            module='set_stats',
            args=dict(
                aggregate=True,
                data=dict(
                    test_var="{{ test_value }}",
                ),
                per_host=False,
            ),
        ),
        _ansible_no_log=False,

    )
    task_vars = dict(
        test_value='test value',
    )

    results = ActionModule(task, task_vars).run(None, task_vars)

    assert results['changed'] == False
    assert results['ansible_stats']['aggregate'] == True
    assert results['ansible_stats']['per_host'] == False
    assert isinstance(results['ansible_stats']['data'], dict)

# Generated at 2022-06-21 03:02:19.358754
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import mock
    sys.modules['_ansible_remote_tmp'] = mock.Mock(
        MOVE_REMOTE_TMP=False,
        WIN_DEFAULT_TMP=False
    )

    def mock_template(text):
        return text

    class mock_templar:
        template = mock_template


    mock_task = mock.MagicMock()
    mock_task.args = {'data':{'my_var':'my_value'}}

    mock_self = mock.MagicMock()
    mock_self._task = mock_task
    mock_self._templar = mock_templar

    res = ActionModule.run(mock_self)
    assert not res['failed']

# Generated at 2022-06-21 03:02:27.201133
# Unit test for constructor of class ActionModule
def test_ActionModule():

    from ansible.plugins.action.set_stats import ActionModule

    action = ActionModule(task=dict(args={'a': 1, 'b': 'some'}), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert action.task == dict(args={'a': 1, 'b': 'some'})
    assert action.connection == None
    assert action.play_context == None
    assert action.loader == None
    assert action.templar == None
    assert action.shared_loader_obj == None

# Generated at 2022-06-21 03:02:46.955181
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test method run of class ActionModule

    Args:
      None

    Returns:
      Return code of the test

    """

    # For unit testing purposes, allow any name instead of a hardcoded one
    import __main__
    __main__.HAS_PYVMOMI = True

    # For unit testing purposes, allow any name instead of a hardcoded one
    import __main__
    __main__.HAS_PYVMOMI = True

    from ansible.playbook.task import Task
    from ansible.template import Templar

    class TaskTest:
        def __init__(self):
            self.args = {}

    class PlayContextTest:
        def __init__(self):
            self.connection = 'local'


# Generated at 2022-06-21 03:02:56.921171
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task_include import TaskInclude
    a = ActionModule(TaskInclude(task={"name": "test", "action": {"__ansible_module__": "setup"}, "args": {}}, block=None),
                     connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 03:03:00.017258
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement a unit test for the method run of class ActionModule
    assert True

# Generated at 2022-06-21 03:03:05.189400
# Unit test for constructor of class ActionModule
def test_ActionModule():
    
    # Raise exception when mandatory option is not used
    def test_1():
        try:
            action = ActionModule()
        except Exception as e:
            print("Exception in test_1: %s" % str(e))
            raise

    # TODO: Provide test cases for all methods of the class.

# Execute the constructors of the class ActionModule

# Generated at 2022-06-21 03:03:12.739802
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m_data = {
        'ansible_stats': {
            'data': {
                'var1': 'val1',
                'var2': 'val2',
                'var3': 'val3'
            },
            'per_host': True,
            'aggregate': False
        },
        'changed': False
    }
    am = ActionModule()
    # TODO: get rid of "_templar" variable
    am._templar = am._shared_loader_obj.templar
    m_args = {
        'data': {
            'var1': 'val1',
            'var2': 'val2',
            'var3': 'val3'
        },
        'per_host': True,
        'aggregate': False
    }

# Generated at 2022-06-21 03:03:21.327889
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    t = ActionModule('/dne')
    t.task_vars = {'foo': 'bar'}
    t.tmp = '/tmp'
    t.task_vars = {'ansible_verbose_always': True}
    t.task_vars = {'ansible_connection': 'ssh'}
    t.task_vars = {'ansible_ssh_host': 'host.example.com'}
    t.task_vars = {'ansible_ssh_user': 'root'}
    t._task.args = {}
    t.task_vars = {'ansible_check_mode': False}

# Generated at 2022-06-21 03:03:23.491686
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Constructor test for class ActionModule")
    set_stats_action = ActionModule(None, dict(), False, None)
    assert set_stats_action is not None

# Generated at 2022-06-21 03:03:34.170354
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.template import Templar
    from ansible.utils import context_objects
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    import sys

    # Create test variables
    templar = Templar({}, None, None)
    context = context_objects.Context()
    loader = None
    variable_manager = VariableManager()
    variable_manager.set_host_variable("testhost", HostVars(dict(name='testhost'), variable_manager))

    # Create test action

# Generated at 2022-06-21 03:03:34.730280
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 03:03:35.262849
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()

# Generated at 2022-06-21 03:03:56.329209
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Result of unit test for method run of class ActionModule'''
    pass

# Generated at 2022-06-21 03:03:57.544049
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module is not None


# Generated at 2022-06-21 03:03:58.078311
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-21 03:04:05.847938
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule  # pylint: disable=no-name-in-module,import-error

    # Get a instance of ActionModule class
    instance = ActionModule(None, None, None, None, '')

    # Set up a dict of data to be processed
    data = dict()
    data['per_host'] = True
    data['aggregate'] = False
    data['data'] = dict()

    # Create main dictionnary of data to be passed to ActionModule class
    # Arguments should be validated in ActionModule class.
    main_data = dict(data = data)

    # Try to run the Module
    result = instance.run(None, main_data)

    # Assert to know that the ActionModule class has processed the data
    assert result['ansible_stats'] == True  # TODO

# Generated at 2022-06-21 03:04:14.926967
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Note: ansible/test/unit/modules/test_set_stats.py already tests action module set_stats

    underlying_task = Mock()
    underlying_task.args = {'data': {'a': 'b', 'c': 'd'}, 'per_host': 'true'}
    underlying_task.vars = {} # this one is for template

    action_module = ActionModule(underlying_task, Mock())
    result = action_module.run(tmp=None, task_vars=None)
    assert result['failed'] == False
    assert result['ansible_stats'] == {'data': {'a': 'b', 'c': 'd'}, 'per_host': True, 'aggregate': True}



# Generated at 2022-06-21 03:04:22.360828
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = AnsibleModule(
        argument_spec = dict(
            per_host=dict(type='bool', default=True),
            aggregate=dict(type='bool', default=False),
            data=dict(type='dict', default={})
        ),
        supports_check_mode=True
    )

    per_host = module.params['per_host']
    aggregate = module.params['aggregate']
    data = module.params['data']

    # TODO: implement tests here...
    assert True == True


# Generated at 2022-06-21 03:04:32.279427
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host_name = 'localhost'
    ports = [22]
    task_vars = dict(ansible_ssh_host=host_name, ansible_ssh_port=ports)

    tmp = ''
    task_path = ''
    play_context = dict(remote_addr=host_name, transport='ssh')
    new_stdin = ''

    am = ActionModule(play_context=play_context, loader=None, task=None,
                      shared_loader_obj=None, task_vars=task_vars,
                      tmp=tmp, new_stdin=new_stdin, task_path=task_path,
                      connection=dict(conn_params=dict(port=ports[0])))

    testdict={'foo':123}
    am.set_task_args(dict(data=testdict))

   

# Generated at 2022-06-21 03:04:32.820174
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-21 03:04:34.226960
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj = ActionModule()
    obj.run()

# Generated at 2022-06-21 03:04:43.276215
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.set_stats as actionplugin

    from ansible.playbook.task import Task

    from ansible.vars.manager import VariableManager

    from ansible.inventory.manager import InventoryManager

    from ansible.parsing.dataloader import DataLoader

    from ansible.errors import AnsibleParserError

    from ansible.module_utils.six import integer_types

    class MockTask(Task):
        def __init__(self, args={}):
            self.args = args

    vars_manager = VariableManager()
    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    inventory.subset('all')


# Generated at 2022-06-21 03:05:40.872917
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up the ActionModule instance to be tested
    task_data = dict(action='set_stats', args=dict(aggregate=True))
    task = DummyTask(task_data)
    action_mod = ActionModule(task, dict())

    # Test the run() method
    res = action_mod.run(None, dict(hostvars=dict()))
    assert not res['failed']
    assert not res['changed']
    assert res['ansible_stats'] == dict(aggregate=True, per_host=False, data={})

    task = DummyTask(dict(action='set_stats', args=dict(data=dict(foo=1))))
    action_mod = ActionModule(task, dict())
    res = action_mod.run(None, dict(hostvars=dict()))

# Generated at 2022-06-21 03:05:48.042350
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    setattr(ActionModule,'_execute_module',lambda self,tmp,module_name,module_args,task_vars: {'rc': 0, 'stdout': ''})

    am = ActionModule({'hostvars': {}}, {'hostvars': {}})
    assert am.run({'rc': 0, 'stdout': ''}) == {'ansible_stats': {'aggregate': True, 'data': {}, 'per_host': False}, 'changed': False}

    am = ActionModule({'hostvars': {'key': 'value'}, 'args': {'data': {'key': 'value'}, 'aggregate': 'no', 'per_host': 'yes'}},
                    {'hostvars': {}})

# Generated at 2022-06-21 03:05:58.565800
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.vars import combine_vars
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    import json

    task = Task.load(dict(action=dict(module='set_stats', args=dict(data=dict(test_key="test_value"), aggregate=True, per_host=False))))
    play_context = PlayContext()
    task_result = TaskResult(host=None, task=task, return_data=dict(counter=10))

    action_module = ActionModule(task, play_context, shared_loader_obj=None)
    action_module._templar = task.get_loader()


# Generated at 2022-06-21 03:06:05.710126
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''
    ActionModule._lookup_plugin_loader = None
    am = ActionModule()

    # Case 1
    data = {'data': {'a': 1, 'b': 2}, 'per_host': True, 'aggregate': True}
    task = FakeTask(args=data)
    am._task = task
    result = am.run(task_vars = None)
    assert result['ansible_stats']['data'] == {'a': 1, 'b': 2}, result['ansible_stats']['data']
    assert result['ansible_stats']['per_host'] == True, result['ansible_stats']['per_host']

# Generated at 2022-06-21 03:06:14.698691
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.set_stats as action
    a = action.ActionModule()

    # test if method run returns the correct result
    last_result = dict(changed=True, msg='changed')
    tmp = "tmp.md"
    task_vars = None
    _result = a.run(task_vars=task_vars, tmp=tmp)
    assert _result['ansible_stats'] == {'aggregate': True, 'per_host': False, 'data': {}}

    # test if method run returns the correct result
    last_result = dict(changed=True, msg='changed')
    tmp = "tmp.md"
    task_vars = None
    _result = a.run(task_vars=task_vars, tmp=tmp)
    assert _result['ansible_stats']

# Generated at 2022-06-21 03:06:24.789397
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    setattr(action_module, '_task', type('', (object,), {'args': {'data': {'a':'b'}}}))
    setattr(action_module, '_templar', type('', (object,), {'template': lambda self, arg, **kwargs: arg}))
    task_vars = {}
    result_expected = {
        'ansible_stats': {
            'per_host': False,
            'aggregate': True,
            'data': {
                'a': 'b'
            }
        },
        'changed': False
    }
    assert result_expected == action_module.run(task_vars=task_vars)

# Generated at 2022-06-21 03:06:25.627566
# Unit test for constructor of class ActionModule
def test_ActionModule():
    cls = ActionModule()


# Generated at 2022-06-21 03:06:28.506859
# Unit test for constructor of class ActionModule
def test_ActionModule():
  ansibleModuleObj = ActionModule()
  print("\nType of ansibleModuleObj:", type(ansibleModuleObj))

if __name__ == "__main__":
  test_ActionModule()

# Generated at 2022-06-21 03:06:37.824034
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class MockActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            raise NotImplementedError
    am = MockActionModule(None, None)

    class MockTask():
        class MockArgs():
            def __init__(self, data, per_host, aggregate):
                self.data = data
                self.per_host = per_host
                self.aggregate = aggregate

        def __init__(self, data, per_host, aggregate):
            self.args = self.MockArgs(data, per_host, aggregate)
            
    class MockTaskVars():
        pass

    # Test with all the correct values.
    task_vars = MockTaskVars()

# Generated at 2022-06-21 03:06:40.383046
# Unit test for constructor of class ActionModule
def test_ActionModule():
	class MockTask(object):
		def __init__(self):
			self.args = {}
	am = ActionModule(MockTask(), dict())
	assert am._task.args == {}

# Generated at 2022-06-21 03:08:51.198067
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test method with empty argument
    assert ActionModule.run(ActionModule(), None, None) == {'changed': False, 'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}}

    # test method with non-empty argument
    args = {'data': {'a': 1, 'b': 2}, 'per_host': 'true', 'aggregate': False}
    assert ActionModule.run(ActionModule(), None, None, args=args) == {'changed': False, 'ansible_stats': {'data': {'a': 1, 'b': 2}, 'per_host': True, 'aggregate': False}}

# Generated at 2022-06-21 03:08:53.605500
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    t_obj = ActionModule()

# Generated at 2022-06-21 03:08:54.768741
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(ActionModule)

# Generated at 2022-06-21 03:08:56.508359
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None)
    assert(isinstance(action, ActionModule))

# Generated at 2022-06-21 03:08:59.814730
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = ActionModule.run(ActionModule(),{},{'data': {'k': 'v'}})
    assert result['changed'] == False
    assert result['ansible_stats'] == {'data': {'k': 'v'}, 'per_host': False, 'aggregate': True}

# Generated at 2022-06-21 03:09:00.316924
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:09:08.067807
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    _root = logging.getLogger()
    for h in list(_root.handlers):
        _root.removeHandler(h)

    task_args = {'data': {'key1': 1, 'key2': '{{ var2 }}'}, 'per_host': 'yes', 'aggregate': False}
    task_vars = {'var2': 2}
    am = ActionModule(task=dict(args=task_args), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    ans_stats = am.run(task_vars=task_vars)
    expected =  {'data': {'key1': 1, 'key2': 2}, 'per_host': True, 'aggregate': False}

# Generated at 2022-06-21 03:09:17.219474
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_base = ActionBase()

    action_module = ActionModule(
        task=MockTask(),
        connection=MockConnection(),
        play_context=MockPlayContext(),
        loader=MockLoader(),
        templar=MockTemplar(),
        shared_loader_obj=None
    )

    # Test with a valid dictionary data
    result = action_module.run(
        tmp=None, task_vars={'one': 'two', 'two': 3}
    )

    assert result['changed'] == False
    assert result['ansible_stats']['data']['one'] == 'two'
    assert result['ansible_stats']['data']['two'] == 3

    assert result['ansible_stats']['per_host'] == False

# Generated at 2022-06-21 03:09:22.539071
# Unit test for constructor of class ActionModule
def test_ActionModule():
    b = '{"data":{"version":"1.1.0","common.version":"2.1.1"}}'
    ActionModule._task.args = {'data': {'version': '1.1.0', 'common.version': '2.1.1'}}
    a = ActionModule(ActionModule._task, ActionModule._connection, ActionModule._play_context, ActionModule._loader)
    a.run()
    assert ActionModule._task.args == b


# Generated at 2022-06-21 03:09:31.027525
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class TaskMock(object):
        def __init__(self, args={}):
            self.args = args
    class ModuleUtilsMock(object):
        def _load_params(self,):
            return {}
    class ConnectionMock(object):
        def __init__(self):
            self._shell = None
        def _connect(self):
            return {}
    class PlayContextMock(object):
        def __init__(self):
            self.remote_addr = '127.0.0.1'
            self.connection = 'local'
            self.network_os = 'linux'
            self.remote_user = 'ansible_user'
    class PlayMock(object):
        def __init__(self):
            self.hostvars = {'127.0.0.1': {}}