

# Generated at 2022-06-21 03:00:37.476020
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule()
    actionModule._templar = AnsibleTemplar()
    actionModule._task = AnsibleTask()

    # test with empty args
    actionModule._task.args = {}
    result = actionModule.run()['ansible_stats']
    assert result['aggregate'] == True
    assert result['per_host'] == False
    assert result['data'] == {}

    # test with non empty args
    actionModule._task.args = {
        'data': {
            'a': '{{ b }}',
            'c': '{{ d }}',
        },
        'per_host': '{{ per_host }}',
        'aggregate': '{{ aggregate }}',
    }

# Generated at 2022-06-21 03:00:45.842923
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Test if result of run() is correct"""

    # Testdata with minimal valid task arguments
    test_data = {
        "data": {"my_value": 123}
    }
    test_stats = {
        'data': {},
        'per_host': False,
        'aggregate': True
    }
    for key, value in test_data["data"].items():
        test_stats["data"][key] = value

    # Use a subclass of ActionModule to avoid failure of run() due to missing
    # attributes of _task object
    class TestActionModule(ActionModule):
        def __init__(self):
            self._task = "task"
            self._task_vars = "task_vars"
            self._loader = "loader"
            self._templar = "templar"


# Generated at 2022-06-21 03:00:55.087793
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Start test_ActionModule_run")
    test_ActionModule = ActionModule()

    # Test empty input
    test_dict = {}
    result = test_ActionModule.run(tmp=None, task_vars=test_dict)
    # TODO: assert something ...

    # Test with data option (legacy)
    test_dict = {"_ansible_verbosity": 3, "_ansible_no_log": False, "changed": False, "failed": False, "invocation": {"module_args": {}}}
    result = test_ActionModule.run(tmp=None, task_vars=test_dict)
    # TODO: assert something ...

    # Test with data option (legacy)

# Generated at 2022-06-21 03:01:05.583286
# Unit test for constructor of class ActionModule
def test_ActionModule():
    my_params = {'aggregate':False, 'per_host':True}
    my_templar = "my_templar"
    my_cli_options = "my_cli_options"
    my_connection = "my_connection"
    my_play_context = "my_play_context"
    my_loader = "my_loader"
    my_shared_loader_obj = "my_shared_loader_obj"
    my_variable_manager = "my_variable_manager"
    my_task_vars = "my_task_vars"
    my_tmp = "my_tmp"
    my_task = "my_task"
    my_connection_info = "my_connection_info"

    my_task_result = "my_task_result"

# Generated at 2022-06-21 03:01:15.263815
# Unit test for constructor of class ActionModule
def test_ActionModule():

    stats = {'data': {'var1': 1, 'var2': 'two'}, 'per_host': False, 'aggregate': True}
    data = {'aggregate': True, 'data': stats['data']}
    task = dict(name='test', action=stats)

    act_mod = ActionModule(task, dict())

    assert act_mod.run(task_vars=dict()) == dict(ansible_stats=stats, changed=False)

    data.update(dict(data=1, per_host=True))
    task.update(action=dict(args=data))

    act_mod = ActionModule(task, dict())

    assert act_mod.run(task_vars=dict())['ansible_stats'] == dict(per_host=True, data=1, aggregate=True)

# Generated at 2022-06-21 03:01:17.186593
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(dict(), dict())
    assert action_module

# Generated at 2022-06-21 03:01:25.062645
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create an instance of the class to call its method
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # check the returned data structure for the run method
    def run_check(task_vars, tmp, data, per_host, aggregate=None, expected_result=None, expected_msg=None):
        if expected_result is None:
            expected_result = {}
        if expected_msg is None:
            expected_msg = 'ok'

        args = {'data': data}
        if per_host is not None:
            args['per_host'] = per_host
        if aggregate is not None:
            args['aggregate'] = aggregate

        # call the method and check the result
        result = action

# Generated at 2022-06-21 03:01:26.451099
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule.__init__, object)

# Generated at 2022-06-21 03:01:27.222468
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	pass

# Generated at 2022-06-21 03:01:38.036768
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Test implementation of ActionBase's constructor and functionality
    # of the unique get_parsed_result function.
    action_module = ActionModule(loader=None, task=None, connection=None, play_context=None, loader_cache=None, shared_loader_obj=None, templar=None, shared_action_plugin_obj=None)

    # Test functionality of get_parsed_result function
    result = action_module.run(tmp=None, task_vars=None)

    # Check if result is a valid dictionary type
    assert(isinstance(result, dict))

    # Check if result is a valid dictionary as per Ansible plugin structure
    assert('changed' in result)
    assert('ansible_stats' in result)
    assert(isinstance(result['ansible_stats'], dict))

    # Check if

# Generated at 2022-06-21 03:01:54.449205
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Create fake Task object
    Task = type('Task', (object,), {})
    task = Task()
    task.args = {}
    task.args['data'] = {}
    setattr(task, 'name', 'Custom Stats')
    setattr(task, 'action', 'Custom Stats')
    setattr(task, 'id', '1')
    setattr(task, 'role', 'Example-Role')
    setattr(task, 'tags', 'None')

    # Create AnsibleVaultEncryptedUnicode obj
    AnsibleVaultEncryptedUnicode = type('AnsibleVaultEncryptedUnicode', (object,), {})
    value = AnsibleVaultEncryptedUnicode()
    secret = 'secret'
    setattr(value, 'vault_secret', secret)

# Generated at 2022-06-21 03:02:06.268039
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arrange
    class ActionModule:
        _task = {}
        _task['args'] = {}
        _task['args']['per_host'] = True
        _task['args']['aggregate'] = False
        _task['args']['data'] = {}
        _task['args']['data']['test'] = 100
        _task['args']['data']['test2'] = 200

        class _templar:
            @staticmethod
            def template(value, convert_bare=False, fail_on_undefined=True):
                return value

    # Act
    action = ActionModule()
    result = action.run()

    # Assert
    assert result['ansible_stats']['per_host'] == True

# Generated at 2022-06-21 03:02:16.742674
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import pytest

    # Case 1: Valid set_stats
    data = {'foo_bar': '3'}
    fake_task = {
        'args': {
            'data': data
        }
    }
    fake_task_vars = {}

    a = ActionModule()
    a._task = fake_task
    result = a.run(task_vars=fake_task_vars)
    assert result == {'changed': False, 'ansible_stats': {'data': {'foo_bar': 3},
                                                          'per_host': False,
                                                          'aggregate': True}}

    # Case 2: Invalid set_stats
    # Non-dictionay 'data' value
    data = 'foo'

# Generated at 2022-06-21 03:02:22.186642
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_mod = ActionModule(
        task=dict(args=dict(per_host=False, aggregate=True)),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert isinstance(action_mod, ActionModule)

# Generated at 2022-06-21 03:02:23.184018
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule()
    # mod.run()

# Generated at 2022-06-21 03:02:30.980361
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    _task = dict(action=dict(module='set_stats', args=dict(data=dict(foo=dict(bar=1)))))
    task_vars = dict()
    tmp = None
    am = ActionModule(task=_task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am.run(tmp, task_vars) == dict(changed=False, ansible_stats=dict(data=dict(foo=dict(bar=1)), per_host=False, aggregate=True))


# Generated at 2022-06-21 03:02:41.211288
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create mocks
    class TmpMock(object):
        def __new__(self):
            return Tmp

    class Tmp(object):
        def __init__(self, tmpdir):
            self.dirname = tmpdir

    class TaskVarsMock(object):
        def __init__(self, data):
            self.data = data

    class TaskMock(object):
        def __init__(self, args):
            self.args = args

    class TemplerMock(object):
        def __init__(self, data, output):
            self.data = data
            self.output = output

        def template(self, data, convert_bare=False, fail_on_undefined=False):
            if data not in self.data:
                return None

# Generated at 2022-06-21 03:02:48.610581
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_args = dict()
    module_args = dict()
    tmp = None
    task_vars = dict()
    task_invocation = dict()

    obj = ActionModule(task=task_args, connection=module_args, play_context=tmp, loader=tmp, templar=tmp, shared_loader_obj=tmp)

    assert obj._valid_args == {'aggregate', 'data', 'per_host'}
    assert obj.TRANSFERS_FILES == False



# Generated at 2022-06-21 03:02:51.933491
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Test class ActionModule constructor
    """
    action = ActionModule(loader=None, task=None, connection=None, play_context=None, loader_callable=None)
    assert action is not None

# Generated at 2022-06-21 03:02:56.747598
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #test basic construction with boolean string
    action_module = ActionModule()
    assert action_module._task.args == {}
    assert action_module._task.loop is None
    assert action_module.TRANSFERS_FILES == False
    assert action_module._VALID_ARGS == frozenset({'aggregate', 'data', 'per_host'})


# Generated at 2022-06-21 03:03:09.093968
# Unit test for constructor of class ActionModule
def test_ActionModule():
    global _VALID_ARGS

    import modules.set_stats
    am = modules.set_stats.ActionModule()
    # test _VALID_ARGS is a frozenset
    assert type(_VALID_ARGS) == frozenset

# Generated at 2022-06-21 03:03:11.002036
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)
    assert isinstance(ActionModule._VALID_ARGS, frozenset)


# Generated at 2022-06-21 03:03:20.681806
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(
        task=dict(
            args=dict(
                foo='bar',
                abc=True,
                per_host=False,
                aggregate=False,
                data={
                    'foo': 'bar',
                    'answer': 42
                }
            )
        )
    )
    assert am.run() == dict(
        ansible_stats=dict(
            foo='bar',
            abc=True,
            per_host=False,
            aggregate=False,
            data={
                'foo': 'bar',
                'answer': 42
            }
        ),
        changed=False,
    )


# Generated at 2022-06-21 03:03:28.769538
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert_equals(ActionModule._VALID_ARGS, frozenset(('aggregate', 'data', 'per_host')))

# Generated at 2022-06-21 03:03:39.382502
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text
    from ansible.playbook.task import Task
    from ansible.template import Templar
    # create a mock Task
    task = Task()
    task._role = None
    # create a mock PlayContext
    play_context = PlayContext()
    # create a mock templar
    templar = Templar(play_context=play_context)
    # create a mock ActionModule
    action_module = ActionModule(task, connection=None, play_context=play_context, loader=None, templar=templar, shared_loader_obj=None)

    # test run with valid task.args
    task_args = {'data': {'test': 'hello'}}
    action

# Generated at 2022-06-21 03:03:40.322496
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, None)
    assert isinstance(module._VALID_ARGS, frozenset)

# Generated at 2022-06-21 03:03:51.422281
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create mock objects
    tmp = "tmp"
    task_vars = dict()
    Stats = dict()
    Stats = {
        'data': {},
        'per_host': False,
        'aggregate': True
    }
    RunnerArgs = dict()
    RunnerArgs = {
        "data": {},
        "per_host": {}
    }
    HostVars = dict()
    HostVars = {
        "meta": {},
        "ansible_facts": {},
        "ansible_stats": {}
    }
    result = {}
    result['ansible_stats'] = {}
    # create an object for ActionModule

# Generated at 2022-06-21 03:03:55.866323
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ return the normal status of run when it is not task_vars"""
    module = ActionModule()
    result = module.run(None, None)
    assert result == {'changed': False, 'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}}


# Generated at 2022-06-21 03:04:04.248057
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case # ###
    # Test files
    # test_ActionModule_run.py
    # test_ActionModule_run_data_1.json
    # test_ActionModule_run_data_2.json
    # test_ActionModule_run_data_3.json
    # test_ActionModule_run_data_4.json
    # test_ActionModule_run_data_5.json
    action_module = ActionModule()
    action_module._task = ActionModule
    action_module._task.args = {}
    action_module._task.args['data'] = {}
    action_module._task.args['per_host'] = {}
    action_module._task.args['aggregate'] = {}
    action_module._task.args['data'] = "test_ActionModule_run_data_1.json"

# Generated at 2022-06-21 03:04:07.091803
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert mod is not None


# Generated at 2022-06-21 03:04:29.995340
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    import tempfile
    import pwd
    import ansible.plugins.action
    # TODO: Find a way to inject the required parameters that are needed to run run()
    test_task = ansible.plugins.action.ActionModule(tempfile.mkdtemp(), 'localhost', 'test_user')
    assert test_task

# Generated at 2022-06-21 03:04:39.954904
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create instance of class ActionModule and mock
    action_module = ActionModule()
    # Create instance of class to mock
    action_base = ActionBase()
    # patch function action_base.run()
    # to return pre-defined values
    action_base.run = MagicMock(return_value={'ansible_stats': {'data': {'some_data': 'blah'}, 'per_host': False, 'aggregate': True}})
    # patch function action_module.run()
    # to call, instead of it's original function,
    # the above mock object, action_base
    action_module.run = action_base.run
    # call function run() of class ActionModule
    action_module.run()
    # assert that function is called once
    action_base.run.assert_called_once_with

# Generated at 2022-06-21 03:04:41.513688
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Constructor")
    ActionModule()
    print("-> OK")


# Generated at 2022-06-21 03:04:46.012730
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # test valid arguments
    ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # test invalid arguments
    try:
        ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None, foo="bar")
        raise AssertionError("Test does not catch invalid argument names")
    except TypeError:
        pass

# Generated at 2022-06-21 03:04:48.861004
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert not action_module.run()
    assert not action_module.run(task_vars={})
    assert not action_module.run(task_vars={}, tmp=None)

# Generated at 2022-06-21 03:04:53.677572
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test for correct initialization (no assert needed)
    mod_action = ActionModule(
        task=dict(
            action=dict(
                module_name='set_stats',
                module_args=dict(
                    aggregate=True,
                    per_host=False,
                    data=dict(
                        a=dict(
                            b=1
                        )
                    )
                )
            )
        ),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )


# Generated at 2022-06-21 03:05:03.391354
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host_opts = {'connection': 'smart', 'transport': 'ssh'}
    loader = None
    variable_manager = None
    pc = None
    play = None
    tqm = None
    play_context = None
    fake_inject = { 'ansible_ssh_pass': '123'}
    tmp_path = '/tmp/ansible-tmp'
    m = main(loader, variable_manager, pc, play, tqm, play_context, fake_inject, '/tmp/ansible-tmp')
    m.set_options()
    ip_result = m.run(host_opts, tmp_path)
    assert isinstance(ip_result, dict)
    # TODO: add asserts once results are know

# Generated at 2022-06-21 03:05:12.805422
# Unit test for constructor of class ActionModule
def test_ActionModule():
  from ansible.parsing.yaml.objects import AnsibleUnicode
  from ansible.vars.manager import VariableManager
  from ansible.inventory.manager import InventoryManager
  from ansible.playbook.play_context import PlayContext
  from ansible.executor.task_result import TaskResult
  from ansible.utils.vars import combine_vars
  #default
  with open('/home/work/Ansible-2.9.9/test/integration/targets/statstest.yml') as fd:
    taskdata = fd.read()
  task = taskdata.strip()
  PlayContext.load = None
  PlayContext.default = None
  variable_manager = VariableManager()

# Generated at 2022-06-21 03:05:13.396484
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 1 == 1

# Generated at 2022-06-21 03:05:21.370470
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {'foo': 2, 'bar': 4}
    task_args = {'data': {'foo': 22, 'bar': {'baz': '{{ foo + bar }}'}}, 'per_host': '{{ true }}', 'aggregate': '{{ false }}'}
    task = {'args': task_args, 'name': 'foo'}
    act_mod = ActionModule(task, {'foo': 2, 'bar': 4})
    act_res = act_mod.run(None, task_vars)
    
    assert act_res['ansible_stats']['data']['foo'] == 22
    assert act_res['ansible_stats']['data']['bar']['baz'] == 6
    assert act_res['ansible_stats']['per_host']

# Generated at 2022-06-21 03:06:04.483778
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test for constructor
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 03:06:14.257935
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    #test case 1
    test_case1 = dict(
        data = dict(
            key1 = "{{ 'ansible' }}",
            key2 = "{{ 'awesome' }}",
            key3 = "{{ 'software' }}"
        )
    )
    # expected result.
    exp_result1 = dict(
            changed = False,
            msg = "",
            ansible_stats = dict(
                aggregate = True,
                data = dict(
                    key1 = "ansible",
                    key2 = "awesome",
                    key3 = "software"
                ),
                per_host = False,
            )
    )

    #test case 2

# Generated at 2022-06-21 03:06:18.855192
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor requires action plugin and loader, ActionBase.__init__
    # invokes the _init_attributes method of the parent class. This method
    # requires the additional 3 parameters, task, shared_loader_obj,
    # tmp_path. Constructor can be invoked only with the above 5 arguments.
    pass

# Generated at 2022-06-21 03:06:23.652054
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        task=dict(),
        connection=dict(),
        play_context=dict(
            check_mode=False,
            diff_mode=False,
        ),
        loader=None,
        templar=None,
        shared_loader_obj=None,
    )
    assert action

# Generated at 2022-06-21 03:06:33.301223
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test of method run of class ActionModule
    host_vars_path = os.path.join(tempfile.mkdtemp(), 'host_vars')
    inventory_path = os.path.join(tempfile.mkdtemp(), 'inventory')
    test_vars = {'host_vars_path': host_vars_path,
                 'inventory_path': inventory_path,
                 'host_vars': {'all': {'ansible_connection': 'local'},
                               'test_1': {'test': 1},
                               'test_2': {'test': 2}},
                 'inventory': {'test_1': ['test_1'],
                               'test_2': ['test_2']}}
    write_config(test_vars)

# Generated at 2022-06-21 03:06:41.639032
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Variables mapping to the arguments of constructor
    test_task = {'args': {'per_host': True, 'aggregate': False}}
    test_connection = 'local'
    test_templar_noop = True
    test_loader = None
    test_shared_loader_obj = None
    test_play_context = None
    test_new_stdin = None
    # Creation of the constructed object using constructor
    test_obj = ActionModule(test_task, test_connection, test_templar_noop, test_loader, test_shared_loader_obj, test_play_context, test_new_stdin)
    # Checks the class name of the created object
    assert test_obj.__class__.__name__ == 'ActionModule'
    # Checks the arguments passed to constructor are correctly set to object's reference

# Generated at 2022-06-21 03:06:48.907320
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(
        task=dict(action=dict(module='set_stats', args=dict(data=dict(a=1, b=2), per_host=True))),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=None,
        shared_loader_obj=None
    )
    result = module.run(task_vars=dict())

    print("result = %s" % result)

    if not result.get('failed'):
        assert result['ansible_stats']['per_host'] is True
        assert result['ansible_stats']['aggregate'] is True
        assert result['ansible_stats']['data']['a'] == 1
        assert result['ansible_stats']['data']['b'] == 2



# Generated at 2022-06-21 03:06:53.394656
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ test the constructor of class ActionModule """

    # testing the constructor of ActionBase
    action_module = ActionModule(
        task=dict(args=dict(data=dict(a=1))),
        connection=None,
        play_context=dict(remote_addr='127.0.0.1'),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    assert action_module

# Generated at 2022-06-21 03:06:57.270228
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test the run method of ActionModule
    """
    # TODO: I can't find a way to mock a module without instantiating a Task class, which contains flow control
    # I only need to mock _load_params and run, but I can't find a way to mock those.
    # So no unit test here, at least not yet.
    pass

# Generated at 2022-06-21 03:07:00.575671
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Test constructor of ActionModule class
    '''

    # Check method _VALID_ARGS of class ActionModule
    action = ActionModule(None, None)
    assert isinstance(action._VALID_ARGS, frozenset)

# Generated at 2022-06-21 03:08:52.505868
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-21 03:08:56.787468
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json

    test_ActionModule.action_module = ActionModule({})

    try:
        res = test_ActionModule.action_module._load_params()
        assert res == True
    except Exception as exp:
        print("Exception in _load_params " + str(exp))
    try:
        res = test_ActionModule.action_module._task.args
        assert isinstance(res, dict)
    except Exception as exp:
        print("Exception in _task.args " + str(exp))
    try:
        res = test_ActionModule.action_module._templar
        assert res is not None
    except Exception as exp:
        print("Exception in _templar " + str(exp))

# Generated at 2022-06-21 03:09:03.484979
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(load_fixture('mock_task.json'),
                          load_fixture('mock_task_vars.json'))
    action._task.args = {'data': {'test': '{{ ansible_memtotal_mb }}'}}
    result = action.run(load_fixture('mock__tmp_path'),
                        load_fixture('mock_task_vars.json'))
    assert result.get('ansible_stats', {}).get('data', {}).get('test') == 394800
    assert result.get('ansible_stats', {}).get('per_host') == False
    assert result.get('ansible_stats', {}).get('aggregate') == True


# Generated at 2022-06-21 03:09:09.104251
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create instance of ActionModule class
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create mocks
    data = {'test': {'data': 'data'}}
    task_vars = {'test': 'test'}
    tmp = False

    # Call action_module.run()
    result = action_module.run(tmp=tmp, task_vars=task_vars)

    # Assert result
    assert result['changed'] == False
    assert result['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True}

# Generated at 2022-06-21 03:09:18.543321
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    new_args = dict()
    new_args['data'] = dict()
    new_args['data']['test_key'] = "test_value"
    new_args['per_host'] = False
    new_args['aggregate'] = True
    am.action_args = new_args
    result = am.run(None, None)
    expected_result = dict()
    expected_result['changed'] = False
    stats = dict()
    stats['data'] = dict()
    stats['data']['test_key'] = "test_value"
    stats['per_host'] = False
    stats['aggregate'] = True
    expected_result['ansible_stats'] = stats

# Generated at 2022-06-21 03:09:23.775581
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_ = {}
    tmp = None
    task_vars = dict()
    task_vars['ansible_facts'] = dict()

    am = ActionModule(task=task_, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    am.run(tmp, task_vars=task_vars)



# Generated at 2022-06-21 03:09:32.283948
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader
    from ansible.vars.hostvars import HostVars
    from ansible.template import Templar
    from ansible.errors import AnsibleError
    import ansible.constants as C
    import ansible.utils.vars
    import ansible.utils.module_

# Generated at 2022-06-21 03:09:37.431027
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # instantiate the class
    action_module = ActionModule(
        task=dict(
            args=dict(
                data=dict(
                    a=1,
                    b=2,
                    c=3,
                    d=4,
                    e=5,
                )
            )
        )
    )

    assert action_module._task.args == action_module.run(task_vars={})['ansible_stats']

# Generated at 2022-06-21 03:09:38.835934
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule()
    assert isinstance(obj, ActionModule)

# Generated at 2022-06-21 03:09:47.556043
# Unit test for method run of class ActionModule