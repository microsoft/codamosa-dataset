

# Generated at 2022-06-21 03:00:25.544868
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Place holder test. There was no functionality to test.
    assert(True)

# Generated at 2022-06-21 03:00:37.279513
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.set_stats import ActionModule
    t = ActionModule(None, {})
    r = t.run(None)
    assert r['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True}
    r = t.run(None, {'data': {'abc': 'def'}})
    assert r['ansible_stats'] == {'data': {'abc': 'def'}, 'per_host': False, 'aggregate': True}
    r = t.run(None, {'data': {'abc': 'def', 'ghi': 'jkl'}})

# Generated at 2022-06-21 03:00:45.666819
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test ActionModule.run
    class MockTask:
        pass

    class MockPlay:
        pass

    class MockLoader:
        pass

    class MockTemplar:
        def __init__(self):
            self.value = 'some value'

        def template(self, data, convert_bare=False, fail_on_undefined=True):
            return self.value

    class MockVars:
        def __init__(self):
            self.value = 'some value'
    class MockActionModule(ActionModule):
        @staticmethod
        def _get_task_vars(task_vars):
            return MockVars(task_vars)

    tmp = None
    task_vars = None
    args = {'data': {'a': 'some', 'b': 'values'}}


# Generated at 2022-06-21 03:00:46.135878
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:00:50.319708
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    members = {'task_vars': {}, '_task': {'args': {'data': {"ip_addresses": "127.0.0.1", "users": ["root"]}}}}
    current_obj = ActionModule()
    for key, value in iteritems(members):
        setattr(current_obj, key, value)
    result = current_obj.run()
    assert isinstance(result, dict)

# Generated at 2022-06-21 03:00:59.413703
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # define arguments that would be sent to the module
    arguments = {
        'per_host': 'yes',
        'aggregate': 'yes',
        'data': {
            'nested': {
                'a': '1',
                'b': '2',
                'c': '3'
            },
            'myvar': 'goodbye',
            'another_one': '125'
        }
    }

    # initialize the module dispatcher class
    x = ActionModule({})

    # initialize the module return values
    ret = {
        'failed': False,
        'changed': False,
        'ansible_stats': {}
    }

    # call the module method and check if the return value is correct
    assert x._task.args == arguments

# Generated at 2022-06-21 03:01:07.170240
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_context import PlayContext
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    play_context = PlayContext()
    play_context._cur_task = 0
    task = Task()
    task._role = None
    task._task = task
    task._role_name = None
    task.action = 'set_stats'
    task.args = {'data': {'foo': 'bar'}, 'per_host': 'yes', 'aggregate': False}
    task._ds = task.args
    task._parent = task
    play

# Generated at 2022-06-21 03:01:07.994048
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:01:16.008928
# Unit test for constructor of class ActionModule
def test_ActionModule():

    import unittest
    from ansible.plugins.action.set_stats import ActionModule
    from ansible.executor.task_queue_manager import TaskQueueManager, TaskQueueItem
    from ansible.executor.play_context import PlayContext
    from ansible.playbook.play_context import PlayContext as Play
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C
    import os

    # test constructor

# Generated at 2022-06-21 03:01:24.806708
# Unit test for constructor of class ActionModule
def test_ActionModule():
    dummy_self = type('DummyClass', (object,), dict())()

    dummy_self.name = 'Setup'
    dummy_self._task = type('DummyClass2', (object,), dict())()
    dummy_self._task.args = dict()

    dummy_self._play_context = type('DummyClass3', (object,), dict())()
    dummy_self._play_context.remote_addr = None
    dummy_self._play_context.connection = 'network_cli'

    dummy_self._loaded_frm_file = False
    dummy_self._task.action = 'setup'

    # test for valid variables names
    for valid_name in ('_', 'a', 'A', 'Z', 'a1', 'a_1', 'a_b_1'):
        dummy_self._task.args

# Generated at 2022-06-21 03:01:34.987138
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task and task_vars
    task = dict()
    task_vars = dict()

    # Create the module
    module = ActionModule(task, task_vars)

    # Create a mock templar
    templar = dict()
    # Create a mock vars_template from the templar
    templar['vars_template'] = dict()
    # Create a mock template from the vars_template
    templar['vars_template']['template'] = dict()
    # Create a mock convert_bare from the template
    templar['vars_template']['template']['convert_bare'] = dict()
    # Create a mock fail_on_undefined from the convert_bare

# Generated at 2022-06-21 03:01:38.295751
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 03:01:39.069471
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True  # TODO: Need unit test

# Generated at 2022-06-21 03:01:47.348146
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule()
    m._task.args = {}
    m._task.args['aggregate'] = 'False'
    m._task.args['data'] = {}
    m._task.args['per_host'] = 'True'
    m._task.action = 'include_vars'
    m._task.action_args = {}
    m._task.role = 'common'
    m._task.role_name = 'common'
    m._task.task_vars['var1'] = 'value1'
    m._task.task_vars['var2'] = 'value2'
    m._play_context = {}
    m._play_context.password = '12345'
    m._play_context.remote_addr = '192.0.2.1'
    m._play_context.remote_

# Generated at 2022-06-21 03:01:55.818193
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Initialize objects
    task = object()
    connection = object()
    in_data = object()
    play_context = object()
    loader = object()
    tmp = object()
    shared_loader_obj = object()
    action = ActionModule(task, connection, in_data, play_context, loader, tmp, shared_loader_obj)
    
    # test member variables
    assert action._task == task
    assert action._play_context == play_context
    assert action._loader == loader
    assert action._shared_loader_obj == shared_loader_obj
    assert action._connection == connection
    assert action._tmp == tmp
    assert len(action._VALID_ARGS) == action._VALID_ARGS.__len__()

# Generated at 2022-06-21 03:02:06.705194
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for `ansible.plugins.action.set_stats.ActionModule.run` method."""
    module = ActionModule(load_fixture('set_stats.json'))
    assert module._task.args == {'data': {'a': 1}, 'aggregate': True, 'per_host': False}

    module = ActionModule(load_fixture('set_stats2.json'))
    assert module._task.args == {'data': {'a': 1, 'test': '{{test}}'}, 'aggregate': True, 'per_host': False}

    module = ActionModule(load_fixture('set_stats3.json'))
    assert module._task.args == {'per_host': 'yes', 'aggregate': 'yes', 'data': {'a': 1}}


# Generated at 2022-06-21 03:02:07.371840
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Add unit tests
    pass

# Generated at 2022-06-21 03:02:17.016936
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # method to test is action/set_stats.py:run
    am=set_stats.ActionModule()
    task_args={'data': {'ansible_python_interpreter': 'test-exec', 'FAKE_': 'test 1', '_FAK2': 'test 2', 'FAKE_3': 'test 3'}, 'aggregate': True, 'per_host': False}
    task_vars={'hostvars': {'host1': {'ansible_python_interpreter': '/usr/bin/python', 'FAKE': 'value1' }}}
    tmp=None
    task_name='set_stats'
    remote_user='root'
    task_tuple=(task_name, tmp, task_args, task_vars, remote_user)

# Generated at 2022-06-21 03:02:20.754208
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    This test tests if the ActionModule class is able to perform the following tasks:
    1. Create an object of class ActionModule
    """
    obj = ActionModule()
    assert obj != None, "Object creation failed"

# Generated at 2022-06-21 03:02:21.407593
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 03:02:39.719350
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # We do not need to test result on run method as it is tested in parsers/vault.py
    action_module = ActionModule(
        task=dict(args=dict(per_host=True, aggregate=True, data=dict(var1='hello', var2='world'))),
        task_vars=dict(hostvars=dict(host1=dict(result=dict()), host2=dict(result=dict()))),
    )
    assert action_module._task.args == dict(per_host=True, aggregate=True, data=dict(var1='hello', var2='world'))


# Generated at 2022-06-21 03:02:50.185931
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  # For each possible value of action in valid_action
  # test both branches of the "if action"

  # Create an instance of an ActionModule object
  action_module = ActionModule()

  # Create an instance of a MockTemplar object
  template = Templar()

  # Create an instance of a MockTask object
  valid_action = MockTask(action_module, template)

  # Create an instance of a MockTask object
  invalid_action = MockTask(action_module, template)

  invalid_action.args = {'data': 5}
  result = action_module.run(invalid_action)
  assert result['failed'] == True
  assert result['msg'] == "The 'data' option needs to be a dictionary/hash"

  invalid_action.args = {'data': {5: 5}}
  result = action_

# Generated at 2022-06-21 03:02:52.347371
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # call constructor and check for assertion
    am = ActionModule(None, None)
    assert am is not None

# Generated at 2022-06-21 03:02:57.731124
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    module_args = dict(data=dict(a='foo', b='bar'))
    task_vars = dict()
    tmp = None

    module = ActionModule()

    result = module.run(tmp, task_vars)

    assert result['changed'] is False
    assert result['ansible_stats']['data']['a'] is 'foo'
    assert result['ansible_stats']['data']['b'] is 'bar'

# Generated at 2022-06-21 03:03:03.018551
# Unit test for constructor of class ActionModule
def test_ActionModule():
    c = ActionModule(None, None)
    assert isinstance(c, ActionBase)
    assert c.TRANSFERS_FILES is False
    assert  c._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-21 03:03:11.255325
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class fake_module_utils_parsing_convert_bool:

        def __init__(self):
            self.fake_boolean = None

        def boolean(self, arg, strict=False):
            return self.fake_boolean

    class fake_module_utils_six:

        def __init__(self):
            self.fake_isidentifier = None

        def isidentifier(self, arg):
            return self.fake_isidentifier

    class fake_action_base:

        def __init__(self):
            self.fake_run = None
            return self.fake_run

    class fake_action_module:

        def __init__(self):
            self.fake_args = None
            self.fake_templar = None
            self.fake_task = None
            self.fake_task

# Generated at 2022-06-21 03:03:20.878621
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()

    # create a dummy task for the test
    module._task = type("Task", (object,), {})

    # template the task's args
    module._templar = type("Templar", (object,), {})
    data = '{some_variable: "{{thats_me}}"}'
    some_variable = "that's me!"
    module._templar.template = lambda x: x
    module._task.args = {'data': data}

    # test that some_variable is injected
    assert 'ansible_stats' in module.run({}, {'thats_me': some_variable})
    assert 'some_variable' in module.run({}, {'thats_me': some_variable})['ansible_stats']['data']
    assert some_variable == module.run

# Generated at 2022-06-21 03:03:31.692551
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.task import Task

    host_name = 'myhost'
    hosts = [host_name]
    variable_manager = None
    loader = None

    tqm = None
    try:
        queue_item = {}
        tqm = TaskQueueManager(
                hosts=hosts,
                inventory=None,
                variable_manager=variable_manager,
                loader=loader,
                options=None,
                passwords=None,
                stdout_callback='default',
            )
        aggregate_results = {}
        PlayContext()
        task = Task()
        ActionModule(task, PlayContext())
        assert False
    except Exception as e:
        assert True

# Generated at 2022-06-21 03:03:40.556257
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit test for method run of class ActionModule """

    class TestVarsModule:
        """ Fake TestVarsModule """
        def get_vars(self, loader=None, path=None, entities=None, cache=True):
            return {}

    class TestTask:
        """ Fake TestTask """
        def __init__(self):
            self.args = {}

    class TestPlayContext:
        """ Fake TestPlayContext """
        def __init__(self):
            self.prompt = (None, None)

    # With a valid config
    _task = TestTask()
    _task.args = {'aggregate':'yes','data':{'var1':1.0,'var2':'str','var3':1}}

# Generated at 2022-06-21 03:03:51.463815
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()

    for expr in ['{foo: bar}', '{  foo  :  bar  }']:
        task_vars = {}
        result = action.run(task_vars=task_vars, tmp=None, task_args=dict(data=expr))
        assert result['changed'] == False
        assert result['ansible_stats'] == {'data': {u'foo': u'bar'}, 'per_host': False, 'aggregate': True}

    for expr in ['"{foo: bar}"', '"{  foo  :  bar  }"']:
        task_vars = {}
        result = action.run(task_vars=task_vars, tmp=None, task_args=dict(data=expr))
        assert result['changed'] == False

# Generated at 2022-06-21 03:04:12.018498
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 03:04:14.304360
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module

# Generated at 2022-06-21 03:04:24.875571
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test creating a new action module
    module = ActionModule()
    # Test passing a string as task args
    task_args = 'test'
    # Test passing a dictionary as task args
    task_args = {'test': 'test'}
    # Test passing a string as tmp
    tmp = 'test'
    # Test passing a dictionary as task var
    task_vars = {'test': 'test'}
    # Test calling method run of class ActionModule
    result = module.run(tmp=tmp, task_vars=task_vars)
    # Test checking if "result" is a dictionary
    assert isinstance(result, dict)
    # Test checking if the "result" dictionary contains the "failed" key
    assert 'failed' in result
    # Test checking if the "result" dictionary contains the "msg" key

# Generated at 2022-06-21 03:04:35.144906
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    class MockModule(object):
        def __init__(self, params, loader, variable_manager, templar, shared_loader_obj):
            self.params = params
            self.loader = loader
            self.variable_manager = variable_manager
            self.templar = templar
            self.shared_loader_obj = shared_loader_obj
            self.called = False

# Generated at 2022-06-21 03:04:44.135724
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_host = dict(name='hostname')
    test_host_vars = dict()
    test_task_vars = dict(hostvars = dict(hostname=test_host_vars))
    test_task = dict(async_val=10, async_enabled=False, action=dict(module_name='set_stats', module_args=dict(data=dict(foo=1),aggregate=True)))
    test_play = None
    test_tmp = None
    test_connection = None
    test_loader = None
    test_templar = None
    test_shared_loader_obj = None

# Generated at 2022-06-21 03:04:45.249590
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule({}, {}, None)
    print(a)

# Generated at 2022-06-21 03:04:51.709575
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader

    from ansible.playbook.play_context import PlayContext

    from ansible.vars.manager import VariableManager

    import ansible.constants as C
    import os

    ###################################
    # prepare test data/environment
    ###################################

    # set default values for module arguments
    # this is needed when testing with old ansible versions that don't have
    # all parameters defined in ActionModule

# Generated at 2022-06-21 03:04:55.217827
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test 1
    # _VALID_ARGS variable is initialized correctly
    a = ActionModule()
    assert(a._VALID_ARGS == frozenset(['aggregate', 'data', 'per_host']))

# Generated at 2022-06-21 03:04:58.350017
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None, None, None, None, None, None)
    assert(a)
    assert(isinstance(a._VALID_ARGS, frozenset))

# Generated at 2022-06-21 03:05:00.682030
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task_include import TaskInclude

    am = ActionModule()
    task = TaskInclude()
    am._task = task

    # test with empty args
    assert isinstance(am.run(), dict)

    # test with valid args
    task.args = {'data': {'test': 'abc'}}
    assert isinstance(am.run(), dict)

# Generated at 2022-06-21 03:05:55.507465
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule(
        task=dict(),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict()
    )

    # test defined class fields
    assert mod._task is not None
    assert mod._connection is not None
    assert mod._play_context is not None
    assert mod._loader is not None
    assert mod._templar is not None
    assert mod._shared_loader_obj is not None
    assert mod._action is None


# Generated at 2022-06-21 03:05:56.713391
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(dict())
    del action_module


# Generated at 2022-06-21 03:06:04.599620
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock config
    config = {
        'ANSIBLE_MODULE_ARGS': {
            'data': {
                'num_tasks': 11,
                'num_ok': 9,
                'num_changed': 2,
                'num_failures': 0,
                'num_unreachable': 0,
                'num_skipped': 0,
                'time': '3:42.74'
            },
            'per_host': True,
            'aggregate': True
        }
    }
    # Create an instance of the object class
    actionmodule_object = ActionModule(config=None, action=config)
    # Retrieve the result from the method run
    result = actionmodule_object.run()

# Generated at 2022-06-21 03:06:14.287917
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 03:06:25.158810
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import ansible.plugins
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.runner
    import ansible.playbook.play_context
    import ansible.inventory.host
    import ansible.inventory.group
    import ansible.inventory.inventory


# Generated at 2022-06-21 03:06:29.313818
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule(task={ "args": { "data": { "foo": "bar" } } }, connection={})
    b = a.run()
    assert b['changed'] is False
    assert b['ansible_stats'] == {'aggregate': True, 'data': {u'foo': u'bar'}, 'per_host': False}

# Generated at 2022-06-21 03:06:33.594893
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule({})
    module.run()
    module = ActionModule({})
    module.run(dict(), dict())
    module = ActionModule({})
    module.run(dict(), dict())
    module = ActionModule({})
    module.run(dict(), dict())


# Generated at 2022-06-21 03:06:35.205554
# Unit test for constructor of class ActionModule
def test_ActionModule():
    f = ActionModule(None, None, None, None)
    assert isinstance(f, ActionModule)

# Generated at 2022-06-21 03:06:43.105622
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import sys
    import mock
    import __builtin__

    # Preparing mocks and test data
    name = 'test_name'
    action = 'test_action'
    inject = dict()
    task_vars = dict()
    tmp = None

    action_module = ActionModule(name=name, action=action, inject=inject)
    action_module._task = task = mock.Mock()
    action_module._loader = loader = mock.Mock()
    action_module._templar = templar = mock.Mock()
    action_module._shared_loader_obj = shared_loader_obj = mock.Mock()

    task.args = args = dict()

    # Run the code to be tested
    result = action_module.run(tmp, task_vars)

    # Assertions


# Generated at 2022-06-21 03:06:46.830956
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # We will create an object of class ActionModule
    # with tmp=None,task_vars=None
    module = ActionModule(
        task=None,
        connection=None,
        _play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    print(module)
# test_ActionModule()

# Generated at 2022-06-21 03:08:52.304160
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    _task = type('', (), {})
    _task.args = {}
    action = ActionModule()
    action._task = _task
    action._task.args = {}
    results = action.run()

    assert 'ansible_stats' in results
    assert 'data' in results['ansible_stats']
    assert 'per_host' in results['ansible_stats']
    assert 'aggregate' in results['ansible_stats']

    assert results['ansible_stats']['data'] == {}
    assert results['ansible_stats']['per_host'] is False
    assert results['ansible_stats']['aggregate'] is True

    _task.args = {'data': {'foo': 'bar'}}
    results = action.run()


# Generated at 2022-06-21 03:08:58.854716
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionmod = ActionModule()
    assert actionmod.run() == dict(changed=False, ansible_stats=dict(data={}, per_host=False, aggregate=True))
    assert actionmod.run(dict(), dict()) == dict(changed=False, ansible_stats=dict(data={}, per_host=False, aggregate=True))
    assert actionmod.run(tmp=None, task_vars=None) == dict(changed=False, ansible_stats=dict(data={}, per_host=False, aggregate=True))

# Generated at 2022-06-21 03:09:01.290536
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class_args = {}
    module_args = { "data": { "foo": "bar" }, "per_host": "no" }

    ac = ActionModule(class_args, module_args)
    assert isinstance(ac.run(), dict)

# Generated at 2022-06-21 03:09:03.052357
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule(None, None)
    assert m is not None
    assert m._VALID_ARGS
    assert m.TRANSFERS_FILES == False


# Generated at 2022-06-21 03:09:03.475531
# Unit test for constructor of class ActionModule
def test_ActionModule():
  assert True

# Generated at 2022-06-21 03:09:04.879785
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(dict(foo='bar'), None, None, None)
    assert action is not None

# Generated at 2022-06-21 03:09:10.348079
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Testing when 'data' is provided
    # Expecting ansible_stats to contain 'data' dictionary
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.play_iterator import PlayIterator
    from ansible.executor.process.worker import WorkerProcess
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager

    host = Inventory().get_host("localhost")
    t = Task()
    t.action = "set_stats"
    t.args = {"data": {"foo": 11, "bar": 22}, "per_host": False, "aggregate": True}

    tr = TaskResult(host, t)
    p = PlayContext()
   

# Generated at 2022-06-21 03:09:19.640303
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    #from ansible.plugins.action import ActionBase
    from ansible.vars.manager import VariableManager

    fake_loader = DictDataLoader({
        "test_playbook_action.yml": """
        - name: test
          set_stats:
            data:
              ansible_facts:
                a: 1
                b: foo
            aggregate:
              ansible_facts.c: 2
            per_host: False
        """,
    })
    fake_inventory = Inventory(loader=fake_loader, variable_manager=VariableManager(), host_list=[])

    task = Task()
    task.action = 'set_stats'

# Generated at 2022-06-21 03:09:27.452594
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    import sys

    # Creating an object of the class
    action_module = ActionModule()

    # Mock class object
    class Mock(object):
        pass

    # Creating object of mock class
    action_module_obj = Mock()
    action_module_obj.args = {'data': {'sample_data': 'test'}, 'other_data': {'test_identifier': 'entered'}}

    # Running method `run` of the class
    # And storing the output of the method
    stats = action_module.run(action_module_obj)

    # Asserting the test case
    assert stats['ansible_stats']['data']['sample_data'] == "test"
    assert stats['ansible_stats']['per_host'] == False

# Generated at 2022-06-21 03:09:29.515929
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TestActionModule(ActionModule):
        def run(self, tmp, task_vars):
            return tmp

    action = TestActionModule()
    result = action._execute_module(task_vars=None, wrap_async=None, tmp=None)
    assert result == None