

# Generated at 2022-06-21 03:00:28.590040
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule(
        task=dict(action=dict(module_name='set_stats', args={'data': {'a':5}, 'per_host': True})),
        connection=dict(),
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert actionModule._task.args.get('data').get('a') == 5
    assert actionModule._task.args.get('per_host') is True


# Generated at 2022-06-21 03:00:33.182703
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(dict(
        _task=None,
        _connection=None,
        _play_context=None,
        _loader=None,
        _templar=None
    ), dict())

    assert isinstance(action, ActionModule)

# Generated at 2022-06-21 03:00:45.195072
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import tempfile
    import os
    import shutil
    from ansible.utils.vars import combine_vars

    a = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Remove and recreate the temporary folder for unit testing
    def reset_tmp_folder():
        if os.path.exists(a.tmp_path):
            for file_object in os.listdir(a.tmp_path):
                file_object_path = os.path.join(a.tmp_path, file_object)
                if os.path.isfile(file_object_path):
                    os.unlink(file_object_path)
                else:
                    shutil.rmtree(file_object_path)

    # Reset temp

# Generated at 2022-06-21 03:00:50.860620
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(action=dict(module_name='set_stats', module_args=dict(data=dict(foo=42))))
    )
    assert action_module._task.action['module_name'] == 'set_stats'

# Generated at 2022-06-21 03:00:59.773300
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # create a dummy ansible module
    t = ActionModule(dict(name='test_playbook', super_users=['root'], task_vars={'ansible_distribution':'RedHat'}))

    res = t._execute_module()

    # setting each variable one at a time
    assert res['ansible_stats']['aggregate'] == True
    assert res['ansible_stats']['per_host'] == False

    t._task.args = dict(per_host=True)
    res = t._execute_module()

    assert res['ansible_stats']['aggregate'] == True
    assert res['ansible_stats']['per_host'] == True

    t._task.args = dict(aggregate=False)
    res = t._execute_module()


# Generated at 2022-06-21 03:01:01.100606
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_ActionModule_run.__self__.run()

# Generated at 2022-06-21 03:01:03.558762
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    task_vars = dict()
    module.data = {'module_name': 'set_stats', 'module_args': dict()}
    module.validate_module_args()
    module.run(None, task_vars)

# Generated at 2022-06-21 03:01:14.531727
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialise our test object
    action = ActionModule()
    # Test with no arguements
    result = action.run(task_vars={'some_var': 'some_value'})
    assert result['ansible_stats']['data'] == {}, "Data should be empty"
    assert result['ansible_stats']['per_host'] == False, "per_host should be False"
    assert result['ansible_stats']['aggregate'] == True, "aggregate should be True"
    # Test with arguements
    result = action.run(task_vars={'some_var': 'some_value'}, tmp=None, args={'data': {'some_var': 'some_value'}, 'per_host': 'yes', 'aggregate': 'yes'})

# Generated at 2022-06-21 03:01:21.058556
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_text

    # Initialize AnsibleModule with valid arguments
    module_args = dict(
        command="/bin/foo",
        data=dict(a=10, b=20, c=30),
        per_host=True,
    )
    module = AnsibleModule(**module_args)

    # Instantiate ActionModule object
    am = module.load_manager('command_plugins.set_stats', module_args)
    am.modul

# Generated at 2022-06-21 03:01:27.783034
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

    t = Task()
    t._role = None
    t.action = 'set_stats'
    t.args = {'data': {'key1': 'value1', 'key2': 'value2'}}
    t._parent = Block(play=Play().load({'name': 'test', 'hosts': 'all', 'gather_facts': 'no'}, variable_manager=None, loader=None))

    a = t.args

    assert a['data'] == {'key1': 'value1', 'key2': 'value2'}

# Generated at 2022-06-21 03:01:38.726063
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Unit test for constructor of class ActionModule
    """
    test_instance = ActionModule()
    assert(test_instance._VALID_ARGS == frozenset(['aggregate', 'data', 'per_host']))
    assert(test_instance.TRANSFERS_FILES == False)

# Generated at 2022-06-21 03:01:42.675184
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ac = ActionModule(None, 'lib_name', None, None, None)

    assert not ac.TRANSFERS_FILES
    assert ac._VALID_ARGS == frozenset(['aggregate', 'data', 'per_host'])

# Generated at 2022-06-21 03:01:51.747405
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ac = ActionModule(mock_task, mock_connection, mock_play_context, mock_loader, mock_templar, mock_shared_loader_obj)
    result = ac.run(None, None)
    assert not result['failed']
    assert result['ansible_stats']['aggregate']
    assert not result['ansible_stats']['per_host']
    assert result['ansible_stats']['data'] == {'foo': 1}


# Generated at 2022-06-21 03:01:53.876224
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    # TODO: Assert the object construction


# Generated at 2022-06-21 03:01:54.864238
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule()

# Generated at 2022-06-21 03:02:06.427368
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import os
    import json

    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    import ansible.constants as C
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.callback import CallbackBase

    class Model:
        def __init__(self, w_args):
            self.args = w_args

    class Task:
        def __init__(self, w_action=None):
            self.action = w_action or dict(module='set_stats', args=dict())

   

# Generated at 2022-06-21 03:02:16.778860
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Local imports, needed because we are not in the module's context
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader

    # Set defaults

# Generated at 2022-06-21 03:02:20.108574
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.facts.virtual.xen.xen import XenDetector as Xend
    x = Xend()
    x.get_all_facts()

# Generated at 2022-06-21 03:02:21.626877
# Unit test for method run of class ActionModule
def test_ActionModule_run():
   print("Testing class ActionModule method run")

   # TODO: Nothing to test here?

# Generated at 2022-06-21 03:02:26.540240
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule(None, None)
    am._task.args = {}
    expected = {'changed': False,
                'ansible_stats': {'data': {},
                                  'per_host': False,
                                  'aggregate': True}}
    actual = am.run(None, None)
    assert actual == expected


# Generated at 2022-06-21 03:02:41.561062
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Fake task_vars
    task_vars = {}

    # Create a fake AnsibleModule object
    class AnsibleModuleFake:
        def __init__(self, *args, **kwargs):
            pass

    # Create a fake AnsibleModule object
    m = AnsibleModuleFake()

    # Create a fake Task object
    class TaskFake:
        def __init__(self, args):
            self.args = args

    # Create a TaskFake object
    t = TaskFake({'data': {'n': 1, 'b': True}, 'per_host': True})

    # Create a class action_plugin
    class action_plugin:
        def __init__(self):
            pass

        def run(self, tmp=None, task_vars=None):
            if task_vars is None:
                task_

# Generated at 2022-06-21 03:02:44.314131
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isidentifier("a") == True
    assert isidentifier("") == False
    assert isidentifier("1") == False

# Generated at 2022-06-21 03:02:55.032524
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module._task = dict()
    kwargs = dict()
    kwargs['data'] = dict()
    kwargs['aggregate'] = True
    kwargs['per_host'] = False
    module._task['args'] = kwargs
    data = dict()
    data['a'] = "a"
    data['b'] = "$a"
    kwargs['data'] = data
    module._templar = dict()
    module._templar['template'] = dict()
    module._templar['template']['a'] = "a"
    module._templar['template']['$a'] = 'a'
    module._templar['template'][True] = True
    module._templar['template'][1] = 1
    module._tem

# Generated at 2022-06-21 03:03:00.147249
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module._task = {}
    action_module._task.args = {}
    action_module._task.args = {"per_host": "True", "aggregate": "True", "data":{"name":"a"}}
    #action_module._task.args = {'per_host': True, 'aggregate': True, 'data':{"name":"a"}}
    result = action_module.run()
    print(result)

# Generated at 2022-06-21 03:03:09.526527
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor import task_result

    TASK_ARGS = {'data': {'abc': '123'}, 'per_host': True, 'aggregate': False}

    ACTION_MODULE = ActionModule(
        task=dict(
            args=TASK_ARGS
        ),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    ACTION_MODULE.task_vars = {'inventory_hostname': 'inventory_hostname', 'group_names': ['group_names']}

    assert ACTION_MODULE._valid_args is None

    RESULT = ACTION_MODULE.run(tmp=None, task_vars=None)


# Generated at 2022-06-21 03:03:19.461238
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # mock task
    task = Mock()

    # mock task.args
    task.args = {'data': {'var1': 'value1'}, 'per_host': False}

    # mock task_vars
    task_vars = {'hostvars': {}}

    # mock connection and module_utils
    connection = Mock()
    connection._shell.exec_command = MagicMock(return_value=[0, '', ''])

    # create instances
    action_base = ActionBase()
    action_module = ActionModule(task, connection, action_base._loader, action_base._templar, action_base._shared_loader_obj)

    # call method
    result = action_module.run(task_vars=task_vars)

    # check results
    assert result['changed'] == False

# Generated at 2022-06-21 03:03:24.945915
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Unit test for ActionModule constructor. The only required
    argument is the task. This is used to populate the ActionModule
    object's _task property. The ActionModule object is initialized
    with empty arguments. """
    class ActionModuleTask:
        def __init__(self):
            self.args = {}
    action_module_task = ActionModuleTask()
    action_module = ActionModule(action_module_task)
    assert action_module


# Generated at 2022-06-21 03:03:35.305486
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # mock module
    module_mock = MagicMock()
    module_mock._templar = _templar_mock
    module_mock._task = _task_mock
    module_mock.run = ActionModule.run
    module_mock._shared_loader_obj = None

    #mock task
    _task_mock.args = {'data': {'a': 1, 'b': 2}, 'per_host': 'False'}
    res = module_mock.run()

    assert(res['ansible_stats']['data']['a'] == 1)
    assert(res['ansible_stats']['data']['b'] == 2)
    assert(res['ansible_stats']['per_host'] is False)

# Generated at 2022-06-21 03:03:36.814650
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, None)
    assert module != None

# Generated at 2022-06-21 03:03:43.521433
# Unit test for constructor of class ActionModule
def test_ActionModule():

    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    play_context = PlayContext()
    play_context._options = {'host_key_checking': False,
                             'nocows': 1,
                             'forks': 10}

    inventory = InventoryManager(loader=None, sources=None)
    variable_manager = VariableManager(loader=None, inventory=inventory)

    action = ActionModule(play_context, {}, variable_manager, loader=None, templar=None, shared_loader_obj=None)

    stats = {'data': {'key': 'value'}, 'per_host': True, 'aggregate': True}

# Generated at 2022-06-21 03:03:54.790932
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-21 03:04:03.550073
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Create a fake task and data set, then test ActionModule
    """

    class AnsibleModule():
        def __init__(self, *args, **kwargs):
            pass

    class AnsibleTask():
        def __init__(self, *args, **kwargs):
            pass

    class AnsibleHost():
        def __init__(self, *args, **kwargs):
            pass

    class AnsibleVars():
        def __init__(self, *args, **kwargs):
            pass

    class AnsibleFileTransfer():
        def __init__(self, *args, **kwargs):
            pass

    def test_run():
        return {'changed': False}

    module = 'set_stats'
    args = {}
    task = AnsibleTask()
    # task.action = module
   

# Generated at 2022-06-21 03:04:05.490168
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module

# Generated at 2022-06-21 03:04:07.322449
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None)
    assert action_module is not None


# Generated at 2022-06-21 03:04:18.151290
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Define a fake action plugin and action loader.
    from ansible.plugins import action
    class FakeActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            return super(FakeActionModule, self).run(tmp, task_vars)
    class FakeActionModuleLoader(action.ActionModuleLoader):
        def get(self, task, connection, play_context, loader, templar, shared_loader_obj):
            return FakeActionModule()
    action.ActionModuleLoader = FakeActionModuleLoader

    # Define a fake Runner.
    class FakeRunner:
        def __init__(self):
            self.tasks = []
            self.tasks.append(FakeTask())
    class FakeTask:
        def __init__(self):
            self.action = 'fakeaction'


# Generated at 2022-06-21 03:04:25.795846
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.set_stats import ActionModule
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C
    import os
    import sys

    if sys.version_info.major < 3:
        import __builtin__ as builtins
    else:
        import builtins

    data_loader = DataLoader()

    variable_manager = VariableManager()
    inventory = InventoryManager(loader=data_loader, variable_manager=variable_manager, host_list='localhost')
    variable_manager.set_inventory(inventory)

    # test _VALID_ARGS

# Generated at 2022-06-21 03:04:26.683866
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 03:04:36.774642
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_loader = DummyActionPluginLoader()
    action_loader.add_directory(os.path.dirname(os.path.abspath(__file__)))
    task = Task(
        load=dict(
            action=dict(
                module='set_stats',
                args=dict(
                    data=dict(
                        foo=5,
                        bar='hi'
                    )
                )
            )
        )
    )
    task_vars = dict()
    host_vars = dict()


# Generated at 2022-06-21 03:04:45.407074
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext

    module_args = {'per_host': True, 'aggregate': True, 'data': {'a': 1, 'b': 1}}
    tmp = None
    task_vars = {'ansible_check_mode': False}
    play_context = PlayContext()

    # Successful run
    result = ActionModule(play_context=play_context).run(tmp, task_vars, module_args)
    assert(result['changed'] == False)
    assert(result['ansible_stats'] == {'data': {'a': 1, 'b': 1}, 'per_host': True, 'aggregate': True})

    # Failure - with data argument as string
    module_args = {'data': '{{ hostvars[inventory_hostname] }}'}

# Generated at 2022-06-21 03:04:46.317732
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None)
    assert action

# Generated at 2022-06-21 03:05:15.972288
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock self object
    mock_self = type('MockSelf', (object,), {})()

    # Create a mock stats object with required attributes
    mock_stats = {}
    mock_stats['data'] = {}
    mock_stats['per_host'] = True
    mock_stats['aggregate'] = True

    # Create a mock ansible_stats object with required attributes
    mock_ansible_stats = {}

    # Create a mock task vars object with required attributes
    mock_task_vars = {}

# Generated at 2022-06-21 03:05:18.772459
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_args = {'data':{'test':True},'aggregate':False, 'per_host':True}
    for key, value in iteritems(module_args):
        assert (ActionModule._VALID_ARGS.__contains__(key))

# Generated at 2022-06-21 03:05:19.481705
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None)

# Generated at 2022-06-21 03:05:23.109231
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    acm = ActionModule(
        task=dict(action=dict(module_name="set_stats",
                              module_args=dict(data=dict(k1=1, k2=2)))) ,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)
    # Check that method run does not return None
    assert acm.run() is not None


# Generated at 2022-06-21 03:05:25.237806
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_module = ActionModule()

    # testing TRANFEERS_FILES attribute
    assert action_module.TRANSFERS_FILES == False

    # testing _VALID_ARGS attribute
    assert action_module._VALID_ARGS == frozenset(['aggregate', 'data', 'per_host'])


# Generated at 2022-06-21 03:05:25.690135
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:05:26.204372
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    assert True

# Generated at 2022-06-21 03:05:36.232970
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Initialize class instance for testing method
    action_module = ActionModule(
        task=dict(),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    action_module._task.args = dict()

    # Test with empty action_module._task.args
    result = action_module.run(
        tmp=None,
        task_vars=None
    )
    assert result['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True}
    assert result['changed'] is False
    assert 'msg' not in result
    assert 'failed' not in result

    # Test with action_module._task.args having single entry

# Generated at 2022-06-21 03:05:45.049107
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.playbook import PlaybookInventory
    from ansible.template import Templar

    class Subject(ActionModule):
        def run(self, tmp=None, task_vars=None):
            pass

    # set up required objects
    t = Task()
    h = Host(name="testhost")
    g = Group(name="testgroup")
    g.add_host(host=h)
    i = PlaybookInventory([g])
    tmplar = Templar(loader=None, variables={})


# Generated at 2022-06-21 03:05:54.456162
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_args={'data' : {'a':1}, 'per_host': True, 'aggregate': False }
    am = ActionModule()
    am.run(task_vars={'a':2})
    assert am.run(task_vars=module_args)[0]['ansible_stats']['data'] == {'a':1}
    assert am.run(task_vars=module_args)[0]['ansible_stats']['per_host'] == True
    assert am.run(task_vars=module_args)[0]['ansible_stats']['aggregate'] == False

# Generated at 2022-06-21 03:06:39.519092
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test stub containing the following test case against class ActionModule
    '''
    # Create an instance of the ActionModule class
    actmod = ActionModule()

    # Create any required test values
    tmp = None
    task_vars = dict()
    task_vars['ansible_stats'] = dict()
    task_vars['ansible_stats']['aggregate'] = True
    task_vars['ansible_stats']['per_host'] = False
    task_vars['ansible_stats']['data'] = dict()
    task_vars['ansible_stats']['data']['COUNT1'] = 10
    task_vars['ansible_stats']['data']['COUNT2'] = 20

    # Call the run method of ActionModule
    result = actmod

# Generated at 2022-06-21 03:06:45.963058
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
        Unit test for method run of class ActionModule
    """
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action.set_stats import ActionModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.vars.unsafe_proxy import UnsafeProxy
    import os
    import json

    # Get the path of set_stats.py

# Generated at 2022-06-21 03:06:47.277943
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: create test case
    raise NotImplementedError

# Generated at 2022-06-21 03:06:48.976581
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Unit test for constructor of class ActionModule.
    """
    assert True


# Generated at 2022-06-21 03:06:57.151439
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test method of class ActionModule run with following test cases:
    1. empty test
    2. setting of aggregate and per_host defaults
    3. setting of aggregate and per_host options on their own
    4. setting of aggregate and per_host options together
    4. data set to a dictionary
    5. data set to a string but invalid jinja2 template (should raise exception)
    6. data set to a valid jinja2 template that can be rendered to a dictionary
    7. data set to a valid jinja2 template that can be rendered to a non dictionary
    8. a dictionary key not valid as a python variable is passed (should raise exception)

    :return: No return
    """
    # instantiate mock objects
    mock_module_util = MockActionModuleUtils()

    # instantiate ActionModule object
    action_module

# Generated at 2022-06-21 03:07:05.145477
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader, inventory, variable_manager = (None, None, None)
    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_inventory(InventoryManager(loader=loader, sources=['localhost,']))
    variable_manager._extra_vars = dict(foo="bar")
    variable_manager._options_vars=dict(foo="bar")

    play_context = PlayContext()

# Generated at 2022-06-21 03:07:05.641996
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:07:06.121814
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    pass

# Generated at 2022-06-21 03:07:13.180548
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import logging

    logging.basicConfig(stream=sys.stderr)
    logging.getLogger().setLevel(logging.DEBUG)

    module = ActionModule()
    module._connection = None
    module._task = None
    module._play_context = None
    module._remote_addr = None
    module._templar = None
    module._loader = None

    result = module.run(tmp=None, task_vars={'ansible_facts': {}})
    print(result)

    assert 'ansible_stats' in result
    assert result['ansible_stats'] is not None
    assert isinstance(result['ansible_stats'], dict)

    assert 'per_host' in result['ansible_stats']

# Generated at 2022-06-21 03:07:13.613299
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 03:09:05.654838
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext

    task = Task()
    task._role = None
    task._block = Block()
    task.args = dict(data=dict(foo=1))
    task._play_context = PlayContext()

    t = ActionModule(task, dict(foo=2))
    assert t._task == task
    assert t._shared_loader_obj == dict(foo=2)
    assert t.task_vars == dict()

# Generated at 2022-06-21 03:09:15.250942
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''

    # create mocks
    mock_task = Mock()
    mock_task._role = None
    mock_task._role_params = {}
    mock_task.args = {'data': {'test': 'testval'}}

    mock_play = Mock()
    mock_play.name = 'test_play'

    mock_loader = Mock()

    mock_templar = Mock()
    def mock_template(val):
        return val
    mock_templar.template = mock_template

    mock_config = Mock()

    # create instance of class and call run method

# Generated at 2022-06-21 03:09:17.875017
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(None, None, None)
    assert module.run(None, {}) == {'ansible_stats': {'per_host': False, 'data': {}, 'aggregate': True}, 'changed': False}



# Generated at 2022-06-21 03:09:26.225045
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {'var1': 123, 'var2': 345}
    module_name = "set_stats"
    args = {'data': {'foo': 123, 'bar': 345}}
    templar = MagicMock()
    task = MagicMock()
    tmp = MagicMock()
    task.args = args
    templar.template.return_value = args['data']
    am = ActionModule(task, tmp, task_vars, templar)
    am.run()
    assert am.run() == {'ansible_stats': {'aggregate': True, 'per_host': False, 'data': args['data']}, 'changed': False}
    args = {'data': {'foo': '$var1', 'bar': '$var2'}}
    task.args = args

# Generated at 2022-06-21 03:09:31.163971
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.playbook import Play
    from ansible.playbook.task import Task
    from ansible.playbook.play import PlayContext


# Generated at 2022-06-21 03:09:38.058468
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(dict(CommandBaseMixin=object(), task=dict(args=dict(aggregate=True, data={}))))
    action._task.args['data'] = dict(foo='bar')
    action._task.args['per_host'] = True
    assert action.run() == {'ansible_stats': {'per_host': True, 'aggregate': True, 'data': {'foo': 'bar'}}, 'changed': False}
    action._task.args['data'] = 'bar'
    assert action.run()['failed']

# Generated at 2022-06-21 03:09:46.975458
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Setup test data:
    #   - args of task to be executed
    #   - value of task_vars
    test_args = {'aggregate': True, 'per_host': False, 'data': {'test_var': 'test_val'}}
    test_task_vars = dict()

    # Init data for the test
    test_action_module_to_test = ActionModule("test_playbook")

    # Call the run method of class ActionModule
    result = test_action_module_to_test.run(None, test_task_vars)

    # Assert that we get the expected result.
    assert result['ansible_stats'] == {'data': {'test_var': 'test_val'}, 'aggregate': True, 'per_host': False}
    assert result['changed'] == False

# Generated at 2022-06-21 03:09:54.840293
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import mock
    import pprint
    from ansible.plugins.action import ActionModule as AM

    test_task_args = {
        'data': {
            'test_var': 'test_value'
        },
        'per_host': 'True',
        'aggregate': 'False'
    }

    test_task_vars = {
        'ansible_facts': {
            'custom_fact': 'test_value'
        }
    }

    test_task_vars_templated = {
        'ansible_facts': {
            'custom_fact': 'test_value'
        },
        'test_var': 'test_value'
    }

    with mock.patch.object(AM, '_templar') as _templar:
        _templar.template.side_effect

# Generated at 2022-06-21 03:09:57.700534
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # a) Test case: run method will return success when task argument is correct
    # and run method returns success.
    assert True == ActionModule.run(None, {'data': {'test': 'value'}})['failed']

# Generated at 2022-06-21 03:10:06.236180
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    # DataLoader object to load the tasks
    loader = DataLoader()
    # Task queue manager object to get the task queue
    tasks = TaskQueueManager(loader=loader, inventory=InventoryManager(loader=loader, sources="localhost,"))
    # Variable manager object to get the variables
    variable_manager = VariableManager(loader=loader, inventory=tasks.inventory)

    # Create play object, playbook objects use .load instead of init or new methods,
    # this will also automatically create the task objects from the info provided in play_source
    play_