

# Generated at 2022-06-21 03:00:30.587174
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task                    = None,
        connection              = '',
        play_context            = dict(),
        loader                  = '',
        templar                 = '',
        shared_loader_obj       = '',
        final_loader            = '',
        collection_list         = '',
        ansible_version_info    = '',
    )
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-21 03:00:32.511133
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule().run(tmp=None, task_vars=None)

# Generated at 2022-06-21 03:00:41.617380
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ac = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    task_vars = {}
    result = {'failed': False, 'changed': False, 'msg': '', 'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}}
    assert ac.run(tmp=None, task_vars=task_vars) == result

    task_vars = {'foo': 'bar'}
    result['failed'] = True
    result['msg'] = "The variable name 'abc:def' is not valid. Variables must start with a letter or underscore character, and contain only " \
        "letters, numbers and underscores."

# Generated at 2022-06-21 03:00:48.854908
# Unit test for constructor of class ActionModule
def test_ActionModule():
	
	# 1) TEST THE POSITIVE SCENARIO
	# Creating an object of ActionModule class, calling the constructor and assigning to an object
	am = ActionModule('/home/gaurav/Desktop/ansible-2.4.1.0/lib/ansible/plugins/action/set_stats.py')
	
	print('\nChecking if all the conditions satisfied for the correct assignment of action module file\n')
	# Checking for the result of the constructor
	if am.result != '0':
		# if result == '0' then the constructor has successfully read the action module file as a string
		print("Error in assigning the action module file as a string!")
		

# Generated at 2022-06-21 03:00:54.954195
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(task={'args':{'per_host':'yes','aggregate':'TRUE','data':{'a':'a','b':'b'}}})

    assert am.run() == dict(
        changed=False,
        ansible_stats=dict(
            aggregate=True,
            per_host=True,
            data=dict(
                a='a',
                b='b'
            )
        )
    )

# Generated at 2022-06-21 03:00:56.993846
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule(None, None, None, None)
    assert mod

# Generated at 2022-06-21 03:01:06.315252
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.constants import DEFAULT_MODULE_PATH

    yaml_dict = dict(
        action=dict(
            module='test_module_name',
            args=dict(test_arg_key='test_arg_value')
        )
    )

    task = Task.load(yaml_dict)
    play_context = PlayContext()

    action_module = ActionModule(task, play_context, DEFAULT_MODULE_PATH)

    assert(action_module._task == task)
    assert(action_module._connection is None)
    assert(isinstance(action_module._loader, object))
    assert(isinstance(action_module._templar, object))

# Generated at 2022-06-21 03:01:08.841363
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actmod = ActionModule(load_action_plugins=False)
    assert actmod.run() is not None

# Generated at 2022-06-21 03:01:19.327742
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader

    action = action_loader.get('set_stats', task=dict(), connection=None, play_context=dict(), loader=None, templar=None, shared_loader_obj=None)

    # test with no data
    result = action.run(task_vars=dict())
    del result['invocation']  # remove invocation field, not necessary
    assert result == {'changed': False, 'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}}

    # test with data
    result = action.run(task_vars={'var': 'val'})
    del result['invocation']  # remove invocation field, not necessary

# Generated at 2022-06-21 03:01:19.845437
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-21 03:01:33.307292
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    raw_module_args = {'data': 'test_data'}
    action_module = ActionModule({}, 'test_action_module', raw_module_args, 'test_ansible_stats')
    result = action_module.run()
    data = result.get('ansible_stats')
    assert result.get('msg') == None
    assert result.get('failed') == False
    assert data.get('aggregate') == True
    assert data.get('per_host') == False
    assert data.get('data') == 'test_data'

# Generated at 2022-06-21 03:01:35.963786
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-21 03:01:38.651358
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None)
    assert isinstance(action, ActionBase)


# Generated at 2022-06-21 03:01:42.333118
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.set_stats import ActionModule

    mod = ActionModule()

    data = {'first': '1', 'second': '2', 'third': '3'}
    result = mod.run(task_vars={}, tmp={'data': data}, task_args={})

    assert result['ansible_stats'] == {'data': data, 'per_host': False, 'aggregate': True}
    assert result['changed'] == False
    assert result['failed'] == False

# Generated at 2022-06-21 03:01:52.224961
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # 1. Describe a test case where AnsibleModule.run
    #    returns valid 'result' hash
    # 2. Describe the test case with valid 'self' hash
    stats = {
        'data': {
            'test_data': 'some value'
        },
        'per_host': False,
        'aggregate': True
    }

    task_vars = {}
    m = ActionModule()
    result = m.run(task_vars=task_vars)
    assert result['ansible_stats'] == stats

# Generated at 2022-06-21 03:01:59.547740
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.set_stats
    a = ansible.plugins.action.set_stats.ActionModule(None, dict(tmp='/tmp/tmppMk0ZJ', data={'name': 'kevin'}), None, None)
    assert a._task.args.get('data').get('name') == 'kevin'

# Generated at 2022-06-21 03:02:08.026018
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 03:02:17.447757
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action = ActionModule(task=dict(name="test_task_name"), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Test with all data types for data
    for data_type in [dict, list, str, int, float, bool]:
        task = dict(args=dict(data=data_type()))
        result = action.run(task_vars=dict())
        assert result['ansible_stats'], "Invalid ansible_stats: %s" % result['ansible_stats']

        # assert that the data is a dict
        assert isinstance(result['ansible_stats']['data'], dict), "invalid key data: %s" % result['ansible_stats']['data']
        # assert that the data is empty
       

# Generated at 2022-06-21 03:02:19.492490
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(runner=None)
    assert action_module is not None

# Generated at 2022-06-21 03:02:30.201201
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    for fail_on_undefined in [True, False]:
        for convert_data in [True, False]:
            for convert_per_host in [True, False]:
                for convert_aggregate in [True, False]:
                    task_vars = dict()
                    module = ActionModule(None, dict(
                        data=dict(
                            a=123,
                            b='{{ c }}',
                            d=dict(
                                e='{{ a }}'
                            )
                        ),
                        per_host=convert_per_host,
                        aggregate=convert_aggregate
                    ))
                    fake_templar = FakeTemplar(fail_on_undefined, dict(c=456))
                    module._templar = fake_templar

# Generated at 2022-06-21 03:02:43.310871
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None)
    assert action_module._VALID_ARGS == frozenset(['aggregate', 'data', 'per_host'])


# Generated at 2022-06-21 03:02:49.868797
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = dict()
    task['args'] = dict()
    task['args']['data'] = "TEST-STRING"
    task['args']['per_host'] = "TEST-STRING"
    task['args']['aggregate'] = "TEST-STRING"
    obj = ActionModule(task, dict())
    assert isinstance(obj._task.args, dict)
    assert isinstance(obj.run(dict(), dict()), dict)

# Generated at 2022-06-21 03:02:52.058758
# Unit test for constructor of class ActionModule
def test_ActionModule():
  # Fixture setup
  # Test case
  # Assertions
  # Fixture teardown
  return

# Generated at 2022-06-21 03:03:00.767309
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils import basic

    class VarManager:
        def __init__(self):
            self.vars = {}

        def set_variable(self, k, v):
            self.vars[k] = v

    # Instance of class ActionModule
    a = ActionModule(None, basic.AnsibleModule)

    # Instance of class VarManager
    vm = VarManager()

    # Setting task_vars
    vm.vars['ansible_var'] = 'ansible_var'

    # Instance of class HostVars
    hv = {}
    hv["ansible_var"] = "ansible_var"

    # Instance of class PlayContext
    pc = basic.AnsibleModule._play_context_class(None, hv)

    # Instance of class Task
   

# Generated at 2022-06-21 03:03:09.848841
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # mock AnsibleModule
    import ansible.module_utils.basic as _basic_module_utils
    _basic_module_utils.AnsibleModule = lambda **kwargs: {
        'params':   kwargs['argument_spec'], 'message': None
    }

    # mock hostvars
    hostvars = {
        'test-host-1': {
            'test_host_var_1_1': 'host_value_1_1',
            'test_host_var_1_2': 'host_value_1_2'
        },
        'test-host-2': {
            'test_host_var_2_1': 'host_value_2_1',
            'test_host_var_2_2': 'host_value_2_2'
        }
    }

   

# Generated at 2022-06-21 03:03:13.429437
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Construct the class with action parameters arguments
    action_module = ActionModule(dict(aggregate='True', data='{{ var }}'))

    # Check if the action module object is created
    assert action_module != None

# Generated at 2022-06-21 03:03:21.755255
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    tmp = None
    task_vars = None

    # call run with no args
    result = module.run(tmp, task_vars)
    assert(result)

    # call run with tmp args
    result = module.run(tmp=True, task_vars=None)
    assert(result)

    # call run with tmp args
    result = module.run(tmp=True, task_vars={})
    assert(result)

    # call run with tmp args
    result = module.run(tmp=None, task_vars={})
    assert(result)

    # call run with tmp args
    result = module.run(tmp=None, task_vars=dict())
    assert(result)

    # call run with tmp args

# Generated at 2022-06-21 03:03:24.946215
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action
    test = ansible.plugins.action.ActionModule(None, {}, None, None, None)
    test._templar = lambda x, y: x
    print(test.run())

# Generated at 2022-06-21 03:03:28.722360
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task={}, connection={}, play_context={}, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.name == 'set_stats'

# Generated at 2022-06-21 03:03:29.281985
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:03:48.956579
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    factory = AnsibleActionModuleFactory()

    action_module = factory.new(
        task=dict(action=dict(module='set_stats', args=dict(data=dict(a=1), per_host=True, aggregate=False))),
        connection=None,
        play_context=dict(check_mode=False),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module._task.args['data']['a'] == 1
    assert action_module._task.args['per_host'] == True
    assert action_module._task.args['aggregate'] == False

# Unit test to create ActionModule

# Generated at 2022-06-21 03:03:58.849840
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # run method tests
    # it requires a global variable named "control" to control the behaviour of any AnsibleModule instantiation
    # loads a `control` variable which is used to control the AnsibleModule instantiation
    # it is defined in testing/utils/__init__.py
    load_fixture('test_ActionModule_run')
    m = AnsibleModule(
        argument_spec = dict(
            aggregate = dict(required=False, default=True, type='bool'),
            data = dict(required=False, default=dict(), type='dict'),
            per_host = dict(required=False, default=False, type='bool')
        )
    )
    f = ActionModule(m, connection=DummyConnection())

    # run call tests
    assert f.TRANSFERS_FILES == False
    assert f._VALID_

# Generated at 2022-06-21 03:04:04.165848
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create object of class ActionModule
    module = ActionModule(load_plugin=False, task=dict(args={'data':{'key1':'value1', 'key2':'value2'}}), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Check parameters inherited from class ActionBase 
    assert module._connection is None
    assert module._play_context is None
    assert module._loader is None
    assert module._templar is None
    assert module._shared_loader_obj == []
    assert module._task.action == 'set_stats'
    assert module._task.args == {'data': {'key1': 'value1', 'key2': 'value2'}}
    assert module._task.action_loader is None
    assert module._task

# Generated at 2022-06-21 03:04:04.678079
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:04:05.213102
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-21 03:04:15.717528
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(load_fixture('set_stats.py', 'action_plugins'), task=dict(action=dict()), connection=dict())
    result = module.run()
    assert not result['failed']
    assert result['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True}
    result = module.run(task_vars=dict(foo='bar', item=dict(x='y')))
    assert result['ansible_stats'] == {'data': {'foo': 'bar', 'item': dict(x='y')}, 'aggregate': True, 'per_host': False}

# Generated at 2022-06-21 03:04:19.326079
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = dict(ansible_stats=dict(data={'a': 1}, per_host=False, aggregate=True))
    assert result == ActionModule.run(
        {}, {},
        dict(data={'a': 1}))


# Generated at 2022-06-21 03:04:23.322941
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for testing the run method of the ActionModule class
    """

    # Use above variables as arguments in the run method to test its functionality
    res = run(tmp, task_vars)

    # Test fail condition
    assert res['failed'] == True
    assert res['msg'] == "The 'data' option needs to be a dictionary/hash"

# Generated at 2022-06-21 03:04:25.828141
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    assert action_module.run(None, None) == {'failed': True, 'msg': 'invalid task or Handler, or missing required arguments'}

# Generated at 2022-06-21 03:04:36.250290
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor import playbook_executor
    sys.path.append('../')
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['ansible/tests/hosts'])
    variable_manager.set_inventory(inventory)
    pbex = playbook_executor.PlaybookExecutor(playbooks=['ansible/tests/test_set_stats.yml'], inventory=inventory, variable_manager=variable_manager, loader=loader)
    pbex.run()
    stats = pbex._t

# Generated at 2022-06-21 03:04:58.713846
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_action = ActionModule(None, None, None)
    assert test_action._VALID_ARGS is not None

# Generated at 2022-06-21 03:05:08.743661
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils import basic
    from ansible.plugins.action.set_stats import ActionModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    loader = DataLoader()
    variable_manager = VariableManager()
    stats = ActionModule(loader=loader, variable_manager=variable_manager)
    assert(stats._get_action_args() is None)
    assert(stats._task is None)
    assert(stats._loader is not None)
    assert(isinstance(stats._loader, DataLoader))
    assert(stats._templar is None)
    assert(stats._shared_loader_obj is None)
    assert(stats._connection is None)
    assert(stats._play_context is None)

# Generated at 2022-06-21 03:05:17.954411
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test for the run method of class ActionModule'''
    class TestAnsibleModule(object):
        def __init__(self):
            self.params = {}

        def fail_json(self, msg, **kwargs):
            self.result = 'failed'

        def exit_json(self, **kwargs):
            self.result = 'exit'

    class TestActionBase(ActionBase):
        TRANSFERS_FILES = False
        _VALID_ARGS = frozenset(('aggregate', 'data', 'per_host'))

        def __init__(self):
            self._task = TestTask()
            self._templar = TestTemplar()

    template = {'id': 1, 'name': 'test'}


# Generated at 2022-06-21 03:05:18.461878
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 03:05:24.085260
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest2 as unittest
    from ansible.module_utils.six import iteritems, string_types
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import isidentifier
    from ansible.utils.vars import merge_hash

    task_vars = {}

    result = {}
    result['failed'] = False
    result['changed'] = False
    result['ansible_stats'] = {}

    args = {}
    args['data'] = {}
    args['data']['a'] = 'a'
    args['data']['b'] = 'b'
    args['aggregate'] = False
    args['per_host'] = True
    args['c'] = 'c'



# Generated at 2022-06-21 03:05:25.461982
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None)
    assert isinstance(action, ActionBase)

# Generated at 2022-06-21 03:05:35.292633
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Unit test for method run of class ActionModule'''

    # Note: module_utils.six.iteritems not mocked, hence the use of `dict.items`.
    test_args = {
        'data': {
            'foo': 'bar',
            'baz': 'qux'
        },
        'aggregate': 'true',
        'per_host': True
    }

    stats = {
        'data': {},
        'per_host': False,
        'aggregate': True
    }
    for k, v in test_args['data'].items():
        stats['data'][k] = v

    stats['aggregate'] = boolean(test_args['aggregate'], strict=False)
    stats['per_host'] = test_args['per_host']

    action_module = ActionModule()

# Generated at 2022-06-21 03:05:44.244143
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import errors

    mock_task = type("mock_task", (object,), {
        "args": {'data': {}, 'per_host': False, 'aggregate': True}
        })()

    mock_loader = type("mock_loader", (object,), {})()
    mock_play_context = type("mock_play_context", (object,), {})()
    mock_new_tpl = type("mock_new_tpl", (object,), {
        "template": lambda self, x: x
        })()
    mock_all_vars = type("mock_all_vars", (object,), {
    })()

# Generated at 2022-06-21 03:05:46.907970
# Unit test for constructor of class ActionModule
def test_ActionModule():

    t = dict()
    t['task_vars'] = dict()

    action_module = ActionModule(dict(), t['task_vars'], False, '/tmp', 10, 10)
    action_module.run()

# Generated at 2022-06-21 03:05:54.866831
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = dict(
        ANSIBLE_MODULE_ARGS={'per_host': True, 'data': {'foo': 'bar'},
                             'aggregate': False},
    )
    am = ActionModule()

    with pytest.raises(AttributeError):
        am.run(result)

    result['task_vars'] = dict()
    del result['ANSIBLE_MODULE_ARGS']

    with pytest.raises(KeyError):
        am.run(result)

# Generated at 2022-06-21 03:06:42.050538
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class TestActionModule(ActionModule):
        def __init__(self):
            pass
        def run(self, tmp=None, task_vars=None):
            pass
    tmp = None
    task_vars = None
    setattr(TestActionModule, '_task', None)
    assert TestActionModule().run(tmp, task_vars) == {'failed': False, 'changed': False}
    setattr(TestActionModule, '_task', None)
    tmp = 'tmp'
    task_vars = 'task_vars'
    assert TestActionModule().run(tmp, task_vars) == {'failed': False, 'changed': False}


# Generated at 2022-06-21 03:06:43.210998
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert('ActionModule' in globals())
    assert(type(ActionModule) == type)

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-21 03:06:44.251867
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: Write unit test
    pass


# Generated at 2022-06-21 03:06:48.554610
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class FakeTask:
        name = 'fake_task'
        args = {'myindentifier': 23}
        action = 'fake_action'
        items = None
        registers = {}
        serial = 1
        vars = {}
        # unit test for Template class
        def __init__(self):
            self.result = None
            self.notified_handlers = []

    class FakeConnection:
        def __init__(self, host, port, user, passwd):
            self.host = host
            self.port = port
            self.user = user
            self.passwd = passwd

        def get_option(self, key):
            return True

    class FakePlayContext:
        def __init__(self):
            self.prompt = None


# Generated at 2022-06-21 03:06:56.343845
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass
#    actionModule = ActionModule()
#    tmp = None
#    
#    task_vars = dict(
#        ansible_stats=dict(
#            aggregate=True,
#            data=dict(
#                test_var1='test_value1',
#                test_var2='test_value2'
#            ),
#            per_host=False
#        ),
#        temp=dict(
#            aggregate=True,
#            data=dict(
#                test_var1='test_value1',
#                test_var2='test_value2'
#            ),
#            per_host=False
#        )
#    )
#    
#    result = actionModule.run(tmp, task_vars)
#    
#    assert isinstance(result, dict), 'Method

# Generated at 2022-06-21 03:06:58.606502
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, {'name': 'test', 'options': {}})
    assert action.__class__.__name__ == 'ActionModule'

# Generated at 2022-06-21 03:06:59.982003
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False



# Generated at 2022-06-21 03:07:00.746317
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True == False, 'Not implemented'

# Generated at 2022-06-21 03:07:08.673916
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils._text import to_bytes
    import json

    # Construct a mock for the TaskExecutor object
    class TaskExecutor(object):

        def __init__(self):
            self.vars = dict()
            self.args = dict()

    # Construct a mock for the Result object
    class Result(object):

        def __init__(self):
            self.result = dict()

    # Construct a mock for the AnsibleModule object
    import collections


# Generated at 2022-06-21 03:07:14.590094
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = dict()
    task['args'] = dict()
    task['vars'] = dict()
    task_vars = dict()
    am = ActionModule()
    am._templar = dict()
    am._templar['template'] = test_template
    #test 1: an empty stats argument is passed
    task['args'] = ''
    result = am.run(None, task_vars)
    assert result['ansible_stats']['data'] == {}
    assert result['ansible_stats']['per_host'] == False
    assert result['ansible_stats']['aggregate'] == True

    #test 2: check for valid input data in args
    task['args'] = 'data={a:b}'
    result = am.run(None, task_vars)

# Generated at 2022-06-21 03:09:14.474926
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert 'ActionModule' in globals()
    action_mod = globals()['ActionModule']
    assert action_mod
    assert isinstance(action_mod, type)
    assert issubclass(action_mod, ActionBase)
    assert hasattr(action_mod, 'run')

# Generated at 2022-06-21 03:09:16.884449
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Test constructor for class ActionModule and assert
    that ActionModule.action_loader is not none.
    """
    action = ActionModule(None, None, None)
    assert action.action_loader != None

# Generated at 2022-06-21 03:09:21.678198
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    action_module = ActionModule(module.params, module.connection)
    result = action_module.run(task_vars=None)
    assert result=={'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}, 'changed': False}

# Generated at 2022-06-21 03:09:29.568371
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # setup fake task_vars for the run() method of the ActionModule object.
    task_vars = None
    tmp = None

    # setup the object to be tested.
    actionModuleTest = ActionModule(None)

    # a successful test should return with a changed value of False,
    # and an ansible_stats value set in the returned data object.
    result = actionModuleTest.run(tmp, task_vars)
    assert result['changed'] == False
    assert result['ansible_stats']

    # a bogus data argument should return with a changed value of True,
    # and a msg value set in the returned data object.
    task_vars = {'data':'asdfasdf'}
    result = actionModuleTest.run(tmp, task_vars)
    assert result['changed'] == True
    assert result

# Generated at 2022-06-21 03:09:32.675265
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule(None, None, None)
    assert am.run(None, None) == {'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}, 'changed': False}

# Generated at 2022-06-21 03:09:42.196987
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader

    class AnsibleModule:
        def __init__(self):
            self.params = {}
            self._task = dict()
            self._task_vars = dict()
            self.params['aggregate'] = False
            self.params['data'] = {'hits': 5, 'version': '1.2.3'}
            self._task['args'] = self.params
            self.exit_json = dict()

    loader = DataLoader()

    task_args = dict()
    task_args['data'] = {'hits': 5, 'version': '1.2.3'}
    task = dict()
    task['args'] = task_args
    fake_task = dict()

# Generated at 2022-06-21 03:09:44.187415
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-21 03:09:51.807327
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()

    # To test ActionModule.run, we need a fake task having the required
    # attributes.
    class Task:
        def __init__(self, args):
            self.args = args

    # test with no args
    task = Task(None)
    actual = module.run(task_vars=None, task=task)
    expected = {
        'changed': False,
        'ansible_stats': {
            'aggregate': True,
            'data': {},
            'per_host': False
        }
    }
    assert actual == expected

    # test with args

# Generated at 2022-06-21 03:10:00.642036
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import mock
    import json
    import os
    import sys

    test_host_vars_path = os.path.join(os.path.dirname(__file__), 'host_vars_test.json')
    with open(test_host_vars_path) as host_vars_file:
        test_host_vars = json.load(host_vars_file)

    mock_play_context = mock.MagicMock()
    mock_task = mock.MagicMock()
    mock_task.args = {
        'data': {'var_1': 'value_1', 'var_2': 'value_2'},
        'per_host': False,
        'aggregate': True,
    }

    test_action_module = ActionModule()
    test_action_module._shared_loader

# Generated at 2022-06-21 03:10:01.443811
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)