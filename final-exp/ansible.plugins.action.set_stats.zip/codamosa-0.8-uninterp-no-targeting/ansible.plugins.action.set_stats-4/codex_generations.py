

# Generated at 2022-06-21 03:00:34.752682
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test for run() for ActionModule:
    #
    # Default options

    # Create a mock environment for the test
    mod_mock = ActionModule(None, None, None, None, None, None, None, None, None, None, None)
    mod_mock.runner = type("TestRunner", (object,), {'_create_tmp_path': lambda x,y: "/tmp/whatever"})()

    task_vars = {}
    with open("/tmp/whatever", "w") as tmp_file:
        tmp_file.write("")

    result = mod_mock.run("/tmp/whatever", task_vars)
    expected_result = {'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}, 'changed': False}
    assert result == expected_

# Generated at 2022-06-21 03:00:40.379807
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(load_fixture('test_action_set_stats.yml'),dict(ANSIBLE_MODULE_ARGS={'aggregate': True, 'data': {'foo': 'bar'}}), None, None)
    result = action.run()
    assert result is not None
    assert result['changed'] == False
    assert result['ansible_stats'] == {'data': {'foo': 'bar'}, 'per_host': False, 'aggregate': True}



# Generated at 2022-06-21 03:00:47.840956
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.set_stats
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    set_stats = ansible.plugins.action.set_stats.ActionModule(
        Task(),
        PlayContext(
            remote_addr='127.0.0.1',
            port=22,
            remote_user='',
            password=None,
            private_key_file='',
            connection='ssh',
            timeout=10,
            become=False,
            become_method='',
            become_user='',
            become_password=None,
            check=False
        )
    )

    result = set_stats._execute_module()
    assert result['failed'] is False
    assert result['changed'] is False

# Generated at 2022-06-21 03:00:48.601846
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Test the module, we are not testing the class here
    pass

# Generated at 2022-06-21 03:00:58.320518
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Testing for method run of class ActionModule
    """
    # set the stage for the test
    # create a test class object and set it up for test
    class ModuleTest(object):
        def __init__(self, args=None):
            self.args = args

    class TaskTest(object):
        def __init__(self, args=None):
            self.args = args

    class TaskVarsTest(object):
        def __init__(self, args=None):
            self.vars = args

    def run_test(args=None):
        """
        Test routine, provide args as input to be tested by the module run method
        :param args: arguments to be passed to templar.template()

        :return:
        """
        # create the testing objects, set them up for test
        module_test

# Generated at 2022-06-21 03:01:06.793447
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task

    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    import ansible.constants as C

    class MockPlayContext(PlayContext):
        def __init__(self, inventory=None, options=None):
            self.connection = 'local'
            self.network_os = 'default'

    class MockOptions(object):
        def __init__(self):
            self.module_path = C.DEFAULT_MODULE_PATH


# Generated at 2022-06-21 03:01:12.091421
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isidentifier('_')
    assert isidentifier('92')
    assert isidentifier('asdf1')
    assert isidentifier('qwertyuiop[]{};:"/?.>,<') is False
    assert isidentifier('5') is False
    assert isidentifier('^') is False

# Generated at 2022-06-21 03:01:20.062854
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class Task(object):
        def __init__(self):
            self.__args = {'data': {}, 'per_host': False, 'aggregate': True}

        def get_args(self):
            return self.__args

    task = Task()
    ActionModule.__init__(task)
    import pdb; pdb.set_trace()

# Generated at 2022-06-21 03:01:27.733409
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' unit testing for method run of class ActionModule '''

    # creating instance of class ActionModule
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # get a dictionary of mock data
    _task_vars = load_fixture('task_vars')
    _tmp = None

    # calling method run of class ActionModule with the above data
    result = action.run(tmp=_tmp, task_vars=_task_vars)

    # assert the return data
    assert result['ansible_stats']['aggregate'] == True
    assert result['ansible_stats']['per_host'] == False
    assert result['ansible_stats']['data']['key1'] == 'val1'

# Generated at 2022-06-21 03:01:33.193552
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    s = dict(
        STATS = dict(
            changed = False,
            ansible_stats = dict(
                aggregate = True,
                data = dict(
                    foo = 'abc',
                    bar = 123
                ),
                per_host = False
            )
        )
    )

    actionModule = ActionModule()
    assert actionModule.run(s) == s["STATS"]

# Generated at 2022-06-21 03:01:39.999246
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule()
    assert mod.run() == {'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}, 'changed': False}

# Generated at 2022-06-21 03:01:41.251157
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule, object)

# Generated at 2022-06-21 03:01:43.908090
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule()

    module_args = {'data': {'foo': '{{ ansible_hostname }}', 'bar': '{{ ansible_memtotal_mb }}', 'baz': '{{ 2 + 3 }}'}}
    result = m.run(None, {'ansible_hostname': 'localhost', 'ansible_memtotal_mb': 4096})
    print(result)


# Generated at 2022-06-21 03:01:47.602434
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.modules.system.set_stats
    assert issubclass(ansible.modules.system.set_stats.ActionModule, ActionModule)

# Generated at 2022-06-21 03:01:55.906644
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager

    task = Task()
    play_context = PlayContext()
    my_inventory = InventoryManager(play_context, '/root/ansible/inventory')

    action_module = ActionModule(task, play_context, my_inventory, loader, templar, shared_loader_obj)

    assert isinstance(action_module, ActionModule)
    assert action_module._shared_loader_obj == shared_loader_obj
    assert action_module._task == task
    assert action_module._play_context == play_context
    assert action_module._loader == loader
    assert action_module._templar == templar
    assert action_module._inventory == my_inventory


#

# Generated at 2022-06-21 03:02:01.731920
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # call function with test data
    x = ActionModule()

    # check if result is as expected
    assert x._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))
    assert x.TRANSFERS_FILES == False

# Generated at 2022-06-21 03:02:02.756335
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule()
    assert obj.run(None, None) is not None

# Generated at 2022-06-21 03:02:03.292054
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:02:05.682599
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None)
    assert ActionModule._VALID_ARGS == action._VALID_ARGS
    

# Unit tests for run method of class ActionModule

# Generated at 2022-06-21 03:02:07.577353
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing constructor of class ActionModule")
    assert True

# Generated at 2022-06-21 03:02:22.822670
# Unit test for constructor of class ActionModule
def test_ActionModule():
	module = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())

	assert module.TRANSFERS_FILES == False
	assert module._VALID_ARGS == frozenset(['aggregate', 'per_host', 'data'])

# Generated at 2022-06-21 03:02:33.263396
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = dict(args=dict(per_host=True, aggregate=False, data=dict(key1='value1', key2='value2')))
    action = ActionModule(task, dict())

    # Test the class constructor
    assert isinstance(action, ActionModule)
    assert action.TRANSFERS_FILES is False
    assert action._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))
    assert action._task == task
    assert action._connection is None
    assert action._play_context is None

    # Test the class run method
    tmp = None
    task_vars = {}
    result = action.run(tmp, task_vars)

    assert 'ansible_stats' in result
    assert len(result['ansible_stats']) == 3
    assert result

# Generated at 2022-06-21 03:02:35.195681
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO
    pass

# Generated at 2022-06-21 03:02:36.954574
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # test for the success case
    module = ActionModule()
    module.run(None, None)

# Generated at 2022-06-21 03:02:44.857127
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # we need to create an ActionModule object before we can run any tests on it
    # the data in the test_data container is a dictionary with key "data" that contains a dictionary of key value pairs

    # initialize the test_data container
    test_data = {"test": "insert"}

    # initialize the test_result container
    test_result = {'data': {}, 'per_host': False, 'aggregate': True}

    # initialize the test_task container
    test_task = {'args': test_data}

    # create the ActionModule object
    test_action = ActionModule(self=test_data, task=test_task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert(test_action.run() == test_result)

    # initialize

# Generated at 2022-06-21 03:02:47.581342
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None) is not None


# Generated at 2022-06-21 03:02:57.691723
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = AnsibleModule(
        argument_spec={
            'test_param': {'type':'str'}
        },
        supports_check_mode=False
    )
    # TODO: add this line below in the code
    #class ActionModule(MyActionPlugin):
    am = ActionModule()

    # test 1
    tmp = None

# Generated at 2022-06-21 03:03:01.070909
# Unit test for constructor of class ActionModule
def test_ActionModule():
    hostvars = dict()
    a = ActionModule(None, hostvars)
    assert a is not None

# Generated at 2022-06-21 03:03:03.157501
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor of class action module
    action_module = ActionModule()
    # Print object
    print(action_module)


# Generated at 2022-06-21 03:03:06.429721
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action.__class__.__name__ == 'ActionModule'

# Generated at 2022-06-21 03:03:31.384156
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(per_host=True, aggregate=True)),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert action_module

# Generated at 2022-06-21 03:03:36.729543
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule_instance = ActionModule(task=dict(action=dict(module_name='set_stats')), connection=None, play_context=None, loader=None,
                                         templar=None, shared_loader_obj=None)
    assert isinstance(actionmodule_instance._VALID_ARGS, frozenset)
    assert actionmodule_instance._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-21 03:03:43.500016
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import _boolean_states
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.collections import ImmutableDict

    # Build a task argument from a hash with the minimum required fields
    task_arg = {'data': {'sample_var': 12}, 'per_host': False, 'aggregate': True}

    # Build a fake AnsibleTask object
    class AnsibleTask:
        def __init__(self):
            self.args = task_arg

    fake_task = AnsibleTask()

    # Build a fake AnsibleModule object
    class FakeAnsibleModule:
        def __init__(self):
            self.params = ImmutableDict()

    fake_ansible_module = FakeAns

# Generated at 2022-06-21 03:03:54.268890
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.dict_transformations import dict_copy

    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.dataloader import DataLoader

    from ansible.plugins.action import ActionBase

    from ansible.utils.vars import merge_hash
    from ansible.vars import VariableManager

    from ansible.inventory.manager import InventoryManager

    from ansible.compat.tests import unittest

    class TestActionModule(ActionModule):
        _VALID_ARGS = frozenset(('data', 'per_host', 'aggregate'))


    class TestActionBase(ActionBase):
        TRANSFERS_FILES = False


# Generated at 2022-06-21 03:04:03.105653
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class Task:

        def __init__(self, args):
            self.args = args

        def __getattr__(self, attr):
            return None

    test_inputs = []

    # both arguments are strings
    args = dict(data='{ "test_var1": 123, "test_var2": "test" }', aggregate=True, per_host=True)
    exp_output = dict(changed=False, ansible_stats=dict(data=dict(test_var1=123, test_var2='test'), aggregate=True, per_host=True))
    test_inputs.append((args, exp_output))

    # one string and one integer
    args = dict(data='{ "test_var1": 123, "test_var2": 2 }', aggregate=True, per_host=True)


# Generated at 2022-06-21 03:04:12.850417
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock
    from ansible.module_utils.parsing.convert_bool import boolean

    class TestActionModule(ActionBase):
        TRANSFERS_FILES = False
        _VALID_ARGS = frozenset(('aggregate', 'data', 'per_host'))
        def run(self, tmp=None, task_vars=None):
            return super(TestActionModule, self).run(tmp, task_vars)

    class TestActionModuleCase(unittest.TestCase):
        _task_vars = dict()
        _task_name = "test_task"
        _task_args_data_value = dict(one=1, two=2, three=3)


# Generated at 2022-06-21 03:04:15.841044
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class MockTask:
        def __init__(self):
            self.args = {}
    task = MockTask()
    ActionModule(task, {}).run(tmp=None, task_vars=None)

# Generated at 2022-06-21 03:04:24.574281
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionModule
    action = ActionModule(
        task=dict(
            action=dict(
                module_name='set_stats'
            ),
            args=dict(
                aggregate=False,
                data=dict(
                    foo='bar'
                )
            )
        ),
        connection=dict(
            transport='ssh'
        ),
        play_context=dict()
    )
    action.validate()
    assert isinstance(action._task.args, dict)
    assert isinstance(action._task.args.get('aggregate', None), bool)
    assert isinstance(action._task.args.get('data', None), dict)
    assert isinstance(action._task.args.get('data').get('foo', None), string_types)

# Generated at 2022-06-21 03:04:26.972714
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test if '_valid_args' is declared as class variable
    assert '_valid_args' in str(ActionModule.__dict__)



# Generated at 2022-06-21 03:04:37.050761
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up mock input
    test_module = ActionModule()
    test_module._task = mock.MagicMock()
    test_module._task.args = {'data': {'12.34': 'testing'}}
    test_module._task.args['data'] = {'12.34': "{{ansible_env['USER']}}"}
    test_module._templar = mock.MagicMock()
    test_module._templar.template = mock.MagicMock(return_value=12.34)
    test_module._templar.template = mock.MagicMock()
    test_module._templar.template = mock.MagicMock()
    test_module._templar.template = mock.MagicMock()
    test_module._templar.template = mock.MagicMock()
   

# Generated at 2022-06-21 03:05:26.770562
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule(
        task=dict(
            action=dict(
                data=dict(
                    var="{{ playbook_dir }}/inventory/group_vars/all",
                    test_data=dict(
                        test=True,
                        test2=False
                    )
                )
            )
        ),
        connection=dict(
            play_context=dict(
                check_mode=True
            )
        )
    )
    result = mod.run(task_vars={"playbook_dir": "."}, tmp="")
    assert result['ansible_stats']['data'] == {'var': './inventory/group_vars/all', 'test_data': {'test': True, 'test2': False}}

# Generated at 2022-06-21 03:05:38.124888
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # !! These must be kept in sync with the real action plugin !!
    from ansible.plugins.action.set_stats import ActionModule
    from ansible.plugins import module_loader

    module_loader.add_directory('./lib')

    mock_action = ActionModule(None, None, None, None, None, None, None, None)

    # Construct a mock task.args. This is not a real task.
    task_args = {}
    task_args['data'] = {'foo': 'bar'}

    # Construct a mock task_vars structure.
    task_vars = {}
    task_vars['ag_fact'] = 'baz'

    # This should NOT fail.
    result = mock_action._execute_module(None, task_args, task_vars, False, None, None, None)

   

# Generated at 2022-06-21 03:05:40.024529
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None)
    assert action.TRANSFERS_FILES == False
    assert action._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))


# Generated at 2022-06-21 03:05:47.623730
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.set_stats import ActionModule

    def test_run(self, tmp=None, task_vars=None):
        if task_vars is None:
            task_vars = dict()

        result = super(ActionModule, self).run(tmp, task_vars)
        del tmp  # tmp no longer has any effect

        stats = {'data': {}, 'per_host': False, 'aggregate': True}

        if self._task.args:
            data = self._task.args.get('data', {})

            if not isinstance(data, dict):
                data = self._templar.template(data, convert_bare=False, fail_on_undefined=True)

            if not isinstance(data, dict):
                result['failed'] = True
                result['msg']

# Generated at 2022-06-21 03:05:51.935470
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    result = module.run()

    assert result == {
       "ansible_stats": {
          "aggregate": True,
          "data": {},
          "per_host": False
       },
       "changed": False
    }

# Generated at 2022-06-21 03:05:55.427485
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule('set_stats', {'data':{'foo':'bar'}})
    res = module.run(None, {})

# Generated at 2022-06-21 03:05:56.315627
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# Generated at 2022-06-21 03:06:04.338429
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.facts import ansible_module

    # test ActionBase.__init__()
    a = ActionModule()
    m = ansible_module(0, '/tmp/action_module.py')
    a._shared_loader_obj = m._shared_loader_obj
    a._templar = m._templar
    a._task.args = {'aggregate': 'yes', 'data': {'a': 1}, 'per_host': 'yes'}
    a._task.action = 'set_stats'
    r = a.run()
    assert r['ansible_stats']['per_host'] == True
    assert r['ansible_stats']['aggregate'] == True
    assert r['ansible_stats']['data']['a'] == 1

# Generated at 2022-06-21 03:06:14.164107
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.playbook.play_context
    import ansible.template
    import ansible.vars

    mock_task = MagicMock()
    mock_templar = MagicMock(spec=ansible.template.Templar)
    mock_play_context = ansible.playbook.play_context.PlayContext()
    mock_play_context._templar = mock_templar

    action = ActionModule(mock_task, mock_play_context)

    expected_result = {
        'ansible_stats': {
            'aggregate': True,
            'data': {
                'test_key': 'test_value'
            },
            'per_host': False
        },
        'changed': False
    }


# Generated at 2022-06-21 03:06:14.848856
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 03:08:08.424293
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule._VALID_ARGS == frozenset(['aggregate', 'data', 'per_host'])
    assert ActionModule.TRANSFERS_FILES == False

# Generated at 2022-06-21 03:08:08.872426
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:08:09.518974
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-21 03:08:18.886706
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class MockTask:
        def __init__(self):
            self.args = {}

    class MockTemplar:
        def template(self, arg, convert_bare=False, fail_on_undefined=True):
            if isinstance(arg, bool):
                return arg
            return str(arg)

    class MockPlayContext:
        def __init__(self):
            pass

    class Mock_load_file_common_argument_spec:
        def __init__(self):
            pass

    action_module = ActionModule()
    action_module._templar = MockTemplar()
    action_module._task = MockTask()
    action_module._play_context = MockPlayContext()
    action_module._load_file_common_argument_spec = Mock_load_file_common_argument_spec()
   

# Generated at 2022-06-21 03:08:27.391876
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test parameter `tmp`
    tmp = None

    # Test parameter `task_vars`
    task_vars = dict()

    r = ActionModule.run(tmp, task_vars)
    assert isinstance(r, dict)
    assert r['failed'] is False
    assert r['changed'] is False
    assert isinstance(r['ansible_stats'], dict)
    assert isinstance(r['ansible_stats']['data'], dict)
    assert isinstance(r['ansible_stats']['per_host'], bool)
    assert r['ansible_stats']['per_host'] is False
    assert isinstance(r['ansible_stats']['aggregate'], bool)
    assert r['ansible_stats']['aggregate'] is True

# Generated at 2022-06-21 03:08:35.255748
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Given
    task_vars = dict()
    module = ActionModule(None, None, None)
    module._task = FakeTask({
        'args': {
            'data': {
                'foo': '{{ foo }}',
                'bar': '{{ bar }}'
            },
            'per_host': 'True',
            'aggregate': 'False'
        }
    })
    module._templar = FakeTemplar({
        'foo': 'foo_value',
        'bar': 'bar_value',
        'True': True,
        'False': False
    })

    # When
    result = module.run(task_vars)

    # Then

# Generated at 2022-06-21 03:08:39.917159
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader(), sources=['localhost'])
    task = Task()
    role = Role()

    am = ActionModule(task, inventory, loader=DataLoader())
    assert am

# Generated at 2022-06-21 03:08:44.013493
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(task=dict(action=dict(set_stats=dict(data=dict()))))
    assert am.transfers_files is False
    assert am._valid_args == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-21 03:08:45.750457
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule._VALID_ARGS == frozenset(['aggregate', 'data', 'per_host']), "Test for constructor of class ActionModule failed"


# Generated at 2022-06-21 03:08:46.188596
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True