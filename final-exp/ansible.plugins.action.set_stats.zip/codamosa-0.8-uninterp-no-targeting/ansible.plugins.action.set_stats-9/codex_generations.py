

# Generated at 2022-06-21 03:00:28.092449
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(Task())
    res = action.run("test", "test")
    assert res["failed"]==True

test_ActionModule_run()

# Generated at 2022-06-21 03:00:38.746024
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set return value of templar.template()
    templar_template_return_value = {}

    # Set the return value of templar.template() to a fixed value
    templar_template = lambda self, key, convert_bare, fail_on_undefined: templar_template_return_value

    # Set the side-effect of templar.template()
    def side_effect_templar_template(self, key, convert_bare, fail_on_undefined):
        if key == 'per_host':
            templar_template_return_value = 'True'
        elif key == 'aggregate':
            templar_template_return_value = 'True'

# Generated at 2022-06-21 03:00:39.781176
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:00:40.976110
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule(None, None)
    assert not x

# Generated at 2022-06-21 03:00:48.248605
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # set up parameters for test
    result_expected = {'changed': False,
                       'ansible_stats': {'data': {'a': 26, 'b': 42}, 'per_host': False, 'aggregate': True}}
    # set up task to run with play context
    task_vars = dict(a=26, b=42)
    tmp = None
    task = dict(args={'data': dict(a='{{ a }}', b='{{ b }}')})
    play_context = dict()

    # run the action task
    am = ActionModule()
    result = am.run(tmp, task_vars=task_vars, task=task, play_context=play_context)

    # compare results
    assert result['changed'] == result_expected['changed']
    assert result['ansible_stats'] == result

# Generated at 2022-06-21 03:00:56.405303
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.utils.vars import isidentifier

    assert isidentifier("test_var", False) is True
    assert isidentifier("test-var", False) is False
    assert isidentifier("test var", False) is False

    assert boolean("true", strict=False) is True
    assert boolean("false", strict=False) is False
    assert boolean("yes", strict=False) is True
    assert boolean("no", strict=False) is False
    assert boolean("on", strict=False) is True
    assert boolean("off", strict=False) is False
    assert boolean("1", strict=False) is True
    assert boolean("0", strict=False) is False


# Generated at 2022-06-21 03:00:57.846810
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #assert ActionModule().run() is None
    assert False

# Generated at 2022-06-21 03:01:06.659531
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json
    import ansible.plugins.action.set_stats
    m_ActionModule = ansible.plugins.action.set_stats.ActionModule
    test_parameters = {'arg1':'test_value1', 'arg2':'test_value2'}
    m_ActionBase = ansible.plugins.action.ActionBase
    m_ActionBase.__init__ = lambda x, y: None
    m_ActionModule._task = dict()

    def test_run(self, tmp, task_vars):
        return {'rc': 0}

    m_ActionModule.run = test_run
    m_ActionModule._task.args = test_parameters
    m_ActionModule_instance = m_ActionModule()
    result = m_ActionModule_instance.run()

    assert 'ansible_stats' in result

# Generated at 2022-06-21 03:01:07.915202
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=dict(action=dict()), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())

# Generated at 2022-06-21 03:01:18.172858
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # pylint: disable=no-self-use,unused-argument,protected-access
    # pylint: disable=too-many-arguments,too-many-statements,redefined-outer-name
    from ansible.plugins.loader import action_loader

    class MockLoader():
        class MockAction():
            _task = type('MockTask', (object,), {'args': {}})
            _templar = type('MockTemplar', (object,),
                            {'template': lambda self, input: input,
                             'template_ds': lambda self, input: input})

            _VALID_ARGS = frozenset(('aggregate', 'data', 'per_host'))

            def __init__(self, *args, **kwargs):
                pass


# Generated at 2022-06-21 03:01:26.093493
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_self = []
    ActionModule.__init__(mock_self)
    assert mock_self._name == 'set_stats'

# Generated at 2022-06-21 03:01:28.433485
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: code test for run method of ActionModule
    pass

# Generated at 2022-06-21 03:01:38.038960
# Unit test for constructor of class ActionModule
def test_ActionModule():

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_context import PlayContext
    from ansible.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    def get_host_ip_dict(hosts):
        return dict((host.name, host.vars['ansible_ssh_host']) for host in hosts)

    loader = DataLoader()
    play_context = PlayContext()
   

# Generated at 2022-06-21 03:01:38.889921
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 03:01:47.261103
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create mock object for the global variables
    mock_module_utils = type('', (), {})()
    mock_module_utils.boolean = boolean
    mock_module_utils.isidentifier = isidentifier
    mock_module_utils.ActionBase = ActionBase
    mock_module_utils.string_types = string_types
    import ansible.module_utils.six as six
    six.iteritems = iteritems
    # Mock of the AnsibleModule class
    mock_AnsibleModule = type('AnsibleModule', (), {})
    mock_AnsibleModule.__init__ = lambda self, argument_spec, bypass_checks: None
    mock_AnsibleModule.fail_json = lambda self, msg: None
    # Create class instance

# Generated at 2022-06-21 03:01:55.419212
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule()
    result = m.run(tmp=None, task_vars={})
    assert result['ansible_stats'] == {'aggregate': True, 'data': {}, 'per_host': False}

    result = m.run(tmp=None, task_vars={'var': 'value'})
    assert result['ansible_stats'] == {'aggregate': True, 'data': {'var': 'value'}, 'per_host': False}

    result = m.run(
        tmp=None, task_vars={'var': 'value'},
        args={'data': {'var': '{{ var }}', 'other': 'other'}, 'per_host': '{{ test }}', 'aggregate': '{{ test }}'}
    )

# Generated at 2022-06-21 03:02:02.878427
# Unit test for constructor of class ActionModule
def test_ActionModule():
    d = dict(ansible_facts=dict(a='b'), ansible_variables=dict(a='b'))
    module = ActionModule('a', 'b', d)
    assert module.name == 'a'
    assert module.action == 'b'
    assert module.args == d
    assert module.job_vars_cache == dict()
    assert module.runner_cache == dict()


# Generated at 2022-06-21 03:02:09.359525
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()  # type: ActionModule
    module._connection = MockConnection()
    module._loader = MockLoader()
    module._task = MockTask()
    module._task.args = dict()
    module._task.args['data'] = dict()
    module._task.args['data']['foo'] = 'bar'
    module._task.args['data']['baz'] = '{{ test }}'
    module._task.args['per_host'] = True
    module._task.args['aggregate'] = False
    module._templar = Templar(loader=module._loader, variables={'test': 'foobar'})
    result = module.run(tmp='/tmp/', task_vars={})

    assert(result['ansible_stats']['data']['foo'] == 'bar')


# Generated at 2022-06-21 03:02:11.566116
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action.run(TaskVars) == {'data': {}, 'per_host': False, 'aggregate': True}

# Generated at 2022-06-21 03:02:13.642554
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule()
    res = m.run({})
    # TODO Write some tests
    #assert res == expected_res

# Generated at 2022-06-21 03:02:30.896436
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(
        {
            'task': {
                'args': {
                    'data': {'a': 1, 'b': 2},
                    'per_host': True,
                    'aggregate': False
                }
            }
        },
        {}
    )
    assert {'task': {'args': {'data': {'a': 1, 'b': 2}, 'per_host': True, 'aggregate': False}}} == a._task
    assert {} == a._loader
    assert {} == a._templar


# Generated at 2022-06-21 03:02:39.158494
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # This assertion would fail if the module was not properly loaded
    assert 'ActionModule' in globals()

    # Create base class object
    action_module = ActionModule(None, None)

    # Create test data

# Generated at 2022-06-21 03:02:39.625451
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-21 03:02:50.050882
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        {'delegate_to': None, 'no_log': False, 'action': 'set_stats',
         'args': {'data': {'test': 'string', 'test2': 1234, 'test3': 3.142}, 'aggregate': True, 'per_host': True}},
        task='/tmp/ansible_test/test.yml', task_vars={}, connection=None, play_context=None
    )

    assert isinstance(action.task_vars, dict)
    assert action.task == '/tmp/ansible_test/test.yml'
    assert action.task_vars == {}
    assert action.noop == False
    assert isinstance(action.connection, object)
    assert isinstance(action.play_context, object)
    assert action.de

# Generated at 2022-06-21 03:02:59.698409
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_result import TaskResult
    test_task = type('', (object,), dict(action=dict(name='foo'), async_val=10, delegate_to='test'))
    test_task = type('task', (object,), {'action': {'name': 'foo'}, 'async_val': 10, 'delegate_to': 'test'})
    test_play = type('', (object,), dict(hosts='hosts', tasks=list([test_task])))
    test_loader=type('', (object,), dict(path_finders=type('', (object,), dict(module_loader='mod_loader'))))
    test_tmplnr=type('', (object,), dict(template='template', environment='env'))

# Generated at 2022-06-21 03:03:04.270502
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = dict(action=dict(module='set_stats'))
    action = ActionModule(task, dict())
    assert action.TRANSFERS_FILES is False
    assert action._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))


# Generated at 2022-06-21 03:03:10.548350
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # mock task_vars so we dont need to call real ansible
    mock_task_vars = {'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}}
    mock_task = {'args': {'data': {'foo': 3}}}
    am = ActionModule(mock_task, mock_task_vars)
    result = am.run(tmp=None, task_vars=mock_task_vars)
    print(result)
    assert result['ansible_stats']['data']['foo'] == 3


# Generated at 2022-06-21 03:03:14.884611
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Tests that `ActionModule` class constructor does not throw exceptions.
    """
    task_vars = dict()
    task_vars['test_var'] = 0
    action = ActionModule(None, None, task_vars, None, None)
    assert action is not None

# Generated at 2022-06-21 03:03:22.644694
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import json
    import os
    import tempfile
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from io import StringIO

    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    loader = DataLoader()
    results_callback = lambda self: None

    class Task:
        def __init__(self, args=None):
            self.args = args

    context = PlayContext()
    templar = Templar(loader=loader, variables=dict())


# Generated at 2022-06-21 03:03:33.326640
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = ActionModule.run(tmp=None, task_vars=None)
    assert result['failed'] == False
    assert result['changed'] == False
    assert result['ansible_stats']['data'] == {}
    assert result['ansible_stats']['per_host'] == False
    assert result['ansible_stats']['aggregate'] == True

    task_vars = {'test_task_vars': 'test_task_vars'}
    result = ActionModule.run(tmp=None, task_vars=task_vars)
    assert result['failed'] == False
    assert result['changed'] == False
    assert result['ansible_stats']['data'] == {}
    assert result['ansible_stats']['per_host'] == False

# Generated at 2022-06-21 03:04:02.379922
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test class instantiation
    action_module = ActionModule(None, None, None, None)
    assert action_module is not None

    # Test run method using test data
    tmp = None
    task_vars = {"test_var": "value1", "param1": "value2"}
    result = action_module.run(tmp, task_vars)
    
    # Test result
    assert not result['changed']
    assert result['failed'] == False
    assert result['ansible_stats'] != None

    # Test run method using test data
    tmp = None
    task_vars = {"test_var": "value1", "param1": "value2"}
    result = action_module.run(tmp, task_vars)
    
    # Test result
    assert not result['changed']

# Generated at 2022-06-21 03:04:08.212804
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook import Play
    import ansible.inventory.host
    import ansible.inventory.group
    import ansible.vars.manager
    import ansible.vars.hostvars
    import ansible.vars.vars
    import ansible.module_utils.facts.core

    import doctest
    import collections

    # used to generate a non-empty task_vars to pass to Task.run
    task_vars_dict = collections.namedtuple('ansible_vars', ['hostvars', 'vars'])

# Generated at 2022-06-21 03:04:08.752974
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-21 03:04:19.781135
# Unit test for constructor of class ActionModule
def test_ActionModule():
    config = {'ANSIBLE TEST': 'test'}
    task_vars = {
        'test': 'test'
    }
    tmp = '/path/to/playbook'
    task = {
        'per_host': 'perhost',
        'aggregate': 'aggregate',
        'data': 'data'
    }
    task_ds = {
        'action': 'test_ActionModule',
        'per_host': False,
        'aggregate': True,
        'data': {'foo': 'bar'},
        'args': task
    }
    am = ActionModule(task, task_ds, tmp, config, task_vars)
    assert am.task == task
    assert am.task_ds == task_ds
    assert am.tmp == tmp
    assert am.config == config

# Generated at 2022-06-21 03:04:21.084810
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert isinstance(module, ActionBase)


# Generated at 2022-06-21 03:04:29.914775
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class FakeSelf():
        class FakeTemplar():
            def template(self, data, **kwargs):
                return data

        _templar = FakeTemplar()

    class FakeTask():
        class FakeArgs(dict):
            def get(self, key, default=None):
                return self[key]

        args = FakeArgs()

    fake_self = FakeSelf()
    fake_self._task = FakeTask()
    fake_task_vars = {}

    fake_self._task.args['data'] = {'var1': 'val1', 'var2': 'val2'}
    fake_self._task.args['per_host'] = 'True'
    result = ActionModule.run(fake_self, None, fake_task_vars)
    assert result['changed'] == False

# Generated at 2022-06-21 03:04:32.817155
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule('task', 'play')
    assert am.TRANSFERS_FILES == False
    assert am._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-21 03:04:36.571044
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()

    assert isinstance(am._VALID_ARGS, frozenset)
    assert am._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))
    assert am.TRANSFERS_FILES == False

# Generated at 2022-06-21 03:04:43.885539
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    templar = Dict({'_fail_on_undefined_errors': False, '_hostname': 'hostname', '_use_contingency_plan': True})

    test_data = [
        ('{{_hostname}}', 'hostname'),
        (5, 5),
        (True, True),
        ('{{_fail_on_undefined_errors}}', False),
        ('{{_use_contingency_plan}}', True),
    ]

    for template, result in test_data:
        assert templar.template(template, convert_bare=False, fail_on_undefined=True) == result

# Generated at 2022-06-21 03:04:48.174215
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module.TRANSFERS_FILES == False
    assert module._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))


# Generated at 2022-06-21 03:05:41.697769
# Unit test for constructor of class ActionModule
def test_ActionModule():
   obj = ActionModule(None, None, '/usr/bin', 'fake_action_name', 'fake_args')
   assert obj._shared_loader_obj == None
   assert obj._action == 'fake_action_name'
   assert obj._task == None
   assert obj._connection == None
   assert obj._play_context == None
   assert obj._loader == None
   assert obj._templar == None
   assert obj._task_vars == None




# Generated at 2022-06-21 03:05:47.990364
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(task=dict(), connection=None, play_context=dict(), loader=dict(path_loader=dict()), templar=dict(), shared_loader_obj=None)
    assert action_module.run(tmp=None, task_vars=dict(ansible_stats=dict())) == dict(changed=False, ansible_stats=dict(data=dict(), per_host=False, aggregate=True))
    assert action_module.run(tmp=None, task_vars=dict(ansible_stats=dict(data=dict(), per_host=False, aggregate=True))) == dict(changed=False, ansible_stats=dict(data=dict(), per_host=False, aggregate=True))

# Generated at 2022-06-21 03:05:49.989243
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(None, None, None, None, None), ActionModule)


# Generated at 2022-06-21 03:06:00.004276
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 03:06:08.017303
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action as action
    from ansible.plugins.action.set_stats import ActionModule as module
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    import platform
    import json

    # init objects
    task = action.load_action_plugin(module.__name__, {})
    module._templar.available_variables = {}
    task = module(task, {})
    task._task = type('task', (object,), {})
    task._task.action = ''
    task._task.loop = ''
    task._task.args = type('task_args', (object,), {})

# Generated at 2022-06-21 03:06:15.803900
# Unit test for constructor of class ActionModule
def test_ActionModule():

    a = ActionModule(None, {}, task_vars=dict())
    a._templar = MockTemplar()

    assert a.run(task_vars=dict()) == {
        'ansible_stats': {'data': {}, 'aggregate': True, 'per_host': False},
        'changed': False,
    }

    a = ActionModule(None, {'data': 'test'}, task_vars={'test': {'foo': 'bar'}})
    a._templar = MockTemplar()

    assert a.run(task_vars={'test': {'foo': 'bar'}}) == {
        'ansible_stats': {'data': {'foo': 'bar'}, 'aggregate': True, 'per_host': False},
        'changed': False,
    }

# Generated at 2022-06-21 03:06:26.106617
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize member variables
    mod = ActionModule()
    mod._task = None
    mod._connection = None
    mod._play_context = None
    mod._loader = None
    mod._templar = None
    mod._shared_loader_obj = None
    mod._action = None
    mod._task_vars = None
    mod._start_at_task = None
    mod.noop_on_check(False)
    mod._diff = None
    mod._always_run = None
    mod._handlers = None
    mod._notify = None
    # Call function to test
    result = mod.run()
    # Verify the results
    assert(mod._task is None)
    assert(mod._connection is None)
    assert(mod._play_context is None)
    assert(mod._loader is None)

# Generated at 2022-06-21 03:06:35.804352
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule({'data': {'test_var': 'test_value'}, 'per_host': False, 'aggregate': True})
    result = action.run(task_vars=dict())
    assert result['ansible_stats']['data'] == {'test_var': 'test_value'}
    assert result['ansible_stats']['per_host'] == False
    assert result['ansible_stats']['aggregate'] == True
    action = ActionModule({'data': {'test_var': 'test_value'}})
    result = action.run(task_vars=dict())
    assert result['ansible_stats']['data'] == {'test_var': 'test_value'}
    assert result['ansible_stats']['per_host'] == False

# Generated at 2022-06-21 03:06:43.562797
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Construct a dict representation of a TaskResult object
    taskresult_dict =  {
            '_result': {'changed': False,
                        'ansible_stats': {'data': {'test-var': 'test-value'},
                                          'per_host': False,
                                          'aggregate': True}},
            '_task': {'action': 'set_stats',
                      'version': 2,
                      'args': {'data': {'test-var': 'test-value'}}},
            '_play_context': {},
            '_loader': None,
            '_templar': None,
            '_shared_loader_obj': None,
            '_task_vars': {}
            }

    taskresult_obj = ActionBase._task_vars_from_dict(taskresult_dict)

# Generated at 2022-06-21 03:06:44.382945
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a is not None


# Generated at 2022-06-21 03:08:54.867947
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.playbook.play
    import ansible.playbook.task_include
    import ansible.playbook.task
    import ansible.playbook.block
    import ansible.playbook.role
    import ansible.playbook.handler_task_include
    p = ansible.playbook.play.Play()
    t = ansible.playbook.task.Task()
    i = ansible.playbook.task_include.TaskInclude()
    b = ansible.playbook.block.Block()
    r = ansible.playbook.role.Role()
    h = ansible.playbook.handler_task_include.HandlerTaskInclude()

    # test action module constructor with play
    assert isinstance(ActionModule(p, {}, False)._play, ansible.playbook.play.Play)

   

# Generated at 2022-06-21 03:09:02.412694
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    
    from ansible.parsing.yaml.constructor import AnsibleConstructor

    task_vars = dict()

    action_module = ActionModule(task=Task(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action_module.run(tmp=None, task_vars=task_vars)

    test_result = {
        u'ansible_stats': {
            u'aggregate': True,
            u'data': {},
            u'per_host': False
        },
        u'changed': False
    }
    assert result == test_result

# Generated at 2022-06-21 03:09:09.678521
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = dict(
        action=dict(
            args=dict(
                aggregate=True,
                per_host=False,
                data=dict(
                    somestats='somevalue'
                )
            ),
            module='set_stats',
            name='Stats Module'
        ),
        play=dict(
            id='someplayid',
            name='Somename',
            complex_args=dict()
        )
    )
    module_args = dict(
        aggregate=True,
        per_host=False,
        data=dict(
            somestats='somevalue'
        )
    )

# Generated at 2022-06-21 03:09:13.372261
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Test case for action module"""
    action = ActionModule({},{},{})
    assert action.TRANSFERS_FILES == False
    assert action._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))


# Generated at 2022-06-21 03:09:16.127253
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()

    assert action.TRANSFERS_FILES == False
    assert action._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))


# Generated at 2022-06-21 03:09:24.336841
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager

    task_vars = dict(per_host=False, aggregate=True)
    hostvars = dict(all=dict(children=dict(child1=dict(), child2=dict()),
                             siblings=dict(),
                             myself={'hostname': 'host1'}))

    class MyModule(object):
        def __init__(self, task_vars):
            self.params = dict(data={
                'output_as_list': '{{myself | children("child[123]") | map("extract", hostvars, "ansible_eth0.ipv4.address")|list}}'})

# Generated at 2022-06-21 03:09:33.072876
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json
    import tempfile

    from ansible.compat.tests.mock import patch
    from ansible.compat.tests.mock import MagicMock

    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext

    from ansible.plugins.loader import action_loader

    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-21 03:09:42.587374
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create mock task, play objects
    task_vars = dict()
    result = {"changed": False, "ansible_stats": {'data': {}, 'per_host': False, 'aggregate': True}}

    # instantiate ActionModule
    action_mod = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Test scenario: data option is not a dictionary
    # expected output: module should return with error message
    data = "this is not a dictionary"
    action_mod_run_data = action_mod.run(task_vars=task_vars, data=data)
    assert action_mod_run_data['failed'] == True and "The 'data' option needs to be a dictionary/hash" in action_mod_

# Generated at 2022-06-21 03:09:50.296377
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for the method `run` of class `ActionModule`
    '''
    task = dict(
        action=dict(
            module="set_stats",
            args=dict(
                data=dict(
                    a=dict(b=1, c=2),
                    d=3,
                    e="{{ '1' + 1 }}"
                ),
                per_host=True
            )
        )
    )

    task_vars = dict()

    def dummy_loader():
        class DummyVarsModule:
            def __init__(self):
                self.__templar = DummyTemplar()

        class DummyTemplar:
            def __init__(self):
                pass

            def template(self, data, **kwargs):
                return data
        return DummyV

# Generated at 2022-06-21 03:09:59.348161
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class Task:
        def __init__(self):
            self.args = {'data':{'x':'y'}}
            self.action = 'set_stats'

    host = "testhostname"
    test_item = Task()
