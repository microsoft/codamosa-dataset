

# Generated at 2022-06-11 12:28:47.216501
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    r = ActionModule.run(None, None)
    assert r['ansible_stats']['data'] == {}
    assert r['ansible_stats']['aggregate']
    assert not r['ansible_stats']['per_host']

# Generated at 2022-06-11 12:28:47.831459
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-11 12:28:57.596310
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #from ansible.compat.tests import unittest
    from ansible import errors
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.plugins.action.set_stats import ActionModule
    from ansible.utils.vars import isidentifier
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils import basic

    class FakeDS(object):
        def __init__(self, task_vars=None):
            self._task_vars = task_vars

        def get_vars(self):
            return self._task_vars

    class FakeTask(object):
        def __init__(self, args):
            self.args = args



# Generated at 2022-06-11 12:29:07.548226
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no template data
    actionModule = ActionModule()
    actionModule._task = {}

    actualResult = actionModule.run()
    assert actualResult['CHANGED'] == False, "Actual result %s did not match expected result False" % actualResult['CHANGED']
    assert actualResult['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True}

    # Test with no template data in _task arg
    actionModule = ActionModule()
    actionModule._task = {}
    actionModule._task['args'] = {}

    actualResult = actionModule.run()
    assert actualResult['CHANGED'] == False, "Actual result %s did not match expected result False" % actualResult['CHANGED']

# Generated at 2022-06-11 12:29:10.997763
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action = ActionModule(None, None, None)

    assert action._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))
    assert action.TRANSFERS_FILES == False


# Generated at 2022-06-11 12:29:20.599569
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_mock = ActionModule()

    # dict
    dict1 = dict()
    dict1['var1'] = "val1"
    dict1['var2'] = "val2"
    result = ActionsModule.run(data=dict1)
    assert isinstance(result['ansible_stats'], dict)
    assert result['ansible_stats']['data'] == dict1

    # value
    dict2 = "some_value"
    result = ActionsModule.run(data=dict2)
    assert isinstance(result['ansible_stats'], dict)
    assert result['ansible_stats']['data'] == dict2

    return True

# Generated at 2022-06-11 12:29:28.582577
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class MockActionModule(ActionModule):
        @property
        def _templar(self):
            return MockTemplar(None, None)

        @property
        def _task(self):
            return MockTask()

        def _execute_module(self, *args, **kwargs):
            pass

    class MockTemplar(object):
        def __init__(self, fail_on_undefined, convert_bare):
            self.fail_on_undefined = fail_on_undefined
            self.convert_bare = convert_bare

        def template(self, arg, fail_on_undefined=None, convert_bare=None):
            if arg == 'true':
                return True
            elif arg == 'false':
                return False
            else:
                return arg


# Generated at 2022-06-11 12:29:37.827106
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create mock argument spec
    mock_args = {
        'data': {
            'key1': 'value1',
            'key2': 'value2'
        },
        'per_host': False,
        'aggregate': True
    }

    # Create instance of class ActionModule
    module = ActionModule()
    # Execute the run method and ensure result is correct
    result = module.run(tmp=None, task_vars='task_vars')
    assert result == {'ansible_stats': {'data': {'key1': 'value1', 'key2': 'value2'}, 'per_host': False, 'aggregate': True}, 'changed': False}

# Generated at 2022-06-11 12:29:38.887683
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Testing ActionModule constructor')
    assert ActionModule()

# Generated at 2022-06-11 12:29:47.152059
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host_vars = dict()
    task_vars = dict()
    task_vars = dict()
    module = ActionModule(task=None, connection=None, _play_context=None, loader=None, templar=None, shared_loader_obj=None)

    task_vars['test_var'] = 'test value'
    result = module.run('tmp', task_vars)
    assert result['changed'] == False
    assert result['ansible_stats']['data']['test_var'] == 'test value'

    result = module.run('tmp', task_vars)


# Generated at 2022-06-11 12:29:53.160335
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass  # TODO: implement this unit test for ActionModule class

# Generated at 2022-06-11 12:29:54.527603
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, None, None, None, None, None, None, None)
    assert module

# Generated at 2022-06-11 12:29:56.515202
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # eval(compile('test_ActionModule_run()', '<string>', 'single', __locals__, __globals__))
    pass

# Generated at 2022-06-11 12:30:07.016218
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    obj = ActionModule(Task(), dict(hosts=["hostname"], connection="local", play=Play().load(dict(name="test",
            hosts=["hostname"], roles=[Role().load(dict(name="test"), play=Play().load(dict(name="test"), variable_manager=dict(hostvars=[Host(name="hostname")])))]))))

    assert obj



# Generated at 2022-06-11 12:30:08.862166
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule._VALID_ARGS == frozenset(['aggregate', 'data', 'per_host'])

# Generated at 2022-06-11 12:30:09.453607
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()

# Generated at 2022-06-11 12:30:14.749185
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create ActionModule instance
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert(isinstance(action_module, ActionModule))
    # test the result of the run() method
    result = action_module.run(tmp=None, task_vars=None)
    # check if the result is of the expected type
    assert(isinstance(result, dict))
    # make sure we have the expected keys in the result
    assert('changed' in result.keys())
    assert('ansible_facts' not in result.keys())
    assert('ansible_stats' in result.keys())
    assert('failed' in result.keys())
    assert('msg' in result.keys())
    # make sure the 'ans

# Generated at 2022-06-11 12:30:16.585316
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, 'run')
    assert hasattr(ActionModule, 'TRANSFERS_FILES')

# Generated at 2022-06-11 12:30:17.816096
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Test ActionModule.run method""" 
    print("Test successfull")

# Generated at 2022-06-11 12:30:20.873605
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Initialize ActionModule class
    am = ActionModule()

    # Initialize ansible task and ansible vars
    ansible_task = dict()
    ansible_vars = dict()



# Generated at 2022-06-11 12:30:41.121888
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Testing for dictonary data input
    test_dict = {'data': {'value_1': 10, 'value_2': 20}, 'per_host': True, 'aggregate': '{{ value_1 }}'}
    result = ActionModule(None, test_dict, None, None)

    # Verifying the Data
    assert result.run()['ansible_stats']['data']['value_1'] == 10
    assert result.run()['ansible_stats']['data']['value_2'] == 20
    assert result.run()['ansible_stats']['per_host'] == True
    assert result.run()['ansible_stats']['aggregate'] == 10

    # Testing for string data

# Generated at 2022-06-11 12:30:45.355754
# Unit test for constructor of class ActionModule
def test_ActionModule():
    def test_constructor():
        module = ActionModule()
        assert module._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))
        assert module.TRANSFERS_FILES == False
    test_constructor()


# Generated at 2022-06-11 12:30:52.475774
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # action_module.exec_module with an undefined 'data' element should raise a KeyError exception
    module_arguments = dict(
        data={
            'foo': 'bar',
            'baz': ['quz', 'quux'],
            'corge': True,
            'grault': False,
            'garply': None,
            'waldo': 0,
            'fred': 1.0,
            'plugh': 0.0,
            'xyzzy': 2**64,
            'thud': 123456789012345678901234567890,
        },
        aggregate=False,
        per_host=True
    )

    from ansible.plugins.action import ActionModule
    from ansible.utils.vars import combine_vars


# Generated at 2022-06-11 12:30:59.796391
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_string = 'set_stats'

    raw_dict = {'action': action_string, 'task': {'args': {'data': {'a': 'b'}}}, 'task_vars': {}}
    raw = action_string + ':' + str(raw_dict.get('args'))
    action = ActionModule(None, raw, raw_dict)
    module_return = action.run(None, raw_dict.get('task_vars'))

    assert module_return.get('msg') is None
    assert module_return.get('ansible_stats').get('data').get('a') == 'b'

# Generated at 2022-06-11 12:31:08.868241
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock
    from ansible.module_utils.six import PY3

    if PY3:
        unicode = str
    class MockConfigParser(object):
        def get(self, section, key):
            return ''

    with patch.object(ActionBase, 'run'):
        action_mod = ActionModule(None, None)
        setattr(action_mod, '_task', MagicMock(args={'aggregate':'yes', 'count':'42'}))
        setattr(action_mod, '_templar', MagicMock(template=lambda x: x))

# Generated at 2022-06-11 12:31:09.354141
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 12:31:20.062658
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # test with valid arg
    task = MockAnsibleTask()
    task.args = {'data': {'status': 'SUCCESS'}}

    action = ActionModule(task, MockConnection())
    result = action.run(task_vars={"ansible_check_mode": False})
    assert result == {'ansible_stats': {'data': {'status': 'SUCCESS'}, 'per_host': False, 'aggregate': True}, 'changed': False}

    # test with invalid arg
    task = MockAnsibleTask()
    task.args = {'data': {'status': 'SUCCESS'}, 'per_host': '{{ true }}'}

    action = ActionModule(task, MockConnection())
    result = action.run(task_vars={"ansible_check_mode": False})


# Generated at 2022-06-11 12:31:20.516536
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert (ActionModule(None, None) is not None)

# Generated at 2022-06-11 12:31:24.437116
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: (1) make test for every return path in method run,
    #       (2) test if the ansible_stats are set correctly
    a = ActionModule(None, None)
    b = a.run(None, None)
    assert b.changed == False

# Generated at 2022-06-11 12:31:30.112760
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule().run() == {'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}, 'failed': False, 'changed': False}
    assert ActionModule().run(task_vars={'foo': 1}) == {'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}, 'failed': False, 'changed': False}

# Generated at 2022-06-11 12:31:57.895395
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_queue_manager import TaskQueueManager

    class MockTask:
        def __init__(self, args):
            self.args = args

    class MockTaskResult:
        def __init__(self):
            self.result = dict()

    task_result = MockTaskResult()
    task_vars = dict()
    task_queue_manager = TaskQueueManager(None, None, None, None, None, None, None, None, None, None, None)

    mock_args1 = {}
    mock_task1 = MockTask(mock_args1)
    action_module = ActionModule(task=mock_task1, task_vars=task_vars, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
   

# Generated at 2022-06-11 12:32:08.578867
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_dict_1 = {'a':1, 'b':2, 'c':3}
    test_dict_2 = {'a':1, 'b':2, 'c':3}
    test_esult_1 = {'a':1, 'b':2, 'c':3}
    test_esult_2 = {'a':'1', 'b':'2', 'c':'3'}
    test_esult_3 = {'a':'', 'b':'2', 'c':'3'}

    test_templar = 'Templar'
    test_task_args = dict()
    test_task_args['data'] = test_dict_1
    test_task = 'Task'
    test_task.args = test_task_args

    test_action_module = Action

# Generated at 2022-06-11 12:32:12.930089
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # try:
    #     import __builtin__ as builtins  # python2
    # except ImportError:
    #     import builtins  # pytho3

    # import sys
    # sys.path.insert(0, 'path/to/library')
    # import my_library
    pass

# Generated at 2022-06-11 12:32:18.053684
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(action=dict(module='set_stats', data='{"a": 1}', aggregate=True)),
        connection=dict(),
        play_context=dict(deprecation_warnings=False),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert module is not None

# Generated at 2022-06-11 12:32:21.973489
# Unit test for constructor of class ActionModule
def test_ActionModule():
   print("test_ActionModule")
   action_module = ActionModule(
        task=dict(action=dict(module_name='set_stats')),
      connection=dict(),
      play_context=dict(),
      loader=None,
      templar=None,
      shared_loader_obj=None)
   assert action_module
   return

# Generated at 2022-06-11 12:32:31.719292
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash

    from ansible.executor.task_result import TaskResult

    test_task = Task()

    test_task.args = dict(
        aggregate=True,
        data=dict(
            x = 10.0,
            y = 1.0
        )
    )

    test_task.action = 'set_stats'

    test_result = TaskResult(host="test_host", task=test_task)
    test_result._result['changed'] = False
    test_result._result['ansible_stats']

# Generated at 2022-06-11 12:32:35.935253
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    This function test the constructor of class ActionModule
    """
    print ("test action module class constructor")
    try:
        action = ActionModule()
    except AttributeError:
        pass
    else:
        assert False, "Should fail because it has not been implemented yet"


# Generated at 2022-06-11 12:32:45.200634
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # import json to ensure that is available for the load(module_utils) call
    import json
    # Dummy task data
    dummy_task_data = {'task': 'dummy_task', 'args': {'data': {'fruits': 'apple'}}, 'action': 'set_stats'}
    # Import the class to be tested
    module = __import__('ansible.plugins.action.set_stats')
    action_module = getattr(module, 'ActionModule')
    # Instantiate the class to be tested
    action_object = action_module(load_module_utils=False, task=dummy_task_data)
    assert action_object.module_args == dummy_task_data['args']
    assert action_object._task.args['data'] == {'fruits': 'apple'}
    assert action

# Generated at 2022-06-11 12:32:52.247729
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import mock

    mod = mock.MagicMock(name='mod')
    mod.module_name = 'set_stats'
    mod.params = {}

    task = mock.MagicMock(name='task')
    task.args = {}
    task.action = 'set_stats'
    task.module_vars = {}

    plugin = ActionModule(task, mod)
    assert plugin._task == task
    assert plugin._connection is None
    assert plugin._play_context is None
    assert plugin._loader is None
    assert plugin._templar is None
    assert plugin._shared_loader_obj is None

# Generated at 2022-06-11 12:33:01.755829
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.set_stats import ActionModule

    # Test with no arguments
    am = ActionModule(dict(
        action='set_stats', task=dict(args=dict())))

    result = am.run(task_vars=dict())
    assert result is not None
    assert result['failed'] is False
    assert 'ansible_stats' in result, "No ansible_stats dictionary in result"
    assert 'data' in result['ansible_stats'], "No data element in ansible_stats"
    assert 'per_host' in result['ansible_stats'], "No per_host element in ansible_stats"
    assert 'aggregate' in result['ansible_stats'], "No aggregate element in ansible_stats"

    # Test with invalid data argument

# Generated at 2022-06-11 12:33:40.953442
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:33:45.600770
# Unit test for constructor of class ActionModule
def test_ActionModule():
    constructor = ActionModule(
        task=dict(args=dict(data=dict(a=1, b=2), aggregate=False,
                            per_host=True)),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert constructor is not None
    assert len(constructor._task.args) == 3
    assert len(constructor.run().keys()) == 2

# Generated at 2022-06-11 12:33:47.353128
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module._VALID_ARGS == frozenset(['aggregate', 'data', 'per_host'])

# Generated at 2022-06-11 12:33:50.950400
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(task=dict())
    assert am._VALID_ARGS == frozenset(['aggregate', 'data', 'per_host'])

    assert am.TRANSFERS_FILES == False


# Generated at 2022-06-11 12:33:53.023346
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    result = module.run(tmp=None, task_vars=None)
    print(result)

# Generated at 2022-06-11 12:33:55.182175
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule(None,None,None)
    assert mod._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-11 12:33:57.421456
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_name = 'ActionModule'
    module = __import__(module_name)
    clazz = getattr(module, 'ActionModule')
    ins = clazz()
    assert ins is not None


# Generated at 2022-06-11 12:33:57.884551
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  assert False

# Generated at 2022-06-11 12:34:00.445027
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, {})
    result = action.run(None, None)
    assert result['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True}


# Generated at 2022-06-11 12:34:03.476724
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(action=dict()), dict(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict()), '/fake/path')

# Generated at 2022-06-11 12:35:52.823907
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	action_module = ActionModule()
	task_vars = dict()
	task_vars['ansible_stats'] = dict()

	# Test 1: Use defaults
	result = action_module.run(task_vars=task_vars)
	assert result['ansible_stats']['data'] == dict()
	assert result['ansible_stats']['aggregate'] == True
	assert result['ansible_stats']['per_host'] == False

	# Test 2: Use valid bool values
	result = action_module.run(tmp=None, task_vars=task_vars, args={
            'data': { 'aggregate': 1, 'per_host': 0 }
        })
	assert result['ansible_stats']['data'] == { 'aggregate': 1, 'per_host': 0 }

# Generated at 2022-06-11 12:35:58.473261
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=dict(action=dict(stats=dict(data='{ "a": "b" }', per_host=True, aggregate=True))))
    assert module._task.args == {'data': '{ "a": "b" }', 'per_host': True, 'aggregate': True}
    assert module.run() == {'ansible_stats': {'aggregate': True, 'data': {'a': 'b'}, 'per_host': True}, 'changed': False}


# Generated at 2022-06-11 12:36:05.143465
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''
    test_result = dict()

    test_result["ansible_stats"] = {
        "aggregate": True,
        "data": {
            "test_key": "test_value",
        },
        "per_host": False,
    }
    test_result["changed"] = False

    test_class = ActionModule(dict(), dict())
    tmp = None
    task_vars = None

    result = test_class.run(tmp, task_vars)

    assert result == test_result

# Generated at 2022-06-11 12:36:11.445930
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create a module without arguments
    mod = ActionModule(None, None, {})

    # create a module with valid arguments
    args = {'aggregate': True, 'data': {'myvar1': 'myval1', 'myvar2': 'myval2'}, 'per_host': True}
    mod = ActionModule(None, None, args)

    # create a module with valid arguments but with badly formatted per_host
    args = {'aggregate': True, 'data': {'myvar1': 'myval1', 'myvar2': 'myval2'}, 'per_host': "Yes"}
    mod = ActionModule(None, None, args)

# Generated at 2022-06-11 12:36:12.589430
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None)
    assert(action)

# Generated at 2022-06-11 12:36:15.515770
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None)
    expected_valid_args = frozenset(('aggregate', 'data', 'per_host'))

    assert(action._VALID_ARGS == expected_valid_args)


# Generated at 2022-06-11 12:36:18.077289
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Unit test for constructor of class ActionModule
    """
    #import ansible.plugins.action.set_stats as ActionModule
    m = ActionModule.ActionModule(None, {}, None, None, None)
    assert m is not None

# Generated at 2022-06-11 12:36:19.138861
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO:
    # write unit test for ActionModule.run
    assert False

# Generated at 2022-06-11 12:36:26.583081
# Unit test for constructor of class ActionModule
def test_ActionModule():

    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    Task._count += 1
    task = Task()
    task._role = None
    task.args = dict(aggregate=True, data=dict(a=10, b=20), per_host=True)
    task._parent = dict(name="test", play=dict(hosts=["host1", "host2", "host3"]))
    task.context = dict(a=10, b=20)

    play_context = PlayContext()
    play_context.remote_addr = 'localhost'

    plugin = ActionModule(task, play_context, '/tmp/ansible_modlib.params', 'non_exist_connection', 'ssh', 'local', task.context, '/tmp/ansible_modlib.tmp')

# Generated at 2022-06-11 12:36:33.981204
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''
    task = MagicMock()
    task.args = {'data':{'test':'data'},'per_host':True,'aggregate':False}
    tmp = MagicMock()
    task_vars = {'data':{'ansible_stats':{'data':{}, 'per_host': False, 'aggregate': True}}}
    am = ActionModule(task,tmp,task_vars)
    assert am.run(tmp,task_vars) == {'ansible_stats': {'data': {'test': 'data'}, 'per_host': True, 'aggregate': False}, 'failed': False, 'changed': False}