

# Generated at 2022-06-11 12:28:48.543043
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(dict(), dict())
    assert action.run() == {'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}, 'changed': False}



# Generated at 2022-06-11 12:28:54.067555
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(task=dict(name="test_task", args={'aggregate': True, 'data': 'hello', 'per_host': False}))
    result = module.run()
    assert result['ansible_stats']['aggregate'] == True
    assert result['ansible_stats']['data'].get('hello') is not None
    assert result['ansible_stats']['per_host'] == False

# Generated at 2022-06-11 12:29:02.293651
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule(Connection())
    m.datastructure = { 'foo':'bar' }
    assert m.run() != False
    m.datastructure = { 'foo':{ 'ansible_foo':'bar' } }
    assert m.run() == False
    m.datastructure = { 'ansible_foo':'bar' }
    assert m.run() == False
    m.datastructure = { 'data':{'foo':'bar'} }
    assert m.run() != False
    m.datastructure = { 'data':{'_foo':'bar'} }
    assert m.run() == False

# Generated at 2022-06-11 12:29:02.868990
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 12:29:04.858724
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule.
    '''
    # TODO: test_ActionModule_run()
    pass

# Generated at 2022-06-11 12:29:09.163777
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert isinstance(am,ActionModule)
    assert am.name == 'set_stats'
    assert am.Transferable == am.TRANSFERS_FILES
    assert am._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-11 12:29:20.216224
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    from ansible.modules.system import set_stats
    ActionModule.run()
    ActionModule.run(tmp='tests/ansible_test/test_data/test_tmp')

    tmp = 'tests/ansible_test/test_data/test_tmp'
    task_vars = {'test_var': 'test_var_value'}
    result = ActionModule.run(tmp, task_vars)
    assert result['ansible_stats']['data'] == task_vars['test_var']
    assert result['ansible_stats']['per_host'] is False
    assert result['ansible_stats']['aggregate'] is True
    pytest.raises(AttributeError, ActionModule.run, None, 'foo')

# Generated at 2022-06-11 12:29:25.732401
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task1 = {
        "args": {
            "data": {
                "test_arg1": "test_val1",
                "test_arg2": "test_val2"
            },
            "per_host": True
        },
        "vars": {
        }
    }

    task2 = {
        "args": {
            "data": {
                "test_arg1": "test_val1",
                "test_arg2": "test_val2"
            },
            "per_host": True,
            "aggregate": True
        },
        "vars": {
        }
    }
    task_vars = {}

    am = ActionModule(task1, task_vars)
    run1 = am.run()
    del am


# Generated at 2022-06-11 12:29:36.294827
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # not sure how to test this, but it will at least prevent failure
    from ansible.playbook.play_context import PlayContext

    # test valid data
    data = {'test_datastore1': 'test_variable_1', 'test_datastore2': 'test_variable2'}
    ctx = PlayContext()
    ctx._tqm = (1,2,3)
    ds = ActionModule(ctx)
    stats = {'data': data, 'per_host': False, 'aggregate': True}
    ds.per_host = False
    ds.aggregate = True
    ds._task_vars = {'test_variable_1': 'test_variable_1'}

# Generated at 2022-06-11 12:29:41.594285
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Test constructor of ansible.plugins.action.set_stats.ActionModule
    """
    from ansible.plugins.action.set_stats import ActionModule

    a = ActionModule()

    assert a._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))
    assert a.TRANSFERS_FILES is False

# Generated at 2022-06-11 12:29:54.005036
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    import json
    
    # Create a dummy class so that we can create a task
    class Play:
        name = 'Test Play'
        hosts = 'all'
        _task_include = None
    
    # Create a dummy class so that we can create a task
    class PlayBook:
        playbook = [Play()]
        hostvars = dict()
        
    # Create a dummy context so that we can

# Generated at 2022-06-11 12:29:59.261543
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    module = ActionModule()
    module._task = object()
    module._task.args = {}
    module._task.args['data'] = {'foo': 'bar'}

    test = {'changed': False, 'ansible_stats': {'data': {'foo': 'bar'}, 'per_host': False, 'aggregate': True}}
    assert test == module.run(None, None)


# Generated at 2022-06-11 12:30:00.203428
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule() is not None

# Generated at 2022-06-11 12:30:11.519070
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class AnsibleModuleMock(object):
      def __init__(self, argument_spec, bypass_checks):
        self.argument_spec = argument_spec
        self.params = {}
        self.params['data'] = {'a': 'b'}
        self.params['per_host'] = False
        self.params['aggregate'] = False
        self.check_mode = False
      def fail_json(self, *args, **kwargs):
        raise Exception('fail_json')

# Generated at 2022-06-11 12:30:14.388814
# Unit test for constructor of class ActionModule
def test_ActionModule():
    AM = ActionModule(None, None, None)
    assert AM.run() == {'changed': False, 'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}}


# Generated at 2022-06-11 12:30:25.057228
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.module_utils.parsing.convert_bool import BOOLEANS

    # Add action plugin directories
    add_all_plugin_dirs()

    m = ActionModule()

    # Create a dict for task vars
    task_vars = dict()

    # Initialize a dict for the 'args' section to use in _task

# Generated at 2022-06-11 12:30:35.551017
# Unit test for constructor of class ActionModule
def test_ActionModule():

    import sys
    sys.modules['ansible.module_utils.parsing.convert_bool'] = importlib.import_module('ansible.module_utils.parsing.convert_bool')
    sys.modules['ansible.plugins.action'] = importlib.import_module('ansible.plugins.action')

    # Unit tests to test class ActionModule instance creation
    action_module = ActionModule()
    assert action_module._task.args == {}
    task_vars = {}
    assert action_module.run(task_vars=task_vars) == {'ansible_stats': {'aggregate': True,
                                                                       'data': {},
                                                                    'per_host': False},
                                                        'changed': False}

    # Unit Tests for ActionModule instance method run

# Generated at 2022-06-11 12:30:38.346228
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None)
    assert hasattr(action_module, '_VALID_ARGS')
    assert action_module._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-11 12:30:49.176199
# Unit test for constructor of class ActionModule
def test_ActionModule():
    def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
        self.task = task
        self.connection = connection
        self.play_context = play_context
        self.loader = loader,
        self.templar = templar
        self.shared_loader_obj = shared_loader_obj

    #Create temporary objects
    task = object()
    connection = object()
    play_context = object()
    loader = object()
    templar = object()
    shared_loader_obj = object()

    #Create object
    test_obj = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

# Generated at 2022-06-11 12:30:57.929434
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.vars import combine_vars
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    import os

    task_vars = dict()
    loader = DataLoader()
    templar = Templar(loader=loader)
    inv = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inv)

# Generated at 2022-06-11 12:31:17.760614
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.module_utils.six import string_types

    # Test without fail_on_undefined
    my_action = ActionModule()
    my_task = dict()
    my_task['args'] = dict()
    my_task['args']['data'] = dict()
    # value of data is not a dictionary, so fail_on_undefined should be True
    # in this case, a string is expected to be returned
    my_task['args']['data'] = 'my_test_value'
    my_task['action'] = dict()
    my_task['action']['set_stats'] = dict()
    my_task['action']['module_name'] = 'set_stats'
    my_result = dict()
    my_result['changed'] = False

# Generated at 2022-06-11 12:31:24.694037
# Unit test for constructor of class ActionModule
def test_ActionModule():
	# The next two lines are part of the testing
	# module using unittest. To test this plugin 
	# from command line comment out the following two 
	# lines and run "python set_stats.py"
    import unittest
    unittest.main()
    
    
# The following lines are part of the testing module using unittest
# To test this plugin from command line comment out the following 
# class and run "python set_stats.py"

# Generated at 2022-06-11 12:31:26.240372
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #TODO
    import sys; sys.exit(1)


# Generated at 2022-06-11 12:31:30.490440
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None, None)
    assert isinstance(a._VALID_ARGS, frozenset)
    assert a._VALID_ARGS ==  frozenset(('per_host', 'data', 'aggregate')), a._VALID_ARGS
    assert a.TRANSFERS_FILES == False

# Generated at 2022-06-11 12:31:35.767047
# Unit test for constructor of class ActionModule
def test_ActionModule():

    task_args = dict()
    task_args['data'] = dict(foo='bar')
    task_args['aggregate'] = True

    # create module
    action_module = ActionModule(task=dict(action=dict(module='set_stats', args=task_args)))

    # run to simulate the constructor
    task_vars = dict()
    result = action_module.run(None, task_vars)

    # test result of constructor
    assert result['ansible_stats'] == dict(aggregate=True, data=dict(foo='bar'), per_host=False)

# Generated at 2022-06-11 12:31:37.167604
# Unit test for constructor of class ActionModule
def test_ActionModule():
    my_model = ActionModule()
    print(my_model)



# Generated at 2022-06-11 12:31:44.719777
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(args=dict(per_host=True, aggregate=True, data=dict(a=1,b=2,c=3))),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)
    assert action_module.run(tmp=None, task_vars=None) == {'ansible_stats': {'data': {'a': 1, 'b': 2, 'c': 3}, 'aggregate': True, 'per_host': True}, 'failed': False}

# Generated at 2022-06-11 12:31:54.821321
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    idMap = {}

    # Create an instance of the module
    module = ActionModule(
        task=dict(
            name='test-action',
            action='test_method',
            args=dict(
                aggregate=True,
                data=dict(
                    foo=1,
                    bar=2
                ),
                per_host=False
            )
        )
    )

    # When hostvars is not a dict, the self.run() method throws exception
    task_vars = None
    try:
        module.run('/tmp', task_vars)
        assert False
    except Exception as e:
        assert str(e) == 'Internal Error: Host variables are not defined.'

    # When hostvars is a dict, but data is not a valid dict, the self.run() method throws exception
    task_vars

# Generated at 2022-06-11 12:31:56.231431
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_mod = ActionModule(None, None)
    assert isinstance(action_mod, ActionModule)

# Generated at 2022-06-11 12:32:01.856222
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create an action module run object
    am =  ActionModule(
        task=dict(action=dict(module_name='set_stats', args=dict(data=dict(foo='foo', bar='bar')))),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=None)

    # run the action module
    result = am.run(task_vars=dict())

    # check whether the result is as expected
    assert result['failed'] == False
    assert result['changed'] == False
    assert result['ansible_stats']['data']['foo'] == 'foo'
    assert result['ansible_stats']['data']['bar'] == 'bar'

# Generated at 2022-06-11 12:32:31.099201
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule
    """
    from ansible.plugins.action.set_stats import ActionModule
    from ansible.modules.extras.cloud.common.aws import ec2_metric_facts
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    import ansible.constants as C
    import os
    import json

    if not os.path.exists('/tmp/ec2_metric_facts_test.yml'):
        return

    if not os.path.exists('/tmp/ec2_metric_facts_test_inventory'):
        return

    C.H

# Generated at 2022-06-11 12:32:35.329611
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = ActionModule.run(ActionModule(), {}, {'data': {'name': 'foo'}})
    assert result['failed'] == False
    assert result['ansible_stats'] == {'data': {'name': 'foo'}, 'per_host': False, 'aggregate': True}


# Generated at 2022-06-11 12:32:44.621954
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import load_extra_vars

    action = ActionModule(Task(), connection='local', play_context=PlayContext(), loader=None, templar=None, shared_loader_obj=None)

    # test data

# Generated at 2022-06-11 12:32:46.468237
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_stats_module = ActionModule()
    assert set_stats_module is not None, 'set_stats_module not initialized'
    return

# Generated at 2022-06-11 12:32:56.322760
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Test ActionModule.run"""

    module = ActionModule()

    # Test empty set_stats
    stats = module.run()
    assert not stats['failed']
    assert not stats['changed']
    assert 'ansible_stats' in stats
    assert not stats['ansible_stats']['per_host']
    assert stats['ansible_stats']['aggregate']
    assert not stats['ansible_stats']['data']

    # Test set_stats with data
    stats = module.run(args={'data': {'test1': 'test1_val', 'test2': 'test2_val'}})
    assert not stats['failed']
    assert not stats['changed']
    assert stats['ansible_stats']['data']['test1'] == 'test1_val'

# Generated at 2022-06-11 12:32:57.229726
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True # TODO: write this test

# Generated at 2022-06-11 12:33:05.672415
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create actual ActionModule instance
    module = ActionModule()
    # create empty TaskExecutionResult object
    result = module.TaskExecutionResult()
    # create empty task object
    task = module.Task()
    # create empty task_vars object
    task_vars = dict()
    # create empty tmp object
    tmp = None

    task.args = dict()
    task.args['data'] = dict()
    task.args['data']['var1'] = 'var1'
    task.args['data']['var2'] = 'var2'
    res = module.run(tmp, task_vars)
    assert res["ansible_stats"] == {'data': {'var1': 'var1', 'var2': 'var2'}, 'per_host': False, 'aggregate': True}

   

# Generated at 2022-06-11 12:33:07.015330
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule('test')
    assert am.action == 'test'


# Generated at 2022-06-11 12:33:11.595192
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # constructor with default arguments
    moduleObj = ActionModule()
    assert not moduleObj.TRANSFERS_FILES
    assert moduleObj._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))
    # constructor with specified arguments
    tmp = "/tmp"
    task_vars = {'patient': 'male'}
    moduleObj = ActionModule(tmp,task_vars)
    assert not moduleObj.TRANSFERS_FILES
    assert moduleObj._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-11 12:33:13.734011
# Unit test for constructor of class ActionModule
def test_ActionModule():
  # creating instance of class ActionModule
  action_module=ActionModule()
  
  # For coverage
  #assert action_module != None

# Generated at 2022-06-11 12:33:55.560167
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None)
    assert action is not None

# Generated at 2022-06-11 12:33:57.981659
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task = None, connection = None, play_context = None, loader = None, templar = None, shared_loader_obj = None)
    assert action_module is not None
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-11 12:34:03.069581
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.set_stats
    x = ansible.plugins.action.set_stats
    action = x.ActionModule(loader=None, task=None, connection=None, play_context=None, loader_cache=None, shared_loader_obj=None, templar=None)
    assert type(action).__name__ == 'ActionModule'
    assert type(action).__module__ == x.__name__

# Generated at 2022-06-11 12:34:10.812980
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Unit test for method run of class ActionModule
    # This test is meant to be used as a template for writing
    # unit tests for modules.
    #
    # The set of assert statements in the if-then-else block are
    # examples of how to test module results.  You should replace
    # these with your own tests.
    #
    # The test_utils.create_module_mock() method will generate a
    # AnsibleModule mock to be used for testing.
    from ansible.module_utils import test_utils
    from ansible.module_utils._text import to_text

    # Create a module mock for testing
    module = test_utils.create_module_mock(templar=test_utils.MockTemplar())
    action = ActionModule(module)

    # Create a test result that is expected from

# Generated at 2022-06-11 12:34:15.613796
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test passing arguments to constructor
    a = ActionModule(dict(), dict())
    assert a.TRANSFERS_FILES == False
    assert a._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

    # Test passing arguments to set_stats module
    d = {
        'data': {'number_of_apples': '{{apples|length}}'},
        'per_host': True,
        'aggregate': False
    }
    a = ActionModule(d, dict())
    assert a.TRANSFERS_FILES == False
    assert a._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

    # Test passing arguments to set_stats module

# Generated at 2022-06-11 12:34:18.307909
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    This method is used to test ActionModule
    """
    obj = ActionModule()
    assert isinstance(obj._VALID_ARGS, frozenset)
    obj.run("tmp", "task_vars")

# Generated at 2022-06-11 12:34:26.622717
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    t = Task()
    t._role = None
    t._block = None
    t.action = 'set_stats'
    t.args = {'data': 'my_var: 5'}
    t.task_vars = dict()

    loader = DataLoader()
    play_context = PlayContext(remote_addr='127.0.0.1', connection='local', network_os='default', port=0, remote_user='default',
                               password='default', become_method=None, become_user=None, check=False, diff=False)

# Generated at 2022-06-11 12:34:30.215883
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ('ActionModule' in globals())
    assert (ActionModule.__name__ == 'ActionModule')
    assert (ActionModule.__doc__ == 'Sets variables for a task, without registering a task result.')
    assert (ActionModule.TRANSFERS_FILES == False)


# Generated at 2022-06-11 12:34:40.137279
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Test empty constructors
    am = ActionModule()
    assert am.TRANSFERS_FILES == False, 'ActionModule empty constructor fails'
    assert am._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host')), 'ActionModule empty constructor fails'

    # Test run with empty params
    tmp = None
    task_vars = None
    tmp_dict = {}
    result = am.run(tmp, task_vars)
    assert result['changed'] == False, 'ActionModule empty run fails'
    assert result['ansible_stats'] == {u'per_host': False, u'aggregate': True, u'data': {}}, 'ActionModule empty run fails'

    # Test run with params
    data = {'key1': 'value1', 'key2': 'value2'}

# Generated at 2022-06-11 12:34:43.826591
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Mock class of ActionBase
    class TestActionModule(ActionModule):

        def run(self, tmp=None, task_vars=None):
            print('test')

    assert TestActionModule(self=None).run(tmp_file='test', task_vars="test") == "test"


# Generated at 2022-06-11 12:36:36.091182
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-11 12:36:39.675289
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # import Ansible built in unit test module
    import ansible.modules.extras.system.set_stats as set_stats
    # instantiate class ActionModule and assign at instance variable
    module = set_stats.ActionModule()
    # assert module is type of ActionBase
    assert isinstance(module, ActionBase)

# Generated at 2022-06-11 12:36:40.899451
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_object = ActionModule()
    assert test_object is not None

# Generated at 2022-06-11 12:36:48.367248
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass
# Example input to run method of class ActionModule
run_in = {
  "aggregate": "{{ true }}",
  "data": {
    "foo": "{{ if true -}}{{ 1 }}{{ else -}}{{ 2 }}{{ endif -}}",
    "bar": "{{ 'this is a string' }}",
    "baz": "{{ [ 1, 2, 3 ] | count }}"
  },
  "per_host": "{{ false }}"
}

# Expected result from run method of class ActionModule

# Generated at 2022-06-11 12:36:56.384910
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with empty set of args
    args = {}
    action = ActionModule(dict())
    action._task = dict(args=args)
    result = action.run()
    assert result['changed'] == False
    assert result['ansible_stats'] == dict(data={}, aggregate=True, per_host=False)

    # Test with provided args['data']
    args = dict(data=dict(a=5, b='t'))
    action = ActionModule(dict())
    action._task = dict(args=args)
    result = action.run()
    assert result['changed'] == False
    assert result['ansible_stats'] == dict(data=dict(a=5, b='t'), aggregate=True, per_host=False)

    # Test with provided args['data'] where there is a template to be applied
   

# Generated at 2022-06-11 12:37:04.561550
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = {
        'action': 'set_stats',
        'args': {
            'data': {
                'foo': 'bar',
                'dummy_var': 'string'
            },
            'per_host': True,
            'aggregate': False,
            'boolean_var': 'True'
        }
    }
    connection = None
    play_context = None
    loader = None
    templar = None
    shared_loader_obj = None
    global_vars = {}

    action_mod = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)

    data = action_mod.run(task_vars=global_vars)

    stats = data['ansible_stats']

    assert isinstance(stats['data'], dict)

# Generated at 2022-06-11 12:37:12.433400
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    a = ActionModule(
        task=dict(action=dict(module='set_stats')),
        connection=None,
        play_context=dict(play=Play().load(dict(
            name="Ansible Play",
            hosts='localhost',
            gather_facts='no',
            tasks=[dict(action=dict(module='set_stats'))]
        ), variable_manager=VariableManager(), loader=None)),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert a is not None

# Generated at 2022-06-11 12:37:13.498741
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod_obj = ActionModule()
    # TODO: find out how to test this

# Generated at 2022-06-11 12:37:19.551688
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create instance of class
    test_obj = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # assert correct type
    assert type(test_obj) == ActionModule
    # assert _VALID_ARGS are set correctly
    assert test_obj._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))
    # assert TRANSFERS_FILES is set correctly
    assert test_obj.TRANSFERS_FILES == False


# Generated at 2022-06-11 12:37:20.140979
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    return None