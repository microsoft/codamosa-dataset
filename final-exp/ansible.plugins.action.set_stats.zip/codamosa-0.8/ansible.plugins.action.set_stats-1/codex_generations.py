

# Generated at 2022-06-11 12:28:47.399191
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class_actionmodule = ActionModule()
    assert class_actionmodule.__class__ == ActionModule

# Generated at 2022-06-11 12:28:57.125423
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test run() method by creating an empty class with just the run() method
    class TestActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            return super(TestActionModule, self).run(tmp, task_vars)

    # dummy action that is required by the ActionBase base class
    class DummyAction(object):
        def __init__(self, args):
            assert isinstance(args, dict)
            self.args = args

    # setup fake an action
    action = DummyAction({})
    # setup a fake task
    class DummyTask(object):
        def __init__(self, args):
            assert isinstance(args, dict)
            self.args = args

# Generated at 2022-06-11 12:29:05.560951
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    m_self = Mock()
    m_self._task.args = {'data': {'a': 1, 'b': 2, 'c': 3}}
    m_self._templar = Mock()
    m_self._templar.template = Mock(side_effect=['a', '1', 'b', '2', 'c', '3'])

    result = ActionModule.run(m_self)
    assert(result['changed'] is False)
    assert(result['ansible_stats'] == {'data': {'a': 1, 'b': 2, 'c': 3}, 'per_host': False, 'aggregate': True})


# Generated at 2022-06-11 12:29:10.908424
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule()
    assert mod.run(
        task_vars={'inventory_hostname': 'test_host'},
        tmp=None,
    ) == {u'changed': False, 'ansible_stats': 
        {'aggregate': True, 'per_host': False, 'data': {u'inventory_hostname': u'test_host'}}}


# Generated at 2022-06-11 12:29:22.494061
# Unit test for constructor of class ActionModule
def test_ActionModule():

    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars # noqa
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    import ansible.constants as C

    loader = DataLoader()
    host_list = ['127.0.0.1', 'jumper.example.com']
    inventory = InventoryManager(loader=loader, sources=host_list)
    host = Host(name='127.0.0.1')


# Generated at 2022-06-11 12:29:25.294325
# Unit test for constructor of class ActionModule
def test_ActionModule():
    retval = ActionModule()
    assert isinstance(retval, ActionModule)
    assert not retval._task.args
    assert "__ansible_tmpdir" in retval._task.templar._available_variables


# Generated at 2022-06-11 12:29:27.882810
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule."""

    module = ActionModule(None, None, None)

    # FIXME: Add test case
    raise NotImplementedError()


# Generated at 2022-06-11 12:29:32.565874
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = {}
    # initialize the class
    class_name = 'ActionModule'
    dummy_class = ActionModule()
    # get the result of the method with result dictionary
    result = dummy_class.run(tmp=None, task_vars=None)
    # Assert the result of the above method
    assert result["changed"] == False

# Generated at 2022-06-11 12:29:43.609314
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 12:29:52.179322
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.set_fact import ActionModule

    t = dict()
    t['_ansible_verbosity'] = 3
    t['_ansible_no_log'] = False
    t['ansible_version'] = '2.0.0.2'
    t['ansible_python_interpreter'] = '/usr/bin/python'
    t['ansible_system'] = 'Linux'
    t['ansible_distribution'] = 'Fedora'
    t['ansible_distribution_major_version'] = '24'
    t['ansible_distribution_version'] = '24'
    t['ansible_os_family'] = 'RedHat'
    t['ansible_pkg_mgr'] = 'dnf'
    t['ansible_user_id'] = 'root'


# Generated at 2022-06-11 12:30:08.666752
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	from ansible.utils.vars import combine_vars
	from ansible.playbook.play_context import PlayContext
	from ansible.playbook.task_include import IncludeTask
	from ansible.playbook.block import Block

	play_context = PlayContext()
	task = IncludeTask()
	block = Block.load(dict(task=dict(name='set_stats')), task, play_context, loader=None)
	combine_vars(task.vars)
	module_ret = dict(failed=False, msg="All ok", changed=False)
	task_vars = dict()

	am = ActionModule()

	# Test without arguments
	ret = am.run(None, task_vars=task_vars)

	assert ret['changed'] == False


# Generated at 2022-06-11 12:30:15.078709
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(ActionBase)
    action_module._task = MagicMock()
    action_module._task.args = {
        'aggregate': False,
        'data': {
            'testkey1': 'testval1',
            'testkey2': 'testval2'
        },
        'per_host': True
    }
    assert action_module.run()['ansible_stats']['aggregate'] == False
    assert action_module.run()['ansible_stats']['per_host'] == True

# Generated at 2022-06-11 12:30:25.967599
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 12:30:36.285780
# Unit test for constructor of class ActionModule
def test_ActionModule():

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.template import Templar

    # Construct a dummy task to be passed to set_stats action
    task = Task()
    task._role = None
    task.args = {'data': {'key1': 'value1'}, 'aggregate': "yes", 'per_host': True}

    # Construct a dummy play_context object
    play_context = PlayContext()

    # Construct a dummy templar object
    templar = Templar(loader=None, variables={})

    # Create an instance of action_module and invoke set_stats action
    action_module = ActionModule(task, play_context, templar, shared_loader_obj=None)
    res = action_module.run({}, {})

   

# Generated at 2022-06-11 12:30:47.338238
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ACTION_MODULE = ActionModule(load_name='set_stats',
                                 task=dict(action=dict(module='set_stats',
                                                       args=dict(data=dict(foo='bar'),
                                                                 aggregate=dict(var='aggregate',
                                                                                default=False),
                                                                 per_host=dict(var='per_host',
                                                                               default=True))))),

# Generated at 2022-06-11 12:30:48.720368
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule
    assert(isinstance(x, object))

# Generated at 2022-06-11 12:30:49.641392
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 12:30:58.452743
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = AnsibleModule(
        argument_spec=dict(
            aggregate=dict(required=False, type='bool', default=True),
            data=dict(required=False, type='dict', default={}),
            per_host=dict(required=False, type='bool', default=False),
        ),
        supports_check_mode=False
    )

    t = ActionModule(module, {'ANSIBLE_MODULE_ARGS': {'module_name': 'setup'}})

    # Test case: no arguments
    assert t.run()['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True}

    # Test case: all arguments valid

# Generated at 2022-06-11 12:31:07.869560
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    import ansible.constants as C

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_

# Generated at 2022-06-11 12:31:14.857908
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_task = {'args': { 'aggregate': True, 'data': {'foo': 'f'}, 'per_host': False} }
    mock_play_context = {'become': False, 'become_method': 'sudo', 'become_user': 'root', 'remote_addr': '127.0.0.1'}
    mock_loader = None
    mock_templar = None
    mock_shared_loader_obj = None
    assert ActionModule(mock_task, mock_play_context, mock_loader, mock_templar, mock_shared_loader_obj)

# Generated at 2022-06-11 12:31:24.964068
# Unit test for constructor of class ActionModule
def test_ActionModule():
    act_m = ActionModule(None, None, None, None, None)
    assert isinstance(act_m._VALID_ARGS, frozenset)
    assert isinstance(act_m.TRANSFERS_FILES, bool)
    assert act_m.TRANSFERS_FILES is False

# Generated at 2022-06-11 12:31:34.158488
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = module.run()
    assert result['ansible_stats']['data'] == {}
    assert result['ansible_stats']['per_host'] == False
    assert result['ansible_stats']['aggregate'] == True

    result = module.run(tmp=None, task_vars=None)
    assert result['ansible_stats']['data'] == {}
    assert result['ansible_stats']['per_host'] == False
    assert result['ansible_stats']['aggregate'] == True

    class test_class():
        def __init__(self, args):
            self.args = args


# Generated at 2022-06-11 12:31:44.182300
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class MockTask(object):
        args = {
            'data': {
                'ansible': 'awesome',
                'awesome': 'ansible'
            },
            'per_host': True,
            'aggregate': False
        }

    parms = {
        'task': {},
        'connection': {},
        'play_context': {},
        'loader': None,
        'templar': {},
        'shared_loader_obj': None,
    }

    action = ActionModule(**parms)
    result = action.run(task_vars={}, tmp={})
    assert result.get('changed') == False

# Generated at 2022-06-11 12:31:46.775358
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None) is not None

# Generated at 2022-06-11 12:31:56.410649
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.plugins.action import ActionBase
    from ansible.utils.vars import merge_hash
    import json

    class FakeModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

    class FakeTask(object):
        def __init__(self, **kwargs):
            self.args = kwargs
            self.no_log = False

    class FakeTemplar(object):
        def __init__(self):
            self.template_data = {
                "foo": "bar",
                "ansible_host": "192.0.2.42",
            }


# Generated at 2022-06-11 12:32:07.316124
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no args, may raise but that is ok
    action_module = ActionModule(None, None, None, None)
    action_module.run(None, None)

    # Test with args set to None and may raise but that is ok
    action_module = ActionModule(None, {'args': None}, None, None)
    action_module.run(None, None)

    # Test with args set to empty dictionary
    action_module = ActionModule(None, {'args': {}}, None, None)
    action_module.run(None, None)

    # Test with valid args: HostVars

# Generated at 2022-06-11 12:32:09.037173
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None)
    assert action_module is not None

# Generated at 2022-06-11 12:32:19.451634
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.set_stats import ActionModule
    from ansible.utils.vars import combine_vars
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.playbook.play import Play
    from ansible.utils.display import Display
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    import os

    loader = DataLoader()
    options = {'verbosity': 0}
    display = Display()
    inventory = InventoryManager(loader, sources='localhost,')

# Generated at 2022-06-11 12:32:21.710870
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(
            action=dict(
                module_name='test_name',
                module_args=dict(),
                module_vars=dict()
            ),
            args=dict()
        ),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert module

# Generated at 2022-06-11 12:32:24.681654
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task

    t = Task()
    t.args = dict()
    am = ActionModule(task=t, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert am is not None

# Generated at 2022-06-11 12:32:31.583423
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionBase)


# Generated at 2022-06-11 12:32:32.211322
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:32:34.145303
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_stats_action = ActionModule({})
    assert set_stats_action



# Generated at 2022-06-11 12:32:36.892397
# Unit test for constructor of class ActionModule
def test_ActionModule():

    t = ActionModule()

    assert t._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))
    assert t.TRANSFERS_FILES == False

# Generated at 2022-06-11 12:32:39.402725
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.six import string_types

    # TODO: use testinfra instead
    assert hasattr(string_types, '__iter__')

# Generated at 2022-06-11 12:32:43.601895
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task

    task = Task()
    task._role = None
    task.action = 'set_stats'

    action = ActionModule(task, dict(connection='local'))
    action._task.args = dict(data=dict(new_task=1))
    action.run(None, dict())

# Generated at 2022-06-11 12:32:52.727697
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create instance of class and test object
    action_mod = ActionModule(load_fixture('set_stats/set_stats_args.yml'))

    # test attribute _task
    assert action_mod._task == {
       'action': 'set_stats',
       'version': 2,
       'args': {
          'aggregate': False,
          'per_host': False,
          'data': {
             'ansible_all_ipv4_addresses': '{{ ansible_all_ipv4_addresses }}',
             'ansible_hostname': '{{ ansible_hostname }}',
             'ansible_hostvars': '{{ ansible_hostvars }}'
          }
       }
    }

    # test attribute _task.args

# Generated at 2022-06-11 12:33:02.163284
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create a mock task to test
    mock_task = MagicMock()
    mock_task.args = dict(data=dict(var1="value1", var2="value2"))

    # Create a mock play context
    mock_pc = MagicMock()

    # Create a mock loader
    mock_loader = MagicMock()

    # Create a mock templar
    mock_templar = MagicMock()
    mock_templar.template.side_effect = lambda x, **kwargs : x

    # Create and initialize ActionModule instance
    am = ActionModule(mock_task, mock_pc, '/path/to/ansible/lib')
    am._templar = mock_templar

    # Create a mock ansible.plugins.action.ActionBaseV2
    mock_ab = MagicMock()
   

# Generated at 2022-06-11 12:33:07.486071
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    module = ActionModule()
    task_vars = dict()
    action_module = ActionModule()
    args = dict(data=dict(my_var='my_value'))
    action_module.run(task_vars=task_vars, **args)
    args = dict(data='my_var: my_value')
    action_module.run(task_vars=task_vars, **args)

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-11 12:33:10.387188
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module_obj = ActionModule(None, None, 10)
    assert action_module_obj is not None
    assert action_module_obj._task.action == 'set_stats'
    assert action_module_obj._task.action_args == {'data': {}, 'per_host': False, 'aggregate': True}

# Generated at 2022-06-11 12:33:28.114538
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # In the near future, the best strategy would be to mock everything
    ss_args = {'data': {'test': 'testdata'}}
    ss_action = ActionModule(None, ss_args, None)
    results = ss_action.run(None, None)
    assert results['changed'] == False
    assert results['ansible_stats']['data']['test'] == 'testdata'

# Generated at 2022-06-11 12:33:29.814285
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None)
    assert am._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-11 12:33:37.670195
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.utils.vars import combine_vars

    module = ActionModule()
    module._templar.template = lambda x: x
    task = lambda: None
    setattr(task, 'args', {
        'aggregate': 'true',
        'data': {'var': '1'},
        'per_host': 'false'})
    setattr(task, 'action', 'set_stats')
    module._task = task
    result = module.run()

    assert result['changed'] is False
    assert result['ansible_stats'] == {
        'data': {'var': '1'},
        'per_host': False,
        'aggregate': True}


# Generated at 2022-06-11 12:33:43.653206
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.modules.extras.statistics.set_stats import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager

    class MockTask(Task):
        def __init__(self):
            self.name = 'set_stats'
            self.action = 'set_stats'
            self.loop = None
            self.args = {'data': {'foo': 'bar', 'baz': 'qux'}, 'per_host': True, 'aggregate': False}
            self.delegate_

# Generated at 2022-06-11 12:33:50.909315
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(
            args=dict(
                data=dict(
                    foo='bar',
                    count=42
                ),
                per_host='yes',
                aggregate='no'
            ),
        )
    )
    assert module.TRANSFERS_FILES is False
    assert module._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))
    assert module._task.args == dict(
        data=dict(
            foo='bar',
            count=42
        ),
        per_host='yes',
        aggregate='no'
    )



# Generated at 2022-06-11 12:33:58.888488
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.set_stats import ActionModule

    task_vars = {}
    action = ActionModule(None, {}, task_vars=task_vars)

    # Empty data
    result = action.run(None, task_vars)
    assert result['changed'] == False
    assert result['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True}

    # Test data override
    action = ActionModule(None, {'data': {'foo': 'bar'}}, task_vars=task_vars)
    result = action.run(None, task_vars)
    assert result['changed'] == False

# Generated at 2022-06-11 12:34:06.968370
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class MockTask(object):
        def __init__(self, args):
            self.args = args
    class MockTemplar(object):
        def template(self, data, convert_bare=False, fail_on_undefined=True):
            return data
    task = MockTask(args={'data': {'key_1': 'value_1'}, 'aggregate': True, 'per_host': False})
    templar = MockTemplar()
    am = ActionModule({}, task, templar)
    result = am.run()
    assert result['ansible_stats'] == {'data': {'key_1': 'value_1'}, 'aggregate': True, 'per_host': False, 'failed': False}


# Generated at 2022-06-11 12:34:09.132325
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create a class object
    myclass = ActionModule()

    # check the super class of what we just created
    # should be ActionBase
    assert isinstance(myclass, ActionBase)

# Generated at 2022-06-11 12:34:15.995422
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule(None, {}, module_args={'aggregate': True, 'data': {'test': 1}, 'per_host': False})
    # test get_running_task_vars function
    am.get_running_task_vars = lambda: {'ansible_stats': {'aggregate': True, 'data': {'test': 1}, 'per_host': False}}
    am.run()
    # assert am.run()


# Generated at 2022-06-11 12:34:16.629126
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  assert True

# Generated at 2022-06-11 12:34:48.327185
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Class constructor test
    module = ActionModule(task=dict(action=dict(module='set_stats')))
    assert module._task.action['module'] == 'set_stats'


# Generated at 2022-06-11 12:34:55.264169
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    play_context = PlayContext()
    play_context.remote_addr = '192.168.0.1'
    test_ActionModule = ActionModule(loader=loader, play_context=play_context, new_stdin=None)
    test_ActionModule._task = mock_task1()

    assert test_ActionModule is not None
    assert test_ActionModule._VALID_ARGS == frozenset(['aggregate', 'data', 'per_host'])

# Unit testing for run method of class ActionModule

# Generated at 2022-06-11 12:34:56.106779
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 12:34:56.674956
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-11 12:35:05.440619
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    tmp = None
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module._task.args = {'data': {'foo': 'hello', 'bar': 'world'}}
    ansible_stats = {'data': {'foo': 'hello', 'bar': 'world'}, 'per_host': False, 'aggregate': True}
    result = action_module.run(tmp, task_vars)
    assert ansible_stats == result['ansible_stats']
    assert result['changed'] == False
    assert result['failed'] == False

    task_vars = dict()
    tmp = None

# Generated at 2022-06-11 12:35:11.459327
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(load_fixture('test_set_stats_action.yaml'),
                          load_fixture('test_set_stats_task.yaml'),
                          load_fixture('test_set_stats_play.yaml'))
    assert module._task.args == {u'data': {u'value': u'{{test_data}}'}}
    module.run()
    assert module.result['ansible_stats'] == {'aggregate': True, 'data': {u'value': u'yes'}, 'per_host': False}

# Generated at 2022-06-11 12:35:13.279815
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test for method run of class ActionModule
    pass


# Generated at 2022-06-11 12:35:14.889171
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # just test that the constructor will not blow up
    am = ActionModule(None, None)
    assert am is not None

# Generated at 2022-06-11 12:35:16.418220
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule()
    assert mod.run is not None
    assert mod.run_command is not None

# Generated at 2022-06-11 12:35:26.647176
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m_tmp = ''
    m_task_vars = {}
    m_self = {'_task': {'args': None}}
    m_super = {'run': lambda x, y: {
        'failed': True,
        'msg': "The 'data' option needs to be a dictionary/hash"
        }
    }

    action = ActionModule()
    action._tmp = m_tmp
    action._task_vars = m_task_vars
    for k, v in m_self.items():
        action.__setattr__(k, v)
    for k, v in m_super.items():
        action.__setattr__(k, v)

    result = action.run(m_tmp, m_task_vars)


# Generated at 2022-06-11 12:36:30.777732
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(1, 2, dict(), dict())
    # Asserts if the instance of ActionModule is created
    assert isinstance(action, ActionModule)

# Generated at 2022-06-11 12:36:33.186201
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # instantiating the object
    t = ActionModule()
    # method returns result
    result = t.run()
    # assert the result is a dictionary
    assert(isinstance(result, dict))

# Generated at 2022-06-11 12:36:34.233577
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: Implement
    return True

# Generated at 2022-06-11 12:36:42.603711
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # verify constructor
    action_module = ActionModule(
        task=dict(
            args={'data': {'key1': 'value1', 'key2': 'value2'}, 'per_host': True, 'aggregate': True}
        )
    )
    # verify attributes
    assert action_module.action == 'set_stats'
    assert action_module.action_type == 'collect'

    # verify argument(s)
    assert 'data' in action_module._task.args
    assert 'per_host' in action_module._task.args
    assert 'aggregate' in action_module._task.args

    # verify boolean option(s)
    assert boolean(action_module._task.args.get('per_host', None), strict=False) is True

# Generated at 2022-06-11 12:36:51.581474
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ans_obj = AnsibleModule(argument_spec=dict())

    source_hash = dict(
        data=dict(
            foo='bar',
            baz=dict(
                one='two',
                three='four'
            )
        ),
        per_host=False,
        aggregate=True
    )
    result_hash = dict(
        ansible_stats=dict(
            data=dict(
                foo='bar',
                baz=dict(
                    one='two',
                    three='four'
                )
            ),
            per_host=False,
            aggregate=True
        ),
        changed=False
    )
    test_obj = ActionModule(ans_obj, dict(task=dict(args=source_hash)))
    assert test_obj.run(task_vars={}) == result_hash


# Generated at 2022-06-11 12:36:52.342784
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, dict())
    assert module

# Generated at 2022-06-11 12:36:58.116437
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager

    results = {"ansible_stats": {
        "data": {
            "example_key": "example_value"
        },
        "per_host": True,
        "aggregate": True
    }}

    config = {"ansible_stats": {
        "data": {
            "example_key": "{{ fake_var }}"
        },
        "per_host": "{{ fake_var }}",
        "aggregate": "{{ fake_var }}"
    }}

    host = "127.0.0.1"

    task = Task()


# Generated at 2022-06-11 12:37:00.416072
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule({},{},{})
    result = action.run()
    assert result['ansible_stats']['aggregate'] is True

# test_ActionModule_run

# Generated at 2022-06-11 12:37:02.258913
# Unit test for constructor of class ActionModule
def test_ActionModule():

    assert ActionModule.TRANSFERS_FILES is False
    assert isinstance(ActionModule._VALID_ARGS, frozenset)



# Generated at 2022-06-11 12:37:10.138983
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    import os
    sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), os.pardir, os.pardir, 'lib'))

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    # create the dummy loader, need DataLoader instance to call get_basedir
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()