

# Generated at 2022-06-11 12:28:53.931687
# Unit test for constructor of class ActionModule
def test_ActionModule():
        action = ActionModule(
            task=dict(args=dict(
                aggregate='True',
                per_host='False',
                data=dict(
                    a=1,
                    b=2
                )
            )),
            connection= dict(),
            play_context= dict(),
            loader= dict(),
            templar= dict(),
            shared_loader_obj= dict()
        )
        assert action.TRANSFERS_FILES is False
        assert action._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))
        assert action.task is not None and isinstance(action.task, dict)
        assert action.connection is not None and isinstance(action.connection, dict)
        assert action.play_context is not None and isinstance(action.play_context, dict)


# Generated at 2022-06-11 12:29:03.922587
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.vars.hostvars import HostVars
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    class MockPlayContext(object):

        def __init__(self):
            self.connection = None
            self.remote_user = None
            self.prompt = None
            self.password = None
            self.port = None
            self.private_key_file = None
            self.timeout = 10
            self.shell = None
            self.become = False
            self.become_method = False
            self.become_user = None
            self.become_pass = None
            self.tags = ["all"]
            self.skip_tags = []
           

# Generated at 2022-06-11 12:29:14.733472
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import pytest

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean

    from ansible.plugins.action import ActionBase

    module_mock = ActionBase()

    data = {'data': {'var1': 100, 'var2': 'Hello', 'var3': False, 'var4': '{{var1}}'},
            'per_host': 'Yes',
            'aggregate': False}

    task_vars = {'var1': 100}

    module_mock.noop_set(boolean(True))

    result = module_mock.run(task_vars=task_vars, **data)


# Generated at 2022-06-11 12:29:18.028161
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am is not None

# Generated at 2022-06-11 12:29:20.162316
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = dict()
    a = ActionModule(None, task_vars)
    del a


# Generated at 2022-06-11 12:29:25.255930
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """FIXME"""
    ActionModule._templar = {'to_text': lambda x: x}
    # FIXME: Currently, ActionModule.run() ignores its tmp and task_vars arguments.
    assert ActionModule.run(None, None) == {}
    assert ActionModule.run(None, {}) == {}
    assert ActionModule.run(None, {'foo': 'bar'}) == {}
    return True


# Generated at 2022-06-11 12:29:35.683747
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Testing for ActionModule.run()

    # Initialise a ActionModule object
    m = ActionModule()

    # Initialise a 'tmp' variable
    tmp = ''

    # Initialise a 'task_vars' variable
    task_vars = dict()

    # Testing when the 'data' option is not a dictionary/hash
    m._task.args = {'data': '1'}
    result = m.run(tmp, task_vars)
    assert result['failed'] == True
    a = {'changed': False, 'msg': "The 'data' option needs to be a dictionary/hash",
         'ansible_stats': {'per_host': False, 'data': {}, 'aggregate': True}, 'failed': True}
    assert result == a

    # Testing when the 'data' option is a dictionary/hash


# Generated at 2022-06-11 12:29:46.135946
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext

    class TestTaskInclude(TaskInclude):
        _task_name = 'test_task_include'

        def __init__(self):
            self._parent = None
            self._role = None
            self._block = None
            self._play = None
            self._loader = None
            self._variable_manager = None
            self._task_vars = dict()
            self._loaded_from = None
            self._handlers = []
            self._block_list = []
            self._role_names = []
            self._loop = None
            self._loop_args = dict()
            self._when = None
            self._always_run = False
            self._notify = []


# Generated at 2022-06-11 12:29:48.759637
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert(action_module is not None)

# Generated at 2022-06-11 12:29:51.402354
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Unit tests for ActionBase class.
    """
    from ansible.playbook.task import Task

    set_stats = ActionModule(Task(), dict(TASK_NAME='TEST_TASK'))
    assert set_stats is not None

# Generated at 2022-06-11 12:30:05.062809
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Constructor of class ActionModule should return an object of ActionModule.
    """
    action_plugin = {'USER': 'foo', 'ANSIBLE_STDOUT_CALLBACK': 'foo', 'HOME': '/home/foo'}
    action_module = ActionModule(task=None, connection='local', play_context=None, loader=None, templar=None,
                                 shared_loader_obj=None, action_base=None, task_vars=None,
                                 default_vars=None, console_qty=None, console_password=None)
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-11 12:30:15.078537
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(None, None, None)
    action.action_loader = None
    action.runner = None
    action._connection = None
    action.task_vars = None
    action.task_vars = dict(test_var="test_value")
    action.task_vars['ansible_current_hosts'] = ['host1', 'host2']
    action._task = object
    action.super = object
    action.super.run = object
    action.super.run.return_value = dict()
    action._templar = object
    action._templar.template = lambda *args, **kwargs: args[0]
    action._task.args = dict(data=dict(test="{{ test_var }}"), aggregate=True, per_host=False)
    res = action.run()


# Generated at 2022-06-11 12:30:16.970357
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Add unit tests for method test_ActionModule_run of class ActionModule
    pass


# Generated at 2022-06-11 12:30:19.911315
# Unit test for constructor of class ActionModule
def test_ActionModule():

  stats = {'data': {'aggregate': True, 'per_host': False}}

  if len(stats['data']) > 0:
      print("{}".format(stats['data']))


# Generated at 2022-06-11 12:30:24.883415
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()
    am.run_async = True
    am._templar.available_variables = {}
    am._task.args = "data: {key: 'value'}"
    result = am.run()
    # Ensure that the stats has no data
    assert not result['ansible_stats']

# Generated at 2022-06-11 12:30:30.926738
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ah = ActionModule(task={
        'id': 1,
        'action': 'test',
        'args': {
            'data': {'key1': 'value1', 'key2': 'value2'},
            'per_host': True
        },
        'task': 'task1'
    }, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    ah.run()

# Generated at 2022-06-11 12:30:41.816924
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json

    # same variable in hostvars and set_stats, set_stats variable will be override
    hostvars = {"ansible_hostname": "test", "ansible_facts": {}, "ansible_all_ipv4_addresses": ["127.0.0.1"]}
    task = {'args': {'data': {'ansible_hostname': 'test2'}}}

    stats = ActionModule(load_plugins=False, task=task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None).run(tmp=None, task_vars=hostvars)

# Generated at 2022-06-11 12:30:47.876784
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # set_stats.py is an empty script with only docstring
    result = ActionModule(None, None, '/path/to/set_stats.py', {}, None, None, '')
    assert result.__class__.__name__ == 'ActionModule'
    assert result.SUCCESS == result.run()['changed']
    assert result.run(task_vars={})['changed'] == result.run(task_vars={})['changed']


# Generated at 2022-06-11 12:30:48.640963
# Unit test for constructor of class ActionModule
def test_ActionModule():
   am = ActionModule()

# Generated at 2022-06-11 12:30:51.639464
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(args=dict(data=1, aggregate=True, per_host=False)),
        connection=None,
        play_context=dict(check_mode=False),
    )

    assert module.run()

# Generated at 2022-06-11 12:31:02.821931
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    assert 'ansible_stats' in ActionModule(dict_map=dict(), templar=dict()).run()



# Generated at 2022-06-11 12:31:10.953967
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=dict(action=dict(__name__='action_module')), task_vars=dict(), templar=dict())
    args = dict(aggregate=None, data=None, per_host=None)

    result = action.run(task_vars=dict(), tmp=None, args=args)
    
    assert result['ansible_stats']['per_host'] is False
    assert result['ansible_stats']['aggregate'] is True
    assert result['ansible_stats']['data'] == {}

    args = dict(aggregate=True, data={'alpha': 'beta'}, per_host=False)
    result = action.run(task_vars=dict(), tmp=None, args=args)


# Generated at 2022-06-11 12:31:22.247168
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert isinstance(action.run, object)
    assert isinstance(action.run_task, object)
    assert isinstance(action.run_safe, object)
    assert isinstance(action.run_simple, object)
    assert isinstance(action.run_main, object)
    assert isinstance(action.run_main_list, object)
    assert isinstance(action.run_main_rc, object)
    assert isinstance(action.run_main_json, object)
    assert isinstance(action.run_main_yaml, object)
    assert isinstance(action.run_main_role, object)
    assert isinstance(action.do_template, object)
    assert isinstance(action.do_copy, object)
    assert isinstance(action.do_script, object)
   

# Generated at 2022-06-11 12:31:26.252479
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule()
    mod._keep_remote_files = []

    f = dict(
        name='test_module',
        action=dict(module_name='test', module_args=dict(data=dict(test='missing'))),
        task=dict(args=dict(data=dict(test='missing'))),
    )
    host = dict(name='test_host')
    tqm = dict(hostvars={})
    res = {}

    mod.run(tmp=None, task_vars=tqm)

# Generated at 2022-06-11 12:31:33.085991
# Unit test for method run of class ActionModule
def test_ActionModule_run():

	_VALID_ARGS = frozenset(('aggregate', 'data', 'per_host'))

	task_vars = dict()
	tmp = None

	ActionBase.run(tmp, task_vars)	

	result = ActionModule.run(tmp, task_vars)

	# check for 'msg' key in result
	try:
		if result['msg'] is not None:
			print('test_ActionModule_run: PASS')
	except Exception as e:
		print('test_ActionModule_run: FAIL')


# Generated at 2022-06-11 12:31:38.928030
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(b_vars=dict(a="a",b="b"),task=dict(action=dict(module_name="a"),args=dict(data=dict(a=1)),name="name",delegate_to="delegate_to")),connection=None,play_context=None,loader=None,templar=None,shared_loader_obj=None)


if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-11 12:31:48.969398
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.modules.monitoring.zabbix import set_stats
    from ansible.module_utils.parsing.convert_bool import boolean

    module = set_stats.ActionModule(None, None, None, None, None)
    assert module

    tmp, task_vars = 'tmp', {}
    result = module.run(tmp, task_vars)
    assert not result['failed']
    assert result['ansible_stats']
    assert isinstance(result['ansible_stats'], dict)
    assert result['ansible_stats']['data']
    assert result['ansible_stats']['per_host'] is False
    assert result['ansible_stats']['aggregate'] is True

    task_vars = {}
    result = module.run(tmp, task_vars)

# Generated at 2022-06-11 12:31:51.330650
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, {}).run('', {}) == dict(failed=True, msg='The \'data\' option needs to be a dictionary/hash')

# Generated at 2022-06-11 12:31:57.129347
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # setup
    # initialize arguments used in calling run method
    tmp = None
    task_vars = None
    # initialize object of ActionModule class
    test = ActionModule(None, None)
    # call run method of ActionModule class
    # assert result of called method is the expected result
    assert test.run(tmp, task_vars) == {'changed': False, 'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}}


# Generated at 2022-06-11 12:32:02.458581
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    task = Task()
    action_plugin = ActionModule(task, PlayContext())


if __name__ == '__main__':
    # Unit test for constructor of class ActionModule
    test_ActionModule()

# Generated at 2022-06-11 12:32:24.716436
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class AnsibleModule(object):
        args = {}
    class PlayContext(object):
        module_vars = {}
    class Task(object):
        args = {}
    class Play(object):
        pass

    obj = ActionModule(AnsibleModule(), PlayContext(), Task(), Play())
    assert obj is not None

# Generated at 2022-06-11 12:32:35.221836
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit test for method run of class ActionModule """
    # Test with data is not a dict
    stats = {'data': {}, 'per_host': False, 'aggregate': True}
    task_vars = {}
    test_ActionModule = ActionModule(None, None, task_vars)
    result = test_ActionModule.run(None, task_vars)
    assert result['failed'] == True
    assert result['msg'] == "The 'data' option needs to be a dictionary/hash"

    # Test with data is not a dict but is a string get from a template
    stats = {'data': {}, 'per_host': False, 'aggregate': True}
    task_vars = {}
    test_ActionModule = ActionModule(None, None, task_vars)
    result = test_ActionModule.run

# Generated at 2022-06-11 12:32:43.884879
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # emtpy task
    task = dict(action=dict(module='set_stats'))
    # setup connection
    connection = dict(play_hosts=['127.0.0.1'],
                      transport='local',
                      remote_addr='127.0.0.1',
                      remote_user='user',
                      runner_path='/path/to/ansible/lib/',
                      module_path='/path/to/ansible/lib/')
    variable_manager = '' #TODO
    loader = '' #TODO
    # pass it to ActionModule constructor
    a = ActionModule(task, connection, variable_manager, loader)
    # check result
    assert a.TRANSFERS_FILES == False

# Generated at 2022-06-11 12:32:45.077173
# Unit test for constructor of class ActionModule
def test_ActionModule():

    module = ActionModule()

    print(module.transfers_files)

# Generated at 2022-06-11 12:32:54.528837
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    inv = {'stats': {'changed': False, 'failures': 0, 'ok': 1, 'skipped': 0, 'unreachable': 0}}
    task_vars = {'ansible_facts': {'ansible_machine_id': 'fake_machine_id'}, 'ansible_check_mode': False}
    tmp = None
    m = 'test_ActionModule_run'

    class FakeModule(object):
        def __init__(self, *args, **kwargs):
            self.params = {'data': {}, 'per_host': True, 'aggregate': False}
            self.args = self.params

    am = ActionModule(FakeModule(), task_vars=task_vars)

    result = am.run(tmp, task_vars)

    assert type(result) is dict
   

# Generated at 2022-06-11 12:33:03.546400
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.set_stats import ActionModule
    p = ActionModule({})

    # Test default values
    assert p._VALID_ARGS == frozenset(['aggregate', 'data', 'per_host'])
    assert p.TRANSFERS_FILES == False

    # Test TRANSFERS_FILES getter
    assert p.transfers_files == False

    # Test TRANSFERS_FILES setter
    p.TRANSFERS_FILES = True
    assert p.transfers_files == True

    # Test constructor with default empty parameters
    assert p.run() == {
        'ansible_stats': {
            'data': {},
            'per_host': False,
            'aggregate': True
        },
        'changed': False
    }


# Generated at 2022-06-11 12:33:04.096862
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a is not None

# Generated at 2022-06-11 12:33:05.224980
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_ActionModule = ActionModule()
    test_ActionModule.run()

# Generated at 2022-06-11 12:33:11.550081
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.errors import AnsibleParserError

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader, variable_manager)
    variable_manager.set_inventory(inventory)
   

# Generated at 2022-06-11 12:33:19.755446
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_ans_inst = MockAnsibleModule()
    mock_ans_inst.params = {}
    mock_ans_inst.params['data'] = {'success': True}
    mock_ans_inst.params['per_host'] = True
    mock_ans_inst.params['aggregate'] = True
    action_mod = ActionModule(mock_ans_inst, 'set_stats')
    result = action_mod.run(tmp=None, task_vars=dict())
    assert result
    assert result['ansible_stats'] == {'data': {'success': True}, 'per_host': True, 'aggregate': True}


# Generated at 2022-06-11 12:34:00.338551
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule._VALID_ARGS == frozenset(['aggregate', 'data', 'per_host'])
    assert ActionModule.TRANSFERS_FILES == False


# Generated at 2022-06-11 12:34:06.067795
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule()
    assert m.TRANSFERS_FILES is False
    assert isinstance(m._VALID_ARGS, frozenset)
    assert isidentifier('mydata') is True
    # Variables must start with a letter or underscore character, and contain only letters, numbers and underscores.
    assert isidentifier('123') is False
    assert isidentifier('1_test') is False
    assert isidentifier('-test') is False
    assert isidentifier('@test') is False

# Generated at 2022-06-11 12:34:14.473357
# Unit test for constructor of class ActionModule
def test_ActionModule():
    def __new__(subclass, *args, **kwargs):
        return args[0]

    dummy_class = type('DummyClass', (object,), {})
    dummy_class.__new__ = __new__

    task = dummy_class()
    task.args = {
        'data': {
            'foo': 'bar'
        },
        'per_host': True,
        'aggregate': False
    }

    res = task.module_executor('ActionModule')

    assert res.ansible_stats == {
        'data': {
            'foo': 'bar'
        },
        'per_host': True,
        'aggregate': False
    }

# Generated at 2022-06-11 12:34:23.547082
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Test with no data
    action = ActionModule(dict(args=dict()))
    assert action.run() == {"ansible_stats": {"aggregate": True, "data": {}, "per_host": False}, "changed": False}

    # Test with invalid data
    action = ActionModule(dict(args=dict(data='foo')))
    assert action.run()['msg'] == "The 'data' option needs to be a dictionary/hash"
    assert action.run()['failed']

    # Test with one variable that needs templating
    action = ActionModule(dict(args=dict(data=dict(foo='{{bar}}'))))

# Generated at 2022-06-11 12:34:26.432511
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(task={'action': {'module': 'set_stats', 'args': {'data': {'k1': 'v1'}, 'per_host': True, 'aggregate': True}}}, connection={}), tmp={}, task_vars={})

# Generated at 2022-06-11 12:34:35.226670
# Unit test for constructor of class ActionModule
def test_ActionModule():
    curdir = os.path.dirname(__file__)
    set_stats_file = os.path.join(curdir, "set_stats.yml")


# Generated at 2022-06-11 12:34:40.058661
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert 'ActionModule' in globals(), "Class `ActionModule` not found"
    action_module = globals()['ActionModule']

    assert 'run' in dir(action_module), "Method `run` not found"
    assert callable(action_module.run), "Method `run` is not callable"

# Generated at 2022-06-11 12:34:48.449861
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TestVarsModule:
        def __init__(self):
            self.args = {}

    class TestActionBase:
        def __init__(self, task):
            self._task = task

    am = ActionModule()
    am.action = 'am'
    am._shared_loader_obj = TestVarsModule()
    am._task = TestActionBase(am)

    assert isinstance(am.action, string_types)
    assert am.action == 'am'
    assert isinstance(am._shared_loader_obj, TestVarsModule)
    assert isinstance(am._task, TestActionBase)
    assert am._task == am
    assert isinstance(am._task._task, ActionModule)

# Generated at 2022-06-11 12:34:51.317029
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Test for method run of class ActionModule')
    actionmodule = ActionModule()
    result = actionmodule.run()
    assert(result['failed'] == True)
    print('End of test for method run of class ActionModule')

# Generated at 2022-06-11 12:35:00.230002
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from collections import namedtuple
    import sys
    import os

    if sys.version_info < (3,):
        from mock import patch, Mock, MagicMock
    else:
        from unittest.mock import patch, Mock, MagicMock

    from ansible.module_utils.basic import AnsibleModule

    from ansible.module_utils._text import to_bytes
    from ansible.utils import context_objects as co
    from ansible.plugins.loader import action_loader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.template import Templar

    from ansible.module_utils.parsing.convert_bool import boolean

    sys.modules['ansible'] = Mock()

# Generated at 2022-06-11 12:36:46.549666
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule({'args': {'data': {'test': 'dummy'}}}), ActionModule)

# Generated at 2022-06-11 12:36:50.196475
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    with pytest.raises(Exception) as e:
        assert(ActionModule(tmp='', task_vars=None).run())
    assert("not implemented" in str(e))

# Generated at 2022-06-11 12:36:51.469951
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_module = ActionModule(None, None)


# Generated at 2022-06-11 12:36:55.755223
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Unit tests for the constructor of ActionModule.
    """
    mod = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Test _VALID_ARGS
    expected = frozenset(('aggregate', 'data', 'per_host'))
    assert mod._VALID_ARGS == expected

    # Test TRANSFERS_FILES
    assert not mod.TRANSFERS_FILES

# Generated at 2022-06-11 12:36:58.571097
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args = {'data': {'test': 1}}
    stats = {'data': {'test': 1}, 'per_host': False, 'aggregate': True}
    action = ActionModule(is_setup=False, task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action.run(args) == {'ansible_stats': stats, 'changed': False}

# Generated at 2022-06-11 12:37:03.845976
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins
    loader = ansible.plugins.loader
    mod = loader.get("action", "set_stats")
    ins = mod()

    assert ins.run({'data':{'foo':'bar','test_value':100}}) == {'ansible_facts': {}, 'changed': False, 'ansible_stats': {'data': {'foo': 'bar', 'test_value': 100}, 'per_host': False, 'aggregate': True}}

# Generated at 2022-06-11 12:37:11.703485
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.vars import ModuleArgsParser
    a = {"data":{"tomato":"hello"}}
    b = {"data":{"egg":"hello"}}
    c = {"data": "{{tomato}}"}
    d = {"data":"key","per_host":False,"aggregate":True}
    e = {"data":"key","per_host":"false","aggregate":"true"}
    f = {"data":"key","per_host":True,"aggregate":False}
    g = {"data":"key","per_host":"true","aggregate":"false"}
    h = {"data":"key"}
    i = {"data":"{{tomato}}"}
    j = {"data":"{{egg}}"}
    k = {"data":"{{data}}"}
    m = {"data":{"{{key}}":"{{value}}","foo":"bar"}}
    n

# Generated at 2022-06-11 12:37:12.226739
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-11 12:37:17.017554
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test with no argument
    mod = ActionModule(None, None, 0)
    assert mod is not None
    assert mod._task.args == {}

    # test with arguments
    args = {'aggregate': True, 'data': {'number_of_changes': 0}, 'per_host': False}
    mod = ActionModule(None, None, args)
    assert mod is not None
    assert mod._task.args == args

# Generated at 2022-06-11 12:37:18.354482
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a1 = ActionModule(ActionBase())
    assert a1

# Unit test 