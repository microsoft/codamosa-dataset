

# Generated at 2022-06-11 12:28:46.225752
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule)
    # TODO: Add more tests for ActionModule

# Generated at 2022-06-11 12:28:47.091399
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert "ActionModule" == ActionModule.__name__

# Generated at 2022-06-11 12:28:48.057772
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement this
    pass

# Generated at 2022-06-11 12:28:54.030478
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_task = MockTask()
    a = ActionModule(mock_task, mock_connection, '/tmp/foo', '', '', '', '')

    assert a._task == mock_task
    assert a._connection == mock_connection
    assert a._loader == mock_loader
    assert a._templar == mock_templar
    assert a._shared_loader_obj == mock_shared_loader_obj
    assert a._task_vars == 'task variables'



# Generated at 2022-06-11 12:29:04.013731
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = dict(
        action=dict(
            module='set_stats',
            data=dict(
                test_key='test_value',
                test_key2='{{ test_value }}',
                test_key3='{{ test_value }}.test'
            ),
            per_host='{{ per_host }}',
            aggregate='{{ aggregate }}',
        )
    )

    task_vars = dict(
        per_host=True,
        aggregate=False,
        test_value='test value'
    )

    action = ActionModule(task, task_vars=task_vars)

    actual = action.run(task_vars=task_vars)

    assert actual['ansible_stats']['data']['test_key'] == 'test_value'

# Generated at 2022-06-11 12:29:09.407816
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule"""
    # use any implementation class of ActionBase that has a method run
    action = ActionModule()

    # tested method run of ActionModule
    result = action.run()

    # basic test to check that all keys of dictionary result have been set by run method
    assert set(result) == {'failed', 'ansible_stats', 'changed', 'msg'}

# Generated at 2022-06-11 12:29:10.000676
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:29:21.490136
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager

    task_queue_manager = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback='null',
    )

    play_context = PlayContext()  # noqa
    task = TaskResult(host=None, task=None)
    task._role = None
    task._task = task # noqa


# Generated at 2022-06-11 12:29:23.356265
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # creating ActionModule constructor
    am = ActionModule()
    # checking if we have class attributes
    assert am._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))
    assert am.TRANSFERS_FILES == False

# Generated at 2022-06-11 12:29:24.766850
# Unit test for constructor of class ActionModule
def test_ActionModule():
   # Check for function that creates an instance of ActionModule
   # assert_raises(ActionModule)
   assert True

# Generated at 2022-06-11 12:29:40.878640
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys

    # Replace sys.modules in order to mock functions
    sys.modules['ansible.plugins.action'] = sys.modules['tests.mock.ansible.plugins.action']
    sys.modules['ansible.module_utils.parsing.convert_bool'] = sys.modules['tests.mock.ansible.module_utils.parsing.convert_bool']
    sys.modules['ansible.module_utils.six'] = sys.modules['tests.mock.ansible.module_utils.six']

    import tests.mock.ansible

    # Test for successful run of method
    result = tests.mock.ansible.plugins.action.ActionModule.run('', '',
                                                                per_host=False,
                                                                aggregate=True,
                                                                data='dict')

# Generated at 2022-06-11 12:29:50.154213
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # First we create an instance of the class we are testing
    my_Test_ActionModule = ActionModule()

    # Now we instanciate some arguments that we will use to call the method
    tmp=None
    task_vars = dict()
    task_args_valid = {'data': {'key1':1, 'key2': 2}, 'per_host': False, 'aggregate': False}
    task_args_data_invalid = {'data': 'a_string_is_not_valid'}
    task_args_per_host_invalid = {'data': {'key1':1, 'key2': 2}, 'per_host': 'invalid_type'}

# Generated at 2022-06-11 12:29:51.835006
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # WHEN
    action_module = ActionModule()

    # THEN
    assert action_module.TRANSFERS_FILES is False

# Generated at 2022-06-11 12:29:58.250037
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, None, None)
    try:
        am.run()
    except (TypeError, NameError) as e:
        assert False, "ActionModule unit test failed because of exception: " + str(e)
    except SystemExit as e:
        # Catching SystemExit because it happens when tests are run with -v flag
        # Expected exit code from ActionModule is 3
        assert e.code == 3, "ActionModule unit test failed because of exception: " + str(e)

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-11 12:30:09.400257
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest

    module_mock = pytest.Mock()
    templar_mock = pytest.Mock()
    task_vars = {'foo': 'foo', 'bar': 'bar'}
    args = {'data': {'a': 'A', 'b': 'B'}, 'aggregate': True, 'per_host': True}
    kwargs = {'module': module_mock, 'task_vars': task_vars, 'task_args': args}

    data = {'a': 'A', 'b': 'B'}
    templar_mock.template.side_effect = lambda x, **kwargs: x
    action_module = ActionModule(**kwargs)
    action_module.run()
    module_mock.run.assert_called_once_with

# Generated at 2022-06-11 12:30:17.399037
# Unit test for constructor of class ActionModule

# Generated at 2022-06-11 12:30:24.334334
# Unit test for constructor of class ActionModule
def test_ActionModule():
    data = {'data': {'var1': 'value1', 'var2': 'value2'}}
    task_vars = {'ansible_stats': {'data': {'var1': 'value1', 'var2': 'value2'}}}
    action_module = ActionModule(None, None, None, data)
    result = action_module.run(None, task_vars)
    assert result['ansible_stats'] == result['ansible_stats']

# Generated at 2022-06-11 12:30:28.943031
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of ActionModule
    actionModule = ActionModule()

    # Check __doc__
    assert actionModule.__doc__ == 'Action plugin to set_stats.'

    # Check run function.
    actionModule.run(tmp = "temporary directory", task_vars = {"TEST_VARIABLE":"TEST_VALUE"})

# Generated at 2022-06-11 12:30:36.717829
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()

    # Test action with dictionary passed in 'data' option
    result = module.run(tmp=None, task_vars=None)
    assert result['changed'] == False
    assert result['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True}

    # Test action with string template
    result = module.run(tmp=None, task_vars=None)
    assert result['changed'] == False
    assert result['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True}

# Generated at 2022-06-11 12:30:47.725008
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # set up argument parsing for run()
    module = ActionModule()
    module._configure_module()
    module._task.args = dict(
        aggregate=True,
        per_host=False,
        data=dict(
            success_hosts="{{success_hosts | length}}",
            failure_hosts="{{failure_hosts | length}}",
            unreachable_hosts="{{unreachable_hosts | length}}")
    )

    # create a mock task_vars for AnsibleModule.run()
    task = dict()
    task_vars = dict(
        success_hosts=['a', 'b'],
        unreachable_hosts=[],
        failure_hosts=[],
    )

    # create mock run() method and run it
    result = dict()

# Generated at 2022-06-11 12:31:07.205582
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task

    def __init__(self, runner):
        self.runner = runner

    Task.__init__ = __init__

    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

    task = Task()
    block = Block()
    play_context = Play()
    task_vars = dict()

    action = ActionModule(task, play_context, task_vars)
    assert action.runner is not None
    assert action._task.loop is None
    assert action._task._parent is None

    task = TaskInclude()
    block = Block()
    play_context = Play()
    task_vars = dict()


# Generated at 2022-06-11 12:31:16.599604
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    results = []
    module_name = 'set_stats'

    def run_hook(caller=None):
        caller._load_params()
        results.extend([caller._task.args, caller._task.action])

    m = ActionModule(None, run_hook, None)

    expected_run_args = {}
    expected_run_action = 'set_stats'
    m.run()
    assert results[0] == expected_run_args
    assert results[1] == expected_run_action

    expected_run_args = {'data': {}, 'per_host': False, 'aggregate': True}
    expected_run_action = 'set_stats'
    m.run(task_vars={})
    assert results[2] == expected_run_args
    assert results[3] == expected_

# Generated at 2022-06-11 12:31:28.047121
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook import Play
    from ansible.playbook.task import Task
    from ansible.module_utils.parsing.convert_bool import boolean

    module = ActionModule()

    data = {'name': 'example_name', 'src': 'example_src', 'args': {}}
    module._task = Task()

    # No data
    module._task.args = {}
    result = module.run(None, None)
    assert result['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True}, "No data results are not as expected."

    # Empty data
    module._task.args = {'data': {}}
    result = module.run(None, None)

# Generated at 2022-06-11 12:31:28.632692
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:31:30.583799
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("success")
    return 0

if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-11 12:31:35.532267
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isidentifier("a")
    assert isidentifier("a1")
    assert isidentifier("a1b")
    assert isidentifier("a1B")
    assert isidentifier("_a")
    assert isidentifier("_a1")
    assert isidentifier("_a1b")
    assert isidentifier("_a1B")
    assert isidentifier("_")
    assert not isidentifier("3a")
    assert not isidentifier("a b")
    assert not isidentifier("a.b")
    assert not isidentifier("a+b")

# Generated at 2022-06-11 12:31:37.303268
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext

    ActionModule(None, PlayContext()) # noqa

# Generated at 2022-06-11 12:31:47.188335
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup test data
    action_module = ActionModule(None, None, None, None)
    action_module.datastructure = None
    action_module._play_context = None
    action_module._task = None
    action_module._loader = None
    action_module._shared_loader_obj = None
    action_module._connection = None
    action_module._task_vars = None
    action_module._templar = None
    action_module._task_vars = None
    action_module._remote_module = None
    action_module._keep_remote_files = None
    action_module._handle_warnings = None
    action_module._low_level_debug = None
    action_module._diff = None
    action_module.set_options = None
    action_module._templar = None

# Generated at 2022-06-11 12:31:56.813118
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module.transfers_files = False
    module._VALID_ARGS = frozenset(('aggregate', 'data', 'per_host'))

    module._task.args = {'data': {'age': '{{ ansible_user_id.age }}'}}
    module._task.action = 'set_stats'
    module._connection.become = False
    module._connection.become_method = 'sudo'
    module._connection.become_user = 'root'
    module._play_context = {}
    module._play_context.become = False
    module._play_context.connection = 'smart'
    module._play_context.become_method = 'sudo'
    module._play_context.become_user = 'root'
    module._loader = None
   

# Generated at 2022-06-11 12:32:07.931060
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  print("")
  print("#### test_ActionModule_run ####")

  from ansible.compat.tests import unittest

  # Create test class
  class TestBaseActionModule(unittest.TestCase):
    def __init__(self, methodName):
      print("")
      print("#### test_ActionModule_run__init__ ####")
      super(TestBaseActionModule, self).__init__(methodName)
    
    def setUp(self):
      print("")
      print("#### test_ActionModule_run_setUp ####")

      # Human-readable formatter (default)
      #self.runner = CliRunner()

      # Machine parseable format
      #self.runner = CliRunner(formatter=MachineFormatter())

    def tearDown(self):
      print("")
     

# Generated at 2022-06-11 12:32:37.430253
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory import Inventory
    from ansible.utils.display import Display
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader


    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost')
    variable_manager.set_inventory(inventory)
    display = Display()


# Generated at 2022-06-11 12:32:45.665527
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.parsing.convert_bool import boolean

    am = ActionModule(AnsibleModule({'per_host': True, 'aggregate': False},
                                    bypass_checks=False))
    assert am.stats['per_host'] == True
    assert am.stats['aggregate'] == False

    am = ActionModule(AnsibleModule({'per_host': "yes", 'aggregate': "False"},
                                    bypass_checks=False))
    assert am.stats['per_host'] == boolean('yes', strict=False)
    assert am.stats['aggregate'] == boolean('False', strict=False)

# Generated at 2022-06-11 12:32:55.329381
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class ActionModuleTest(ActionModule):
        # Unit test for method run of class ActionModule

        # TODO: document this method in non-empty set_stats.py module
        def run(self, tmp=None, task_vars=None):
            if task_vars is None:
                task_vars = dict()

            result = super(ActionModuleTest, self).run(tmp, task_vars)
            del tmp  # tmp no longer has any effect

            return result
    # Create an object of ActionModuleTest class
    action_module_test = ActionModuleTest(
        task=dict(),
        connection=dict(),
        _play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict())
    assert type(action_module_test.run()) == dict



# Generated at 2022-06-11 12:32:56.674348
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test constructor of class ActionModule
    am = ActionModule()

# Generated at 2022-06-11 12:33:05.150714
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))
    assert ActionModule.TRANSFERS_FILES


# @TODO:  Add unit tests for the run() method
#         This will require a mock object for the AnsibleModule
#         class, along with a mock object for the PlayContext class
#         and the TaskExecutor class
#         The implementation would be:
#         1) Calling the run() method of the ActionModule super class
#         2) The super class would use the AnsibleModule to get the
#            actual arguments to the module
#         3) The super class would call the TaskExecutor run() method
#         4) The TaskExecutor run() method would execute the task using
#            the AnsibleModule class
#         5) The AnswerModule constructor is passed a

# Generated at 2022-06-11 12:33:05.942793
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-11 12:33:11.988673
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_args = {'_ansible_remote_tmp': '/tmp', '_ansible_keep_remote_files': True,
                   '_ansible_no_log': False, '_ansible_debug': False,'_ansible_verbosity': 1,
                   '_ansible_action': 'set_stats',
                   '_ansible_job_id': '1', '_ansible_config': '/etc/ansible/ansible.cfg'}
    task_args = {'data': {'example': 1, 'var1': 'var1_value', 'var2': 'var2_value'},
                 'aggregate': True, 'per_host': False}

# Generated at 2022-06-11 12:33:20.152150
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(load_fixture('set_stats_template.yml'), {})
    task_vars = {'ansible_facts': {'a': 1, 'b': 2}}
    module._templar = Templar(task_vars, {})
    result = module.run(None, task_vars)
    assert result['changed'] is False
    assert not result['failed']
    assert result['ansible_stats']['data'] == {'x': 1, 'y': 2, 'z': '{{a}}'}
    assert result['ansible_stats']['per_host'] is True
    assert result['ansible_stats']['aggregate'] is False

# Generated at 2022-06-11 12:33:27.009150
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.set_stats
    sample_args = {'aggregate': False, 'data': {"key1": 10, "key2": 10.0, "key3": "value", "key4": "{{ lookup('file','sample_file') }}"}, 'per_host': True}
    am = ansible.plugins.action.set_stats.ActionModule(dict(module_args=sample_args))
    import json
    # Checking if the constructor of class ActionModule is running fine or not.
    assert isinstance(json.dumps(am.run()), string_types)

# Generated at 2022-06-11 12:33:35.213622
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    #setup test environment
    import ansible.module_utils.parsing.convert_bool as module
    module.boolean = boolean

    m = AnsibleModule()
    m._ansible_module_name='set_stats'
    m._ansible_module_instance = None
    m.params = {}

    #setup test data
    data = {'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}}

    #test the run method of ActionModule
    action = ActionModule(m, {}, {})
    result = action.run(tmp=None, task_vars=None)
    del action

    assert result == data
    data = 'sample'
    assert result != data

    #test when data is not a dictionary

# Generated at 2022-06-11 12:34:24.732570
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a new ActionModule object
    ActionModule = __import__("ansible.plugins.action.set_stats").ActionModule
    action_module = ActionModule(dict(name='set_stats test call', task=dict(_id=1)), dict(DEFAULT_HASH_BEHAVIOUR="replace"))
    action_module.datastructure_safe=True

    # Run the method we are testing: run
    # The first 3 arguments are hard-coded to be None, as we are not testing
    # this object's methods' ability to run a task.
    # The next argument is a list that we will be using as the module's arguments
    # for the purpose of this test.
    # The last argument is a dict that we will be using as the module's choices
    # for the purpose of this test.
    # The return value of the run method will

# Generated at 2022-06-11 12:34:25.573538
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-11 12:34:27.168315
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()


# Generated at 2022-06-11 12:34:35.726210
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = {}

    # method idempotency test
    result = module.run(tmp='', task_vars={})
    assert result['changed'] == False
    assert result['ansible_stats']['aggregate'] == True
    assert result['ansible_stats']['per_host'] == False
    assert len(result['ansible_stats']['data']) == 0

    # data is not a dictionary
    result = module.run(tmp='', task_vars={'foo': 'bar'})
    assert result['failed'] == True
    assert 'msg' in result

    # test boolean options with True values

# Generated at 2022-06-11 12:34:37.527108
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing ActionModule run")
    assert True

# Generated at 2022-06-11 12:34:39.294247
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # The constructor of class ActionModule should always return an object
    assert(ActionModule() is not None)

# Generated at 2022-06-11 12:34:41.601704
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule.run(None, {'data': {'foo': 10, 'bar': 20}, 'per_host': False, 'aggregate': True})
    assert True == False

# Generated at 2022-06-11 12:34:43.222212
# Unit test for constructor of class ActionModule
def test_ActionModule():
    set_stats_obj = set_stats()
    print("Set Stats Object :: ",set_stats_obj)

# Generated at 2022-06-11 12:34:52.378160
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(load_context=True)
    action._task.args['per_host'] = '{{ test }}'
    action._templar.available_variables = dict(test=True)
    action._templar.template = lambda x, convert_bare=False, fail_on_undefined=True: x
    try:
        result = action.run()
    except Exception as e:
        assert False, 'Failed: ' + str(e)

    if result.get('failed', False):
        assert False, result.get('msg', 'Failed and no msg')

    assert result.get('changed', False) is False, 'Expected changed to be False'
    assert 'ansible_stats' in result, 'ansible_stats should be in output'

# Generated at 2022-06-11 12:34:56.789642
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # No parameter, default settings
    class MockTask:
        def __init__(self):
            self.args = {}
    action = ActionModule(MockTask())
    assert action._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))
    assert action.TRANSFERS_FILES == False
    result = action.run(tmp=None, task_vars=None)
    del result['msg']
    del result['failed']
    assert result == { 'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True},
                       'changed': False}

    # Specify valid data
    class MockTask:
        def __init__(self):
            args = {}
            args['data'] = {}

# Generated at 2022-06-11 12:36:44.670505
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(load_fixture('set_stats/fixture1.yml'))

    assert isinstance(module.run(task_vars={}), dict)

# Generated at 2022-06-11 12:36:51.124600
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    task_vars = {}
    action = ActionModule(None, {})
    action._task = {}
    action._task.args = {}
    action._task.args['data'] = {}
    action._task.args['data']['testVar'] = "testValue"
    action._task.args['data']['testBool'] = False
    action._task.args['per_host'] = "yes"
    action._task.args['aggregate'] = "no"
    acti

# Generated at 2022-06-11 12:36:57.324782
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_args = {
        'aggregate': False,
        'data': {
            "test_str": "str",
            "test_int": 42,
            "test_bool": True
        },
        'per_host': True
    }

    stats = {'changed': False, 'ansible_stats': {'data': {'test_int': 42, 'test_bool': True, 'test_str': 'str'}, 'per_host': True, 'aggregate': False}}

    def get_mock_task(args):
        mock_task = Mock()
        mock_task.args = args
        return mock_task

    def get_mock_action(args):
        mock_action = Mock()
        mock_action._task = get_mock_task(args)
        return mock_action

    mock

# Generated at 2022-06-11 12:37:05.716017
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task
    from ansible.template import Templar

    task = Task()
    task._role = None
    task.args = {'data': {'foo': 'bar', 'baz': 'bat'}}
    loader = DataLoader()
    templar = Templar(loader=loader)
    task_vars = {'ansible_service_mgr': 'systemd'}

    module = ActionModule(task, connection=None, play_context=None, loader=loader, templar=templar, shared_loader_obj=None)

    res = module.run(task_vars=task_vars)

    assert 'ansible_stats' in res

# Generated at 2022-06-11 12:37:13.350182
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test for unsupported args
    args = {'aggregate': '', 'per_host': False, 'data': [1,2,3]}
    action_module = ActionModule(dict(action='ansible.actions.core.set_stats'))
    result = action_module.run(task_vars=dict(ansible_check_mode=True))
    assert result['failed'] == True

    # test for invalid data
    args = {'aggregate': '', 'per_host': False, 'data': {'k1': 'v1', 1: 'v1'}}
    action_module = ActionModule(dict(action='ansible.actions.core.set_stats'))
    result = action_module.run(task_vars=dict(ansible_check_mode=True))
    assert result['failed'] == True



# Generated at 2022-06-11 12:37:21.653248
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test empty task_args
    module = ActionModule(None)
    task_args = dict()
    result = module.run(task_vars=None, task_args=task_args)
    assert result['ansible_stats']['data'] == {}
    assert result['ansible_stats']['aggregate'] is True
    assert result['ansible_stats']['per_host'] is False

    # test task_args with task_vars
    task_args = dict(data=dict(a=dict(b="{{ my_var }}")))
    module = ActionModule(None)
    result = module.run(task_vars=dict(my_var="c"), task_args=task_args)
    assert result['ansible_stats']['data'] == dict(a=dict(b="c"))


# Generated at 2022-06-11 12:37:28.691237
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    data = {'data': {'foo': 'Foo', 'spam': 'Spam'}, 'per_host': False, 'aggregate': True}
    module = ActionModule(load_fixture_file('set_stats.py'), data, True)
    template = """
        data:
          foo: Foo
          spam: Spam
        aggregate: yes
        per_host: no
    """
    module.load_task_vars(template)
    result = module.run()
    assert result['changed'] == False
    assert result['ansible_stats']['data']['foo'] == 'Foo'
    assert result['ansible_stats']['data']['spam'] == 'Spam'
    assert result['ansible_stats']['per_host'] == False

# Generated at 2022-06-11 12:37:32.454907
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print('Test ActionModule_run into module ansible.plugins.action.set_stats')
    # TODO: add more unit tests

    a = ActionModule(dict(args=dict(data=dict(a='b'))))
    result = a._execute_module(None, None, None, None, None)
    print(result)


test_ActionModule_run()

# Generated at 2022-06-11 12:37:37.376776
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    result = module.run('/tmp', {'play_hosts': ['localhost', 'remotehost'], 'foo': 'bar'})
    assert result['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True}
    result = module.run('/tmp', {'play_hosts': ['localhost', 'remotehost'], 'foo': 'bar'})
    assert result['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True}


# Generated at 2022-06-11 12:37:45.751327
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class Options(object):
        def __init__(self):
            self.args = None

    class Task(object):
        def __init__(self):
            self.args = None
        def get_args(self):
            return self.args

    class PlayContext(object):
        def __init__(self):
            self.connection = 'local'
            self.network_os = None
            self.remote_addr = None
            self.port = None
            self.remote_user = None
            self.password = None
            self.private_key_file = None
            self.connection_user = None
            self.become_method = None
            self.become_user = None
            self.become_pass = None
            self.verbosity = 0
            self.only_tags = []
            self.skip