

# Generated at 2022-06-11 12:28:45.556994
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-11 12:28:49.368868
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule(task=dict(args=dict(data='foo')))
    assert x.run()['ansible_stats']['data']['data'] == 'foo'
    assert x.run(task_vars=dict())['ansible_stats']['data']['data'] == 'foo'

# Generated at 2022-06-11 12:28:59.295681
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    mock_task = type('', (object,), {'args': {'data': {'test_key': 'test_value'}, 'per_host': False}, 'async_val': None, 'run_once': False})()
    mock_templar = type('', (object,), {'template': lambda s, x, y, z=False, a=True: x})()
    mock_play_context = type('', (object,), {'prompt': None, 'ask_pass': False, 'remote_addr': None, 'remote_user': None, 'port': None, 'become': False,
                                             'become_method': None, 'become_user': None, 'ask_value_pass': False, 'timeout': 10})()

# Generated at 2022-06-11 12:29:09.257644
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Expected result:
        'ansible_stats': {
            'data': {'first_key': 'first value', 'second_key': 'second value'},
            'per_host': False,
            'aggregate': True
        }
    """
    from ansible.module_utils.parsing.convert_bool import boolean
    task_vars = dict()
    tmp = '/tmp/'
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    args = dict(data={'first_key': 'first value', 'second_key': 'second value'}, per_host=boolean('False', strict=True), aggregate=boolean('True', strict=True))
    action_module._

# Generated at 2022-06-11 12:29:20.752029
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test valid arguments
    for args in [dict(data=dict(a='b', c='d')), dict(per_host=False)]:
        i = ActionModule(dict(args=args), task=dict(name='somename'))
        assert i

    # Test non dict args
    for args in [list(), dict(a=list())]:
        try:
            i = ActionModule(dict(args=args), task=dict(name='somename'))
            assert False, "ActionModule(args=%r) should have raised an exception." % args
        except TypeError:
            pass
    # Test invalid argument

# Generated at 2022-06-11 12:29:27.629567
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule_instance = ActionModule()
    # TODO: mock cleanly the task_vars and tmp options
    # Mock TaskBase.run() method
    ActionModule_instance._task.args = {'data': {'memory': '3 GB'}, 'aggregate': True, 'per_host': False}
    ActionModule_instance._task.args['data'].update(ActionModule._VALID_ARGS)
    ActionModule_instance.run(task_vars=dict(), tmp='/tmp')
    ActionModule_instance._task.args.pop('data')
    ActionModule_instance.run(task_vars=dict(), tmp='/tmp')

# Generated at 2022-06-11 12:29:31.559420
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    AnsibleActionModule = ActionModule(dict(task=dict(), connection=None, play_context=dict()), dict(DEFAULT=dict()))
    AnsibleActionModule.run(tmp=None, task_vars={'ansible_host': 'host.example.com'})

# Generated at 2022-06-11 12:29:32.179460
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-11 12:29:43.259021
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # make a stub of templar
    templar = lambda text, convert_bare, fail_on_undefined: text

    # make a stub of task
    task = lambda x: x
    task.args = dict()
    task.args['data'] = dict()

    # make a stub of ActionBase
    action_base = lambda x, y: dict()

    # make a stub of task_vars
    task_vars = dict()

    # do the test
    action_module = ActionModule(task, None, templar, action_base, task_vars)
    res = action_module.run(None, task_vars)

    # test whether it is working
    assert(isinstance(res, dict))
    assert(res['changed'] == False)

# Generated at 2022-06-11 12:29:50.735684
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_args = {"data": {"pear": 1},
                 "per_host": False,
                 "aggregate": True}

    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action._task.args = task_args
    action.templar = None

    result = action.run(task_vars={})

    assert result['ansible_stats']['data']['pear'] == 1
    assert result['ansible_stats']['per_host'] == False
    assert result['ansible_stats']['aggregate'] == True


# Generated at 2022-06-11 12:30:05.305050
# Unit test for constructor of class ActionModule
def test_ActionModule():
    def _get_action_module(action_plugin, *args, **kwargs):
        action_plugin_dir, action_plugin_name = action_plugin.rsplit('.', 1)
        module = action_plugin_dir + '.' + 'set_stats'
        imported_module = __import__(module, fromlist=[action_plugin_name])
        return getattr(imported_module, action_plugin_name)

    action_plugin = 'per_host.set_stats'
    # (task_name, task, args, task_vars, objects)
    set_stats = _get_action_module(action_plugin)
    assert set_stats

# Generated at 2022-06-11 12:30:09.642651
# Unit test for constructor of class ActionModule
def test_ActionModule():
    Stats = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(Stats, ActionModule)
    assert isinstance(Stats._VALID_ARGS, frozenset)

# Generated at 2022-06-11 12:30:14.064508
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Tests run method of class ActionModule.
    # Test against a valid 'data' option
    # with a valid variable name.

    # No templates are used here.

    module = ActionModule()
    data = {'host_var': 'value'}
    task = Mock(spec=['args'])
    task.args = {'data': data}
    result = module.run(None, None, task=task)
    assert result == {
        'changed': False,
        'ansible_stats': {
            'data': {
                'host_var': 'value'
            },
            'per_host': False,
            'aggregate': True,
        }
    }

# Generated at 2022-06-11 12:30:14.851438
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Do nothing now
    return

# Generated at 2022-06-11 12:30:25.561631
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Stub class to mimic ActionModule class and its run method
    class ActionModuleStub():
        def _task_fields(self):
            return {'args': [{'data': {'foo': 1, 'bar': 2}, 'per_host': True, 'aggregate': False}]}

        def _execute_module_with_retry(self, *args, **kwargs):
            return {
                'module_name': 'set_stats',
                'module_args': 'foo={{ foo }} bar={{ bar }}',
                'failed': False,
                'changed': False,
            }

        def _execute_module(self, execute_module_params, tmp, task_vars, *args, **kwargs):
            return 'foo=1 bar=2'.encode()

        def _templar(self):
            return

# Generated at 2022-06-11 12:30:36.043205
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()
    am.task_vars = {}
    am.task_vars['ansible_facts'] = {}
    am._task.args = {}
    am._task.vars = {}

    # Check return value for 'failed' when args.data is not dict and convert_bare_false
    am._task.args['data'] = '[1,2,3]'
    assert am.run()['failed'] is True

    # Check return value for 'failed' when args.data is not dict and fail_on_undefined
    am._task.args['data'] = '{{ non_exist_variable }}'
    assert am.run()['failed'] is True

    # Check return value for 'failed' when args.data is dict, but one key is not valid

# Generated at 2022-06-11 12:30:47.104126
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import tempfile
    import shutil
    import json
    import sys

    # Python 3 bytes()
    if sys.version_info >= (3,):
        bytes = lambda x, *args: x.encode(*args)

    # Create temp directory
    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-11 12:30:56.118628
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Test run method of class ActionModule"""
    task = FakeTask()
    task.args = {
        'data': {
            'foo': 'bar',
            'baz': 'qux'
        },
        'aggregate': True,
        'per_host': False
    }
    templar = FakeTemplar()
    action_module = ActionModule(task=task, templar=templar)
    templar.template = lambda x, y, z: x
    result = action_module.run(None, dict())
    assert not result['failed']
    assert result['changed'] is False

# Generated at 2022-06-11 12:31:05.653114
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def setup(module):
        def execute_module():
            res = module.run()
            assert not res['failed']
            assert res['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True}
            res = module.run({'data': {'one': 2, 'three': 4}})
            assert not res['failed']
            assert res['ansible_stats'] == {'data': {'one': 2, 'three': 4}, 'per_host': False, 'aggregate': True}
            res = module.run({'data': {'one': 2, 'three': 4}, 'aggregate': False, 'per_host': True})
            assert not res['failed']

# Generated at 2022-06-11 12:31:06.529266
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 12:31:22.322436
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    aux_result = {'changed': False, 'ansible_stats': {'aggregate': True, 'per_host': False, 'data': {}}}
    set_stats_instance = set_stats.ActionModule(dict(), dict())
    result = set_stats_instance.run(tmp='test', task_vars={'test': 'test'})
    assert result==aux_result

# Generated at 2022-06-11 12:31:27.341426
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  action_module = ActionModule()
  action_module._task.args = {'data': {}}
  assert action_module._task.args.get('data') == {}

  action_module = ActionModule()
  action_module._task.args = {'data': ''}
  assert action_module._task.args.get('data') == ''

  action_module = ActionModule()
  action_module._task.args = {'data': 'a'}
  assert action_module._task.args.get('data') == 'a'

  action_module = ActionModule()
  action_module._task.args = {'data': {'a': 'b'}}
  assert action_module._task.args.get('data') == {'a': 'b'}

# Generated at 2022-06-11 12:31:35.365400
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode, AnsibleMapping
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    from ansible.plugins.action import ActionBase

    from ansible.plugins.action.set_stats import ActionModule

    from ansible.playbook.task import Task


# Generated at 2022-06-11 12:31:37.210916
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module

# Test the method run of ActionModule class

# Generated at 2022-06-11 12:31:41.006656
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule(None, dict(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None))
    assert x.TRANSFERS_FILES is False
    assert isinstance(x._VALID_ARGS, frozenset)

# Generated at 2022-06-11 12:31:43.930107
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # check ansible_stats is dict
    # check ansible_stats has following keys:
    # 'data'
    # 'per_host'
    # 'aggregate'
    assert False


# Generated at 2022-06-11 12:31:44.851101
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert(am)

# Generated at 2022-06-11 12:31:47.106282
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Call the constructor of class ActionModule
    # This will throw an exception if it fails
    _ = ActionModule(None, None)

# Generated at 2022-06-11 12:31:56.729785
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TestModule:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    task = TestModule(args=dict(aggregate='{{ item.aggregate }}', data='{{ item.data }}'))
    assert task._valid_args == frozenset(('aggregate', 'data', 'per_host'))

    task_vars = TestModule(member1='foo', member2='bar')
    assert task_vars == task_vars
    assert task_vars != 'foo'

    # Test for the run() method with 3 optional arguments
    action = ActionModule(task, connection='dummy', play_context='dummy', loader='dummy', templar='dummy', shared_loader_obj='dummy')

# Generated at 2022-06-11 12:31:59.796154
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module

# Generated at 2022-06-11 12:32:20.466765
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(action=dict(module_name='set_stats',
                              module_args=dict(data=dict(key="value")))))
    assert action_module is not None

# Generated at 2022-06-11 12:32:21.656252
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # class constructor test
    module = ActionModule()
    assert module

# Generated at 2022-06-11 12:32:27.394885
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TestModule(object):
        def __init__(self):
            self.args = dict()
            self.args['data'] = dict()
            self.args['per_host'] = True
            self.args['aggregate'] = True
            self.args['data']['var1'] = 1
            self.args['data']['var2'] = dict()
            self.args['data']['var2']['var2a'] = 4
            self.args['data']['var2']['var2b'] = 5
        def get_args(self):
            return self.args

    def TestTemplar(self):
        self.template = dict()
        self.template['var1'] = 1
        self.template['var2'] = dict()

# Generated at 2022-06-11 12:32:28.935367
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule(argument_spec=dict())
    assert m is not None

# Generated at 2022-06-11 12:32:39.077218
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Given a mocked ActionModule, a mocked TaskExecutor, and a mocked task, test if the run method actually sets the stats in
    # the sender.
    from collections import namedtuple
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.task import Task
    from ansible.playbook import Play

    mock_action_module = ActionModule()
    mock_task_executor = MockTaskExecutor()
    mock_task = Task()
    mock_task.action = 'set_stats'

    mock_task.args = dict(data={'foo': 'bar', 'baz': 'baq'})

# Generated at 2022-06-11 12:32:44.380705
# Unit test for constructor of class ActionModule
def test_ActionModule():

  class fixture:
      task_vars = {'test': 'a'}
      templar = lambda x, convert_bare=False, fail_on_undefined=True: 'a'
      args = {'data': {'a': 1, 'b': 2}, 'per_host': False, 'aggregate': True}

  action_module = ActionModule(fixture(), {})
  assert action_module.run().get('changed') == False

# Generated at 2022-06-11 12:32:47.503107
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action import ActionModule

    # Create instance of ActionModule class
    action_module = ActionModule(None, None, task_vars=None)

    assert action_module.__class__.__name__ is 'ActionModule'



# Generated at 2022-06-11 12:32:51.991767
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    import json
    import tempfile
    import shutil
    import os

    # Create a temp directory
    tmpdir = tempfile.mkdtemp()

    # Create a temp playbook
    (playbook_fd, playbook_path) = tempfile.mkstemp(dir=tmpdir, prefix='playbook_', text=True)

    # create a temp file for ansible_vars
    (vars_fd, vars_path) = tempfile.mkstemp(dir=tmpdir, prefix='ansible_vars_', text=True)

    # create a temp file for ansible_facts
    (facts_fd, facts_path) = tempfile.mkstemp(dir=tmpdir, prefix='ansible_facts_', text=True)



# Generated at 2022-06-11 12:33:01.571470
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    play_context = PlayContext()
    play_context.prompt = dict()
    play_context.remote_addr = '127.0.0.1'
    play_context.connection = 'local'
    play_context.network_os = 'default'

    play_source = dict(
            name = "Ansible Play",
            hosts = 'all',
            gather_facts = 'no',
            become = True
        )
    play = Play().load(play_source, variable_manager = None, loader = None)

    # Create a temporary directory path to write tempfiles
    # if this fails the first assert will fail

# Generated at 2022-06-11 12:33:09.102358
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest2 as unittest

    from ansible.compat.tests import mock

    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.utils.vars import isidentifier

    from ansible.plugins.action import ActionBase

    class TestClassActionModule(ActionModule):
        pass

    class TestClassActionBase(ActionBase):
        def __init__(self, *args, **kwargs):
            super(TestClassActionBase, self).__init__(*args, **kwargs)
            self._task.args = {}

    class TestClassTemplate(object):
        def __init__(self):
            self.result = {
                'template_fail': False,
                'template_exception': None,
                'template_result': None,
            }


# Generated at 2022-06-11 12:33:50.908419
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None)
    assert action is not None

# Generated at 2022-06-11 12:33:58.888341
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import load_extra_vars

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager,  host_list='localhost,')

# Generated at 2022-06-11 12:34:07.260400
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import PY3

    def eq(first, second):
        return first == second

    class test_ActionModule_run_class():
        def _run_result(self, tmp, task_vars):
            return {'changed': False, 'ansible_stats': self.stats}

        def getVarValueFromParams(self, task_vars, params, key):
            return task_vars[params[key]]

        def define_vars(self, params, task_vars):
            if 'data' in params:
                data = params.get('data')

# Generated at 2022-06-11 12:34:08.158159
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert "ActionModule" in str(ActionModule)

# Generated at 2022-06-11 12:34:08.952410
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am.action_required

# Generated at 2022-06-11 12:34:19.257707
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # create object of class ActionModule
    action_module = ActionModule(
        task=dict(action=dict(module_name='set_stats', module_args=dict())),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )

    # test for data type of returned value is dict
    assert isinstance(action_module.run(), dict)

    # test for keys present in the returned dict
    assert 'changed' in action_module.run()
    assert 'msg' in action_module.run()
    assert 'ansible_stats' in action_module.run()

    # create object of class ActionModule with args 'data' and 'per_host'

# Generated at 2022-06-11 12:34:27.272541
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {}
    tmp = ''
    args = {}
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # test 1
    args = {}
    args['data'] = {}
    args['data']['a'] = '1'
    args['data']['b'] = '2'
    res = {}
    res['ansible_stats'] = {}
    res['ansible_stats']['aggregate'] = True
    res['ansible_stats']['per_host'] = False
    res['ansible_stats']['data'] = {}
    res['ansible_stats']['data']['a'] = '1'

# Generated at 2022-06-11 12:34:36.360924
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Setup mocks for ActionModule._execute_module
    class Mocked_ActionModule(ActionModule):
        def _execute_module(self, tmp=None, task_vars=None):
            return {'changed': False}

    # Setup mocks for ActionModule._get_tmp_path
    def get_tmp_path():
        return None

    def get_task_vars():
        return None

    # Setup mocks for ActionBase._display.warnings
    def display_warnings(warnings):
        return None

    # Setup mocks for ActionBase._display.deprecations
    def display_deprecations(deprecations):
        return None

    # Setup mocks for ActionBase._add_ansible_module_data

# Generated at 2022-06-11 12:34:46.244968
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create a fake task, and inject the arbitrary argument 'data'
    # the data value should be a dictionary
    # set the action module as set_file_attributes
    FAKE_TASK = dict(
        action = dict(
            module = 'set_stats'
        ),
        args = dict(
            data = dict(
                foo = 'bar',
                baz = 'quux'
            )
        )
    )
    FAKE_TASK_VARS = dict(
        ansible_stats = dict(
            data = dict(),
            per_host = False,
            aggregate = True
        )
    )
    # create a mock object of class AnsibleModule from Ansible
    # This will register the fake_task with AnsibleModule as the task

# Generated at 2022-06-11 12:34:48.710341
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=None)
    assert action_module

# Generated at 2022-06-11 12:36:44.616409
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Running test_ActionModule_run")

    from ansible.plugins.loader import action_loader
    from ansible.utils.vars import combine_vars

    # Create a task with a simple argument
    task = action_loader.get('set_stats', task={'args': {'data': {'foo': 'bar'}}})

    # create a host
    host = {'name': 'testhost'}

    # create a variable manager on the task
    var_mgr = task.variable_manager
    var_mgr.extra_vars = combine_vars(var_mgr.extra_vars, {})
    var_mgr.options_vars = combine_vars(var_mgr.options_vars, {})

    # create the task result object

# Generated at 2022-06-11 12:36:46.072128
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a.TRANSFERS_FILES == False
    assert isinstance(a._VALID_ARGS, frozenset)

# Generated at 2022-06-11 12:36:55.073754
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule"""
    module = ActionModule()

    # Case 1: The data includes a key that is not a valid python variable
    # name
    task_vars = {'module': 'set_stats', 'module_args': {'data': {"1abc": "foo"}}}
    result = module.run(None, task_vars)
    assert result['failed'] == True
    assert result['msg'] == ("The variable name '1abc' is not valid. Variables must start with a letter or underscore character, and contain only "
                             "letters, numbers and underscores.")

    # Case 2: The data includes a key that is a valid python variable name
    # name
    task_vars = {'module': 'set_stats', 'module_args': {'data': {"abc1": "foo"}}}


# Generated at 2022-06-11 12:36:57.164726
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(play_context=dict(), loader=None, templar=None, shared_loader_obj=None)
    assert module
    assert not hasattr(module, "TRANSFERS_FILES")

# Generated at 2022-06-11 12:37:05.541418
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.utils.template
    from ansible.module_utils.parsing.convert_bool import boolean

    a = ansible.utils.template.AnsibleTemplate(loader=None)
    a._convert_bare_variables = lambda x: x

    # test_ActionModule_run_templar_no_fail_on_undefined
    v1 = dict(
        args=dict(
            data=dict(
                a=1,
                b=2,
                c=3,
            )
        ),
        task_vars={},
        templar=a,
    )
    r = ActionModule.run(v1)
    assert r.get('changed') == False

# Generated at 2022-06-11 12:37:13.216101
# Unit test for constructor of class ActionModule
def test_ActionModule():

    task_vars = dict()

    # normal test
    action_result = dict(failed=False, changed=False, skipped=False)
    action_result['result'] = dict()
    action_result['ansible_facts'] = dict()
    action_result['ansible_stats'] = dict()
    action_result['ansible_stats']['data'] = dict()

    am = ActionModule(dict(), action_result, task_vars=task_vars)
    print(am.run_command('echo', 'Hello World'))

    # test task args
    task_args = dict()
    task_args['data'] = dict()
    task_args['data']['dummy_var1'] = 'dummy_value1'

# Generated at 2022-06-11 12:37:14.898750
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    not strictly a unit test, but tests that construction of this class
    is possible.
    """
    a = ActionModule()

# Generated at 2022-06-11 12:37:19.667078
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_play = {
        "name": "ping",
        "connection": "local",
        "hosts": "all",
        "gather_facts": "no"
    }

    # Test the constructor
    test_module = ActionModule(task=test_play, connection='local', play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert test_module is not None

# Generated at 2022-06-11 12:37:27.208029
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # defining helper functions that can be used to do assertions for the test
    def assert_expected_results(result):
        assert not result.get('failed')
        assert not result.get('changed')
        assert result.get('ansible_stats')
        assert result.get('ansible_stats').get('aggregate')
        assert result.get('ansible_stats').get('data').get('my_stat') == 123

    def assert_expected_exception_results(result, message):
        assert result.get('failed')
        assert result.get('msg') == message

    # instantiating an ActionModule object
    test_action_module = ActionModule(load_plugins=False)

    # defining the arguments that will be used to construct a task for the test
    task_args = {'data': {'my_stat': 123}}
    task

# Generated at 2022-06-11 12:37:29.816042
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(load_plugins=False)
    assert action_module._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))
    assert action_module.TRANSFERS_FILES == False
