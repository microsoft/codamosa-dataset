

# Generated at 2022-06-11 12:28:55.137205
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import yaml

    # Test with no arguments
    action = ActionModule({'test': {'test': {'test': "{{test}}"}}})
    # TODO: empty test

    # Test with valid arguments
    action = ActionModule({'test': {'test': {'test': "{{test}}"}, 'args': {'data': {"foo": "bar"}}}})
    # TODO: test

    # Test with invalid argument
    action = ActionModule({'test': {'test': {'test': "{{test}}"}, 'args': {'data': ["foo", "bar"]}}})
    value = action.run({'test': {'test': "{{test}}"}}, {'test': {'test': "{{test}}"}})
    assert value['failed'] is True

# Generated at 2022-06-11 12:28:56.031451
# Unit test for method run of class ActionModule

# Generated at 2022-06-11 12:29:06.054168
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible import context
    import os

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,',])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Setup playbook executor, but

# Generated at 2022-06-11 12:29:10.277323
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    stats = {'changed': False}

    # TODO: unit-test this method
    # The method is stubbed from the ActionBase.run, which
    # is not testable.
    # Need to define a meta class which inherits from ActionBase
    # and provide a run method which is testable

# Generated at 2022-06-11 12:29:11.874259
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: implement this method for unit testing
    assert(False)

# Generated at 2022-06-11 12:29:23.095304
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test empty task
    am = ActionModule({}, {}, {})

    stats = am.run()
    assert stats['changed'] == False
    assert stats['ansible_stats']['aggregate'] == True
    assert stats['ansible_stats']['per_host'] == False
    assert stats['ansible_stats']['data'] == {}

    # test with data
    data = {'status': 'ok', 'bogus': 'yes', 'type': 'text'}
    am = ActionModule({'data': data}, {}, {})

    stats = am.run()
    assert stats['changed'] == False
    assert stats['ansible_stats']['aggregate'] == True
    assert stats['ansible_stats']['per_host'] == False
    assert stats['ansible_stats']['data']

# Generated at 2022-06-11 12:29:31.867405
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ansible_module = dict(
        ansible_facts=dict(
            ansible_system="test_ansible_system"
        ),
        failed=False,
        changed=False,
        ansible_stats=dict(
            data=dict(
                test_ansible_system="test_ansible_system",
                ansible_hostname="test_hostname"
            ),
            per_host=True,
            aggregate=True
        )
    )

    module = ActionModule()
    module._task = dict(args=dict(
        data=dict(
            ansible_system="{{ ansible_facts['ansible_system'] }}",
            ansible_hostname="{{ ansible_facts['ansible_hostname'] }}"
        ),
        per_host=True,
        aggregate=True
    ))



# Generated at 2022-06-11 12:29:37.540624
# Unit test for constructor of class ActionModule
def test_ActionModule():
    coldata = {'data': {'foo': 'bar'}, 'per_host': False, 'aggregate': True}
    assert ActionModule.run(ActionModule, {'data': coldata}, {}) == {'changed': False, 'ansible_stats': {'data': {'foo': 'bar'}, 'per_host': False, 'aggregate': True}}


# Generated at 2022-06-11 12:29:39.298181
# Unit test for constructor of class ActionModule
def test_ActionModule():
    words = "hello, world"
    am = ActionModule(words)
    assert am.words == "hello, world"

# Generated at 2022-06-11 12:29:47.879119
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Unit tests for constructors of class ActionModule
    """
    test_obj = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())
    if test_obj.TRANSFERS_FILES != False:
        raise AssertionError("TRANSFERS_FILES should be False")
    if test_obj._VALID_ARGS != frozenset(('aggregate', 'data', 'per_host')):
        raise AssertionError("VALID_ARGS should be frozenset(('aggregate', 'data', 'per_host'))")


# Generated at 2022-06-11 12:29:54.153678
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert(action)


# Generated at 2022-06-11 12:29:57.793159
# Unit test for constructor of class ActionModule
def test_ActionModule():
    t = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert not t.TRANSFERS_FILES
    assert isinstance(t._VALID_ARGS, frozenset)

# Generated at 2022-06-11 12:29:58.401352
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:30:09.634733
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test illegal/invalid type constructor arguments
    try:
        action_module = ActionModule(object, dict())
    except AssertionError as e:
        assert "task must be a dict" in str(e)
    try:
        action_module = ActionModule(dict(), object)
    except AssertionError as e:
        assert "ds must be an AnsibleTask object" in str(e)
    try:
        action_module = ActionModule(dict(), dict())
    except AssertionError as e:
        assert "ds is required" in str(e)
    try:
        action_module = ActionModule(dict(), dict(), dict())
    except AssertionError as e:
        assert "loader must be an AnsibleLoader object" in str(e)

    # test legal constructor arguments
    ds = dict()


# Generated at 2022-06-11 12:30:12.593634
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule()
    assert mod._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))
    assert not mod.TRANSFERS_FILES


# Generated at 2022-06-11 12:30:14.970678
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.set_stats import ActionModule
    a = ActionModule(1, {})
    assert a._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-11 12:30:21.483027
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	tmp = None
	task_vars = {'inventory_hostname': 'mutant'}

	ActionModule._task = _task = dict()
	ActionModule._task['args'] = {'data': '{{playbook_dir}}', 'per_host': 'True','aggregate': 'True'}
	ActionModule.run(tmp, task_vars)
	assert ActionModule._task
	assert ActionModule._task['args'].get('data') == '/home/root/ansible/playbooks'



# Generated at 2022-06-11 12:30:23.953003
# Unit test for constructor of class ActionModule
def test_ActionModule():

    a = ActionModule()

    #Asserting the class attributes
    assert a.TRANSFERS_FILES == False

# Generated at 2022-06-11 12:30:34.619263
# Unit test for constructor of class ActionModule
def test_ActionModule():

    import sys
    import unittest
    import pylint
    import ansible.plugins.loader
    import ansible.plugins.action
    import ansible.module_utils.parsing.convert_bool
    import ansible.module_utils.vars
    import ansible.utils.vars

    print("\nStart unit test:")
    #Syntax check(pylint)
    #pylint: disable=no-value-for-parameter
    print("\nSyntax check(pylint):")
    pylint.run_pyflakes_for_package('ansible.plugins.action')
    print("\nEnd Syntax check(pylint):")

    print("\nStart unit test:")
    #Unit test for constructor

# Generated at 2022-06-11 12:30:39.682766
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''

    # Setup test variables
    tmp = None
    task_vars = {}
    action = ActionModule(None, None, tmp, task_vars)

    # Test run method with valid data and a value for aggregate,
    # per_host and data set.
    result = action.run(tmp, task_vars)

    assert 'ansible_stats' in result
    assert 'per_host' in result['ansible_stats']
    assert 'aggregate' in result['ansible_stats']
    assert 'data' in result['ansible_stats']
    assert isinstance(result['ansible_stats']['data'], dict)
    assert 'changed' in result
    assert not result['changed']

    # Test run method with valid data, but no

# Generated at 2022-06-11 12:30:57.849808
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #
    # 1) Create instance of class ActionModule
    #
    am = ActionModule(task={}, connection={}, play_context={}, loader={}, templar={}, shared_loader_obj={})
    #
    # 2) Set task_vars
    #
    task_vars = {'stat1':1,'stat2':2}
    #
    # 3) Run method run testing the case when
    #
    # a) It is not a dict or int
    #
    # Tested method:
    # run(self, tmp=None, task_vars=dict())
    #
    # Expected returns:
    # result = dict(failed=True, msg='The 'data' option needs to be a dictionary/hash')
    #

# Generated at 2022-06-11 12:30:58.926013
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-11 12:30:59.888783
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)

# Generated at 2022-06-11 12:31:08.938525
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    # init objects
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # init play

# Generated at 2022-06-11 12:31:10.014835
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    assert action_module.run(tmp=None)

# Generated at 2022-06-11 12:31:21.154300
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Construct a dummy module_utils.basic.AnsibleModule object
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.dataloader import DataLoader

    args = dict(
        data=dict(
            foo='{{foo}}',
            bar=1,
            baz='value of qux is {{qux}}'
        ),
        per_host=True,
        aggregate=False
    )

    mock_module = AnsibleModule(
        argument_spec=dict(
            aggregate=dict(required=False, type='bool'),
            data=dict(required=False, type='dict'),
            per_host=dict(required=False, type='bool')
        ),
        supports_check_mode=True
    )


# Generated at 2022-06-11 12:31:22.703631
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_mod = ActionModule()

    assert not action_mod._connection._shell

# Generated at 2022-06-11 12:31:32.655945
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import basic

    basic._ANSIBLE_ARGS = None

    # Create a dummy ansible module
    am = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    # Create a dummy action module
    action = ActionModule(am, dict(foo='bar'))

    # Assert that the action module run method returns a valid result
    assert isinstance(action.run(), dict)

    # Assert that the action module run method fails with an invalid argument
    assert 'failed' in action.run(task_vars={}, tmp='baz', _ansible_check_mode=True)

    # Assert that the action module run method fails with an invalid data argument
    assert 'failed' in action.run

# Generated at 2022-06-11 12:31:33.078868
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 12:31:34.551067
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(None), ActionBase)



# Generated at 2022-06-11 12:32:00.447388
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Mock task
    mock_task_args = {'data': {'foo': 'bar'}, 'per_host': True, 'aggregate': True}
    mock_task = type('MockTask', (object,), {'args': mock_task_args})

    # Mock task variables
    mock_task_vars = {}

    # Mock templar
    mock_templar_template = lambda *args, **kwargs: args[0]
    mock_templar = type('MockTemplar', (object,), {'template': mock_templar_template})

    # Mock plugin
    mock_plugin = type('MockPlugin', (object,), {})()

    mock_action = ActionModule(mock_task, mock_connection, mock_templar, mock_plugin)

    # Call method run


# Generated at 2022-06-11 12:32:10.920786
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.compat import mock
    from ansible.plugins.action.set_stats import ActionModule

    act = ActionModule(mock.Mock(), mock.Mock())

    act_result = {'failed': False, 'changed': False}

    mock_task_args = {
        'per_host': 'no',
        'aggregate': 'yes',
        'data': {'a': 'A', 'b': '{{ B }}', 'c': ['{{ C }}'], 'd': {'dsub': ['{{ Dsub }}']}}
    }

    mock_task_vars = {
        'B': 'B',
        'C': ['Csub'],
        'Dsub': 'ds',
    }


# Generated at 2022-06-11 12:32:21.096544
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionBase

    MOCK_DATA = [
        {
            'AN_VARIABLE_NAME': 10,
            '_MOCK__VARIABLE_NAME': 20,
        },
    ]

    for task in MOCK_DATA:
        acm = ActionModule(task=task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
        res = acm.run(None, None)
        assert 'changed' in res
        assert 'ansible_stats' in res and isinstance(res['ansible_stats'], dict)
        assert res['ansible_stats']['per_host'] == False
        assert res['ansible_stats']['aggregate'] == True

# Generated at 2022-06-11 12:32:30.103257
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Adapted from test/units/modules/test_async.py

    These tests provoke the following error:
    Exception: No module named ansible.module_utils.basic
    """
    import os.path
    import shutil
    import sys
    import time

    from six import PY3

    from ansible.compat.tests import unittest
    from ansible.module_utils.six import StringIO

    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.strategy import ActionModule
    from ansible.utils.display import Display
    from ansible.inventory.manager import InventoryManager

# Generated at 2022-06-11 12:32:40.155927
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up test objects
    import ansible.inventory
    from ansible.playbook.task import Task

    mytask = Task()
    mytask._role = None
    setattr(mytask, '_role', None)

    # Test with no data
    am = ActionModule(mytask, dict())
    am.runner = DummyRunner()
    results = am.run(task_vars={})
    assert results['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True}
    assert results['changed'] == False
    assert results['failed'] == False

    # Test with data and aggregate true (default)
    mytask.args = {'data': {'myvar': 'Hello'}}
    am = ActionModule(mytask, dict())
    am.runner = DummyRunner()

# Generated at 2022-06-11 12:32:47.857581
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    data = {'a': 1, 'b': 2, 'c': 3}
    task = Task()
    task._role = None
    task.args = {'data': data}
    action = ActionModule({}, task, PlayContext())
    action.run()

    assert action.run()['ansible_stats']['aggregate']
    assert action.run()['ansible_stats']['data'] == {'a': 1, 'b': 2, 'c': 3}
    assert action.run()['ansible_stats']['per_host']
    assert action.run()['changed'] == False

# Generated at 2022-06-11 12:32:54.434426
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ac = ActionModule('Task', 'Action', False, {}, {})
    assert ac.action == 'Action'
    assert ac.task == 'Task'
    assert ac.transfers_files is False
    assert ac.delegate_to is None
    assert ac.delegate_facts is None
    assert ac.no_log is False
    assert ac._tmpdir is None
    assert ac._display is None
    assert ac._connection is None
    assert ac._shell is None
    assert ac._module is None

# Generated at 2022-06-11 12:32:58.031208
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = AnsibleModule(argument_spec=dict(
        aggregate=dict(type="bool", default=True),
        data=dict(type="dict", required=True),
        per_host=dict(type="bool", default=False),
    ))
    assert module

# Generated at 2022-06-11 12:33:01.006715
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule('remote', '127.0.0.1', 10, None)
    assert action_module

if __name__ == "__main__":
    print("Running unit test on Ansible Action Module")
    test_ActionModule()

# Generated at 2022-06-11 12:33:08.721426
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils._text import to_bytes
    import ansible.module_utils.parsing.convert_bool
    from ansible.plugins.action import ActionModule
    from ansible.compat.tests.mock import patch
    from ansible.utils.vars import isidentifier

    # setup for test
    # mock the object with the method being tested and its required dependencies
    task = mock.MagicMock()
    task._ds = {'argspec': None}
    task.args = {'data': {'var_a': 'test', 'var_b': 'test2'}, 'per_host': True, 'aggregate': False}
    task._role = mock.MagicMock()
    task._role.get_vars.return_value = {'var_a': 'mock'}

   

# Generated at 2022-06-11 12:33:57.658970
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from test.unit.module_utils.parsing.convert_bool import boolean_test_data
    from test.unit.module_utils.args_test_data import args_test_data

    # create instace of ActionModule
    # set_type_of_self(self):
    ActionModule.action_loader = Mock()
    ActionModule.action_loader._task_stack = []
    ActionModule._connection_info = {'host': '127.0.0.1', 'port': 22, 'user': 'vagrant', 'password': 'vagrant'}
    ActionModule._shared_loader_obj = Mock()
    ActionModule._shared_loader_obj._basedir = '.'
    ActionModule._templar = Mock()
    ActionModule._loader = Mock()
    ActionModule._task = Mock()
    ActionModule._task

# Generated at 2022-06-11 12:33:59.610051
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert a is not None

# Generated at 2022-06-11 12:34:05.013975
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test with empty task_vars
    obj = ActionModule({}, {})
    assert obj.run() == dict(failed=True, msg="Failed to load dnstest.py")

    # test with task_vars having set module_utils
    obj = ActionModule({}, dict(ANSIBLE_MODULE_UTILS='/path/to/module_utils'))
    assert obj.run() == dict(failed=True, msg="Failed to load dnstest.py")

# Generated at 2022-06-11 12:34:12.602923
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    if not isinstance(am._VALID_ARGS, frozenset):
        return "ERROR, constructor of class ActionModule should set _VALID_ARGS to frozenset"
    if am._VALID_ARGS != frozenset(('aggregate', 'data', 'per_host')):
        return "ERROR, constructor of class ActionModule should set _VALID_ARGS to frozenset({'aggregate', 'data', 'per_host'})"
    if not isinstance(am.TRANSFERS_FILES, bool):
        return "ERROR, constructor of class ActionModule should set TRANSFERS_FILES to False"
    return "GOOD"


# Generated at 2022-06-11 12:34:16.077439
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_mod = ActionModule()
    assert action_mod._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))
    assert action_mod.TRANSFERS_FILES == False

# Generated at 2022-06-11 12:34:17.098135
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert callable(ActionModule)

# Generated at 2022-06-11 12:34:25.573485
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args = {'_ansible_no_log': False, '_ansible_verbosity': 2, '_ansible_debug': True, '_ansible_diff': True, '_ansible_check_mode': False}
    actionmodule = ActionModule(None, {}, args=args, task_uuid="a", loader=None, templar=None)
    task_vars = {'hostvars': {'host1': {'version': '1.2'}, 'host2': {'version': '1.3'}}}
    actionmodule._play_context = None
    actionmodule._task_vars = task_vars

# Generated at 2022-06-11 12:34:28.956849
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())
    assert module != None


# Generated at 2022-06-11 12:34:33.917583
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create the object
    instance = ActionModule()

    # check for the attributes
    for attr in ['_VALID_ARGS']:
        assert hasattr(instance, attr), 'Expected ActionModule object to have an attribute "%s"' % attr

    # check for the methods
    for attr in ['run']:
        assert hasattr(instance, attr), 'Expected ActionModule object to have a method "%s"' % attr

# Generated at 2022-06-11 12:34:43.787042
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # set default test object values for testing the action plugin under test
    host = 'localhost'
    task_vars = dict()
    connection = 'local'
    play_context = dict()

    module_name = 'set_stats'
    module_args = dict(aggregate=True, per_host=True)
    module_args['data'] = dict(var1=True, var2=['one', 'two', 'three'], var3='hello world')

    # Make a new action plugin with above test values
    action = ActionModule(host, task_vars, connection, play_context, module_name, module_args)

    # Run execute() method of action plugin under test.  Return results in res
    res = action.execute()

    # Asserts test values to make sure action plugin worked as expected

# Generated at 2022-06-11 12:36:31.122704
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:36:33.258965
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Unit test for constructor of class ActionModule.
    """

    __tracebackhide__ = True

    accounting_module = ActionModule()
    assert accounting_module is not None

# Generated at 2022-06-11 12:36:33.920350
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:36:39.571257
# Unit test for constructor of class ActionModule
def test_ActionModule():

    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module._task is None
    assert module._connection is None
    assert module._play_context is None
    assert module._loader is None
    assert module._templar is None
    assert module._shared_loader_obj is None
    assert module._connection_info is None
    assert module.task_vars is None
    assert module.tmp is None



# Generated at 2022-06-11 12:36:46.745361
# Unit test for constructor of class ActionModule
def test_ActionModule():

    fake_task = dict(
        action=dict(
            module_name='test',
            module_args=dict(
                data=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','0','1','2','3','4','5','6','7','8','9','_']
            ),
            per_host=True,
            aggregate=False,
        )
    )

    # print(fake_task)

    am = ActionModule(fake_task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-11 12:36:52.099146
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit test for method run of class ActionModule """

    # Initialization
    tmp = None
    task_vars = {}
    actionmodule = ActionModule(tmp, task_vars)

    # Initialization
    # Method run of class ActionModule returns a dictionary
    assert isinstance(actionmodule.run(), dict)


# Generated at 2022-06-11 12:36:53.981921
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None)
    assert(str(action_module))
    assert(action_module.run(None, None))


# Generated at 2022-06-11 12:36:57.370947
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=None, connection=None,
                          play_context=None, loader=None, templar=None,
                          shared_loader_obj=None)

    assert action._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))
    assert action._task is None
    assert action._play_context is None
    assert action._loader is None
    assert action.TRANSFERS_FILES == False

# Generated at 2022-06-11 12:36:59.811999
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module.TRANSFERS_FILES is False
    assert module._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-11 12:37:08.083945
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    import inspect
    import unittest
    import ansible.module_utils.parsing.convert_bool

    sys.modules['ansible.module_utils.parsing.convert_bool'] = ansible.module_utils.parsing.convert_bool

    class TestTask(object):
        def __init__(self):
            self.args = None

    class TestPlayContext(object):
        def __init__(self):
            self.become = False
            self.become_method = None
            self.become_user = None

    class TestRunner(object):
        def __init__(self):
            self.play = None

    class TestPlay(object):
        def __init__(self):
            self.context = None
