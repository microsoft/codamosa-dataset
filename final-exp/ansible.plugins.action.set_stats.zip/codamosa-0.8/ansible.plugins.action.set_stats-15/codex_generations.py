

# Generated at 2022-06-11 12:28:54.200002
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    test_data = {
        'args': {'data': {'a': '{{ inventory_hostname }}', 'b': 1}},
        'tmp': '/root/ansible',
        'task_vars': {'inventory_hostname': 'localhost'},
        'expected': {'ansible_stats': {'data': {'b': '1', 'a': 'localhost'}, 'per_host': False, 'aggregate': True},
                     'changed': False},
    }

    task_vars = test_data.get('task_vars', {})

    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    am._task = FakeTask()

# Generated at 2022-06-11 12:29:02.066511
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Check _VALID_ARGS is initialized properly
    assert isinstance(ActionModule._VALID_ARGS, frozenset)
    # Check _VALID_ARGS contains expected elements
    expected_elements = set(['per_host', 'aggregate', 'data'])
    assert expected_elements.issubset(ActionModule._VALID_ARGS)
    # Check _VALID_ARGS does not contain unexpected elements
    unexpected_elements = set(['foo', 'bar', 'baz'])
    assert unexpected_elements.isdisjoint(ActionModule._VALID_ARGS)

# Generated at 2022-06-11 12:29:03.356903
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert isinstance(action, ActionModule)

# Generated at 2022-06-11 12:29:14.078263
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict(
        ansible_stats=dict(data=dict(a=1, b=2), aggregate=False, per_host=True),
        ansible_play_hosts=[
            'localhost',
            '127.0.0.1',
            'test.server.com'
        ]
    )

    action_module = ActionModule()
    action_module._task = dict(
        args=dict(data=dict(a=1, b=2), aggregate=False, per_host=True)
    )
    action_module._templar = dict(
        template=lambda x: x
    )
    result = action_module.run(task_vars=task_vars)

# Generated at 2022-06-11 12:29:16.054886
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule('test', 'localhost', 'all', 'setup', 'my_var').name == 'my_var'

# Generated at 2022-06-11 12:29:18.771827
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, 'test')
    assert action is not None
    assert action.TRANSFERS_FILES is False

# Generated at 2022-06-11 12:29:27.603058
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp, task_vars = None, None

    # Test 1: ActionModule with no args
    # Expected result: stats should have the default values (aggregate:True, per_host:False, data:dict())
    am = ActionModule({}, tmp, task_vars)
    assert am.run(tmp, task_vars)['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True}

    # Test 2: ActionModule with an invalid data (not a dictionary
    # Expected result: failed msg
    am = ActionModule({'data': 'invalid_data'}, tmp, task_vars)
    assert am.run(tmp, task_vars)['msg'] == "The 'data' option needs to be a dictionary/hash"

    # Test 3: ActionModule with an an invalid

# Generated at 2022-06-11 12:29:34.012457
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(dict(action='set_stats', data={'foo': 'bar'}))
    action._task = dict(action='set_stats')
    action._task.args = dict(data={'foo': 'bar'})
    assert action.run(tmp=None, task_vars=None) == {'ansible_stats': {'data': {'foo': 'bar'}, 'aggregate': True, 'per_host': False}, 'changed': False}

# Generated at 2022-06-11 12:29:42.938585
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Correct initialization of ActionModule
    am = ActionModule('test_task', 'test_connection', 'test_play_context', {})
    assert am._task.name == 'test_task'
    assert am._connection.connection_info == 'test_connection'
    assert am._play_context.remote_addr == 'test_play_context'

    # Checks that _VALID_ARGS is a frozenset
    assert isinstance(ActionModule._VALID_ARGS, frozenset)

    # Checks that _VALID_ARGS has at least one element
    assert len(ActionModule._VALID_ARGS) > 0


# Generated at 2022-06-11 12:29:47.130939
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with minimal valid options
    args = dict(aggregate=True, data= dict(count_nodes_up=3), per_host=False )
    action = ActionModule(dict(args=args))
    result = action.run(tmp=None, task_vars=None)
    assert result['failed'] is False
    assert result['ansible_stats'] == args

    # Test with other valid data types
    args = dict(aggregate=True, data= dict(count_nodes_up=3, temp_list=[1,2,3]), per_host=False )
    action = ActionModule(dict(args=args))
    result = action.run(tmp=None, task_vars=None)
    assert result['failed'] is False
    assert result['ansible_stats'] == args

    # Test with invalid data

# Generated at 2022-06-11 12:30:01.630587
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    #NOTE: pylint is not able to import (load) modules dynamically.
    #      Following import statement is recommended by pylint.
    #      This is a workaround.
    #      [pylint] E0401:Unable to import 'ansible.plugins.action.action_base'

    #ToDo: Fix the pylint error.
    #pylint: disable=no-name-in-module
    from ansible.plugins.action.action_base import ActionBase

    #ToDo: Fix the pylint error.
    #pylint: disable=no-name-in-module
    from ansible.plugins.action import set_stats
    
    global ActionModule
    ActionModule = set_stats.ActionModule

    # Create a mocker object, from mock.patch module
    #
    # Returns a new mock

# Generated at 2022-06-11 12:30:02.697744
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # creating an object for class ActionModule
    ActionModule()

# Generated at 2022-06-11 12:30:04.410089
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None


# Generated at 2022-06-11 12:30:14.570274
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test with no args
    task = {
        'args': None,
        'action': {
            '__ansible_module__': 'set_stats',
            '__ansible_arguments__': None
        }
    }
    task_vars = None
    tmp = None
    action = ActionModule(task, tmp, False)
    result = action.run(task_vars=task_vars)
    assert result['msg'] is None
    assert result['changed'] == False
    assert result['ansible_stats']['aggregate'] == True
    assert result['ansible_stats']['per_host'] == False
    assert result['ansible_stats']['data'] == {}

    # Test with args

# Generated at 2022-06-11 12:30:20.559863
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, None).TRANSFERS_FILES is False
    assert type(ActionModule(None, None, None, None)._VALID_ARGS) is frozenset
    assert len(ActionModule(None, None, None, None)._VALID_ARGS) == 3
    for arg in ['aggregate', 'data', 'per_host']:
        assert arg in ActionModule(None, None, None, None)._VALID_ARGS

# Generated at 2022-06-11 12:30:31.714251
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    module = ActionModule(None, None)

    # Condition: test case 1, no optional args
    tmp = None
    task_vars = None
    result = module.run(tmp, task_vars)
    assert result['failed'] == False
    assert result['changed'] == False
    assert result['ansible_stats']['per_host'] == False
    assert result['ansible_stats']['aggregate'] == True
    assert result['ansible_stats']['data'] == {}

    # Condition: test case 2, optional args, k and v are strings
    tmp = None
    task_vars = None
    data = {'k1': 'v1'}
    result = module.run(tmp, task_vars, aggregate=True, data=data, per_host=True)
    assert result['failed']

# Generated at 2022-06-11 12:30:35.249400
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_base = ActionBase()
    action_base.add_argument = Mock(return_value=None)
    action_module = ActionModule(action_base)
    assert action_module.argument_spec == {}


# Generated at 2022-06-11 12:30:46.334144
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Test set_stats.py: Test run method of class ActionModule")
    import ansible
    import os
    # setup basic mock, but will have to tweak a bit later
    mock_loader = mock_loader_factory()

    mock_task = mock_task_factory(None)
    mock_task_vars = mock_task_vars_factory(0)

    # Create mock task to be used for ActionModule
    class TestActionModule(ActionModule):
        # ========================================================
        # Override methods of ActionModule
        # ========================================================
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            super(TestActionModule, self).__init__(task, connection, play_context, loader, templar, shared_loader_obj)

# Generated at 2022-06-11 12:30:46.722277
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-11 12:30:47.671827
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO
    assert False

# Generated at 2022-06-11 12:30:57.303729
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    args = {}
    task = Task()
    task._parent = Play()
    task._role = None
    task.context = PlayContext()

    am = ActionModule(task, args)
    assert isinstance(am, ActionModule)

# Generated at 2022-06-11 12:31:03.648235
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''Ensures the correct excpetion is raised if an invalid variable name is given'''

    class Task(object):
        def __init__(self):
            self.args = dict()

    class MyModule(ActionModule):
        def __init__(self):
            self._task = Task()

    try:
        m = MyModule()
        m.run(tmp='/tmp/', task_vars=dict())
        assert False
    except Exception as e:
        assert 'The variable name' in str(e)

# Generated at 2022-06-11 12:31:06.020464
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None)
    assert isinstance(action._VALID_ARGS, frozenset)
    assert action.TRANSFERS_FILES == False

# Generated at 2022-06-11 12:31:06.473113
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()

# Generated at 2022-06-11 12:31:13.243885
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create action module object
    am = ActionModule()

    # Create vars for action module
    task_vars = dict(a=1, b=2, c=3, test_dict=dict(a=1, b=2, c=3))

    # Set local namespace
    am.set_local_information(loader=None, templar=None, shared_loader_obj=None)

    # Set task vars
    am.set_task_vars(vars=task_vars)

    # Create args for action module
    args_dict = dict(data=dict(a='{{ a }}', b='{{ b }}', c='{{ c }}'))
    
    args = dict()
    args['_original_file'] = '/some/path/main.yml'

# Generated at 2022-06-11 12:31:25.081610
# Unit test for constructor of class ActionModule
def test_ActionModule():
    json_data_str = '''
    {
        "delegate_to": "test",
        "hostvars": {
            "host1": {
                "var1": "value1"
            }
        },
        "playbook_dir": "/home/ansible",
        "play_hosts": [
            "host1"
        ]
    }
    '''

    json_data = json.loads(json_data_str)
    test_task = json_data
    test_loader = DictDataLoader()
    test_play_context = PlayContext()
    test_play = Play().load(test_task, test_loader, test_play_context)
    test_self = ActionModule()
    test_self._connection = Connection()
    test_self._task = test_play
    test_task

# Generated at 2022-06-11 12:31:34.217825
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    set_stats = ActionModule()
    set_stats._templar = {"last_task": {"name": "task1"},
                      "hostvars": {
                          "host1": {"ansible_host": "10.0.0.1", "ansible_user": "root"},
                          "host2": {"ansible_host": "10.0.0.2", "ansible_user": "root"},
                          "host3": {"ansible_host": "10.0.0.3", "ansible_user": "root"}}
                      }

    # No args
    task = {"action": {"module": "set_stats"}}
    res = set_stats.run(task)
    assert res['failed'] is False

# Generated at 2022-06-11 12:31:44.295290
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create the class.
    am = ActionModule()

    # Make sure that the _task member is properly initialized.
    assert isinstance(am._task, dict)

    # Make sure that the _loader member is properly initialized.
    assert am._loader is None

    # Make sure that the _shared_loader_obj member is properly initialized.
    assert am._shared_loader_obj is None

    # Make sure that the _templar member is properly initialized.
    assert am._templar is None

    # Make sure that the _connection member is properly initialized.
    assert am._connection is None

    # Make sure that the _play_context member is properly initialized.
    assert am._play_context is None

    # Make sure that the _task_vars member is properly initialized.
    assert am._task_vars is None

    # Make sure that

# Generated at 2022-06-11 12:31:44.853628
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:31:54.944162
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # construct a mock task with a valid action
    task_ds = {
        'action': 'set_stats',
        'delegate_to': 'localhost',
        'args': {'data': {}, 'per_host': 'false', 'aggregate': 'true'}
    }
    task = MockTask(task_ds)

    # construct a mock play context with a valid connection
    play_context = MockPlayContext()

    # construct a mock loader object
    loader = MockLoader()

    # construct a mock templar object
    templar = MockTemplar(loader=loader)

    # construct a test action plug-in
    set_stats = ActionModule(task=task, play_context=play_context, loader=loader, templar=templar)
    # assert that the action plug-in was constructed successfully
   

# Generated at 2022-06-11 12:32:09.743068
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task

    # set up test objects
    task = Task()
    task._role = None
    play_context = PlayContext()
    task_vars = dict()

    # create ActionModule object
    p = ActionModule(task, play_context, task_vars)
    assert p is not None

# Generated at 2022-06-11 12:32:12.931115
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action
    plugin_inst = ansible.plugins.action.ActionModule(None, {}, {}, {})
    assert isinstance(plugin_inst._VALID_ARGS, frozenset)

# Generated at 2022-06-11 12:32:16.255921
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule(task='task', connection='connection', play_context='play_context', loader='loader', templar='templar', shared_loader_obj='shared_loader_obj')


# Generated at 2022-06-11 12:32:24.515591
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

    res = action_module.run()
    assert(res['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True})
    assert(res['changed'] == False)

    # check return value of run() with data only
    res = action_module.run(task_vars={"ansible_hostname": "host1"},
                            tmp=None,
                            task_action=dict(
                                action=dict(module_name="set_stats",
                                            module_args=dict(data=dict(ansible_hostname="host1")))))
    assert(res['ansible_stats'] == {'data': {'ansible_hostname': 'host1'}, 'per_host': False, 'aggregate': True})

# Generated at 2022-06-11 12:32:25.486693
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement test
    assert False

# Generated at 2022-06-11 12:32:36.019699
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Get a temporary path.
    import tempfile
    tmp = tempfile.mkdtemp()

    # Create a task object.
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager._extra_vars = {'x': 'foo', 'y': 'bar'}
    variable_manager._options_vars = {'x': 'zoo', 'y': 'zar'}
    t = Task()

    # Create an action base object.
    from ansible.plugins.action import ActionBase

# Generated at 2022-06-11 12:32:36.892148
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert hasattr(ActionModule, 'run')

# Generated at 2022-06-11 12:32:38.158500
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule(None, dict())

    x.run(None, dict())

# Generated at 2022-06-11 12:32:47.241096
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    task = Task()
    task.__class__ = Task
    task.action = 'debug'
    task.args = "{{ test_var }}"

    play_context = PlayContext()
    play_context.__class__ = PlayContext
    play_context.become = True

    play = Play()
    play.__class__ = Play
    play.connection = 'local'
    play.hosts = ['localhost']
    play.name = 'debug'

# Generated at 2022-06-11 12:32:51.943779
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test set-stats module

    task_args = {
        'aggregate': True,
        'data': {
            'a': '{{ a }}',
            'b': '{{ b }}',
        }
    }
    task_vars = {
        'a': 'foo',
        'b': 'bar',
        'c': 'baz',
    }
    result = {
        'changed': False,
        'ansible_stats': {
            'data': {
                'a': 'foo',
                'b': 'bar',
            },
            'aggregate': True,
        }
    }

    def run_test_case(test_case):
        result['ansible_stats']['data'].update(test_case['data'])

# Generated at 2022-06-11 12:33:22.407995
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host

    class Connection:
        def __init__(self):
            self.transport = 'local'

    class Runner(object):

        def __init__(self):
            self.stats = {}

        def update_stats(self, stats, remote_host=None):
            self.stats = stats

    class PlaybookCallbacks:
        def __init__(self):
            self.stats = {}

        def on_stats(self, stats):
            self.stats = stats

    user_vars = dict(foo='foo', bar='bar')

# Generated at 2022-06-11 12:33:30.884082
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create a global variable on module level
    theGlobalVar = 'Hallo'
    # construct an ActionModule object, with theModuleName='set_stats'
    moduleObject = ActionModule(theModuleName='set_stats')

    moduleObject.theGlobalVar = 'Hallo'

    stats = {'data': {}, 'per_host': False, 'aggregate': True}

    taskArgs = {'data': {'theGlobalVar': '{{ theGlobalVar }}'}}
    # create a dictionary with keys corresponding to the arguments of the method run of class ActionModule
    taskVars = {'theGlobalVar': 'Hallo'}

    assert moduleObject.run(tmp=None, task_vars=taskVars) == {'ansible_stats': stats, 'changed': False}



# Generated at 2022-06-11 12:33:36.187150
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(dict(per_host=True, aggregate=False, data={'a': '1', 'b': 2}),
                          task=dict(args={'per_host': True}))
    res = action.run(task_vars={'ansible_stats': {'test': 'a'}})
    assert res.get('ansible_stats').get('per_host') == True
    assert res.get('ansible_stats').get('data').get('a') == '1'

# Generated at 2022-06-11 12:33:41.441377
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    my_obj = ActionModule(task=dict(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # test the run method using correct arguments
    my_obj.run(tmp=None, task_vars=None)
    my_obj.run(tmp=None, task_vars={})
    my_obj.run(tmp=None, task_vars=dict())



# Generated at 2022-06-11 12:33:43.545508
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(ActionBase)
    assert action_module.TRANSFERS_FILES is False
    assert action_module._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-11 12:33:52.634336
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test task.args.get('data') is a dict
    task_args = {'data': {'test_1': 'value1', 'test_2': 'test2'}}
    this_module = ActionModule(load_fixture_file('set_stats_module.json', action=task_args))
    result = this_module.run(task_vars=None)
    assert not result.get('failed', False)
    assert result.get('changed', False)
    assert result.get('ansible_stats', {}).get('aggregate', False)
    assert not result.get('ansible_stats', {}).get('per_host', True)
    assert result.get('ansible_stats', {}).get('data', None) == {'test_1': 'value1', 'test_2': 'test2'}

# Generated at 2022-06-11 12:33:58.987003
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action as ac
    import ansible.plugins.action.set_stats as stats
    import ansible.plugins.action.debug as debug

    stats = stats.ActionModule('../../../action_plugins/set_stats.py')
    set_stats = debug.ActionModule('../../../action_plugins/debug.py')

    set_stats_result = set_stats.run(None, None)
    assert set_stats_result['ansible_facts']['ansible_version']['full'] == '2.1.2.0'
    set_stats_result = set_stats.run(None, {'ansible_version': {'full': '2.1.3.0'}})

# Generated at 2022-06-11 12:34:01.742990
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(
        task=dict(),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict())
    action.connection = None
    assert action

# Generated at 2022-06-11 12:34:10.059797
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Parametric Unit test for method run for class ActionModule"""
    import tempfile
    from ansible.module_utils.six import PY3
    module = ActionModule()
    task_vars = {}
    result = {
        'ansible_facts': {},
        'ansible_modules': {},
        'ansible_play_hosts_all': {},
        'ansible_play_batch': [],
        'ansible_play_hosts': {},
        'ansible_play_rolenames': [],
        'ansible_play_role_names': [],
    }
    apiResult = {
        'json': {},
        'status': 200
    }

# Generated at 2022-06-11 12:34:13.381795
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am.run(task_vars={})['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True}

# Generated at 2022-06-11 12:35:07.741469
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isidentifier('a')
    assert isidentifier('a_2')
    assert isidentifier('_a_2')
    assert not isidentifier('2')
    assert not isidentifier('-a')
    assert isinstance(ActionModule._VALID_ARGS, frozenset)

# Generated at 2022-06-11 12:35:13.060349
# Unit test for constructor of class ActionModule
def test_ActionModule():
  task = dict(action = dict(module = 'set_stats', args= dict(data=dict(key='value'))))
  # Mock the task executor
  task_executor = action_module.ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
  res = task_executor.run(None, None)  
  assert res['ansible_stats']['data']['key'] == 'value'

# Generated at 2022-06-11 12:35:16.855361
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement unit test of function run
    pass

if __name__ == '__main__':
    import sys
    import doctest
    doctest.testmod()

    arguments = sys.argv[1:]
    if len(arguments):
        if "--unit" in arguments:
            test_ActionModule_run()

# Generated at 2022-06-11 12:35:18.381362
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, {})
    assert(isinstance(action, ActionModule))

# Generated at 2022-06-11 12:35:28.592254
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action import ActionBase
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.template import Templar
    from ansible.utils.boolean import boolean
    from ansible.module_utils.six import string_types


# Generated at 2022-06-11 12:35:34.259149
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock
    from ansible.executor.task_result import TaskResult
    from ansible.plugins.action import ActionBase

    action = ActionModule(MagicMock(), {}, MagicMock())

    # test without data
    result = action._execute_module(tmp=None, task_vars=None)
    assert result == {'ansible_stats': {u'per_host': False, u'aggregate': True, u'data': {}}}

    # test with data
    data = "{{foo}}"
    args = {'data': data}

    action = ActionModule(MagicMock(), args, MagicMock())


# Generated at 2022-06-11 12:35:44.251714
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_mod = ActionModule()
    assert action_mod.run() == {'ansible_stats': {'aggregate': True, 'data': {}, 'per_host': False}, 'changed': False}

    action_mod = ActionModule()
    assert action_mod.run(task_vars={}) == {'ansible_stats': {'aggregate': True, 'data': {}, 'per_host': False}, 'changed': False}

    action_mod = ActionModule()
    assert action_mod.run(task_vars={'this': {'dict': 'test'}}) == {'ansible_stats': {'aggregate': True, 'data': {}, 'per_host': False}, 'changed': False}

    action_mod = ActionModule()

# Generated at 2022-06-11 12:35:50.326476
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    import pytest

    am = ActionModule(
        task=TaskInclude(),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)

    assert am.action == 'set_stats'

# Generated at 2022-06-11 12:35:51.241576
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    assert action_module

# Generated at 2022-06-11 12:35:53.763756
# Unit test for constructor of class ActionModule
def test_ActionModule():
    t = ActionModule()
    assert t._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))
    assert t.TRANSFERS_FILES == False


# Generated at 2022-06-11 12:37:45.040608
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = dict(
        args = dict(
            data = dict(
                foo = '{{bar}}',
                baz = ['qux']
            )
        )
    )
    templar = dict(
        template = lambda x, convert_bare=False, fail_on_undefined=True: x,
    )
    invoker = dict(
        _task = task,
        _templar = templar,
    )
    action_module = ActionModule()
    action_module.__dict__.update(invoker)

    # test
    result = action_module.run()

    # verify

# Generated at 2022-06-11 12:37:47.547801
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #print("ActionModule")
    AM = ActionModule(load_plugins=False, runner_queue=None, connection_queue=None, become_queue=None)
    #print("ActionModule done")
    return AM

# Verify that required dictionary keys for result dictionary are present

# Generated at 2022-06-11 12:37:48.377744
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None)

# Generated at 2022-06-11 12:37:50.503873
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(datastructure=None, task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None, an_ds=None)
    assert isinstance(am, ActionModule)

# Generated at 2022-06-11 12:37:51.798441
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(None, None)
    assert isinstance(action_module.run(), dict)

# Generated at 2022-06-11 12:37:53.977275
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    ActionModule is a class inheriting ActionBase
    """
    am = ActionModule()
    assert am.__class__.__bases__[0] == ActionBase

# Generated at 2022-06-11 12:37:54.469148
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:38:00.488610
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()

    # Test valid args
    setattr(module, '_task', {'args': {'aggregate': True}})
    setattr(module, '_Templar', {})
    setattr(module, '_templar', {})
    assert module.run()['ansible_stats']['aggregate'] is True

    # Test invalid args
    setattr(module, '_task', {'args': {'aggregate': 1}})
    setattr(module, '_Templar', {})
    setattr(module, '_templar', {})
    assert module.run()['msg'] == 'The "aggregate" option needs to be a boolean'

# Generated at 2022-06-11 12:38:01.432758
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__doc__ is not None



# Generated at 2022-06-11 12:38:08.202327
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Instantiate object
    task_vars = dict()
    action_module = ActionModule({}, task_vars=task_vars)

    # Run the method with the required parameters
    result = action_module.run(tmp=None, task_vars=task_vars)

    # Check the returned object
    assert type(result) is dict
    assert len(result) == 2
    assert 'changed' in result
    assert result['changed'] == False

    # Check the value of the returned object, ansible_stats sub-dictionary
    ansible_stats_dict = result['ansible_stats']
    assert type(ansible_stats_dict) is dict
    assert len(ansible_stats_dict) == 3

    # Check the value of the returned object, data sub-dictionary
    data_dict = ansible_stats