

# Generated at 2022-06-11 12:28:55.692313
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ans_ret = dict()
    ans_ret['user'] = 'Ansible'
    ans_ret['age'] = 25
    ans_ret['hostname'] = 'localhost'
    ans_ret['per_host'] = False
    ans_ret['aggregate'] = True

    _tmp = dict()
    _tmp['data'] = dict()
    _tmp['data']['user'] = '{{ ansible_user_id }}'
    _tmp['data']['age'] = 25
    _tmp['data']['hostname'] = '{{ ansible_hostname }}'

    # test_instance = __class__(True, 'Bad class name')
    test_instance = ActionModule(True, 'Bad class name')

    test_instance._task.args = _tmp

    tmp=None

# Generated at 2022-06-11 12:28:56.245173
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 12:29:01.827903
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)
    assert not hasattr(ActionModule, 'run')
    module = ActionModule(
        task=dict(),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert isinstance(module, object)
    assert isinstance(module, ActionModule)

# Generated at 2022-06-11 12:29:02.462700
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:29:03.693493
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for the method run of class ActionModule
    """
    pass

# Generated at 2022-06-11 12:29:14.498436
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule

    result = {}

    module = ActionModule()

    # test for data type other than dict
    # expected output: {'failed': True, msg: 'The 'data' option needs to be a dictionary/hash'}
    task = {'args': {'data': 'some_string'}}

    module_result = module.run(task_vars={}, task=task, result=result)

    assert module_result['failed']

    # test for dict with invalid variable names
    # expected output: {'failed': True, msg: 'The variable name 'test$test' is not valid ...'}
    task = {'args': {'data': {'test$test': 'some_string'}}}


# Generated at 2022-06-11 12:29:24.747522
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class MockModule(object):
        def __init__(self, args):
            self.args = args

    class MockTask(object):
        def __init__(self, args):
            self.args = args

    action_module = ActionModule(MockTask(dict(per_host=True)), dict())
    assert action_module.run(None, None) == dict(
        changed=False,
        ansible_stats=dict(data={}, per_host=True, aggregate=True))

    # Test that a bad data value is rejected
    action_module = ActionModule(MockTask(dict(data=True)), dict())
    assert action_module.run(None, None) == dict(
        failed=True,
        msg="The 'data' option needs to be a dictionary/hash")

    # Test that templating of the

# Generated at 2022-06-11 12:29:26.073650
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True


# ansible-2.5/lib/ansible/plugins/action/set_stats.py

# Generated at 2022-06-11 12:29:36.603940
# Unit test for constructor of class ActionModule
def test_ActionModule():

    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    argument_spec = {
        'data':  dict(type='dict', required=False),
        'aggregate': dict(type='bool', default=True),
        'per_host': dict(type='bool', default=False),
    }

    tmp = basic._ANSIBLE_ARGS
    basic._ANSIBLE_ARGS = basic.AnsibleArgumentSpec(argument_spec=argument_spec)

    action_mod = ActionModule(task=dict(), connection=basic.FakeConnection())

    print(action_mod.__dict__)
    assert action_mod.__dict__['_config'] == basic._ANSIBLE_ARGS.__dict__
    assert action_mod.__dict__['_task'] == dict()
   

# Generated at 2022-06-11 12:29:46.927080
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import hashlib

    task_args = dict(
        data=dict(
            p1='val1',
            p2='val2'
        ),
        aggregate=True,
        per_host=True
    )


# Generated at 2022-06-11 12:30:00.671963
# Unit test for constructor of class ActionModule
def test_ActionModule():
    def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
        super(ActionModule, self).__init__(task, connection, play_context, loader, templar, shared_loader_obj)

    instance = ActionModule(object(), object(), object(), object(), object(), object())

    assert isinstance(instance._VALID_ARGS, frozenset)
    assert 'aggregate' in instance._VALID_ARGS
    assert 'data' in instance._VALID_ARGS
    assert 'per_host' in instance._VALID_ARGS
    assert instance._VALID_ARGS == frozenset(['aggregate', 'data', 'per_host'])


# Generated at 2022-06-11 12:30:11.942612
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.ansible_modlib.common.hashing import secure_hash
    import pytest
    from ansible.module_utils.basic import AnsibleModule, AnsibleExitJson, AnsibleFailJson

    def raise_exc(classname, msg):
        raise classname(msg)

    def test_module(**kwargs):
        return kwargs

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(type='dict'),
            aggregate=dict(type='bool'),
            per_host=dict(type='bool')
        ),
        supports_check_mode=True
    )


# Generated at 2022-06-11 12:30:20.872896
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup initial test variables
    queue = []

    # Setup a dummy ansible options object "fake_ansible_options"
    fake_ansible_options = type('', (), {})()

    # Setup a dummy ansible loader object "fake_ansible_loader"
    fake_ansible_loader = type('', (), {})()

    # Setup a dummy ansible VariableManager object "fake_ansible_vars"
    fake_ansible_vars = type('', (), {})()

    # Create an instance of ActionModule
    am = ActionModule(
        queue,
        fake_ansible_options,
        fake_ansible_loader,
        fake_ansible_vars,
    )

    # Test run method

# Generated at 2022-06-11 12:30:30.338840
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.action.set_stats import ActionModule
    acm = ActionModule(None, dict(action=dict(set_stats=dict(data=dict(asdf=dict(hjkl='lkjh')), per_host=True))))
    print(acm.run(task_vars={}))
    acm = ActionModule(None, dict(action=dict(set_stats=dict(data=dict(asdf=dict(hjkl='lkjh')), per_host='{{true}}'))))
    print(acm.run(task_vars={}))

# Generated at 2022-06-11 12:30:35.797422
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    This is where we'd normally test the constructor of the main class
    for our action plugin, however, since this plugin does not do anything
    special in it's constructor, there is no need.

    This is where we do the unit test for the class
    """
    tmp = None
    task_vars = None
    module = ActionModule(tmp, task_vars)
    assert(type(module) is ActionModule)

# Generated at 2022-06-11 12:30:36.990279
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # instantiate class
    actionmodule = ActionModule()
    assert actionmodule is not None

# Generated at 2022-06-11 12:30:38.577783
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        action_module = ActionModule(None)
    except Exception:
        return False

    return True


# Generated at 2022-06-11 12:30:49.249628
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json
    import mock
    import task_vars
    from module_utils.parsing.convert_bool import boolean

    module = ActionModule(task=mock.Mock(), connection=mock.Mock(), play_context=mock.Mock())

    # no args, task vars is None
    result = module.run()
    task_vars = result['ansible_stats']
    assert task_vars.get('data', {}) == {}
    assert task_vars.get('per_host', False) is False
    assert task_vars.get('aggregate', True) is True

    # args has data
    result = module.run(task_vars=task_vars.get('data', None))
    task_vars = result['ansible_stats']
    assert task_vars

# Generated at 2022-06-11 12:30:50.539951
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  module = ActionModule()
  module.run()

# Generated at 2022-06-11 12:30:51.760087
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("TEST:: test_ActionModule")
    assert True

# Generated at 2022-06-11 12:31:05.813003
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action is not None
    assert isinstance(action, ActionModule)
    assert isinstance(action._VALID_ARGS, frozenset)

# Generated at 2022-06-11 12:31:12.869961
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #
    # Construct a mock object of class TaskExecutor.  We will use it
    # to inject appropriate values into an ActionModule object.
    #
    class TaskExecutor:
        def __init__(self):
            self.play = None
            self.playbook = None
            self.shared_loader_obj = None
            self.tmpdir = None
            self.include_vars = None
            self.vars_plugins = None
            self.vars_files = None

        def start(self):
            pass

    class Task:
        def __init__(self):
            self.action = None
            self.loop = None
            self.block = None
            self.tags = None
            self.role_name = None
            self.args = None


# Generated at 2022-06-11 12:31:13.833942
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionModule)

# Generated at 2022-06-11 12:31:25.859139
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Testing run method with different values of options
    # 'data', 'per_host' and 'aggregate'
    from ansible.plugins import action
    from ansible.utils.vars import combine_vars

    module_name = 'test_action_module'
    action_name = 'set_stats'

    # in following test cases, we are using None as first argument
    # of run method of class ActionModule which is tmp and
    # second argument is taskvars which is a variable used by ansible
    # which we don't use here

    # case 1: testing with 'data' option
    task = {'action': {'module': module_name, 'args': {'data': {'results': 'some_value'}}}}

# Generated at 2022-06-11 12:31:34.609707
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    print("### Running test_ActionModule_run()")

    import re, sys, os
    import lib.ansible_module_set_stats

    argv = sys.argv
    sys.argv = [argv[0], "DUMMYTMP", "DUMMYTASKVARS"]

    # Validate task_vars type
    set_stats = lib.ansible_module_set_stats.ActionModule()
    result = set_stats.run(tmp=None, task_vars=None)
    assert 'msg' in result and result['msg'] == "DUMMYTASKVARS needs to be a dictionary/hash"

    # Validate template dictionary type
    result = set_stats.run(tmp=None, task_vars={})

# Generated at 2022-06-11 12:31:37.740126
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am.TRANSFERS_FILES == False
    assert am._VALID_ARGS == frozenset([ 'aggregate', 'data', 'per_host' ])

# Generated at 2022-06-11 12:31:47.562297
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.task import Task
    from ansible.playbook.task import Task as PlaybookTask
    module = ActionModule()
    task = Task()
    playbooktask = PlaybookTask()
    playbooktask._ds = dict()
    task.action = 'set_stats'
    task._ds = dict()
    task.args = {'aggregate': True, 'data': {'test': 'test'}, 'per_host': False}
    module._task = task
    result = module.run(task_vars={})

# Generated at 2022-06-11 12:31:54.614714
# Unit test for constructor of class ActionModule
def test_ActionModule():

    module_args = {'data': {'testvar': 'testvalue', 'testarr': ['test1', 'test2']}, 'per_host': True, 'aggregate': False}
    mock_loader = MockLoader()
    action_module = ActionModule(mock_loader, module_args)

    assert action_module.run() == {'ansible_stats': {'aggregate': False, 'data': {'testarr': ['test1', 'test2'], 'testvar': 'testvalue'}, 'per_host': True}, 'changed': False}

# Generated at 2022-06-11 12:32:02.662033
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # test for missing args dict
    am = ActionModule(dict(ANSIBLE_MODULE_ARGS=None), only_help=True)
    assert(am.only_help is True)

    # test for missing data dict
    am = ActionModule(dict(ANSIBLE_MODULE_ARGS=dict(data=None)), only_help=True)
    assert(am.only_help is True)

    # test for existing data dict
    am = ActionModule(dict(ANSIBLE_MODULE_ARGS=dict(data=dict())), only_help=True)
    assert(am.only_help is True)

# Generated at 2022-06-11 12:32:03.283703
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-11 12:32:32.766919
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.playbook.task import Task

    TASK_DATA = dict(
        name="set_fact",
        action=dict(module=to_bytes('set_stats'), aggregate=to_bytes(False), per_host=to_bytes(True), data=dict(foo=to_bytes(True)))
    )

    task = Task.load(TASK_DATA)
    action_mod = ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    args = dict(aggregate=False, per_host=True, data={'foo':True})
    result = action_mod.run(task_vars=None, tmp=None)

# Generated at 2022-06-11 12:32:42.544709
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = AnsibleModule(
        #argument_spec=dict(),
        #supports_check_mode=False
    )

    # mock the result of ActionBase._connection_info, this method is called in ActionModule.run()
    ActionBase._connection_info = MagicMock(name='_connection_info')
    ActionBase._connection_info.return_value = (None, None)

    # mock the result of ActionBase.transport, this method is called in ActionBase._connection_info()
    ActionBase.transport = 'local'

    # create test object
    am = ActionModule(
        task=dict(action=dict(module_name='set_stats')),
        connection=None,
        play_context=dict(become=None, become_user=None)
    )

    # execute run(self)
    result

# Generated at 2022-06-11 12:32:51.598262
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # test_raw
    raw = dict(
        __ansible_module__="module1",
        __ansible_arguments__="arguments1",
        __ansible_sys_argv=["ansible_sys_argv1", "ansible_sys_argv2"],
        __ansible_version__="version1",
        __ansible_playbook_python__="playbook_python1",
        __ansible_playbook_dir__="playbook_dir1",
        __ansible_managed__="managed1",
        __ansible_execute_module__=False,
        __ansible_command__="command1",
        __ansible_diff__=True,
        __ansible_no_log__=True,
        __ansible_verbosity__=2
    )

    # test_args
   

# Generated at 2022-06-11 12:32:52.602373
# Unit test for constructor of class ActionModule
def test_ActionModule():
    return ActionModule(task=None)

# Generated at 2022-06-11 12:33:02.046878
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule"""
    test_module = ActionModule()
    test_module.action._load_name = 'set_stats'
    test_module.action._task = test_task
    test_module.action._loader = test_loader
    test_module.action._shared_loader_obj = test_shared_loader_obj
    test_module.action.templar = test_templar
    test_module.action.templar.environment = test_play_context
    test_module.action._connection = test_connection
    test_module.action.datastructure = test_datastructure
    test_module.action.play_context = test_play_context
    result = test_module.run()

# Generated at 2022-06-11 12:33:08.207930
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule('test', dict(data=dict(first=11, second=22)), False, False)
    assert module.action == 'test'
    assert module.module_name == 'test'
    assert module.module_args == dict(data=dict(first=11, second=22))
    assert module.boolean_options == ()
    assert 'ansible_stats' not in module.result
    assert module._task is not None
    assert module._connection is None
    assert module._play_context is None
    assert module._loader is None
    assert module._templar is None
    assert module._shared_loader_obj is None

# Generated at 2022-06-11 12:33:13.650743
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_base = ActionBase()
    action_module = ActionModule(action_base._task, action_base._connection, action_base._play_context, action_base._loader, action_base._templar, action_base._shared_loader_obj)
    assert action_module.action == 'set_stats'
    assert action_module.TRANSFERS_FILES is False
    assert action_module._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))


# Generated at 2022-06-11 12:33:14.183500
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-11 12:33:24.100347
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    a = ActionModule()
    assert a.run() == dict( changed = False, ansible_stats = dict( data = {}, per_host = False, aggregate = True) )
    assert a.run(task_vars = dict()) == dict( changed = False, ansible_stats = dict( data = {}, per_host = False, aggregate = True) )
    assert a.run(task_vars = dict(var1=10, var2=20)) == dict( changed = False, ansible_stats = dict( data = {}, per_host = False, aggregate = True) )
    assert a.run(task_vars = dict(var1=10, var2=20), tmp=None) == dict( changed = False, ansible_stats = dict( data = {}, per_host = False, aggregate = True) )
    assert a

# Generated at 2022-06-11 12:33:27.287935
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Check whether action module is of ActionModule class
    action_plugin = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(action_plugin, ActionModule)

# Generated at 2022-06-11 12:34:09.738598
# Unit test for constructor of class ActionModule
def test_ActionModule():
    inst = ActionModule( task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert inst._VALID_ARGS == frozenset(['aggregate', 'data', 'per_host'])



# Generated at 2022-06-11 12:34:13.740998
# Unit test for constructor of class ActionModule
def test_ActionModule():

    class TestModule(object):
        def __init__(self, args=None):
            self.args = args

    task = TestModule()
    action = ActionModule(task, task_vars=dict())

    assert action.run()

# Generated at 2022-06-11 12:34:23.093112
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # create a dummy task
    task = {'args': {'data': {'a': 1, 'b': 2, 'c': 3}, 'per_host': False, 'aggregate': True}}

    # create a dummy module_utils
    module_utils = {}

    # create a dummy module_utils/parsing/conver_bool
    module_utils['parsing'] = {}
    module_utils['parsing']['convert_bool'] = boolean

    # create a dummy module_utils/urls
    module_utils['urls'] = None

    # create an instance of ActionModule
    am = ActionModule(task, module_utils)

    # get the result
    res = am.run()

    # assert the result

# Generated at 2022-06-11 12:34:29.295759
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create mock inventory and task objects
    class MockInventory(object):
        def __init__(self):
            self.hosts = ['foo.example.com']
    inv = MockInventory()
    class MockTask(object):
        def __init__(self):
            self.args = {}
    task = MockTask()
    action_module = ActionModule(task, inv, None, None, None)
    # Test the method with some possible valid inputs
    for data in (
            {'data': {'foo': 42}, 'per_host': True},
            {'data': {'foo': 42}, 'per_host': False, 'aggregate': False}
    ):
        task.args = data
        result = action_module.run()
        assert result['changed'] == False

# Generated at 2022-06-11 12:34:30.757645
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(ActionModule._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host')))

# Generated at 2022-06-11 12:34:40.651574
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create mocks
    mock_plugins = {'action': {'set_stats': ActionModule}}
    hostvars = dict()
    hostvars['hostname'] = 'localhost'
    hostvars['groups'] = ['group1', 'group2']
    mock_task_vars = {'inventory_hostname': 'localhost', 'ansible_ssh_host': 'localhost', 'group_names': ['group1', 'group2'],
                      'hostvars': hostvars}

    # Create a task
    mock_task = type('task', (object,), {'args': {'aggregate': True, 'data': {'hostname': '{{ inventory_hostname }}', 'groups': '{{ group_names }}'}},
                                         'run_once': False})()

    # Create action object

# Generated at 2022-06-11 12:34:42.998410
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(0, dict(), False, None, None)
    assert action_module is not None
    assert action_module.TRANSFERS_FILES == False

# Generated at 2022-06-11 12:34:48.668486
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(
        task=dict(action=dict(module_name='set_stats', module_args=dict(data='{{ foo }}', aggregate=True))),
        connection=dict(module_name='local', module_args=dict()),
        play_context=dict(check_mode=False),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert a

# Generated at 2022-06-11 12:34:51.836411
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ check if test_ActionModule is created properly"""

    # create an object of ActionModule class
    my_obj = ActionModule()
    # check if the object is created properly or not
    assert my_obj
    # check one of the method of the class
    assert my_obj.run()

# Generated at 2022-06-11 12:34:56.516391
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.loader import action_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    # Create action module object
    mod = action_loader.get('set_stats', class_only=True)()

    # Create data structures needed by the action module
    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=None)
    vars_manager = VariableManager(loader=loader, inventory=inv_manager)

    # Mock task() method in order to simualte the task passed in
    class bcolors():
        OKGREEN = ""
        FAIL = ""
        ENDC = ""
    import __builtin__

# Generated at 2022-06-11 12:36:45.957620
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Testing the ActionModule constructor")

    assert issubclass(ActionModule, ActionBase)
    assert support.isidentifier('_a') == True
    assert support.isidentifier('_a1') == True
    assert support.isidentifier('1a') == False
    assert support.isidentifier('ab c') == False

# Generated at 2022-06-11 12:36:54.963479
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_task = type("Mock", (), {
        'action': 'my_action',
        'args': {'data': [ 'foo' ], 'aggregate': True, 'per_host': True },
        'delegate_to': 'localhost'
    })

    mock_loader = type("Mock", (), {
        'get_basedir': lambda _: '',
        'get_profile_vars': lambda _: {},
        'get_plugin_loaders': lambda _: {}
    })

    mock_templar = type("Mock", (), {
        'template': lambda _: [ 'foo' ]
    })


# Generated at 2022-06-11 12:36:57.862148
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Constructor of ActionModule does nothing.
    We just test that instantiation does not result in an exception
    '''
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am is not None

# Generated at 2022-06-11 12:37:00.777009
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am is not None
    assert am.TRANSFERS_FILES is False
    assert am._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))



# Generated at 2022-06-11 12:37:08.874954
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.playbook.play
    from ansible.playbook.task import Task

    play_context = ansible.playbook.play.PlayContext()
    play = ansible.playbook.play.Play.load(dict(
        name="Ansible Play",
        hosts=['fake_host'],
        gather_facts='no',
        tasks=[dict(action=dict(module='set_stats', args=dict(data=dict(test_var=5))))]
    ), loader=None, variable_manager=None)

    t = Task()
    t._role = None
    t.action = 'set_stats'
    t.args = dict(data=dict(test_var=5))
    t.block = None


# Generated at 2022-06-11 12:37:09.948690
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor of ActionModule is tested in test_action_factory.py
    pass

# Generated at 2022-06-11 12:37:12.257962
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule("Dummy").TRANSFERS_FILES == False
    assert ActionModule("Dummy")._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-11 12:37:14.783613
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule._VALID_ARGS == frozenset(['aggregate', 'data', 'per_host'])
    assert not ActionModule.TRANSFERS_FILES

# --- Unit tests
from ansible.playbook.task import Task


# Generated at 2022-06-11 12:37:21.035880
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    run_data = {
        'data': {
            'status': 'changed',
            'failed': False,
            'changed': True,
            'failed_when_result': True,
        },
        'per_host': False,
        'aggregate': True,
    }
    tmp, task_vars = None, {'ansible_facts': {}}
    action_module = ActionModule(tmp, task_vars)
    result = action_module.run(tmp, task_vars)

    assert result['ansible_stats'] == run_data

# Generated at 2022-06-11 12:37:26.401782
# Unit test for constructor of class ActionModule
def test_ActionModule():

    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler

    role = Role()
    t = Task()
    t._role = role
    try:
        am = ActionModule(t, "", "", "", "", "", None)
        assert am
        assert am._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))
    except AttributeError:
        assert False
    except Exception:
        assert False
