

# Generated at 2022-06-11 12:28:55.521438
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    module = ActionModule(None, None)

    assert module.run() == {'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}, 'changed': False}

    assert module.run(task_vars={'variable_name': 'value'}) == {'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}, 'changed': False}

    assert module.run(task_vars={'play_hosts': '127.0.0.1'}) == {'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}, 'changed': False}


# Generated at 2022-06-11 12:29:03.651119
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    setup_mock(mocker)
    am = ActionModule(load_fixture('set_stats_playbook.yml'),
                      dict(playbook=dict(hosts=[dict(name='testhost')])))
    res = am.run(task_vars=dict(ansible_check_mode=False, ansible_connection=dict(connection='local')))
    assert res.get('ansible_stats').get('data') == {'a': 1}
    assert res.get('ansible_stats').get('per_host') == False
    assert res.get('ansible_stats').get('aggregate') == True


# Generated at 2022-06-11 12:29:14.455348
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(connection=None,play_context=None,loader=None,templar=None,shared_loader_obj=None)
    action.set_task(name='set_stats', args={'data':{'a':1}, 'aggregate': True, 'per_host': False}, async_val=None, async_poll_interval=None, push_vars=None)
    action.task.action='set_stats'
    action._display={'ok':[], 'changed':[], 'skipped':[]}
    action._connection=None
    action.loader=None
    action.task_vars={}

    # Test per_host arg as a string and aggregate as a boolean

# Generated at 2022-06-11 12:29:16.053440
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ unit testing for method run of class ActionModule"""
    pass

# Generated at 2022-06-11 12:29:25.865410
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE

    am = ActionModule(play_context=PlayContext(), loader=None, templar=None, shared_loader_obj=None)
    am._task = None
    am._task_vars = dict()
    assert am.run(tmp=None, task_vars=am._task_vars) == {}

    am = ActionModule(play_context=PlayContext(), loader=None, templar=None, shared_loader_obj=None)
    am._task = Mock()
    am._task.args = dict(per_host=True, aggregate=False)
    am._task_vars = dict()

# Generated at 2022-06-11 12:29:29.849545
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None,None)
    assert isinstance(a._VALID_ARGS, frozenset)
    assert 'aggregate' in a._VALID_ARGS
    assert 'data' in a._VALID_ARGS
    assert 'per_host' in a._VALID_ARGS

# Generated at 2022-06-11 12:29:30.427890
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-11 12:29:37.829347
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_module = dict()
    action = ActionModule(mock_module)
    assert action._task.__module__ == '__main__'
    assert action._task.__name__ == '__main__'
    assert action._task.__doc__ == "action module"
    assert action._task.__file__ == 'test_action_module'
    assert action._task.__dict__ == mock_module
    assert action._task.__vars__ == dict()
    assert action._task.args == dict()


# Generated at 2022-06-11 12:29:47.631929
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # check that if an non-dict data is passed, it is templated and
    # if the resulting string is not a dict, failed is returned.
    assert_result = {'failed': True,
                     'msg': "The 'data' option needs to be a dictionary/hash"}
    data = "{{ not_a_dict }}"
    templar = AnsibleTemplar()
    result = templar.template(data, convert_bare=False, fail_on_undefined=True)
    assert_result['ansible_stats'] = {'data': {}, 'per_host': False, 'aggregate': True}
    assert (ActionModule(task=None).run(tmp=None, task_vars=None) == assert_result)


# Generated at 2022-06-11 12:29:54.569746
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # import the module file
    module_obj = __import__('ansible.plugins.action.set_stats', globals(), locals(), ['ActionModule'], 0)
    ActionModule = getattr(module_obj, 'ActionModule')

    # setup a fake task to use
    fake_task = DummyTask()

    # create an instance of ActionModule
    action_module = ActionModule(fake_task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # setup the mock return value of template method

# Generated at 2022-06-11 12:30:00.864926
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module is not None

# Generated at 2022-06-11 12:30:04.313360
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    res = module.run()
    assert res == {'changed': False, 'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}}

# Generated at 2022-06-11 12:30:05.304455
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None

# Generated at 2022-06-11 12:30:13.091876
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Setup test
    task_vars = dict(
        ansible_stats=dict(
            data=dict(ansible_facts_serial=1)
        )
    )

    # Execute method
    result = ActionModule.run(
        task_vars=task_vars,
        tmp=None,
        task_vars=task_vars
    )

    assert result['ansible_stats']['data'] == dict(ansible_facts_serial=2), 'Test should be successful'
    assert result['changed'] == False, 'Test should be successful'

# Generated at 2022-06-11 12:30:18.942808
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    from ansible.module_utils.parsing.convert_bool import boolean
    task_result = TaskResult('/foo', '')
    am = ActionModule(task_result, {'a': 1}, [])

    tmp = 'bar'
    task_vars = dict(a=1)
    result = am.run(tmp, task_vars)
    assert result['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True}
    assert result['ansible_facts'] == dict(a=1)

    # 'args' contains invalid data
    result = am.run(tmp, task_vars, dict(data='foo'))
    assert 'msg' in result
    assert result['failed'] is True
   

# Generated at 2022-06-11 12:30:20.799461
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, None)
    assert am is not None
    am.run(None, None)

# Generated at 2022-06-11 12:30:31.948088
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_module = dict()
    test_module['name'] = 'test_module'
    test_module['result'] = {'changed': False}
    test_module['rc'] = 0
    test_module['msg'] = 'OK'
    
    test_task = dict()
    test_task['name'] = 'test_task'
    test_task['result'] = {'changed': False}
    test_task['rc'] = 0
    test_task['msg'] = 'OK'
    test_task['ansible_stats'] = {'data': {'test': 'test1'}, 'per_host': False, 'aggregate': True}
    
    task = dict()
    task['action'] = 'set_stats'
    task['args'] = {'data': {'test': 'test1'}}
   

# Generated at 2022-06-11 12:30:42.806188
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.playbook.task import Task

    from ansible.playbook.block import Block

    from ansible.playbook.role import Role

    from ansible.playbook.play import Play

    from ansible.executor.task_queue_manager import TaskQueueManager

    from ansible.executor.playbook_executor import PlaybookExecutor

    from ansible.inventory.manager import InventoryManager

    from ansible.vars.manager import VariableManager

    from ansible.parsing.dataloader import DataLoader

    from ansible.module_utils.common.collections import ImmutableDict

    from ansible.plugins.callback import CallbackBase

    from ansible import context

    import os
    import json
    import sys


# Generated at 2022-06-11 12:30:51.236282
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import unittest
    import sys
    sys.modules['ansible'] = __import__('mock_ansible')
    from ansible import utils

    class Options(object):
        def __init__(self, args=None):
            self.args = args
            self.connection = 'local'
            self.module_path = None
            self.forks = 5
            self.remote_user = 'username'
            self.private_key_file = None
            self.ssh_common_args = None
            self.ssh_extra_args = None
            self.sftp_extra_args = None
            self.scp_extra_args = None
            self.become = False
            self.become_method = None
            self.become_user = None
            self.verbosity = False

# Generated at 2022-06-11 12:31:00.211036
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.plugins.action import ActionModule

    def test_method(data):
        module = AnsibleModule(argument_spec={'data': dict})
        task_vars = {'ansible_stats': {'data': {}}}
        action = ActionModule(None, task_vars, ActionBase._load_params())
        action.set_args(data)
        return action.run()

    d = {"test1": "test1",
         "test2": "test2"}
    # test that we can set stats
    result = test_method({'data': d})

# Generated at 2022-06-11 12:31:21.673585
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.utils.vars import merge_hash
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert am is not None
    assert am.ACTION_VERSION == '1.0'

    assert am.TRANSFERS_FILES == False
    assert am._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

    # TODO: test _load_params when implemented in action/__init__

    # TODO: test _execute when implemented in action/__init__

    # test _filter_unsupported_parameters
    assert am._filter_unsported_parameters('', {})

# Generated at 2022-06-11 12:31:25.666308
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_args = {
        "aggregate": "True",
        "per_host": "False",
        "data": {
            "test": "value"
        }
    }

    m = ActionModule(None, module_args, None)
    assert m is not None

# Generated at 2022-06-11 12:31:32.950934
# Unit test for constructor of class ActionModule
def test_ActionModule():
    def mock_task_class():
        class MockTask():
            def __init__(self):
                self.args = {'data': {'av1': 'bv1', 'av2': 'bv2'}, 'per_host': '', 'aggregate': 'true'}
                self.action = 'set_stats'
                self.name = 'set_stats'
        return MockTask()
    def mock_task_vars():
        return {}
    action_module = ActionModule(mock_task_class(), mock_task_vars())
    print(action_module.run())

# Generated at 2022-06-11 12:31:34.512651
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True # TODO: implement your test here


# Generated at 2022-06-11 12:31:44.596817
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import ansible.utils.template as template
    import ansible.template
    import jinja2
    from ansible.plugins.action.set_stats import ActionModule

    # no data passed
    task_args = {}
    tmp = None
    tm = template.Template(None)
    templar = ansible.template.Templar(loader=None, variables=None)
    templar._available_variables = dict()
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=tm, shared_loader_obj=None)

    fake_result = {'changed': False, 'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}}
    result = module.run(tmp, {})
    assert result == fake

# Generated at 2022-06-11 12:31:47.532103
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None)
    assert am._VALID_ARGS == ('aggregate', 'data', 'per_host')
    assert am.TRANSFERS_FILES == False

# Generated at 2022-06-11 12:31:57.103142
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.errors import AnsibleParserError
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.template import Templar
    import sys
    import pytest
    from ansible.vars.manager import VariableManager

    class MockPlayContext(PlayContext):

        def __init__(self):
            self.become = False
            self.become_pass = None

    class MockTask(Task):

        def __init__(self, args):
            self.args = args

    class MockPlaybookModule(object):

        class tqm(object):

            class _failed_hosts(object):
                hosts = []

    class MockTemplar(Templar):

        def __init__(self):
            pass


# Generated at 2022-06-11 12:32:08.185551
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    _task = dict(
        args = dict(
            data = dict(
                num_tasks_ok = 1
            )
        )
    )
    task_vars = dict(
        _ansible_get_socket_path=True,
        connection='local',
        path_info='/'
    )
    am = ActionModule(is_module=True, _task=_task, _connection=None, _play_context=None, loader=None, templar=None, shared_loader_obj=None)
    res = am.run(task_vars=task_vars)
    assert res['ansible_stats'] == {'aggregate': True, 'per_host': False, 'data': {'num_tasks_ok': '1'}}
    assert not res['changed']
    assert 'msg'

# Generated at 2022-06-11 12:32:18.267009
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_args = {'data': {'var1': 7, 'var2': 'value'}, 'per_host': False, 'aggregate': True}
    task = {'args': task_args}

    tmp = None
    task_vars = {'var1': 7}

    action_mod = ActionModule(task, tmp, task_vars)
    res = action_mod.run(tmp, task_vars)

    assert res['ansible_stats']['data']['var1'] == 7
    assert res['ansible_stats']['data']['var2'] == 'value'
    assert res['ansible_stats']['per_host'] is False
    assert res['ansible_stats']['aggregate'] is True



# Generated at 2022-06-11 12:32:18.834024
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-11 12:32:47.928438
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from collections import namedtuple
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import add_all_plugin_dirs

    from ansible.template import Templar

    FakeLoader = namedtuple('FakeLoader', ['get_basedir'])
    FakeTask = namedtuple('FakeTask', ['args'])

    class FakeVarsModule:
        def __init__(self):
            self.vars = {}

        def __call__(self, *args, **kwargs):
            self.vars = combine_vars(self.vars, kwargs)

    fake_loader = FakeLoader(get_basedir=lambda: 'foo/bar/baz')
    fake_task = FakeTask(args={'data': {'somevalidname': 'somevalue'}})
    fake

# Generated at 2022-06-11 12:32:52.560645
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am.run() == {'changed': False}
    assert am.run(task_vars={'ansible_version': {'full': '1.2.3.4'}}) == {'changed': False, 'ansible_version': {'full': '1.2.3.4'}}

# Generated at 2022-06-11 12:32:53.115994
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-11 12:33:02.475487
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    import ansible.modules.system.uptime
    import ansible.modules.system.set_stats
    test_module = ansible.modules.system.set_stats.ActionModule(AnsibleModule(
        argument_spec=ansible.modules.system.set_stats.ActionModule.argument_spec
    ))
    test_module._ansible_verbosity = 10
    result = test_module.run(task_vars={})
    assert result['ansible_stats']['data'] == {}
    assert result['ansible_stats']['per_host'] == False
    assert result['ansible_stats']['aggregate'] == True


# Generated at 2022-06-11 12:33:09.766669
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.parsing.convert_bool import boolean
    import tempfile

    from ansible.plugins.loader import action_loader
    from ansible.vars.hostvars import HostVars

    # Arrange
    loader = action_loader.ActionModuleLoader(
        ImmutableDict({"CONFIG_FILE": os.path.join(tempfile.gettempdir(), "ansible.cfg"), "DEFAULT_MODULE_PATH": tempfile.gettempdir()}),
        HostVars(dict()),
        'fake_playbook_path')


# Generated at 2022-06-11 12:33:12.282313
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    unit test class constructor of action module
    '''
    action = ActionModule(None, None, None, None, None)
    assert isinstance(action, ActionModule)



# Generated at 2022-06-11 12:33:13.774289
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    print(action_module.run())

# Generated at 2022-06-11 12:33:14.991436
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Unit test for constructor of class ActionModule
    """
    assert(True)

# Generated at 2022-06-11 12:33:18.344255
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))
    assert am.TRANSFERS_FILES == False


# Generated at 2022-06-11 12:33:27.445548
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Test the run method of ActionModule class
    """
    class _DS:
        def __init__(self, **kwargs):
            self.module_name = "set_stats.py"
            for (k,v) in iteritems(kwargs):
                setattr(self, k, v)

    class _DEM:
        def __init__(self, **kwargs):
            for (k,v) in iteritems(kwargs):
                setattr(self, k, v)

    class _DT:
        def __init__(self, **kwargs):
            for (k,v) in iteritems(kwargs):
                setattr(self, k, v)


# Generated at 2022-06-11 12:34:08.914869
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None) is not None

# Generated at 2022-06-11 12:34:19.220368
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    # create dummy module object
    module = AnsibleModule(argument_spec={})
    mock_ansible_module = type("AnsibleModule", (object,), dict(params=dict(),
                               check_mode=False,
                               no_log=False,
                               fail_json=module.fail_json,
                               exit_json=module.exit_json))

    # create dummy class object of action plugin
    mock_action_base = type("ActionBase", (object,), dict(task_vars={},
                          loader=dict(basedir='.'),
                          _shared_loader_obj=None,
                          _templar=mock_ansible_module))

    mock_this

# Generated at 2022-06-11 12:34:27.242518
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    def test_params(module_name):

        def fake_load_file_common_arguments(templar, task_ds, wrap_async=False, post_validate_file=True):
            return task_ds

        task_vars = dict(
            ansible_inventory_sources=['/etc/ansible/hosts'],
            ansible_inventory_hostname_short='localhost',
            ansible_facts=dict(),
            ansible_playbook_python=False,
        )

        def fake_tmpl(*args, **kwargs):
            return args[0]

        # Remove ActionModule class to free the namespace
        del ActionModule
        from ansible.plugins.action import ActionModule
        # After ActionModule class is removed, we should also remove ActionBase on which it is subclassed
        del ActionBase


# Generated at 2022-06-11 12:34:36.360032
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Test ActionModule.run() with all the valid args
    for key in iteritems(ActionModule._VALID_ARGS):
        assert isinstance(key, string_types)
        # Test invalid type of key
        assert not isinstance(key, int)
        assert isidentifier(key)
        # Test invalid type of value
        assert not isinstance(key, int)
    assert isinstance(ActionModule._VALID_ARGS, frozenset)
    # Test invalid type of VALID_ARGS
    assert not isinstance(ActionModule._VALID_ARGS, dict)
    # Test if test_ActionModule.run() is the subclass of ActionBase
    assert issubclass(ActionModule, ActionBase)
    # Test invalid type of ActionBase
    assert not issubclass(ActionModule, dict)

# Generated at 2022-06-11 12:34:46.244879
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule('test')

    result = module.run()
    assert not result['failed']
    # TODO:
    #assert not result['changed']
    #assert result['ansible_stats'] == {
    #    'data': {},
    #    'per_host': False,
    #    'aggregate': True,
    #}

    result = module.run(task_vars=dict(myvar='foo'))
    assert not result['failed']
    #assert not result['changed']
    #assert result['ansible_stats'] == {
    #    'data': {},
    #    'per_host': False,
    #    'aggregate': True,
    #}


# Generated at 2022-06-11 12:34:53.932659
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_params = dict()
    task_args = dict()

    module = ActionModule(task=task_params, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert(isinstance(module, ActionModule))

    stats = module.run(tmp=None, task_vars=task_args)

    assert(isinstance(stats['ansible_stats'], dict))
    assert(isinstance(stats['ansible_stats']['data'], dict))
    assert(stats['ansible_stats']['per_host'] == False)
    assert(stats['ansible_stats']['aggregate'] == True)


# Unit Test for ActionModule Embedded Action

# Generated at 2022-06-11 12:34:57.174188
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )


# Generated at 2022-06-11 12:35:00.819582
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, None, None, None, None, None, None)
    assert am.TRANSFERS_FILES is False
    assert am._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-11 12:35:02.707865
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    assert action_module.run(None, None)
    assert action_module.run(None, {})

# Generated at 2022-06-11 12:35:08.729234
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Unit test class ActionModule."""
    # Create task object and set args
    task = ActionModule()
    task.args = {'data': {'key1': 'value1', 'key2': 'value2'}, 'per_host': True}

    # Get result of run method
    result = task.run()
    # Check result
    assert result['changed'] is False
    assert result['ansible_stats'] == {'data': {'key1': 'value1', 'key2': 'value2'},
                                       'per_host': True, 'aggregate': True}

# Generated at 2022-06-11 12:37:06.171227
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert 'data' in ActionModule._VALID_ARGS
    assert 'per_host' in ActionModule._VALID_ARGS
    assert 'aggregate' in ActionModule._VALID_ARGS
    assert 'any_other_arg' not in ActionModule._VALID_ARGS
    assert ActionModule.TRANSFERS_FILES == False
    instance = ActionModule(None, None, None)
    assert 'data' in instance._VALID_ARGS
    assert 'per_host' in instance._VALID_ARGS
    assert 'aggregate' in instance._VALID_ARGS
    assert 'any_other_arg' not in instance._VALID_ARGS
    assert instance.TRANSFERS_FILES == False


# Generated at 2022-06-11 12:37:06.680040
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-11 12:37:14.325653
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.core.action_set_stats
    import ansible.playbook.task
    import ansible.utils
    from ansible.utils.vars import combine_vars

    ast = ansible.plugins.core.action_set_stats.ActionModule
    at = ansible.playbook.task.Task()
    at._task = dict(
        action=dict(
            __ansible_module__='set_stats',
        ),
    )
    at._connection = ansible.playbook.conditional.Conditional(
        playbook=ansible.playbook.base.Base(),
        loader=ansible.parsing.dataloader.DataLoader(),
    )

    at._tqm = None
    at._loader = ansible.parsing.dataloader.DataLoader()
    at

# Generated at 2022-06-11 12:37:21.481785
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Test ActionBase constructor
    :return: True
    """
    module_mock = type("ansible.module_utils.basic.AnsibleModule")()
    class_mock = type("ansible.parsing.yaml.objects.AnsibleUnicode")()
    templar_mock = type("ansible.template.AnsibleTemplar")(class_mock)
    args_mock = type("ansible.vars.unsafe_proxy.AnsibleUnsafeText")()
    class_instance = ActionModule(module_mock, templar_mock, args_mock)
    assert class_instance is not None

# Generated at 2022-06-11 12:37:23.379836
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action

# Generated at 2022-06-11 12:37:24.131436
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule is not None


# Generated at 2022-06-11 12:37:25.549512
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: implement unit test(s) for ActionModule.run method
    raise Exception("not implemented")

# Generated at 2022-06-11 12:37:32.791140
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''unit tests for constructor of action plugin
    '''

# Generated at 2022-06-11 12:37:40.119408
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action_module = ActionModule()
    loader_mock = {}
    runner_mock = {}
    task_vars = {}
    task_values = { 'action': {'__ansible_argspec': {}}, '_ansible_module_name': 'DummyClass' }
    task_mock = { 'async': 0, 'args': 'task_args', 'delegate_to': '127.0.0.1', 'delegate_facts': False, 'environment': '{}', 'name': 'Test task', 'tags': 'tags_here'}
    action_module.setup(loader_mock, runner_mock, task_values, task_mock)
    result = action_module.run(None, task_vars)


# Generated at 2022-06-11 12:37:46.959441
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.set_stats import ActionModule
    x = ActionModule(
        task=dict(args={'data': {'potato': 'mashed'}, 'per_host': True, 'aggregate': False}),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)
    assert isinstance(x._task.args, dict)
    assert isinstance(x._task.args['data'], dict)
    assert isinstance(x._task.args['per_host'], bool)
    assert isinstance(x._task.args['aggregate'], bool)

