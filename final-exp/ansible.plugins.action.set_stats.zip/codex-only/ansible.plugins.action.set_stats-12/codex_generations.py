

# Generated at 2022-06-23 08:39:36.796609
# Unit test for constructor of class ActionModule
def test_ActionModule():
    tk = dict(
        ANSIBLE_MODULE_ARGS=dict(
            data=dict(
                one=1,
                two=dict(
                    three=3
                ),
                four=4
            )
        )
    )
    task = dict(
        action=dict(
            module='set_stats'
        ),
        args=dict(
            data=dict(
                one=1,
                two=dict(
                    three=3
                ),
                four=4
            )
        )
    )
    am = ActionModule(task, tk, {})

    result = am.run()
    assert result['ansible_stats']['per_host'] == False
    assert result['ansible_stats']['data']['one'] == 1

# Generated at 2022-06-23 08:39:42.125939
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    This is a unit test for method run of class ActionModule
    The goal of this test will be to make sure that the methods
    called from run are called with correct parameters or
    that run returns correct results
    Below are the individual tests
    """

    # Mock of the class object
    mockObject = type('mockObject', (object,), {})()

    # Mock of the super class
    mockSuper = type('mockSuper', (object,), {'run': lambda self, tmp=None, task_vars=None: task_vars})

    # Creating the class we would like to test
    class ObjectToTest(mockSuper):
        # Defining the class
        def __init__(self):
            mockSuper.__init__(self)
            self.TRANSFERS_FILES = False

        # Method being tested

# Generated at 2022-06-23 08:39:52.047062
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from units.mock.loader import DictDataLoader

    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager

    from ansible.plugins.action.set_stats import ActionModule

    templar = DictDataLoader()
    variable_manager = VariableManager()
    inventory = None
    loader = None
    play_context = PlayContext(loader=loader, variable_manager=variable_manager, inventory=inventory)

    # mock different ``task_vars`` value, default should be empty dict
    task_vars = {'test_key': 'test_value'}

    action_name = 'set_stats'

# Generated at 2022-06-23 08:40:01.714461
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create instance of class ActionModule
    module = ActionModule()

    # create instance of class AnsibleModule
    class AnsibleModule:
        pass

    class AnsibleModule_fail_json:
        def __call__(self, *args, **kwargs):
            if 'msg' in kwargs:
                raise Exception(kwargs['msg'])
            raise Exception(args[0])

    m = AnsibleModule()
    m.fail_json = AnsibleModule_fail_json()

    class Task:
        def __init__(self):
            self.args = {'aggregate': True}

    # Set it as a parameter for ActionModule
    module._task = Task()

    class Connection:
        def __init__(self):
            self.host = 'foo'

    module._connection = Connection()


# Generated at 2022-06-23 08:40:09.181075
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Instantiate instance of ActionModule class
    act_mod = ActionModule(
            task = dict(data = dict(),args = dict(data = dict(key = "val"))),
            connection = None,
            play_context = dict(become=True,become_method='sudo',become_user='root'),
            loader=dict(),
            templar=dict(),
            shared_loader_obj=None
    )
    # run method of class ActionModule should return dict
    assert isinstance(act_mod.run(), dict)

# Generated at 2022-06-23 08:40:11.469957
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am is not None

# Generated at 2022-06-23 08:40:20.062585
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(None, None)
    action.setup_task_vars('', '', {}, {}, {})
    action.setup_play_context()

    # Test case #1:
    # When both per_host and aggregate is False
    # The module should return status OK as both the
    # options can't be set to False at the same time
    # for ansible-playbook to work
    #
    # m_args = {'data': {'ansible_stats_test': 'ansible_stats_test'},
    #           'per_host': False,
    #           'aggregate': False}
    #
    # result = action.run(m_args)
    #
    # assert 'ansible_stats' in result.keys()
    # assert 'data' in result['ansible_stats']

# Generated at 2022-06-23 08:40:29.508379
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule_instance = ActionModule()
    # Test with a string value for data option
    args = { "data": "test string" }
    assert ActionModule_instance.run(task_vars=dict(), args=args)["failed"] == True

    # Test with an empty dictionary for data option
    args = { "data": {} }
    assert ActionModule_instance.run(task_vars=dict(), args=args)["failed"] == False

    # Test with a dictionary for data option
    args = { "data": { "key1": "value1", "key2": "value2" } }
    result = ActionModule_instance.run(task_vars=dict(), args=args)
    assert ActionModule_instance.run(task_vars=dict(), args=args)["failed"] == False

# Generated at 2022-06-23 08:40:39.601300
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import context
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    import pytest

    # collect return of method run
    class get_run:
        def __init__(self, result, tmp=None, task_vars=None):
            self._task = Task()
            self._task.args = {'data': {
                                'test': '{{ test }}'
                              },
                              'aggregate': '{{ aggregate }}',
                              'per_host': '{{ per_host }}'}
            self._task.action = 'set_stats'
            self._task.delegate_to = '{{ delegate_to }}'
            self._task._ansible_action_set_stats = 'set_stats'

# Generated at 2022-06-23 08:40:40.544926
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionModule)

# Generated at 2022-06-23 08:40:44.430952
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert type(action_module.run) == type(ActionModule.run)
    assert type(action_module._VALID_ARGS) == frozenset

# Generated at 2022-06-23 08:40:45.003747
# Unit test for constructor of class ActionModule
def test_ActionModule():

    assert True

# Generated at 2022-06-23 08:40:55.110335
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # set up task args
    task_args = {
        'data': {'test': '{{ test }}', 'test2': 'test2'},
        'per_host': '{{ per_host }}',
        'aggregate': '{{ aggregate }}',
    }
    # set up task vars
    task_vars = {
        'test': 'test',
        'per_host': 'true',
        'aggregate': 'false'
    }

    # set up expected return values
    expected_result = {
        'changed': False,
        'ansible_stats': {
            'data': {
                'test': 'test',
                'test2': 'test2'
            },
            'per_host': True,
            'aggregate': False
        }
    }
    # create ActionModule object
   

# Generated at 2022-06-23 08:41:04.885326
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # First test
    module = ActionModule()
    module._task = {}
    module._task.args = {'data': {'a': 2, 'b': 4}}
    module._task.action = 'set_stats'
    module._templar = {'template': lambda x: x}
    result = module.run(None, None)
    assert module.run(None, None) == {'ansible_stats': {'data': {'a': 2, 'b': 4}, 'aggregate': True, 'per_host': False}, 'changed': False}
    assert module.run(None, None) != {'ansible_stats': {'data': {'c': 2, 'd': 4}, 'aggregate': True, 'per_host': False}, 'changed': False}

# Generated at 2022-06-23 08:41:16.346581
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def fake_fail_json(self, msg, **kwargs):
        raise AssertionError(msg)
    def fake__templar(self, msg):
        return msg
        
    def _get_task():
        task = dict()
        task['args'] = dict()
        task['_attributes'] = dict()
        return task
    
    class _ActionModule(ActionModule):
        _templar = fake__templar
        def fail_json(self, *args, **kwargs):
            return fake_fail_json(self, *args, **kwargs)

    def _get_result_json(data=None, per_host=None, aggregate=True, **kwargs):
        result = dict()
        result['ansible_stats'] = dict()
        result['changed'] = False

# Generated at 2022-06-23 08:41:21.531002
# Unit test for constructor of class ActionModule
def test_ActionModule():
   class _ActionModule(ActionModule):
      VALID_ARGS = ActionModule._VALID_ARGS

   variables = dict()
   t = _ActionModule(task=dict(), connection=None, play_context=dict(), loader=None, templar=None, shared_loader_obj=None)
   assert(t.VALID_ARGS == ActionModule._VALID_ARGS)

# Generated at 2022-06-23 08:41:32.051541
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(task=dict(action=dict(module_args=dict())))
    action._templar = dict()

    assert action.run() == dict(changed=False, ansible_stats=dict(data={}, per_host=False, aggregate=True))
    # Make sure that it does not fail with empty dict
    assert action.run(
        task_vars=dict(
            ansible_stats=dict(
                data=dict(),
                per_host=False,
                aggregate=True
            )
        )
    )
    assert action.run(
        task_vars=dict(
            ansible_stats=dict(
                data=dict(
                    foo=1,
                    bar=2
                ),
                per_host=False,
                aggregate=True
            )
        )
    )



# Generated at 2022-06-23 08:41:43.138463
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Unit test method for ActionModule class constructor
    """
    from ansible.module_utils._text import to_native
    from ansible.module_utils.basic import AnsibleModule
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.plugins.loader import get_all_plugin_loaders

    # Create the action plugin
    action = ActionModule(
        task=Task(),
        connection=None,
        play_context=PlayContext(),
        loader=get_all_plugin_loaders()['action'],
        templar=None,
        shared_loader_obj=None)

    # Create the AnsibleModule object

# Generated at 2022-06-23 08:41:50.995415
# Unit test for constructor of class ActionModule
def test_ActionModule():
    conn = object()

    action = ActionModule(conn, '/path/to/nowhere', './test-templates', True, False, 10, False)
    assert action._connection == conn
    assert action._loader._basedir == '/path/to/nowhere'
    assert action._templar._basedir == './test-templates'
    assert action._shared_loader_obj._basedir == '/path/to/nowhere'
    assert action.add_host == True
    assert action._role_name == False
    assert action._task_vars == 10
    assert action._loader._disable_template is False
    assert action._only_if == False
    assert action._not_if == False



# Generated at 2022-06-23 08:41:58.949140
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.executor.task_result import TaskResult
    from ansible.template import Templar
    import ansible.utils.vars

    class FakeArgsCollection:
        def __init__(self, cmd):
            self.cmd = cmd

    class FakeTask:
        def __init__(self, tmp, args):
            self.tmp = tmp
            self.args = args

    class FakeExecutor:
        def __init__(self):
            self.task_vars = {}

    class FakeTemplar:
        def __init__(self):
            self.convert_bare = False
            self.fail_on_undefined = True

        def template(self, cmd, convert_bare=False, fail_on_undefined=True):
            return cmd

    task

# Generated at 2022-06-23 08:42:06.744635
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json

    # Template to be instantiated
    template = """
    {
        "aggregate": true,
        "data": {
            "k1": "v1",
            "k2": "v{{ 2 }}"
        }
    }
    """

    # instantiated template
    template_data = json.loads(template)

    # Set parameters that to be tested for run method
    task_args = template_data
    task_vars = {}

    # create a new instance of the module
    my_module = ActionModule()

    # Simulate AnsibleModule._load_params() to load the parameters passed to the module
    for argument, value in task_args.items():
        if argument not in my_module.no_log_values:
            value = 'VALUE IS OMITTED DUE TO NO_LOG'

       

# Generated at 2022-06-23 08:42:07.587421
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule._VALID_ARGS

# Generated at 2022-06-23 08:42:16.337155
# Unit test for constructor of class ActionModule
def test_ActionModule():

    from ansible.playbook.task import Task

    module_args = dict(
        data=dict(
            test_stat1=123,
            test_stat2=456,
            test_stat3=True,
            test_stat4="test",
            test_stat5=dict(
                subkey1="subvalue1",
                subkey2="subvalue2",
            )
        ),
        aggregate=True,
        per_host=False,
    )

    task = Task()

    am = ActionModule(task, module_args)
    assert am.run(None, None)

# Generated at 2022-06-23 08:42:20.870874
# Unit test for constructor of class ActionModule
def test_ActionModule():

    the_templar = { 'template' : lambda x: x}
    the_task = { 'args' : {} }

    new_action = ActionModule(the_templar, the_task, {})

    assert new_action.__class__.__name__ == 'ActionModule'

# Generated at 2022-06-23 08:42:29.579388
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    A = ActionModule()

# Generated at 2022-06-23 08:42:38.535434
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import mock

    mock_task = mock.MagicMock()
    mock_task.args = {}
    mock_task.args['data'] = {'a':'b','c':'d','e':'f','g':'h'}
    mock_task.args['per_host'] = True
    mock_task.args['aggregate'] = False

    mock_loader = mock.MagicMock()
    mock_play_context = mock.MagicMock()

    mock_connection = mock.MagicMock()
    mock_connection.transport = "ssh"
    mock_connection.exec_command = mock.MagicMock()
    mock_connection.exec_command.return_value = "out", "error", 0

    mock_play_context.connection = "ssh"

# Generated at 2022-06-23 08:42:39.791515
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert(ActionModule.run(None, None) == 'a')

# Generated at 2022-06-23 08:42:48.549712
# Unit test for constructor of class ActionModule

# Generated at 2022-06-23 08:42:59.384422
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    fd = open('/tmp/run_Test', 'w')

    # replacement for module_utils function
    def get_vars(loader, path, entities):
        fake_vars = {'fact1': 'fake_value_fact1',
                     'fact2': 'fake_value_fact2'
                     }
        vars_ret= []
        for entity in entities:
            if entity in fake_vars.keys():
                vars_ret.append(fake_vars[entity])
        return vars_ret

    fake_vars = {'fact1': 'fake_value_fact1',
                 'fact2': 'fake_value_fact2',
                 'fact3': 'fake_value_fact3',
                 'fact4': 'fake_value_fact4'
                 }
    fake_loader = None


# Generated at 2022-06-23 08:43:00.401420
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-23 08:43:12.111300
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module = ActionModule()
    action_module._task = "something"
    action_module._loader = "something_else"
    action_module._templar = "another_thing"
    action_module._connection = "And connection"

    assert action_module.run() == {'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}, 'changed': False}
    assert 'ansible_stats' in action_module.run()
    assert 'changed' in action_module.run()
    assert action_module.run()['ansible_stats']['data'] == {}
    assert action_module.run()['ansible_stats']['per_host'] == False
    assert action_module.run()['ansible_stats']['aggregate'] == True
    assert action

# Generated at 2022-06-23 08:43:23.215935
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    adict = {'data': dict()}
    atup = ('var', 'val')
    atuple = ('var', 'val')
    amap = {'data': dict()}
    alist = [('var', 'val')]
    strlist = 'var1:val1'
    strlist2 = 'var1:val1,var2:val2,var3:val3'
    strlist3 = 'var1:val1, var2:val2, var3:val3'
    strlist4 = 'var1:val1 var2:val2 var3:val3'
    strlist5 = 'var1:val1, var2:val2, var3:val3 '
    data = dict()
    data['dict'] = adict
    data['tup'] = atup

# Generated at 2022-06-23 08:43:28.402032
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action.set_stats as my_module
    module_obj = my_module.ActionModule(None, None, None, None, None)
    assert module_obj._task.args == {}
    assert module_obj._task.args is not None
    assert not module_obj.run(tmp=None, task_vars=None)

# Generated at 2022-06-23 08:43:29.614449
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(), ActionModule)

# Generated at 2022-06-23 08:43:40.811838
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    hostname = 'localhost'
    task_vars = dict()
    tmp = None
    args = {'data': {'key': 'value'}, 'per_host': False, 'aggregate': False}
    module = ActionModule(task=None, connection=None, _play_context=None, loader=None, templar=None, shared_loader_obj=None)
    res = module._execute_module(host_list=[hostname], module_name='set_stats', module_args=args, task_vars=task_vars)
    assert type(res) is dict
    assert 'data' in res['ansible_stats']
    assert 'key' in res['ansible_stats']['data']
    assert 'value' in res['ansible_stats']['data'].values()

# Generated at 2022-06-23 08:43:52.615131
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule

    # Test each possible types returned
    for data_value in [1337, 3.14, 'string', True, False]:
        for per_host_value in [True, False]:
            for aggregate_value in [True, False]:
                # set data, per_host and aggregate values in a dictionary
                test_args = {'data': data_value, 'per_host': per_host_value, 'aggregate': aggregate_value}

                # set ActionModule class instance
                test_ActionModule = ActionModule(dict(ANSIBLE_MODULE_ARGS=test_args), dict())

                # extract result of method run
                test_result = test_ActionModule.run(tmp=None, task_vars=None)
                
                assert test_result['changed'] == False


# Generated at 2022-06-23 08:43:55.329725
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(load_module='', task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(a, ActionModule)

# Generated at 2022-06-23 08:44:06.485405
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class ActionModule_run_Test(ActionModule):
        def _execute_module(self, tmp=None, task_vars=None, persist_files=False, delete_remote_tmp=True):
            return {'ansible_stats': self.run(tmp, task_vars)}

    test_obj = ActionModule_run_Test({}, {})
    test_task = {
        'action': 'set_stats', 'args': {'data': {'a': 1, 'b': 2, 'c': 3}},
    }

    res = test_obj._execute_module(task_vars={'ansible_facts': {}},
                                   persist_files=True,
                                   delete_remote_tmp=True,
                                   task_vars={'test_task': test_task})

# Generated at 2022-06-23 08:44:16.471254
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    import ansible.plugins.action.set_stats

    try:
        tmp = os.path.realpath(os.path.join(os.path.dirname(os.path.realpath(__file__)), '..', '..', '..', '..', '..', '..', 'lib', 'ansible', 'plugins', 'action', 'set_facts.py'))
    except NameError:
        tmp = os.path.realpath(os.path.join(os.path.dirname(os.path.realpath(__file__)), '..', '..', '..', '..', '..', '..', 'lib', 'ansible', 'plugins', 'action', 'set_facts.py'))
    test_file = open(tmp, 'r')
    test_file_contents = test_file

# Generated at 2022-06-23 08:44:25.834174
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 08:44:28.603961
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(ActionModule.able, ActionModule._templar, ActionModule._loader, ActionModule._shared_loader_obj, ActionModule._task)
    assert am.TRANSFERS_FILES == False
    assert am.run(task_vars=None) is None

# Generated at 2022-06-23 08:44:31.859082
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task={}, connection={}, play_context={}, loader={}, templar={}, shared_loader_obj={})
    # private method so call it directly
    assert action._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))


# Generated at 2022-06-23 08:44:37.197429
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Tests for method run of class ActionModule
    """
    instance = ActionModule()
    assert(instance.run() is not None)

# Generated at 2022-06-23 08:44:38.676940
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule('setup', {})
    assert actionModule._connection

# Generated at 2022-06-23 08:44:40.022510
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:44:44.464548
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Constructor test
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module

# Generated at 2022-06-23 08:44:52.557759
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import action_loader
    from ansible.errors import AnsibleUndefinedVariable
    from ansible.template.template import Templar


    play_context = PlayContext(play=dict(name='play_1'))
    variable_manager = VariableManager()
    variable_manager.set_inventory(variable_manager.loader.inventory)
    variable_manager.set_play_context(play_context)

    action_plugin = action_loader.get('set_stats', play_context)
    action_plugin._templar = Templar(loader=None, variables=variable_manager)

    # test basic data

# Generated at 2022-06-23 08:45:02.002486
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    import shutil
    import tempfile

    td = tempfile.mkdtemp()

    sys.path.append(td)

    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars_vars import HostVarsVars
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-23 08:45:08.748049
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_bytes
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager

    from collections import namedtuple
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    loader = DataLoader()
    Options

# Generated at 2022-06-23 08:45:12.556341
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    tmp = None
    task_vars = dict()
    result = module.run(tmp, task_vars)
    print(result)

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-23 08:45:25.296212
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test normal functionality
    a = ActionModule({'module_args': {'data': {'test_stats1': 1, 'test_stats2': 2}, 'per_host': True, 'aggregate': False}})
    result = a.run()
    assert result['changed'] == False
    assert result['ansible_stats']['data']['test_stats1'] == 1
    assert result['ansible_stats']['data']['test_stats2'] == 2
    assert result['ansible_stats']['per_host'] == True
    assert result['ansible_stats']['aggregate'] == False

    # test dict with templating

# Generated at 2022-06-23 08:45:31.908976
# Unit test for constructor of class ActionModule
def test_ActionModule():
    cls = ActionModule(
        task=dict(),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict())
    assert cls._task == dict()
    assert cls._connection == dict()
    assert cls._play_context == dict()
    assert cls._loader == dict()
    assert cls._templar == dict()
    assert cls._shared_loader_obj == dict()
    assert not cls._supports_check_mode
    assert not cls._supports_async
    assert not cls._supports_async_timeout


# Generated at 2022-06-23 08:45:44.010353
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule"""

    from ansible.module_utils.basic import AnsibleModule

    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.parsing.convert_bool import boolean

    from ansible.inventory.host import Host
    from ansible.playbook.task import Task
    from ansible.plugins.action import ActionBase
    from ansible.playbook.play_context import PlayContext

    from ansible.plugins import action_loader
    from ansible.vars.manager import VariableManager

    import sys
    import tempfile

    try:
        from __main__ import display
    except ImportError:
        display = None

    # generate tempfile and set stdout, stderr

# Generated at 2022-06-23 08:45:47.156805
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.modules.system.set_stats
    action = ansible.modules.system.set_stats.ActionModule(None, dict(), dict())
    assert action is not None

# Generated at 2022-06-23 08:45:51.442657
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule"""
    # input parameters
    tmp = None
    task_vars = None

    # test object
    obj = ActionModule(tmp, task_vars)

    # execute run() method
    result = obj.run()

    # expected result
    expected_result = {'failed': False, 'changed': False}

    # comparision of expected result and actual result
    assert result == expected_result

# Generated at 2022-06-23 08:45:58.589547
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_var = {
        'per_host': False,
        'aggregate': True,
        'data': {'my_var': '{{ my_var }}'}
    }

    my_var = {
        'hostvars': {
            'host1.example.com': {
                'my_var': '{{ my_var }}'
            }
        }
    }

    task = {
        'args': action_var,
        'action': 'set_stats',
        'args': action_var
    }


# Generated at 2022-06-23 08:45:59.329494
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-23 08:46:01.314447
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = ActionModule({"test": "test"})
    assert result is not None

# Generated at 2022-06-23 08:46:10.497230
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Import modules needed by this test
    import tempfile
    import shutil
    import sys
    import os
    import json
    import inspect

    # TODO: Add Python 3 support
    if os.name != 'nt':
        try:
            # Python 3
            from imp import reload_module
        except ImportError:
            # Python 2
            from imp import reload as reload_module
    else:
        # Python 2
        from imp import reload as reload_module

    # Get the path to the current module
    cur_path = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))

    # Import Ansible module_utils used by this test
    sys.path.append(os.path.join(cur_path, '../../../module_utils/'))

# Generated at 2022-06-23 08:46:20.178587
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule(task=dict(args=dict()), connection=dict(host=None))
    m.data = {}
    m.task_vars = dict()
    m._task = dict(args=dict())
    m._task_vars = dict()
    m._templar = dict()
    m.noop_on_check(False)
    m._low_level_execute_command(None)
    m.async_val = None
    m.async_seconds = 0
    m.become = None
    m.become_method = None
    m.become_user = None
    m.check_mode = False
    m.cleanup()
    m.connection = 'smart'
    m.noop_check(False)
    m.connection_info = dict(host=None)

# Generated at 2022-06-23 08:46:25.485762
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Tests for constructor of class ActionModule """
    obj = ActionModule(None, None, None, None)
    assert obj._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))
    assert obj.TRANSFERS_FILES is False

# Generated at 2022-06-23 08:46:34.756092
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {}
    sentinel = object()

    def _action_base_run(tmp, task_vars):
        assert task_vars is sentinel
        return dict(changed=False)

    def _jinja2_template(template, convert_bare=False, fail_on_undefined=True):
        assert convert_bare is False
        assert fail_on_undefined is True
        if template == 'True':
            return True
        elif template == 'False':
            return False
        return template

    def _boolean(value, strict=False):
        assert strict is False
        return {'true': True, 'True': True, 'TRUE': True,
                'false': False, 'False': False, 'FALSE': False}[value]

    action_module = ActionModule()
    action_module

# Generated at 2022-06-23 08:46:35.684550
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()


# Generated at 2022-06-23 08:46:36.370306
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:46:39.845997
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)

# Generated at 2022-06-23 08:46:41.042864
# Unit test for constructor of class ActionModule
def test_ActionModule():
    t = ActionModule()
    assert t is not None

# Generated at 2022-06-23 08:46:45.935460
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = {}
    _action = ActionModule()
    _action.run(None, result)
    assert (result['ansible_stats']['data'] == {})
    assert (result['ansible_stats']['per_host'] == False)
    assert (result['ansible_stats']['aggregate'] == True)

# Generated at 2022-06-23 08:46:53.223733
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # fixture: action module arguments
    action_module_args = dict(
        data = dict(
            ansible_facts = dict(
                ansible_processor = dict(
                    devices = dict(
                        count = 1,
                        list = ['Intel(R) Core(TM) i7-4810MQ CPU @ 2.80GHz']
                    )
                )
            )
        ),
        aggregate = True,
        per_host = False,
        ansible_host = "localhost"
    )

    from ansible.module_utils.facts.system.processor import Processor
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.platform import Platform
    from ansible.module_utils.facts.hardware.dmi import DMI

# Generated at 2022-06-23 08:47:02.244575
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(task={'action': 'set_stats', 'args': {'data': {'var1': 'val1', 'var2': 'val2'}, 'per_host': False, 'aggregate': True}}, setup_cache=None, runner_cache=None, connection_cache=None, loader=None, templar=None, shared_loader_obj=None)
    assert(module._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host')))
    assert(module.TRANSFERS_FILES == False)

# Generated at 2022-06-23 08:47:03.386457
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-23 08:47:12.185520
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # This test is written at time when ActionModule has no module (no set_stats.py).
    # We need to check the constructor behaviour alone.
    a = ActionModule()

    assert a.TRANSFERS_FILES == False
    assert isinstance(a._VALID_ARGS, frozenset)
    assert len(a._VALID_ARGS) == 3

    assert isinstance(a._task, dict)
    assert len(a._task) == 0

    assert a._connection is None

    assert isinstance(a._play_context, dict)
    assert len(a._play_context) == 0

    assert a._loader is None

    assert a._templar is None

    assert a._shared_loader_obj is None

    assert a._task_vars is None

    assert a._tmp is None

# Unit

# Generated at 2022-06-23 08:47:18.421857
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None)
    assert isinstance(action, ActionModule)
    assert action._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-23 08:47:20.280189
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not ActionModule(None, dict(), dict(), dict(), None).run()

# Generated at 2022-06-23 08:47:28.027239
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Define input parameters for method run
    task_action = dict(
        data=dict(
            a=1,
            b=2
        ),
        per_host=False,
        aggregate=True
    )

    task_vars = dict()

    # Define expected results of method run
    status_ok = dict(
        changed=False,
        ansible_stats=dict(
            data=dict(
                a=1,
                b=2
            ),
            per_host=False,
            aggregate=True
        )
    )

    task_args = dict()
    action = ActionModule(task_args, task_action, task_vars)
    p = action.run(None, task_vars)
    # Check if output of method run defined in class ActionModule is equal to expected results

# Generated at 2022-06-23 08:47:34.383182
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Make sure we have set the module_utils plugins path
    import sys
    sys.path.append("../")
    # Instantiate the class
    am = ActionModule()
    # Run the method
    try:
        am.run(task_vars=dict())
    except:
        raise AssertionError("ActionModule.run(task_vars=dict() returned a non expected result")

# Generated at 2022-06-23 08:47:36.787569
# Unit test for constructor of class ActionModule
def test_ActionModule():

    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert_true(module)

# Generated at 2022-06-23 08:47:43.230362
# Unit test for constructor of class ActionModule
def test_ActionModule():
    yaml_str = """
        - hosts: localhost
          tasks:
            - stats:
                data:
                    # absolute path to the directory containing the stats files
                    location: /var/lib/awx/stats/

                    # create a per host set of stats
                    per_host: true

                    # create an aggregate set of stats for all hosts
                    aggregate: true
                per_host: true
                aggregate: true
    """
    from ansible.plugins.task.stats import ActionModule
    from ansible.playbook.task import Task

    # initialize needed objects
    t = Task()
    t.action = 'stats'
    t.args = dict()
    setattr(t, '_role', dict())
    setattr(t._role, '_role_path', '/usr/share/ansible/roles/')
   

# Generated at 2022-06-23 08:47:52.079468
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    class A:
        pass

    # setup test data used in function
    x1 = A()
    x1.__dict__['_task'] = A()
    x1.__dict__['_task'].__dict__['args'] = {'data': 'test', 'per_host': True, 'aggregate': False}
    x1.__dict__['_templar'] = A()
    x1.__dict__['_templar'].__dict__['template'] = A()
    x1.__dict__['_templar'].__dict__['template'].return_value = {'test': 'value'}

    # perform the test
    result = x1.run(None, None)

    # verify test result

# Generated at 2022-06-23 08:47:57.291741
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.utils.vars import combine_vars
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    class FakeTask:
        def __init__(self):
            self.args = dict()

    class FakePlayContext:
        def __init__(self):
            self.become = False
            self.become_user = 'root'

    fake_task = FakeTask()
    fake_play_context = FakePlayContext()
    fake_loader = DataLoader()
    fake_inventory = InventoryManager(fake_loader, sources='')

    fake_variable_manager = fake_inventory.get_variable_manager()

    # test invalid data
    fake_task.args['data'] = "string"

# Generated at 2022-06-23 08:48:00.548136
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a.TRANSFERS_FILES == False
    assert isinstance(a._VALID_ARGS, frozenset)

# Generated at 2022-06-23 08:48:03.921733
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # result = {"changed": False, "ansible_stats": {"data": [{"total_count": 1,"ok_count": 1,"fail_count": 0,"skip_count": 0}]}}
    assert isinstance(ActionModule(), object)

# Generated at 2022-06-23 08:48:10.329360
# Unit test for constructor of class ActionModule
def test_ActionModule():

    module_args_dict = {}
    module_args_str = "\"\""
    action = ActionModule(None, module_args_dict)
    assert action._task.args == {"data": {}}

    action = ActionModule(None, module_args_str)
    assert action._task.args == {"data": {}}

# Generated at 2022-06-23 08:48:13.080701
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:48:19.106149
# Unit test for constructor of class ActionModule
def test_ActionModule():
    template = {
        'type': 'set_stats',
        'data': {'a': 'b'},
        'per_host': False,
        'aggregate': False,
    }
    action = ActionModule(None, template, '/some/path')
    assert action is not None
    assert action._VALID_ARGS == frozenset(['aggregate', 'data', 'per_host'])

# Generated at 2022-06-23 08:48:24.146682
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule()
    assert isinstance(m._VALID_ARGS, frozenset)
    assert m.TRANSFERS_FILES == False



# Generated at 2022-06-23 08:48:29.817075
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())
    ret = am.run()

    assert ret['ansible_stats']['aggregate'] is True
    assert ret['ansible_stats']['per_host'] is False
    assert ret['ansible_stats']['data'] == {}

# Generated at 2022-06-23 08:48:32.764852
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mock_task = type('', (), {})()
    mock_task.args = {'data': {'ansible_os_family': 'RedHat', 'ansible_python_version': '2.7.5', 'ansible_system': 'Linux'}, 'aggregate': True, 'per_host': False}
    action = ActionModule(mock_task, load_fragment_from_file=lambda x: "")
    action.get_bin_path = lambda x: x
    action.run(task_vars=mock_task.args)


# Generated at 2022-06-23 08:48:36.553220
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        assert ActionModule
    except NameError as e:
        raise



# Generated at 2022-06-23 08:48:46.285245
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.loader as plugin_loader

    # Retrieve the module's classname.
    modname = 'set_stats'
    classname = None
    for name, obj in iteritems(plugin_loader.all(class_only=True)):
        if name.strip() == modname:
            classname = obj
            break

    # Assert if the classname is not found.
    assert classname is not None

    # Create a dummy action plugin.

# Generated at 2022-06-23 08:48:50.440778
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module._VALID_ARGS == set(['per_host', 'data', 'aggregate'])
    assert module.TRANSFERS_FILES is False
    assert module.NO_TARGET is False
    assert module.BYPASS_HOST_LOOP is False
    assert module.RESULT_DEPRECATED_START is 0

# Generated at 2022-06-23 08:48:56.206472
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: create proper unit test for run method
    pass

# Generated at 2022-06-23 08:49:05.276480
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # TEST: if self._task.args is empty, we do not fail obviously
    action_module = ActionModule()
    action_module._task.args = {}
    result = action_module.run()
    assert(result['ansible_stats']['data'] == {})
    assert(result['ansible_stats']['aggregate'] == True)
    assert(result['ansible_stats']['per_host'] == False)

    # TEST: if data is not a dict we fail
    action_module = ActionModule()
    action_module._task.args = dict(data='this is not a dict')
    result = action_module.run()
    assert(result['failed'] == True)

    # TEST: if the data option is a dict, we do not fail obviously
    action_module = ActionModule()
    action_

# Generated at 2022-06-23 08:49:16.768155
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    myclass = ActionModule()

    # Inject valid values into the object created
    myclass._task.args = {'data': {'key1': 'val1'}}
    myclass.runner_cache = dict();
    myclass.runner_cache['test_run'] = dict()
    myclass.runner_cache['test_run']['hostvars'] = dict()
    myclass.runner_cache['test_run']['hostvars']['localhost'] = dict()
    myclass.runner_cache['test_run']['hostvars']['localhost']['ansible_connection'] = 'local'
    myclass.runner_cache['test_run']['hostvars']['localhost']['default_ipv4'] = dict()

# Generated at 2022-06-23 08:49:25.029074
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import ansible.plugins.action
    class MyActionModule(ansible.plugins.action.ActionModule):
        VALID_ARGS = frozenset(('aggregate', 'data', 'per_host'))
    class MyTask(object):
        def __init__(self, args):
            self.args = args
    test_args = {'per_host': True, 'data': {'fail_key': 'fail_val'}}
    test_task = MyTask(test_args)
    assert test_task.args['per_host'] is True

    test_module = MyActionModule(test_task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = test_module.run(tmp=None, task_vars=None)


# Generated at 2022-06-23 08:49:29.146011
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())