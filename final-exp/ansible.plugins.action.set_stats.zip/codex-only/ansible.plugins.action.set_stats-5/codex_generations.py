

# Generated at 2022-06-23 08:39:35.011375
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict())
    res = am.run(tmp='tmp', task_vars={'my_var': 'my_value'})
    assert 'ansible_stats' in res
    assert 'aggregate' in res['ansible_stats']
    assert 'per_host' in res['ansible_stats']
    assert 'data' in res['ansible_stats']


# Generated at 2022-06-23 08:39:37.898497
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(), dict())._task == dict()

# Generated at 2022-06-23 08:39:38.691775
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 08:39:42.990677
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.parsing.vault import VaultLib
    from ansible.playbook.task import Task
    from ansible.template import Templar

    task = Task()
    task._role = None

    module = ActionModule(task, {})
    assert isinstance(module._templar, Templar)
    assert isinstance(module._loader, VaultLib)

# Generated at 2022-06-23 08:39:44.302864
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: Unit testing for this module
    pass

# Generated at 2022-06-23 08:39:52.942721
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TestActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            if task_vars is None:
                task_vars = dict()
            tmp = None
            super(TestActionModule, self).run(None, task_vars)

    tam = TestActionModule(task=dict(args={}), connection=None, play_context=dict(basedir=''), loader=None, templar=None, shared_loader_obj=None)
    assert tam is not None
    assert isinstance(tam, ActionModule)
    assert tam.TRANSFERS_FILES is False
    assert isinstance(tam._VALID_ARGS, frozenset)
    assert len(tam._VALID_ARGS) == 3

# Generated at 2022-06-23 08:40:02.600452
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json
    from ansible.modules.system import set_stats as module
    from ansible.module_utils.basic import AnsibleModule
    from ansible.vars.hostvars import HostVars

    mod = module._AnsiballzFramework(AnsibleModule(argument_spec={}, supports_check_mode=True))
    mod.noop = True

    # dict returned from module run

# Generated at 2022-06-23 08:40:10.277349
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m_args = dict(data=dict(key1='value1', key2='value2'), aggregate=True)

    m_task_vars = dict(stat_dict=dict(key1='value1', key2='value2'))
    m_tmp = None

    m_result = dict(changed=False, ansible_stats=dict(data=m_task_vars['stat_dict']))

    a = ActionModule(m_args, m_task_vars, m_tmp)
    result = a.run()

    assert result == m_result

# Generated at 2022-06-23 08:40:18.932899
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # mock object to be used in the tests.
    class MockActionBase(ActionBase):
        def __init__(self):
            self.RESULT = {'failed': False, 'changed': False, 'ansible_stats': {}}
            self._templar = MockTemplar()

        def run(self, *args, **kwargs):
            assert kwargs['tmp'] is None
            assert kwargs['task_vars']['foo'] == 'bar'
            assert self.RESULT['changed'] is False
            assert self.RESULT['ansible_stats']['aggregate'] is True
            return self.RESULT

    class MockTemplar:
        def template(self, *args, **kwargs):
            assert kwargs['convert_bare'] is False

# Generated at 2022-06-23 08:40:28.888471
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    obj = ActionModule()
    
    # Create an instance of class TaskExecutor
    obj2 = TaskExecutor()
    
    # Instance of class Result
    res = Result()
    
    # Case 1 - run() method
    result = obj.run(None, None)
    if isinstance(result, Result):
        print('TEST PASS : case 1: run() method')
        res.suc += 1
    else:
        print('TEST FAIL : case 1: run() method')
        res.fail += 1
        
    # Case 2 - run() method
    result = obj.run(None, {})
    if isinstance(result, Result):
        print('TEST PASS : case 2 : run() method')
        res.suc += 1

# Generated at 2022-06-23 08:40:39.217285
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader

    # create the module instance
    set_stats_action = action_loader.get('set_stats', task=Task(), connection=None, play_context=PlayContext(), loader=None, templar=None, shared_loader_obj=None)

    # prepare arguments
    set_stats_action._task.args['data'] = {'key': 'value'}

    # mock data
    set_stats_action._templar = MagicM

# Generated at 2022-06-23 08:40:40.434923
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None, None)
    assert am is not None


# Generated at 2022-06-23 08:40:45.001858
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(),
        connection=dict(),
        play_context=dict(check_mode=False),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    assert module

# Generated at 2022-06-23 08:40:48.016844
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create object of class ActionModule
    action_module = ActionModule()

    # get object of class DanteModule
    task_result = action_module.run()

    # check if result is of type TaskResult
    #assert isinstance(task_result, TaskResult)


# Generated at 2022-06-23 08:40:57.070206
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    am = ActionModule({'task_name': 'Stats'})

    stats = dict()

    stats['data'] = dict()

    # test with no data passed
    data = am.run()
    assert data['ansible_stats']['aggregate'] == True
    assert data['ansible_stats']['per_host'] == False
    assert data['ansible_stats']['data'] == {}

    # test with valid data passed
    data = am.run(task_vars=dict(), tmp=dict(), args=stats)
    assert data['ansible_stats']['aggregate'] == True
    assert data['ansible_stats']['per_host'] == False
    assert data['ansible_stats']['data'] == {}

    # test with non-dict data passed
    stats['data'] = "Hello"

# Generated at 2022-06-23 08:40:59.886698
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Unit test for run() method of class ActionModule
    # TODO: unit test run() method
    pass

__all__ = ['test_ActionModule_run']

# Generated at 2022-06-23 08:41:04.645966
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = ActionModule('test', {})
    assert result._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-23 08:41:11.995956
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.parsing import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    import os

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager,  host_list=['my_host'])
    variable_manager.set_inventory(inventory)

    play_source =  dict(
    name = "Ansible Play",
    hosts = 'my_host',
    gather_facts = 'no',
    tasks = [
        dict(action=dict(module='set_stats', args=dict(data=dict(one=1, two='two', three=True, four=['a', 'b', 'c']))))
        ]
    )



# Generated at 2022-06-23 08:41:15.801102
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)
    assert ActionModule.TRANSFERS_FILES == False
    assert ActionModule._VALID_ARGS == frozenset(['aggregate', 'data', 'per_host'])

# Generated at 2022-06-23 08:41:16.400589
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:41:17.074844
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True == True

# Generated at 2022-06-23 08:41:27.239141
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    os = 'centos'
    verb = 'build'
    win_user = 'Administrator'
    win_pass = 'blah'
    host = '192.168.1.1'

    src = 'a.txt'
    dest = 'b.txt'
    group = 'users'
    owner = 'chuck'
    mode = '100'
    args = '-r'
    remote_src = True
    validate = 'checksum'
    backup = True
    unsafe_writes = True


    # data for testing:
    # template_data = {'os': 'FreeBSD', 'verb': 'create', 'items': 5}

    # in:
    # {
    #     "host": "192.168.1.1"
    #     "win_user": "Administrator"
    #    

# Generated at 2022-06-23 08:41:28.336969
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:41:33.292445
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class ActionModule_mod(ActionModule):
        def run(self, tmp=None, task_vars=None):
            return {'ansible_stats' : None}
    a = ActionModule_mod(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert a.run()["ansible_stats"] is None

# Generated at 2022-06-23 08:41:44.013062
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Sample task_vars
    task_vars = {'foo': 'bar', 'alpha': 'bravo'}

    # Create a mock
    action = ActionModule()
    action._task = 'foo'
    action.tmp = 'bar'
    action.task_vars = task_vars
    action._low_level_execute_command = 'baz'
    action._low_level_run_command = 'qux'

    # Create a mock
    result = {}

    # Run method under test
    result = action.run()

    assert(result['ansible_stats']['data'] == {})
    assert(result['ansible_stats']['per_host'] == False)
    assert(result['ansible_stats']['aggregate'] == True)

# Generated at 2022-06-23 08:41:54.795697
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.utils.vars import combine_vars
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    terms = [{'name': 'testvar',
             'args': {'data': {'testdata': {'foo': 'bar', 'baz': 'qux'},
                               'aggregate': 'True'}}}]
    task = Task()
    task.action = 'set_stats'
    task.args = terms
    variable_manager.set_inventory(loader.load_from_file('../mock/hosts'))

# Generated at 2022-06-23 08:42:01.655467
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    tmp = None
    task_vars = dict()
    tmp = None
    action_mod = ActionModule()
    assert action_mod

    stats = {'data': {'a': '1'}, 'per_host': False, 'aggregate': True}
    stats_expected = {'data': {'a': '1'}, 'per_host': False, 'aggregate': True}
    result = action_mod.run(tmp, task_vars)
    result_expected = {'ansible_stats': stats_expected, 'changed': False}
    assert result == result_expected

    task_vars = dict()
    tmp = None
    action_mod = ActionModule()
    assert action_mod


# Generated at 2022-06-23 08:42:09.297063
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_FALSE, BOOLEANS_TRUE
    from ansible.utils import vars as ansible_vars
    from ansible.utils.vars import isidentifier

    def test_boolean(values, expected):
        module = ActionModule()
        method = 'boolean'
        method = getattr(module, method)

        for value in values:
            result = method(value)
            assert result == expected, "%s(%r) returned %r, expected %r" % (method.__name__, value, result, expected)

    test_boolean(BOOLEANS_TRUE, True)
    test_boolean(BOOLEANS_FALSE, False)

# Generated at 2022-06-23 08:42:10.714376
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test case for the method called '_run' of the class ActionModule
    """
    pass

# Generated at 2022-06-23 08:42:13.023577
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Use the constructor of class ActionModule to create an
    instance of the object.
    """
    pass

# Generated at 2022-06-23 08:42:15.467555
# Unit test for constructor of class ActionModule
def test_ActionModule():

    import ansible.plugins.action

    am = ansible.plugins.action.ActionModule(None, None, None, None)



# Generated at 2022-06-23 08:42:24.143481
# Unit test for constructor of class ActionModule
def test_ActionModule():

    class FakeModule:
        class Task:
            def __init__(self, data):
                self.args = data

            def _load_vars(self):
                pass

        def __init__(self):
            self.task = self.Task({'data': {'a': 'b', 'c': 'd'}})

    class FakePlayContext:
        def __init__(self):
            self.connection = 'local'
            self.network_os = 'default'
            self.remote_addr = '127.0.0.1'
            self.port = 22
            self.remote_user = 'remote_user'

        def set_namespace(self, namespace):
            self.namespace = namespace

        def set_task_uuid(self, task_uuid):
            self.task_uuid = task

# Generated at 2022-06-23 08:42:29.884955
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.executor.task_result import TaskResult
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.plugins.loader import action_loader

    fake_loader = DataLoader()
    fake_inventory = InventoryManager(loader=fake_loader, sources='')
    variable_manager = VariableManager(loader=fake_loader, inventory=fake_inventory)

    fake_variable_manager = lambda: None
    fake_variable_manager.get_vars = lambda x,y,z: {}

    fake_play = Play().load({}, variable_manager=variable_manager, loader=fake_loader)

# Generated at 2022-06-23 08:42:30.705251
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:42:32.025089
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert isinstance(module, ActionBase)

# Generated at 2022-06-23 08:42:40.302783
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: pass in test data
    task = dict(
        args = dict(
            data = dict(
                a = "{{ x }}",
                b = 10,
            ),
            per_host = "{{ y }}",
            aggregate = "{{ z }}",
        ),
    )

    vars = dict(
        x = "test data",
        y = True,
        z = False,
    )

    task_vars = dict(
        ansible_stats = dict(
            data = dict(
                a = "test data",
                b = 10,
            ),
            per_host = True,
            aggregate = False,
        ),
        ansible_check_mode = False,
        ansible_diff = False,
    )


# Generated at 2022-06-23 08:42:48.772996
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.loader import find_plugin
    #TODO remove this import after removing the old test_action_plugin_basic.py
    from ansible.plugins.action.set_stats import ActionModule as set_stats_ActionModule

    class FakeVarsModule():
        ''' Fake ansible.vars.VariableManager() '''
        def __init__(self):
            self.extra_vars = {'aggregate': True, 'data': {'foo': 'bar'}, 'per_host': False}

    class FakeHost():
        ''' Fake ansible.inventory.host.Host() '''
        vars = FakeVarsModule()


# Generated at 2022-06-23 08:42:55.227343
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible import constants as C
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block

    fake_loader = DataLoader()
    fake_inventory = InventoryManager(loader=fake_loader, sources=[])
    fake_variable_manager = VariableManager(loader=fake_loader, inventory=fake_inventory)

    class FakeOptions:
        listtags = False
        listtasks = False
        listhosts = False
        syntax = False
        connection = 'ssh'
        module_path = None
        forks = 5
        private_

# Generated at 2022-06-23 08:43:03.761652
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule({'action': 'set_stats'})

    # Tests ActionBase.run
    result = action.run({}, {})
    assert result['changed'] is False
    assert result['ansible_stats']['data'] == {}
    assert result['ansible_stats']['per_host'] is False
    assert result['ansible_stats']['aggregate'] is True

    # Tests the first path for ActionModule.run
    result = action.run({}, {}, {})
    assert result['failed'] is True
    assert result['msg'] is "The 'data' option needs to be a dictionary/hash"

    # Tests the second path for ActionModule.run
    result = action.run({}, {}, {'data': {'a': 1}})
    assert result['changed'] is False

# Generated at 2022-06-23 08:43:08.245835
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(dict(a=1, data={'b': 2}, aggregate=True, per_host=True), None)
    assert am.run() == dict(failed=False, changed=False, ansible_stats=dict(data={'a': 1, 'b': 2}, aggregate=True, per_host=True))

# Generated at 2022-06-23 08:43:16.297439
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule(
        task=dict(
            action=dict(module_name='ansible.builtin.set_stats',
                        module_args=dict(data=dict(a=3, b='foo', c='{{ d }}'), aggregate=True, per_host=False)),
            args=dict()),
        play=dict(hosts=['localhost']),
        connection=dict(),
        loader=dict(
            basedir='/testdir/',
            shared_loader_obj=dict(
                template_class=dict(),
                basedir='/testdir/',
                _basedir='/testdir/',
            ),
        ),
        templar=dict(),
    )
    result = m.run(task_vars=dict(d='bar'))
    assert not result['failed']

# Generated at 2022-06-23 08:43:17.649687
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule.run('foo','bar')


# Generated at 2022-06-23 08:43:20.839544
# Unit test for constructor of class ActionModule
def test_ActionModule():

    cls = ActionModule(None, None)

    assert cls._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

    assert not cls.TRANSFERS_FILES

# Generated at 2022-06-23 08:43:31.448000
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # For all tests, initialize the module.
    module = ActionModule()

    # Initialize the ActionModule's main data structure to simulate a task
    module._task = dict()

    # Initialize the ActionModule's main data structure to simulate a task's argument
    module._task_args = dict()

    # set up some defaults for the aggregate and per_host variables
    module._task_args['per_host'] = False
    module._task_args['aggregate'] = True

    # Test all functions of set_stats module

# Generated at 2022-06-23 08:43:42.372873
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars={"my_var": "my_value"}
    task_vars_new=task_vars.copy()
    task_vars_new['per_host']=False
    task_vars_new['aggregate']=True
    task_vars_new['data'] = {'counter': 0}

    # create a Mock instance of class AnsibleModule
    mock_templar = MagicMock()
    mock_templar.template = MagicMock(side_effect=lambda x: str(x))
    mock_task = MagicMock()
    mock_task.args = {'data': {'counter': '{{ counter }} + 1'}}

    # test ActionModule_set_stats class

# Generated at 2022-06-23 08:43:51.389877
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None)
    assert action._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

    assert action.run() == {'changed': False, 'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}}
    assert action.run(task_vars={'somevar': 'somevalue'}) == {'changed': False, 'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}}


# Generated at 2022-06-23 08:43:52.443499
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('test_ok')

# Generated at 2022-06-23 08:43:53.043343
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-23 08:43:59.773368
# Unit test for constructor of class ActionModule
def test_ActionModule():
    data = dict()
    data['changed'] = False
    data['ansible_stats'] = {}
    data['ansible_stats']['data'] = {}
    data['ansible_stats']['per_host'] = False
    data['ansible_stats']['aggregate'] = True

    tdata = dict()
    tdata['data'] = dict()
    tdata['data']['test'] = 1

    data2 = dict()
    data2['changed'] = False
    data2['ansible_stats'] = {}
    data2['ansible_stats']['data'] = {}
    data2['ansible_stats']['data']['test'] = 1
    data2['ansible_stats']['per_host'] = False
    data2['ansible_stats']['aggregate']

# Generated at 2022-06-23 08:44:04.125264
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    
    # Test for no execution
    module = ActionModule(None, None, None, None)
    result = module.run(None, None)
    assert result['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True}

    # Test for no execution
    module = ActionModule(None, None, None, None)
    result = module.run(None, {'hostvars': {}})
    assert result['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True}

    # Test for no execution
    module = ActionModule(None, None, None, {'args': {}})
    result = module.run(None, {'hostvars': {}})

# Generated at 2022-06-23 08:44:14.760910
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module._task.args = {}
    result = module.run(None, {'hostvars': {'host1': {'hoge': 1}, 'host2': {'hoge': 2}}})
    assert result['ansible_stats']['data']['_runs'] == 2
    assert result['ansible_stats']['data']['_ok'] == 2
    assert result['ansible_stats']['data']['_skipped'] == 0
    assert result['ansible_stats']['data']['_failed'] == 0
    assert result['ansible_stats']['data']['changed'] == False
    assert result['ansible_stats']['per_host'] == False
    assert result['ansible_stats']['aggregate'] == True

# Generated at 2022-06-23 08:44:26.475360
# Unit test for method run of class ActionModule
def test_ActionModule_run():

# creates a test action module
    class UnitTestActionModule(ActionModule):

        def run(self,tmp=None,task_vars=None):
            return super(UnitTestActionModule,self).run(tmp,task_vars)

    task_vars = dict(
        aggregate=True,
        data=dict(
            a=True,
            b=1,
            c="foo",
        ),
        per_host=True,
        _raw_params="aggregate: '{{ aggregate }}' per_host: '{{ per_host }}' data: '{{ data }}'",
    )

# Generated at 2022-06-23 08:44:30.713339
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule({'args': {'data': {'asdf': 'qwer'}, 'aggregate': 'yes', 'per_host': 'yes'}}, {})
    assert action.run() == {'ansible_stats': {'data': {'asdf': 'qwer'}, 'aggregate': True, 'per_host': True}}

# Generated at 2022-06-23 08:44:38.729521
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-23 08:44:49.944752
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ test_ActionModule_run
    """
    from ansible import constants as C
    from ansible.utils.vars import combine_vars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.utils import context_objects as co

    def lookup_plugin(plugin_name, *args, **kwargs):
        if plugin_name == 'vars':
            return dict(a="{{foo}}", b="{{foo}}", c="value")

        raise Exception("unexpected call to lookup_plugin")

    setattr(C, 'DEFAULT_HASH_BEHAVIOUR', 'replace')


# Generated at 2022-06-23 08:44:58.870452
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule(task={'args': {'data': {'testKey': 'testValue'}, 'per_host': True}},
                      connection={'play_context': {'become': False, 'become_method': None, 'become_user': None},
                                  'remote_user': 'user', 'transport': 'conn'},
                      task_vars={}, loader=None, templar=None, shared_loader_obj=None)
    assert am.run() == {'ansible_stats': {'data': {'testKey': 'testValue'}, 'per_host': True, 'aggregate': True},
                         'changed': False}


# Generated at 2022-06-23 08:45:05.950694
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    AnsibleModule test for method run

    :return:
    """

    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    from ansible.plugins.action import ActionBase

    from ansible.utils.vars import merge_hash
    from ansible.template import Templar

    class ActionModuleTest(ActionBase):

        def run(self, tmp, task_vars):
            return super(ActionModuleTest, self).run(tmp, task_vars)

    # Create the objects
    task = Task()
    task_vars = {'template': 'data/templates/hosts.j2', 'msg': 'rainbow'}
    play_context = PlayContext()
    templar = Templar(loader=None, variables=task_vars)

    module

# Generated at 2022-06-23 08:45:16.484700
# Unit test for constructor of class ActionModule
def test_ActionModule():
    data = dict()
    data['ansible_facts'] = dict()
    data['ansible_facts']['test_var'] = 'test_value'
    data['ansible_facts']['test_var_2'] = 'test_value_2'
    data['ansible_stats'] = dict()
    data['ansible_stats']['data'] = dict()
    data['ansible_stats']['data']['test_var_3'] = 'test_value_3'
    data['ansible_stats']['data']['test_var_4'] = 'test_value_4'
    data['ansible_stats']['data']['test_var_5'] = 'test_value_5'
    data['ansible_stats']['per_host'] = True

# Generated at 2022-06-23 08:45:23.636342
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    args = {}
    args['data'] = {}
    args['per_host'] = True
    args['aggregate'] = True
    task = dict()
    task['args'] = args
    result = module.run(None, None, task)
    assert result['changed'] == False
    assert result['ansible_stats']['data'] == {}
    assert result['ansible_stats']['per_host'] is True
    assert result['ansible_stats']['aggregate'] is True

# Generated at 2022-06-23 08:45:31.672536
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj_bi = ActionModule(task=dict(), connection=dict(), play_context=dict(check_mode=True, remote_addr='remoteaddr', remote_user='remoteuser'),
                          loader=None, templar=None, shared_loader_obj=None)
    obj_t = ActionModule(task=dict(), connection=dict(), play_context=dict(check_mode=False, remote_addr='remoteaddr', remote_user='remoteuser'),
                          loader=None, templar=None, shared_loader_obj=None)
    assert obj_bi._supports_check_mode is False, "obj_bi._supports_check_mode should be False"
    assert obj_t._supports_check_mode is True, "obj_t._supports_check_mode should be True"
    assert obj_t._play_context

# Generated at 2022-06-23 08:45:36.103492
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # ensure the module constructor works
    am = ActionModule(task=dict(action=dict(module_name='set_stats', module_args=dict()), task_vars=dict()))
    assert am is not None

# Generated at 2022-06-23 08:45:44.740421
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    action_module = ActionModule()

    tmp = 0
    task_vars = dict()

    action_module._task = _task
    result = action_module.run(tmp, task_vars)

    assert result['changed'] == False
    assert result['ansible_stats']['aggregate'] == True
    assert result['ansible_stats']['per_host'] == False

    assert result['ansible_stats']['data']['test_run'] == 100
    assert result['ansible_stats']['data']['test_run2'] == "{{foo}}"

# Mock-up class _task

# Generated at 2022-06-23 08:45:54.278465
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import sys
    import json
    import unittest
    import sys
    import tempfile
    import subprocess

    from ansible import __version__
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.template import Templar
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.module_utils.six import PY3

    from paramiko import SSHException
    from io import BytesIO, StringIO


# Generated at 2022-06-23 08:46:06.333028
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    
    # Create an object of class ActionModule
    test_object = ActionModule()
    args_in = {'data': {'test_one': 1, 'test_two': 2}}
    result = test_object.run(tmp = None, task_vars = None)

    assert result['changed'] == False
    assert result['ansible_stats']['per_host'] == False
    assert result['ansible_stats']['aggregate'] == True
    assert result['ansible_stats']['data'] == {}
    assert type(result['ansible_stats']['data']) == dict

    result = test_object.run(tmp = None, task_vars = None, args = args_in)

    assert result['changed'] == False
    assert result['ansible_stats']['per_host'] == False

# Generated at 2022-06-23 08:46:08.757873
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert bool(am) is True
    # Test output is a dictionary
    assert isinstance(am.run(), dict)

# Generated at 2022-06-23 08:46:19.078286
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook import Play
    from ansible.template import Templar

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    from collections import namedtuple

    mock_templar = Templar(loader=DictDataLoader())

    mock_data = dict(
        ansible_facts=dict(
            ansible_bogus=True
        ),
        _ansible_no_log=True
    )

    test_task = Task()
    test_task._role = namedtuple('_role', 'task_vars')(dict())
    test_task._block = Block()

# Generated at 2022-06-23 08:46:24.247484
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    This is an example of how to test the constructor of the
    python module.
    """
    new_object = ActionModule()
    print(new_object)

if __name__ == '__main__':
    # Unit test the Action Module
    test_ActionModule()

# Generated at 2022-06-23 08:46:34.041549
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    This function is a test for the method run of Paramiko.
    '''
    action_module = ActionModule()
    data_1 = {'data':{'a':7, 'b':11}, 'per_host':True, 'aggregate':False}
    data_2 = {'data':{'a':7, 'b':[1,2,3]}, 'per_host':True, 'aggregate':False}
    data_3 = {'data':{'a':7, 'b':[1,2,3]}, 'per_host':False, 'aggregate':True}
    data_4 = {'data':{'a':7, 'b':11}, 'per_host':False, 'aggregate':True}

# Generated at 2022-06-23 08:46:39.119766
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json

    a = ActionModule()
    a._display.verbosity = 4
    a._shared_loader_obj = None
    # a._loader = DataLoader()
    a._task = None
    a._task_vars = None
    a._loaded_file = None
    a._templar = None
    a._connection = None
    a._play_context = None
    a._runner_connection = None
    a._action = None
    a._result = None
    a._templar.verbosity = 4
    res = a.run({}, {})
    x = json.dumps({'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}, 'changed': False}, indent=4, sort_keys=True)

# Generated at 2022-06-23 08:46:46.367552
# Unit test for method run of class ActionModule
def test_ActionModule_run(): 
    action = ActionModule()

    action._task = {'args': {'data': {'x': 42}, 'per_host': False, 'aggregate': False}}
    action._templar = {'template': lambda x: x}

    expected_result = {'changed': False, 'ansible_stats': {'data': {'x': 42}, 'per_host': False, 'aggregate': False}}
    result = action.run(task_vars={})

    assert result == expected_result


# Generated at 2022-06-23 08:46:53.409132
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None,
                      task_vars=dict(
                          foo='bar',
                          baz=dict(
                              baz1='foobar',
                              baz2=dict(
                                  baz3='barfoo',
                                  baz4=dict(
                                      baz5='foofoo'
                                  )
                              )
                          )
                      )
                      )
    tmpl = am._templar
    tmpl._available_variables = am._templar._available_variables
    r = am.run(None, None)
    assert isinstance(r, dict)
    assert not r['failed']
    assert 'msg' not in r
    data = r['ansible_stats']['data']
    assert isinstance(data, dict)
   

# Generated at 2022-06-23 08:46:54.384937
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None, None, None)

# Generated at 2022-06-23 08:46:55.042659
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 08:46:58.529479
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, 'test.yml', {}, None, None)
    assert type(action) == ActionModule

# Generated at 2022-06-23 08:47:00.958846
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Empty constructor of ActionModule
    action_module = ActionModule(None, {})

    assert action_module.TRANSFERS_FILES is False

# Generated at 2022-06-23 08:47:01.972170
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(ActionModule)

# Generated at 2022-06-23 08:47:08.702842
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(load_fixture('test-set_stats.yml'), {})
    result = module.run(task_vars={'ansible_check_mode':False})
    assert result['ansible_stats']['data']['test_var'] == 'test'
    assert result['ansible_stats']['per_host'] == False
    assert result['ansible_stats']['aggregate'] == True

# Generated at 2022-06-23 08:47:09.225125
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-23 08:47:10.540664
# Unit test for constructor of class ActionModule

# Generated at 2022-06-23 08:47:13.370009
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule._VALID_ARGS == {"aggregate", "data", "per_host"}

# Generated at 2022-06-23 08:47:20.933640
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task

    y = Task()
    am = ActionModule(y, dict(per_host=True, aggregate=False))
    assert am._valid_args == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-23 08:47:30.403155
# Unit test for constructor of class ActionModule
def test_ActionModule():
   data = {'data':{'key1': 'value1', 'key2': 'value2'}, 'other': 'other'}
   result = ActionModule().run(None, None, data)
   stats = result.get('ansible_stats')
   data_dict = stats.get('data')
   result_data = {}

   for (k,v) in iteritems(data_dict):
       result_data[k]=v
   data.pop('other')
   assert result_data == data

# Generated at 2022-06-23 08:47:31.462668
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    raise NotImplementedError()

# Generated at 2022-06-23 08:47:36.912091
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """ Unit test for method run of class ActionModule
    """
    # setup test
    test_hostname = 'testhost'
    test_task = {
        'args': {
            'aggregate': True,
            'data': {
                'test_variable_1': 'test_value_1',
                'test_variable_2': '{{ test_var }}',
                'test_variable_3': 'test_value_3'
            },
            'per_host': True,
        },
        'hostvars': {}
    }
    test_task_vars = {'test_var': 'test_value_2'}

# Generated at 2022-06-23 08:47:41.655549
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule(load_context=lambda: dict(task_vars=dict(a=1, b=2)))
    assert isinstance(obj.run(task_vars=dict(c=3)), dict)

# Generated at 2022-06-23 08:47:42.380379
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:47:44.485844
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(None, dict())
    assert isinstance(module, ActionModule)


# Generated at 2022-06-23 08:47:47.862214
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Arrange
    action = ActionModule(task, connection, play_context=play_context, loader=loader, templar=templar, shared_loader_obj=None)

    # Assert
    assert action._action_name == 'set_stats'



# Generated at 2022-06-23 08:47:52.185428
# Unit test for constructor of class ActionModule
def test_ActionModule():
    isdict = isinstance({}, dict)
    assert isdict 
    assert callable(super(ActionModule, ActionModule))
    assert callable(ActionModule.run)
    #assert callable(ActionModule._task.args)
    #assert eq(stats, {'data': {}, 'per_host': False, 'aggregate': True})


# Generated at 2022-06-23 08:47:53.152282
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print(ActionModule({}, {}))

# Generated at 2022-06-23 08:47:53.694464
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()

# Generated at 2022-06-23 08:47:57.485508
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' test_ActionModule.py: Unit test for constructor of class ActionModule '''

    # Test with no argument
    am = ActionModule(None, None, None, None, '/home/vagrant/ansible/action_plugins', None, None)
    assert am

# Generated at 2022-06-23 08:48:03.009949
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        task=dict(
            args={},
        ),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    assert action_module is not None

# Generated at 2022-06-23 08:48:15.320488
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    d = dict(aggregate=None, aggregate2=None, aggregate3=None,
             per_host=None, per_host2=None, per_host3=None,
             data=dict(a="1", b="2", c="3", d="4"))
    t = dict(vars=dict(a="1", b="2", c="3", d="4"))
    a = ActionModule()
    a._task = dict(args=d)
    a._templar = dict()
    a._templar.template = lambda x, convert_bare=False, fail_on_undefined=True: x
    a._templar.template.__name__ = "Mock"
    r = a.run(task_vars=t)

# Generated at 2022-06-23 08:48:23.228412
# Unit test for constructor of class ActionModule
def test_ActionModule():
    my_action = ActionModule(name='my_action', task=dict(args=dict()), shared_loader_obj=None, connection=None, play_context=None, loader=None, templar=None, passwords=None)
    assert my_action._task.name == 'my_action'
    assert my_action.loader is None
    assert my_action.templar is None
    assert my_action.playbook is None
    assert my_action.play is None
    assert my_action.play_context is None
    assert my_action.basedir is None
    assert my_action.connection is None
    assert my_action.task_vars is None
    assert my_action._task.args == dict()


# Generated at 2022-06-23 08:48:29.851257
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    class TestActionModule(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test__validate_inputs_good(self):
            pass

        def test__validate_inputs_bad(self):
            pass

        def test__validate_inputs_bad(self):
            pass

    if __name__ == '__main__':
        unittest.main()
    '''

# Generated at 2022-06-23 08:48:30.316015
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert(False)

# Generated at 2022-06-23 08:48:31.768935
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        a = ActionModule()
    except:
        print("Not able to instantiate class ActionModule")
        raise

# Generated at 2022-06-23 08:48:37.737496
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task
    task = dict()
    task['args'] = dict()
    task['args']['data'] = dict()
    task['args']['data']['a'] = 3
    task['args']['data']['b'] = 5

    # Instanciate an ActionModule mock
    action_module = ActionModule(task, dict())

    # Call the run method and check the result
    action_module.run()
    assert not action_module._result['failed']

    # Remove the 'b' from data
    del task['args']['data']['b']

    # Call the run method and check that 'failed' is True
    action_module.run()
    assert action_module._result['failed']

# Generated at 2022-06-23 08:48:49.179080
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()
    action._add_action_module(ActionModule())
    action._add_action_module(ActionModule())
    action._task.add_action('set_stats', ActionModule())
    result = action.run()
    assert 'ansible_stats' in result
    assert 'data' in result['ansible_stats']
    assert 'per_host' in result['ansible_stats']
    assert 'aggregate' in result['ansible_stats']
    assert result['ansible_stats']['per_host'] == False
    assert result['ansible_stats']['aggregate'] == True
    assert isinstance(result['ansible_stats']['data'], dict)
    assert result['ansible_stats']['data'] == {}

# Generated at 2022-06-23 08:49:03.842913
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.playbook_executor import PlaybookExecutor

    task_vars = {'is_id': '99'}
    task_dep_vars = {'is_id_2': '100'}

    loader = '{"hosts": [], "vars":{}, "tasks":[], "roles":[]}'
    play_context = PlayContext()
    play_context.search_path = ['loader']
    play_context.connection = 'local'

    new_stdin = '{"hosts": [], "vars":{}, "tasks":[], "roles":[]}'


# Generated at 2022-06-23 08:49:12.030406
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    play_context = PlayContext()
    host = Host(name='hostname')
    group = Group(name='groupname')
    group.add_host(host)
    play_context.set_inventory(host=host)

    play_context.network_os = 'ios'
    play_context.become = False
    play_context.become_method = 'enable'
    play_context.become_user = 'testuser'
    play_context.remote_user = 'testuser'

    task = Task()
    task._role = None
    task._block = None
    task.context = play_context


# Generated at 2022-06-23 08:49:19.665327
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = dict(changed = False)
    module = ActionModule( dict(task=dict(args=dict(data = dict(a=1,b=2,c=3), aggregate = True, per_host = False))), dict(ansible_facts = dict(a=1,b=2,c=3)), None, None, None)
    result = module.run(None, None)
    assert result.get('changed') == False
    assert result.get('ansible_stats').get('data') == dict(a=1,b=2,c=3)
    assert result.get('ansible_stats').get('aggregate') == True
    assert result.get('ansible_stats').get('per_host') == False

# Generated at 2022-06-23 08:49:33.189910
# Unit test for constructor of class ActionModule
def test_ActionModule():
    name = "set_stats"
    path = "PATH"
    inject = dict()
    task_vars = dict()
    loader = "LOADER"
    templar = "TEMPLAR"
    shared_loader_obj = "SHARED_LOADER_OBJ"

    action = ActionModule(name, path, inject, task_vars, loader, templar, shared_loader_obj)

    assert action.name == name
    assert action.path == path
    assert action.inject == inject
    assert action.task_vars == task_vars
    assert action.loader == loader
    assert action.templar == templar
    assert action.shared_loader_obj == shared_loader_obj