

# Generated at 2022-06-23 08:39:30.294553
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible import template
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.encrypt import do_encrypt
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host

    # Initialize objects
    tqm = object()
    loader = object()
    variable_manager = VariableManager()
    variable_manager.set_inventory(HostVars(loader, variable_manager))
    variable_manager.set_playbook_basedir("./playbooks")
    variable_manager.set_sources('./playbooks/hosts', './playbooks/group_vars')

# Generated at 2022-06-23 08:39:32.096409
# Unit test for method run of class ActionModule
def test_ActionModule_run():
   act = ActionModule(None, None, None)
   assert act.run(None, None) == {"failed": False}



# Generated at 2022-06-23 08:39:36.011018
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    print(am.__dict__)
    assert am.run() == {'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}, 'changed': False}

# Generated at 2022-06-23 08:39:43.787481
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host = 'localhost'
    task = dict(action=dict(module='set_stats', args=dict(data=dict(test1='hello', test2='world'))))
    connection = 'local'
    play_context = dict(check_mode=True, diff=True)

    new_stdin = """{% if 1 == 2 %}
foo
{% endif %}"""

    a = ActionModule(task, connection, play_context, new_stdin)
    b = ActionBase()

# Generated at 2022-06-23 08:39:47.311287
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' test_ActionModule
    This is a unit test of the constructor of the class ActionModule
    '''

    tmp = set_stats.ActionModule(None, None, None)

    assert tmp is not None

# Generated at 2022-06-23 08:39:54.879868
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test case 1: instance of ActionModule created
    test_action_module = ActionModule()

    assert(test_action_module.TRANSFERS_FILES == False)
    assert(test_action_module._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host')))

    # test case 2: constructor of class ActionModule is called with tmp and task_vars parameter
    # results in run method called
    test_action_module = ActionModule()
    test_action_module.run(tmp=None, task_vars=None)

    # test case 3: constructor of class ActionModule is called with tmp parameter
    # results in run method called
    test_action_module = ActionModule()
    test_action_module.run(tmp=None, task_vars=None)

    # test case

# Generated at 2022-06-23 08:40:05.101662
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule, object)
    assert issubclass(ActionModule, ActionBase)
    # _VALID_ARGS must be of 'frozenset' type chk
    assert isinstance(ActionModule._VALID_ARGS, frozenset)
    # _VALID_ARGS must contain only string types
    assert not any(isinstance(item, string_types) for item in ActionModule._VALID_ARGS)
    # _VALID_ARGS must be of 'frozenset' type chk
    assert isinstance(ActionModule._VALID_ARGS, frozenset)
    # _VALID_ARGS must contain only string types
    assert not any(isinstance(item, string_types) for item in ActionModule._VALID_ARGS)
    # _VALID_ARGS must be of 'f

# Generated at 2022-06-23 08:40:16.286181
# Unit test for constructor of class ActionModule

# Generated at 2022-06-23 08:40:21.744449
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print("Trying to construct ActionModule")

    action = ActionModule()

    print(action.run())

    print("Successfully completed ActionModule construct")


if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-23 08:40:32.347557
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager

    def get_hosts(pattern):
        h = Host('localhost')
        h.name = 'localhost'
        return [h]

    class FakeModule(object):
        def __init__(self):
            self.params = {'data': {}}

        def fail_json(self, **kwargs):
            raise NotImplementedError

    # Load action plugin
    action = ActionModule()
    action._shared_loader_obj = FakeModule()

    # Create a task with arbitrary options
    task = Task()
    task.args = {'data': {'var_start_with_num': 'val'}}

    # Required for Action

# Generated at 2022-06-23 08:40:37.048499
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ('_VALID_ARGS' in dir(ActionModule))
    assert ('TRANSFERS_FILES' in dir(ActionModule))
    assert ('run' in dir(ActionModule))
    assert isinstance(ActionModule.TRANSFERS_FILES, bool)
    assert isinstance(ActionModule._VALID_ARGS, frozenset)
    assert isinstance(test_ActionModule.__name__, str)

# Generated at 2022-06-23 08:40:42.654629
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(task='faketask', connection='fakeconnection', play_context='fakeplaycontext')
    result = module.run(task_vars='faketaskvars')
    assert result == {'changed': False, 'ansible_stats': {'data': {}, 'per_host': False, 'aggregate': True}}


if __name__ == "__main__":
    test_ActionModule_run()

# Generated at 2022-06-23 08:40:51.775937
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook import play
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils import context_objects as co
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars

    loader = DataLoader()

# Generated at 2022-06-23 08:40:56.695636
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_args = {'data': {'foo': 'bar'}}
    temp_vars = {}
    from ansible.playbook.task import Task
    temp_task = Task()
    temp_task.args = task_args
    x = ActionModule.ActionModule(task=temp_task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert x._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))


# Unit test to check whether isidentifier() method returns True as expected

# Generated at 2022-06-23 08:41:05.416952
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.action import ActionBase
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    import pytest

    action = ActionModule()
    action._templar = None
    action._shared_loader_obj = DataLoader()
    action._loader = action._shared_loader_obj
    action._task = Task()
    action._task_vars = dict()
    action._task.args = dict()
    action._task.action = 'set_stats'

    # Empty args

# Generated at 2022-06-23 08:41:05.923823
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True is True

# Generated at 2022-06-23 08:41:17.133824
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play


# Generated at 2022-06-23 08:41:27.276832
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class TestTask():
        def __init__(self, args={}):
            self.args = args

    class TestModule():
        def __init__(self, action_module):
            self.action_module = action_module

    class TestTaskExecutor():
        def __init__(self, task_vars={}):
            self.task_vars = task_vars

    class TestTaskVarsModule():
        def __init__(self):
            self.vars = {}
            self.no_log = False

        def set_vars(self, vars):
            self.vars = vars

    class TestModuleUtils():
        def __init__(self):
            self.bool = False;

        def convert_bool(self, val, strict=False):
            if self.bool:
                return

# Generated at 2022-06-23 08:41:34.907406
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    TEST_TASK_ARGS = {'tags': ['test_tag'], 'test_test': 'test_test_value'}
    TEST_TASK = Task()
    TEST_TASK.args = TEST_TASK_ARGS
    TEST_ACTIONMODULE = ActionModule(TEST_TASK, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert TEST_ACTIONMODULE._task.args == TEST_TASK.args
    assert TEST_ACTIONMODULE._task.tags == TEST_TASK.tags


# Generated at 2022-06-23 08:41:42.006868
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # No.1
    print('\nTest for ActionModule - No.1')

    test_module = ActionBase._shared_loader_obj._create_module_class("set_stats")
    test_module.run(task_vars={})

    # No.2
    print('\nTest for ActionModule - No.2')

    test_module = ActionBase._shared_loader_obj._create_module_class("set_stats")
    test_module.run(task_vars={}, tmp=None)

# Generated at 2022-06-23 08:41:47.029544
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ansible = Ansible()
    action_mod = ActionModule(ansible, dict(TMP_ARGS={'data': {'greeting': 'hello world!'}}), '/tmp', 'localhost')
    result = action_mod.run(None, None)
    assert not result['failed']
    assert not result['changed']
    assert isinstance(result['ansible_stats'], dict)
    assert result['ansible_stats']['data']['greeting'] == 'hello world!'
    assert result['ansible_stats']['aggregate'] is True
    assert result['ansible_stats']['per_host'] is False

# Generated at 2022-06-23 08:41:50.689199
# Unit test for constructor of class ActionModule
def test_ActionModule():
    moduleTest = ActionModule(None,{},None,None)
    assert(moduleTest)
    assert(moduleTest._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host')))


# Generated at 2022-06-23 08:41:58.325870
# Unit test for constructor of class ActionModule

# Generated at 2022-06-23 08:42:11.081611
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils import context_objects as co

    class Host(object):
        def __init__(self, name):
            self.name = name
            self.vars = dict()

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=["localhost"])
    host = Host("localhost")

# Generated at 2022-06-23 08:42:18.141958
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from collections import namedtuple

    MockModule = namedtuple('MockModule', ['args'])
    MockTemplar = namedtuple('MockTemplar', ['template'])

    mock_ansible_template = "template_data"

    action = ActionModule()
    action.action = "set_stats"
    action.task = MockModule(args = {'data' : {'msg': 'Hello world!'}, 'per_host' : 'True', 'aggregate' : 'True'})
    action._task.async_val = 0
    action._task.loop = 'none'
    action._task.tags = ''
    action._task.action = 'set_stats'
    action._task.only_if = None
    action._task.register = None
    action._task.when = None
    action._task

# Generated at 2022-06-23 08:42:28.390902
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class ActionBase_mock():
        def __init__(self):
            self.tags = []
            self.run_args = []
            self.run_result = {'changed': False}

        def run(self, tmp, task_vars):
            self.run_args.append((tmp, task_vars))
            return self.run_result

    class Task_mock():
        def __init__(self):
            self.args = None

    class ActionModule_mock(ActionModule):
        # Allow testing from the same directory as the module
        module_utils_path = "./"

    am = ActionModule_mock()

    task = Task_mock()
    am.set_loader(None)
    am._task = task
    am._low_level_runner_enabled = False
    am._connection

# Generated at 2022-06-23 08:42:34.073366
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None, None, None, None, None, None, None)
    assert action.__dict__ == {'_config': {},
                               '_task': None,
                               '_play_context': None,
                               '_loader': None,
                               '_templar': None,
                               '_shared_loader_obj': None,
                               '_connection': None}

# Generated at 2022-06-23 08:42:42.151220
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Variables for test
    task_vars = {}
    stats = {'data': {}, 'per_host': False, 'aggregate': True}

    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = am.run(tmp=None, task_vars=task_vars)
    assert result['ansible_stats'] == stats

    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    task_vars = {'toto': 'titi'}
    stats = {'data': {'toto': 'titi'}, 'per_host': False, 'aggregate': True}
   

# Generated at 2022-06-23 08:42:49.189348
# Unit test for constructor of class ActionModule
def test_ActionModule():

    data = {'data': {'test': 1, 'test2': '{{ another }}'}, 'per_host': True, 'aggregate': '{{ aggregate }}'}
    task_vars = {'another': 2, 'aggregate': False}
    tmp = '.tmp'

    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = am.run(tmp=tmp, task_vars=task_vars)
    assert result['ansible_stats'] == {'data': {'test': 1, 'test2': 2}, 'per_host': True, 'aggregate': False}

# Generated at 2022-06-23 08:42:51.304307
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module != None

# Generated at 2022-06-23 08:42:52.594834
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Check ActionModule class initialization
    a = ActionModule()
    assert a is not None

# Generated at 2022-06-23 08:43:02.210511
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Given:
    # a json string representing args
    # and a MagicMock object representing self._templar
    args = "{'data': {'a': '1'}, 'per_host': True}"
    self = MagicMock()
    self._templar = MagicMock()

    # When:
    # ActionModule.run method is called
    ActionModule.run(self, args)

    # Then:
    # assert that the method self._templar.template is called with args twice.
    # assert that the method self._templar.template is called with convert_bare = False
    # assert that the method self._templar.template is called with fail_on_undefined=True

# Generated at 2022-06-23 08:43:04.114879
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule

# Generated at 2022-06-23 08:43:13.807212
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 08:43:21.194704
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(
        task=dict(
            args=dict(
                aggregate=True,
                per_host=True,
                data=dict(
                    a=99
                )
            )
        )
    )

    assert module.run() == dict(
        changed=False,
        ansible_stats={
            'aggregate': True,
            'per_host': True,
            'data': {
                'a': 99
            }
        }
    )

# Generated at 2022-06-23 08:43:23.457968
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(
        task=dict(action=dict(module_name="set_stats"), args={}),
        connection=dict(play_context=dict(become=False)),
        play_context=dict(become=False),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

# Generated at 2022-06-23 08:43:25.312873
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # The set_stats.py module does not really have a constructor.
    # This is just a mehod of testing the def _valid_args() method.
    my_action_module = ActionModule()
    result = my_action_module._valid_args
    assert result == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-23 08:43:34.589768
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test to check the run method of ActionModule.

    This function indirectly tests the following methods:
     - ansible.plugins.action.ActionBase.run
    """
    # Create a ActionModule object
    action_module = ActionModule(None, None, None, None)

    # Set test parameters
    stats = {'data': {}, 'per_host': False, 'aggregate': True}

    # Create result
    result = {'changed': False, 'ansible_stats': stats}

    # Call run
    res = action_module.run(None, None)

    # Check result
    assert res == result

# Generated at 2022-06-23 08:43:35.228848
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:43:37.048278
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule('test')
    assert module.__dict__['_task'].action == 'set_stats'

# Generated at 2022-06-23 08:43:40.289289
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-23 08:43:52.065641
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialization and instantiation of class object
    task_vars = dict()
    module = ActionModule(task=dict(), connection=None, templar=None, shared_loader_obj=None)
    module._task.args = {'data': {'some_counter': 2}, 'per_host': True, 'aggregate': False}
    ret = module.run(task_vars=task_vars)
    assert ret['ansible_stats']['data']['some_counter'] == 2
    assert ret['ansible_stats']['per_host'] is True
    assert ret['ansible_stats']['aggregate'] is False
    del module
    del task_vars

    # Test if the option 'data' is not a dictionary
    task_vars = dict()

# Generated at 2022-06-23 08:43:52.815237
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("STUB: test_ActionModule_run")



# Generated at 2022-06-23 08:43:58.580223
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Syntactic sugar to make writing tests easier."""

    class ActionModuleTest(ActionModule):

        def run(self, tmp=None, task_vars=None):
            if task_vars is None:
                task_vars = dict()

            result = super(ActionModuleTest, self).run(tmp, task_vars)
            del tmp  # tmp no longer has any effect

            # your module execution has happened here
            result['changed'] = False
            result['ansible_facts']['test_key'] = 'test_value'

            return result

    return ActionModuleTest(dict(), dict())

# Generated at 2022-06-23 08:44:02.549917
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()

    result = action_module.run(tmp=None, task_vars=None)

    assert result['changed'] == False
    assert result['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True}

# Generated at 2022-06-23 08:44:09.167174
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Method run of class ActionModule has assumed that the module returns `message` in response, if certain conditions are met.
    # If it is not present, then an exception is thrown.
    # It is expected that should be modified to not throw an exception
    # when a module doesn't retun the message string in response.

    # If a module returns some other string (say, 'msg') in response
    # to the arguments passed to run method, then an exception is thrown

    import ansible.plugins.action as action
    d = action.ActionModule.run(['data', 'name'], ['text'])
    assert d == {'name': 'text'}

# Generated at 2022-06-23 08:44:12.266520
# Unit test for constructor of class ActionModule
def test_ActionModule():
    fake_task = dict()
    mod = ActionModule(fake_task, dict())
    assert mod._VALID_ARGS == frozenset(['aggregate', 'data', 'per_host'])


# Generated at 2022-06-23 08:44:13.206544
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule(None, None)
    assert mod

# Generated at 2022-06-23 08:44:16.803582
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule({},{})
    assert action._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-23 08:44:25.794351
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.ansible_modlib._text import to_text
    from ansible.template import Templar

    am = ActionModule(dict(action='stats'))
    am._task = dict(args=dict(data=dict(foo="{{ 'bar' }}")))
    am._templar = Templar(loader=None, variables=dict())

    result = am.run(task_vars={})
    assert result['changed'] == False
    assert result['ansible_stats'] == {'data': {'foo': u'bar'}, 'per_host': False, 'aggregate': True}

# Generated at 2022-06-23 08:44:26.381485
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:44:40.404623
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert am is not None
    assert am._task is None
    assert am._connection is None
    assert am._play_context is None
    assert am._loader is None
    assert am._templar is None
    assert am._shared_loader_obj is None
    assert am._task_vars is None
    assert am._tmp is None
    assert am.runner is None
    assert am._cache is None
    assert am._task_vars_cache is None
    assert am._templar._fail_on_undefined is True

    # Since we are not running module_executor, there is no real caching to be done.
    # So, let us test that we can

# Generated at 2022-06-23 08:44:49.978267
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    _task = dict(data=dict(x="{{y}}"))

    _connection = None

    _task_vars = dict(y=42)
    _tmpdir = ''
    _task_path = ''

    am = ActionModule(task=_task, connection=_connection, runner_path='')
    result = am.run(_task_vars=_task_vars, tmp=_tmpdir, task_path=_task_path)
    
    assert result['ansible_stats']['data']['x'] == 42
    assert result['ansible_stats']['aggregate'] == True
    assert result['ansible_stats']['per_host'] == False
    assert result['failed'] == False


# Generated at 2022-06-23 08:44:54.644719
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''Unit test for constructor of class ActionModule
    '''

    ac = ActionModule()
    # Since the method is a class, assertEqual cannot be used.
    # assertEqual(type(ac), ActionModule, 'type of ac is ActionModule')
    assert ac, 'ac is not null'

# Generated at 2022-06-23 08:44:55.882015
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)

# Generated at 2022-06-23 08:45:04.276127
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Test case of `run` method of ActionModule"""
    # create an ActionModule object
    action_module = ActionModule(None, None)
    data = {'foo': 'bar', 'key': 'value'}
    task_vars = {}
    result = action_module.run(None, task_vars)
    changed = False
    truth = {'aggregate': True, 'per_host': False, 'data': {'foo': 'bar', 'key': 'value'}}
    ansible_stats = {'aggregate': True, 'per_host': False, 'data': {'foo': 'bar', 'key': 'value'}}
    assert result['changed'] == changed
    assert result['ansible_stats'] == ansible_stats
    assert result['ansible_stats'] == truth



# Generated at 2022-06-23 08:45:06.146908
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None).run()

# Generated at 2022-06-23 08:45:14.098971
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = dict(
        args=dict(
            data=dict(key1=1, key2=2, value1='str', value2=False),
            per_host=True,
            aggregate=False
        ),
        delegate_to='localhost'
    )

    set_stats_module = ActionModule(task,
                                    connection=dict(),
                                    play_context=dict(),
                                    loader=None,
                                    templar=None,
                                    shared_loader_obj=None)

    assert set_stats_module


# Generated at 2022-06-23 08:45:25.453218
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Return the 'ansible_stats' dict as "result['ansible_facts']"
    # TODO: Make sure all the other things are setup correctly.
    # TODO: Disallow "data:" option

    # The current test will only just check the given examples from
    # the documentation.
    #
    # TODO: Multiple variations for given examples
    # TODO: Test for correct results for invalid/unsupported tasks

    am = ActionModule({}, {}, {}, {}, {})

    # TODO: Setup proper env to mimic the execution context correctly
    # TODO: Return the 'ansible_stats' dict as "result['ansible_facts']"
    # TODO: Make sure all the other things are setup correctly.
    # TODO: Disallow "data:" option

    # test simple example
    result = am.run

# Generated at 2022-06-23 08:45:26.546372
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule()
    assert obj

# Generated at 2022-06-23 08:45:27.392024
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.__doc__ is not None

# Generated at 2022-06-23 08:45:35.747777
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class FakeModule:
        pass

    class FakeTask:
        pass

    class FakePlay:
        pass

    module = FakeModule()
    module.params = {}
    task = FakeTask()
    task.args = {}
    play = FakePlay()
    task.action = "set_stats"
    task._role = None
    task._task = task
    task.no_log = False
    task.loop = 'localhost'
    task.delegate_to = None
    task.run_once = False
    play.playbook = None
    play._play = play
    play.hostvars = {}
    adhoc_loader = None
    play_context = None
    connection = None
    task_vars = {}
    templar = None


# Generated at 2022-06-23 08:45:46.435345
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    import json
    import re
    import os

    action = ActionModule(None, None, False, {})
    # test that valid data is returned
    action.run(task_vars={"inventory_hostname": "localhost", "mysql_server_id_data": "1234", "conn_info": {"host": "localhost"}})

    # test that invalid data is not returned
    action.run(task_vars={"inventory_hostname": "localhost", "mysql_server_id_data": "1234567890123456789012345678901234567890123456789012345678901234"})
    action.run(task_vars={"inventory_hostname": "localhost", "mysql_server_id_data": "12.3"})

# Generated at 2022-06-23 08:45:55.491571
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # set up the defaults
    _VALID_ARGS = frozenset(('aggregate', 'data', 'per_host'))

    def get_parameters(self):
        params = super(ActionModule, self).get_parameters()
        params['valid_args'] = self._VALID_ARGS
        return params

    # set up the mock object
    import ansible.plugins
    am = ansible.plugins.action.ActionModule.ActionModule()
    am.get_parameters = get_parameters.__get__(am, ActionModule)
    assert am.get_parameters()['valid_args'] == _VALID_ARGS


# Generated at 2022-06-23 08:46:02.453823
# Unit test for constructor of class ActionModule
def test_ActionModule():
  action_base = ActionBase()
  action_module = ActionModule(task=action_base._task, connection=action_base._connection, play_context=action_base._play_context, loader=action_base._loader, templar=action_base._templar, shared_loader_obj=action_base._shared_loader_obj)
  assert action_module is not None

# Generated at 2022-06-23 08:46:03.639874
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert 1 == 1

# Generated at 2022-06-23 08:46:10.498803
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_args = {
      "aggregate": True,
      "data": {"a": 1, "b": 2, "c": "{{ c }}"},
      "per_host": True
    }
    mod = ActionModule(dict(task_args=task_args))
    ret = mod.run(dict())
    assert ret == dict(
        ansible_stats=dict(
            aggregate=True,
            data=dict(a=1, b=2, c="{{ c }}"),
            per_host=True
        ),
        changed=False
    )
    # TODO: test with different values and different args

# Generated at 2022-06-23 08:46:11.617508
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-23 08:46:14.511381
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class FakeActionModule(ActionModule):
        """Fake Action Module"""
    action_module = FakeActionModule(None, {}, {}, None)
    assert isinstance(action_module._VALID_ARGS, frozenset)

# Generated at 2022-06-23 08:46:22.864416
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test successful execution
    task = {'action': {'module': 'set_stats', 'args': {'data': {'a': 1, 'b': 2}, 'per_host': True, 'aggregate': False}}}
    task_vars = {}
    result = ActionModule(task, {}).run(task_vars=task_vars)
    assert result == {'changed': False, 'ansible_stats': {'data': {'a': 1, 'b': 2}, 'per_host': True, 'aggregate': False}}


    # Test successful execution
    task = {'action': {'module': 'set_stats', 'args': {'data': '[1,2,3]', 'per_host': 'yes', 'aggregate': 'no'}}}
    task_vars = {}

# Generated at 2022-06-23 08:46:26.913314
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None)
    assert action._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host')), "_VALID_ARGS not set properly in constructor of action module"

# Generated at 2022-06-23 08:46:28.137436
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)

# Generated at 2022-06-23 08:46:35.966647
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    This test case is used to test the run method of class ActionModule
    """
    task_vars = dict()
    hostvars = dict()
    set_module_args = {}
    module_return_values = dict()
    module_return_values["failed"] = False
    module_return_values["changed"] = False
    module_return_values["msg"] = "The 'data' option needs to be a dictionary/hash"
    expected_result = {}
    expected_result["failed"] = True
    expected_result["changed"] = False
    expected_result["msg"] = "The 'data' option needs to be a dictionary/hash"
    module = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=None, templar=None, shared_loader_obj=None)
    mock_

# Generated at 2022-06-23 08:46:42.899851
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys
    import __builtin__

    class __builtin__:
        class str:
            pass
        class object:
            pass

    class str(str):
        pass

    class object(object):
        pass

    class dict(dict):
        pass

    class TestActionModule(ActionModule):
        pass

    global __builtin__
    setattr(__builtin__, 'str', str)
    setattr(__builtin__, 'object', object)
    setattr(__builtin__, 'dict', dict)

    import ansible.plugins.action
    setattr(ansible.plugins.action, 'ActionBase', object)

    sys.modules["ansible.module_utils.six"] = object

    a = TestActionModule('test_data', [], dict())

# Generated at 2022-06-23 08:46:44.154698
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)

# Generated at 2022-06-23 08:46:54.322831
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # AnsibleModule implements AnsibleAbstractClass,
    # so initialize AnsibleModule object instead of ActionBase object
    from ansible.module_utils.basic import AnsibleModule

    module_args = dict(
        data=dict(
            data1='10',
            data2='20',
            data3='30'
        ),
        per_host=True,
        aggregate=False,
    )
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    action_module = ActionModule(
        module,
        task=dict(
            args=module_args
        )
    )

    result = action_module.run(
        tmp=None,
        task_vars=dict()
    )

    assert result['changed'] == False

# Generated at 2022-06-23 08:46:54.991296
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 08:47:04.393501
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class Module:
        def __init__(self):
            self.params = {}
    class Task:
        def __init__(self):
            self.args = {}

    am = ActionModule()
    am._task = Task()
    am._task.args = {'data': {'dummy_key': 'dummy_value'}}
    am.run()

    am.set_spec(Module())
    am.set_loader(None)
    am._task.args = {'data': {'dummy_key': 'dummy_value', 'per_host': False}, 'per_host': False}
    am.run()


# Generated at 2022-06-23 08:47:10.373117
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # In the given module, 'result' is the return value of run()
    result = {'failed': False, 'msg': '', 'ansible_stats': {'data': {u'failed': True}, 'per_host': False, 'aggregate': True}}
    # assert the return value of method 'run()'
    assert result == ActionModule().run({'data': '{{ status == "failed" }}', 'aggregate': False, 'per_host': False},
                                        {'status': 'failed'})

# Generated at 2022-06-23 08:47:14.029549
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Test ActionModule class constructor """
    taction = ActionModule(None, {'task': 'test_task'})
    assert taction._task.name == 'test_task'

# Generated at 2022-06-23 08:47:18.348262
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test mock for Task
    # Task.args dict contains --extra-vars from command line
    args = dict()
    args['data'] = dict()
    args['data']['a.b'] = 'c'
    args['data']['$a'] = 'b'
    args['data']['a*'] = 'd'
    args['data']['d?'] = 'e'
    args['data']['a!'] = 'f'
    args['data']['f3'] = 'g'
    args['data']['$'] = 'h'
    args['data'][' '] = 'i'
    args['data']['i'] = 'j'
    args['data']['_a'] = 'k'

# Generated at 2022-06-23 08:47:19.050029
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ActionModule()

# Generated at 2022-06-23 08:47:21.255823
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    return

# Generated at 2022-06-23 08:47:23.273545
# Unit test for constructor of class ActionModule
def test_ActionModule():
    act = ActionModule(None, None)
    assert act

# Generated at 2022-06-23 08:47:34.024845
# Unit test for method run of class ActionModule
def test_ActionModule_run():
        # Test method run with valid data
        data = {'data':{'key1':'val1', 'key2':'val2'}, 'per_host':True, 'aggregate':True}
        stats = {'data': {'key1':'val1', 'key2':'val2'}, 'per_host': True, 'aggregate': True}
        args = {'data':{'key1':'val1', 'key2':'val2'}, 'per_host':'true', 'aggregate':'true'}
        expected_result = {'changed': False, 'ansible_stats': stats}
        mod = ActionModule()
        mod.set_task(data)
        result = mod.run(tmp='/tmp', task_vars={'vars':{'args':args}})

# Generated at 2022-06-23 08:47:36.787763
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Make sure that instantiating the class does not throw an exception.
    action_module_class = ActionModule
    action_module_class(load_name='test_action_module', task=dict())

# Generated at 2022-06-23 08:47:48.568279
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test (with pytest) for method run of class ActionModule"""
    # Initialization
    ansible_result = dict()
    ansible_result['changed'] = False
    ansible_result['ansible_stats'] = dict()
    ansible_result['ansible_stats']['data'] = dict()
    ansible_stats_dict = dict()
    ansible_stats_dict['aggregate'] = True
    ansible_stats_dict['per_host'] = False
    ansible_stats_dict['data'] = dict()
    ansible_stats_dict['data']['foo'] = 12
    ansible_stats_dict['data']['bar'] = 3
    ansible_result['ansible_stats'] = ansible_stats_dict

    # Init of mocks
    task_vars = dict()

# Generated at 2022-06-23 08:47:58.161924
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # mock container for module
    set_stats_class_mock = {
        '_handle_exception': lambda s, e: '{error: msg}',
    }
    # instance of class
    set_stats_instance_mock = {}
    # mock object built from the class
    set_stats_class_mock_obj = mock.Mock(**set_stats_class_mock)
    # instance of mock object
    set_stats_instance_mock_obj = set_stats_class_mock_obj.return_value


# Generated at 2022-06-23 08:48:01.152536
# Unit test for constructor of class ActionModule
def test_ActionModule():

    a = ActionModule(None, None)

    assert len(a.VALID_ARGS) == 3
    assert 'aggregate' in a.VALID_ARGS
    assert 'data' in a.VALID_ARGS
    assert 'per_host' in a.VALID_ARGS


# Generated at 2022-06-23 08:48:10.507368
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os

    # Setup the object
    am = ActionModule()
    am._task = object()
    am._task.action = 'test_action'
    am._task.args = dict()
    am._task.args['data'] = dict()
    am._task.args['data'][1] = 1
    am._task.args['data'][2] = 2
    am._task.args['data'][3] = 3
    am._task.args['data'][4] = 4
    am._task.args['data']['five'] = 5
    am._task.args['per_host'] = True
    am._task.args['aggregate'] = True
    am._shared_loader_obj = object()
    am._loader = object()
    am._templar = object()
    am._templ

# Generated at 2022-06-23 08:48:17.496331
# Unit test for constructor of class ActionModule
def test_ActionModule():
    allargs = {}
    module = ActionModule(None, allargs)
    assert module.TRANSFERS_FILES is False, 'Transfers files should be False'
    assert module._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host')), 'Should have a copy of valid args'



# Generated at 2022-06-23 08:48:18.023185
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:48:21.884143
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(action='', name='', job_id=0, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module.TRANSFERS_FILES == False
    assert module._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))


# Generated at 2022-06-23 08:48:27.248019
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager

    from io import StringIO
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar


    class TestTaskQueueManager(TaskQueueManager):
        def __init__(self, *args, **kwargs):
            self.results = []
            self.options = kwargs.get('options', {})
            self._hostvars_plugins = []

# Generated at 2022-06-23 08:48:30.693364
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test imports
    from ansible.plugins.action.set_stats import ActionModule
    module = ActionModule(None, None, None)
    assert(module)

# Generated at 2022-06-23 08:48:37.556229
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class DummyV2Task(object):
        def __init__(self):
            self.args = {}

    class DummyTask(object):
        def __init__(self):
            self._task = DummyV2Task()

    class DummyModuleUtils(object):
        class AnsibleModule(object):
            def __init__(self):
                pass

            def fail_json(self, *args, **kwargs):
                pass

    class DummyVars(object):
        def __init__(self):
            self.module_utils = DummyModuleUtils()

        def _lower_keys_recursive(self, value):
            return value

    class DummyTemplar(object):
        def __init__(self):
            pass

        def template(self, *args, **kwargs):
            return

# Generated at 2022-06-23 08:48:47.376918
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Unit test for method run of class ActionModule
    """

    # Mock imports

    # From Ansible Task Manager
    Task = mock.MagicMock()
    task = Task()
    task.args = {'data': {'key1': 'value1'},
                 'per_host': True,
                 'aggregate': True}
    task.async_val = 15

    # From Ansible plugin play
    PlayContext = mock.MagicMock()
    play_context = PlayContext()

    # From Ansible actions
    AnsibleModule = mock.MagicMock()
    ansible_module = AnsibleModule()

    # Create a class
    class TestActionModule(ActionModule):
        _connection = "test"
        _task = task
        _play_context = play_context
        _ansible_module = ans

# Generated at 2022-06-23 08:48:54.362829
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.utils.vars import merge_hash
    from ansible.plugins import action

    from ansible.playbook.task import Task

    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager

    class AnsibleModuleFake:
        """ Class to fake a AnsibleModule object """

        def __init__(self, **kwargs):
            self.params = {}
            for k, v in kwargs.items():
                self.params[k] = v
            self.params = kwargs

    class AnsibleActionFake(ActionModule):
        """ Class to fake a ActionModule object """


# Generated at 2022-06-23 08:49:03.659708
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # set up mock objects
    mock_task = MagicMock()
    mock_task._ds = dict()

    # create instance of ActionModule without calling init
    action_module = ActionModule(task=mock_task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # call constructor of class ActionModule
    action_module.__init__(task=mock_task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # test that the instance is of class ActionModule
    isinstance(action_module, ActionModule)

# Generated at 2022-06-23 08:49:11.917483
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule."""
    import sys
    import unittest

    class TestException(Exception):
        """Test Exception."""
        pass

    class MockTemplar(object):
        """Class to mock Templar."""
        def __init__(self, value):
            """init MockTemplar."""
            self.value = value

        def template(self, value, convert_bare=True, fail_on_undefined=False):
            """template method."""
            return self.value

    class MockActionBase(object):
        """Class to mock ActionBase."""
        def __init__(self, task_args=None, task_vars=None, result=None):
            """init MockActionBase."""
            self.task_args = task_args

# Generated at 2022-06-23 08:49:20.368519
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''

    import ansible.plugins.action
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.template
    import ansible.utils.vars

    am = ansible.plugins.action.ActionModule(
        ansible.playbook.task.Task(
            ansible.playbook.play.Play().load(
                dict(
                    name="test play",
                    hosts='',
                    gather_facts='no',
                    tasks=[
                        dict(action=dict(module="set_stats", args=dict(data=dict(a=1, b=2, c="{{n}}")), aggregate=True, per_host=True))
                    ]
                )
            )
        )
    )

    am._tem

# Generated at 2022-06-23 08:49:31.756867
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Instantiate the instance of class ActionModule
    # with valid args
    testAction = ActionModule(task=dict(args=dict(aggregate=True, data=dict(a="1", b="2"), per_host=True)))
    assert testAction.run()

    # Instantiate the instance of class ActionModule
    # with invalid args
    testAction = ActionModule(task=dict(args=dict(bad_arg="value")))
    assert testAction.run()["failed"]