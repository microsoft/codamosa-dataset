

# Generated at 2022-06-23 08:39:36.762107
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # check the following cases:
    #   - data = 'foo'
    #   - data = dict(foo = 'bar')
    #   - data = dict(baz = True)
    #   - data = dict(bar = False)
    #   - data = dict(boo = 1)
    #   - data = dict(bar = 1)
    #   - per_host = 'foo'
    #   - aggregate = 'foo'

    fake_task = {}
    fake_task_vars = {}


# Generated at 2022-06-23 08:39:42.137211
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Make a dummy host record to test with
    host = {
        'name': "test-host.example.com",
        'groups': ['group1', 'group2']
    }

    # Make a dummy task record to test with
    task = {
        'name': 'test task',
        'action': 'set_stats',
        'args': {},
    }

    # Create a dummy executor and add the host record
    executor = ActionModule.Executor(None, None, None)
    executor.add_host(host)

    def templar_template(data, convert_bare=False, fail_on_undefined=True):
        return data

    # Patch templar's template method
    executor._templar.template = templar_template

    # Set _task to the dummy task record


# Generated at 2022-06-23 08:39:47.795564
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    ActionModule class run method returns
    result['ansible_stats'] of dictionary with
    keys 'data', 'per_host', 'aggregate'
    """

    result = ActionModule.run({}, {})

    assert isinstance(result, dict)
    assert isinstance(result['ansible_stats'], dict)
    assert 'data' in result['ansible_stats'].keys()
    assert 'per_host' in result['ansible_stats'].keys()
    assert 'aggregate' in result['ansible_stats'].keys()


# Generated at 2022-06-23 08:39:52.445061
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print('Testing ActionModule constructor')
    action = ActionModule()
    print(action._VALID_ARGS)

test_ActionModule()

# Generated at 2022-06-23 08:40:02.065456
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule(task=dict(args=dict(data=5, aggregate=True, per_host=False)))
    assert am.run(task_vars={}) == dict(
        changed=False,
        ansible_stats=dict(data=5, aggregate=True, per_host=False)
    )

    am = ActionModule(task=dict(args=dict(data={'a': 'b'}, aggregate=True, per_host=False)))
    assert am.run(task_vars={}) == dict(
        changed=False,
        ansible_stats=dict(data={'a': 'b'}, aggregate=True, per_host=False)
    )

    am = ActionModule(task=dict(args=dict(data='{{ x }}', aggregate=True, per_host=False)))

# Generated at 2022-06-23 08:40:02.717607
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()

# Generated at 2022-06-23 08:40:11.385376
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.parsing.convert_bool import boolean

    task = {"action": {"__ansible_module__": "set_stats"},
            "args": {"data": {"foo": "ok", "bar": "pong"}},
            "task": {"name": "set_stats"}}

    action = ActionModule({}, task, {})

    task = {"action": {"__ansible_module__": "set_stats"},
           "args": {"data": {"foo": "ok", "bar": "pong"},
                    "aggregate": True},
           "task": {"name": "set_stats"}}

    action = ActionModule({}, task, {})


# Generated at 2022-06-23 08:40:19.989104
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test the method run of class ActionModule
    """
    from ansible.module_utils._text import to_text
    from ansible import module_utils
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils import basic
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.errors import AnsibleParserError
    from ansible.plugins.action import ActionBase


# Generated at 2022-06-23 08:40:21.171449
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Unit test code
    pass

# Generated at 2022-06-23 08:40:26.575898
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(dict(tmp=None, task_vars=None), task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action.TRANSFERS_FILES == False
    assert action._VALID_ARGS == frozenset(['aggregate', 'data', 'per_host'])

# Generated at 2022-06-23 08:40:29.033327
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action._VALID_ARGS == frozenset(['aggregate', 'data', 'per_host'])
    assert action.TRANSFERS_FILES is False

# Generated at 2022-06-23 08:40:36.150248
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test with data option
    module_args1 = {'data': {'x': 'y', 'a': 'b'}, 'per_host': 'yes', 'aggregate': 'no'}
    action = ActionModule(None, module_args1, None, None, None)

    # Test with template
    module_args2 = {'data': '{{ ansible_os_family }}'}
    action = ActionModule(None, module_args2, None, None, None)

# Generated at 2022-06-23 08:40:42.789475
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test 1
    hostvars = {"ansible_stats": {"data": {"a": 20}}}
    task_args = {
        "data": {"b": "a"}}
    task = {"args": task_args}
    tmp = None
    am = ActionModule(task=task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    res = am.run(task_vars=hostvars)
    assert res["ansible_stats"] == {'data': {}, 'per_host': False, 'aggregate': True}
    assert res["failed"] == True
    assert res["msg"] == "The variable name 'data' is not valid. Variables must start with a letter or underscore character, and contain only letters, numbers and underscores."

    # Test 2


# Generated at 2022-06-23 08:40:53.613202
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # data is a dictionary
    data = {'name' : 'Ansible', 'version' : '1.9'}

    # task_vars is a dict
    task_vars = dict()

    # ansible_stats is a dict
    ansible_stats = {'data' : data, 'per_host' : False, 'aggregate' : True}

    action_module_obj = ActionModule(1, 2, 3, 2, 6, 2)
    result = action_module_obj.run(None, task_vars)

    assert result['ansible_stats']['data']['name'] == 'Ansible'
    assert result['ansible_stats']['data']['version'] == '1.9'
    assert result['ansible_stats']['per_host'] == False

# Generated at 2022-06-23 08:41:04.373604
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule(None)
    mod.set_loader()

    task_vars = dict()
    task_vars['foo'] = 'bar'
    desired_results = {'msg': "The 'data' option needs to be a dictionary/hash", 'failed': True}
    no_data_args = {'data': ['foo']}
    actual_results = mod.run(task_vars=task_vars, tmp=None, **no_data_args)

    assert desired_results == actual_results

    desired_results = {'msg': "The variable name 'bad%key' is not valid. Variables must start with a letter or underscore character, and contain only letters, numbers and underscores.", 'failed': True}
    bad_key_args = {'data': {'bad%key': 'foo'}}
    actual_results

# Generated at 2022-06-23 08:41:15.742824
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # define task
    play_source = dict(
        name = "Ansible Play",
        hosts = "all",
        gather_facts = "no",
        tasks = [
            dict(action=dict(module=dict(name='set_stats', args=dict(data=dict(mystat=1)))))
        ]
    )

    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)

   

# Generated at 2022-06-23 08:41:16.772359
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule, object)

# Generated at 2022-06-23 08:41:25.288299
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

    # Should return True with no exception
    result = action_module.run()
    assert result['changed'] == False
    assert result['ff'] == 5
    assert result['msg'] == 'non-zero return code'
    assert result['rc'] == 1
    assert result['stderr'] == 'stderr line 1\nstderr line 2'
    assert result['stderr_lines'] == ['stderr line 1', 'stderr line 2']
    assert result['stdout'] == 'stdout line 1\nstdout line 2'
    assert result['stdout_lines'] == ['stdout line 1', 'stdout line 2']

# Generated at 2022-06-23 08:41:32.672682
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class MockTask(object):
        def __init__(self):
            self.args = {}
            self.args['data'] = {}

    from ActionModule import ActionModule
    action_module = ActionModule(task=MockTask(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None
    assert action_module.TRANSFERS_FILES == False
    assert action_module._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))

# Generated at 2022-06-23 08:41:36.204949
# Unit test for constructor of class ActionModule
def test_ActionModule():
    b_obj = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=None, templar=None, shared_loader_obj=None)
    return b_obj

# Generated at 2022-06-23 08:41:38.692148
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    # TODO: check if this version is supported or not.
    assert sys.version_info.major == 2

# Generated at 2022-06-23 08:41:46.962863
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module._task = Task()
    action_module._task.args = {'per_host':True}
    action_module.run()
    action_module._task.args = {'data': {'name1': 'value1', 'name2':'value2'}}
    action_module.run()
    action_module._task.args = {'data': {'name1': 'value1', 'name2':'value2'}, 'per_host': True, 'aggregate': False}
    action_module.run()
    action_module._task.args = {'data': {'name1': 'value1', 'name2':'value2'}, 'per_host': False, 'aggregate': False}
    action_module.run()
    action_module._task.args

# Generated at 2022-06-23 08:41:56.109723
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task = dict(
        name='test_ActionModule_run',
        args=dict(
            data=dict(
                test_value=10,
                test_value2=20,
            ),
            per_host=True,
            aggregate=True
        )
    )

    task_ds = dict()
    task_ds['ansible_facts'] = dict()
    task_ds['ansible_facts']['ansible_lsb'] = dict()
    task_ds['ansible_facts']['ansible_lsb']['distcodename'] = 'precise'
    task_ds['ansible_facts']['ansible_processor_cores'] = '2'

    tmp = None
    python_version = 2.7
    templar = dict()

# Generated at 2022-06-23 08:41:57.972800
# Unit test for constructor of class ActionModule
def test_ActionModule():
    data = ActionModule('test', {}, {})
    assert isinstance(data, ActionModule)


# Generated at 2022-06-23 08:42:01.378002
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(
        task=dict(action=dict(module_name="test", module_args="test")),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict())
    assert am is not None

# Generated at 2022-06-23 08:42:06.811766
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None
    assert action_module._VALID_ARGS == {'aggregate', 'data', 'per_host'}

# Generated at 2022-06-23 08:42:10.909841
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create an instance of the module
    module = ActionModule(
        task=dict(
            args=dict(
                per_host=True,
                aggregate=False,
                data=dict(key1='value1', key2='value2')
            )
        ),
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    # Check module instance is created successfully
    assert module is not None

# Generated at 2022-06-23 08:42:18.034234
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Create mock_task
    mock_task = MagicMock()
    mock_task.args = {'data': {'ansible_python_version': '2.6.9', 'ansible_distribution': 'CentOS'},
                      'per_host': True,
                      'aggregate': False}

    # Create mock_templar
    mock_templar = MagicMock()
    mock_templar.return_value = {'ansible_python_version': '2.6.9', 'ansible_distribution': 'CentOS'}

    # Mock task_vars
    task_vars = {'inventory_hostname': 'localhost'}
    # Mock result
    result = dict(failed=False, changed=False)

    # Start the test

# Generated at 2022-06-23 08:42:22.666378
# Unit test for constructor of class ActionModule
def test_ActionModule():
    global _VALID_ARGS
    _VALID_ARGS = frozenset(('aggregate', 'data', 'per_host'))

    assert _VALID_ARGS == ('aggregate', 'data', 'per_host')

# Generated at 2022-06-23 08:42:24.991532
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(1, 2)
    assert am._shared_loader_obj == 1
    assert am._task == 2



# Generated at 2022-06-23 08:42:36.095527
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    t = Task()
    task_vars = dict()

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost, '])
    play_context = PlayContext()
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    task_vars['ansible_ssh_host'] = 'localhost'
    # Run Method
    am = ActionModule(t, play_context, task_vars, variable_manager)
    result = am.run(task_vars=task_vars)

   

# Generated at 2022-06-23 08:42:46.802528
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tm = ActionModule()
    result = tm.run(None, None)

    assert 'changed' in result
    assert result['changed'] == False

    assert 'ansible_stats' in result
    assert isinstance(result['ansible_stats'], dict)

    assert 'data' in result['ansible_stats']
    assert isinstance(result['ansible_stats']['data'], dict)

    assert 'per_host' in result['ansible_stats']
    assert result['ansible_stats']['per_host'] == False

    assert 'aggregate' in result['ansible_stats']
    assert result['ansible_stats']['aggregate'] == True

    result = tm.run(None, {'a': {'b': 'c'}})

# Generated at 2022-06-23 08:42:57.014820
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class FakeActionModule:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    fake_loader = FakeActionModule()
    fake_playbook = FakeActionModule(task_vars={})
    fake_task = FakeActionModule(args={})
    fake_ds = FakeActionModule(basedir='/fake/playbook/dir')
    fake_tmp = '/fake/tmp/dir'

    am = ActionModule(
        fake_loader,
        fake_playbook,
        fake_ds,
        fake_task,
        fake_tmp
    )
    assert "ActionModule" in str(am)

# Generated at 2022-06-23 08:43:02.412760
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # create mocks
    module_execute_returns = None
    module_execute_exception = None
    module_execute_exception_message = None
    module_execute_not_implemented_function = False
    tmp = None
    task_vars = None
    
    # mock the action base class
    class TestActionBase(ActionBase):
        def run(self, tmp, task_vars):
            if module_execute_not_implemented_function:
                raise NotImplementedError
            if module_execute_exception:
                raise Exception(module_execute_exception_message)
            return module_execute_returns
    
    # create the object under test
    action_module = TestActionBase()
    action_module.ActionBase = TestActionBase
    action_module._task = object()
   

# Generated at 2022-06-23 08:43:08.008343
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None)

    if not isinstance(action._task.args, dict):
        raise AssertionError('args not in dict')
    if not isinstance(action.TRANSFERS_FILES, bool):
        raise AssertionError('TRANSFERS_FILES not in bool')

# Generated at 2022-06-23 08:43:10.942379
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-23 08:43:17.750340
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # this is the func
    action_module = ActionModule()

    # let's define the data (I'm using mock data)
    args = {'data': {'myvar': 'myval'}, 'aggregate': True, 'per_host': True}
    tmp = None
    task_vars = {'hostvars': {'host1': {'var1': 'val1'}}}
    result = action_module.run(tmp=tmp, task_vars=task_vars)
    assert not result['failed']
    assert result['changed'] is False
    assert type(result['ansible_stats']['data']) is dict
    assert result['ansible_stats']['data']['myvar'] == 'myval'

    # check for errors
    args = {'data': 'bogus'}


# Generated at 2022-06-23 08:43:26.492947
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test case for method run of class ActionModule
    #print("\n test_ActionModule_run:")

    task_vars = dict()

    from ansible.parsing.vault import VaultLib
    from ansible.playbook.task import Task
    from ansible.template import Templar

    # instantiation of an ActionModule object
    am = ActionModule(Task(), dict())

    # call the run method of class ActionModule
    #print(('VaultLib.unvault_block(', task_vars, '):', VaultLib.unvault_block(task_vars)))

    result = am.run(tmp='', task_vars=VaultLib.unvault_block(task_vars))
    #print(('result:', result))
    #print(result['ansible_stats']['data

# Generated at 2022-06-23 08:43:29.603300
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, dict(role_namespace='test_role'), 'test_action', None)
    assert action.role_namespace == 'test_role'

# Generated at 2022-06-23 08:43:32.561177
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    play_context = PlayContext()
    play_context.connection = 'local'

    mytask = Task()

# Generated at 2022-06-23 08:43:43.376951
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.stats import AggregateStats
    from ansible.executor.task_executor import TaskExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import action_loader
    import os
    import json

    class AnsibleModuleMock:
        pass

    class AnsibleRunnerMock:
        def __init__(self, inventory, variable_manager, loader, passwords):
            self.inventory

# Generated at 2022-06-23 08:43:44.862709
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # constructor of class ActionModule
    ActionModule()


# Generated at 2022-06-23 08:43:55.931198
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.parsing.convert_bool import boolean
    assert not boolean(None)
    assert not boolean('', strict=False)
    assert not boolean('False', strict=False)
    assert not boolean('false', strict=False)
    assert not boolean('off', strict=False)
    assert not boolean('NO', strict=False)
    assert not boolean('no', strict=False)
    assert not boolean('n', strict=False)
    assert not boolean('0', strict=False)
    assert not boolean(0)
    assert not boolean(0.0)

    # strict
    assert boolean('True', strict=True)
    assert boolean('true', strict=True)
    assert boolean('on', strict=True)
    assert boolean('YES', strict=True)
    assert boolean('yes', strict=True)

# Generated at 2022-06-23 08:44:07.017968
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import sys
    if sys.version_info[0] == 2:
        # python 2
        from ansible.compat.tests import unittest
        from ansible.compat.tests.mock import patch, Mock, MagicMock, call
    else:
        # python 3
        from unittest import TestCase
        from unittest.mock import patch, Mock, MagicMock, call
    import os

    class TestActionModule(unittest.TestCase, ActionModule):
        pass

    mock_am = MagicMock()
    mock_am._connection = MagicMock()
    mock_am._loader = Mock()
    mock_am._templar = Mock()
    mock_am._shared_loader_obj = Mock()
    mock_am._task = Mock()
    mock_am._task.args = {}

# Generated at 2022-06-23 08:44:16.886294
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test of method run of class ActionModule
    """
    module = ActionModule()
    module._templar = MockTemplar()
    module._task = MockTask()

    module._task.args = {'aggregate': 'True', 'data': {'foo': 'bar', 'baz': '{{ test_var }}'}, 'per_host': 'False'}
    result = module.run(tmp=None, task_vars=None)

    # Check that result is a dictionary
    assert isinstance(result, dict)

    # Check that result is a dictionary
    assert result['changed'] == False

    # Check that result is a dictionary

# Generated at 2022-06-23 08:44:27.691273
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test method run of class ActionModule
    """
    module = ActionModule()
    module._task = dict(action=dict(action='set_stats', data=dict(a='b'), per_host=True, aggregate=True))
    module._task_vars = dict()
    module._templar = dict()
    module._templar.template = dict()
    def mock_template(arg,convert_bare,fail_on_undefined):
        """
        Mock method for _templar.template()
        """
        if isinstance(arg, dict):
            return dict(arg)
        else:
            return arg
    module._templar.template = mock_template

    result = module.run(tmp='', task_vars=dict())
    # NOTE: function run() returns dict
    assert result

# Generated at 2022-06-23 08:44:35.251985
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # just for unit test
    import copy

    def _get_dict_from_obj(obj, attr):
        if isinstance(obj, object):
            return getattr(obj, attr, None)
        else:
            return obj.get(attr, None)

    from ansible.module_utils._text import to_text
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import open_url
    from ansible.module_utils.parsing.convert_bool import boolean

    def _get_module():
        argspec = dict(
            aggregate=dict(type='bool', default=True),
            data=dict(type='dict'),
            per_host=dict(type='bool', default=False)
        )


# Generated at 2022-06-23 08:44:43.953118
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # setup mocks
    mod = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    def test_templar(val, convert_bare=False, fail_on_undefined=True):
        return val
    mod._templar = test_templar

    # test
    results = mod.run()

    # assert
    assert results is not None
    assert results['ansible_stats'] is not None
    assert results['ansible_stats']['data'] is not None
    assert not bool(results['ansible_stats']['data'])
    assert results['ansible_stats']['per_host'] and isinstance(results['ansible_stats']['per_host'], bool)

# Generated at 2022-06-23 08:44:46.765385
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Unit test for constructor of class ActionModule."""
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert action_module is not None

# Generated at 2022-06-23 08:44:51.347540
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action.name == 'set_stats'
    assert action.version == (1, 0, 0)
    assert action.flags == set()
    assert action.init is not None

# Generated at 2022-06-23 08:45:00.959871
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arrange
    import ansible.plugins.action
    import ansible.template
    import ansible.parsing.yaml.objects
    test_action_module = ansible.plugins.action.ActionModule(
        task=ansible.parsing.yaml.objects.AnsibleTask(),
        connection=None,
        play_context=None,
        loader=None,
        templar=ansible.template.Templar(),
        shared_loader_obj=None
    )

    templated_data = {
        'templated_data': '{{ "templated_value" }}'
    }
    templated_data_2 = {
        'templated_data': '{{ some_var }}'
    }

    # Act
    templated_data_result = test_action

# Generated at 2022-06-23 08:45:08.591112
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.playbook.task import Task
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.manager import VariableManager

    def get_vars(loader, path, entities, cache=True):
        return {"hostvars": {"host1": {"x": 1}, "host2": {"x": 2}}}

    loader = None
    templar = None
    task = Task()
    task.register_loader = None
    task.vars = UnsafeProxy({})
    task._templar = templar
    task._variable_manager = VariableManager(loader=loader, inventory=None)

# Generated at 2022-06-23 08:45:15.374684
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule(dict(task=dict(args=dict(data=dict(a=1,b=2,c=3,d=4,e=5))), _ansible_tmpdir='/tmp',_ansible_pkg_mgr=None, _ansible_version=True))
    data = action.run()
    assert data['ansible_stats'] == {'aggregate': True, 'data': {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}, 'per_host': False}

# Generated at 2022-06-23 08:45:16.096061
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-23 08:45:26.795028
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible import context
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    context.CLIARGS = {'module_path': '', 'connection': 'local'}

    loader, inventory, variable_manager = (None, None, VariableManager())
    task = TaskInclude('set_stats', {'data': {'a': 'b', 'c': 'd'}}, loader=loader)
    templar = Templar(loader=loader, variables=variable_manager)
    am = ActionModule(task, templar, loader=loader, shared_loader_obj=loader, variable_manager=variable_manager)

    am.run(tmp=None, task_vars=None)

# Generated at 2022-06-23 08:45:28.435166
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert issubclass(ActionModule, ActionBase)

# Generated at 2022-06-23 08:45:31.436892
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test creation of instance without any options
    a = ActionModule({})
    assert a._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))
    assert a.TRANSFERS_FILES == False

# Generated at 2022-06-23 08:45:43.927045
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # First test to create a correct ansible_stats
    module = ActionModule()
    module._task = 'Any string'
    module._task.args = {
        'data': {
            'test_var_1': 5,
            'test_var_2': 7
        },
        'per_host': True,
        'aggregate': False
    }
    tmp = {'tmp': 'Any String'}
    task_vars = {'tmp': 'Any String'}
    result = module.run(tmp, task_vars)

    # Test if the result expected is returned
    assert result['ansible_stats'] == {'per_host': True, 'aggregate': False, 'data': {'test_var_1': 5, 'test_var_2': 7}}


    # Second test to create a wrong ans

# Generated at 2022-06-23 08:45:45.561326
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert(ActionModule is not None)



# Generated at 2022-06-23 08:45:56.172436
# Unit test for constructor of class ActionModule
def test_ActionModule():

    from ansible.plugins import action
    from ansible.module_utils.six import string_types
    from ansible.utils.vars import isidentifier
    import ansible.module_utils.parsing.convert_bool


    # Create raw object for action class

# Generated at 2022-06-23 08:46:00.284842
# Unit test for constructor of class ActionModule
def test_ActionModule():

    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am is not None

# Generated at 2022-06-23 08:46:10.035353
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import json
    import unittest
    import sys
    import os
    import tempfile
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    # Mode 0644:
    MODE_0644 = 292
    # Mode 0755
    MODE_0755 = 493

    # This is path to the inventory file
    #  You will need to change this path to your
    # inventory file location.
    test_inventory_path = "/home/matc/work/ansible/inventory"
    # Create a task.
    task = dict(action=dict(module="set_stats",
                            args=dict(data=dict(foo=1, bar=2))))
    # Create a play.

# Generated at 2022-06-23 08:46:19.654469
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    vars_manager = VariableManager()
    inventory_manager = InventoryManager(vars_manager=vars_manager, loader=None, sources=[])
    inventory_manager.set_inventory("all")

    task = Task()

# Generated at 2022-06-23 08:46:20.872077
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None)
    assert am is not None

# Generated at 2022-06-23 08:46:32.514251
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule()
    tmp = None

    task_vars = dict()

    # test 1
    task_vars['ansible_stats'] = dict()
    task_vars['ansible_stats']['aggregate'] = True
    task_vars['ansible_stats']['data'] = {'test1': 'test1'}
    task_vars['ansible_stats']['per_host'] = False

    result = mod.run(tmp, task_vars)

    assert result['changed'] == False
    data = result['ansible_stats']['data']
    assert data['test1'] == 'test1'

    # test 2
    task_vars['ansible_stats'] = dict()
    task_vars['ansible_stats']['aggregate'] = False
   

# Generated at 2022-06-23 08:46:33.672232
# Unit test for constructor of class ActionModule
def test_ActionModule():

    action = ActionModule()

    assert action is not None

# Generated at 2022-06-23 08:46:36.746664
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None), ActionModule)


# Generated at 2022-06-23 08:46:49.850923
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Test that creating an ActionModule class works as expected"""

    # fake context
    context = {'ANSIBLE_MODULE_ARGS': {}}

    # create a pseudo action module from the context
    action_module = ActionModule(context=context)

    assert isinstance(action_module, ActionModule)
    assert isinstance(action_module._task, dict)
    assert isinstance(action_module._connection, dict)
    assert isinstance(action_module._play_context, dict)
    assert isinstance(action_module._loader, object)
    assert isinstance(action_module._templar, object)
    assert isinstance(action_module._shared_loader_obj, object)

    # test the 'data' dictionary
    assert isinstance(action_module._task.args, dict)
    assert action_module._task.args

# Generated at 2022-06-23 08:47:03.616067
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule(runner=None, task=None)
    assert not am.run()

    am = ActionModule(runner=None, task=MagicMock(
        args={"data": {"test": "data"}, "aggregate": True, "per_host": True}))
    assert am.run()["changed"] == False
    assert am.run()["ansible_stats"]["data"]["test"] == "data"
    assert am.run()["ansible_stats"]["aggregate"] == True
    assert am.run()["ansible_stats"]["per_host"] == True

    am = ActionModule(runner=None, task=MagicMock(
        args={"data": "{{ test }}", "aggregate": None, "per_host": None}))

    assert am.run()["changed"] == False

# Generated at 2022-06-23 08:47:08.780568
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(ActionModule.run, ActionModule._VALID_ARGS, False, False, False)
    assert action_module.run_args == {'vars': dict(), 'tmp': None}
    assert action_module.supports_check_mode is False
    assert action_module.bypass_checks is False
    assert action_module.no_log is False

# Generated at 2022-06-23 08:47:14.233730
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.parsing.convert_bool import boolean
    action_module = ActionModule()

    assert action_module._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))
    assert action_module.TRANSFERS_FILES == False

    tmp = None
    task_vars = dict()

    result = action_module.run(tmp, task_vars)

    assert result['ansible_stats']['data'] == {}
    assert result['ansible_stats']['per_host'] == False
    assert result['ansible_stats']['aggregate'] == True


# Generated at 2022-06-23 08:47:16.978618
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    This function is used to test ActionModule constructor.
    """

    action = ActionModule()

    print (action.__doc__)
    print (action.TRANSFERS_FILES)
    print (action._VALID_ARGS)

# Generated at 2022-06-23 08:47:26.932035
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # test calling the class constructor
    # test passing a task object
    from ansible.playbook.task import Task
    task = Task()
    task.args = {'data': {'x': 'foo'}}
    set_stats_obj = ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert set_stats_obj.run(task_vars={})['ansible_stats'] == {'data': {'x': 'foo'}, 'per_host': False, 'aggregate': True}
    task.args = {'data': {'x': 'foo', 'y': 'bar'}, 'per_host': True, 'aggregate': False}

# Generated at 2022-06-23 08:47:37.812400
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    loader = DictDataLoader({})
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'test_var': 'test_value'}
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='my_hostname')
    host = inventory.get_host(inventory.hosts.keys()[0])
    t = Task()
    t.set_loader(loader=loader)
    t._hosts = [host]
    t.args = {'data': {'a': 'b'}}
    t._variable_manager = variable_manager

    a = ActionModule(task=t, connection=None, play_context=PlayContext(), loader=loader, templar=Templar(loader=loader), shared_loader_obj=None)

# Generated at 2022-06-23 08:47:38.934806
# Unit test for constructor of class ActionModule
def test_ActionModule():

    assert ActionModule({}, {})

# Generated at 2022-06-23 08:47:49.765261
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 08:47:54.028354
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create instance of class ActionModule
    action_module = ActionModule()
    # Assert that the object created is of type ActionModule
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-23 08:47:59.057035
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def create_task(args):
        class Task:
            def __init__(self, args):
                self.args = args
        return Task(args)

    task = create_task({})

    action = ActionModule(task, {})
    result = action.run()

    assert result['ansible_stats'] == {'data': {}, 'per_host': False, 'aggregate': True}

# Generated at 2022-06-23 08:48:01.435163
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: write unit tests for ActionModule
    module = ActionModule()
    assert module is not None

# Generated at 2022-06-23 08:48:10.642202
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock task object.
    from ansible.task import Task
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[dict(action=dict(module='set_stats', args=dict(data={'foo': 1},
                                                               per_host=True,
                                                               aggregate=False)))]
    )
    # create a mock templar so the test can use it

# Generated at 2022-06-23 08:48:21.850742
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Mock class imports
    class MockActionBase(object):
        def run(self, tmp=None, task_vars=None):
            return { 'failed': False, 'changed': True, 'ansible_stats': { 'data': { 'a': 1 }, 'per_host': False, 'aggregate': True } }

    # Mock module imports
    class MockTemplar(object):
        def template(self, template, convert_bare=False, fail_on_undefined=True):
            return { 'a': 1 }

    # Mock the necessary class imports and variables
    action_base = MockActionBase()
    templar = MockTemplar()
    action_module = ActionModule()

    # Test action module with no args
    stats = action_module.run(task_vars=None)
    assert not stats['failed']

# Generated at 2022-06-23 08:48:23.841617
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False, "Test not implemented"

# Generated at 2022-06-23 08:48:32.796904
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def test_func(self, tmp=None, task_vars=None):
        self._task.args = {'data': {'k1': 'v1', 'k2': 'v2'}, 'per_host': True, 'aggregate': False}
        return super(ActionModule, self).run(tmp, task_vars)

    # Monkey patch the run class to avoid executing the original code
    ActionModule.run = test_func


# Generated at 2022-06-23 08:48:35.571801
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module

# Generated at 2022-06-23 08:48:44.388080
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

    # Ugly mock for task, but usable for this test
    # For more info:
    # http://pytest.org/latest/builtin.html#_pytest.python.MockFixture
    from _pytest.python import MockFixture

    t_args = MockFixture(None, {})
    t_args.get.return_value = None
    t_args.__iter__ = lambda self: iter(self.__dict__.keys())

    class TaskMock:
        def __init__(self, args):
            self.args = args

    # Mock for task_vars, but usable for this test
    class TaskVarsMock():
        @staticmethod
        def __setitem__(name, value):
            task_vars[name] = value


# Generated at 2022-06-23 08:48:46.069935
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:48:48.553785
# Unit test for constructor of class ActionModule
def test_ActionModule():
    c = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert c is not None

# Generated at 2022-06-23 08:48:55.095536
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isidentifier('test')
    assert isidentifier('_test')
    assert not isidentifier('1test')
    assert isidentifier('__test__')

    module_args = {'data': {'test': 'ok'},
                   'per_host': 'true',
                   'aggregate': 'false'}

    task = {'args': module_args}

    action = ActionModule(task, {})
    assert action._task.args == module_args
    assert action._VALID_ARGS == frozenset(('aggregate', 'data', 'per_host'))
    assert action.TRANSFERS_FILES is False

    stats = {'data': {'test': 'ok'}, 'per_host': True, 'aggregate': False}

# Generated at 2022-06-23 08:49:04.996918
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    _ActionModule_run = None
    class _ActionModule(ActionModule):
        def __init__(self, *args, **kwargs):
            self.run_args = args
            self.run_kwargs = kwargs

        def run(self,*args,**kwargs):
            nonlocal _ActionModule_run
            if _ActionModule_run is None:
                _ActionModule_run = super(_ActionModule, self).run
            return _ActionModule_run(self, *args, **kwargs)


    def _safe_eval(obj):
        if isinstance(obj, string_types):
            obj = eval(obj, {}, {})
        return obj

    _actionmod_instance = _ActionModule()


# Generated at 2022-06-23 08:49:16.688867
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.vars.unsafe_proxy import UnsafeProxy

    b_true = boolean(True, strict=False)
    b_false = boolean(False, strict=False)

    # a lambda to patch ansible.template.Templar
    t_patch = lambda a, b, c, d: a

    # a lambda to patch ansible.template.Templar.template
    t_patch_t = lambda a, b, c, d: a

    # a class to mock the ansible.plugins.action.ActionBase class
    class ActionBaseMock(object):
        def __init__(self):
            self._task = None

    # a class to mock the ansible.playbook.task.Task class

# Generated at 2022-06-23 08:49:23.292054
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Constructor of class ActionModule should:
    - set TRANSFERS_FILES to False
    - set _VALID_ARGS to frozen set of ['aggregate', 'data', 'per_host']

    :return: None
    """
    actionmodule = ActionModule(None, None, None, None)
    assert actionmodule.TRANSFERS_FILES == False
    assert actionmodule._VALID_ARGS == frozenset(['aggregate', 'data', 'per_host'])

# Generated at 2022-06-23 08:49:25.347002
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(None, None, None, {})

# Generated at 2022-06-23 08:49:28.336698
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None, None)
    assert a is not None