

# Generated at 2022-06-25 07:18:53.066869
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    action_module_0 = ActionModule()
    assert not isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:19:04.508430
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.connection import ConnectionError

    # Define basic parameters
    tmp = '/tmp'
    task_vars = {}

    # Define default connection parameters
    class Connection:
        def __init__(self):
            self.module = AnsibleModule()

    class ActionModule:
        def __init__(self):
            self.DEFAULT_CONNECT_TIMEOUT = 5
            self.DEFAULT_REBOOT_TIMEOUT = 300
            self.MINIMUM_DISTRIBUTION_VERSION = None

# Generated at 2022-06-25 07:19:07.258007
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module_0 = ActionModule()
    action_module_0.check_boot_time(distribution="distribution_0", previous_boot_time="previous_boot_time_0")


# Generated at 2022-06-25 07:19:18.338155
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    action_module = ActionModule()
    action_module._task.args = dict(reboot_timeout='10')
    action_module._task.action = 'reboot'
    action_module.DEFAULT_SUDOABLE = True
    action_module.TEST_COMMANDS = dict(
        DEFAULT_TEST_COMMAND="test_command",
        REDHAT='test_command_redhat',
        ORACLE='test_command_oracle',
        FEDORA='test_command_fedora',
        CENTOS='test_command_centos',
        SCIENTIFIC='test_command_scientific',
        AMAZON='test_command_amazon'
    )

# Generated at 2022-06-25 07:19:26.280546
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    # Global variables relevant to the test case
    global action_module_0
    global distribution_0
    global original_connection_timeout_0
    global action_kwargs_0

    # Test case 0 setup
    action_module_0 = ActionModule()
    distribution_0 = NonCallableMock(name='distribution')
    original_connection_timeout_0 = NonCallableMock(name='original_connection_timeout')
    action_kwargs_0 = {
        'previous_boot_time': 'previous_boot_time'
    }

    # Call method validate_reboot of ActionModule
    result_0 = action_module_0.validate_reboot(distribution_0, original_connection_timeout_0, action_kwargs_0)


# Generated at 2022-06-25 07:19:28.735896
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    cmd = action_module_0.get_shutdown_command(None, 'RHEL-8.0')
    assert isinstance(cmd, str)


# Generated at 2022-06-25 07:19:30.245440
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    # TODO: implement unit test
    return


# Generated at 2022-06-25 07:19:31.866111
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print(reboot_module)


# Generated at 2022-06-25 07:19:33.541208
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_0 = ActionModule()
    test_0.run()


# Generated at 2022-06-25 07:19:36.013559
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # TODO: implement a unit test for method get_shutdown_command of class ActionModule
    action_module_0 = ActionModule()



# Generated at 2022-06-25 07:20:13.988759
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # setup and run task
    action_module = ActionModule()
    task_vars = dict(
        ansible_distribution='CentOS',
        ansible_distribution_version='6.7',
        ansible_distribution_release='Final'
    )
    distribution = action_module.get_distribution(task_vars)
    result = action_module._get_shutdown_command(task_vars, distribution)
    assert result == '/sbin/shutdown'


# Generated at 2022-06-25 07:20:20.968490
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    action_module_0 = ActionModule()
    mock_result_0 = {
        u'rc': 0,
        u'stdout': u'',
        u'stderr': u''
        }
    result_0 = action_module_0.perform_reboot(mock_result_0, 'el6')
    assert (result_0 == {'failed': False, 'rebooted': True, 'changed': True, 'start': mock_result_0})

# Generated at 2022-06-25 07:20:22.324678
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    action_module_0 = ActionModule()
    action_module_0.run_test_command('ubuntu')


# Generated at 2022-06-25 07:20:27.747327
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    print('Testing get_distribution...')

    action_module = ActionModule()
    action_module.ANSIBLE_REBOOT_DISTRIBUTION_FACTS = {
        'RedHat': [
            'RedHat'
        ],
        'Debian': [
            'Debian',
            'Ubuntu'
        ],
        'SUSE': [
            'SUSE'
        ],
        'Arch': [
            'Arch'
        ],
        'Darwin': [
            'Darwin'
        ],
        'Mandriva': [
            'MandrivaLinux'
        ],
        'Solaris': [
            'Solaris'
        ],
        'FreeBSD': [
            'FreeBSD'
        ],
        'AIX': [
            'AIX'
        ]
    }

    #

# Generated at 2022-06-25 07:20:39.847956
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    action_module_0 = ActionModule()
    action_module_0._task.args['distribution'] = 'openSUSE'
    action_module_0._task.args['os_family'] = 'Suse'
    action_module_0._task.args['use_reboot'] = True
    action_module_0._task.args['distribution'] = 'openSUSE Leap'
    action_module_0._task.args['shutdown_command'] = 'init 0'
    action_module_0._task.args['distribution'] = 'RHEL'
    action_module_0._task.args['use_reboot'] = True
    action_module_0._task.args['os_family'] = 'RedHat'
    action_module_0._task.args['distribution'] = 'Debian'
    action_

# Generated at 2022-06-25 07:20:49.435511
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # get_distribution test 1
    action_module = ActionModule()
    params = dict()
    params['platform'] = 'Linux'
    params['distribution'] = 'RedHat'
    params['distribution_release'] = '6.0'

    task_vars = dict()
    task_vars['ansible_distribution'] = params['distribution']
    task_vars['ansible_distribution_version'] = params['distribution_release']
    task_vars['ansible_distribution_release'] = '6.0'
    task_vars['ansible_facts']['os_family'] = 'RedHat'
    task_vars['ansible_facts']['distribution_major_version'] = params['distribution_release']

# Generated at 2022-06-25 07:20:53.981730
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:20:55.870702
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action_module_0 = ActionModule()
    action_module_0.deprecated_args()


# Generated at 2022-06-25 07:20:57.393004
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    test_case_0()

# Generated at 2022-06-25 07:20:59.730480
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module_1 = ActionModule()
    distribution = 'RedHat'
    assert action_module_1.get_shutdown_command_args(distribution) == '-r now'


# Generated at 2022-06-25 07:22:01.602003
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    action_module = ActionModule()
    action_module.run()
    action_module.get_system_boot_time("ubuntu")


# Generated at 2022-06-25 07:22:04.289808
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    action_module = ActionModule()
    out_time = action_module.validate_reboot(distribution='rhel')
    assert (out_time == {'failed': True, 'rebooted': True, 'msg': 'Timed out waiting for last boot time check (timeout=300)'})

# Generated at 2022-06-25 07:22:08.419623
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # test_case_0
    action_module_0 = ActionModule()
    result = action_module_0.check_boot_time(distribution=None)


# Generated at 2022-06-25 07:22:19.585857
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():

    # Test case 0
    # Simple test
    action_module_0 = ActionModule()
    tmp = None
    task_vars = {}
    distribution = 'test_distribution'
    action = 'test action'
    action_desc = 'test action description'
    reboot_timeout = 1
    action_kwargs = {}
    action_kwargs['previous_boot_time'] = 'test_previous_boot_time'

    try:
        action_module_0.do_until_success_or_timeout(action=action, action_desc=action_desc, reboot_timeout=reboot_timeout, distribution=distribution, action_kwargs=action_kwargs)
    except Exception as error:
        display.display('Test case 0 failed: {error}'.format(error=error))

# Generated at 2022-06-25 07:22:23.186185
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    pass


# Generated at 2022-06-25 07:22:29.447187
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module_1 = ActionModule()

    # Test with input 'task_vars' type that is not in the allowed types
    task_vars_2 = 123
    try:
        action_module_1.get_distribution(task_vars_2)
    except TypeError as e:
        assert (str(e) == 'task_vars: 123 is invalid input type')

    # Test with input 'task_vars' type that is not in the allowed types
    task_vars_3 = 'abc'
    try:
        action_module_1.get_distribution(task_vars_3)
    except TypeError as e:
        assert (str(e) == "task_vars: 'abc' is invalid input type")

    # Test with input 'task_vars' type that is not in the allowed

# Generated at 2022-06-25 07:22:32.345152
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action_module_0 = ActionModule()
    assert_raises(NotImplementedError, action_module_0.deprecated_args)


# Generated at 2022-06-25 07:22:39.409775
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module_1 = ActionModule()
    distribution = ''
    expected_value = ''

    actual_value = action_module_1.get_shutdown_command_args(distribution)
    assert actual_value == expected_value


# Generated at 2022-06-25 07:22:45.920854
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Simulate task_vars
    task_vars = {
        'ansible_distribution': 'Debian',
        'ansible_distribution_release': 'wheezy',
    }
    action_module = ActionModule()
    result = action_module.perform_reboot(task_vars, 'Debian')
    assert result is not None
    assert result['failed'] == False
    return True


# Generated at 2022-06-25 07:22:49.723513
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    action_module_0 = ActionModule()
    distribution = 'test_distribution'
    action_kwargs = dict()
    ret = action_module_0.validate_reboot(distribution, action_kwargs)


# Generated at 2022-06-25 07:24:54.082961
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    # Create instance of ActionModule
    action_module = ActionModule()
    # Call method get_system_boot_time on instance
    action_module.get_system_boot_time(distribution="CentOS")
    action_module.get_system_boot_time()


# Generated at 2022-06-25 07:24:55.702993
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    print("--- test_ActionModule_validate_reboot")
    #assert action_module_0.validate_reboot() == None



# Generated at 2022-06-25 07:24:57.606264
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module_0 = ActionModule()
    task_vars_0 = {}
    result = action_module_0.get_distribution(task_vars_0)


# Generated at 2022-06-25 07:25:06.887810
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    action_module = ActionModule()
    action_module._task.action = 'reboot'
    action_module._connection.connection._shell.run.return_value = {'stdout': 'Fri 22 Apr 2016 12:37:51 PM CDT', 'stderr': '', 'rc': 0}
    action_module.do_until_success_or_timeout = mock.MagicMock(return_value={'rebooted': True})
    action_module.get_system_boot_time = mock.MagicMock(return_value='Fri 22 Apr 2016 12:37:51 PM CDT')

    distribution = 'Ubuntu'
    original_connection_timeout = 0
    action_kwargs = {}

    # Test execution
    result = action_module.validate_reboot(distribution, original_connection_timeout, action_kwargs)

# Generated at 2022-06-25 07:25:08.332379
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    action_module = ActionModule()
    action_module.run_test_command(distribution="")


# Generated at 2022-06-25 07:25:11.721380
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    action_module_0 = ActionModule()
    distribution_0 = "Ubuntu"
    var_0 = action_module_0.get_system_boot_time(distribution_0)
    display.display(var_0)
    if (not (var_0)): raise Exception('Assertion failed.')


# Generated at 2022-06-25 07:25:13.460894
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # TODO: currently unused
    action_module_obj = ActionModule()

    # TODO: test for reboot_timeout parameter


# Generated at 2022-06-25 07:25:15.154934
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module = ActionModule()
    action_module.get_shutdown_command_args(distribution='redhat')


# Generated at 2022-06-25 07:25:21.534183
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    action_module = ActionModule()
    action_module.get_distribution = MagicMock(return_value='Ubuntu')
    action_module.check_boot_time = MagicMock(return_value=None)
    action_module.run_test_command = MagicMock(return_value=None)

    result = action_module.validate_reboot('Ubuntu', original_connection_timeout=None, action_kwargs=None)
    assert result == {'rebooted': True, 'changed': True}


# Generated at 2022-06-25 07:25:22.963193
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():

    action_module_0 = ActionModule()
    action_module_0.deprecated_args()
