

# Generated at 2022-06-25 07:19:07.510231
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    action_module_instance = ActionModule()
    param_distribution = ''
    param_original_connection_timeout = None
    param_action_kwargs = None
    result_should_be = feature_not_implemented
    result_real = action_module_instance.validate_reboot(param_distribution, param_original_connection_timeout, param_action_kwargs)
    assert result_should_be == result_real


# Generated at 2022-06-25 07:19:12.873846
# Unit test for method get_shutdown_command of class ActionModule

# Generated at 2022-06-25 07:19:23.215327
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    # Create a temporary directory for test
    cur_dir = os.getcwd()
    temp_dir = tempfile.mkdtemp()
    os.chdir(temp_dir)

    action_module = ActionModule()

    action_module.platform_dist_name = "DEBIAN"
    assert action_module.get_shutdown_command_args() == '-r now'

    action_module.platform_dist_name = "MACOSX"
    assert action_module.get_shutdown_command_args() == '-r now'

    action_module.platform_dist_name = "MACOS"
    assert action_module.get_shutdown_command_args() == '-r now'

    action_module.platform_dist_name = "REDHAT"
    assert action_module.get_shutdown_command

# Generated at 2022-06-25 07:19:25.083058
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action_module_1 = ActionModule()
    action_module_1.deprecated_args()


# Generated at 2022-06-25 07:19:32.788455
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module_1 = ActionModule()
    distribution = "Ubuntu"
    expected_result = "shutdown -r now"
    actual_result = action_module_1.get_shutdown_command_args(distribution)
    assert actual_result == expected_result
    distribution = "Non-Existent-System"
    expected_result = "shutdown -rF now"
    actual_result = action_module_1.get_shutdown_command_args(distribution)
    assert actual_result == expected_result


# Generated at 2022-06-25 07:19:34.400649
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:19:39.019099
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    # Call method run of class ActionModule with arguments.
    # Create an instance of class ActionModule for invoking the run() method
    result = action_module_0.run('tmp_1', 'task_vars_1')
    pprint(result)


# Generated at 2022-06-25 07:19:42.349742
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module = ActionModule()
    action_module.check_boot_time('ubuntu', '2019-04-10T11:25:29')

# Generated at 2022-06-25 07:19:47.672091
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module_0 = ActionModule()
    distribution_0 = u'CentOS'
    previous_boot_time_0 = u'2018-10-08T05:42:36.821451+00:00'
    try:
        action_module_0.check_boot_time(distribution_0, previous_boot_time_0)
    except ValueError as value_error_0:
        with pytest.raises(ValueError):
            raise value_error_0
        pass


# Generated at 2022-06-25 07:19:54.671025
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    action_module = ActionModule()
    assert action_module.get_shutdown_command("Ubuntu") == "/sbin/shutdown"
    assert action_module.get_shutdown_command("CentOS") == "/sbin/shutdown"
    assert action_module.get_shutdown_command("FreeBSD") == "/sbin/shutdown"
    assert action_module.get_shutdown_command("Unknown") == "/sbin/shutdown"
