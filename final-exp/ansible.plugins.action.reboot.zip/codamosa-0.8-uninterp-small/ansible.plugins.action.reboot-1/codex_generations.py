

# Generated at 2022-06-25 07:18:50.361147
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module_0 = ActionModule()
    action_module_0.check_boot_time()


# Generated at 2022-06-25 07:18:55.646989
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action_module_0 = ActionModule()
    action_module_0.deprecated_args()


# Generated at 2022-06-25 07:19:05.175801
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module = ActionModule()
    assert action_module.get_distribution('redhat') == 'RedHat'
    assert action_module.get_distribution('red hat') == 'RedHat'
    assert action_module.get_distribution('rhel') == 'RedHat'
    assert action_module.get_distribution('centos') == 'RedHat'
    assert action_module.get_distribution('debian') == 'Debian'
    assert action_module.get_distribution('ubuntu') == 'Debian'
    assert action_module.get_distribution('suse') == 'SUSE'
    assert action_module.get_distribution('arch') == 'Arch'
    assert action_module.get_distribution('fedora') == 'Fedora'

# Generated at 2022-06-25 07:19:08.626118
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # TODO: implement test for method check_boot_time of class ActionModule
    pass


# Generated at 2022-06-25 07:19:19.781927
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module_0 = ActionModule()

    tasks = list()
    task = dict()
    task["name"] = "Reboot the host"
    task["action"] = {
        "__ansible_module__" : "reboot",
        "__ansible_arguments__" : "[]"
    }
    tasks.append(task)
    play_source = dict()
    play_source["name"] = "Local test play"
    play_source["hosts"] = "localhost"
    play_source["tasks"] = tasks
    play = Play().load(play_source, variable_manager=VariableManager(), loader=DictDataLoader())
    tasks = play.get_tasks()
    task_0 = tasks[0]
    action_module_0._task = task_0
    # Params
    # Return value

# Generated at 2022-06-25 07:19:21.183760
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():

    action_module = ActionModule()
    action_module._task = {'action': 'reboot'}



# Generated at 2022-06-25 07:19:30.448111
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module_0 = ActionModule()
    distribution_0 = 'nVidia'

    # if len(current_boot_time) == 0 or current_boot_time == previous_boot_time:
    # If the condition is true, the code under it should be executed.
    # To test this, we set the test value as follows
    action_module_0.get_system_boot_time = (lambda distribution: 'nix')
    previous_boot_time = 'nix'
    with pytest.raises(ValueError):
        action_module_0.check_boot_time(distribution_0, previous_boot_time)

    # If the condition is false, the code under it should be skipped.
    # To test this, we set the test value as follows

# Generated at 2022-06-25 07:19:33.835226
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    action_module_0 = ActionModule()
    distribution = "Ubuntu"
    action_module_0.run_test_command(distribution)


# Generated at 2022-06-25 07:19:38.521929
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp = None
    task_vars = None
    result = action_module_0.run(tmp, task_vars)

    assert result == {}

# Unit test stub for get_system_boot_time to ensure all code paths are covered

# Generated at 2022-06-25 07:19:39.876469
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action_module_0 = ActionModule()
    action_module_0.deprecated_args()


# Generated at 2022-06-25 07:20:11.792012
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    print("====================")
    print("Unit test for method perform_reboot of class ActionModule")
    action_module_0 = ActionModule()
    action_module_0.set_task(Task())
    action_module_0.set_connection(Connection())
    task_vars_0 = {}
    distribution_0 = 'RHEL'
    result = action_module_0.perform_reboot(task_vars_0, distribution_0)
    print("result ==", result)


# Generated at 2022-06-25 07:20:19.258083
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Test method arguments
    action_module_0 = ActionModule()
    task_vars_0 = {}
    distribution_0 = 'distribution_tuple_0'

    # Test Exception handling
    try:
        reboot_result_0 = action_module_0.perform_reboot(task_vars_0, distribution_0)
    except RuntimeError as e:
        print(str(e))
        return
    except Exception:
        print("An exception occured while testing the perform_reboot method")
        return
    print("Test passed")


# Generated at 2022-06-25 07:20:25.754984
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module = ActionModule()

# Generated at 2022-06-25 07:20:27.052607
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize instance object
    action_module = ActionModule()
    action_module.run()


# Generated at 2022-06-25 07:20:38.984466
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    action_module = ActionModule()
    #case_0
    # initialize the local variables
    task_vars = {}
    distribution = 'DEBIAN'
    actual_result_0 = action_module.get_shutdown_command(task_vars, distribution)
    expected_result_0 = '/sbin/shutdown'
    assert actual_result_0 == expected_result_0
    #case_1
    # initialize the local variables
    task_vars = {}
    distribution = 'REDHAT'
    actual_result_1 = action_module.get_shutdown_command(task_vars, distribution)
    expected_result_1 = '/sbin/shutdown'
    assert actual_result_1 == expected_result_1
    #case_2
    # initialize the local variables
    task_vars = {}

# Generated at 2022-06-25 07:20:48.853371
# Unit test for method get_distribution of class ActionModule

# Generated at 2022-06-25 07:20:59.342639
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    action_module = ActionModule()
    def action_func(distribution):
        display.debug('{0}: action_func'.format(action_module._task.action))
    action_desc = 'test_desc'
    number_of_failures = 10
    fail_sleep = 2

    class ActionModuleTest(object):
        def __init__(self, action_module, number_of_failures):
            self.action_module = action_module
            self.number_of_failures = number_of_failures

        def check_boot_time(self, distribution):
            display.debug('{0}: check_boot_time, number_of_failures: {1}'.format(self.action_module._task.action, self.number_of_failures))

# Generated at 2022-06-25 07:21:06.958404
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    os = 'Arch'
    distribution = {'name': 'Arch', 'version': 'rolling', 'id': 'Arch', 'family': 'Arch'}
    task_vars = {'OS': os, 'DISTRIBUTION': distribution}

    action_module = ActionModule()
    result = action_module.perform_reboot(task_vars, distribution)

    assert result
    assert result['start']
    assert result['failed'] == False
    assert result['rebooted'] == True


# Generated at 2022-06-25 07:21:10.620931
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    # Use case 1:
        action_module_1 = ActionModule()
        action_module_1.get_system_boot_time("Linux")


# Generated at 2022-06-25 07:21:16.464917
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp_0 = None
    task_vars_0 = None
    result_0 = action_module_0.run(tmp_0, task_vars_0)
    assert result_0 is not None
    # Don't know how to test this further
    # Maybe shell out to a mock connection plugin
    # that returns responses indicating the system
    # was rebooted.


# Generated at 2022-06-25 07:22:18.003420
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    action_module_0 = ActionModule()
    str_arg_1 = 'dummy_str_1'
    str_arg_2 = 'dummy_str_2'
    dict_arg_3 = dict()
    dict_arg_3['key_1'] = 'value_1'
    dict_arg_3['key_2'] = 'value_2'
    dict_arg_3['key_3'] = 'value_3'
    dict_arg_3['key_4'] = 'value_4'
    dict_arg_3['key_5'] = 'value_5'

    # Test case 0, instance 0
    action_module_0.get_shutdown_command(str_arg_1, str_arg_2, dict_arg_3)
    assert True


# Generated at 2022-06-25 07:22:24.733132
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args = '{"test_command": "uptime", "reboot_timeout": "1800", "connect_timeout": "600", "msg": "Performed reboot", "reboot_timeout_sec": "1800", "connect_timeout_sec": "600"}'
    fmt = '{"changed": "%s", "elapsed": %s, "rebooted": "%s"}'
    expected_result = {u'changed': 'true', u'elapsed': 0, u'rebooted': 'true'}
    action_module_1 = ActionModule()
    action_module_1.run(tmp=None, task_vars='{"reboot_timeout": "1800", "connect_timeout": "600", "msg": "Performed reboot", "reboot_timeout_sec": "1800", "connect_timeout_sec": "600"}')

# Unit test

# Generated at 2022-06-25 07:22:28.625046
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():

    # create class instance
    action_module_1 = ActionModule()
    display.display(action_module_1)

    # Init local vars
    task_vars = dict(
        ansible_facts=dict(
            ansible_distribution='Debian'
        )
    )

    # execute method
    result_get_distribution = action_module_1.get_distribution(task_vars)

    # check result
    assert 'Debian' == result_get_distribution



# Generated at 2022-06-25 07:22:31.508655
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module_0 = ActionModule()
    action_module_0.check_boot_time(distribution=None,)



# Generated at 2022-06-25 07:22:35.137187
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    task_vars = {'ansible_facts': {'persistent_command_timeout': 1800}}
    self = ActionModule()
    self._task = {'args': {'force': False, 'timeout': 10, 'msg': 'shutting down for system maintenance', 'connect_timeout': 60}}
    distribution = 'Darwin'
    expected_result = '/sbin/shutdown'
    actual_result = self.get_shutdown_command(task_vars, distribution)
    print(actual_result)
    print(expected_result)
    assert actual_result == expected_result


# Generated at 2022-06-25 07:22:41.350878
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    action_module_0 = ActionModule()
    task_vars_0 = {}
    distribution_0 = 'debian'
    reboot_result_0 = action_module_0.perform_reboot(task_vars=task_vars_0, distribution=distribution_0)
    assert reboot_result_0['start'] == datetime.utcnow()
    assert reboot_result_0['failed'] == False
    assert reboot_result_0['rebooted'] == False


# Generated at 2022-06-25 07:22:48.279719
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():

    class MockAction(object):
        def __init__(self):
            self.called = False

        def __call__(self, distribution, action_kwargs=None):
            self.called = True
            raise TimedOutException('Timed out')

    action_module_1 = ActionModule()
    action_module_1._task.args['reboot_timeout'] = 1
    action_module_1._task.action = 'reboot'
    action_module_1.do_until_success_or_timeout(None, None, None, MockAction(), distribution=None, action_kwargs=None)

    import pytest

# Generated at 2022-06-25 07:22:50.091482
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    action_module = ActionModule()
    action_module.run_test_command(distribution="debian")


# Generated at 2022-06-25 07:22:50.939034
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-25 07:22:53.700714
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module = ActionModule()
    action_module.check_boot_time('Ubuntu', '2018-09-30 13:39:25.461266')


# Generated at 2022-06-25 07:25:06.070970
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    action_module_1 = ActionModule()
    task = namedtuple('task', ['action', 'args'])
    task_1 = task('action', {'shutdown_command': '/sbin/shutdown'})
    action_module_1._task = task_1

    task_vars = namedtuple('task_vars', ['facts'])
    task_vars_1 = task_vars(facts = {'distribution': 'Debian'})
    distribution = 'Debian'

    assert action_module_1.get_shutdown_command(task_vars_1, distribution) == '/sbin/shutdown'


# Generated at 2022-06-25 07:25:09.596642
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # Execute method
    action_module_0 = ActionModule()
    result_0 = action_module_0.check_boot_time("distribution_0", "previous_boot_time_0")
    # The test code below is lacking and should be updated
    assert result_0 is not None and result_0 != ""


# Generated at 2022-06-25 07:25:11.390613
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module_0 = ActionModule()
    action_module_0.get_shutdown_command_args(distribution=None)


# Generated at 2022-06-25 07:25:13.756212
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action_module_0 = ActionModule()
    try:
        action_module_0.deprecated_args()
    except Exception as e:
        print("Exception caught: {}".format(e))



# Generated at 2022-06-25 07:25:21.010775
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    print("test_ActionModule_check_boot_time")
    action_module_1 = ActionModule()

    # Test case with known input to check method check_boot_time of class ActionModule
    try:
        previous_boot_time = 'Sun 2018-06-24 03:39:23 UTC'
        distribution = "CentOS Linux release 7.5.1804 (Core)"
        action_module_1.check_boot_time(distribution, previous_boot_time)
        assert True
    except:
        assert False


# Generated at 2022-06-25 07:25:27.110328
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    action_module_0 = ActionModule()
    action_module_0.task = MagicMock()

    param_0 = '/usr/bin/shutdown'
    param_1 = None
    param_2 = '/usr/bin'
    param_3 = None
    param_4 = None
    param_5 = None
    param_6 = None

    get_shutdown_command_Test_Func = action_module_0.get_shutdown_command(param_0, param_1, param_2, param_3, param_4, param_5, param_6)
    get_shutdown_command_Test_Func = action_module_0.get_shutdown_command(param_0, param_1, param_2, param_3, param_4, param_5, param_6)

# Unit test

# Generated at 2022-06-25 07:25:35.207634
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    action_module_0 = ActionModule()
    task_vars_0 = {}
    distribution_0 = "CoreOS"
    result = action_module_0.perform_reboot(task_vars_0, distribution_0)
    assert result == {'start': datetime.datetime(2019, 1, 1, 7, 56, 56, 727480), 'failed': False}


# Generated at 2022-06-25 07:25:37.379257
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    action_module = ActionModule()
    task_vars = {'ansible_distribution': 'RedHat'}
    action_module.get_shutdown_command(task_vars, 'RedHat')


# Generated at 2022-06-25 07:25:42.855376
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    context = dict()
    action_module_0 = ActionModule()
    task_vars = dict()
    task_vars['ansible_distribution'] = 'Fedora'
    task_vars['ansible_distribution_version'] = '27'
    action_module_0.get_distribution(task_vars)


# Generated at 2022-06-25 07:25:44.726213
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # test result is a dictionary
    action_module_1 = ActionModule()
    action_module_1._get_distribution = MagicMock(return_value={})
    assert_is_instance(action_module_1.get_distribution({}), dict)
