

# Generated at 2022-06-25 07:18:57.823525
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    action_module_0 = ActionModule()
    distribution_0 = "Ubuntu"
    try:
        action_module_0.run_test_command(distribution_0)
    except Exception as e:
        pass


# Generated at 2022-06-25 07:19:09.799866
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    # Test with DEFAULT_TEST_COMMAND
    action_module_0 = ActionModule()
    action_module_0._task.args['test_command'] = None
    result_0 = action_module_0.run_test_command('reboot')
    # Test with test_command
    action_module_1 = ActionModule()
    action_module_1._task.args['test_command'] = 'echo test_command'
    result_1 = action_module_1.run_test_command('reboot')
    # Test with test_command running an invalid command
    action_module_2 = ActionModule()
    action_module_2._task.args['test_command'] = 'nvdfdshdfgshuc'

# Generated at 2022-06-25 07:19:16.237228
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    module = ActionModule()
    distribution = 'redhat' # Test variable
    previous_boot_time = '2019-03-24' # Test variable
    expected = 'stuck in infinite loop' # Test variable
    try:
        module.check_boot_time(distribution,previous_boot_time)
    except Exception as e:
        assert e.args[0] == expected


# Generated at 2022-06-25 07:19:23.695049
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    # Create instance of class ActionModule
    action_module_1 = ActionModule()

    # Try to execute method validate_reboot with valid parameters on instance action_module_1
    # Execution should be successful
    distribution = None
    original_connection_timeout = 60
    action_kwargs = None
    try:
        result = action_module_1.validate_reboot(distribution, original_connection_timeout, action_kwargs)
    except Exception as e:
        assert False, "Method validate_reboot raised exception of type %s, with message: %s" % (type(e), e.message)
    else:
       assert True


# Generated at 2022-06-25 07:19:34.726865
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():

    # Test for function get_distribution with valid data
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:19:38.192979
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    action_module_0 = ActionModule()
    distribution = 'some string'
    task_vars = {}
    print(action_module_0.perform_reboot(task_vars, distribution))


# Generated at 2022-06-25 07:19:42.347332
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    action_module = ActionModule()
    result = action_module.get_system_boot_time('Linux')
    assert result != None
    result = action_module.get_system_boot_time('Windows')
    assert result != None


# Generated at 2022-06-25 07:19:45.210759
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    action_module_1 = ActionModule()
    distribution = "centos"
    action_module_1.run_test_command(distribution)


# Generated at 2022-06-25 07:19:48.804752
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module = ActionModule()
    task_vars = {
        'ansible_facts': {
            'distribution': 'RedHat',
            'distribution_major_version': '6',
            'distribution_release': 'Final'
        }
    }


# Generated at 2022-06-25 07:20:00.053468
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    action_module_0 = ActionModule()
    action_module_0._task = AnsibleTask()
    action_module_0._task.action = 'reboot'
    action_module_0._task.error = AnsibleError('')
    action_module_0._task.asyncval = 42
    action_module_0._task.async_val = 42
    action_module_0._task.notified_by = {}
    action_module_0._task.args = {'become_method': 'sudo', 'become_user': '', 'reboot_timeout': 3097, 'connect_timeout': 3097, 'msg': 'Perform reboot now'}
    action_module_0._play_context = PlayContext()
    action_module_0._play_context.remote_port = 50499
    action_

# Generated at 2022-06-25 07:21:00.234900
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    action_module = ActionModule()
    action_module.get_system_boot_time()


# Generated at 2022-06-25 07:21:03.230566
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp = None
    task_vars = None
    action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 07:21:08.102255
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()

    module_result = action_module.run()

    assert module_result['changed'] == True
    assert module_result['rebooted'] == True
    print("Unit test for method run of class ActionModule completed")

#Unit test for method get_distribution of class ActionModule

# Generated at 2022-06-25 07:21:13.356326
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.run(None, None)


# Generated at 2022-06-25 07:21:17.880107
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    action_module_0 = ActionModule()
    print("\nRunning test action_module_0.get_system_boot_time")
    try:
        test_case_0()
    except Exception as error:
        print(str(error))
    else:
        print("Test action_module_0.get_system_boot_time passed")

# Run test for method get_system_boot_time
test_ActionModule_get_system_boot_time()


# Generated at 2022-06-25 07:21:23.684428
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module_0 = ActionModule()

    assert_equals(action_module_0.get_shutdown_command_args('freebsd'), '-r now')
    assert_equals(action_module_0.get_shutdown_command_args('openbsd'), '-r now')
    assert_equals(action_module_0.get_shutdown_command_args('netbsd'), '-r now')
    assert_equals(action_module_0.get_shutdown_command_args('linux'), None)
    assert_equals(action_module_0.get_shutdown_command_args('hpux'), '-r')
    assert_equals(action_module_0.get_shutdown_command_args('solaris'), '-y -i5 -g0')
    assert_equ

# Generated at 2022-06-25 07:21:29.920847
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Get a ActionModule object
    action_module_1 = ActionModule()
    # set a mock object for task_vars
    task_vars = {}

    # Get a ActionModule object
    action_module_2 = ActionModule()
    # Get a string for distribution
    distribution = 'Linux'

    # Calling perform_reboot method of ActionModule object
    result = action_module_2.perform_reboot(task_vars, distribution)
    print(result)
    assert 'failed' in result
    assert 'rebooted' in result
    assert result['failed'] == False
    assert result['rebooted'] == True


# Generated at 2022-06-25 07:21:32.049733
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():

    action_module_0 = ActionModule()
    assert action_module_0.get_distribution({}) == 'DEFAULT'


# Generated at 2022-06-25 07:21:34.390949
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module = ActionModule()
    assert action_module.check_boot_time("test_distribution", "test_previous_boot_time") == None, "check_boot_time function has error"


# Generated at 2022-06-25 07:21:42.714166
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    action_module_0 = ActionModule()
    action_module_0.post_reboot_delay = "test_value"
    task_vars_0 = {"test_key": "test_value"}
    setattr(action_module_0, '_task', Mock(return_value=task_vars_0))
    action_module_0.get_shutdown_command(task_vars_0, "test_value_0")


# Generated at 2022-06-25 07:23:42.700097
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action_module = ActionModule()
    assert None == action_module.deprecated_args()


# Generated at 2022-06-25 07:23:45.836059
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    task_vars_0 = {}
    task_vars_0["ansible_os_family"] = "AnsibleOSFamily"
    action_module_0 = ActionModule()

    with pytest.raises(AnsibleError):
        action_module_0.get_shutdown_command(task_vars_0, "distribution_0")


# Generated at 2022-06-25 07:23:56.104066
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():

    action_module_0 = ActionModule()
    action_module_0.run = mock.MagicMock()
    action_module_0.run.return_value = {
        'ansible_facts': {
            'distribution': 'centos',
            'distribution_release': '7',
            'distribution_version': '7.3.1611'
        }
    }
    action_module_0.run_command = mock.MagicMock()
    action_module_0.run_command.return_value = {
        'rc': 0,
        'stdout': '2017-04-14 16:42:32.916162320 +0900',
        'stderr': ''
    }


# Generated at 2022-06-25 07:24:00.218675
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
  action_module_1 = ActionModule()
  distribution = 'centos'
  original_connection_timeout = 300
  action_kwargs = 'action_kwargs'
  rv = action_module_1.validate_reboot(distribution, original_connection_timeout, action_kwargs)
  assert rv == {'changed': True, 'failed': False, 'rebooted': True}



# Generated at 2022-06-25 07:24:06.225064
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Boot a linux system, check rc.

    # Test case 1:
    # 1. Reboot a linux system
    # 2. Check the return value
    # Test 1 is expected to return success.
    task_vars = {}
    action_module_1 = ActionModule(task=Task('perform_reboot'), connection=Connection())
    result = action_module_1.perform_reboot(task_vars, distribution='Ubuntu')
    if not result['rebooted']:
        print("Test case 1 failed.")
        return

    # Test case 2:
    # 1. Reboot a windows system
    # 2. Check the return value
    # Test 2 is expected to return failure.
    task_vars = {}
    action_module_2 = ActionModule(task=Task('perform_reboot'), connection=Connection())
   

# Generated at 2022-06-25 07:24:09.939584
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module_0 = ActionModule()
    action_module_1 = ActionModule()

    # Test case 0
    action_module_0.get_distribution({'ansible_facts': {'ansible_distribution': 'Fedora', 'ansible_distribution_version': '32'}})
    # Test case 1
    action_module_1.get_distribution({'ansible_facts': {'ansible_distribution': 'Red Hat Enterprise Linux Server', 'ansible_distribution_version': '7.6'}})



# Generated at 2022-06-25 07:24:13.303195
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:24:15.033534
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    global action_module_0
    action_module_0.check_boot_time(distribution="pamu")


# Generated at 2022-06-25 07:24:19.961945
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module = ActionModule()
    task_vars = dict(ansible_distribution='ubuntu', ansible_distribution_release='20.04', ansible_distribution_version='20.04')
    result = action_module.get_distribution(task_vars)
    assert result == 'DEFAULT'


# Generated at 2022-06-25 07:24:21.950956
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.run()


# Generated at 2022-06-25 07:26:37.173687
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    action_module_1 = ActionModule()
    action_module_1._task = dict()
    action_module_1._task['action'] = 'reboot'
    action_module_1._task['args'] = dict()
    action_module_1._task['args']['test_command'] = '/bin/true'
    distribution_1 = 'Fedora'
    action_module_1.run_test_command(distribution_1, )


# Generated at 2022-06-25 07:26:45.858483
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    action_module_1 = ActionModule()
    action_module_1._task = DummyTaskClass()
    action_module_1._task.args = {'reboot_timeout': 60}
    action_module_1._task.action = 'action_module_1'
    action_module_1._connection = DummyConnectionClass()

    # Test case with argument distribution = 'redhat'
    # and argument original_connection_timeout = None
    # and argument action_kwargs.
    action_module_1._task.args['reboot_timeout'] = 60
    action_module_1.DEFAULT_REBOOT_TIMEOUT = 3600
    action_module_1._task.action = 'action_module_1'
    action_module_1.DEFAULT_SUDOABLE = True
    action_module_1._connection

# Generated at 2022-06-25 07:26:47.372637
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    action_module_0 = ActionModule()

    # call method get_shutdown_command
    action_module_0.get_shutdown_command()



# Generated at 2022-06-25 07:26:50.695007
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    action_module_1 = ActionModule()
    tmp_1 = None
    task_vars_1 = {}
    result_1 = action_module_1.perform_reboot(task_vars_1, 'Linux')
    assert_false(result_1['failed'])
    assert_true(result_1['rebooted'])
    assert_equal(0, result_1['rc'])


# Generated at 2022-06-25 07:26:52.180030
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    action_module_0 = ActionModule()
    distribution = "redhat"
    action_module_0.get_system_boot_time(distribution)


# Generated at 2022-06-25 07:26:55.257908
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    # 
    action_module_0 = ActionModule()
    # Test invalid case
    distribution = "test"
    try:
        action_module_0.get_system_boot_time(distribution=distribution)
    except Exception as e:
        print (e)
    # Test valid case
    distribution = "test"
    action_module_0.get_system_boot_time(distribution=distribution)


# Generated at 2022-06-25 07:26:56.323865
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action_module_0 = ActionModule()
    action_module_0.deprecated_args()


# Generated at 2022-06-25 07:26:58.046469
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module_0 = ActionModule()
    distribution = 'redhat'
    result = action_module_0.get_shutdown_command_args(distribution=distribution)
    assert result == '-r now'


# Generated at 2022-06-25 07:27:07.683532
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module = ActionModule()
    action_module._task_vars = {'ansible_distribution': 'Ubuntu'}
    action_module._task_vars['ansible_distribution_version'] = '4'
    action_module._task_vars['ansible_distribution_release'] = '1'
    action_module._task_vars['ansible_distribution_major_version'] = '4'
    
    try:
        action_module.get_distribution(action_module._task_vars)
    except Exception:
        pytest.fail('ActionModule.get_distribution not passing when ansible_distribution is Ubuntu, ansible_distribution_version is 4, and ansible_distribution_release is 1')


# Generated at 2022-06-25 07:27:10.671399
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # Test case 0
    action_module_0 = ActionModule()
