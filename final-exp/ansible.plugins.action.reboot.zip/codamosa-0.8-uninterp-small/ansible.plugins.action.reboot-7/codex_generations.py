

# Generated at 2022-06-25 07:18:57.626984
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Test for all valid values for variable RebootCommand
    action_module_1 = ActionModule()
    task_vars_1 = {}
    distribution_1 = "test"
    result_1 = action_module_1.perform_reboot(task_vars_1, distribution_1)

    # Test for all valid values for variable RebootCommand
    action_module_2 = ActionModule()
    task_vars_2 = {}
    distribution_2 = "test"
    result_2 = action_module_2.perform_reboot(task_vars_2, distribution_2)

    # Test for all valid values for variable RebootCommand
    action_module_3 = ActionModule()
    task_vars_3 = {}
    distribution_3 = "test"
    result_3 = action_module_3.perform_re

# Generated at 2022-06-25 07:19:02.588425
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    action_module_0 = ActionModule()

    display.debug("{action}: test get_system_boot_time".format(action='reboot'))

    task_vars = dict()
    distribution = None
    action_module_0.get_system_boot_time(distribution)

    display.debug("{action}: test get_system_boot_time failed".format(action='reboot'))


# Generated at 2022-06-25 07:19:04.662878
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    action_module_0 = ActionModule()
    distribution = {}
    action_module_0.run_test_command(distribution)


# Generated at 2022-06-25 07:19:15.424484
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module_1 = ActionModule()
    task_vars_1 = dict()
    try:
        action_module_1.get_distribution(task_vars_1)
    except Exception as e:
        assert False

    task_vars_2 = dict()
    task_vars_2['ansible_system'] = 'Linux'
    try:
        action_module_1.get_distribution(task_vars_2)
    except Exception as e:
        assert False

    task_vars_3 = dict()
    task_vars_3['ansible_distribution'] = 'Fedora'
    try:
        action_module_1.get_distribution(task_vars_3)
    except Exception as e:
        assert False

    task_vars_4 = dict()
   

# Generated at 2022-06-25 07:19:24.574487
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module_0 = ActionModule()
    action_module_0.get_shutdown_command_args('SLES')
    action_module_0.get_shutdown_command_args('SLES_12_3')
    action_module_0.get_shutdown_command_args('SLES_12_2')
    action_module_0.get_shutdown_command_args('SLES_12_1')
    action_module_0.get_shutdown_command_args('SLES_12_0')
    action_module_0.get_shutdown_command_args('SLES_11_4')
    action_module_0.get_shutdown_command_args('SLES_11_3')
    action_module_0.get_shutdown_command_args('SLES_11_2')


# Generated at 2022-06-25 07:19:28.695726
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():

    # Set call arguments
    distribution = 'Ubuntu'

    # Call method
    action_module_1 = ActionModule()
    rv = action_module_1.validate_reboot(distribution)

    # Check whether returned value is correct
    assert rv['rebooted'] == True



# Generated at 2022-06-25 07:19:31.822311
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    action_module_1 = ActionModule()
    assert action_module_1.run_test_command(0, distribution=None, **None) == None


# Generated at 2022-06-25 07:19:36.151091
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action_module = ActionModule()
    action_module._task.args = dict(msg="test message")
    try:
        action_module.deprecated_args()
    except Exception:
        raise Exception("Unexpected exception raised when calling 'deprecated_args'")


# Generated at 2022-06-25 07:19:44.273148
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module_0 = ActionModule()
    print("\n")

    # Printing action name and test name
    print("\nAction Module: Check_boot_time\n")

    # Test 1
    print("Test 1: Check if boot time was checked for Fedora distribution")

# Generated at 2022-06-25 07:19:47.511515
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    action_module_0 = ActionModule()
    distribution = str()

    # Invoke method
    ret = action_module_0.run_test_command(distribution=distribution)
    print(ret)



# Generated at 2022-06-25 07:20:46.768670
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action_module_0 = ActionModule()
    action_module_0.deprecated_args()


# Generated at 2022-06-25 07:20:52.000839
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    action_module_obj = ActionModule()
    action_module_obj.do_until_success_or_timeout(action=action_module_obj.check_boot_time,
                                                  action_desc="last boot time check",
                                                  reboot_timeout=1,
                                                  distribution='None',
                                                  action_kwargs={'previous_boot_time': 1})


# Generated at 2022-06-25 07:20:56.114434
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module_1 = ActionModule()
    distribution = 'Ubuntu'
    previous_boot_time = ''
    action_module_1.check_boot_time(distribution, previous_boot_time)


# Generated at 2022-06-25 07:20:59.636637
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module_0 = ActionModule()
    action_module_0.do_until_success_or_timeout(
        action=action_module_0.check_boot_time,
        action_desc="last boot time check",
        reboot_timeout=5,
        distribution='Ubuntu')


# Generated at 2022-06-25 07:21:05.435230
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module_1 = ActionModule()
    task_vars_1 = {'ansible_facts': {'os': 'CentOS', 'distribution': 'CentOS'}}
    result_1 = action_module_1.get_distribution(task_vars_1)
    assert result_1 == "RedHat"


# Generated at 2022-06-25 07:21:16.464997
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    host_data = {
        'ansible_distribution': 'Ubuntu',
        'ansible_distribution_version': '16.04',
        'ansible_os_family': 'Debian'
    }

    if isinstance(action_module_0, ActionModule):
        display = ActionModule._display
    else:
        display = Display()
    action_module_0.set_task_as_main_source()
    action_module_0.set_connection_as_main_source()
    action_module_0.set_loader()
    action_module_0.set_shared_loader()
    action_module_0.set_options()
    action_module_0.set_display(display)

    action_module_0._task.playbook = AnsiblePlaybook()

# Generated at 2022-06-25 07:21:23.726743
# Unit test for method get_system_boot_time of class ActionModule

# Generated at 2022-06-25 07:21:25.764304
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    action_module_0 = ActionModule()
    assert action_module_0 is not None
    assert ActionModule in ActionModule.__bases__
    assert isinstance(action_module_0, ActionModule)


# Generated at 2022-06-25 07:21:28.479686
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action_module_0 = ActionModule()
    action_module_0.deprecated_args()


# Generated at 2022-06-25 07:21:36.831778
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    hostvars = {'ansible_distribution': 'Ubuntu'}
    ansible_distribution = hostvars.get('ansible_distribution')
    hostvars = {'ansible_os_family': 'Debian'}
    ansible_os_family = hostvars.get('ansible_os_family')
    task_vars = {}
    task_vars['hostvars'] = {}
    task_vars['hostvars']['localhost'] = hostvars
    distribution = action_module_0.get_distribution(task_vars)
    assert distribution == 'debian'
    task_vars['hostvars']['localhost'] = {'ansible_distribution': ansible_distribution, 'ansible_os_family': ansible_os_family}
    distribution = action_

# Generated at 2022-06-25 07:23:36.867061
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp = None
    task_vars = None
    task_vars = {}
    action_module_0.run(tmp, task_vars)


# Generated at 2022-06-25 07:23:45.452550
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    import sys
    import io
    import inspect
    capture_stdout = io.StringIO()

# Generated at 2022-06-25 07:23:51.072345
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    global test_case_0
    """
    Test steps for method do_until_success_or_timeout of class ActionModule

    :param None

    :return: None
    """

    print('Test case with valid arguments')
    test_case_0.do_until_success_or_timeout(action=test_case_0.check_boot_time, reboot_timeout=timeout, action_desc="command execution", distribution="ubuntu")
    print('Test case with invalid arguments')
    test_case_0.do_until_success_or_timeout(action=test_case_0.check_boot_time, reboot_timeout=timeout, action_desc="command execution", distribution="ubuntu")

    print('Test case with valid arguments')

# Generated at 2022-06-25 07:23:54.256354
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module_test = ActionModule()
    # test for rhel6
    distribution = 'rhel6'
    shutdown_command_args = '-r now'

    assert action_module_test.get_shutdown_command_args(distribution) == shutdown_command_args



# Generated at 2022-06-25 07:23:57.450936
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    # test case 1
    action_module_1 = ActionModule()



# Generated at 2022-06-25 07:24:04.096747
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Prepare
    action_module = ActionModule()
    action_module.DEFAULT_SHUTDOWN_COMMAND = 'default_shutdown_command'

    # Test cases - default

# Generated at 2022-06-25 07:24:04.950200
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.run()


# Generated at 2022-06-25 07:24:07.435518
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    display.vvv()
    test_case_0()

if __name__ == '__main__':
    display.debug()
    test_ActionModule_do_until_success_or_timeout()

# Generated at 2022-06-25 07:24:12.935524
# Unit test for method do_until_success_or_timeout of class ActionModule

# Generated at 2022-06-25 07:24:15.535346
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    # Create an instance of class ActionModule

    action_module_0 = ActionModule()

    # Call method deprecated_args of class ActionModule with mock object as argument
    action_module_0.deprecated_args()
