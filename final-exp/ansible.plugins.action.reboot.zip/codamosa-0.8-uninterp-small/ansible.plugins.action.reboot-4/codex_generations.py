

# Generated at 2022-06-25 07:19:01.288851
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    # Input parameters for the method
    distribution = 'FreeBSD'
    expected_result = action_module_0.get_shutdown_command_args(distribution)
    assert expected_result == '-r now'


# Generated at 2022-06-25 07:19:04.137377
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    action_module_1 = ActionModule()
    get_system_boot_time_function = getattr(action_module_1,"get_system_boot_time")


# Generated at 2022-06-25 07:19:05.727671
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    result = action_module_0.run()
    assert(result['changed'] == True)


# Generated at 2022-06-25 07:19:12.708097
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module = ActionModule()
    # case 1: distribution is ubuntu
    distribution = 'ubuntu'
    shutdown_command_args_expected = '-r now'
    shutdown_command_args_actual = action_module.get_shutdown_command_args(distribution)
    assert shutdown_command_args_expected == shutdown_command_args_actual
    # case 2: distribution is rhel
    distribution = 'rhel'
    shutdown_command_args_expected = '-r now'
    shutdown_command_args_actual = action_module.get_shutdown_command_args(distribution)
    assert shutdown_command_args_expected == shutdown_command_args_actual
    # case 3: distribution is centos
    distribution = 'centos'
    shutdown_command_args_expected = '-r now'
    shutdown_command

# Generated at 2022-06-25 07:19:22.388441
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    print("Starting test_ActionModule_run_test_command")
    action_module_0 = ActionModule()
    test_case = 0
    if test_case == 0:
        test_distribution = 'dummy'
        try:
            test_result = action_module_0.run_test_command(test_distribution)
        except Exception as e:
            print("Caught exception running run_test_command of class ActionModule: %s" % (e))
        else:
            print("run_test_command test case 0 passed")
    else:
        print("Unknown test case for method run_test_command of class ActionModule")
    print("Ending test_ActionModule_run_test_command")


# Generated at 2022-06-25 07:19:27.079148
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module_0 = ActionModule()
    task_vars = {}
    task_vars = {}
    task_vars = {}
    task_vars = {}
    task_vars = {}
    task_vars = {}
    task_vars = {}
    task_vars = {}
    task_vars = {}
    task_vars = {}
    dist = action_module_0.get_distribution(task_vars)
    assert (dist == 'DEFAULT')


# Generated at 2022-06-25 07:19:30.242683
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    # Setup the test case
    action_module_0 = ActionModule()
    action_module_0._task = Mock(args={})
    action_module_0.run_test_command(distribution='CentOS')


# Generated at 2022-06-25 07:19:34.669438
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    action_module_1 = ActionModule()
    try:
        assert action_module_1.get_system_boot_time() is None
    except Exception as e:
        print(e)
        assert True
    else:
        assert False

# Generated at 2022-06-25 07:19:38.142366
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    action_module_ = ActionModule()
    action_module_.do_until_success_or_timeout(action_module_.check_boot_time, 60, "last boot time check", "CentOS-7")


# Generated at 2022-06-25 07:19:39.491084
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    action_module_0.perform_reboot()



# Generated at 2022-06-25 07:20:08.971729
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    # Initialize test variables
    action_module_0 = ActionModule()
    action_module_0.run_test_command(None)


# Generated at 2022-06-25 07:20:17.580616
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    action_module = ActionModule()

    # try/except added for handling unexpected exceptions when calling
    # method get_system_boot_time of class ActionModule
    try:
        action_module.get_system_boot_time()
    except Exception as err:
        print("Exception when calling method get_system_boot_time of class ActionModule: {}".format(err))
    else:
        print("Method get_system_boot_time of class ActionModule executed successfully.")



# Generated at 2022-06-25 07:20:25.020050
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    action_module_1 = ActionModule()

# Generated at 2022-06-25 07:20:26.264621
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module = ActionModule()
    action_module.get_shutdown_command_args()


# Generated at 2022-06-25 07:20:37.928608
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    task = AnsibleTask()
    action_module_1 = ActionModule(task, None)

    action_module_1._task.args['connect_timeout'] = 0
    action_module_1.deprecated_args()

    action_module_1._task.args['connect_timeout'] = 1
    action_module_1.deprecated_args()

    action_module_1._task.args['connect_timeout'] = '1'
    action_module_1.deprecated_args()

    action_module_1._task.args['connect_timeout'] = 'foo'
    action_module_1.deprecated_args()

    action_module_1._task.args['connect_timeout_sec'] = 0
    action_module_1.deprecated_args()


# Generated at 2022-06-25 07:20:39.431977
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    print("Testing test_ActionModule_deprecated_args")
    action_module_0 = ActionModule() # Instance of class ActionModule
    action_module_0.deprecated_args()
    return


# Generated at 2022-06-25 07:20:49.012171
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():

    # Check if all the arguments are strings and non-empty
    # Create 'args' variable to call the method with parameters
    if True:
        args = {}
        data = {}
        data['test_command'] = "uptime"

        setattr(action_module_0, '_task', data)
        try:
            result = action_module_0.run_test_command(distribution='CentOS')
        except Exception as e:
            display.error("method 'run_test_command' of class 'ActionModule' raised exception '%s'" % to_native(e))
            raise e
        else:
            display.info("method 'run_test_command' of class 'ActionModule' returned '%s'" % to_native(result))



# Generated at 2022-06-25 07:20:50.953961
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module_0 = ActionModule()
    assert type(action_module_0.get_distribution(obj_0)) == str


# Generated at 2022-06-25 07:20:59.537238
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    if not is_pytest_enabled():
        return
    action_module_1 = ActionModule()
    task_args_1 = dict()
    task_args_1['reboot_timeout'] = 30
    task_args_1['post_reboot_delay'] = 0
    task_args_1['reboot_timeout_sec'] = 30
    task_args_1['test_command'] = 'test ! -f /var/run/reboot-required'
    task_args_1['connect_timeout'] = 30
    task_args_1['msg'] = 'Failed to reboot'
    distribution_1 = 'Ubuntu'
    action_module_1._task = task_0
    action_module_1._task.action = 'reboot'
    action_module_1._task.args = task_args_1


# Generated at 2022-06-25 07:21:11.823886
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module = ActionModule()
    # test CentOS
    action_module.get_distribution(task_vars={"ansible_distribution": "CentOS", "ansible_distribution_version": "6.7"})
    action_module.get_distribution(task_vars={"ansible_distribution": "CentOS", "ansible_distribution_version": "7.0"})

    # test RedHat
    action_module.get_distribution(task_vars={"ansible_distribution": "RedHat", "ansible_distribution_version": "7.0"})

    # test Fedora
    action_module.get_distribution(task_vars={"ansible_distribution": "Fedora", "ansible_distribution_version": "23"})
    action_module.get_dist

# Generated at 2022-06-25 07:21:43.355586
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module_0 = ActionModule()
    assert action_module_0.check_boot_time(None, None) == None


# Generated at 2022-06-25 07:21:46.387162
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    result_1 = action_module_1.run(tmp=None, task_vars=None)
    print(result_1)

if __name__ == '__main__':
    test_case_0()
    test_ActionModule_run()

# Generated at 2022-06-25 07:21:54.007020
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    action_module_0 = ActionModule()
    task_vars_0 = {}
    distribution_0 = 'test_value'
    varargs_0 = [
        task_vars_0,
        distribution_0
    ]
    result_0 = action_module_0.get_shutdown_command(*varargs_0)
    assert result_0 is None


# Generated at 2022-06-25 07:22:04.865375
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    action_module_mock = ActionModule()

    boot_time = "2019/01/11 18:52:03"
    action_module_mock.check_boot_time = MagicMock(wraps=lambda self, distribution, previous_boot_time: None if (previous_boot_time == boot_time) else True)
    action_module_mock.do_until_success_or_timeout(action=action_module_mock.check_boot_time, reboot_timeout=100, action_desc="test action", distribution="test", action_kwargs={'previous_boot_time': boot_time})
    action_module_mock.check_boot_time.assert_called_with(action_module_mock, "test", "2019/01/11 18:52:03")


# Generated at 2022-06-25 07:22:11.690577
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    action_module_1 = ActionModule()
    task_vars_1 = {}
    distribution_1 = 'DEFAULT'

    log_output("test_ActionModule_perform_reboot")
    try:
        result_1 = action_module_1.perform_reboot(task_vars_1, distribution_1)
        assert result_1['failed'] == True
        assert result_1['rebooted'] == False
        assert result_1['start'] == datetime(2020, 5, 4, 22, 0)
        assert result_1['msg'] == 'Reboot command failed. Error was: \'\''
    except Exception as e:
        log_output("test_ActionModule_perform_reboot: " + to_text(e))
        assert False


# Generated at 2022-06-25 07:22:13.132506
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    action_module_obj = ActionModule()

    action_module_obj.run_test_command("no distribution")
    assert True


# Generated at 2022-06-25 07:22:19.034100
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    action_module_0 = ActionModule()
    # Test for:
    # 1. When self._task.action = "wait_for_connection", self.run_test_command should return RuntimeError
    config = {}
    config.update({'DEFAULT_TEST_COMMAND': 'exit 1'})
    action_module_0._task.action = 'wait_for_connection'
    action_module_0.TEST_COMMANDS['DEFAULT'] = config
    try:
        action_module_0.run_test_command('DEFAULT')
    except (AnsibleConnectionFailure):
        pass
    # Test for:
    # 1. When command_result['rc'] != 0, self.run_test_command should return Exception
    config_1 = {}

# Generated at 2022-06-25 07:22:28.574027
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module = ActionModule()
    print('Unit test: check_boot_time')

    # When system has not booted
    print('\tWhen system has not booted')
    # And when distribution is 'Ubuntu'
    print('\tAnd when distribution is \'Ubuntu\'')
    # Then AssertionError should be thrown
    assert_throws(ValueError, lambda: action_module.check_boot_time('Ubuntu', '2019-05-16T14:14:31.000000+00:00'))

    # When system has not booted
    print('\tWhen system has not booted')
    # And when distribution is 'CentOS'
    print('\tAnd when distribution is \'CentOS\'')
    # Then AssertionError should be thrown

# Generated at 2022-06-25 07:22:35.788671
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    print()
    print('unit test for method get_system_boot_time of class ActionModule')
    # Unit test code here
    print('test on distribution="RedHat"')
    distribution = "RedHat"
    action_module_0 = ActionModule()
    assert action_module_0.get_system_boot_time(distribution) == b'1479658911'
    print('test on distribution="Debian"')
    distribution = "Debian"
    action_module_0 = ActionModule()
    assert action_module_0.get_system_boot_time(distribution) == b'1479658911'
    print('test on distribution="FreeBSD"')
    distribution = "FreeBSD"
    action_module_0 = ActionModule()

# Generated at 2022-06-25 07:22:41.124601
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    action_module_0 = ActionModule()
    distribution = 0
    test_command = 0
    try:
        test_command = action_module_0.run_test_command(distribution)
    except Exception as exception_0:
        assert True

    display = 0
    test_command = 0
    try:
        test_command = action_module_0.run_test_command(distribution)
    except Exception as exception_1:
        assert True


# Generated at 2022-06-25 07:23:46.625403
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    action_module_0 = ActionModule()
    # Testing parameter 'action'
    expected_value_0 = "my_action"
    action_module_0.do_until_success_or_timeout(action=expected_value_0)
    actual_value_0  = action_module_0._action
    assert actual_value_0 == expected_value_0, "Expected value for action to be '%s' but got '%s'" % (expected_value_0, actual_value_0)

    # Testing parameter 'action_desc'
    expected_value_1 = "my_action_desc"
    action_module_0.do_until_success_or_timeout(action_desc=expected_value_1)
    actual_value_1  = action_module_0._action_desc
    assert actual_value_1

# Generated at 2022-06-25 07:23:53.345433
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    action_module_0 = ActionModule()
    distribution = 'Ubuntu'
    boot_time_command = 'cat /proc/stat | grep btime'

    display.debug("Doing testing on method get_system_boot_time of class ActionModule")
    cmd_result = action_module_0.get_system_boot_time(distribution)

    assert cmd_result == 'btime 1449067625'


# Generated at 2022-06-25 07:24:00.694237
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module_0 = ActionModule()

    # Implementation of test case 1
    result = action_module_0.get_distribution(task_vars=None)
    assert result == 'default', "Test case {0}".format(1)

    # Implementation of test case 2
    result = action_module_0.get_distribution(task_vars={"ansible_facts": "ansible_facts"})
    assert result == 'default', "Test case {0}".format(2)

    # Implementation of test case 3
    result = action_module_0.get_distribution(task_vars={"ansible_facts": "ansible_facts", "ansible_distribution": "ansible_distribution"})
    assert result == 'ansible_distribution', "Test case {0}".format(3)

   

# Generated at 2022-06-25 07:24:01.866266
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action_module_0 = ActionModule()
    action_module_0.deprecated_args()


# Generated at 2022-06-25 07:24:02.586364
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    assert 1 == 1


# Generated at 2022-06-25 07:24:07.799900
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = None
    action_module_0 = ActionModule()
    tmp_0 = None
    task_vars_0 = None
    action_module_0.run(tmp_0, task_vars_0)

    # Situation 1:
    action_module_0 = ActionModule()

    # Action 1:
    # if self._connection.transport == 'local':
    #     return {'changed': False, 'elapsed': 0, 'rebooted': False, 'failed': True, 'msg': 'Running {0} with local connection would reboot the control node.'.format(self._task.action)}

    # Ground truth:
    tmp_90 = None
    task_vars_90 = None
    action_module_0.run(tmp_90, task_vars_90)

    # Situation 2:

# Generated at 2022-06-25 07:24:13.178002
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    # Note that this test does not run the same way through pytest as it does in the
    # action plugin, since the task vars are not available.
    action_module_0 = ActionModule()
    action_module_0.action = 'reboot'
    task_vars_0 = {}
    task_vars_0['ansible_facts'] = {}
    task_vars_0['ansible_facts']['distribution'] = 'AIX'
    task_vars_0['ansible_facts']['distribution_release'] = '7.1'
    task_vars_0['ansible_facts']['distribution_version'] = '7100-03'
    task_vars_0['ansible_facts']['distribution_major_version'] = 7
    action_module_0.task

# Generated at 2022-06-25 07:24:23.467397
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module_0 = ActionModule()
    distribution = action_module_0.get_distribution({'ansible_distribution': 'RHEL 6.6'})
    assert distribution == 'RedHat6'

    distribution = action_module_0.get_distribution({'ansible_distribution': 'Debian 8.0'})
    assert distribution == 'Debian8'

    distribution = action_module_0.get_distribution({'ansible_distribution': 'Suse 11.3'})
    assert distribution == 'Suse11'

    distribution = action_module_0.get_distribution({'ansible_distribution': 'CentOS 6.4'})
    assert distribution == 'RedHat6'

    distribution = action_module_0.get_distribution({'ansible_distribution': 'Fedora 25'})


# Generated at 2022-06-25 07:24:27.805957
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module_0 = ActionModule()
    arguments = {'distribution': 'Ubuntu'}
    try:
        action_module_0.check_boot_time(**arguments)
        assert False == "Expect exception"
    except ValueError as e:
        assert "boot time has not changed" == e.args[0]
    except Exception as e:
        assert False == "Expect type ValueError"

# Generated at 2022-06-25 07:24:30.488095
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module_0 = ActionModule()

    # call to get_distribution in class ActionModule with parameter task_vars_0
    display.debug(action_module_0.get_distribution({'ansible_distribution': 'Debian'}))
    return


# Generated at 2022-06-25 07:25:46.021444
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():

    # Check that ActionModule.get_system_boot_time raise RuntimeError with correct error message
    try:
        action_module = ActionModule()
        action_module.get_system_boot_time("any")
    except RuntimeError as e:
        assert 'BOOT_TIME_COMMAND' in str(e)
    else:
        assert False, "An exception was expected to be raised with message: 'BOOT_TIME_COMMAND'"

    # Check that ActionModule.get_system_boot_time raise RuntimeError with correct error message
    try:
        action_module = ActionModule()
        action_module.get_system_boot_time("DEFAULT_BOOT_TIME_COMMAND")
    except RuntimeError as e:
        assert 'DEFAULT_BOOT_TIME_COMMAND' in str(e)

# Generated at 2022-06-25 07:25:48.800685
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    action_module_0 = ActionModule()
    # Test 1
    action_module_0.run_test_command('centos')



# Generated at 2022-06-25 07:25:55.274844
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module_1 = ActionModule()
    action_module_1.DEFAULT_SUDOABLE = True
    action_module_1.get_shutdown_command_args('el')
    action_module_1.get_shutdown_command_args('cal')
    action_module_1.get_shutdown_command_args('darwin')
    action_module_1.get_shutdown_command_args('freebsd')
    action_module_1.get_shutdown_command_args('solaris')
    action_module_1.get_shutdown_command_args('inux')
    action_module_1.get_shutdown_command_args('inux')
    action_module_1.get_shutdown_command_args('inux')
    action_module_1.get_shutdown

# Generated at 2022-06-25 07:25:56.749978
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action_module_0 = ActionModule()

    # Test valid use cases

    # Test invalid use cases

    # Test edge cases



# Generated at 2022-06-25 07:25:58.808862
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    action_module_1 = ActionModule()
    action_module_1.perform_reboot()


# Generated at 2022-06-25 07:26:04.881742
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    action_module_0 = ActionModule()
    action_module_0.check_boot_time = MagicMock(name='check_boot_time')
    action_module_0.check_boot_time.return_value = {}

    action_module_0.run_test_command = MagicMock(name='run_test_command')
    action_module_0.run_test_command.return_value = {}
    distribution_0 = {}
    original_connection_timeout_0 = 899
    action_kwargs_0 = {}
    result_0 = action_module_0.validate_reboot(distribution_0, original_connection_timeout_0, action_kwargs_0)
    assert result_0 == {'rebooted': True, 'changed': True}



# Generated at 2022-06-25 07:26:14.720863
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    action_module_0 = ActionModule()
    test_system_distribution_0 = 'system_distribution'
    test_task_vars_0 = {}

    test_task_vars_0['ansible_facts'] = {'distribution': test_system_distribution_0}

    test_path_0 = '/tmp/test_path'
    test_path_1 = '/tmp/test_search_path_1'
    test_path_2 = '/tmp/test_search_path_2'
    test_path_array = [test_path_0, test_path_1, test_path_2]
    test_path_bin = '/tmp/test_path_bin'
    test_search_paths = test_path_1 + ':' + test_path_2

# Generated at 2022-06-25 07:26:18.402735
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    action_module_0 = ActionModule()
    action_module_0.perform_reboot(task_vars={"ansible_user": "ansible"}, distribution="Debian")


# Generated at 2022-06-25 07:26:19.403066
# Unit test for method get_distribution of class ActionModule

# Generated at 2022-06-25 07:26:23.866140
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():

    action_module_0 = ActionModule()
    task_vars_0 = {}
    distribution_0 = 'Ubuntu'

    result_06 = action_module_0.get_shutdown_command(task_vars_0, distribution_0)
    assert result_06 == '/sbin/shutdown'
    print('Successful - get_shutdown_command')
    print()
