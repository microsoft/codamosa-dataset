

# Generated at 2022-06-25 07:18:58.788075
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module_ = ActionModule()
    distribution = "Ubuntu"
    task_vars = {"ansible_distribution": distribution}

    expected_result = distribution

    actual_result = action_module_.get_distribution(task_vars)

    assert_equals(expected_result, actual_result)


# Generated at 2022-06-25 07:19:04.137108
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    #SetUp and Assert - get_distribution
    action_module_1 = ActionModule()
    assert action_module_1.get_distribution(task_vars={'ansible_distribution': 'Ubuntu'}) == 'Ubuntu'


# Generated at 2022-06-25 07:19:14.774018
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    action_module_0 = ActionModule()

    stdin_mock = MagicMock()

    option_values = []

    def effect(name, value):
        option_values.append((name, value))

    set_option = MagicMock(side_effect=effect)
    get_option = MagicMock(side_effect=lambda x: option_values[x][1])

    action_module_0._connection = type('', (object,), dict(
        transport='ssh',
        get_option=get_option,
        set_option=set_option,
        _new_stdin=stdin_mock
    ))
    action_module_0._connection.get_option.__name__ = 'get_option'
    action_module_0._connection.set_option.__name__ = 'set_option'



# Generated at 2022-06-25 07:19:19.327529
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    action_module_1 = ActionModule()
    distribution = 'something'
    result = action_module_1.get_shutdown_command(distribution)
    assert result is not None


# Generated at 2022-06-25 07:19:21.438990
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module = ActionModule()
    assert action_module.get_shutdown_command_args('') == ''


# Generated at 2022-06-25 07:19:25.930035
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    action_module_0 = ActionModule()
    reboot_timeout = 300;
    assert action_module_0.do_until_success_or_timeout(action=action_module_0.check_boot_time, action_desc='last boot time check', reboot_timeout=reboot_timeout, distribution='Red Hat', action_kwargs={'previous_boot_time': '2017-06-30T22:04:29Z'}) == None


# Generated at 2022-06-25 07:19:37.266523
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    dict_0 = dict()
    dict_0['distribution'] = 'RedHat_7'
    dict_0['distrib_id'] = 'RedHat_7'
    dict_0['distrib_major_version'] = '7'
    dict_0['distrib_release'] = '7.5'
    dict_0['distrib_variant'] = 'Server'

# Generated at 2022-06-25 07:19:44.632317
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():

    #
    # Test case: raise exception
    #

    # Construct the task to test
    action_module = ActionModule()
    action_module._task = Task()
    action_module._task.action = 'test action'
    action_module.DEFAULT_REBOOT_TIMEOUT = 0
    action_module.check_boot_time_fail_count = 0

    # Mock the check_boot_time function
    def check_boot_time(distribution, previous_boot_time):
        if action_module.check_boot_time_fail_count < 5:
            action_module.check_boot_time_fail_count += 1
            raise Exception('error')
        return 'boottime'

    # Call the do_until_success_or_timeout method and verify it raised an exception

# Generated at 2022-06-25 07:19:45.672490
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    test_case_0()


# Generated at 2022-06-25 07:19:49.912961
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():

    action_module = ActionModule()
    action_module.set_task(task_0)
    action_module.set_connection(connection_0)

    task_vars = dict()
    result = action_module.perform_reboot(task_vars, 'amzn')
    print(result)


# Generated at 2022-06-25 07:20:20.746482
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    test_module = ActionModule()
    assert test_module != None


# Generated at 2022-06-25 07:20:26.856407
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    print ('\nRunning test method check_boot_time of class ActionModule')
    action_module_1 = ActionModule()
    action_module_1._task.args = {'test_command': 'uptime'}
    action_module_1._task.action = 'reboot'
    action_module_1._low_level_execute_command = Mock(return_value={'rc': 0, 'stderr': '', 'stdout': '12:00am'})
    action_module_1._task.action = 'reboot'
    action_module_1._task.args = {'test_command': 'uptime'}
    action_module_1._task.args = {'test_command': 'uptime'}
    action_module_1._connection = Mock()
    action_module_1._connection.get_

# Generated at 2022-06-25 07:20:28.585002
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    action_module_0 = ActionModule()
    result = action_module_0.get_system_boot_time(distribution=__new__(str))
    assert(type(result) == str)


# Generated at 2022-06-25 07:20:32.942297
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action_module_1 = ActionModule()
    action_module_1.deprecated_args()


# Generated at 2022-06-25 07:20:36.669414
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    action_module_0 = ActionModule()
    task_vars_0 = {}
    distribution_0 = "ACHTUNG"
    action_module_0.get_shutdown_command(task_vars_0, distribution_0)


# Generated at 2022-06-25 07:20:46.795676
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module = ActionModule()
    assert action_module.get_shutdown_command_args('centos') == "now"
    assert action_module.get_shutdown_command_args('redhat') == "now"
    assert action_module.get_shutdown_command_args('fedora') == "now"
    assert action_module.get_shutdown_command_args('solaris') == "0"
    assert action_module.get_shutdown_command_args('suse') == "now"
    assert action_module.get_shutdown_command_args('debian') == "now"
    assert action_module.get_shutdown_command_args('ubuntu') == "now"
    assert action_module.get_shutdown_command_args('gentoo') == "now"
    assert action_module.get

# Generated at 2022-06-25 07:20:49.090544
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action_module_0 = ActionModule()
    action_module_0.deprecated_args()


# Generated at 2022-06-25 07:20:52.268227
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # TODO: Pass good arguments to method
    try:
        obj_a = ActionModule()
        ret = obj_a.do_until_success_or_timeout(action, reboot_timeout)
        assert ret
    except Exception as e:
        assert False


# Generated at 2022-06-25 07:20:56.434821
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    action_module_0 = ActionModule()
    distribution_0 = 'Ubuntu'
    action_module_0.get_system_boot_time(distribution_0)


# Generated at 2022-06-25 07:21:02.100517
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    test_reboot_action_module = ActionModule()
    test_distribution = 'Ubuntu'
    expected_result = None

    try:
        result = test_reboot_action_module.run_test_command(test_distribution)
    except Exception as e:
        if to_text(e) == to_text(expected_result):
            print("Success")
        else:
            print("Error in test_ActionModule_run_test_command: expected: " + to_text(e))
    else:
        print("Error in test_ActionModule_run_test_command: expected: " + to_text(e))


# Generated at 2022-06-25 07:22:33.402872
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    action_module_0 = ActionModule()
    distribution_0 = "Debian"
    assert action_module_0.get_system_boot_time(distribution_0) is not None


# Generated at 2022-06-25 07:22:43.627109
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    from ansible.module_utils.reboot import ActionModule
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts import DefaultFactCollector
    from ansible.module_utils.facts.collector.base import BaseFactCollector

    class MockModule(object):
        def __init__(self):
            self.run_command_environ_update = {}

    from ansible.connection.connection import Connection
    from ansible.inventory.host import Host
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import connection_loader, module_loader

    class MockPlayContext(PlayContext):
        def __init__(self):
            super(MockPlayContext, self).__init__()

# Generated at 2022-06-25 07:22:49.807771
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    action_module_0 = ActionModule()
    task_vars_0 = dict()
    distribution_0 = 'linux'
    assert action_module_0.get_shutdown_command(task_vars_0, distribution_0) == '/sbin/shutdown'


# Generated at 2022-06-25 07:22:56.503497
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    def action_0_func(args):
        if args.get('reboot_timeout') >= 9:
            return {'success': True}
        else:
            raise Exception("failed")
    def action_0_description_func(args):
        return "description_0"
    try:
        case_0_result = action_module_0.do_until_success_or_timeout(action_0_func, "description_0", 10)
        assert case_0_result['success'] == True
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-25 07:22:59.795871
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module_0 = ActionModule()
    # Put test code here
    assert True == True # TODO: implement your test here


# Generated at 2022-06-25 07:23:02.918962
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    # FIXME: Add unit tests
    pass


# Generated at 2022-06-25 07:23:09.364766
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Initializing test case context
    action_module_0 = ActionModule()
    test_case_0_task_vars = dict()
    test_case_0_task_vars['ansible_facts'] = dict()
    test_case_0_task_vars['ansible_facts']['ansible_distribution'] = 'Ubuntu'
    test_case_0_task_vars['ansible_facts']['ansible_distribution_release'] = '16.04'
    test_case_0_task_vars['ansible_facts']['ansible_distribution_version'] = '16.04'
    test_case_0_task_vars['ansible_facts']['ansible_os_family'] = 'Debian'

# Generated at 2022-06-25 07:23:19.799824
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # Arrange
    action_module_0 = ActionModule()
    action_module_0._task = Mock(action='dummy')

# Generated at 2022-06-25 07:23:23.633872
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    action_module_1 = ActionModule()
    distribution = action_module_1.get_distribution()
    original_connection_timeout = None
    action_kwargs = {}
    action_module_1.validate_reboot(distribution, original_connection_timeout, action_kwargs)


# Generated at 2022-06-25 07:23:30.155180
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    action_module = ActionModule()
    action_module.check_boot_time = MagicMock(side_effect=[Exception('test'), True, True])
    action_module.run_test_command = MagicMock(side_effect=[True, True, True, Exception('test'), True])
    result = action_module.validate_reboot('debian', action_kwargs={'previous_boot_time': 1})
    assert result['rebooted'] == True
    action_module.check_boot_time.assert_called()
    assert action_module.run_test_command.call_count == 5
