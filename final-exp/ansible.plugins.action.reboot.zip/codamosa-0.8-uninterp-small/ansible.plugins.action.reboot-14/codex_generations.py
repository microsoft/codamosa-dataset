

# Generated at 2022-06-25 07:18:50.352543
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    result = action_module_0.run()
    print(result)


# Generated at 2022-06-25 07:18:53.938069
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module_0 = ActionModule()
    distribution_0 = 'Ubuntu'
    var_0 = action_module_0.get_shutdown_command_args(distribution_0)
    assert var_0 == '-r now', "Value mismatch"


# Generated at 2022-06-25 07:19:04.369685
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # Test with no timeout and no sleeps
    action_module_100 = ActionModule()
    action_module_100.do_until_success_or_timeout(
            action=action_module_100.check_boot_time,
            action_desc="last boot time check",
            reboot_timeout=0,
            distribution='Ubuntu',
            action_kwargs={})

    # Test with no timeout and 12 sleeps
    action_module_101 = ActionModule()
    action_module_101.do_until_success_or_timeout(
            action=action_module_101.check_boot_time,
            action_desc="last boot time check",
            reboot_timeout=0,
            distribution='Ubuntu',
            action_kwargs={'previous_boot_time': 'test_12_sleeps'})

    # Test with no

# Generated at 2022-06-25 07:19:05.422981
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    action_module_0 = ActionModule()



# Generated at 2022-06-25 07:19:09.157451
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module = ActionModule()
    task_vars = None
    assert action_module.get_distribution(task_vars) == 'FreeBSD'


# Generated at 2022-06-25 07:19:13.714382
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  action_module = ActionModule()
  print(action_module.run())

# Unit test the above functions

# Generated at 2022-06-25 07:19:23.657885
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    global action_module_0
    assert action_module_0.action_module.get_shutdown_command_args('redhat') == '-r now'
    assert action_module_0.action_module.get_shutdown_command_args('centos') == '-r now'
    assert action_module_0.action_module.get_shutdown_command_args('fedora') == '-r now'
    assert action_module_0.action_module.get_shutdown_command_args('debian') == '-r now'
    assert action_module_0.action_module.get_shutdown_command_args('ubuntu') == '-r now'
    assert action_module_0.action_module.get_shutdown_command_args('oracle') == '-r now'
    assert action_module_0

# Generated at 2022-06-25 07:19:30.206703
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    import time
    import unittest
    import tempfile
    import shutil
    import os
    from sys import version_info
    from ansible import context
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.common import to_bytes
    from ansible.plugins.loader import action_loader
    from ansible.plugins.action.reboot import ActionModule
    from ansible.plugins.action.reboot import default_platform_facts
    from ansible.playbook.play_context import PlayContext
    from unit.mock.loader import DictDataLoader
    from unit.mock.path import mock_unfrackpath_noop
    from unit.mock.connection import Connection
    from unit.test_loader import DictDataLoader
    from unit.mock.executor import ActionModuleExec

# Generated at 2022-06-25 07:19:41.303234
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    action_module = ActionModule()
    method_name = 'validate_reboot'
    task_vars = {}
    display.display = Mock()
    display.vvv = Mock()
    display.debug = Mock()
    action_module._task = Mock()
    action_module._task.action = "fake_action"
    action_module._low_level_execute_command = Mock(side_effect=[AnsibleConnectionFailure(), "test_response"])

    display.display.assert_called_once_with('hi')
    display.vvv.assert_called_once_with('hi')
    display.debug.assert_called_once_with('hi')
    assert_equal(action_module._low_level_execute_command.call_count, 2)


# Generated at 2022-06-25 07:19:43.013944
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


if __name__ == "__main__":

    test_case_0()
    test_ActionModule_run()
    print("All tests passed!")

# Generated at 2022-06-25 07:20:13.987877
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module = ActionModule()
    distribution = action_module._get_value_from_facts('DISTRIBUTION_NAMES', 'SLES', 'SLES_NAME')
    assert distribution == 'SLES'


# Generated at 2022-06-25 07:20:23.149959
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    action_module_1 = ActionModule()
    action_module_1._task = Task()
    action_module_1._task.action = 'reboot'
    action_module_1._task.args = {'patterns': '.xyz', 'file_type': 'file'}
    action_module_1._play_context = PlayContext()
    action_module_1._play_context.check_mode = True
    action_module_1._play_context.become = True
    action_module_1._connection = Connection()
    action_module_1._connection.transport = 'smart'
    action_module_1._connection.set_options({'remote_user': 'remote_user_value'})

# Generated at 2022-06-25 07:20:28.537639
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module_0 = ActionModule()

    assert action_module_0.get_shutdown_command_args('Linux') == "--no-wall -r now"

    assert action_module_0.get_shutdown_command_args('AIX') == "now"

    assert action_module_0.get_shutdown_command_args('FreeBSD') == "-p now"

    assert action_module_0.get_shutdown_command_args('NetBSD') == "-p now"

    assert action_module_0.get_shutdown_command_args('OpenBSD') == "-p now"

    assert action_module_0.get_shutdown_command_args('SunOS') == "-y -i5 -g0"

    assert action_module_0.get_shutdown_command_args('Darwin') == "now"

# Generated at 2022-06-25 07:20:31.966164
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module_0 = ActionModule()
    assert(action_module_0.get_shutdown_command_args('RedHat') == '-r now')
    assert(action_module_0.get_shutdown_command_args('Debian') == '-r now')
    assert(action_module_0.get_shutdown_command_args('Suse') == '-r now')
    assert(action_module_0.get_shutdown_command_args('CoreOS') == '-r now')
    assert(action_module_0.get_shutdown_command_args('Default') == '-r')


# Generated at 2022-06-25 07:20:33.642250
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    result = {}
    action_module_0 = ActionModule()
    action_module_0.run_test_command(action_module_0._task.args)
    assert('{}'.format(action_module_0._task.action) not in result)


# Generated at 2022-06-25 07:20:38.121681
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

    task_vars_0 = {}
    tmp_0 = ''
    action_module_0.run(tmp_0, task_vars_0)

    task_vars_1 = {}
    tmp_1 = ''
    action_module_0.run(tmp_1, task_vars_1)


# Generated at 2022-06-25 07:20:41.978448
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    action_module_0 = ActionModule()

    # Testing branch invalid_0
    # Testing branch invalid_1
    # Testing branch invalid_2
    # Testing branch invalid_3
    # Testing branch invalid_4
    # Testing branch invalid_5
    # Testing branch invalid_6
    # Testing branch invalid_7
    # Testing branch invalid_8
    # Testing branch invalid_9
    # Testing branch invalid_10
    # Testing branch invalid_11
    # Testing branch invalid_12
    # Testing branch invalid_13
    # Testing branch invalid_14
    # Testing branch invalid_15
    # Testing branch invalid_16
    # Testing branch invalid_17
    # Testing branch invalid_18


# Generated at 2022-06-25 07:20:50.284387
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    action_module_0 = ActionModule()
    action_module_0._task.args = {'test_command': 'echo foo'}
    task_vars_0 = {
        'ansible_distribution': 'ubuntu'
        }
    action_module_0._low_level_execute_command = mock.MagicMock()
    display.vvv = mock.MagicMock()
    action_module_0._task.action = 'test action'
    action_module_0.run_test_command('ubuntu', task_vars=task_vars_0)
    action_module_0._low_level_execute_command.assert_called_once_with('echo foo', sudoable=False)
    assert display.vvv.call_args_list == []


# Generated at 2022-06-25 07:20:57.635469
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module_test = ActionModule()
    test_distribution = 'test_distribution'
    try:
        action_module_test._get_value_from_facts('TEST_COMMANDS', test_distribution, 'DEFAULT_TEST_COMMAND')
    except AnsibleError:
        pass
    except Exception as e:
        raise e
    else:
        raise AssertionError('Expected Exception was not raised.')


# Generated at 2022-06-25 07:21:08.901618
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():

    action_module = ActionModule()
    if not isinstance(action_module, ActionModule):
        raise Exception('Expected to be instance of ActionModule')

    task_vars_0 = {}
    task_vars_0['ansible_distribution'] = 'Ubuntu'
    task_vars_0['ansible_distribution_release'] = '14.04'
    task_vars_0['ansible_distribution_version'] = '14.04'

    distribution_0 = action_module.get_distribution(task_vars_0)

    if distribution_0 != 'Ubuntu 14.04':
        raise Exception('Expected to be Ubuntu 14.04')


# Generated at 2022-06-25 07:22:09.931107
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    print("")
    print("test_ActionModule_validate_reboot")
    action_module_0 = ActionModule()
    # Run unit test
    action_module_0.validate_reboot()


# Generated at 2022-06-25 07:22:12.192900
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    action_module_0 = ActionModule()
    action_module_0.test_params = dict()
    task_vars = dict()
    result = action_module_0.get_shutdown_command(task_vars)


# Generated at 2022-06-25 07:22:15.043957
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module_0 = ActionModule()
    distribution_0 = 'DEFAULT'
    try:
        result_0 = action_module_0.get_shutdown_command_args(distribution_0)
    except Exception as e:
        print(e)
    else:
        print(result_0)


# Generated at 2022-06-25 07:22:21.447994
# Unit test for method run of class ActionModule
def test_ActionModule_run():  # noqa
    # default arguments
    kwargs = {}
    kwargs['tmp'] = ''
    kwargs['task_vars'] = {}
    # required arguments
    kwargs['self'] = ''
    kwargs['tmp'] = ''
    kwargs['task_vars'] = ''
    ret = ActionModule().run(**kwargs)
    assert ret['failed'] == False


# Generated at 2022-06-25 07:22:24.010916
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arrange
    action_module_0 = ActionModule()

    # Act
    result = action_module_0.run()

    # Assert
    assert result == {'start': 'start', 'failed': False, 'rebooted': False}



# Generated at 2022-06-25 07:22:25.529988
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    task_vars = {}
    module_result_0 = action_module_0.check_boot_time(distribution_0, previous_boot_time_0)


# Generated at 2022-06-25 07:22:32.740514
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    action_module_0 = ActionModule()
    # ###
    # # You can test your code here using the unittest module
    # # You can test your code here using the unittest module
    # # You can test your code here using the unittest module
    # # You can test your code here using the unittest module
    # ###
    # Unit test for method validate_reboot of class ActionModule

# Generated at 2022-06-25 07:22:34.673449
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action_module_0 = ActionModule()
    print("Unit test for: ActionModule_deprecated_args")
    display.debug("Calling deprecated_args()")
    action_module_0.deprecated_args()


# Generated at 2022-06-25 07:22:43.628264
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    TASK_VARS_0 = {"ansible_loop_var": "item", "ansible_ssh_host": "172.17.0.2"}
    action_module_0.run(task_vars=TASK_VARS_0)
    action_module_0.run(task_vars=TASK_VARS_0)
    TASK_VARS_1 = {"ansible_loop_var": "item", "ansible_ssh_host": "172.17.0.2", "task_vars": "task_vars"}
    action_module_0.run(task_vars=TASK_VARS_1)

# Generated at 2022-06-25 07:22:48.877469
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_1 = ActionModule()
    reset_connection_1 = mock.Mock()

    from ansible.plugins.action import ActionModule as ActionModule_2
    action_module_2 = ActionModule_2()

    with mock.patch.object(ActionModule, '_reset_connection') as mock_reset_connection_0:

        mock_reset_connection_0.return_value = reset_connection_1

        action_module_2.run(tmp=True, task_vars={"ansible_connection": 'local'})

        mock_reset_connection_0.assert_called_with(tmp=True, task_vars={"ansible_connection": 'local'})
