

# Generated at 2022-06-25 07:18:53.392790
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    action_module_1 = ActionModule()
    distribution_1 = ""
    task_vars_1 = {}

    assert action_module_1.perform_reboot(task_vars_1, distribution_1) == {'start': datetime.utcnow(), 'failed': False, 'rebooted': False}


# Generated at 2022-06-25 07:18:57.225085
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    # Test empty
    action_module = ActionModule()
    assert action_module.get_shutdown_command_args('test') == '-h now'


# Generated at 2022-06-25 07:19:00.112568
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    print("Test getting distribution from facts")
    action_module = ActionModule()
    distribution = action_module.get_distribution({'ansible_facts': {'distribution': 'Fedora'}})
    assert distribution == 'Fedora'


# Generated at 2022-06-25 07:19:07.431001
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():

    action_module_0 = ActionModule()
    try:  # Using Lambda function as an action
        action_module_0.do_until_success_or_timeout(action=lambda: action_module_0.check_boot_time('Ubuntu', '12:00'), action_desc="last boot time check", reboot_timeout=10, distribution='Ubuntu', action_kwargs='previous_boot_time')

    except Exception as err:
        print(err.args)
        traceback.print_exc()
        raise err
    return action_module_0


# Generated at 2022-06-25 07:19:18.568678
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    distribution = 'Linux'

    action_module_0 = ActionModule()

    assert action_module_0.get_shutdown_command_args(distribution) == '-r now'

    distribution = 'FreeBSD'

    assert action_module_0.get_shutdown_command_args(distribution) == '-r now'

    distribution = 'OpenBSD'

    assert action_module_0.get_shutdown_command_args(distribution) == '-r now'

    distribution = 'Darwin'

    assert action_module_0.get_shutdown_command_args(distribution) == '-r now'

    distribution = 'SunOS'

    assert action_module_0.get_shutdown_command_args(distribution) == '-y -i6'

    distribution = 'AIX'

    assert action_

# Generated at 2022-06-25 07:19:20.329344
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    action_module_0 = ActionModule()
    action_module_0.run_test_command()

# Generated at 2022-06-25 07:19:21.998082
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    action_module = ActionModule()
    action_module.get_system_boot_time('Linux')


# Generated at 2022-06-25 07:19:28.986695
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module_0 = ActionModule()

    result_0 = action_module_0.get_shutdown_command_args('redhat')
    assert(result_0 == '-r now')

    result_1 = action_module_0.get_shutdown_command_args('debian')
    assert(result_1 == '-r now')

    result_2 = action_module_0.get_shutdown_command_args('oracle')
    assert(result_2 == '-r now')

    result_3 = action_module_0.get_shutdown_command_args('freebsd')
    assert(result_3 == '-r now')

    result_4 = action_module_0.get_shutdown_command_args('archlinux')
    assert(result_4 == '-r now')

    result_

# Generated at 2022-06-25 07:19:36.809608
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module_0 = ActionModule()
    # 0. Should return DEFAULT_DISTRIBUTION if task_vars['ansible_distribution'] is not set
    task_vars_0 = {'ansible_distribution': None}
    expected_output = action_module_0.DEFAULT_DISTRIBUTION
    actual_output = action_module_0.get_distribution(task_vars=task_vars_0)
    assert(expected_output == actual_output)


# Generated at 2022-06-25 07:19:42.344152
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module_0 = ActionModule()
    action_module_0._task.action = 'reboot'
    action_module_0._task.args = {}
    action_module_0._task.args['boot_time_command'] = "date"
    distribution = 'any'
    previous_boot_time = "any"
    ActionModule.check_boot_time(action_module_0, distribution, previous_boot_time)


# Generated at 2022-06-25 07:20:41.819910
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    action_module_0 = ActionModule()
    test_command_0 = 'test_command_0'
    action_module_0._task.args['test_command'] = test_command_0
    action_kwargs = {}
    distribution_0 = 'centos'
    action_module_0.run_test_command(test_command=test_command_0, distribution=distribution_0)


# Generated at 2022-06-25 07:20:52.453824
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    print("Running test_ActionModule_get_shutdown_command_args...")
    action_module_0 = ActionModule()

    # Expected value returned from get_shutdown_command_args
    desired_return_value = "now"

    # Run method
    test_case_0_return_value = action_module_0.get_shutdown_command_args("a_distribution")

    # Check return value
    if test_case_0_return_value != desired_return_value:
        print("ERROR: Return value incorrect!\n")
        print("Expected: " + desired_return_value)
        print("Received: " + test_case_0_return_value)
        print("\nAborting test!\n")
        sys.exit(1)
    else:
        print("Test Passed!")

# Generated at 2022-06-25 07:20:59.597723
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    print("Testing ActionModule.get_shutdown_command")
    # Print test case name
    print("Test case 0")

    test_task_vars_0 = {}
    test_task_vars_0["ansible_os_family"] = "Linux"

    test_distribution_0 = "debian"

    # Perform test
    try:
        # Perform module function
        test_result_0 = action_module_0.get_shutdown_command(test_task_vars_0["ansible_os_family"], test_distribution_0)
    except Exception:
        # Catch and print thrown exception
        print("Exception thrown in ActionModule.get_shutdown_command")
        print(traceback.format_exc())


# Generated at 2022-06-25 07:21:11.874768
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Test case where task_vars isn't provided
    try:
        action_module_1 = ActionModule()
        action_module_1.get_shutdown_command(None, 'Ubuntu')
    except Exception as e:
        if e.args[0] != "task_vars must be provided":
            print('get_shutdown_command raised exception with message: "' + e.args[0] + '", expected: "task_vars must be provided"')
            return False
    else:
        print('get_shutdown_command did not throw an exception when task_vars was not provided')
        return False

    # Test case where task_vars is invalid

# Generated at 2022-06-25 07:21:14.966359
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    action_module_1 = ActionModule()
    distribution = "Ubuntu"
    action_module_1.get_system_boot_time(distribution)


# Generated at 2022-06-25 07:21:21.214568
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():

    action_module_0 = ActionModule()

    result_bool_0 = action_module_0.validate_reboot(
        'rhev',
        None,
        action_kwargs={
            'previous_boot_time': '2018-08-14 16:12:26.769715+00:00'
        })

    assert result_bool_0 == {
        'changed': True,
        'rebooted': True
    }


# Generated at 2022-06-25 07:21:30.029571
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    # Test 1 run_test_command('freebsd', **kwargs)
    action_module_1 = ActionModule()
    action_module_1._task.args = {'test_command': 'echo "hello"'}
    action_module_1._connection.exec_command = stub_exec_command_with_command_returning_rc_0

    try:
        action_module_1.run_test_command(distribution='freebsd')
    except Exception as e:
        print(to_text(e))

    # Test 2 run_test_command('freebsd', **kwargs)
    action_module_2 = ActionModule()
    action_module_2._task.args = {'test_command': 'echo "hello"'}
    action_module_2._connection.exec_command = stub_exec_command_

# Generated at 2022-06-25 07:21:32.172157
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module_0 = ActionModule()
    result = action_module_0.get_distribution()
    assert result is not None


# Generated at 2022-06-25 07:21:40.657779
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Load module and run unit test
mock_module = imp.load_source('reboot', '/usr/lib/python2.7/site-packages/ansible/modules/system/reboot.py')
test_suite = unittest.TestLoader().loadTestsFromTestCase(mock_module.TestAnsibleReboot)
unittest.TextTestRunner(verbosity=2).run(test_suite)

# Create reboot task
reboot_task = {
    'action': 'reboot',
    'args': {}}

# Create connection to localhost

# Generated at 2022-06-25 07:21:41.757259
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action_module_0 = ActionModule()
    action_module_0.deprecated_args()


# Generated at 2022-06-25 07:23:41.404129
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action_module_0 = ActionModule()
    action_module_0.deprecated_args()

if __name__ == '__main__':

    test_case_0()

# Generated at 2022-06-25 07:23:46.779516
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module = ActionModule()
    distribution = action_module.get_distribution()

# Generated at 2022-06-25 07:23:50.540785
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    action_module_0 = ActionModule()
    action_module_0.run_test_command()


# Generated at 2022-06-25 07:23:53.706249
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module_0 = ActionModule()
    distribution_0 = None
    previous_boot_time_0 = ""

    # Call method
    result_0 = action_module_0.check_boot_time(distribution_0, previous_boot_time_0)
    assert result_0 == None


# Generated at 2022-06-25 07:23:58.363884
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    action_module = ActionModule()
    action_module.do_until_success_or_timeout(action_module.test_case_0, action_desc='test_case_0', reboot_timeout=30)


# Generated at 2022-06-25 07:24:00.253339
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module = ActionModule()
    args = action_module.get_shutdown_command_args("n")
    assert args == "-r now"


# Generated at 2022-06-25 07:24:01.529537
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    action_module = ActionModule()
    assert action_module.run_test_command(None)


# Generated at 2022-06-25 07:24:03.026860
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module_1 = ActionModule()
    result_1 = action_module_1.get_shutdown_command_args("Debian")
    assert result_1 == " -h now "


# Generated at 2022-06-25 07:24:05.931279
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    action_module = ActionModule()

    action_module.validate_reboot(distribution='NT')
    action_module.validate_reboot(distribution='NT', original_connection_timeout='NT', action_kwargs='NT')


# Generated at 2022-06-25 07:24:06.848399
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module.run()
