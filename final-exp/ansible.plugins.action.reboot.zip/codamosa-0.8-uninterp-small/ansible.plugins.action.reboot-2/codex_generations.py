

# Generated at 2022-06-25 07:18:54.555525
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # init an test ActionModule object
    am = ActionModule()
    # init a test task
    task = DummyTask()
    # init a test task vars
    task_vars = dict(ansible_os_family='FreeBSD')

    # check if the ActionModule object return a shutdown command
    cmd = am.get_shutdown_command(task_vars, "FreeBSD")
    assert cmd == "/sbin/shutdown", "The test_ActionModule_get_shutdown_command has failed"


# Generated at 2022-06-25 07:19:04.517987
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    module_0 = ActionModule()
    module_0.set_task(task_def_0)
    module_0.set_connection(connection_def_0)
    module_0.set_loader(loader_def_0)
    module_0.set_play_context(play_context_0)
    test_input_0 = {}
    test_input_0['task_vars'] = task_vars_0
    test_result_0 = module_0.perform_reboot(**test_input_0)
    test_result_ref_0 = {'start': datetime.datetime(2018, 4, 2, 0, 26, 14, 691354), 'failed': False, 'rc': 0}
    assert test_result_0 == test_result_ref_0


# Generated at 2022-06-25 07:19:09.326376
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
  a1 = ActionModule(dict(), dict())
  tc = dict(ansible_facts=dict(os=dict(family="RedHat"), os_family="RedHat"))
  assert_equal(a1.get_distribution(tc), "RedHat")
  tc = dict(ansible_distribution="RedHat", ansible_distribution_version="6.4")
  assert_equal(a1.get_distribution(tc), "RedHat")


# Generated at 2022-06-25 07:19:16.479089
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    # Given
    args = {
        'reboot_timeout_sec': 1,
        'test_command': 'test'
    }
    mock_task = Mock()
    mock_task.action = 'reboot'
    mock_task.args = args
    mock_self = Mock()
    mock_self._task = mock_task

    # Action
    mock_self.deprecated_args()

    # Assertions
    assert mock_task.args == args


# Generated at 2022-06-25 07:19:25.275620
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # Pretend it's RedHat and set up an ActionModule instance
    units = ActionModule()
    units._connection.host = "redhat.local"

    # Set up a fake result from a low_level_execute_command call
    fake_result = {'rc': 0, 'stdout': b'Thu Nov 10 13:55:54 PST 2016\n', 'stderr': b''}

    # Define a boot_time and a new one that is the same, so we can catch the exception
    # The "last boot time" is the time before the reboot, and the "current boot time" is the time after
    last_boot_time = 'Thu Nov 10 13:55:54 PST 2016'
    current_boot_time = last_boot_time

    # This is what the method we're testing uses to get the current boot time (after the reboot

# Generated at 2022-06-25 07:19:36.564188
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    pass

if __name__ == '__main__':
    test_cases = [
        'test_case_0',
        'test_ActionModule_validate_reboot',
    ]
    test_functions = {}
    test_class_instances = {}

    # Loop through all possible test cases
    for test_case in test_cases:
        # Get the corresponding method
        test_function = globals()[test_case]
        test_functions[test_case] = test_function

        # If the function being tested is a class method,
        # we need to instantiate the class
        if 'ActionModule' in test_case:
            # Instantiate the class
            test_class_instances['test_case_0'] = ActionModule()
            # Get the class instance in the test case
            test_class_

# Generated at 2022-06-25 07:19:42.218842
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    task_vars = {'ansible_distribution': 'CentOS', 'ansible_distribution_version': '7.2', 'ansible_distribution_release': 'Core', 'ansible_os_family': 'RedHat'}
    action_module = ActionModule()
    result = action_module.get_shutdown_command(task_vars, "CentOS")
    assert result == '/sbin/shutdown'


# Generated at 2022-06-25 07:19:48.409642
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # Setup

    # Test
    action_module = ActionModule(
        task={'args': {}, 'action': 'reboot'},
        connection={},
        play_context={},
        loader={},
        templar={},
        shared_loader_obj={})

    try:
        action_module.check_boot_time()
    except Exception as e:
        if isinstance(e, Exception):
            raise Exception(e)


# Generated at 2022-06-25 07:19:57.154584
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # This is a hacky way to get an object of class ActionModule to be able to call the method under test.
    class MockActionModule(ActionModule):
        def __init__(self, task_vars):
            self._task = MockTask(task_vars)

    action_module = MockActionModule({})
    try:
        action_module.do_until_success_or_timeout(action=test_case_0, reboot_timeout=10, distribution='', action_desc='', action_kwargs=None)
        error = False
    except:
        error = True
    assert error


# Generated at 2022-06-25 07:20:03.833654
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(
        _task=dict(),
        connection=str(),
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None)
    # general test
    try:
        result = action_module_0.run(tmp=bool(), task_vars=dict())
        # make sure a TimedOutException has been raised
        assert False
    except TimedOutException as e:
        pass


# Generated at 2022-06-25 07:20:36.947844
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    dict_0 = { }
    dict_1 = { }
    action_module_0 = ActionModule(**dict_0)
    task_vars_0 = dict_1
    str_0 = action_module_0.perform_reboot(task_vars_0)
    print(str_0)

if __name__ == '__main__':
    test_ActionModule_perform_reboot()

# Generated at 2022-06-25 07:20:38.477205
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Run test_ActionModule_run
test_ActionModule_run()

# Generated at 2022-06-25 07:20:39.305488
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()

# Generated at 2022-06-25 07:20:49.131534
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    dict_0 = {}
    int_0 = -3721
    action_module_0 = ActionModule(**dict_0)
    try:
        action_module_0.do_until_success_or_timeout(action='default', reboot_timeout=int_0, action_desc='s', distribution='s')
    except TimedOutException as e:
        assert to_native(e) == "Timed out waiting for s (timeout=-3721)"


# Generated at 2022-06-25 07:20:53.364689
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    # Unit test for method run_test_command of class ActionModule
    assert True
    # Comment for test_case test_ActionModule_run_test_command
    dict_0 = {}
    int_0 = -3721
    action_module_0 = ActionModule(**dict_0)
    # End of test for test_case test_ActionModule_run_test_command



# Generated at 2022-06-25 07:20:58.361745
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    dict_0 = {}
    int_0 = -3721
    action_module_0 = ActionModule(**dict_0)
    action_module_0.deprecated_args()


# Generated at 2022-06-25 07:21:03.123676
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    dict_0 = {}
    action_module_0 = ActionModule(**dict_0)

    action_module_0.get_system_boot_time = Mock(return_value=0)

    action_module_0.check_boot_time('slackware', 'freebsd')


# Generated at 2022-06-25 07:21:15.442001
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    dict_0 = {}
    int_0 = -3721
    dict_1 = {}
    dict_2 = {}
    dict_2['checkmode'] = dict_1
    dict_1['meta'] = dict_2
    dict_2 = {}
    dict_2['a'] = dict_1
    dict_1['args'] = dict_2
    dict_2 = {}
    dict_2['a'] = dict_1
    dict_1['action'] = dict_2
    dict_2 = {}
    dict_2['a'] = dict_1
    dict_1['handler'] = dict_2
    dict_2 = {}
    dict_2['a'] = dict_1
    dict_1['task'] = dict_2
    dict_2 = {}
    dict_2['a'] = dict_1
   

# Generated at 2022-06-25 07:21:20.812869
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    dict_0 = {}
    int_0 = -3721
    action_module_0 = ActionModule(**dict_0)
    task_vars_0 = {}
    suite = unittest.TestSuite()
    suite.addTest(ActionModuleTestCase('test_get_distribution'))
    result = unittest.TextTestRunner().run(suite)


# Generated at 2022-06-25 07:21:22.430312
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    dict_0 = {}
    int_0 = -3721