

# Generated at 2022-06-25 07:18:56.754227
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():

    # Test case 1
    # Test action: check_boot_time
    # Test function: reboot_timeout = 2
    # test success only
    action_module_1 = ActionModule()
    action_module_1.do_until_success_or_timeout(check_boot_time, 2, "last boot time check")


# Generated at 2022-06-25 07:19:04.820852
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    action_module_1 = ActionModule()
    distribution_1 = "Ubuntu"
    expected_1 = "7997"
    actual_1 = action_module_1.get_system_boot_time(distribution_1)
    assert expected_1 == actual_1
    distribution_2 = "Debian"
    expected_2 = "7797"
    actual_2 = action_module_1.get_system_boot_time(distribution_2)
    assert expected_2 == actual_2
    distribution_3 = "CentOS"
    expected_3 = "7597"
    actual_3 = action_module_1.get_system_boot_time(distribution_3)
    assert expected_3 == actual_3
    distribution_4 = "RedHat"
    expected_4 = "7397"
    actual_

# Generated at 2022-06-25 07:19:11.427178
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    action_module_0 = ActionModule()
    action_module_0.DEFAULT_REBOOT_TIMEOUT = 300
    action_module_0.DEFAULT_CONNECT_TIMEOUT = 60
    action_module_0._task.action = 'reboot'
    task_vars_0 = {}
    result_0 = action_module_0.perform_reboot(task_vars_0, 'distribution_0')
    assert result_0['start'] is not None
    assert result_0['failed'] is False



# Generated at 2022-06-25 07:19:18.337809
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module_0 = ActionModule()

    # Call the method with a blank distribution and previous_boot_time
    try:
        action_module_0.check_boot_time("","")
    except Exception as e:
        if (str(e) == "'boot time has not changed'"):
            print("Testcase Passed")
        else:
            raise e
    except:
        raise Exception("Testcase Failed")    


# Generated at 2022-06-25 07:19:19.714333
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    actionModule = ActionModule()
    assert actionModule.run_test_command('') == None


# Generated at 2022-06-25 07:19:24.036621
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module_0 = ActionModule()
    task_vars_0 = {
        'ansible_distribution': 'Ubuntu',
        'ansible_distribution_release': 'Maverick Meerkat',
    }

    result = action_module_0.get_distribution(task_vars_0)
    assert result == 'Ubuntu Mavericks'


# Generated at 2022-06-25 07:19:30.497324
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module_0 = ActionModule()
    arg_0 = 'distribution'

# Generated at 2022-06-25 07:19:32.636200
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action_module_0 = ActionModule()
    assert True

# Generated at 2022-06-25 07:19:37.833412
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    try:
        action_module_1 = ActionModule()
        action_module_1.validate_reboot("{ N/A }")
    except Exception as err:
        print("Test failed - exception thrown")
        print("tb:", traceback.format_exc())
        return False
    return True


# Generated at 2022-06-25 07:19:48.453872
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    action_module_0 = ActionModule()
    distribution_0 = ['Linux']
    test_command_0 = 'date'
    
    display.vvv('{action}: attempting post-reboot test command'.format(action='reboot'))
    display.debug('{action}: attempting post-reboot test command \'{command}\''.format(action='reboot', command=test_command_0))
    execute_command_ret_1 = {'rc': 0, 'stderr': '', 'stdout': "Thu Oct 18 15:47:58 UTC 2018\n"}
    execute_command_mock_1.return_value = execute_command_ret_1
    command_result_0 = action_module_0._low_level_execute_command(test_command_0, sudoable=True)
    
    
    
    


# Generated at 2022-06-25 07:20:48.334483
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = {"__mock_connection__": MockConnection(),
                 "ansible_facts": {"os_family": "RedHat"}}
    action_module_0 = ActionModule()
    test_case_0()
    result = action_module_0.run(tmp=None, task_vars=task_vars)
    print(result)

test_ActionModule_run()

# Generated at 2022-06-25 07:20:53.370073
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    pass


# Generated at 2022-06-25 07:20:55.653247
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():

    action_module_0 = ActionModule()

    action_module_0.get_shutdown_command()


# Generated at 2022-06-25 07:20:58.403069
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module_0 = ActionModule()

    action_module_0.check_boot_time("Debian")


# Generated at 2022-06-25 07:21:10.754998
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module = ActionModule()
    # Use the file here https://github.com/ansible/ansible/pull/33689/files#diff-7b2a0c43d3fbf6f67cc6eee24eb05250R831
    # to do the testing

# Generated at 2022-06-25 07:21:14.699373
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Check the return value of method run of class ActionModule.
    '''
    action_module = ActionModule()
    print(action_module.run())


# Generated at 2022-06-25 07:21:23.356643
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # Perform system reboot quickly
    reboot_timeout = 1
    distribution = 'FEDORA'


# Generated at 2022-06-25 07:21:26.392945
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    assert action_module_0
    task_vars = dict()
    distribution = 'redhat'
    result = action_module_0.perform_reboot(task_vars, distribution)
    assert 'elapsed' in result
    assert 'start' in result
    assert 'rebooted' in result


# Generated at 2022-06-25 07:21:35.865143
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    action_module_0 = ActionModule()
    mock_self_0 = Mock()

# Generated at 2022-06-25 07:21:44.052215
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    action_module_0 = ActionModule()
    action_module_0.get_current_connection()
    action_module_0.get_current_task()
    task_vars_0 = {}
    distribution_0 = action_module_0.get_distribution(task_vars_0)
    shutdown_command_0 = action_module_0.get_shutdown_command(task_vars_0, distribution_0)
    print(shutdown_command_0)
    print('')
