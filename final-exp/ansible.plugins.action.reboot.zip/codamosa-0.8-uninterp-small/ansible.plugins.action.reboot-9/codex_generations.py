

# Generated at 2022-06-25 07:18:52.089309
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_obj = ActionModule()
    # Test using default argument
    result_obj = action_module_obj.run()
    assert True


# Generated at 2022-06-25 07:19:03.586920
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    action_module_0 = ActionModule()
    mod = sys.modules[__name__]
    dist = platform.linux_distribution()[0]
    dist = dist.replace(' ', '_')
    dist = dist.replace('/', '_')
    dist = dist.lower()
    distribution = dist
    action = mod.get_system_boot_time # type: ActionModule
    action_kwargs = {'distribution': distribution}
    action_desc = "last boot time check"
    reboot_timeout = 1000

# Generated at 2022-06-25 07:19:07.770535
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    set_module_args({
        'reboot_timeout_sec': 1,
        'shutdown_timeout_sec': 2,
        'post_reboot_delay': 3,
        'connect_timeout_sec': 4
    })
    action_module = ActionModule()
    action_module.deprecated_args()


# Generated at 2022-06-25 07:19:13.922414
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    # Declaration of test class
    class TestClass:
        def __init__(self):
            self.host = None
            self.transport = "paramiko"
            self.port = None
            self.user = "foo"
            self.password = None
            self.private_key_file = None
            self._become = None
            self.become_method = None
            self.become_user = None
            self.become_pass = None
            self.delegate_to = None
            self._sshkey_paths_found = []

        def get_option(self, option_name):
            if option_name == "connection_timeout":
                return 5

    # Declaration of test class
    class TestClass_connection:
        def __init__(self):
            self.action = None


# Generated at 2022-06-25 07:19:22.214861
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    # Instantiation of class ActionModule
    action_module_0 = ActionModule()
    # Assign parameter 'distribution' of method 'get_shutdown_command_args'
    # of class 'ActionModule' a value
    distribution_0 = 'rhel'
    # Call method 'get_shutdown_command_args' of class 'ActionModule'
    # with parameter 'distribution'
    return_value_0 = action_module_0.get_shutdown_command_args(distribution_0)
    # Check if return value of method equals expected value
    assert return_value_0 == '-r now'


# Generated at 2022-06-25 07:19:26.862610
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module_0 = ActionModule()

    # Test case for No Exception
    try:
        action_module_0.check_boot_time(distribution='distribution_0', previous_boot_time='previous_boot_time_0')
    except Exception as e:
        print('Failed: {0}'.format(e))


# Generated at 2022-06-25 07:19:32.526423
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action_module_1 = ActionModule()
    action_module_1._task = Mock()
    action_module_1._task.args = dict()
    action_module_1.DEPRECATED_ARGS = dict()
    task_args = dict()
    action_module_1._task.args = task_args
    action_module_1.DEPRECATED_ARGS = dict()
    result_expected = None
    result = action_module_1.deprecated_args()
    assert result == result_expected
    task_args = dict()
    action_module_1._task.args = task_args
    action_module_1.DEPRECATED_ARGS = dict()
    result_expected = None
    result = action_module_1.deprecated_args()
    assert result == result_expected

# Generated at 2022-06-25 07:19:33.686703
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    test_case_0()

# Generated at 2022-06-25 07:19:43.227498
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    action_module_1 = ActionModule()
    task_vars_2 = {"ansible_distribution": "Ubuntu", "ansible_distribution_release": "20.04", "ansible_distribution_major_version": "20", "ansible_distribution_version": "20.04", "ansible_distribution_file_parsed": True, "ansible_facts": {"ansible_distribution": "Ubuntu", "ansible_distribution_version": "20.04", "ansible_distribution_release": "focal", "ansible_distribution_major_version": "20", "ansible_distribution_file_path": "/etc/os-release", "ansible_distribution_file_parsed": True}}
    result_3 = {"start": "Test mock datetime"}
    assert action_module

# Generated at 2022-06-25 07:19:52.539251
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()
    tmp = None
    task_vars = dict()
    task_vars['ansible_network_os'] = 'nxos'
    task_vars['ansible_network_os'] = 'nxos'
    task_vars['ansible_network_os'] = 'nxos'
    task_vars['ansible_network_os'] = 'nxos'
    task_vars['ansible_network_os'] = 'nxos'
    task_vars['ansible_network_os'] = 'nxos'
    task_vars['ansible_network_os'] = 'nxos'
    task_vars['ansible_network_os'] = 'nxos'

# Generated at 2022-06-25 07:20:22.210859
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module = ActionModule()
    assert '-r' == action_module.get_shutdown_command_args('RedHat')
    assert '' == action_module.get_shutdown_command_args('DEFAULT')


# Generated at 2022-06-25 07:20:27.660651
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():

    print("\nTesting ActionModule of method get_distribution")
    sys.modules['ansible_collections.ansible.reboot.plugins.module_utils.facts.system.network'] = NetworkMock
    sys.modules['ansible_collections.ansible.reboot.plugins.module_utils.facts.system.distribution'] = DistributionMock
    action_module_0 = ActionModule()
    task_vars = {}
    result = action_module_0.get_distribution(task_vars)

    print("EXPECTED:\n{exp}".format(exp='debian'))
    print("OUTPUT:\n{out}".format(out=result))

# Generated at 2022-06-25 07:20:34.432768
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    global action_module_0
    action_module_0 = ActionModule()
    action_module_0.validate_reboot = MagicMock()
    action_module_0.validate_reboot()


# Generated at 2022-06-25 07:20:35.444464
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert not action_module_0.run()


# Generated at 2022-06-25 07:20:36.832096
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module_1 = ActionModule()
    pass


# Generated at 2022-06-25 07:20:43.191261
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Prepare inputs
    action_module_1 = ActionModule()
    task_vars = {'ansible_distribution': 'Darwin'}
    distribution = 'Darwin'

    # Execute function
    reboot_result = action_module_1.perform_reboot(task_vars, distribution)

    # Verify results
    assert reboot_result.get('error') is None, reboot_result.get('error')
    assert reboot_result['rebooted'] is False, reboot_result['rebooted']
    assert reboot_result['rc'] == 0, reboot_result['rc']


# Generated at 2022-06-25 07:20:46.092737
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module = ActionModule()
    action_module.check_boot_time("redhat", datetime.utcnow())



# Generated at 2022-06-25 07:20:50.408155
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    action_module = ActionModule()
    result = action_module.validate_reboot('CentOS-Dev')
    if not result['failed']:
        raise AssertionError("Test case failed: 'validate_reboot' must return ['failed'] key with a True value")


# Generated at 2022-06-25 07:20:53.704063
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    action_module_0 = ActionModule()
    # Perform reboot
    result = action_module_0.perform_reboot(task_vars=None, distribution=None)

    # Verify that the results from the method are correct
    assert result['failed'] == False
    assert result['start'] is not None



# Generated at 2022-06-25 07:20:57.174045
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module_0 = ActionModule()
    distribution = 'DEBIAN'
    previous_boot_time = '2018-03-14T10:17:18.593445'
    action_module_0.check_boot_time(distribution, previous_boot_time)


# Generated at 2022-06-25 07:21:54.466598
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    action_module_0 = ActionModule()


# Generated at 2022-06-25 07:22:05.190240
# Unit test for method perform_reboot of class ActionModule

# Generated at 2022-06-25 07:22:07.945630
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module_0 = ActionModule()
    distribution = mock.MagicMock()
    previous_boot_time = mock.MagicMock()
    action_module_0.check_boot_time(distribution, previous_boot_time)


# Generated at 2022-06-25 07:22:10.042853
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module_0 = ActionModule()



# Generated at 2022-06-25 07:22:13.460250
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action_module_0 = ActionModule()
    action_module_0.deprecated_args()



# Generated at 2022-06-25 07:22:23.224111
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module = ActionModule()

    try:
        check_type_dict(action_module._task.vars)
    except TypeError as e:
        print("TypeError: Invalid type for 'action_module._task.vars' argument. Expected: <class 'dict'>, Actual: {0}".format(type(action_module._task.vars)))
        raise e


# Generated at 2022-06-25 07:22:27.120789
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    action_module_0 = ActionModule()
    # Original return value from perform_reboot
    reboot_result = {'start': datetime.utcnow(), 'failed': False}
    result = action_module_0.validate_reboot(distribution='default', original_connection_timeout=None, action_kwargs={'previous_boot_time': 'not_empty'})

    assert result['rebooted'] == True
    assert result['changed'] == True


# Generated at 2022-06-25 07:22:35.411697
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Initialize a task object with required parameters
    task = Task()
    task.action = 'reboot'
    task.args = {
        'reboot_timeout': 56,
        'reboot_retries': 8
    }

    # Initialize a system distribution object with required parameters
    sys_dist = SystemDistribution()
    sys_dist.distribution = 'FreeBSD'
    sys_dist.distribution_release = '10.3-RELEASE'
    sys_dist.distribution_version = '10.3-RELEASE'

    # Initialize an os_family object with required parameters
    os_family = OSFamily()
    os_family.os_family = 'FreeBSD'

    # Initialize a connection object with required parameters
    connection = Connection()
    connection.transport = 'ssh'

    # Initialize a connection

# Generated at 2022-06-25 07:22:43.627609
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    ####################
    # Set up parameters
    ####################
    task_vars = dict()
    task_vars["ansible_distribution"] = "Darwin"
    distro = "Darwin"

    ####################
    # Set up mocks
    ####################
    _module_patcher = patch.multiple(ActionModule,
                                     _execute_module=DEFAULT,
                                     _low_level_execute_command=DEFAULT,
                                     get_distribution=DEFAULT,
                                     get_shutdown_command=DEFAULT,
                                     get_shutdown_command_args=DEFAULT
                                    )

    _module_patcher['_low_level_execute_command'].return_value = dict(rc=0, stdout='', stderr='')


# Generated at 2022-06-25 07:22:48.373305
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    action_module = ActionModule()
    action_module._task = fake_ansible_task()
    action_module.DEFAULT_SUDOABLE = False
    action_module._task.action = 'dummy_action_name'
    action_module._task.args = {'test_param': 'test_value'}
    action_module._connection = fake_connection()
    action_module_result = action_module.perform_reboot(task_vars={}, distribution='Fake_distribution')
    assert action_module_result['start']
    assert action_module_result['failed'] == False


# Generated at 2022-06-25 07:24:50.815978
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module_0 = ActionModule()
    distribution = 'string'
    assert action_module_0.get_shutdown_command_args(distribution) == str()


# Generated at 2022-06-25 07:24:57.865785
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():

    action_module_1 = ActionModule()
    action_module_2 = ActionModule()
    action_module_3 = ActionModule()

    # Test 1
    print("\nTest 1: Get distribution from facts")
    inventory_vectors_1 = dict(
        ansible_facts = dict(
            DISTRIBUTION = "myOS"
        )
    )
    task_vars_1 = inventory_vectors_1
    expected_1 = "myOS"
    result_1 = action_module_1.get_distribution(task_vars_1)
    print("Expected:", expected_1)
    print("Result:", result_1)
    assert result_1 == expected_1

    # Test 2
    print("\nTest 2: Get distribution from system")

# Generated at 2022-06-25 07:25:00.943609
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    action_module_0 = ActionModule()
    distribution_arg_1 = None
    action_module_0.run_test_command(distribution=distribution_arg_1)


# Generated at 2022-06-25 07:25:09.643378
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    target_results = {'elapsed': 0, 'reboot': True, 'failed': True, 'msg': "Running Reboot with local connection would reboot the control node."}

    exec_module_0 = Executor()
    action_module_0 = ActionModule(exec_module=exec_module_0)
    action_module_0.set_task('Reboot')
    display.verbosity = 3
    action_module_0.set_play_context('check_mode', True)
    test_result_0 = action_module_0.run()
    assert test_result_0 == target_results

# test data

# Generated at 2022-06-25 07:25:10.859263
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    result = action_module.run()


# Generated at 2022-06-25 07:25:17.329124
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    action_module_0 = ActionModule()
    # Test with distribution = None
    result_0 = action_module_0.validate_reboot(distribution = None)
    assert result_0['rebooted'] == True, 'Result was not equal to True'
    assert result_0['failed'] == True, 'Result was not equal to True'
    # Test with distribution = 'Undisclosed'
    result_1 = action_module_0.validate_reboot(distribution = 'Undisclosed')
    assert result_1['rebooted'] == True, 'Result was not equal to True'
    assert result_1['failed'] == True, 'Result was not equal to True'


# Generated at 2022-06-25 07:25:22.462373
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    actionModule_0 = ActionModule()
    mock_distribution_0 = Mock(name='distribution_0')
    actionModule_0.get_shutdown_command_args(mock_distribution_0)
    mock_distribution_0 = Mock(name='distribution_0')
    actionModule_0.get_shutdown_command_args(mock_distribution_0)


# Generated at 2022-06-25 07:25:27.100417
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    action_module_1 = ActionModule()
    hostvars = {
        'ansible_distribution': 'Linux',
        'ansible_distribution_release': 'Debian',
        'ansible_distribution_version': '10.1',
        'ansible_shutdown_command': None,
        'ansible_shutdown_command_args': None
    }
    result = action_module_1.get_shutdown_command(hostvars)
    assert result == '/sbin/shutdown', "Test result must be '{}'".format('/sbin/shutdown')


# Generated at 2022-06-25 07:25:29.807063
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action_module_0 = ActionModule()

    action_module_0.deprecated_args()


# Generated at 2022-06-25 07:25:31.880133
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    action_module_0 = ActionModule()
    action_module_0.run_test_command("")
