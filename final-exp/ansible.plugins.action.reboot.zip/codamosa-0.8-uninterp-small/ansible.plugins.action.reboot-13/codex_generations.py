

# Generated at 2022-06-25 07:18:52.865839
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    action_module_0 = ActionModule()
    distribution_0 = 'ansible'
    original_connection_timeout_0 = None
    action_kwargs_0 = 'overwrite'
    result = action_module_0.validate_reboot(distribution_0, original_connection_timeout_0, action_kwargs_0)


# Generated at 2022-06-25 07:18:56.091971
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    action_module_1 = ActionModule()
    var_1 = None
    # TODO: Change test environment to something that can make a connection

# Generated at 2022-06-25 07:18:58.377740
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module_0 = ActionModule()
    var_0 = action_get_shutdown_command_args()


# Generated at 2022-06-25 07:19:09.381820
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module_0 = ActionModule()
    var_boot_time_command = 'uptime'
    # bool check_boot_time(self,distribution,previous_boot_time)
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #
    #

# Generated at 2022-06-25 07:19:15.622637
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action_module_0 = ActionModule()
    var_0 = action_deprecated_args()
    var_0.run(self=var_0)



# Generated at 2022-06-25 07:19:21.443471
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    # initialize action module
    action_module_0 = ActionModule()
    # setup args
    var_0 = {'reboot_timeout_sec': 50, 'reboot_timeout': 50, 'post_reboot_delay': 5, 'msg': 'System will reboot in {time} seconds'}

    action_module_0.deprecated_args(task=var_0, arg_name='reboot_timeout', var_name='reboot_timeout', version='2.0')



# Generated at 2022-06-25 07:19:31.428770
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    action_module_0 = ActionModule()
    var_1 = TODO
    var_2 = TODO
    # Setup and configure the test_module environment
    if (test_module_dir is None):
        test_module_dir = mkdtemp()
        if (test_module_dir is None):
            pass

    # Setup and configure the test_module environment
    if (test_module_dir is None):
        test_module_dir = mkdtemp()
        if (test_module_dir is None):
            pass

    # Setup and configure the test_module environment
    if (test_module_dir is None):
        test_module_dir = mkdtemp()
        if (test_module_dir is None):
            pass

    # Setup and configure the test_module environment

# Generated at 2022-06-25 07:19:42.155483
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    action_module_0 = ActionModule()
    action_module_1 = ActionModule()
    action_module_2 = ActionModule()
    action_module_3 = ActionModule()
    action_module_4 = ActionModule()
    action_module_5 = ActionModule()
    action_module_6 = ActionModule()
    action_module_7 = ActionModule()
    action_module_8 = ActionModule()
    action_module_9 = ActionModule()

    action_module_10 = ActionModule()
    action_module_11 = ActionModule()
    action_module_12 = ActionModule()
    action_module_13 = ActionModule()
    action_module_14 = ActionModule()
    action_module_15 = ActionModule()
    action_module_16 = ActionModule()
    action_module_17 = ActionModule()
   

# Generated at 2022-06-25 07:19:47.243894
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    action_module_0 = ActionModule()
    arg_0 = None
    arg_2 = 3.082791958136417
    arg_1 = 'action_desc'
    try:
        ret_obj = action_module_0.do_until_success_or_timeout(arg_0, arg_1, arg_2)
    except Exception as err:
        print("Caught exception when calling do_until_success_or_timeout:", err)


# Generated at 2022-06-25 07:19:51.966552
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    action_module_0 = ActionModule()
    var_0 = True if not action_module_0 else False
    try:
        action_module_0.do_until_success_or_timeout(action_type=None, reboot_timeout=None, action_desc=None, distribution=None, action_kwargs=None)
    except Exception as e:
        var_0 = None
    assert var_0


# Generated at 2022-06-25 07:21:10.007214
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():

    # this test case will throw exception because action_module_0 is not a valid object.
    # Mock it
    action_module_0 = mock()
    action_module_0.DEPRECATED_ARGS = {}
    action_module_0._task = mock()
    action_module_0._task.action = "reboot"
    action_module_0._task.args = {}
    action_module_0.display = mock()
    action_module_0.display.warning = mock()
    action_module_0.display.warning.side_effect = Exception()

    assertRaises(Exception, action_module_0.deprecated_args)


# Generated at 2022-06-25 07:21:13.873249
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():

    init_list_0 = []
    action_module_0 = ActionModule()
    distribution_0 = str()
    action_module_0.check_boot_time(distribution_0)


# Generated at 2022-06-25 07:21:21.527074
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # Define test variables and constants
    action_module_1 = ActionModule()
    action_module_1.DEFAULT_REBOOT_TIMEOUT = 10

    # Fail on 'argument' error?
    try:
        action_module_1.do_until_success_or_timeout()
        return False
    except TypeError:
        pass

    # Fail on 'action' error?
    try:
        action_module_1.do_until_success_or_timeout(action=None)
        return False
    except AttributeError:
        pass

    # Fail on 'action_desc' error?
    try:
        action_module_1.do_until_success_or_timeout(action=test_case_0, action_desc=None)
        return False
    except AttributeError:
        pass

    # Fail

# Generated at 2022-06-25 07:21:27.724275
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():

    action_module_0 = ActionModule()

    assert action_module_0.check_boot_time() == "test"

# # Unit test for method get_system_boot_time of class ActionModule
# def test_ActionModule_get_system_boot_time():
#
#     action_module_0 = ActionModule()
#
#     assert action_module_0.get_system_boot_time() == "test"
#
# # Unit test for method init_system of class ActionModule
# def test_ActionModule_init_system():
#
#     action_module_0 = ActionModule()
#
#     assert action_module_0.init_system() == "test"
#
# # Unit test for method reboot of class ActionModule
# def test_ActionModule_reboot():
#
#     action_module_0

# Generated at 2022-06-25 07:21:32.613450
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module_0 = ActionModule()
    distribution = 'Debian'
    previous_boot_time = 'Thu Nov  2 09:27:54 UTC 2017'
    action_module_0.check_boot_time(distribution, previous_boot_time)


# Generated at 2022-06-25 07:21:36.389141
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    action_module = ActionModule()
    try:
        action_module.do_until_success_or_timeout(action_module.check_boot_time, 30, None, None)
    except TimedOutException as e:
        print("Expected Exception: {0}".format(e))

if __name__ == '__main__':
    # test_ActionModule_do_until_success_or_timeout()
    test_case_0()

# Generated at 2022-06-25 07:21:42.335658
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    action_module_0 = ActionModule()
    # FIXME: operation is not supported on this platform
    #assert_equal(action_module_0.validate_reboot(), {'failed': False, 'msg': '', 'rebooted': True, 'changed': True})


# Generated at 2022-06-25 07:21:47.009475
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    action_module_0 = ActionModule()
    # define input values used in 'run_test_command' method
    distribution = 2
    action_kwargs = dict()
    # expected output value
    expected_test_command = 'uptime || true'
    # actual output value
    actual_test_command = action_module_0.run_test_command(distribution, **action_kwargs)
    print(actual_test_command)
    assert(expected_test_command is actual_test_command)


# Generated at 2022-06-25 07:21:56.876592
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    action_module_0 = ActionModule()
    method_name_0 = 'validate_reboot'
    method_name_1 = 'check_boot_time'
    method_name_2 = 'run_test_command'
    class_name_0 = 'ActionModule'
    class_name_1 = 'RebootModule'
    int_0 = random.randint(1, 99)

# Generated at 2022-06-25 07:22:01.306211
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module_0 = ActionModule()
    action_module_0.check_boot_time()


# Generated at 2022-06-25 07:23:03.336553
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():

    action_module = ActionModule()
    action_module.test_command = "echo 'Hello World'"
    action_module.run_test_command()

# Generated at 2022-06-25 07:23:04.466220
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()


# Generated at 2022-06-25 07:23:05.847324
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module_obj = ActionModule()
    action_module_obj.check_boot_time()


# Generated at 2022-06-25 07:23:10.125973
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    action_module_0 = ActionModule()
    action_kwargs = {}
    assert True == action_module_0.validate_reboot(distribution = "", action_kwargs = action_kwargs)


# Generated at 2022-06-25 07:23:14.277826
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    action_module_0 = ActionModule()

    distribution = 'linux'
    action_kwargs = None
    action_module_0.run_test_command(distribution, **action_kwargs)


# Generated at 2022-06-25 07:23:22.040474
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module_0 = ActionModule()
    assert action_module_0.get_shutdown_command_args('debian') == '-r now'
    assert action_module_0.get_shutdown_command_args('rhel') == '-r now'
    assert action_module_0.get_shutdown_command_args('suse') == '-r now'
    assert action_module_0.get_shutdown_command_args('ubuntu') == '-r now'
    assert action_module_0.get_shutdown_command_args('centos') == '-r now'
    assert action_module_0.get_shutdown_command_args('fedora') == '-r now'
    assert action_module_0.get_shutdown_command_args('redhat') == '-r now'
   

# Generated at 2022-06-25 07:23:24.523371
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module_1 = ActionModule()
    try:
        action_module_1.check_boot_time('distribution', 'foo')
    except ValueError as e:
        display.debug(e)
    else:
        assert(False)


# Generated at 2022-06-25 07:23:27.761229
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    action_module = ActionModule()
    # unit test not implemented
    action_module.get_system_boot_time(distribution=None)


# Generated at 2022-06-25 07:23:30.485557
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    print("\nTest run_test_command()")
    action_module_0 = ActionModule()
    distribution = "Ubuntu"
    action_module_0.run_test_command(distribution)


# Generated at 2022-06-25 07:23:36.669163
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module_0 = ActionModule()
    distribution = None
    distribution = "linux"
    assert action_module_0.get_shutdown_command_args(distribution) == "-r now"
    distribution = "freebsd"
    assert action_module_0.get_shutdown_command_args(distribution) == "-r now"
    distribution = "osx"
    assert action_module_0.get_shutdown_command_args(distribution) == "-r now"
    distribution = "solaris"
    assert action_module_0.get_shutdown_command_args(distribution) == "-y -i 5"
    distribution = "aix"
    assert action_module_0.get_shutdown_command_args(distribution) == "-F -r"
    distribution = "hpux"
   

# Generated at 2022-06-25 07:24:39.909013
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():

    action_module_0 = ActionModule()
    task_vars_0 = {}
    distribution_0 = "redhat"

    try:
        assert action_module_0.get_shutdown_command(task_vars_0, distribution_0) == '/sbin/shutdown'
    except Exception as e:
        print(e)


# Generated at 2022-06-25 07:24:40.841253
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action_module_0 = ActionModule()
    action_module_0.deprecated_args()


# Generated at 2022-06-25 07:24:42.208999
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action_module_0 = ActionModule()
    action_module_0.deprecated_args()


# Generated at 2022-06-25 07:24:43.628780
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    action_module_object = ActionModule()
    action_module_object.run_test_command("Linux")


# Generated at 2022-06-25 07:24:47.736525
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    def test_action_func(distribution, **kwargs):
        if kwargs['test_var'] == 0 or kwargs['test_var'] == 5:
            raise Exception(kwargs['test_var'])

    action_module = ActionModule()

    action_module.do_until_success_or_timeout(action=test_action_func,
                                              reboot_timeout=10,
                                              action_desc="do_until_success_or_timeout test case",
                                              distribution='Darwin',
                                              action_kwargs={'test_var': 0})


# Generated at 2022-06-25 07:24:57.715980
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    print("==== test_ActionModule_validate_reboot")

    action_module = ActionModule()
    action_module.check_boot_time = mock.Mock()
    action_module.run_test_command = mock.Mock()

    action_module.validate_reboot(distribution='dummy_distribution',
                                  original_connection_timeout='dummy_original_connection_timeout',
                                  action_kwargs={'previous_boot_time': 'dummy_previous_boot_time'})

    action_module.check_boot_time.assert_called_once_with(distribution='dummy_distribution',
                                                          previous_boot_time='dummy_previous_boot_time')

# Generated at 2022-06-25 07:25:00.574114
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    action_module_instance = ActionModule()
    distribution = 1
    action_module_instance.get_system_boot_time(distribution)


# Generated at 2022-06-25 07:25:02.168413
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module_0 = ActionModule()
    result = action_module_0.get_distribution()


# Generated at 2022-06-25 07:25:03.849753
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action_module_0 = ActionModule()
    action_module_0.deprecated_args()


# Generated at 2022-06-25 07:25:05.809809
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    called_function = ActionModule()
    assert called_function.perform_reboot() == None
