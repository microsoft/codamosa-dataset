

# Generated at 2022-06-25 07:19:00.442182
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    action_module = ActionModule()

    # Test 1: pass
    test_result = action_module.get_system_boot_time(distribution='RedHat')
    expected_result = None
    assert expected_result is None

    # Test 2: pass
    test_result = action_module.get_system_boot_time(distribution='Debian')
    expected_result = None
    assert expected_result is None

    # Test 3: pass
    test_result = action_module.get_system_boot_time(distribution='SuSE')
    expected_result = None
    assert expected_result is None

    # Test 4: pass
    test_result = action_module.get_system_boot_time(distribution='FreeBSD')
    expected_result = None
    assert expected_result is None

    # Test 5: pass

# Generated at 2022-06-25 07:19:04.355267
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Setup the task args
    args = dict()

    # Create the action module object
    action_module_0 = ActionModule()

    # Calling the method get_shutdown_command to test it
    result = action_module_0.get_shutdown_command(args)


# Generated at 2022-06-25 07:19:08.505073
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module_0 = ActionModule()
    task_vars_0 = {"system_distribution": "macOS High Sierra"}
    test_var_0 = action_module_0.get_distribution(task_vars_0)
    print(test_var_0)
    assert test_var_0 == 'MacOS'


# Generated at 2022-06-25 07:19:19.650570
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    action_module = ActionModule()

    # Test with valid arguments
    test_result = action_module.get_shutdown_command({'ansible_os_family': 'RedHat'})
    assert(test_result == '/sbin/shutdown')

    # Test with valid arguments
    test_result = action_module.get_shutdown_command({'ansible_os_family': 'RedHat', 'ansible_distribution': 'Debian'})
    assert(test_result == '/sbin/shutdown')

    # Test with valid arguments
    test_result = action_module.get_shutdown_command({'ansible_os_family': 'RedHat', 'ansible_distribution': 'Ubuntu'})
    assert(test_result == '/sbin/shutdown')

    # Test with valid arguments

# Generated at 2022-06-25 07:19:22.470994
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module = ActionModule()
    action_module.check_boot_time(distribution='RedHat')
    action_module.check_boot_time(distribution='FreeBSD')


# Generated at 2022-06-25 07:19:33.097528
# Unit test for method get_shutdown_command of class ActionModule

# Generated at 2022-06-25 07:19:36.026505
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    action_module_0 = ActionModule()
    distribution = '''test_distribution'''
    action_module_0.run_test_command(distribution)


# Generated at 2022-06-25 07:19:44.250230
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    action_module_obj = ActionModule()

    # Test with default value of boot_time_command
    # Test with valid value
    # Test with invalid value
    # Test with empty path
    # Test with invalid path
    # Test with valid path and invalid pattern
    # Test with valid path and pattern
    # Test with multiple valid paths and pattern
    # Test with default value of boot_time_command and valid value of TEST_COMMANDS
    # Test with default value of boot_time_command and invalid value of TEST_COMMANDS
    # Test with default value of boot_time_command and valid value of TEST_COMMANDS and valid value of boot_time_command
    # Test with default value of boot_time_command and valid value of BOOT_TIME_COMMANDS
    # Test with default value of boot_time_command and invalid value of BOOT

# Generated at 2022-06-25 07:19:51.006689
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module_0 = ActionModule()
    distribution_0 = 'test'
    previous_boot_time_0 = 'test'
    try:
        action_module_0.check_boot_time(distribution_0, previous_boot_time_0)
    except TypeError as err:
        assert(err.args[0] == "check_boot_time() missing 1 required positional argument: 'self'")
    except Exception as err:
        print(err.args)
        print("Unexpected error:", sys.exc_info()[0])
        raise


# Generated at 2022-06-25 07:19:53.286414
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module_0 = ActionModule()
    distribution_0 = None
    assert action_module_0.get_shutdown_command_args(distribution_0) is None
