

# Generated at 2022-06-11 12:14:27.706321
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import mock
    import types

    # Mock for __init__
    class mock_init(object):
        """
        Mock for __init__
        """
        def __init__(self):
            self._supports_check_mode = None
            self._supports_async = None
            self.post_reboot_delay = 0
            self._play_context = None
            self._task = None
            self._low_level_execute_command = None
            self._connection = None
            self.DEFAULT_TEST_COMMAND = None
            self.DEFAULT_REBOOT_TIMEOUT = None
            self.DEFAULT_CONNECT_TIMEOUT = None
            self.BOOT_TIME_COMMANDS = None
            self.REBOOT_COMMANDS = None

# Generated at 2022-06-11 12:14:32.053326
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    action_module = ActionModule()
    distribution = 'Ubuntu'
    task_vars = {}
    # Test
    shutdown_command = action_module.get_shutdown_command(task_vars, distribution)
    assert_equal(shutdown_command, '/sbin/shutdown')


# Generated at 2022-06-11 12:14:42.834548
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    host_vars = {'ansible_connection': 'local'}
    task = Task(action=dict(reboot_timeout=10))
    module = ActionModule(host=MagicMock(ansible_host='host', variables=host_vars),
                          connection=MagicMock(transport='local'), task=task,
                          loader=MagicMock(), play_context=MagicMock(),
                          shared_loader_obj=MagicMock())
    with patch.object(display, 'warning') as mock_display_warning:
        module.deprecated_args()
        mock_display_warning.assert_any_call("Since Ansible 2.6, reboot_timeout is no longer a valid option for reboot")


# Generated at 2022-06-11 12:14:47.874544
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    # create an instance of the class
    am = ActionModule()
    # define args
    args = {'test': 'test'}
    dep_args = {'test': '2.4.0'}
    # setup the task
    task = {'action': 'test', 'args': args}
    am._task = task
    am.DEPRECATED_ARGS = dep_args
    # call the method
    am.deprecated_args()
    # assert nothing happens


# Generated at 2022-06-11 12:14:55.669729
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    actionmodule = ActionModule()
    actionmodule.get_system_boot_time = MagicMock(return_value="timestamp")

    actionmodule.check_boot_time(distribution="", previous_boot_time="timestamp")

    actionmodule.get_system_boot_time.assert_called_once_with(distribution="")
    actionmodule.get_system_boot_time = MagicMock(return_value="timestamp_new")
    with pytest.raises(ValueError):
        actionmodule.check_boot_time(distribution="", previous_boot_time="timestamp")



# Generated at 2022-06-11 12:15:04.790134
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    display = Display()
    display.vvv = MagicMock(return_value=None)
    display.debug = MagicMock(return_value=None)
    module_loader = None
    task = Task()
    connection = None
    tmp = None
    play_context = PlayContext()
    play_context.check_mode = None
    action_module = ActionModule(None, display, module_loader, None, task, connection, play_context, None, tmp)
    task_vars = {}
    result = action_module.get_distribution(task_vars)
    assert isinstance(result, type(None))


# Generated at 2022-06-11 12:15:10.319775
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action_module = ActionModule(task=dict(), connection=None,
                                 play_context=PlayContext(remote_user='root', remote_addr='localhost',
                                                          password=None, become_method='sudo', become_user='become_user'))

    # Tests if the deprecated_args method runs without error
    action_module.deprecated_args()



# Generated at 2022-06-11 12:15:20.253357
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    display = Display()

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )

    # initialize
    action_module = ActionModule(
        module=module,
        task=Task(),
        connection=Connection(),
        play_context=PlayContext(),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    # setup test values
    distribution = 'any_thing'
    previous_boot_time = 'any_thing'

    # run test
    try:
        action_module.check_boot_time(distribution, previous_boot_time)
    except:
        pytest.fail('ActionModule.check_boot_time threw an unexpected exception')

    # report test results
    assert True

# Generated at 2022-06-11 12:15:29.547308
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    # The following lines are used to test before_reboot_delay, after_reboot_delay
    # and reboot_timeout as these arguments were removed from the main module
    # and moved to the action plugin
    task = Mock()
    task.action = 'reboot'
    task.args = dict(before_reboot_delay=1, after_reboot_delay=0, reboot_timeout=600)
    task_vars = dict()
    am = ActionModule(task, task_vars)
    am.deprecated_args()
    assert task.args['before_reboot_delay'] == 1
    assert task.args['after_reboot_delay'] == 0
    assert task.args['reboot_timeout'] == 600



# Generated at 2022-06-11 12:15:39.324003
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # Test simple case
    # 'task_vars' is a dictionary with variables from playbook
    # 'tmp' is a temporary directory
    # 'connection' is an ansible connection
    # 'play_context' is a playbook context
    # 'loader' is an ansible loader
    task_vars = {
         'ansible_facts': {
             'distribution_version': '16.04',
             'distribution': 'Ubuntu',
         }
    }
    tmp = '/tmp'
    connection = 'connection'
    play_context = 'play_context'
    loader = 'loader'
    task = {
        'action': 'reboot',
    }
    ansible_module = ActionModule(task, connection, play_context, loader, tmp)
    ansible_module.DEFAULT_BOOT_TIME_COMM

# Generated at 2022-06-11 12:16:55.368940
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    agent = AnsibleAgent(host='127.0.0.1')
    data = agent.generate_action_data('reboot', 'reboot', action_args=dict(msg='le message'))
    del data['task']['args']['msg']  # this parameter is not used in this method
    del data['task']['args']['test_command']  # this parameter is not used in this method
    del data['task']['args']['connect_timeout']  # this parameter is not used in this method
    del data['task']['args']['reboot_timeout']  # this parameter is not used in this method
    del data['task']['args']['delay']  # this parameter is not used in this method

# Generated at 2022-06-11 12:17:05.647297
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    import sys

    stdout = sys.stdout
    stdout_text_io = StringIO()
    sys.stdout = stdout_text_io

    ##################################################
    # deprecated_args: no input
    ##################################################

    module = ActionModule()
    module._task = {
        'action': 'reboot',
    }

    module.deprecated_args()


# Generated at 2022-06-11 12:17:09.623023
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # Tests that do_until_success_or_timeout method of ActionModule(see unit test.)
    try:
        am = ActionModule()
        with pytest.raises(NotImplementedError):
            am.do_until_success_or_timeout()
    except:
        assert False



# Generated at 2022-06-11 12:17:16.641478
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    action_module = ActionModule({'path': '/etc'}, {'connection': 'smart', 'forks': 10}, {'become': False, 'become_method': 'sudo', 'become_user': None, 'check_mode': False, 'connect_timeout': 10}, '/home/centos/ansible/test')

    assert action_module.get_system_boot_time() == '/var/log/boot.log'

    return



# Generated at 2022-06-11 12:17:26.062553
# Unit test for method get_shutdown_command_args of class ActionModule

# Generated at 2022-06-11 12:17:35.454705
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    from ansible.plugins.action import ActionBase

    connection = MagicMock()
    connection.run.return_value = {'rc': 0, 'stdout': '', 'stderr': ''}
    connection.transport = 'ssh'

    action_base = ActionBase(connection, '', '', {}, None, '/tmp/ansible-tmp')
    action_base.connection._shell.which.return_value = 'testing_path'

    device_under_test = ActionModule(action_base.connection, {}, action_base._templar, action_base._loader)

    distribution = 'Linux'
    task_vars = {
        'ansible_facts': {
            'reboot_distribution': distribution
        }
    }


# Generated at 2022-06-11 12:17:40.135593
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    action = ActionModule()
    # Test with action = check_boot_time and no args
    action_1 = ActionModule.do_until_success_or_timeout(action, action.check_boot_time , reboot_timeout=60, distribution=None, action_kwargs=None, action_desc='')
    assert action_1 == None # not yet implemented


# Generated at 2022-06-11 12:17:41.929804
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action = AnsibleAction()
    assert type(action).__name__ == 'AnsibleAction'


# Generated at 2022-06-11 12:17:52.268317
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Creating an instance of class ActionModule which inherits object
    # and set the connection to local and the action to module_reboot
    module_instance = ActionModule('local','module_reboot')

    #Setting the test variables in a dictionary
    task_vars = {'ansible_distribution': 'ubuntu'}
    module_instance.get_system_boot_time = lambda distribution: '1'
    module_instance.get_shutdown_command = lambda task_vars , distribution : 'shutdown'
    module_instance.get_shutdown_command_args = lambda distribution: '-r'
    module_instance.run_test_command = lambda distribution, **kwargs: '1'
    module_instance.check_boot_time = lambda distribution, previous_boot_time: True

    # Result should be False as the check_mode is

# Generated at 2022-06-11 12:18:02.338990
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # should set distribution to default value if cannot find distribution fact
    class FakeTask(object):
        def __init__(self, action, args, connection):
            self.action = action
            self.args = args
            self.connection = connection

    fake_module_args = dict(
        test_command='echo hello',
        reboot_timeout=60,
        pre_reboot_delay=0,
        post_reboot_delay=0
    )

    fake_task = FakeTask(action='fake_action', args=fake_module_args, connection='fake_connection')

    # should raise AnsibleError with the proper message if no distribution fact
    fake_task_vars = dict(
        ansible_facts=dict()
    )
    class FakeConnection(object):
        def __init__(self, transport):
            self._

# Generated at 2022-06-11 12:18:44.485993
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    """Test method check_boot_time.

    Note:
        This unit test currently fails, as it performs a check on the returned value,
        which is not suppoorted by the python-mock library.

    """
    module = ActionModule()
    module.run = magicmock.MagicMock()
    module.run.return_value = {}

    module._task = magicmock.MagicMock()
    module._task.action = 'test'

    distribution = 'test'
    previous_boot_time = 'test'
    module.check_boot_time(distribution, previous_boot_time)


# Generated at 2022-06-11 12:18:47.368382
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module = ActionModule(None, None)
    # Call method
    result = action_module.check_boot_time(None, None)
    # Validate results
    print(result)


# Generated at 2022-06-11 12:18:56.786101
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    controller = AnsibleController(connection=MockConnection(host='testhost'))
    action_module = ActionModule(task=MockTask(ActionModule.REBOOT_COMMAND), connection=controller._connection,
                                 play_context=MockPlayContext(), loader=MockLoader(), templar=MockTemplar(), shared_loader_obj=None)

    # test default path '/sbin:/bin:/usr/sbin:/usr/bin' with
    # shutdown binary 'shutdown'
    assert action_module.get_shutdown_command(distribution=None) == '/sbin/shutdown'

    # test default path '/sbin:/bin:/usr/sbin:/usr/bin' with
    # shutdown binary 'poweroff'

# Generated at 2022-06-11 12:19:07.300628
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    """
    Unit test for do_until_success_or_timeout method of class ActionModule
    """
    hdlr = logging.FileHandler('/tmp/ansible_test.log')
    #hdlr.setFormatter(formatter)
    for loggerName in [
                                                      #"ansible",
                                                      #"ansible.module_utils.network.common.lists",
                                                      #"ansible.module_utils.network.common.utils",
                                                      "ansible.module_utils.network.common.cfg",
                                                      #"ansible.module_utils.six"
                                                      "test"
                        ]:
        temp = logging.getLogger(loggerName)
        temp.setLevel(logging.DEBUG)
        temp.addHandler(hdlr)


# Generated at 2022-06-11 12:19:08.062385
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:19:08.722564
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    assert True

# Generated at 2022-06-11 12:19:11.063130
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    module = ActionModule(dict())
    result = module.get_system_boot_time('test')
    assert result == 'test'


# Generated at 2022-06-11 12:19:18.042987
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    module = AnsibleModule(
        argument_spec={
            'reboot_timeout_sec': {'type': 'int'},
            'connect_timeout_sec': {'type': 'int'},
            'reboot_timeout': {'type': 'int'},
            'connect_timeout': {'type': 'int'},
        },
        supports_check_mode=True
    )

    m = ActionModule(module, 'reboot')

    with pytest.raises(AnsibleError):
        m.deprecated_args()


# Generated at 2022-06-11 12:19:19.597976
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    ActionModule.run_test_command(self, distribution)

# Generated at 2022-06-11 12:19:25.846688
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None

    # Set up
    task_vars = { 'ansible_facts': {'distribution': "RedHat", 'distribution_release': "7.6", 'distribution_version': '', 'os_family': "RedHat"}}

    # Execute
    result = ActionModule.run(ActionModule, tmp, task_vars)

    # Verify
    assert result == {'changed': True, 'elapsed': 0, 'rebooted': True}


# Generated at 2022-06-11 12:22:55.063407
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Given a class ActionModule
    action_module = ActionModule('reboot', task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # And a class task
    task = Task()
    # And a string distribution
    distribution = "Linux"
    # And a class task_vars
    task_vars = None

    response = action_module.perform_reboot(task_vars, distribution)

    assert response['start'] != None
    assert response['failed'] == False


# Generated at 2022-06-11 12:22:58.405157
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    distribution = 'DEFAULT_DISTRIBUTION'
    action_module = ActionModule()
    previous_boot_time = 'previous_boot_time'
    action_module.check_boot_time(distribution, previous_boot_time)


# Generated at 2022-06-11 12:22:59.362476
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-11 12:23:07.511555
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Create an instance of ActionModule class, to run the unit test on
    action = ActionModule(task=MagicMock(), connection=MagicMock(), play_context=MagicMock())
    
    # Create a dictionary of task_vars
    task_vars = dict()
    task_vars['ansible_os_family'] = 'RedHat'
    task_vars['ansible_distribution'] = 'RedHat'
    
    # Create a dictionary of ansible_facts
    ansible_facts = dict()
    ansible_facts['DISTRIBUTION_OVERRIDES'] = dict()
    ansible_facts['DISTRIBUTION_OVERRIDES']['RedHat'] = dict()

# Generated at 2022-06-11 12:23:11.657957
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    a = action.ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert a.get_shutdown_command(None, None) == 'shutdown'


# Generated at 2022-06-11 12:23:17.778208
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    # Test with shutdown_timeout argument specified and a value of 0.
    host_vars = {'ansible_distribution': 'centos'}

    args = {'shutdown_timeout': 0}

    action = ActionModule(args, host_vars)
    distribution = action.get_distribution(host_vars)

    shutdown_command_args = action.get_shutdown_command_args(distribution)

    assert shutdown_command_args == ''


# Generated at 2022-06-11 12:23:25.556321
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    module = AnsibleModule(
        argument_spec = dict(
            msg = dict(default='', type='str'),
            _ansible_check_mode = dict(default=False, type='bool'),
        )
    )
    args = {
        u'msg': u'',
        u'_ansible_check_mode': False,
        '__ansible_module__': u'fake_module'
    }
    fake_unit_test = ActionModule('fake_action', module, args)
    assert fake_unit_test.deprecated_args() == None


# Generated at 2022-06-11 12:23:32.907801
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module = ActionModule()
    result = action_module.check_boot_time("distribution")
    assert result == ["path"]
    # No further assertions possible, since we are not providing 
    # a real implementation of the method `get_system_boot_time(...)`.
    # The method `get_system_boot_time(...)` is mocked in the implementation file.
    # For example, if we wanted to mock it to return the string "test", the assertion
    # would be the following:
    # assert result == "test"


# Generated at 2022-06-11 12:23:42.450441
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    am = ActionModule()
    default_fallback = '-r'