

# Generated at 2022-06-11 12:14:21.153559
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # Setup mock
    # ActionModule object
    from ansible_collections.notmintest.not_a_real_collection.plugins.modules import reboot
    mock_ActionModule = create_autospec(reboot.ActionModule)

    mock_ActionModule._task = MagicMock()

    # Mock distribution
    mock_distribution = MagicMock()
    mock_action_kwargs = MagicMock()

    # Assert side effect
    mock_action = create_autospec(reboot.ActionModule.check_boot_time)
    mock_action.side_effect = ValueError('boot time has not changed')

    # Call ActionModule method

# Generated at 2022-06-11 12:14:27.383858
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    args = load_fixture('raw_params_get_shutdown_command.json')
    module = ActionModule(load_fixture('task.json'), DictObj(args))
    expected_result = load_fixture('result_get_shutdown_command_sles.json')
    result = module.get_shutdown_command(DictObj(load_fixture('task_vars_shutdown.json')), 'SLES')
    assert_equal(result, expected_result)



# Generated at 2022-06-11 12:14:29.112724
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    action_module = Reboot()
    action_module.run_test_command(distribution='ubuntu')

# Generated at 2022-06-11 12:14:40.928516
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    distribute = Fakes.random_string(5)
    action_module = ActionModule(DEFAULT_TASK, DEFAULT_PLAY_CONTEXT, None)
    args_set = action_module.get_shutdown_command_args(distribute)

    # Initialize variables required for the test
    assertion_message = "Expected {0} to be of type {1} but got type {2}"
    args_message = "Expected {0} to be of type {1} but got type {2}"
    args_expected = [StrType, StrType, StrType, StrType, NoneType, StrType]


# Generated at 2022-06-11 12:14:47.685114
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action = {}
    action['args'] = {}
    action['deprecated_args'] = {}
    a = ActionModule(task=action, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    a.DEPRECATED_ARGS = {'arg1': '2'}
    action['action'] = 'reboot'

    a.deprecated_args()

    assert action['args']['arg1'] is None
    assert action['args']['arg2'] is None


# Generated at 2022-06-11 12:14:48.767273
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    pass


# Generated at 2022-06-11 12:14:50.463525
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    """Test get_shutdown_command"""
    # No need to test this method right now



# Generated at 2022-06-11 12:14:51.103421
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    pass

# Generated at 2022-06-11 12:15:02.183409
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    # Prepare test data
    test_host = 'localhost'
    test_user = 'testuser'
    test_password = 'testpassword'
    test_data = "Ubuntu"
    test_facts = {'distribution': test_data}
    test_task_vars = {"ansible_facts": test_facts}
    test_connection = ConnectionMock(self=Mock(host=test_host, login_user=test_user, login_password=test_password))
    test_value = 'Ubuntu'
    # Execute the code
    test_object = ActionModule(connection=test_connection, task_vars=test_task_vars, runner_queue=None)

# Generated at 2022-06-11 12:15:09.175805
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)
    assert module.run() == {
        'failed': True,
        'reboot': False,
        'msg': 'Running reboot with local connection would reboot the control node.',
        'changed': False,
        'elapsed': 0,
        'rebooted': False
    }

# Unit test of method perform_reboot of class ActionModule 

# Generated at 2022-06-11 12:15:40.202483
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    am = ActionModule()
    am.check_boot_time("distribution", "previous_boot_time")

# Generated at 2022-06-11 12:15:41.255496
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass



# Generated at 2022-06-11 12:15:43.727986
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    a = ActionModule(mock.MagicMock(),mock.MagicMock())
    args = {'reboot_timeout': 12,
            'connect_timeout': 180}
    result = a.get_shutdown_command_args(args)
    expected = '-r -t 12'
    assert result == expected


# Generated at 2022-06-11 12:15:50.877315
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    am = ActionModule()
    am._task = AnsibleTask()
    am._task.action = 'reboot'
    am._connection = MockConnection()
    am._low_level_execute_command = MagicMock(return_value={
        'rc': 0,
        'stdout': 'Dec 31 23:59',
        'stderr': ''
    })
    am._supports_check_mode = True
    am._supports_async = True

    fail_count = 0

    # test method with a few different combinations
    with patch('datetime.datetime'):
        am.check_boot_time = MagicMock(side_effect=lambda: fail_count in [0, 1])

# Generated at 2022-06-11 12:16:01.248598
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    executable = sys.executable
    args = [executable, '-u', '-m', 'test.ansible.modules.test_command_module', 'shutdown', 'linux']
    sys.argv = args
    #assert_equal(env._ansible_servername, None)
    with patch.object(CommandModule, 'run') as mocked_run:
        mocked_run.return_value = {'rc': 0}
        #env._ansible_servername = None
        CommandModule().run()
    assert_equal(mocked_run.call_count, 1)

# Generated at 2022-06-11 12:16:12.478351
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    action_module = ActionModule()

    # Test with no args
    assert action_module.run_test_command(None) is not False
    assert action_module.run_test_command(None) is not True
    assert isinstance(action_module.run_test_command(None), None)
    assert action_module.run_test_command(None) is None

    # Test with non existing distribution
    assert action_module.run_test_command('does_not_exist') is not False
    assert action_module.run_test_command('does_not_exist') is not True
    assert isinstance(action_module.run_test_command('does_not_exist'), None)
    assert action_module.run_test_command('does_not_exist') is None

    # Test with non existing distribution
    assert action_module

# Generated at 2022-06-11 12:16:13.468257
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
	pass


# Generated at 2022-06-11 12:16:14.538642
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    pass # unit test is not implemented.



# Generated at 2022-06-11 12:16:21.269163
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():

    class MockDistribution(object):
        def __init__(self, distribution, release):
            self.distribution = distribution
            self.release = release

        def __str__(self):
            return self.distribution.lower()

    class MockRebootModule(RebootModule):
        def __init__(self, *args):
            RebootModule.__init__(self, *args)

        def get_distribution(self, task_vars):
            # Set to a test value
            return MockDistribution('Test', '1.1')


# Generated at 2022-06-11 12:16:31.993765
# Unit test for method check_boot_time of class ActionModule

# Generated at 2022-06-11 12:17:30.114194
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    pass


# Generated at 2022-06-11 12:17:33.197061
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # this is just a stub/template until full unit tests are added
    action_module = ActionModule()
    action_module.do_until_success_or_timeout(None, None, None, **{})

# Generated at 2022-06-11 12:17:40.185224
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    a = ActionModule()
    facts = {}
    facts['distribution'] = 'RedHat'
    facts['distribution_version'] = '6.9'
    facts['distribution_release'] = 'Final'
    a.set_options(action=None, no_log=None, connection=None, persistent_action=None, module_paths=None, forks=None, become=None, become_method=None, become_user=None, check=None, diff=None)
    a.set_task_vars(task_vars=None)

    a.set_fact(facts)
    expected = '/sbin/shutdown'
    actual = a.get_shutdown_command(task_vars=facts)
    assert actual == expected


# Generated at 2022-06-11 12:17:41.970163
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
  #TODO(kahoona): Implement this unit test
  return False


# Generated at 2022-06-11 12:17:52.320005
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():

    # An AnsibleModule object
    dummy_module = AnsibleModule(argument_spec={})
    
    # A fake ansible task to run module under test
    dummy_task = DummyTask(action=DummyActionModule())

    # A Dummy PlayContext object
    dummy_play = DummyPlayContext()

    # A Dummy AnsibleConnection object
    ansible_connection = DummyAnsibleConnection(play_context=dummy_play)

    dummy_action_module = ActionModule(task=dummy_task, connection=ansible_connection, templar=None, shared_loader_obj=None)
    distribution='any'
    previous_boot_time='last_boot_time'
    result = dummy_action_module.check_boot_time(distribution, previous_boot_time)

# Generated at 2022-06-11 12:18:02.386070
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = MagicMock(name='ansible.plugins.action.reboot.Connection')
    m.reset = MagicMock(return_value=None)
    m.get_option = MagicMock(return_value=None)
    m.set_option = MagicMock(return_value=None)
    m.transport = "abc"
    m.get_distribution = MagicMock(return_value=("Ubuntu", "16.04.4 LTS", "xenial"))
    m.close = MagicMock(return_value=None)
    m.get_distribution = MagicMock(return_value=("Ubuntu", "16.04.4 LTS", "xenial"))
    m.host = "host1"
    m.port = "22"
    m.get_remote_host = Magic

# Generated at 2022-06-11 12:18:12.645001
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # Create a mock task to pass to our module.  The mock_action_base class
    # defined in test/unit/test_utils.py allows us to create mock modules that
    # will work with the AnsibleModule class defined in ansible.module_utils.basic
    # This creates a mock action module that will be used in our unit tests for
    # the remainder of this script.
    # This next line creates a mock object for our `reboot` module
    mock_action_module = AnsibleActionModule(ReActionModule.DEFAULT_TEST_MODULE_PATH)

    facts = {}
    distribution = mock_action_module.get_distribution(facts)
    assert distribution == 'generic'

    facts = dict(ansible_distribution=None)
    distribution = mock_action_module.get_distribution(facts)
    assert distribution

# Generated at 2022-06-11 12:18:23.472572
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    # Setup
    import ansible.config
    def _get_ansible_config():
        return None

    monkeypatch.setattr(ansible.config.loader, 'get_config', _get_ansible_config)

    mocked_task = MagicMock()
    mocked_task.action = 'test_action'
    mocked_task.args = {
        'test_arg': 'test_val'
    }

    # Test
    action_module = ActionModule(mocked_task, MagicMock())
    action_module.DEPRECATED_ARGS.update({
        'test_arg': '1.0'
    })
    action_module.display = MagicMock()
    action_module.deprecated_args()

# Generated at 2022-06-11 12:18:34.103836
# Unit test for method run_test_command of class ActionModule

# Generated at 2022-06-11 12:18:44.061741
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    # Test normal flow
    reboot_timeout = 300
    test_host = Mock()
    test_host.options = {}
    test_host.options['maxtimeout'] = 300
    test_host.run_command.return_value = {'stdout': 'Tue 2018-12-04 09:04:59 EST\n', 'rc': 0}
    test_action = ActionModule(Mock(), task=dict(), connection=Mock())
    test_action._connection = Mock()
    test_connection = test_action._connection
    test_connection.set_option = Mock()
    test_connection.get_option = Mock(return_value=reboot_timeout)
    test_connection.reset = Mock()

# Generated at 2022-06-11 12:20:53.621765
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils import basic
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils._text import to_bytes
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.common._collections_compat import MutableMapping
    from ansible_collections.notstdlib.moveitallout.plugins.modules.system import reboot

    class AnsibleModule(object):
        def __init__(self, argument_spec, **kwargs):
            self.params = dict()
            self.exit_args = dict()

        def fail_json(self, **kwargs):
            self.exit_args = kwargs
            self.exit_args['failed'] = True

# Generated at 2022-06-11 12:20:55.284344
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    ret = ActionModule.validate_reboot()
    
    assert ret == {'failed': True,
  'rebooted': True,
  'msg': 'Timed out waiting for last boot time check (timeout=1200)'}



# Generated at 2022-06-11 12:20:59.880578
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    import requests
    import pytest
    from ansible.utils.vars import combine_vars
    from ansible.plugins.action import ActionBase
    from ansible.errors import AnsibleConnectionFailure
    from ansible.utils.vars import combine_vars
    from ansible.template import Templar
    import time
    import random
    import ansible.utils.unsafe_proxy
    from ansible.plugins.connection.local import Connection as ConnectionLocal

    #test1
    test_object = ActionModule()
    test_object.run()
    #test2
    test_object = ActionModule(task=DummyTask(), connection=ConnectionLocal())
    test_object.run()
    arg1 = 'distribution' 
    arg2 = 'original_connection_timeout'
    arg3 = 'action_kwargs'
    test_

# Generated at 2022-06-11 12:21:01.172942
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    # note: this unit test is purposely over-constrained for demonstration purposes
    module = ActionModule()
    assert module.get_shutdown_command_args('ubuntu') == 'shutdown now'

# Generated at 2022-06-11 12:21:03.502344
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    from ansible.plugins.action.reboot import ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.get_shutdown_command(task_vars=None, distribution=None) == '/sbin/shutdown'


# Generated at 2022-06-11 12:21:05.079099
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    host = DummyHost()
    action = ActionModule(host, 'test_task_name')
    distribution = 'ubuntu'
    action.get_system_boot_time(distribution)


# Generated at 2022-06-11 12:21:05.722920
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass



# Generated at 2022-06-11 12:21:10.530269
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    """Test the get_system_boot_time method of the ActionModule class.

    Args:
        None

    Returns:
        None

    Raises:
        None
    """
    # This import statement is to overcome circular dependency;
    # The unit test framework needs to import the module it tests, and this import
    # statement brings the 'ModuleExecutor' class into memory, to be tested.
    # Without this import statement, the framework will not be able to find this
    # class to test.
    # pylint: disable=redefined-outer-name
    from ansible.executor.task_executor import ModuleExecutor

    # pylint: disable=missing-docstring

# Generated at 2022-06-11 12:21:15.363464
# Unit test for method check_boot_time of class ActionModule

# Generated at 2022-06-11 12:21:22.328508
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module = ActionModule()
    task_vars = {}
    distribution = action_module.get_distribution(task_vars)
    assert distribution == 'DEFAULT'

    task_vars = {}
    task_vars['ansible_distribution'] = 'Ubuntu'
    distribution = action_module.get_distribution(task_vars)
    assert distribution == 'Ubuntu'

    task_vars = {}
    task_vars['ansible_distribution'] = 'Debian'
    distribution = action_module.get_distribution(task_vars)
    assert distribution == 'Debian'

    task_vars = {}
    task_vars['ansible_distribution'] = 'Fedora'
    distribution = action_module.get_distribution(task_vars)