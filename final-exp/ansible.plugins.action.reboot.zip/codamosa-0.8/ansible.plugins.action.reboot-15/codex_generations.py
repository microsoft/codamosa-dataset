

# Generated at 2022-06-11 12:14:24.692938
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    ssh_connection = Mock(name='ssh_connection')
    module_args = {}
    search_paths = ['path1', 'path2', 'path3']
    action_module = ActionModule(ssh_connection, module_args)
    find_binary_mock = Mock(name='find_binary')
    action_module.find_binary = find_binary_mock
    task_vars = {}

    # The find_binary will find the command
    find_binary_mock.return_value = '/usr/sbin/halt'

    distribution = 'FreeBSD'
    expected_return = '/usr/sbin/halt'
    return_value = action_module.get_shutdown_command(task_vars, distribution)
    assert expected_return == return_value
    find_binary_mock.assert_called

# Generated at 2022-06-11 12:14:32.394098
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():

    # GIVEN a module
    module = ActionModule()

    # WHEN a distribution is passed and a AnsibleConnectionFailure is raised (invalid connection)
    distribution = 'CentOS'
    task_vars = {}
    with patch.object(module, 'perform_reboot') as mockobj:
        mockobj.side_effect = AnsibleConnectionFailure
        module.perform_reboot(distribution, task_vars)

    # THEN a call to perform_reboot is made with the correct distribution and task_vars
    mockobj.assert_called_once_with(task_vars, distribution)

# Generated at 2022-06-11 12:14:39.223260
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    distribution = 'linux'
    #test if when there is no failure then the rebooted is changed to True

# Generated at 2022-06-11 12:14:48.627582
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    class MockActionModule(ActionModule):
        def __init__(self, *args, **kwargs):
            super(MockActionModule, self).__init__(*args, **kwargs)
            self.mock_low_level_execute_command = MagicMock()

        def _low_level_execute_command(self, cmd, sudoable=True):
            return self.mock_low_level_execute_command(cmd, sudoable=True)

        @staticmethod
        def get_system_boot_time(distribution):
            return "2019-09-11 15:45:09 UTC"


    action = MockActionModule(task=dict(args=dict()))

# Generated at 2022-06-11 12:14:56.367244
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    ansible_str = 'test_ActionModule_check_boot_time'
    action_module = AnsibleModule(ansible_str, 'reboot')
    action_module.get_system_boot_time = MagicMock(return_value = 'abc')
    action_module.DEFAULT_SUDOABLE = True
    action_module.reboot_validate_distribution_facts = MagicMock(return_value = 'abc')
    action_module.check_boot_time('abc', 'def')
    assert action_module.get_system_boot_time.called


# Generated at 2022-06-11 12:15:04.066348
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action_module = ActionModule()
    action_module._task.args = {'pre_reboot_delay': 10, 'post_reboot_delay': 20, 'reboot_timeout': 30}
    action_module.deprecated_args()
    assert action_module._task.args['pre_reboot_delay_sec'] == 10
    assert action_module._task.args['post_reboot_delay_sec'] == 20
    assert action_module._task.args['reboot_timeout_sec'] == 30



# Generated at 2022-06-11 12:15:15.168022
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    rnd = random.randint(0,100)


# Generated at 2022-06-11 12:15:17.703571
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    """
    ActionModule#get_shutdown_command_args(distribution)
    """
    raise NotImplementedError('Unit test not implemented!')

# Generated at 2022-06-11 12:15:24.098199
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    # setup param
    distribution = "linux"
    original_connection_timeout = None
    action_kwargs = {}
    # setup instance
    instance = ActionModule()
    # setup return_value of do_until_success_or_timeout
    instance.do_until_success_or_timeout = lambda a, action_desc, b, c, d: None
    # call method
    result = instance.validate_reboot(distribution, original_connection_timeout, action_kwargs)
    assert result is None


# Generated at 2022-06-11 12:15:27.537452
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # An object of class ActionModule
    action_obj = ActionModule()
    # Variable defined to call method to test
    task_vars = {}
    assert action_obj.get_distribution(task_vars) == 'default'


# Generated at 2022-06-11 12:16:10.623207
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    args = {
      "reboot_timeout": 300,
      "reboot_timeout_sec": 300,
      "post_reboot_delay": 0
    }

    am = ActionModule()
    am.DEFAULT_REBOOT_TIMEOUT = 300
    am._task = MagicMock()
    am._task.args = args

# Generated at 2022-06-11 12:16:13.572545
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    instance = ActionModule()
    command_args = {"ubuntu": ['-P', 'now'], "redhat": ['-r', 'now'], "debian": ['-r', 'now']}
    distribution = "redhat"
    result = instance.get_shutdown_command_args(distribution)
    # print(distribution + ": " + result[0] + " " + result[1])
    assert result in command_args

# Generated at 2022-06-11 12:16:20.800480
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    from ansible import context
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.utils.display import Display
    from ansible.plugins.action.reboot import ActionModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import get_default_fact_cache
    display = Display()  # type: ignore
    am = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None,
    )
    distribution = 'Rhel'
    expected = '-r now'
    actual = am.get_

# Generated at 2022-06-11 12:16:25.601238
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    host = MockConnection()

    task = MockTask()

    action_module = ActionModule(task, host)

    distro = FakeDistribution()

    result = action_module.perform_reboot(MockTask(), distro)

    assert result['failed'] == False

    assert result['start'] != None


# Generated at 2022-06-11 12:16:36.332155
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    assert len(ActionModule.do_until_success_or_timeout.__code__.co_varnames) == 5
    assert ActionModule.do_until_success_or_timeout.__code__.co_varnames[0] == 'self'
    assert ActionModule.do_until_success_or_timeout.__code__.co_varnames[1] == 'action'
    assert ActionModule.do_until_success_or_timeout.__code__.co_varnames[2] == 'reboot_timeout'
    assert ActionModule.do_until_success_or_timeout.__code__.co_varnames[3] == 'action_desc'
    assert ActionModule.do_until_success_or_timeout.__code__.co_varnames[4] == 'distribution'


# Unit

# Generated at 2022-06-11 12:16:41.816457
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    from library.reboot import ActionModule
    test_module = ActionModule(
        task=dict(vars=dict(ansible_os_family='Debian')),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None)
    assert test_module.get_distribution(None) == "debian"


# Generated at 2022-06-11 12:16:42.909814
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    assert False

# Generated at 2022-06-11 12:16:49.412633
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module = ActionModule(dict(
        action='reboot',
        distribution='ubuntu',
        test_command='echo OK',
    ))
    result = action_module.get_shutdown_command_args('ubuntu')
    assert repr(result) == repr('-r now')
    result = action_module.get_shutdown_command_args('unknown')
    assert repr(result) == repr('-r now')


# Generated at 2022-06-11 12:16:53.985147
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    args = dict()
    reboot_timeout = 1
    distribution = 'Ubuntu'
    validate(ActionModule(None, None).get_shutdown_command_args(distribution,
                                                                reboot_timeout),
             {'args': args, 'reboot_timeout': reboot_timeout,
              'distribution': distribution})

# Generated at 2022-06-11 12:16:57.348128
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    action_module = ActionModule()
    param1 = ''
    expected = ''
    actual = action_module.get_system_boot_time(distribution=param1)
    assert actual == expected


# Generated at 2022-06-11 12:17:38.918175
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    class mock_task():
        def __init__(self):
            self.action = 'reboot'

    class mock_connection():
        def __init__(self):
            self.transport = 'ssh'

    class mock_play_context():
        def __init__(self):
            self.check_mode = False

    module = ActionModule(
        task_vars=dict(),
        connection=mock_connection(),
        play_context=mock_play_context(),
        loader=None,
        templar=None,
        shared_loader_obj=None)

    action = module.do_until_success_or_timeout
    # set a very high reboot timeout just to make sure timeout is raised
    reboot_timeout = 1200
    distribution = 'DEFAULT'
    # set test command that should succeed after 1 iteration


# Generated at 2022-06-11 12:17:45.741592
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    host_vars_object = {
        'ansible_distribution': 'Fedora',
        'ansible_kernel': '4.4.0-1162.el7.x86_64'
    }
    reboot_module = ActionModule('reboot')

    # Testing Fedora
    distribution = 'Fedora'
    task_vars = {
        'ansible_facts': host_vars_object,
        'ansible_distribution': distribution,
        'ansible_distribution_release': '28',
        'ansible_os_family': 'RedHat'
    }
    reboot_module._task = {'args': {
        'shutdown_timeout': '30',
        'reboot_timeout': '100'
    }}
    reboot_module._task_vars = task_vars
    reboot_module

# Generated at 2022-06-11 12:17:56.318448
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    m = Mock()
    m.ansible_facts = dict(distribution='Linux')
    m.action = 'reboot'
    m.args = dict(reboot_timeout=300)
    a = ActionModule(m)
    a.DEFAULT_BOOT_TIME_COMMAND = "uptime"

    a.DEFAULT_SUDOABLE = False
    a.get_system_boot_time = Mock(name="get_system_boot_time")
    a.get_system_boot_time.return_value = "14:39:34 up 8 days,  6:45, 13 users,  load average: 0.00, 0.00, 0.00"

# Generated at 2022-06-11 12:18:06.270854
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    print("BEGIN test_ActionModule_get_distribution")
    test_action_module = ActionModule(None, None)
    ansible_facts = {
        'ansible_virtualization_role': 'guest',
        'ansible_virtualization_type': 'docker',
        'ansible_distribution': 'Debian',
        'ansible_distribution_version': '8.0'}
    test_action_module.set_connection_variable(ansible_facts)
    test_action_module._task.action = 'reboot'
    test_action_module._task.args = { }
    distribution = test_action_module.get_distribution(ansible_facts)
    assert distribution == 'DEBIAN_DOCKER'
    print("END test_ActionModule_get_distribution")

# Unit

# Generated at 2022-06-11 12:18:07.322276
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    pass


# Generated at 2022-06-11 12:18:11.736743
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # No exception raised
    action_module = ActionModule()

# Generated at 2022-06-11 12:18:23.203951
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    #
    # Test get_distribution with no facts or detected_os
    #

    mock_task = Mock()
    mock_task.args = {}
    mock_task.args['_ansible_check_mode'] = False
    mock_task.args['_ansible_debug'] = True
    mock_task.args['_ansible_diff'] = False
    mock_task.args['_ansible_verbosity'] = 2
    mock_task.args['action'] = 'reboot'
    mock_task.args['connect_timeout'] = 5
    mock_task.args['connect_timeout_sec'] = 5
    mock_task.args['msg'] = ''
    mock_task.args['no_log'] = False
    mock_task.action = 'reboot'
    mock_task.async_val = None

# Generated at 2022-06-11 12:18:33.863992
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    class MockWaitTimeAction(ActionModule):
        def __init__(self):
            super(MockWaitTimeAction, self).__init__(dict())
            self.__fail_count = 0
            self.__current_time = datetime.now()
            self.__max_wait_time = 10 #seconds
        def get_current_time(self):
            return self.__current_time
        def set_current_time(self, new_time=None):
            self.__current_time = new_time if new_time else datetime.now()
        def increment_fail_count(self):
            self.__fail_count += 1
        def get_fail_count(self):
            return self.__fail_count
        def get_max_wait_time(self):
            return self.__max_wait_time

# Generated at 2022-06-11 12:18:40.854102
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # FUTURE: Fix this fragmented test
    test_method = {}

    def test_method():
        global test_method
        # test_method['counter'] += 1
        # if test_method['counter'] == 3:
        #     return
        raise ValueError("Test exception")

    action_module = ActionModule()
    test_method['counter'] = 0
    action_module.do_until_success_or_timeout(action=test_method, action_desc="", reboot_timeout=5, distribution="")



# Generated at 2022-06-11 12:18:50.337080
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    import collections
    # unit
    class Test_ActionModule_get_distribution:
        # remove any traces of the class being instantiated
        # for each test run
        @classmethod
        def tearDownClass(cls):
            del cls.module

        @mock.patch.object(AnsibleModule, 'run_command')
        def test_get_distribution(self, mock_run_command):
            # unit
            class Test_get_distribution:
                # arrange
                def __init__(self):
                    self.value = None
                    self.distribution_id = None

                def __call__(self, value):
                    # arrange
                    import json
                    if value in ['lsb_release', 'redhat']:
                        value = ['/usr/bin/{0}'.format(value)]
                    el

# Generated at 2022-06-11 12:20:00.391870
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    class Context:
        def get_remaining_time(self):
            return timestamp
    class ActionModule:
        def __init__(self):
            self.action = 'reboot'
            self.timed_out = False
        def do_something(self, **kwargs):
            if kwargs['test_var'] == 'fail':
                raise ValueError('test error')
            else:
                return True
    class TimedOutException(Exception):
        pass
    class AnsibleError(Exception):
        pass
    class Display:
        def debug(self, msg):
            print(msg)
    class Datetime:
        @staticmethod
        def utcnow():
            return datetime(1, 1, 1, 0)
    check_module = ActionModule()
    checkmodule = CheckModule()
    checkmodule._

# Generated at 2022-06-11 12:20:09.890472
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    module = ActionModule()
    assert module.get_distribution({'ansible_facts': {'distribution': 'Ubuntu'}}) == 'Ubuntu'
    assert module.get_distribution({'ansible_facts': {'distribution': 'Debian'}}) == 'Debian'
    assert module.get_distribution({'ansible_facts': {'distribution': 'Redhat'}}) == 'Redhat'
    assert module.get_distribution({'ansible_facts': {'distribution': 'OracleLinux'}}) == 'Redhat'
    assert module.get_distribution({'ansible_facts': {'distribution': 'Amazon'}}) == 'Amazon'
    assert module.get_distribution({'ansible_facts': {'distribution': 'CentOS'}}) == 'Redhat'

# Generated at 2022-06-11 12:20:20.364787
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # testing error message
    action_module = ActionModule()
    with pytest.raises(TimedOutException) as excinfo:
        action_module.do_until_success_or_timeout(action="", action_desc="" , reboot_timeout=1)
    assert excinfo.value.args[0] == 'Timed out waiting for  (timeout=1)'
    # mock the current time
    action_module.datetime = Mock()
    utcnow = MagicMock()
    action_module.datetime.utcnow = utcnow
    now = datetime.utcnow()
    utcnow.return_value = now
    # testing the call to action, expected to raise exception

# Generated at 2022-06-11 12:20:25.976604
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    class ActionModuleImpl(ActionModule):
        def __init__(self, *args):
            self.conn = None
            self.connection = None
            self.DEFAULT_REBOOT_TIMEOUT = 5
            self.post_reboot_delay = 1
            self.shutdown_command = 'shutdown.exe'

        def get_distribution(self, task_vars):
            return 'Windows'

        def get_shutdown_command_args(self):
            return '-r -t 5'


# Generated at 2022-06-11 12:20:31.015820
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # unit test for method get_distribution of class ActionModule
    # set up test
    action_module = ActionModule(connection=None,
                                 play_context=None,
                                 loader=None,
                                 templar=None,
                                 shared_loader_obj=None)
    action_module._task = Mock()
    action_module._task.action = 'reboot'

    # Make sure distribution isn't already set in task args
    action_module._task.args = {}

    # Set up facts
    # The distro info for Ubuntu is pulled in by the setup module
    # and is the minimum required to get an id
    task_vars = {'ansible_facts': {'distribution': 'Ubuntu'}}

    # test
    distribution = action_module.get_distribution(task_vars)

   

# Generated at 2022-06-11 12:20:35.551741
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    action_module = action_plugin.ActionModule(task=Mock(action='reboot'), connection=Mock(), play_context=Mock(), loader=Mock(), templar=Mock(), shared_loader_obj=Mock())
    action_module.get_system_boot_time = Mock(return_value='123')
    action_module.check_boot_time = Mock()

    try:
        action_module.validate_reboot(distribution='Debian', action_kwargs={})
    except Exception as e:
        assert False, "Unexpected exception thrown: %s" % to_text(e)

    assert action_module.get_system_boot_time.call_count == 1
    assert action_module.check_boot_time.call_count == 1



# Generated at 2022-06-11 12:20:36.152761
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    pass


# Generated at 2022-06-11 12:20:36.757842
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    pass



# Generated at 2022-06-11 12:20:41.316747
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    path = "/Users/n/Projects/ansible/lib/ansible/modules/system/reboot.py"

    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six import b
    from ansible.module_utils.six.moves import shlex_quote
    from ansible.module_utils.basic import AnsibleModule
    import json
    import os

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-11 12:20:45.928543
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Perform the proper mocking so we can test with a real ActionModule class
    # This is a subclass of the AnsibleModule class with some helper functions
    class MockAnsibleModule(ActionModule):
        def __init__(self, *args, **kwargs):
            self.params = args[0]
            self.connection = args[1]
            self.task = args[2]
            self._result = dict(failed=False)

        def get_distribution(self, task_vars):
            return 'Fedora'


# Generated at 2022-06-11 12:23:35.299662
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    module = get_module_instance_for_testing()

    task_vars = {}
    distribution = 'Ubuntu'

    result = module.perform_reboot(task_vars, distribution)
    assert result == {'start': datetime(2017, 9, 30, 14, 2, 8, 213811), 'failed': False}

# Generated at 2022-06-11 12:23:38.359938
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    facts = {}
    # No facts for platform
    task_vars = {}
    action_module = ActionModule(None, {}, task_vars)
    assert action_module.get_distribution(task_vars) is None



# Generated at 2022-06-11 12:23:43.894522
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Set up test data.
    task_vars = {
        'ansible_service_mgr': 'systemd',
        'ansible_system': 'SunOS',
    }

    # unit test
    action = ActionModule(None, None, None)
    shutdown_bin = action.get_shutdown_command(task_vars=task_vars, distribution='_solaris')

    # Validate the result.
    assert shutdown_bin == '/usr/sbin/shutdown'

