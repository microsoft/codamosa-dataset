

# Generated at 2022-06-11 12:14:20.890058
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Configure the ActionModule
    # TODO: Can remove this once we figure out how to get this from Ansible
    class Mock:
        _task = {
            'action': 'reboot',
            'args': {}
        }
    am = ActionModule(Mock, {})

    # Check that result is initialized correctly
    assert(am.run({}, {}) == {'skipped': True, 'skipped_reason': 'Likely not a supported system', 'failed': False})

    # Check that a reboot was performed
    assert(am.run({}, {'ansible_facts': {'distribution': 'generic'}}) == {'changed': True, 'elapsed': 0, 'rebooted': True})

    # Check that a reboot was validated
    mock_connection = MockConnection()
    am._connection = mock_connection
   

# Generated at 2022-06-11 12:14:29.494599
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
  # Instantiate test class and perform setup
  actionModule = ActionModule()
  return_value1 = {
      "failed": False,
      "rebooted": False,
      "changed": False,
      "elapsed": 0,
      "msg": ""
  }
  actionModule._supports_check_mode = True
  actionModule._supports_async = True
  actionModule._task.action = "test_action_Module"
  actionModule._task.args = {
      "post_reboot_delay": 0,
      "reboot_timeout": 0,
      "connect_timeout": 0
  }
  actionModule._connection.transport = "local"
  actionModule._play_context.check_mode = True

# Generated at 2022-06-11 12:14:40.877609
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    with pytest.raises(ValueError) as execinfo:
        action_module.check_boot_time("does not matter", "does not matter")
    assert "boot time has not changed" in str(execinfo.value)

    class MockException(Exception):
        def __str__(self):
            err = 'Test command failed: {err} {out}'.format(
                err='stderr',
                out='stdout')
            return err

    with pytest.raises(MockException):
        action_module.check_boot_time("does not matter", "does not matter")


# Generated at 2022-06-11 12:14:49.609041
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module = ActionModule(dict(), dict())
    assert action_module.get_shutdown_command_args("redhat") == "-r now"
    assert action_module.get_shutdown_command_args("centos") == "-r now"
    assert action_module.get_shutdown_command_args("amazon") == "-r now"
    assert action_module.get_shutdown_command_args("fedora") == "-r now"
    assert action_module.get_shutdown_command_args("ubuntu") == "-r now"
    assert action_module.get_shutdown_command_args("debian") == "-r now"
    assert action_module.get_shutdown_command_args("suse") == "-r now"

# Generated at 2022-06-11 12:14:50.641308
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # FIXME: implement this
    pass

# Generated at 2022-06-11 12:15:01.641959
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # Pre-condition check that there is no 'ansible.cfg' in the current directory
    ansible_cfg_path = os.getcwd() + '/ansible.cfg'
    if os.path.isfile(ansible_cfg_path):
        raise Exception('ansible.cfg found in current directory.  Please remove it so that the unit test can run.')

    # We are creating a test class derived from ActionModule
    class ActionModuleTest(ActionModule):
        def __init__(self, *args, **kwargs):
            super(ActionModuleTest, self).__init__(*args, **kwargs)

        def get_system_boot_time(self, distribution):
            return "2016-04-08 03:51:16"

        def get_distribution(self, task_vars):
            return "Linux"

    #

# Generated at 2022-06-11 12:15:02.756541
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    pass


# Generated at 2022-06-11 12:15:13.889913
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    action = dict(
        _ansible_no_log=False,
        _uses_shell=False,
        _raw_params='reboot',
        _task_fields=dict(
            _task=dict(
                args=dict(
                    test_command='/bin/true',
                    reboot_timeout=600,
                ),
                action='reboot',
            ),
        ),
        _execute_module=None,
        _connection=dict(
            transport='ssh',
        )
    )

    action_module = ActionModule(action, play_context=None)

    original_connection_timeout = '120'
    distribution = 'centos'

    result = action_module.validate_reboot(distribution, original_connection_timeout)


# Generated at 2022-06-11 12:15:22.387347
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    task_vars = dict()
    task_vars['ansible_connection'] = 'local'
    task_vars['ansible_host'] = 'localhost'
    task_vars['ansible_port'] = '22'
    task_vars['ansible_user'] = 'root'
    task_vars['ansible_password'] = 'secret'
    task_vars['ansible_become'] = True
    task_vars['ansible_become_method'] = 'sudo'
    task_vars['ansible_become_user'] = 'root'
    task_vars['ansible_become_password'] = 'secret'
    task_vars['ansible_shell_type'] = 'sh'

# Generated at 2022-06-11 12:15:28.997897
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    actionModule = ActionModule()
    task_vars = {
        'ansible_system': 'Linux',
        'ansible_distribution': 'Fedora',
        'ansible_distribution_release': '27',
        'ansible_distribution_version': '27',
        'ansible_distribution_file_parsed': True
    }
    result = actionModule.get_shutdown_command(task_vars, 'UNKNOWN')
    assert result == '/sbin/shutdown'



# Generated at 2022-06-11 12:16:53.519170
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    ansible_runner = AnsibleRunner(testcase={
        "task": {
            "name": "reboot test",
            "action": {
                "module": "reboot",
                "args": {
                    "connect_timeout": 30,
                    "msg": "Bye",
                    "post_reboot_delay": 10
                }
            }
        }
    }, facts={})

    am = ActionModule(ansible_runner.task, ansible_runner.connection, ansible_runner.play_context, ansible_runner.loader)
    assert am.get_distribution({}) == "DEFAULT", "Failed to get distribution with unknown OS"
    assert am.get_distribution({"ansible_os_family": "RedHat"}) == "RHEL"

# Generated at 2022-06-11 12:16:54.642304
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # Raise NotImplementedError
    # There is not reasonable way to test a method that waits indefinitely
    raise NotImplementedError

# Generated at 2022-06-11 12:17:05.210523
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    # Ensure that arguments are extracted, and that defaults are used if not
    test_args = {'action': 'reboot', 'use_reboot': False, 'delay': 100, 'warm_reboot': True, 'reboot_timeout': 300}
    am = ActionModule(mock.Mock(), test_args)
    assert am.get_shutdown_command_args('redhat') == '-r +1 && sleep 100'
    test_args = {'action': 'reboot', 'use_reboot': True, 'delay': 100, 'warm_reboot': False}
    am = ActionModule(mock.Mock(), test_args)
    assert am.get_shutdown_command_args('redhat') == '-r'

# Generated at 2022-06-11 12:17:16.290442
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    """
    Test for the perform_reboot method of the ActionModule class
    """
    _ = AnsibleOptions(listtags=False, listtasks=False, listhosts=False, syntax=False, connection='ssh',
                       module_path=None, forks=100, remote_user='ansible', private_key_file=None,
                       ssh_common_args=None, ssh_extra_args=None, sftp_extra_args=None, scp_extra_args=None,
                       become=False, become_method='sudo', become_user='root', verbosity=3, check=False,
                       start_at_task=None, inventory=None, diff=False)
    _ = AnsibleConfig(definitions)
    _ = AnsibleVaultEncryptedUnicode('')

# Generated at 2022-06-11 12:17:17.331718
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    module.run()

# Generated at 2022-06-11 12:17:20.857122
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module = ActionModule(None, None, None)
    assert action_module.get_shutdown_command_args('freebsd') == '-r now'
    assert action_module.get_shutdown_command_args('linux') == '-r now'

# Generated at 2022-06-11 12:17:30.442487
# Unit test for method get_distribution of class ActionModule

# Generated at 2022-06-11 12:17:39.653546
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():

    task_vars = {
        'ansible_connection': 'network_cli'
    }
    distribution = {
        'Debian': {
            'name': 'Debian',
            'family': 'Debian',
            'shutdown_bin': '/sbin/shutdown',
            'TERM': 'xterm',
            'DEFAULT_TEST_COMMAND': '/usr/bin/true'
        }
    }

    # perform_reboot() produces an error
    host = 'localhost'
    play_context = PlayContext()
    play_context.connection = 'network_cli'
    task = Task()
    task.action = 'reboot'
    task.async_val = None
    task.args = {'connect_timeout': 10}
    connection = Connection(play_context, task, host)


# Generated at 2022-06-11 12:17:49.631673
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    # Boot timeout has been specified
    host_boot_test_failed_boot_time_test_command_failed_rc_0 = Host(name="host_boot_test_failed_boot_time_test_command_failed_rc_0",
                                                                     hostname="host_boot_test_failed_boot_time_test_command_failed_rc_0",
                                                                     vars=dict(ansible_connection="local",
                                                                               ansible_python_interpreter="/usr/bin/python3",
                                                                               ansible_host="host_boot_test_failed_boot_time_test_command_failed_rc_0"))

    result = ActionModule._run_test_command(host_boot_test_failed_boot_time_test_command_failed_rc_0, distribution="RedHat")

# Generated at 2022-06-11 12:18:00.137593
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    result = dict()
    result['foo'] = 'bar'
    result['reboot'] = False
    result['changed'] = True
    result['failed'] = True
    original_connection_timeout = None

    _task = dict()
    _task['async'] = None
    _task['async_val'] = None
    _task['notify'] = list()
    _task['delegate_to'] = None
    _task['delegate_facts'] = None
    _task['environment'] = None
    _task['register'] = None
    _task['when'] = None
    _task['first_available_file'] = None
    _task['until'] = None
    _task['retries'] = 0
    _task['delay'] = 0
    _task['poll'] = 0

# Generated at 2022-06-11 12:18:58.700693
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    m = ActionModule(
        task=dict(
            args=dict(
                shutdown_command='/sbin/halt -i -q',
            ),
        ),
    )
    m.task_vars = dict(
        ansible_lsb=dict(
            id='Ubuntu',
            distribution='Ubuntu',
            release='18.04',
            description='Ubuntu 18.04.1 LTS',
            major_release='18',
        )
    )

    assert m.get_shutdown_command(m.task_vars, 'Ubuntu') == '/sbin/halt -i -q'


# Generated at 2022-06-11 12:19:00.969332
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    am = ActionModule()
    am.check_boot_time("test_distribution", "test_boot_time")

# Generated at 2022-06-11 12:19:08.546908
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    host = MockConnection()
    mock_task = MockTask()
    mock_task.args = {'shutdown_timeout': 300}
    action_module = ActionModule(host, mock_task)
    task_vars = {'ansible_os_family': 'RedHat', 'ansible_distribution': 'CentOS', 'ansible_distribution_version': '7'}
    display.verbosity = 4
    assert action_module.get_shutdown_command(task_vars, 'CentOS') == '/sbin/shutdown'


# Generated at 2022-06-11 12:19:18.452657
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    from ansible.modules.system.reboot import ActionModule

    task_vars = {}
    tmp_path = mkdtemp()

    am = ActionModule(task=MagicMock(), connection=MagicMock(), play_context=MagicMock(), loader=MagicMock(),
                      templar=MagicMock(), shared_loader_obj=None)

    # Case 1 - reboot_type is 'reboot' which should be True
    am.get_system_boot_time = MagicMock(return_value='True')
    am.validate_reboot = MagicMock(return_value='True')

    test_distribution = 'TEST_DISTRIBUTION'
    test_action_kwargs = {'previous_boot_time': ['test']}


# Generated at 2022-06-11 12:19:28.020338
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():

    AM = ActionModule()

    # Test default value
    assert AM.get_system_boot_time('CentOS') == '/bin/date -d"$(awk -F. \'{print $1}\' /proc/uptime) second ago" +"%Y-%m-%d %H:%M:%S"'

    assert AM.get_system_boot_time('Ubuntu') == '/bin/date -d"$(awk -F. \'{print $1}\' /proc/uptime) second ago" +"%Y-%m-%d %H:%M:%S"'

    # Test custom value

# Generated at 2022-06-11 12:19:29.543871
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # try to instantiate the class
    my_obj = ActionModule()

# Generated at 2022-06-11 12:19:34.550310
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    '''
    test_ActionModule_get_distribution
    Tests the method get_distribution of class ActionModule
    '''
    self = {}
    self['_task'] = {}
    self['_task']['args'] = {}
    self['_task']['args']['distribution'] = 'Debian'
    # Will fail
    # self.get_distribution()



# Generated at 2022-06-11 12:19:44.554631
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    # Create an instance of the Arguments class
    args = Arguments()
    # Create an instance of the Task class
    task = Task()
    # Create an instance of the TaskVars class
    task_vars = TaskVars()

    # Create an instance of the ActionModule class
    action_module = ActionModule(task, args, task_vars)
    # Set the value of the boot_time_command attribute
    action_module.boot_time_command = "uptime | awk '{print $1}'"
    # Set the value of the DEFAULT_TEST_COMMAND attribute
    action_module.DEFAULT_TEST_COMMAND = "uptime"
    # Call the "get_system_boot_time" method of the ActionModule class
    action_module.get_system_boot_time("Ubuntu")

# Generated at 2022-06-11 12:19:54.613303
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # pre-test
    def _get_distribution(self, task_vars):
        return "CentOS"

    def _get_boot_time(self, distribution, **kwargs):
        if "DummyBootTimeError" in self.stderr:
            raise AnsibleError("Error getting boot time")

        if self.stdout == "DummyBootTime":
            return "DummyBootTime"


    def _get_shutdown_command(self, task_vars, distribution):
        if "DummyShutdownError" in self.stderr:
            raise AnsibleError("Error getting shutdown command")

        if self.stdout == "DummyShutdown":
            return "DummyShutdown"


    def _get_shutdown_command_args(self, distribution):
        return "DummyShutdownArgs"

# Generated at 2022-06-11 12:20:02.833444
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # Create new instance of our class
    action_module_obj = ActionModule()
    # Create arguments for method
    distribution = "test distribution"
    previous_boot_time = "test previous_boot_time"
    # Call method on class with our mock arguments
    result = action_module_obj.check_boot_time(distribution, previous_boot_time)
    # Assert methods were called as expected
    assert action_module_obj._task.args.get.call_count == 2
    assert action_module_obj._task.args.get.call_args_list == [call('boot_time_command'), call('connect_timeout')]
    assert action_module_obj._get_value_from_facts.call_count == 1