

# Generated at 2022-06-11 12:14:07.767490
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    pass


# Generated at 2022-06-11 12:14:20.611636
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
	_task = MagicMock()
	_connection = MagicMock()
	_play_context = MagicMock()

	test_instance = ActionModule(_task, _connection, _play_context)
	test_instance._low_level_execute_command = MagicMock(return_value={'rc':0})
	test_instance.get_system_boot_time = MagicMock(return_value='')

	action = test_instance.do_until_success_or_timeout(action=test_instance.run_test_command, 
                                                       action_desc="test_command", 
                                                       reboot_timeout=10, 
                                                       distribution="test_distribution", 
                                                       action_kwargs=None)
	assert action['rebooted'] == True




# Generated at 2022-06-11 12:14:27.089167
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    args = {}
    action = {}
    task_vars = {}
    set_module_args(args)

    # Initialize task
    task = Task()
    task._ds = action
    task._task = action

    # Initialize connection
    connection = Connection()

    # Initialize the module class
    module = ActionModule(task, connection)
    result = module.get_shutdown_command(task_vars, 'centos')
    assert result == '/sbin/shutdown'


# Generated at 2022-06-11 12:14:38.129629
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # setup
    am = ActionModule()
    am._task = Mock()
    am.DEFAULT_SUDOABLE = True
    am._low_level_execute_command = Mock()
    am._low_level_execute_command.return_value = {'rc': 0, 'stdout': 'Thu 2020-03-26 05:44:44 UTC'}
    am.DEFAULT_CONNECT_TIMEOUT = 30
    distribution = 'CentOS'
    previous_boot_time = 'Thu 2020-03-26 05:44:44 UTC'
    connect_timeout = am._task.args.get('connect_timeout', am._task.args.get('connect_timeout_sec', am.DEFAULT_CONNECT_TIMEOUT))

    # run

# Generated at 2022-06-11 12:14:42.650215
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.get_system_boot_time('test_distribution') is not None


# Generated at 2022-06-11 12:14:46.451356
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    test_instance = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    test_result = test_instance.perform_reboot(task_vars=None, distribution=None)
    pass

# Generated at 2022-06-11 12:14:49.439684
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    m = ActionModule(dict(ANSIBLE_MODULE_ARGS={'sleep':'5', 'connect_timeout_sec':'1', 'reboot_timeout_sec':'2'}))
    assert not m.deprecated_args()


# Generated at 2022-06-11 12:15:00.337642
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    import unittest.mock as mock
    import sys
    import traceback
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.errors import AnsibleConnectionFailure

    def get_mock_action_logic(return_after_n_calls, return_exception_after_n_calls, timeout=1, return_value=None):
        def mock_action_logic(*args, **kwargs):
            # If asked to raise an exception, do it the first time we're called
            if return_exception_after_n_calls is not None:
                if mock_action_logic.call_count >= return_exception_after_n_calls:
                    raise Exception('Failed to do something!')
            # If asked

# Generated at 2022-06-11 12:15:11.360066
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    action_module = ActionModule()

# Generated at 2022-06-11 12:15:20.935927
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    from unittest.mock import Mock, patch
    from collections import namedtuple
    from datetime import datetime
    from datetime import timedelta

    from ansible.module_utils.six import PY3
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.six import string_types

    from units.compat import unittest

    import ansible.plugins
    import ansible.plugins.action

    ansible.plugins.action.ActionModule._low_level_execute_command = Mock()
    ansible.plugins.action.ActionModule.get_system_boot_time = Mock()
    ansible.plugins.action.ActionModule.test_command = Mock()


# Generated at 2022-06-11 12:15:51.718100
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    action_module = ActionModule()
    result = action_module.perform_reboot(None, None)
    assert result == {}

# Generated at 2022-06-11 12:15:58.367670
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    distribution = "CentOS"
    shutdown_command = "/sbin/shutdown"
    # Get shutdown_command from the facts
    result = get_shutdown_command_from_facts("SHUTDOWN_COMMANDS", distribution)
    assert result == "/usr/bin/shutdown"
    # Get shutdown_command from the defaults
    result = get_shutdown_command_from_facts("SHUTDOWN_COMMANDS", distribution, shutdown_command)
    assert result == "/sbin/shutdown"



# Generated at 2022-06-11 12:16:09.630963
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    am = ActionModule(dict(ANSIBLE_MODULE_ARGS='{}',ANSIBLE_MODULE_CONSTANTS=dict()),dict())
    am._task = dict(vars=dict())
    assert am.get_shutdown_command(dict(),'') == 'shutdown'
    am._task['vars'] = dict(ansible_os_family='RedHat')
    assert am.get_shutdown_command(dict(),'') == 'shutdown'
    am._task['vars'] = dict(ansible_os_family='Blah')
    assert am.get_shutdown_command(dict(),'') == 'shutdown'
    am._task['vars'] = dict(ansible_os_family='FreeBSD')
    assert am.get_shutdown_command(dict(),'') == 'shutdown'

# Generated at 2022-06-11 12:16:18.754710
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    default_dict = dict()
    default_dict['task_vars'] = dict()
    default_dict.update(YAML_DUMPED_RESULT)

    runner_interface = MagicMock()
    runner_interface.action = 'reboot'
    runner_interface.task_vars = dict()
    runner_interface.task_vars.update(default_dict['task_vars'])

    task_interface = MagicMock()
    task_interface.async_val = 0
    task_interface.args = dict()
    task_interface.args.update({'connect_timeout': 'override', 'reboot_timeout': 'override'})

    connection_interface = MagicMock()
    connection_interface.transport = 'local'

    # Making sure we get False as the result
    action_module_

# Generated at 2022-06-11 12:16:29.738816
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():


    # Test success
    module = AnsibleModule({
      'connect_timeout': 5,
      'distribution': 'ubuntu'
    }, ansible_args=[])
    distro_module = ActionModule(module.params, module._task)
    shutil.copy('./test/integration/targets/reboot_freebsd.py', './test/integration/targets/shutdown_freebsd.py')

# Generated at 2022-06-11 12:16:30.891721
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    assert True



# Generated at 2022-06-11 12:16:32.317139
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    assert False # TODO: implement your test here


# Generated at 2022-06-11 12:16:36.767033
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module = ActionModule(5,5,5)
    # Test with no task, tmp, inject or play args
    task_vars = {}
    result = action_module.get_distribution(task_vars)
    assert result == 'DEFAULT'
    
    

# Generated at 2022-06-11 12:16:44.325816
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    test_args = {}
    test_action = ActionModule(None, test_args)
    # Test case with default distribution name
    test_task_vars = {}
    test_result = test_action.get_distribution(test_task_vars)
    assert test_result == 'default'
    # Test case with default distribution name
    test_task_vars = {'ansible_distribution': 'Ubuntu'}
    test_result = test_action.get_distribution(test_task_vars)
    assert test_result == 'ubuntu'


# Generated at 2022-06-11 12:16:54.614484
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    module = ActionModule(loader=None, connection=None, play_context=None, loader_for_test=MockLoader())
    mock_distribution = 'DEFAULT'

    with pytest.raises(TimedOutException):
        message = 'Timed out waiting for action_desc (timeout=1)'
        module.do_until_success_or_timeout(action=mock_action_string, action_desc='action_desc', reboot_timeout=1, distribution=mock_distribution)

    with pytest.raises(RuntimeError):
        module.do_until_success_or_timeout(action=mock_action_string_with_runtime_error, action_desc='action_desc', reboot_timeout=1, distribution=mock_distribution)


# Generated at 2022-06-11 12:18:00.706848
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    j = ActionModule('reboot', {'reboot_timeout': 5})
    j.distribution = {'DISTRIBUTION_DEFAULT_SHUTDOWN_COMMAND': 'shutdown_command'}
    assert('shutdown_command' == j.get_shutdown_command_args('os_family'))

    j = ActionModule('reboot', {'reboot_timeout': 5})
    j.distribution = {'DISTRIBUTION_DEFAULT_SHUTDOWN_COMMAND': 'shutdown_command', 'DISTRIBUTION_DEFAULT_SHUTDOWN_COMMAND_ARGS': 'shutdown_command_args'}
    assert('shutdown_command shutdown_command_args' == j.get_shutdown_command_args('os_family'))


# Generated at 2022-06-11 12:18:11.019304
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    class MockTask:
        action = 'reboot'
        
        class MockArgs:
            test_command = 'whoami'
        args = MockArgs()

    module = ActionModule()

    class MockDistribution:
        def __init__(self):
            self.name = 'default'
        def __eq__(self, other):
            return self.name == other.name

    class MockTaskVars:
        def __init__(self):
            self.distribution = MockDistribution()

    module._task = MockTask()
    module._low_level_execute_command = MagicMock(return_value={'rc':0, 'stdout':'root', 'stderr':''})
    module.run_test_command(distribution=MockDistribution(), task_vars=MockTaskVars())

# Generated at 2022-06-11 12:18:12.684812
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    print(ActionModule().get_shutdown_command_args('RedHat'))


# Generated at 2022-06-11 12:18:23.474594
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    """Test method do_until_success_or_timeout of class ActionModule"""
    # Random seed for repeatability
    random.seed(0)
    # Create a mock class for ActionModule
    mock = ActionModule()

    # Test with action=mock.check_boot_time, action_desc="last boot time check", reboot_timeout=reboot_timeout, distribution=distribution, action_kwargs=action_kwargs. Should pass
    mock.check_boot_time = MagicMock()
    with patch.object(mock, 'check_boot_time'):
        mock.check_boot_time.side_effect = [ValueError("boot time has not changed"), ValueError("boot time has not changed"), None]
        reboot_timeout = 1
        distribution = ""
        action_kwargs = None

# Generated at 2022-06-11 12:18:32.020894
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    # See if the function deprecated_args runs without exceptions

    class Options(object):
        pass

    class Task(object):
        def __init__(self, args):
            self.args = args
            self.action = 'action'

    # mock module arguments
    options = Options()
    options.connect_timeout_sec = 0
    options.shutdown_timeout_sec = 0
    options.reboot_timeout_sec = 0
    options.check_interval_sec = 0
    task = Task(options)
    module = ActionModule(task, connection=None)

    module.deprecated_args()

# Generated at 2022-06-11 12:18:41.828601
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    from ansible.module_utils.basic import AnsibleModule
    # prepare the test environment
    test_obj = ActionModule(name='test', runner=AnsibleModule)

    # Create a mock object to store the validated results
    result = {'success' : None}
    # Test Case where the method executes without any exceptions
    counter = 0
    def action_method(distribution=None, action_kwargs=None):
        nonlocal counter
        counter += 1
        if counter > 3:
            raise AnsibleError("Test Action failed!")
    try:
        test_obj.do_until_success_or_timeout(action=action_method, action_desc=None, reboot_timeout=2, distribution=None)
        result['success'] = True
    except Exception:
        result['success'] = False
    assert result['success']

# Generated at 2022-06-11 12:18:46.967843
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # input params
    task_vars = {'ansible_system': 'Linux'}
    distribution = 'Ubuntu'

    action_mod = ActionModule()
    result = action_mod.get_shutdown_command(task_vars, distribution)

    assert result == '/sbin/shutdown', "Expected '/sbin/shutdown' but got '{result}'".format(result=result)


# Generated at 2022-06-11 12:18:56.393547
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    my_mock_task = Mock()
    my_mock_task.action = 'reboot'
    my_mock_task.args = {}

    # Instantiate class under test
    action_module = ActionModule(my_mock_task, Mock())

    # Make sure the correct arguments are set
    assert action_module.DEFAULT_TEST_COMMAND == '/usr/bin/true'
    assert action_module.DEFAULT_REBOOT_TIMEOUT == 300
    assert action_module.DEFAULT_CONNECT_TIMEOUT == 40
    assert action_module.DEFAULT_POST_REBOOT_DELAY == 0
    assert action_module.DEFAULT_SUDOABLE == True

    # Set mock for display.warning()
    display_mock = Mock()

# Generated at 2022-06-11 12:19:06.919739
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    from ansible.plugins.action.reboot import ActionModule

    has_failing_check_boot_time = False
    has_succeeding_check_boot_time = False

    class TestActionModule(ActionModule):
        ALLOWED_BOOT_TIME_COMMANDS = {'ALLOWED_BOOT_TIME_COMMANDS': 'ALLOWED_BOOT_TIME_COMMAND'}
        ALLOWED_TEST_COMMANDS = {'ALLOWED_TEST_COMMANDS': 'ALLOWED_TEST_COMMAND'}

        def do_until_success_or_timeout(self, *args, **kwargs):
            nonlocal has_failing_check_boot_time
            nonlocal has_succeeding_check_boot_time

            action = args[0]


# Generated at 2022-06-11 12:19:11.323000
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    am = ActionModule()
    am.get_system_boot_time = lambda dist: '2018-12-21 14:59:40'
    am._task.action = 'reboot'
    # Force an exception to verify error handling
    assert am.check_boot_time('debian', 'error') == 0
