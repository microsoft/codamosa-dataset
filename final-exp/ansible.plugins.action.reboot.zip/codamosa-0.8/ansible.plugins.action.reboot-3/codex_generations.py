

# Generated at 2022-06-11 12:14:18.931900
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    action_module = ActionModule(task=ModuleTestCase.task, connection=ModuleTestCase.connection, play_context=ModuleTestCase.play_context, loader=ModuleTestCase.loader, templar=ModuleTestCase.templar, shared_loader_obj=None)
    action_module._task.args = {}
    action_module._task.args['test_command'] = 'test_test_command'
    action_module._connection._shell.exec_command.return_value = (1, b'stdout', b'stderr')
    try:
        action_module.run_test_command(distribution='test_distribution')
    except RuntimeError as e:
        assert str(e) == "Test command failed: stderr stdout"



# Generated at 2022-06-11 12:14:23.998992
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    module = ActionModule(remote_user='root')
    # module._task.args = {
    #     'reboot_timeout': 60,
    #     'connect_timeout': 10,
    #     'test_command': 'whoami'
    # }
    distribution = "CentOS"
    shutdown_command_args = module.get_shutdown_command_args(distribution)
    assert shutdown_command_args == '-r now'


# Generated at 2022-06-11 12:14:34.028335
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    instance = ActionModule()
    distribution = 'DEFAULT'
    original_connection_timeout = None
    action_kwargs = None
    assert isinstance(instance, ActionModule)
    assert instance.check_boot_time(distribution=distribution, previous_boot_time='previous_boot_time')
    assert instance.get_system_boot_time(distribution=distribution) == 'DEFAULT_BOOT_TIME_COMMAND'
    assert instance.perform_reboot(task_vars=None, distribution=distribution) == {'start': datetime.utcnow(), 'failed': False}
    assert instance.run_test_command(distribution=distribution)

# Generated at 2022-06-11 12:14:37.051406
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    # Arrange
    action_module = ActionModule()
    distribution = "DEFAULT"

    # Act
    action_module.run_test_command(distribution)


# Generated at 2022-06-11 12:14:37.832541
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
	pass

# Generated at 2022-06-11 12:14:44.266881
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    # Test with valid distribution
    distribution = 'Red Hat'
    shutdown_cmd_args = sh.get_shutdown_command_args(distribution)
    assert shutdown_cmd_args == '-r now'

    # Test with invalid distribution
    distribution = 'CentOS'
    shutdown_cmd_args = sh.get_shutdown_command_args(distribution)
    assert shutdown_cmd_args == '-r now'


# Generated at 2022-06-11 12:14:51.579659
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    test_module = ActionModule()

    class MockDistribution:
        pass

    class MockFactCache:
        def get(self, *args, **kwargs):
            return ''

    class MockFacts:
        def get(self, *args, **kwargs):
            return ''

    class MockAnsibleTask:
        def __init__(self):
            self.args = {}

    class MockAnsibleTaskArgs:
        def __init__(self, **kwargs):
            self._kwargs = kwargs

        def get(self, key, default=None):
            return self._kwargs.get(key, default)

    class MockAnsiblePlayContext:
        def __init__(self, **kwargs):
            self._kwargs = kwargs


# Generated at 2022-06-11 12:14:55.670889
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
	arg = {}
	arg['shutdown_command'] = None
	arg['unit_test'] = True
	action_module = ActionModule(None, arg)
	assert action_module.get_shutdown_command(None, None) == '/sbin/shutdown'


# Generated at 2022-06-11 12:15:06.914268
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # mock parameters
    self = Mock()
    tmp = None
    task_vars = None

    # mock class variables
    self.__supports_check_mode = None
    self.__supports_async = None
    self._play_context.check_mode = None

    # class attributes
    self._task.action = 'reboot'

# Generated at 2022-06-11 12:15:09.937199
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    action_module = ActionModule()
    assert action_module.get_system_boot_time(None) == 'Tue, 20 Dec 2016 06:20:50 +0000'

# Generated at 2022-06-11 12:15:47.967948
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    """check if deprecated args are detected"""

    task = ActionModule(dict(action='reboot'))
    task.DEPRECATED_ARGS = {'test_command': '2.6.0', 'test_command_sleep': '2.6.0', 'shutdown_timeout': '2.6.0', 'shutdown_timeout_sec': '2.6.0'}
    task_args = {'test_command': 'foobar', 'test_command_sleep': 2, 'shutdown_timeout': 2, 'shutdown_timeout_sec': 3}
    task._task.args = task_args

    with pytest.raises(AnsibleError) as excinfo:
        task.deprecated_args()


# Generated at 2022-06-11 12:15:58.139367
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.get_shutdown_command_args('redhat') == '-r now'
    assert action_module.get_shutdown_command_args('redhad') == '-r now'
    assert action_module.get_shutdown_command_args('amzn') == '-r now'
    assert action_module.get_shutdown_command_args('gentoo') == '-r now'
    assert action_module.get_shutdown_command_args('ubuntu') == '-r now'
    assert action_module.get_shutdown_command_args('debian') == '-r now'
    assert action_module.get_shutdown

# Generated at 2022-06-11 12:16:09.433167
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    from ansible.plugins.action import ActionModule
    from ansible.plugins.action.systemd import ActionModule as SystemdActionModule
    from ansible.plugins.action.systemd import SYSTEMD_MANAGER_NAME
    import os

    action_plugin = ActionModule(task=MagicMock(), connection=MagicMock(), play_context=MagicMock())
    systemd_action_plugin = SystemdActionModule(task=MagicMock(), connection=MagicMock(), play_context=MagicMock())

    task_vars = {}
    with pytest.raises(AnsibleError) as exec_info:
        action_plugin.get_shutdown_command(task_vars, 'ubuntu')
    assert exec_info.value.message == 'Both shutdown_command and shutdown_timeout are mandatory when using a custom shutdown command'

    task_

# Generated at 2022-06-11 12:16:15.554276
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    # Ensures the method called is that the deprecated one
    action_module = ActionModule(None, None)
    for arg_name in action_module.DEPRECATED_ARGS:
        with patch.object(action_module, '_task') as mock_task:
            mock_task.args = {arg_name: 'some_value'}
            action_module.deprecated_args()
            assert mock_task.action in action_module._display.deprecated.called

# Generated at 2022-06-11 12:16:25.555929
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    class FakeSource:
        def __init__(self, hosts_list=None, vars_list=None):
            pass

        def __call__(self):
            return False

    class FakeOptions:
        def __init__(self):
            self.connection = ''
            self.module_path = ''
            self.forks = ''
            self.become = ''
            self.become_method = ''
            self.become_user = ''
            self.check = ''
            self.diff = ''
            self.syntax = ''

    action = ActionModule(None, FakeSource(), FakeOptions())

    class FakeConnection:
        def __init__(self):
            self._shell = None
            self.become_user = 'user'
            self.become_password = 'password'
            self.become

# Generated at 2022-06-11 12:16:30.634504
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    module = ActionModule("reboot", "path/to/reboot.yml", "task", {"action": "reboot", "shutdown_command": "/sbin/reboot"}, [{"facts": "ansible_distribution"}])
    if isinstance(module.get_shutdown_command({}, "Test"), str):
        assert True

# Generated at 2022-06-11 12:16:40.981409
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import sys
    import unittest

    try:
        from __main__ import display
    except ImportError:
        display = None

    class Display(object):
        def __init__(self):
            self.display_data = []

        def warning(self, msg):
            self.display_data.append(msg)

        def debug(self, msg):
            self.display_data.append(msg)

        def vvv(self, msg):
            self.display_data.append(msg)

    class Task(object):
        def __init__(self):
            self.args = {'test_command': 'foo'}

    class Connection(object):
        def __init__(self):
            self.transport = 'local'

        def set_option(self, option, value):
            self

# Generated at 2022-06-11 12:16:43.762155
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict()
    action = ActionModule('test')
    assert action.run(task_vars=task_vars) == {}

# Generated at 2022-06-11 12:16:54.437840
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    self_obj = ActionModule(task=MagicMock(), connection=MagicMock(), play_context=MagicMock(), loader=MagicMock(), templar=MagicMock(), shared_loader_obj=None)
    self_obj._task = MagicMock()
    self_obj._task.action = 'reboot'
    self_obj._task.action = 'reboot'
    self_obj._task.args = dict()
    self_obj._task.action = 'reboot'

    # DEPRECATED_ARGS = {'connect_timeout': '2.2'}
    self_obj.DEPRECATED_ARGS = {'connect_timeout': '2.2'}
    self_obj._task.args = {'connect_timeout': None}
    self_obj._task.action = 'reboot'
    self

# Generated at 2022-06-11 12:17:05.079959
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Define task_vars used in get_shutdown_command
    task_vars = {}

    # Define distribution used in get_shutdown_command
    distribution = 'DEFAULT'

    # Define ansible_fact_distribution used in get_shutdown_command
    ansible_facts = {'distribution': 'DEFAULT', 'distribution_release': '1.0.0'}

    # Create a dictionary that contains the parameters for the test
    args = {'ansible_facts': ansible_facts, 'distribution': distribution, 'task_vars': task_vars}
    # Call the test method, passing the parameters
    result = ActionModule._get_shutdown_command(**args)

    assert result == 'shutdown', 'Expected result to equal shutdown, got "{0}"'.format(result)

#

# Generated at 2022-06-11 12:18:09.839566
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    """Test if do_until_success_or_timeout returns correct value"""
    from ansible.modules.system.seboolean import boolean
    from ansible import errors
    import time
    import datetime
    from datetime import timedelta
    import random
    import pytest
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-11 12:18:17.298223
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module = ActionModule()
    action_module._task = Mock()

    # test with invalid fact
    action_module._task.args = {'distribution': 'invalid'}
    mock_task_vars = {'ansible_facts': {'distribution': 'ansible'}}
    result = action_module.get_distribution(mock_task_vars)
    assert result == 'ansible'

    # test with valid fact
    action_module._task.args = {'distribution': 'ubuntu'}
    mock_task_vars = {'ansible_facts': {'distribution': 'ansible', 'distribution_release': '16.04'}}
    result = action_module.get_distribution(mock_task_vars)
    assert result == 'ubuntu'

    # test with fall

# Generated at 2022-06-11 12:18:22.618490
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    the_action = ActionModule()
    the_action._task = Task()
    the_action._task.action = 'reboot test action'
    the_action.DEPRECATED_ARGS = {'arg1': '1.0'}
    the_action._task.args = {'arg2': '2'}
    the_action.deprecated_args()


# Generated at 2022-06-11 12:18:33.387604
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    action_module = AnsibleModule(
        argument_spec={
            'reboot_timeout': {'type': 'int'}
        },
        supports_check_mode=True,
        supports_async=True,
    )

    action_module.action = 'reboot'
    action_module.set_options_incrementals({'connection': 'paramiko'})
    action_module._load_params()

    # Connection plugin
    connection = _create_connection(action_module, action_module._task.args['connection'])
    connection.connect()
    connection._shell = _create_mock_shell()

    # System facts plugin
    # pylint: disable=protected-access
    action_module._shared_loader_obj = FakeAnsibleModuleLoader()
    # pylint: enable=protected-access


# Generated at 2022-06-11 12:18:43.333190
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup mock objects
    class MockConnection(object):
        def __init__(self, **kwargs):
            pass
        def reset(self):
            pass
        def set_option(self, option, value):
            pass
        def get_option(self, option):
            pass
    class MockAnsibleModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
        def run_command(self, cmd):
            pass
        def run_command_environ_update(self, **kwargs):
            pass
    class MockAnsibleTask(object):
        def __init__(self, **kwargs):
            self.args = kwargs
            self.action = 'reboot'

# Generated at 2022-06-11 12:18:52.820485
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    module_args = dict(
        reboot_timeout=sit.DEFAULT_REBOOT_TIMEOUT,
        test_command=sit.DEFAULT_TEST_COMMAND
    )
    action_mock = ActionModule(dict(action='reboot', module_args=module_args))
    setattr(action_mock._task, 'environment', dict())
    setattr(action_mock._task, 'args', dict())

    reboot_command_mock = sit.mock_patch_object(ansible_module.ActionModule, 'get_reboot_command', return_value='/sbin/reboot')
    reboot_command_args_mock = sit.mock_patch_object(ansible_module.ActionModule, 'get_reboot_command_args')
    distribution_mock = sit.mock_

# Generated at 2022-06-11 12:18:53.467620
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:19:03.675083
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    import subprocess
    import tempfile

    class MockConnection(Connection):
        def __init__(self, *args, **kwargs):
            super(MockConnection, self).__init__(*args, **kwargs)
            self._options = {}

        def reset(self):
            pass

        def set_option(self, name, value):
            self._options[name] = value

        def get_option(self, name):
            try:
                return self._options[name]
            except KeyError:
                raise KeyError(name)

    def Mock_run_test_command(self, distribution, **kwargs):
        return True

    def Mock_check_boot_time(self, distribution, previous_boot_time):
        return True


# Generated at 2022-06-11 12:19:11.956436
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    host = 'localhost'
    port = 22
    user = 'root'
    passwd = 'root'
    transport = 'smart'
    connection = Connection(host, port, user, passwd, transport)

    # test method ActionModule.check_boot_time()
    action_module = ActionModule(None, action='reboot', connection=connection, play_context=PlayContext())
    distribution = action_module.get_distribution()
    previous_boot_time = action_module.get_system_boot_time(distribution)
    action_module.check_boot_time(distribution, previous_boot_time)


# Generated at 2022-06-11 12:19:15.689007
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    # Arrange
    self_mock = ActionModule()
    self_mock.get_distribution(task_vars)
    # Act
    result = self_mock.get_shutdown_command_args(distribution)
    # Assert



# Generated at 2022-06-11 12:21:47.694737
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # Initialize test variables
    task_vars = {'ansible_distribution': 'TestLinux', 'ansible_distribution_major_version': '1'}
    # Initialize test fixtures
    t_ActionModule = ActionModule()
    t_ActionModule._task = FakeTask()
    # Run test 1
    result = t_ActionModule.get_distribution(task_vars)
    expected = 'TestLinux'
    assert result == expected


# Generated at 2022-06-11 12:21:55.120795
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    # Make sure that we are using the source for this function in the test
    # https://github.com/ansible/ansible/blob/v2.5.5/lib/ansible/plugins/action/reboot.py#L98
    from ansible.plugins.action import reboot

    # This should NOT be modified
    action_module = reboot.ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # define test function assignments
    test_distribution = None
    expected_value = '-r now'

    # call the function being tested
    actual_value = action_module.get_shutdown_command_args(test_distribution)

    # assert that there was no failure
    assert actual_value is not None
    # assert

# Generated at 2022-06-11 12:22:01.184143
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    am = ActionModule()
    am._task = AnsibleMock()
    am._task.args = {}
    am._task.action = 'test'
    am._task.ansible_distribution = 'Ubuntu'
    am._task.ansible_distribution_version = '15.10'
    am._get_value_from_facts = MagicMock(return_value="Ubuntu")

    task_vars = {}
    with pytest.raises(AnsibleError):
        am.get_distribution(task_vars)


# Generated at 2022-06-11 12:22:08.436715
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # Test function name
    this_function_name = sys._getframe().f_code.co_name
    print("\n*** Test: {function_name} ***".format(function_name=this_function_name))

    # Declare function input
    class FakeTask(object):
        def __init__(self):
            self.action = 'reboot'
    task = FakeTask()

    class FakeModuleArgs(object):
        def __init__(self):
            self.distribution = None
            self.reboot_timeout = None
            self.connect_timeout = None
            self.test_command = None
            self.shutdown_timeout = None
            self.post_reboot_delay = None
            self.connect_timeout_sec = None
            self.reboot_timeout_sec = None
            self.shutdown

# Generated at 2022-06-11 12:22:09.276306
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False



# Generated at 2022-06-11 12:22:19.675126
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    from ansible.executor import task_result
    from ansible.executor.task_result import TaskResult
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.plugins.action import ActionBase
    import sys
    import unittest

    class MockTaskResult(TaskResult):
        def __init__(self, **kwargs):
            self.options = {}
            self.succeeded = False
            self.skipped = False
            self.failed = False
            self.unreachable = False
            self.changed = False
            self.ansible_facts = {}
            self.task_ignore_errors = False
            self.exception = kw

# Generated at 2022-06-11 12:22:21.979952
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action_module = ActionModule(dict(ANSIBLE_MODULE_ARGS=dict(foo='bar')))
    action_module.deprecated_args()



# Generated at 2022-06-11 12:22:29.535186
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    # test_ActionModule_get_shutdown_command_args() : Test the ActionModule.get_shutdown_command_args() method

    # Setup test data
    test_data = {}
    test_data['distribution'] = 'test_distribution'

    # test_ActionModule_get_shutdown_command_args() : Verify that calling ActionModule.get_shutdown_command_args() with proper arguments,
    # returns expected result.
    test_result = get_shutdown_command_args(test_data['distribution'])
    assert test_result == args

    # test_ActionModule_get_shutdown_command_args() : Verify that calling ActionModule.get_shutdown_command_args() with improper arguments,
    # raises expected exception.
    test_exception = None

# Generated at 2022-06-11 12:22:37.911997
# Unit test for method run of class ActionModule
def test_ActionModule_run():
   """test_ActionModule_run"""
   values = {}
   values['tmp'] = None
   values['task_vars'] = None

   task = AnsibleTask()
   values['_task'] = task
   connection = AnsibleConnection('', '')
   values['_connection'] = connection

   module = ActionModule()
   module.__dict__.update(values)

   # 1st test
   result = module.run()
   assert  result == {'changed': False, 'elapsed': 0, 'rebooted': False, 'failed': True, 'msg': 'Running reboot with local connection would reboot the control node.'}

   # 2nd test
   result = module.run(tmp='tmp')

# Generated at 2022-06-11 12:22:47.104935
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    """
    check_boot_time()
    """
    # Test with a valid previous_boot_time and a failed command
    _instance = ActionModule()
    _instance.get_system_boot_time = MagicMock(return_value='')
    _instance._low_level_execute_command = MagicMock(
        return_value={
            'rc': 1,
            'stdout': '',
            'stderr': ''
        }
    )

    distribution = 'RedHat'
    previous_boot_time = '2017-12-20'

    with pytest.raises(AnsibleError):
        _instance.check_boot_time(
            distribution,
            previous_boot_time
        )
