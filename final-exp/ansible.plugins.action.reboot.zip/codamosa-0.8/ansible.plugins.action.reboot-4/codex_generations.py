

# Generated at 2022-06-11 12:14:17.262098
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():

    # Arrange
    self = ActionModule()
    self._task = mock.MagicMock()
    distribution = 'foo'
    expected_result = {'rc': 0, 'stdout': '', 'stderr': ''}
    self._low_level_execute_command = mock.MagicMock(return_value=expected_result)


    # Act
    self.run_test_command(distribution)


    # Assert
    self._low_level_execute_command.assert_called_once_with('foo')



# Generated at 2022-06-11 12:14:22.735521
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():

    my_runa = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert my_runa.get_shutdown_command_args('DEBIAN') == ' -r now'

# Generated at 2022-06-11 12:14:29.369943
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    module.run_command = MagicMock(return_value={
        'rc': 0,
        'stdout': '',
        'stderr': '',
    })

    my_module = ActionModule(module)

    # result
    expected = None
    actual = my_module.run_test_command()

    # cleanup
    if os.path.exists(test_path):
        shutil.rmtree(test_path)

    assert actual == expected


# Generated at 2022-06-11 12:14:41.210672
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Arrange
    module = AnsibleModule(
        argument_spec=dict(
            distribution=dict(type='str', required=False),
            shutdown_command=dict(type='str', required=False),
            search_paths=dict(type='list', required=False),
        ))

    # Mock dependencies
    # Arrange
    search_paths = ['/system/path', '/local/path']
    mock_task = MagicMock(spec_set=dict(args=dict(search_paths=search_paths)))
    # Act
    am = ActionModule(mock_task, dict())
    # Assert
    assert_that(am.get_shutdown_command(list(), 'redhat'), equal_to('/sbin/shutdown'))

# Generated at 2022-06-11 12:14:49.817312
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    # create instance of class ActionModule
    module = ActionModule()

    # get distribution, previous_boot_time
    task_vars = dict(ansible_distribution='DEFAULT')
    distribution = 'DEFAULT'
    original_connection_timeout = None
    action_kwargs = dict(previous_boot_time='DEFAULT')
    # run method
    result = module.validate_reboot(distribution, original_connection_timeout, action_kwargs)
    # compare result
    assert result == dict(failed=True)
    # get distribution, previous_boot_time
    task_vars = dict(ansible_distribution='DEFAULT')
    distribution = 'DEFAULT'
    original_connection_timeout = None
    action_kwargs = dict(previous_boot_time='DEFAULT')
    # run method
   

# Generated at 2022-06-11 12:14:56.148944
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # Initialize a ActionModule object with a mock connection object
    dist = 'Debian'
    boot_time = 'Tue May  1 00:00:00 2018\n'
    action_module = ActionModule(mock_config_factory(connection_factory(transport='local')))
    test_module_result = action_module.check_boot_time(dist, boot_time)
    # Validate results
    assert test_module_result is None


# Generated at 2022-06-11 12:15:07.381188
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Resetting task to its original state
    ansible_module.params = {}
    ansible_module.params['async'] = 0
    ansible_module.params['connect_timeout'] = None
    ansible_module.params['connect_timeout_sec'] = None
    ansible_module.params['msg'] = None
    ansible_module.params['non_posix_shell'] = False
    ansible_module.params['one_line'] = None
    ansible_module.params['output_file'] = None
    ansible_module.params['poll'] = 15
    ansible_module.params['post_reboot_delay'] = 0
    ansible_module.params['post_reboot_delay_sec'] = None
    ansible_module.params['prompt'] = None
    ansible_module.params

# Generated at 2022-06-11 12:15:09.175476
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    # ActionModule_deprecated_args() returns nothing
    return None

# Generated at 2022-06-11 12:15:19.366522
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import mock
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.mock.loader import DictDataLoader
    from ansible_collections.notstdlib.moveitallout.plugins.modules import reboot

    class TestActionModule(unittest.TestCase):
        def setUp(self):
            self._actionmodule = reboot.ActionModule(mock.Mock(), mock.Mock(), mock.Mock())


# Generated at 2022-06-11 12:15:29.130220
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    task_vars = dict()
    module_args = dict()
    system_info = dict()
    module_system_facts = dict()
    module_system_facts['distribution'] = 'RedHat'
    system_info['system_facts'] = module_system_facts
    task_vars['ansible_system_facts'] = system_info
    obj = ActionModule(task_vars, module_args, 'ansible.builtin.reboot', 'reboot')
    obj._task = MagicMock()
    obj._task.action = 'reboot'
    obj._task.args = dict()
    obj._task.args['test_command'] = 'echo "test command" > /dev/null'
    obj._play_context = MagicMock()
    obj._play_context.deprecated = dict()
    obj

# Generated at 2022-06-11 12:16:09.776935
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    import datetime
    import random
    from ansible.module_utils.six import StringIO
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.action import ActionBase
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

# Generated at 2022-06-11 12:16:17.789979
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    am = ActionModule(None, None, 0)

    assert not am.do_until_success_or_timeout(action=lambda: 1, reboot_timeout=10, action_desc=None)

    assert am.do_until_success_or_timeout(action=lambda: 1, reboot_timeout=10, action_desc=None, action_kwargs={'previous_boot_time': '2018-10-23'})

    assert am.do_until_success_or_timeout(action=lambda: '2018-10-24', reboot_timeout=10, action_desc=None, action_kwargs={'previous_boot_time': '2018-10-23'})

# Generated at 2022-06-11 12:16:28.660791
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    hostname = 'myhost'
    connection = 'smart'
    port = 22
    remote_user = 'myusername'
    remote_pass = None
    private_key_file = None
    private_key_pass = None
    timeout = 10

    # set up a connection
    connection_info = {
        'host': hostname,
        'port': port,
        'username': remote_user,
        'password': remote_pass,
        'private_key_file': private_key_file,
        'private_key_pass': private_key_pass,
        'timeout': timeout,
        'transport': connection
    }

    # create task with action=reboot and valid args
    task = AnsibleTask(action='reboot', allow_extras=True)

# Generated at 2022-06-11 12:16:39.047531
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up mock objects
    from ansible.module_utils.common.collections import ImmutableDict
    task_vars = {'ansible_facts': {'distribution': 'Ubuntu',
                                   'shutdown_command': '/sbin/shutdown'}}
    self = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    self._connection = Mock()
    self._connection.transport = 'ssh'
    self._task = Mock()
    self._task.action = 'reboot'
    self._task.args = {'connect_timeout': 1}
    self._task.async_val = None
    self._task.notify = None
    self._task.loop = None
    self._task.loop_

# Generated at 2022-06-11 12:16:43.954439
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    a = ActionModule()
    a.do_until_success_or_timeout(action=lambda: None,
                                  action_desc="a",
                                  reboot_timeout=0,
                                  distribution="d",
                                  action_kwargs={"a": 1})
# # Unit test for method get_distribution of class ActionModule

# Generated at 2022-06-11 12:16:45.018145
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    ...


# Generated at 2022-06-11 12:16:54.168537
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    test_main = AnsibleModule(argument_spec={})
    test_main._task_fields['action'] = 'test'
    test_main._task_fields['args'] = {}

    test_connection = Connection()
    test_connection.init_for_module(test_main)

    test_action = ActionModule(task=test_main, connection=test_connection)

    test_task_vars = {}

    test_result = test_action.get_distribution(test_task_vars)

    assert test_result == 'DEFAULT', 'Expected distribution to be "DEFAULT" instead got "{0}"'.format(test_result)


# Generated at 2022-06-11 12:17:04.778971
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # Get a ActionModule object for testing
    mock_basemodule = Mock()
    mock_task = Mock()
    mock_task.args = {}
    mock_task.action = 'reboot'
    mock_task.async_val = 0
    mock_task.loop = False
    mock_task.notify = []
    mock_task.register = ''
    mock_task.tags = []
    mock_task.until = []
    mock_task.run_once = False
    mock_task.when = []
    mock_task.working_dir = ''
    mock_basemodule._task = mock_task
    mock_basemodule._low_level_execute_command = Mock()
    mock_basemodule.DEFAULT_CONNECT_TIMEOUT = 20

# Generated at 2022-06-11 12:17:15.850453
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():

    # Mock the AnsibleModule object
    mock_AnsibleModule_obj = mock.create_autospec(AnsibleModule)
    mock_AnsibleModule_obj.params = {
        'reboot_timeout': 1,
        'connect_timeout': 1,
        'wait_for_reboot': 1,
        'post_reboot_delay': 1,
    }

    # Mock the AnsibleModule object.
    # Set the required ansible params as per the reboot module.
    # This is not required ansible will fail the task if these params are missing.
    mock_AnsibleModule_obj.params = {
        'reboot_timeout': 1,
        'connect_timeout': 1,
        'wait_for_reboot': 1,
        'post_reboot_delay': 1,
    }

    #

# Generated at 2022-06-11 12:17:25.315089
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    module = ActionModule()
    # Invalid Params
    # Failure Cases
    # unexpected-success-case
    # Success Cases
    # unknown-distribution-case
    distribution = 'unknown-distribution-case'
    original_connection_timeout = None
    action_kwargs = {}
    result = module.validate_reboot(distribution, original_connection_timeout, action_kwargs)
    assert result['rebooted'] == True
    assert result['failed'] == True
    assert result['msg'] == 'Timed out waiting for last boot time check (timeout=600)'
    # min-case
    distribution = 'min-case'
    original_connection_timeout = None
    action_kwargs = {'previous_boot_time': "1553937961"}

# Generated at 2022-06-11 12:18:25.788684
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # arrange
    action_module = ActionModule()
    params = {'reboot_timeout': '0'}
    task_vars = {'ansible_distribution': 'Linux',
                 'ansible_kernel': 'Linux'}

    # act

    # assert
    assert False, "Not implemented"


# Generated at 2022-06-11 12:18:26.963815
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass


# Generated at 2022-06-11 12:18:37.352707
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    action_module = ActionModule()
    action_module.ACTION_VERSION = '1.0'
    action_module.ACTION_SUPPORTS_CHECK_MODE = True
    action_module.ACTION_SUPPORTS_ASYNC = True
    action_module._supports_async = True
    action_module._supports_check_mode = True
    action_module._result = {}
    action_module._task = {}
    action_module._task.action = 'reboot'
    action_module.DEFAULT_TEST_COMMAND = 'whoami'
    action_module.DEFAULT_BOOT_TIME_COMMAND = 'whoami'
    action_module.DEFAULT_REBOOT_TIMEOUT = 120
    action_module.DEFAULT_CONNECT_TIMEOUT = 120
    action_module.DEFAULT_

# Generated at 2022-06-11 12:18:47.051991
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    action = ActionModule()
    action._task.action = 'reboot'
    action._task.args = {}
    empty = {}
    assert action.get_shutdown_command(empty, 'windows') == 'shutdown.exe'
    assert not action._task.args.get('shutdown_command')
    action._task.args = dict(shutdown_command='reboot')
    assert action.get_shutdown_command(empty, 'windows') == 'reboot'
    assert action._task.args.get('shutdown_command') == 'reboot'
    action._task.args = dict(shutdown_command='foo')
    assert action.get_shutdown_command(empty, 'windows') == 'foo'
    assert action._task.args.get('shutdown_command') == 'foo'
    action._task.args

# Generated at 2022-06-11 12:18:56.514353
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    args = {}
    my_obj = ActionModule(args)
    my_obj.do_until_success_or_timeout = mock.MagicMock()
    my_obj.run_test_command = mock.MagicMock()
    my_obj.validate_reboot = mock.MagicMock()
    my_obj.get_system_boot_time = mock.MagicMock()
    my_obj.get_shutdown_command = mock.MagicMock()
    my_obj.perform_reboot = mock.MagicMock()
    my_obj.check_boot_time = mock.MagicMock()
    my_obj.get_shutdown_command_args = mock.MagicMock()
    my_obj.get_distribution = mock.MagicMock()
    action_kwargs = {}
    my_obj

# Generated at 2022-06-11 12:19:07.048848
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # Test with empty info
    info = {}
    # Test with string boot_time_command
    boot_time_command = "date"
    # Test with valid boot_time_command
    boot_time_command = "uptime | awk '{print $(NF-2),$(NF-1),$(NF-0),$(NF+1)}'"
    # Test with boot_time_command that raises an exception
    boot_time_command = "nonexistentcmd"

    # Test with string distribution
    distribution = "ubuntu"
    # Test with lowercase distribution
    distribution = "centos"

    # Test with empty info
    info = {}
    # Test with valid info

# Generated at 2022-06-11 12:19:12.357018
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # Stub
    class StubConnection(object):
        def __init__(self, machine_distribution):
            self.machine_distribution = machine_distribution

        def get_option(self, *args, **kwargs):
            return {'remote_addr': '1.1.1.1', 'connection': 'network_cli'}.get(args[0])

        def set_options(self, *args, **kwargs):
            return

    # Stub
    class StubTask(object):
        def __init__(self):
            self.action = 'test_get_distribution'
            self.args = {}

    class StubPlayContext(object):
        def __init__(self):
            self.network_os = None
            self.remote_addr = '1.1.1.1'

# Generated at 2022-06-11 12:19:15.440449
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    print('Running test: test_ActionModule_deprecated_args')
    action_module = ActionModule()
    with pytest.deprecated_call():
        action_module.deprecated_args()


# Generated at 2022-06-11 12:19:21.407376
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    try:
        test_obj = ActionModule()
        result = test_obj.do_until_success_or_timeout(action=test_obj.check_boot_time, action_desc='last boot time check', reboot_timeout=60, distribution='test')
        return_value = result
    except Exception:
        traceback.print_exc()
        return_value = ('tbd','tbd')
    return (return_value, ('tbd','tbd'))


# Generated at 2022-06-11 12:19:22.401051
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    pass



# Generated at 2022-06-11 12:21:57.637736
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    class FakeTask:
        def __init__(self):
            self.action = 'test_action'
            self.args = {'shutdown_command': 'test_command_arg'}

    class FakePlayContext:
        def __init__(self):
            self.become = None
            self.become_user = None


    class FakeModule:
        def __init__(self):
            self.params = {'shutdown_command': 'test_module_arg'}

    class FakeModuleDeprecated:
        def __init__(self):
            self.params = {'shutdown_command_deprecated': 'test_module_arg'}

    class FakeConnection:
        def __init__(self):
            self.transport = 'test_connection'

    action_module = ActionModule()
    action_module

# Generated at 2022-06-11 12:22:05.280687
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action = {"name": "reboot", "action": "reboot"}
    task = {"vars": {}}
    task_vars = {}

    play_context = PlayContext()
    connection = MockConnection()

    r = ActionModule(connection, play_context, action, task, task_vars)

    #test with both old and new arguments
    args = {"test_command": "date", "connect_timeout": 2, "connect_timeout_sec": 3, "reboot_timeout": 5,
            "reboot_timeout_sec": 7, "pre_reboot_delay": 9, "post_reboot_delay": 11, "msg": "", "rebooted": "", "rc": 0}

    result = r.deprecated_args(args)
    assert result is None

    #test with old arguments only
    del args

# Generated at 2022-06-11 12:22:08.792066
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    action_module = ActionModule()
    # verify test fails if timeout is reached before boot time is refreshed
    with pytest.raises(TimedOutException):
        action_module.validate_reboot('distribution', original_connection_timeout=None, action_kwargs={'previous_boot_time': 'previous_boot_time'})

# Generated at 2022-06-11 12:22:11.389667
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    t_ansible_module_reboot = ActionModule()
    t_ansible_module_reboot.do_until_success_or_timeout(None, 12, None, None)


# Generated at 2022-06-11 12:22:16.226467
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    module = ActionModule()
    module._low_level_execute_command = mock.MagicMock(side_effect=[{'rc':0,'stdout':'','stderr':''}])
    assert module.run_test_command(distribution='mock_dist') is None


# Generated at 2022-06-11 12:22:25.035856
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Given
    connection = create_autospec(connection_loader.get('network_cli', class_only=True))
    action_module = create_autospec(ActionModule)
    action_module._low_level_execute_command = Mock(return_value={'rc': 0, 'stdout': '', 'stderr': ''})
    task_vars = {}
    action_module.perform_reboot = Mock(return_value={'failed': False, 'start': datetime.utcnow()})

    def get_system_boot_time(distribution):
        return '12:34:56'

    action_module.get_system_boot_time = Mock(side_effect=get_system_boot_time)

    def check_boot_time(distribution, action_kwargs):
        raise ValueError()

# Generated at 2022-06-11 12:22:32.852557
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    class MockActionModule(object):
        def __init__(self, *args):
            self._task = task()
            self._task.action = 'debug'
        def _low_level_execute_command(self):
            return get_output_result(3, "", "", "", "")
        def _get_value_from_facts(self, *args):
            return ""
    module = MockActionModule()
    task_vars = {}
    module._play_context = play_context
    module._play_context.check_mode = True
    module._connection = connection()
    module._connection.transport = 'local'
    distribution = 'centos-7'
    result = module.validate_reboot(distribution)
    assert result['failed'] == True
    assert result['rebooted'] == False


# Generated at 2022-06-11 12:22:41.094227
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    # create an instance of the class to be tested
    class_to_test = ActionModule()
    # create an instance of the arguments used
    class_to_test._task = task = None
    # set the instance attributes of the object
    class_to_test._task = mock.MagicMock()
    class_to_test._task.args = {'test': 'test'}

    class_to_test.DEPRECATED_ARGS = {
        'test': 'test'
    }

    # attempt to run the code to be tested
    try:
        class_to_test.deprecated_args()
    # validate the results
    except AnsibleError as e:
        assert(False)
    # validate the results
    else:
        assert(True)


# Generated at 2022-06-11 12:22:46.100444
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module = ActionModule()
    task_vars = {
        'ansible_facts': {
            'distribution': 'FooBarLinux'
        }
    }
    action_module._task = {
        'args': {}
    }
    result = action_module.get_distribution(task_vars)
    assert result == 'FooBarLinux'



# Generated at 2022-06-11 12:22:52.094539
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    distribution = 'default'
    task = DummyAnsibleTask()
    task.action = 'reboot'
    task.args = {'boot_time_command': 'uptime'}
    action_mod = ActionModule(task, fake_connection)
    assert action_mod.get_system_boot_time(distribution) == '07:07:58 up 168 days, 22:28,  1 user,  load average: 0.02, 0.02, 0.02'
