

# Generated at 2022-06-11 12:14:20.962445
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Test a simple, but invalid command
    def test_perform_reboot_command_fail():
        module_mock = init_module_mock()
        module_mock['module_utils.basic._ansible_module_common'].AnsibleModule.return_value.check_mode = False

        # Set up expected parameters and results
        distribution = 'Ubuntu'
        shutdown_command = 'shutdown'
        reboot_command = 'shutdown -r now'

        task_vars_mock = { 'ansible_distribution': distribution }

        expected_result = { 'start': datetime(2016, 1, 1), 'failed': True, 'rebooted': False,
                            'msg': "Reboot command failed. Error was: 'invalid command, '" }

        # Initialize the mock objects
        connection_

# Generated at 2022-06-11 12:14:24.736124
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    self_action = ActionModule()
    assert self_action._task.action == 'reboot'

    self_action._task.args = dict(sleep_timeout=1)
    
    self_action._task.args = dict(sleep_timeout=2)

# Generated at 2022-06-11 12:14:35.062523
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test case
    result = {}
    result['skipped'] = False
    result['failed'] = False
    # test case

    # test case
    if result.get('skipped', False) or result.get('failed', False):
        return result
    # test case
    
    # test case
    result = {}
    result['skipped'] = False
    result['failed'] = False
    # test case

    tmp = {}
    task_vars = {}

    # test case
    result = {}
    result['skipped'] = False
    result['failed'] = True
    result['msg'] = 'Running reboot with local connection would reboot the control node.'
    # test case

    # test case
    result = {}
    result['skipped'] = False
    result['failed'] = False
    # test case

    #

# Generated at 2022-06-11 12:14:45.968464
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    print("========== test ActionModule_get_shutdown_command ===========")
    task_vars = {}
    hostvars = {}
    self = ActionModule(task_vars, hostvars)
    #result = self.get_shutdown_command(task_vars, distribution)
    #result = self._get_value_from_facts('SHUTDOWN_COMMANDS', 'Debian', 'DEFAULT_SHUTDOWN_COMMAND')
    result = self._low_level_execute_command('ls', sudoable=self.DEFAULT_SUDOABLE)
    print(result)
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

# Generated at 2022-06-11 12:14:52.561649
# Unit test for method validate_reboot of class ActionModule

# Generated at 2022-06-11 12:15:03.782076
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():

    # setup mock data
    distribution=None
    previous_boot_time=None

    # setup expected result data
    expected_check_boot_time_result=None

    # initialize mocks - need to mock their return values in order to check the input parameters
    m_self=MagicMock(spec=ActionModule)
    m_get_system_boot_time=MagicMock(return_value='expected_get_system_boot_time_result')

    # setup mocks
    m_self.get_system_boot_time=m_get_system_boot_time

    # execute tested method
    check_boot_time_result=ActionModule.check_boot_time(m_self, distribution, previous_boot_time)

    # verify results
    assert check_boot_time_result==expected_check_boot_time_result

   

# Generated at 2022-06-11 12:15:14.971083
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    from ansible.module_utils.common.sys_info import get_distribution, get_distribution_version, get_system_capabilities, get_platform_subclass

    # instantiate the class with the required object
    mock_task = MagicMock()
    mock_connection = MagicMock()
    module = ActionModule(mock_task, mock_connection)

    # get required kwargs, and some extras for future testing
    kwargs = {
        'distribution': 'CentOS',
        'original_connection_timeout': 1,
        'action_kwargs': {
            'previous_boot_time': '2017-09-06 10:10:45 UTC'
        }
    }
    # test the method

# Generated at 2022-06-11 12:15:16.013596
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    pass


# Generated at 2022-06-11 12:15:22.239727
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    import copy
    import collections

    result = collections.namedtuple('result', ['stdout', 'stderr', 'rc'])
    cmd = 'whoami'
    sudoable = True
    expected = {
        'stdout': 'root',
        'stderr': '',
        'rc': 0
    }

    am = ActionModule()
    am.run_test_command(cmd, sudoable)

    assert am._task.args.get('test_command') == cmd
    assert am._task.args.get('reboot_timeout') == 120.0
    assert am._task.args.get('msg') == 'system successfully rebooted'


# Generated at 2022-06-11 12:15:23.497305
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
  pass


# Generated at 2022-06-11 12:15:55.628268
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    pass

# Generated at 2022-06-11 12:16:07.311138
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    cmd_line = (
        'ansible-playbook '
        'reboot.yml --vault-id @prompt '
        '--check --diff --hosts=localhost, '
        '--diff-filter=many-contexts '
        '--start-at-task=reboot_system '
        '--step --sudo --sudo-user=root --become --ask-become-pass --ask-vault-pass --tags=reboot '
        '--skip-tags=network,security '
        '--syntax-check --list-tasks --list-tags --list-hosts '
    )

# Generated at 2022-06-11 12:16:08.092683
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    pass

# Generated at 2022-06-11 12:16:14.026610
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    action_module = ActionModule()
    class args(object):
        def __init__(self):
            self.reboot_timeout=600
    action_module._task.args = args()
    result = action_module.validate_reboot('distribution')
    
    assert result['failed'] == True
    assert result['rebooted'] == True
    assert result['msg'] == 'Timed out waiting for last boot time check (timeout=600)'

# Generated at 2022-06-11 12:16:14.836270
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    pass # TODO


# Generated at 2022-06-11 12:16:17.279550
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("test_ActionModule_run():")
    # action_module = create_instance_of(ActionModule())
    # action_module.run()
    print("Error: test_ActionModule_run not implemented")

# Generated at 2022-06-11 12:16:20.619414
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    am = ActionModule()
    test_distribution = 'test_distribution'
    task_vars = {}
    am.get_shutdown_command(task_vars, test_distribution)


# Generated at 2022-06-11 12:16:31.852985
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # create the module
    action_module = ActionModule()

    # create a fake module to pass to the module
    fake_module = FakeModule()

    # create a fake connection plugin to pass to the module
    class FakeConnection(AnsibleConnectionBase):
        def __init__(self, module):
            self.module = module
            self.has_pipelining = False

        def get_option(self, option):
            if option == 'connection_timeout':
                return self.module._connection._connection.get_option(option)
            else:
                raise KeyError(option)

        def set_option(self, option, value):
            if option == 'connection_timeout':
                self.module._connection._connection.set_option(option, value)
            else:
                raise KeyError(option)


# Generated at 2022-06-11 12:16:42.248815
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    # Setup and mock out necessary bits
    mock_ansible_module = MagicMock(name='ansible_module')
    mock_ansible_module.run_command.return_value = 0, '2018-08-13 10:45:27', ''
    mock_ansible_module.params = {}
    mock_ansible_module.check_mode = False
    mock_ansible_module.no_log = False
    task_vars = {}
    distribution = ''
    action_module = ActionModule(mock_ansible_module, task_vars=task_vars, distribution=distribution)

    # Execute the code to be tested
    result = action_module.get_system_boot_time(distribution)

    # Check the result
    assert result == '2018-08-13 10:45:27'



# Generated at 2022-06-11 12:16:53.119625
# Unit test for method get_system_boot_time of class ActionModule

# Generated at 2022-06-11 12:18:02.161857
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    hostname = 'hostname'
    distro = 'distro'
    reboot_timeout = 10
    test_command = 'echo "hello"'
    class AnsibleError:
        def __init__(self, message):
            self.message = message
    class AnsibleConnectionFailure:
        def __init__(self, message):
            self.message = message
    class TimedOutException:
        def __init__(self, message):
            self.message = message
    
    def test_command_success():
        return {'rc': 0}
    def test_command_fail():
        raise Exception("test command failed")


# Generated at 2022-06-11 12:18:03.229338
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    pass


# Generated at 2022-06-11 12:18:04.519427
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    pass #TODO


# Generated at 2022-06-11 12:18:14.106214
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.playbook.play_context import PlayContext

    class Controller:
        def __init__(self):
            self.connection = None

    class ActionModuleUnderTest(ActionModule):
        def do_until_success_or_timeout(self, action, action_desc, reboot_timeout, distribution, action_kwargs=None):
            if action_kwargs is None:
                action_kwargs = {}
            action(distribution=distribution, **action_kwargs)
            return

    class AnsibleModuleMock:
        def __init__(self, params):
            self.params = params

        def fail_json(self, msg, **kwargs):
            raise ValueError(msg)

        def exit_json(self, **kwargs):
            return k

# Generated at 2022-06-11 12:18:24.666457
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    """
    Test deprecated_args method of class ActionModule
    """
    # Setup
    module_name = 'reboot'
    task_name = 'reboot'

# Generated at 2022-06-11 12:18:34.916552
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():

    # Create an instance of the class
    obj = ActionModule()

    # Create a mock of class 'AnsibleConnection'
    mock_ansibleconnection = MagicMock()
    type(mock_ansibleconnection).set_option = Mock()
    type(mock_ansibleconnection).reset = Mock()
    type(mock_ansibleconnection).get_option = Mock(return_value=1)

    # Set the attributes of the instance
    obj._task = mock_ansibleconnection
    obj._connection = mock_ansibleconnection

    action = mock_ansibleconnection
    action_desc = "last boot time check"
    reboot_timeout = 20
    distribution = mock_ansibleconnection
    action_kwargs = {}

    # Test

# Generated at 2022-06-11 12:18:35.754014
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    pass

# Generated at 2022-06-11 12:18:36.513020
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:18:44.789775
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # default action_plugin
    module = AnsibleModule(argument_spec={})
    task = Task(action=dict(name = 'reboot', action = 'reboot'))

    import connection_loader
    plugin = connection_loader.get('reboot', task, False)
    plugin._task = task

    # Some test data
    task_vars = dict()
    tmp = 'tmp'
    result = plugin.run(tmp, task_vars)
    assert isinstance(result, dict)
    assert 'rebooted' in result
    assert 'msg' in result
    assert 'changed' in result
    assert 'failed' in result
    assert 'elapsed' in result

# Generated at 2022-06-11 12:18:46.283464
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass # We don't test Ansible Modules

 

# Generated at 2022-06-11 12:20:49.183775
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module = ActionModule(dict(ANSIBLE_MODULE_ARGS={}, ANSIBLE_MODULE_CONSTANTS={}), None)
    mock_task = DummyTask()
    action_module._task = mock_task
    action_module.get_distribution(None)
    assert mock_task.called_get_distribution


# Generated at 2022-06-11 12:20:53.458242
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    # Set up mock objects
    self = ActionModule()
    self._task = Mock()
    self._task.action = "reboot"
    self._task.args = {
        'use_reboot': True
    }
    self.DEPRECATED_ARGS = {
        'use_reboot': '2.11'
    }
    display = Mock()
    display._display_warn = Mock()

    # Call method
    self.deprecated_args()

    # Check results
    assert display._display_warn.call_count == 1
    assert display._display_warn.call_args[0][0] == "Since Ansible 2.11, use_reboot is no longer a valid option for reboot"


# Generated at 2022-06-11 12:20:58.055027
# Unit test for method deprecated_args of class ActionModule

# Generated at 2022-06-11 12:21:02.598199
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # create in-memory AnsibleOptions object
    ansible_options = AnsibleOptions()
    ansible_options.verbosity = 4

    # play context
    play_context = PlayContext()
    play_context.verbosity = 4

    # mock connection
    conn_mock = MockConnection(play_context, ansible_options)

    # mock module
    module_mock = MockModule(conn_mock, play_context, ansible_options)

    # create the class
    action_module = ActionModule(module_mock)

    # run the test
    result_msg = ''
    result = action_module.do_until_success_or_timeout(
        action=ActionModuleTest.action,
        action_desc="action_desc",
        reboot_timeout=60,
        distribution='distribution',
    )


# Generated at 2022-06-11 12:21:07.263691
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():

    import action_plugins.modules.systemd_host_reboot
    from ansible.module_utils.common.network import NetworkError
    from ansible.module_utils.connection import Connection, ConnectionError
    from ansible.errors import AnsibleError
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    # default action_module_kwargs and related definitions
    # parameters passed to the module by module_executor
    # and mutable action_module_kwargs

# Generated at 2022-06-11 12:21:08.270734
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = AnsibleActionModuleReboot()
    assert(action_module.run() == "foo")

# Generated at 2022-06-11 12:21:13.125219
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    _connection = MagicMock()
    _task = MagicMock()
    _task.action = 'reboot'
    _task.args = {}
    _task.args['reboot_timeout'] = 60
    _task.args['reboot_timeout_sec'] = 60
    _play_context = MagicMock()
    _play_context.check_mode = True
    _play_context.remote_addr = 'faux'
    _loader = None
    _templar = None
    _shared_loader_obj = None
    _ansible = None
    _handle = MagicMock()
    _handle.name = '_handle'
    _handle.name = '_handle'

# Generated at 2022-06-11 12:21:15.034878
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    with patch('ansible_collections.notmintest.not_a_real_collection.plugins.modules.os_reboot.ActionModule.perform_reboot') as mock_action:
        result = mock_action()
        assert result['changed']


# Generated at 2022-06-11 12:21:17.983048
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule()
    mod.set_options({'test_option': 'test_value'})
    mod._task.action='test_name'
    result = mod.run()

    assert(result == {'changed': False, 'elapsed': 0, 'rebooted': False, 'failed': True, 'msg': 'Running test_name with local connection would reboot the control node.'})


# Generated at 2022-06-11 12:21:27.345929
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    task = MagicMock()
    connection = MagicMock()
    play_context = MagicMock()
    obj = ActionModule(task, connection, play_context)
    command_path = (obj.DEFAULT_SHUTDOWN_COMMAND.split(' ', 1)[0])
    if 'shutdown' in command_path:
        command_path = 'which ' + command_path
    else:
        command_path = 'which ' + 'shutdown'
    obj._low_level_execute_command = MagicMock(return_value={'stdout': command_path, 'stderr': '', 'rc': 0, 'start': '', 'end': '', 'delta': '', 'cmd': command_path})
    assert obj.get_shutdown_command({}, 'ubuntu') == command_path.split()[1]