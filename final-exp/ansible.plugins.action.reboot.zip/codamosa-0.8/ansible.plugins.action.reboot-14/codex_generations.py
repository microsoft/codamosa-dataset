

# Generated at 2022-06-11 12:14:22.576944
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    (action_module, tmp_path) = setup_test_ActionModule()

    # run_test_command
    # Input: None, distribution: str, rc: int, stdout: str, stderr: str
    # Output: RuntimeError
    #
    # Here, a test command is being simulated which will run successfully. The
    # mocked command is a success if the test command is being executed.
    action_module._low_level_execute_command = mock.MagicMock(return_value={'rc': 0})
    action_module.run_test_command(distribution='CentOS')
    action_module._low_level_execute_command.assert_called_once()

    # Input: None, distribution: str, rc: int, stdout: str, stderr: str
    # Output: RuntimeError
    #
    #

# Generated at 2022-06-11 12:14:30.139887
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    from ansible.module_utils.basic import AnsibleModule
    import ansible.modules.system.reboot as reboot
    module = reboot

# Generated at 2022-06-11 12:14:41.742948
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    from ansible.module_utils.six.moves import shlex_quote

    action_module = ActionModule(None)
    test_command = 'true'
    test_command_result = {"cmd": test_command, "rc": 0, "stdout": "", "stderr": "", "stdout_lines": [], "stderr_lines": []}

    with patch('ansible.module_utils.basic._ANSIBLE_ARGS', new_callable=dict):
        with patch('ansible.plugins.action.command.ActionModule.run_command') as mock_run_command:
            mock_run_command.return_value = test_command_result
            action_module.run_test_command('Linux', test_command=test_command)

# Generated at 2022-06-11 12:14:46.753912
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    module = ActionModule(
        argument_spec=dict(
            path=dict(type='list', elements='path', elements_type='str'),
            pattern=dict(type='str'),
            file_type=dict(type='str')
        ),
    )
    # Set up mock
    path = 'path'
    pattern = 'pattern'
    file_type = 'file_type'
    # Execute the script
    result = module.deprecated_args()
    # Verify the results
    assert(result == None)

# Generated at 2022-06-11 12:14:56.684853
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    task_vars = dict(ansible_facts=dict(distribution='FreeBSD'))

    # Initialize class and call method to test
    am = ActionModule(task=dict(args=dict(paths=["/etc/freenas-release", "/etc/version"],
                                          patterns=['FreeNAS'],
                                          file_type='file')),
                      connection=dict(),
                      play_context=dict(),
                      loader=dict(),
                      templar=dict(),
                      shared_loader_obj=dict())
    boot_time_command = am.get_system_boot_time(distribution=task_vars)
    assert boot_time_command == 'sysctl kern.boottime | awk \'{print $4}\' | cut -d, -f1'

# Generated at 2022-06-11 12:15:05.367679
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
	dest = 'foo'

	# Build MockModule
	module = MockModule()
	module.params = {
		'secret_token': 'foo'
	}
	module.DROPBOT_API_URL = 'https://api.dropbot.xyz/v0'

	# Create a MockConnection
	conn = MockConnection()

	# Build Plugin
	plugin = ActionModule.load_plugin(conn, module)
	plugin.initialize(module)
	plugin.run_test_command(dest)

	# if we get here without an exception, we are good.
	assert True is True

# Generated at 2022-06-11 12:15:09.671274
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    host = {"ansible_system":"RedHat"}
    action_module = ActionModule()
    action_module._task.args.update({ "delayed":"yes" })
    assert action_module.get_shutdown_command_args(host) == "now"

# Generated at 2022-06-11 12:15:19.761334
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Arrange
    from ansible.modules.system import reboot
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.network import add_argument, ModuleStub
    from ansible.module_utils._text import to_text
    from ansible.errors import AnsibleError
    import datetime
    import mock
    import pytest

    def _make_mock_connection():
        connection = mock.MagicMock()
        connection.get_option.return_value = None
        return connection

    _mock_connection = _make_mock_connection()


# Generated at 2022-06-11 12:15:24.232418
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    task = Task()
    connection = Connection(play_context=PlayContext())
    action_module = ActionModule(task=task, connection=connection)
    action_module.do_until_success_or_timeout(action=action_module.run_test_command, distribution='Linux', reboot_timeout=10, action_desc='test')


# Generated at 2022-06-11 12:15:29.714072
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # Create an object of class ActionModule
    obj = my_object()
    # Create a dummy distribution parameter
    distribution = "dummy"
    # Create a previous_boot_time paramter
    previous_boot_time = "dummy"
    # Run the check_boot_time method of the object
    obj.check_boot_time(distribution, previous_boot_time)


# Generated at 2022-06-11 12:16:41.257036
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_name = 'reboot'
    name = 'local'
    tmp = '/tmp'
    distribution = 'CentOS Linux'
    task_vars = None
    class MockReturn:
        stdout = ''

    class MockConnection:
        def __init__(self, return_value, transport=''):
            self.return_value = return_value
            self.transport = transport
        def set_option(self, option, value):
            pass
        def get_option(self, option):
            pass
        def reset(self):
            pass

    class MockActionModule:
        def get_distribution(self, task_vars):
            return distribution
        def get_shutdown_command(self, task_vars, distribution):
            if distribution == 'CentOS Linux':
                return '/sbin/shutdown'

# Generated at 2022-06-11 12:16:50.639976
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    with pytest.raises(AnsibleError) as error:
        from ansible.plugins.action.reboot import ActionModule
        action_module = ActionModule()
        action_module.DEPRECATED_ARGS = {
            'reboot_timeout': '2.0',
            'shutdown_timeout': '2.0',
        }
        action_module._task = Mock()
        action_module._task.args = {
            'shutdown_timeout': 10,
        }
        action_module.deprecated_args()
    assert "Deprecated option 'shutdown_timeout', use 'reboot_timeout_sec' instead" == str(error.value)


# Generated at 2022-06-11 12:17:00.441024
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # Arrange
    task_vars = {
        'ansible_facts': {
            'ansible_distribution': 'RedHat'
        },
        'ansible_check_mode': False
    }
    self = _createActionModule(task_vars)

    # Action
    try:
        result = self.do_until_success_or_timeout(action=self.check_boot_time, action_desc="last boot time check", reboot_timeout=30, distribution='RedHat', action_kwargs={'previous_boot_time': 'Tue 2018-05-01 01:58:08 CST'})
    except TimedOutException as toex:
        result = False

    # Assert
    assert result



# Generated at 2022-06-11 12:17:09.868046
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action_module = ActionModule('task', {'action': 'reboot'}, 'local')
    action_module.DEPRECATED_ARGS = {'reboot_poll': '2.9.0'}

    display = Display()
    display.warning = MagicMock(return_value=None)
    action_module.display = display

    action_module._task = MagicMock()
    action_module._task.args = {'reboot_poll': '10'}

    action_module.deprecated_args()

    display.warning.assert_called_once_with('Since Ansible 2.9.0, reboot_poll is no longer a valid option for reboot')

    action_module._task.args = {'reboot_poll': '10'}


# Generated at 2022-06-11 12:17:11.755585
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    module = ActionModule()
    module.get_shutdown_command()


# Generated at 2022-06-11 12:17:12.732976
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    assert False

# Generated at 2022-06-11 12:17:22.670348
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    m_display = MagicMock(spec_set=Display)
    m_connection = MagicMock(spec_set=Connection)

    am = ActionModule(m_display, m_connection)
    assert am is not None
    assert am.DEFAULT_REBOOT_TIMEOUT == 500

    m_display.verbosity = 0
    m_display.debug.return_value = None

    m_connection._task.action = 'reboot'
    m_connection._task.args = {'reboot_timeout': 10}

    m_connection_reset = m_connection.reset
    m_connection_reset.return_value = None

    m_connection_set_option = m_connection.set_option
    m_connection_set_option.return_value = None

    m_connection_get_option = m_connection.get_

# Generated at 2022-06-11 12:17:32.549565
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.compat.tests.mock import patch, MagicMock, call
    from collections import namedtuple
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor import module_common as module_common
    TaskResult = namedtuple('TaskResult', ['host', 'result'])

    task_vars = {'key': 'value'}
    result = {'ansible_facts': {'world': 'earth'}}
    task_result = TaskResult('dummy_host', result)

    tqm = TaskQueueManager(module_name='pam_limits', module_args='', module_vars=task_vars)


# Generated at 2022-06-11 12:17:33.944154
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    mod = ActionModule()
    # TODO: implement test



# Generated at 2022-06-11 12:17:35.489154
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    # TODO(retr0h): Add unit test for get_shutdown_command_args
    pass

# Generated at 2022-06-11 12:18:45.214322
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    # test the method that checks for deprecated arguments
    action_module = ActionModule(None)
    test_args = {'reboot_timeout_sec': 10, 'reboot_timeout': 20, 'test_command': 'touch /tmp/test_file'}
    action_module._task.args = test_args
    action_module.deprecated_args()
    assert test_args['reboot_timeout'] == 10
    assert test_args['reboot_timeout_sec'] == 20
    assert test_args['test_command'] == 'touch /tmp/test_file'

# Unit tests for method get_distribution of class ActionModule

# Generated at 2022-06-11 12:18:48.319107
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # mock needed attributes
    am = ActionModule()
    am.task_vars = {}
    
    result = am.get_distribution(am.task_vars)
    # check that returned values are correct
    assert result == 'DEFAULT'

# Generated at 2022-06-11 12:18:57.723219
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action = dict()
    action['action'] = 'reboot'
    play_context = dict()
    task = dict()
    task['action'] = 'reboot'
    task['args'] = dict()
    task['args']['delay'] = '2'
    task['args']['delay_sec'] = '3'
    task['args']['reboot_timeout'] = '6'
    task['args']['reboot_timeout_sec'] = '7'
    task['args']['connect_timeout'] = '9'
    task['args']['connect_timeout_sec'] = '10'
    display = dict()
    display['verbosity'] = 0
    tmp = dict()
    task_vars = dict()
    task_vars['ansible_facts'] = dict()
    task_

# Generated at 2022-06-11 12:19:07.048892
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    result = {}
    result['stdout'] = 'Thu Oct  3 01:48:26 UTC 2019'
    result['stderr'] = ''
    result['rc'] = 0
    Distribution.DEFAULT_BOOT_TIME_COMMAND = 'echo Thu Oct  3 01:48:26 UTC 2019'
    myobj = ActionModule()
    myobj.do_until_success_or_timeout(
        action=myobj.check_boot_time,
        action_desc=None,
        reboot_timeout=60,
        distribution='DEFAULT',
        action_kwargs={'previous_boot_time': result['stdout']})
test_ActionModule_do_until_success_or_timeout()

# Generated at 2022-06-11 12:19:08.217990
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    assert False

# Generated at 2022-06-11 12:19:15.849253
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    self = ActionModule()
    self.do_until_success_or_timeout = MagicMock()
    self.get_system_boot_time = MagicMock(return_value=None)
    self.check_boot_time = MagicMock(return_value=None)
    self.run_test_command = MagicMock(return_value=None)
    distribution = None
    original_connection_timeout = None
    action_kwargs = None
    returned_value = self.validate_reboot(distribution, original_connection_timeout, action_kwargs)
    print(returned_value)


# Generated at 2022-06-11 12:19:25.441031
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    hostname = None
    port = None
    connection = None
    runner_queue = None
    play_context = None
    new_stdin = None
    task_uuid = None
    loader = None
    templar = None
    shared_loader_obj = None
    variable_manager = None
    loader_kwargs = None
    am_kwargs = {}
    sudoable = None
    task_vars = {u'ansible_check_mode': False, u'distribution': u'FreeBSD', u'ansible_host': u'localhost'}
    is_new_to_controller = None
    task_action = 'reboot'
    use_task_vars = True

# Generated at 2022-06-11 12:19:30.003529
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    action = ActionModule()
    # Arrange
    action._connection = object()
    action._connection.get_option = MagicMock(return_value='/usr/bin/python')
    # Act/Assert
    try:
        action.get_system_boot_time('Ubuntu')
    except AnsibleError:
        pass

# Generated at 2022-06-11 12:19:32.423682
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    module = AnsibleModule()
    action_mod = ActionModule(module, 'reboot')
    assert action_mod.run_test_command(None)

# Generated at 2022-06-11 12:19:42.278438
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    # Common setup
    ansible_facts = {}
    shutil.rmtree('/tmp/ansible/adhoc')
    shutil.rmtree('/tmp/ansible/facts')
    shutil.rmtree('/tmp/ansible/playbooks')
    shutil.rmtree('/tmp/ansible/roles')
    shutil.rmtree('/tmp/ansible/modules')
    shutil.copytree('../../../module_utils', '/tmp/ansible/module_utils')
    shutil.copytree('../../../modules', '/tmp/ansible/modules')
    shutil.copytree('../../../action_plugins', '/tmp/ansible/action_plugins')
    shutil.copytree('../../../library', '/tmp/ansible/library')
    shutil.copytree

# Generated at 2022-06-11 12:22:37.444459
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    pass


# Generated at 2022-06-11 12:22:38.332892
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    pass


# Generated at 2022-06-11 12:22:46.226501
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():

    # Create the object
    action_module = ActionModule(task=Task(), connection=Connection(), play_context=PlayContext(), loader=None, templar=None, shared_loader_obj=None)

    # Create a distribution
    distribution = 'FreeBSD'

    # Run the method
    result = action_module.get_system_boot_time(distribution)

    # Run the method again
    result2 = action_module.get_system_boot_time(distribution)

    # Assert we got a dictionary as our result
    assert(isinstance(result, str))

    # Assert we got a dictionary as our result
    assert(isinstance(result2, str))



# Generated at 2022-06-11 12:22:55.278869
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    my_task = Task()
    my_task.action = 'reboot'
    my_task.args = {'distribution':'my_distribution'}

    my_connection = Connection()
    my_connection.python_interpreter = '/bin/python'
    my_connection.transport = 'ssh'
    my_connection.host = 'localhost'
    my_connection.port = 22
    my_connection.user = 'root'
    my_connection.password = 'password'
    my_connection.private_key_file = '/root/key'
    my_connection.timeout = 10
    my_connection.become = False
    my_connection.become_method = 'sudo'
    my_connection.become_user = 'root'
    my_connection.become_pass = 'password'
    my

# Generated at 2022-06-11 12:22:56.598867
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    action = ActionModule()
    print(action)
    assert(action != None)

# Generated at 2022-06-11 12:23:04.848500
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    module_args = {}

# Generated at 2022-06-11 12:23:10.537235
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Arrange
    ansible_result = dict(stdout='', stderr='')
    task_vars = dict(ansible_facts=dict(distribution='Debian'))
    test_obj = ActionModule(dict(), dict(), True, ansible_result)

    # Act
    result = test_obj.get_shutdown_command(task_vars, 'Debian')

    # Assert
    assert result == '/sbin/shutdown'



# Generated at 2022-06-11 12:23:20.887003
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_mod = ActionModule()
    assert not action_mod._get_value_from_facts('DISTRO_REQUIRE_SUDO', 'centos', 'DEFAULT_REQUIRE_SUDO')
    # Test for no distro_facts value
    action_mod.fa = type('FakeAnsibleModule', (), {'params': {}, 'distro_facts': {}})
    assert action_mod.get_distribution({}) == 'DEFAULT'
    # Test for distro_facts value
    action_mod.fa = type('FakeAnsibleModule', (), {'params': {}, 'distro_facts': {'distribution': 'CentOS', 'distribution_major_version': '7'}})
    assert action_mod.get_distribution({}) == 'centos'
    # Test for distro_facts

# Generated at 2022-06-11 12:23:31.481295
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    # arguments
    distribution = None
    command_result = {'rc': 0, 'stdout': '', 'stderr': ''}

    # reset globals to starting state
    ActionModule.DEFAULT_REBOOT_TIMEOUT = 300
    ActionModule.DEFAULT_TEST_COMMAND = 'whoami'

    # create mock object
    action_module = ActionModule(None, None)
    action_module._task = Mock()
    action_module._task.action = 'reboot'
    action_module._task.args = {}
    action_module._connection = Mock()
    action_module.get_distribution = Mock()
    action_module.get_distribution.return_value = 'not implemented'
    action_module._low_level_execute_command = Mock()
    action_module._low_level_

# Generated at 2022-06-11 12:23:34.118011
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    action_module = ActionModule()
    result = action_module.get_system_boot_time('rhel')
    assert result
