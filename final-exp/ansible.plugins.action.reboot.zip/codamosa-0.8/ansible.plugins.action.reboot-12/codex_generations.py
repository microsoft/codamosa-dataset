

# Generated at 2022-06-11 12:14:13.209038
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    am = ActionModule()
    am._task._role._role_path = '/tmp/foo'
    am.DEFAULT_BOOT_TIME_COMMAND = 'uptime'
    am.DEFAULT_SUDOABLE = True
    am.get_system_boot_time('IM_monkey')



# Generated at 2022-06-11 12:14:24.737866
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    module = ActionModule(dict(task=dict(vars=dict(ansible_distribution='HPUX', ansible_distribution_version='11.31')),
                               play_context=dict(become_user='root',
                                                 become_method='su',
                                                 become_exe='/opt/bin/su',
                                                 become_flags=None,
                                                 become_pass=None,
                                                 sudo_flags=None,
                                                 sudo_exe=None,
                                                 sudo_user=None,
                                                 check_mode=False)))

    result = module.get_shutdown_command_args()

    assert isinstance(result, str)
    assert result == '-r'

# Generated at 2022-06-11 12:14:35.062918
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action = {'action': 'reboot'}
    play_context = {'check_mode': False}
    task_vars = {'ansible_distribution': 'Darwin', 'ansible_distribution_version': '13.4.0', 'ansible_distribution_major_version': '13', 'ansible_os_family': 'Darwin', 'ansible_distribution_release': 'Darwin Kernel Version 13.4.0: Mon Jan 11 18:17:34 PST 2016; root:xnu-2422.115.14~1/RELEASE_X86_64', 'ansible_distribution_file_parsed': True}

# Generated at 2022-06-11 12:14:45.969176
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    from unittest import mock

    am = ActionModule()

    with mock.patch.object(Am, '_low_level_execute_command', return_value=dict(rc=0, stdout='foo', stderr='')) as llec_mock:
        am.run_test_command('mydist')
    llec_mock.call_count(1)

    with mock.patch.object(Am, '_low_level_execute_command', return_value=dict(rc=1, stdout='foo', stderr='')) as llec_mock:
        try:
            am.run_test_command('mydist')
        except:
            pass
    llec_mock.called_once_with(mock.ANY, sudoable=False)


# Generated at 2022-06-11 12:14:55.831790
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts._collector import BaseFactCollector
    from ansible.module_utils.facts._collector.base import CollectedFacts

    mock_collected_facts = CollectedFacts(
        ansible_facts=dict(
            distribution='test_distribution',
            distribution_version='test_distribution_version',
        )
    )

    class TestFactCollector(BaseFactCollector):
        """
        A mock class to replace LinuxDistributionFactCollector
        """

        name = 'test'
        _platform = 'test_platform'

        def collect(self, module=None, collected_facts=None):
            return mock_collected_facts


# Generated at 2022-06-11 12:15:07.068300
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # instantiation
    module = ActionModule(load_fixture('raw_arguments.json'), load_fixture('connection_payload.json'))
    module._supports_check_mode = True
    module._supports_async = True

    # parametrized attributes
    module._low_level_execute_command()

    # initialization
    module._load_params()
    module._task.action = "reboot"
    module._connection.transport = ""

    # execution
    with pytest.raises(AnsibleError) as excinfo:
        module.perform_reboot(None)
    assert excinfo.value.message == "Running reboot with local connection would reboot the control node."
    assert excinfo.value.args == ("Running reboot with local connection would reboot the control node.",)


# Generated at 2022-06-11 12:15:17.794873
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    # mock for class Task
    mock_Task = MagicMock()
    mock_Task.action = 'action_test'
    mock_Task.args = {}
    mock_Task.deprecate_as_string = MagicMock()

    # mock for class Options
    mock_Options = MagicMock()
    mock_Options.connection = 'connection_test'
    mock_Options.module_path = 'module_path_test'
    mock_Options.forks = 50
    mock_Options.become = False
    mock_Options.become_method = 'become_method_test'
    mock_Options.become_user = 'become_user_test'
    mock_Options.check = False
    mock_Options.diff = False

    # mock for class PlayContext
    mock_PlayContext = MagicMock()


# Generated at 2022-06-11 12:15:21.832188
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    class_instance = ActionModule()
    distribution = 'linux'
    original_connection_timeout = None
    action_kwargs = {}
    result = class_instance.validate_reboot(distribution, original_connection_timeout, action_kwargs)
    assert True == result['rebooted']
    assert True == result['changed']


# Generated at 2022-06-11 12:15:28.070589
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    am = ActionModule()
    reboot_timeout = 3
    action_kwargs = {'action_kwargs': {'distribution': 'ubuntu'}}
    with pytest.raises(ValueError):
        am.do_until_success_or_timeout(
            action=am.check_boot_time,
            action_desc="last boot time check",
            reboot_timeout=reboot_timeout,
            distribution='ubuntu',
            action_kwargs=action_kwargs)

# Generated at 2022-06-11 12:15:29.655614
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    am = ActionModule()
    am.run_test_command()

# Generated at 2022-06-11 12:16:34.107063
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Given:
    # # Class ActionModule will call the given action (reboot) with the given parameters
    result = {}
    result.update({
        'failed': False,
        'rebooted': True,
        'changed': True,
        'elapsed': 0
    })
    with patch.dict(ActionModule.DEFAULT_ARGS, {'connect_timeout': '10', 'reboot_timeout': '20', 'post_reboot_delay': '30'}):
        am = ActionModule()
        am._supports_check_mode = True
        am._supports_async = True
        am._task = MagicMock()
        am._task.action = 'reboot'
        am._task.args = {'other_arg': 'other'}
        am._task.async_val = 1
       

# Generated at 2022-06-11 12:16:44.420017
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    given_success = True
    given_action_desc = "last boot time check"
    given_reboot_timeout = 30
    given_distribution = "redhat"
    given_action_kwargs = {'previous_boot_time': '12345'}
    get_value_from_facts = lambda arg1, arg2, arg3: "reboot"
    low_level_execute_command = lambda arg1, arg2=None: {'rc': 0, 'stdout': '01-01-1970', 'stderr': ''}
    check_boot_time = lambda arg1, arg2, arg3: None
    time_sleep = lambda arg1: None

# Generated at 2022-06-11 12:16:50.868661
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    args = {}
    module = ActionModule(
        action='reboot',
        task=None,
        connection=None,
        play_context=PlayContext(),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    module.deprecated_args()

    for item in args.keys():
        assert module._task.args.get(item) is None



# Generated at 2022-06-11 12:16:52.683998
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = Host()
    host.run()
    # TODO: mock and verify calls
test_ActionModule_run()

# Generated at 2022-06-11 12:17:03.209097
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import re
    import os
    import sys
    import json
    import subprocess
    import builtins
    import signal
    import shutil
    import tempfile
    import textwrap
    import socket
    import time
    import random
    import uuid

    fake_user = 'testuser'
    if os.getuid() != 0:
        fake_user = builtins.__xonsh__.env.get('USER')

    # Create a directory for temporary files
    tmpdir = tempfile.mkdtemp()

    # Create a temporary ansible.cfg file
    ansible_cfg_path = os.path.join(tmpdir, 'ansible.cfg')

# Generated at 2022-06-11 12:17:14.144160
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    module = ActionModule()
    module._task = {"action": "reboot"}
    module._connection = AnsibleConnection()
    module._connection._shell = AnsibleShell()
    module.DEFAULT_TEST_COMMAND = "command"
    module.TEST_COMMANDS = {"distro": "distro_command"}
    # Test exception case
    with pytest.raises(RuntimeError):
        reboot_result = {"rc": 1, "stderr": "error", "stdout": "success"}
        module._low_level_execute_command = lambda x, sudoable: reboot_result
        module.run_test_command(distribution="distro")
    # Test valid case
    reboot_result = {"rc": 0, "stderr": "", "stdout": "success"}
    module._low_level_

# Generated at 2022-06-11 12:17:23.956356
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    task_vars = dict()

    am_result = dict(
        rebooted=False,
        elapsed=1,
        failed=False,
        changed=False,
        msg=None
    )

    action_module = ActionModule(None, None, None, None)
    result = action_module.get_system_boot_time(distribution="Linux")
    assert result == "Linux", "ISO Standard"
    result = action_module.get_system_boot_time(distribution="FreeBSD")
    assert result == "FreeBSD", "ISO Standard"
    result = action_module.get_system_boot_time(distribution="OpenBSD")
    assert result == "OpenBSD", "ISO Standard"
    result = action_module.get_system_boot_time(distribution="Solaris")

# Generated at 2022-06-11 12:17:33.596385
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    hostvars = dict()
    # Input 'ansible_os_family' is of type string
    ansible_os_family = dict()
    # Input 'ansible_distribution' is of type string
    ansible_distribution = dict()
    m_ansible_os_family = MagicMock(return_value=ansible_os_family)
    m_ansible_distribution = MagicMock(return_value=ansible_distribution)
    with patch.dict(hostvars, {'ansible_os_family': m_ansible_os_family,'ansible_distribution': m_ansible_distribution}, clear=True):
        action_module = ActionModule()
        test = action_module.get_distribution(hostvars=hostvars)
        m_ansible_os_family.assert_

# Generated at 2022-06-11 12:17:40.998027
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    # Test a normal system
    actionm = ActionModule()
    # Test for a reboot
    distribution = 'unknown'
    original_connection_timeout = None
    action_kwargs = {'previous_boot_time': '1'}
    result = actionm.validate_reboot(distribution, original_connection_timeout, action_kwargs)
    assert result['rebooted'] == True
    # Test for a non-reboot
    action_kwargs = {'previous_boot_time': '2'}
    result = actionm.validate_reboot(distribution, original_connection_timeout, action_kwargs)
    assert result['rebooted'] == True
    # Test for a reboot with a timeout
    distribution = 'unknown'
    original_connection_timeout = None

# Generated at 2022-06-11 12:17:51.376591
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import connection_loader

    task = Task()
    task._role = None
    task._block = None
    task._play = None
    task.action = 'reboot'
    task.set_loader(None)
    task.args = dict()
    task.args['shutdown_timeout'] = 0

    play_context = PlayContext()
    play_context.check_mode = False
    connection = connection_loader.get('local', play_context, '/dev/null')
    task.deprecated_args()


# Generated at 2022-06-11 12:19:36.004200
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    raise NotImplementedError("Test not implemented yet")



# Generated at 2022-06-11 12:19:46.138174
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():

    module = AnsibleModule(argument_spec=dict())

    a = ActionModule(module, dict())

    mock_return_values = {
        'file_exists': 0,
        'get_distribution': 'rhel',
        'get_system_boot_time': datetime.utcnow() - timedelta(minutes=5),
        'check_boot_time': True,
        'run_test_command': True,
        'perform_reboot': {
            'failed': False
        },
    }


# Generated at 2022-06-11 12:19:56.076164
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    # set up test environment
    action = 'reboot'
    check_mode = False
    connection = 'local'
    distribution = 'Linux'
    inventory_hostname = 'localhost'
    play_context={'become': None, 'become_method': None, 'become_user': None, 'check_mode': check_mode, 'diff': False}
    transport = 'paramiko'

    # set up action module
    action_module = ActionModule(action, play_context)
    action_module._supports_check_mode = True
    action_module._supports_async = True
    action_module._connection = MockConnection(connection, play_context, transport)
    action_module._task.action = action

# Generated at 2022-06-11 12:20:00.182965
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    # Create an instance of class ActionModule
    test_action_module = ActionModule()
    # Create an instance of class Distribution
    test_distribution = Distribution()
    test_distribution.distribution_name = 'DISTRIBUTION_NAME'
    # test_command = "echo It's a test"
    test_command = 'It\'s a test'
    # Call method run_test_command of class ActionModule with arguments test_distribution and test_command
    test_action_module.run_test_command(test_distribution, test_command)


# Generated at 2022-06-11 12:20:02.917532
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    # Initialize a mock object of class ActionModule
    action_mod = ActionModule()
    distribution = 'RedHat'
    action_mod.run_test_command(distribution)

# Generated at 2022-06-11 12:20:06.545350
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    # Example of the deprecated_args function call
    # function call with the appropriate arguments
    # ActionModule_instance.deprecated_args(arg1, arg2, arg3)

    # Test code
    assert True # TODO: implement your test here


# Generated at 2022-06-11 12:20:07.728263
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    pass


# Generated at 2022-06-11 12:20:18.442693
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    from ansible.module_utils.common.network import ModuleStub
    from datetime import timedelta
    from datetime import datetime

    class CheckBootTime:
        def __init__(self, success_at):
            self.success_at = success_at

        def __call__(self, distribution, previous_boot_time):
            if distribution not in ['Ubuntu', 'CentOS', 'Fedora']:
                raise Exception("Invalid distribution passed in")
            if not self.success_at:
                raise Exception("check_boot_time was called too many times")
            if self.success_at == datetime.utcnow():
                return

            raise ValueError("boot time has not changed")

    class TestCommand:
        def __init__(self, success_at):
            self.success_at = success_at


# Generated at 2022-06-11 12:20:24.642238
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():

    from library.system_reboot_action import ActionModule

    from library.system_reboot_action import TimedOutException
    from ansible.errors import AnsibleError
    from ansible.module_utils.parsing.convert_bool import boolean
    import datetime
    import random
    import time

    with patch.object(ActionModule, 'get_distribution', return_value="fake_distribution"):
        with patch.object(ActionModule, 'get_shutdown_command_args', return_value="fake_shutdown_command_args"):
            with patch.object(ActionModule, 'get_shutdown_command', return_value="fake_shutdown_command"):
                action_module = ActionModule(connection=Mock(), play_context=Mock(), new_stdin=Mock())
                action_module._task

# Generated at 2022-06-11 12:20:29.737719
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # Argument task_vars must exists
    with pytest.raises(AnsibleError):
        ActionModule().get_distribution(None)

    mock_task_vars1 = dict(ansible_facts=dict(ansible_os_family="openbsd", distro="OpenBSD", distribution="OpenBSD"))
    assert ActionModule().get_distribution(mock_task_vars1) == 'openbsd'

    mock_task_vars2 = dict(ansible_facts=dict(ansible_os_family="windows"))
    assert ActionModule().get_distribution(mock_task_vars2) == 'windows'

    mock_task_vars3 = dict(ansible_facts=dict(ansible_os_family="Solaris"))

# Generated at 2022-06-11 12:23:18.546969
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    action = ActionModule()
    print("Testing method get_system_boot_time of class ActionModule")

    # Load module data
    with open('/vagrant/ansible_collections/ansible_collections/community/system/plugins/modules/system/reboot.py', 'r') as f:
        module_data = f.read()
    exec(module_data, globals())

    # Test 1:
    # Return system boot time
    print("Test 1: Return system boot time")
    display.vvv = Mock(return_value = None)
    action._low_level_execute_command = Mock(return_value = {
        'rc': 0,
        'stderr': '',
        'stdout': '2019-11-26 12:08:03.839442+01:00'
    })
   

# Generated at 2022-06-11 12:23:29.412436
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_mod = ActionModule(play_context=play_context, new_stdin=None)
    action_mod.DEFAULT_DISTRIBUTION = "DEFAULT_DISTRIBUTION"
    action_mod.DISTRIBUTION_FACTS_KEYS = {'FACT_KEY_1': 'DISTRIBUTION_1', 'FACT_KEY_2': 'DISTRIBUTION_2'}
    action_mod.DISTRIBUTION_FACT_KEYS_ORDER = [{'key': 'FACT_KEY_1', 'prefer': False},{'key': 'FACT_KEY_2', 'prefer': True}]

# Generated at 2022-06-11 12:23:39.178535
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    # Initialisation
    system_facts = dict(facts_module_mock)

    # Test execution
    reboot = ActionModule(task_mock, connection_mock, play_context_mock, loader_mock, templar_mock, shared_loader_obj=None)
    reboot.set_options_mock(dict(), 'DEFAULT_BOOT_TIME_COMMAND', 'boot_time_command')
    reboot._get_value_from_facts_mock = MagicMock(return_value=None)
    result = reboot.get_system_boot_time('test')

    # Test assertions
    assert reboot._low_level_execute_command_mock.called
    assert result == '2018-07-24T09:42:53Z'