

# Generated at 2022-06-11 12:14:22.736440
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    action_module = ActionModule()
    task = mock.MagicMock()
    action_module.get_distribution = 'mock distribution'
    action_module.do_until_success_or_timeout = lambda action, reboot_timeout, action_desc, distribution, action_kwargs: action(distribution=distribution)

    # test successful test_command
    test_command = 'mock_test_command'
    task.args = {'test_command': test_command}
    action_module._task = task
    command_result = {'rc': 0, 'stdout': 'mock standard out', 'stderr': 'mock standard error'}
    action_module._low_level_execute_command = lambda test_command, sudoable: command_result

# Generated at 2022-06-11 12:14:30.206090
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup an instance of the AnsibleModule class with correct parameters
    im = MagicMock()
    im.params = dict()
    im.params['msg'] = "Test Msg"
    module = ActionModule(im)

    # Setup mocks for the class module and the inherited class ActionBaseV2
    amv = Mock(name='ActionModule_ActionBaseV2_Mock')
    amv.action = 'test_module'
    module._task.action = 'test_module'
    module._task.async_val = 0
    module._task.delay = 0
    module._task.notify = dict()
    module._task.reconnect_delay = 1
    module._task.notify_timeout_sec = 15
    module._play_context = Mock(name='ActionModule_play_context_Mock')
    module

# Generated at 2022-06-11 12:14:42.043734
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    #
    # Unit test for method run_test_command of class ActionModule
    #
    # mock test
    task_vars = {'ansible_distribution': 'redhat', 'ansible_facts': {'distribution': 'RedHat', 'distribution_major_version': '7'}, 'ansible_distribution_version': '7.4'}
    display = mock.Mock()
    self = ActionModule(task_vars=task_vars, display=display)

    distribution = 'RedHat'
    test_command = 'cat /proc/version'

    # mock low_level_execute_command
    CommandResult = collections.namedtuple('CommandResult', ['rc', 'stdout', 'stderr'])

# Generated at 2022-06-11 12:14:49.964223
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    try:
        import mock
    except ImportError:
        import unittest.mock as mock
    import time

    # Start with a mock ActionModule instance. We just need enough attributes to the
    # action module for do_until_success_or_timeout to run.
    test_class = mock.MagicMock()
    test_class.action = 'test_action'
    test_class.DEFAULT_REBOOT_TIMEOUT = 300
    test_class.DEFAULT_CONNECT_TIMEOUT = 10

    with mock.patch.object(time, 'sleep') as mock_sleep:
        # Test AttributeError raised when timeout is not numeric
        module = ActionModule(None, test_class)

# Generated at 2022-06-11 12:14:54.211102
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():

    obj = ActionModule()

    # Call method do_until_success_or_timeout of class ActionModule
    # TODO I can't exactly figure out HOW to do this here.
    obj.do_until_success_or_timeout(None, None, None, None, None)
    return


# Generated at 2022-06-11 12:15:05.474428
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():

    # From test/units/modules/platform/linux/system/test_reboot.py
    action = 'reboot'
    reboot_timeout = 10

    class Distribution():
        def __init__(self, name):
            self.name = name
            self.id = self.name

    class TimedOutException(Exception):
        pass
    time_exception = TimedOutException('Timed out waiting for reboot (timeout={timeout})'.format(timeout=reboot_timeout))

    import time
    class ActionModule():
        def __init__(self, task):
            self.DEFAULT_CONNECT_TIMEOUT = 30
            self.DEFAULT_REBOOT_TIMEOUT = 600

        def do_until_success_or_timeout(self, reboot_timeout, action, action_kwargs, distribution, action_desc):
            action

# Generated at 2022-06-11 12:15:16.390309
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = FauxAnsibleModule()
    module_result = { 'rc': 0, 'stdout':'', 'stderr':'' }
    action_module.execute_command = lambda command, sudoable: module_result
    action_module.get_distribution = lambda: 'Fedora'
    action_module.get_shutdown_command = lambda task_vars, distribution: '/sbin/shutdown'

    reboot_result = {
        'changed': True,
        'elapsed': 5,
        'failed': True,
        'msg': 'Reboot command failed. Error was: ""',
        'rebooted': False,
        'start': datetime(1900, 1, 1, tzinfo=timezone.utc)
    }

# Generated at 2022-06-11 12:15:23.572356
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # Asserting that the method check_boot_time() of class ActionModule raises
    # an ValueError if the boot time hasn't changed based on the output of a command
    # which returns the last boot time
    with mock.patch.object(ActionModule,"get_system_boot_time") as mock_method:
        mock_method.return_value = "2019-05-28 08:41:08.520016"
        fake_distribution = "test"
        fake_previous_boot_time = "2019-05-28 08:41:08.520016"
        am = ActionModule(task=None, connection=None, play_context=None, loader=None,templar=None,shared_loader_obj=None)

# Generated at 2022-06-11 12:15:33.758094
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    (os_path_exists, os_path_isfile) = mock.Mock(), mock.Mock()
    (os_path_exists.return_value, os_path_isfile.return_value) = (True, True)
    (os_path_exists, os_path_isfile) = (os_path_exists, os_path_isfile)
    self_connection = mock.Mock()
    self_task = mock.Mock()
    self_task.action = 'reboot'
    self_task.args = {'connect_timeout': 1, 'reboot_timeout': 2}
    module = ActionModule(self_connection, self_task, os_path_exists=os_path_exists, os_path_isfile=os_path_isfile)
    module.deprecated_

# Generated at 2022-06-11 12:15:37.971394
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    action_module = ActionModule(task=MagicMock(), connection=MagicMock(), play_context=MagicMock(), loader=None, templar=None, shared_loader_obj=None)
    assert action_module.run_test_command("distribution", **{"kwargs": "kwargs"}) == None


# Generated at 2022-06-11 12:16:15.532368
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    module = ActionModule()
    assert module.get_shutdown_command_args() == '-r -t 0'
    assert module.get_shutdown_command_args('redhat') == '-r now'
    assert module.get_shutdown_command_args('fedora') == '-r now'
    assert module.get_shutdown_command_args('debian') == '-r -t 0'
    assert module.get_shutdown_command_args('ubuntu') == '-r -t 0'
    assert module.get_shutdown_command_args('centos') == '-r now'
    assert module.get_shutdown_command_args('default') == '-r -t 0'
    assert module.get_shutdown_command_args('none') == '-r -t 0'
    assert module.get

# Generated at 2022-06-11 12:16:17.674622
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    task_vars = dict()
    result = dict()
    # Call method
    ActionModule.deprecated_args(ActionModule(), task_vars, result)



# Generated at 2022-06-11 12:16:23.386032
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # Arrange
    from ansible.plugins.action.reboot import ActionModule
    mock_module_util = Mock()
    mock_module_util.ANSIBLE_MODULE_UTILS = None
    x = ActionModule.get_distribution(mock_module_util, 'centos')

    # Act
    y = "centos"
    # Assert
    assert x == y


# Generated at 2022-06-11 12:16:24.629920
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    assert False, "Test not implemented"


# Generated at 2022-06-11 12:16:35.363983
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    #
    # Validate the ActionModule._execute_module function
    #
    # test_deprecated_args: try to use deprecated args, check if warning is raised
    #
    # Args:
    #     test_case (dict): first arg for the mock call
    #
    # basic test

    action_name = 'test_action_name'
    action_args = {'test_arg_name': 'test_arg_value'}
    task_info = {'test_key': 'test_value'}
    ansible_vars = {'test_ansible_var_name': 'test_ansible_var_value'}

# Generated at 2022-06-11 12:16:40.733811
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Define values for the method run of class ActionModule
    method_run_tmp = None
    method_run_task_vars = None
    # Set values for the method run of class ActionModule
    self_connection = None
    self_play_context = None
    self_task = None
    self_loader = None
    self_shared_loader_obj = None
    self_global_var

# Generated at 2022-06-11 12:16:47.411176
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # Initialize test variables
    distribution = 'ubuntu'
    previous_boot_time = datetime.utcnow()

    # Initialize action_module instance
    task_vars = {}
    action_module = ActionModule(task_vars=task_vars)

    try:
        action_module.check_boot_time(distribution=distribution, previous_boot_time=previous_boot_time)
    except Exception as e:
        raise e

    return

# Generated at 2022-06-11 12:16:56.944895
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # get_shutdown_command setup
    hostvars = {}
    module = ActionModule(load_fixture('reboot', 'argument_spec'), hostvars)
    distribution = 'centos'

    # get_shutdown_command executed
    task = Task()
    task.action = 'reboot'
    task._task = 'reboot'
    task.action = 'reboot'
    task.args = {'reboot_timeout': 30, 'post_reboot_delay': 0}
    module._task = task
    result = module.get_shutdown_command(hostvars, distribution)

    # get_shutdown_command results
    assert result == 'shutdown'



# Generated at 2022-06-11 12:16:57.740733
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:17:07.730556
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    import ansible.plugins.action.reboot as reboot
    import copy

    task_vars = {}
    self = reboot.ActionModule(copy.deepcopy(task_vars))
    task_vars['ansible_facts'] = {}
    distribution = None

    self._task.action = 'reboot'

    # test default_shutdown_command
    task_vars['ansible_facts']['shutdown_command'] = '/usr/sbin/shutdown -h'
    cmd = self.get_shutdown_command(task_vars, distribution)
    assert cmd == '/usr/sbin/shutdown -h'

    # test default_shutdown_command
    task_vars['ansible_facts']['shutdown_command'] = '/usr/sbin/halt'
    cmd = self.get_

# Generated at 2022-06-11 12:17:41.059868
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    pass


# Generated at 2022-06-11 12:17:41.800470
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    pass

# Generated at 2022-06-11 12:17:47.244533
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    # Fetching value for variable 'distribution' failed. The error was: An unhandled exception occurred while templating 'Variable 'ansible_distribution' is undefined. String: {% if ansible_distribution == "CentOS" %}
    # DEFAULT_BOOT_TIME_COMMAND
    assert ActionModule.get_system_boot_time(distribution) == 'DEFAULT_BOOT_TIME_COMMAND'


# Generated at 2022-06-11 12:17:58.076994
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    args = dict(
        reboot_timeout=300,
        test_command='echo "bacon"',
        connection='ssh',
        transport='smart',
        remote_addr='127.0.0.1',
        remote_user='user',
        password='password',
        timeout=10,
        become_user='root',
    )
    task_vars = dict(
        ansible_connection='smart',
        ansible_ssh_common_args='',
        remote_host='127.0.0.1',
        remote_user='user',
        ansible_connection_timeout=120,
    )

# Generated at 2022-06-11 12:18:08.007293
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    def get_system_boot_time(distribution):
        sample_data = """
        opensuse
        {'BOOT_TIME_COMMAND': 'stat --printf="%Y" /proc/1$
        """
        for line in sample_data.splitlines():
            if distribution in line:
                # parse out the correct command
                try:
                    return line.split(':')[1].strip().strip('\'')
                except IndexError:
                    return None

    am = ActionModule(task=MockTask(), connection=MockConnection(), play_context=PlayContext(), loader=None, templar=None, shared_loader_obj=None)
    distributions = ['opensuse', 'redhat', 'fedora', 'debian']

# Generated at 2022-06-11 12:18:13.056809
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    test_instance = ActionModule()
    test_instance.check_boot_time = MagicMock(return_value='1')
    test_instance.run_test_command = MagicMock()
    result = test_instance.validate_reboot(distribution='distribution')
    assert result.get('rebooted')
    assert result.get('changed')

# Generated at 2022-06-11 12:18:23.205672
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # instantiate action plugin
    action_module = ActionModule()
    # instantiate task
    task = Task()
    # instantiate play
    play = Play()
    # instantiate play context
    play_context = PlayContext()
    # instantiate connection plugin
    connection = Connection()
    # instantiate inventory plugin
    inventory = Inventory()
    # instantiate connection plugin
    connection = Connection()
    # set connection plugin to connection
    connection._connection = connection
    # set connection plugin to play_context
    play_context._connection = connection
    # set inventory plugin to play_context
    play_context.inventory = inventory

    # call method run of class ActionModule
    action_module.run(tmp=None, task_vars=None)


# Generated at 2022-06-11 12:18:33.863692
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    class Connection_mock:
        def __init__(self):
            self.transport = 'local'

    class Connection_mock_ssh:
        def __init__(self):
            self.transport = 'ssh'

    class Task_mock:
        def __init__(self):
            self.action = 'reboot'
            self.args = {}

        def update_vars(self, vars):
            self.vars = vars

    class PlayContext_mock:
        def __init__(self):
            self.check_mode = True

    class Runner_mock:
        def __init__(self):
            self.connection = Connection_mock()
            self.play_context = PlayContext_mock()
            self.task = Task_mock()


# Generated at 2022-06-11 12:18:43.806533
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Create an actual instance of ActionModule to test the function
    obj = ActionModule({}, {}, {}, {}, {}, None, {})

    # Create a mock object of AnsibleConnection to replace the connection obj
    test_connection = AnsibleConnection()

    # Set the connection object of the action module to be used during the test
    obj._connection = test_connection

    # Create a mock object for the task with the args used for the test
    test_task = Mock()

    # Define the expected command to be returned by the function
    expected_command = 'shutdown'

    # Set the arguments to be used in the function test
    test_task.args = {'shutdown_command': 'shutdown'}

    # Set the class variable describing the command to be returned by the function

# Generated at 2022-06-11 12:18:47.409583
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    action = ActionModule()
    test_obj = BaseTestActionModule()
    test_obj.controller = Controller()
    test_obj.controller.register_action('reboot', action)
    test_obj.controller.execute_action('reboot', None, None)

# Generated at 2022-06-11 12:19:49.804363
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    ActionModule.check_boot_time("")

# Generated at 2022-06-11 12:19:59.434921
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    # Load test file
    test_file = os.path.join(os.path.dirname(__file__), 'unit/ansible_collections/ansible/builtin/tests/unit/modules/system/test_reboot.py')
    sys.argv = [sys.argv[0]]
    sys.argv.append('-v')
    sys.argv.append('-x')
    sys.argv.append(test_file)
    sys.argv.append('-kdeprecated_args')
    # Initialize a new instance of the class
    action_module = ActionModule()
    # Setup args
    task_args = {}
    # Run the method

# Generated at 2022-06-11 12:20:00.356740
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # TODO: Implement test
    pass

# Generated at 2022-06-11 12:20:09.847959
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    args = dict(
        reboot=True,
        force=True,
        delay=10,
    )

    task = MagicMock()
    task.args = args

    am = ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    distribution = 'FreeBSD'
    assert am.get_shutdown_command_args(distribution) == '-p now -r +10'

    distribution = 'OpenBSD'
    assert am.get_shutdown_command_args(distribution) == '-p now'

    distribution = 'SunOS'
    assert am.get_shutdown_command_args(distribution) == '-y -g 10 -i 5'

    distribution = 'Linux'
    assert am.get_shutdown_command_

# Generated at 2022-06-11 12:20:20.333479
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Create an instance of the class to be tested
    am = ActionModule()
    # Add test data case
    task_vars = {}
    # Add return value for AnsibleModule.params
    am.params = {}
    am.params['shutdown_command'] = "shutdown_command"
    am.params['use_syslog'] = None
    am.params['force_delay'] = []
    am.params['use_sendcmd'] = False
    am.params['use_reboot'] = False
    am.params['reboot_timeout'] = None
    am.params['reboot_timeout_sec'] = None
    am.params['test_command'] = None
    am.params['connect_timeout'] = None
    am.params['connect_timeout_sec'] = None
    am.params['msg'] = "msg"

# Generated at 2022-06-11 12:20:24.805041
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.utils.display import Display

    display = Display()
    display.verbosity = 4
    a = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=False,
        mutually_exclusive=[],
        required_together=[],
    )

    a.exit_json(**{'changed': True})
    a.exit_json(changed=True)
    a.exit_json()

    a.fail_json(msg="Test exception")


# Generated at 2022-06-11 12:20:25.288209
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    pass

# Generated at 2022-06-11 12:20:27.300271
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # Create an instance of the class to test
    action_module = ActionModule(action_plugin.ActionBase("test", {}, {}, {}, {}))

    # This will raise an exception if it is not implemented
    action_module.check_boot_time("")



# Generated at 2022-06-11 12:20:32.269179
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # Reset static variables for running unit tests
    ActionModule.set_test_timeout_value(30)

    action_module = ActionModule()
    action_module.set_test_fail_count_value(0)

    # run test with success
    kwargs = {'item': 'test'}
    action_module.do_until_success_or_timeout(action=action_module.do_until_success_or_timeout_action_success,
                                              action_desc='',
                                              reboot_timeout=30,
                                              action_kwargs=kwargs)

    # run test with failure

# Generated at 2022-06-11 12:20:33.818057
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    # Return a tuple with a string and a list containing parameter names and their corresponding types
    return '_low_level_execute_command', (os._wrap_close, 'String', 'Dict',)



# Generated at 2022-06-11 12:23:31.909047
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Instantiating ActionModule and initializing its member attributes
    amd = ActionModule()
    amd._top_level_task_vars = dict()
    amd._top_level_task_vars['ansible_ssh_user'] = 'test_ansible_ssh_user'
    amd._top_level_task_vars['ansible_distribution_version'] = 'test_ansible_distribution_version'
    amd._top_level_task_vars['ansible_distribution_file_parsed'] = 'test_ansible_distribution_file_parsed'
    amd._top_level_task_vars['ansible_distribution_release'] = 'test_ansible_distribution_release'

# Generated at 2022-06-11 12:23:34.117170
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    assert action._get_distribution() == action.DEFAULT_DISTRIBUTION


# Generated at 2022-06-11 12:23:37.498580
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    self = ActionModule(None, None)

    result = self.get_shutdown_command_args(None)

    expected = ''
    assert result == expected, "Expected: %s, Actual: %s" % (expected, result)
