

# Generated at 2022-06-11 12:14:20.332484
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    """Unit tests for method ActionModule.run_test_command of class action."""
    action_module = ActionModule()

    def mock_low_level_execute_command(self, low_level_command, sudoable=None):
        if low_level_command == 'exit 0':
            return {'stdout': '', 'stderr': '', 'rc': 0}
        else:
            return {'stdout': '', 'stderr': '', 'rc': 1}

    action_module._low_level_execute_command = types.MethodType(mock_low_level_execute_command, action_module)

    # Failure test case
    try:
        action_module.run_test_command('centos')
    except RuntimeError as e:
        assert "Test command failed" in to_text(e)

   

# Generated at 2022-06-11 12:14:29.277557
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    import json

    task = FakeTask()
    connection = FakeConnection()
    plugin = ActionModule(connection=connection, task=task)
    reload(module_utils.facts.system)
    with patch.object(module_utils.facts.system.SystemFacts, 'get_distribution') as mock_get_distribution:
        with patch.object(module_utils.facts.system.SystemFacts, 'get_distribution_version') as mock_get_distribution_version:
            with patch.object(ActionModule, 'get_system_boot_time') as mock_get_system_boot_time:
                with patch.object(ActionModule, 'do_until_success_or_timeout') as mock_do_until_success_or_timeout:
                    # Mock exception from get_distribution
                    mock_get_distribution.side_

# Generated at 2022-06-11 12:14:41.078096
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    module = ActionModule()
    module.DEFAULT_CONNECT_TIMEOUT = 12
    module.DEFAULT_REBOOT_TIMEOUT = 17
    class Task:
        def __init__(self):
            self.args = {'reboot_timeout': 42}
    module._task = Task()
    class Connection:
        def __init__(self, transport=None):
            self.transport = transport
    class PlayContext:
        def __init__(self, check_mode=False):
            self.check_mode = check_mode
    module._play_context = PlayContext(False)

    module._connection = Connection('network')
    result = module.perform_reboot(None, 'test_distro')
    assert result['changed']
    assert not result['failed']

# Generated at 2022-06-11 12:14:49.730117
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    argv = ['./ansible-test', 'test_action_module', '--explain', '--show-content']

    # Assert that the example has not been moved out of its section.
    # A later version should be in its own section.
    lines = __file__.split('\n')
    my_index = lines.index("    # Unit test for method deprecated_args of class ActionModule")
    example_index = lines.index("    # Unit test example for method deprecated_args of class ActionModule")
    assert example_index - my_index == 7

    # Execute the example.
    os.environ['ANSIBLE_CONFIG'] = 'test/integration/ansible.cfg'
    cmd = ActionModule(argv=argv)
    cmd._load_params()

# Generated at 2022-06-11 12:14:56.471789
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # Init mock
    mock_ActionModule = MagicMock(spec=ActionModule)
    mock_ActionModule.get_value_from_facts.return_value = 'Fedora'

    # Create test context and run test
    test_context = create_task_context()
    test_context.action = mock_ActionModule
    test_context.task.args = {}
    result = test_context.action.get_distribution(test_context.task_vars)
    assert result == 'Fedora'


# Generated at 2022-06-11 12:14:57.536489
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:15:08.705661
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.reboot import ActionModule
    from ansible.playbook.task import Task

    # Note: the following values are all mock data.
    tmp = 'tmp_value'
    task_vars = {
        'ansible_distribution': 'ansible_distribution_value',
        'ansible_facts': {
            'ansible_distribution': 'ansible_facts_distribution_value',
            'ansible_distribution_version': 'ansible_facts_distribution_version_value',
        },
        'ansible_distribution_release': 'ansible_distribution_release_value',
        'ansible_distribution_version': 'ansible_distribution_version_value',
        'ansible_reboot_command': 'ansible_reboot_command_value',
    }

# Generated at 2022-06-11 12:15:12.339488
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    print("test_ActionModule_do_until_success_or_timeout")

    # TODO: add unit tests for method get_shutdown_command_args()
    print("This method does not have tests yet.")
    assert(True)

# Generated at 2022-06-11 12:15:21.509110
# Unit test for method get_shutdown_command of class ActionModule

# Generated at 2022-06-11 12:15:28.067666
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    from ansible.module_utils.common.text.converters import to_bytes
    action_module = ActionModule()
    test_command = 'uptime'
    action_module.set_task_and_play("testing_ActionModule", "testing_ActionModule")
    action_module.set_connection("testing_ActionModule")
    action_module.run_test_command("testing_ActionModule")
    assert to_bytes(action_module._task.action) == to_bytes("testing_ActionModule")

# Generated at 2022-06-11 12:16:00.741187
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    """
    Test function get_shutdown_command of class ActionModule.
    """
    am = ActionModule()
    am.get_shutdown_command(task_vars={}, distribution='rhel')

# Generated at 2022-06-11 12:16:04.299655
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    m = ActionModule()
    m.check_boot_time = MagicMock(return_value=None)
    result = m.run_test_command('test')
    assert(result == None)

# Generated at 2022-06-11 12:16:09.730128
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module = ActionModule('_task', '_connection', '_play_context', loader=None, templar=None, shared_loader_obj=None)
    Distribution = namedtuple('Distribution', 'name')

    action_module._distribution = Distribution('distribution')
    assert action_module.get_distribution({}) == 'distribution'

# Generated at 2022-06-11 12:16:17.129732
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    print('Testing get_shutdown_command_args() with default shutdown_timeout value')
    action_module = ActionModule(task=MockTask(), connection=MockConnection(), play_context=MockPlayContext(), loader=None, templar=None, shared_loader_obj=None)
    result = action_module.get_shutdown_command_args(distribution='Linux')
    if result != '-r now':
        pytest.fail("Expected '-r now' but got '{0}'".format(result))
    print('Tested get_shutdown_command_args() successfully')


# Generated at 2022-06-11 12:16:27.751510
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    inventory._hosts = [Host("fake-hostname").vars]

    module_deprecation_lookup = {}
    task_vars = {"ansible_distribution": "fake-distribution"}
    module = ActionModule("fake-name",
                          task=Task("fake-name", TaskResult(host="fake-hostname"),
                                    task_vars=task_vars),
                          connection=Connection("local"),
                          play_context=PlayContext(play_context_vars={"name": "fake-name"}, module_deprecation_lookup=module_deprecation_lookup),
                          loader=None,
                          templar=None,
                          shared_loader_obj=None)

    def fake_get_distribution(self, task_vars):
        return "fake-distribution"

# Generated at 2022-06-11 12:16:38.253506
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    actmod = ActionModule()
    class TestClass:
        def __init__(self):
            self.failed = False
            self.failed_count = 0
            self.called = False
            self.called_count = 0
    testclass = TestClass()
    actmod.do_until_success_or_timeout(action=lambda: testclass.called, action_desc="Test", reboot_timeout=10, distribution=None)
    assert testclass.called == True
    assert testclass.called_count == 1
    assert testclass.failed == False
    assert testclass.failed_count == 0
    testclass.failed = True
    testclass.failed_count = 0

# Generated at 2022-06-11 12:16:48.875932
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    action_module = ActionModule()

    # test_distribution is "redhat".
    # When distribution is "redhat",
    # the action plugin will try to get the boot time of
    # the system with command "uptime -s",
    # then the value returned in command_result['stdout']
    # should be the current boot time of the system.
    command_result = {}
    command_result['rc'] = 0
    command_result['stdout'] = test_boot_time
    command_result['stderr'] = ''
    action_module._low_level_execute_command = MagicMock(return_value=command_result)

    result = action_module.get_system_boot_time("redhat")

    assert result == test_boot_time

# Generated at 2022-06-11 12:16:59.510393
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.connection import ConnectionBase

    # Placeholder for class
    class Connection(ConnectionBase):
        pass

    from ansible.module_utils.facts import Facts
    facts_obj = Facts(module_name='test', module_args={}, timeout=5)
    facts = facts_obj.get_facts()

    # Placeholder for reboot
    def reboot(self, task_vars, distribution):
        reboot_result = {}
        reboot_result['start'] = datetime.utcnow()
        reboot_result['failed'] = False
        return reboot_result

    class ActionModule(RebootModule):
        def get_distribution(self, task_vars):
            return 'CentOS'

        def get_system_boot_time(self, distribution):
            return 'time1'


# Generated at 2022-06-11 12:17:01.227675
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
  action = ActionModule({'name': 'foo'}, {}, {})
  raise Exception(action)

# Generated at 2022-06-11 12:17:09.295040
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():

    # Arrange
    # Create an instance of ActionModule
    result = {}
    action_module = ActionModule()

    # Create a dummy task_vars
    task_vars = {}

    # Act
    # Call method get_shutdown_command with arguments task_vars, distribution
    # set to POSIX
    result = action_module.get_shutdown_command(task_vars, 'POSIX')

    # Assert
    expected_result = '/sbin/shutdown'
    assert result == expected_result, "Expected: %r, Actual: %r" % (expected_result, result)



# Generated at 2022-06-11 12:18:10.533461
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
  fixture = ActionModule(display=None, play_context=PlayContext(), new_stdin=None, loader=None, options=None, passwords=None)
  output = fixture.check_boot_time("bar")
  expected_output = None
  assert output == expected_output


# Generated at 2022-06-11 12:18:17.664674
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Create connection object
    connection = AnsibleConnection(paramiko.SSHClient())
    connection.set_option('host_key_checking', False)

    # Create task object
    task_vars = dict({ 'inventory_hostname': 'localhost', 'ansible_connection': 'ssh' })
    task = AnsibleTask()
    task.args = dict({})
    action = ActionModule(task, connection)

    # test with a valid distribution
    distribution = 'cheese'
    action._get_value_from_facts = MagicMock()
    action._get_value_from_facts.return_value = 'cheese'
    action._low_level_execute_command = MagicMock()

# Generated at 2022-06-11 12:18:23.647725
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    a = ActionModule(
'''---
- name: test
  hosts: localhost
  tasks:
    - name: test
      test_reboot:
        test_command: echo okay
        connect_timeout: 0
        reboot_timeout: 0
''')
    result = a.run_test_command(distribution='')
    if result['rc'] != 0:
        raise RuntimeError(result)

# Generated at 2022-06-11 12:18:24.362236
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    pass

# Generated at 2022-06-11 12:18:25.641955
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # The actual testing code
    raise NotImplementedError

# Generated at 2022-06-11 12:18:35.942566
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    # We have a data structure which gives us a default value for every
    # combination of distribution and use_reboot_command_with_timeout.
    # The function under test just uses that.
    action = ActionModule(task=load_fixture('task'))

# Generated at 2022-06-11 12:18:36.995555
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    raise NotImplementedError()


# Generated at 2022-06-11 12:18:39.988559
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    
    # test ActionModule validation of reboot

    test_obj = ActionModule()
    
    # setup mocks
    
    # mock distribution
    mock_distribution = "mock distribution"
    
    # run test
    test_obj.validate_reboot(mock_distribution)
    
    # assert results
    assert True
    
    
    
    
    
    
    
    


# Generated at 2022-06-11 12:18:48.234490
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    import unittest2 as unittest
    class _ActionModule(ActionModule):
        __test__ = True
        _connection = None
        _task = None

        def __init__(self):
            self._supports_async = False
            self._supports_check_mode = True
            self.result = dict(changed=False)

    class _CustomModule(unittest.TestCase):
        def setUp(self):
            self.ActionModule = _ActionModule()

        def tearDown(self):
            del self.ActionModule

    test_case = _CustomModule()
    test_case.maxDiff = None
    test_case.setUp()
    test_case.tearDown()

# Generated at 2022-06-11 12:18:56.632008
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    test_obj = AnsibleModule(
        argument_spec = dict()
    )
    test_obj._task.args = {}
    test_obj._task.action = 'reboot'

    test_obj._task.args['force'] = True
    assert test_obj.get_shutdown_command_args('Linux') == '-f'
    assert test_obj.get_shutdown_command_args('FreeBSD') == '-f'

    test_obj._task.args['force'] = False
    assert test_obj.get_shutdown_command_args('Linux') == ''
    assert test_obj.get_shutdown_command_args('FreeBSD') == '-r'


# Generated at 2022-06-11 12:21:08.513340
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    """
    check_boot_time() ->

    @param distribution:
    """
    # result = self.check_boot_time()
    # [TODO] Implement test later
    pass


# Generated at 2022-06-11 12:21:10.482175
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    # Arguments of the method.
    distribution = 'Linux'
    # Return value of the method or none if the method raises an exception
    return_value = ActionModule.get_shutdown_command_args(distribution)
    assert return_value == '-r now'



# Generated at 2022-06-11 12:21:12.588031
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    args = {'test_command': 'echo "hi"'}
    am = ActionModule(Task(), Connection(), module_name='reboot', module_args=args)
    am.DEPRECATED_ARGS = {'test_command': '2.3'}
    am.deprecated_args()


# Generated at 2022-06-11 12:21:13.591125
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module = ActionModule()
    # TODO: mock check_boot_time
    pass


# Generated at 2022-06-11 12:21:15.886595
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
  with pytest.raises(Exception):
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module.DEPRECATED_ARGS = {}
    action_module.deprecated_args()



# Generated at 2022-06-11 12:21:24.381841
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module = ActionModule(task=Mock(action='reboot'), connection=Mock(), play_context=Mock())

    with patch("ansible.plugins.action.reboot.ActionModule._low_level_execute_command") as low_level_execute_command:
        with patch("ansible.plugins.action.reboot.ActionModule._get_value_from_facts") as get_value_from_facts:
            # first test with low_level_execute_command
            low_level_execute_command.return_value = {'stdout': b'Ubuntu blah blah 16.04.1', 'rc': 0}
            get_value_from_facts.return_value = None
            task_vars = {"ansible_facts":{}}
            expected = "debian"

# Generated at 2022-06-11 12:21:29.697970
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    action_module = ActionModule(dict(), play_context=PlayContext(), new_stdin=None, loader=None, templar=None, shared_loader_obj=None)
    action_module._task = Mock(Mock(action='reboot'))
    action_module._task.args = {'reboot_timeout': '1'}
    try:
        action_module.get_system_boot_time({'distribution': 'Mock'})
    except TimedOutException:
        pass


# Generated at 2022-06-11 12:21:31.441384
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # FUTURE: consider mocking here
    # but is it worth the extra code to do so?
    pass


# Generated at 2022-06-11 12:21:34.250021
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
  # Test with a valid dataset
  action_module = get_ActionModule_instance()
  action_module.get_system_boot_time(distribution='test_distribution')

  # Test with a invalid dataset

  # Test with a non-existing dataset



# Generated at 2022-06-11 12:21:43.057608
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    # Arrange
    ACTION_MODULE_INSTANCE = ActionModule()
    ACTION_MODULE_INSTANCE._task.args['msg'] = None
    ACTION_MODULE_INSTANCE._task.args['reboot_timeout'] = None
    ACTION_MODULE_INSTANCE._task.args['test_command'] = None
    ACTION_MODULE_INSTANCE._task.args['connect_timeout'] = None
    ACTION_MODULE_INSTANCE._task.args['connect_timeout_sec'] = None
    ACTION_MODULE_INSTANCE._task.args['test_command_stderr'] = None
    ACTION_MODULE_INSTANCE._task.action = 'reboot'
    expected = None

    # Action
    actual = ACTION_MODULE_INSTANCE.deprecated_args()

    # Assert