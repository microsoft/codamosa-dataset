

# Generated at 2022-06-21 02:37:41.462267
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
  class MockActionModule:
    pass
  module = MockActionModule()
  module.run_test_command = ActionModule.run_test_command
  module._task = MockActionModule()
  module._task.action = 'reboot'
  module.DEFAULT_SUDOABLE = False
  module._low_level_execute_command = lambda cmd, sudoable: {'rc': 0, 'stderr': "", 'stdout': ""}
  distribution = 'DEFAULT'
  test_command = '/bin/true'
  module.run_test_command(distribution, test_command=test_command)
# Execute unit tests
test_ActionModule_run_test_command()

# Generated at 2022-06-21 02:37:48.452940
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    # ActionModule.validate_reboot(distribution, original_connection_timeout=None, action_kwargs=None)

    # Test with action_kwargs = None, original_connection_timeout = None
    with patch.object(ActionModule, 'check_boot_time') as mock_check_boot_time:
        mock_check_boot_time.return_value = None
        action_kwargs = None
        original_connection_timeout = None
        assert ActionModule.validate_reboot(mock_check_boot_time, action_kwargs, original_connection_timeout) == None

    # Test with action_kwargs = None
    # with patch.object(ActionModule, 'check_boot_time') as mock_check_boot_time:
    #     mock_check_boot_time.return_value = None
    #    

# Generated at 2022-06-21 02:37:57.640120
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    test_class = ActionModule()
    test_class.ACTION_WARNINGS = {}
    test_class.ACTION_DEPRECATED_ARGS = {}
    test_class.ACTION_DEPRECATED_EXCLUDE_ARGS = {}
    test_class.ACTION_REPLACED_ARGS = {}
    test_class.ACTION_REQUIRED_ARGS = {}
    test_class._supports_check_mode = True
    test_class._supports_async = True
    test_class.action = None
    test_class.alias = 'reboot'
    test_class.plugin_name = 'reboot'
    test_class.current_file_name = __file__
    test_class.action_loader = ActionLoader()

# Generated at 2022-06-21 02:38:05.423397
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    test_action_module = ActionModule(name=__name__)
    # test that reboot command fails
    test_connection = Connection()
    test_play_context = PlayContext()
    test_task_vars = dict()
    test_task = Task()
    test_action_module._connection = test_connection
    test_action_module._play_context = test_play_context
    test_action_module._task = test_task
    test_distribution = 'test'
    test_test_command = 'true'.encode('utf-8')
    test_action_module.DEFAULT_TEST_COMMAND = test_test_command
    test_reboot_command = 'false'.encode('utf-8')
    test_action_module.DEFAULT_REBOOT_COMMAND = test_reboot_

# Generated at 2022-06-21 02:38:08.883795
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    try:
        raise TimedOutException('test')
    except TimedOutException as e:
        assert str(e) == 'test'



# Generated at 2022-06-21 02:38:09.881760
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:38:14.845968
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    """
    Test shutdown_command parameter as specified in documentation.
    """
    am = init_mock(ActionModule, ['get_distribution'])
    am.get_distribution.return_value = 'RedHat'
    args = {'shutdown_command_args': '-f'}
    assert am.get_shutdown_command_args('RedHat') == '-f'


# Generated at 2022-06-21 02:38:21.136030
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    # FUTURE: delete this test or be prepared to maintain it
    action = ActionModule({'action': {'deprecated_args': {}}})
    for a in action.DEPRECATED_ARGS:
        setattr(action._task.args, a, 'dummy')


# Generated at 2022-06-21 02:38:22.535898
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    pass


# Generated at 2022-06-21 02:38:24.359321
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    pass


# Generated at 2022-06-21 02:39:04.560658
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    task_vars={}
    module=ActionModule()
    module_args={'action':'reboot'}
    distribution={'name': 'Fedora'}
    module._task=Task(name='reboot', task_args=module_args)
    module._task.action='reboot'
    module._task.args={'shutdown_command': 'sudo /sbin/shutdown'}

    # test with only a shutdown_command kwarg specified
    expected_shutdown_command = 'sudo /sbin/shutdown'
    assert module.get_shutdown_command(task_vars, distribution) == expected_shutdown_command
    assert module._task.args['shutdown_command'] == expected_shutdown_command

    # test with only a distribution specified (default: linux)
    module._task.args={}


# Generated at 2022-06-21 02:39:17.954535
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    action_module = ActionModule(
        task={'action': 'Reboot'}, 
        connection={'transport': 'ssh'}, 
        #play_context={'check_mode': False},
        task_vars=dict(ansible_distribution='Debian')
    )
    action_module._task.args.update(
        reboot_timeout=30,
        reboot_timeout_sec=30,
        reboot=True,
        test_command='whoami',
    )
    action_module.post_reboot_delay = 0
    action_module._low_level_execute_command = MagicMock(return_value=dict(
        rc=0,
        stdout=b'',
        stderr=b'',
    ))

# Generated at 2022-06-21 02:39:30.228523
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    mock_task = MagicMock(name='mock_task')
    mock_task._connection = MagicMock(name='mock_task._connection')
    mock_task._connection.reset = MagicMock(name='mock_task._connection.reset')
    mock_task._connection.get_option.return_value = MagicMock(name='mock_task._connection.get_option.return_value')
    mock_task._connection.set_option = MagicMock(name='mock_task._connection.set_option')
    mock_task._connection.transport = MagicMock(name='mock_task._connection.transport')
    mock_task._play_context = MagicMock(name='mock_task._play_context')

# Generated at 2022-06-21 02:39:36.598195
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    # Arrange
    action_module = ActionModule(None, None, None, None)

    # Act
    instance = action_module.run_test_command()

    # Assert
    assert_is_not_none(instance)


# Generated at 2022-06-21 02:39:42.182732
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    try:
        raise TimedOutException("not implemented")
    except TimedOutException as e:
        assert "not implemented" in e.args[0], "Error message should be 'not implemented'"


# Generated at 2022-06-21 02:39:44.369583
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
  am = ActionModule()
  am.check_boot_time("")


# Generated at 2022-06-21 02:39:47.828354
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # This would be a good place for unit test code
    print("Unit test for method check_boot_time of class ActionModule")
    pass


# Generated at 2022-06-21 02:39:49.861773
# Unit test for constructor of class ActionModule
def test_ActionModule():
    response = ActionModule()
    assert response is not None


# Generated at 2022-06-21 02:39:59.500807
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule('setup', dict(distribution='test', test_command='test'), None, None, None, None, None)
    assert action.post_reboot_delay == 0
    assert action.DEFAULT_REBOOT_TIMEOUT == 600
    assert action.DEFAULT_CONNECT_TIMEOUT == 5
    assert action.DEFAULT_SUDOABLE is True
    assert action.BOOT_TIME_COMMANDS.get('DEFAULT_BOOT_TIME_COMMAND') == "uptime -s"
    assert action.TEST_COMMANDS.get('DEFAULT_TEST_COMMAND') == "uname -s"
    assert action.TEST_COMMANDS.get('Solaris') == "uname -s"

# Generated at 2022-06-21 02:40:10.210484
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    print("test_ActionModule_perform_reboot")

    task_vars = {}
    distribution = 'shanghai'
    action = ActionModule(task=task_vars, connection=None, play_context=None)
    action.get_shutdown_command_args(distribution)
    action.get_shutdown_command(task_vars, distribution)

    result = action.perform_reboot(task_vars, distribution)

    assert result['rc'] == 0
    assert result['changed'] == True
    assert result['rebooted'] == True
    assert result['failed'] == False



# Generated at 2022-06-21 02:41:02.619280
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    pass


# Generated at 2022-06-21 02:41:08.514941
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    # Parameters
    # distribution: -
    # original_connection_timeout: -
    # action_kwargs: -
    # testActionModule = ActionModule(ansible_version, distribution, previous_boot_time)

    assert False, "Test not implemented"

# Generated at 2022-06-21 02:41:17.267803
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Arrange
    task_vars = {'ansible_fqdn': 'localhost'}
    am = ActionModule(connection=None, action=None, task=None)

    # Act
    result = am.get_shutdown_command(task_vars)

    # Assert
    assert result == '/sbin/shutdown'


# Generated at 2022-06-21 02:41:23.876146
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # init test method vars
    file_name = ""
    file_path = ""
    task_vars = {}
    module_utils = None
    action = "reboot"
    action_plugin = ""
    action_plugin_args = []
    task_vars['ansible_facts'] = {}

    # prepare call args and call method
    am = ActionModule(file_name, file_path, task_vars, module_utils, action, action_plugin, action_plugin_args)
    am.run_command = MagicMock()
    am.run_command.return_value = {'stdout': "CentOS Linux release 7.2.1511 (Core) ", 'rc': 0}
    ret_value = am.get_distribution(task_vars)

    # evaluate test results

# Generated at 2022-06-21 02:41:29.685798
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None

# Unit tests for method ActionModule.get_distribution

# Generated at 2022-06-21 02:41:30.381538
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    pass

# Generated at 2022-06-21 02:41:36.992300
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    reboot_task = {'action': 'reboot', 'tags': [], 'when': [], 'args': {'connect_timeout_sec': 5, 'test_command': 'whoami', 'connect_timeout': 5}}
    mock_task = Mock()
    mock_task.action = reboot_task['action']
    mock_task._ansible_check_mode = False
    mock_task.args = reboot_task['args']
    mock_task.tags = reboot_task['tags']
    mock_task.when = reboot_task['when']
    mock_task.register = None
    mock_task.notify = None
    mock_task.run_once = None
    mock_task._async_val = False
    reboot_play_context = MOCK_BASE_PLAY_CONTEXT
    mock_task._play_context

# Generated at 2022-06-21 02:41:47.172742
# Unit test for method validate_reboot of class ActionModule

# Generated at 2022-06-21 02:41:57.804969
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    mod = sys.modules[ActionModule.__module__]
    action = ActionModule(connection=MagicMock())
    action.DEFAULT_REBOOT_TIMEOUT = 20
    action.get_distribution = MagicMock()
    action.get_distribution.return_value = ''
    action._task.action = 'reboot'
    action._task.args = {}
    action._connection = MagicMock()
    action._connection.get_option.side_effect = lambda o: o == 'connection_timeout' and 10 or None
    action._connection.set_option.return_value = None
    action._connection.reset.return_value = None
    action._play_context = MagicMock()
    action._play_context.check_mode = False

# Generated at 2022-06-21 02:42:00.880623
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    try:
        raise TimedOutException('test')
    except TimedOutException:
        pass



# Generated at 2022-06-21 02:43:53.578250
# Unit test for constructor of class ActionModule
def test_ActionModule():
    with pytest.raises(TypeError) as excinfo:
        am = ActionModule(None, None, None)
    assert 'argument must be a PlayContext object' in str(excinfo)



# Generated at 2022-06-21 02:43:59.054206
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    action_module = ActionModule()

    # Assign the arguments
    task_vars = dict()
    task_vars['ansible_facts'] = dict()
    task_vars['ansible_facts']['distribution'] = 'Ubuntu'

    # Call method
    shutdown_command = action_module._get_shutdown_command(task_vars, 'Ubuntu')

    # Check values
    assert shutdown_command == '/sbin/shutdown'


# Generated at 2022-06-21 02:44:09.055769
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = AnsibleModule(
        argument_spec=dict(
            test_command=dict(required=False, type='str'),
            reboot_timeout=dict(required=False, type='int'),
            connect_timeout=dict(required=False, type='float'),
            pre_reboot_delay=dict(required=False, type='int'),
            post_reboot_delay=dict(required=False, type='int')
        )
    )

    task = Task()
    task._ds = dict()
    task._ds['action'] = "reboot"
    task._ds['set_facts'] = dict()
    task._ds['until_timeout'] = 10
    task._ds['changed_when'] = []

    am = ActionModule(task, module.params, module)
    #am.run()
    am.get_

# Generated at 2022-06-21 02:44:19.481655
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    # Declaring ActionModule object
    # and executing run method against it for the following test scenario:
    # test scenario:
    """

    # Declare and initialize the required variables
    my_object = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)
    my_object.post_reboot_delay = 1
    my_object.DEFAULT_SUDOABLE = True
    my_object.DEFAULT_CONNECT_TIMEOUT = 1
    my_object.DEFAULT_REBOOT_TIMEOUT = 1
    my_object.DEFAULT_POST_REBOOT_DELAY = 1
    my_object.VALID_DISTRIBUTIONS = {'Linux': {}}
    my_object.TEST_COMMANDS = {'Linux': {}}
    my_

# Generated at 2022-06-21 02:44:30.721275
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    from ansible.utils.unsafe_proxy import UnsafeProxy
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible import context
    import ansible.constants as C

    class TestClass:
        def __init__(self):
            # These are needed to set up the task being tested.
            self.variable_manager = VariableManager()
            self.loader = DataLoader()
            self.options = context.CLIOptions()
            self.options.connection = 'ssh'
            self.options.module_path = ''

# Generated at 2022-06-21 02:44:35.691857
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():

    # fake expected sysinfo
    sysinfo = {'distribution': 'ubuntu',
               'distribution_release': '14.04.5',
               'distribution_version': '14.04'}
    expected_result = '2017-01-17 05:03:31.000000'

    # create a ActionModule object with fake method
    am = ActionModule()
    am.get_system_facts = lambda: sysinfo

    # fake method to test the result
    def low_level_execute_command(cmd, sudoable=False):
        return {'stdout': expected_result,
                'stderr': '',
                'rc': 0}

    am._low_level_execute_command = low_level_execute_command

    # call method

# Generated at 2022-06-21 02:44:38.987809
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    try:
        raise TimedOutException('Test Exception')
    except TimedOutException as e:
        assert e.args[0] == 'Test Exception'
        assert str(e) == 'Test Exception'



# Generated at 2022-06-21 02:44:40.463896
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    pass


# Generated at 2022-06-21 02:44:42.928548
# Unit test for constructor of class TimedOutException
def test_TimedOutException():

    ex = TimedOutException()
    assert True



# Generated at 2022-06-21 02:44:49.413713
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    print("test_run_test_command: start")
    # Create object for class ActionModule
    obj_ActionModule = ActionModule()
    # Create a fake distribution for the object of class ActionModule
    distribution_fake = "Linux"
    # invoke run_test_command method of class ActionModule.
    result = obj_ActionModule.run_test_command(distribution_fake)
    print("test_run_test_command: end")
