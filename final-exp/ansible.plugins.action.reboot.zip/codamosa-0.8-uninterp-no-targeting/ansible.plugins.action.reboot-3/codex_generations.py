

# Generated at 2022-06-21 02:37:41.248355
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    with patch('ansible_collections.notmintest.not_a_real_collection.plugins.modules.system.reboot.ActionModule._get_distribution_from_facts', return_value='DEBIAN9'):
        action = ActionModule()
        result = action.get_distribution(dict(ansible_facts=dict(distribution='DEBIAN9')))
    assert result == 'DEBIAN9'


# Generated at 2022-06-21 02:37:52.487524
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    from ansible.modules.system.reboot import ActionModule
    from ansible.module_utils.basic import AnsibleModule

    class FakeModule:
        def __init__(self, pseudo_args):
            self._task = pseudo_args

    class FakePlayContext:
        def __init__(self):
            self.check_mode = False
            self.verbosity = 0

    class FakeTask:
        def __init__(self, pseudo_args):
            self.args = pseudo_args

    class FakeAnsibleModule:
        def __init__(self, pseudo_args):
            self.params = pseudo_args

        def exit_json(self, pseudo_args):
            pass

        def fail_json(self, pseudo_args):
            pass


# Generated at 2022-06-21 02:38:01.356351
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    boot_time_command = 'date -d "$(awk -F. \'{print $1}\' /proc/uptime) second ago" +%F %T'
    distribution = 'DEFAULT_BOOT_TIME_COMMAND'
    actionmodule = ActionModule()
    actionmodule.perform_reboot = {}
    actionmodule.validate_reboot = {}
    actionmodule.run_test_command = {}
    actionmodule.check_boot_time = {}
    actionmodule.do_until_success_or_timeout = {}
    actionmodule.assertEqual(actionmodule.get_system_boot_time(distribution), boot_time_command)


# Generated at 2022-06-21 02:38:04.184907
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    try:
        raise TimedOutException()
    except TimedOutException:
        pass



# Generated at 2022-06-21 02:38:11.149440
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # Create an instance of the class to be tested
    test_instance = ActionModule()
    # Prepare the arguments that would be sent to the method
    task_vars = None

    # Run the method with the sent arguments
    result = test_instance.get_distribution(task_vars)

    # Assert the result
    assert result == 'DEFAULT'


# Generated at 2022-06-21 02:38:23.557421
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    action_module = ActionModule()
    test_task_vars = {
        'ansible_facts': {
            'distribution': 'RedHat',
            'distribution_version': '7.6'
        }
    }
    action_module._task.args = {'shutdown_command': '/bin/sshutdown'}
    action_module._task.action = "reboot"
    action_module._connection = Mock()
    test_result = action_module.get_shutdown_command(test_task_vars, 'RedHat')
    assert test_result == '/bin/sshutdown'

# Generated at 2022-06-21 02:38:26.525064
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    test_object = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert test_object.validate_reboot(distribution='CentOS', original_connection_timeout=None, action_kwargs={'previous_boot_time': previous_boot_time}) == {'rebooted': True, 'failed': False, 'changed': True}

# Generated at 2022-06-21 02:38:33.852256
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():

    # Create instance of class ActionModule
    action_module_instance = ActionModule()

    # Create Mock of distribution
    distribution = Mock()

    # Call method get_shutdown_command_args of class ActionModule
    result = action_module_instance.get_shutdown_command_args(distribution)

    # Try to assert parameters are equal
    assert isinstance(result, str)


# Generated at 2022-06-21 02:38:35.094448
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    exc = TimedOutException()
    assert isinstance(exc, Exception)



# Generated at 2022-06-21 02:38:43.287664
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Configure mock parameters and results
    mock_task = MagicMock()
    mock_task.action = 'reboot'
    mock_task.args = {'connect_timeout': 120, 'post_reboot_delay': 0, 'reboot_timeout': 1200}
    mock_task.async_val = 3
    mock_task.check_mode = False

    # Mock module
    mock_task_vars = MagicMock()
    mock_task_vars.copy = MagicMock()

    mock_play_context = MagicMock(check_mode=False)
    mock_play_context.check_mode = False

    # Mock module
    mock_new_module_args = {'_ansible_check_mode': False, '_ansible_diff': False, '_ansible_no_log': False}



# Generated at 2022-06-21 02:39:17.241062
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    hostvars = HostVars({'ansible_distribution': 'DISTRIBUTION', 'ansible_distribution_version': 'VERSION'})
    action_module = ActionModule({})
    assert action_module.get_distribution(hostvars) == 'DISTRIBUTION VERSION'


# Generated at 2022-06-21 02:39:29.921161
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    class ActionModule(object):
        _task={'args':{}}

    action_mod=ActionModule()

    def get_distro(distro):
        class Distro(object):
            id=distro
            name=''

        class Facts(object):
            ansible_distribution=Distro()

        class TaskVars(object):
            ansible_facts=Facts()

        return TaskVars()

    # Test the get_distribution method is able to detect the following Linux distros

# Generated at 2022-06-21 02:39:40.951167
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    # ARRANGE
    #
    # - create a mock object to replace the local connection
    class Connection(object):
        def __init__(self, *args, **kwargs):
            self._args = args
            self._kwargs = kwargs
        def set_option(self, *args, **kwargs):
            self._args = args
            self._kwargs = kwargs
        def reset(self):
            pass
        def get_option(self, *args, **kwargs):
            return self._args
    #
    # - create a mock object to replace the local task
    class Task(object):
        def __init__(self, *args, **kwargs):
            self._args = args
            self._kwargs = kwargs
    #
    # - create a mock object to replace the local play_

# Generated at 2022-06-21 02:39:42.061753
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    assert True

# Generated at 2022-06-21 02:39:50.960252
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    AM = ActionModule(None)
    AM.DEFAULT_SUDOABLE = True
    AM.DEFAULT_CONNECT_TIMEOUT = 5
    AM.post_reboot_delay = 120
    AM._task = Mock()
    class MockConnection:
        def __init__(self, transport, runner):
            self.transport = transport
            self.runner = runner
    # Use an alternate connection type with a lower timeout
    AM._connection = MockConnection('netconf', Mock(default_transport='netconf'))
    test_data = {
        'task_vars': {
            'ansible_connection': 'netconf'
        },
        'distribution': 'Linux'
    }
    with pytest.raises(RuntimeError):
        result = AM.perform_reboot(**test_data)

#

# Generated at 2022-06-21 02:39:57.268156
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module = ActionModule()
    action_module.connection = None
    action_module.task = None
    action_module.play_context = None
    action_module._task.action = 'Reboot'

    with pytest.raises(ValueError) as error:
        action_module.check_boot_time()

    assert 'boot time has not changed' in str(error)

# Generated at 2022-06-21 02:40:10.657756
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    class ActionModule(Reboot):
        def __init__(self, *args, **kwargs):
            self.called_action = None
            self.called_action_args = None
            self.called_action_kwargs = None

        def action(self, *args, **kwargs):
            self.called_action = "action"
            self.called_action_args = args
            self.called_action_kwargs = kwargs

    mock_task = Mock()
    mock_task.action = "action"
    mock_task.args = {'action': "action"}
    action_module = ActionModule(mock_task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module.called_action = None
    assert action_module

# Generated at 2022-06-21 02:40:12.172422
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule()
    assert m != None

# Generated at 2022-06-21 02:40:16.466891
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    module = ActionModule()
    reboot_result = ActionModule.check_boot_time(module, 'reboot_result', 'distribution')
    return reboot_result

# Generated at 2022-06-21 02:40:20.044344
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    a = ActionModule(task=object, connection=object, play_context=object, loader=object, templar=object, shared_loader_obj=None)
    assert a.run_test_command(None) == None

# Generated at 2022-06-21 02:41:25.669762
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    target_obj = ActionModule(None, dict(action=None), task_uuid=None, is_conditional=False, is_handler=False, has_loop=False, has_async=False, is_async_task=False, is_include=False, include_params=None, is_role=False, role_name=None, role_params=None)
    task_vars = dict()

    distribution = 'arch'

    # Test with good value for distribution
    new_return = target_obj.get_shutdown_command(task_vars, distribution)
    assert new_return is not None

    # Test with good value for distribution
    distribution = 'debian'
    new_return = target_obj.get_shutdown_command(task_vars, distribution)
    assert new_return is not None

    # Test

# Generated at 2022-06-21 02:41:34.723740
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # mock the ansible connection so that we can return our own values
    mock_task = MagicMock()
    mock_task.args.get.return_value = 'shutdown_command'
    mock_task.action = 'reboot'
    mock_ansible_connection = MagicMock()
    mock_ansible_connection.transport = 'ssh'

    # Mock isinstance check as it's needed to return a value in the get_system_shutdown_command method
    with patch('ansible_collections.notmintest.not_a_real_collection.plugins.modules.reboot.isinstance', return_value=True) as mock_isinstance:

        # Define the mock return values for the methods needed
        mock_ansible_connection.run.return_value = dict(stdout='shutdown_command', rc=0)


# Generated at 2022-06-21 02:41:46.446745
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # Unit test for get_distribution
    # This is called by the get_shutdown_command, so it is important to test it.
    # Arbitrary values chosen to test the method.
    # First test: REBOOT_DISTRIBUTION_MAP should return the expected distribution
    task_vars = {
        'ansible_default_ipv4': {
            'address': '192.168.1.1'
        },
        'ansible_facts': {
            'distribution': 'RedHat',
            'distribution_major_version': '42',
        }
    }

    # This is a mock, so we can set our own return value
    class MockConnection:
        def get_option(self, option_name):
            if option_name == 'gather_subset':
                return ['all']
            return

# Generated at 2022-06-21 02:41:57.527639
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
  import datetime
  test_action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
  assert callable(getattr(test_action_module, "do_until_success_or_timeout", None))
  test_action = Mock()
  test_action_desc = "test_action_desc"
  test_reboot_timeout = int()
  test_distribution = "test_distribution"
  test_action_kwargs = dict()

# Generated at 2022-06-21 02:42:08.724169
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    action = ActionModule()
    action.post_reboot_delay = 0

    class ShutdownCommand(object):
        def __init__(self):
            self.rc = 0

        def __call__(self, *args, **kwargs):
            return self.rc

    shutdown_command_object = ShutdownCommand()
    action.get_shutdown_command = lambda *args, **kwargs: shutdown_command_object

    class MockTask(object):
        def __init__(self):
            self.args = {}

    class MockPlayContext(object):
        def __init__(self):
            pass

        def check_mode(self):
            return False

    class MockRunner(object):
        def __init__(self):
            self._connection = None


# Generated at 2022-06-21 02:42:20.355221
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    task_vars = dict()
    module_arm = ActionModule(dict(), connection=MagicMock())
    # Perform test on method perform_reboot
    # 1. Default values
    # 2. Custom values
    task_vars = dict()
    module_arm = ActionModule(dict(), connection=MagicMock())
    task_vars['ansible_distribution'] = "Kali"
    # Perform test on method perform_reboot
    # 1. Default values
    # 1.1. Permission denied error
    module_arm.DEFAULT_SUDOABLE = True
    module_arm._low_level_execute_command = MagicMock(return_value={'rc': 1, 'stdout': "", 'stderr': "Permission denied"})

# Generated at 2022-06-21 02:42:24.089208
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module_class_obj = ActionModule()
    distribution = ""
    assert(action_module_class_obj.get_shutdown_command_args(distribution) == "now")


# Generated at 2022-06-21 02:42:37.315498
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    hostname = '127.0.0.1'
    port = 22
    task_vars = {'ansible_ssh_host': hostname, 'ansible_ssh_port': port, 'ansible_ssh_pass': 'password'}
    file_name = 'mock_file'
    file_args = ['./{0}'.format(file_name)]
    task_args = {'reboot_timeout': 600}
    tmp = '/tmp'
    connection = 'ssh'
    play_context = PlayContext()
    task = Task()
    action_plugin = ActionModule()


# Generated at 2022-06-21 02:42:45.328777
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
  param0 = 1
  param1 = 2
  action = []
  desc = []
  reboot_timeout = 1
  distribution = []
  action_kwargs = {}
  obj = ActionModule()
  result = obj.do_until_success_or_timeout(param0,param1,action,desc,reboot_timeout,distribution,action_kwargs)
  assert result is None

# Generated at 2022-06-21 02:42:51.394124
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
  # Grab ActionModule instance and directly test get_shutdown_command_args
    am = global_setup_test()
    distro = am.get_distribution('Ubuntu')
    am.get_shutdown_command_args(distro)
    return

# Generated at 2022-06-21 02:45:02.557941
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
  action = ActionModule(task=dict(action='setup'), connection=dict(transport='ssh'))
  action._connection.reset = mock.MagicMock()
  action._connection.reset.return_value = None
  action._low_level_execute_command = mock.MagicMock()
  action._low_level_execute_command.return_value = dict(rc=0, stdout=b'', stderr=b'')
  assert action.check_boot_time(distribution=None, previous_boot_time=None) is None


# Generated at 2022-06-21 02:45:12.637061
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # initializations
    test_action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    test_action_module._task = MagicMock()
    test_action_module._task.action = 'reboot'
    test_action_module._task.args = {}
    test_action_module._task.args.get = MagicMock(return_value=None)
    test_action_module._task.action = 'reboot'
    test_action_module.get_distribution = MagicMock(return_value='RedHat')
    test_action_module._low_level_execute_command = MagicMock(return_value={'rc': 0, 'stdout': 'shutdown', 'stderr': ''})


# Generated at 2022-06-21 02:45:15.837545
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    cls = ActionModule
    assert cls.check_boot_time(cls, 'Ubuntu 18.04 LTS') is not None

# Generated at 2022-06-21 02:45:21.328032
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = am.run(tmp, task_vars)
    assert isinstance(result, dict)
    assert result['changed'] == False
    assert result['rebooted'] == False
    assert result['failed'] == True
    assert result['msg'] == 'Running reboot with local connection would reboot the control node.'



# Generated at 2022-06-21 02:45:25.380526
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module

# Generated at 2022-06-21 02:45:34.601823
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action_module = ActionModule(task=Mock(), connection=Mock(), play_context=Mock(), loader=Mock(), templar=Mock(), shared_loader_obj=Mock())
    # Expected failure when no args are set
    result = action_module.deprecated_args()
    assert result is None

    # Set test args
    action_module._task.args = {'test': 'test'}

    # Failure when args don't match any in dict
    result = action_module.deprecated_args()
    assert result is None

    # Set action to match one in dict
    action_module._task.action = 'reboot'
    # Set args to match one in dict
    action_module._task.args = {'pre_reboot_delay': 0}
    # Test for deprecation warning

# Generated at 2022-06-21 02:45:35.269309
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    pass



# Generated at 2022-06-21 02:45:37.723766
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    boot_result = action_module.check_boot_time('distribution', 'previous_boot_time')
    assert boot_result == None


# Generated at 2022-06-21 02:45:39.156598
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # this needs to be implemented
    pass

# Generated at 2022-06-21 02:45:42.603637
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    try:
        raise TimedOutException('test_TimedOutException')
    except TimedOutException:
        pass

