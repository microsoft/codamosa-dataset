

# Generated at 2022-06-21 02:37:41.528198
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.plugins.action.reboot import ActionModule
    from ansible.module_utils.connection import Connection
    from ansible.playbook import PlayContext
    from ansible.playbook.task import Task

    connection = Connection(None)
    context = PlayContext()
    task = Task()
    context.become = False
    action = ActionModule(task, connection, context, '/tmp', False, None)

    assert action.check_boot_time('debian', '') == None

# Generated at 2022-06-21 02:37:48.488699
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    from ansible.executor.task_result import TaskResult
    from ansible.plugins.action.reboot import ActionModule
    from ansible.plugins.action.reboot import TimedOutException
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    import os
    import tempfile

    display = Display()
    filename = tempfile.mkstemp()

    # Generate some variables
    # Use them later when executing tasks

# Generated at 2022-06-21 02:37:55.872580
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module = ActionModule(None, None, None, None)
    distribution_name = 'test_distribution'
    distribution_name_not_found = 'test_distribution_not_found'
    expected_args = 'test_args'
    expected_args_not_found = 'test_args_not_found'
    args = action_module.get_shutdown_command_args(distribution_name)
    assert args == expected_args, args
    args = action_module.get_shutdown_command_args(distribution_name_not_found)
    assert args == expected_args_not_found, args

# Generated at 2022-06-21 02:38:04.294182
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task_vars = dict(
        ansible_facts=dict(
            distribution_facts=dict(
                distro=dict(
                    id='test-distro-id'
                )
            )
        )
    )

    mock_task = mock.MagicMock()
    mock_task.action = 'test-action'
    mock_task.async_val = 43200
    mock_task.notify = ['test-handler']
    mock_task.args = dict(
        test_command='echo I_AM_A_TEST_COMMAND'
    )

    mock_connection = mock.MagicMock()
    mock_connection.transport = 'test-connection'

    mock_play_context = mock.MagicMock()
    mock_play_context.timeout = 5

# Generated at 2022-06-21 02:38:09.107427
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    # Execute method under test
    ActionModule(task={"None": "None"}, connection={"None": "None"}, play_context={"None": "None"}).get_system_boot_time("None")


# Generated at 2022-06-21 02:38:22.636181
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    class args(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)
    _action_module = ActionModule()
    _action_module.DEFAULT_REBOOT_TIMEOUT = 3600

    #======================================================================================
    # A mocked version of the get_system_boot_time method
    #======================================================================================
    def _get_boot_time(distribution, previous_boot_time=None, rebooted=True):
        if rebooted:
            return  previous_boot_time
        else:
            return datetime.now()


# Generated at 2022-06-21 02:38:29.030147
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    """
    [Unit Test] ActionModule.do_until_success_or_timeout
    """
    unittest.TestCase.assertTrue(ActionModule.do_until_success_or_timeout, "Method 'do_until_success_or_timeout'")


# Generated at 2022-06-21 02:38:39.451294
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up mock objects
    task = MockTask()
    task.action = 'reboot'
    task.async_val = 5
    task.args = {'reboot_timeout': 900,
                 'connect_timeout': 30,
                 'msg': 'Initializing reboot',
                 'post_reboot_delay': 0,
                 'reboot_timeout_sec': 900}

    conn = MockConnection()
    conn.transport = 'ssh'

    play_context = MockPlayContext()
    play_context.check_mode = False

    action_module = ActionModule(task, conn, play_context)

    task_vars = {}

    # Mock methods

# Generated at 2022-06-21 02:38:44.655615
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    '''Unit test with mock objects'''
    # set up mock objects
    mock_self = mock.MagicMock()
    mock_self.get_distribution.return_value = "RedHat"
    mock_task_vars = {}

    # run test
    test_result = ActionModule.get_distribution(mock_self, mock_task_vars)

    # assert results
    assert test_result == "RedHat"
    mock_self.get_distribution.assert_called_once_with(mock_task_vars)


# Generated at 2022-06-21 02:38:53.892666
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    my_obj = ActionModule(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    my_obj._task = AttrDict()
    my_obj._task.action = "random"

    distribution = "random"
    my_result = my_obj.get_shutdown_command_args(distribution)
    assert my_result is None


# Generated at 2022-06-21 02:39:31.379473
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    from ansible.module_utils import basic

    # Stub for class ActionModule
    class ActionModuleStub(basic.AnsibleModule):
        pass

    # Stub for class AnsibleConnectionFailure
    class AnsibleConnectionFailureStub(Exception):
        pass

    def check_boot_time(distribution, previous_boot_time):
        raise ValueError("boot time has not changed")

    module_stub = ActionModuleStub(argument_spec={})

    # Stub for class ActionModule

# Generated at 2022-06-21 02:39:33.352642
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # test_module = ActionModule()

    # result = test_module.get_shutdown_command()
    pass


# Generated at 2022-06-21 02:39:36.639335
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action = ActionModule()
    assert action.get_shutdown_command_args('redhat') == '-t 1 -r now'


# Generated at 2022-06-21 02:39:41.537422
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    """
    Constructor of class TimedOutException()
    :return:
    """
    exception = TimedOutException()
    print(exception)



# Generated at 2022-06-21 02:39:45.552724
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    try:
        raise TimedOutException("Timed out")
    except TimedOutException as e:
        assert isinstance(e, TimedOutException)



# Generated at 2022-06-21 02:39:56.853569
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Create stub for class ActionModule
    class_ActionModule_instance = ActionModule()
    class_ActionModule_instance.get_shutdown_command = mocker.MagicMock(return_value="shutdown")
    class_ActionModule_instance.get_shutdown_command_args = mocker.MagicMock(return_value="-r now")
    class_ActionModule_instance._low_level_execute_command = mocker.MagicMock(return_value=dict(rc=0))
    class_ActionModule_instance._task = dict()

    task_vars = dict()
    distribution = mocker.MagicMock()
    result = class_ActionModule_instance.perform_reboot(task_vars, distribution)


# Generated at 2022-06-21 02:40:00.054646
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    #ActionModule.get_shutdown_command_args(distribution)
    assert False # TODO: implement your test here


# Generated at 2022-06-21 02:40:12.113434
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    module = ActionModule()
    counter = 1

    def action_success():
        return counter

    # test with no kwargs
    module.do_until_success_or_timeout(action=action_success,
                                       action_desc="",
                                       reboot_timeout=10)

    # test with kwargs
    module.do_until_success_or_timeout(action=action_success,
                                       action_desc="",
                                       reboot_timeout=10,
                                       action_kwargs={})

    def action_fail():
        raise Exception

    with pytest.raises(Exception):
        # test with no kwargs
        module.do_until_success_or_timeout(action=action_fail,
                                           action_desc="",
                                           reboot_timeout=10)

# Generated at 2022-06-21 02:40:22.847248
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    host_name = '172.16.2.109'
    port_num = 22
    ssh_user = 'root'
    ssh_pass = 'example'
    sudo_pass = ''


# Generated at 2022-06-21 02:40:33.785392
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # create instance of ActionModule class
    action_module_instance = ActionModule()
    assert_equal(action_module_instance.perform_reboot(task_vars, distribution), result, msg="Reboot command failed. Error was: '{stdout}, {stderr}'".format(stdout=to_native(reboot_result['stdout'].strip()),stderr=to_native(reboot_result['stderr'].strip())))

# Generated at 2022-06-21 02:41:14.033896
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    import mock
    import tempfile

    # Create an instance of AnsibleModule mock object to be used in the unit test function
    AM = AnsibleModuleMock()

    # Instantiate action class under test
    A = ActionModule(AM, dict(ANSIBLE_MODULE_ARGS={'test_command': 'echo hello'}))

    # Return a success result when calling the execute_command method of the A.connection mock object
    A.connection.execute_command.return_value = dict(rc=0, stdout='hello', stderr='', stdin=tempfile.TemporaryFile, start_time=datetime.datetime.now(), end_time=datetime.datetime.now())

    # Execute test function
    A.run_test_command('UNKNOWN')

    # Assert that function is executed as expected

# Generated at 2022-06-21 02:41:16.664027
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    try:
        raise TimedOutException()
    except TimedOutException:
        pass



# Generated at 2022-06-21 02:41:25.830240
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action = ActionModule()
    action.connection = Connection()

    assert action.get_distribution({}) == 'DEFAULT'
    assert action.get_distribution({'ansible_distribution': 'test'}) == 'test'
    assert action.get_distribution({'ansible_distribution_version': '1'}) == 'DEFAULT'
    assert action.get_distribution({'ansible_distribution': 'RedHat', 'ansible_distribution_version': '1'}) == 'RedHat'
    assert action.get_distribution({'ansible_distribution': 'RedHat', 'ansible_distribution_version': '5'}) == 'RedHat5'

# Generated at 2022-06-21 02:41:31.037224
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    test_class = ActionModule(None, None, run_once=True)
    test_class._low_level_execute_command = mock.MagicMock(return_value={'rc': 0, 'stderr': '', 'stdout': ''})
    test_class.run_test_command(None)



# Generated at 2022-06-21 02:41:45.194024
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Create an instance of class ActionModule
    action_module = ActionModule(
        task=dict(
            action=dict(
                reboot=dict(
                    post_reboot_delay=0
                )
            )
        ),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )
    # Create a mock of class Connection
    connection = mock.Mock()
    # Set the attribute connection of the instance of class ActionModule
    action_module._connection = connection
    # Create a mock of class Task
    task = mock.Mock()
    # Set the attribute _task of the instance of class ActionModule
    action_module._task = task
    # Create a mock of class PlayContext
    play_context = mock.Mock()

# Generated at 2022-06-21 02:41:46.106532
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    pass

# Generated at 2022-06-21 02:41:50.888503
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    """Test constructor of class TimedOutException"""
    try:
        raise TimedOutException('Test')
    except TimedOutException as e:
        assert 'Test' == e.message



# Generated at 2022-06-21 02:41:57.625975
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    dist = Distribution({
        'family': 'RedHat',
        'name': 'Fedora',
        'major_version': '22'
    })

    plugin = ActionModule(task=dict(action='reboot'), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    plugin.get_system_login_uid = MagicMock()
    plugin.get_system_login_uid.return_value = '0'

    plugin._connection = MagicMock()
    plugin.get_distribution = MagicMock()
    plugin.get_distribution.return_value = dist()
    plugin.get_shutdown_command = MagicMock()
    plugin.get_shutdown_command.return_value = '/bin/shutdown'

    plugin._task = MagicMock()

# Generated at 2022-06-21 02:42:08.752973
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    class mock_action:
        def __init__(self):
            self.action = 'testing'
            self.args = {
                'test_command': 'success',
            }

    class mock_task:
        def __init__(self):
            self.action = mock_action()

    class mock_ansiblemodule:
        def __init__(self):
            self.params = {
                'test_command': 'success',
            }

        def fail_json(self, results):
            return results

    class mock_ansibleconnection:
        def __init__(self):
            self.connection = mock_ansibleconnection


        def reset(self):
            pass

    class mock_ansibleplaycontext:
        def __init__(self):
            self.check_mode = False
            self.become = True

# Generated at 2022-06-21 02:42:20.761625
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Declare mocks
    class MockConnectionPlugin(object):
        def __init__(self, play_context, new_stdin, *args, **kwargs):
            self.set_options(kwargs)

        def set_options(self, var_options=None):
            self.connection_timeout = None
        def get_option(self, varname):
            return self.connection_timeout
        def close(self):
            return
        def connect(self, port=None, username=None, password=None,
                    private_key_file=None, passphrase=None):
            return
        def execute(self, cmd):
            return dict(stdout='', stderr='', rc=0)
        def put_file(self, in_path, out_path):
            return

# Generated at 2022-06-21 02:43:29.524317
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    """Unit test for ActionModule.run_test_command"""
    module = ActionModule({"name": "reboot", "action": "reboot"}, action_loader, connection_loader)
    module._low_level_execute_command = lambda x, sudoable=True: {"rc": 0, "stdout": "", "stderr": ""}
    module._task.action = "reboot"
    assert module.run_test_command(distribution="Debian") == None
    module._low_level_execute_command = lambda x, sudoable=True: {"rc": 1, "stdout": "", "stderr": ""}
    try:
        module.run_test_command(distribution="Debian")
    except RuntimeError:
        pass
    else:
        raise AssertionError("Expected RuntimeError")
# Unit

# Generated at 2022-06-21 02:43:30.990149
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    pass


# Generated at 2022-06-21 02:43:39.515476
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    rebootmngr = Reboot()
    rebootmngr.check_boot_time = MagicMock()
    rebootmngr.run_test_command = MagicMock()

    distribution = 'redhat'
    original_connection_timeout = 2
    action_kwargs = {'previous_boot_time': 'previous_boot_time'}
    result = rebootmngr.validate_reboot(
        distribution=distribution,
        original_connection_timeout=original_connection_timeout,
        action_kwargs=action_kwargs)
    assert result['rebooted']

# Generated at 2022-06-21 02:43:40.337478
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    raise NotImplementedError()

# Generated at 2022-06-21 02:43:45.901236
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action_module = ActionModule()
    task = Mock()
    task.action = 'reboot'
    task.args = dict(reboot_timeout=60)
    action_module._task = task

    action_module.deprecated_args()


# Generated at 2022-06-21 02:43:51.679463
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    mock_action = ActionModule(None, None, None, None)

    mock_distribution = {'ID': 'fedora', 'NAME': 'Fedora', 'VERSION_ID': '26', 'VERSION': '26 (Workstation Edition)'}

    mock_action.get_system_boot_time(mock_distribution)

    # Test invalid input
    try:
        # No distribution
        mock_action.get_system_boot_time(None)
    except AnsibleError as e:
        assert e.message == 'Unable to determine distribution to get boot time'

    try:
        # Invalid distribution
        mock_action.get_system_boot_time({})
    except AnsibleError as e:
        assert e.message == 'Unable to determine distribution to get boot time'

    # Test custom command
    mock_action.get

# Generated at 2022-06-21 02:43:56.944089
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module = ActionModule()
    distribution = 'centos'  # fake distribution value
    previous_boot_time = ''  # previous boot time is not updated yet
    action_module.check_boot_time(distribution, previous_boot_time)


# Generated at 2022-06-21 02:44:00.186101
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    my_obj =  ActionModule(task=MagicMock(), connection=MagicMock(), play_context=MagicMock())
    distribution = None
    original_connection_timeout = None
    action_kwargs = None
    assert my_obj.validate_reboot(distribution, original_connection_timeout, action_kwargs) == {}
    # test with multiple input parameters



# Generated at 2022-06-21 02:44:07.420637
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    action = AnsibleActionModule(
        {
            'ACTION': 'test_command',
            'ANSIBLE_MODULE_ARGS': {
                'test_command': 'echo "OK"'
            }
        },
        PlayContext()
    )
    try:
        action.run_test_command('fake_dist')
    except Exception as e:
        assert False, "Exception while running test_command: %s" % to_text(e)

# Generated at 2022-06-21 02:44:11.478765
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    testcase = unittest.TestCase()
    classtest = ActionModule.run_test_command(self, distribution='', **kwargs)
    assert classest == None



# Generated at 2022-06-21 02:46:28.909254
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    with pytest.raises(ValueError, match='boot time has not changed'):
        test_action_module = ActionModule(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
        test_action_module.check_boot_time(distribution='', previous_boot_time='')


# Generated at 2022-06-21 02:46:37.928472
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module = ActionModule(
        task=Task(action='Reboot', args={}),
        connection=Connection(play_context=PlayContext(check_mode=False)),
        play_context=PlayContext(check_mode=False),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    # Test with shutdown_command_args not set and distribution not set
    distribution = 'default_distribution'
    shutdown_command_args = action_module.get_shutdown_command_args(distribution)
    assert shutdown_command_args == '/s /t 0'

    # Test with shutdown_command_args set and distribution set (but not used)

# Generated at 2022-06-21 02:46:45.545054
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():

    # action module instance
    am = ActionModule()

    task_vars = {}

    # create mock distribution
    mock_distribution = {
        'name': 'mock_distribution',
        'version': 'mock_version'
    }

    # Perform reboot, success
    result = am.perform_reboot(task_vars, mock_distribution)
    assert result
    assert not result['failed']
    assert result['start']

    # Perform reboot, fail
    with patch.object(am, '_low_level_execute_command', side_effect=Exception('unable to connect to socket')):
        result = am.perform_reboot(task_vars, mock_distribution)
    assert result
    assert result['failed']



# Generated at 2022-06-21 02:46:52.164784
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    task = Task()
    action = ActionModule(task, {})
    task_vars = {
        'ansible_facts': {
            'distribution': 'Ubuntu'
        }
    }
    result = action.get_shutdown_command(task_vars, 'Ubuntu')
    assert result == 'shutdown'
