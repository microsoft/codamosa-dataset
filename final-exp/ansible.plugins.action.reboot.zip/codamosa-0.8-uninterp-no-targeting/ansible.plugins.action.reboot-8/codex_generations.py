

# Generated at 2022-06-21 02:37:39.575351
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # test setup
    action_module = ActionModule()
    task_vars = {}
    distribution = 'DEFAULT'

    # define return values of mocked get_distribution
    def get_distribution(x=None, **kwargs):
        if x == 'arch':
            return 'arch'
        return 'DEFAULT'

    # define return values of mocked get_fact
    def get_fact(x=None, **kwargs):
        if x == 'SHUTDOWN_BIN_PATH':
            return 'shutdown_path'
        return None

    # define return values of mocked find_needle

# Generated at 2022-06-21 02:37:44.565022
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    shutdown_bin = '/sbin/shutdown'
    sut = ActionModule()
    sut.get_shutdown_command({}, 'test_distribution')
    # TODO: Raise not implemented exception

# Generated at 2022-06-21 02:37:49.953832
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    mock_action = Mock(side_effect=[ValueError, ValueError, ValueError, None])
    am = ActionModule()
    am.do_until_success_or_timeout(action=mock_action, action_desc="last boot time check", reboot_timeout=1)
    assert mock_action.call_count == 4


# Generated at 2022-06-21 02:37:56.682307
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    # This method is the part that is being tested so you can replace it with whatever you want for testing

    module = ActionModule()
    assert module.get_shutdown_command_args(None) == module.DEFAULT_SHUTDOWN_COMMAND_ARGS, "Default command args is something unexpected"



# Generated at 2022-06-21 02:38:00.446549
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    
    # Imports
    import pytest
    
    # Setup
    # - execute test method

    # Execute
    Result = ActionModule.validate_reboot('distribution','original_connection_timeout','action_kwargs')
    
    # Verify
    assert Result is not None

# Generated at 2022-06-21 02:38:13.816750
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # build action module task
    action_module_task = {
        'name': 'reboot',
        'action': 'reboot',
        'args': {
        }
    }
    # build task_vars
    task_vars = {
    }
    # build distro value
    distro = "RHEL7"
    # build previous_boot_time value
    previous_boot_time = 'Sun 2015-03-22 00:00:00'
    # build expected result
    expected_result = Exception("boot time has not changed")
    # build ActionModule object
    action_module_object = ActionModule(action_module_task, task_vars)
    # call method check_boot_time with args

# Generated at 2022-06-21 02:38:24.941146
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
  from ansible.module_utils.basic import AnsibleModule
  from ansible.module_utils._text import to_bytes
  from ansible.module_utils.common.process import get_bin_path
  import os

  test_cases = ((to_bytes('centos'), to_bytes('/usr/bin/whoami')),
                (to_bytes('opensuse'), to_bytes('/usr/bin/whoami')),
                (to_bytes('redhat'), to_bytes('/usr/bin/whoami')),
                (to_bytes('ubuntu'), to_bytes('/usr/bin/whoami')),
                (to_bytes('debian'), to_bytes('/usr/bin/whoami')))

  def run_test_command(osfamily, test_command):
    ansible_module = AnsibleModule({})

   

# Generated at 2022-06-21 02:38:29.934072
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():

    # Arrange
    from ansible.module_utils.common.removed import removed

    remove = 'Ansible has removed the feature'

    DEPRECATED_ARGS = {
        'priority': removed,
        'schedule': removed,
        'connect_timeout_sec': removed,
        'reboot_timeout_sec': removed,
        'post_reboot_delay_sec': removed,
    }

    # Act
    display = Display()
    task = MockTask()
    connection = MockConnection()

    action = ActionModule(task, connection, display)
    action.DEPRECATED_ARGS = DEPRECATED_ARGS

    # Assert
    assert action.DEPRECATED_ARGS == DEPRECATED_ARGS

    action.deprecated_args()


# Generated at 2022-06-21 02:38:36.087506
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Fixture - Setup
    test_obj = ActionModule()
    test_vars = {
        'ansible_facts': {
            'os_family': 'Darwin'
        }
    }

    # Exercise
    actual_return_value = test_obj.get_shutdown_command(test_vars, 'Darwin')

    # Verify
    assert actual_return_value == '/sbin/shutdown'


# Generated at 2022-06-21 02:38:44.078386
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    action = ActionModule(task=Task(), connection=Connection(), play_context=PlayContext(), loader=None, templar=None, shared_loader_obj=None)
    action._low_level_execute_command = MagicMock()
    action._low_level_execute_command.return_value = {'rc': 0, 'stdout': 'test_stdout', 'stderr': 'test_stderr'}
    action._task.action = 'test'
    action.DEFAULT_SUDOABLE = False

    action._task.args = {'test_command': 'test_command'}
    action._task.args['test_command'] = 'test_command'

    display.debug = MagicMock()
    display.vvv = MagicMock()
    display.warning = MagicMock()

    # test for exception

# Generated at 2022-06-21 02:39:52.740614
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    arguments = {'reboot_timeout': 30}
    hostvars = {}
    distribution = 'openSUSE'
    ret = ActionModule.get_shutdown_command_args(distribution, arguments)
    hostvars = {'ansible_architecture': 'x86_64', 'ansible_distribution': 'openSUSE', 'ansible_distribution_release': '13.2'}
    distribution = 'openSUSE'
    ret = ActionModule.get_shutdown_command_args(hostvars, distribution)
    distribution = 'FreeBSD'
    ret = ActionModule.get_shutdown_command_args(hostvars, distribution)

# Generated at 2022-06-21 02:39:57.095055
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    actionModule = ActionModule()
    expected_results = '2018'
    actual_results = actionModule.get_system_boot_time("None")
    assert actual_results.find(expected_results) != -1


# Generated at 2022-06-21 02:39:58.858644
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    TimedOutException(msg='Error message')
    TimedOutException()



# Generated at 2022-06-21 02:40:03.916856
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    target = ActionModule(None, None)
    target.get_system_boot_time('ubuntu')
    target.get_system_boot_time('Red Hat')
    target.get_system_boot_time('DEFAULT')

# Generated at 2022-06-21 02:40:15.034601
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    object = ActionModule(None, {}, None, None)
    # 1
    method_input = {
        'DEFAULT_BOOT_TIME_COMMAND': 'uptime',
        'DEFAULT_CONNECT_TIMEOUT': 60,
        'BOOT_TIME_COMMANDS': {
            'RedHat': [
                'uptime'
            ],
            'Arch': [
                'uptime'
            ],
            'Oracle': [
                'uptime'
            ],
            'Debian': [
                'uptime'
            ]
        }
    }
    method_output = '12345'

    def get_system_boot_time_mock(self, distribution):
        return method_output


# Generated at 2022-06-21 02:40:22.108634
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
  task_vars = dict()
  module_args = dict()
  mock_action = dict()
  action_kwargs = dict()
  a = ActionModule(task=task_vars, connection=connection, play_context=play_context, loader=loader, templar=templar, shared_loader_obj=loader_obj)
  a.do_until_success_or_timeout(action=mock_action, action_desc=action_desc, reboot_timeout=reboot_timeout, distribution=distribution, action_kwargs=action_kwargs)
  


# Generated at 2022-06-21 02:40:24.514785
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    b_action = ActionModule(play_context=PlayContext())
    b_action.run()

# Generated at 2022-06-21 02:40:34.521707
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    action_module = ActionModule(
        {'ANSIBLE_MODULE_ARGS': {}},
        task_vars=dict(distribution='redhat', distribution_major_version='7'),
        connection='local',
        play_context=PlayContext(),
        loader=None,
        templar=None,
        shared_loader_obj=None)
    assert action_module.DEFAULT_REBOOT_TIMEOUT == 900
    assert action_module.DEFAULT_CONNECT_TIMEOUT == 5.0
    assert action_module.DEFAULT_SUDOABLE is False
    assert action_module

# Generated at 2022-06-21 02:40:40.515117
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_task_vars = dict()
    mock_task_vars['ansible_distribution'] = 'RedHat'
    connection = ConnectionMock()
    task = TaskMock()
    action_module = ActionModule(task, connection, mock_task_vars)
    assert action_module
    assert not action_module.is_valid_distribution()


# Generated at 2022-06-21 02:40:50.974641
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    test_input = '''
    ---
    - name: get system boot time
      hosts: localhost
      connection: local
      tasks:
        - name: get boot time
          remote_reboot:
            test_command: 'echo "2018-04-16 12:26:53"'
    '''
    test_output = '2018-04-16 12:26:53'
    # Set up mocks
    task_vars = {'ansible_distribution': 'Ubuntu', 'ansible_distribution_version': '16.04 LTS'}
    ActionModule = ansible.plugins.action.ActionModule
    action_mock = ActionModule(None, None, None, None)
    action_mock._low_level_execute_command = create_low_level_execute_command()
    # Execute test
   

# Generated at 2022-06-21 02:41:57.555845
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create instance of class ActionModule
    ActionModule_instance = ActionModule(play_context=play_context, new_stdin=new_stdin)

    # Try run method with valid parameters
    # unit test does not currently work with running remote tasks
    # Need to investigate how to set up ansible environment properly to use this module as a task
    # Need to mock two classes low_level_execute_command, get_supported_distros
    # reboot_result = ActionModule_instance.run(tmp="tmp_parameter_data", task_vars={"task_vars_parameter_data"})
    # assert reboot_result["rebooted"] == True


# Generated at 2022-06-21 02:42:02.989443
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    # Check if deprecated_args returns the proper value
    action = ActionModule(None, None)
    expected_result = 'None'
    actual_result = action.deprecated_args()
    assert actual_result == expected_result



# Generated at 2022-06-21 02:42:13.721550
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    error_message = "Oops!"
    try:
        x = ActionModule()
        x._task = "st"
        x._play_context = "st"
        x._connection = "st"
        x._loader = "st"
        x._templar = "st"
        x.get_system_boot_time = MagicMock(side_effect=ValueError(error_message))
        x.check_boot_time(None, None)
    except Exception as e:
        assert e.message == error_message


# Generated at 2022-06-21 02:42:26.311178
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # GIVEN the results of _get_platform_info()
    platform_info = {
        'system': 'Linux',
        'machine': 'x86_64',
        'release': '3.0.101-0.47.66-default',
        'version': '#1 SMP Thu Nov 5 13:02:17 UTC 2015 (0f963e0883e23d3867765e9a9e70ab2eb8a8d42d)'
    }

    # GIVEN the distributions we need to test

# Generated at 2022-06-21 02:42:38.066331
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    # instantiate the module object without an action plugin
    task_vars, tmp, _cast_result = ActionModule._compile_module_args(
        dict(path=__file__),
        task_vars=dict(ansible_facts=dict(
            ansible_system='Linux',
            ansible_distribution='Debian',
            ansible_distribution_version='9.1',
        )),
    )
    tmpdir = tempfile.mkdtemp()
    aconn = Connection(tmpdir)

# Generated at 2022-06-21 02:42:48.966315
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.utils import context_objects as co
    from ansible.vars.manager import VariableManager
    from ansible.connection.connection_loader import get_connection_loader
    from ansible.executor.task_queue_manager import TaskQueueManager

    from ansible.plugins.action import ActionBase

    from ansible_collections.community.general.tests.unit.compat import unittest
    from ansible_collections.ansible.netcommon.tests.unit.compat import mock
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import patch, MagicMock


# Generated at 2022-06-21 02:42:55.141405
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    from ansible.plugins.action.reboot import ActionModule
    action = 'reboot'

    am = ActionModule(action, {'action': action}, {'task': MockTask(), 'play': MockPlay()})
    am._connection = MockConnection()

    display = MockDisplay()
    am.display = display

    # test when boot_time value has changed
    result = am.check_boot_time(distribution='redhat', previous_boot_time='Tue 2018-03-20 17:07:01 EST')
    assert result is None

    # test when boot_time value has not changed
    with pytest.raises(ValueError):
        am.check_boot_time(distribution='redhat', previous_boot_time='Tue 2018-03-20 17:07:01 EST')

# Generated at 2022-06-21 02:43:08.379715
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # These tests are run within a virtual environment enabled with the
    # 'ansible-connection-mock' extra requirement, enabling us to use the
    # 'mock_connection' fixture.
    vars = {'ansible_connection': 'mock_connection'}
    # Build a test playbook of the form:
    #
    # - hosts: any
    #   gather_facts: no
    #   tasks:
    #     - name: test action plugin
    #       {action_plugin_module}:
    #           # Add any action plugin args here

# Generated at 2022-06-21 02:43:09.536358
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    #ret_val = None
    at = ActionModule()
    print(at.deprecated_args())

# Generated at 2022-06-21 02:43:20.570274
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    actionmodule = ActionModule(None, None)

    display.verbosity = 3

    test_distribution = 'test_distribution'
    fake_command_args = 'fake_command_args'

    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import Mapping

    def fake_get_value_from_facts(key_name, distribution, default_value, *args, **kwargs):
        assert_true(isinstance(key_name, str))
        assert_true(isinstance(distribution, str))
        assert_true(isinstance(default_value, str))
        assert_true(isinstance(args, tuple))
        assert_true(isinstance(kwargs, Mapping))
        return fake_command_args

    actionmodule.get_

# Generated at 2022-06-21 02:44:31.994252
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    class MockActionModule:
        def __init__(self):
            self.action = 'reboot'

    class MockTask:
        def __init__(self):
            self.action = 'reboot'

    class MockTask:
        def __init__(self):
            self.args = {}
            self.action = 'reboot'

    class MockTask:
        def __init__(self):
            self.args = {'boot_time_command': None}
            self.action = 'reboot'

    class MockTask:
        def __init__(self):
            self.args = {'boot_time_command': 'test_boot_time_command'}
            self.action = 'reboot'


# Generated at 2022-06-21 02:44:42.247791
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest
    import re
    # We need to mock ansible.utils.display.Display.vvv, but we can't just import it because
    # the mock needs to be available to the action module, so we need to mock it inside
    # the module and access it using the fully qualified name.
    display_vvv = None

    # For mocking ansible.utils.display.Display.debug
    display_debug_messages = []

    def mock_display_debug(message):
        display_debug_messages.append(message)

    # For mocking ansible.utils.display.Display.vvv
    def mock_display_vvv(message):
        display_vvv(message)

    # For mocking ansible.utils.display.Display.warning
    display_warning_messages = []


# Generated at 2022-06-21 02:44:51.572674
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Create an instance of class ActionModule
    class module_args:
        pass

    argin = module_args()
    argin.action = 'reboot'
    argin.test_command = '/usr/bin/whoami'
    argin.connect_timeout = '60'
    argin.reboot_timeout = '120'
    argin.shutdown_timeout = '30'
    argin.post_reboot_delay = '5'
    argin.test_command = '/usr/bin/whoami'
    argin.inventory_hostname = 'this-host'
    argin.connection = 'local'
    argin.host_list = ['localhost']
    argin.path = '/usr/bin:/usr/sbin:/bin:/sbin'
    argin.no_log = '0'
   

# Generated at 2022-06-21 02:44:56.091059
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    module = ActionModule(task=dict(action='reboot', args=dict()))
    reboot_timeout = 3
    action_kwargs = dict()
    action_desc = 'test actions'
    count = 0
    def action(x, **a):
        nonlocal count
        count += 1
        if count > 5:
            raise RuntimeError('')
        raise ValueError('')
    try:
        module.do_until_success_or_timeout(action, action_desc, reboot_timeout, None, action_kwargs)
        assert False
    except TimedOutException:
        assert count < reboot_timeout

# Generated at 2022-06-21 02:44:57.931322
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    TimedOutException()


        

# Generated at 2022-06-21 02:45:06.176217
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    args = dict(reboot_timeout=60)
    task_vars = dict()
    distribution = dict()
    original_connection_timeout = None
    action_kwargs = dict()
    mock_self = MagicMock()
    ActionModule.validate_reboot(mock_self, distribution, original_connection_timeout, action_kwargs)


# Generated at 2022-06-21 02:45:14.068294
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    from ansible.executor.task_result import TaskResult
    from ansible.utils.color import stringc
    from ansible.plugins.loader import connection_loader
    from ansible.parsing.plugin_docs import read_docstring
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.playbook.play import Play
    from ansible.executor.play_iterator import PlayIterator
    from ansible.executor.task_queue_manager import TaskQueueManager
    import json

    # define custom display class
    class Display():
        verbosity = 4
        color = 'dark'
        stringc = stringc
        warnings = []

# Generated at 2022-06-21 02:45:18.029420
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    action = ActionModule()
    action.post_reboot_delay = 0
    action._task.args = {}
    action._connection._shell.exec_command = mock.MagicMock(return_value={'rc': 0})
    result = {}
    result = action.perform_reboot({}, 'DEFAULT')
    assert result == {'failed': False, 'start': datetime.datetime(2015, 12, 1, 20, 6, 55, 894269)}

# Generated at 2022-06-21 02:45:20.803117
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    args = dict(
        distribution='OpenSuSE',
        distribution_release='42.3',
        distribution_version='12.3',
        ansible_user='tux'
    )
    action_module = ActionModule(dict(), Connection(None, None), {})
    result = action_module.get_shutdown_command(args)
    assert result == 'shutdown'

# Generated at 2022-06-21 02:45:29.105378
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    # Create an instance of the class
    action_module = ActionModule('reboot', dict(), False, 'localhost', 'all')
    if not isinstance(action_module, ActionModule):
        raise AssertionError()
    # Execute the method with a known result
    res = action_module.get_system_boot_time('distribution')
    assert isinstance(res, str)

