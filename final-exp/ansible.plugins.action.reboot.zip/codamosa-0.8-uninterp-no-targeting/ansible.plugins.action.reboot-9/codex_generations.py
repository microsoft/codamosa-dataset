

# Generated at 2022-06-21 02:37:43.577952
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Test variables and parameters
    os_distribution = 'VMWareESXi'
    distribution = 'VMWareESXi'
    reboot_result = {'changed': False, 'failed': True, 'rebooted': False, 'msg': "Reboot command failed. Error was: '{stdout}, {stderr}'".format(
            stdout='test_stdout', stderr='test_stderr')}
    expected_result = {'start': 'datetime_current', 'failed': True, 'rebooted': False, 'msg': "Reboot command failed. Error was: '{stdout}, {stderr}'".format(
            stdout='test_stdout', stderr='test_stderr')}
    reboot_command = 'test_shutdown_command_args'

# Generated at 2022-06-21 02:37:48.808642
# Unit test for method check_boot_time of class ActionModule

# Generated at 2022-06-21 02:37:54.401222
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test action module run
    connection = AnsibleConnection('ssh')
    tmp = ''
    task_vars = {}
    action = ActionModule(connection, tmp, task_vars, 'reboot', 'reboot')
    res = action.run(tmp, task_vars)
    assert res == {'changed': False, 'elapsed': 0, 'rebooted': False, 'failed': True, 'msg': 'Running reboot with local connection would reboot the control node.'}


# Generated at 2022-06-21 02:37:55.394177
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    pass


# Generated at 2022-06-21 02:38:03.358289
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    action_module.DEFAULT_BOOT_TIME_COMMAND = 'uptime'
    assert(action_module.DEFAULT_BOOT_TIME_COMMAND == action_module.BOOT_TIME_COMMANDS['Linux']['DEFAULT_BOOT_TIME_COMMAND'])
    assert(action_module.TEST_COMMANDS == action_module._get_value_from_facts('TEST_COMMANDS', None, None))
    assert(action_module.BOOT_TIME_COMMANDS == action_module._get_value_from_facts('BOOT_TIME_COMMANDS', None, None))

    action_module.DEFAULT_BOOT_TIME_COMMAND = 'uname'

# Generated at 2022-06-21 02:38:09.509921
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    module = ActionModule(
        task=dict(args=dict(shutdown_command='test', shutdown_command_args='test')),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    result = module.get_shutdown_command(dict(), 'test')
    assert result == 'test'

    module = ActionModule(
        task=dict(args=dict(shutdown_command='/sbin/halt', shutdown_command_args='test')),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    result = module.get_shutdown_command(dict(), 'test')

# Generated at 2022-06-21 02:38:10.423119
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:38:11.357038
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
  e = TimedOutException('message')



# Generated at 2022-06-21 02:38:21.396269
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action_module = ActionModule()

    # Test with self._task.args is None
    try:
        action_module.deprecated_args()
        assert False
    except AttributeError:
        pass

    # Test with self._task.args contains deprecated args
    action_module._task = Mock()
    action_module._task.action = "reboot"
    action_module._task.args = dict()
    action_module._task.args['connect_timeout'] = "10"
    action_module.deprecated_args()



# Generated at 2022-06-21 02:38:31.506868
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # Test case data
    action = "action"
    reboot_timeout = 10
    action_desc = "action description"
    distribution = "macosx"
    action_kwargs = {}
    # Test run
    actmod = ActionModule()
    result = actmod.do_until_success_or_timeout(action, reboot_timeout, action_desc, distribution, action_kwargs)
    assert result == None
#Unit test for method perform_reboot of class ActionModule

# Generated at 2022-06-21 02:39:05.219946
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    # Unit test for method get_shutdown_command_args of class ActionModule
    # methods with return values
    assert action_module.get_shutdown_command_args('Linux') == '-r now'
    assert action_module.get_shutdown_command_args('FreeBSD') == '-r now'
    
    
    
    
    

# Generated at 2022-06-21 02:39:16.942809
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    connection = Connection()
    task = Task(action='reboot')
    task._task.args = {}
    am = ActionModule(task, connection, play_context=PlayContext(), loader=None, templar=None, shared_loader_obj=None)
    am._task.args = {}
    am._task.args['shutdown_command'] = ''
    tmp = None
    task_vars = { "ansible_fqdn": "ansible_test", "ansible_facts": { "distribution": "RedHat" }}
    result = am.get_shutdown_command(task_vars)
    assert result == '/sbin/shutdown'

# Generated at 2022-06-21 02:39:29.756923
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # instantiate mock class
    mock_ActionModule = ActionModule("ActionModule")

    # setup some expected results

    target_get_distribution = "distribution"
    expected_get_distribution_result = target_get_distribution
    expected_get_distribution_result_exists = True

    # dynamically build our test tasks

# Generated at 2022-06-21 02:39:38.534492
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    task_vars = dict()
    display = Mock()
    ansible_vars = dict()
    action_module = ActionModule(task=Mock(), connection=Mock(), play_context=Mock(), loader=Mock(), templar=Mock(), shared_loader_obj=Mock())
    action_module._get_value_from_facts.return_value = shutdown_bin
    action_module._display = display
    action_module._task.args = dict()
    action_module._task.args['shutdown_command'] = None
    action_module._task.args['distribution'] = None
    action_module.get_shutdown_command(task_vars, None)
    assert action_module._get_value_from_facts.called
    assert display.warning.called

# Generated at 2022-06-21 02:39:52.740748
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    _distribution = 'Foo'
    success_list = [
        {
            'ansible_facts': {
                'distribution': _distribution
            }
        },
        {
            'ansible_facts': {
                'distribution_version': _distribution
            }
        },
        {
            'ansible_facts': {
                'ansible_distribution': _distribution
            }
        },
        {
            'ansible_facts': {
                'ansible_distribution_version': _distribution
            }
        },
        {
            'ansible_facts': {
                'ansible_os_family': _distribution
            }
        }
    ]
    t = ActionModule()


# Generated at 2022-06-21 02:40:02.676216
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

# Generated at 2022-06-21 02:40:13.292538
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action = ActionModule()
    assert hasattr(action, 'deprecated_args')
    action._task.action = 'reboot'
    action._task.args = {'connect_timeout_sec': 1}
    action.deprecated_args()
    action._task.args = {'connect_timeout': 1}
    action.deprecated_args()
    action._task.args = {'test_command': 'reboot'}
    action.deprecated_args()
    action._task.args = {'reboot_timeout_sec': 1}
    action.deprecated_args()
    action._task.args = {'reboot_timeout': 1}
    action.deprecated_args()
    action._task.args = {'pre_reboot_delay': 1}
    action.deprecated_args()
    action._task

# Generated at 2022-06-21 02:40:19.878769
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    #### GET_SYSTEM_BOOT_TIME ####
    # NB: This doesn't call the actual remote command so mocking implementation is sufficient

    # test that the method get_system_boot_time(self, distribution) raises a NotImplementedError exception
    # when called with the required argument(s), and no exception when it isn't
    # called with the required argument(s)
    # TODO
    pass

# Generated at 2022-06-21 02:40:26.798722
# Unit test for constructor of class ActionModule
def test_ActionModule():
    if AnsibleError:
        # Ansible 2.8
        test_module = ActionModule(FakeModule())
    else:
        # Ansible 2.6
        test_module = ActionModule()
        test_module._task = FakeModule()
    assert test_module is not None

# Test for deprecated_args() function of class ActionModule

# Generated at 2022-06-21 02:40:30.323992
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    mock_connection = MagicMock()
    mock_task = MagicMock()
    mock_task.action = 'Mocked Task'
    mock_task.args = {
        'deprecated_arg': 'True'
    }
    action_module = ActionModule(mock_task, mock_connection)
    action_module.deprecated_args()
    assert display.warning.called