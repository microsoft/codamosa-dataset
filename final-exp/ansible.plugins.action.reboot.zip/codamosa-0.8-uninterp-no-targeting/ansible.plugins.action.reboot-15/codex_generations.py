

# Generated at 2022-06-21 02:37:34.435525
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # Not a test case
    return


# Generated at 2022-06-21 02:37:38.401569
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(
        connection=FakeConnection(),
        task=FakeTask(),
        play_context=FakePlayContext(),
        loader=FakeLoader(),
        templar=FakeTemplar(),
        shared_loader_obj=None,
        # We need to mock this or else there will be an error
        # when calling get_plugin and the connection type is None
        connection_loader=None
    )

    return action_module

# Generated at 2022-06-21 02:37:51.629553
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.connection import Connection
    from ansible.inventory.host import Host

    host = Host(name="myhost", port=22)
    myargs = dict(
        ansible_connection='smart',
        ansible_network_os='myos',
        ansible_user='myuser',
        ansible_ssh_pass='mypass',
        ansible_become=False,
    )

# Generated at 2022-06-21 02:38:01.794893
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()

    # Test task_vars default to empty dictionary
    assert isinstance(module._task_vars, dict)
    assert module._task_vars == {}

    # Test play_context default to empty dictionary
    assert isinstance(module._play_context, dict)
    assert module._play_context == {}

    # Test connection default to None
    assert module._connection is None

    # Test supports_check_mode default to False
    assert module._supports_check_mode is False

    # Test supports_async default to False
    assert module._supports_async is False

    # Test task default to None
    assert module._task is None

    # Test task_vars default to None
    assert module._in_data is None

    # Test loader default to None
    assert module._loader is None

# Generated at 2022-06-21 02:38:03.813116
# Unit test for constructor of class TimedOutException

# Generated at 2022-06-21 02:38:11.607538
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    # Create an object of the class under test
    class_under_test = ActionModule()
    # Setup Mock Objects
    original_connection_timeout = None
    action_kwargs = None

    result = class_under_test.validate_reboot(
        distribution=None,
        original_connection_timeout=original_connection_timeout,
        action_kwargs=action_kwargs
    )

    # Check if the results are as expected
    assert result == None

# Generated at 2022-06-21 02:38:23.945715
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    host_vars = load_fixture("host_vars")
    mock_task = load_fixture("reboot_task")
    mock_task["action"] = "local_action"
    mock_task["action"]["args"] = {
            "connect_timeout_sec": 10,
            "test_command": "/bin/true",
            "reboot_timeout_sec": 15,
            "msg": "Rebooting system...",
            "reboot_timeout": 20,
            "shutdown_timeout_sec": 5,
            "connect_timeout": 5,
            "shutdown_timeout": 6,
            "post_reboot_delay_sec": 1,
            "post_reboot_delay": 2
        }
    mock_connection = type('obj', (object,), {})()
    mock_play_context

# Generated at 2022-06-21 02:38:36.605527
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    print("reboot_test::test_ActionModule_get_shutdown_command")

    # get_shutdown_command - correct shutdown command returned
    # also checks default sudoable value: 'yes'
    action = ActionModule(None, None)
    action.DEFAULT_SHUTDOWN_COMMAND = '/sbin/reboot'
    action.DEFAULT_SHUTDOWN_COMMAND_ARGS = '-f'
    action.DEFAULT_SUDOABLE = True
    action._task = Mock()
    action._task.args = {}
    action._task.action = 'reboot'

    task_vars = AnsibleVars()
    task_vars['ansible_distribution'] = 'Fedora'
    task_vars['ansible_distribution_version'] = '28'
    task_vars

# Generated at 2022-06-21 02:38:44.471944
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    connection_dict = {
        'host': 'localhost',
        'port': 1,
        'username': 'testuser',
        'password': 'testpassword',
        'private_key_file': 'testkey.pem',
        'ssh_common_args': 'testargs',
        'ssh_extra_args': 'testargs',
        'sftp_extra_args': 'sftp_testargs',
        'scp_extra_args': 'scp_testargs',
        'scp_if_ssh': 'scp_if_ssh_testargs',
        'connection_timeout': 1,
        'persistent_connect_timeout': 1,
        'accelerate_port': 1,
        'accelerate_timeout': 1,
        'accelerate_connect_timeout': 1
    }
    test

# Generated at 2022-06-21 02:38:55.021734
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module = ActionModule()
    assert action_module.get_distribution("os_family:Linux") == "linux"
    assert action_module.get_distribution("os_family:FreeBSD") == "freebsd"
    assert action_module.get_distribution("os_family:AIX") == "aix"
    assert action_module.get_distribution("os_family:Darwin") == "darwin"
    assert action_module.get_distribution("os_family:windows") == "windows"
    assert action_module.get_distribution("os_family:default") == "default"


# Generated at 2022-06-21 02:40:10.396291
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import connection_loader

    os.environ['ANSIBLE_STRATEGY'] = 'linear'
    play_context = PlayContext()
    connection = connection_loader.get('local', play_context, '/dev/null')

    action = ActionModule(dict(), connection, play_context, None, None)
    assert action

# Generated at 2022-06-21 02:40:19.158511
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():

    expected_result = {
        'failed': True,
        'rebooted': True,
        'msg': 'Timed out waiting for last boot time check (timeout=60)'
    }

    action = ActionModule()
    action.DEFAULT_REBOOT_TIMEOUT = 60
    actual_result = action.validate_reboot(distribution=None, original_connection_timeout=None, action_kwargs=None)

    assert actual_result == expected_result


# Generated at 2022-06-21 02:40:31.604762
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Argument 'task_vars' is required (and there is no default value)
    with pytest.raises(TypeError, match="missing 1 required positional argument: 'task_vars'"):
        action = ActionModule(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
        action.run()

    # Argument 'task_vars' is missing
    with pytest.raises(TypeError, match="missing 1 required positional argument: 'task_vars'"):
        action = ActionModule(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
        action.run(tmp=None)

    # Argument 'task_vars' must be dict, got None

# Generated at 2022-06-21 02:40:41.080944
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    obj = ActionModule(task=ConstReturnValue(dict()), connection=None, play_context=dict(), loader=None, templar=None, shared_loader_obj=None)

    obj._task.action = 'test module'

    # set member variables
    obj.post_reboot_delay = 0
    obj.DEFAULT_REBOOT_TIMEOUT = 0
    obj.DEFAULT_CONNECT_TIMEOUT = 0

    kwargs = {}
    obj.do_until_success_or_timeout(action=obj.validate_reboot, action_desc="test_desc", reboot_timeout=0, distribution="test_distribution", **kwargs)

# Generated at 2022-06-21 02:40:51.631715
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action_module = ActionModule(
        task=MagicMock(),
        connection=MagicMock(),
        play_context=MagicMock(),
        loader=MagicMock(),
        templar=MagicMock(),
        shared_loader_obj=None)

    # __init__ args for ActionModule
    task = None
    connection = None
    play_context = None
    loader = None
    templar = None
    shared_loader_obj = None

    action_module._task = MagicMock(args={'reboot_timeout_sec': 0})
    action_module.deprecated_args()
    action_module._task.args.get.assert_any_call('reboot_timeout')
    action_module._task.args.get.assert_any_call('reboot_timeout_sec')

# Generated at 2022-06-21 02:41:00.452767
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    results = ActionModule().get_shutdown_command_args('RedHat')
    assert results == '-r now'
    results = ActionModule().get_shutdown_command_args('Debian')
    assert results == '-r now'
    results = ActionModule().get_shutdown_command_args('default')
    assert results == '-r now'
    results = ActionModule().get_shutdown_command_args('')
    assert results == '-r now'
    results = ActionModule().get_shutdown_command_args('Ubuntu')
    assert results == '-r now'
    results = ActionModule().get_shutdown_command_args('CentOS')
    assert results == '-r now'


# Generated at 2022-06-21 02:41:12.750339
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    host_os = 'Linux'
    host_distribution = 'RedHat'
    reboot_timeout = 900
    test_shutdown_command_args = {
        'RedHat': '-r now',
        'Debian': '-r now',
        'ArchLinux': '-r now',
        'Gentoo': '-r now',
        'alpine': '-r now',
        'SUSE': '-r now',
        'NILinuxRT': '-r now',
        'Solaris': '-y -g 0',
        'FreeBSD': '-p',
        'Darwin': '-h now',
        'DEFAULT': '-r now'
    }
    host_vars = dict(ansible_distribution=host_distribution)

# Generated at 2022-06-21 02:41:24.420869
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    distribution = 'SomeDistribution'

    shutdown_command_arg_facts = {
        'SomeDistribution': 'SomeShutdownCommandArg'
    }

    expected_shutdown_command_arg_facts = {
        'SomeDistribution': 'SomeShutdownCommandArg'
    }

    mocker = mock.Mock()
    mocker.return_value = shutdown_command_arg_facts

    action_module._get_value_from_facts = mocker

    actual_shutdown_command_arg = action_module.get_shutdown_command_args(distribution)


# Generated at 2022-06-21 02:41:33.113433
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    action = ActionModule({
        '_ansible_verbosity': 3,
        '_ansible_check_mode': False,
        '_ansible_no_log': False,
        'action': 'reboot'
    }, 'test_display_test')

    # reset time to static value
    time.time = Mock(return_value=1)

    # should return before timeout
    action.do_until_success_or_timeout(
        action=lambda distribution: True,
        action_desc=None,
        reboot_timeout=1,
        distribution='distribution')

    # should return after success

# Generated at 2022-06-21 02:41:40.231474
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    # Setup test environment

    # Perform unit test
    # test = ActionModule(connection=None, runner=None, task=None)
    # result = test.validate_reboot(distribution=None, original_connection_timeout=None, action_kwargs=None)
    assert True