

# Generated at 2022-06-21 02:37:40.430105
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():

    # Performs a test of method validate_reboot of class ActionModule
    #
    # Returns:
    #  None

    # Declare variables
    action_module = None
    param0 = None
    param1 = None
    param2 = None

    # Setup variables

    # Execution of method
    action_module.validate_reboot(param0, param1, param2)

    # Return


# Generated at 2022-06-21 02:37:53.811338
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    from ansible.plugins.action.reboot import ActionModule
    mock_task = MagicMock()
    mock_task.action = 'test_dummy_action'
    mock_task.args = None
    mock_play_context = MagicMock()
    mock_play_context.remote_addr = 'ansible_dummy_host'
    mock_play_context.connection = 'dummy_connection'
    mock_play_context.become = True
    mock_play_context.become_method = 'dummy_become_method'
    mock_play_context.become_user = 'dummy_become_user'

    am = ActionModule(mock_task, mock_play_context, None, None, None)
    am._low_level_execute_command = MagicMock()
    am._low

# Generated at 2022-06-21 02:38:02.156637
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 02:38:03.285940
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    assert isinstance(Exception, TimedOutException)



# Generated at 2022-06-21 02:38:06.811636
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Arguments
    task_vars = dict()
    # Perform the test, then check the results
    assert True == True


# Generated at 2022-06-21 02:38:17.710529
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # Create a new context for testing
    context = Connection(None, 'local')
    # Create a new ActionModule object for testing
    action_mod = ActionModule(context, {}, None, None)

    # Get current system distribution
    distribution = action_mod.get_distribution()

    # Test that the distribution returned is the same type as the current host system.
    # If the distribution returned is not the same type as the current host system, then the
    # Vagrant build will fail and 'vagrant test' will not run the remaining tests.
    if distribution in ['redhat', 'fedora', 'centos', 'scientific', 'amazon', 'oraclelinux'] or distribution.startswith('ol'):
        distro_test = 'redhat'
    elif distribution in ['debian', 'ubuntu']:
        distro_test = 'debian'


# Generated at 2022-06-21 02:38:19.597609
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    try:
        raise TimedOutException()

    except Exception as e:
        if "TimedOutException" not in to_native(e):
            raise


# Generated at 2022-06-21 02:38:21.909659
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    """Test constructor of class TimedOutException"""
    try:
        raise TimedOutException
    except TimedOutException:
        pass



# Generated at 2022-06-21 02:38:35.579621
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    module = ActionModule('reboot')

    distribution = 'DEBIAN8'
    original_connection_timeout = 100
    reboot_timeout = 30

    test_command = 'DEFAULT_TEST_COMMAND'

    def check_success():
        module.run_test_command(distribution=distribution)
        raise RuntimeError("Expected test_command to succeed")

    def check_failure():
        with pytest.raises(RuntimeError):
            module.run_test_command(distribution=distribution)


# Generated at 2022-06-21 02:38:39.120906
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    try:
        raise TimedOutException("This is a test")
    except TimedOutException as e:
        assert e == "This is a test"



# Generated at 2022-06-21 02:39:19.319072
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task_vars={},
        connection='ssh',
        play_context=dict(check_mode=False, remote_addr='192.168.1.1'),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )


# Generated at 2022-06-21 02:39:27.380907
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # Create a test object of class ActionModule
    AM = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Test that AttributeError is raised when AM.check_boot_time is called with no arguments
    with pytest.raises(AttributeError):
        AM.check_boot_time()

    assert 0

# Generated at 2022-06-21 02:39:35.487520
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    action_module = ActionModule(None)

    # Test for return value for 'rebooted' key of type bool.
    assert isinstance(action_module.validate_reboot(63469, 30461)['rebooted'], bool)

    # Test for return value for 'failed' key of type bool.
    assert isinstance(action_module.validate_reboot(63469, 30461)['failed'], bool)

    # Test for return value for 'rebooted' key of type bool.
    assert isinstance(action_module.validate_reboot(27776, 1420)['rebooted'], bool)

    # Test for return value for 'changed' key of type bool.
    assert isinstance(action_module.validate_reboot(27776, 1420)['changed'], bool)

    #

# Generated at 2022-06-21 02:39:43.220873
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    ### Start test run
    session = ActionModuleTest()

    # Get fixture data
    ACTION_MODULE_PATH = session.fixture_data['ACTION_MODULE_PATH']

    # Fixture path
    MODULE_NAME = 'reboot'
    FILENAME = 'check_boot_time.py'
    FIXTURE_PATH = 'unit/modules/' + MODULE_NAME + '/fixtures/' + FILENAME
    FIXTURE_PATH = [os.path.join(ACTION_MODULE_PATH, FIXTURE_PATH)]

    # Fixture data
    ACTION_MODULE_ARGS = session.fixture_data['ACTION_MODULE_ARGS']
    ACTION_MODULE_ARGS['_uses_shell'] = False

# Generated at 2022-06-21 02:39:52.904711
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class FakeConnection():
        def __init__(self):
            self.transport = 'ssh'

    class FakePlayContext():
        def __init__(self):
            self.connection = 'local'

    class FakeTask():
        def __init__(self):
            self.action = 'reboot'
            self.args = {}

    action_module = ActionModule()
    setattr(action_module, '_connection', FakeConnection())
    setattr(action_module, '_play_context', FakePlayContext())
    setattr(action_module, '_task', FakeTask())

    return action_module


# Generated at 2022-06-21 02:39:55.371916
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    e = TimedOutException("Test Exception")
    assert to_text(e) == "Test Exception"



# Generated at 2022-06-21 02:39:59.337642
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    task_vars = {}
    module_args = {}
    reboot_result = {}
    distribution = 'Linux'
    display.vvv("")
    display.debug("")
    reboot_result = ActionModule.perform_reboot(ActionModule, task_vars, distribution)
    assert reboot_result['failed'] == False
    assert reboot_result['rebooted'] == False
    assert reboot_result['msg'] == ""



# Generated at 2022-06-21 02:40:11.816773
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    test_object = ActionModule(
        task=dict(
            vars=dict(
                ansible_facts=dict(
                    ansible_os_family='freebsd',
                    ansible_distribution='FreeBSD'
                )
            )
        ),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    # test when 'shutdown_command' is present in args
    test_object._task.args = dict(shutdown_command='/sbin/reboot')
    expected = '/sbin/reboot'

# Generated at 2022-06-21 02:40:16.120905
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module = ActionModule()

    # Verify return type
    assert isinstance(action_module.get_shutdown_command_args(distribution=''), str)

# Generated at 2022-06-21 02:40:21.070512
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    fixture_path = os.path.join(fixture_path, 'does_not_exist.py')
    import ansible.utils.template
    t = ansible.utils.template.Template(fixture_path)
    kwargs = {'foo': 'bar'}
    result = t.template(**kwargs)
    assert result == 'bar'
    return



# Generated at 2022-06-21 02:40:59.758098
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # initialize mock ansible module
    ansible_module = Mock(AnsibleModule)
    ansible_module.check_mode.return_value = False
    ansible_module.params.return_value = dict(
        reboot_timeout=0.0,
        post_reboot_delay=0.0
    )
    # initialize connection plugin
    connection_plugin = Mock(Connection)
    connection_plugin.get_option.side_effect = [0.0,0.0]
    # initialize mock play context
    play_context = Mock(PlayContext)
    play_context.check_mode.return_value = False

    # initialize ActionModule object
    action_module = ActionModule(ansible_module, play_context, connection_plugin)

    # perform test
    action_module.run(None, {})


# Unit

# Generated at 2022-06-21 02:41:12.384251
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Specifying arguments for the constructor of class ActionModule
    host = create_host('test_host')
    connection = Connection(host)
    task = Task()
    task_vars = dict()

    # Creating instance of class ActionModule
    action_module = ActionModule(task, connection, task_vars)

    # Setting attribute of instance action_module
    action_module.reboot_timeout = 0

    # Overriding the value of parameter tmp in function set_action_module_vars
    tmp = None

    # Calling the test function
    result_action_module = action_module.set_action_module_vars(tmp)

    # Asserting the result
    assert result_action_module['msg'] == 'The module reboot could not be found. This often indicates a misspelling, missing collection, or incorrect module path.'

# Generated at 2022-06-21 02:41:19.957520
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    am = ActionModule()

    class MockException(Exception):
        pass

    def e_func(a, b, c, d, e=True, f=None, g='hello', h=1, i=2, j=3, k=4, l=5, m=6, n=7, o=8, p=9, q=10, r=11):

        class MockException(Exception):
            pass
        if a == 1:
            d -= 1
            return 0
        elif d > 0:
            raise ValueError("something failed")
        elif e == True:
            raise MockException("hello")
        else:
            return 0

    am.do_until_success_or_timeout(e_func, 'docstring', 1, g=None, p='b')

# Generated at 2022-06-21 02:41:22.851413
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
  target = ActionModule()
  target.get_shutdown_command()

# Generated at 2022-06-21 02:41:33.046122
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    action = ActionModule()

    # Test run with no watch, return immediately
    test_action_kwargs = {'reboot_timeout': 0}
    res = action.do_until_success_or_timeout(action=None, reboot_timeout=0, action_desc='', distribution='', action_kwargs=test_action_kwargs)
    assert not res

    with pytest.raises(ValueError) as exception_info:
        action.do_until_success_or_timeout(action=ValueError, reboot_timeout=0, action_desc='', distribution='', action_kwargs=test_action_kwargs)
    assert exception_info.match('boot time has not changed')

# Generated at 2022-06-21 02:41:42.716193
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    from ansible.plugins import action

    # Create an instance of ActionModule class
    action_module = action.ActionModule(None, None, None, None)

    # Set test variables
    distribution = "Debian GNU/Linux"
    previous_boot_time = "Thu 2018-10-25 07:49:43 UTC"

    # Test call to method check_boot_time
    action_module.check_boot_time(distribution, previous_boot_time)


# Generated at 2022-06-21 02:41:45.428310
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    ActionModule.run_test_command(ActionModule())

# Generated at 2022-06-21 02:41:55.527118
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    """
    Test function run_test_command actionmodule_reboot_linux
    """
    # Init ActionModule
    actionmodule_reboot_linux_obj = ActionModule(u"setup", {u"ansible_facts": {}})

    # Prepare mocks
    test_command_mock = Mock()
    distribution_mock = Mock()

    # Use real parameters
    distribution_real_arg = u'rhel'

    # Use real function
    actionmodule_reboot_linux_obj.run_test_command(distribution=distribution_real_arg)
    # Do asserts



# Generated at 2022-06-21 02:42:07.943318
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # Initialise the class instance
    module = ActionModule()

    # Create an instance of the TimedOutException class
    timed_out_exception = TimedOutException('Timed out waiting for {desc} (timeout={timeout})'.format(desc='action_desc', timeout='reboot_timeout'))

    # Test that method do_until_success_or_timeout raises a TimedOutException
    with pytest.raises(TimedOutException) as e:
        module.do_until_success_or_timeout(
            action='action',
            action_desc='action_desc',
            reboot_timeout='reboot_timeout',
            distribution='distribution',
            action_kwargs='action_kwargs')
    # Ensure that the test returns the correct exception
    assert e.value == timed_out_exception


# Generated at 2022-06-21 02:42:20.075541
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    args = {'msg': 'Shutting down for reboot.', 'connect_timeout': 5}
    play_context = {'check_mode': False, 'name': 'test-play', 'playbook_basedir': '/path/to/playbook/directory'}

    task_vars = {
        'ansible_facts': {
            'DISTRIB_ID': 'ubuntu',
            'DISTRIB_RELEASE': '16.04',
            'DISTRIB_CODENAME': 'xenial',
            'DISTRIB_DESCRIPTION': 'Ubuntu 16.04.6 LTS',
            'PROCESSOR_ARCHITECTURE': 'amd64',
            'PROCESSOR_IDENTFIER': 'Intel64 Family 6 Model 63 Stepping 2, GenuineIntel'
        }
    }


# Generated at 2022-06-21 02:43:29.964712
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    """
    test for action_plugin.check_boot_time
    """
    # Setup test environment
    am = ActionModule(
        task=Mock(action='reboot'),
        connection=Mock(
            connection=mock_connector),
        play_context=Mock(check_mode=False))
    am._task.args = {}

    linux_distribution_name = 'linux'
    linux_previous_boot_time = '2018-08-10 08:29:50 CEST'
    am._task.args['test_command'] = "test"
    am._task.args['test_command_success_status'] = [0]

    # Execute test
    am.check_boot_time(distribution=linux_distribution_name, previous_boot_time=linux_previous_boot_time)


# Generated at 2022-06-21 02:43:33.038437
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    shutdown_bin = 'shutdown'

    # test for pass
    task = AnsibleTask()
    task.args = {'pre_reboot_delay': 0}
    action_module = ActionModule(task, AnsibleConnection(), AnsibleTask(action='mock'))

    result = action_module.get_shutdown_command({}, 'mock')
    assert result == shutdown_bin
    # test for fail
    # assert False



# Generated at 2022-06-21 02:43:42.552632
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    mod = ActionModule(
        task=dict(action='some action'),
        connection=SomeBaseConnection(
            play_context=dict(become=True)
        ),
        new_stdin='{"arguments": {"_ansible_tmpdir": "/tmp", "_ansible_no_log": false, "_ansible_verbosity": 1, "fail_key": true, "_ansible_syslog_facility": "LOG_USER", "_ansible_version": "2.4.3.0", "_ansible_no_log_warnings": false, "_ansible_debug": false, "_ansible_async": 10, "_ansible_diff": false, "_ansible_keep_remote_files": false, "_ansible_remote_tmp": false}, "module_name": "reboot"}'
    )

    mod.run()



# Generated at 2022-06-21 02:43:55.668722
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    ac = ActionModule(dict(ANSIBLE_MODULE_ARGS={
        'reboot_timeout': 60,
        'connect_timeout': 5,
        '_ansible_check_mode': False,
        '_ansible_diff': False,
        '_ansible_verbosity': 3,
        '_ansible_selinux_special_fs': ['fuse', 'nfs', 'vboxsf', 'ramfs', '9p'],
        '_ansible_version': '2.4.0.0-1.el7.noarch',
        '_ansible_no_log': False,
        '_ansible_devel': False}))

# Generated at 2022-06-21 02:44:07.719062
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    mocker = Mocker()

    class MockActionModule:
        _task = None
        _connection = None
        DEFAULT_REBOOT_TIMEOUT = 0
        DEFAULT_SUDOABLE = False
        INVALID_DIST = 'invalid'
        MODULE_RETURN_KEYS = ['failed', 'msg', 'rebooted']

        def __init__(self, task, connection):
            self._task = task
            self._connection = connection

        def get_distribution(self, task_vars):
            return self._task.args.get('distribution', self.INVALID_DIST)

        def get_shutdown_command(self, task_vars, distribution):
            return self._task.args.get('shutdown_command', 'shutdown')


# Generated at 2022-06-21 02:44:19.000490
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    # We need to mimic the task_vars global to make the get_distribution function work
    task_vars = {'ansible_distribution': 'Redhat'}
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    old_get_system_boot_time = am.get_system_boot_time
    old_check_boot_time = am.check_boot_time
    old_run_test_command = am.run_test_command
    am.get_system_boot_time = MagicMock()
    am.check_boot_time = MagicMock()
    am.run_test_command = MagicMock()

# Generated at 2022-06-21 02:44:28.910961
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():

    ansible_run_results = dict(
        failed=False,
        rebooted=True
    )

    module = ActionModule()

    # On successful reboot, run test command
    module.run_test_command = MagicMock(return_value=None)

    # On successful reboot, return system boot time
    module.check_boot_time = MagicMock(return_value=None)

    # Validate reboot was successful
    ret_val = module.validate_reboot('distribution', None, None)

    assert ret_val == ansible_run_results


# Generated at 2022-06-21 02:44:35.203900
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    # Create mock variables
    distribution = ''
    expected_result = ''
    # Perform test
    result = ActionModule._get_system_boot_time(distribution)
    # Assert
    assert result == expected_result


# Generated at 2022-06-21 02:44:43.211871
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule

    See the following issues for background:
    https://github.com/ansible/ansible/issues/10938
    https://github.com/ansible/ansible/issues/15901
    https://github.com/ansible/ansible/issues/15837
    '''

    # Ansible's log facility is initialized during the yaml loading so
    # before any tests are run we need to make sure we don't have left
    # over values in the log module.  This causes output to be
    # captured and makes the test output less readable.
    log._log_messages = []

    module = Reboot()

    def _load_name_to_path_map():
        ''' internal function to simulate a real loader.load_module() function'''
        name_to_path

# Generated at 2022-06-21 02:44:50.433301
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Failing case
    result = ActionModule.perform_reboot(action, None)
    assert result == {'start': datetime.utcnow(), 'failed': True, 'rebooted': False, 'msg': "Reboot command failed. Error was: '{stdout}, {stderr}'"}
    
    # Passing case
    result = ActionModule.perform_reboot(action, None)
    assert result == {'start': datetime.utcnow(), 'failed': False, 'rebooted': True, 'msg': None}

# Generated at 2022-06-21 02:46:12.121108
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    host_vars = {}
    task_vars = {}
    temp_vars = {'ansible_facts': {'distribution': 'BSD'}}
    temp_vars.update(host_vars)
    temp_vars.update(task_vars)
    action_args = {}
    am = ActionModule(None, action_args, temp_vars, 'faketask')
    assert am.get_shutdown_command_args('BSD') == '-r now'
    assert am.get_shutdown_command_args('DEBIAN') == '-r now'
    assert am.get_shutdown_command_args('REDHAT') == '-r now'
    assert am.get_shutdown_command_args('SUSE') == '-r now'
    assert am.get_shutdown

# Generated at 2022-06-21 02:46:18.144863
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Create an instance of ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Test with valid values
    # Test with expected failures



# Generated at 2022-06-21 02:46:23.788027
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # setup test
    action_module = ActionModule({})
    action_module._task.async_val = None
    action_module._task.action = 'reboot'
    action_module._task.args = {}
    action_module._supports_check_mode = True
    action_module._supports_async = True
    # perform the test
    result = action_module.run()
    # assertions
    assert result == {'skipped': True, 'failed': False}


# Generated at 2022-06-21 02:46:29.827957
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # Set up some parameters for unit test
    tmp=None
    args={'reboot_timeout': 10}
    distribution = "Ubuntu"
    
    # Create an instance of the class ActionModule
    a = ActionModule(tmp, args)

    # Call the method get_distribution of class ActionModule
    assert a.get_distribution(distribution)=="Ubuntu"

# Generated at 2022-06-21 02:46:33.113139
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    actionm = ActionModule()
    # Put your test code here

# Generated at 2022-06-21 02:46:44.528246
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # GIVEN
    task_vars = dict(ansible_distribution = 'Arch Linux', ansible_distribution_version = 'rolling')
    distribution = 'Arch Linux'
    with patch('ansible.modules.system.reboot.ActionModule.get_distribution') as mgd, \
        patch('ansible.modules.system.reboot.ActionModule.get_system_boot_time') as mgsb, \
        patch('ansible.modules.system.reboot.ActionModule.perform_reboot') as mpr, \
        patch('ansible.modules.system.reboot.ActionModule.validate_reboot') as mvr, \
        patch('ansible.modules.system.reboot._low_level_execute_command') as mll:

        mgd.return_value = distribution

# Generated at 2022-06-21 02:46:47.377850
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    err = TimedOutException("TestErrorMessage")
    assert to_text(err) == "TestErrorMessage"



# Generated at 2022-06-21 02:46:49.981126
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    try:
        raise TimedOutException()
    except TimedOutException:
        pass



# Generated at 2022-06-21 02:46:55.002131
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    mod = ActionModule({"name": "reboot",
                        "args": {
                            "reboot_timeout": 10,
                            "connect_timeout": 5
                        }},
                       task={"name": "reboot",
                             "action": "reboot"
                             })
    distribution = "Linux"

    expected = "-r now"
    actual = mod.get_shutdown_command_args(distribution=distribution)

    assert actual == expected
