

# Generated at 2022-06-21 02:37:38.870040
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = AnsibleModuleMock()
    module.params = {
    }
    result = ActionModule(module).run(None, {})
    assert result['changed'] == True
    assert result['elapsed'] == 0
    assert result['rebooted'] == True

# Generated at 2022-06-21 02:37:45.743212
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    # Test validate_reboot
    # Test rebooting is successful
    action_module = ActionModule()

    test_distribution = "default"
    test_original_connection_timeout = 15
    test_action_kwargs = {"previous_boot_time" : "2020-01-01"}

    result = action_module.validate_reboot(test_distribution, test_original_connection_timeout, action_kwargs=test_action_kwargs)
    assert result["failed"] == False
    assert result["rebooted"] == True
    assert result["changed"] == True
    # Test rebooting is failed
    result2 = action_module.validate_reboot(test_distribution, test_original_connection_timeout, action_kwargs=test_action_kwargs)
    assert result2["failed"] == True

# Generated at 2022-06-21 02:37:54.660002
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    restart_paths = '/bin,/usr/bin,/sbin,/usr/sbin,/usr/local/bin'
    test_hostname = 'testhostname'
    test_user = 'testuser'
    test_password = 'testpassword'
    test_distribution = 'systemd'
    test_reboot_command = 'reboot'
    test_reboot_timeout = 120
    test_connect_timeout = 60
    test_no_reboot_pat = 'No rebooting required'

    # Setup inventory plugin
    # inventory_plugin_args = dict(
    #     host_list=test_hostname,
    #     group_list=[''],
    #     cache=False,
    #     runner_cache=False,
    #     host_pattern_key='inventory_hostname',
    #

# Generated at 2022-06-21 02:37:58.501439
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    try:
        raise TimedOutException("Test Exception")
    except TimedOutException as e:
        assert e.args[0] == "Test Exception"

    try:
        raise TimedOutException("")
    except TimedOutException as e:
        assert e.args[0] == ""



# Generated at 2022-06-21 02:38:05.112553
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    action = ActionModule(task=Mock(), connection=Mock(), play_context=Mock(), loader=Mock(), templar=Mock(), shared_loader_obj=Mock())
    action._get_value_from_facts = Mock(return_value="value_from_facts")
    action._get_shutdown_binary_path = Mock(return_value="/usr/bin/shutdown")
    action._task.args = dict(shutdown_command=None)
    action._task.action = "reboot"
    result = action.get_shutdown_command(dict(), "distribution")
    ASSERT_EQUAL(result, "/usr/bin/shutdown")

# Generated at 2022-06-21 02:38:05.764799
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None)
    assert action

# Generated at 2022-06-21 02:38:14.148602
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    host = 'foo'
    task = dict(action='bar', args=dict())
    # Return value of ActionModule.run_test_command().
    result = dict()
    # Optional arguments of MockExecuteModule.__init__().
    class_args = dict()
    # Return value of MockExecuteModule.get_distribution().
    distribution = None
    # Return value of MockExecuteModule.get_shutdown_command().
    shutdown_command = 'cowsay "Moo"'
    # Return value of MockExecuteModule.get_shutdown_command_args().
    shutdown_command_args = '-h'
    # Return value of MockExecuteModule.get_system_boot_time().
    boot_time = '2000-01-01 00:00:01'


# Generated at 2022-06-21 02:38:20.169639
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    from ansible.modules.system import reboot
    from ansible.module_utils.facts.virtual import Virtual
    from ansible.module_utils.facts.system import System
    from ansible.module_utils.facts.collector import BaseFactCollector
    
    

# Generated at 2022-06-21 02:38:26.947087
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    task_vars = {'ansible_facts': {}}
    task_vars['ansible_facts']['distribution'] = 'DEFAULT'
    task_vars['ansible_facts']['distribution_release'] = 'DEFAULT'
    task_vars['ansible_facts']['distribution_version'] = 'DEFAULT'

    module = ActionModule()
    module._connection = FakeConnection()
    module._task = Mock()
    module._task.args = {'reboot_timeout': module.DEFAULT_REBOOT_TIMEOUT}
    module._task.action = 'reboot'

    result = module.perform_reboot(task_vars, 'DEFAULT')
    assert module._connection.test_method_called
    assert "Reboot command failed. Error was: 'DEFAULT_ERROR'"

# Generated at 2022-06-21 02:38:31.253234
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    # TODO:
    # -Parameterize each test for ActionModule.run_test_command
    # -Create actual unit test
    pass # Nothing to do here


# Generated at 2022-06-21 02:39:17.116327
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Mock the low level execute_command method
    def _low_level_execute_command(command, sudoable=False, **kwargs):
        if command == 'reboot':
            return {'stdout': '', 'stderr': '', 'rc': 0}
        return {'stdout': '', 'stderr': '', 'rc': 3}

    # Mock method get_shutdown_command of class ActionModule to return a value
    def _get_shutdown_command(self, task_vars):
        return 'shutdown'

    # Mock method get_shutdown_command_args of class ActionModule to return a value
    def _get_shutdown_command_args(self, distribution):
        return ''

    # Mock method get_distribution of class ActionModule to return a value

# Generated at 2022-06-21 02:39:18.630049
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()



# Generated at 2022-06-21 02:39:26.999735
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    action = reboots.ActionModule(None, {}, {}, {}, None, {})
    task_vars = {'ansible_facts': {'SHUTDOWN_COMMANDS': {'Fedora': '/bin/systemctl'}}}
    shutdown_command = action.get_shutdown_command(task_vars)
    assert shutdown_command == '/bin/systemctl'


# Generated at 2022-06-21 02:39:35.150857
# Unit test for constructor of class ActionModule

# Generated at 2022-06-21 02:39:40.759009
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
#
# Tests for method `deprecated_args` of class `ActionModule`
#
#
    class test_ActionModule_deprecated_args(unittest.TestCase):

        # Unit test for method deprecated_args of class ActionModule
        def test_ActionModule_deprecated_args(self):
            # Test for method `deprecated_args` of class `ActionModule`
            # Create an instance of the class to test
            # self.assertRaises(Exception, AnsibleActionModule.deprecated_args)
            raise SkipTest  # TODO: implement your test here


# Generated at 2022-06-21 02:39:53.714392
# Unit test for method run of class ActionModule

# Generated at 2022-06-21 02:40:02.235860
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    host_vars = {
        'ansible_distribution': 'Debian',
        'ansible_distribution_version': '8',
        'ansible_distribution_release': 'jessie',
    }
    task_vars = {
        'ansible_facts': {
            'hostvars': {
                'localhost': host_vars,
            }
        }
    }
    module = ActionModule(None, None)
    distribution = module.get_distribution(task_vars)
    assert distribution['distribution'] == 'Debian'
    assert distribution['major_version'] == 8
    assert distribution['release'] == 'jessie'


# Generated at 2022-06-21 02:40:13.065619
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    hostvars = dict()
    display = Display()
    play_context = PlayContext()
    play_context.prompt = dict()
    play_context.prompt['reboot_timeout'] = 300
    connection = Connection()
    connection._play_context = play_context
    connection._new_stdin = six.StringIO()

    connection._new_stdin_write = connection._new_stdin.write

    def _new_stdin_write(data):
        connection._new_stdin_write(data)
        connection._new_stdin.seek(0)

    connection._new_stdin_write = _new_stdin_write
    connection._connected = True
    connection._shell = None

    module_args = dict()

# Generated at 2022-06-21 02:40:19.516105
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module = ActionModule()

    # If distribution is none and task_vars is an empty dict, default shutdown command args should be returned.
    distribution = None
    assert(action_module.get_shutdown_command_args(distribution) == ActionModule.DEFAULT_SHUTDOWN_COMMAND_ARGS)

    # If distribution is 'RedHat' from the input task_vars, reboot should be returned.
    distribution_redhat = 'RedHat'
    task_vars_redhat = {'ansible_distribution': distribution_redhat}
    assert(action_module.get_shutdown_command_args(distribution_redhat, task_vars_redhat) == 'reboot')

    # If distribution is 'CentOS' from the input task_vars, r should be returned.

# Generated at 2022-06-21 02:40:32.091677
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.plugins.action import ActionBase
    from datetime import datetime, timedelta

    class MockModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            super(AnsibleModule, self).__init__(*args, **kwargs)
            self.exit_args = None
            self.exit_json = self.exit
            self.fail_json = self.fail
        def exit(self, *args, **kwargs):
            self.exit_args = {'args': args, 'kwargs': kwargs}
            raise Exception('EXIT!')

# Generated at 2022-06-21 02:43:19.527477
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action = {}

    task = {}
    task['action'] = 'reboot'
    task['args'] = {}
    action['task'] = task

    play_context = {}
    action['play_context'] = play_context

    connection = {}
    action['connection'] = connection

    display = MagicMock()

    # Setup is complete, now start the tests
    test_obj = ActionModule(
        action,
        display,
        connection,
        '/tmp/ansible/test_action_plugin.py',
        '/tmp/ansible/test_action_plugin.py',
        False  # no check_mode
    )

    test_obj.deprecated_args()
    return



# Generated at 2022-06-21 02:43:30.409738
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    # Arrange
    action_module = ActionModule(dict(
        _task=dict(
            args=dict(
                test_command=None,
                reboot_timeout=1,
                connect_timeout=None
            ),
            action='reboot'
        ),
        _play_context=dict(
            check_mode=True,
            connection='local'
        ),
        _supports_check_mode=True,
        _supports_async=True
    ))

    with patch.object(action_module, 'get_distribution') as mocked_get_distribution:
        mocked_get_distribution.return_value = 'Windows'

# Generated at 2022-06-21 02:43:40.945148
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    from ansible import context
    from ansible.utils.vars import combine_vars
    from ansible.module_utils.connection import Connection

    context.CLIARGS = ImmutableDict(connection='ssh', forks=10, become=None,
                                    become_method=None, become_user=None, check=False, module_path=None,
                                    diff=False, syntax=False, start_at=None)
    constants_values = {
        'DEFAULT_REBOOT_TIMEOUT': 60,
    }
    class AnsibleModuleMock(object):
        def __init__(self, return_values=None):
            self.params = {
                'reboot_timeout': 60
            }
            if return_values:
                self.params = combine_vars(self.params, return_values)


# Generated at 2022-06-21 02:43:53.579058
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    t = {
        'distribution': 'Linux',
        'assert': 'REBOOTED_MESSAGE',
        'rebooted_msg': 'hooray',
        'rc': 0,
        'stdout': 'hooray',
        'stderr': '',
    }

    # Check that if test_command returns specific msg, then the rebooted
    # variable is set to True
    module = ActionModule()
    module._task = MagicMock()
    module._task.action = 'reboot'
    module._task.args = {
        'test_command': 'echo REBOOTED_MESSAGE=hooray',
    }

    module._low_level_execute_command = MagicMock(return_value=t)


# Generated at 2022-06-21 02:43:56.946146
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    """
    Test method do_until_success_or_timeout of class ActionModule
    """
    action_module_reboot = copy.deepcopy(action_module_reboot_initialized)
    action_module_reboot.do_until_success_or_timeout(action=action_module_reboot.check_boot_time, action_desc="last boot time check", reboot_timeout=360, distribution='Ubuntu', action_kwargs={'previous_boot_time': '2020-08-12 2:18 PM'})

# Generated at 2022-06-21 02:44:02.689772
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    # Create mock object for ActionModule class
    action_module = MagicMock(spec=ActionModule)
    # Perform test
    try:
        action_module.get_system_boot_time
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-21 02:44:06.936784
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    """
    Simple unit test for class TimedOutException
    """
    e = TimedOutException()
    assert e is not None
    assert isinstance(e, Exception)
    assert str(e) is not None and len(str(e)) > 0



# Generated at 2022-06-21 02:44:07.992863
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:44:10.694318
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Basic test required for AnsibleModule class
    am = ActionModule()
    assert(am is not None)

# Generated at 2022-06-21 02:44:12.362779
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    
    pass



# Generated at 2022-06-21 02:45:45.784477
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    task_vars = {
        'ansible_facts': {
            'distribution': 'centos',
            'virtualization_role': 'guest'
        }
    }
    am = ActionModule(dict(ANSIBLE_MODULE_ARGS={}, ANSIBLE_MODULE_CONSTANTS={}, ANSIBLE_MODULE_COMPLEX_ARGS={}))
    am._task = FakeTask()
    am._task.args = {'shutdown_command': 'test'}
    am._task.action = 'reboot'
    am._connection = FakeConnection()
    am.DEFAULT_SUDOABLE = False
    assert am.get_shutdown_command(task_vars, 'centos') == 'test'

    task_vars['ansible_facts']['ansible_virt_type']

# Generated at 2022-06-21 02:45:54.972364
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    # GIVEN: Instantiation of ActionModule class with mock task
    reboot_action = ActionModule(MagicMock(action='reboot'))
    reboot_action._task.args = {'pre_reboot_delay': 1}
    # WHEN: deprecated_args is called
    reboot_action.deprecated_args()
    # THEN: assert that a deprecation warning is shown
    assert reboot_action._task.action in ['reboot']

    # Another test with a non existent action name
    reboot_action = ActionModule(MagicMock(action='reboot_invalid'))
    reboot_action._task.args = {'pre_reboot_delay': 1}
    # WHEN: deprecated_args is called
    reboot_action.deprecated_args()
    # THEN: assert that a deprecation warning is shown
    assert reboot

# Generated at 2022-06-21 02:46:00.912900
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    from ansible.module_utils.six.moves import StringIO
    stdout = StringIO()
    m = mock_module(stdout=stdout)
    m.params = create_params()
    m.params['use_reboot'] = True
    m.params['post_reboot_delay'] = 1
    m.params['shutdown_timeout'] = 1
    m.params['reboot_timeout'] = 2
    m.params['test_command'] = 'test'

    am = ActionModule(m)
    am.deprecated_args()
    content = stdout.getvalue()
    assert 'use_reboot' in content
    assert 'post_reboot_delay' in content
    assert 'shutdown_timeout' in content
    assert 'reboot_timeout' in content

# Generated at 2022-06-21 02:46:12.532437
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    """
    Test get_system_boot_time method of class ActionModule
    """
    
    ################
    #
    # prepare mocks
    boot_time_command = 'get boot time command'
    expected_command_result = {'rc': 0, 'stdout': 'last boot time', 'stderr': ''}
    get_system_boot_time_mock = mock.MagicMock()
    get_system_boot_time_mock.side_effect = lambda distribution: boot_time_command
    low_level_execute_command_mock = mock.MagicMock()
    low_level_execute_command_mock.side_effect = lambda command, sudoable: expected_command_result
    
    
    
    #
    ################
    # make call
    action_module_instance

# Generated at 2022-06-21 02:46:23.023482
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class MockConnection(Connection):
        def __init__(self, *args, **kwargs):
            super(MockConnection, self).__init__(*args, **kwargs)
            self.transport = 'local'

    class MockPlayContext(object):
        def __init__(self):
            self.check_mode = False

    class MockRunner(object):
        def __init__(self):
            self._connection = MockConnection()
            self._play_context = MockPlayContext()

        def get_var(self, *args, **kwargs):
            return "Test"

    class MockTask(object):
        def __init__(self):
            self.action = 'reboot'
            self.args = {}

    obj = Reboot(task=MockTask(), runner=MockRunner())
    assert obj is not None

# Generated at 2022-06-21 02:46:30.144922
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    # gets the value of a specific field for a specific array in a given property
    manager = ModuleManager('reboot')
    distro_info = {}
    distro_info['BOOT_TIME_COMMANDS'] = {
        'DEFAULT_BOOT_TIME_COMMAND': 'get_boot_time'
    }
    res = manager.get_system_boot_time(distro_info)
    assert res == 'get_boot_time'


# Generated at 2022-06-21 02:46:43.856930
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = None
    task_vars = None

    # set up mocks and stubs
    action_module = Reboot(task=Mock(), connection=Mock(), play_context=Mock(), loader=Mock(), templar=Mock())
    task = action_module._task = Mock()
    connect = task.args = {'msg': '', 'post_reboot_delay': 0, 'reboot_timeout': 90, 'test_command': 'echo "123"'}
    connection = action_module._connection = Mock()
    connection.transport = 'local'
    play_context = action_module._play_context = Mock()
    play_context.check_mode = True
    task_vars = {}

    # run the code
    result = action_module.run(tmp,task_vars=None)

    #

# Generated at 2022-06-21 02:46:46.792074
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    try:
        raise TimedOutException()
    except TimedOutException:
        pass



# Generated at 2022-06-21 02:46:55.793722
# Unit test for method get_shutdown_command of class ActionModule