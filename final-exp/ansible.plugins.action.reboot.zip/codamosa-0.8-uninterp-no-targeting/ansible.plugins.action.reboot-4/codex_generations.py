

# Generated at 2022-06-21 02:37:40.589550
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Initialize values and execute method
    action_module = ActionModule()
    task_vars = dict()
    task_vars['ansible_processor_vcpus'] = 0
    task_vars['ansible_processor_cores'] = 0
    task_vars['ansible_architecture'] = 'arm'
    distribution = ''
    actual = action_module.get_shutdown_command(task_vars, distribution)

    assert actual == 'sudo shutdown -r now'


# Generated at 2022-06-21 02:37:48.183274
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():

    action = ActionModule()

    test_distribution = action._get_value_from_facts('DISTRIBUTION_NAME', 'rhel', 'FALLBACK_DISTRIBUTION')
    task_vars = {'ansible_distribution': 'rhel'}

    distribution = action.get_distribution(task_vars)
    assert distribution == test_distribution


# Generated at 2022-06-21 02:37:57.290321
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():

    class MockTask(object):
        def __init__(self, args={}):
            self.args = args
            
    class MockDistribution(object):
        def __init__(self):
            pass
        
    class MockFacts(object):
        def __init__(self, get_ansible_facts):
            self.get_ansible_facts = get_ansible_facts
            self.ansible_facts = {}
            
        def get_ansible_facts(self):
            return self.ansible_facts
        
    class MockModule(object):
        def __init__(self):
            self.params = {}

    class MockConnection(object):
        def __init__(self):
            self.transport = "local"
            

# Generated at 2022-06-21 02:38:05.219692
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    # mock settings for get_shutdown_command_args
    task = mock.Mock()
    task.action = 'reboot'
    mock_settings = {
        'TASK': task,
        '_CONNECTION_PLUGIN_PATH': '/_CONNECTION_PLUGIN_PATH'
    }
    mock_shutdown_command_args = 'mock_shutdown_command_args'
    mock_ansible_version = 'mock_ansible_version'

    task = mock.Mock()
    task.action = 'reboot'
    action_module = ActionModule(task=task, connection=mock.Mock(), templar=Templar(), shared_loader_obj=BaseLoader())

    # Perform test task

# Generated at 2022-06-21 02:38:10.251693
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    with TimedOutException(u'\u0039') as e:
        # Exception object should return unicode when converted to text
        assert isinstance(e, TimedOutException)
        assert isinstance(to_text(e), unicode)



# Generated at 2022-06-21 02:38:23.571181
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    action = ActionModule('reboot', {})
    action._task = Mock()
    action._task.action = 'reboot'
    action.DEFAULT_REBOOT_TIMEOUT = 240
    action.MAX_FAIL_SLEEP = 240
    action.post_reboot_delay = 0
    action._connection = Mock()
    action._connection.transport = 'test_transport'
    command_result_default = dict(rc=0,
                                  stdout='',
                                  stderr='')

    # test with no exception
    def test_action_no_exception(distribution, action_kwargs={}):
        pass


# Generated at 2022-06-21 02:38:36.496421
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    class Args(object):

        def __init__(self, **kwargs):
            for key in kwargs:
                setattr(self, key, kwargs[key])

    class Task(object):

        def __init__(self, **kwargs):
            for key in kwargs:
                setattr(self, key, kwargs[key])

    class Connection(object):

        def __init__(self, **kwargs):
            for key in kwargs:
                setattr(self, key, kwargs[key])

    class Host(object):

        def __init__(self):
            self.has_pipelining = True
            self.get_connection = lambda: Connection(transport='paramiko')

    class PlayContext(object):

        def __init__(self):
            self.check

# Generated at 2022-06-21 02:38:44.392095
# Unit test for method perform_reboot of class ActionModule

# Generated at 2022-06-21 02:38:48.801382
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module_instance = get_action_module_instance()

    action_module_instance.check_boot_time(distribution=None, previous_boot_time=None)

# Generated at 2022-06-21 02:38:52.154799
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action_module = ActionModule(task_vars=dict())
    assert action_module.deprecated_args() is None


# Generated at 2022-06-21 02:40:12.186243
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actions = [
        'reboot', 'reboot_notify']
    args_1 = {
        'msg': 'This will reboot your system',
        'connect_timeout': '10'
    }
    args_2 = {
        'test_command': 'echo OK',
        'reboot_timeout': '300'
    }
    expected_hostname = 'myhostname'
    facts_data = {'distribution': 'Ubuntu', 'distribution_major_version': '14.04', 'distribution_release': 'trusty'}
    facts = FakeAnsibleFacts(facts_data)
    task = FakeAnsibleTask()
    task._connection.host.name = expected_hostname
    result = {'stdout': '', 'stderr': '', 'rc': 0}

# Generated at 2022-06-21 02:40:13.361621
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    ActionModule().perform_reboot(task_vars, distribution)

# Generated at 2022-06-21 02:40:15.306182
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    assert TimedOutException('error message')


# Generated at 2022-06-21 02:40:24.800508
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    argv = ['ansible-reboot']
    parser = cli.CLI(
        argv,
        connection_loader=None,
        module_loader=None,
        stdout_callback=None,
        run_tree=False)
    parser.parse()

    current_host = 'hostname'
    current_task = Task()
    current_task.action = 'reboot'
    current_task.args = {'test_attribute': 1}

    current_play_context = PlayContext()
    current_play_context.remote_addr = 'some.remote.addr'
    current_play_context.connection = 'fake'
    current_play_context.remote_user = 'some.remote.user'

    current_connection = Connection()

# Generated at 2022-06-21 02:40:26.810181
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    pass


# Generated at 2022-06-21 02:40:28.317507
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    pass


# Generated at 2022-06-21 02:40:34.796618
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # Test to check the method check_boot_time of class ActionModule
    # Unit test for method check_boot_time of class ActionModule

    # Testing with success status

    test_obj = ActionModule(task=Task('test_task', None))
    test_obj.check_boot_time('test_distribution', 'test_previous_boot_time')

    # Testing with failure status

    test_obj = ActionModule(task=Task('test_task', None))

    with pytest.raises(TimedOutException):
        test_obj.check_boot_time('test_distribution', 'test_previous_boot_time')

# Generated at 2022-06-21 02:40:40.904570
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    action_module = AnsibleModule(
        argument_spec=dict(
            search_paths=dict(required=False, type='str', default='/usr/bin,/bin,/usr/sbin')
        )
    )
    action = ActionModule(action_module._task, action_module._connection, action_module._play_context, action_module._loader, action_module._templar, action_module._shared_loader_obj)
    boot_time_command = action._get_value_from_facts('BOOT_TIME_COMMANDS', 'RedHat', 'DEFAULT_BOOT_TIME_COMMAND')
    assert action.get_system_boot_time('RedHat') == boot_time_command


# Generated at 2022-06-21 02:40:42.136693
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    pass


# Generated at 2022-06-21 02:40:52.716312
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    module = ActionModule(action=dict(name='reboot', args={'shutdown_command_args': '-r now'}), play_context=dict(become=None))
    module_args = {}
    task_vars = {}

    # test default
    actual_result = module.get_shutdown_command(task_vars, 'foo')
    assert actual_result == 'shutdown'

    # test override for valid value
    task_vars['ansible_reboot_command'] = 'shutdown_override'
    actual_result = module.get_shutdown_command(task_vars, 'foo')
    assert actual_result == 'shutdown_override'

    # test override for invalid value
    task_vars['ansible_reboot_command'] = 'shutdown_override'

# Generated at 2022-06-21 02:41:39.652359
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    try:
        raise TimedOutException("some message")
    except TimedOutException as e:
        assert to_text(e) == to_text("some message")



# Generated at 2022-06-21 02:41:43.830731
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    action_module = ActionModule()
    action_module.do_until_success_or_timeout('test',1,'test_desc', 'test_distribution',{'action_kwargs':2})


# Generated at 2022-06-21 02:41:46.690542
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    am = ActionModule()
    # get_system_boot_time(self, distribution):
    assert False



# Generated at 2022-06-21 02:41:53.549541
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    am = ActionModule()

    # Generate data for test
    distribution = 'CentOS'
    expected_value = '-r now'

    # Run test
    actual_value = am.get_shutdown_command_args(distribution)

    # Assertions
    assert(actual_value == expected_value)


# Generated at 2022-06-21 02:41:55.996873
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionModule = ActionModule()
    result = actionModule.run()
    assert result is not None

# Generated at 2022-06-21 02:42:01.716005
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = MagicMock(name='host')

    task = MagicMock(name='task')
    task.action = 'reboot'

    tmp = tempfile.mkdtemp()
    execute_module(tmp, 'reboot', host, task=task)

# Generated at 2022-06-21 02:42:08.808390
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    obj_ActionModule = ActionModule(task=MagicMock(), connection=MagicMock(), play_context=MagicMock())
    obj_ActionModule.DEFAULT_REBOOT_TIMEOUT = 120
    method_parm_task_vars = MagicMock()
    method_parm_task_vars.get = MagicMock()
    method_parm_distribution = MagicMock()
    method_return = obj_ActionModule.perform_reboot(task_vars=method_parm_task_vars, distribution=method_parm_distribution)
    assert method_return is None


# Generated at 2022-06-21 02:42:20.369658
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class MockTask():
        def __init__(self):
            self.service = 'reboot'
            self.args = dict()

    class MockPlayContext():
        def __init__(self):
            self.check_mode = False
            self.become = False

    class MockRoot():
        def __init__(self):
            host_vars = dict()
            self.host_vars = host_vars
            self.key_path = None

    class MockSetupCache():
        def __init__(self):
            pass

        def get(self, key, default=None):
            return dict()

    class MockConnection():
        transport = 'ssh'

    my_action = ActionModule()
    my_action.task = MockTask()
    my_action.play_context = MockPlayContext()
    my_

# Generated at 2022-06-21 02:42:33.651136
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    # Initialize the object
    obj = ActionModule('task', 'connection')

    # Test with unsupported distribution
    distribution = 'Unsupported Distribution'
    desired_result = ''
    actual_result = obj.get_shutdown_command_args(distribution)
    assert actual_result == desired_result

    # Test with supported distribution
    distribution = 'Ubuntu'
    desired_result = ''
    actual_result = obj.get_shutdown_command_args(distribution)
    assert actual_result == desired_result

    # Test with supported distribution
    distribution = 'RedHat'
    desired_result = '-r now'
    actual_result = obj.get_shutdown_command_args(distribution)
    assert actual_result == desired_result

# Generated at 2022-06-21 02:42:47.307226
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule()
    m._play_context = PlayContext()
    m._play_context.check_mode = False
    m._play_context.remote_addr = None
    m._connection = object()
    m._task = object()
    m._task.action = "Reboot"
    m._task.args = { 'connect_timeout': 10, 'reboot_timeout': 10, 'post_reboot_delay': 0, 'test_command': 'echo 1'}
    m._task.module_vars = {}
    m._task.module_vars['ansible_distribution'] = 'foo'
    m._task.delegate_to = None
    m._task.register = None
    m._task.run_once = None

    m.run()

# Generated at 2022-06-21 02:44:21.218197
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # can't mock this due to function signature
    return True

# Generated at 2022-06-21 02:44:23.199774
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    assert len(str(TimedOutException())) > 0



# Generated at 2022-06-21 02:44:31.491511
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    vars = { 'ansible_facts': { 'distribution': 'Ubuntu' } }
    task_vars = { 'vars': vars }

    module_args = dict(test_command='test_command', test_command_args='test_command_args')
    mock_task = MagicMock(args=module_args)

    mock_task.action = 'reboot'
    am = ActionModule(mock_task, MagicMock(), MagicMock(), MagicMock(), connection='connection', play_context='play_context', loader='loader', templar='templar', shared_loader_obj='shared_loader_obj')
    result = am.deprecated_args()
    assert result is None


# Generated at 2022-06-21 02:44:42.087554
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.analysis import module_args_parser
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils._text import to_native
    from ansible.errors import AnsibleError

    module_args = dict(
        reboot_timeout=1,
        connect_timeout=30,
        test_command='/bin/true',
    )


# Generated at 2022-06-21 02:44:51.531249
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # method definition to run for test
    def mock_get_distribution(self):
        return 'DUMMY_DISTRIBUTION'
    # monkey patching object
    ActionModule.get_distribution = mock_get_distribution
    # call test method
    action_module = ActionModule(
        task=Mock(action='reboot'),
        connection=Mock(name='connection', transport='ssh', close=None, _shell=None, _play_context=None),
        play_context=Mock(name='play_context', password=None, check_password_support=None),
        loader=Mock(name='loader'),
        templar=Mock(name='templar'),
        shared_loader_obj=Mock(name='shared_loader_obj'),
    )
    result = action_module.get_

# Generated at 2022-06-21 02:44:57.669470
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    # Default values for instantiated variables
    DEFAULT_TEST_COMMAND = 'date'
    DEFAULT_REBOOT_TIMEOUT = 6000
    DEFAULT_NUMBER_OF_RETRIES = 1
    DEFAULT_CONNECT_TIMEOUT = 10
    DEFAULT_BOOT_TIME_COMMAND = 'date'
    DEFAULT_SHUTDOWN_COMMAND = 'shutdown'

    # Declaration of values for instantiated variables
    task_vars = [
        {
            'ansible_facts': {
                'distribution':'Ubuntu'
            }
        }
    ]
    distribution = 'Ubuntu'
    action_kwargs = {
        'previous_boot_time':'14/12/2018'
    }
    original_connection_timeout = 100
    DEFAULT_TEST_

# Generated at 2022-06-21 02:45:08.011193
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    action_module = get_action_module()
    action_module._task.args = {}
    # Test case 1
    distribution = 'TEST_DISTRIBUTION'
    action_kwargs = {'previous_boot_time': 'TEST_PREVIOUS_BOOT_TIME', 'foo': 'bar'}
    action_module.do_until_success_or_timeout(action_module.check_boot_time, 10, 'last boot time check', distribution, action_kwargs)


# Generated at 2022-06-21 02:45:19.971864
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(ActionModule.ActionModule, {})
    assert type(action_module) is ActionModule
    assert action_module.DEFAULT_BOOT_TIME_COMMAND == 'uptime -s'
    assert action_module.DEFAULT_TEST_COMMAND == 'date +%s'
    assert action_module.DEFAULT_REBOOT_TIMEOUT == 300
    assert action_module.DEFAULT_CONNECT_TIMEOUT == 10.0
    assert action_module.REBOOT_COMMAND == ['reboot', 'shutdown -h', 'shutdown -r']
    assert action_module.REBOOT_COMMAND_ARG == ['--force', '-P', '-r']

# Generated at 2022-06-21 02:45:22.926261
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    e = TimedOutException('test')
    assert e.args[0] == 'test'



# Generated at 2022-06-21 02:45:33.145448
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    args = {}
    args.update({'delete_remote_tmp': False})
    args.update({'delegate_to': None})
    args.update({'diff': False})
    args.update({'module_name': None})
    args.update({'play_context': None})
    args.update({'stdin': None})

    actual_result = ActionModule.deprecated_args(args)
    # Assertion fails if result is None
    assert actual_result != None, "ActionModule.deprecated_args() returned None"
    # Asserts if actual_result is not equal to expected_result
    assert actual_result == expected_result, "ActionModule.deprecated_args() returned unexpected value"
