

# Generated at 2022-06-21 02:37:37.030015
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    m_object = ActionModule()
    m_object.get_shutdown_command_args(distribution='my_distribution')

# Generated at 2022-06-21 02:37:41.027484
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    try:
        raise TimedOutException
    except Exception as ex:
        assert True



# Generated at 2022-06-21 02:37:52.401951
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    args_file = "testActionModule_get_system_boot_time_args.txt"
    with open(args_file, "w") as f:
        f.write("{\"debug\": false, \"_ansible_verbosity\": 0, \"_ansible_no_log\": false, \"_ansible_syslog_facility\": \"LOG_USER\", \"action\": \"reboot\", \"connect_timeout\": 30, \"reboot_timeout\": 600, \"msg\": null, \"paths\": [\"/bin\"], \"distribution\": \"Linux\"}\n")
    # Create task object
    task = Task()
    # Create task_vars object
    task_vars = {"ansible_facts": {}}

    am = ActionModule(task, task_vars)
    # get_system_boot_time of class ActionModule
   

# Generated at 2022-06-21 02:38:01.715997
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # Fails if the method check_boot_time not exists
    if (not hasattr(ActionModule, "check_boot_time")):
        raise AssertionError("The method 'check_boot_time' not exists")

    # Fail if the return type of method check_boot_time is not the expected
    # See: https://docs.python.org/3/library/unittest.mock.html#unittest.mock.Mock.assert_called_with
    if (not isinstance(ActionModule.check_boot_time(ActionModule, distribution=mock.ANY), None.__class__)):
        raise AssertionError("Expected return of method check_boot_time is None, but not")



# Generated at 2022-06-21 02:38:05.817812
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    timed = TimedOutException("Timed Out")
    assert isinstance(timed, TimedOutException)
    assert str(timed) == "Timed Out"


# Generated at 2022-06-21 02:38:17.195343
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Create a Mock object
    mock_ActionModule = Mock(spec_set=ActionModule, name='mock_get_shutdown_command')
    task_vars = dict(ansible_facts=dict(ansible_os_family='some_family'))

    # Set instances attribute of Mock object to mock_instance
    #mock_ActionModule._task.args = mock_args
    mock_ActionModule._task.action = 'reboot'
    mock_ActionModule._task.args = dict(
        shutdown_command = '/test/shutdown/command'
    )
    # Call the method under test, passing the mock object
    ret = ActionModule.get_shutdown_command(mock_ActionModule, task_vars)

    # Check if the called method using the mock object returned the expected result

# Generated at 2022-06-21 02:38:22.058481
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    try:
        raise TimedOutException('message')
    except TimedOutException as e:
        assert 'message' == e.message
    else:
        raise Exception('test_TimedOutException failed')
# END Unit test for constructor of class TimedOutException



# Generated at 2022-06-21 02:38:33.342952
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    args = {u'action': u'reboot',
            u'test_command': u'echo'}

    def get_system_boot_time(distribution):
        pass

    module = ActionModule(self._play_context, args)
    module.get_system_boot_time = get_system_boot_time
    result = module.run_test_command(u'FreeBSD', distribution=u'FreeBSD')
    assert result == {'start': datetime.utcnow(),
                      'changed': False,
                      'failed': False,
                      'rebooted': False}


# Generated at 2022-06-21 02:38:42.020421
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # test ActionModule.do_until_success_or_timeout

    try:
        ActionModule.do_until_success_or_timeout(action=None, reboot_timeout=None, action_desc=None, distribution=None)
        assert False, "Expected AttributeError"
    except AttributeError:
        pass

    try:
        ActionModule.do_until_success_or_timeout(action=None, reboot_timeout=None, action_desc=None, distribution=None, action_kwargs=None)
        assert False, "Expected AttributeError"
    except AttributeError:
        pass

    try:
        ActionModule.do_until_success_or_timeout(None, None, None, None, None)
        assert False, "Expected AttributeError"
    except AttributeError:
        pass


# Generated at 2022-06-21 02:38:55.029401
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Initializing constant variables
    from ansible.module_utils.six import PY3, PY2
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils import basic

    if PY2:
        py_version = 2
    elif PY3:
        py_version = 3

    # Constructing object
    am = ActionModule(task=dict(action='reboot', args=dict(msg='test')), connection=dict(), play_context=dict(), loader=dict(), templar=basic.AnsibleTemplar(), shared_loader_obj=None)
    # Getting members of object
    # String representation of object
    test_str = str(am)

# Generated at 2022-06-21 02:39:32.797846
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import tempfile
    import yaml

    from ansible.module_utils._text import to_bytes
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader

    class AnsibleModule:
        def __init__(self, argument_spec, bypass_checks):
            self.argument_spec = argument_spec
            self.params = {}

    class Connection:
        class _socket_connection:
            def __init__(self, sock):
                self.sock = sock

            def sendall(self, data):
                pass
        def __init__(self, *args, **kwargs):
            self.transport = 'ssh'
           

# Generated at 2022-06-21 02:39:41.354531
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    type('', (), {})  # make the class testable in py2 (otherwise test_cases will skip it)
    action_module = ActionModule(task=MagicMock(), connection=MagicMock(), play_context=MagicMock(), loader=None, templar=None, shared_loader_obj=None)
    search_paths = ["/usr/bin", "/sbin", "/usr/sbin"]
    shutdown_bin = "shutdown"
    display.deprecated("Deprecated")

# Generated at 2022-06-21 02:39:43.856631
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    try:
        raise TimedOutException("test")
    except TimedOutException as e:
        assert e.args[0] == "test"
        assert str(e) == "test"



# Generated at 2022-06-21 02:39:48.331843
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_test = ActionModule(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module_test._task.action == 'reboot'

# Generated at 2022-06-21 02:39:59.014927
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    import tempfile
    from ansible.utils.path import makedirs_safe
    makedirs_safe("/tmp/action_plugins")
    my_file = open("/tmp/action_plugins/__init__.py", "w")
    my_file.close()
    makedirs_safe("/tmp/action_plugins/actions")
    my_file = open("/tmp/action_plugins/actions/__init__.py", "w")
    my_file.close()
    makedirs_safe("/tmp/facts_plugins")
    my_file = open("/tmp/facts_plugins/__init__.py", "w")
    my_file.close()
    makedirs_safe("/tmp/modules")
    my_file = open("/tmp/modules/__init__.py", "w")

# Generated at 2022-06-21 02:40:04.841875
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # Arrange
    action_module = ActionModule()
    
    # Act and Assert
    assert(action_module.check_boot_time(distribution='', previous_boot_time=''))
    
    

# Generated at 2022-06-21 02:40:14.212600
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    action = 'reboot'
    task_vars = dict()
    task_vars['ansible_' + action] = dict()
    task_vars['ansible_' + action]['distribution'] = 'RedHat'
    task_vars['ansible_' + action]['DEFAULT_REBOOT_TIMEOUT'] = 100
    task_vars['ansible_' + action]['DEFAULT_SHUTDOWN_COMMAND'] = 'shutdown'
    task_vars['ansible_' + action]['DEFAULT_SHUTDOWN_COMMAND_ARGS'] = '-r +1'
    task_vars['ansible_' + action]['SHUTDOWN_COMMANDS'] = dict()

# Generated at 2022-06-21 02:40:17.909341
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = RebootModule()
    assert str(type(module)) == "<class 'ansible_collections.ansible.community.plugins.action.reboot.RebootModule'>"

# Generated at 2022-06-21 02:40:20.869754
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    action = ActionModule()
    task_vars = {}
    result = action.perform_reboot(task_vars, 'test_distribution')
    assert result['start'] != None
    assert result['failed'] == False
    

# Generated at 2022-06-21 02:40:22.580205
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    am = ActionModule()
    am.get_shutdown_command



# Generated at 2022-06-21 02:41:24.326517
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    host_info = {}
    host_info['distribution'] = 'CentOS'
    host_info['distribution_major_version'] = '7'
    host_info_list = [host_info]
    task_vars = {}
    task_vars['ansible_facts'] = {'ansible_system': host_info['distribution'], 'ansible_distribution_major_version': host_info_list['distribution_major_version']}

    reboot_action = ActionModule(task_vars=task_vars)
    actual_result = reboot_action.get_distribution(task_vars)
    expected_result = 'CentOS' + ' ' + '7'

    assert actual_result == expected_result

# Generated at 2022-06-21 02:41:27.951640
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():

  action_module = ActionModule()

  assert action_module.run_test_command() == 'return_value'


# Generated at 2022-06-21 02:41:35.950129
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    task_vars = { 'ansible_facts': { 'TEST' : { 'SHUTDOWN_COMMANDS': {'DEFAULT_SHUTDOWN_TIMEOUT': '0',
                                                                       'DEFAULT_SHUTDOWN_COMMAND': '/sbin/shutdown',
                                                                       'DEFAULT_SHUTDOWN_COMMAND_SUDOABLE': False,
                                                                       'DEFAULT_SHUTDOWN_TIMEOUT_SUDOABLE': False} } } }
    distribution = "TEST"
    module = ActionModule(task_vars, task_vars)
    shutdown_command = module.get_shutdown_command(task_vars, distribution)
    assert shutdown_command == '/sbin/shutdown'


# Generated at 2022-06-21 02:41:45.321977
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    # Perform the test
    test_class = ActionModule(None, None)
    test_class.DEPRECATED_ARGS = {'foo': "1.0", 'bar': "1.1"}
    test_class._task.args = {
        'foo': 'foo1',
        'baz': 'baz1'
    }
    test_class.deprecated_args()
    # Expected result
    assert test_class._task.args == {
        'foo': 'foo1',
        'baz': 'baz1'
    }


# Generated at 2022-06-21 02:41:57.077187
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    args = {
        'reboot_timeout': 10,
        'post_reboot_delay': 0,
        'shutdown_timeout': 0,
        'action': 'reboot',
        '_ansible_no_log': False,
        '_ansible_check_mode': False,
        '_ansible_verbosity': 2,
        '_ansible_version': 'v2.4.0.0-1.el7',
        '_ansible_syslog_facility': 'LOG_USER',
        '_ansible_debug': True,
        '_ansible_diff': False
    }

    hostname = 'localhost'
    connection = 'smart'
    play_context = PlayContext()


# Generated at 2022-06-21 02:42:04.647230
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    print('test_ActionModule_do_until_success_or_timeout start')
    # self._task.action
    self_action = None
    # action_desc
    action_desc = None
    # reboot_timeout
    reboot_timeout = None
    # distribution
    distribution = None
    # action_kwargs
    action_kwargs = None
    print('test_ActionModule_do_until_success_or_timeout end')

# Generated at 2022-06-21 02:42:08.035904
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action = ActionModule()

    result1 = action.get_distribution({})

    assert result1 == 'default'

    result2 = action.get_distribution({'ansible_system': 'CentOS'})

    assert result2 == 'CentOS'

# Generated at 2022-06-21 02:42:19.301608
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host_vars = dict(ansible_facts=dict(distribution='Fedora'), ansible_host='localhost')
    task = dict(name='reboot test', action='reboot')
    play_context = PlayContext()
    connection = Connection(play_context=play_context)
    module = ActionModule(task=task, connection=connection, play_context=play_context)
    host_vars = dict(ansible_facts=dict(distribution='Fedora'), ansible_host='localhost')
    task_vars = dict(reboot=dict(fedora=dict(BOOT_TIME_COMMANDS=dict(time="/bin/echo \"Tue Feb 17 18:13:10 PST 2017\""))), ansible_facts=host_vars)
    result = module.run(task_vars=task_vars)
   

# Generated at 2022-06-21 02:42:20.831136
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass



# Generated at 2022-06-21 02:42:27.049894
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    e = TimedOutException("Message")
    assert e.msg == "Message"

try:
    from openshift.dynamic.exceptions import NotFoundError
    from openshift.dynamic.exceptions import ConflictError
    from openshift.dynamic.exceptions import ForbiddenError
    from openshift.dynamic.exceptions import UnauthorizedError
    from openshift.dynamic.exceptions import OpenshiftException
    HAS_OC_LIB = True
except ImportError:
    HAS_OC_LIB = False



# Generated at 2022-06-21 02:44:30.748029
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # Test with action_desc == None
    # Test with action_desc == ''
    task_vars = {}
    distribution = 'Ubuntu'
    original_connection_timeout = None
    action_kwargs = {}
    # Test with reboot_timeout > 0
    # Test with reboot_timeout < 0
    # Test with fail_count > 0
    # Test with fail_count == 0
    # Test with (datetime.utcnow() < max_end_time) == True
    # Test with (datetime.utcnow() < max_end_time) == False
    # Test with TimedOutException
    # Test with exception other than TimedOutException
    # Test with connect_timeout != original_connection_timeout
    # Test with connect_timeout == original_connection_timeout
    # Test with original_connection_timeout == None
   

# Generated at 2022-06-21 02:44:41.776822
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # mock an ansible connection
    # test for a successful reboot with given command
    def execute_command_mock(*args, **kwargs):
        command_result = {
            'stdout': '',
            'stderr': '',
            'rc': 0
        }
        return command_result
    am = ActionModule()
    am._low_level_execute_command = MagicMock(
        side_effect=execute_command_mock)
    am._task.args = {
        'shutdown_timeout': '20',
        'post_reboot_delay': '3'
    }
    result = am.perform_reboot(task_vars={}, distribution='test_dist')
    assert not result['failed']
    assert result['start']
    # test for an unsuccessful reboot with given command

# Generated at 2022-06-21 02:44:51.469370
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    test_class = ActionModule()
    test_class._task.args = dict()
    test_class._task.args['delay'] = 0
    test_class._task.args['reboot_timeout'] = 0
    test_class._task.args['reboot_timeout_sec'] = 0
    test_class._task.args['timeout'] = 0
    test_class._task.args['connect_timeout'] = 0
    test_class._task.args['connect_timeout_sec'] = 0
    test_class._task.args['test_command'] = ""
    test_class._task.args['shutdown_command'] = ""
    test_class._task.args['shutdown_timeout'] = 0
    test_class._task.args['shutdown_timeout_sec'] = 0

# Generated at 2022-06-21 02:44:59.567629
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    args = dict(
        ansible_system_distribution='DISTRIB',
        ansible_distribution='DIST',
        ansible_distribution_version='VERSION',
        ansible_distribution_release='RELEASE',
        ansible_os_family='OS_FAMILY',
    )
    module = ActionModule(dict(), dict(module_args=args))
    assert module.get_distribution(module) == 'DIST'


# Generated at 2022-06-21 02:45:02.114123
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_class = ActionModule()
    assert test_class is not None


# Generated at 2022-06-21 02:45:08.990369
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    action_module_instance = ActionModule()
    distribution = "test"
    try:
        action_module_instance.run_test_command(distribution)
    except NotImplementedError as e:
        print("test_ActionModule_run_test_command: test not implemented", e)
    print("ActionModule_run_test_command is_implemented: False")

# Generated at 2022-06-21 02:45:20.841004
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    action_module = ActionModule()
    try:
        result = action_module.get_shutdown_command(None, "red_hat")
    except AssertionError as e:
        assert str(e) == "Distribution `red_hat` is not supported"


# Generated at 2022-06-21 02:45:32.810485
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # mock hostvars
    hostvars = dict(ansible_all_ipv4_addresses=["192.168.0.2"])

    # mock AnasibleTask
    task = 'AnsibleTask'

    # mock Ansibleplay
    play = 'AnsiblePlay'

    # mock Ansible
    ansible = 'Ansible'

    # mock AnsibleRunner
    ansible_runner = 'AnsibleRunner'

    # mock ActionModule
    # ActionModule is the class that contains the method under test
    action_module = ActionModule(task, play, ansible, ansible_runner)

    # TESTS AND ASSERTIONS
    # test perform_reboot method by calling it with the arguments below
    # In order to provide a successful reboot, we must mock the reboot command
    # and have it return zero

# Generated at 2022-06-21 02:45:45.644451
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    self = AnsibleModule()
    self._task = AnsibleTask()
    self._task.action = "test"
    self._task.args = {
        "test_command_test": "test",
        "test_command_sleep": "test",
        "test_command": "test",
        "test_command_test_test": "test",
        "test_command_test_test_test": "test",
        "test_command_test_test_test_test": "test",
        "test_command_test_test_test_test_test": "test",
    }

    am = ActionModule()
    am._supports_check_mode = True
    am._supports_async = True
    am._play_context = AnsiblePlayContext()
    am._play_context.check_mode = True


# Generated at 2022-06-21 02:45:53.268319
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Here is a list of arguments for the method that we will
    #  try to use to get the command.
    #  It should be added to if more arguments are added to the module
    args = {
        'reboot_timeout': '10',
        'test_command': '/bin/true',
        'connect_timeout': '10',
        'connect_timeout_sec': '10',
        'reboot_timeout_sec': '10',
        'pre_reboot_delay': '10',
        'post_reboot_delay': '10',
    }

    # Set up the module object
    task = AnsibleTask()
    action = ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Get the command and arguments
    command