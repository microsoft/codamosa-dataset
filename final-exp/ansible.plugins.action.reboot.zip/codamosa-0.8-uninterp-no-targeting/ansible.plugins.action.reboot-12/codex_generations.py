

# Generated at 2022-06-21 02:37:37.075117
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # Setup inputs for test_ActionModule_check_boot_time
    distribution = None
    previous_boot_time = None
    action = ActionModule(dict(), dict())
    action.check_boot_time(distribution, previous_boot_time)

# Generated at 2022-06-21 02:37:39.279030
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    pass

# Generated at 2022-06-21 02:37:53.811457
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(task_vars=dict())

    assert am.DEFAULT_CONNECT_TIMEOUT == 30
    assert am.DEFAULT_REBOOT_TIMEOUT == 300

    assert am._supports_check_mode == True
    assert am._supports_async == True

    assert am._task.action == 'reboot'
    assert am._task.args.get('msg') == "Reboot not attempted because running in check mode"

    assert am.post_reboot_delay == 0

    assert am._supports_async == True
    assert am.async_seconds == 0

    assert am.async_poll_interval == 10
    assert am.DEFAULT_SUDOABLE == True

    assert am.DEPRECATED_ARGS.get('connect_timeout') == '2.5'
    assert am

# Generated at 2022-06-21 02:38:02.442950
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Initialize a TestConnection from Ansible to mock a connection, set methods and attributes
    test_connection = TestConnection('local')
    test_connection.set_hostname('hostname')
    test_connection.set_distribution('distro')
    test_connection.set_boot_time('boot_time')
    test_connection.set_pid('123')
    test_connection.set_isatty(True)
    test_connection.hostname = 'hostname'
    test_connection._shell.exec_command = MagicMock(return_value=('', '', 0))
    test_connection.reset = MagicMock(return_value='good')
    test_connection.set_option = MagicMock(return_value='good')
    test_connection.get_option = MagicMock(return_value=5)

   

# Generated at 2022-06-21 02:38:09.856793
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    module = ActionModule()
    # Fails
    try:
        module.do_until_success_or_timeout(
            action=ActionModule.run_test_command,
            action_desc="",
            reboot_timeout=10,
            distribution="DEFAULT_DISTRIBUTION")
    except Exception as e:
        pass


# Generated at 2022-06-21 02:38:22.706043
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Get an instance of our class
    module = ActionModule()
    # Failing test case 1
    task_vars = {
      'ansible_version': '2.5.1',
      'ansible_facts': {
        'ansible_distribution': 'Debian',
        'ansible_distribution_version': '9.6'
      }
    }
    expected_result = {
      'changed': True,
      'elapsed': 0,
      'rebooted': True
    }
    result = module.run(None, task_vars)
    assert result == expected_result, "Expected: {0}, Actual: {1}".format(expected_result, result)


# Generated at 2022-06-21 02:38:36.050206
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    task_vars = {
        'ansible_system_shutdown_command': 'shutdown',
        'ansible_shutdown_command': 'shutdown',
        'shutdown_command': 'shutdown'
    }

    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # No shutdown_command provided in the playbook
    assert action.get_shutdown_command(task_vars, 'all_systems') == '/sbin/shutdown'
    assert action.get_shutdown_command(task_vars, 'all_systems') == '/sbin/shutdown'

    # System shutdown_command provided with playbook shutdown_command

# Generated at 2022-06-21 02:38:44.049392
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    class MockConnection(object):
        pass

    class MockTask(object):
        def __init__(self):
            self.action = 'test_action'
            try:
                self.args
            except AttributeError:
                self.args = {}

    class MockTaskVars(object):
        def __init__(self):
            self.ansible_facts = {
                'ansible_distribution': 'CentOS Linux',
                'ansible_distribution_major_version': '7',
                'ansible_distribution_release': 'Core',
                'ansible_distribution_version': '7.8.2003'
            }

    class MockOptions:
        def __init__(self):
            self.connection_timeout = 1
            self.remote_tmp = '/tmp'
            self.private_key_file

# Generated at 2022-06-21 02:38:55.850884
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module = ActionModule(task=MagicMock())
    action_module.get_shutdown_command_args(distribution='RedHat')
    action_module.get_shutdown_command_args(distribution='CentOS')
    action_module.get_shutdown_command_args(distribution='Ubuntu')
    action_module.get_shutdown_command_args(distribution='Debian')
    action_module.get_shutdown_command_args(distribution='CoreOS')
    action_module.get_shutdown_command_args(distribution='Arch')
    action_module.get_shutdown_command_args(distribution='Gentoo')
    action_module.get_shutdown_command_args(distribution='Amazon')

# Generated at 2022-06-21 02:39:03.634380
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module = ActionModule(task=MockTask(), connection=MockConnection(), play_context=MockPlayContext())
    task_vars = {
        'ansible_facts': {
            'ansible_distribution': 'centos',
            'ansible_distribution_major_version': '6',
        }
    }

    distribution = action_module.get_distribution(task_vars=task_vars)

    assert distribution == 'centos6'

# Generated at 2022-06-21 02:39:39.509673
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    from ansible.utils.display import Display
    display = Display()
    shutil.rmtree("test/results")
    os.mkdir("test/results")
    # Attempting to mock the module object leads to problems with
    # deepcopy, so instead create a new instance of the object
    # and mock the parts of the object we require
    my_task = AnsibleTask()
    my_task._task_vars = {"ansible_facts":{}}
    my_task._task = {"action":"reboot"}
    my_task._play_context = {}
    my_connection = AnsibleConnection()
    my_connection.transport = 'local'
    my_connection.connection = AnsibleConnection()
    my_connection.connection.set_options({})
    my_task._connection = my_connection

    my_action_

# Generated at 2022-06-21 02:39:52.188440
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    module = ActionModule()

    # The following check makes sure the attributes are set properly to create
    # and object of type ActionModule
    assert(isinstance(module, ActionModule))

    # Test case when reboot fails
    exception_message = "Test reboot failed."
    exception = AttributeError(exception_message)
    result = module.validate_reboot(None, None, exception)
    assert result['failed'] == True
    assert result['rebooted'] == True
    assert result['msg'] == exception_message

    # Test case when reboot succeeds
    result = module.validate_reboot(None, None, None)
    assert result['failed'] == False
    assert result['rebooted'] == True

# Generated at 2022-06-21 02:39:56.869663
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    t = MagicMock(spec_set=TaskExecutor)
    a = ActionModule(t)
    a.get_shutdown_command("giraffe")
    a.get_shutdown_command("redhat")
    a.get_shutdown_command("ubuntu")


# Generated at 2022-06-21 02:40:07.029064
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    distribution = ''
    result = action_module.do_until_success_or_timeout(action=action_module.check_boot_time, action_desc="", reboot_timeout=0, distribution=distribution, action_kwargs={'previous_boot_time': None})
    assert result == None, "Result does not match expected value"

# Generated at 2022-06-21 02:40:20.798003
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Initialize a mock connection
    connection = mock.Mock()
    connection.transport = 'local'
    connection.reset = mock.Mock(return_value = None)
    connection.set_option = mock.Mock(return_value = None)
    connection.get_option = mock.Mock(return_value = None)
    # Initialize a mock task
    task_vars = {}
    task_vars['ansible_connection'] = 'local'
    task_vars['ansible_play_hosts'] = ['host1', 'host2']
    task_vars['ansible_python_interpreter'] = '/usr/bin/python'
    task_vars['connection'] = 'local'
    task_vars['playbook_dir'] = '/playbook/dir'
    task_vars

# Generated at 2022-06-21 02:40:23.391570
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    action_module = ActionModule()
    action_module.perform_reboot(reboot_timeout=3)

# Generated at 2022-06-21 02:40:34.053273
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    import platform

    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch
    from ansible_collections.notstdlib.moveitallout.plugins.modules import _reboot

    with patch.object(platform, 'dist', return_value=('', '', '', '', '')):
        am = _reboot.ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
        assert_equals(am.get_distribution({'ansible_facts': {}}), 'DEFAULT')


# Generated at 2022-06-21 02:40:45.396856
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    from units.mock.loader import DictDataLoader
    from units.mock.path import prepath_loader
    from units.compat.mock import MagicMock, patch

    # create an instance of the ActionModule
    # since "self" is used to access properties/methods in the class, a hack is done to make it work
    # (dynamic class creation with type)
    action_obj = type('ActionModule', (ActionModule,), {'_task': MagicMock()})()

    # set up mocks
    mock_datetime = MagicMock()

    # set up mocks to return a timeout
    real_datetime = datetime.datetime

# Generated at 2022-06-21 02:40:49.173154
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    obj = ActionModule()
    distribution = 'centos'
    expected_output = '1492576226'
    actual_output = obj.get_system_boot_time(distribution)
    assert actual_output == expected_output



# Generated at 2022-06-21 02:40:59.279406
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    class MockPreTaskShell(object):

        def __init__(self, action=None, module_name=None, module_args=None):
            self._action = action
            self._module_name = module_name
            self._module_args = module_args

            self.action = action
            self.module_name = module_name
            self.module_args = module_args

    # Mock AnsibleTaskV2 to be able to set playbook_dir
    class MockAnsibleTaskV2(object):

        def __init__(self, action=None, module_name=None, module_args=None, task_vars=None):
            self._action = action
            self._module_name = module_name
            self._module_args = module_args
            self._task_vars = task_vars

            self

# Generated at 2022-06-21 02:43:20.984967
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    action_module = ActionModule()
    task_vars = {}
    facts = {}

    #
    # Test with 'shutdown_command' as top level key
    #
    task_vars['shutdown_command'] = '/sbin/shutdown -r'
    task_vars['ansible_facts'] = facts

    shutdown_command = action_module.get_shutdown_command(task_vars, 'Debian')
    assert shutdown_command == '/sbin/shutdown -r'

    #
    # Test with 'shutdown_command' as second level key
    #
    task_vars['shutdown_command'] = None
    task_vars['ansible_facts'] = facts
    task_vars['ansible_facts']['shutdown_command'] = '/sbin/shutdown -r'



# Generated at 2022-06-21 02:43:23.731496
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action_module = ActionModule()
    action_module.deprecated_args()
    assert True

# Generated at 2022-06-21 02:43:25.232768
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    assert TimedOutException('TestException')



# Generated at 2022-06-21 02:43:27.496909
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    runner = Run()
    task = AnsibleTask()
    action_module = ActionModule(runner, task)
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-21 02:43:38.784273
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    """
    Unit test for method get_system_boot_time of class ActionModule
    """
    task = MockTask()
    m = ModuleLoader(task)
    task.async_val = 0

    task.args = {}
    task.action = 'reboot'

    module = m.get('reboot', task=task, connection=None)
    # Access protected attribute
    module._connection = MockConnection()
    module._task = task
    assert module.get_system_boot_time('debian') == 'Mon Sep 30 16:24:00 2019'
    assert module.get_system_boot_time('default') == 'Mon Sep 30 16:24:00 2019'


# Generated at 2022-06-21 02:43:49.211038
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    task_vars = {}
    self_action = 'fake_action'
    distribution = 'fake_distribution'
    original_connection_timeout = 10
    action_kwargs = {}

    # Means rc is 0 and boot time checks are good
    with patch('module_utils.basic._AnsibleModule.run_command', return_value=None):
        fake_action_module = ActionModule(self_action, task_vars)
        result = fake_action_module.validate_reboot(distribution, original_connection_timeout, action_kwargs)
        assert result.get('rebooted', None) is not None
        assert result.get('failed', None) is not None
        assert result.get('msg', None) is not None

    # Means reboot failed as expected

# Generated at 2022-06-21 02:43:58.033393
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    target = ActionModule()
    target._task.args['test_command'] = 'echo "Hello World"'
    distro_info = {'distribution': 'RHEL', 'distribution_release': '7.6.1810', 'distribution_major_version': '7'}
    # result1 = target.run_test_command(distro_info)
    # print(result1)
    result2 = target.run()
    print(result2)

if __name__ == '__main__':
    test_ActionModule_run_test_command()

# Generated at 2022-06-21 02:43:59.781828
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    #TODO: Improve the test coverage...
    pass

# Generated at 2022-06-21 02:44:08.084406
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # Setup
    argspec = inspect.getargspec(ActionModule.get_distribution)
    self = Mock()
    self._get_value_from_facts = Mock()
    self._task.args = {}
    self.DEFAULT_DISTRIBUTION = "foo"
    args = {'self': self, 'task_vars': task_vars}
    # Exercise
    result = ActionModule.get_distribution(**args)
    # Verify
    assert result == "foo"
    assert args['self']._get_value_from_facts.call_count == 0


# Generated at 2022-06-21 02:44:19.131827
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test private method _get_value_from_facts
    class MockFacts:
        def __init__(self, val):
            self.val = val

        def get(self, arg, default=None):
            return self.val.get(arg, default)

    class MockTask:
        def __init__(self, val):
            self.val = val

        def get_option(self, arg):
            return self.val.get(arg)

    class MockModuleLoader:
        def get_aliased_module(self, arg, **kwargs):
            return None

    # test method _get_value_from_facts
    # test error handling
    my_action_module = ActionModule(None, None, None)