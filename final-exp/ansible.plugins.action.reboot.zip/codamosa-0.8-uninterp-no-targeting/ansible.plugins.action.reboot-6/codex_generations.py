

# Generated at 2022-06-21 02:37:42.780499
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # Declare mock objects
    mock_action = MagicMock()
    mock_action_desc = 'test_ActionModule_do_until_success_or_timeout'
    mock_reboot_timeout = 1
    mock_distribution = 'test_distribution'
    mock_action_kwargs = {'test_key': 'test_kwarg'}

    def test_action_side_effect(**kwargs):
        if 'test_key' in kwargs:
            raise RuntimeError()
        return True

    mock_action.side_effect = test_action_side_effect

    # Declare test object
    am = ActionModule()

    # Run method under test

# Generated at 2022-06-21 02:37:53.812496
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    cls = modules.vultr.boot.ActionModule

    #########################################################################################################################
    #Test default value
    task_args = {}
    test_obj = cls(task=task_args, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert test_obj._task.args.get('shutdown_command_args') is None
    assert test_obj.get_shutdown_command_args(None) == '-r now'

    #########################################################################################################################
    #Test arguments
    task_args = {'shutdown_command_args': '-k -n'}

# Generated at 2022-06-21 02:38:02.540436
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    connection = {
        'transport': 'ssh',
        'ssh_args': '-o ControlMaster=auto -o ControlPersist=60s -o StrictHostKeyChecking=no',
        'host': '10.1.1.1',
        'username': 'root',
        'password': 'password',
        'port': 22
    }

    class Connection(object):
        def __init__(self, connection):
            super(Connection, self).__init__()
            self.connection = connection

        def __getitem__(self, key):
            return self.connection[key]

        def get_option(self, key):
            return self.connection[key]

        def reset(self):
            return


# Generated at 2022-06-21 02:38:10.690980
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    from faker import Faker
    from faker.providers import AnsibleModule

    action = ActionModule.ActionModule()

    action.DEPRECATED_ARGS = Faker().AnsibleModule.deprecated_args()
    action._task = AnsibleModule.AnsibleModule()
    action._task.args = Faker().AnsibleModule.valid_args()

    action.deprecated_args()



# Generated at 2022-06-21 02:38:16.481512
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
  original_connection_timeout = None
  action_kwargs = {u'previous_boot_time': u'1489162400.00'}
  distribution = u'DEBIAN8'
  am = ActionModule()
  result = am.validate_reboot(distribution, original_connection_timeout, action_kwargs)
  assert result == {'changed': True, 'rebooted': True, 'failed': False}


# Generated at 2022-06-21 02:38:25.971346
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    with patch.object(ActionModule, 'get_distribution') as get_distribution:
        # Setup test
        get_distribution.return_value = 'RedHat'

        # Execute test
        action_module = ActionModule()
        result = 'now'

        # Verify results
        assert result == action_module.get_shutdown_command_args('RedHat')

        # Setup test
        get_distribution.return_value = 'SUSE'

        # Execute test
        action_module = ActionModule()
        result = 'now'

        # Verify results
        assert result == action_module.get_shutdown_command_args('SUSE')

        # Setup test
        get_distribution.return_value = 'Solaris'

        # Execute test
        action_module = ActionModule()

# Generated at 2022-06-21 02:38:38.042609
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    from datetime import datetime
    from time import time
    action_module = ActionModule()
    action_module.DEFAULT_SUDOABLE = True
    action_module.DEFAULT_BOOT_TIME_COMMAND = 'uptime -s'
    action_module.TEST_COMMANDS = dict(RedHat=dict(DEFAULT_BOOT_TIME_COMMAND='uptime -s'))
    action_module._connection = MagicMock()
    action_module._connection.reset.return_value = True
    action_module._connection.exe.return_value = dict(rc=0, stdout=datetime.now().isoformat(), stderr="")
    action_module._connection.set_option.return_value = "uptime -s"
    action_module._connection.get_option.return_value

# Generated at 2022-06-21 02:38:40.553550
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    try:
        raise TimedOutException
    except TimedOutException:
        pass


# Generated at 2022-06-21 02:38:46.648533
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # Setup:
    #
    # - create a mock action function
    # - create a mock distribution
    # - create a mock class (mockActionModule) for which we can override methods
    # - call do_until_success_or_timeout on a mockActionModule
    #
    # Expectations:
    #
    # - If the action method raises an exception within the timeout limit, an exception should be thrown
    # - If the action method is successful within the timeout limit, no exception should be thrown
    #
    # Teardown:
    #
    # - Nothing

    def action_method(distribution):
        display.debug('action_method called')
        raise SystemExit(1)

    # Mock distribution which will be passed to action_method
    distribution = 'Linux'

    # Create a mock ActionModule class

# Generated at 2022-06-21 02:38:50.303184
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test instantiation of ActionModule
    action_module = ActionModule()

    assert action_module.DEFAULT_TEST_COMMAND == '/usr/bin/which which'
    assert action_module.DEFAULT_BOOT_TIME_COMMAND == 'uptime -s'
    assert action_module.DEFAULT_REBOOT_TIMEOUT == 300
    assert action_module.DEFAULT_CONNECT_TIMEOUT == 100
    assert action_module.DEFAULT_SUDOABLE == False
    assert action_module.post_reboot_delay == 0

# Generated at 2022-06-21 02:39:26.525053
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module = ActionModule(None, None, None)
    # Fails if distribution is UNKNOWN
    task_vars = dict([(u'ansible_distribution', u'UNKNOWN')])
    distribution = action_module.get_distribution(task_vars)
    assert distribution != u'UNKNOWN'


# Generated at 2022-06-21 02:39:34.730057
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
	from ansible.module_utils.basic import AnsibleModule
	from ansible.module_utils._text import to_text
	from ansible.module_utils.data import create_ansible_module
	module = create_ansible_module(
		argument_spec=dict(
			reboot_timeout=dict(type='int', default=300),
			connect_timeout=dict(type='int', default=30),
			distribution=dict(type='str', required=False),
		),
		supports_check_mode=False,
		autoupgrade=True
	)
	a = ActionModule(
		module=module,
	)

# Generated at 2022-06-21 02:39:39.020168
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    with pytest.raises(TypeError, match=r".* unsupported parameter 'distribution'.*"):
        ActionModule().validate_reboot('redhat')
        # raise error as this method requires 2nd arg as well
        # ActionModule().validate_reboot('redhat', 'parameter_distribution')

# Generated at 2022-06-21 02:39:53.547877
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    my_statement = 'my_statement'
    my_response = 'my_response'
    my_distribution = 'my_distribution'
    my_shutdown_command = 'my_shutdown_command'

    # Initialize connection plugin (do not test connection plugin itself, just pass the class)
    con = connection.Connection(None)

    # Fixture (monkeypatch)
    def _low_level_execute_command(self, cmd, sudoable=True):
        call = 'ActionModule_low_level_execute_command'
        return self.__low_level_execute_command(call, cmd, sudoable)


# Generated at 2022-06-21 02:40:03.117559
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    # Test with no params
    plugin = ActionModule(None, None, None)
    assert plugin.get_shutdown_command_args('ubuntu') == '-r now'
    assert plugin.get_shutdown_command_args('centos') == '-r now'
    assert plugin.get_shutdown_command_args('redhat') == '-r now'
    assert plugin.get_shutdown_command_args('something else') == '-r now'

    # Test with params
    plugin = ActionModule(None, None, None)
    plugin._task.args = {'reboot_timeout': 20}
    assert plugin.get_shutdown_command_args('centos') == '-r +20'
    plugin._task.args = {'reboot_timeout': 15}
    assert plugin.get_shutdown_command_

# Generated at 2022-06-21 02:40:06.021936
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    exc = TimedOutException("message")
    assert exc.args == ("message",)



# Generated at 2022-06-21 02:40:09.118308
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    x = TimedOutException()
    assert x is not None
    assert repr(x) == 'TimedOutException()'
    assert str(x) == 'TimedOutException()'



# Generated at 2022-06-21 02:40:10.744223
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    assert 1 == 2


# Generated at 2022-06-21 02:40:22.264516
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # import modules needed for testing
    import sys
    import pytest

    sys.modules['ansible.plugins.action.systemd'] = None
    sys.modules['ansible.plugins.action.systemd.system'] = None
    sys.modules['ansible.plugins.action.systemd.system.Systemd'] = None

    from ansible.plugins.action.reboot import ActionModule
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_text

    # create the object
    obj = ActionModule(
        task=dict(action=dict(reboot_timeout=10)),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )

    # required for faked method

# Generated at 2022-06-21 02:40:33.496210
# Unit test for method get_shutdown_command of class ActionModule

# Generated at 2022-06-21 02:41:31.709174
# Unit test for constructor of class ActionModule
def test_ActionModule():
    task = AnsibleTask()
    action = ActionModule(task, connection=None)
    assert isinstance(action, ActionModule)

# Generated at 2022-06-21 02:41:41.682002
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    a = ActionModule(None, None, None, None)
    success = False
    def action(distribution=None, action_kwargs=None):
        global success
        if not success:
            raise ValueError("some error happened")
        success = True
        return

    a.do_until_success_or_timeout(action=action, action_desc="This is a test", reboot_timeout=1, distribution=None)
    assert success



# Generated at 2022-06-21 02:41:51.377625
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    module = ActionModule()
    task_vars = {}
    distribution = {}
    result = module.perform_reboot(task_vars, distribution)
    assert isinstance(result, dict)
    assert len(result) == 3
    assert result['failed'] == False
    assert result['start'] == datetime.utcnow()
    assert 'reboot_command_result' in result
    

# Generated at 2022-06-21 02:41:57.666518
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    def test_get_shutdown_command_args(shutdown_command_args, distribution, distribution_version, expected):
        class ActionModule(BaseActionModule):
            def get_distribution(self, task_vars):
                return distribution

            def get_distribution_version(self, distribution):
                return distribution_version

            get_distribution_version = staticmethod(get_distribution_version)

            get_distribution = staticmethod(get_distribution)

        reb_mod = ActionModule(task=Mock(), connection=Mock(), play_context=Mock(), loader=Mock(), templar=Mock(), shared_loader_obj=Mock())


# Generated at 2022-06-21 02:42:05.984280
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    # Initializing test
    ansible_collections.ansible.community.tests.unit.modules.utilities. default_args = {}
    # initialize the object
    aml = ActionModule()
    # Get the value of distribution
    distribution = 'Linux'
    # Executing method
    ret = aml.get_system_boot_time(distribution)
    assert isinstance(ret, to_text)
    assert ret == '2019-11-05T15:22'



# Generated at 2022-06-21 02:42:10.926269
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Instantiating object
    distro_facts = dict(
        ansible_distribution='Ubuntu',
        ansible_distribution_release='14.04',
        ansible_distribution_version='14.04',
    )
    task_vars = dict({'ansible_facts': distro_facts}, ansible_check_mode=True)

    # Assert that method doesn't raise any exception
    reboot_action = ActionModule(None, task_vars=task_vars)
    reboot_action.get_shutdown_command(task_vars=task_vars, distribution='Ubuntu')


# Generated at 2022-06-21 02:42:20.993424
# Unit test for method run of class ActionModule
def test_ActionModule_run():

        #
        # perform_reboot
        #

        # test 1:
        #
        # description:
        # Check that perform_reboot() returns a dict
        #
        # validate:
        # if result contains changed
        #
        # pass_criteria:
        # result['changed'] exists
        #

        # Setup
        #
        # Mocking
        class MockActionModule(ActionModule):
            DEFAULT_SUDOABLE = True

        class MockTask:
            args = {}
            action = 'reboot'

        class MockConnection:
            transport = 'ssh'

        class MockPlayContext:
            check_mode = False

        module = MockActionModule(task=MockTask(), connection=MockConnection(), play_context=MockPlayContext())

        #  Run code to be tested

# Generated at 2022-06-21 02:42:27.829411
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    # Set up test case data
    module_name = 'reboot'
    module_args = {}
    variables = {}
    distribution = 'redhat'

    test_case = {
        'name': 'reboot: test get_shutdown_command_args',
        'inputs': '',
        'assert': """assert 'shutdown_command_args' is None"""
    }
    module = ActionModule(module_name, module_args, variables, distribution)
    result = module.get_shutdown_command_args(distribution)

    assert result is None, test_case['assert']


# Generated at 2022-06-21 02:42:39.383671
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    # Create a mock connection object.
    connection = Connection()
    # Mock the connect method of the Connection class.
    connection.get_option = MagicMock(return_value='CentOS-7-x86_64-LiveGNOME-1708.iso')

    # Create a mock inventory object.
    inventory = Inventory()
    # Mock the get_host method of the Inventory class.
    inventory.get_host = MagicMock(return_value=Host())

    # Create a mock task object.
    task = Task()
    # Mock the run method of the Task class.
    task.run = MagicMock(return_value=dict())

    # Create a mock play object.
    play = Play()
    # Mock the run method of the Play class.
    play.run = MagicMock(return_value=dict())

    # Create a

# Generated at 2022-06-21 02:42:48.181897
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    """Unit test for method get_system_boot_time of class ActionModule"""
    # Initialize test action module
    action_module = ActionModule(task=dict(args={}), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # Set up mocks
    action_module._low_level_execute_command = MagicMock(name='_low_level_execute_command', return_value=dict(rc=0, stdout='Wed 2017-05-31 21:30:01 UTC', stderr=''))
    # Exercise code
    result = action_module.get_system_boot_time('Ubuntu')
    # Assert we got back the value we expected
    assert result == 'Wed 2017-05-31 21:30:01 UTC'

# Unit test

# Generated at 2022-06-21 02:44:42.065453
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    pass

# Generated at 2022-06-21 02:44:43.659186
# Unit test for constructor of class ActionModule
def test_ActionModule():
    m = ActionModule()


# Generated at 2022-06-21 02:44:45.624025
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    exception = TimedOutException()
    assert exception


# Generated at 2022-06-21 02:44:47.610130
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    obj = TimedOutException()
    assert obj.args == tuple()



# Generated at 2022-06-21 02:44:52.947850
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    action_module = get_action_module()
    result = action_module.run_test_command(None)
    # Ensure that result was created
    assert result is not None


# Generated at 2022-06-21 02:44:59.112038
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    import ansible.module_utils.network.common.utils as utils
    module = utils.import_module('ansible.modules.remote_management.dellemc.idrac.idrac_lifecycle_controller.ActionModule')
    actionmodule = module.ActionModule()
    actionmodule.get_shutdown_command()


# Generated at 2022-06-21 02:45:11.412096
# Unit test for method validate_reboot of class ActionModule

# Generated at 2022-06-21 02:45:17.798975
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import get_distribution
    am = ActionModule({'name': 'test_ActionModule_get_shutdown_command_args',
                       'login_user': 'test',
                       'connection': 'local'},
                      'test_ActionModule_get_shutdown_command_args',
                      'ansible_facts')

# Generated at 2022-06-21 02:45:21.209484
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    mod = module.ActionModule(runner=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(mod, module.ActionModule)

    with pytest.raises(AttributeError):
        mod.perform_reboot()

# Generated at 2022-06-21 02:45:32.985398
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    action_module = ActionModule()
    assert action_module.do_until_success_or_timeout(action=mock_action, action_desc="mock action", reboot_timeout=1, distribution='mock_distribution') == None
    assert action_module.do_until_success_or_timeout(action=mock_action_raise_Exception, action_desc="mock action", reboot_timeout=1, distribution='mock_distribution') == None
    try:
        action_module.do_until_success_or_timeout(action=mock_action_raise_ValueError, action_desc="mock action", reboot_timeout=1, distribution='mock_distribution')
    except ValueError as e:
        assert e.args[0] == "boot time has not changed"