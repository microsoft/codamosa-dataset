

# Generated at 2022-06-17 09:30:58.929469
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Setup test
    module = ActionModule()
    module._task = Task()
    module._task.action = 'reboot'
    module._task.args = {'reboot_timeout': 10}
    module._connection = Connection()
    module._connection.transport = 'local'
    module._low_level_execute_command = MagicMock()
    module._low_level_execute_command.return_value = {'rc': 0, 'stdout': '', 'stderr': ''}
    module.get_shutdown_command = MagicMock()
    module.get_shutdown_command.return_value = 'shutdown'
    module.get_shutdown_command_args = MagicMock()
    module.get_shutdown_command_args.return_value = '-r now'
    module.get_dist

# Generated at 2022-06-17 09:31:06.515728
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    action_module = ActionModule()
    action_module._supports_check_mode = True
    action_module._supports_async = True
    action_module._task = Mock()
    action_module._task.action = 'reboot'
    action_module._task.args = {'reboot_timeout': 10}
    action_module._play_context = Mock()
    action_module._play_context.check_mode = False
    action_module._connection = Mock()
    action_module._connection.transport = 'local'
    action_module.post_reboot_delay = 0
    action_module.DEFAULT_REBOOT_TIMEOUT = 10
    action_module.DEFAULT_CONNECT_TIMEOUT = 10
    action_module.DEFAULT_SUDOABLE = True
    action_

# Generated at 2022-06-17 09:31:18.110715
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Create an instance of class ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create an instance of class Task
    task = Task()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class Connection
    connection = Connection()

    # Create an instance of class AnsibleLoader
    ansible_loader = AnsibleLoader()

    # Create an instance of class AnsibleTemplar
    ansible_templar = AnsibleTemplar()

    # Create an instance of class AnsibleVaultEncryptedUnicode
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode()

    # Create an instance of class Ansible

# Generated at 2022-06-17 09:31:32.283047
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Create an instance of the class to test
    action_module = ActionModule()

    # Create a mock of the class to test
    mock_action_module = MagicMock(spec=ActionModule)

    # Create a mock of the class to test
    mock_task = MagicMock(spec=Task)

    # Create a mock of the class to test
    mock_connection = MagicMock(spec=Connection)

    # Create a mock of the class to test
    mock_play_context = MagicMock(spec=PlayContext)

    # Create a mock of the class to test
    mock_loader = MagicMock(spec=DataLoader)

    # Create a mock of the class to test
    mock_templar = MagicMock(spec=Templar)

    # Create a mock of the class to test
    mock_task_vars

# Generated at 2022-06-17 09:31:45.602366
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    # Setup
    action_module = ActionModule()
    action_module._task = Mock()
    action_module._task.action = 'reboot'
    action_module._task.args = {'reboot_timeout': '30'}
    action_module._connection = Mock()
    action_module._connection.get_option.return_value = '30'
    action_module._connection.set_option.return_value = None
    action_module._connection.reset.return_value = None
    action_module._low_level_execute_command = Mock()
    action_module._low_level_execute_command.return_value = {'rc': 0, 'stdout': '', 'stderr': ''}
    action_module.get_system_boot_time = Mock()
    action_module.get_system_boot_

# Generated at 2022-06-17 09:31:48.321231
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    # Create a mock of class ActionModule
    mock_ActionModule = MagicMock()
    mock_ActionModule.get_shutdown_command_args.return_value = '-r now'

    # Call the method get_shutdown_command_args of class ActionModule
    result = mock_ActionModule.get_shutdown_command_args('RedHat')

    # Check if the result is as expected
    assert result == '-r now'


# Generated at 2022-06-17 09:31:54.786304
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    # test with a valid distribution
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    distribution = 'ubuntu'
    boot_time = action_module.get_system_boot_time(distribution)
    assert boot_time is not None

    # test with an invalid distribution
    distribution = 'invalid'
    boot_time = action_module.get_system_boot_time(distribution)
    assert boot_time is None


# Generated at 2022-06-17 09:32:06.425344
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    # Setup
    action_module = ActionModule()
    action_module._task = Mock(action='reboot')
    action_module._connection = Mock()
    action_module._connection.get_option.return_value = None
    action_module._connection.set_option.return_value = None
    action_module._connection.reset.return_value = None
    action_module.check_boot_time = Mock()
    action_module.run_test_command = Mock()
    action_module.DEFAULT_REBOOT_TIMEOUT = 10
    action_module.DEFAULT_CONNECT_TIMEOUT = 10
    action_module.post_reboot_delay = 0
    distribution = 'DEFAULT'
    original_connection_timeout = None
    action_kwargs = None

    # Test
    action_module.validate_

# Generated at 2022-06-17 09:32:16.263856
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Create a mock task
    task = Mock()
    task.action = 'reboot'
    task.args = {'connect_timeout': 10, 'reboot_timeout': 10, 'test_command': 'echo "hello"'}

    # Create a mock connection
    connection = Mock()
    connection.transport = 'local'
    connection.set_option.return_value = None
    connection.reset.return_value = None

    # Create a mock play context
    play_context = Mock()
    play_context.check_mode = False

    # Create a mock AnsibleModule
    ansible_module = Mock()
    ansible_module.params = {}
    ansible_module.check_mode = False

    # Create a mock AnsibleModule
    ansible_module = Mock()
    ansible_module.params = {}
   

# Generated at 2022-06-17 09:32:24.141786
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    # Create an instance of the class
    action_module = ActionModule()
    # Create a mock of the class
    action_module_mock = mock.Mock(spec=ActionModule)
    # Create a mock of the class
    action_module_mock.get_shutdown_command_args.return_value = 'shutdown_command_args'
    # Call the method
    action_module_mock.get_shutdown_command_args('distribution')
    # Check if the method was called
    action_module_mock.get_shutdown_command_args.assert_called_once_with('distribution')
    # Check the return value
    assert action_module_mock.get_shutdown_command_args.return_value == 'shutdown_command_args'


# Generated at 2022-06-17 09:33:02.598474
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # Setup
    action_module = ActionModule()
    action_module._task = Mock()
    action_module._task.action = 'reboot'
    action_module._task.args = {'reboot_timeout': 10}
    action_module._task.args.get = Mock()
    action_module._task.args.get.return_value = 10
    action_module._task.args.get.side_effect = lambda x: action_module._task.args[x]
    action_module._task.async_val = None
    action_module._task.async_seconds = None
    action_module._task.async_poll_interval = None
    action_module._task.async_timeout = None
    action_module._task.async_jid = None
    action_module._task.notify

# Generated at 2022-06-17 09:33:06.588076
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    action_module = ActionModule()
    action_module.do_until_success_or_timeout(action=action_module.check_boot_time, action_desc="last boot time check", reboot_timeout=5, distribution="Ubuntu", action_kwargs={'previous_boot_time': "previous_boot_time"})


# Generated at 2022-06-17 09:33:13.986217
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    # Create an instance of ActionModule
    action_module = ActionModule()
    # Create a mock of class AnsibleConnection
    ansible_connection = mock.MagicMock()
    # Create a mock of class AnsibleTask
    ansible_task = mock.MagicMock()
    # Create a mock of class AnsiblePlay
    ansible_play = mock.MagicMock()
    # Create a mock of class AnsiblePlayContext
    ansible_play_context = mock.MagicMock()
    # Create a mock of class AnsibleModule
    ansible_module = mock.MagicMock()
    # Create a mock of class AnsibleModuleArgs
    ansible_module_args = mock.MagicMock()
    # Create a mock of class AnsibleModuleReturn
    ansible_module_return = mock.MagicMock()
    # Create a

# Generated at 2022-06-17 09:33:22.648338
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Test with a task that has no args
    task = Task()
    task.action = 'reboot'
    task.args = {}
    action_module = ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    task_vars = {}
    distribution = 'DEFAULT'
    result = action_module.get_shutdown_command(task_vars, distribution)
    assert result == '/sbin/shutdown'
    # Test with a task that has args
    task = Task()
    task.action = 'reboot'
    task.args = {'shutdown_command': '/usr/bin/shutdown'}

# Generated at 2022-06-17 09:33:29.319798
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up mock objects
    mock_task = MagicMock()
    mock_task.action = 'reboot'
    mock_task.args = {'reboot_timeout': '10'}
    mock_task.async_val = None
    mock_task.notify = []
    mock_task.run_once = False
    mock_task.loop = None
    mock_task.loop_args = None
    mock_task.when = []
    mock_task.changed_when = []
    mock_task.failed_when = []
    mock_task.check_mode = False
    mock_task.no_log = False
    mock_task.register = None
    mock_task.delegate_to = None
    mock_task.delegate_facts = False
    mock_task.until = None
    mock_

# Generated at 2022-06-17 09:33:33.927178
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # Create a mock object of class ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create a mock object of class TimedOutException
    timed_out_exception = TimedOutException()

    # Create a mock object of class ValueError
    value_error = ValueError()

    # Create a mock object of class Exception
    exception = Exception()

    # Create a mock object of class AnsibleConnectionFailure
    ansible_connection_failure = AnsibleConnectionFailure()

    # Create a mock object of class AnsibleError
    ansible_error = AnsibleError()

    # Create a mock object of class AttributeError
    attribute_error = AttributeError()

    # Create a mock object of class TypeError


# Generated at 2022-06-17 09:33:39.125979
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    # Create an instance of the class to be tested
    action_module = ActionModule()

    # Create a mock of the class to be tested
    action_module = create_autospec(action_module)

    # Set the return value of the mock
    action_module.get_shutdown_command_args.return_value = "shutdown_command_args"

    # Test the method
    assert action_module.get_shutdown_command_args("distribution") == "shutdown_command_args"

    # Assert that the mock was called as expected
    action_module.get_shutdown_command_args.assert_called_with("distribution")


# Generated at 2022-06-17 09:33:43.014755
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    # Create an instance of ActionModule
    action_module = ActionModule()
    # Create a mock of class Distribution
    distribution = Distribution()
    # Call method run_test_command of class ActionModule
    action_module.run_test_command(distribution)


# Generated at 2022-06-17 09:33:50.470851
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # Create an instance of ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create a mock of class Distribution
    distribution = Distribution()

    # Call method check_boot_time with the mock
    action_module.check_boot_time(distribution)


# Generated at 2022-06-17 09:34:01.575813
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module._supports_check_mode = True
    action_module._supports_async = True
    action_module._task = None
    action_module._connection = None
    action_module._play_context = None
    action_module._loader = None
    action_module._templar = None
    action_module._shared_loader_obj = None
    action_module.post_reboot_delay = 0
    action_module.DEFAULT_REBOOT_TIMEOUT = 0
    action_module.DEFAULT_CONNECT_TIMEOUT = 0
    action_module.DEFAULT_SUDOABLE = False
    action_

# Generated at 2022-06-17 09:35:09.907784
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    # Create a mock of class ActionModule
    action_module = MagicMock(spec=ActionModule)
    action_module.run.return_value = None
    action_module.get_distribution.return_value = None
    action_module.get_shutdown_command.return_value = None
    action_module.get_shutdown_command_args.return_value = None
    action_module.get_system_boot_time.return_value = None
    action_module.check_boot_time.return_value = None
    action_module.run_test_command.return_value = None
    action_module.do_until_success_or_timeout.return_value = None
    action_module.perform_reboot.return_value = None

# Generated at 2022-06-17 09:35:19.878409
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    # Create an instance of ActionModule
    action_module = ActionModule()

    # Create a mock of class AnsibleConnection
    mock_ansible_connection = mock.create_autospec(AnsibleConnection)

    # Set attribute _connection of action_module to mock_ansible_connection
    action_module._connection = mock_ansible_connection

    # Create a mock of class AnsibleTask
    mock_ansible_task = mock.create_autospec(AnsibleTask)

    # Set attribute _task of action_module to mock_ansible_task
    action_module._task = mock_ansible_task

    # Create a mock of class AnsiblePlayContext
    mock_ansible_play_context = mock.create_autospec(AnsiblePlayContext)

    # Set attribute _play_context of action_module to mock

# Generated at 2022-06-17 09:35:32.808823
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module = ActionModule()
    action_module._task = Mock()
    action_module._task.args = {'distribution': 'test'}
    action_module._task.action = 'test'
    action_module._task.action_plugin_name = 'test'
    action_module._task.action_plugin_type = 'test'
    action_module._task.action_plugin_load_name = 'test'
    action_module._task.action_plugin_version = 'test'
    action_module._task.action_plugin_path = 'test'
    action_module._task.action_plugin_provider = 'test'
    action_module._task.action_plugin_deprecated = 'test'
    action_module._task.action_plugin_deprecation_warnings = 'test'
    action_

# Generated at 2022-06-17 09:35:43.019571
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Test with a valid shutdown_command
    task_vars = {'ansible_facts': {'distribution': 'RedHat'}}
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module._task.args = {'shutdown_command': '/sbin/shutdown'}
    assert action_module.get_shutdown_command(task_vars, 'RedHat') == '/sbin/shutdown'

    # Test with a valid shutdown_command_args
    task_vars = {'ansible_facts': {'distribution': 'RedHat'}}

# Generated at 2022-06-17 09:35:54.592402
# Unit test for method validate_reboot of class ActionModule

# Generated at 2022-06-17 09:36:02.410444
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Create a mock task object
    task = MagicMock()

    # Create a mock connection object
    connection = MagicMock()

    # Create a mock play context object
    play_context = MagicMock()

    # Create a mock loader object
    loader = MagicMock()

    # Create a mock templar object
    templar = MagicMock()

    # Create a mock ansible_version_info object
    ansible_version_info = MagicMock()

    # Create a mock ansible_version object
    ansible_version = MagicMock()

    # Create a mock ansible_facts object
    ansible_facts = MagicMock()

    # Create a mock ansible_facts['distribution'] object
    ansible_facts['distribution'] = 'RedHat'

    # Create a mock ansible_facts['distribution

# Generated at 2022-06-17 09:36:15.921815
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    # Create an instance of ActionModule
    action_module = ActionModule()

    # Create a mock of class ActionModule
    mock_action_module = MagicMock(spec=ActionModule)

    # Create a mock of class AnsibleModule
    mock_ansible_module = MagicMock(spec=AnsibleModule)

    # Create a mock of class AnsibleModule
    mock_ansible_module_params = MagicMock(spec=dict)

    # Create a mock of class AnsibleModule
    mock_ansible_module_params_boot_time_command = MagicMock(spec=str)

    # Create a mock of class AnsibleModule
    mock_ansible_module_params_boot_time_command_value = MagicMock(spec=str)

    # Set the value of the mock_ansible_module_params_boot_time

# Generated at 2022-06-17 09:36:24.580088
# Unit test for method run of class ActionModule

# Generated at 2022-06-17 09:36:36.278122
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    # Create a mock connection plugin
    mock_connection = MockConnection()

    # Create a mock task
    mock_task = MockTask()

    # Create a mock action module
    mock_action_module = ActionModule(mock_task, mock_connection)

    # Create a mock distribution
    mock_distribution = 'mock_distribution'

    # Create a mock original connection timeout
    mock_original_connection_timeout = 'mock_original_connection_timeout'

    # Create a mock action kwargs
    mock_action_kwargs = {'mock_key': 'mock_value'}

    # Create a mock result
    mock_result = {'mock_key': 'mock_value'}

    # Create a mock timed out exception

# Generated at 2022-06-17 09:36:46.698257
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class TimedOutException
    timed_out_exception = TimedOutException()

    # Create an instance of class ValueError
    value_error = ValueError()

    # Create an instance of class AnsibleError
    ansible_error = AnsibleError()

    # Create an instance of class AnsibleConnectionFailure
    ansible_connection_failure = AnsibleConnectionFailure()

    # Create an instance of class AnsibleAction
    ansible_action = AnsibleAction()

    # Create an instance of class AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of class AnsibleModuleDeprecationWarning
    ansible_module_deprecation_warning = AnsibleModuleDeprecationWarning()

    # Create an instance of

# Generated at 2022-06-17 09:38:43.131667
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    task_vars = {}
    result = action_module.get_distribution(task_vars)
    assert result == 'DEFAULT'


# Generated at 2022-06-17 09:38:50.461298
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class TimedOutException
    timed_out_exception = TimedOutException()

    # Create an instance of class ValueError
    value_error = ValueError()

    # Create an instance of class AnsibleError
    ansible_error = AnsibleError()

    # Create an instance of class AnsibleConnectionFailure
    ansible_connection_failure = AnsibleConnectionFailure()

    # Create an instance of class AnsibleError
    ansible_error = AnsibleError()

    # Create an instance of class AnsibleError
    ansible_error = AnsibleError()

    # Create an instance of class AnsibleError
    ansible_error = AnsibleError()

    # Create an instance of class AnsibleError
    ansible_error = AnsibleError

# Generated at 2022-06-17 09:39:00.106536
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # Create a mock object of class ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # Test with valid parameters
    distribution = "Ubuntu"
    previous_boot_time = "Sun Nov  4 12:34:56 2018"
    action_module.check_boot_time(distribution, previous_boot_time)
    # Test with invalid parameters
    distribution = "Ubuntu"
    previous_boot_time = "Sun Nov  4 12:34:56 2018"
    action_module.check_boot_time(distribution, previous_boot_time)
    # Test with invalid parameters
    distribution = "Ubuntu"
    previous_boot_time = "Sun Nov  4 12:34:56 2018"


# Generated at 2022-06-17 09:39:06.963612
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    # Create a mock object of class ActionModule
    action_module = ActionModule(
        task=Mock(),
        connection=Mock(),
        play_context=Mock(),
        loader=Mock(),
        templar=Mock(),
        shared_loader_obj=Mock())

    # Create a mock object of class AnsibleError
    ansible_error = AnsibleError(msg='AnsibleError')

    # Create a mock object of class RuntimeError
    runtime_error = RuntimeError(msg='RuntimeError')

    # Create a mock object of class AnsibleConnectionFailure
    ansible_connection_failure = AnsibleConnectionFailure(msg='AnsibleConnectionFailure')

    # Create a mock object of class AnsibleConnectionFailure
    ansible_error = AnsibleError(msg='AnsibleError')

    # Create a mock object of

# Generated at 2022-06-17 09:39:18.734639
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create a mock of class AnsibleConnection
    mock_ansible_connection = mock.create_autospec(AnsibleConnection)

    # Set the connection attribute of action_module to mock_ansible_connection
    action_module._connection = mock_ansible_connection

    # Create a mock of class AnsibleTask
    mock_ansible_task = mock.create_autospec(AnsibleTask)

    # Set the task attribute of action_module to mock_ansible_task
    action_module._task = mock_ansible_task

    # Create a mock of class AnsiblePlayContext
    mock_ansible_play_context = mock.create_autospec(AnsiblePlayContext)

    # Set the play_context attribute of action_module to

# Generated at 2022-06-17 09:39:31.010379
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    # Test with no args
    action_module = ActionModule()
    action_module._task = {}
    action_module._task.action = 'reboot'
    action_module._task.args = {}
    action_module.deprecated_args()
    # Test with args
    action_module = ActionModule()
    action_module._task = {}
    action_module._task.action = 'reboot'
    action_module._task.args = {'reboot_timeout': '10'}
    action_module.deprecated_args()


# Generated at 2022-06-17 09:39:34.466909
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    task_vars = {}
    result = action_module.get_distribution(task_vars)
    assert result == 'DEFAULT'


# Generated at 2022-06-17 09:39:42.820537
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # Test with a successful action
    action_module = ActionModule()
    action_module.do_until_success_or_timeout(action=lambda: None, action_desc="", reboot_timeout=1)

    # Test with a failing action
    action_module = ActionModule()
    with pytest.raises(TimedOutException):
        action_module.do_until_success_or_timeout(action=lambda: 1/0, action_desc="", reboot_timeout=1)


# Generated at 2022-06-17 09:39:52.880151
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    # Create an instance of class ActionModule
    action_module = ActionModule()
    # Create an instance of class Distribution
    distribution = Distribution()
    # Create an instance of class Task
    task = Task()
    # Create an instance of class PlayContext
    play_context = PlayContext()
    # Create an instance of class Connection
    connection = Connection()
    # Create an instance of class AnsibleModule
    ansible_module = AnsibleModule()
    # Create an instance of class AnsibleModule
    ansible_module = AnsibleModule()
    # Create an instance of class AnsibleModule
    ansible_module = AnsibleModule()
    # Create an instance of class AnsibleModule
    ansible_module = AnsibleModule()
    # Create an instance of class AnsibleModule
    ansible_module = AnsibleModule()
    # Create an instance of

# Generated at 2022-06-17 09:40:03.567531
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    # Test with a valid distribution
    distribution = 'RedHat'
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.get_system_boot_time(distribution) is not None

    # Test with an invalid distribution
    distribution = 'Invalid'
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.get_system_boot_time(distribution) is None
