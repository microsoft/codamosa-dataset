

# Generated at 2022-06-17 09:31:02.484645
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create a mock of object distribution
    distribution = Mock()

    # Call method run_test_command with parameters distribution
    action_module.run_test_command(distribution)


# Generated at 2022-06-17 09:31:07.366997
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # Create an instance of the class
    action_module = ActionModule()

    # Create a mock of the class
    action_module_mock = MagicMock(spec=ActionModule)

    # Create a mock of the class
    action_module_mock.check_boot_time.return_value = None

    # Assert that the mock is valid
    assert action_module_mock.check_boot_time() == None


# Generated at 2022-06-17 09:31:13.853373
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    # Setup
    action_module = ActionModule()
    action_module._task = Mock()
    action_module._task.action = 'reboot'
    action_module._task.args = {'shutdown_timeout': '10'}
    distribution = 'redhat'

    # Test
    result = action_module.get_shutdown_command_args(distribution)

    # Assert
    assert result == '-r now'


# Generated at 2022-06-17 09:31:15.238212
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module = ActionModule()
    action_module.get_distribution(task_vars=None)

# Generated at 2022-06-17 09:31:24.892009
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    # Setup
    action_module = ActionModule()
    action_module.DEFAULT_BOOT_TIME_COMMAND = 'uptime -s'

# Generated at 2022-06-17 09:31:31.069435
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    task_vars = {}
    distribution = action_module.get_distribution(task_vars)
    assert distribution == 'DEFAULT'


# Generated at 2022-06-17 09:31:39.266865
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module = ActionModule()
    assert action_module.get_distribution({}) == 'DEFAULT'
    assert action_module.get_distribution({'ansible_distribution': 'RedHat'}) == 'RedHat'
    assert action_module.get_distribution({'ansible_distribution': 'CentOS'}) == 'RedHat'
    assert action_module.get_distribution({'ansible_distribution': 'Fedora'}) == 'RedHat'
    assert action_module.get_distribution({'ansible_distribution': 'Debian'}) == 'Debian'
    assert action_module.get_distribution({'ansible_distribution': 'Ubuntu'}) == 'Debian'

# Generated at 2022-06-17 09:31:49.165682
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    # Test with a valid distribution
    distribution = 'redhat'
    # Test with a valid original_connection_timeout
    original_connection_timeout = 10
    # Test with a valid action_kwargs
    action_kwargs = {'previous_boot_time': '2019-01-01'}
    # Test with a valid reboot_timeout
    reboot_timeout = 10
    # Test with a valid action_desc
    action_desc = 'last boot time check'
    # Test with a valid action
    action = 'check_boot_time'
    # Test with a valid distribution
    distribution = 'redhat'
    # Test with a valid action_kwargs
    action_kwargs = {'previous_boot_time': '2019-01-01'}
    # Test with a valid action_desc

# Generated at 2022-06-17 09:32:00.725047
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # Create an instance of ActionModule
    action_module = ActionModule()
    # Create a mock of class TimedOutException
    class TimedOutException:
        pass
    # Create a mock of class ValueError
    class ValueError:
        pass
    # Create a mock of class datetime
    class datetime:
        class utcnow:
            pass
    # Create a mock of class timedelta
    class timedelta:
        pass
    # Create a mock of class random
    class random:
        class randint:
            pass
    # Create a mock of class time
    class time:
        pass
    # Set variables for test
    distribution = 'distribution'
    action_kwargs = {'previous_boot_time': 'previous_boot_time'}
    # Set return values for mocked function
    TimedOutException

# Generated at 2022-06-17 09:32:13.038715
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Create a mock task
    mock_task = Mock()
    mock_task.action = 'reboot'
    mock_task.args = {'reboot_timeout': 30, 'reboot_timeout_sec': 30, 'test_command': '/bin/true', 'connect_timeout': 10, 'connect_timeout_sec': 10}
    # Create a mock connection
    mock_connection = Mock()
    mock_connection.transport = 'ssh'
    # Create a mock play context
    mock_play_context = Mock()
    mock_play_context.check_mode = False
    # Create a mock AnsibleModule
    mock_ansible_module = Mock()
    mock_ansible_module.check_mode = False

# Generated at 2022-06-17 09:33:10.107268
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # Create an instance of ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create a mock of task_vars
    task_vars = {}

    # Call method get_distribution with parameters task_vars
    result = action_module.get_distribution(task_vars)

    # AssertionError: 'DEFAULT_DISTRIBUTION' not in result
    assert 'DEFAULT_DISTRIBUTION' in result


# Generated at 2022-06-17 09:33:16.060651
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    # Setup
    action_module = ActionModule()
    action_module._task = mock.Mock()
    action_module._task.action = 'reboot'
    action_module._task.args = {}
    action_module._low_level_execute_command = mock.Mock()
    action_module._low_level_execute_command.return_value = {'rc': 0, 'stdout': 'Tue 2018-01-23 15:00:00 UTC', 'stderr': ''}
    distribution = 'DEFAULT'

    # Test
    result = action_module.get_system_boot_time(distribution)

    # Assert
    assert result == 'Tue 2018-01-23 15:00:00 UTC'


# Generated at 2022-06-17 09:33:20.110326
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    # Setup
    action_module = ActionModule()
    action_module._task = Mock()
    action_module._task.action = 'reboot'

    # Test
    action_module.get_shutdown_command_args('redhat')

    # Assert
    assert action_module._task.args.get('shutdown_command_args') == '-r now'


# Generated at 2022-06-17 09:33:30.265418
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Test with a valid distribution
    distribution = 'RedHat'
    # Test with a valid task_vars
    task_vars = {}
    # Test with a valid shutdown_command
    shutdown_command = 'shutdown'
    # Test with a valid shutdown_command_args
    shutdown_command_args = '-r now'
    # Test with a valid reboot_command
    reboot_command = '{0} {1}'.format(shutdown_command, shutdown_command_args)
    # Test with a valid reboot_result
    reboot_result = {}
    # Test with a valid reboot_result['rc']
    reboot_result['rc'] = 0
    # Test with a valid result
    result = {}
    # Test with a valid result['start']
    result['start'] = datetime.utcnow()
    # Test with

# Generated at 2022-06-17 09:33:36.055542
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Create an instance of class ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create a mock of class Task
    task = MagicMock()

    # Create a mock of class PlayContext
    play_context = MagicMock()

    # Create a mock of class Connection
    connection = MagicMock()

    # Create a mock of class AnsibleLoader
    loader = MagicMock()

    # Create a mock of class DataLoader
    shared_loader_obj = MagicMock()

    # Create a mock of class Templar
    templar = MagicMock()

    # Create a mock of class TaskVars
    task_vars = MagicMock()

    # Create a mock of class Distribution

# Generated at 2022-06-17 09:33:48.744214
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create a mock of class Task
    task = mock.MagicMock()
    task.action = 'reboot'

    # Set the task attribute of class ActionModule
    action_module._task = task

    # Create a mock of class PlayContext
    play_context = mock.MagicMock()
    play_context.check_mode = False

    # Set the play_context attribute of class ActionModule
    action_module._play_context = play_context

    # Create a mock of class Connection
    connection = mock.MagicMock()
    connection.transport = 'ssh'

    # Set the connection attribute of class ActionModule
    action_module._connection = connection

    # Create a mock of class AnsibleModule
    ansible_module = mock.MagicMock()

# Generated at 2022-06-17 09:34:00.621852
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock module
    mock_module = MagicMock()
    mock_module.params = {'reboot_timeout': 60}
    mock_module.check_mode = False
    mock_module.run_command.return_value = (0, '', '')

    # Create a mock connection
    mock_connection = MagicMock()
    mock_connection.transport = 'ssh'
    mock_connection.get_option.return_value = 60

    # Create a mock play context
    mock_play_context = MagicMock()
    mock_play_context.check_mode = False

    # Create a mock task
    mock_task = MagicMock()
    mock_task.action = 'reboot'
    mock_task.args = {'reboot_timeout': 60}

    # Create a mock task_vars


# Generated at 2022-06-17 09:34:06.827622
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    action_module = ActionModule()
    action_module._task = Mock()
    action_module._task.action = 'reboot'
    action_module._task.args = {'test_command': 'echo "hello"'}
    action_module._connection = Mock()
    action_module._low_level_execute_command = Mock(return_value={'rc': 0, 'stdout': 'hello', 'stderr': ''})
    distribution = 'DEFAULT'
    action_module.run_test_command(distribution)
    action_module._low_level_execute_command.assert_called_with('echo "hello"', sudoable=True)


# Generated at 2022-06-17 09:34:12.646494
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # Create an instance of ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create a mock of task_vars
    task_vars = {}

    # Call method get_distribution of class ActionModule with task_vars
    result = action_module.get_distribution(task_vars)

    # Assert result is None
    assert result is None

# Generated at 2022-06-17 09:34:17.238122
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Setup
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    task_vars = {}
    distribution = 'DEFAULT'
    # Exercise
    result = action_module.get_shutdown_command(task_vars, distribution)
    # Verify
    assert result == '/sbin/shutdown'


# Generated at 2022-06-17 09:36:18.538126
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Create a mock task
    task = Mock()
    task.action = 'reboot'
    task.args = {'reboot_timeout': 60, 'connect_timeout': 10, 'test_command': 'echo "hello"'}

    # Create a mock connection
    connection = Mock()
    connection.transport = 'ssh'
    connection.set_option = Mock()
    connection.reset = Mock()
    connection.get_option = Mock(return_value=10)

    # Create a mock play_context
    play_context = Mock()
    play_context.check_mode = False

    # Create a mock AnsibleModule
    module = Mock()
    module.check_mode = False
    module.no_log = False

    # Create a mock AnsibleModule
    distribution = Mock()

# Generated at 2022-06-17 09:36:27.809248
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # Test with no exception
    action_module = ActionModule()
    action_module.do_until_success_or_timeout(action=lambda: None, action_desc="test", reboot_timeout=1)
    # Test with exception
    with pytest.raises(Exception):
        action_module.do_until_success_or_timeout(action=lambda: 1/0, action_desc="test", reboot_timeout=1)


# Generated at 2022-06-17 09:36:35.974754
# Unit test for method deprecated_args of class ActionModule

# Generated at 2022-06-17 09:36:36.468379
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    pass

# Generated at 2022-06-17 09:36:46.863926
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create a mock of class TimedOutException
    timed_out_exception = TimedOutException()

    # Create a mock of class ValueError
    value_error = ValueError()

    # Create a mock of class AnsibleConnectionFailure
    ansible_connection_failure = AnsibleConnectionFailure()

    # Create a mock of class AnsibleError
    ansible_error = AnsibleError()

    # Create a mock of class AttributeError
    attribute_error = AttributeError()

    # Create a mock of class Exception
    exception = Exception()

    # Create a mock of class datetime
    datetime_mock = Mock()

    # Create a mock of class time
    time_mock = Mock()

    # Create a mock of class random
    random_

# Generated at 2022-06-17 09:36:59.387859
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    # Create a mock connection plugin
    connection_plugin = MockConnectionPlugin()
    # Create a mock task
    task = MockTask()
    # Create a mock play context
    play_context = MockPlayContext()
    # Create a mock loader
    loader = MockLoader()
    # Create a mock templar
    templar = MockTemplar()
    # Create a mock action module
    action_module = ActionModule(task, connection_plugin, play_context, loader, templar)

    # Test
    # Test with no arguments
    result = action_module.run()

    # Verify
    assert result == {'changed': False, 'elapsed': 0, 'rebooted': False, 'failed': True, 'msg': 'Running reboot with local connection would reboot the control node.'}


# Generated at 2022-06-17 09:37:08.280185
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    # Setup
    action_module = ActionModule()
    action_module.check_boot_time = MagicMock()
    action_module.run_test_command = MagicMock()
    distribution = "distribution"
    original_connection_timeout = "original_connection_timeout"
    action_kwargs = "action_kwargs"

    # Test
    action_module.validate_reboot(distribution, original_connection_timeout, action_kwargs)

    # Assert
    action_module.check_boot_time.assert_called_with(distribution, action_kwargs)
    action_module.run_test_command.assert_called_with(distribution, action_kwargs)


# Generated at 2022-06-17 09:37:15.015187
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class TaskExecutor
    task_executor = TaskExecutor()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class Connection
    connection = Connection()

    # Set the connection.transport to 'local'
    connection.transport = 'local'

    # Set the task_executor.connection to connection
    task_executor.connection = connection

    # Set the task_executor._task to task
    task_executor._task = task

    # Set the task_executor._play_context to play_context
    task_executor._play_context = play_context

    # Set the action_module._task

# Generated at 2022-06-17 09:37:21.974336
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    # Test with a successful test command
    test_command = 'echo "test"'
    command_result = {'rc': 0, 'stdout': 'test', 'stderr': ''}
    test_action = ActionModule()
    test_action._low_level_execute_command = MagicMock(return_value=command_result)
    test_action.run_test_command(distribution='DEFAULT', test_command=test_command)
    test_action._low_level_execute_command.assert_called_once_with('echo "test"', sudoable=True)
    # Test with a failed test command
    test_command = 'echo "test"'
    command_result = {'rc': 1, 'stdout': 'test', 'stderr': ''}
    test_action = ActionModule()
    test_action._

# Generated at 2022-06-17 09:37:34.115020
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create a mock of class TimedOutException
    class TimedOutException(Exception):
        pass

    # Create a mock of class ValueError
    class ValueError(Exception):
        pass

    # Create a mock of class AnsibleError
    class AnsibleError(Exception):
        pass

    # Create a mock of class AnsibleConnectionFailure
    class AnsibleConnectionFailure(Exception):
        pass

    # Create a mock of class AttributeError
    class AttributeError(Exception):
        pass

    # Create a mock of class AnsibleError
    class AnsibleError(Exception):
        pass

    # Create a mock of class AnsibleError
    class AnsibleError(Exception):
        pass

    # Create a mock of class AnsibleError