

# Generated at 2022-06-17 09:31:02.687784
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    # Test with no arguments
    module = ActionModule()
    result = module.validate_reboot()
    assert result == {}


# Generated at 2022-06-17 09:31:12.575267
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Create a mock task
    task = Mock()
    task.action = 'reboot'
    task.args = dict()

    # Create a mock connection
    connection = Mock()
    connection.transport = 'ssh'
    connection.host = 'localhost'
    connection.port = 22
    connection.remote_addr = '127.0.0.1'
    connection.remote_user = 'root'
    connection.become = False
    connection.become_method = 'sudo'
    connection.become_user = 'root'
    connection.become_pass = None
    connection.no_log = False

    # Create a mock play context
    play_context = Mock()
    play_context.check_mode = False
    play_context.remote_addr = '127.0.0.1'
    play_context

# Generated at 2022-06-17 09:31:15.588728
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create a mock of object distribution
    distribution = Mock()

    # Call method run_test_command with parameters: distribution
    result = action_module.run_test_command(distribution)

    # Check if the result is as expected
    assert result is None

# Generated at 2022-06-17 09:31:21.198193
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # Test with a valid boot time
    action_module = ActionModule()
    action_module.check_boot_time('Linux', 'Tue 2018-05-29 10:30:00')

    # Test with an invalid boot time
    with pytest.raises(ValueError):
        action_module.check_boot_time('Linux', 'Tue 2018-05-29 10:30:00')


# Generated at 2022-06-17 09:31:34.018365
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create a mock of class Task
    task = MagicMock()

    # Create a mock of class PlayContext
    play_context = MagicMock()

    # Create a mock of class Connection
    connection = MagicMock()

    # Set the connection attribute of the instance of class ActionModule
    action_module._connection = connection

    # Set the play_context attribute of the instance of class ActionModule
    action_module._play_context = play_context

    # Set the task attribute of the instance of class ActionModule
    action_module._task = task

    # Create a mock of class AnsibleModule
    ansible_module = MagicMock()

    # Create a mock of class AnsibleModule
    ansible_module = MagicMock()

    # Create a mock of class

# Generated at 2022-06-17 09:31:40.335171
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    # Setup
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    distribution = None
    # Exercise
    action_module.run_test_command(distribution)
    # Verify
    assert True # did not raise exception


# Generated at 2022-06-17 09:31:46.286312
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Create an instance of class ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create an instance of class Task
    task = Task()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class Connection
    connection = Connection()

    # Create an instance of class AnsibleLoader
    ansible_loader = AnsibleLoader()

    # Create an instance of class AnsibleTemplar
    ansible_templar = AnsibleTemplar()

    # Create an instance of class SharedPluginLoaderObj
    shared_plugin_loader_obj = SharedPluginLoaderObj()

    # Set the values of task, connection, play_context, loader, templar and shared_

# Generated at 2022-06-17 09:31:55.427468
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    # Test with no args
    action_module = ActionModule()
    distribution = 'RedHat'
    assert action_module.get_shutdown_command_args(distribution) == '-r now'
    distribution = 'Debian'
    assert action_module.get_shutdown_command_args(distribution) == '-r now'
    distribution = 'FreeBSD'
    assert action_module.get_shutdown_command_args(distribution) == '-r now'
    distribution = 'SUSE'
    assert action_module.get_shutdown_command_args(distribution) == '-r now'
    distribution = 'Gentoo'
    assert action_module.get_shutdown_command_args(distribution) == '-r now'
    distribution = 'Arch'
    assert action_module.get_shutdown

# Generated at 2022-06-17 09:32:07.082623
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # Create an instance of class ActionModule
    action_module = ActionModule()
    # Create an instance of class Distribution
    distribution = Distribution()
    # Create an instance of class AnsibleModule
    ansible_module = AnsibleModule()
    # Create an instance of class AnsibleModule
    ansible_module = AnsibleModule()
    # Create an instance of class AnsibleModule
    ansible_module = AnsibleModule()
    # Create an instance of class AnsibleModule
    ansible_module = AnsibleModule()
    # Create an instance of class AnsibleModule
    ansible_module = AnsibleModule()
    # Create an instance of class AnsibleModule
    ansible_module = AnsibleModule()
    # Create an instance of class AnsibleModule
    ansible_module = AnsibleModule()
    # Create an instance of class AnsibleModule


# Generated at 2022-06-17 09:32:12.329977
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    # Create a mock task
    task = Mock()
    task.action = 'reboot'
    task.args = {'reboot_timeout': '10'}

    # Create a mock play context
    play_context = Mock()
    play_context.check_mode = False

    # Create a mock connection
    connection = Mock()
    connection.transport = 'ssh'

    # Create a mock loader
    loader = Mock()

    # Create a mock templar
    templar = Mock()

    # Create a mock display
    display = Mock()

    # Create a mock action module

# Generated at 2022-06-17 09:33:13.735453
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # Create an instance of class ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create a mock of class Task
    task = MagicMock()

    # Create a mock of class Connection
    connection = MagicMock()

    # Create a mock of class PlayContext
    play_context = MagicMock()

    # Create a mock of class DataLoader
    loader = MagicMock()

    # Create a mock of class Templar
    templar = MagicMock()

    # Create a mock of class SharedPluginLoaderObj
    shared_loader_obj = MagicMock()

    # Create an instance of class ActionModule

# Generated at 2022-06-17 09:33:22.615787
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    # Test with a valid distribution
    action_module = ActionModule()
    action_module.DEFAULT_BOOT_TIME_COMMAND = "uptime"
    action_module.BOOT_TIME_COMMANDS = {
        'RedHat': 'uptime',
        'Debian': 'uptime',
        'SUSE': 'uptime',
        'Arch': 'uptime',
        'Alpine': 'uptime',
        'Gentoo': 'uptime',
        'Solaris': 'uptime',
        'FreeBSD': 'uptime',
        'OpenBSD': 'uptime',
        'AIX': 'uptime',
        'HP-UX': 'uptime',
        'Darwin': 'uptime',
        'DEFAULT': 'uptime'
    }
    result = action_module.get_system

# Generated at 2022-06-17 09:33:27.116269
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    task_vars = {}
    distribution = action_module.get_distribution(task_vars)
    assert distribution == 'DEFAULT'


# Generated at 2022-06-17 09:33:33.212385
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Setup test
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    task_vars = {}
    distribution = 'Ubuntu'

    # Execute method
    result = action_module.get_shutdown_command(task_vars, distribution)

    # Verify results
    assert result == '/sbin/shutdown'


# Generated at 2022-06-17 09:33:43.800310
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # Setup
    action_module = ActionModule()
    action_module._task = Mock()
    action_module._task.args = {}
    action_module._task.args['distribution'] = None
    action_module._task.args['dist'] = None
    action_module._task.args['os_family'] = None
    action_module._task.args['os'] = None
    action_module._task.args['os_type'] = None
    action_module._task.args['platform'] = None
    action_module._task.args['system'] = None
    action_module._task.args['uname'] = None
    action_module._task.args['release'] = None
    action_module._task.args['version'] = None
    action_module._task.args['kernel'] = None
    action_module._

# Generated at 2022-06-17 09:33:53.678481
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    # Create a mock action module
    action_module = ActionModule()
    # Create a mock distribution
    distribution = 'mock_distribution'
    # Create a mock boot time command
    boot_time_command = 'mock_boot_time_command'
    # Create a mock command result
    command_result = {'rc': 0, 'stdout': 'mock_stdout', 'stderr': 'mock_stderr'}
    # Create a mock display
    display = 'mock_display'
    # Create a mock low level execute command
    low_level_execute_command = 'mock_low_level_execute_command'
    # Create a mock task
    task = 'mock_task'
    # Create a mock task action
    task_action = 'mock_task_action'
    # Create a

# Generated at 2022-06-17 09:34:03.824592
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class TaskExecutor
    task_executor = TaskExecutor()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class Connection
    connection = Connection()

    # Create an instance of class AnsibleModule
    ansible_module = AnsibleModule()

    # Create an instance of class AnsibleModule
    ansible_module_2 = AnsibleModule()

    # Create an instance of class AnsibleModule
    ansible_module_3 = AnsibleModule()

    # Create an instance of class AnsibleModule
    ansible_module_4 = AnsibleModule()

    # Create an instance of class AnsibleModule
    ansible_

# Generated at 2022-06-17 09:34:14.524707
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Setup test
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module._task = Mock()
    action_module._task.args = {'shutdown_command': 'shutdown_command'}
    action_module._task.action = 'reboot'
    action_module._task.action = 'reboot'
    action_module._task.action = 'reboot'
    action_module._task.action = 'reboot'
    action_module._task.action = 'reboot'
    action_module._task.action = 'reboot'
    action_module._task.action = 'reboot'
    action_module._task.action = 'reboot'

# Generated at 2022-06-17 09:34:21.309839
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create an instance of class TaskExecutor
    task_executor = TaskExecutor()

    # Create an instance of class Task
    task = Task()

    # Create an instance of class PlayContext
    play_context = PlayContext()

    # Create an instance of class Connection
    connection = Connection()

    # Set properties of object task_executor
    task_executor._task = task

    # Set properties of object task
    task._task_executor = task_executor
    task._role = None
    task._block = None
    task._play = None
    task._ds = None
    task._loader = None
    task._templar = None
    task._shared_loader_obj = None
    task._task_vars = {}
    task

# Generated at 2022-06-17 09:34:28.315093
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Create an instance of the class
    action_module = ActionModule()
    # Create a mock of the class
    action_module_mock = MagicMock(spec=ActionModule)
    # Create a mock of the class
    action_module_mock.get_shutdown_command.return_value = 'shutdown'
    # Create a mock of the class
    action_module_mock.get_shutdown_command.return_value = 'shutdown'
    # Create a mock of the class
    action_module_mock.get_shutdown_command.return_value = 'shutdown'
    # Create a mock of the class
    action_module_mock.get_shutdown_command.return_value = 'shutdown'
    # Create a mock of the class
    action_module_mock.get_shutdown_

# Generated at 2022-06-17 09:36:24.149406
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # Setup test data
    action = ActionModule()
    action_desc = 'test action'
    reboot_timeout = 10
    distribution = 'test_distribution'
    action_kwargs = {'previous_boot_time': 'test_previous_boot_time'}
    # Execute the method under test
    action.do_until_success_or_timeout(action=action.check_boot_time, action_desc=action_desc, reboot_timeout=reboot_timeout, distribution=distribution, action_kwargs=action_kwargs)


# Generated at 2022-06-17 09:36:34.759077
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Create the object
    am = ActionModule()

    # Create a mock task
    task = Mock()
    task.action = 'reboot'
    task.args = {}

    # Set the task on the object
    am._task = task

    # Create a mock connection
    connection = Mock()
    connection.transport = 'ssh'

    # Set the connection on the object
    am._connection = connection

    # Create a mock play context
    play_context = Mock()
    play_context.connection = 'ssh'

    # Set the play context on the object
    am._play_context = play_context

    # Create a mock low level execute command
    low_level_execute_command = Mock()

# Generated at 2022-06-17 09:36:38.420152
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    # Test with no arguments
    result = ActionModule.validate_reboot()
    assert result == None


# Generated at 2022-06-17 09:36:44.190485
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # Test with no arguments
    action_module = ActionModule()
    action_module.check_boot_time(distribution='test_distribution', previous_boot_time='test_previous_boot_time')


# Generated at 2022-06-17 09:36:49.662392
# Unit test for method deprecated_args of class ActionModule

# Generated at 2022-06-17 09:37:01.521651
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # Create an instance of ActionModule
    am = ActionModule()
    # Create a mock of class TimedOutException
    toex = TimedOutException()
    # Create a mock of class Distribution
    distribution = Distribution()
    # Create a mock of class ActionModule
    action_kwargs = ActionModule()
    # Create a mock of class ActionModule
    action_desc = ActionModule()
    # Create a mock of class ActionModule
    reboot_timeout = ActionModule()
    # Create a mock of class ActionModule
    distribution = ActionModule()
    # Create a mock of class ActionModule
    action = ActionModule()
    # Call method do_until_success_or_timeout of class ActionModule
    am.do_until_success_or_timeout(action, reboot_timeout, action_desc, distribution, action_kwargs)

# Generated at 2022-06-17 09:37:10.507326
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module = ActionModule()
    action_module._task = Mock()
    action_module._task.action = 'reboot'
    action_module._task.args = {'shutdown_timeout': '10'}

    distribution = 'RedHat'
    result = action_module.get_shutdown_command_args(distribution)
    assert result == '-r now'

    distribution = 'Debian'
    result = action_module.get_shutdown_command_args(distribution)
    assert result == '-r now'

    distribution = 'FreeBSD'
    result = action_module.get_shutdown_command_args(distribution)
    assert result == '-r now'

    distribution = 'OpenBSD'
    result = action_module.get_shutdown_command_args(distribution)
    assert result

# Generated at 2022-06-17 09:37:20.175863
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # Create an instance of the class
    action_module = ActionModule()

    # Create a mock of the class
    mock_action_module = MagicMock(spec=ActionModule)

    # Create a mock of the class
    mock_action_module = MagicMock(spec=ActionModule)

    # Create a mock of the class
    mock_action_module = MagicMock(spec=ActionModule)

    # Create a mock of the class
    mock_action_module = MagicMock(spec=ActionModule)

    # Create a mock of the class
    mock_action_module = MagicMock(spec=ActionModule)

    # Create a mock of the class
    mock_action_module = MagicMock(spec=ActionModule)

    # Create a mock of the class
    mock_action_module = MagicMock(spec=ActionModule)

# Generated at 2022-06-17 09:37:25.167126
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Setup
    action_module = ActionModule()
    action_module._task = Mock()
    action_module._task.action = 'reboot'
    action_module._task.args = {'shutdown_command': 'shutdown_command'}
    task_vars = {'ansible_facts': {'distribution': 'distribution'}}

    # Test
    result = action_module.get_shutdown_command(task_vars)

    # Assert
    assert result == 'shutdown_command'


# Generated at 2022-06-17 09:37:35.280886
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create a mock of class TaskExecutor
    task_executor = mock.MagicMock()

    # Create a mock of class Task
    task = mock.MagicMock()

    # Create a mock of class PlayContext
    play_context = mock.MagicMock()

    # Set the attributes of the mock
    task.action = 'reboot'
    task.args = {'connect_timeout': '10', 'reboot_timeout': '20', 'test_command': 'uptime', 'msg': 'System is going down for reboot NOW!', 'shutdown_timeout': '30', 'post_reboot_delay': '40', 'reboot_timeout_sec': '50', 'connect_timeout_sec': '60'}

    # Set the attributes of the mock