

# Generated at 2022-06-17 09:31:07.697169
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    # Test with a valid test command
    test_command = 'echo "test"'
    test_command_result = {'rc': 0, 'stdout': 'test', 'stderr': ''}
    test_distribution = 'test'
    test_action = 'test'
    test_action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    test_action_module._low_level_execute_command = MagicMock(return_value=test_command_result)
    test_action_module.run_test_command(test_distribution)
    test_action_module._low_level_execute_command.assert_called_once_with(test_command, sudoable=True)

    # Test with an invalid test

# Generated at 2022-06-17 09:31:13.625602
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # Setup
    action_module = ActionModule(
        task=Mock(
            action='reboot',
            args={}
        ),
        connection=Mock(),
        play_context=Mock(),
        loader=Mock(),
        templar=Mock(),
        shared_loader_obj=None
    )

    # Test
    task_vars = {
        'ansible_distribution': 'Ubuntu',
        'ansible_distribution_version': '14.04'
    }
    result = action_module.get_distribution(task_vars)

    # Assert
    assert result == 'Ubuntu'


# Generated at 2022-06-17 09:31:24.333620
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # Create an instance of class ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create an instance of class Distribution
    distribution = Distribution()

    # Create an instance of class Reboot
    reboot = Reboot()

    # Create an instance of class AnsibleError
    ansible_error = AnsibleError()

    # Create an instance of class AnsibleConnectionFailure
    ansible_connection_failure = AnsibleConnectionFailure()

    # Create an instance of class TimedOutException
    timed_out_exception = TimedOutException()

    # Create an instance of class AnsibleError
    ansible_error = AnsibleError()

    # Create an instance of class AnsibleConnectionFailure

# Generated at 2022-06-17 09:31:26.285438
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    pass


# Generated at 2022-06-17 09:31:31.394605
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # Create an instance of class ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create a mock of class Task
    task = MagicMock()

    # Create a mock of class PlayContext
    play_context = MagicMock()

    # Create a mock of class Connection
    connection = MagicMock()

    # Create a mock of class AnsibleLoader
    loader = MagicMock()

    # Create a mock of class Templar
    templar = MagicMock()

    # Create a mock of class SharedPluginLoaderObj
    shared_loader_obj = MagicMock()

    # Assign the mock objects to the instance of class ActionModule
    action_module._task = task
    action_module._play_context

# Generated at 2022-06-17 09:31:37.621695
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create a mock of class Distribution
    distribution = Distribution()

    # Call method get_shutdown_command_args of class ActionModule
    shutdown_command_args = action_module.get_shutdown_command_args(distribution)

    # Assert that the return value of method get_shutdown_command_args of class ActionModule is equal to '-r now'
    assert shutdown_command_args == '-r now'


# Generated at 2022-06-17 09:31:47.998766
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module = ActionModule()
    action_module._task = Mock()
    action_module._task.args = {'shutdown_command_args': '-h now'}
    action_module.DEFAULT_SHUTDOWN_COMMAND_ARGS = '-r now'
    action_module.SHUTDOWN_COMMAND_ARGS = {'RedHat': '-r now'}
    assert action_module.get_shutdown_command_args('RedHat') == '-h now'
    action_module._task.args = {}
    assert action_module.get_shutdown_command_args('RedHat') == '-r now'
    action_module.SHUTDOWN_COMMAND_ARGS = {}

# Generated at 2022-06-17 09:31:59.209422
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Create a mock task
    task = Task()
    task.action = 'reboot'
    task.args = {
        'reboot_timeout': '30',
        'connect_timeout': '10',
        'post_reboot_delay': '0',
        'test_command': 'whoami',
        'shutdown_command': '/sbin/shutdown',
        'shutdown_command_args': '-r now'
    }

    # Create a mock connection
    connection = Connection()
    connection.transport = 'ssh'

    # Create a mock play context
    play_context = PlayContext()
    play_context.check_mode = False

    # Create a mock AnsibleModule
    ansible_module = AnsibleModule()

    # Create a mock AnsibleModule
    ansible_module = AnsibleModule()



# Generated at 2022-06-17 09:32:08.767312
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # Test with a successful action
    action_module = ActionModule()
    action_module.do_until_success_or_timeout(action=lambda: None, action_desc="", reboot_timeout=1)

    # Test with a failing action
    action_module = ActionModule()
    with pytest.raises(TimedOutException):
        action_module.do_until_success_or_timeout(action=lambda: 1/0, action_desc="", reboot_timeout=1)


# Generated at 2022-06-17 09:32:19.114537
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    # Create an instance of ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create a mock for the method _task.args
    _task_args = MagicMock()
    action_module._task.args = _task_args

    # Create a mock for the method _task.action
    _task_action = MagicMock()
    action_module._task.action = _task_action

    # Create a mock for the method display.warning
    display_warning = MagicMock()
    action_module.display.warning = display_warning

    # Call method deprecated_args with arguments:
    action_module.deprecated_args()

    # Check that the mock_calls for method _task.args is

# Generated at 2022-06-17 09:32:59.595428
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Create a mock task
    mock_task = Mock()
    mock_task.action = 'reboot'
    mock_task.args = {
        'reboot_timeout': 60,
        'connect_timeout': 10,
        'msg': 'Reboot initiated by Ansible'
    }

    # Create a mock connection
    mock_connection = Mock()
    mock_connection.transport = 'ssh'
    mock_connection.host = 'localhost'
    mock_connection.port = 22
    mock_connection.user = 'test_user'
    mock_connection.password = 'test_password'
    mock_connection.private_key_file = '/path/to/private_key'
    mock_connection.become = True
    mock_connection.become_method = 'sudo'

# Generated at 2022-06-17 09:33:09.188349
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Test with a valid shutdown_command
    task_vars = {'ansible_facts': {'distribution': 'RedHat'}}
    action_module = ActionModule(task=MagicMock(), connection=MagicMock(), play_context=MagicMock(), loader=MagicMock(), templar=MagicMock(), shared_loader_obj=None)
    action_module._task.args = {'shutdown_command': '/sbin/shutdown'}
    assert action_module.get_shutdown_command(task_vars, 'RedHat') == '/sbin/shutdown'
    # Test with a valid distribution
    task_vars = {'ansible_facts': {'distribution': 'RedHat'}}

# Generated at 2022-06-17 09:33:14.044459
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Create a mock task
    task = Mock()
    task.action = 'reboot'
    task.args = {'shutdown_command': 'shutdown_command'}

    # Create a mock connection
    connection = Mock()
    connection.transport = 'ssh'

    # Create a mock play context
    play_context = Mock()
    play_context.check_mode = False

    # Create a mock AnsibleModule
    ansible_module = Mock()
    ansible_module.params = {'shutdown_command': 'shutdown_command'}

    # Create a mock AnsibleModule
    ansible_module = Mock()
    ansible_module.params = {'shutdown_command': 'shutdown_command'}

    # Create a mock AnsibleModule
    ansible_module = Mock()

# Generated at 2022-06-17 09:33:17.426226
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    # Create an instance of ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create a mock of distribution
    distribution = MagicMock(spec=str)

    # Call method run_test_command with the mock
    action_module.run_test_command(distribution)


# Generated at 2022-06-17 09:33:28.981192
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    # Create a mock task
    task = Mock()
    task.action = 'reboot'
    task.args = {'connect_timeout': '10', 'reboot_timeout': '20', 'test_command': 'test_command', 'msg': 'msg'}

    # Create a mock connection
    connection = Mock()
    connection.transport = 'ssh'

    # Create a mock play context
    play_context = Mock()
    play_context.check_mode = False

    # Create a mock AnsibleModule
    ansible_module = Mock()

    # Create a mock AnsibleModule
    ansible_module = Mock()

    # Create a mock display
    display = Mock()

    # Create a mock datetime
    datetime = Mock()

    # Create a mock timedelta
    timedelta = Mock()

    # Create a mock time

# Generated at 2022-06-17 09:33:35.011376
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create a mock of class TaskExecutor
    task_executor = mock.MagicMock()

    # Create a mock of class Task
    task = mock.MagicMock()

    # Set the attributes of the mock
    task.action = 'reboot'
    task.args = {'connect_timeout': '10', 'reboot_timeout': '10'}

    # Set the attributes of the mock
    task_executor.task = task

    # Set the attributes of the mock
    action_module._task = task_executor

    # Call the method
    action_module.deprecated_args()

    # Check if the method has been called
    assert task_executor.display.warning.called

    # Check if the method has been called
    assert task

# Generated at 2022-06-17 09:33:47.178360
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # Test with success
    action_module = ActionModule()
    action_module.do_until_success_or_timeout(
        action=action_module.check_boot_time,
        action_desc="last boot time check",
        reboot_timeout=10,
        distribution='DEFAULT',
        action_kwargs={'previous_boot_time': 'test'})

    # Test with failure
    action_module = ActionModule()
    with pytest.raises(TimedOutException):
        action_module.do_until_success_or_timeout(
            action=action_module.check_boot_time,
            action_desc="last boot time check",
            reboot_timeout=1,
            distribution='DEFAULT',
            action_kwargs={'previous_boot_time': 'test'})


# Generated at 2022-06-17 09:33:51.896662
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # Create an instance of ActionModule
    am = ActionModule()
    # Create a mock distribution
    distribution = 'mock_distribution'
    # Create a mock previous_boot_time
    previous_boot_time = 'mock_previous_boot_time'
    # Call method check_boot_time of class ActionModule
    am.check_boot_time(distribution, previous_boot_time)


# Generated at 2022-06-17 09:34:02.754992
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # Create an instance of ActionModule
    action_module = ActionModule()
    # Create a mock of class TimedOutException
    timed_out_exception = TimedOutException()
    # Create a mock of class ValueError
    value_error = ValueError()
    # Create a mock of class AnsibleConnectionFailure
    ansible_connection_failure = AnsibleConnectionFailure()
    # Create a mock of class AnsibleError
    ansible_error = AnsibleError()
    # Create a mock of class AttributeError
    attribute_error = AttributeError()
    # Create a mock of class Exception
    exception = Exception()
    # Create a mock of class AnsibleConnectionFailure
    ansible_connection_failure = AnsibleConnectionFailure()
    # Create a mock of class AnsibleError
    ansible_error = AnsibleError()
    #

# Generated at 2022-06-17 09:34:07.456997
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create a mock of class Distribution
    distribution = Distribution()

    # Call method get_shutdown_command_args of class ActionModule
    result = action_module.get_shutdown_command_args(distribution)

    # Assertions
    assert result == '-r now'


# Generated at 2022-06-17 09:35:19.168749
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    # Create an instance of class ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create a mock of class Distribution
    distribution = Distribution()

    # Call method get_shutdown_command_args of class ActionModule with the mock of class Distribution
    action_module.get_shutdown_command_args(distribution)


# Generated at 2022-06-17 09:35:32.697432
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    # Create a mock object of class ActionModule
    action_module_obj = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create a mock object of class AnsibleConnection
    ansible_connection_obj = AnsibleConnection(play_context=None, new_stdin=None)

    # Set the connection attribute of the mock object of class ActionModule
    action_module_obj._connection = ansible_connection_obj

    # Create a mock object of class AnsibleTask

# Generated at 2022-06-17 09:35:43.001014
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Test with a valid shutdown_command
    task_vars = dict(
        ansible_facts=dict(
            DISTRIBUTION='RedHat',
            DISTRIBUTION_MAJOR_VERSION='7',
            DISTRIBUTION_VERSION='7.5',
            DISTRIBUTION_RELEASE='Red Hat Enterprise Linux Server release 7.5 (Maipo)',
            DISTRIBUTION_CODENAME='Maipo'
        )
    )
    action_module = ActionModule(dict(
        name='reboot',
        action='reboot',
        args=dict(
            shutdown_command='/usr/bin/shutdown'
        )
    ), task_vars=task_vars)
    assert action_module.get_shutdown_command(task_vars) == '/usr/bin/shutdown'

    #

# Generated at 2022-06-17 09:35:51.508885
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Create an instance of ActionModule
    action_module = ActionModule()

    # Create a mock of task_vars
    task_vars = {}

    # Create a mock of distribution
    distribution = 'test_distribution'

    # Call method get_shutdown_command of action_module with the mock objects
    result = action_module.get_shutdown_command(task_vars, distribution)

    # Assert the result
    assert result == 'shutdown'


# Generated at 2022-06-17 09:35:58.557832
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Create an instance of class ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create a mock of class Task
    task = MagicMock()

    # Create a mock of class Connection
    connection = MagicMock()

    # Create a mock of class PlayContext
    play_context = MagicMock()

    # Create a mock of class DataLoader
    loader = MagicMock()

    # Create a mock of class Templar
    templar = MagicMock()

    # Create a mock of class SharedPluginLoaderObj
    shared_loader_obj = MagicMock()

    # Set the attributes of the mock
    action_module._task = task
    action_module._connection = connection
    action_module._play

# Generated at 2022-06-17 09:36:08.690226
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Create a mock task
    mock_task = Mock()
    mock_task.action = 'reboot'
    mock_task.args = {'shutdown_command': '/sbin/shutdown'}

    # Create a mock connection
    mock_connection = Mock()
    mock_connection.transport = 'ssh'
    mock_connection.host = 'localhost'
    mock_connection.port = 22
    mock_connection.remote_addr = '127.0.0.1'
    mock_connection.set_options.return_value = None

    # Create a mock AnsibleModule
    mock_ansible_module = Mock()
    mock_ansible_module.params = {'shutdown_command': '/sbin/shutdown'}

    # Create a mock AnsibleModule
    mock_ansible_module = Mock()
    mock

# Generated at 2022-06-17 09:36:18.999886
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    # Create an instance of class ActionModule
    action_module = ActionModule()
    # Create a mock of the class AnsibleModule
    ansible_module_mock = mock.Mock()
    # Create a mock of the class AnsibleModule.run_command
    ansible_module_mock.run_command = mock.Mock()
    # Create a mock of the class AnsibleModule.run_command.return_value
    ansible_module_mock.run_command.return_value = {'rc': 0, 'stdout': '', 'stderr': ''}
    # Set the attributes of the class ActionModule
    action_module._task = ansible_module_mock
    action_module._low_level_execute_command = ansible_module_mock.run_command
    # Set the attributes of the class Ansible

# Generated at 2022-06-17 09:36:31.376150
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    # Setup
    action_module = ActionModule()
    action_module._task = MagicMock()
    action_module._task.action = 'reboot'
    action_module._low_level_execute_command = MagicMock()
    action_module.DEFAULT_SUDOABLE = True
    distribution = 'test_distribution'
    test_command = 'test_command'

    # Test
    action_module.run_test_command(distribution, test_command=test_command)

    # Assert
    action_module._low_level_execute_command.assert_called_once_with(test_command, sudoable=True)


# Generated at 2022-06-17 09:36:37.386149
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Create an instance of class ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # Create an instance of class Task
    task = Task()
    # Create an instance of class PlayContext
    play_context = PlayContext()
    # Create an instance of class Connection
    connection = Connection()
    # Create an instance of class AnsibleLoader
    ansible_loader = AnsibleLoader()
    # Create an instance of class DataLoader
    data_loader = DataLoader()
    # Create an instance of class VariableManager
    variable_manager = VariableManager()
    # Create an instance of class Templar
    templar = Templar(loader=None, variables=None)
    # Create an instance of class SharedPluginLoaderObj
    shared

# Generated at 2022-06-17 09:36:47.520683
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create a mock connection plugin
    class MockConnection(ConnectionBase):
        def __init__(self, *args, **kwargs):
            self.transport = 'local'
            self.host = 'localhost'
            self.port = 22
            self.has_pipelining = False
            self.become = False
            self.become_method = 'sudo'
            self.become_user = 'root'
            self.no_log = False
            self.allow_executable = False
            self.set_options(**kwargs)

        def set_options(self, var_options=None, direct=None):
            self.connection = self
            self.become = False
            self.become_method = 'sudo'
            self.become_user = 'root'
            self.no_log = False

# Generated at 2022-06-17 09:38:35.683789
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    # Test with no arguments
    try:
        ActionModule.run_test_command(self=None, distribution=None)
    except Exception as e:
        assert type(e) is TypeError
    # Test with valid arguments
    try:
        ActionModule.run_test_command(self=None, distribution=None, **{})
    except Exception as e:
        assert type(e) is TypeError

# Generated at 2022-06-17 09:38:42.347510
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    # Create an instance of ActionModule
    action_module = ActionModule()
    # Create a mock of distribution
    distribution = mock.MagicMock()
    # Call method run_test_command with the mock
    action_module.run_test_command(distribution)


# Generated at 2022-06-17 09:38:47.417240
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    # Create an instance of class ActionModule
    action_module = ActionModule()
    # Create an instance of class Distribution
    distribution = Distribution()
    # Test method get_shutdown_command_args of class ActionModule
    action_module.get_shutdown_command_args(distribution)


# Generated at 2022-06-17 09:38:54.828088
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action_module = ActionModule()
    action_module._task = Mock()
    action_module._task.action = 'reboot'
    action_module._task.args = {'connect_timeout': '10'}
    action_module.deprecated_args()


# Generated at 2022-06-17 09:39:03.032675
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # Create an instance of ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create a mock of class Distribution
    distribution = Distribution()
    # Create a mock of class datetime
    datetime = Datetime()
    # Create a mock of class ValueError
    value_error = ValueError()
    # Set attributes of mock
    value_error.args = ["boot time has not changed"]

    # Create a mock of class AnsibleError
    ansible_error = AnsibleError()
    # Set attributes of mock
    ansible_error.args = ["Unable to find command \"/sbin/shutdown\" in search paths: ['/sbin', '/usr/sbin', '/bin', '/usr/bin']"]

# Generated at 2022-06-17 09:39:08.687457
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create a mock of class TaskExecutor
    task_executor = mock.MagicMock()

    # Create a mock of class Task
    task = mock.MagicMock()

    # Create a mock of class PlayContext
    play_context = mock.MagicMock()

    # Create a mock of class Connection
    connection = mock.MagicMock()

    # Set the attributes of the mock objects
    task_executor.task = task
    task_executor._play_context = play_context
    task_executor._connection = connection

    # Set the attributes of the mock objects
    task.action = 'reboot'
    task.args = {'connect_timeout': 10, 'reboot_timeout': 120, 'post_reboot_delay': 0}



# Generated at 2022-06-17 09:39:19.272649
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # Create an instance of class ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # Create an instance of class AnsibleModule
    ansible_module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    # Create an instance of class Task
    task = Task()
    # Create an instance of class PlayContext
    play_context = PlayContext()
    # Create an instance of class Connection
    connection = Connection()
    # Create an instance of class PlayContext
    play_context = PlayContext()
    # Create an instance of class PlayContext
    play_context = PlayContext()
    # Create an instance of class PlayContext
    play_context = PlayContext()
    # Create an instance of class

# Generated at 2022-06-17 09:39:32.854892
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Create a mock task
    mock_task = Mock()
    mock_task.action = 'reboot'
    mock_task.args = {'shutdown_command': 'shutdown'}

    # Create a mock connection
    mock_connection = Mock()
    mock_connection.transport = 'ssh'

    # Create a mock play context
    mock_play_context = Mock()
    mock_play_context.check_mode = False

    # Create a mock AnsibleModule
    mock_ansible_module = Mock()
    mock_ansible_module.params = {}

    # Create a mock AnsibleModule
    mock_ansible_module = Mock()
    mock_ansible_module.params = {}

    # Create a mock AnsibleModule
    mock_ansible_module = Mock()

# Generated at 2022-06-17 09:39:44.763875
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of class ActionModule
    action_module = ActionModule()

    # Create a mock of class TaskExecutor
    task_executor = mock.Mock()

    # Create a mock of class Task
    task = mock.Mock()

    # Create a mock of class PlayContext
    play_context = mock.Mock()

    # Create a mock of class Connection
    connection = mock.Mock()

    # Set the attributes of the mock objects
    task_executor.task = task
    task.action = 'reboot'
    task.args = {'reboot_timeout': '300', 'connect_timeout': '10'}
    task.async_val = None
    task.notify = []
    task.run_once = False
    task.loop = None
    task.loop_args = None
    task

# Generated at 2022-06-17 09:39:48.002113
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # Setup
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    distribution = None
    previous_boot_time = None

    # Test
    module.check_boot_time(distribution, previous_boot_time)
