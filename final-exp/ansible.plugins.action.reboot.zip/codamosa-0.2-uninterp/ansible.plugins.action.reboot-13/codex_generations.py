

# Generated at 2022-06-17 09:35:45.662152
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    # Setup
    action_module = ActionModule()
    action_module._task = Mock()
    action_module._task.action = 'reboot'
    action_module._task.args = {'reboot_timeout': '10'}
    action_module._connection = Mock()
    action_module._connection.get_option = Mock(return_value=10)
    action_module._connection.set_option = Mock()
    action_module._connection.reset = Mock()
    action_module.DEFAULT_REBOOT_TIMEOUT = 10
    action_module.DEFAULT_CONNECT_TIMEOUT = 10
    action_module.check_boot_time = Mock(side_effect=[ValueError('boot time has not changed'), None])

# Generated at 2022-06-17 09:35:56.474622
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Create an instance of ActionModule
    action_module = ActionModule()
    # Create a mock of class TaskExecutor
    task_executor = TaskExecutor()
    # Set the return value of method get_task_vars of task_executor to a mock
    task_executor.get_task_vars = MagicMock(return_value=None)
    # Set the return value of method get_vars of task_executor to a mock
    task_executor.get_vars = MagicMock(return_value=None)
    # Set the return value of method get_tmp_path of task_executor to a mock
    task_executor.get_tmp_path = MagicMock(return_value=None)
    # Set the return value of method get_original_file_attributes of task_executor to a mock

# Generated at 2022-06-17 09:36:05.493714
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # Test with a successful action
    action_module = ActionModule()
    action_module.do_until_success_or_timeout(action=lambda: None, action_desc="", reboot_timeout=1)

    # Test with a failing action
    action_module = ActionModule()
    with pytest.raises(TimedOutException):
        action_module.do_until_success_or_timeout(action=lambda: 1/0, action_desc="", reboot_timeout=1)


# Generated at 2022-06-17 09:36:16.577724
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Create a mock task
    task = Mock()
    task.action = 'reboot'

# Generated at 2022-06-17 09:36:24.787581
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # Create an instance of ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create a mock function for action
    def mock_action(distribution, **kwargs):
        pass

    # Create a mock function for action_kwargs
    def mock_action_kwargs():
        pass

    # Call method do_until_success_or_timeout of action_module with required arguments
    action_module.do_until_success_or_timeout(action=mock_action, action_desc="last boot time check", reboot_timeout=reboot_timeout, distribution=distribution, action_kwargs=mock_action_kwargs)


# Generated at 2022-06-17 09:36:33.010413
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    # Setup
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module._task = Mock()
    action_module._task.action = 'reboot'
    action_module._task.args = {'connect_timeout': '10'}

    # Test
    action_module.deprecated_args()

    # Assertions
    assert action_module._task.args['connect_timeout'] == '10'


# Generated at 2022-06-17 09:36:42.923306
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    # Create an instance of class ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Test with distribution = 'DEFAULT'
    distribution = 'DEFAULT'
    assert action_module.get_shutdown_command_args(distribution) == '-r now'

    # Test with distribution = 'RedHat'
    distribution = 'RedHat'
    assert action_module.get_shutdown_command_args(distribution) == '-r now'

    # Test with distribution = 'CentOS'
    distribution = 'CentOS'
    assert action_module.get_shutdown_command_args(distribution) == '-r now'

    # Test with distribution = 'Fedora'

# Generated at 2022-06-17 09:36:53.817889
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    # Create an instance of class ActionModule
    action_module = ActionModule()
    # Create an instance of class Distribution
    distribution = Distribution()
    # Set the distribution name
    distribution.name = 'Ubuntu'
    # Set the distribution version
    distribution.version = '16.04'
    # Set the distribution id
    distribution.id = 'Ubuntu'
    # Set the distribution like
    distribution.like = 'debian'
    # Set the distribution family
    distribution.family = 'debian'
    # Set the distribution codename
    distribution.codename = 'xenial'
    # Set the distribution major version
    distribution.major_version = '16'
    # Set the distribution minor version
    distribution.minor_version = '04'
    # Set the distribution build number
    distribution.build_number = '0'
    # Set

# Generated at 2022-06-17 09:36:56.545819
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Test with no arguments
    module = ActionModule()
    result = module.perform_reboot()
    assert result == {}


# Generated at 2022-06-17 09:37:05.367137
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # Setup
    action_module = ActionModule(task=MagicMock(), connection=MagicMock(), play_context=MagicMock())
    distribution = 'test_distribution'
    previous_boot_time = 'test_previous_boot_time'
    action_module.get_system_boot_time = MagicMock(return_value='test_current_boot_time')

    # Test
    action_module.check_boot_time(distribution, previous_boot_time)

    # Verify
    action_module.get_system_boot_time.assert_called_once_with(distribution)
