

# Generated at 2022-06-17 09:31:06.176505
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # Create an instance of ActionModule
    action_module = ActionModule()

    # Create a mock of class TimedOutException
    class TimedOutException(Exception):
        pass

    # Create a mock of class ValueError
    class ValueError(Exception):
        pass

    # Create a mock of class AnsibleError
    class AnsibleError(Exception):
        pass

    # Create a mock of class AnsibleConnectionFailure
    class AnsibleConnectionFailure(Exception):
        pass

    # Create a mock of class AttributeError
    class AttributeError(Exception):
        pass

    # Create a mock of class AnsibleError
    class AnsibleError(Exception):
        pass

    # Create a mock of class AnsibleError
    class AnsibleError(Exception):
        pass

    # Create a mock of class AnsibleError

# Generated at 2022-06-17 09:31:17.692445
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # create an instance of the class to be tested
    action_module = ActionModule()
    # create a mock of the AnsibleModule class
    mock_ansible_module = MagicMock()
    # create a mock of the AnsibleModule class
    mock_ansible_module.params = {}
    # create a mock of the AnsibleModule class
    mock_ansible_module.check_mode = False
    # create a mock of the AnsibleModule class
    mock_ansible_module.debug = False
    # create a mock of the AnsibleModule class
    mock_ansible_module.run_command = MagicMock()
    # create a mock of the AnsibleModule class
    mock_ansible_module.run_command.return_value = (0, '', '')
    # create a mock of the AnsibleModule class
    mock

# Generated at 2022-06-17 09:31:28.472020
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    # Setup
    action_module = ActionModule()
    action_module._task = Mock()
    action_module._task.action = 'reboot'
    action_module._task.args = {'reboot_timeout': 10}
    action_module._connection = Mock()
    action_module._connection.get_option.return_value = None
    action_module._connection.set_option.return_value = None
    action_module._connection.reset.return_value = None
    action_module.DEFAULT_REBOOT_TIMEOUT = 10
    action_module.DEFAULT_CONNECT_TIMEOUT = 10
    action_module.DEFAULT_SUDOABLE = True
    action_module.DEFAULT_TEST_COMMAND = 'echo "hello"'
    action_module.DEFAULT_BOOT_TIME_COMM

# Generated at 2022-06-17 09:31:34.936250
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # Create a mock action module
    action_module = ActionModule(task=Mock(), connection=Mock(), play_context=Mock(), loader=Mock(), templar=Mock(), shared_loader_obj=Mock())
    # Create a mock task_vars
    task_vars = {}
    # Call the method
    result = action_module.get_distribution(task_vars)
    # Assert the result
    assert result == 'DEFAULT'


# Generated at 2022-06-17 09:31:46.507585
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    # Test with a valid distribution
    action_module = ActionModule()
    action_module.set_task({"action": "reboot"})
    action_module.set_connection({"transport": "ssh"})
    action_module.set_loader({"_basedir": "."})
    action_module.set_play_context({"check_mode": False})
    action_module.set_task_vars({"ansible_facts": {"distribution": "RedHat"}})

# Generated at 2022-06-17 09:31:55.272481
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # Create an instance of class ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create a mock object of class Task
    task = MagicMock()

    # Set the task object attribute of action_module
    action_module._task = task

    # Create a mock object of class PlayContext
    play_context = MagicMock()

    # Set the play_context object attribute of action_module
    action_module._play_context = play_context

    # Create a mock object of class Connection
    connection = MagicMock()

    # Set the connection object attribute of action_module
    action_module._connection = connection

    # Create a mock object of class AnsibleLoader
    loader = MagicMock()

    #

# Generated at 2022-06-17 09:32:06.941500
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Setup
    action_module = ActionModule()
    action_module._task = Mock()
    action_module._task.action = 'reboot'
    action_module._task.args = {'reboot_timeout': '30'}
    action_module._task.args.get = Mock(return_value='30')
    action_module._task.args.get.side_effect = lambda x: action_module._task.args[x]
    action_module._task.args.get.return_value = '30'
    action_module._task.args.get.return_value = '30'
    action_module._task.args.get.return_value = '30'
    action_module._task.args.get.return_value = '30'

# Generated at 2022-06-17 09:32:16.528222
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    # Create an instance of class ActionModule
    action_module = ActionModule()
    # Create an instance of class AnsibleModule
    ansible_module = AnsibleModule()
    # Create an instance of class AnsibleTask
    ansible_task = AnsibleTask()
    # Create an instance of class AnsiblePlay
    ansible_play = AnsiblePlay()
    # Create an instance of class AnsiblePlayContext
    ansible_play_context = AnsiblePlayContext()
    # Create an instance of class AnsibleConnection
    ansible_connection = AnsibleConnection()
    # Create an instance of class AnsibleRunner
    ansible_runner = AnsibleRunner()
    # Create an instance of class AnsibleRunnerCallbacks
    ansible_runner_callbacks = AnsibleRunnerCallbacks()
    # Create an instance of class AnsibleRunnerResult
    ansible

# Generated at 2022-06-17 09:32:22.825101
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # Create an instance of ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Create a mock of task_vars
    task_vars = {}

    # Call method get_distribution with parameters task_vars
    result = action_module.get_distribution(task_vars)

    # AssertionError: 'DEFAULT_DISTRIBUTION' not in result
    assert 'DEFAULT_DISTRIBUTION' in result


# Generated at 2022-06-17 09:32:31.158359
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # Test with a success
    action_module = ActionModule()
    action_module.do_until_success_or_timeout(action=lambda: True, action_desc="test", reboot_timeout=1)

    # Test with a failure
    with pytest.raises(TimedOutException):
        action_module.do_until_success_or_timeout(action=lambda: False, action_desc="test", reboot_timeout=1)


# Generated at 2022-06-17 09:33:35.664154
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Setup test
    test_module = ActionModule()
    test_module._task = MagicMock()
    test_module._task.action = 'reboot'
    test_module._task.args = {'reboot_timeout': '300'}
    test_module._task.async_val = 300
    test_module._task.async_seconds = 300
    test_module._task.async_poll_interval = 10
    test_module._task.async_jid = '123456789.123'
    test_module._task.no_log = False
    test_module._task.run_once = False
    test_module._task.notify = []
    test_module._task.tags = []
    test_module._task.when = []
    test_module._task.loop = []


# Generated at 2022-06-17 09:33:48.253343
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # Create a mock object for the module class
    action_module_mock = ActionModule()

    # Create a mock object for the task class
    task_mock = Task()

    # Create a mock object for the task_vars class
    task_vars_mock = dict()

    # Set the task_vars_mock object attribute 'ansible_facts'
    task_vars_mock['ansible_facts'] = dict()

    # Set the task_vars_mock object attribute 'ansible_facts'
    task_vars_mock['ansible_facts']['ansible_distribution'] = 'Ubuntu'

    # Set the task_vars_mock object attribute 'ansible_facts'
    task_vars_mock['ansible_facts']['ansible_distribution_version']

# Generated at 2022-06-17 09:34:00.260917
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # Create an instance of ActionModule
    action_module = ActionModule()
    # Create a mock of the class 'ActionModule'
    action_module_mock = MagicMock(spec=ActionModule)
    # Create a mock of the method 'get_system_boot_time' of class 'ActionModule'
    action_module_mock.get_system_boot_time = MagicMock(return_value="")
    # Create a mock of the method '_low_level_execute_command' of class 'ActionModule'
    action_module_mock._low_level_execute_command = MagicMock(return_value={"rc": 0, "stdout": "", "stderr": ""})
    # Create a mock of the method '_get_value_from_facts' of class 'ActionModule'
    action_module_mock

# Generated at 2022-06-17 09:34:05.493740
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Create an instance of ActionModule
    action_module = ActionModule()

    # Create a mock of task_vars
    task_vars = {}

    # Create a mock of distribution
    distribution = 'mock_distribution'

    # Call method get_shutdown_command of class ActionModule with parameters task_vars and distribution
    result = action_module.get_shutdown_command(task_vars, distribution)

    # Assert the result is equal to 'shutdown'
    assert result == 'shutdown'


# Generated at 2022-06-17 09:34:14.102729
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    # Setup
    action_module = ActionModule()
    action_module._task = Mock()
    action_module._task.action = 'reboot'
    action_module._task.args = {}
    action_module._low_level_execute_command = Mock()
    action_module._low_level_execute_command.return_value = {'rc': 0, 'stdout': 'Tue Aug  7 13:21:01 UTC 2018', 'stderr': ''}
    distribution = 'Linux'

    # Test
    result = action_module.get_system_boot_time(distribution)

    # Verify
    assert result == 'Tue Aug  7 13:21:01 UTC 2018'

# Generated at 2022-06-17 09:34:18.195632
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # Create an instance of class ActionModule
    am = ActionModule()

    # Create a mock of method get_system_boot_time
    with patch.object(ActionModule, 'get_system_boot_time', return_value='2018-01-01 00:00:00'):
        # Call method check_boot_time
        am.check_boot_time('distribution', 'previous_boot_time')


# Generated at 2022-06-17 09:34:32.107105
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module = ActionModule()
    action_module.DEFAULT_SUDOABLE = True
    action_module.DEFAULT_CONNECT_TIMEOUT = 5
    action_module.DEFAULT_REBOOT_TIMEOUT = 600
    action_module.DEFAULT_POST_REBOOT_DELAY = 0
    action_module.TEST_COMMANDS = {
        'DEFAULT_TEST_COMMAND': 'echo "hello world"'
    }
    action_module.BOOT_TIME_COMMANDS = {
        'DEFAULT_BOOT_TIME_COMMAND': 'echo "boot time"'
    }
    action_module.SHUTDOWN_COMMANDS = {
        'DEFAULT_SHUTDOWN_COMMAND': 'echo "shutdown command"'
    }
    action_module.SHUT

# Generated at 2022-06-17 09:34:38.299200
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    # Setup
    action_module = ActionModule()
    action_module._task = MagicMock()
    action_module._task.action = 'reboot'
    action_module.DEPRECATED_ARGS = {'reboot_timeout': '2.4'}
    action_module._task.args = {'reboot_timeout': '1'}
    action_module.display = MagicMock()

    # Test
    action_module.deprecated_args()

    # Assert
    action_module.display.warning.assert_called_once_with("Since Ansible 2.4, reboot_timeout is no longer a valid option for reboot")


# Generated at 2022-06-17 09:34:47.245631
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    # Create an instance of class ActionModule
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # Test with distribution as 'redhat'
    distribution = 'redhat'
    # Test with distribution as 'debian'
    distribution = 'debian'
    # Test with distribution as 'suse'
    distribution = 'suse'
    # Test with distribution as 'freebsd'
    distribution = 'freebsd'
    # Test with distribution as 'arch'
    distribution = 'arch'
    # Test with distribution as 'gentoo'
    distribution = 'gentoo'
    # Test with distribution as 'alpine'
    distribution = 'alpine'
    # Test with distribution as 'default'
    distribution = 'default'


# Generated at 2022-06-17 09:34:52.568302
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    # Test with no parameters
    action_module = ActionModule()
    action_module.validate_reboot()
    # Test with parameters
    action_module = ActionModule()
    action_module.validate_reboot(distribution="distribution", original_connection_timeout="original_connection_timeout", action_kwargs="action_kwargs")
