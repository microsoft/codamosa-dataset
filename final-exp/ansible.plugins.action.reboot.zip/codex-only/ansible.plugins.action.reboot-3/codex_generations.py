

# Generated at 2022-06-23 08:18:46.146182
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # Create the task object from which we'll access data.  This is not
    # strictly necessary, but we're trying to simulate how the module will be
    # used.
    task = Task()
    task.action = 'reboot'
    task.args = {
        'test_command': '/opt/bin/uptime',
        'reboot_timeout': 10,
        'post_reboot_delay': 0,
        'shutdown_command': '/sbin/shutdown',
        'shutdown_command_args': '-r now',
    }

    # Create a mock object of the action
    module = ActionModule(
        task,
        connection=None,
        play_context=PlayContext(),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )


# Generated at 2022-06-23 08:19:00.288754
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # resetting the instance so that it is recreated
    ActionModule._instance = None

    # setup a mock task
    task = mock.MagicMock()
    action = AnsibleActionModule(task)
    task.action = 'reboot'

    # Provide a mock task_vars
    task_vars = dict()
    task_vars['ansible_facter_system_uptime_sec'] = '0'

    setattr(task, 'args', dict())

    # Since the system uptime is 0, it should return True
    assert action.get_shutdown_command(task_vars, 'default') is not None

    # resetting the instance so that it is recreated
    ActionModule._instance = None


# Generated at 2022-06-23 08:19:11.110216
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    # test when no args are passed
    action_module = get_action_module()
    result = action_module.get_shutdown_command_args('amzn')
    assert result == '-r now'

    # test when args are passed
    action_module = get_action_module(args={'shutdown_command_args': '-h now'})
    result = action_module.get_shutdown_command_args('amzn')
    assert result == '-h now'

    # test when args are passed as a list
    action_module = get_action_module(args={'shutdown_command_args': ['-h', 'now']})
    result = action_module.get_shutdown_command_args('amzn')
    assert result == '-h now'

    # test when args are passed as a list


# Generated at 2022-06-23 08:19:22.526707
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # Test with a non-empty stdout (e.g.: FreeBSD)
    result = {'rc': 0, 'stdout': b'test'}
    distribution = 'FreeBSD'
    previous_boot_time = b'Tue Sep 25 10:00:56 CEST 2018'
    task_action = action.ActionModule()
    # Set the side effect of the mocked method
    side_effect = [result]
    task_action.get_system_boot_time = MagicMock(side_effect=side_effect)
    # Method to be tested
    task_action.check_boot_time(distribution, previous_boot_time)
    # Test that the mocked method was called
    task_action.get_system_boot_time.assert_called_once_with(distribution)
    # Test with an empty stdout that should raise an

# Generated at 2022-06-23 08:19:34.147461
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    action_module = ActionModule()

    action_module._connection = None
    action_module._task = None
    action_module._play_context = None
    action_module._supports_async = None
    action_module._supports_check_mode = None
    action_module._tmp = None
    action_module._loader = None
    action_module._shared_loader_obj = None
    action_module.DEFAULT_BOOT_TIME_COMMAND = None
    action_module.DEFAULT_CONNECT_TIMEOUT = None
    action_module.DEFAULT_REBOOT_TIMEOUT = None
    action_module.DEFAULT_REBOOT_TIMEOUT_IN_SECONDS = None
    action_module.DEFAULT_SUDOABLE = None
    action_module.DEPRECATED_ARGS = None

# Generated at 2022-06-23 08:19:35.312081
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():

    assert False # No tests implemented yet

# Generated at 2022-06-23 08:19:47.929892
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    import datetime
    from ansible.module_utils._text import to_text
    from ansible.errors import AnsibleError
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # Create an instance of module ActionModule
    action_module = ActionModule()
    # Create an instance of class AnsibleError
    e = AnsibleError()

    # Set the following attributes for module ActionModule
    action_module._task = dict()
    action_module._task.action = "reboot"
    action_module._task.args = dict()
    action_module._task.args['boot_time_command'] = AnsibleUnicode()
    action_module._task.args['boot_time_command'].value = "who -b"

# Generated at 2022-06-23 08:19:59.611182
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    mocker, mock_task = mocker_setup(mock_action_task='reboot')
    action_module = ActionModule(mock_task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    action_module._get_task_var = mocker.MagicMock(return_value='/sbin/shutdown')
    m_ansible = mocker.patch('ansible.plugins.action.reboot.AnsibleModule')
    result = action_module.get_shutdown_command('ubuntu')
    assert result == '/sbin/shutdown'


# Generated at 2022-06-23 08:20:10.148263
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    module_name = 'system'
    module_path = os.path.join(ansible_path, 'lib/ansible/test/modules', module_name)
    module_args = {"name": "test"}
    mock_task = MagicMock()
    mock_task.action = 'reboot'
    mock_task.args = module_args
    module = Reboot(mock_task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    distribution = "system"
    module.run_test_command(distribution)

# Generated at 2022-06-23 08:20:19.258397
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    _task = mock.MagicMock()
    _task.args = dict()
    _task.action = 'reboot'
    _task.args['connect_timeout'] = 10
    _task.args['reboot_timeout'] = 10
    _task.async_val = 60
    _task.async_jid = '12345.67890'
    _play_context = mock.MagicMock()
    _play_context.connection = 'network_cli'
    _play_context.check_mode = False
    _play_context.no_log = False
    _task.play_context = _play_context
    _task.register = 'reboot_result'
    _inject = dict(
        command='/sbin/shutdown -r now',
    )

# Generated at 2022-06-23 08:20:32.891934
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # ----
    # Setup
    # ----
    # Setup a mock task, connection, and action
    mock_task = MagicMock()
    mock_task.args = {'shutdown_command': 'shutdown'}
    mock_task.action = 'reboot'
    mock_connection = MagicMock()
    mock_connection.transport = 'ssh'
    mock_action = ActionModule(mock_task, mock_connection)
    # Return a mock run_command
    mock_action._low_level_execute_command = MagicMock(return_value={'rc':0})
    # Set the distribution to return
    mock_action._get_distro = MagicMock(return_value='DEBIAN')
    # Setup a mock distribution fact

# Generated at 2022-06-23 08:20:39.201904
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Local variables for test of method run of class ActionModule
    kwargs = {'reboot_timeout': 10, 'post_reboot_delay': 10}
    # Init class ActionModule
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # Call run of class ActionModule and test return
    result = am._execute()
    assert result['changed'] is True
    assert result['rebooted'] is True
    assert result['elapsed'] == 0
    assert result['failed'] is False
    assert result['msg'] is None



# Generated at 2022-06-23 08:20:43.480331
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    action_module = ActionModule(dict(test_key=True))

    action_module.do_until_success_or_timeout(action=action_module, action_desc="test execution", action_kwargs={'test_key': True})
    assert action_module.test_key is True

# Generated at 2022-06-23 08:20:45.761011
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    pass # tests are implemented using "with patch('ansible.module_utils.basic.AnsibleModule.exit_json')"

# Generated at 2022-06-23 08:20:52.237796
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    am = ActionModule()
    am.set_task('reboot')
    assert am.get_distribution(task_vars={"ansible_facts": {"distribution": "Debian"}}) == "Debian"
    assert am.get_distribution(task_vars={"ansible_facts": {"system": "FreeBSD"}}) == "FreeBSD"
    assert am.get_distribution(task_vars={"ansible_facts": {"system": "OpenBSD"}}) == "OpenBSD"
    assert am.get_distribution(task_vars={"ansible_facts": {"system": "Linux"}}) == "Linux"
    assert am.get_distribution(task_vars={"ansible_facts": {"system": "other"}}) == "DEFAULT"


# Generated at 2022-06-23 08:21:05.704449
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    action_module = Reboot()
    action_module._task = AnsibleTask()
    action_module._task.action = 'reboot'
    action_module._task.args = {'exclude_files': ['.*ignore_me']}
    action_module.DEFAULT_SUDOABLE = False
    action_module._loader = FakeLoader()
    action_module._templar = FakeTemplar()
    action_module._display = FakeDisplay()
    action_module._connection = FakeConnection()
    action_module._low_level_execute_command = FakeLowLevelExecuteCommand()
    action_module._play_context = FakePlayContext()
    action_module._play_context.update({'connection': 'smart', 'forks': 5, 'become': False, 'become_method': 'help'})
    action

# Generated at 2022-06-23 08:21:14.849234
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    import time
    import datetime
    
    module = get_test_object(ActionModule)
    display.vvv = mock.MagicMock()
    module._low_level_execute_command = mock.MagicMock(return_value={'rc': 0, 'stdout': 'Sun, 23 Sep 2018 00:08:17 -0400'})
    distribution = 'Darwin'

    boot_time = datetime.datetime(2018, 9, 23, 0, 8, 17, tzinfo=datetime.timezone.utc)
    assert module.get_system_boot_time(distribution) == boot_time



# Generated at 2022-06-23 08:21:19.498513
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    a = ActionModule(None, dict(), dict())
    try:
        a.do_until_success_or_timeout(action=a.check_boot_time, reboot_timeout=1, distribution={}, action_kwargs={'previous_boot_time': '1234'})
        assert False
    except TimedOutException:
        assert True



# Generated at 2022-06-23 08:21:22.305238
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    """Test run_test_command"""
    pass

# Generated at 2022-06-23 08:21:25.777883
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    display.display('Create a TimedOutException object')
    to_exception = TimedOutException()
    assert isinstance(to_exception, TimedOutException)



# Generated at 2022-06-23 08:21:27.025302
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()

# Generated at 2022-06-23 08:21:34.941148
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
  args, kwargs = (1,2), {'a':3, 'b':4}
  d = namedtuple('Distribution', ['name'])('Distribution1')
  reboot_result = {'failed': False, 'rebooted': False, 'start': datetime.datetime(2018, 1, 1, 0, 0)}
  expected = {'failed': True, 'rebooted': True,
              'msg': "Timed out waiting for last boot time check (timeout=1)"}
  result = ActionModule(1,2,3,4).validate_reboot(d, *args, **kwargs)
  assert(result == expected)


# Generated at 2022-06-23 08:21:47.286295
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    mod = ActionModule(
        task=dict(action=dict(reboot=dict(connect_timeout=None)))
    )
    mod._task.action = 'reboot'
    mod._task._ds = None
    mod._supports_check_mode = True
    mod._supports_async = True

    # A valid call
    mod._task.args = {
        'paths': ['usr/bin/', 'usr/local/bin/'],
        'reboot_timeout': 10
    }
    mod._connection = MagicMock()
    mod._low_level_execute_command = MagicMock()

# Generated at 2022-06-23 08:21:52.237617
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    def test_helper(mocker, task_vars, distribution, facts, facts_distribution):
        reboot_action_module = ActionModule(mocker.Mock(), mocker.Mock())

        result = reboot_action_module.get_distribution(task_vars)

        assert result == distribution

        with mocker.patch.object(ActionModule, 'get_distribution_facts', return_value=facts):
            result = reboot_action_module.get_distribution(task_vars)

            assert result == facts_distribution
    # Test cases

# Generated at 2022-06-23 08:21:53.790458
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    try:
        raise TimedOutException()
    except TimedOutException:
        pass



# Generated at 2022-06-23 08:22:03.426401
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    am = ActionModule({}, {})
    am.do_until_success_or_timeout(
        action=am.check_boot_time,
        action_desc="last boot time check",
        reboot_timeout=60,
        distribution='Ubuntu',
        action_kwargs={'previous_boot_time': 'Thu 2018-12-13 10:35'}) == {'changed': False, 'elapsed': 0, 'failed': False, 'rebooted': False, 'start': datetime.datetime(2018, 12, 13, 10, 35)}


# Generated at 2022-06-23 08:22:06.541280
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module = ActionModule(connect=None, disconnect=None, runner=None, task=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action_module.get_shutdown_command_args('redhat')
    assert result == "-r now"
    result = action_module.get_shutdown_command_args('debian')
    assert result == "-r now"


# Generated at 2022-06-23 08:22:16.981973
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Setup test setup
    module_args = {}
    set_module_args(module_args)

    # Setup test mocks
    path = os.path.join(os.path.dirname(__file__), 'test_data', 'ansible.cfg')
    test_vars = {'ansible_config_file': path}
    mock_AnsibleModule = MagicMock(return_value=AnsibleModule(
        argument_spec=dict()
    ))
    mock_AnsibleModule.params = module_args


# Generated at 2022-06-23 08:22:28.384045
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    AM = ActionModule()
    distribution = "linux"
    previous_boot_time = "2018-08-28T16:30:34.492969-05:00"
    
    # Fail case 1
    # Check the case where we get a successful return from system boot_time
    # but the returned value is empty
    command_result = {
        'rc': 0,
        'stdout': "",
        'stderr' : ""
    }

    with patch.object(AM, "_low_level_execute_command") as mock_execute:
        mock_execute.return_value = command_result
        with pytest.raises(ValueError) as e:
            AM.check_boot_time(distribution, previous_boot_time)
        assert e.value.args[0] == "boot time has not changed"

# Generated at 2022-06-23 08:22:40.888981
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Method that sets up the testing environment
    def _set_up(self):
        import ansible_collections.community.general.plugins.modules.system.reboot
        self.module = ansible_collections.community.general.plugins.modules.system.reboot.ActionModule(
            task=dict(action=dict(reboot=True)),
            connection=dict(transport='ssh'),
            play_context=dict(),
            loader=None,
            templar=None,
            shared_loader_obj=None
        )
        self.module._connection = MagicMock()
        self.module._connection.get_option.return_value = self.module.DEFAULT_CONNECT_TIMEOUT  # get_option('connection_timeout')
        self.test_system_distro = "test_system_distro"
       

# Generated at 2022-06-23 08:22:46.397105
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    task = {"name": "test"}
    task["args"] = {}
    low_level_execute_command_mock = mock.Mock()
    low_level_execute_command_mock.return_value = {'rc': 0, 'stdout': 'Mon 2016-04-11 05:33:42.00 UTC\n', 'stderr': ''}
    instance = ActionModule(task, mock.Mock(), connection_loader=mock.Mock(), play_context=mock.Mock(), loader=mock.Mock())
    instance._low_level_execute_command = low_level_execute_command_mock
    assert 'Mon 2016-04-11 05:33:42.00 UTC' == instance.get_system_boot_time("oracle")
    low_level_execute_command_mock.return_

# Generated at 2022-06-23 08:22:49.247754
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    module = module_factory()
    module._task.action = 'reboot'
    # _task.args contains the legacy argument 'reboot_timeout'
    module._task.args = {
        'reboot_timeout': 3600,
    }
    module.deprecated_args()
    # _task.args should no longer contain the legacy argument 'reboot_timeout'
    assert module._task.args == {}


# Generated at 2022-06-23 08:22:51.909073
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    result = True
    # Test patten: (args, exp_result)
    pattern_list = [
        ()
        ]

    for test_data in pattern_list:
        # Setup
        action_module = ActionModule()

        # Assertion
        result &= assert_equals(action_module.validate_reboot(*test_data[0]), test_data[1])

    return result


# Generated at 2022-06-23 08:22:57.441419
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action_module = ActionModule()
    param = 'reboot_timeout'
    value = '1.0'

    action_module._task.args[param] = value
    action_module.deprecated_args()

# Generated at 2022-06-23 08:23:02.842714
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    # Initialize test environment
    module = ActionModule()
    distribution = 'Red Hat'
    action_kwargs = {}
    original_connection_timeout = 22

    # Call method under test
    # pass

# Generated at 2022-06-23 08:23:13.137859
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    am = ActionModule(action=None, templar=None, shared_loader_obj=None, connection=None, play_context=None, loader=None, templar_available=False)

    # Run check_boot_time with no args
    # FIXME: should we check for no args?
    # FIXME: Should we raise exception if previous_boot_time arg is not a date string?
    if True:
        # attempt to get default distro value
        with patch("ansible.module_utils.facts.core.get_distribution", return_value='DEFAULT_VALUE'):
            am.check_boot_time('DEFAULT_VALUE', 'PREVIOUS_BOOT_TIME')

    # Run check_boot_time with test distro and mocked previous_boot_time of '2020-01-01 00:00:00'


# Generated at 2022-06-23 08:23:15.771053
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    e = TimedOutException('This is a test exception')
    assert str(e) == 'This is a test exception'



# Generated at 2022-06-23 08:23:26.905044
# Unit test for method deprecated_args of class ActionModule

# Generated at 2022-06-23 08:23:27.990257
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    e = TimedOutException('foo', 'bar')


# Generated at 2022-06-23 08:23:33.273597
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    am = ActionModule()
    test_result = am.get_system_boot_time('debian')
    assert test_result == "2014-10-06 13:15:23.027995+01:00"


# Generated at 2022-06-23 08:23:39.498045
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    # Arrange
    action_module = ActionModule(None, task=MockTask(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module._task.action = "reboot"

    # Act
    result = action_module.deprecated_args()

    # Assert
    # Not implemented yet
    pass

# Generated at 2022-06-23 08:23:42.097828
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module = ActionModule(load_fixture('pre_tasks.yml'), {})
    action_module.get_shutdown_command_args()



# Generated at 2022-06-23 08:23:52.129614
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import sys

    # First test valid instantiation
    test_task = AnsibleTask()

    action = ActionModule(task=test_task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    assert action._task == test_task
    assert action._play_context is None
    assert action._shared_loader_obj is None
    assert action._loader is None
    assert action._templar is None
    assert action._connection is None
    assert action._supports_async is True
    assert action._supports_check_mode is True
    assert type(action.get_distribution({'ansible_facts': {'distribution': 'Fedora'}})) is str

# Generated at 2022-06-23 08:23:55.911075
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    loader_extension_class = ActionModule()
    # get_distribution(task_vars)
    task_vars_dict = {}
    result = loader_extension_class.get_distribution(task_vars_dict)
    # assert statements

# Generated at 2022-06-23 08:24:07.574396
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    am = ActionModule()
    am.get_shutdown_command_args.__dict__['DEFAULT_SUDOABLE'] = True
    am.get_shutdown_command_args.__dict__['FEDORA_SHUTDOWN_ARGS'] = "--poweroff"
    am.get_shutdown_command_args.__dict__['REDHAT_SHUTDOWN_ARGS'] = "--poweroff"
    am.get_shutdown_command_args.__dict__['DEFAULT_SHUTDOWN_ARGS'] = "--poweroff"

    # test Fedora
    task_vars = {'ansible_facts': {'distribution': 'Fedora'}}
    assert am.get_shutdown_command_args(task_vars) == '--poweroff'

    # test RedHat
    task_

# Generated at 2022-06-23 08:24:17.772696
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    test_action_module = ActionModule()
    test_action_module.DEFAULT_SUDOABLE = True

    # make sure call to get_shutdown_command_args() fails with no distribution
    with pytest.raises(AnsibleError) as excinfo:
        test_action_module.get_shutdown_command_args(distribution=None)
    assert 'No distribution detected' in str(excinfo.value)

    # make sure call to get_shutdown_command_args() fails with an invalid distribution
    with pytest.raises(AnsibleError) as excinfo:
        test_action_module.get_shutdown_command_args(distribution='foobar')
    assert 'Invalid distribution' in str(excinfo.value)

    # make sure call to get_shutdown_command_args() with a valid

# Generated at 2022-06-23 08:24:21.039875
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module = ActionModule()
    assert action_module.get_distribution({}) == 'DEFAULT'


# Generated at 2022-06-23 08:24:32.744970
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    distribution = None
    task_vars = None
    shutdown_command = None
    shutdown_command_args = None
    reboot_command = None
    result = {}
    reboot_result = {}
    reboot_result['rc'] = 0
    result['start'] = datetime.utcnow()
    result['failed'] = False
    reboot_result['stdout'] = 'stdout'
    reboot_result['stderr'] = 'stderr'
    assert perform_reboot(distribution, task_vars, shutdown_command, shutdown_command_args, reboot_command, result, reboot_result) == ({'start': datetime.utcnow(), 'failed': False}, {'elapsed': 0, 'changed': True, 'rebooted': True, 'failed': False})

# Generated at 2022-06-23 08:24:46.744722
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class MyActionModule(Reboot):
        def get_distribution(self, task_vars):
            return 'DEFAULT'

    import datetime

    action_module = MyActionModule(dict(action='reboot'))
    ansible_facts = {}
    ansible_facts['DEFAULT_BOOT_TIME_COMMAND'] = ['date', '+%s']
    ansible_facts['DEFAULT_TEST_COMMAND'] = ['test', '-f', '/proc/1/cmdline']
    action_module.DEFAULT_SUDOABLE = True
    action_module._low_level_execute_command = lambda cmd, sudoable: {'rc': 0, 'stderr': '', 'stdout': str(int(datetime.datetime.now().timestamp()))}
    action_module._task

# Generated at 2022-06-23 08:24:56.608276
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # Setup
    module_name = 'setup'
    task_vars = fact_cache = {}

    # Mock class
    class MockClass(object):
        def get_binary_path(self, _module_name, _fact_cache, path_type, use_deprecated_lookup=False):
            return 'expected'

    # Patch class
    with mock.patch(
        'ansible.modules.system.reboot.ActionModule.get_binary_path',
        new_callable=mock.PropertyMock(return_value=MockClass().get_binary_path)
    ):
        # Execute function
        module = ActionModule(task_vars, module_name)
        module.get_binary_path
        distribution = module.get_distribution(fact_cache)

    # Assert

# Generated at 2022-06-23 08:25:04.913317
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    task_vars = {}

    action_module = ActionModule()

    action_module._task.args['reboot_timeout'] = 10
    action_module._task.args['reboot_timeout_sec'] = 20
    action_module._task.args['test_command'] = '/usr/bin/uptime'
    action_module._task.args['connect_timeout'] = 30
    action_module._task.args['connect_timeout_sec'] = 40

    action_module._task.action = 'reboot'

    # test success
    action_module._low_level_execute_command = lambda x: {'rc': 0, 'stdout': 'output', 'stderr': 'error'}

    result = action_module.perform_reboot(task_vars, 'Ubuntu')
    assert 'failed' not in result

# Generated at 2022-06-23 08:25:09.444209
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    am = ActionModule()
    result = am.get_system_boot_time('leftpad')
    assert result == 'leftpad'


# Generated at 2022-06-23 08:25:13.124161
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    # Create a new instance of ActionModule and check that 'DEFAULT_TEST_COMMAND' is returned
    test_action = ActionModule()
    assert test_action.DEFAULT_TEST_COMMAND == 'uptime'
    assert test_action.run_test_command('RedHat') == None


# Generated at 2022-06-23 08:25:14.201604
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    test = TimedOutException()



# Generated at 2022-06-23 08:25:24.659491
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    # Non-generic utility function to initialise a class
    class TestActionModule(ActionModule):
        def __init__(self):
            self._task = Mock()
            self._task.action = 'MOCK_REBOOT'
            self._task.args = {}
            self._connection = Mock()
            self._connection.transport = 'local'
            self._task.async_val = 15
            self._task.notify = ['test1', 'test2']
            self._low_level_execute_command = Mock()
            self.DEFAULT_REBOOT_TIMEOUT = 15
            self.DEFAULT_TEST_COMMAND = '/bin/true'
            self.DEFAULT_SUDOABLE = True
            self.DEFAULT_CONNECT_TIMEOUT = 15

# Generated at 2022-06-23 08:25:35.238780
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    import sys
    import pytest
    from mock import patch, Mock, MagicMock

    with patch.object(sys, 'argv', ["ansible-test", "units", __file__]):
        from ansible.module_utils.basic import AnsibleModule

        with pytest.raises(AnsibleError):
            model = AnsibleModule(
                argument_spec={
                    'shutdown_command': {'type': 'str', 'required': False}
                }
            )
            boot_time_command = "uptime"
            distribution = "CentOS"
            connected_obj = ActionModule(task=MagicMock())
            connected_obj.get_system_boot_time(boot_time_command, distribution)


# Generated at 2022-06-23 08:25:43.968110
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # get_distribution(self, task_vars)
    # Since the task_vars is not set, we expect the method to detect the distribution and return the default value
    # However, the method could fail because on some systems the fact 'ansible_distribution' is missing and the method
    # could not detect the distribution in that case
    a = ActionModule()
    try:
        res = a.get_distribution(task_vars={})
    except:
        res = 'Failed'
    assert res == 'DEFAULT'


# Generated at 2022-06-23 08:25:49.250662
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    action_module = ActionModule()
    # Handle a case, when during validation of reboot, check_boot_time method raises TimedOutException exception
    try:
        action_module.validate_reboot(distribution="ubuntu", original_connection_timeout=None, action_kwargs={'previous_boot_time': "Thu 2019-02-21 22:55:07 UTC"})
    except TimedOutException:
        return False
    return True
print(test_ActionModule_validate_reboot())


# Generated at 2022-06-23 08:26:01.260679
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.modules.system import reboot
    from ansible.plugins.loader import _get_all_plugin_loaders
    from ansible.utils.display import Display
    from ansible.errors import AnsibleError
    import os
    import pytest
    import mock
    import sys
    sys.path = ['', '/usr/lib/python2.7', '/usr/lib/python2.7/plat-x86_64-linux-gnu', '/usr/lib/python2.7/lib-tk', '/usr/lib/python2.7/lib-old', '/usr/lib/python2.7/lib-dynload', '/usr/local/lib/python2.7/dist-packages', '/usr/lib/python2.7/dist-packages']

# Generated at 2022-06-23 08:26:14.211790
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    def utcnow():
        return datetime(2017, 12, 25, 15, 0, 0)

    action_module = ActionModule()

    # Test when a reboot is not detected.
    class TestActionModule(ActionModule):
        def run_test_command(*args, **kwargs):
            assert False, "test_command should not be called in this case"

    am = TestActionModule()
    with pytest.raises(TimedOutException):
        with patch.object(ActionModule, 'utcnow', utcnow):
            am.validate_reboot(distribution='x', original_connection_timeout=None, action_kwargs={'previous_boot_time': '2017-12-25 15:00:00'})

    # Test when a reboot is detected.

# Generated at 2022-06-23 08:26:20.461789
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module = ActionModule()
    # Test with distribution=None
    assert 'now' in action_module.get_shutdown_command_args(None)
    # Test with distribution=Ubuntu
    assert 'now' in action_module.get_shutdown_command_args("Ubuntu")
    # Test with distribution=RedHat
    assert 'now' in action_module.get_shutdown_command_args("RedHat")
    # Test with distribution=Linux
    assert 'now' in action_module.get_shutdown_command_args("Linux")
    # Test with distribution=Linux and reboot_timeout
    assert 'now' in action_module.get_shutdown_command_args("Linux", reboot_timeout=3)
    # Test with distribution=Linux and reboot_timeout in seconds
    assert 'now' in action_module.get_

# Generated at 2022-06-23 08:26:27.814128
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    actionModule = ActionModule()
    task_vars = {'ansible_os_family': 'RedHat'}
    search_paths = ['/usr/local/sbin', '/usr/local/bin', '/sbin', '/bin', '/usr/sbin', '/usr/bin']
    result = actionModule.get_shutdown_command(task_vars, search_paths)
    assert result == '/sbin/shutdown'


# Generated at 2022-06-23 08:26:40.989377
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    from datetime import datetime, timedelta
    reboot_args = dict(
        connect_timeout='',
        test_command='',
        post_reboot_delay='',
        reboot_timeout=''
    )

# Generated at 2022-06-23 08:26:49.697240
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    host = 'localhost'
    port = 22
    user = 'root'
    password = 'password'
    private_key_file = '~/.ssh/id_rsa'
    connection = Connection(host, port, user, password, private_key_file)
    action = 'reboot'
    play_context = PlayContext()
    task = Task()
    task.action = action
    task.async_val = 43
    task.notify = ['foo']
    task.tags = ['bar']
    task.args = {'reboot_timeout': 300}
    task.deprecate_warnings = True
    task_vars = {'ansible_ssh_pass': 'passwd'}
    loader = DataLoader()

    action_module = ActionModule(task, connection, play_context, loader)

    result

# Generated at 2022-06-23 08:26:59.484351
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    #
    # Check no distribution exceptions on a successful reboot
    #
    display_mock = MagicMock()
    connection_mock = MagicMock()
    connection_mock.get_option = MagicMock(return_value = None)
    connection_mock.run = MagicMock()
    class TestModule():
        def __init__(self):
            self.TEST_COMMANDS = { 'DEFAULT': 'echo "test command success"' }
            self.BOOT_TIME_COMMANDS = { 'DEFAULT': 'echo "Thu 2020-08-20 00:00:00"', 'RedHat': 'echo "Thu 2020-08-20 00:00:00"'}

# Generated at 2022-06-23 08:27:08.567023
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    """
    Test actionmodule.ActionModule.get_system_boot_time()
    """

    from ansible.module_utils.basic import AnsibleModule
    import ansible.plugins.action.reboot as actionreboot
    # Create a fake AnsibleModule
    module = AnsibleModule(
        argument_spec={
            'boot_time_command': dict(type='str', default='who -b'),
            'test_command': dict(type='str', default=''),
        },
        supports_check_mode=True
    )
    # Create a fake connection
    connection = Connection()
    # Create a fake task

# Generated at 2022-06-23 08:27:10.498152
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    try:
        raise TimedOutException()
    except TimedOutException:
        pass



# Generated at 2022-06-23 08:27:14.158772
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    AM_instance=ActionModule()
    distribution="ABC"
    result=AM_instance.get_shutdown_command_args(distribution)
    assert isinstance(result,str)


# Generated at 2022-06-23 08:27:17.816405
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    task_vars = {}
    object = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    distribution = None
    result = object.perform_reboot(task_vars, distribution)
    assert result.get('start') is not None

    try:
        result.get("failed")
    except AttributeError:
        pass
    else:
        assert False, "Should have raise AttributeError"


# Generated at 2022-06-23 08:27:27.851352
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    # Setup
    action_module = ActionModule('reboot')
    action_module._task.action = 'reboot'
    action_module._task.args['reboot_timeout_sec'] = '300'
    action_module._task.args['test_command'] = 'ls'
    action_module.DEFAULT_TEST_COMMAND = 'ls'
    action_module.DEFAULT_REBOOT_TIMEOUT = 300
    # Action
    result = action_module.validate_reboot('test_value')
    # Assertion
    assert result['changed'] is True
    assert result['failed'] is False

# Generated at 2022-06-23 08:27:32.402225
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    task = {'action': 'test_action', 'args': {}}
    module = ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module.get_shutdown_command(task_vars=None, distribution=None) == 'shutdown'


# Generated at 2022-06-23 08:27:37.567639
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    task_args = dict()
    for arg, version in DEPRECATED_ARGS.items():
        task_args[arg] = True
    am = ActionModule(task=None, connection=None, _play_context=None, loader=None, templar=None, shared_loader_obj=None)
    am.display = Display()
    am._task.args = task_args
    am.deprecated_args()


# Generated at 2022-06-23 08:27:49.940000
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # Create a mock connection object with a get_distribution method returning the value of _distro_name
    class _MockConnection:
        def get_distribution(self):
            return 'system'
    # Create a mock ansible task object with a connection attribute - set to the mock object created above
    class _MockTask:
        connection = _MockConnection()
    # Create a mock ansible module object
    class _MockModule:
        @staticmethod
        def fail_json(*args, **kwargs):
            raise AnsibleError("Unexpected call to fail_json")

    # Create a mock ansible play context object
    class _MockPlayContext:
        def __init__(self):
            self.remote_addr = 'remote_addr'
            self.connection = 'connection'
            self.port = 80

# Generated at 2022-06-23 08:27:53.904021
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    try:
        raise TimedOutException('Timeout')
    except TimedOutException as e:
        assert e.message == 'Timeout'


# Generated at 2022-06-23 08:28:03.712146
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    host = 'some_remote_host'
    connection = MagicMock()
    play_context = MagicMock()
    loader = MagicMock()
    connection_loader = MagicMock()
    templar = MagicMock()
    task = MagicMock()

    connection.transport = 'local'
    play_context.check_mode = False

    am = ActionModule(
        connection=connection,
        play_context=play_context,
        loader=loader,
        templar=templar,
        shared_loader_obj=None
    )
    am._task = task
    am._connection = connection
    am._low_level_execute_command = MagicMock(return_value={'rc': 0})

    # If running with local connection, fail so we don't reboot ourself
    result = am.run

# Generated at 2022-06-23 08:28:06.382137
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    try:
        raise TimedOutException('test')
    except TimedOutException as ex:
        assert to_text(ex) == 'test'



# Generated at 2022-06-23 08:28:08.739845
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    try:
        raise TimedOutException('timeout')
    except TimedOutException as e:
        assert e.args[0] == 'timeout'



# Generated at 2022-06-23 08:28:15.109192
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.deprecations = []

    class MockTask(object):
        def __init__(self):
            self.args = {}
            self.action = 'reboot'

    class MockContext(object):
        def __init__(self):
            self.connection = 'test'

    class MockDistro(object):
        def __init__(self):
            self.name = 'test_distro'
            self.family = 'test_family'

    action_module = ActionModule(MockTask(), MockContext())
    action_module.DEFAULT_TEST_COMMAND = 'test_command'
    action_module._task = MockTask()
    action_module._connection = MockConnection()

    action_module.T

# Generated at 2022-06-23 08:28:19.487259
# Unit test for constructor of class ActionModule
def test_ActionModule():
    play_context = PlayContext()
    action_vars = dict(ansible_verbosity=4, ansible_playbook_python="/usr/bin/python", ansible_connection="local")
    task_vars = dict(ansible_architecture="x86_64", ansible_connection="local", ansible_distribution="Ubuntu", ansible_python_interpreter="/usr/bin/python")
    args = dict()
    ActionModule(inner_task=Task(), action_vars=action_vars, task_vars=task_vars, args=args, play_context=play_context)

# Generated at 2022-06-23 08:28:30.467623
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    module = AnsibleModule()
    module.params = {
        'patterns': ['foo'],
        'file_type': 'file',
        'paths': ['file1', 'file2'],
        'recurse': False,
    }
    module._ansible_debug = True
    module._ansible_verbosity = 2
    module._ansible_version = '2.10.2'
    module._ansible_no_log = True
    os.environ['ANSIBLE_REMOTE_TEMP'] = '/tmp'
    os.environ['ANSIBLE_KEEP_REMOTE_FILES'] = '0'
    am = ActionModule(module)

# Generated at 2022-06-23 08:28:39.045073
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    print("hello")
    in_mock_manager, in_mock_loader, in_mock_variable_manager, in_mock_options = MagicMock(), MagicMock(), MagicMock(), MagicMock()
    # Create mock module object
    in_mock_module = MagicMock(name='MockModule')
    # Create mock task object
    in_mock_task = MagicMock(name='MockTask')
    # Create mock task object - get_action
    in_mock_task.action = "Reboot"
    # Create mock task object - args
    in_mock_task.args = dict()
    # Create mock task object - set_type_error_results
    in_mock_task.set_type_error_results = MagicMock()
    # Create mock task object - action
