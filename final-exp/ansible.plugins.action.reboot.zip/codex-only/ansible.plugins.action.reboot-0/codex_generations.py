

# Generated at 2022-06-23 08:18:48.390737
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.connection import Connection
    from ansible.plugins.loader import action_loader

    # Define 'options' object

# Generated at 2022-06-23 08:18:52.935471
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    ActionModule().deprecated_args()

# Generated at 2022-06-23 08:18:54.547216
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    x = TimedOutException()
    assert x.args == ()



# Generated at 2022-06-23 08:18:58.647183
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    import pytest
    # action_mock1 = ActionModule(None, None, None, None, None)
    # assert action_mock1.check_boot_time('distribution', 'previous_boot_time') == True



# Generated at 2022-06-23 08:19:06.950423
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    task_args = dict()

    connection = dict(
        conn_type='network_cli',
        host='172.20.10.7',
        port=22,
        networkos='iosxr',
        username='ansible',
        password='Router123',
        timeout=60
    )

    testobj = ActionModule(task_args, connection)
    distribution = testobj.get_distribution({})
    out = testobj.get_system_boot_time(distribution)
    assert out != None

# Generated at 2022-06-23 08:19:08.683870
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(dict(ANSIBLE_MODULE_ARGS={}))
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-23 08:19:14.762861
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    # Setup
    distr = 'Ubuntu'
    action_mod = ActionModule()

    # Execute
    shutdown_command_args = action_mod.get_shutdown_command_args(distr)

    # Asserts
    assert shutdown_command_args == '-t 60 -r now'

# Generated at 2022-06-23 08:19:17.262628
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    e = TimedOutException('foo')
    assert e.strerror == 'foo'
    assert to_native(e) == 'foo'



# Generated at 2022-06-23 08:19:22.830907
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    data = mock_get_connection_data()
    action_module = ActionModule(data)
    action_module.task_vars = {}
    action_module.task_vars['ansible_facts'] = {}
    action_module.task_vars['ansible_facts']['ansible_distribution'] = 'Debian'
    action_module.task_vars['ansible_facts']['ansible_distribution_version'] = '8'
    action_module.task_vars['ansible_facts']['ansible_distribution_release'] = 'jessie'
    action_module.task_vars['ansible_facts']['ansible_distribution_major_version'] = '8'

# Generated at 2022-06-23 08:19:29.771248
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Arrange
    # Create mock object and set needed attributes
    module_args = {'reboot_timeout': 300}
    set_module_args(module_args)
    mock_task = Mock()
    mock_task.action = 'reboot'
    mock_task.args = module_args
    fake_channel = Mock()
    fake_channel.recv_exit_status.return_value = 0
    fake_channel.recv.return_value = b''
    fake_channel.recv_stderr.return_value = b''
    connection = Mock()
    connection.exec_command.return_value = (0, fake_channel, None, None)
    connection.set_host_overrides.return_value = None
    connection.set_options = Mock()
    connection.set_options.return_value

# Generated at 2022-06-23 08:19:37.741809
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    module = ActionModule(mock.MagicMock(), mock.MagicMock(), connection_info=mock.MagicMock(), loader=None, options=mock.MagicMock(), passwords=mock.MagicMock())
    assert module.get_distribution(None) == 'DEFAULT'
    assert module.get_distribution({'ansible_facts': {'distribution': 'CentOS'}}) == 'CentOS'
    assert module.get_distribution({'ansible_facts': {'os_family': 'RedHat'}}) == 'RedHat'


# Generated at 2022-06-23 08:19:49.195808
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():

    module = ActionModule()

    assert module.get_shutdown_command_args('centos') == '-r now'
    assert module.get_shutdown_command_args('debian') == '-r now'
    assert module.get_shutdown_command_args('ubuntu') == '-r now'
    assert module.get_shutdown_command_args('redhat') == '-r now'
    assert module.get_shutdown_command_args('scientific') == '-r now'
    assert module.get_shutdown_command_args('fedora') == '-r now'
    assert module.get_shutdown_command_args('amazon') == '-r now'
    assert module.get_shutdown_command_args('opensuse') == '-r now'
    assert module.get_shutdown_command_args

# Generated at 2022-06-23 08:19:50.793733
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    exception = TimedOutException()
    exception.message = "This is a TimedOutException"



# Generated at 2022-06-23 08:19:54.735093
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_obj_run = ActionModule()
    test_obj_run.run()


# Generated at 2022-06-23 08:20:05.150141
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    from ansible_collections.community.general.tests.unit.compat import unittest
    from ansible_collections.community.general.plugins.modules.remote_management.os import ActionModule
    from ansible_collections.community.general.plugins.loader import action_loader

    # Load action plugin
    action_cls = action_loader.get('os_reboot', class_only=True)
    actionobj = action_cls(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)


# Generated at 2022-06-23 08:20:08.762032
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    # arrange
    action_module = ActionModule(dict(param='val', connection='ssh'), dict())
    dist = 'rhel'
    action_kwargs=dict()
    # act
    result = action_module.run_test_command(dist, action_kwargs)
    # assert
    assert result is None

# Generated at 2022-06-23 08:20:11.490004
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    exc = TimedOutException("test_TimedOutException")
    with pytest.raises(Exception):
        raise exc

# Unit  test for constructor of class TimedOutException

# Generated at 2022-06-23 08:20:12.841706
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action = ActionModule()
    action.deprecated_args()

# Generated at 2022-06-23 08:20:15.083780
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    am = ActionModule(MagicMock())

    assert am.check_boot_time(distribution=None, previous_boot_time=None) is None

# Generated at 2022-06-23 08:20:16.252710
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
  pass

# Generated at 2022-06-23 08:20:18.327992
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    exception = TimedOutException('msg')
    assert 'msg' == exception.message



# Generated at 2022-06-23 08:20:22.507245
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_instance = ActionModule()
    assert test_instance.run() == 1

# Generated at 2022-06-23 08:20:31.362286
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # test with no exception thrown
    action.do_until_success_or_timeout(action=lambda: None, action_desc='test_action',
                                       reboot_timeout=10, distribution='test_distribution')
    # test with exception thrown
    with pytest.raises(Exception):
        action.do_until_success_or_timeout(action=lambda: None, action_desc=None,
                                           reboot_timeout=1, distribution='test_distribution')

# Generated at 2022-06-23 08:20:44.914951
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    # Create instance of class ActionModule
    action_module = ActionModule(
        task=Return_task(args={'reboot_timeout': 600}),
        connection=Return_connection(transport='ssh'),
        play_context=Return_play_context(check_mode=False),
        loader=False,
        templar=False,
        shared_loader_obj=False
    )

    # assign the return invocations to their related method or function
    # assign the return invocations of get_system_boot_time to mock_get_system_boot_time
    action_module.get_system_boot_time = mock_get_system_boot_time
    # assign the return invocations of run_test_command to mock_run_test_command
    action_module.run_test_command = mock_run_test_command
   

# Generated at 2022-06-23 08:20:53.109850
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # Create an instance of ActionModule class
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # Execute method do_until_success_or_timeout with appropriate arguments
    try:
        assert_equals(EXECUTE_FUNCTION, action_module.do_until_success_or_timeout(action=EXECUTE_FUNCTION, action_desc="UNIT TESTING", reboot_timeout=0, distribution="DEFAULT", action_kwargs={'previous_boot_time':"UNIT TESTING"}))
    except ValueError:
        assert True
    else:
        assert False


# Generated at 2022-06-23 08:21:01.197185
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # Fixture
    class ActionModule:
        def __init__(self, display, connection):
            self.display = display
            self.connection = connection
    action_module = ActionModule(mock.Mock(), mock.Mock())
    mocked_facts = {
        'DEFAULT_BOOT_TIME_COMMAND': 'cat /proc/uptime',
        'BOOT_TIME_COMMANDS': {
            'RedHat': 'cat /proc/uptime',
            'SUSE': 'cat /proc/uptime'
        }
    }

    class Facts:
        def __init__(self):
            pass
        def get_distribution(self):
            return 'RedHat'


# Generated at 2022-06-23 08:21:13.232827
# Unit test for constructor of class ActionModule
def test_ActionModule():
    def test(expected, data):
        am = ActionModule(data)
        assert am.__dict__ == expected, "Expected %s, got %s" % (expected, am.__dict__)

    # Notify

# Generated at 2022-06-23 08:21:18.935071
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    fd, module_path = tempfile.mkstemp()
    action_module = ActionModule(task=Task(), connection=Connection(), play_context=PlayContext(), loader=None, templar=None, shared_loader_obj=None)

    os.close(fd)
    task_vars = dict(ansible_ssh_user='test_user', ansible_ssh_host='host.example.org')
    shutil.rmtree(module_path)
    test_data = dict(ansible_facts=dict(system='CentOS'), ansible_pkg_mgr='dnf')
    test_data_module_setup = dict(ansible_facts=dict(system='CentOS', ansible_pkg_mgr='dnf'))

# Generated at 2022-06-23 08:21:28.792201
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert a is not None
    new_task = Task()
    new_task.args = DictObj()
    a = ActionModule(task=new_task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert a is not None

# Test a simple real system. Reboot the localhost using a local connection

# Generated at 2022-06-23 08:21:30.385332
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    # mock class, not a real unit test
    pass

# Generated at 2022-06-23 08:21:37.241837
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action_module = ActionModule()
    action_module._supports_check_mode = True
    action_module._supports_async = True
    action_module._task = ansible_module_mock
    action_module.deprecated_args()


# Generated at 2022-06-23 08:21:48.789148
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("test_ActionModule_run")

    # mock the module
    m = type('', (), {"_task": "a", "_play_context": "b", "_connection": "c", "run": ActionModule.run})()

    # mock the runner class
    class TestRunner:
        def __init__(self, action_module):
            self._action_module = action_module
            self.run = TestRunner.run
    def TestRunner_run(self, task_vars=None):
        if task_vars is None:
            task_vars = {}
        return self._action_module.run(None, task_vars)

    TestRunner.run = TestRunner_run

    # mock the run method
    ActionModule.run = mock.MagicMock(return_value={'changed': False})

# Generated at 2022-06-23 08:21:51.556642
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    fail_count = 0
    max_fail_sleep = 12
    random_int = random.randint(0, 1000) / 1000
    fail_sleep = 2 ** fail_count + random_int
    print(fail_sleep)
    print(max_fail_sleep)

if __name__ == '__main__':
    test_ActionModule_run_test_command()

# Generated at 2022-06-23 08:21:58.876576
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    hostname = 'test_host'
    port = 22
    username = 'test_username'
    password = 'test_password'

    result = {}
    task_args = {}
    task_action = 'test_task_action'

    # Create connection plugin for testing
    mock_plugin = ansible.plugins.connection.network_cli.Connection(play_context=None, new_stdin=None)
    mock_plugin._connection = connection_loader.get('ssh', play_context=None, new_stdin=None, **{'host': hostname, 'port': port})
    mock_plugin._play_context = Mock(spec=PlayContext)
    mock_plugin._play_context.connection = 'network_cli'
    mock_plugin._play_context.remote_addr = hostname

# Generated at 2022-06-23 08:22:10.002972
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    test_host = MockConnection()
    test_host.distribution = {'name': 'test', 'version': '1.0'}
    test_result = {
        'ansible_facts': {
            'distribution': test_host.distribution
        }
    }
    test_task_vars = {}
    test_task = ActionModule._create_task_object(
        {'action': 'reboot'},
        task_vars=test_task_vars
    )

    # Case 1: return distribution from ansible_facts
    test_task_vars = test_result

# Generated at 2022-06-23 08:22:22.082512
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # The method `do_until_success_or_timeout` takes a keyword argument `action_kwargs`
    # which itself takes a keyword argument `previous_boot_time`

    # Create a mock of the class, with mocked methods.
    mock_action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    mock_action.get_system_boot_time = MagicMock(return_value='foo')
    mock_action._execute_module = MagicMock(return_value={'rc': 0, 'stdout': 'boot time', 'stderr': ''})

# Generated at 2022-06-23 08:22:26.541806
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    print('Unit test for method deprecated_args of class ActionModule')

    obj = ActionModule()

    # check if DEPRECATED_ARGS is valid dict
    assert isinstance(obj.DEPRECATED_ARGS, dict)

# Generated at 2022-06-23 08:22:32.805713
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    """
    # python test_action.py ActionModule
    """
    am = ActionModule('a', 'b', {})
    am.get_system_boot_time = lambda *args: 'a'
    with patch('action.ActionModule', autospec=True) as mock:
        mock.return_value = am
        am.check_boot_time('a', 'b')
        mock.assert_called_with()
        

# Generated at 2022-06-23 08:22:40.719277
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    my_obj = ActionModule(
        task=dict(action=dict(reboot=dict())),
        connection=dict(),
        play_context=dict(),
        loader=dict(),
        templar=dict(),
        shared_loader_obj=dict()
    )
    task_vars = dict()
    distribution = dict()
    result = my_obj.get_shutdown_command(task_vars, distribution)
    assert result is not None

# Generated at 2022-06-23 08:22:47.108331
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():

    #target_object = ActionModule(task, connection, play_context, loader, templar, shared_loader_obj)
    target_object = ActionModule(None, None, None, None, None, None)
    method = getattr(target_object, 'get_shutdown_command_args')
    distribution = 'Debian'
    args = method(distribution=distribution)
    assert args == '-r now'



# Generated at 2022-06-23 08:22:59.504187
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # create instance of the ActionModule class with fake task, play context and connection
    action_mod = ActionModule(task=task, play_context=play_context, connection='local')
    # Mock a shutdown command for unit testing purposes
    action_mod.SHUTDOWN_COMMANDS = {
        'RedHat': '/sbin/shutdown',
        'DEFAULT': '/sbin/shutdown'
    }
    action_mod.SHUTDOWN_COMMAND_ARGS = {
        'RedHat': '-r 1',
        'DEFAULT': '-r now'
    }
    action_mod.post_reboot_delay = 0
    # Create a fake result dict to test if reboot was successfully initiated

# Generated at 2022-06-23 08:23:11.962654
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    """
    This is a unittest to test the above method of class ```ActionModule```
    """
    def raise_exception(distribution, **kwargs):
        msg = 'this is exception'
        raise Exception(msg)

    def raise_value_error(distribution, **kwargs):
        raise ValueError('fructose')

    def raise_runtime_error(distribution, **kwargs):
        raise RuntimeError('bananas')

    def return_none(distribution, **kwargs):
        return None

    def test_runner(action, actions, reboot_timeout, distribution, action_kwargs, expected_error):
        try:
            action_module = ActionModule()
            actions(distribution, **action_kwargs)

        except TimedOutException as e:
            assert e.args[0] == expected_

# Generated at 2022-06-23 08:23:24.125327
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule(
        task=dict(
            action='reboot',
            version_added='1.0',
            args=dict(
                use_reboot=True,
                pre_reboot_delay=5,
                reboot_timeout=300,
                test_command='uptime'
            )
        )
    )

    # test system with supported use_reboot
    module.get_distribution = MagicMock(return_value='Ubuntu')
    module._get_facts = MagicMock(return_value=dict(system='Linux'))
    module._low_level_execute_command = MagicMock(return_value=dict(rc=0, stdout='', stderr=''))
    module._connection.set_option = MagicMock(return_value=None)
    module._connection.get_

# Generated at 2022-06-23 08:23:36.676215
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    test_parm = {"paths": "/bin",
                 "patterns": "shutdown",
                 "file_type": "any"}
    test_distribution = ""
    check_type_str = ""
    try:
        t_ActionModule = ActionModule()
    except Exception as e:
        print("ActionModule create object error, the error is %s" % (e))
        return
    try:
        action_module_result = t_ActionModule.run_test_command(test_distribution, test_parm)
    except Exception as e:
        print("ActionModule run_test_command error, the error is %s" % (e))
        return
    else:
        print("ActionModule run_test_command check passed")

# Generated at 2022-06-23 08:23:42.297765
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    action_module = ActionModule()
    try:
        action_module.do_until_success_or_timeout(lambda x: x, 1, "test", 0, action_kwargs={'previous_boot_time': 1234})
        assert False
    except ValueError:
        assert True
    except Exception:
        assert False


# Generated at 2022-06-23 08:23:46.927940
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    module = ActionModule(None, None, None)

    # test shutdown command
    assert module.do_until_success_or_timeout(action=None,
        action_desc=None,
        reboot_timeout=None,
        distribution=None,
        action_kwargs=None) is None
    return

# Generated at 2022-06-23 08:23:58.876167
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
  apb = AnsibleActionModuleReboot()
  hostvars = {
            "ansible_host": "test_host",
            "ansible_connection": "network_cli"
        }
  self._connection.set_host_overrides(hostvars)
  self._connection.set_options(direct={'persistent_command_timeout': 10, 'connect_timeout': 20, 'timeout': 10})
  task_vars = {
        "ansible_host": "test_host",
        "ansible_connection": "network_cli"
    }
  distribution = 'CentOS'
  # case 1
  test_apt_and_yum_update = True
  # case 2
  test_apt_and_yum_update = False
  if test_apt_and_yum_update:
    out

# Generated at 2022-06-23 08:24:09.206755
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    # Given a mocked task, ActionModule with one supported deprecated arg and
    # one deprecated arg that is not supported, when calling deprecated_args,
    # then a single warning should be displayed
    task = Mock()
    new_module = ActionModule(task)
    new_module.DEPRECATED_ARGS = {'key1': 'version1', 'key2': None}
    task.args = {'key1': 'value1', 'key2': 'value2'}
    task.action = 'action1'
    display = Mock()
    display.warning = Mock()

    new_module.deprecated_args(display=display)

# Generated at 2022-06-23 08:24:14.553640
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    task_vars = dict()
    shutdown_bin = None

    # test default with no distribution
    assert module.get_shutdown_command(task_vars, None) == '/sbin/shutdown'

    # test distribution not in facts
    task_vars = dict()
    task_vars['ansible_distribution'] = 'RedHat'
    assert module.get_shutdown_command(task_vars, 'RedHat') == '/sbin/shutdown'

    # test distribution in facts but command not in facts
    task_vars = dict()
    task_vars['ansible_distribution'] = 'RedHat'

# Generated at 2022-06-23 08:24:18.520472
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action_module = ActionModule(task=Mock(), connection=Mock(), play_context=Mock(), loader=Mock(), templar=Mock(), shared_loader_obj=Mock())
    assert action_module.deprecated_args() == None

# Generated at 2022-06-23 08:24:31.414079
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():

    # get a reference to ActionModule
    ActionModule = actions.get('reboot')
    # get a reference to BaseAction
    BaseAction = action.BaseAction()
    # get a reference to the Display class
    Display = display.Display()

    # get a reference to PlayContext class
    PlayContext = play_context.PlayContext()
    '''
    # create a new instance of PlayContext
    play_context = PlayContext()
    play_context.checks = False
    play_context.network_os = 'linux'
    play_context.remote_addr = 'localhost'
    play_context.remote_user = 'test_user'
    '''

    # create a new instance of BaseAction
    base_action = BaseAction()

    # create a new instance of Display
    display_ = Display()

    # create a new instance of

# Generated at 2022-06-23 08:24:45.407958
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    t = DummyTask()
    p = DummyPlay()
    t._play = p
    m = DummyModule()
    s = DummyConnection()
    s._shell.return_value = (0, 'ok', 'ok')
    connection = ActionModule.ActionModule(task=t, connection=s, play_context=m, loader=m, templar=m, shared_loader_obj=m)
    connection._task.args = {}
    m.display.warning.called = False
    m.display.warning.assert_not_called()
    connection.deprecated_args()
    m.display.warning.assert_not_called()
    connection._task.args = {'reboot_timeout': '10', 'test_command': 'uptime'}
    connection.deprecated_args()

# Generated at 2022-06-23 08:24:48.064646
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action_module = ActionModule()
    # Test with no argument
    assert action_module.deprecated_args() is None



# Generated at 2022-06-23 08:24:51.022550
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():

    a = ActionModule()
    a.get_system_boot_time()

# Generated at 2022-06-23 08:24:52.772103
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_action_module = ActionModule()
    test_action_module.run()

# Generated at 2022-06-23 08:25:02.291075
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    hostvars = {'is_FooOS': True, 'ansible_distribution': 'FooOS'}
    am = ActionModule(None, {})
    distribution = am.get_distribution(hostvars)
    assert distribution == 'FooOS'

    hostvars = {'is_FooOS': False, 'ansible_distribution': 'FooOS'}
    am = ActionModule(None, {})
    distribution = am.get_distribution(hostvars)
    assert distribution == 'FooOS'

    hostvars = {'is_FooOS': False, 'ansible_distribution': 'FooOS'}
    am = ActionModule(None, {})
    distribution = am.get_distribution(hostvars)
    assert distribution == 'FooOS'

    hostvars

# Generated at 2022-06-23 08:25:08.789258
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action = ActionModule(load_fixture('action_module.yml'), {}, {}, {})
    assert(action.get_distribution({'ansible_facts': {'distribution': 'CentOS', 'distribution_major_version': '7'}}) == 'CentOS')


# Generated at 2022-06-23 08:25:14.505563
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    host_vars = dict()
    # case where no distribution is found in host vars
    am = ActionModule(
        task=MockTask(), connection=MockConnection(), loader=MockLoader())
    assert am.get_distribution(host_vars) == 'DEFAULT'
    # case where distribution is found in host vars
    host_vars = dict(ansible_facts=dict(distribution='rhel'))
    assert am.get_distribution(host_vars) == 'rhel'


# Generated at 2022-06-23 08:25:24.819593
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Establish an instance of the action module
    action = ActionModule()
    # Establish an instance of the play context
    class play_context(object):
        check_mode = True
    context = play_context()
    # Establish an instance of the task
    class task(object):
        action = 'reboot'
        args = {'reboot_timeout': 0}
    task_obj = task()
    # Update the instance of the action module with the play context and the task
    action._play_context = context
    action._task = task_obj
    # Establish an instance of the task variables
    class task_vars(object):
        ansible_facts = {'REBOOT_MANAGER': 'ansible'}
    task_vars_obj = task_vars()
    # Establish return values for the

# Generated at 2022-06-23 08:25:35.390457
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    task_vars = {'ansible_facts': {'distribution': 'CentOS',
                                   'distribution_major_version': '7'}}
    action_module = ActionModule(dict(), task_vars=task_vars)
    
    result = {}
    distribution = 'CentOS'

    reboot_result = action_module.perform_reboot(task_vars, distribution)
    
    result['start'] = datetime.utcnow()

    if reboot_result['rc'] != 0:
        result['failed'] = True
        result['rebooted'] = False

# Generated at 2022-06-23 08:25:40.615238
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    # set up mock arguments
    distribution = mock.MagicMock()
    # instantiate ActionModule class instance
    am = ActionModule()
    # call method
    am.get_system_boot_time(distribution)


# Generated at 2022-06-23 08:25:48.578843
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    ActionModule._connection = None
    ActionModule._play_context = None

    task_vars = {}
    reboot_result = ActionModule.perform_reboot(self=ActionModule, task_vars=None, distribution=None)

    #
    # do not compare 'start' element of results as it is a datetime object and
    # time will differ
    #
    # so remove 'start' from results before comparing
    #
    start = reboot_result['start']
    del reboot_result['start']

    assert reboot_result == {'rebooted': False, 'failed': True, 'msg': 'Reboot command failed. Error was: \'\', \'\'', 'start': start}



# Generated at 2022-06-23 08:25:54.028947
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    test_ActionModule = ActionModule(mock.MagicMock(), mock.MagicMock())
    test_ActionModule.run_test_command('platform', distro='platform')


# Generated at 2022-06-23 08:26:04.903087
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    action_module = ActionModule()
    with patch('ansible.module_utils._text.to_text') as to_text_mock:
        with patch.dict('ansible.utils.plugin_docs.ANSIBLE_METADATA', {'status': [], 'supported_by': 'community'}):
            action_module._task = Mock()
            action_module._connection = Mock()
            with patch.object(action_module, '_low_level_execute_command') as _low_level_execute_command_mock:
                _low_level_execute_command_mock.return_value = {
                    'rc':0,
                    'stdout':'1578803380',
                    'stderr':''
                }
                action_module._task.action = 'ansible_get_system_boot_time'

# Generated at 2022-06-23 08:26:13.345145
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    class Task(object):
        def __init__(self):
            self.args = dict()
            self.action = 'reboot'

    my_action = ActionModule(Task())

    # Test no argument
    my_action._task.args = {}
    my_action.deprecated_args()

    # Test deprecated argument
    my_action._task.args = dict()
    my_action._task.args['pre_reboot_delay'] = '60'
    my_action.deprecated_args()


# Generated at 2022-06-23 08:26:22.291046
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # Creation of a mock object, called am_mock (short for ActionModule mock).
    am_mock = mock.MagicMock(name='ActionModule mock')
    # Creation of a mock object, called am_patcher (short for ActionModule patcher).
    am_patcher = unittest.mock.patch('ansible_collections.ansible.community.plugins.modules.reboot.ActionModule')
    # Using the patcher, we are replacing all instances of the ActionModule class in this module with our am_mock.
    am_mock_patch = am_patcher.start()
    # Replacing the real class with our mock.
    am_mock_patch.return_value = am_mock
    # Replacing the methods we are using from the class with our own methods.
    am_mock_patch.do

# Generated at 2022-06-23 08:26:23.478944
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    pass


# Generated at 2022-06-23 08:26:32.666817
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    distribution = "openSUSE-42.3"

    # Arrange
    am = ActionModule(None)
    am.DEFAULT_SUDOABLE = True
    am.DEFAULT_POST_REBOOT_DELAY = 1
    am.BOOT_TIME_COMMANDS = {
        "Fedora": "last reboot | head -n1",
        "openSUSE-42.3": "last reboot | head -n1"
    }
    am.REBOOT_TIMEOUT_SEC = 5
    am.TEST_COMMANDS = {
        "Fedora": "test -f /var/crash/reboot_test",
        "openSUSE-42.3": "test -f /var/crash/reboot_test"
    }

# Generated at 2022-06-23 08:26:35.185908
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    try:
        raise TimedOutException()
    except TimedOutException:
        pass



# Generated at 2022-06-23 08:26:45.850422
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    args = {'boot_time_command' : 'uptime',
            'reboot_timeout' : 0,
            'reboot_timeout_sec' : 0,
            'post_reboot_delay' : 0,
            'connect_timeout' : 0,
            'connect_timeout_sec' : 0,
            'test_command' : '/bin/true',
            'shutdown_timeout' : 0,
            'shutdown_timeout_sec' : 0,
            'msg' : '',
            'reboot_timeout' : 0,
            'rebooted' : False}
    x = ActionModule(None, args, None)
    x.TEST_COMMANDS = {'RedHat': 'uptime',
                       'Darwin': 'uptime',
                       'FreeBSD': 'uptime'}

# Generated at 2022-06-23 08:26:53.127980
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    test_obj = ActionModule(task=FakeTask(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    test_args = {'distribution': 'Linux'}
    return_value = test_obj.get_shutdown_command(**test_args)
    correct_return_value = 'shutdown'
    assert return_value == correct_return_value


# Generated at 2022-06-23 08:27:01.195218
# Unit test for constructor of class ActionModule
def test_ActionModule():

    module_name = 'reboot'
    action_name = 'reboot'
    task_name = 'test_reboot'

    class MockTask(object):
        def __init__(self):
            self.action = action_name
            self.async_val = None
            self.notify = []
            self.loop = None
            self.args = {'use_reboot': 'auto'}

    class MockPlayContext(object):
        def __init__(self):
            self.check_mode = False

    class MockConnection(object):
        def __init__(self):
            self.transport = 'ssh'
            self.become = False
            self.become_method = None
            self.become_user = None
            self.set_option = Mock()
            self.reset = Mock()

# Generated at 2022-06-23 08:27:14.079396
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    # A class implementing a test double of run_test_command()
    class dummy_run_test_command:
        DEFAULT_TEST_COMMAND = 'test'
        TEST_COMMANDS = {'dist': 'test_dist'}
        def __init__(self, **kwargs):
            self.kwargs = kwargs

        def __call__(self, distribution=None, **kwargs):
            self.kwargs.update(kwargs)
            return [self.DEFAULT_TEST_COMMAND, self.TEST_COMMANDS[distribution]][distribution is not None]
    
    obj = ActionModule()
    obj.run_test_command = dummy_run_test_command()
    obj.run_test_command('dist')

# Generated at 2022-06-23 08:27:29.380711
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    """Test for method run_test_command of class ActionModule"""
    # Setup test vars
    test_action = ActionModule(
        action='reboot',
        module_name='reboot',
        task=MockTask(),
        connection=MockConnection(),
        play_context=MockPlayContext(),
        loader=MockLoader(),
        templar=MockTemplar(),
        shared_loader_obj=None
    )

    test_action._low_level_execute_command = Mock()
    test_action._low_level_execute_command.return_value = {'rc': 0}

    test_distribution = 'CentOS Linux'

    # run the code being tested
    result = test_action.run_test_command(test_distribution)

    # verify results
    assert result is not None

# Generated at 2022-06-23 08:27:32.871617
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    """
    test_ActionModule_check_boot_time
    """
    action_module = ActionModule()
    try:
        action_module.check_boot_time(None, '')
    except TypeError:
        pass

# Generated at 2022-06-23 08:27:43.690669
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    fake_task = MagicMock()
    fake_task.action = "reboot"
    fake_task.args = {
        'connect_timeout': 10,
        'test_command': 'echo "password" | sudo -S ls',
        'reboot_timeout': 600,
        'post_reboot_delay': 0,
        'shutdown_timeout': 0,
        'connect_timeout_sec': 10
    }

    fake_distribution = "Ubuntu"
    fake_boot_time = 'Fri 2018-09-21 16:27:19 BST'

    module_obj = ActionModule(fake_task, None)
    module_obj.check_boot_time(fake_distribution, fake_boot_time)


# Generated at 2022-06-23 08:27:52.282927
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    inputs = (
        ((None, 'RedHat'), True),
        ((None, 'RedHat'), False),
        ((None, 'RedHat'), "bob"),
        (None, None)
    )

    with pytest.raises(AnsibleError) as excinfo:
        for (input_param, expected_result) in inputs:
            assert ActionModule._get_system_boot_time(input_param) == expected_result
    assert excinfo.value.args[0].startswith('Unable to find command')



# Generated at 2022-06-23 08:27:58.315925
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    obj = ActionModule('reboot', 'Reboot the system',{'reboot_timeout': 120, 'reboot_timeout_sec': 120, 'connect_timeout': 5, 'connect_timeout_sec': 5, 'interval': 1, 'interval_sec': 1, 'msg': 'Bye!', 'post_reboot_delay': 5, 'test_command': 'echo it works'})
    distribution = ''
    output = obj.get_shutdown_command_args(distribution)
    assert output == ' -r now'
    distribution = 'Linux'
    output = obj.get_shutdown_command_args(distribution)
    assert output == ' -r now'
    distribution = 'RedHat'
    output = obj.get_shutdown_command_args(distribution)
    assert output == ' -r now'
   

# Generated at 2022-06-23 08:28:06.962947
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
	module = ActionModule()
	module._task = MagicMock()
	module._task.action = "example_action"
	module._supports_check_mode = True
	module._supports_async = True
	module._play_context = MagicMock()
	module._play_context.check_mode = False
	module._connection = MagicMock()
	module._connection.transport = "local"
	module.post_reboot_delay = 0
	module._task.args = {"connect_timeout": None, "connect_timeout_sec": None, "distribution": "Ubuntu", "reboot_timeout": None, "reboot_timeout_sec": None}
	module.DEFAULT_CONNECT_TIMEOUT = 10
	module.DEFAULT_REBOOT_TIMEOUT = 600
	module.DEFAULT_SUD

# Generated at 2022-06-23 08:28:10.483207
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    result = action_module.check_boot_time('', '')
    assert not result


# Generated at 2022-06-23 08:28:17.970728
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
  action = RebootActionModule(
      task=Mock(),
      connection=Mock(),
      play_context=Mock(),
      loader=Mock(),
      templar=Mock(),
      shared_loader_obj=None)
  result = action.get_system_boot_time(distribution='Ubuntu')
  assert result == command_result['stdout'].strip()


# Generated at 2022-06-23 08:28:26.500264
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    # Setting up mock
    my_module = AnsibleModule({
        'test_command': 'echo "hi"'
    })
    my_module.deprecated_args = dict
    my_module._task.args = dict
    my_module._task.action = str
    my_module._task.loop = dict
    my_module._task.action_args = dict
    my_module._task.current_action = str
    my_module._task.tags = dict
    my_module._task.run_once = bool
    my_module._task.name = str
    my_module._task.notified_by = list
    my_module._task.notify = list
    my_module._task.loop_control = dict
    my_module._task.delegate_to = str
    my_module._task.loop_

# Generated at 2022-06-23 08:28:29.208867
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule(None, None)
    assert action._supports_check_mode
    assert action._supports_async



# Generated at 2022-06-23 08:28:29.824943
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    pass

# Generated at 2022-06-23 08:28:38.626924
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    import mock
    import yaml

    from ansible.compat.tests.mock import patch

    _task = mock.Mock(action='reboot', args={'reboot_timeout': 1, 'pre_reboot_delay': 3, 'post_reboot_delay': 5, 'connect_timeout': 10})
    _connect_timeout = mock.Mock()
    _module = mock.Mock()
    _task_vars = mock.Mock()
    _tmp = mock.Mock()

    test_obj = ActionModule(_task, _connect_timeout, _tmp, _module)


    with patch.object(test_obj, '_task') as mock_task:
        mock_task.args = {}
        test_obj.deprecated_args()