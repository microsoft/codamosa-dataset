

# Generated at 2022-06-23 08:18:47.381448
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    # The last boot time is never checked in this method
    # Therefore, we create a fake last boot time that should always be different from the current one
    current_boot_time = datetime.utcnow()
    previous_boot_time = current_boot_time + timedelta(seconds=1)

    am = ActionModule()

    try:
        # check_boot_time should not be called
        # If it is, it will raise an exception
        am.validate_reboot("fake distribution", action_kwargs={'previous_boot_time': previous_boot_time})
    except Exception:
        pytest.fail("validate_reboot did not connect successfully")


# Generated at 2022-06-23 08:18:54.164189
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Run the method
    raise NotImplementedError(
        'No unit tests defined for {0}'.format(
            'perform_reboot'
        )
    )

# Generated at 2022-06-23 08:18:55.799474
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():

    # No parametrized tests for this method

    return




# Generated at 2022-06-23 08:19:01.029300
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    module = ActionModule(
        argument_spec={},
        supports_check_mode=True
    )
    module._task.vars = {}
    result = module.get_shutdown_command({}, "redhat")
    assert result

# Generated at 2022-06-23 08:19:03.592816
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    am = ActionModule()
    am.check_boot_time(distribution=None, previous_boot_time=None)


# Generated at 2022-06-23 08:19:09.483117
# Unit test for method validate_reboot of class ActionModule

# Generated at 2022-06-23 08:19:21.178065
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    action = 'reboot'
    data = {}
    inject = {}
    task_vars = {'ansible_distribution': 'CentOS'}
    tmp = '/tmp'
    connection = 'local'

    action_module = ActionModule(task=task.Task(), connection=connection, play_context=play_context.PlayContext(), loader=None, templar=None, shared_loader_obj=None)
    action_module._task.action = action
    action_module._task.args = {'reboot_timeout':600}
    action_module._low_level_execute_command = Mock()

    def check_boot_time(distribution, previous_boot_time):
        pass

    action_module.check_boot_time = Mock(side_effect = check_boot_time)


# Generated at 2022-06-23 08:19:28.967253
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Arrange
    self = ActionModule()
    task_vars = {}
    distribution = "unknown"
    expected_result = {'failed': False}
    with patch('ansible.plugins.action.reboot.ActionModule.get_shutdown_command', return_value="fake_shutdown_command.exe"):
        with patch('ansible.plugins.action.reboot.ActionModule.get_shutdown_command_args', return_value="fake_shutdown_command_args"):
            with patch('ansible.plugins.action.reboot.ActionModule._low_level_execute_command', return_value={'rc': 0}):
                # Act
                result = self.perform_reboot(task_vars, distribution)

    # Assert
    assert result == expected_result

# Generated at 2022-06-23 08:19:35.034509
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    # set up instance of ActionModule to call the validate_reboot() method()
    reboot_validate = ActionModule.validate_reboot(self, distribution, original_connection_timeout, action_kwargs)
    correct_result = {'failed': False, 'rebooted': True, 'changed': True}
    assert(reboot_validate == correct_result)


# Generated at 2022-06-23 08:19:36.380908
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(dict(), dict())
    assert action_module

# Generated at 2022-06-23 08:19:38.915500
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    try:
        raise TimedOutException()
    except TimedOutException:
        pass



# Generated at 2022-06-23 08:19:50.023444
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module = ActionModule()
    action_module._task = TestTask()
    action_module._task.action = 'reboot'
    action_module._connection = MockConnection()
    action_module._low_level_execute_command = MockCommandExecutor()
    action_module._task.args = {'reboot_timeout': 600, 'test_command': 'uptime', 'connect_timeout': 2}

    distribution = 'unknown'
    previous_boot_time = 'Mon Jul  9 07:41:27 PDT 2018'

    #Test when command fails
    action_module._task.args = {'reboot_timeout': 600, 'test_command': 'uptime', 'connect_timeout': 2}

# Generated at 2022-06-23 08:20:03.367956
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    """Unit test for method ActionModule.get_shutdown_command"""
    # Declaring the base class
    class BaseClass:
        """Base class for unit test"""
        def __init__(self):
            """Constructor for BaseClass"""
            self.action = 'reboot'
            self.args = {
                'shutdown_command': 'test',
                'connect_timeout': None,
                'connect_timeout_sec': None,
                'reboot_timeout': None,
                'reboot_timeout_sec': None,
                'test_command': None,
                'msg': 'lorem ipsum'
            }
    # Creating a subclass
    class DerivedClass(BaseClass):
        """The derived class"""
        def __init__(self):
            """Constructor for DerivedClass"""
            BaseClass.__

# Generated at 2022-06-23 08:20:14.694306
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    from ansible.compat.tests.mock import Mock, patch

    action_module_obj = ActionModule()
    action_module_obj.action = "TestReboot"
    action_module_obj.task_vars = {}

    action_module_obj.task_vars["ansible_facts"] = {"ansible_distribution_version" : "7.7", "ansible_distribution" : "RedHat"}

    expected_result = {"distribution" : "RedHat", "version" : "7.7", "full_name" : "RedHat 7.7"}
    actual_result = action_module_obj.get_distribution(action_module_obj.task_vars["ansible_facts"])

    assert expected_result == actual_result


# Generated at 2022-06-23 08:20:21.193242
# Unit test for constructor of class ActionModule
def test_ActionModule():
    t = AnsibleTask()
    a = ActionModule(t, dict())
    assert a._task == t
    assert a._supports_async
    assert a._supports_check_mode
    assert a.DEFAULT_REBOOT_TIMEOUT == 600
    assert a.DEFAULT_CONNECT_TIMEOUT == 30
    assert a.DEFAULT_TEST_COMMAND == '/bin/true'
    assert a.DEFAULT_SUDOABLE


# Generated at 2022-06-23 08:20:23.644822
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    exception = TimedOutException()
    assert exception



# Generated at 2022-06-23 08:20:34.368077
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    # test case data
    action = 'reboot'
    connection = None
    play_context = None
    distribution = 'Linux'
    original_connection_timeout = 1
    action_kwargs = None

    action_module = ActionModule(action, connection, play_context, distribution=distribution)

    # mock get_system_boot_time function
    action_module.get_system_boot_time = MagicMock(return_value=100)
    # mock perform_reboot function
    action_module.perform_reboot = MagicMock(return_value={'failed': False, 'start': datetime.utcnow()})
    # mock get_distribution function
    action_module.get_distribution = MagicMock(return_value='Linux')
    # mock do_until_success_or_timeout function
    action

# Generated at 2022-06-23 08:20:45.540825
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    results = {}
    module_connection = collections.namedtuple('module_connection', 'transport')
    play_context = collections.namedtuple('play_context', 'check_mode')
    ansible_module = collections.namedtuple('ansible_module', 'check_mode')
    module_task = collections.namedtuple('module_task', 'action')
    module_tmp = collections.namedtuple('module_tmp', 'tmpdir')
    module_task_vars = collections.namedtuple('module_task_vars', 'task_vars')
    module_ansible_facts = collections.namedtuple('module_ansible_facts', 'ansible_facts')
    if results['failed']:
        return results
    return results



# Generated at 2022-06-23 08:20:48.545600
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    module = ActionModule()

    # Attempt to call the method with default arguments, should raise a ValueError
    with pytest.raises(NotImplementedError):
        module.deprecated_args()

# Generated at 2022-06-23 08:20:58.736223
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    # Assign values
    deprecated_args = {
        'connect_timeout': '2.7'
    }

    # Create object of class ActionModule
    obj = ActionModule(task=MagicMock(), connection=MagicMock(), play_context=MagicMock(), loader=MagicMock(), templar=MagicMock(), shared_loader_obj=None)

    # Set attribute _task of object to a mock
    obj._task = MagicMock()

    # Set attribute _task.args of object to a mock
    obj._task.args = MagicMock()
    # Set attribute _task.args.get of object to a mock
    obj._task.args.get = MagicMock()
    obj._task.args.get.return_value = ''
    
    # Set attribute _task.action of object to a mock
    obj._task

# Generated at 2022-06-23 08:21:02.658443
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
  a = AnsibleAction()
  b = AnsibleAction()
  b.DEFAULT_SUDOABLE=True
  b.run_test_command('pass') == a.run_test_command('pass')
  
  

# Generated at 2022-06-23 08:21:06.861662
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    task_vars = dict()
    action_module = ActionModule(task_vars=task_vars, connection='local', play_context=dict())
    action_module._task.args = dict()
    v = action_module.get_shutdown_command(task_vars=task_vars)
    assert v == '/sbin/shutdown'

# Generated at 2022-06-23 08:21:16.964274
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    args = {
    }
    cmd = "command"
    in_data = None
    task_vars = dict(
        ansible_facts = dict(
            ansible_distribution = 'A',
            ansible_distribution_release = 'B',
            ansible_distribution_version = 'C',
            ansible_os_family = 'D',
            ansible_distribution_major_version = 'E',
        )
    )
    module = ActionModule(
        task=Mock(),
        connection=Mock(),
        play_context=Mock(),
        loader=Mock(),
        templar=Mock(),
        shared_loader_obj=Mock()
    )
    module.get_distribution(task_vars)
    module._low_level_execute_command.assert_called_

# Generated at 2022-06-23 08:21:30.154014
# Unit test for method validate_reboot of class ActionModule

# Generated at 2022-06-23 08:21:31.407275
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    pass


# Generated at 2022-06-23 08:21:37.894405
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    test_instance = ActionModule()
    task_vars = {}
    distribution = 'Debian'
    test_value = test_instance.get_shutdown_command(task_vars, distribution)
    assert test_value == 'shutdown'


# Generated at 2022-06-23 08:21:49.359050
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    action_module_instance = ActionModule()

    def dummy_get_distribution():
        pass

    def dummy_get_shutdown_command():
        pass


    action_module_instance._task.action = "test"
    action_module_instance._connection.reset = dummy_get_distribution
    action_module_instance.get_distribution = dummy_get_shutdown_command
    action_module_instance.get_shutdown_command = dummy_get_shutdown_command
    action_module_instance.run = dummy_get_distribution
    action_module_instance.perform_reboot = dummy_get_distribution
    action_module_instance.validate_reboot = dummy_get_distribution
    action_module_instance.check_boot_time = dummy_get_distribution
    action_module_instance

# Generated at 2022-06-23 08:21:58.583989
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    task_vars = {}
    # test case 1
    am = ActionModule(dict(module_name='module_name', module_args='module_args', task_vars=task_vars, task_action='task_action', task_id='task_id', task_name='task_name'))
    # set the ansible_facts.distribution
    task_vars['ansible_facts'] = {'distribution': 'Fedora'}
    assert am.get_distribution(task_vars) == 'Fedora'

    # test case 2
    am = ActionModule(dict(module_name='module_name', module_args='module_args', task_vars=task_vars, task_action='task_action', task_id='task_id', task_name='task_name'))
    # set the

# Generated at 2022-06-23 08:21:59.048823
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:22:03.352726
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    container_class_str = "ActionModule"
    container_class = getattr(sys.modules[__name__], container_class_str)

    set_module_args('')
    module = AnsibleModule(argument_spec=dict())

    fake_ansible_connection = Mock()
    fake_ansible_connection.transport = 'local'
    fake_ansible_connection.reboot_conn_timeout = None

    fake_play_context = Mock()
    fake_play_context.remote_addr = 'localhost'
    fake_play_context.connection = 'local'
    fake_play_context.port = None
    fake_play_context.remote_user = None
    fake_play_context.password = None
    fake_play_context.private_key_file = None
    fake_play_context.connection_

# Generated at 2022-06-23 08:22:04.782153
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()
    assert module.run() == 1

# Generated at 2022-06-23 08:22:05.567626
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    pass

# Generated at 2022-06-23 08:22:15.889302
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # initiate a action module
    action_module = ActionModule(
        connection=Connection(),
        play_context=PlayContext(),
        loader=None,
        templar=None,
        shared_loader_obj=None)
    # make up a task
    task = Task()
    task.action = 'reboot'
    # set task.args
    task.args = {'reboot_timeout':300, 'connect_timeout':5}
    # set the action module's task
    action_module._task = task
    # get a facter module
    facter = Facter()

    # make up a task_vars

# Generated at 2022-06-23 08:22:16.577277
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:22:27.951176
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # Default timeout is 120 seconds
    reboot_timeout = 120

    # Post-reboot test command can be set to a custom value
    test_command = 'sleep 30'

    # Timeout should be reduced so we can catch a failure and cancel the test
    reboot_timeout = 5

    # Set the number of times the reboot should fail
    fail_count = 3

    mock_distribution = 'default'

    # Create and initialise the action module
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Define fake actions to return success and failure
    def return_success(distribution=mock_distribution, **kwargs):
        return True


# Generated at 2022-06-23 08:22:39.643988
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():

    # mock the host facts for Ubuntu
    mock_ansible_module = MagicMock()
    mock_ansible_instance = ActionModule(mock_ansible_module)

    # get_system_boot_time should return a datetime string with the system's last boot time
    mock_ansible_instance.get_system_boot_time("Ubuntu")
    mock_ansible_instance.get_system_boot_time("Ubuntu")

    # get_system_boot_time should return a datetime string with the system's last boot time
    # with a custom boot_time_command
    mock_ansible_instance.get_system_boot_time("Ubuntu", boot_time_command="/bin/cat /var/run/boot-time.txt")

# Generated at 2022-06-23 08:22:50.286183
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # Return value of mocker.patch.object()
    mock_distribution = Mock()
    mock_previous_boot_time = Mock()

    # Return value of mocker.patch.object()
    mock_boot_time = Mock()
    mock_boot_time.strip = Mock()

    # Return value of mocker.patch.object()
    mock_get_system_boot_time = Mock()
    mock_get_system_boot_time.return_value = mock_boot_time

    # Return value of mocker.patch.object()
    mock_TimedOutException = Mock()

    # Return value of mocker.patch.object()
    mock_ValueError = Mock()

    # Return value of mocker.patch.object()
    mock_time = Mock()

    # Return value of mocker.patch.object()
   

# Generated at 2022-06-23 08:22:54.255551
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    try:
        raise TimedOutException("test exception")
    except TimedOutException as e:
        assert "test exception" in str(e)



# Generated at 2022-06-23 08:23:04.333083
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    # These are globally used throughout the ActionModule unit tests
    # For example, to check if errors are raised then we will check
    # the 'failed' key in the return which will be set to true if
    # an exception was raised.
    #
    # Other tests can modify this to test their scenarios
    result = {}

# Generated at 2022-06-23 08:23:08.439667
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    actionmodule = ActionModule(None, None, None)
    try:
        actionmodule.run_test_command({'DISTRIBUTION': '', 'DISTRIB_ID': ''})
    
    except:
        pass



# Generated at 2022-06-23 08:23:09.460250
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    pass

# Generated at 2022-06-23 08:23:22.380754
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # _init_() tests
    module_args = {}
    am = ActionModule(None, module_args, None)
    assert isinstance(am, ActionModule)

    module_args = {'action': 'reboot', 'reboot_timeout': '60'}
    am = ActionModule(None, module_args, None)
    assert am.DEFAULT_REBOOT_TIMEOUT == '60'

    module_args = {'action': 'reboot', 'post_reboot_delay': '100'}
    am = ActionModule(None, module_args, None)
    assert am.post_reboot_delay == 100

    module_args = {'action': 'reboot', 'reboot_timeout': '60', 'post_reboot_delay': '100'}

# Generated at 2022-06-23 08:23:22.934487
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    pass

# Generated at 2022-06-23 08:23:31.249778
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    am = ActionModule()

    # test for linux
    task_vars = {
        'ansible_pkg_mgr': 'apt',
        'ansible_facts': {
            'distribution': 'Ubuntu'
        }
    }
    distribution = am.get_distribution(task_vars=task_vars)
    assert distribution == 'linux'

    shutdown_bin = am.get_shutdown_command(task_vars=task_vars, distribution=distribution)
    assert shutdown_bin == 'shutdown'

    # test for freebsd
    task_vars = {
        'ansible_pkg_mgr': 'pkgng',
        'ansible_facts': {
            'distribution': 'FreeBSD'
        }
    }

# Generated at 2022-06-23 08:23:36.021264
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module = ActionModule(task=Mock(), connection=Mock(), play_context=Mock(), loader=Mock(), templar=Mock(), shared_loader_obj=Mock())
    # output = action_module.get_distribution(task_vars={})
    # assert output == None
    # assert False

# Generated at 2022-06-23 08:23:47.987786
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    # Example from spec
    from ansible.module_utils.common.text.converters import to_bytes
    module_kwargs = {}
    self = ActionModule(
        action='fake_action',  # type: str
        connection=None,  # type: Optional[Connection]
        task=None,  # type: Optional[Task]
        **module_kwargs  # type: Any
    )
    distribution = 'fake distribution'
    expected_result = {
        'rc': 0,
        'stderr': b'',
        'stdout': to_bytes('fake stdout'),
        'stdout_lines': ['fake stdout line']
    }
    test_command = 'fake test command'
    self._get_value_from_facts = lambda facts, distro, default: test_command
    self._low

# Generated at 2022-06-23 08:23:59.732713
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    distribution = 'distribution'

    # Construct a mock action_module
    mock_am = MagicMock(spec=ActionModule, name='ActionModule')
    mock_am._task.action = 'reboot'
    mock_am._task.args = {}
    mock_am._task.args['test_command'] = "true"
    mock_am._task.args['reboot_timeout'] = 10

    # Mock the datetime module
    mock_datetime = MagicMock(name="datetime")
    datetime_mock = Mock(wraps=datetime)
    datetime_mock.datetime.now.return_value = mock_datetime

    # Mock the time module
    mock_time = MagicMock(name="time")
    time_mock = Mock(wraps=time)

# Generated at 2022-06-23 08:24:07.963236
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    module_arguments = {"patterns": ["any"], "paths": ["/tmp/ansible_reboot_test_dir"], "file_type": "file"}
    action_module = ActionModule({"module_args": module_arguments}, "action_module_test_task", "local")
    distribution = "test_distribution"

    original_connection_timeout = 120
    action_kwargs = {}

    action_module.validate_reboot(distribution, original_connection_timeout, action_kwargs)


# Generated at 2022-06-23 08:24:17.640243
# Unit test for constructor of class ActionModule
def test_ActionModule():

    args = {
        'reboot_timeout': 120,
    }

    class MockPlayContext():
        def __init__(self):
            self.connection = 'smart'
            self.check_mode = False

    class MockTask():
        def __init__(self):
            self.args = args
            self.action = 'reboot'

    class MockConnection():
        def __init__(self):
            self.connection_type = 'ssh'

    pc = MockPlayContext()
    t = MockTask()
    c = MockConnection()

    # Test constructor with no module_args
    reboot = ActionModule(t, pc, c)
    assert reboot.DEFAULT_REBOOT_TIMEOUT == 600
    assert reboot.DEFAULT_CONNECT_TIMEOUT == 5
    assert reboot.DEFAULT_POST_REBOOT_

# Generated at 2022-06-23 08:24:30.679497
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # Mock _task
    mock_task = mock.Mock()
    mock_action = mock.Mock()
    mock_task.action = mock_action

    # Mock _connection
    mock_connection = mock.Mock()
    # Mock sudoable
    mock_sudoable = mock.PropertyMock(return_value=True)
    type(mock_connection).sudoable = mock_sudoable

    # Mock _play_context
    mock_play_context = mock.Mock()
    mock_check_mode = mock.PropertyMock(return_value=True)
    mock_play_context.check_mode = mock_check_mode

    # Mock _loader
    mock_loader = mock.Mock()

    # Mock _templar
    mock_templar = mock.Mock()

    # Mock distribution
   

# Generated at 2022-06-23 08:24:40.326490
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    from ansible.module_utils.facts.system.distribution import Distribution
    action_module_obj = ActionModule()
    task_vars = {}
    task_vars['ansible_facts'] = {}
    distribution_id = 'CentOS'
    dist_name = 'CentOS'
    major_version = 7
    minor_version = 0
    dist_version = '7.0'
    dist_version_id = '7.0'
    dist_codename = ''
    dist_id = 'centos'
    dist_pretty_name = 'CentOS'
    dist_pretty_version = '7.0'
    release_file_name = 'redhat-release'

# Generated at 2022-06-23 08:24:42.918949
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    timeout = 10
    ret = "Command  timed out after " + str(timeout) + " seconds"
    try:
        raise TimedOutException(ret)
    except TimedOutException as e:
        ret2 = str(e)
    assert ret == ret2



# Generated at 2022-06-23 08:24:50.612814
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    args = {'reboot_timeout': 10,
        'test_command': 1,
        'shutdown_timeout': 10,
        'wait_for_reboot': True,
        'pre_reboot_delay': 10}
    # print(ansible_module._low_level_execute_command.__name__)
    ansible_module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    boot_time_module = ActionModule(ansible_module, args, False)
    distribution = 'DEBIAN'
    boot_time = 'Wed Aug 15 18:03:35 2018'

    try:
        boot_time_module.check_boot_time(distribution, boot_time)
    except Exception as e:
        assert isinstance(e, ValueError)


# Generated at 2022-06-23 08:24:53.913464
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    action_module = ActionModule(self, self._task, tmp, self._connection, play_context, loader, templar, shared_loader_obj)
    action_module.run_test_command(distribution, **kwargs)


# Generated at 2022-06-23 08:25:03.298347
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    mock_task = Mock()
    mock_task.action = 'reboot'
    mock_task.args = {'boot_time_command': None,
                      'post_reboot_delay': 0,
                      'pre_reboot_delay': 0,
                      'connect_timeout': 10,
                      'connect_timeout_sec': 10,
                      'test_command': 'exit 0',
                      'reboot_timeout': 20,
                      'reboot_timeout_sec': 20,
                      'msg': 'Reboot server'}
    mock_task.async_val = None

    mock_task_vars = {'ansible_facts': {'distribution': 'debian',
                                        'ansible_distribution': 'debian',
                                        'ansible_distribution_release': 'stretch'}}

    mock_connection = Mock()

# Generated at 2022-06-23 08:25:14.159322
# Unit test for method get_distribution of class ActionModule

# Generated at 2022-06-23 08:25:22.795333
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    module = ActionModule(
        task=MagicMock(),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

# Generated at 2022-06-23 08:25:32.797519
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    test_module = AnsibleModule(argument_spec={'path': {'type': 'list', 'elements': 'str'}, 'patterns': {'type': 'list', 'elements': 'str'}, 'file_type': {'required': False, 'type': 'str'}})
    test_module_instance = ActionModule(test_module, task_vars={'ansible_facts': {'DEFAULT_SHUTDOWN_COMMAND': 'shutdown', 'DEFAULT_SHUTDOWN_PROMPT': 'shutdown'}}, connection=FakeConnection())
    test_input = {'path': ['/usr/bin', '/bin', '/usr/sbin', '/sbin'], 'patterns': ['shutdown'], 'file_type': 'any'}
    expected_output = '/bin/shutdown'

# Generated at 2022-06-23 08:25:45.554230
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    action = ActionModule(None, {}, 
            None, 
            None, 
            None, 
            None, 
            None, 
            None, 
            None, 
            None,
            None
            )

    task_vars = {"ansible_facts": {"SHUTDOWN_COMMANDS": {"RHEL": "shutdown command"}}}
    distribution = "RHEL"
    args = {"shutdown_command": "shutdown command"}
    expected = "shutdown command"
    assert(action.get_shutdown_command(task_vars, distribution, args) == expected)

    args = {"shutdown_command": None}
    expected = "shutdown command"
    assert(action.get_shutdown_command(task_vars, distribution, args) == expected)


# Generated at 2022-06-23 08:25:50.478490
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    try:
        raise TimedOutException("Timed out")
        assert(False)
    except TimedOutException as e:
        assert(e.args[0] == "Timed out")
    except:
        assert(False)


# Generated at 2022-06-23 08:25:51.084970
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    pass

# Generated at 2022-06-23 08:26:02.305704
# Unit test for method get_shutdown_command_args of class ActionModule

# Generated at 2022-06-23 08:26:15.041431
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    class FakeDistribution():
        TEST_COMMANDS = {}
    distribution = FakeDistribution()
    class Fake_task():
        args = {}

    class Fake_play_context():
        check_mode = True

    class Fake_tmp():
        path = '/tmp'

    class Fake_connection():
        connection = 'local'
        def reset(self):
            pass

    class Fake_loader():
        def get_basedir(self):
            return ''

    class Fake_task_vars():
        distribution = FakeDistribution()

    class Fake_self():
        _task = Fake_task()
        _play_context = Fake_play_context()
        DEFAULT_REBOOT_TIMEOUT = 0
        post_reboot_delay = 0
        _tmpdir = Fake_tmp()
        _low_level_execute_

# Generated at 2022-06-23 08:26:24.297395
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    mock_distribution = "mock_system"
    mock_original_connection_timeout = "connection_timeout_duration"
    mock_action_kwargs = {"previous_boot_time" : "pre_boot_time"}
    test_obj = ActionModule()
    test_obj._task.action = "mock_action"
    test_obj._connection = Mock()
    test_obj._connection.transport = "mock_transport"
    test_obj._play_context = Mock()
    test_obj._play_context.check_mode = False
    test_obj.check_boot_time = Mock()
    test_obj.get_system_boot_time = Mock()
    test_obj.check_boot_time.side_effect = ValueError("boot time changed")
    test_obj.get_system_boot_

# Generated at 2022-06-23 08:26:33.149886
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    print('Test ActionModule.do_until_success_or_timeout')

    from ansible import constants as C
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins import module_loader
    from ansible.plugins.loader import connection_loader
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display


    # Mock paramiko for testing function

    class paramiko_mock:
        def __init__(self):
            print('')

    def paramiko_mock_patch():
        return paramiko_mock

    # Mock subprocess for testing function


# Generated at 2022-06-23 08:26:35.130297
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(dict(ANSIBLE_MODULE_ARGS={}), {})

# Generated at 2022-06-23 08:26:36.339353
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    assert True == True

# Generated at 2022-06-23 08:26:38.585315
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    try:
        raise TimedOutException
    except TimedOutException:
        pass


# Generated at 2022-06-23 08:26:42.852118
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    """Unit test for method do_until_success_or_timeout of class ActionModule."""
    result = ActionModule.do_until_success_or_timeout(ActionModule)
    assert result, "ActionModule.do_until_success_or_timeout() should return True."



# Generated at 2022-06-23 08:26:48.145820
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    mock_action_module = mock.Mock(spec=ActionModule)
    mock_action_module.get_system_boot_time.return_value = "2018"
    result = mock_action_module.get_system_boot_time("ubuntu")
    assert result == "2018"

# Generated at 2022-06-23 08:26:49.824093
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action = ActionModule("", "", "")
    res = action.get_shutdown_command_args("debian")
    assert res == "now"


# Generated at 2022-06-23 08:26:58.492475
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Test for running 
    ActionModule.run"""
    print("#### Tests for ActionModule.run() ####")
    shutdown_command = "/sbin/shutdown"
    shutdown_args = "-r now"
    result = {"failed": False, "rebooted": True, "elapsed": 3, "reboot_result": {"start": datetime.utcnow(), "failed": False},
            "previous_boot_time": "", "reboot_timeout": 600, "changed": True}
    am = ActionModule(None, "Test", {"shutdown_command":shutdown_command, "shutdown_arg":shutdown_args})
    assert result == am.run()


# Generated at 2022-06-23 08:27:04.016130
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Prepare
    mock_module = MagicMock()

    # Execute
    reboot_module = ActionModule(mock_module, 'low_level_execute_command', 'execute_command', '_execute_module')

    # Assert

# Generated at 2022-06-23 08:27:14.578867
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Setup test system and create fake task
    test_system = System()
    test_system.distribution = 'foo_distribution'
    test_task = Task()
    test_task.action = 'reboot'

    test_module = ActionModule(test_task, test_system)
    # Create fake task_vars and populate with test data
    test_task_vars = dict()

    test_method_data = dict()
    test_method_data['config'] = {'reboot_timeout': -1, 'reboot_timeout_sec': -1, 'connect_timeout': -1, 'connect_timeout_sec': -1, 'post_reboot_delay': -1}
    test_method_data['vars'] = {'ansible_check_mode': False}
    test_method_data['distribution']

# Generated at 2022-06-23 08:27:29.415479
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module = ActionModule(action='test_action', task='test_task', play=Play(), task_vars={}, wrap_async=None, connection='connection', play_context='context')
    action_module.DEFAULT_SHUTDOWN_COMMAND_ARGS = '-r'
    action_module.DEFAULT_SHUTDOWN_COMMAND_ARGS_SUSE = '-r now'
    action_module.DEFAULT_SHUTDOWN_COMMAND_ARGS_RHEL = '-r +1'
    # Test for requested distribution is none and task_vars is not None
    result = action_module._get_shutdown_command_args(distribution=None, task_vars={'ansible_distribution': 'Ubuntu'})
    assert result == action_module.DEFAULT_SHUTDOWN

# Generated at 2022-06-23 08:27:31.798213
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    action_module = ActionModule()
    assert action_module.validate_reboot("any_distribution") is None


# Generated at 2022-06-23 08:27:40.379865
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    class MockedActionModule(ActionModule):
        class MockedConnection(object):
            class MockedLowLevelExec(object):
                output_obj = {'stdout': 'Success', 'stderr': '', 'rc': 0, 'start': '', 'end': ''}
                
                def __call__(self, cmd, sudoable, executable):
                    return self.output_obj

            def __init__(self):
                self.ll_exec = self.MockedLowLevelExec()

            def reset(self):
                pass

            def set_option(self, key, value):
                pass

            def get_option(self, key):
                return ''

        class MockedAnsibleHost(object):
            name = 'hostname'

        class MockedAnsibleTask(object):
            action = 'action'

       

# Generated at 2022-06-23 08:27:52.688434
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Create a good mock task, where all needed fields are set
    task_vars = {'ansible_connection': 'local'}
    subject = ActionModule(task=MockTask(args={'test_command': '/usr/bin/uptime', 'reboot_timeout': 300, 'connect_timeout': 5}),
                         connection=MockConnection(return_values={'execute_command': (0, '/bin/systemd-shutdown', '')}),
                         play_context=MockPlayContext(), loader=MockLoader(), shared_loader_obj=None,
                         final_q=None, terminates=None)
    result = subject.perform_reboot(task_vars, 'AnyLinux')

# Generated at 2022-06-23 08:27:56.682054
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    tmp = None
    task_vars = None
    # Actual call:
    result = ActionModule.perform_reboot(tmp, task_vars)
    # cleanup
    return  # noqa

# Generated at 2022-06-23 08:28:08.043831
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    action_module = ActionModule()
    shut_module = ShutdownModule()
    task_vars = dict()

    task_vars['ansible_distribution'] = shut_module.DEFAULT_DISTRIBUTION
    action_module._get_value_from_facts = MagicMock(return_value=shut_module.DEFAULT_SHUTDOWN_COMMAND)
    result = action_module.get_shutdown_command(task_vars, shut_module.DEFAULT_DISTRIBUTION)
    assert result == shut_module.DEFAULT_SHUTDOWN_COMMAND

    action_module._get_value_from_facts = MagicMock()
    result = action_module.get_shutdown_command(task_vars, shut_module.DEFAULT_DISTRIBUTION)
    assert result == shut_module.DE

# Generated at 2022-06-23 08:28:11.894264
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    module = get_test_connection()
    action = run_action_module(module, 'reboot', 'test_OS',
        boot_time_command='test_boot_time',
        test_command='test_test_command')

    # result is a timestamp
    assert action['rebooted']

# Generated at 2022-06-23 08:28:13.001489
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    test_exception = TimedOutException()
    assert test_exception.args[0] == ''



# Generated at 2022-06-23 08:28:15.117216
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    exc = TimedOutException()
    assert isinstance(exc, Exception)



# Generated at 2022-06-23 08:28:22.830468
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    # Arrange
    am = ActionModule({}, {}, {}, {})

    system_boot_time_command_results = [
        {
            'rc': 0,
            'stdout': b'Sat Oct 21 16:27:32 MDT 2017',
            'stderr': b''
        }
    ]
    am._low_level_execute_command = MagicMock(side_effect=system_boot_time_command_results)

    # Act
    result = am.get_system_boot_time("centos")

    # Assert
    assert result == 'Sat Oct 21 16:27:32 MDT 2017'



# Generated at 2022-06-23 08:28:23.733723
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Instantiate a class object
    pass

# Generated at 2022-06-23 08:28:28.443639
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module is not None

# Generated at 2022-06-23 08:28:29.690140
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    assert callable(ActionModule.get_system_boot_time)


# Generated at 2022-06-23 08:28:33.108209
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
  reboot_action = RebootActionModule(mock.Mock())
  result = reboot_action.check_boot_time(distribution='linux', previous_boot_time="some_time")
  assert result is None


# Generated at 2022-06-23 08:28:37.690423
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    action_module = ActionModule()
    distribution = ''
    original_connection_timeout = ''
    action_kwargs = None
    assert action_module.validate_reboot(distribution, original_connection_timeout, action_kwargs)

# Generated at 2022-06-23 08:28:39.926577
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    mock_action = MagicMock()
    action_module = ActionModule()
    action_module.do_until_success_or_timeout(mock_action, 5, 10, {})
    assert mock_action.call_count == 5
