

# Generated at 2022-06-23 08:18:46.935149
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    # Unit tests for get_shutdown_command_args

    # get_shutdown_command_args(distribution)
    # This method takes one argument, distribution.
    # distribution is of type str.

    # Test 1

    # Setup
    action_module = Reboot()
    action_module._supports_check_mode = True
    action_module._supports_async = True
    action_module.CONNECTION_RETRY_TIMEOUT = 60
    action_module.CONNECTION_RETRY_SLEEP = 5
    action_module._task.action = reboot
    action_module._task.args = {'reboot_timeout': 300}
    action_module.DEFAULT_REBOOT_TIMEOUT = 300
    action_module.DEFAULT_CONNECT_TIMEOUT = 5
    action_module.DEFAULT_

# Generated at 2022-06-23 08:18:47.824365
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False



# Generated at 2022-06-23 08:19:03.003480
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    def mock_do_until_success_or_timeout(action, action_desc, reboot_timeout, distribution, action_kwargs=None):
        if action_kwargs is None:
            action_kwargs = {}
        # Perform mock check boot time to simulate a successful reboot
        if action.__name__ == 'check_boot_time':
            action(distribution=distribution, **action_kwargs)
            return
        # Perform mock run test command to simulate a successful test
        if action.__name__ == 'run_test_command':
            action(distribution=distribution, **action_kwargs)
            return

    # Perform mock check boot time to simulate a successful reboot

# Generated at 2022-06-23 08:19:09.522610
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    module = ansible_collections.community.general.plugins.action.reboot
    action_module = module.ActionModule(MockTask(), MockConnection(MockAnsibleModule()))
    with pytest.raises(ValueError) as excinfo:
        action_module.check_boot_time(Mock(), 'previous_boot_time')
    assert 'boot time has not changed' in str(excinfo.value)


# Generated at 2022-06-23 08:19:13.714402
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    task_vars = {
        'ansible_service_mgr': 'systemctl',
    }
    shutdown_bin = 'shutdown'
    action = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action.get_shutdown_command(task_vars, shutdown_bin) == '/bin/systemctl poweroff'


# Generated at 2022-06-23 08:19:24.301636
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():

    # Unit test for method get_shutdown_command_args of class ActionModule
    # 
    # Invoke method with a known distribution and known args and check
    # return value
    # 
    # Mock the task and prepare test values
    task = MagicMock()
    task.action = 'reboot'
    task._task.args = {}
    action_module = ActionModule(task, MagicMock())

    args = '-r'
    shut_down_args = action_module.get_shutdown_command_args(args)
    assert shut_down_args == args

    # Mock the task and prepare test values
    task = MagicMock()
    task.action = 'reboot'
    task._task.args = {'shutdown_command_args': '-h'}

# Generated at 2022-06-23 08:19:33.911335
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    # # Create a mock task to validate
    mock_task = MockTask()
    mock_task.action = 'reboot'
    mock_task.args = {'pre_reboot_delay': 3, 'reboot_timeout': 60, '_ansible_no_log': True}

    # Create an instance of ActionModule with the mocked task
    action_module = ActionModule(mock_task)

    # invoke method
    result = action_module.deprecated_args()

    # validate results
    assert result is None

# Generated at 2022-06-23 08:19:36.897411
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    from ansible.modules.system.reboot import ActionModule
    am = ActionModule(None, None)
    am.set_task(Task(None))
    am.get_distribution(None)

# Generated at 2022-06-23 08:19:45.486243
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # FIXME: make this unit test workable at some point
    return True
    #task_vars_dict = {'inventory_hostname': 'test', 'testvar': 'testval'}
    #task_vars = DictData(task_vars_dict)
    #mod = AnsibleModule(argument_spec={})
    #act = ActionModule(task=mod.params, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    #return act.task_vars == {}

# Generated at 2022-06-23 08:19:57.257803
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    argv = 'some_arg'
    action_args = {'some_arg': argv}
    task_args = {'some_arg': argv}
    task_action = 'reboot'
    task_name = 'reboot'
    file_name = 'reboot.py'
    task_vars = {'some_arg': argv}

    for action in ['reboot', 'wait_reboot']:
        task_action = action
        task = create_task(task_name, task_action, file_name, task_args, task_vars)
        am = create_action_module(task)
        # test
        am.deprecated_args()


# Generated at 2022-06-23 08:20:02.253067
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    # create an instance of the class to test
    am = ActionModule(None)
    # set testing variables
    distribution = 'test'
    # test the method with correct values
    try:
        am.get_system_boot_time(distribution)
        assert True
    except Exception as e:
        assert False
    # test the method with incorrect values
    try:
        am.get_system_boot_time(None)
        assert False
    except Exception as e:
        assert True



# Generated at 2022-06-23 08:20:14.517012
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    #
    # Create a mock object
    #
    mock_action_module = ActionModule()
    mock_action_module._task.action = "sample action"
    mock_action_module._task.args = {"shutdown_command": "/sbin/shutdown"}

# Generated at 2022-06-23 08:20:24.129834
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # Get a valid fixture to pass to the ActionModule.
    task_vars = dict()
    action_module = ActionModule()

    # Set the 'ansible_facts' to match the default OS from the ActionModule
    task_vars['ansible_facts'] = dict()
    task_vars['ansible_facts']['distribution'] = 'Debian'
    task_vars['ansible_facts']['distribution_version'] = '8.0'

    # Invoke the action plugin and grab the resulting return value.
    distribution = action_module.get_distribution(task_vars)

    # Assert that the return value is what is expected.
    assert_equal(distribution, 'Debian')


# Generated at 2022-06-23 08:20:34.659436
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.process import get_bin_path

    class MockSystemDistribution(object):
        def __init__(self, distribution, version=None, release=None):
            self.distribution = distribution
            self.version = version
            self.release = release

        def name(self):
            return self.distribution

        def version(self):
            return self.version

        def release(self):
            return self.release

    class MockAnsibleModule(object):
        def __init__(self, args):
            self.args = args

        class ActionModule(object):
            def __init__(self, args, task_vars=None):
                self._task = self.ActionModule(args)

            class ActionModule(object):
                def __init__(self, args):
                    self

# Generated at 2022-06-23 08:20:36.189322
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    action_module = ActionModule()
    assert False

# Generated at 2022-06-23 08:20:37.080905
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    exception = TimedOutException()
    assert exception is not None


# Generated at 2022-06-23 08:20:47.457778
# Unit test for constructor of class ActionModule
def test_ActionModule():
    _connection = Connection()
    action_module = ActionModule(_connection, name="reboot", play_context=PlayContext())
    assert action_module.post_reboot_delay == 0
    assert action_module.DEFAULT_CONNECT_TIMEOUT == 20
    assert action_module.DEFAULT_REBOOT_TIMEOUT == 300
    assert action_module.DEFAULT_FACT_COMMAND == 'uname'
    assert action_module.DEFAULT_SUDOABLE == True
    assert action_module.BOOT_TIME_COMMANDS['Fedora'] == 'date -d `systemd-analyze time | sed -n \'s/[0-9.]*//p\'`'
    assert action_module.REBOOT_COMMANDS['Fedora'] == 'systemctl reboot'
    assert action_module.REBOOT

# Generated at 2022-06-23 08:20:48.199522
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    pass

# Generated at 2022-06-23 08:20:53.075420
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    from ansible.module_utils.six import text_type
    action_module = ActionModule()
    expected_value = text_type
    actual_value = action_module.check_boot_time('distribution', 'previous_boot_time')
    assert expected_value == actual_value, "Expected {0}, got {1}".format(repr(expected_value), repr(actual_value))

# Generated at 2022-06-23 08:20:59.895469
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    am = ActionModule()
    assert am.do_until_success_or_timeout(action=am.check_boot_time, action_desc="check boot time", reboot_timeout=2, distribution=None, action_kwargs={'previous_boot_time': 1}) == None
    try:
        am.do_until_success_or_timeout(action=am.check_boot_time, action_desc="check boot time", reboot_timeout=1, distribution=None, action_kwargs={'previous_boot_time': 1})
        assert False
    except Exception as e:
        assert e.__class__ == TimedOutException


# Generated at 2022-06-23 08:21:06.536615
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    """Test method get_distribution of class ActionModule"""
    task_vars = dict()
    task_vars['ansible_os_family'] = 'RedHat'
    task_vars['ansible_distribution'] = 'CentOS'
    action_module = ActionModule(dict(), dict())
    expected = 'CentOS'
    actual = action_module.get_distribution(task_vars)
    assert actual == expected

# Generated at 2022-06-23 08:21:08.438111
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    assert False  # TODO: implement your test here


# Generated at 2022-06-23 08:21:15.968110
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # unit test for the method perform_reboot
    # result is a bool which indicates whether the code run successfully or not. If the code
    # did not run successfully then the result is False and we will raise an error.
    result = False
    output = ""

    # check to see if the method perform_reboot is callable in the class. If not then we cannot run
    # perform_reboot.

# Generated at 2022-06-23 08:21:18.695708
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    e = TimedOutException('msg')
    assert e.message == 'msg'



# Generated at 2022-06-23 08:21:26.300595
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_spec = {
        'action': 'reboot',
        'version': '2.0',
        'delegate_to': 'localhost'
    }
    test_action = RebootActionModule(None, test_spec)

    assert test_action._task.action == 'reboot'
    assert isinstance(test_action, RebootActionModule)


# Generated at 2022-06-23 08:21:31.367255
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Unit test for case when control node is rebooted
    if False:
        raise AnsibleError('Running {0} with local connection would reboot the control node.'.format(self._task.action))

    # Unit test for case when check mode is enabled
    if True:
        return {'changed': True, 'elapsed': 0, 'rebooted': True}

    # Unit test for case when task variables is None
    if False:
        task_vars = {}

    # Unit test for case when result of super class run method is skipped or failed
    if True:
        result = {'skipped': True}
        return result
    if True:
        result = {'failed': True}
        return result

    # Unit test for case when an exception is raised in get_distribution

# Generated at 2022-06-23 08:21:44.921894
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    #from ansible.module_utils.basic import AnsibleModule
    from ansible.plugins.connection.local import Connection
    from ansible.utils.vars import combine_vars
    module_args = dict(
        test_command='/sbin/ls',
        reboot_timeout=600,
    )
    self = ActionModule(load_ansible_module=False)
    self._config = {}
    self._task = AnsibleTask()
    self._task.action = 'reboot'
    self._task.async_val = 0
    self._task.timeout = 0
    self._task.args = module_args
    self._connection = Connection(self._config)
    self._task.ansible_facts = dict()

# Generated at 2022-06-23 08:21:47.345674
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(None, None, None, None, None, None)
    assert action_module is not None

# Generated at 2022-06-23 08:21:48.788339
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    obj = TimedOutException()
    assert obj is not None



# Generated at 2022-06-23 08:21:56.918854
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    args = {'shutdown_command': 'shutdown', 'shutdown_timeout': '1'}

# Generated at 2022-06-23 08:22:08.631588
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    action_module = ActionModule(None)
    error_msg = "error_msg"

    def success_action(*args, **kwargs):
        return True

    def fail_action(*args, **kwargs):
        raise RuntimeError(error_msg)

    network_ok = False
    timeout_time = 1
    sleep_time = 0.26


    def check_network_ok(*args, **kwargs):
        nonlocal network_ok
        return network_ok

    with pytest.raises(TimedOutException):
        action_module.do_until_success_or_timeout(success_action, action_desc="success_action", reboot_timeout=timeout_time)


# Generated at 2022-06-23 08:22:11.332053
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    am = ActionModule(task=MagicMock(), connection=MagicMock(), play_context=MagicMock(), loader=MagicMock(), templar=MagicMock(), shared_loader_obj=None)
    am.do_until_success_or_timeout(action=MagicMock(), action_desc=MagicMock(), reboot_timeout=MagicMock(), distribution=MagicMock())


# Generated at 2022-06-23 08:22:15.743036
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 08:22:24.442122
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    action_module = ActionModule()
    task = Mock()
    play_context = Mock()
    task_vars = dict()

    play_context.check_mode = False
    task_vars['ansible_hostname'] = 'hostname'
    task_vars['ansible_distribution'] = 'distribution'

    task.action = 'reboot'
    task.async_val = 43200
    task.args = dict()

    result = action_module.perform_reboot(task_vars, 'distribution')
    assert {} == result


# Generated at 2022-06-23 08:22:36.374402
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    action_name = 'reboot'

    mocker_reboot = MagicMock()
    mocker_reboot_success = MagicMock()
    mocker_reboot_success.side_effect = [ValueError, None]

    action_module = ActionModule(mocker_reboot, action_name, mocker_reboot_success)
    distribution = "distribution"
    with pytest.raises(TimedOutException):
        action_module.do_until_success_or_timeout(action=mocker_reboot, action_desc="reboot check", reboot_timeout=10, distribution=distribution)
    mocker_reboot.assert_called_once_with(distribution=distribution)
    mocker_reboot_success.assert_called_twice()

# Generated at 2022-06-23 08:22:47.378925
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    fake_module = 'test_module'
    fake_class = 'ActionModule'
    fake_distribution = 'Linux'

    checks_file = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'checks.py')
    checks_data = open(checks_file).read()

    # run the script to create the mock module
    import imp
    checks = imp.new_module('checks')

# Generated at 2022-06-23 08:22:58.643477
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    task_vars = dict()
    distribution = dict()
    reboot_result = dict()
    result = dict()

    connection = Mock()

    my_task = dict(
        action='reboot'
    )

    # failed

# Generated at 2022-06-23 08:23:00.656004
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    tmp = None
    task_vars = {}
    obj = ActionModule(tmp, task_vars)
    distribution = 'Debian'
    assert obj.perform_reboot(distribution) == 'shutdown -r now'


# Generated at 2022-06-23 08:23:12.043456
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    """
    Test :meth:`ansible_collections.community.general.plugins.modules.reboot.ActionModule.deprecated_args`
    of the :class:`ansible_collections.community.general.plugins.modules.reboot.ActionModule` class.
    """
    module_args = {}
    module_args.update(args_from_varargs('test_command', 'uptime'))
    module_args.update(args_from_varargs('reboot_timeout', 120))
    module_args.update(args_from_varargs('post_reboot_delay', 1))

    # FUTURE: mock the warnings class to test for warning messages
    display_mock = mock.Mock()

# Generated at 2022-06-23 08:23:14.741728
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    mock_distribution = 'mock_distribution'
    mock_task = MagicMock(spec=Task, action='reboot')
    mock_task.args = {}
    action_module = ActionModule(mock_task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.get_shutdown_command_args(mock_distribution) == ''


# Generated at 2022-06-23 08:23:26.018948
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    # Setup
    task_vars_new = dict()
    task_vars_new['ansible_facts'] = dict()
    task_vars_new['ansible_facts']['distribution'] = "fake_distribution"
    task_vars_new['ansible_facts']['distribution_release'] = "fake_distribution_release"
    task_vars_new['ansible_facts']['distribution_version'] = "fake_distribution_version"
    mock_get_system_boot_time_side_effect = [
            "fake_previous_boot_time",
            "fake_current_boot_time",
    ]
    mock_distribution = "fake_distribution"
    mock_previous_boot_time = "fake_previous_boot_time"
    mock_action

# Generated at 2022-06-23 08:23:39.099444
# Unit test for constructor of class ActionModule
def test_ActionModule():
    results = {}
    connection_timeout = b'1000'
    connection_plugin = 'local'

    # set a fixture (mock) tempdir so we are not looking for
    # /tmp/ansible_reboot_payload
    tmpdir = tempfile.mkdtemp()


# Generated at 2022-06-23 08:23:49.127761
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    task_vars = {}
    action = ActionModule(task=Mock(args={}), connection=Mock(), play_context=Mock())

    distribution = 'redhat'
    boot_time = '2018-01-10 11:30:11'
    action._get_value_from_facts = Mock(return_value='not empty string')
    action.get_system_boot_time = Mock(return_value=boot_time)

    with pytest.raises(ValueError) as e:
        action.check_boot_time(distribution, boot_time)
        assert to_text(e) == 'boot time has not changed'

    boot_time = '2018-01-10 11:30:11'
    action.get_system_boot_time = Mock(return_value=boot_time)
    action.check

# Generated at 2022-06-23 08:23:56.598808
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module = ActionModule(connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Pass a distribution and a legacy 'reboots' argument, expect the legacy args to be used
    result = action_module.get_shutdown_command_args('SunOS')
    assert result == '-y -g0 -i5'

    # Pass a distribution and a modern 'shutdown_timeout' parameter, expect the new args to be used
    result = action_module.get_shutdown_command_args('Linux', shutdown_timeout=600)
    assert result == '-r +10'

    # Pass a distribution and a modern 'shutdown_timeout' parameter with a value of 0, expect no timeout

# Generated at 2022-06-23 08:24:08.240950
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action = ActionModule('test');

    # Test no distro, no distro facts, no reboot_timeout
    result = action.get_shutdown_command_args(None)
    assert result == "-r now"

    # Test no distro, no distro facts, with reboot_timeout
    result = action.get_shutdown_command_args(None, False, 30)
    assert result == "-r +30 now"

    # Test no distro, with distro facts
    result = action.get_shutdown_command_args(None, True)
    assert result == "-t 30"

    # Test no distro, with distro facts, with reboot_timeout
    result = action.get_shutdown_command_args(None, True, 30)
    assert result == "-t 30"

    # Test with distro, no distro facts

# Generated at 2022-06-23 08:24:09.882077
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    pass

# Generated at 2022-06-23 08:24:19.487432
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():

    # test validate_reboot success
    distribution = 'ubuntu'
    action_kwargs = {'previous_boot_time' : 'Tue 2017-09-26 15:28:10 EDT'}
    task_vars = {}
    module = ActionModule(task=FakeTask(), connection=FakeConnection(), play_context=FakePlayContext())
    display.vvv(module.validate_reboot(distribution, action_kwargs))

    # test validate_reboot failure
    distribution = 'ubuntu'
    action_kwargs = {'previous_boot_time' : 'Tue 2017-09-26 15:28:10 EDT'}
    task_vars = {}
    module = ActionModule(task=FakeTask(), connection=FakeConnection(), play_context=FakePlayContext())

# Generated at 2022-06-23 08:24:28.998842
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    actionmodule = ActionModule()
    distribution = "distribution"
    reboot_timeout = int(0)
    action_desc = "action_desc"
    action_kwargs = {"action_kwargs": "action_kwargs"}
    actionmodule.do_until_success_or_timeout(action=actionmodule.check_boot_time, reboot_timeout=reboot_timeout, distribution=distribution, action_kwargs=action_kwargs)
    return

if __name__ == '__main__':
    test_ActionModule_do_until_success_or_timeout()

# Generated at 2022-06-23 08:24:38.435219
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    mod = ActionModule({}, {}, {'action': 'reboot'}, {})
    mixed = ['bar', 'baz', {'qux': 'quux'}]
    mixed2 = ['bar', 'baz', 1]

    success = True

    try:
        mod.do_until_success_or_timeout(
            action=lambda: 5,
            action_desc='test func',
            reboot_timeout=10,
            distribution='redhat',
            action_kwargs={'foo': 'bar', 'bar': mixed, 'baz': mixed2})
    except Exception as e:
        success = False

    assert success, 'Timed out to early'

    success = False


# Generated at 2022-06-23 08:24:49.663778
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    task_vars = {
            'ansible_facts': {
                'distribution': 'Debian',
                'shutdown_binary': '/sbin/shutdown',
                'search_paths': ['/bin', '/sbin', '/usr/bin', '/usr/sbin']
                }
            }
    m = ActionModule(dict(action='test_action',
                          _uses_shell=False,
                          _raw_params='test_params',
                          _task_fields={'args': dict(action='test_action',
                                                     _uses_shell=False,
                                                     _raw_params='test_params',
                                                     _task_fields={'args': dict()})}),
                     task_vars=task_vars)

# Generated at 2022-06-23 08:24:57.973119
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    this_module = sys.modules[__name__]

    def do_nothing(distribution):
        raise Exception('Test Error')

    # test that ActionModule._do_until_success_or_timeout throws an exception
    with pytest.raises(TimedOutException) as err:
        action = ActionModule()
        action.do_until_success_or_timeout(
            action=do_nothing,
            action_desc='testing do_until_success_or_timeout',
            reboot_timeout=1,
            distribution='ubuntu'
        )
    assert "Timed out waiting for testing do_until_success_or_timeout (timeout=1)" in str(err)


# Generated at 2022-06-23 08:25:11.005572
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    # Make dummy module class with stubs
    class MyClass(object):
        def __init__(self):
            self._connection = ModuleStubConnection()
            self._task = ModuleStubTask()
            self.post_reboot_delay = 0
            self.DEFAULT_SUDOABLE = 'yes'

    # Define fixture data for tests
    my_distribution = 'my_distribution'
    my_original_connection_timeout = 1.0

    # Setup test class
    my_class = MyClass()

    # Run test
    result = my_class.validate_reboot(my_distribution, my_original_connection_timeout)

    # Check results
    assert result['failed'] == False
    assert result['rebooted'] == True
    assert result['changed'] == True


# Generated at 2022-06-23 08:25:21.682807
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action = 'reboot'
    host = 'tests.ansible.com'
    task = Task.load({
        'action': action,
        'args': {},
        'delegate_to': host
    })

    connection = mock.MagicMock()
    connection.transport = None
    connection.host = host

    task_vars = {
        'ansible_connection': 'network_cli',
        'ansible_network_os': 'ios',
        'ansible_ssh_host': host,
    }

    play_context = PlayContext()
    play_context.connection = 'network_cli'

    module = ActionModule(
        task,
        connection,
        play_context,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    #

# Generated at 2022-06-23 08:25:31.973498
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
  self = Mock()
  # Pass 4 fixtures
  m_get_distribution = Mock()
  m_get_distribution.valid_distributions = ['CentOS', 'Ubuntu', 'RedHat']
  self.get_distribution = m_get_distribution
  m_task_vars = Mock()
  m_task_vars.update({'ansible_distribution_file_variety': 'RedHat', 'ansible_distribution_version': '7.6'})
  self._task.args = {'wait_for_reboot': False}
  # Pass 1 fixtures
  # Set up mock for call get_distribution
  m_self = Mock(self)
  m_task_vars = Mock(m_task_vars)
  # Call method get_distribution with params (self, task_v

# Generated at 2022-06-23 08:25:44.650128
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    """Test ActionModule.validate_reboot."""

    # Arrange
    # mock the object
    am = MagicMock()
    # mock variables used in the method
    am.get_system_boot_time.side_effect = [
        "Fri Oct 30 14:44:34 UTC 2015", "Fri Oct 30 14:44:34 UTC 2015", "Fri Oct 30 14:44:34 UTC 2015",
        "Fri Oct 30 14:44:34 UTC 2015", "Fri Oct 30 15:18:11 UTC 2015"
    ]
    am.get_shutdown_command = "shutdown"
    am.get_shutdown_command_args = "-r"
    distribution = 'ubuntu'
    reboot_timeout = 60
    previous_boot_time = "Fri Oct 30 14:44:34 UTC 2015"

# Generated at 2022-06-23 08:25:57.871095
# Unit test for method get_system_boot_time of class ActionModule

# Generated at 2022-06-23 08:26:00.904572
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    try:
        raise TimedOutException("Testing")
    except TimedOutException as err:
        assert str(err) == "Testing"


# Generated at 2022-06-23 08:26:04.562119
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # Test:
    reboot_timeout = 10
    previous_boot_time = "Sat Jan  7 02:01:15 UTC 2017"

    # Execute:
    action_module = ActionModule()
    action_module.check_boot_time(previous_boot_time)

    # Verify:
    assert True

    # Cleanup:
    pass

# Generated at 2022-06-23 08:26:09.957894
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    instance = ActionModule()
    distribution = ''
    original_connection_timeout = None
    action_kwargs = ''
    instance.validate_reboot(distribution, original_connection_timeout, action_kwargs)

# Generated at 2022-06-23 08:26:18.315517
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # set up the Mocked ActionModule object
    action_module = get_ActionModule_mock()
    action_module._task.args['reboot_timeout'] = 10
    # Patch AnsibleModule so we don't exit on failure and can return the expected results
    with patch('ansible.modules.system.reboot.AnsibleModule') as ansible_module_mock:
        action_module._ansible_module = ansible_module_mock.return_value
        # Patch the execute_command function with a mock
        with patch.object(action_module, '_low_level_execute_command') as execute_command_mock:
            # Set up the desired results
            reboot_result = {'rc': 0, 'stderr': '', 'stdout': ''}

# Generated at 2022-06-23 08:26:20.736769
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    
    reboot_module = ActionModule()
    result = reboot_module.get_system_boot_time(distribution="freebsd")
    assert not len(result) == 0, "Failed to get boot time"


# Generated at 2022-06-23 08:26:22.546388
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    exception = TimedOutException()
    assert type(exception) is TimedOutException



# Generated at 2022-06-23 08:26:26.272066
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    # Create an empty instance of ActionModule class
    test_instance = ...
    # Call method deprecated_args of ActionModule class with *args and **kwargs
    test_result = test_instance.deprecated_args()
    # Verify the result
    assert ...

# Generated at 2022-06-23 08:26:33.783081
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # this method is cloned from action/reboot.py
    mock_task = MagicMock()
    mock_task.action = 'reboot'
    mock_task.args = {}

    mock_connection = MagicMock()
    mock_connection.reset = MagicMock()

    # Define expected results for check_boot_time
    expected_response = 'Tue, 17 Oct 2017 16:31:18 +0000'

    # Define test vars
    distribution = "RedHat"

    # Run the test
    test_class = ActionModule()
    test_class._low_level_execute_command = MagicMock(return_value=expected_response)
    test_class._task = mock_task
    test_class._connection = mock_connection


# Generated at 2022-06-23 08:26:45.146332
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    m_task_vars = {}
    m_play_context = mock.MagicMock()
    m_loader = mock.MagicMock()
    m_connection = mock.MagicMock()
    m_templar = mock.MagicMock()
    m_shared_loader_obj = mock.MagicMock()
    m_action = mock.MagicMock()
    m_task = mock.MagicMock()
    m_templar.template = lambda args: args
    m_task.args = {}
    m_task.action = 'reboot'
    m_task.action = 'reboot'
    with mock.patch.object(ActionBase, '__init__', lambda self, task, connection, play_context, loader, templar, shared_loader_obj: None):
        action_module_obj = Action

# Generated at 2022-06-23 08:26:52.720491
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TestActionModule(ActionModule):
        _task = {'args': {'msg': 'foobar'}}
        _play_context = PlayContext()
        _play_context.check_mode = True
        _play_context.network_os = 'foobar'
        _play_context.remote_addr = '1.2.3.4'

    am = TestActionModule()
    assert isinstance(am, ActionModule)



# Generated at 2022-06-23 08:26:57.920088
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    DIST_COMMANDS = {
        'Linux': 'lsb_release -si',
        'Solaris': 'uname -v',
        'AIX': 'uname -sr'
    }
    DEFAULT_DIST_COMMAND = 'uname -s'
    distribution = 'Linux'

    mocked_execute_command = MagicMock()

    mocked_execute_command.return_value = {
        'rc': 0,
        'stdout': to_bytes(distribution + '\n'),
        'stderr': to_bytes('')
    }

    actionModule = ActionModule(mocked_execute_command, {}, {'DEFAULT_DIST_COMMAND': DEFAULT_DIST_COMMAND, 'DIST_COMMANDS': DIST_COMMANDS})

# Generated at 2022-06-23 08:27:08.545322
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # Get all distributions
    distributions = ActionModule.DISTRIBUTIONS

    # Create action module instance
    module = ActionModule(connection=FakeConnection(), play_context=FakePlayContext(), loader=FakeLoader())

    # Create test data
    task_vars = {}

    # Test for each distribution
    for distribution in distributions:
        # Create fake value for distribution
        task_vars[distribution.lower()] = True
        # Check get_distribution return value
        assert module.get_distribution(task_vars) == distribution, 'Bad distribution returned: {0}'.format(module.get_distribution(task_vars))
        # Reset task_vars
        task_vars[distribution.lower()] = False

    # Test case when none of the facts is set
    task_vars = {}

# Generated at 2022-06-23 08:27:13.291339
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
	# Create a mock instance of `ActionModule`
	action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

	# Execute the method to be tested
	action_module.get_distribution({})


# Generated at 2022-06-23 08:27:27.851531
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.facts.system import distro

    action_module = ActionModule()
    action_module._connection = Connection()
    action_module._task = AnsibleTask({'action': 'reboot'})
    distribution = distro.LinuxDistribution()

    action_module.get_system_boot_time = MagicMock()
    action_module.get_system_boot_time.return_value = TEMPORARY_BOOT_TIME

    try:
        action_module.check_boot_time(distribution, TEMPORARY_BOOT_TIME)
    except Exception:
        assert False


# Generated at 2022-06-23 08:27:39.034932
# Unit test for method run_test_command of class ActionModule

# Generated at 2022-06-23 08:27:51.889622
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    hostvars = {}
    hostvars['ansible_system'] = 'Linux'
    hostvars['ansible_distribution'] = 'Ubuntu'
    hostvars['ansible_pkg_mgr'] = 'apt'
    hostvars['ansible_python_interpreter'] = '/usr/bin/python'

    action_module = ActionModule(dict(), None)
    action_module._task = dict()
    action_module._task['args'] = dict()
    action_module._task['args']['shutdown_command'] = '/sbin/shutdown'
    action_module._task['args']['search_paths'] = '/opt/bin /usr/bin'

    # check we have the correct search paths
    assert action_module.search_paths == '/opt/bin /usr/bin'



# Generated at 2022-06-23 08:28:02.537410
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    def mock_get_distribution(task_vars):
        return 'RedHat'
    def mock_get_system_boot_time(distribution):
        return 'Sat May 1 23:59:59 BST 2018'
    def mock_get_shutdown_command_args(distribution):
        return '+1'
    def mock_get_shutdown_command(task_vars, distribution):
        return '/sbin/shutdown'
    def mock_connection_reset():
        pass
    def mock_get_option(key):
        return 10
    def mock_set_option(key, value):
        return value
    def mock_low_level_execute_command(command, sudoable=False):
        return {'stdout': '', 'stderr': '', 'rc': 0}

# Generated at 2022-06-23 08:28:07.969673
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():

    # Input data for the unit test
    distribution = 'CentOS Linux 6.5'

    # Expected result
    expected_result = '-r now'

    # Unit test code
    am = ActionModule({'distribution': distribution}, None, None)
    actual_result = am.get_shutdown_command_args(distribution)

    # Verify the result
    assert expected_result == actual_result



# Generated at 2022-06-23 08:28:16.179744
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    b = action_plugin.ActionModule(task=MagicMock(), connection=MagicMock(), play_context=MagicMock())

    # Test when fact 'system_distribution' is present
    test_distribution = 'FreeBSD'
    test_facts = {'system_distribution': test_distribution}
    test_group = 'TEST_COMMANDS'
    test_key = 'DEFAULT_TEST_COMMAND'
    test_value = 'uptime -p'
    test_default_value = 'uptime'
    b.get_system_boot_time(test_facts)
    b._get_value_from_facts(test_group, test_facts, test_key)
    test_boot_time_command = test_value

# Generated at 2022-06-23 08:28:19.291432
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test that checks if the constructor creates a new instance of ActionModule
    action = ActionModule()
    assert isinstance(action, ActionModule)

# Unit tests for run() method

# Generated at 2022-06-23 08:28:20.926800
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    pass


# Generated at 2022-06-23 08:28:31.994164
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # happy path
    module = ActionModule(connection=None,
                          task_vars=dict(),
                          loader=None,
                          templar=None,
                          shared_loader_obj=None)
    assert module is not None
    assert module.DEFAULT_REBOOT_TIMEOUT == 1800
    assert module.DEFAULT_TEST_COMMAND == 'echo Success'
    assert module.DEFAULT_CONNECT_TIMEOUT == 5

# Generated at 2022-06-23 08:28:36.045722
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    module = ActionModule('wait_for_connection')
    distribution = 'TargetDist'
    assert(module.get_shutdown_command_args(distribution)=='now')