

# Generated at 2022-06-23 08:18:39.130797
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    # Create an instance of class ActionModule
    am = ActionModule()
    # Use method run_test_command of class ActionModule
    am.run_test_command('RedHat', distribution='RedHat')

# Generated at 2022-06-23 08:18:49.467756
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    # arrange
    ansible_module_class = 'ActionModule'
    test_ActionModule = ActionModule(ansible_module_class)
    test_action_desc = 'legacy.common.wait_for'
    test_reboot_timeout = 'test_reboot_timeout'
    test_distribution = '_distribution'
    test_AnsibleError = 'AnsibleError'
    test_original_connection_timeout = '_original_connection_timeout'
    test_TimedOutException = 'TimedOutException'
    test_TimedOutException_message = 'The timed out exception is raised.'
    # act
    test_ActionModule.validate_reboot(test_distribution, test_original_connection_timeout, test_reboot_timeout,  test_action_desc)
    # assert
    assert test

# Generated at 2022-06-23 08:18:50.931677
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    action_module = ActionModule(dict(), dict())
    assert action_module.get_system_boot_time('not_supported') == ''

# Generated at 2022-06-23 08:18:51.882484
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    # TODO fix this test
    assert False


# Generated at 2022-06-23 08:18:56.900104
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    am = ActionModule()
    am.set_task(DummyTask())
    task_vars = {'ansible_facts': {'distribution': 'RedHat'}}
    assert am.get_distribution(task_vars) == 'RedHat'



# Generated at 2022-06-23 08:19:05.775049
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    """Unit test for ActionModule's run_test_command method"""
    # Test a case in which the test command fails
    # and ensure that an exception is thrown
    class TaskMock(object):
        def __init__(self, action):
            self.action = action

    class ConnectionMock(object):
        def __init__(self, action, task, sudoable):
            self.action = action
            self.task = task
            self.sudoable = sudoable

        def run_test_command(self, distribution, **kwargs):
            raise RuntimeError("Test command failed")

    class ConnectionLowLevelMock(object):
        def __init__(self, action, task, sudoable):
            self.action = action
            self.task = task
            self.sudoable = sudoable

# Generated at 2022-06-23 08:19:06.837281
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
  v = ActionModule()
  v.run_test_command(task_vars=v)

# Generated at 2022-06-23 08:19:18.924123
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    args = dict()

    action_module = get_real_obj_for(ActionModule, args)
    distribution = 'Linux'
    result = action_module.get_shutdown_command_args(distribution)
    assert result == '-r now'

    distribution = 'SunOS'
    result = action_module.get_shutdown_command_args(distribution)
    assert result == '-g0 -y -i6'

    distribution = 'FreeBSD'
    result = action_module.get_shutdown_command_args(distribution)
    assert result == '-r now'

    distribution = 'OpenBSD'
    result = action_module.get_shutdown_command_args(distribution)
    assert result == '-r now'

    distribution = 'unknown'
    result = action_module.get_shutdown

# Generated at 2022-06-23 08:19:22.209116
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    exc = TimedOutException('test_TimedOutException message')
    assert str(exc) == 'test_TimedOutException message'



# Generated at 2022-06-23 08:19:29.436467
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    from ansible.errors import AnsibleError
    from ansible.module_utils.basic import AnsibleModule

    am = ActionModule(AnsibleModule(argument_spec={}), task=dict(action='reboot'))
    call_counts = {}
    def call_incr(func_name):
        def wrapped_action(*args, **kwargs):
            nonlocal call_counts
            if func_name not in call_counts:
                call_counts[func_name] = 0
            call_counts[func_name] += 1
            if call_counts[func_name] > 6:
                raise Exception()
            else:
                raise AnsibleError()
        return wrapped_action

    def mock_datetime_utcnow():
        nonlocal call_counts

# Generated at 2022-06-23 08:19:32.389736
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action = ActionModule({}, {}, {}, {})
    action.DEPRECATED_ARGS = {}
    action._task = {'args': {}}
    with pytest.raises(AnsibleError):
        action.deprecated_args()


# Generated at 2022-06-23 08:19:41.963733
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    play_context = MagicMock()
    task = MagicMock()
    connection = MagicMock()
    loader = MagicMock()
    tmp = MagicMock()
    # Instantiate ActionModule with fake_success action and with a timeout of 5 seconds
    am = ActionModule(play_context, task, connection, loader, tmp, action=fake_success, reboot_timeout=5)

    # The action should be called without fail and will return a result
    result = am.do_until_success_or_timeout(action=fake_success, action_desc='fake_success_test', reboot_timeout=5, distribution='fake_distribution')
    assert result is not None
    assert result['success'] is True
    assert result['fail'] is False
    assert result['desc'] == 'fake_success_test_result'

    # The action should

# Generated at 2022-06-23 08:19:47.091051
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    distribution = 'debian'
    original_connection_timeout = 'original_connection_timeout'
    action_kwargs = 'action_kwargs'
    action = ActionModule()
    result = action.validate_reboot(distribution, original_connection_timeout, action_kwargs)
    expected = {'rebooted': True, 'changed': True}
    assert result == expected

# Generated at 2022-06-23 08:19:48.191217
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    pass

# Generated at 2022-06-23 08:19:56.913774
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    # Create an instance of ActionModule
    action_module = ActionModule()

    # Mock task class with args {'boot_delay': '', 'test_command': '', 'reboot_timeout': '', 'pre_reboot_delay': '', 'msg': '', 'connect_timeout': '', 'check': '', 'connect_timeout_sec': '', 'reboot_timeout_sec': '', '_raw_params': '', '_uses_shell': '', '_ansible_selinux_special_fs': [], '_ansible_no_log': '', '_uses_delegate': '', '_ansible_check_mode': '', '_ansible_verbosity': '', '_ansible_syslog_facility': '', 'action': 'reboot'}
    task_instance = Task()
    task_

# Generated at 2022-06-23 08:19:59.148013
# Unit test for method deprecated_args of class ActionModule

# Generated at 2022-06-23 08:20:01.130038
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ActionModule.run(tmp=None, task_vars=None)

# Bridge method for ActionModule.run

# Generated at 2022-06-23 08:20:01.853284
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    assert True

# Generated at 2022-06-23 08:20:14.142163
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module = ActionModule()
    distribution = 'distribution'
    previous_boot_time = 'previous_boot_time'
    try:
        action_module.check_boot_time(distribution, previous_boot_time)
    except Exception as exception:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        traceback_details = {
                    'filename': exc_traceback.tb_frame.f_code.co_filename,
                    'lineno'  : exc_traceback.tb_lineno,
                    'name'    : exc_traceback.tb_frame.f_code.co_name,
                    'type'    : exc_type.__name__,
                    'message' : exception,
                    }
        traceback.print_exc()

# Generated at 2022-06-23 08:20:24.465785
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    test_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    test_distribution = 'TEST_DISTRIBUTION'
    test_previous_boot_time = 'TEST_PREVIOUS_BOOT_TIME'
    test_get_system_boot_time_result = 'TEST_BOOT_TIME'
    test_check_boot_time_result = 'TEST_CHECK_BOOT_TIME_RESULT'
    test_check_boot_time_failed = False

    @patch.object(ActionModule, '_low_level_execute')
    def test_check_boot_time_success(mock_low_level_execute):
        mock_low_level_execute.return_value = test_boot

# Generated at 2022-06-23 08:20:26.326143
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    exc = TimedOutException("Timed Out")
    assert str(exc) == "Timed Out"



# Generated at 2022-06-23 08:20:36.010120
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    from ansible.compat.tests import patch
    from ansible.module_utils.basic import AnsibleModule

    action_module = ActionModule(
        task=dict(),
        connection=dict(),
        play_context=dict(),
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    action_module.get_system_boot_time = lambda x: '2018-09-05 10:20:29'

    reboots = 0

# Generated at 2022-06-23 08:20:39.274078
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    distribution = ActionModule.get_distribution({'ansible_distribution': 'RedHat'})
    assert distribution == 'RedHat'



# Generated at 2022-06-23 08:20:41.950969
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    try:
        raise TimedOutException("message")
    except AnsibleError as e:
        assert "message" == to_native(e)



# Generated at 2022-06-23 08:20:49.952162
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # arrange

    namespace = 'ansible_collections.ansible.netcommon.plugins.modules'
    module_name = 'reboot'
    action_name = 'reboot'
    fake_task = Task(
        name=action_name,
        action=action_name,
        delegate_to='localhost',
        args={},
        task_vars={}
    )
    fake_play_context = PlayContext()
    fake_connection = Connection(play_context=fake_play_context)

    reboot_module = ActionModule(
        task=fake_task,
        connection=fake_connection,
        play_context=fake_play_context,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

# Generated at 2022-06-23 08:20:58.500110
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # parameters
    distribution = None
    previous_boot_time = None

    # response
    response = None

    # test 1
    # ActionModule.check_boot_time(distribution, previous_boot_time)
    response = ActionModule.check_boot_time(distribution, previous_boot_time)

    # test 2
    # ActionModule.check_boot_time(distribution, previous_boot_time)
    response = ActionModule.check_boot_time(distribution, previous_boot_time)

    # test 3
    # ActionModule.check_boot_time(distribution, previous_boot_time)
    response = ActionModule.check_boot_time(distribution, previous_boot_time)

    # test 4
    # ActionModule.check_boot_time(distribution, previous_boot_time)
    response

# Generated at 2022-06-23 08:21:11.134734
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    # TODO: I suppose that this could be encapsulated into a function with a proper unittest
    # setup.

    class MockOSDistro():
        def __init__(self, name):
            self.name = name

    class MockOS():
        def __init__(self, distro=None):
            self.distro = distro

    class MockTask():
        def __init__(self, action, args):
            self.action = action
            self.args = args

    class MockModuleLib():
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def low_level_execute_command(self, command, sudoable):
            return self

    # FUTURE: This could go into a setup/teardown if this

# Generated at 2022-06-23 08:21:12.667351
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    ex = TimedOutException("Fake Exception")
    assert str(ex) == "Fake Exception"



# Generated at 2022-06-23 08:21:18.581887
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    import datetime
    import time
    import pytest

    # Fixture that monkey-patches the check_boot_time and run_test_command functions to return an error
    # Used to test when validating the reboot fails
    @pytest.fixture
    def failed_mock_check_boot_time(mocker, monkeypatch):
        # Monkey patch the get_system_boot_time function to return a previous_boot_time (if exists)
        # so we can compare them

        # Must be a function that is callable by ActionModule class
        def mock_get_system_boot_time_with_previous_boot_time(self):
            return self._task.args.get('previous_boot_time')


# Generated at 2022-06-23 08:21:21.887345
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action = ActionModule(None, None, None, None)
    assert action.do_action(None) == None

# Generated at 2022-06-23 08:21:33.311394
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    # Set up, act, assert
    # Check that the validate_reboot method returns the expected value in the 'failed' key
    # of the method return value.
    #   - Failed is defined here as the system boot time not being different to the
    #     previous value passed to the method
    #
    # Note - this test could be expanded to test for other items in the return value
    #        like 'rebooted' and 'msg'
    #
    module = ActionModule()

    class MockSettings:
        def __getattr__(self, item):
            if item == 'connection_timeout':
                return "5"
            if item == 'connection_timeout_sec':
                return "5"
            return None

    class MockConnection:
        def get_option(self, option_name):
            return 5


# Generated at 2022-06-23 08:21:35.184142
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    assert True

# Generated at 2022-06-23 08:21:38.523700
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    module = MagicMock(ActionModule)
    module.DEPRECATED_ARGS = {}
    module._task.args = {}
    module._task.action = 'reboot'
    module.deprecated_args()


# Generated at 2022-06-23 08:21:43.614901
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action = AnsibleActionModule(action_name="test_action", task=Task(), connection=None, play_context=PlayContext(), loader=None, templar=None, shared_loader_obj=None)
    action.DEPRECATED_ARGS = dict()
    action._task.args = dict()
    action.deprecated_args()


# Generated at 2022-06-23 08:21:53.792365
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Initialize template context
    result = {
    }
    task_vars = {}
    distribution = ''
    # Pre-test initialization
    action_module = ActionModule()
    action_module._task = DummyClass()
    action_module._task.action = 'test'
    action_module._task.args = {
    }
    action_module._play_context = DummyClass()
    action_module._play_context.connection = 'test'
    action_module._play_context.check_mode = False
    action_module._low_level_execute_command = DummyClass()
    action_module._low_level_execute_command.return_value = {
        'rc': 0,
        'stdout': 'test',
        'stderr': 'test',
    }
    action_module._connection

# Generated at 2022-06-23 08:22:04.561918
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    am = ActionModule()
    am.__dict__['_task'] = { 'action' : 'reboot' }

    # test passing the test immediately
    result = am.do_until_success_or_timeout(action=lambda x: True, action_desc=None, reboot_timeout=10, distribution=None)
    assert result is None

    # test being timed out
    result = am.do_until_success_or_timeout(action=lambda x: False, action_desc=None, reboot_timeout=0.01, distribution=None)
    assert isinstance(result, TimedOutException)
    assert result.args[0] == 'Timed out waiting for None (timeout=0.01)'

# Generated at 2022-06-23 08:22:11.941269
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    args = dict()
    args['reboot_timeout_sec'] = 42
    set_module_args(args)
    distribution = 'Ubuntu'

    action = ActionModule(load_fixture('reboot_fixture.yaml', args), DUMMY_FIXTURE_PATH, task_vars = dict())
    action.do_until_success_or_timeout(action=action.check_boot_time, action_desc="last boot time check", reboot_timeout=30, distribution=distribution, action_kwargs=dict())
    assert True


# Generated at 2022-06-23 08:22:18.870552
# Unit test for constructor of class ActionModule
def test_ActionModule():
    as_root = [True, False]
    when = ['always', 'never']
    for user in as_root:
        for run in when:
            mod = ActionModule(
                task={"action": "reboot", "as_root": user, "when": run},
                connection=Mock(name='Mock Ansible connection'),
                play_context=Mock(name='Mock Ansible play context'),
                loader=Mock(name='Mock Ansible loader'))

# Generated at 2022-06-23 08:22:30.213907
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    # This test is for testing the method run_test_command of the class ActionModule
    # Input data
    my_am = ActionModule({}, {}, connection = AnsibleConnection(play_context = PlayContext(), new_stdin = None, defs = {}))
    my_am._connection = AnsibleConnection(play_context = PlayContext(), new_stdin = None, defs = {})
    my_am._task = Task(name = 'test', action = 'test action')
    my_am._task.args = {'test_command': 'whoami'}
    distribution = 'DEFAULT_TEST_DISTRIBUTION'
    # Expected output
    expected_output = "test_results"
    # Test execution
    my_am.run_test_command(distribution = distribution)
    actual = "test_results"


# Generated at 2022-06-23 08:22:39.693923
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    m = ActionModule(None, None, None, None)
    try:
        assert m.do_until_success_or_timeout(lambda x: True, 15, None, {}) == None
    except TimedOutException as e:
        assert False, 'Unexpected TimedOutException: ' + e.args
    try:
        m.do_until_success_or_timeout(lambda x: False, 1, None, {})
        assert False, 'Expected TimedOutException, but instead task succeeded'
    except TimedOutException as e:
        assert True # Expected TimedOutException

# Generated at 2022-06-23 08:22:42.295472
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_connection = MagicMock()
    mock_connection.transport = 'local'
    mock_task = MagicMock()
    mock_task.action = 'test_action'
    mock_task.args = {'test_arg': 'test_value'}
    am = ActionModule(mock_connection, mock_task)
    return am

# Generated at 2022-06-23 08:22:52.892578
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
	host_vars = {}
	host_vars['ansible_distribution'] = 'FreeBSD'
	host_vars['ansible_system'] = 'FreeBSD'
	host_vars['ansible_distribution_release'] = '11.3-RELEASE'
	host_vars['ansible_distribution_version'] = '11.3-RELEASE'
	tmp = None
	task_vars = {}
	task_vars['vars'] = host_vars
	module = ActionModule(loader=None, action_plugin=None, connection_plugin=None, task_vars=task_vars)
	module._task = {}
	module._connection = {}
	module.DEFAULT_REBOOT_TIMEOUT = 60
	module.DEFAULT_CONNECT_TIMEOUT = 60
	module._play

# Generated at 2022-06-23 08:23:00.065457
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    module_args = {'_ansible_check_mode': True, '_ansible_no_log': False, '_ansible_verbosity': 1, '_ansible_version': u'2.7.9', '_ansible_global_vars': {'gather_subset': [u'all'], 'gather_timeout': 10}}

# Generated at 2022-06-23 08:23:12.003405
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    class FakeHost():
        class FakeConnection():
            class FakeOptions():
                connection_timeout = None

            @staticmethod
            def reset():
                pass

            @staticmethod
            def get_option(option):
                return FakeConnection.FakeOptions().connection_timeout

            @staticmethod
            def set_option(option, value):
                FakeConnection.FakeOptions().connection_timeout = value

        @staticmethod
        def set_option(option, value):
            pass

        @staticmethod
        def get_option(option):
            return FakeConnection.FakeOptions().connection_timeout

        @staticmethod
        def reset():
            pass


# Generated at 2022-06-23 08:23:24.181331
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create task
    task_mock = mock.Mock()
    task_mock.action = 'reboot'
    task_mock.async_val = 10
    task_mock.notify = []
    task_mock.args = {'msg': 'test'}
    task_mock.register = None

    # Create loader
    loader_mock = mock.Mock()

    # Create templar
    templar_mock = mock.Mock()

    # Create display
    display_mock = mock.Mock()

    # Create play context
    play_context_mock = mock.Mock()
    play_context_mock.check_mode = False

    # Create connection
    connection_mock = mock.Mock()
    connection_mock.transport = 'ssh'

# Generated at 2022-06-23 08:23:37.333773
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_task = MagicMock()
    mock_connection = MagicMock()
    mock_play_context = MagicMock()
    mock_play_context.connection = 'local'
    mock_play_context.network_os = None
    module = ActionModule(mock_task, mock_connection, mock_play_context)
    assert module.DEFAULT_REBOOT_TIMEOUT == 300
    assert module.DEFAULT_CONNECT_TIMEOUT == 10
    assert module.DEFAULT_POST_REBOOT_DELAY == 0
    assert module.SUPPORTED_DISTRIBUTIONS == {'RedHat': {}, 'CentOS': {}, 'Fedora': {}, 'Ubuntu': {}}
    assert module.DEFAULT_SHUTDOWN_COMMAND == 'shutdown'
    assert module.DEFAULT_SHUT

# Generated at 2022-06-23 08:23:38.973836
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    pass


# Generated at 2022-06-23 08:23:44.551667
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Initialization of the test case
    # Setup of the test case
    # pre-conditions
    distribution = None
    task_vars = {}
    # Call of the method to be tested
    # ActionModule.perform_reboot(self, task_vars, distribution)
    # Testing of the results
    assert True == False # let's make this test failed!


# Generated at 2022-06-23 08:23:48.072755
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
  action = ActionModule()
  distribution = 'DEBIAN8'
  original_connection_timeout = None
  action_kwargs = None
  ret = action.validate_reboot(distribution, original_connection_timeout, action_kwargs)
  assert ret == {}



# Generated at 2022-06-23 08:23:48.870847
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    pass

# Generated at 2022-06-23 08:23:56.397997
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
  test_task_vars = dict()
  test_connection = dict()
  test_module_defaults = dict()
  test_module_defaults['__ansible_module_name'] = 'reboot'
  test_tmp = None
  test_module_path = None

  test_action_module = ActionModule(task=dict(), connection=test_connection, play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())
  
  with pytest.raises(AnsibleError) as excinfo:
    test_action_module._low_level_execute_command = MagicMock(return_value = {'rc' : 1, 'stdout' : '', 'stderr' : ''})
    test_action_module.check_boot_time('DEBIAN')

# Generated at 2022-06-23 08:24:02.847071
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()

    assert action_module.DEFAULT_REBOOT_TIMEOUT == 600
    assert action_module.DEFAULT_CONNECT_TIMEOUT == 5
    assert action_module.DEFAULT_WAIT == 0
    assert action_module.DEFAULT_SUDOABLE == False
    assert not action_module._supports_check_mode
    assert not action_module._supports_async



# Generated at 2022-06-23 08:24:04.782792
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    testobj = TimedOutException()
    assert testobj is not None


# Class to handle parallel execution using current connection type.

# Generated at 2022-06-23 08:24:15.013393
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():

    # If a value for distribution is not provided then the DEFAULT_REBOOT_ARGS should be returned
    distribution = None
    action = ActionModule()
    assert action.get_shutdown_command_args(distribution) == '-r'

    # Test that the distribution variables are used to map to the correct shutdown command args
    distribution = 'Linux'
    action = ActionModule()
    assert action.get_shutdown_command_args(distribution) == '-r'

    distribution = 'FreeBSD'
    action = ActionModule()
    assert action.get_shutdown_command_args(distribution) == '-r'

    # Test that the custom arguments override the distribution specific variables
    distribution = 'Linux'
    action = ActionModule()

# Generated at 2022-06-23 08:24:27.113702
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    def test_ActionModule_run_test_command_MOCK_low_level_execute_command_success(self):
        command_result = {"rc": 0}
        return command_result

    setattr(ActionModule, '_low_level_execute_command', test_ActionModule_run_test_command_MOCK_low_level_execute_command_success)

    distribution = "DEFAULT"
    action_module = ActionModule()
    assert_raises_regexp(Exception, "system successfully rebooted", lambda: action_module.run_test_command(distribution))

    def test_ActionModule_run_test_command_MOCK_low_level_execute_command_failed(self):
        command_result = {"rc": 1, "stderr": "stderr"}
        return command_result


# Generated at 2022-06-23 08:24:29.329096
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    # check if exception's name equals to the one we defined
    assert TimedOutException("").__class__.__name__ == 'TimedOutException'


# Generated at 2022-06-23 08:24:38.981967
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    """Test method get_distribution of class ActionModule"""
    # Initializing ActionModule class

# Generated at 2022-06-23 08:24:50.028861
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    fake_module = _ActionModule()
    fake_module._task.action = 'reboot'
    fake_module._task.args = dict((('wait_for_reboot', 0), ('reboot_timeout', 0), ('test_command', 0), ('connect_timeout', 0), ('connect_timeout_sec', 0)))
    fake_module.display = _Display()
    fake_module.display.warning = lambda x: x
    assert fake_module.deprecated_args() is None
    fake_module._task.action = 'os_reboot'
    fake_module._task.args = dict((('wait_for_reboot', 0), ('reboot_timeout', 0), ('test_command', 0), ('connect_timeout', 0), ('connect_timeout_sec', 0)))
    assert fake_module.deprecated_args() is None


# Generated at 2022-06-23 08:24:52.870908
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    am = ActionModule(mock.MagicMock())
    am.get_shutdown_command_args("centos7")


# Generated at 2022-06-23 08:25:00.340736
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    host = 'localhost'
    connection = connection_loader.get('local', None, task_uuid=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    task_vars = dict()
    module_name = 'test'
    module_args = dict()
    module_kwargs = dict()
    display = Display()
    am = ActionModule(task=None, connection=connection, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    am.deprecated_args()

# Generated at 2022-06-23 08:25:03.222997
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    test_obj = ActionModule()
    task_vars = {'ansible_distribution': 'debian', 'ansible_distribution_release': '9.1', 'ansible_distribution_version': '9.1'}
    expected = 'debian'
    result = test_obj.get_distribution(task_vars)
    assert result == expected

# Generated at 2022-06-23 08:25:14.133227
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # test with attr: task_vars
    task_vars = {}
    test_instance = ActionModule()
    assert test_instance.get_distribution(task_vars) == {'distribution': 'UNKNOWN', 'major_version': '', 'minor_version': ''}

    # test with attr: task_vars
    task_vars = {}
    test_instance = ActionModule()
    assert test_instance.get_distribution(task_vars) == {'distribution': 'UNKNOWN', 'major_version': '', 'minor_version': ''}

    # test with attr: task_vars
    task_vars = {}
    test_instance = ActionModule()

# Generated at 2022-06-23 08:25:18.746604
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    device_info = json.loads('{"network_api": "netconf", "username": "arista", "password": "arista", "port": "22", "host": "184.105.247.76"}')
    self = ActionModule(device_info)
    result = self.perform_reboot(device_info, 'Arista')
    if result:
        print("success")

# Generated at 2022-06-23 08:25:20.017890
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    re.compile("Fedora Core . . .*")


# Generated at 2022-06-23 08:25:23.653305
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module.DEFAULT_REBOOT_TIMEOUT == 300
    assert action_module.DEFAULT_SUDOABLE is False
    assert action_module.DEFAULT_CONNECT_TIMEOUT == 30

# Generated at 2022-06-23 08:25:33.264885
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # First, test the constructor.
    task_vars = dict(ansible_connection='ssh', ansible_user='foo', ansible_become_pass='bar', ansible_distribution='Ubuntu')
    connection_factory = ConnectionFactory(play_context=PlayContext())
    connection = connection_factory.create(task_vars['ansible_connection'], task_vars)
    module_executor = ModuleExecutor(connection, task_vars)
    am = ActionModule(connection, module_executor, task_vars, None, None, [])

    # Then try a test run
    am.run(task_vars=task_vars)

# Generated at 2022-06-23 08:25:35.037929
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:25:46.565144
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    # Data in format of "results": ["param1": value1, "param2": value2, ...]
    module = ActionModule()
    if AnsibleModule._debug:
        module.set_task(Task())


# Generated at 2022-06-23 08:25:47.973250
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module = ActionModule()
    # FUTURE: add test coverage



# Generated at 2022-06-23 08:25:53.057770
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    # Setup
    obj = ActionModule()
    distribution = 'RedHat'

    # Exercise
    result = obj.get_system_boot_time(distribution)

    # Verify
    assert result == 'Thu Aug 26 11:15:55 CDT 2015'

# Generated at 2022-06-23 08:26:02.958997
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    global is_unit_testing
    is_unit_testing = True

    # SETUP
    import mock
    from ansible.plugins.connection.local import Connection as LocalConnection

    class UnitTestActionModule(ActionModule):
        DEFAULT_SUDOABLE = False
        DEFAULT_CONNECT_TIMEOUT = 7.2

        def get_system_boot_time(self, distribution):
            # stub_time = datetime(2014, 2, 11, 21, 22, 19)
            # return stub_time.strftime("%a %b %d %H:%M:%S %Y")
            return 'Sun Feb  9 18:42:41 EST 2014'

        def get_shutdown_command(self, task_vars, distribution):
            return '/sbin/shutdown'


# Generated at 2022-06-23 08:26:15.592084
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action = ActionModule(None, MockTask(), MockConnection())
    action._task.args = {'pre_reboot_delay': None,
                         'post_reboot_delay': None,
                         'reboot_timeout': None,
                         'reboot_timeout_sec': None,
                         'connect_timeout': None,
                         'connect_timeout_sec': None}
    action.deprecated_args()
    action._task.args = {'reboot_timeout': None,
                         'reboot_timeout_sec': None,
                         'connect_timeout': None,
                         'connect_timeout_sec': None}
    action.deprecated_args()

# Generated at 2022-06-23 08:26:28.472498
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    task_vars = dict()
    class registered_var_mock():
        def __init__(self, value):
            self.value = value
    class connection_mock():
        def __init__(self):
            self._connection = True
            self._connected = True
            self._socket_path = '/test/test'
        def connect(self):
            return self
        def close(self):
            self._connected = False

# Generated at 2022-06-23 08:26:29.771425
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    print('not implemented')


# Generated at 2022-06-23 08:26:35.959530
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    # Arrange
    action_module = ActionModule(None, None, None)
    distribution = None
    expected = None

    # Act
    actual = action_module.get_system_boot_time(distribution)

    # Assert
    assertEqual(actual,expected)

# Generated at 2022-06-23 08:26:37.101757
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    pass # nothing to test


# Generated at 2022-06-23 08:26:45.402612
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    this_action_module = ActionModule()
    print(this_action_module.get_shutdown_command_args('CentOS'))
    print(this_action_module.get_shutdown_command_args('centos'))
    print(this_action_module.get_shutdown_command_args('Windows'))
    print(this_action_module.get_shutdown_command_args('win'))
    print(this_action_module.get_shutdown_command_args('win10'))
    print(this_action_module.get_shutdown_command_args(''))



# Generated at 2022-06-23 08:26:53.508080
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    module = AnsibleModule(
        argument_spec = dict()
    )
    module.params = {
        "sudo": True,
        "sudo_user": "test",
        "become": True,
        "become_method": "test",
        "become_user": "test",
    }
    action = ActionModule(
        module,
        {
            "ANSIBLE_MODULE_ARGS": module.params,
            "ANSIBLE_MODULE_CONSTANTS": {},
            "ANSIBLE_MODULE_REQUIRED_IF": {},
            "ANSIBLE_MODULE_KWARGS": {},
            "ANSIBLE_MODULE_REQUIRED_ARGS": [],
            "ANSIBLE_MODULE_ARGS_DOC": {},
        },
        "test"
    )


# Generated at 2022-06-23 08:27:05.718929
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_module = ansible.utils.module_docs.AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
        bypass_checks=True,
    )
    mock_module.check_mode = True
    mock_module._verbosity = 2
    mock_module._connection = 'local'
    mock_module._task_vars = {}

    reboot = ActionModule(mock_module, 'reboot')

    assert reboot._task.action == 'reboot'
    assert reboot._supports_check_mode is True
    assert reboot._supports_async is True
    assert reboot.DEFAULT_TEST_COMMAND == '/usr/bin/true'
    assert reboot.DEFAULT_SUDOABLE is True
    assert reboot.DEFAULT_REBOOT_TIMEOUT == 300
   

# Generated at 2022-06-23 08:27:08.588199
# Unit test for method get_shutdown_command of class ActionModule

# Generated at 2022-06-23 08:27:16.559500
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    x = ActionModule()

    # create the original constructor values
    task_vars = dict()
    sudoable=True
    connection=None
    play_context=None
    loader=False
    templar=None
    shared_loader_obj=None

    # call the constructor
    x.__init__(task_vars, sudoable, connection, play_context, loader, templar, shared_loader_obj)

    
    # When we do not have the distribution, return an error
    mocker.patch('ansible.module_utils.facts.processor.get_all_facts', return_value={})
    with pytest.raises(Exception):
        x.get_system_boot_time(distribution=None)

    
    
    
    
    
    
    
    
    
    
    
   

# Generated at 2022-06-23 08:27:27.673643
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    # Pass in 1 as a parameter to return DEFAULT_PLATFORM,
    # which is 'Linux' as stated in alternative_facts.get()
    _, module_params = get_test_variables_mock(1)

    # Use the instantiated class
    test_object = ActionModule()

    # Pass in module_params as test_object.task.args
    test_object._task.args = module_params
    # Set distribution to 'Linux'
    distribution = 'Linux'

    # Get the shutdown_command_args from get_shutdown_command_args()
    shutdown_command_args = test_object.get_shutdown_command_args(distribution)

    # Test shutdown_command_args returned is
    # '-P now' as stated in alternative_facts.get()

# Generated at 2022-06-23 08:27:35.363347
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():

    mock_self = create_autospec(ActionModule)

    mock_task_vars = {
        'ansible_distribution': 'foo',
        'ansible_distribution_release': '1.0',
        'ansible_distribution_version': 'x',
        'ansible_facts': {'bar': 'baz'},
        'ansible_os_family': 'qux'
    }

    mock_self._task.action = 'quux'

    with patch.object(ActionModule, '_low_level_execute_command', return_value={'rc': 0, 'stdout': 'foo', 'stderr': ''}) as mock_low_level_execute_command:
        result = mock_self._get_distribution(mock_task_vars)
        assert result == 'foo'




# Generated at 2022-06-23 08:27:38.444547
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    # Execute function call
    result = ActionModule().run_test_command(distribution='none')
    # Check for expected result
    assert result == None

# Generated at 2022-06-23 08:27:41.126503
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    try:
        raise TimedOutException("test")
    except TimedOutException:
        assert True


# Generated at 2022-06-23 08:27:43.756827
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    action_module = ActionModule()
    assert action_module.run_test_command is not None


# Generated at 2022-06-23 08:27:45.758567
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # TODO: Implement test
    pass

# Generated at 2022-06-23 08:27:50.338666
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # creating a class object
    obj = ActionModule()

    # calling the method do_until_success_or_timeout()
    obj.do_until_success_or_timeout(action_desc = "last boot time check", reboot_timeout = 2, distribution = "Redhat")


# Generated at 2022-06-23 08:27:57.665287
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    class FakeTask:
        def __init__(self):
            self.action = 'fake_action'
            self.args = {}

    config = ConfigParser()
    config.read(os.path.join(current_path, 'unittests/test_reboot.cfg'))
    config_object = 'reboot'

    class FakeConnection:
        config = config
        config_object = config_object

        def __init__(self):
            self.transport = 'fake_transport'

        def set_options(self, options):
            self.options = options

        def reset(self):
            pass

        def get_option(self, name):
            return self.options[name]

    class FakeModule:
        def __init__(self):
            self._connection = FakeConnection()


# Generated at 2022-06-23 08:28:08.607522
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():

    action_module = ActionModule()

    try:
        from unittest.mock import Mock, mock_open, call, patch
        from ansible.module_utils.six.moves import builtins
    except:
        from mock import Mock, mock_open, call, patch
        from ansible.module_utils.six.moves import builtins

    # Setup patch context to mock out the stubbed methods
    with patch.object(action_module, '_get_value_from_facts', autospec=True) as mock_get_value_from_facts:
        mock_get_value_from_facts.side_effect = [
            'some-shutdown-args'
        ]

        args = action_module.get_shutdown_command_args('RedHat')

        mock_get_value_from_facts.assert_has_

# Generated at 2022-06-23 08:28:15.087227
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    host = Mock()
    host.get_distribution.return_value = 'debian'
    host.get_boot_time.return_value = '2017-04-12 10:05:34'
    action = ActionModule(host, None)
    #'{"path": "some/path", "command": "some command"}')
    action.get_boot_time = MagicMock()
    action.get_boot_time.return_value = '2017-04-12 10:05:34'
    action.check_boot_time(distribuition='debian', previous_boot_time='2017-04-12 10:05:34')
    action.get_boot_time.assert_called_once_with('debian')
    host.get_boot_time.assert_called_once_with()


# Generated at 2022-06-23 08:28:24.469436
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Create the mock module so we can access its exit_json and fail_json methods
    module = Mock()
    module.check_mode = False
    module.exit_json = exit_json
    module.fail_json = fail

    # Create a mock task that sets the default ansible_os_family to Linux
    task = Mock()
    task.action = 'reboot'

    task_vars = {}
    task_vars['ansible_os_family'] = 'Linux'

    # Create a mock connection that can be accessed by the action module's _connection property
    connection = Mock()
    connection.transport = 'ssh'

    # Create a mock play context
    play_context = Mock()
    play_context.check_mode = False

    # Create an action module to test

# Generated at 2022-06-23 08:28:36.000850
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    task_vars = {}
    the_host = '192.168.1.1'
    the_username = 'song'
    connection_timeout = 10
    connection_timeout_sec = 10
    reboot_timeout_sec = None

    s = MockedModuleRunner()
    s.reset()
    s.init(task=MockedTask(), connection=MockedConnection(the_host, the_username, connection_timeout), play_context=MockedPlayContext(), loader=MockedLoader(), templar=MockedTemplar())

    s._task.args['reboot_timeout_sec'] = reboot_timeout_sec
    s._task.args['connection_timeout'] = connection_timeout
    s._task.args['connection_timeout_sec'] = connection_timeout_sec

    distribution = 'centos'