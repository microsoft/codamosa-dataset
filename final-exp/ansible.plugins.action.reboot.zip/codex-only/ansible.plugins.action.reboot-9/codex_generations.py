

# Generated at 2022-06-23 08:18:47.182832
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    os.path.exists = MagicMock(side_effect=lambda path: True if path == '/bin/sh' else False)

    m_shutdown_bin = MagicMock(spec_set=str)
    m_shutdown_bin.__contains__ = MagicMock(side_effect=lambda x: True if x == '/sbin/shutdown' else False)
    m_shutdown_bin.__getitem__ = MagicMock(side_effect=lambda x: '/sbin/shutdown' if x == 0 else '/sbin/shutdown')

    m_command_result = MagicMock(spec_set=dict)
    m_command_result.get = MagicMock(side_effect=lambda x: {'rc': 0, 'stderr': '', 'stdout': ''}[x])

    m_dat

# Generated at 2022-06-23 08:19:02.300317
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.action import ActionBase
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    class TestTaskQueueManager(TaskQueueManager):
        def __init__(self, inventory, variable_manager, loader, options, passwords, stdout_callback=None):
            self._inventory = inventory
            self._variable_manager = variable_manager
            self._loader = DataLoader()
            self._options = options
            self._stdout_callback = stdout_callback
            self.passwords = passwords

# Generated at 2022-06-23 08:19:12.254356
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import connection_loader

    # Create dataloader for the options
    data_loader = DataLoader()

    # Create the inventory from hostfile
    inventory_manager = InventoryManager(loader=data_loader, sources=["/etc/ansible/hosts"])

    # Create variable manager
    variable_manager = VariableManager(loader=data_loader, inventory=inventory_manager)

    # Create play_context
    play_context = PlayContext()
    play_context.remote_addr = 'localhost'
    play_context.remote_user = 'root'
    play_

# Generated at 2022-06-23 08:19:23.662562
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # Imports inside method so pytest doesn't try to import these modules globally
    import pytest
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.system.linux import LinuxDistribution

    action_module = ActionModule()
    facts = {'distribution': {'name': 'Red Hat Enterprise Linux Server', 'version': '7.1', 'id': 'rhel', 'pretty_name': 'Red Hat Enterprise Linux Server 7.1 (Maipo)', 'ansible_facts': {'distribution': 'RedHat', 'distribution_file_parsed': True, 'distribution_major_version': '7', 'distribution_release': 'Maipo', 'distribution_version': '7.1'}, 'distribution_version': '7.1'}}
    task

# Generated at 2022-06-23 08:19:30.271397
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 08:19:42.622901
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # create an instance of the Ansible exit_json class to pass back the result
    # to the Ansible engine
    fake_exit_json = AnsibleExitJson()

    # create the required arguments that would typically be provided by Ansible
    # when running a module
    module_args = {
        'distribution': 'deb',
    }

    # create a fake Ansible task object to use with our private action module
    module_action = ActionModule(
        task=AnsibleTask(load_module_spec=False, argument_spec={}),
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    # run the private action module code and capture the exit_json that it
    # generates

# Generated at 2022-06-23 08:19:44.512401
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    t = TimedOutException('test')
    assert t.message == 'test'



# Generated at 2022-06-23 08:19:57.365054
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    #default case
    task_vars = {'ansible_facts': {'distribution': 'MacOSX'}}
    action_module = ActionModule(connection='connection', play_context='play_context', loader='loader', templar='templar', shared_loader_obj='shared_loader_obj')
    action_module._task = Task()
    action_module._task.action = 'action'
    action_module._task.args = {'connect_timeout': 'connect_timeout'}
    action_module._low_level_execute_command = function_mock(name='_low_level_execute_command')
    action_module._low_level_execute_command.return_value = {'stdout': to_text('stdout'), 'rc': 0, 'stderr': to_text('')}
    action_

# Generated at 2022-06-23 08:20:02.533717
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # setup
    action_module = AnsibleActionModule(my_task, my_connection, my_play_context, my_loader)
    action_module._task.action = 'reboot'
    action_module._task.args = {}

    # test
    result = action_module.get_distribution(fake_install_facts_distro_name)

    # assert
    assert result == fake_install_facts_distro_name
    assert action_module.distribution == fake_install_facts_distro_name


# Generated at 2022-06-23 08:20:14.561492
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """Unit test for method run of class ActionModule."""
    from ansible.plugins.action.reboot import ActionModule

    # Set up a mock for parameters for the run method
    fake_tmp = 'fake_tmp'
    fake_task_vars = {'ansible_connection': 'fake_connection'}

    # Create an instance of the ActionModule class
    action_module = ActionModule()

    # Create a mock for the PluginLoader class
    fake_loader = Mock()

    # Create a mock for the AnsibleModule class
    fake_ansible_module = Mock()

    # Get the mocked version of the run method
    mocked_run = get_mocked_method(ActionModule, 'run', fake_tmp, fake_task_vars)

    # Call the mocked run method

# Generated at 2022-06-23 08:20:24.688166
# Unit test for method get_system_boot_time of class ActionModule

# Generated at 2022-06-23 08:20:29.344527
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    _task = Mock()
    _connection = Mock()
    _play_context = Mock()

    shutdown_command = ActionModule(_task, _connection, _play_context, '/dev/null', 'no', 'no').get_shutdown_command(1, 'linux')
    assert shutdown_command is not None, shutdown_command



# Generated at 2022-06-23 08:20:30.222902
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    pass


# Generated at 2022-06-23 08:20:35.718356
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    assert to_text(type(TimedOutException)) == "<class 'ansible_collections.ansible.community.plugins.module_utils.network.f5.timed_out_exception.TimedOutException'>"
    assert to_text(TimedOutException.__module__) == 'ansible_collections.ansible.community.plugins.module_utils.network.f5.timed_out_exception'


# Generated at 2022-06-23 08:20:46.857131
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    from ansible_collections.ansible.community.tests.unit.compat.mock import MagicMock, patch

    from ansible.utils.display import Display

    action = 'setup'
    task_vars = dict(
            ansible_distribution='Darwin',
            ansible_distribution_version='16.7.0',
            ansible_distribution_release='Sierra'
            )

    display = Display()

    with patch.object(Display, 'display', return_value=None, autospec=True) as mock_display:
        action_module = ActionModule(task=MagicMock(action=action), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

        #perform test
        result = action_module.get_system_boot_

# Generated at 2022-06-23 08:20:54.908006
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False,
        mutually_exclusive=[],
        required_together=[['reboot_timeout', 'reboot_timeout_sec']],
    )
    # Initialize the ActionModule object
    am = ActionModule(module=module, task=Task(), connection=Connection(), play_context=PlayContext(), loader=None, templar=None, shared_loader_obj=None)

    task_vars = {
        'ansible_os_family': 'Linux',
    }
    distribution = 'RedHat'
    expected_result = '/sbin/shutdown'
    actual_result = am.get_shutdown_command(task_vars, distribution)
    assert actual_result == expected_result


# Generated at 2022-06-23 08:20:58.626249
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    module = ActionModule()
    distribution = 'Fedora'
    answer = module.get_shutdown_command_args(distribution)
    assert answer == '-r now'

# Generated at 2022-06-23 08:21:11.271951
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action = ActionModule(
        {
            'ANSIBLE_MODULE_ARGS': {
                'shutdown_command_args': '-a -z -P now',
            },
            'module_setup': True,
            'suspend_check': True,
            'action': 'reboot',
        },
        PlayContext(),
        None,
        None,
        DataLoader(),
        None,
        None,
        None,
    )
    result = action.get_shutdown_command_args('Fedora')
    assert result == '-a -z -P now'


# Generated at 2022-06-23 08:21:12.813690
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    exception = TimedOutException('Error message.')
    assert exception.args[0] == 'Error message.'



# Generated at 2022-06-23 08:21:13.366120
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-23 08:21:17.874688
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():

    # Method is called by method run()
    
    # Args:
    # action_desc, reboot_timeout, action_kwargs, distribution
    
    # Only testing the default parameters given by method run()
    # action_desc == None
    # reboot_timeout == 
    # action_kwargs == None
    # distribution == 
    
    # The method doesn't return anything
    
    # This function will raise an exception if the test failed
    #assert(True)
    
    # Testing the test itself
    #assert(True)
    
    
    
    return


# Generated at 2022-06-23 08:21:30.934969
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    print("testing get_shutdown_command_args...")
    # Init
    action_module = ActionModule(
        task=MockTask(),
        connection=MockConnection(),
        play_context=MockPlayContext(),
        loader=None,
        templar=MockTemplar(),
        shared_loader_obj=None
    )

    action_module._task.args = {
        'shutdown_command_args': 'reboot-without-confirming'
    }

    # Test with explicit shutdown_command_args
    assert action_module.get_shutdown_command_args('redhat') == 'reboot-without-confirming'
    assert action_module.get_shutdown_command_args('solaris') == 'reboot-without-confirming'

    # Test with distributions that have specific shutdown_command

# Generated at 2022-06-23 08:21:44.512032
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Mock module_utils API
    module_loader = ModuleLoader()
    module_loader._load_module_source = Mock()
    ansible_version = ansible.__version__.split('.')
    min_version = [2, 2]

    # Mock Ansible API
    class MockAnsibleModule():
        def __init__(self, argument_spec):
            self.argument_spec = argument_spec

    class MockPlayContext():
        def __init__(self, check_mode=False, diff=False):
            self.check_mode = check_mode
            self.diff = diff

    class MockTask():
        def __init__(self, action, args):
            self.action = action
            self.args = args

    display = Display()

    # Mock AnsibleAPI objects
    connection = MockConnection('')

# Generated at 2022-06-23 08:21:54.511551
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Since the constructor of class ActionModule is a special method,
    # it can only be called by using super(). At this time, to write a unit
    # test for the constructor of class ActionModule, we have to use the
    # name of parent class as the type of this object.
    cobj = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert cobj.BOOT_TIME_COMMANDS['Linux']['CentOS'] == 'grep btime /proc/stat'
    assert cobj.BOOT_TIME_COMMANDS['Linux']['RedHat'] == 'grep btime /proc/stat'

# Generated at 2022-06-23 08:22:00.072940
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    """
    Unit test for validate_reboot() method of ActionModule

    We don't actually test the functionality of the method here, but we do verify
    that the method exists.
    """
    check_method_exists(ActionModule, 'validate_reboot')



# Generated at 2022-06-23 08:22:04.517290
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # mock variable
    task_vars = {}
    # expected result
    expected_result = 'shutdown'
    # run method test
    result = ActionModule().get_shutdown_command(task_vars)
    # assert expected result
    assert expected_result == result

# Generated at 2022-06-23 08:22:14.327350
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    class Connection:
        def __init__(self, transport, set_option, reset, get_option):
            self.transport = transport
            self.set_option = set_option
            self.reset = reset
            self.get_option = get_option

    class PlayContext:
        def __init__(self, check_mode):
            self.check_mode = check_mode

    class Task:
        def __init__(self, action, args):
            self.action = action
            self.args = args

    class ModuleResult:
        def __init__(self, result):
            self.result = result
            self.rebooted = False

    class PlayBook:
        def __init__(self, connection, play_context, task, module_result):
            self.connection = connection

# Generated at 2022-06-23 08:22:15.003609
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    pass

# Generated at 2022-06-23 08:22:25.081644
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    module = 'reboot'
    hostname = 'hostname'
    port = 'port'
    task = MockTask()

    action_module = ActionModule(task, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    task_vars = {}
    distribution = 'ansible_os_family'
    result = action_module.get_distribution(task_vars)
    assert result == distribution

    task_vars = {'ansible_facts': {'ansible_os_family': distribution}}
    result = action_module.get_distribution(task_vars)
    assert result == distribution


# Generated at 2022-06-23 08:22:28.523038
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action = ActionModule()
    distribution = 'Debian'
    shutdown_command_args = action.get_shutdown_command_args(distribution)
    assert shutdown_command_args == '-r now'


# Generated at 2022-06-23 08:22:40.969874
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    # Set up test variables
    distribution = 'faux_distribution'
    original_connection_timeout = 'faux_original_connection_timeout'
    action_kwargs = {'previous_boot_time': 'faux_boot_time'}
    # Set up mock objects
    ActionModule().do_until_success_or_timeout = MagicMock(return_value='faux_do_until_success_or_timeout_return')
    am = ActionModule()
    am.check_boot_time = MagicMock(return_value='faux_check_boot_time_return')
    am.run_test_command = MagicMock(return_value='faux_run_test_command_return')
    am._connection.reset = MagicMock(return_value='faux_reset_return')

# Generated at 2022-06-23 08:22:44.610162
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # If called with invalid distribution name, this should raise KeyError
    with pytest.raises(KeyError):
        am = ActionModule(None, None)
        am.get_distribution('Mock distribution')

# Generated at 2022-06-23 08:22:56.489910
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Setup test
    connection = Connection(transport='local')
    task = Task(action='reboot', args={'msg': 'Test ut'}, connection=connection)
    action_module = ActionModule(task=task, connection=connection)

    task_vars = {}
    tmp = ''
    distribution = 'Fedora'


# Generated at 2022-06-23 08:23:05.962224
# Unit test for method validate_reboot of class ActionModule

# Generated at 2022-06-23 08:23:09.920343
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # Vars
    action_module = ActionModule({}, {}, {})

    # Test
    try_reboot_for_distribution = action_module.get_distribution

    # Unit test for method get_shutdown_command of class ActionModule

# Generated at 2022-06-23 08:23:22.707372
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    context = Context(os.path.join(os.path.dirname(__file__), 'tasks', 'test_reboot.yml'), None, {}, C, display=Display(), loader=None)
    t = Task('test', context, user_data=dict())
    a = ActionModule(t, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    test_command_result = dict()
    try:
        a.run_test_command('centos', **{'test_command': 'false'})
    except Exception as e:
        test_command_result['stderr'] = e.stderr
        test_command_result['stdout'] = e.stdout

# Generated at 2022-06-23 08:23:27.602194
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    my_obj = ActionModule(
        task=dict(
            action='test_module'
        )
    )
    my_obj.do_until_success_or_timeout = Mock()
    my_obj.check_boot_time(distribution='distribution', previous_boot_time='previous_boot_time')
    assert my_obj.do_until_success_or_timeout.call_count == 1
    assert my_obj.do_until_success_or_timeout.call_args_list[0][0][0].__name__ == 'check_boot_time'

# Generated at 2022-06-23 08:23:33.069096
# Unit test for method deprecated_args of class ActionModule

# Generated at 2022-06-23 08:23:34.281516
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    pass



# Generated at 2022-06-23 08:23:40.430311
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    def fake_get_value_from_facts(self, arg1, arg2, arg3):
        return "LINUX_DISTRIBUTION"

    def fake__get_distribution(self):
        return "LINUX_DISTRIBUTION"

    distribution = ActionModule._get_distribution(fake_get_value_from_facts, fake__get_distribution)
    assert distribution == "LINUX_DISTRIBUTION"

# Generated at 2022-06-23 08:23:50.777883
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    # create mock
    mock = MagicMock()
    mock.DEFAULT_REBOOT_DELAY = 10
    mock.DEFAULT_REBOOT_TIMEOUT = 120
    mock.DEFAULT_TEST_COMMAND = 'whoami'
    mock.DEFAULT_BOOT_TIME_COMMAND = 'whoami'
    mock.REBOOT_DELAY = 10
    mock.REBOOT_TIMEOUT = 120
    mock.TEST_COMMANDS = {}
    mock.BOOT_TIME_COMMANDS = {}
    mock.DEFAULT_SUDOABLE = True
    mock.DEFAULT_CONNECT_TIMEOUT = 30

# Generated at 2022-06-23 08:23:52.645384
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    """ Function to test the method validate_reboot of class ActionModule. """
    pass



# Generated at 2022-06-23 08:23:53.546928
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    test_instance = TimedOutException()
    assert True



# Generated at 2022-06-23 08:23:55.865288
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # make sure that AnsibleModule can be instantiated with the following
    # args and succeeds
    assert AnsibleModule(argument_spec={})


# Generated at 2022-06-23 08:23:57.724452
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    return

# Generated at 2022-06-23 08:24:10.182713
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    from os import makedirs
    from shutil import copy

    from ansible.errors import AnsibleError
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.plugins.loader import action_loader
    from ansible.utils import context_objects as co

    from library.modules.action_plugins.systemd_reboot import ActionModule as SystemdRebootActionModule
    from library.modules.action_plugins.systemd_reboot.distros import SystemdRebootDistros

    # Create the ansible context
    display = Display()
    display.verbosity = 4
    task_vars = dict()
    loader = AnsibleLoader(task_vars, None)
    connection = Connection(loader=loader, display=display)
    connection.transport = 'local'
    connection._shell = None



# Generated at 2022-06-23 08:24:19.673753
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    def test_connection_reset(self):
        pass

    def test_get_value_from_facts(self, source, distribution, default_value):
        return 'test_fact'

    def test_get_distribution(self, task_vars):
        return 'centos'

    module = ActionModule()
    module._connection = Mock(spec_set=ConnectionBase)
    module._connection.get_option.side_effect = KeyError
    module.check_boot_time = Mock()
    module.validate_reboot = Mock()
    module.run_test_command = Mock()
    module._low_level_execute_command = Mock()

# Generated at 2022-06-23 08:24:27.682626
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    module = ActionModule(connection=MagicMock(), task=MagicMock(), loader=None, templar=None, shared_loader_obj=None)
    distribution = 'Debian'
    assert module.get_system_boot_time(distribution) == 'Wed Apr 1 12:08:00 UTC 2015'
    distribution = None
    assert module.get_system_boot_time(distribution) == 'Wed Apr 1 12:08:00 UTC 2015'


# Generated at 2022-06-23 08:24:40.405358
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module_params = dict(
        reboot_timeout=5,
        test_command="cmd",
    )
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.params = module_params.copy()

    action_module = ActionModule(module, 'reboot', module.params)
    action_module.get_distribution = MagicMock(return_value='linux')
    action_module.get_shutdown_command = MagicMock(return_value='cmd')
    action_module.get_shutdown_command_args = MagicMock(return_value='cmd')
    action_module._connection.transport = 'ssh'
    action_module._connection.get_option = MagicMock(return_value=1)
    action_module._connection.set_option = MagicMock()

# Generated at 2022-06-23 08:24:43.130706
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    try:
        raise TimedOutException()
    except TimedOutException as e:
        assert(e.args[0] == "")



# Generated at 2022-06-23 08:24:46.642413
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    exception = TimedOutException()
    assert exception is not None
    assert str(exception) == "Timed out"
    assert repr(exception) == "TimedOutException()"


# Generated at 2022-06-23 08:24:56.543115
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # This test will fail if the module is not defined properly
    # Before running this test, please make sure the module is installed
    module = '/path/to/action_plugins/reboot.py'
    p = plugin_loader.find_plugin(module)
    test_instance = p()

    # Now that we have the plugin instance, we need to simulate the args that
    # will be passed to the module along with the task. See the notes for the
    # test_ActionModule_run_async() test for an example.

    # It is okay to have an empty dict for task_args
    task_args = dict()

    # We need to set internal variables so that the module can find the
    # connection plugin implmentation and the play context
    connection_info = dict()
    task_internal_info = dict()

# Generated at 2022-06-23 08:25:02.123629
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    action_module = ActionModule()
    args = Mock(**{'_task.args.shutdown_command_arguments': "some_arguments"})
    expected_value = "/sbin/shutdown some_arguments"
    actual_value = action_module._get_shutdown_command(args, "Linux", 'LANG=C /sbin/shutdown $ARGUMENTS', 'shutdown', '/sbin')
    assert actual_value == expected_value

# Generated at 2022-06-23 08:25:05.620718
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    am = ActionModule(task=dict(action='reboot'), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert am.get_shutdown_command_args(distribution='RedHat') == '--no-wall now'
    assert am.get_shutdown_command_args(distribution='Ubuntu') == '-r now'


# Generated at 2022-06-23 08:25:15.238455
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    set_module_args(dict(
        arg=dict(type='dict'),
        arg_type_dict=dict(type='dict'),
        arg_type_list=dict(type='list'),
        arg_type_str=dict(type='str'),
        arg_type_bool=dict(type='bool'),
        arg_no_type=dict(default='test'),
    ))
    m = ActionModule(task=dict(action='test_action'), connection=dict(transport='local'), play_context={}, loader=Mock())
    assert m.deprecated_args() == None
    assert m.arg_type_dict.data == dict(type='dict')
    assert m.arg_type_list.data == dict(type='list')
    assert m.arg_type_str.data == dict(type='str')
   

# Generated at 2022-06-23 08:25:17.896808
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Test the constructor of class ActionModule
    """
    assert_raises(AnsibleError, ActionModule, dict())

# Generated at 2022-06-23 08:25:18.728848
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:25:30.625173
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    from ansible.utils.display import Display
    display = Display()
    self = ActionModule(None, None, None, '/path/to/playbook', display)
    self.DEFAULT_CONNECT_TIMEOUT = 5
    self.DEFAULT_SUDOABLE = True
    self.DEFAULT_REBOOT_TIMEOUT = 600
    self.post_reboot_delay = 0

    # Make a ConnectionMock
    class ConnectionMock:
        default_transport = 'local'
        transport = 'local'
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            self.task = task
            self.connection = connection
            self.play_context = play_context
            self.loader = loader
            self.templar = templar
           

# Generated at 2022-06-23 08:25:33.254765
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    timeout = TimedOutException()
    assert isinstance(timeout, TimedOutException)
    assert isinstance(timeout, Exception)



# Generated at 2022-06-23 08:25:36.303368
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Tested in tests/units/modules/utility/test_reboot.py
    pass

# Generated at 2022-06-23 08:25:39.000873
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass




# Generated at 2022-06-23 08:25:48.418480
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action = mock.Mock()
    action._task.action = 'reboot'
    action._task.args = {}
    action._low_level_execute_command = mock.Mock()
    command_result = {"rc": 0, "stdout": "Thu Jan  1 10:01:52 CST 1970\n", "stderr": ""}
    action._low_level_execute_command.return_value = command_result

    distribution = 'Ubuntu'
    previous_boot_time = 'Thu Jan  1 10:01:52 CST 1970'
    action.check_boot_time(distribution, previous_boot_time)
    action._low_level_execute_command.assert_called_once_with('who -b', sudoable=True)


# Generated at 2022-06-23 08:25:49.285452
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True

# Generated at 2022-06-23 08:25:50.388871
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    pass



# Generated at 2022-06-23 08:25:57.852204
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # Define class and method to be tested
    class TestActionModule(ActionModule):
        def get_distribution(self):
            return 'test_distribution'
    # Initialize TestActionModule object
    action_module = TestActionModule()
    # Test method get_distribution
    assert action_module.get_distribution() == 'test_distribution'

# Generated at 2022-06-23 08:25:59.677317
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    action = ActionModule()
    # somehow call get_system_boot_time
    # assert result

# Generated at 2022-06-23 08:26:01.950604
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    t = TimedOutException("foo")
    assert t.message == "foo"
    assert t.message == "foo"



# Generated at 2022-06-23 08:26:14.763159
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
  am = ActionModule()
  am.set_task(dict)
  am.set_connection(dict)
  am._connection.set_task_vars(dict)

  # Note: The first param of "set_task_vars" has been renamed from "task_vars" to "vars".

# Generated at 2022-06-23 08:26:23.960392
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.module_utils.connection import Connection
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.plugins import module_loader
    from ansible.plugins.loader import module_loader, add_all_plugin_dirs, find_plugin
    from ansible.plugins.strategy.linear import StrategyModule

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

# Generated at 2022-06-23 08:26:26.470173
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
  # Basic smoke test, to ensure the function is actually present
  module = ActionModule()
  module.run_test_command(None)

# Generated at 2022-06-23 08:26:31.973376
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    distribution="DEFAULT_DISTRIBUTION"
    original_connection_timeout=None
    action_kwargs=None
    result = action_module.validate_reboot(distribution, original_connection_timeout, action_kwargs)
    assert type(result) is dict


# Generated at 2022-06-23 08:26:43.955481
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    mock_airflow_db_hook = Mock()
    mock_low_level_execute_command = Mock()
    mock_low_level_execute_command.return_value = {'rc': 0}

    test_action_module = ActionModule(
        task = None,
        connection = None,
        play_context = None,
        loader = None,
        templar = None,
        shared_loader_obj = None
    )

    test_action_module.run_test_command(
        distribution = 'Ubuntu',
        low_level_execute_command = None
    )

    mock_low_level_execute_command.assert_called_once_with(
        '/bin/true',
        sudoable = True
    )



# Generated at 2022-06-23 08:26:47.740001
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    action_module_method_under_test = ActionModule()
    assert action_module_method_under_test.get_shutdown_command(None, None) is not None


# Generated at 2022-06-23 08:26:58.059241
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # pylint: disable=unused-argument
    module = ActionModule(argument_spec={}, supports_check_mode=True, bypass_checks=False)
    assert module.DEFAULT_REBOOT_TIMEOUT == 300
    assert module.DEFAULT_CONNECT_TIMEOUT == 10
    assert module.DEFAULT_TEST_COMMAND == '/usr/bin/true'
    assert module.DEFAULT_TEST_COMMANDS
    assert module.DEFAULT_SHUTDOWN_COMMAND == '/sbin/shutdown'
    assert module.DEFAULT_BOOT_TIME_COMMAND == '/bin/who -b'
    assert module.DEFAULT_BOOT_TIME_COMMANDS
    assert module.DEFAULT_SUDOABLE == False
    assert module.DEPRECATED_ARGS

# Generated at 2022-06-23 08:26:59.903244
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    try:
        raise TimedOutException("Test")
    except TimedOutException as e:
        assert "Test" in str(e)



# Generated at 2022-06-23 08:27:12.595637
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.reboot import ActionModule
    from ansible.plugins.action.reboot import _execute_command
    from ansible.plugins.action.reboot import _get_value_from_facts
    from ansible.plugins.action.reboot import do_until_success_or_timeout
    from ansible.plugins.action.reboot import get_shutdown_command
    from ansible.plugins.action.reboot import get_shutdown_command_args
    from ansible.plugins.action.reboot import perform_reboot
    from ansible.plugins.action.reboot import validate_reboot
    import os
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import merge_hash

    # Mock the module to avoid having to substitute environ variable
    action_module

# Generated at 2022-06-23 08:27:29.343714
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    # define expected values for the test
    expected_result = dict(
        rebooted=True,
        elapsed=0,
        failed=False,
        changed=True
    )
    expected_reboot_result = dict(
        rebooted=True,
        failed=False
    )
    # initialize test vars
    result = dict(
        rebooted=False,
        elapsed=0,
        failed=False,
        changed=False
    )
    action_kwargs = dict()
    reboot_result = dict(
        rebooted=False,
        failed=False
    )
    original_connection_timeout = 1
    reboot_timeout = 1

# Generated at 2022-06-23 08:27:38.762109
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    import copy
    import pytest

    task_vars = {}
    action_vars = {}

    task = DummyTask()

    test_dict = {'active_become': 'true'}

    am = ActionModule(task, task_vars, action_vars)

    assert isinstance(am, ActionModule)

    # Ensure we have a task
    assert isinstance(task, DummyTask)

    # Ensure we have a task_vars
    assert isinstance(task_vars, dict)

    # Ensure we have action_vars
    assert isinstance(action_vars, dict)

    # Ensure the default shutdown command matches expected
    am._task.action = 'reboot'

    # Ensure the default test command matches expected

# Generated at 2022-06-23 08:27:41.181838
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    module = ActionModule()
    module.run_test_command('test_distribution')



# Generated at 2022-06-23 08:27:45.864763
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Perform the unit test
    try:
        instance = ActionModule()
        instance.get_shutdown_command({}, {})
    except Exception as e:
        assert(False), e


# Generated at 2022-06-23 08:27:50.510772
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = {}
    test_args = {}
    test_task = Mock()

    # create object under test
    action_module = ActionModule(task=test_task)

    # test return value of constructor is instance of ActionModule
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-23 08:27:57.377193
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    # FIXME: unit tests should not hit the network
    import ansible.plugins.action.reboot

# Generated at 2022-06-23 08:28:08.337551
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():

    # fixture for get_shutdown_command
    def get_shutdown_command_fixture(self, task_vars, distribution):
        self._task.action = 'reboot'
        self.DEFAULT_SUDOABLE = False
        self._task.args = {'use_reboot': True, 'pre_reboot_delay': 0, 'post_reboot_delay': 0, 'connect_timeout': 10}


# Generated at 2022-06-23 08:28:13.466225
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    module = ActionModule()
    module.DEFAULT_CONNECT_TIMEOUT = 10
    module.DEFAULT_SUDOABLE = True

    #################################################################
    # Case 1: Success
    #################################################################
    # TODO:

    #################################################################
    # Case 2: Failure
    #################################################################
    # TODO:

    #################################################################
    # Case 3: Exception
    #################################################################
    # TODO:


# Generated at 2022-06-23 08:28:17.659533
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    action_module = ActionModule()
    distribution = "linux"
    try:
        action_module.check_boot_time(distribution=distribution)
    except Exception as e:
        assert type(e) == ValueError


# Generated at 2022-06-23 08:28:20.929290
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    self = ActionModule()
    self.distribution = 'DEFAULT_DISTRIBUTION'

    # Perform test
    self.get_system_boot_time(distribution=self.distribution)

    # Assertions
    assert True


# Generated at 2022-06-23 08:28:32.031348
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    # Mock a task with given facts for testing.
    task_vars = dict()
    task_vars['ansible_facts'] = dict()
    task_vars['ansible_facts']['DEBIAN_OS_FAMILY'] = 'DEBIAN'
    task_vars['ansible_facts']['OSFAMILY'] = 'DEBIAN'
    task_vars['ansible_facts']['REDHAT_OS_FAMILY'] = 'RedHat'
    task_vars['ansible_facts']['SYSTEMD_VERSION'] = '219'
    task_vars['ansible_facts']['SUSE_OS_FAMILY'] = 'SUSE'
    module = ActionModule(task=Task(), connection=None, play_context=None)

    # Test the default setting

# Generated at 2022-06-23 08:28:38.231274
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():

    _task=dict(action=ActionModule)
    _task.args=dict()
    a=ActionModule(_task,connection=None,play_context=None,loader=None,templar=None,shared_loader_obj=None)
    _task.args=collections.defaultdict(lambda:None, reboot_timeout="10")
    for _arg, _version in a.DEPRECATED_ARGS.items():
        _task.args[_arg]=None
        a.deprecated_args()
        assert _task.args[_arg] is None
