

# Generated at 2022-06-23 08:18:40.835613
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module_instance = ActionModule()
    assert isinstance(module_instance, ActionModule)



# Generated at 2022-06-23 08:18:50.315878
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Establish a mock connection
    fake_connection = Connection('local')
    # Establish a mock task
    task = Task('reboot')
    # Establish a mock action
    action = ActionModule(task, fake_connection, [], {}, 'local')
    # Establish a mock task vars
    task_vars = {}
    task_vars['ansible_os_family'] = 'Solaris'
    ####
    # Run the test
    ####
    result = action.run(task_vars=task_vars)
    # Test assertions
    # Test so that code fails with error in local connection
    assert result['failed']
    assert result['msg'] == 'Running reboot with local connection would reboot the control node.'
    assert result['rebooted'] == False
    assert result['skipped'] == False
   

# Generated at 2022-06-23 08:18:55.501831
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    class MockCommandResult():
        def __init__(self, rc, stdout, stderr):
            self.rc = rc
            self.stdout = stdout
            self.stderr = stderr

    class MockModule():
        def __init__(self):
            self.params = {}

    class MockAnsibleModule():
        def __init__(self):
            self.params = {}

    class MockTask():
        def __init__(self):
            self.args = {}

        def action(self):
            return 'reboot'

    class MockLowLevel():
        def __init__(self):
            self.connection = ''


# Generated at 2022-06-23 08:19:05.114955
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    module_args = {}
    result = {'ansible_facts': {'FACTS': {}}, 'ansible_facts_d': {'FACTS': {}}}
    hostvars_mock = {'ansible_facts': {'FACTS': {}}, 'ansible_facts_d': {'FACTS': {}}}

    ansible_module_reboot_instance = ActionModule(ansible_module_reboot_spec)
    task = Task()

    # This should return an empty tuple since _get_value_from_facts
    # is a method of the class ActionModule
    method = ansible_module_reboot_instance._get_value_from_facts

# Generated at 2022-06-23 08:19:14.761656
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    from ansible.compat.tests.mock import MagicMock, patch
    from ansible.compat.tests.mock import PropertyMock
    from ansible.executor.task_result import TaskResult
    import ansible.executor.task_result as task_result
    import ansible.plugins.action.reboot as reboot_module
    import ansible.plugins.action.reboot
    import ansible.plugins.connection.ssh

    ansible.plugins.connection.ssh.Connection = MagicMock()
    reboot_obj = reboot_module.ActionModule(MagicMock(), MagicMock())
    reboot_obj.get_boot_time_command = MagicMock()
    reboot_obj.get_boot_time_command.return_value = "uptime -s"
    fake_connection = MagicMock(name='connection')

# Generated at 2022-06-23 08:19:15.502281
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:19:20.570483
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # mock the required objects
    tmp = object()
    task_vars = object()

    # set up object
    a = ActionModule()
    a._supports_check_mode = True
    a._supports_async = True

    m_service = mock.MagicMock()
    m_osut = mock.MagicMock()
    m_re = mock.MagicMock()
    with mock.patch.multiple(
            a,
            _service=m_service,
            _get_distribution=m_osut,
            _get_reboot_command=m_re,
    ):
        # do it
        a._connection.transport = 'local'
        result = a.run(tmp, task_vars)
        # assert what we expect

# Generated at 2022-06-23 08:19:28.557152
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():

    # Define test parameters
    module_defaults = dict()
    module_defaults['_ansible_verbosity'] = 3
    module_defaults['connection'] = 'network_cli'
    module_defaults['network_os'] = 'ios'
    module_defaults['network_os_platform'] = 'iosxr'
    module_defaults['ansible_become'] = False
    module_defaults['ansible_become_method'] = 'disable'
    module_defaults['remote_user'] = 'test'
    module_defaults['ansible_check_mode'] = False
    module_defaults['ansible_diff_mode'] = False

    module_args = dict()
    module_args['reboot_timeout'] = 30
    module_args['shutdown_command'] = ''

    task_

# Generated at 2022-06-23 08:19:37.867800
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    class MockModule(object):
        def __init__(self, action):
            self.action = action

    test_action = ActionModule('test_action', 'test_path')

    test_action._low_level_execute_command = MagicMock()

    test_action._task.args = {'test_command': None}
    test_action._task.action = 'test_action'

    test_action.run_test_command('test_system')

    test_action._low_level_execute_command.assert_called_once_with('/usr/bin/test -x /usr/bin/python', sudoable=False)
    

# Generated at 2022-06-23 08:19:49.275784
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action = ActionModule()
    action._task.action = 'reboot'
    action._connection.transport = 'ssh'
    action._task.args = {'shutdown_timeout_sec': 5,
                         'reboot_timeout_sec': 30}
    action._play_context.connection = 'local'
    action.post_reboot_delay = 0

    task_vars = {'ansible_distribution': 'CentOS',
                 'ansible_distribution_major_version': '7',
                 'ansible_distribution_version': '7.4.1708',
                 'ansible_system': 'Linux'}

    result = action.get_shutdown_command_args(task_vars['ansible_distribution'])

# Generated at 2022-06-23 08:19:59.708049
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module = ActionModule()
    arguments = [{'distribution': 'Debian'}, {'distribution': 'Ubuntu'}, {'distribution': 'Redhat'}, {'distribution': 'SLES'}]
    expected_results = ['-r now', '-r now', '-r now', '-r now']
    for argument, expected_result in zip(arguments, expected_results):
        result = action_module.get_shutdown_command_args(**argument)
        assert result == expected_result


# Generated at 2022-06-23 08:20:13.005678
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    action_module = ActionModule(mock_task, mock_connection, play_context=mock_play_context)
    action_module._get_value_from_facts = (lambda x, y, z: {'PATH': '/bin'})
    action_module.get_shutdown_command = (lambda x, y: "/bin/shutdown")
    action_module.get_shutdown_command_args = (lambda x: "-r now")

    action_module.perform_reboot(mock_task_vars, 'Linux')
    action_module.perform_reboot(mock_task_vars, 'FreeBSD')
    action_module.perform_reboot(mock_task_vars, 'Solaris')

# Generated at 2022-06-23 08:20:20.746247
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils.connection
    from ansible.module_utils.connection import Connection
    from ansible.module_utils._text import to_text


# Generated at 2022-06-23 08:20:30.148437
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    # Check default values and not provided values
    task_vars = {}
    action_module = ActionModule(task=MagicMock(), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module.get_shutdown_command(task_vars) == '/sbin/shutdown'
    # Check provided command
    task_vars = {'shutdown_command': '/usr/bin/poweroff'}
    assert action_module.get_shutdown_command(task_vars) == '/usr/bin/poweroff'

# Generated at 2022-06-23 08:20:39.552425
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    """
    ActionModule.deprecated_args() unit test stub.
    """
    action_module = ActionModule()
    action_module._task = task_instance = MagicMock()
    task = task_instance.return_value = MagicMock(args={})
    action_module.DEPRECATED_ARGS = {}
    #action_module.deprecated_args()
    expected_msg = "Since Ansible {version}, {arg} is no longer a valid option for {action}".format(
                    version=action_module.DEFAULT_DEPRECATED_ARGS_VERSION,
                    arg='test_arg',
                    action=action_module._task.action)
    action_module.DEPRECATED_ARGS = {'test_arg': action_module.DEFAULT_DEPRECATED_ARGS_VERSION}

# Generated at 2022-06-23 08:20:51.011417
# Unit test for constructor of class ActionModule
def test_ActionModule():
    play = FakePlay()
    play_context = FakePlayContext()
    play_context.connection = 'smart'
    play_context.check_mode = False
    play.play_context = play_context
    play.playbook.password_prompt = None

    task = FakeTask()
    task.action = 'reboot'
    task.play = play
    task_vars = {}

    module = ActionModule(task, task_vars)

    assert module._task.action == "reboot"
    assert module._play.play_context.connection == "smart"
    assert module.action_name == "reboot"
    assert module._task.action == "reboot"
    assert module._task.args.get('connect_timeout_sec') == "30"

# Generated at 2022-06-23 08:21:05.518030
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    # Setup Mock task and ActionModule instances
    module_args = {
        'paths': ['/bin', '/sbin', '/usr/bin', '/usr/sbin', '/usr/local/bin', '/usr/local/sbin', '/usr/local/sbin/sbin'],
        'patterns': ['last'],
        'file_type': 'any'
    }
    set_module_args(module_args)
    task = Mock()
    action_module_instance = ActionModule(task, Mock(), task_vars=dict())
    action_module_instance._get_value_from_facts = Mock(return_value="last reboot")
    return_result = action_module_instance.get_system_boot_time("RedHat")
    assert (return_result == "last reboot")


# Generated at 2022-06-23 08:21:08.667046
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    try:
        raise TimedOutException("Timed out")
    except TimedOutException as e:
        assert e.args[0] == "Timed out"


# Generated at 2022-06-23 08:21:14.089580
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    """
    validate_reboot and test_command of the class ActionModule must be tested together

    To run this test, first use the test_ActionModule_perform_reboot to start the
    reboot process.  After the reboot, run this test.  The test will then successfully
    test the validate_reboot.

    When testing, set the post_reboot_delay to 30 seconds.
    """
    am = ActionModule()
    am.validate_reboot("post-reboot test command", 30)



# Generated at 2022-06-23 08:21:15.498054
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import ansible.plugins.action.systemd as systemd
    action = systemd.ActionModule({})

    assert action
    assert isinstance(action, ActionModule)

# Generated at 2022-06-23 08:21:18.917656
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Given
    action_module = ActionModule()

    # When
    result = action_module.perform_reboot(1, 2)

    # Then
    assert result == {'failed': True, 'msg': 'TODO'}


# Generated at 2022-06-23 08:21:31.911160
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    am = ActionModule('', {}, {})
    assert am.get_shutdown_command_args('redhat') == '-r now'
    assert am.get_shutdown_command_args('centos') == '-r now'
    assert am.get_shutdown_command_args('debian') == '-r now'
    assert am.get_shutdown_command_args('ubuntu') == '-r now'
    assert am.get_shutdown_command_args('freebsd') == '-r now'
    assert am.get_shutdown_command_args('solaris') == '-i 5 -g 0 -y'
    assert am.get_shutdown_command_args('openbsd') == '-r now'

# Generated at 2022-06-23 08:21:33.985492
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    assert True == True

# Generated at 2022-06-23 08:21:35.903425
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    assert type(TimedOutException) == type



# Generated at 2022-06-23 08:21:46.381122
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    action_module = ActionModule(None, None)
    action_module._task = {
        'action': 'reboot',
        'args': {
            'shutdown_command': '/usr/bin/shutdown'
        }
    }
    task_vars = {
        "ansible_distribution": 'RedHat',
        "ansible_distribution_major_version": '7',
        "ansible_distribution_version": '7.5'
    }

    expected = '/usr/bin/shutdown'
    actual = action_module.get_shutdown_command(task_vars, task_vars['ansible_distribution'])
    assert actual == expected

# Generated at 2022-06-23 08:21:48.835122
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    # Test target of method run_test_command of class ActionModule
    # Test with valid arguments
    # Test with invalid arguments

    pass


# Generated at 2022-06-23 08:21:57.083455
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    """Unit test when success is always achieved before timeout is reached
    """
    mock_task = mock.MagicMock()
    mk_action = ActionModule(mock_task, connection=mock.MagicMock(), play_context=mock.MagicMock())
    iteration_count = 3
    action_kwargs = {'previous_boot_time': 'previous_boot_time'}
    action_kwargs['distribution'] = 'distribution'

    test_action = mock.MagicMock(side_effect=lambda x: action_kwargs[x])

    mk_action.do_until_success_or_timeout(
        action=test_action,
        action_desc="last boot time check",
        reboot_timeout=5,
        **action_kwargs)

    assert test_action.call_count == iteration_

# Generated at 2022-06-23 08:22:08.729915
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.common.removed import removed
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.ansible_base_command import Command
    from ansible.module_utils.connection import Connection


# Generated at 2022-06-23 08:22:13.727200
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    fail_msg = 'timed out'
    e = TimedOutException(fail_msg)
    assert e.args[0] == fail_msg



# Generated at 2022-06-23 08:22:17.820982
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action = ActionModule()
    action._task = {}
    action._task.action = 'action'
    action._task.args = {}
    action._task.args['delay'] = 'delay'
    with pytest.raises(AnsibleError):
        action.deprecated_args()


# Generated at 2022-06-23 08:22:19.535379
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    ActionModule.get_shutdown_command()


# Generated at 2022-06-23 08:22:24.226940
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module is not None, "action_module should not be None"

# Run test cases

# Generated at 2022-06-23 08:22:36.537287
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    task_vars = {u'ansible_distribution': u'Debian'}
    module = ActionModule()
    module._task = {u'action': u'reboot'}
    module._low_level_execute_command = MagicMock(return_value={u'stdout': u'/usr/bin/shutdown', u'stderr': u'', u'rc': 0})
    search_paths = ['/bin', '/sbin', '/usr/bin', '/usr/sbin']
    # Unit test - Linux
    actual_result = module.get_shutdown_command(task_vars, u'Linux')
    assert_true(module._low_level_execute_command.called)
    assert_equal('/usr/bin/shutdown', actual_result)
    # Unit test - with shutdown_timeout
    module

# Generated at 2022-06-23 08:22:47.574040
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    os_facts = {
        "boot_time": "2017-04-10T09:48:46.324898+02:00",
        "system": "Linux"
    }
    os_version = "4.4.0-21-generic"
    os_platform = "Linux"
    os_distribution = "Ubuntu"
    os_full_distribution = "Ubuntu"
    os_architecture = "x86_64"
    os_family = "Distributor ID: DebianDescription: DebiansqueezeRelease: 6.0Codename: squeeze"
    os_variant = "Debian"
    os_type = "Linux"
    os_major_release = "6.0"

    # action module
    action_module = reboot()

    action_module._task.args = {}

    #

# Generated at 2022-06-23 08:22:48.817570
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    am = ActionModule()
    result = am.check_boot_time('distribution', 'command_result')
    assert result

# Generated at 2022-06-23 08:22:58.668326
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    obj = ActionModule()
    obj._paths = [
        '/sbin',
        '/usr/sbin',
        '/bin',
        '/usr/bin',
        '/local/bin',
        '/local/sbin'
    ]
    obj._connection = Connection()
    obj._connection._shell.exec_command = MagicMock(return_value={'rc': 0, 'stdout': '', 'stderr': ''})
    obj._task = Task()
    obj._task.action = 'reboot'

# Generated at 2022-06-23 08:23:00.011998
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module._supports_check_mode is True

# Unit tests for method get_distribution of class ActionModule

# Generated at 2022-06-23 08:23:10.281413
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    class TestActionModule(ActionModule):
        def __init__(self, task):
            self._task = task

    test_action_module = TestActionModule({})
    test_action_module.do_until_success_or_timeout(lambda: "Success", "Test 1", 10)

    test_action_module.do_until_success_or_timeout(lambda: "Success", "Test 2", 10, action_kwargs={'command': 'fail'})

    with pytest.raises(ValueError):
        test_action_module.do_until_success_or_timeout(lambda: "Success", "Test 3", 1)


# Generated at 2022-06-23 08:23:22.977288
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    mock_task = AnsibleMockTask()
    mock_task.args = {'shutdown_timeout_sec': 50,
                      'force': False,
                      'force_delay': True,
                      'init_sleep_sec': None}

    am = ActionModule(
        task=mock_task,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
    )

    test_distribution = 'default'
    output = am.get_shutdown_command_args(test_distribution)
    assert output == 'now'

    test_distribution = 'openbsd'
    output = am.get_shutdown_command_args(test_distribution)
    assert output == ''

    test_distribution = 'arch'

# Generated at 2022-06-23 08:23:32.177064
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    print("test_ActionModule_check_boot_time")
    action_module = ActionModule()
    # raising
    with pytest.raises(ValueError) as excinfo:
        action_module.check_boot_time(distribution='', previous_boot_time='')
    assert "boot time has not changed" in str(excinfo.value)
    # returns
    result = action_module.check_boot_time(distribution='', previous_boot_time='a')
    assert result is None

# Generated at 2022-06-23 08:23:38.053409
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    task_vars = { 'ansible_distribution': 'Ubuntu' }
    action_module = ActionModule(None, task_vars)

    # Stub action's return values
    def action(**kwargs):
        # print("in action")
        return 1
    # action.side_effect = Exception("ERROR in action")

    # Stub check_boot_time's return values
    def check_boot_time(distribution, previous_boot_time):
        # print("in check_boot_time")
        return 1
    # check_boot_time.side_effect = Exception("ERROR in check_boot_time")

    # Test do_until_success_or_timeout with return values as 1
    # check_boot_time should be called only once and action should be called 3 times
    # and we should get return value 1
    print

# Generated at 2022-06-23 08:23:48.633420
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    # Construct ActionModule object
    am = ActionModule(dict(ANSIBLE_MODULE_ARGS=dict()),
                      'systemd',
                      '/var/lib/awx/projects/automation/roles/automate_infrastructure/tasks/deploy_automate.yml',
                      3,
                      'systemd',
                      'main.py',
                      2,
                      'automate_infrastructure',
                      'ansible.builtin.systemd',
                      '$HOME',
                      'dummy1',
                      'dummy2')

    # Create function side-effect object
    class SideEffect(object):
        def __init__(self, *responses):
            self.responses = responses

# Generated at 2022-06-23 08:24:00.509652
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    for distro in [
        'Unsupported',
        'Amazon',
        'RedHatEnterpriseLinux',
        'RedHatEnterpriseLinux7',
        'Ubuntu',
        'Debian',
        'SUSEEnterpriseLinux',
        'SUSEEnterpriseLinux12',
        'SUSEEnterpriseLinux12SP2',
        'ScientificLinux'
    ]:
        from ansible.plugins.action import ActionModule
        am = ActionModule({'connection': 'local'}, {}, {'ansible_facts': {'ansible_distribution': distro}})
        if distro == 'Unsupported':
            try:
                am.get_system_boot_time('Unsupported')
            except Exception as e:
                assert 'is unsupported' in str(e)

# Generated at 2022-06-23 08:24:12.326034
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # Create an instance of ActionModule
    am = ActionModule()
    # Create a ASUCCESS_ANSIBLE_RESULT
    asuccess_ansible_result = AnsibleResult()
    asuccess_ansible_result.success = True
    asuccess_ansible_result.rc = 0
    asuccess_ansible_result.stdout = "System boot time"
    # Create a AFALIURE_ANSIBLE_RESULT
    afailure_ansible_result = AnsibleResult()
    afailure_ansible_result.success = False
    afailure_ansible_result.rc = -1
    afailure_ansible_result.stdout = "Failed to get system boot time"
    # Test check_boot_time with asuccess_ansible_result

# Generated at 2022-06-23 08:24:20.680195
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    """Test method check_boot_time of class ActionModule."""
    # Create test action module
    am = ActionModule({})
    
    # Prepopulate test action module with needed attributes
    am.DEFAULT_CONNECT_TIMEOUT = 5
    am.DEFAULT_REBOOT_TIMEOUT = 5
    am.DEFAULT_SUDOABLE = False
    am.DEFAULT_TEST_COMMAND = 'whoami'
    am.REBOOT_RESTART_COMMANDS = {
        'custom1': 'systemctl reboot',
        'custom2': 'shutdown -r now',
    }
    am.REBOOT_STOP_COMMANDS = {
        'custom1': 'systemctl poweroff',
        'custom2': 'shutdown -h now',
    }
    am._connection = None

# Generated at 2022-06-23 08:24:32.836775
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    host_system = MagicMock()
    host_system.get_distribution.return_value = 'debian'
    host_system_facts = {
        'BOOT_TIME_COMMANDS': {
            'debian': 'cat /proc/uptime | cut -f1 -d. | awk \'{print $1}\''
        },
        'DEFAULT_BOOT_TIME_COMMAND': 'cat /proc/uptime | cut -f1 -d. | awk \'{print $1}\''
    }
    host_system.ansible_facts = host_system_facts

    action_module = ActionModule(host_system)
    boot_time_command = 'cat /proc/uptime | cut -f1 -d. | awk \'{print $1}\''
    mock_output = '1597903841'

# Generated at 2022-06-23 08:24:46.864300
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Override the value of the update_cache AnsibleModule global variable set to True
    # to ensure the cache is not updated
    monkeypatch = MonkeyPatch([(ansible_module.update_cache, False)])
    monkeypatch.setattr(ActionModule, 'get_distribution', lambda self, task_vars: 'RedHat')
    monkeypatch.setattr(ActionModule, 'get_shutdown_command', lambda self, task_vars, distribution: 'shutdown')
    monkeypatch.setattr(ActionModule, 'get_shutdown_command_args', lambda self, distribution: '-r now')
    monkeypatch.setattr(ActionModule, 'get_system_boot_time', lambda self, distribution: '1')
    monkeypatch.setattr(ActionModule, 'run_test_command', lambda self, distribution: None)

    #

# Generated at 2022-06-23 08:24:56.674556
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_module_name = 'mock_module'
    mock_task = type('obj', (object,), {'action': 'mock_action', 'args': {}})
    mock_connection = type('obj', (object,), {'transport': 'mock_transport'})
    mock_play_context = type('obj', (object,), {'check_mode': True})

    mock_task_vars = {}
    mock_loader = type('obj', (object,), {'get_basedir': lambda: '/path/to/module'})
    mock_templar = type('obj', (object,), {'template': lambda x: x})

    # Initialize the module and call run()

# Generated at 2022-06-23 08:25:09.881749
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class TestModule(ActionModule):
        _task = None
        _connection = 'fake_connection'

        @property
        def _low_level_execute_command(self):
            return lambda cmd, sudoable=False: dict(rc=0, stdout='', stderr='')

    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext

    action = TestModule()

    # Test attributes initialized to default values
    assert action.DEFAULT_REBOOT_TIMEOUT == 600
    assert action.DEFAULT_CONNECT_TIMEOUT == 5
    assert action.DEFAULT_POST_REBOOT_DELAY == 0
    assert action.DEFAULT_SUDOABLE == False

    # Test attribute initialization
    task = Task()

# Generated at 2022-06-23 08:25:18.587764
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Preparing mock
    module_mock = MagicMock()
    module_mock.run.return_value = {'failed': False, 'reboot': True, 'elapsed': 3}

    # Preparing parameters
    tmp = None
    task_vars = {'ansible_distribution': 'RedHat'}

    # Preparing return values
    result = {'elapsed': 3, 'changed': True, 'rebooted': True}

    module_mock.get_distribution.return_value = 'RedHat'
    module_mock.get_shutdown_command.return_value = '/sbin/shutdown'
    module_mock.get_shutdown_command_args.return_value = '-r now'

# Generated at 2022-06-23 08:25:23.324283
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    my_obj = ActionModule()
    # Line: 'return os_distribution'
    # THIS LINE SHOULD BE REVISED to pass this unit test
    assert my_obj.get_distribution({}) == 'DEFAULT'

# Generated at 2022-06-23 08:25:32.013124
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    # Trigger exception when null input is given
    with pytest.raises(AnsibleError) as error:
        test_module = ActionModule()
        test_module.run_test_command(distribution='test', test_command='test')
    assert to_text(error.value) == 'Test command failed:  '

    # Trigger exception when wrong input is given
    with pytest.raises(AnsibleError) as error:
        test_module = ActionModule()
        test_module.run_test_command(distribution='test', test_command='wrong_command')
    assert to_text(error.value) == "Test command failed: 'wrong_command' not found "


# Generated at 2022-06-23 08:25:38.344282
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    # Configure mock values for method
    
    
    
    
    
    
    # Execute method
    obj = ActionModule()
    obj.deprecated_args()
    
    # Assert return values

# Generated at 2022-06-23 08:25:47.971162
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # Test with a success action
    reset_globals()
    am = ActionModule(task=mytask, connection=None, play_context=myplay)
    am._task.action = 'reboot'
    max_end_time = datetime.utcnow() + timedelta(seconds=5)
    am.do_until_success_or_timeout(
        action=lambda x, previous_boot_time: am.check_boot_time(x, previous_boot_time),
        action_desc="last boot time check",
        reboot_timeout=0,
        distribution="test",
        action_kwargs={"previous_boot_time": "test"})
    assert mydisplay.messages[0] == "reboot: last boot time check fail 'boot time has not changed', retrying in 1 seconds..."

# Generated at 2022-06-23 08:25:58.874200
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():

    #
    # The test server used here is a Clear Linux Server VM which requires a special 
    # command to be used to reboot the system.
    #

    class ActionModule(object):
        def _low_level_execute_command(self, cmd, sudoable=True):
            if re.search('clear-linux-shutdown', cmd):
                return

            raise RuntimeError("Invalid command: {0}".format(cmd))

    shutdown_command = '/usr/bin/clear-linux-shutdown'
    shutdown_command_args = '-r now'

    action_module = ActionModule()
    reboot_result = action_module.perform_reboot(dict(), 'clear-linux-os')

    # Verify that the call to perform_reboot completed without an error
    assert(reboot_result['failed'] == False)

    #

# Generated at 2022-06-23 08:26:10.013352
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    runner = ansible_runner.run('./test/unit/ansible_collections/ansible/cloud/plugins/modules/',
                                'reboot.yaml',
                                'kubernetes', 'centos', '7.0')
    assert runner.success
    assert runner.status == 'successful'
    assert runner.parsed is not None
    assert runner.parsed.get('msg') is None
    assert runner.parsed.get('failed') is False
    assert runner.parsed.get('rebooted') is True
    assert runner.parsed.get('elapsed') > 0


# Generated at 2022-06-23 08:26:18.340317
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    import time
    import traceback
    import unittest
    import uuid
    
    action_module_instance = ActionModule()

    class TimedOutException(Exception):
        def __init__(self, msg, **kwargs):
            super(TimedOutException, self).__init__(msg)
            self.kwargs = kwargs

    def mock_action(*args, **kwargs):
        action_name = kwargs.get('action_name')
        if action_name == 'fail':
            raise Exception('This action failed')
        elif action_name == 'timeout':
            raise TimedOutException('This action timed out', **kwargs)

        return kwargs.get('action_name', 'success')


# Generated at 2022-06-23 08:26:29.999487
# Unit test for method get_shutdown_command_args of class ActionModule

# Generated at 2022-06-23 08:26:43.349897
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_mod = ActionModule()
    assert action_mod.DEFAULT_REBOOT_TIMEOUT == 120
    assert action_mod.DEFAULT_REBOOT_DELAY == 0
    assert action_mod.DEFAULT_CONNECT_TIMEOUT == 5
    assert action_mod.DEFAULT_TEST_COMMAND == '/usr/bin/true'
    assert action_mod.DEFAULT_SUDOABLE is True

# Generated at 2022-06-23 08:26:44.601297
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    actionModule = ActionModule()
    actionModule.run_test_command('Linux')

# Generated at 2022-06-23 08:26:56.417082
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
  # Mock the class with specific attributes
  mock_action_module = mock.Mock(spec=ActionModule)
  # mock_action_module.DEFAULT_REBOOT_TIMEOUT = mock.Mock(return_value=20)
  mock_action_module.DEFAULT_REBOOT_TIMEOUT = 20
  mock_action_module.DEFAULT_CONNECT_TIMEOUT = 20
  mock_distribution = {'BOOT_TIME_COMMANDS':{'DEFAULT_BOOT_TIME_COMMAND': 'echo "2018-02-02 08:44:00"'}}
  original_connection_timeout = 5
  # Implement the mock
  mock_action_module.get_system_boot_time = mock.Mock(return_value="2018-02-02 08:44:00")
  # Call the method to be

# Generated at 2022-06-23 08:27:01.039375
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    with patch.object(ActionModule, 'get_system_boot_time') as mock_get_system_boot_time:
        mock_get_system_boot_time.return_value = 'Mon Dec 23 17:47:18 UTC 2019'
        action_module = ActionModule(None)
        action_module.check_boot_time('Ubuntu', 'Mon Dec 23 17:47:18 UTC 2019')
        assert mock_get_system_boot_time.call_count == 1

# Generated at 2022-06-23 08:27:13.901851
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test a case of successful reboot
    class TestArgs(object):
        def __init__(self, reboot_timeout):
            self.reboot_timeout = reboot_timeout

    class TestPlayContext(object):
        def __init__(self):
            self.check_mode = False
            self.allow_world_readable_tmpfiles = False

    class TestTask(object):
        def __init__(self):
            self.action = 'reboot'
            self.args = TestArgs(reboot_timeout=10)

    class TestModuleArgs(object):
        def __init__(self):
            self.path = ''
            self.connection = 'smart'
            self.system_facts = {}
            self.timeout = 10
            self.reboot_timeout = 10
            self.reboot_timeout_sec = 10

   

# Generated at 2022-06-23 08:27:20.108781
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    task_vars = {
        "ansible_connection": "network_cli"
    }

    def get_option(self, option):
        return 1 if option == 'connection_timeout' else None

    class ActionModule_validate_reboot(ActionModule):
        DEFAULT_SUDOABLE = True

        def __init__(self, *args, **kwargs):
            super(ActionModule_validate_reboot, self).__init__(*args, **kwargs)
            self.DEFAULT_TEST_COMMAND = 'success'
            self.DEFAULT_BOOT_TIME_COMMAND = 'previous_boot_time'

        def get_distribution(self, task_vars):
            return 'DEFAULT'


# Generated at 2022-06-23 08:27:22.538738
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    t = TimedOutException("This is my message")
    assert "This is my message" == str(t)



# Generated at 2022-06-23 08:27:33.193232
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    # Patch AnsibleModule.run_command to avoid individual test cases from
    # executing commands.
    with mock.patch.object(ActionModule, '_low_level_execute_command') as mock_run_command:
        mock_run_command.return_value = {'rc': 0, 'stdout': '', 'stderr': ''}
        action_module = ActionModule()
        # Call run_test_command with distribution=None and full args list
        action_module._task.args={'test_command': 'test-command', 'connect_timeout': 30, 'reboot_timeout': 300}
        action_module.run_test_command(distribution=None)
        # Check function call
        mock_run_command.assert_called_once_with('test-command', sudoable=False)


# Generated at 2022-06-23 08:27:45.861523
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():

    # test with no ansible_distribution or ansible_fqdn
    # expected to return the value of DEFAULT_DISTRIBUTION
    action_module = ActionModule()
    result = action_module.get_distribution({})
    assert result == 'DEFAULT_DISTRIBUTION'

    # test with ansible_distribution set
    # expected to return the value of ansible_distribution
    result = action_module.get_distribution({'ansible_distribution': 'test distribution'})
    assert result == 'test distribution'

    # test with ansible_distribution_version
    # expected to return the value of ansible_distribution
    result = action_module.get_distribution({'ansible_distribution': 'test distribution',
                                             'ansible_distribution_version': '1.0'})


# Generated at 2022-06-23 08:27:47.796338
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Run method
    action_module = ActionModule()
    action_module.perform_reboot()
    

# Generated at 2022-06-23 08:27:56.143330
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    # call with
    #    test_ActionModule_run_test_command()

    module = ActionModule()

    # call with test_command override
    module._task.args['test_command'] = '/bin/echo foo'
    module.run_test_command(distribution='centos')
    module._task.args.pop('test_command')

    # call with test_command from distribution
    module.run_test_command(distribution='centos')
    assert module._task.args.get('test_command') == 'cat /etc/issue'

    # call with test_command from distribution
    module.run_test_command(distribution='ubuntu')
    assert module._task.args.get('test_command') == 'cat /etc/issue'

    # call with no test_command from distribution
    module.run_test

# Generated at 2022-06-23 08:28:07.741440
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """
    Unit test for constructor of class ActionModule
    """

# Generated at 2022-06-23 08:28:13.882044
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    module = ActionModule('reboot', 'Ansible', play_context=MagicMock(), runner=MagicMock(), conn=MagicMock(), tmp=MagicMock())
    module._low_level_execute_command = MagicMock()
    module._low_level_execute_command.return_value = {
        'stdout': 'out',
        'stderr': 'error',
        'rc': 0
    }
    result = module.run({'ansible_distribution': 'redhat'})
    assert result['failed'] == False


# Generated at 2022-06-23 08:28:20.926961
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    task = dict(
        args=dict(
            reboot_timeout=60,
            connect_timeout=15
        )
    )

    distribution = 'fubar'
    os_family = 'Debian'
    action_module = ActionModule(task, dict())
    with pytest.raises(AnsibleError) as command_error:
        result = action_module.get_shutdown_command(task['args'], distribution)
        assert "Unable to find command"


# Generated at 2022-06-23 08:28:30.980903
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # prepare the test
    try:
        from ansible.plugins.connection.local import Connection
        connection = Connection(None, None)
    except ImportError:
        connection = None

    ActionModule.DEFAULT_SUDOABLE = True
    ActionModule.DEFAULT_CHECKMODE = False
    ActionModule.DEFAULT_REBOOT_TIMEOUT = 0
    ActionModule.DEFAULT_REBOOT_DELAY = 0
    module = ActionModule(connection, {}, None)

    # run the code to be tested
    action_result = module.perform_reboot({"reboot_timeout": 0}, "redhat")

    # assert the results
    assert action_result["failed"] == False
    assert action_result["rebooted"] == True



# Generated at 2022-06-23 08:28:39.879499
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # Set up mocked classes and objects
    am = ActionModule(None, None, None, None)
    # todo: set/reset TaskResult._async_seconds to cause tests to fail
    # todo: test exception throwing
    failed_test_result = TaskResult(None, False, False, None)
    failed_test_result._async_seconds = 0
    failed_test_result.failed = True
    failed_test_result.rebooted = False
    failed_test_result.msg = "Timed out waiting for last boot time check (timeout=0)"
    passed_test_result = TaskResult(None, False, False, None)
    passed_test_result._async_seconds = 0
    passed_test_result.failed = False
    passed_test_result.rebooted = True

    # Run unit tests
