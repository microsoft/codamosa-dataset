

# Generated at 2022-06-23 08:18:47.057872
# Unit test for method run_test_command of class ActionModule

# Generated at 2022-06-23 08:18:53.182189
# Unit test for method deprecated_args of class ActionModule

# Generated at 2022-06-23 08:19:05.881663
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    mocked_task = Mock()
    mocked_task.args = {
        'boot_time_command': None,
        'distribution': 'DEFAULT_BOOT_TIME'
    }

    mocked_self = Mock()
    mocked_self._task = mocked_task
    mocked_self._get_value_from_facts = MagicMock(return_value='DEFAULT_BOOT_TIME_COMMAND')
    mocked_self._low_level_execute_command = MagicMock(
        return_value=dict(rc=0, stdout='\nLinux localhost.localdomain 3.10.0-123.el7.x86_64 #1 SMP Wed Jun 18 16:35:19 UTC 2014 x86_64 x86_64 x86_64 GNU/Linux\n',
                          stderr=''))

   

# Generated at 2022-06-23 08:19:13.868219
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    host_vars = {
        'ansible_system': 'some_system',
        'ansible_distribution': 'some_distribution',
        'ansible_distribution_version': '7.3.3',
        'ansible_distribution_major_version': '7',
    }

# Generated at 2022-06-23 08:19:24.431009
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    # test_connection_reset
    #
    #     make sure the connection is reset if it fails to get the correct
    #     boot time due to the connection being shut off
    #
    #     verify:
    #       - system boot time is returned from check after reset
    #       - ansible connection failure is raised if a reset fails
    #
    # test_no_reboot
    #
    #     Test for an error when system boot time has not changed.
    #
    #     verify:
    #       - value error is raised
    #
    # returns: None
    #
    print('Test No. 1')
    a_module = ActionModule()
    #
    # test_no_reboot
    #
    #     Test for an error when system boot time has not changed.
    #
    #     verify:
   

# Generated at 2022-06-23 08:19:36.730303
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class MockConnection(object):
        def __init__(self):
            self._connection = None
            self.transport = 'mock'

        def set_option(self, key, value):
            self._connection = dict()
            self._connection[key] = value

        def get_option(self, key):
            if not self._connection:
                raise KeyError(key)
            return self._connection[key]

    task = dict(action=dict(__ansible_argspec=dict(spec=dict(), supports_check_mode=True, supports_async=True)))
    class_instance = ActionModule(task=task, connection=MockConnection())
    assert class_instance._supports_check_mode == True
    assert class_instance._supports_async == True


# Generated at 2022-06-23 08:19:48.562141
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.connection import Connection

    class TestActionModule(ActionModule):
        def get_system_boot_time(self, distribution):
            return super(TestActionModule, self).get_system_boot_time(distribution)

        def run(self, tmp=None, task_vars=None):
            self._supports_check_mode = True
            return super(TestActionModule, self).run(tmp, task_vars)


# Generated at 2022-06-23 08:19:57.180284
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    print("test_ActionModule_perform_reboot")
    task_vars={'ansible_fqdn': 'ubuntu', 'ansible_distribution': 'Debian'}
    action_module=ActionModule()
    action_module._task=MagicMock()
    action_module._task.action='reboot'
    action_module._task.args={}
    action_module._task.args.get=lambda :"shutdown -r now"
    action_module._low_level_execute_command=lambda x,y:{"rc":0}
    action_module.DEFAULT_SUDOABLE=True

# Generated at 2022-06-23 08:20:06.648576
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action = ActionModule()

    # Getting the type of 'action' (line 55)
    action_type_344 = module_type_store.get_type_of(stypy.reporting.localization.Localization(__file__, 55, 11), 'action')
    # Setting the type of the member '_supports_check_mode' of a type (line 55)
    module_type_store.set_type_of_member(stypy.reporting.localization.Localization(__file__, 55, 11), action_type_344, '_supports_check_mode', True_343)
    # SSA branch for the else part of an if statement (line 54)
    module_type_store.open_ssa_branch('else')
    
    
    # Call to isinstance(...): (line 56)
   

# Generated at 2022-06-23 08:20:15.756135
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    patched_module = patch.multiple(basic.AnsibleModule, exit_json=DEFAULT, fail_json=DEFAULT)
    patched_connection = patch.object(ActionModule, '_low_level_execute_command')
    with patched_module:
        with patched_connection as patched_connection:
            action = ActionModule(DEFAULT, DEFAULT)
            patched_connection.side_effect = [
                {'rc': 0, 'stdout': 'some stdout', 'stderr': ''}
            ]
            result = action.deprecated_args()
            assert patched_connection.call_count == 0
            assert not result


# Generated at 2022-06-23 08:20:29.806273
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():

    action_mock = ActionModule()
    action_mock._task = Mock()
    action_mock._task.action = 'reboot'
    action_mock._task.args = {'reboot_timeout': '500'}

    # Set up mock instances of objects used in ActionModule.check_boot_time()
    # Mock the method get_system_boot_time() to return a string
    action_mock.get_system_boot_time = Mock()
    action_mock.get_system_boot_time.return_value = 'Fri 2017-03-17 11:13:06'

    # Mock the method _low_level_execute_command() to return a dict
    action_mock._low_level_execute_command = Mock()

# Generated at 2022-06-23 08:20:37.968650
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    action_module = ActionModule()
    task_vars = {}

    # Test with empty values
    result = action_module.get_distribution(task_vars)
    assert result == 'DEFAULT'

    task_vars = {
        'ansible_os_family': 'RedHat'
    }

    # Test with valid values
    result = action_module.get_distribution(task_vars)
    assert result == 'RedHat'

    task_vars = {
        'ansible_os_family': 'RedHat',
        'ansible_distribution': 'Fedora'
    }

    # Test with valid values
    result = action_module.get_distribution(task_vars)
    assert result == 'Fedora'

# Generated at 2022-06-23 08:20:47.834159
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    a = ActionModule('test_task', {}, {}, {})

    mock_module_return_value = {
        'stdout': 'Oct 20 09:42:00 2018',
        'stdout_lines': [
            'Oct 20 09:42:00 2018'
        ],
        'warnings': [
        ]
    }

    mock_module = Mock()
    mock_module.run_command.return_value = mock_module_return_value

    with patch('ansible.plugins.action.reboot.ActionModule._execute_module', return_value=mock_module_return_value) as patched_module:
        a._low_level_execute_command = mock_module.run_command
        result = a.get_system_boot_time('DEBIAN')

# Generated at 2022-06-23 08:20:50.101362
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    am = ActionModule()
    assert am.do_until_success_or_timeout(action=am.do_until_success_or_timeout, action_desc="last boot time check", reboot_timeout=2, distribution="RedHat")

# Generated at 2022-06-23 08:21:03.033655
# Unit test for method run of class ActionModule

# Generated at 2022-06-23 08:21:11.565995
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action = ActionModule()
    # Channels:
    # 1. distribution = 'FreeBSD'
    distribution = 'FreeBSD'
    expected_return_value = [
        '-r',
        'now'
    ]
    actual_return_value = action.get_shutdown_command_args(distribution)
    assert expected_return_value == actual_return_value, "Expected {0}, Actual {1}".format(expected_return_value, actual_return_value)
    # 1. distribution = 'Windows'
    distribution = 'Windows'
    expected_return_value = [
        '/r',
        '/t',
        '60'
    ]
    actual_return_value = action.get_shutdown_command_args(distribution)

# Generated at 2022-06-23 08:21:15.132275
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    with pytest.raises(AnsibleError) as excinfo:
        ActionModule_old = ActionModule(dict(params= {'test_command': (1,2,3)}), dict(action='test'))
        ActionModule_old.deprecated_args()
    assert 'is no longer a valid option for test' in str(excinfo.value)


# Generated at 2022-06-23 08:21:20.317839
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    failed_test_msg = "Test failed"
    distribution = "distribution"
    previous_boot_time = "previous_boot_time"
    from mock import Mock
    from mock import patch
    patch1 = "ansible.plugins.action.reboot.ActionModule.get_system_boot_time"
    patch2 = "ansible.plugins.action.reboot.ActionModule.check_boot_time"
    patch3 = "ansible.plugins.action.reboot.ActionModule._task"
    action_module = ActionModule()
    with patch(patch1, Mock()) as get_system_boot_time, patch(patch2, Mock()) as check_boot_time:
        get_system_boot_time.return_value = "current_boot_time"

# Generated at 2022-06-23 08:21:32.638759
# Unit test for constructor of class ActionModule
def test_ActionModule():
    fixture = {
        'ansible_facts': {
            'distribution': 'Ubuntu',
            'distribution_version': '14.04'
        }
    }

    # Create a fake task and action plugin
    task = Task()
    task.action = 'reboot'
    task.args = {}
    task.set_loader({})
    task.register_ds = MagicMock()
    task.args.copy = MagicMock()
    action_plugin = ActionModule(task, fixture, None, MagicMock(), '', '', '')

    assert action_plugin.get_distribution(fixture) == 'Ubuntu'

# Generated at 2022-06-23 08:21:45.889510
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    # Make instance of '_low_level_execute_command' mock
    _low_level_execute_command_ = unittest2.mock.MagicMock(return_value={'rc': 0, 'stdout': '1234567890', 'stderr': ''})
    # Make instance of '_get_value_from_facts' mock
    _get_value_from_facts_ = unittest2.mock.MagicMock(return_value='')
    # Create instance of ActionModule
    action_module = ActionModule(_low_level_execute_command_, _get_value_from_facts_)
    # Make instance of 'AnsibleModule' mock
    ansible_module = unittest2.mock.MagicMock()

    ansible_module.check_mode = False
    ansible_module

# Generated at 2022-06-23 08:21:55.174550
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert action_module.DEFAULT_REBOOT_TIMEOUT == 300
    assert action_module.DEFAULT_CONNECT_TIMEOUT == 5
    assert action_module.DEFAULT_SUDOABLE == True
    assert action_module.DEFAULT_TEST_COMMAND == "/usr/bin/true"
    assert action_module.DEFAULT_BOOT_TIME_COMMAND == "uptime -s"
    assert action_module.get_distribution("") == "unknown"
    assert action_module._get_value_from_facts("", "", "") == ""
    assert action_module.post_reboot_delay == 0
    assert action_module.REBOOT_CACHE_FILE == '/tmp/ansible_reboot_data'

# Unit tests for get_shut

# Generated at 2022-06-23 08:21:55.987630
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    assert False, 'Tests not implemented'

# Generated at 2022-06-23 08:21:57.645443
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    ex = TimedOutException()
    assert ex is not None
    assert ex.args is not None
    assert ex.args == tuple()


# Generated at 2022-06-23 08:22:02.452672
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    _distribution = None
    _previous_boot_time = datetime.utcnow()
    _action_module_instance = ActionModule()
    _action_module_instance.check_boot_time(_distribution, _previous_boot_time)


# Generated at 2022-06-23 08:22:11.088414
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    # Pass an empty dict for 'task_vars' argument
    #
    # The warning does not assert the correct content
    # so only checking for the warning
    with warnings.catch_warnings(record=True) as warning:
        warnings.simplefilter('always', DeprecationWarning)
        m = ActionModule(None, dict())
        m.deprecated_args()
        assert len(warning) == 2
        assert str(warning[0].message) == 'Since Ansible 2.8, delay is no longer a valid option for reboot'
        assert str(warning[1].message) == 'Since Ansible 2.8, reboot_timeout is no longer a valid option for reboot'


# Generated at 2022-06-23 08:22:12.725812
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    expected = ""
    actual = self.get_shutdown_command_args()
    assert actual == expected

# Generated at 2022-06-23 08:22:24.043756
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Create a task
    action = 'reboot'
    task = Mock()
    task.action = action
    module_name = 'reboot_action'
    module_args = {}
    task.args = module_args

    # Create a runner
    loader = Mock()
    runner = Mock()
    runner.get_task_var = Mock()
    runner.get_task_var.side_effect = lambda *args, **kwargs: {}
    runner.get_vars = Mock()
    runner.get_vars.side_effect = lambda *args, **kwargs: {}
    runner.get_vault_secret = Mock()
    runner.get_vault_secret.side_effect = lambda *args, **kwargs: None
    play_context = Mock()

# Generated at 2022-06-23 08:22:27.716145
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    distribution = 'Linux'
    shutdown_command_args = '-r now'
    al = ActionModule()

    response = al.get_shutdown_command_args(distribution)
    assert response == shutdown_command_args

# Generated at 2022-06-23 08:22:40.171127
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    module = AnsibleModule(
        argument_spec=dict(
            reboot_timeout=dict(type='int'),
            reboot_timeout_sec=dict(type='int'),
            connect_timeout=dict(type='int'),
            connect_timeout_sec=dict(type='int'),
            test_command=dict(type='str'),
            test_connectivity=dict(type='bool'),
            pre_reboot_delay=dict(type='int'),
            msg=dict(type='str'),
            pre_reboot_sleep=dict(type='int'),
            post_reboot_check=dict(type='bool'),
            post_reboot_delay=dict(type='int'),
            pre_reboot_delay=dict(type='int'),
            pre_reboot_sleep=dict(type='int')
        ),
    )


# Generated at 2022-06-23 08:22:42.171060
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    exception = TimedOutException("TestException")
    assert str(exception) == "TestException"



# Generated at 2022-06-23 08:22:51.069920
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    host = DummyHost()
    host.__dict__['task'] = DummyDict(dict(action='reboot'))
    host.__dict__['_task'] = DummyDict(dict(args = dict(reboot_timeout = 60, reboot_timeout_sec = 60)))
    am = ActionModule(host)
    am._low_level_execute_command = DummyDict(dict(rc = 0, stdout='', stderr=''))
    distribution = DummyDict(dict(distribution = 'RedHat'))
    result = am.perform_reboot(distribution)
    assert result['failed'] == False
    assert result['rebooted'] == True


# Generated at 2022-06-23 08:23:03.108919
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # initialize the test
    test_obj = ActionModule()

    # the arguments that would normally be passed to the Ansible module
    module_args = {}

    # the Ansible facts, normally set by the Ansible module
    task_vars = {}

    # the test Ansible module
    class TestModule(object):
        def __init__(self, *args, **kwargs):
            self.params = module_args

    # initialize the test Ansible module
    module = TestModule()
    test_obj._task = module

    # set the Ansible facts
    test_obj._task.args = module_args
    test_obj._task.vars = task_vars

    # run the method under test
    test_obj.get_distribution(task_vars)


# Generated at 2022-06-23 08:23:10.016109
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # generate an instance of a ActionModule class
    action_module = ActionModule(action='reboot', task=dict(args={}), play_context=DummyPlayContext())

    # generate a task_vars dict
    task_vars = dict(ansible_facts={'distribution': 'debian'})

    # call the method with the arguments
    result = action_module.get_distribution(task_vars)

    # assert result
    assert result == 'debian'


# Generated at 2022-06-23 08:23:15.491216
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    module = ActionModule(self._task, self._connection, self._play_context, loader, self._templar, self._shared_loader_obj)
    args_result = module.get_shutdown_command_args('Debian')
    assert args_result == '-h now'


# Generated at 2022-06-23 08:23:23.126035
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    action = { 'action': 'reboot' }
    task = Task(action)
    m = ActionModule(task, {}, {'play_context': PlayContext()})
    m.DEPRECATED_ARGS = { 'hello': '2.0.0' }
    m._task.args = { 'hello': 'world' }

    assert m.deprecated_args() == None

    assert m._task.args == { 'hello': 'world' }

# Generated at 2022-06-23 08:23:36.201283
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mock_task = Mock()

    mock_task.action = 'reboot'
    mock_task.args = dict()

    mock_play_context = Mock()
    mock_play_context.connection = 'smart'
    mock_play_context.check_mode = False

    module = ActionModule(mock_task, mock_play_context)
    assert module.DEFAULT_REBOOT_TIMEOUT == 600
    assert module.DEFAULT_CONNECT_TIMEOUT == 10
    assert module.DEFAULT_BOOT_TIME_COMMAND == 'who -b'
    assert module.DEFAULT_TEST_COMMAND == '/bin/true'
    assert module.DIST_DEFAULT_BOOT_TIME_COMMAND == 'who -b'

# Generated at 2022-06-23 08:23:42.200229
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible_collections.ansible.community.plugins.module_utils.common.removed import removed_module
    from ansible_collections.ansible.community.plugins.module_utils.common.dict_transformations import recursive_diff
    import ansible.utils.template as template
    ActionModule.run(None, None)

# Generated at 2022-06-23 08:23:48.853886
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Test the constructor of class ActionModule"""

    # ActionModule(self, task, connection, play_context, loader, templar, shared_loader_obj)
    module = ActionModule(
        task=dict(),
        connection=MagicMock(),
        play_context=MagicMock(),
        loader=MagicMock(),
        templar=MagicMock(),
        shared_loader_obj=MagicMock())
    result = module.get_distribution(dict())
    assert result == 'Unknown'

# Generated at 2022-06-23 08:23:55.537076
# Unit test for method validate_reboot of class ActionModule
def test_ActionModule_validate_reboot():
    # Unit test for method validate_reboot of class ActionModule
    my_task = AnsibleTask()
    my_conn = AnsibleConnection('localhost')
    my_play_context = PlayContext()
    my_action = ActionModule(my_task, my_conn, my_play_context)

    # test no distribution supplied, check_boot_time will raise an exception
    try:
        my_action.validate_reboot(distribution=None)
    except TimedOutException as e:
        # this exception is expected, system boot time cannot be retrieved without a distribution
        pass
    else:
        assert False, 'calling validate_reboot with no distribution should have TimedOutException'

# Generated at 2022-06-23 08:24:06.745449
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():

    result = {}
    # 1: Distribution - value set, test_command set
    distribution = 'test'
    test_command = 'test'
    result['1'] = {}
    result[1]['test'] = True
    try:
        # a. test_command given, do not auto detect
        r = ActionModule._get_value_from_facts('TEST_COMMANDS', distribution, 'DEFAULT_TEST_COMMAND')
        if r == test_command:
            result[1]['a'] = True
        else:
            result[1]['a'] = False

    except Exception as e:
        result[1]['a'] = False

    # 2: Distribution - value set, test_command not set
    distribution = 'test'
    test_command = ''
    result['2'] = {}
    result

# Generated at 2022-06-23 08:24:10.928864
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    self = ActionModule()
    self.do_until_success_or_timeout(action=self.get_system_boot_time, reboot_timeout=10, distribution='default')


# Generated at 2022-06-23 08:24:12.356200
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    pass

# Generated at 2022-06-23 08:24:23.223548
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    module = ActionModule(dict(ANSIBLE_MODULE_ARGS=dict()), task=Task(), connection=Connection())
    distribution_to_boot_time_comands = {'Fedora': 'who -b'}
    distribution_to_default_boot_time_command = {'default': 'who -b'}
    module.FACTS_BOOT_TIME_COMMANDS = distribution_to_boot_time_comands
    module.DEFAULT_BOOT_TIME_COMMANDS = distribution_to_default_boot_time_command

    # check that input is not empty
    assert module.get_system_boot_time(distribution='Fedora')

    module.FACTS_BOOT_TIME_COMMANDS = {}
    assert module.get_system_boot_time(distribution='')

    # check that

# Generated at 2022-06-23 08:24:25.019586
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Testing constructor of class ActionModule
    # Case 1: Failed to call constructor
    # test = ActionModule()

    # Case 2: Call constructor action_reboot
    test = ActionModule()
    assert test.action_reboot

# Generated at 2022-06-23 08:24:27.008955
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    try:
        raise TimedOutException
    except TimedOutException:
        pass



# Generated at 2022-06-23 08:24:37.751094
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    action = Reboot()
    # expected values from above code
    expected_result = {'rebooted': True, 'changed': True, 'failed': False}
    # run method under test
    result = action.do_until_success_or_timeout(action=action.check_boot_time,
                                                action_desc="last boot time check",
                                                reboot_timeout=60,
                                                distribution='redhat',
                                                action_kwargs={'previous_boot_time': ''})
    # assertions
    assert result == expected_result, "Expected the result to be {0}, but got {1}".format(expected_result, result)

# Generated at 2022-06-23 08:24:49.118985
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():

    # Test setup
    # Implementation of mock object for _low_level_execute_command
    class _low_level_execute_command_return:
        def __init__(self, rc=None, stdout=None, stderr=None):
            self.rc = rc
            self.stdout = stdout
            self.stderr = stderr

    def _low_level_execute_command(command, **kwargs):
        if command == 'uptime -p':
            return _low_level_execute_command_return(rc=0, stdout='up 2 days', stderr='')
        elif command == 'cat /proc/uptime':
            return _low_level_execute_command_return(rc=0, stdout='172796.92 172796.92', stderr='')
       

# Generated at 2022-06-23 08:24:52.617569
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
  am = ActionModule(dict())

  result = am.check_boot_time(0, 0)
 
  assert result is None


# Generated at 2022-06-23 08:25:02.177128
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    class Mock_Task:
        def __init__(self):
            self.action = 'test_action'
        def args(self):
            return {
                'shutdown_command': None,
                'reboot_timeout': 10,
                'reboot_timeout_sec': 10,
                'connect_timeout': 15,
                'connect_timeout_sec': 15,
                'post_reboot_delay': 0,
                'test_command': 'hostname',
                'boot_time_command': None,
            }
    class Mock_Connection:
        def __init__(self):
            self.transport = 'ssh'
        def get_option(self, s):
            return 'connection_timeout_ssh_default'

    class Mock_Module_Utils_System:
        def __init__(self):
            self

# Generated at 2022-06-23 08:25:03.145338
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    # Ensure a Windows distribution return the correct values
    pass

# Generated at 2022-06-23 08:25:05.757389
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    e = TimedOutException("Blah blah blah")
    assert e.message == "Blah blah blah"



# Generated at 2022-06-23 08:25:16.074830
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    class ActionModule(object):
        def __init__(self, *args, **kwargs):
            self._task = DummyTask()
            self._connection = DummyConnection()
            self.DEFAULT_SUDOABLE = True

        def _low_level_execute_command(self, command, sudoable=False):
            return {'rc': 0, 'stdout': '', 'stderr': ''}

    class DummyTask(object):
        def __init__(self, *args, **kwargs):
            self.action = 'reboot'
            self.args = {'boot_time_command': 'uptime'}

    class DummyConnection(object):
        def __init__(self, *args, **kwargs):
            self.connection_id = 'local'

    action_module = ActionModule()


# Generated at 2022-06-23 08:25:25.229756
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    # Test ActionModule.get_system_boot_time when mock_get_system_boot_time returns an empty string
    mock_get_system_boot_time = MagicMock(return_value='')

    am = ActionModule(connection=None, runner=None)
    am.check_boot_time = mock_get_system_boot_time
    result = am.get_system_boot_time('MockDistribution')

    assert not result

# Generated at 2022-06-23 08:25:33.086502
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    logger = logging.getLogger()

    # Test standard execution
    action_module = ActionModule(logger)
    result = action_module.run_test_command('archlinux', test_command='echo testing')
    assert result is None
    # Test no command given
    result = action_module.run_test_command('archlinux')
    assert isinstance(result, Exception)
    # Test unknown distribution error handling
    result = action_module.run_test_command('unknowndistro')
    assert isinstance(result, KeyError)



# Generated at 2022-06-23 08:25:42.942951
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():

    test_action_module = ActionModule(ActionModule.DEFAULT_CONNECTION, None, task_vars=None, loader=None, templar=None, shared_loader_obj=None)

    # test with no shutdown_bin set and no shutdown_command set
    test_task_vars = {}
    test_distribution = 'DEFAULT'
    result = test_action_module.get_shutdown_command(test_task_vars, test_distribution)
    assert result == '/sbin/shutdown'


# Generated at 2022-06-23 08:25:49.224331
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    action_module = ActionModule()
    action_module._task.action = 'reboot'
    result = action_module.get_system_boot_time("")
    assert result



# Generated at 2022-06-23 08:25:56.972690
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    my_obj = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # call method
    try:
        my_obj.check_boot_time(distribution=None, previous_boot_time=None)
    except Exception as e:
        assert 'not implemented' in to_text(e)


# Generated at 2022-06-23 08:26:01.952699
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    obj = ActionModule(task=MagicMock(), connection=MagicMock(), play_context=MagicMock())
    args = {'foo': 'bar'}
    retval = obj.deprecated_args()
    assert retval is not None


# Generated at 2022-06-23 08:26:06.071155
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = AnsibleModule(argument_spec={})
    assert isinstance(module, ActionModule), '%r should be an instance of ActionModule' % module

# Generated at 2022-06-23 08:26:16.767476
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  distribution = ''
  task_vars = {}
  class Args(object):
    def __init__(self):
      self.connect_timeout = None
      self.connect_timeout_sec = None
      self.reboot_timeout = None
      self.reboot_timeout_sec = None
      self.test_command = None
      self.connect_default_timeout = None
      self.post_reboot_delay = None
      self.pre_reboot_delay = None
      self.msg = None
      self.reboot = None
      self.shutdown_command = None
      self.shutdown_command_args = None
      self.reboot_timeout = None
      self.reboot_timeout_sec = None
      self.connect_timeout = None
      self.connect_timeout_sec = None
      self.test

# Generated at 2022-06-23 08:26:21.414384
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    print('Testing get_system_boot_time of class ActionModule')
    print()
    print('Tests not yet implemented.')

# Generated at 2022-06-23 08:26:22.168825
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 08:26:24.158327
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    module = ActionModule()
    module.deprecated_args()

# Generated at 2022-06-23 08:26:26.915603
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    try:
        raise TimedOutException("Test TimedOutException")
    except TimedOutException:
        print("Test TimedOutException success")



# Generated at 2022-06-23 08:26:36.036835
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    action_module = Reboot()
    ret = action_module.get_shutdown_command({}, '')
    assert ret == '/sbin/shutdown'



# Generated at 2022-06-23 08:26:47.198758
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import netaddr
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import action_loader
    from ansible.compat.tests.mock import patch
    from units.mock.procenv import swap_stdin_and_argv
    from ansible.compat.tests.mock import MagicMock
    from ansible.compat.tests.mock import patch
    from ansible.utils.path import unfrackpath
    from ansible.errors import AnsibleError
    from ansible.plugins.connection.ssh import Connection as SSH
    from ansible.plugins.action.reboot import ActionModule as RebootActionModule
    from ansible.plugins.action.reboot import TimedOutException
    from ansible.plugins.action.reboot import check_type_str

# Generated at 2022-06-23 08:26:57.675393
# Unit test for method get_system_boot_time of class ActionModule

# Generated at 2022-06-23 08:27:03.864127
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule('reboot')
    assert module.DEFAULT_REBOOT_TIMEOUT == 300
    assert module.DEFAULT_CONNECT_TIMEOUT == 10
    assert module.DEFAULT_SUDOABLE == True
    assert module.DEFAULT_POWEROFF_TIMEOUT == 5
    assert module.DEFAULT_POST_REBOOT_DELAY == 10

# Generated at 2022-06-23 08:27:15.951267
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    host = 'localhost'
    connection = Connection('localhost')
    play_context = PlayContext()
    loader = DictDataLoader()
    variable_manager = VariableManager()
    variable_manager.set_host_variable(host, 'ansible_connection', connection)
    play = Play().load(dict(
      name = "Ansible Play",
      hosts = host,
      gather_facts = 'no',
      tasks = [
        dict(action=dict(module='reboot',
                         args=dict(use_shutdown_agent=True)))
      ]
    ), variable_manager=variable_manager, loader=loader)

    tqm = None
    completion_cache = None

# Generated at 2022-06-23 08:27:26.251198
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    # test get_distribution method
    from host_select import SelectHost
    from task_executor import TaskExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    # Create mock play and call get_distribution

# Generated at 2022-06-23 08:27:32.338515
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action_module = ActionModule(ActionModule._task, ActionModule._connection, ActionModule._play_context, ActionModule._loader, ActionModule._templar, ActionModule._shared_loader_obj)
    result = action_module.get_shutdown_command_args('ubuntu')
    assert result == ' -r now'


# Generated at 2022-06-23 08:27:40.671978
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    test_ActionModule = ActionModule()

    method_name = 'get_system_boot_time'
    method = getattr(ActionModule, method_name)

    # Default test

    distribution = 'my-distribution'
    expected_result = 'my-boot-time'
    with mock.patch('ansible_collections.community.general.plugins.modules.system.reboot.ActionModule._get_value_from_facts') as _get_value_from_facts_mock:
        _get_value_from_facts_mock.return_value = 'my-boot-time-command'
        with mock.patch('ansible_collections.community.general.plugins.modules.system.reboot.ActionModule._low_level_execute_command') as _low_level_execute_command_mock:
            _low_level

# Generated at 2022-06-23 08:27:52.954155
# Unit test for method get_distribution of class ActionModule
def test_ActionModule_get_distribution():
    task_vars = {'ansible_distribution': 'RedHat', 'ansible_facts': {'distribution': 'RedHat'},
                    'ansible_system': 'Linux', 'ansible_lsb': {'codename': 'RedHat', 'major_release': '2'}}

    am = ActionModule(None, None, None)
    am.set_task(MagicMock())

    # Test with ansible_facts.distribution exists
    am._task.args.get.return_value = None
    result = am.get_distribution(task_vars)
    assert result == 'RedHat'

    # Test with ansible_system == SunOS

# Generated at 2022-06-23 08:28:03.277541
# Unit test for method check_boot_time of class ActionModule
def test_ActionModule_check_boot_time():
    from ansible.plugins.action.reboot import ActionModule

    # Initialise object

# Generated at 2022-06-23 08:28:06.381529
# Unit test for method run_test_command of class ActionModule
def test_ActionModule_run_test_command():
    """
    Test that the method run_test_command()
    """
    test_obj = ActionModule()
    test_obj.run_test_command()
    pass




# Generated at 2022-06-23 08:28:13.390231
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    # Input parameters:
    #   action: Action name
    #   args: Action input arguments
    #   connection_info: Connection info
    #   task: Task object
    #   **kwargs: Not used
    # Expected result:
    #   Success. No exception is raised
    action = 'reboot'
    args = {}
    connection_info = {}
    task = Task()
    try:
        obj = ActionModule(action, args, connection_info, task, {})
    except Exception as e:
        pytest.fail("An exception was raised: {0}".format(str(e)))


# Generated at 2022-06-23 08:28:14.219761
# Unit test for method get_system_boot_time of class ActionModule
def test_ActionModule_get_system_boot_time():
    pass

# Generated at 2022-06-23 08:28:20.012118
# Unit test for method get_shutdown_command_args of class ActionModule
def test_ActionModule_get_shutdown_command_args():
    action = ActionModule(None, None, None, None)
    assert action.get_shutdown_command_args('ubuntu') == '-r now'
    assert action.get_shutdown_command_args('freeBSD') == '-r'
    assert action.get_shutdown_command_args('openBSD') == '-r'
    assert action.get_shutdown_command_args('gentoo') == '-r now'
    assert action.get_shutdown_command_args('amazon') == '-r now'
    assert action.get_shutdown_command_args('centos') == '-r now'
    assert action.get_shutdown_command_args('redhat') == '-r now'
    assert action.get_shutdown_command_args('fedora') == '-r now'

# Generated at 2022-06-23 08:28:30.700419
# Unit test for method get_shutdown_command of class ActionModule
def test_ActionModule_get_shutdown_command():
    assert ActionModule().get_shutdown_command(task_vars={}, distribution='CENTOS') == '/sbin/shutdown'
    assert ActionModule().get_shutdown_command(task_vars={}, distribution='REDHAT') == '/sbin/shutdown'
    assert ActionModule().get_shutdown_command(task_vars={}, distribution='FEDORA') == '/sbin/shutdown'
    assert ActionModule().get_shutdown_command(task_vars={}, distribution='UBUNTU') == '/sbin/shutdown'
    assert ActionModule().get_shutdown_command(task_vars={}, distribution='DEBIAN') == '/sbin/shutdown'
    assert ActionModule().get_shutdown_command(task_vars={}, distribution='SUSE') == '/sbin/shutdown'
   

# Generated at 2022-06-23 08:28:32.086866
# Unit test for method deprecated_args of class ActionModule
def test_ActionModule_deprecated_args():
    # This method is no longer used
    pass

# Generated at 2022-06-23 08:28:40.958902
# Unit test for method perform_reboot of class ActionModule
def test_ActionModule_perform_reboot():
    from ansible.module_utils import basic
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.connection.local import Connection
    from ansible.compat.tests.mock import Mock

    # If running with local connection, fail so we don't reboot ourself
    play_context = PlayContext()
    play_context.connection = 'local'
    connection = Connection(play_context, '/usr/bin/ansible-connection', ['/usr/bin/ansible-connection'])
    task_vars = {}
    mock_ansible_module = Mock(basic.AnsibleModule)
    action_module = ActionModule(mock_ansible_module, connection, '/usr/bin/ansible-playbook', task_vars)