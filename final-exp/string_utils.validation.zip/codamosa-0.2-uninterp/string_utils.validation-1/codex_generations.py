

# Generated at 2022-06-18 03:43:19.357423
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-18 03:43:29.090883
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') == True
    assert is_isbn('1506715214') == True
    assert is_isbn('978-0312498580') == True
    assert is_isbn('150-6715214') == True
    assert is_isbn('978-0312498580', normalize=False) == False
    assert is_isbn('150-6715214', normalize=False) == False
    assert is_isbn('978-0312498580', normalize=True) == True
    assert is_isbn('150-6715214', normalize=True) == True
    assert is_isbn('978-0312498580', normalize=False) == False
    assert is_isbn('150-6715214', normalize=False) == False
   

# Generated at 2022-06-18 03:43:40.453597
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:43:50.118633
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com')
    assert is_url('https://mysite.com')
    assert not is_url('.mysite.com')
    assert is_url('http://www.mysite.com', ['http', 'https'])
    assert is_url('https://mysite.com', ['http', 'https'])
    assert not is_url('ftp://mysite.com', ['http', 'https'])
    assert not is_url('http://mysite.com', ['https'])
    assert not is_url('https://mysite.com', ['http'])
    assert is_url('http://www.mysite.com/index.html')
    assert is_url('http://www.mysite.com/index.html?param=value')

# Generated at 2022-06-18 03:43:53.451492
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:44:02.766975
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4111111111111111') == True
    assert is_credit_card('4111111111111') == False
    assert is_credit_card('4012888888881881') == True
    assert is_credit_card('378282246310005') == True
    assert is_credit_card('6011111111111117') == True
    assert is_credit_card('5105105105105100') == True
    assert is_credit_card('5105 1051 0510 5106') == False
    assert is_credit_card('9111111111111111') == False


# Generated at 2022-06-18 03:44:11.504342
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') == True
    assert is_isbn('1506715214') == True
    assert is_isbn('978-0312498580') == True
    assert is_isbn('150-6715214') == True
    assert is_isbn('978-0312498580', normalize=False) == False
    assert is_isbn('150-6715214', normalize=False) == False
    assert is_isbn('978-0312498580', normalize=True) == True
    assert is_isbn('150-6715214', normalize=True) == True
    assert is_isbn('978-0312498580', normalize=False) == False
    assert is_isbn('150-6715214', normalize=False) == False
   

# Generated at 2022-06-18 03:44:13.419383
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:44:25.840505
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') == True
    assert is_isbn('1506715214') == True
    assert is_isbn('978-0312498580') == True
    assert is_isbn('150-6715214') == True
    assert is_isbn('978-0312498580', normalize=False) == False
    assert is_isbn('150-6715214', normalize=False) == False
    assert is_isbn('9780312498580', normalize=False) == True
    assert is_isbn('1506715214', normalize=False) == True
    assert is_isbn('9780312498580', normalize=True) == True
    assert is_isbn('1506715214', normalize=True) == True
    assert is_is

# Generated at 2022-06-18 03:44:36.862136
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4111111111111111')
    assert is_credit_card('4111111111111111', card_type='VISA')
    assert not is_credit_card('4111111111111111', card_type='MASTERCARD')
    assert is_credit_card('5555555555554444')
    assert is_credit_card('5555555555554444', card_type='MASTERCARD')
    assert not is_credit_card('5555555555554444', card_type='VISA')
    assert is_credit_card('378282246310005')
    assert is_credit_card('378282246310005', card_type='AMERICAN_EXPRESS')

# Generated at 2022-06-18 03:44:53.772319
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:44:57.908702
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75')
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334')
    assert not is_ip('1.2.3')
test_is_ip()


# Generated at 2022-06-18 03:45:01.731098
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75') == True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip('1.2.3') == False
test_is_ip()


# Generated at 2022-06-18 03:45:05.647004
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:45:08.623636
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:45:13.432682
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75')
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334')
    assert not is_ip('1.2.3')
    assert not is_ip('2001:db8:85a3:0000:0000:8a2e:370:?')


# Generated at 2022-06-18 03:45:16.574811
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:45:20.503379
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75') == True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip('1.2.3') == False
test_is_ip()


# Generated at 2022-06-18 03:45:23.841119
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75') == True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip('1.2.3') == False


# Generated at 2022-06-18 03:45:33.438642
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-1-56619-909-4').is_isbn_13() is True
    assert __ISBNChecker('978-1-56619-909-5').is_isbn_13() is False
    assert __ISBNChecker('978-1-56619-909-6').is_isbn_13() is False
    assert __ISBNChecker('978-1-56619-909-7').is_isbn_13() is False
    assert __ISBNChecker('978-1-56619-909-8').is_isbn_13() is False
    assert __ISBNChecker('978-1-56619-909-9').is_isbn_13() is False

# Generated at 2022-06-18 03:45:42.170701
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}')
    assert is_json('[1, 2, 3]')
    assert not is_json('{nope}')


# Generated at 2022-06-18 03:45:47.900043
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False
    assert is_json('{"name": "Peter", "age": "20"}') == True
    assert is_json('{"name": "Peter", "age": "20", "gender": "male"}') == True
    assert is_json('{"name": "Peter", "age": "20", "gender": "male", "location": "Singapore"}') == True
    assert is_json('{"name": "Peter", "age": "20", "gender": "male", "location": "Singapore", "nationality": "Singaporean"}') == True

# Generated at 2022-06-18 03:45:55.966098
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
   

# Generated at 2022-06-18 03:46:01.935095
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:46:13.255693
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:46:23.321090
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:46:33.590220
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@gmail.com') == True
    assert is_email('my.email@gmail.com') == True
    assert is_email('my.email@gmail.com') == True
    assert is_email('my.email@gmail.com') == True
    assert is_email('my.email@gmail.com') == True
    assert is_email('my.email@gmail.com') == True
    assert is_email('my.email@gmail.com') == True
    assert is_email('my.email@gmail.com') == True
    assert is_email('my.email@gmail.com') == True

# Generated at 2022-06-18 03:46:39.902955
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:46:43.355662
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:46:51.073066
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:47:03.230490
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:47:14.758777
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-0-306-40615-7').is_isbn_13() is True
    assert __ISBNChecker('978-0-306-40615-8').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-8', normalize=False).is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-7', normalize=False).is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-7', normalize=False).is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-7', normalize=False).is_isbn_13() is False
    assert __ISBN

# Generated at 2022-06-18 03:47:24.011043
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:47:33.389748
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:47:44.284081
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0306406152').is_isbn_10() == True
    assert __ISBNChecker('0306406153').is_isbn_10() == False
    assert __ISBNChecker('030640615X').is_isbn_10() == True
    assert __ISBNChecker('030640615x').is_isbn_10() == True
    assert __ISBNChecker('030640615').is_isbn_10() == False
    assert __ISBNChecker('03064061523').is_isbn_10() == False
    assert __ISBNChecker('030640615A').is_isbn_10() == False
    assert __ISBNChecker('030640615a').is_isbn_10() == False

# Generated at 2022-06-18 03:47:53.133456
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-0-306-40615-7').is_isbn_13() is True
    assert __ISBNChecker('978-0-306-40615-8').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-9').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-0').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-1').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-2').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-3').is_isbn_13

# Generated at 2022-06-18 03:48:03.772679
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:48:12.916406
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:48:23.667605
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:48:34.701162
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:48:50.069196
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-1-56619-909-4').is_isbn_13()
    assert __ISBNChecker('978-1-56619-909-4', normalize=False).is_isbn_13()
    assert __ISBNChecker('9781566919094').is_isbn_13()
    assert __ISBNChecker('9781566919094', normalize=False).is_isbn_13()
    assert not __ISBNChecker('978-1-56619-909-3').is_isbn_13()
    assert not __ISBNChecker('978-1-56619-909-3', normalize=False).is_isbn_13()
    assert not __ISBNChecker('9781566919093').is_isbn_13()


# Generated at 2022-06-18 03:48:59.107163
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:49:08.358923
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:49:11.360402
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-18 03:49:18.272921
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:49:26.086060
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:49:31.644805
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-0-306-40615-7').is_isbn_13()
    assert __ISBNChecker('978-0-306-40615-7', normalize=False).is_isbn_13()
    assert __ISBNChecker('978-0-306-40615-7', normalize=True).is_isbn_13()
    assert __ISBNChecker('978-0-306-40615-7', normalize=False).is_isbn_13()
    assert __ISBNChecker('978-0-306-40615-7', normalize=True).is_isbn_13()
    assert __ISBNChecker('978-0-306-40615-7', normalize=False).is_isbn_13()

# Generated at 2022-06-18 03:49:41.998171
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0306406152').is_isbn_10() == True
    assert __ISBNChecker('0306406153').is_isbn_10() == False
    assert __ISBNChecker('0306406154').is_isbn_10() == False
    assert __ISBNChecker('0306406155').is_isbn_10() == False
    assert __ISBNChecker('0306406156').is_isbn_10() == False
    assert __ISBNChecker('0306406157').is_isbn_10() == False
    assert __ISBNChecker('0306406158').is_isbn_10() == False
    assert __ISBNChecker('0306406159').is_isbn_10() == False

# Generated at 2022-06-18 03:49:44.109611
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-18 03:49:47.790507
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-18 03:50:10.945565
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:50:20.834760
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:50:28.928173
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:50:38.176067
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
   

# Generated at 2022-06-18 03:50:40.111899
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:50:43.870208
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:50:53.038486
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('255.200.100.75') == True
    assert is_

# Generated at 2022-06-18 03:51:02.039781
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0306406152').is_isbn_10() == True
    assert __ISBNChecker('0306406153').is_isbn_10() == False
    assert __ISBNChecker('030640615X').is_isbn_10() == True
    assert __ISBNChecker('030640615Y').is_isbn_10() == False
    assert __ISBNChecker('030640615').is_isbn_10() == False
    assert __ISBNChecker('03064061522').is_isbn_10() == False
    assert __ISBNChecker('030640615A').is_isbn_10() == False
    assert __ISBNChecker('030640615-2').is_isbn_10() == False

# Generated at 2022-06-18 03:51:05.883474
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:51:13.792285
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-0-306-40615-7').is_isbn_13() is True
    assert __ISBNChecker('978-0-306-40615-8').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-9').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-0').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-1').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-2').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-3').is_isbn_13

# Generated at 2022-06-18 03:51:35.852390
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0306406152').is_isbn_10() == True
    assert __ISBNChecker('0306406153').is_isbn_10() == False
    assert __ISBNChecker('030640615X').is_isbn_10() == True
    assert __ISBNChecker('030640615Y').is_isbn_10() == False
    assert __ISBNChecker('030640615').is_isbn_10() == False
    assert __ISBNChecker('03064061521').is_isbn_10() == False
    assert __ISBNChecker('030640615A').is_isbn_10() == False
    assert __ISBNChecker('030640615a').is_isbn_10() == False

# Generated at 2022-06-18 03:51:44.169654
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
   

# Generated at 2022-06-18 03:51:53.366207
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
   

# Generated at 2022-06-18 03:52:01.111433
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0-306-40615-2').is_isbn_10() == True
    assert __ISBNChecker('0-306-40615-3').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-4').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-5').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-6').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-7').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-8').is_isbn_10() == False

# Generated at 2022-06-18 03:52:06.613772
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:52:16.240401
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0306406152').is_isbn_10() == True
    assert __ISBNChecker('030640615X').is_isbn_10() == True
    assert __ISBNChecker('030640615').is_isbn_10() == False
    assert __ISBNChecker('03064061521').is_isbn_10() == False
    assert __ISBNChecker('030640615A').is_isbn_10() == False
    assert __ISBNChecker('030640615-X').is_isbn_10() == False
    assert __ISBNChecker('030640615-X', normalize=False).is_isbn_10() == False
    assert __ISBNChecker('030640615X', normalize=False).is_isbn_10()

# Generated at 2022-06-18 03:52:26.917860
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:52:30.842110
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False
    
test_is_ip_v4()


# Generated at 2022-06-18 03:52:41.972922
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
   