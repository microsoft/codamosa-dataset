

# Generated at 2022-06-18 03:43:23.601868
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580')
    assert is_isbn('1506715214')
    assert not is_isbn('978-0312498580', normalize=False)
    assert not is_isbn('150-6715214', normalize=False)
    assert not is_isbn('978-0312498580')
    assert not is_isbn('150-6715214')
    assert not is_isbn('978-0312498580', normalize=False)
    assert not is_isbn('150-6715214', normalize=False)
    assert not is_isbn('978-0312498580')
    assert not is_isbn('150-6715214')
    assert not is_isbn('978-0312498580', normalize=False)
   

# Generated at 2022-06-18 03:43:27.163437
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:43:30.595124
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75') == True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip('1.2.3') == False
test_is_ip()


# Generated at 2022-06-18 03:43:39.156077
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4111111111111111') == True
    assert is_credit_card('4111111111111') == False
    assert is_credit_card('4012888888881881') == True
    assert is_credit_card('378282246310005') == True
    assert is_credit_card('6011111111111117') == True
    assert is_credit_card('5105105105105100') == True
    assert is_credit_card('5105 1051 0510 5106') == False
    assert is_credit_card('9111111111111111') == False


# Generated at 2022-06-18 03:43:41.357974
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:43:51.642200
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0306406152').is_isbn_10() == True
    assert __ISBNChecker('0306406153').is_isbn_10() == False
    assert __ISBNChecker('030640615X').is_isbn_10() == True
    assert __ISBNChecker('030640615Y').is_isbn_10() == False
    assert __ISBNChecker('030640615').is_isbn_10() == False
    assert __ISBNChecker('03064061521').is_isbn_10() == False
    assert __ISBNChecker('030640615A').is_isbn_10() == False
    assert __ISBNChecker('030640615a').is_isbn_10() == False

# Generated at 2022-06-18 03:43:55.356635
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') == True
    assert is_isbn('1506715214') == True
    assert is_isbn('978-0312498580') == True
    assert is_isbn('150-6715214') == True
    assert is_isbn('978-0312498580', normalize=False) == False
    assert is_isbn('150-6715214', normalize=False) == False


# Generated at 2022-06-18 03:44:06.651730
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:44:09.203367
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:44:11.599396
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-18 03:44:21.541277
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-18 03:44:29.763552
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') == True
    assert is_url('https://mysite.com') == True
    assert is_url('.mysite.com') == False
    assert is_url('http://www.mysite.com', ['http']) == True
    assert is_url('https://mysite.com', ['http']) == False
    assert is_url('https://mysite.com', ['http', 'https']) == True
    assert is_url('https://mysite.com', ['ftp', 'https']) == True
    assert is_url('https://mysite.com', ['ftp', 'http']) == False


# Generated at 2022-06-18 03:44:40.494227
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:44:52.266586
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') == True
    assert is_url('https://mysite.com') == True
    assert is_url('.mysite.com') == False
    assert is_url('http://www.mysite.com', ['http']) == True
    assert is_url('https://mysite.com', ['http']) == False
    assert is_url('http://www.mysite.com', ['http', 'https']) == True
    assert is_url('https://mysite.com', ['http', 'https']) == True
    assert is_url('http://www.mysite.com', ['ftp']) == False
    assert is_url('https://mysite.com', ['ftp']) == False

# Generated at 2022-06-18 03:44:59.076920
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com')
    assert is_url('https://mysite.com')
    assert not is_url('.mysite.com')
    assert is_url('http://www.mysite.com', ['http'])
    assert not is_url('https://mysite.com', ['http'])
    assert is_url('http://www.mysite.com', ['http', 'https'])
    assert is_url('https://mysite.com', ['http', 'https'])



# Generated at 2022-06-18 03:45:07.220826
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') == True
    assert is_url('https://mysite.com') == True
    assert is_url('.mysite.com') == False
    assert is_url('http://www.mysite.com', ['http']) == True
    assert is_url('https://mysite.com', ['http']) == False
    assert is_url('http://www.mysite.com', ['https']) == False
    assert is_url('https://mysite.com', ['https']) == True
    assert is_url('http://www.mysite.com', ['http', 'https']) == True
    assert is_url('https://mysite.com', ['http', 'https']) == True

# Generated at 2022-06-18 03:45:17.153075
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0-306-40615-2').is_isbn_10() == True
    assert __ISBNChecker('0-306-40615-3').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-4').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-5').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-6').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-7').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-8').is_isbn_10() == False

# Generated at 2022-06-18 03:45:26.082298
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:45:36.853992
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:45:39.416433
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:45:44.582997
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:45:55.626568
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:46:03.404324
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
   

# Generated at 2022-06-18 03:46:04.920264
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-18 03:46:08.347440
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0306406152').is_isbn_10()
    assert __ISBNChecker('0306406153').is_isbn_10()
    assert __ISBNChecker('0306406154').is_isbn_10()
    assert __ISBNChecker('0306406155').is_isbn_10()
    assert __ISBNChecker('0306406156').is_isbn_10()
    assert __ISBNChecker('0306406157').is_isbn_10()
    assert __ISBNChecker('0306406158').is_isbn_10()
    assert __ISBNChecker('0306406159').is_isbn_10()
    assert __ISBNChecker('0306406160').is_isbn_10()

# Generated at 2022-06-18 03:46:18.807143
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-0-306-40615-7').is_isbn_13() is True
    assert __ISBNChecker('978-0-306-40615-8').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-9').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-0').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-1').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-2').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-3').is_isbn_13

# Generated at 2022-06-18 03:46:27.959175
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:46:36.626670
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0-306-40615-2').is_isbn_10() == True
    assert __ISBNChecker('0-306-40615-3').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-0').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-9').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-1').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-4').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-5').is_isbn_10() == False

# Generated at 2022-06-18 03:46:47.910046
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:46:57.669757
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:47:13.718692
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
   

# Generated at 2022-06-18 03:47:22.891282
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:47:29.990231
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:47:38.492175
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0306406152').is_isbn_10() is True
    assert __ISBNChecker('030640615X').is_isbn_10() is True
    assert __ISBNChecker('030640615').is_isbn_10() is False
    assert __ISBNChecker('03064061521').is_isbn_10() is False
    assert __ISBNChecker('030640615A').is_isbn_10() is False
    assert __ISBNChecker('030640615-X').is_isbn_10() is False

# Generated at 2022-06-18 03:47:49.098820
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:47:56.019310
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:48:06.270889
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False

# Generated at 2022-06-18 03:48:16.195662
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:48:20.724195
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999')


# Generated at 2022-06-18 03:48:30.681550
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:48:47.826838
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:48:57.569024
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:49:05.443055
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0306406152').is_isbn_10() == True
    assert __ISBNChecker('0306406153').is_isbn_10() == False
    assert __ISBNChecker('030640615X').is_isbn_10() == True
    assert __ISBNChecker('030640615x').is_isbn_10() == False
    assert __ISBNChecker('030640615').is_isbn_10() == False
    assert __ISBNChecker('03064061520').is_isbn_10() == False
    assert __ISBNChecker('030640615A').is_isbn_10() == False
    assert __ISBNChecker('030640615a').is_isbn_10() == False

# Generated at 2022-06-18 03:49:14.897392
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
   

# Generated at 2022-06-18 03:49:24.243221
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:49:34.474843
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:49:40.454543
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:49:48.653414
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:49:55.331556
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0306406152').is_isbn_10()
    assert __ISBNChecker('0306406153').is_isbn_10()
    assert __ISBNChecker('0306406154').is_isbn_10()
    assert __ISBNChecker('0306406155').is_isbn_10()
    assert __ISBNChecker('0306406156').is_isbn_10()
    assert __ISBNChecker('0306406157').is_isbn_10()
    assert __ISBNChecker('0306406158').is_isbn_10()
    assert __ISBNChecker('0306406159').is_isbn_10()
    assert __ISBNChecker('0306406160').is_isbn_10()

# Generated at 2022-06-18 03:49:58.282586
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:50:23.254347
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:50:26.820582
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:50:36.287745
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0-306-40615-2').is_isbn_10()
    assert __ISBNChecker('0306406152').is_isbn_10()
    assert __ISBNChecker('0-306-40615-2', normalize=False).is_isbn_10()
    assert __ISBNChecker('0306406152', normalize=False).is_isbn_10()

    assert not __ISBNChecker('0-306-40615-3').is_isbn_10()
    assert not __ISBNChecker('0306406153').is_isbn_10()
    assert not __ISBNChecker('0-306-40615-3', normalize=False).is_isbn_10()

# Generated at 2022-06-18 03:50:44.734211
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:50:53.466222
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:51:00.093823
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:51:03.538712
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:51:12.879916
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0306406152').is_isbn_10() == True
    assert __ISBNChecker('0306406153').is_isbn_10() == False
    assert __ISBNChecker('030640615X').is_isbn_10() == True
    assert __ISBNChecker('030640615Y').is_isbn_10() == False
    assert __ISBNChecker('030640615').is_isbn_10() == False
    assert __ISBNChecker('03064061521').is_isbn_10() == False
    assert __ISBNChecker('030640615X1').is_isbn_10() == False
    assert __ISBNChecker('030640615X1', normalize=False).is_isbn_10() == False
    assert __

# Generated at 2022-06-18 03:51:23.544593
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:51:31.313242
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:52:09.921748
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:52:14.577481
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:52:25.755013
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:52:35.309038
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0306406152').is_isbn_10() == True
    assert __ISBNChecker('0-306-40615-2').is_isbn_10() == True
    assert __ISBNChecker('0306406153').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-3').is_isbn_10() == False
    assert __ISBNChecker('030640615').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-').is_isbn_10() == False
    assert __ISBNChecker('03064061521').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-21').is_isbn_10() == False

# Generated at 2022-06-18 03:52:45.465996
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0306406152').is_isbn_10() == True
    assert __ISBNChecker('0306406153').is_isbn_10() == False
    assert __ISBNChecker('030640615X').is_isbn_10() == True
    assert __ISBNChecker('030640615Y').is_isbn_10() == False
    assert __ISBNChecker('030640615').is_isbn_10() == False
    assert __ISBNChecker('03064061521').is_isbn_10() == False
    assert __ISBNChecker('030640615A').is_isbn_10() == False
    assert __ISBNChecker('030640615a').is_isbn_10() == False

# Generated at 2022-06-18 03:52:52.848131
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email