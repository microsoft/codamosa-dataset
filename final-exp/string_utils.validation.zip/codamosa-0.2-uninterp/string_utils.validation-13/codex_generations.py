

# Generated at 2022-06-18 03:43:18.465667
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:43:29.145759
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-0-306-40615-7').is_isbn_13() is True
    assert __ISBNChecker('978-0-306-40615-8').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-9').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-0').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-1').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-2').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-3').is_isbn_13

# Generated at 2022-06-18 03:43:32.661775
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75') == True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip('1.2.3') == False
test_is_ip()


# Generated at 2022-06-18 03:43:39.156388
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-18 03:43:47.815635
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('LOL')
    assert is_palindrome('Lol', ignore_case=True)
    assert is_palindrome('i topi non avevano nipoti', ignore_spaces=True)
    assert not is_palindrome('ROTFL')
    assert not is_palindrome('Lol')
    assert not is_palindrome('i topi non avevano nipoti')
    assert not is_palindrome('')
    assert not is_palindrome(None)

test_is_palindrome()

# Generated at 2022-06-18 03:43:59.024522
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:44:02.503801
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:44:08.479131
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') == True
    assert is_isbn('1506715214') == True
    assert is_isbn('978-0312498580') == True
    assert is_isbn('150-6715214') == True
    assert is_isbn('978-0312498580', normalize=False) == False
    assert is_isbn('150-6715214', normalize=False) == False


# Generated at 2022-06-18 03:44:10.754016
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:44:12.475507
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:44:27.025598
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('42.0') == True
    assert is_decimal('42') == False
    assert is_decimal('42.0') == True
    assert is_decimal('42') == False
    assert is_decimal('42.0') == True
    assert is_decimal('42') == False
    assert is_decimal('42.0') == True
    assert is_decimal('42') == False
    assert is_decimal('42.0') == True
    assert is_decimal('42') == False
    assert is_decimal('42.0') == True
    assert is_decimal('42') == False
    assert is_decimal('42.0') == True
    assert is_decimal('42') == False
    assert is_decimal('42.0') == True

# Generated at 2022-06-18 03:44:34.772959
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:44:46.585713
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') == True
    assert is_url('https://mysite.com') == True
    assert is_url('.mysite.com') == False
    assert is_url('http://www.mysite.com', ['http']) == True
    assert is_url('http://www.mysite.com', ['https']) == False
    assert is_url('https://www.mysite.com', ['https']) == True
    assert is_url('https://www.mysite.com', ['http']) == False
    assert is_url('https://www.mysite.com', ['http', 'https']) == True
    assert is_url('https://www.mysite.com', ['ftp', 'https']) == True

# Generated at 2022-06-18 03:44:57.406053
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}')
    assert is_json('[1, 2, 3]')
    assert not is_json('{nope}')
    assert not is_json('')
    assert not is_json(None)
    assert not is_json(1)
    assert not is_json(True)
    assert not is_json(False)
    assert not is_json('{')
    assert not is_json('}')
    assert not is_json('[')
    assert not is_json(']')
    assert not is_json('[1, 2, 3')
    assert not is_json('{"name": "Peter"')
    assert not is_json('{"name": "Peter"},')
    assert not is_json('[1, 2, 3],')

# Generated at 2022-06-18 03:45:00.987838
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False
test_is_ip_v4()



# Generated at 2022-06-18 03:45:03.365793
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}')
    assert is_json('[1, 2, 3]')
    assert not is_json('{nope}')


# Generated at 2022-06-18 03:45:06.847336
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:45:16.819748
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com')
    assert is_url('https://mysite.com')
    assert not is_url('.mysite.com')
    assert is_url('http://www.mysite.com', allowed_schemes=['http'])
    assert not is_url('https://mysite.com', allowed_schemes=['http'])
    assert is_url('https://mysite.com', allowed_schemes=['https'])
    assert not is_url('http://mysite.com', allowed_schemes=['https'])
    assert is_url('http://mysite.com', allowed_schemes=['http', 'https'])
    assert is_url('https://mysite.com', allowed_schemes=['http', 'https'])
   

# Generated at 2022-06-18 03:45:18.340659
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('42.0') == True
    assert is_decimal('42') == False


# Generated at 2022-06-18 03:45:27.027895
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert not is_email('@gmail.com')
    assert not is_email('my.email@the-provider.com@')
    assert not is_email('my.email@the-provider.com@gmail.com')
    assert not is_email('my.email@the-provider.com@gmail.com@')
    assert not is_email('my.email@the-provider.com@gmail.com@gmail.com')
    assert not is_email('my.email@the-provider.com@gmail.com@gmail.com@')

# Generated at 2022-06-18 03:45:42.784714
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:45:53.947065
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:45:56.899028
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-18 03:46:05.646376
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4111111111111111') == True
    assert is_credit_card('4111111111111') == False
    assert is_credit_card('4012888888881881') == True
    assert is_credit_card('378282246310005') == True
    assert is_credit_card('6011111111111117') == True
    assert is_credit_card('5105105105105100') == True
    assert is_credit_card('5105 1051 0510 5106') == False
    assert is_credit_card('9111111111111111') == False



# Generated at 2022-06-18 03:46:15.236751
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:46:18.219362
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:46:28.140065
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:46:36.735995
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:46:47.909954
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
   

# Generated at 2022-06-18 03:46:57.669747
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0306406152').is_isbn_10() == True
    assert __ISBNChecker('030640615X').is_isbn_10() == True
    assert __ISBNChecker('030640615x').is_isbn_10() == True
    assert __ISBNChecker('030640615').is_isbn_10() == False
    assert __ISBNChecker('03064061521').is_isbn_10() == False
    assert __ISBNChecker('030640615X1').is_isbn_10() == False
    assert __ISBNChecker('030640615X2').is_isbn_10() == False
    assert __ISBNChecker('030640615X3').is_isbn_10() == False
    assert __ISBNCheck

# Generated at 2022-06-18 03:47:16.132271
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:47:24.802939
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:47:34.003431
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4111111111111111') == True
    assert is_credit_card('4111111111111') == False
    assert is_credit_card('4012888888881881') == True
    assert is_credit_card('378282246310005') == True
    assert is_credit_card('6011111111111117') == True
    assert is_credit_card('5105105105105100') == True
    assert is_credit_card('5105 1051 0510 5106') == False
    assert is_credit_card('9111111111111111') == False
    assert is_credit_card('4111111111111111', 'VISA') == True
    assert is_credit_card('4111111111111111', 'MASTERCARD') == False

# Generated at 2022-06-18 03:47:44.992645
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:47:46.562897
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:47:48.123588
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:47:49.752454
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:47:56.347878
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:48:04.576949
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4111111111111111') == True
    assert is_credit_card('4111111111111') == False
    assert is_credit_card('4012888888881881') == True
    assert is_credit_card('378282246310005') == True
    assert is_credit_card('6011111111111117') == True
    assert is_credit_card('5105105105105100') == True
    assert is_credit_card('5105 1051 0510 5106') == False
    assert is_credit_card('9111111111111111') == False


# Generated at 2022-06-18 03:48:07.033067
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:48:24.839898
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:48:27.690237
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-18 03:48:38.744835
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert not is_email('@gmail.com')
    assert not is_email('my.email@the-provider.com@')
    assert not is_email('my.email@the-provider')
    assert is_email('"my.email"@the-provider.com')
    assert is_email('"my.email@the-provider.com"@the-provider.com')
    assert is_email('"my.email@the-provider.com"@the-provider.com')
    assert is_email('"my.email@the-provider.com"@the-provider.com')
    assert is_email('"my.email@the-provider.com"@the-provider.com')

# Generated at 2022-06-18 03:48:42.033229
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999')


# Generated at 2022-06-18 03:48:50.286659
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-0-306-40615-7').is_isbn_13()
    assert __ISBNChecker('978-0-306-40615-7', False).is_isbn_13()
    assert __ISBNChecker('978-0-306-40615-7', True).is_isbn_13()
    assert __ISBNChecker('978-0-306-40615-8').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-8', False).is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-8', True).is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-9').is_isbn

# Generated at 2022-06-18 03:48:59.214782
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:49:08.368014
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0306406152').is_isbn_10()
    assert __ISBNChecker('030640615X').is_isbn_10()
    assert __ISBNChecker('030640615x').is_isbn_10()
    assert not __ISBNChecker('030640615').is_isbn_10()
    assert not __ISBNChecker('03064061521').is_isbn_10()
    assert not __ISBNChecker('030640615Y').is_isbn_10()
    assert not __ISBNChecker('030640615y').is_isbn_10()
    assert not __ISBNChecker('030640615Z').is_isbn_10()
    assert not __ISBNChecker('030640615z').is_isbn_

# Generated at 2022-06-18 03:49:10.927068
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:49:18.014270
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:49:22.348050
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0-306-40615-2').is_isbn_10() == True
    assert __ISBNChecker('0-306-40615-3').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-4').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-5').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-6').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-7').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-8').is_isbn_10() == False

# Generated at 2022-06-18 03:49:39.010997
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
   

# Generated at 2022-06-18 03:49:47.835154
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:49:54.711986
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-0-306-40615-7').is_isbn_13()
    assert __ISBNChecker('978-0-306-40615-7', normalize=False).is_isbn_13()
    assert not __ISBNChecker('978-0-306-40615-8').is_isbn_13()
    assert not __ISBNChecker('978-0-306-40615-8', normalize=False).is_isbn_13()
    assert not __ISBNChecker('978-0-306-40615-9').is_isbn_13()
    assert not __ISBNChecker('978-0-306-40615-9', normalize=False).is_isbn_13()

# Generated at 2022-06-18 03:50:02.410604
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:50:06.476612
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-18 03:50:08.944998
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:50:20.144303
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:50:23.669883
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-18 03:50:33.958509
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0306406152').is_isbn_10() == True
    assert __ISBNChecker('0306406153').is_isbn_10() == False
    assert __ISBNChecker('030640615X').is_isbn_10() == True
    assert __ISBNChecker('030640615x').is_isbn_10() == True
    assert __ISBNChecker('030640615').is_isbn_10() == False
    assert __ISBNChecker('03064061521').is_isbn_10() == False
    assert __ISBNChecker('030640615A').is_isbn_10() == False
    assert __ISBNChecker('030640615a').is_isbn_10() == False

# Generated at 2022-06-18 03:50:41.472862
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-3-16-148410-0').is_isbn_13() == True
    assert __ISBNChecker('9783161484100').is_isbn_13() == True
    assert __ISBNChecker('978-3-16-148410-1').is_isbn_13() == False
    assert __ISBNChecker('978316148410').is_isbn_13() == False
    assert __ISBNChecker('978-3-16-148410-0', normalize=False).is_isbn_13() == True
    assert __ISBNChecker('9783161484100', normalize=False).is_isbn_13() == True
    assert __ISBNChecker('978-3-16-148410-1', normalize=False).is_

# Generated at 2022-06-18 03:51:02.725662
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False
    assert is_json('{"name": "Peter"') == False
    assert is_json('[1, 2, 3') == False
    assert is_json('[1, 2, 3]') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('[1, 2, 3]') == True
   

# Generated at 2022-06-18 03:51:12.408557
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:51:23.506615
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:51:31.284862
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0306406152').is_isbn_10() == True
    assert __ISBNChecker('030640615X').is_isbn_10() == True
    assert __ISBNChecker('030640615x').is_isbn_10() == True
    assert __ISBNChecker('030640615').is_isbn_10() == False
    assert __ISBNChecker('03064061511').is_isbn_10() == False
    assert __ISBNChecker('030640615A').is_isbn_10() == False
    assert __ISBNChecker('030640615a').is_isbn_10() == False
    assert __ISBNChecker('030640615-').is_isbn_10() == False

# Generated at 2022-06-18 03:51:38.927152
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:51:45.544228
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-0-306-40615-7').is_isbn_13()
    assert __ISBNChecker('978-0-306-40615-7', normalize=False).is_isbn_13()
    assert not __ISBNChecker('978-0-306-40615-8').is_isbn_13()
    assert not __ISBNChecker('978-0-306-40615-8', normalize=False).is_isbn_13()
    assert not __ISBNChecker('978-0-306-40615-9').is_isbn_13()
    assert not __ISBNChecker('978-0-306-40615-9', normalize=False).is_isbn_13()

# Generated at 2022-06-18 03:51:54.710746
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:52:04.082740
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:52:05.614867
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:52:10.260060
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:52:32.555286
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0-306-40615-2').is_isbn_10() == True
    assert __ISBNChecker('0306406152').is_isbn_10() == True
    assert __ISBNChecker('0-306-40615-3').is_isbn_10() == False
    assert __ISBNChecker('0306406153').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-0').is_isbn_10() == False
    assert __ISBNChecker('030640615').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-1').is_isbn_10() == False
    assert __ISBNChecker('0306406151').is_isbn_10() == False

# Generated at 2022-06-18 03:52:35.604468
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-18 03:52:40.155900
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-18 03:52:43.527660
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-18 03:52:52.286984
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email