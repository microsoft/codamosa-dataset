

# Generated at 2022-06-18 03:43:07.098001
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
   

# Generated at 2022-06-18 03:43:09.316364
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75')
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334')
    assert not is_ip('1.2.3')


# Generated at 2022-06-18 03:43:12.689430
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-18 03:43:22.602841
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert not is_email('@gmail.com')
    assert not is_email('my.email@the-provider.com@gmail.com')
    assert is_email('my.email@the-provider.com@gmail.com', allowed_schemes=['my.email@the-provider.com@gmail.com'])
    assert is_email('my.email@the-provider.com@gmail.com', allowed_schemes=['my.email@the-provider.com'])
    assert not is_email('my.email@the-provider.com@gmail.com', allowed_schemes=['my.email@the-provider.com@gmail.com'])

# Generated at 2022-06-18 03:43:31.722266
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') == True
    assert is_isbn('1506715214') == True
    assert is_isbn('978-0312498580') == True
    assert is_isbn('150-6715214') == True
    assert is_isbn('978-0312498580', normalize=False) == False
    assert is_isbn('150-6715214', normalize=False) == False
    assert is_isbn('9780312498580', normalize=False) == True
    assert is_isbn('1506715214', normalize=False) == True
    assert is_isbn('9780312498580', normalize=True) == True
    assert is_isbn('1506715214', normalize=True) == True
    assert is_is

# Generated at 2022-06-18 03:43:41.287421
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') == True
    assert is_url('https://mysite.com') == True
    assert is_url('.mysite.com') == False
    assert is_url('http://www.mysite.com', ['http']) == True
    assert is_url('https://www.mysite.com', ['http']) == False
    assert is_url('https://www.mysite.com', ['http', 'https']) == True
    assert is_url('ftp://www.mysite.com', ['http', 'https']) == False
    assert is_url('ftp://www.mysite.com', ['http', 'https', 'ftp']) == True
    assert is_url('http://www.mysite.com', ['https', 'ftp']) == False

# Generated at 2022-06-18 03:43:51.643209
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0-306-40615-2').is_isbn_10() == True
    assert __ISBNChecker('0-306-40615-3').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-4').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-5').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-6').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-7').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-8').is_isbn_10() == False

# Generated at 2022-06-18 03:43:53.936075
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-18 03:44:05.430303
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-0-306-40615-7').is_isbn_13() == True
    assert __ISBNChecker('978-0-306-40615-8').is_isbn_13() == False
    assert __ISBNChecker('978-0-306-40615-9').is_isbn_13() == False
    assert __ISBNChecker('978-0-306-40615-0').is_isbn_13() == False
    assert __ISBNChecker('978-0-306-40615-1').is_isbn_13() == False
    assert __ISBNChecker('978-0-306-40615-2').is_isbn_13() == False
    assert __ISBNChecker('978-0-306-40615-3').is_isbn_13

# Generated at 2022-06-18 03:44:08.437307
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-18 03:44:22.218527
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:44:25.083867
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:44:35.767919
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:44:38.598439
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}')
    assert is_json('[1, 2, 3]')
    assert not is_json('{nope}')


# Generated at 2022-06-18 03:44:46.763918
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-0-306-40615-7').is_isbn_13() is True
    assert __ISBNChecker('978-0-306-40615-8').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-9').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-0').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-1').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-2').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-3').is_isbn_13

# Generated at 2022-06-18 03:44:55.026188
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4111111111111111') == True
    assert is_credit_card('4111111111111') == False
    assert is_credit_card('4012888888881881') == True
    assert is_credit_card('378282246310005') == True
    assert is_credit_card('6011111111111117') == True
    assert is_credit_card('5105105105105100') == True
    assert is_credit_card('5105 1051 0510 5106') == False
    assert is_credit_card('9111111111111111') == False


# Generated at 2022-06-18 03:45:04.768662
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0-306-40615-2').is_isbn_10() is True
    assert __ISBNChecker('0306406152').is_isbn_10() is True
    assert __ISBNChecker('0-306-40615-3').is_isbn_10() is False
    assert __ISBNChecker('0306406153').is_isbn_10() is False
    assert __ISBNChecker('0-306-40615-X').is_isbn_10() is False
    assert __ISBNChecker('030640615X').is_isbn_10() is False
    assert __ISBNChecker('0-306-40615-x').is_isbn_10() is False
    assert __ISBNChecker('030640615x').is_isbn_10()

# Generated at 2022-06-18 03:45:07.641352
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:45:14.985413
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4111111111111111') == True
    assert is_credit_card('4111111111111') == False
    assert is_credit_card('4012888888881881') == True
    assert is_credit_card('378282246310005') == True
    assert is_credit_card('6011111111111117') == True
    assert is_credit_card('5105105105105100') == True
    assert is_credit_card('5105 1051 0510 5106') == False
    assert is_credit_card('9111111111111111') == False


# Generated at 2022-06-18 03:45:17.959499
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:45:31.897249
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:45:41.492943
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:45:44.397140
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-18 03:45:55.627874
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:46:01.613291
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:46:03.734804
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-18 03:46:14.780579
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:46:19.576002
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:46:22.648894
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-18 03:46:32.936803
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0-306-40615-2').is_isbn_10() == True
    assert __ISBNChecker('0-306-40615-3').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-4').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-5').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-6').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-7').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-8').is_isbn_10() == False

# Generated at 2022-06-18 03:46:50.541334
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0-306-40615-2').is_isbn_10()
    assert __ISBNChecker('0306406152').is_isbn_10()
    assert __ISBNChecker('0-306-40615-2').is_isbn_10()
    assert __ISBNChecker('0306406152').is_isbn_10()
    assert __ISBNChecker('0-306-40615-2').is_isbn_10()
    assert __ISBNChecker('0306406152').is_isbn_10()
    assert __ISBNChecker('0-306-40615-2').is_isbn_10()
    assert __ISBNChecker('0306406152').is_isbn_10()

# Generated at 2022-06-18 03:47:02.320967
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-0-306-40615-7').is_isbn_13() == True
    assert __ISBNChecker('978-0-306-40615-8').is_isbn_13() == False
    assert __ISBNChecker('978-0-306-40615-9').is_isbn_13() == False
    assert __ISBNChecker('978-0-306-40615-0').is_isbn_13() == False
    assert __ISBNChecker('978-0-306-40615-1').is_isbn_13() == False
    assert __ISBNChecker('978-0-306-40615-2').is_isbn_13() == False
    assert __ISBNChecker('978-0-306-40615-3').is_isbn_13

# Generated at 2022-06-18 03:47:14.175069
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0-306-40615-2').is_isbn_10() == True
    assert __ISBNChecker('0-306-40615-3').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-4').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-5').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-6').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-7').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-8').is_isbn_10() == False

# Generated at 2022-06-18 03:47:23.655049
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4111111111111111')
    assert is_credit_card('4111111111111111', 'VISA')
    assert is_credit_card('4111111111111111', 'MASTERCARD')
    assert is_credit_card('4111111111111111', 'AMERICAN_EXPRESS')
    assert is_credit_card('4111111111111111', 'DINERS_CLUB')
    assert is_credit_card('4111111111111111', 'DISCOVER')
    assert is_credit_card('4111111111111111', 'JCB')

    assert is_credit_card('5555555555554444')
    assert is_credit_card('5555555555554444', 'MASTERCARD')

# Generated at 2022-06-18 03:47:30.802458
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:47:42.232477
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:47:48.508230
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-18 03:47:55.661496
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
   

# Generated at 2022-06-18 03:48:05.987639
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
   

# Generated at 2022-06-18 03:48:15.761041
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4111111111111111')
    assert is_credit_card('4111 1111 1111 1111')
    assert is_credit_card('4111-1111-1111-1111')
    assert is_credit_card('4111.1111.1111.1111')
    assert is_credit_card('4111 1111 1111 1111', 'VISA')
    assert is_credit_card('4111 1111 1111 1111', 'visa')
    assert not is_credit_card('4111 1111 1111 1111', 'MASTERCARD')
    assert not is_credit_card('4111 1111 1111 1111', 'mastercard')
    assert is_credit_card('5500000000000004')
    assert is_credit_card('5500 0000 0000 0004')

# Generated at 2022-06-18 03:48:28.873748
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:48:39.223303
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0306406152').is_isbn_10() == True
    assert __ISBNChecker('0306406153').is_isbn_10() == False
    assert __ISBNChecker('030640615X').is_isbn_10() == True
    assert __ISBNChecker('030640615x').is_isbn_10() == True
    assert __ISBNChecker('030640615').is_isbn_10() == False
    assert __ISBNChecker('03064061521').is_isbn_10() == False
    assert __ISBNChecker('030640615A').is_isbn_10() == False
    assert __ISBNChecker('030640615a').is_isbn_10() == False

# Generated at 2022-06-18 03:48:42.577104
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-18 03:48:54.441901
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:49:03.744216
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:49:13.912108
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0-306-40615-2').is_isbn_10() == True
    assert __ISBNChecker('0-306-40615-3').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-4').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-5').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-6').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-7').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-8').is_isbn_10() == False

# Generated at 2022-06-18 03:49:23.418007
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:49:33.649212
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:49:44.163227
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:49:52.320361
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-0-306-40615-7').is_isbn_13() is True
    assert __ISBNChecker('978-0-306-40615-8').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-9').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-0').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-1').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-2').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-3').is_isbn_13

# Generated at 2022-06-18 03:50:04.275218
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:50:12.787783
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:50:23.082635
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:50:33.385114
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:50:40.961613
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-0-306-40615-7').is_isbn_13()
    assert __ISBNChecker('978-0-306-40615-7', False).is_isbn_13()
    assert __ISBNChecker('978-0-306-40615-7', True).is_isbn_13()
    assert __ISBNChecker('978-0-306-40615-8').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-8', False).is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-8', True).is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-8').is_isbn

# Generated at 2022-06-18 03:50:51.469234
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:50:58.817990
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-3-16-148410-0').is_isbn_13()
    assert __ISBNChecker('9783161484100').is_isbn_13()
    assert not __ISBNChecker('978316148410').is_isbn_13()
    assert not __ISBNChecker('978316148410a').is_isbn_13()
    assert not __ISBNChecker('978316148410-0').is_isbn_13()
    assert not __ISBNChecker('978316148410-0', normalize=False).is_isbn_13()


# Generated at 2022-06-18 03:51:10.129490
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:51:15.259765
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:51:24.590812
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False
    assert is_json('') == False
    assert is_json(None) == False
    assert is_json(1) == False
    assert is_json(1.0) == False
    assert is_json(True) == False
    assert is_json(False) == False
    assert is_json([]) == False
    assert is_json({}) == False
    assert is_json(()) == False
    assert is_json(set()) == False
    assert is_json(frozenset()) == False
    assert is_json(b'') == False
    assert is_json(bytearray(b'')) == False


# Generated at 2022-06-18 03:51:51.449555
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-0-306-40615-7').is_isbn_13() is True
    assert __ISBNChecker('978-0-306-40615-8').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-9').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-0').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-1').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-2').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-3').is_isbn_13

# Generated at 2022-06-18 03:51:59.685945
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-0-306-40615-7').is_isbn_13() == True
    assert __ISBNChecker('978-0-306-40615-8').is_isbn_13() == False
    assert __ISBNChecker('978-0-306-40615-9').is_isbn_13() == False
    assert __ISBNChecker('978-0-306-40615-0').is_isbn_13() == False
    assert __ISBNChecker('978-0-306-40615-1').is_isbn_13() == False
    assert __ISBNChecker('978-0-306-40615-2').is_isbn_13() == False
    assert __ISBNChecker('978-0-306-40615-3').is_isbn_13

# Generated at 2022-06-18 03:52:09.144607
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-0-306-40615-7').is_isbn_13()
    assert __ISBNChecker('978-0-306-40615-7', normalize=False).is_isbn_13()
    assert __ISBNChecker('978-0-306-40615-7', normalize=True).is_isbn_13()
    assert __ISBNChecker('978-0-306-40615-8').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-8', normalize=False).is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-8', normalize=True).is_isbn_13() is False

# Generated at 2022-06-18 03:52:20.529722
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
   

# Generated at 2022-06-18 03:52:30.957527
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-3-16-148410-0').is_isbn_13() == True
    assert __ISBNChecker('978-3-16-148410-1').is_isbn_13() == False
    assert __ISBNChecker('978-3-16-148410-2').is_isbn_13() == False
    assert __ISBNChecker('978-3-16-148410-3').is_isbn_13() == False
    assert __ISBNChecker('978-3-16-148410-4').is_isbn_13() == False
    assert __ISBNChecker('978-3-16-148410-5').is_isbn_13() == False

# Generated at 2022-06-18 03:52:42.096575
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:52:49.052249
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email