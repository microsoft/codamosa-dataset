

# Generated at 2022-06-18 03:43:13.629046
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:43:17.801542
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75') == True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip('1.2.3') == False
test_is_ip()


# Generated at 2022-06-18 03:43:20.335061
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:43:25.266437
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75') == True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip('1.2.3') == False
test_is_ip()


# Generated at 2022-06-18 03:43:33.031943
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') == True
    assert is_isbn('1506715214') == True
    assert is_isbn('978-0312498580') == True
    assert is_isbn('150-6715214') == True
    assert is_isbn('978-0312498580', normalize=False) == False
    assert is_isbn('150-6715214', normalize=False) == False
    assert is_isbn('978-0312498580', normalize=True) == True
    assert is_isbn('150-6715214', normalize=True) == True
    assert is_isbn('978-0312498580', normalize=False) == False
    assert is_isbn('150-6715214', normalize=False) == False
   

# Generated at 2022-06-18 03:43:36.160484
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999')


# Generated at 2022-06-18 03:43:43.366591
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') == True
    assert is_isbn('1506715214') == True
    assert is_isbn('978-0312498580') == True
    assert is_isbn('150-6715214') == True
    assert is_isbn('978-0312498580', normalize=False) == False
    assert is_isbn('150-6715214', normalize=False) == False
    assert is_isbn('978-0312498580', normalize=True) == True
    assert is_isbn('150-6715214', normalize=True) == True
    assert is_isbn('978-0312498580', normalize=False) == False
    assert is_isbn('150-6715214', normalize=False) == False
   

# Generated at 2022-06-18 03:43:51.959610
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0306406152').is_isbn_10() == True
    assert __ISBNChecker('0306406153').is_isbn_10() == False
    assert __ISBNChecker('0306406154').is_isbn_10() == False
    assert __ISBNChecker('0306406155').is_isbn_10() == False
    assert __ISBNChecker('0306406156').is_isbn_10() == False
    assert __ISBNChecker('0306406157').is_isbn_10() == False
    assert __ISBNChecker('0306406158').is_isbn_10() == False
    assert __ISBNChecker('0306406159').is_isbn_10() == False

# Generated at 2022-06-18 03:44:01.868368
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4111111111111111') == True
    assert is_credit_card('4111111111111') == False
    assert is_credit_card('4012888888881881') == True
    assert is_credit_card('378282246310005') == True
    assert is_credit_card('6011111111111117') == True
    assert is_credit_card('5105105105105100') == True
    assert is_credit_card('5105 1051 0510 5106') == False
    assert is_credit_card('9111111111111111') == False


# Generated at 2022-06-18 03:44:11.007128
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0306406152').is_isbn_10() == True
    assert __ISBNChecker('0306406153').is_isbn_10() == False
    assert __ISBNChecker('030640615X').is_isbn_10() == True
    assert __ISBNChecker('030640615Y').is_isbn_10() == False
    assert __ISBNChecker('030640615').is_isbn_10() == False
    assert __ISBNChecker('03064061521').is_isbn_10() == False
    assert __ISBNChecker('030640615A').is_isbn_10() == False
    assert __ISBNChecker('030640615-2').is_isbn_10() == True

# Generated at 2022-06-18 03:44:28.236367
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') == True
    assert is_url('https://mysite.com') == True
    assert is_url('.mysite.com') == False
    assert is_url('http://www.mysite.com', ['http']) == True
    assert is_url('https://mysite.com', ['http']) == False
    assert is_url('http://www.mysite.com', ['https']) == False
    assert is_url('https://mysite.com', ['https']) == True
    assert is_url('http://www.mysite.com', ['http', 'https']) == True
    assert is_url('https://mysite.com', ['http', 'https']) == True

# Generated at 2022-06-18 03:44:31.109050
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-18 03:44:42.219772
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:44:51.984231
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') == True
    assert is_url('https://mysite.com') == True
    assert is_url('.mysite.com') == False
    assert is_url('http://www.mysite.com', ['http']) == True
    assert is_url('https://mysite.com', ['http']) == False
    assert is_url('https://mysite.com', ['http', 'https']) == True
    assert is_url('https://mysite.com', ['http', 'https', 'ftp']) == True
    assert is_url('ftp://mysite.com', ['http', 'https', 'ftp']) == True
    assert is_url('ftp://mysite.com', ['http', 'https']) == False

# Generated at 2022-06-18 03:44:55.186238
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:45:04.892844
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com')
    assert is_url('https://mysite.com')
    assert not is_url('.mysite.com')
    assert is_url('http://www.mysite.com', ['http'])
    assert not is_url('https://www.mysite.com', ['http'])
    assert is_url('http://www.mysite.com', ['http', 'https'])
    assert is_url('https://www.mysite.com', ['http', 'https'])
    assert not is_url('ftp://www.mysite.com', ['http', 'https'])
    assert not is_url('http://www.mysite.com', ['https'])

# Generated at 2022-06-18 03:45:14.562722
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:45:21.062770
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4111111111111111') == True
    assert is_credit_card('4111111111111') == False
    assert is_credit_card('4012888888881881') == True
    assert is_credit_card('378282246310005') == True
    assert is_credit_card('6011111111111117') == True
    assert is_credit_card('5105105105105100') == True
    assert is_credit_card('5105 1051 0510 5106') == False
    assert is_credit_card('9111111111111111') == False


# Generated at 2022-06-18 03:45:29.675926
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
   

# Generated at 2022-06-18 03:45:31.460536
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999')


# Generated at 2022-06-18 03:45:45.462441
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:45:55.973604
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:46:06.394545
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:46:09.689039
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:46:12.154901
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-18 03:46:15.021342
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:46:24.884648
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:46:34.956733
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:46:45.533697
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4111111111111111')
    assert is_credit_card('4111111111111111', 'VISA')
    assert not is_credit_card('4111111111111111', 'MASTERCARD')
    assert is_credit_card('5555555555554444')
    assert is_credit_card('5555555555554444', 'MASTERCARD')
    assert not is_credit_card('5555555555554444', 'VISA')
    assert is_credit_card('378282246310005')
    assert is_credit_card('378282246310005', 'AMERICAN_EXPRESS')
    assert not is_credit_card('378282246310005', 'MASTERCARD')

# Generated at 2022-06-18 03:46:55.841204
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:47:05.590125
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:47:17.157150
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('255.200.100.75') == True
    assert is_

# Generated at 2022-06-18 03:47:26.064169
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:47:34.780531
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0306406152').is_isbn_10() == True
    assert __ISBNChecker('0306406153').is_isbn_10() == False
    assert __ISBNChecker('030640615X').is_isbn_10() == True
    assert __ISBNChecker('030640615x').is_isbn_10() == True
    assert __ISBNChecker('030640615').is_isbn_10() == False
    assert __ISBNChecker('03064061521').is_isbn_10() == False
    assert __ISBNChecker('030640615A').is_isbn_10() == False
    assert __ISBNChecker('030640615a').is_isbn_10() == False

# Generated at 2022-06-18 03:47:45.869206
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:47:54.078151
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-0-306-40615-7').is_isbn_13()
    assert __ISBNChecker('978-0-306-40615-7', normalize=False).is_isbn_13()
    assert __ISBNChecker('978 0 306 40615 7').is_isbn_13()
    assert __ISBNChecker('978 0 306 40615 7', normalize=False).is_isbn_13()
    assert __ISBNChecker('9780306406157').is_isbn_13()
    assert __ISBNChecker('9780306406157', normalize=False).is_isbn_13()

    assert not __ISBNChecker('978-0-306-40615-8').is_isbn_13()

# Generated at 2022-06-18 03:48:04.748326
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:48:12.400222
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-3-16-148410-0').is_isbn_13() == True
    assert __ISBNChecker('9783161484100').is_isbn_13() == True
    assert __ISBNChecker('978316148410').is_isbn_13() == False
    assert __ISBNChecker('978316148410').is_isbn_13() == False
    assert __ISBNChecker('978316148410').is_isbn_13() == False
    assert __ISBNChecker('978316148410').is_isbn_13() == False
    assert __ISBNChecker('978316148410').is_isbn_13() == False
    assert __ISBNChecker('978316148410').is_isbn_13() == False
   

# Generated at 2022-06-18 03:48:16.550179
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}')
    assert is_json('[1, 2, 3]')
    assert not is_json('{nope}')
    assert not is_json('')
    assert not is_json(None)
    assert not is_json(1)
    assert not is_json(True)
    assert not is_json(False)
    assert not is_json(['a', 'b', 'c'])
    assert not is_json(['a', 'b', 'c'])
    assert not is_json(['a', 'b', 'c'])
    assert not is_json(['a', 'b', 'c'])
    assert not is_json(['a', 'b', 'c'])
    assert not is_json(['a', 'b', 'c'])

# Generated at 2022-06-18 03:48:26.926283
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0306406152').is_isbn_10() == True
    assert __ISBNChecker('0306406153').is_isbn_10() == False
    assert __ISBNChecker('030640615X').is_isbn_10() == True
    assert __ISBNChecker('030640615x').is_isbn_10() == False
    assert __ISBNChecker('030640615').is_isbn_10() == False
    assert __ISBNChecker('03064061523').is_isbn_10() == False
    assert __ISBNChecker('030640615A').is_isbn_10() == False
    assert __ISBNChecker('030640615-2').is_isbn_10() == True

# Generated at 2022-06-18 03:48:41.860798
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:48:50.206489
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0306406152').is_isbn_10() == True
    assert __ISBNChecker('0306406153').is_isbn_10() == False
    assert __ISBNChecker('030640615X').is_isbn_10() == True
    assert __ISBNChecker('030640615Y').is_isbn_10() == False
    assert __ISBNChecker('030640615').is_isbn_10() == False
    assert __ISBNChecker('03064061521').is_isbn_10() == False
    assert __ISBNChecker('030640615-2').is_isbn_10() == False
    assert __ISBNChecker('030640615-X').is_isbn_10() == False

# Generated at 2022-06-18 03:48:59.576827
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-0-306-40615-7').is_isbn_13() == True
    assert __ISBNChecker('978-0-306-40615-8').is_isbn_13() == False
    assert __ISBNChecker('978-0-306-40615-9').is_isbn_13() == False
    assert __ISBNChecker('978-0-306-40615-0').is_isbn_13() == False
    assert __ISBNChecker('978-0-306-40615-1').is_isbn_13() == False
    assert __ISBNChecker('978-0-306-40615-2').is_isbn_13() == False
    assert __ISBNChecker('978-0-306-40615-3').is_isbn_13

# Generated at 2022-06-18 03:49:02.087217
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:49:12.526412
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:49:22.247564
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False
    assert is_json('{"name": "Peter"') == False
    assert is_json('{"name": "Peter", "age": "20"}') == True
    assert is_json('{"name": "Peter", "age": "20", "address": "123 Main St"}') == True
    assert is_json('{"name": "Peter", "age": "20", "address": "123 Main St", "phone": "123-456-7890"}') == True

# Generated at 2022-06-18 03:49:24.788483
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:49:34.889122
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-0-306-40615-7').is_isbn_13() is True
    assert __ISBNChecker('978-0-306-40615-8').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-9').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-0').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-1').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-2').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-3').is_isbn_13

# Generated at 2022-06-18 03:49:40.792124
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
   

# Generated at 2022-06-18 03:49:43.888879
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-18 03:49:53.520609
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-18 03:50:01.946019
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0306406152').is_isbn_10() == True
    assert __ISBNChecker('0306406153').is_isbn_10() == False
    assert __ISBNChecker('030640615X').is_isbn_10() == True
    assert __ISBNChecker('030640615x').is_isbn_10() == False
    assert __ISBNChecker('030640615').is_isbn_10() == False
    assert __ISBNChecker('03064061521').is_isbn_10() == False
    assert __ISBNChecker('030640615A').is_isbn_10() == False
    assert __ISBNChecker('030640615a').is_isbn_10() == False

# Generated at 2022-06-18 03:50:11.292060
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:50:14.152236
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-18 03:50:24.091809
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-0-306-40615-7').is_isbn_13()
    assert __ISBNChecker('978-0-306-40615-7', False).is_isbn_13()
    assert __ISBNChecker('978-0-306-40615-8').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-8', False).is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-7-1').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-7-1', False).is_isbn_13() is False

# Generated at 2022-06-18 03:50:34.294961
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True

# Generated at 2022-06-18 03:50:37.020696
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:50:39.578091
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-18 03:50:50.428361
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:50:59.648542
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:51:11.315515
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:51:15.722104
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:51:19.393081
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-18 03:51:23.282811
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:51:31.105806
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-1-56619-909-4').is_isbn_13()
    assert __ISBNChecker('9781566919094').is_isbn_13()
    assert __ISBNChecker('978-1-56619-909-4', normalize=False).is_isbn_13()
    assert __ISBNChecker('9781566919094', normalize=False).is_isbn_13()

    assert not __ISBNChecker('978-1-56619-909-5').is_isbn_13()
    assert not __ISBNChecker('9781566919095').is_isbn_13()
    assert not __ISBNChecker('978-1-56619-909-5', normalize=False).is_isbn_13()


# Generated at 2022-06-18 03:51:38.606141
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:51:45.375817
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0306406152').is_isbn_10() == True
    assert __ISBNChecker('0306406153').is_isbn_10() == False
    assert __ISBNChecker('030640615').is_isbn_10() == False
    assert __ISBNChecker('03064061521').is_isbn_10() == False
    assert __ISBNChecker('030640615a').is_isbn_10() == False
    assert __ISBNChecker('030640615-2').is_isbn_10() == True
    assert __ISBNChecker('030640615-2', normalize=False).is_isbn_10() == False
    assert __ISBNChecker('030640615-2', normalize=False).is_isbn_13()

# Generated at 2022-06-18 03:51:54.550944
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:52:04.045065
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:52:10.682841
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False
    assert is_json('') == False
    assert is_json(None) == False
    assert is_json(1) == False
    assert is_json(True) == False
    assert is_json(False) == False
    assert is_json(['a', 'b', 'c']) == False
    assert is_json({'a': 'b', 'c': 'd'}) == False


# Generated at 2022-06-18 03:52:28.368097
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:52:29.724961
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-18 03:52:41.041083
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email

# Generated at 2022-06-18 03:52:48.498430
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
   