

# Generated at 2022-06-21 21:23:54.493851
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('email@123.123.123.123') == True
    assert is_email('email@[123.123.123.123]') == True
    assert is_email('"email"@domain.com') == True
    assert is_email('admin@mailserver1') == True
    assert is_email('"much.more unusual"@example.com') == True
    assert is_email('"very.unusual.@.unusual.com"@example.com') == True
    assert is_email('"very.(),:;<>[]\".VERY.\"very@\\ \"very\".unusual"@strange.example.com') == True
    assert is_

# Generated at 2022-06-21 21:24:02.551116
# Unit test for function is_uuid
def test_is_uuid():
    """
    Unit test for function is_uuid.

    :return: True if unit test successful, False otherwise
    """
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf')
    assert not is_uuid('6f8aa2f9686c4ac387665712354a04cf')
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True)
    assert is_uuid(uuid.uuid4())
    return True



# Generated at 2022-06-21 21:24:07.235788
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com')
    assert is_url('https://mysite.com')
    assert not is_url('.mysite.com')



# Generated at 2022-06-21 21:24:10.282437
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram("Dermatoglyphics")
    assert is_isogram("isogram")
    assert is_isogram("LakeDistrict")
    assert not is_isogram("moose")


# Generated at 2022-06-21 21:24:13.215046
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') # returns true
    assert is_url('https://mysite.com') # returns true
    assert not is_url('.mysite.com') # returns false



# Generated at 2022-06-21 21:24:16.520494
# Unit test for function is_string
def test_is_string():
    assert is_string('foo') == True
    assert is_string(b'foo') == False
    print('Test for function is_string passed.')
test_is_string()



# Generated at 2022-06-21 21:24:24.997283
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('3423214120').is_isbn_10()
    assert not __ISBNChecker('3423214121').is_isbn_10()
    assert not __ISBNChecker('342321412').is_isbn_10()
    assert not __ISBNChecker('34232141201').is_isbn_10()
    assert not __ISBNChecker('34232A4120').is_isbn_10()
    assert not __ISBNChecker('342321412Z').is_isbn_10()


# PUBLIC API


# Generated at 2022-06-21 21:24:26.379546
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') == True
    assert is_isbn_10('150-6715214') == True
    assert is_isbn_10('150-6715214', normalize=False) == False


# Generated at 2022-06-21 21:24:29.851392
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert(is_isbn_13("9780312498580") == True)
    assert(is_isbn_13("978-0312498580") == True)
    assert(is_isbn_13("978-0312498580", normalize=False) == False)
    assert(is_isbn_13("978-0312498583") == False)
    assert(is_isbn_13("978-0312498583", normalize=False) == False)
    assert(is_isbn_13("Hello") == False)
    print("test_is_isbn_13 passed!")
test_is_isbn_13()



# Generated at 2022-06-21 21:24:32.906713
# Unit test for function words_count
def test_words_count():
    assert words_count('hello world') == 2
    assert words_count('one,two,three.stop') == 4

# Generated at 2022-06-21 21:24:49.031142
# Unit test for function is_ip_v6
def test_is_ip_v6():
    """
    Test if a string is a valid ip v6.

    It tests all possible correct inputs as well as incorrect ones.

    >>> test_is_ip_v6() #doctest: +ELLIPSIS
    True
    """
    # Valid IP v6 addresses
    assert is_ip_v6('2001:db8:0:0:1:0:0:1')
    assert is_ip_v6('2001:db8::1')
    assert is_ip_v6('2001:db8::1:1')
    assert is_ip_v6('2001:db8:0:0:1::1')
    assert is_ip_v6('2001:db8:0:1:1:1:1:1')

# Generated at 2022-06-21 21:25:01.467158
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert not is_ip_v4(None)
    assert not is_ip_v4('')
    assert not is_ip_v4(' ')
    assert not is_ip_v4('123')
    assert not is_ip_v4('10.1.1')
    assert not is_ip_v4('255.257.100.75')
    assert not is_ip_v4('255.100.100.-1')
    assert not is_ip_v4('255.0.0')
    assert not is_ip_v4('255.0.0.0.1')
    assert not is_ip_v4('localhost')
    assert not is_ip_v4('255.1.1')
    assert is_ip_v4('0.0.0.0')
    assert is_ip_

# Generated at 2022-06-21 21:25:06.475434
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999')



# Generated at 2022-06-21 21:25:09.097422
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') == True
    assert is_url('https://mysite.com') == True
    assert is_url('.mysite.com') == False



# Generated at 2022-06-21 21:25:20.822403
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert not is_email('@gmail.com')
    assert not is_email('my.email@gmail..com')
    assert is_email('my.email@gmail.com.com')
    assert is_email(r'prettyandsimple@example.com')
    assert is_email(r'somewhat.common@example.com')
    assert is_email(r'very.uncommon@example.com')
    assert is_email(r'disposable.style.email.with+symbol@example.com')
    assert is_email(r'other.email-with-dash@example.com')
    assert is_email(r'x@example.com')
    assert is_email(r'hello@example')
    assert not is_email

# Generated at 2022-06-21 21:25:22.955381
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal("1.0")
    assert not is_decimal("1")
    assert not is_decimal("b")


# Generated at 2022-06-21 21:25:34.941859
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    assert __ISBNChecker('0-13-060624-9').is_isbn_10()
    assert not __ISBNChecker('0-13-060624-9').is_isbn_13()
    assert not __ISBNChecker('978-3-16-148410-0').is_isbn_10()
    assert __ISBNChecker('978-3-16-148410-0').is_isbn_13()
    assert not __ISBNChecker('0-13-060624-8').is_isbn_10()
    assert not __ISBNChecker('0-13-060624-8').is_isbn_13()
    assert __ISBNChecker('9-7-8-3-1-6-1-4-8-4-1-0').is_is

# Generated at 2022-06-21 21:25:42.547494
# Unit test for function is_number
def test_is_number():
    assert is_number(42) == True
    assert is_number('42') == True
    assert is_number(19.99) == True
    assert is_number('19.99') == True
    assert is_number(-9.12) == True
    assert is_number('-9.12') == True
    assert is_number('1e3') == True
    assert is_number('1 2 3') == False
    assert is_number() == False

# function is_integer

# Generated at 2022-06-21 21:25:45.754863
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title')
    assert not is_slug('My blog post title')
    assert is_slug('slug-with--double-hyphen')

# Generated at 2022-06-21 21:25:48.130342
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75') == True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip('1.2.3') == False
    return test_is_ip



# Generated at 2022-06-21 21:25:53.381867
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580') == True
    assert is_isbn_13('978-0312498580') == True
    assert is_isbn_13('978-0312498580', normalize=False) == False



# Generated at 2022-06-21 21:25:58.473509
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False
    assert is_ip_v4('255.200.100.256') == False


# Generated at 2022-06-21 21:26:02.711261
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string('') != True
    assert is_full_string(None) != True
    assert is_full_string(' ') != True
    assert is_full_string('hello') == True



# Generated at 2022-06-21 21:26:14.878740
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('0876111320').is_isbn_13() is True
    assert __ISBNChecker('978-0876111324').is_isbn_13() is True
    assert __ISBNChecker('978087-611132-4').is_isbn_13() is True
    assert __ISBNChecker('978087-611132').is_isbn_13() is False
    assert __ISBNChecker('0876111321').is_isbn_13() is False
    assert __ISBNChecker('0876111320').is_isbn_13() is True
    assert __ISBNChecker('978-0876111324').is_isbn_13() is True
    assert __ISBNChecker('978087-611132-4').is_is

# Generated at 2022-06-21 21:26:16.335804
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') == True
    

# Generated at 2022-06-21 21:26:20.096864
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert(is_isbn_10('1506715214') == True)
    assert(is_isbn_10('150-6715214') == True)
    assert(is_isbn_10('150-6715214', normalize=False) == False)



# Generated at 2022-06-21 21:26:21.774151
# Unit test for function is_isbn
def test_is_isbn():
    assert not is_isbn('9780312498580')
test_is_isbn()



# Generated at 2022-06-21 21:26:27.360994
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case("my_string")
    assert is_snake_case("My_string")
    assert not is_snake_case("My_String")
    assert is_snake_case("my_string_123")
    assert not is_snake_case("_my_string")
    assert not is_snake_case("my_string_")
    assert is_snake_case("my_string", "-")


# Generated at 2022-06-21 21:26:32.681115
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('myString') == True
    assert is_camel_case('MyString') == True
    assert is_camel_case('mystring') == False
    assert is_camel_case('my string') == False
    assert is_camel_case('1Mystring') == False
    assert is_camel_case('MYSTRING') == False
    assert is_camel_case('myString123') == True
    assert is_camel_case('1') == False
    assert is_camel_case('') == False
    assert is_camel_case(None) == False



# Generated at 2022-06-21 21:26:33.749725
# Unit test for function is_number
def test_is_number():
    assert is_number('42') == True

# Generated at 2022-06-21 21:26:47.845847
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1111111111')  # check for ISBN 10
    assert not is_isbn_10('11111111111')  # check for wrong ISBN 10
    assert is_isbn_10('1506715214')  # check for ISBN 10
    assert not is_isbn_10('150-6715214')  # check for wrong ISBN 10 with hyphens
    assert is_isbn_10('1506715214')  # check for ISBN 10 with hyphens
    assert not is_isbn_10('1506715214', normalize=False)  # check for wrong ISBN 10 with hyphens
    assert is_isbn_10('150-6715214', normalize=False)  # check for ISBN 10 with hyphens

test_is_isbn_10()


# Generated at 2022-06-21 21:26:53.103785
# Unit test for function is_number
def test_is_number():
    assert is_number('42') == True
    assert is_number('19.99') == True
    assert is_number('-9.12') == True
    assert is_number('1e3') == True
    assert is_number('1 2 3') == False
    assert is_number(None) == False
    assert is_number('') == False
    assert is_number(1) == False
    assert is_number(2.2) == False
    assert is_number(True) == False
    assert is_number(False) == False

# Generated at 2022-06-21 21:27:02.698251
# Unit test for function is_isbn_13
def test_is_isbn_13():
    print("Running unit tests for function is_isbn_13")
    print(" * Valid ISBN13 (13 digits):")
    assert is_isbn_13("9788809039272")
    print(" * Valid ISBN13 (13 digits with '-')")
    assert is_isbn_13("978-880-9039272")
    print(" * Invalid ISBN13 (12 digits)")
    assert not is_isbn_13("9788809039")
    print(" * Invalid ISBN13 (13 digits, last one is X)")
    assert not is_isbn_13("978880903927X")



# Generated at 2022-06-21 21:27:05.979465
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10("1506715214") == True
    assert is_isbn_10("150-6715214") == True
    assert is_isbn_10("150-6715214", normalize=False) == False



# Generated at 2022-06-21 21:27:13.040348
# Unit test for function contains_html
def test_contains_html():
    # This function is called in the unittest file

    # Input is not a string
    if not contains_html('my string is <strong>bold</strong>'):
        print("Function \'contains_html\' failed!")
        return False

    # Input is a string
    if not contains_html('my string is not bold'):
        print("Function \'contains_html\' failed!")
        return False

    # Input is a string
    if not contains_html('my string is not bold'):
        print("Function \'contains_html\' failed!")
        return False
    print("Test for \'contains_html\' passed")
    return True



# Generated at 2022-06-21 21:27:14.603181
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('otto') == True

# Generated at 2022-06-21 21:27:25.711979
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com', allowed_schemes=['http', 'https']) 
    assert not is_url('https://mysite.com', allowed_schemes=['http']) 
    assert is_url('ftp://www.mysite.com', allowed_schemes=['ftp']) 
    assert not is_url('www.mysite.com') 
    assert not is_url('.mysite.com') 
    assert is_url('http://www.mysite.com') 
    assert is_url('https://www.mysite.com') 
    assert is_url('ftps://www.mysite.com') 
    assert is_url('ftp://www.mysite.com') 

# Generated at 2022-06-21 21:27:37.567479
# Unit test for function is_palindrome
def test_is_palindrome():
    assert True == is_palindrome('LOL')
    assert True == is_palindrome('Lol', ignore_case=True)
    assert False == is_palindrome('giallo')
    assert False == is_palindrome('Palindrome')
    assert False == is_palindrome('I topi non avevano nipoti')
    assert False == is_palindrome(123)
    assert True == is_palindrome(123321)
    assert True == is_palindrome('8')
    assert False == is_palindrome('9A')
    assert True == is_palindrome('ABBA')
    assert True == is_palindrome('ABBA', ignore_case=True)

    # Testing palindromes with spaces
    assert True == is_palindrome('AB B A')

# Generated at 2022-06-21 21:27:43.106036
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    isbn_checker = __ISBNChecker('0393048470')
    actual_result = isbn_checker.is_isbn_10()
    expected_result = True
    assert actual_result == expected_result


# Generated at 2022-06-21 21:27:46.719207
# Unit test for function is_ip_v6
def test_is_ip_v6():
    """
    Test for is_ip_v6.
    """
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7234') == True
    assert is_ip_v6('nope') == False
    assert is_ip_v6('4.12.200.4') == False
    # assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7234') == False



# Generated at 2022-06-21 21:27:52.996531
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    assert __ISBNChecker('1234567891').is_isbn_10() is True
    assert __ISBNChecker('9-7800-79-39-8').is_isbn_10() is True
    assert __ISBNChecker('978-0-306-40615-7').is_isbn_13() is True
    assert __ISBNChecker('978-0-306-40615-7', normalize=False).is_isbn_13() is True

# PUBLIC API



# Generated at 2022-06-21 21:27:58.632514
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title') == True
    assert is_slug('My blog post title') == False
    # Test whether the character specified in the parameter is used
    assert is_slug('my_blog_post_title',separator = '_') == True
    assert is_slug('my_blog_post_title',separator = '-') == False


# Generated at 2022-06-21 21:28:10.392433
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    is_string('isbn') is True
    is_number('1234567890') is True
    is_number('123456789a') is False
    is_number(None) is False
    is_number(1234567890) is False
    is_number(1.234567890) is False

    # Test constructor
    ok = False
    try:
        checker = __ISBNChecker('1234567890')
        checker = __ISBNChecker(1234567890, False)
    except InvalidInputError:
        ok = True

    assert ok

    # Test is_isbn_10 method
    ok = False

# Generated at 2022-06-21 21:28:18.123466
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com')                                 # True
    assert is_url('https://mysite.com')                                    # True
    assert is_url('.mysite.com')                                           # False
    assert is_url('ftp://ftp.mysite.com')                                  # True
    assert is_url('ftp://ftp.mysite.com', allowed_schemes=['ftp'])         # True
    assert is_url('ftp://ftp.mysite.com', allowed_schemes=['https'])       # False
# END test_is_url


# Full email example:
# john.doe@mail.com

# Generated at 2022-06-21 21:28:25.094940
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:0:0:8a2e:370:7334') == True
    assert is_ip_v6('2001:db8:85a3:0:0:8a2e:370:7334') == True
    assert is_ip_v6('::1') == True
    assert is_ip_v6('::') == True
    assert is_ip_v6('2001:db8:85a3:0:0:8a2e:370:7334') == True
    assert is_ip_v6('FEDC:BA98:7654:3210:FEDC:BA98:7654:3210') == True
    assert is_ip_v6('1080:0:0:0:8:800:200C:417A')

# Generated at 2022-06-21 21:28:27.392887
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title') == True
    assert is_slug('My blog post title') == False
is_slug('My blog post title')


# Generated at 2022-06-21 21:28:32.900487
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('foo_bar') == True
    assert is_snake_case('foo-bar') == False
    assert is_snake_case('foo-bar-baz', '-') == True
    assert is_snake_case('foo-bar-baz') == False
    assert is_snake_case('-foo-bar-baz') == True
    assert is_snake_case('foo1-bar1-baz') == True
    assert is_snake_case('--') == True
    assert is_snake_case('foo') == False
    assert is_snake_case('foo_') == False


# Generated at 2022-06-21 21:28:40.710144
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title')
    assert not is_slug('My blog post title')

    # custom separator
    assert is_slug('my-blog-post-title', '-')
    assert not is_slug('My blog post title', '-')
    assert is_slug('My blog post title', '!')
    assert not is_slug('My blog post title', '!')

    # non-string
    assert not is_slug(0)
    assert not is_slug(1.1)
    assert not is_slug(None)
    assert not is_slug([])

# Generated at 2022-06-21 21:28:44.882100
# Unit test for function is_string
def test_is_string():
    assert is_string('foo')
    assert not is_string(None)
    assert not is_string(b'bar')
    assert not is_string([1, 2, 3])
    assert not is_string({'foo', 'bar'})



# Generated at 2022-06-21 21:28:47.278625
# Unit test for function is_isbn
def test_is_isbn():
    assert(is_isbn('9780312498580'))
    assert(is_isbn('1506715214'))
    return True


# Generated at 2022-06-21 21:29:04.844047
# Unit test for function is_number
def test_is_number():
    assert is_number(1) == True
    assert is_number(-1) == True
    assert is_number('-1') == True
    assert is_number('1.2') == True
    assert is_number('-1.2') == True
    assert is_number(1.2) == False
    assert is_number(-1.2) == False
    assert is_number('1.2.3') == False
    assert is_number('-1.2.3') == False
    assert is_number('1e3') == True
    assert is_number('-1e3') == True
    assert is_number('1.2e3') == True
    assert is_number('-1.2e3') == True
    assert is_number('1.2e') == True

# Generated at 2022-06-21 21:29:08.712847
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') == True
    assert is_isbn('1506715214') == True
    assert is_isbn('abc') == False


# Generated at 2022-06-21 21:29:11.520584
# Unit test for function is_string
def test_is_string():
    assert(is_string("foo"))
    assert(not is_string(b'foo'))
# end of Unit test for function is_string



# Generated at 2022-06-21 21:29:16.669545
# Unit test for function is_ip_v4
def test_is_ip_v4():
    ip_list = {'255.200.100.75', '255.200.100.999', 'nope'}
    for ip in ip_list:
        is_v4 = is_ip_v4(ip)
        print('ip: ', ip, '\t is ip v4: ', is_v4)




# Generated at 2022-06-21 21:29:18.772937
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    checker = __ISBNChecker('978-1-56619-909-4')
    assert checker.is_isbn_13() == True



# Generated at 2022-06-21 21:29:22.426482
# Unit test for function is_number
def test_is_number():
    assert is_number('42') == True
    assert is_number('19.99') == True
    assert is_number('-9.12') == True
    assert is_number('1e3') == True
    assert is_number('1 2 3') == False



# Generated at 2022-06-21 21:29:32.663884
# Unit test for function is_number
def test_is_number():
    """
    Test cases for function is_number.
    """
    assert is_number("23")
    assert is_number("123.23")
    assert is_number("-23")
    assert is_number("-123.23")
    assert is_number("+23")
    assert is_number("+123.23")
    assert is_number("23E5")
    assert is_number("23e5")
    assert is_number("-23E5")
    assert is_number("-23e5")
    assert is_number("23E-5")
    assert is_number("23e-5")
    assert is_number("23E+5")
    assert is_number("23e+5")
    assert is_number("-23.23E+5")

# Generated at 2022-06-21 21:29:40.349746
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334') is True
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?') is False
    assert is_ip_v6('2001:db8:85a3:0:0:8a2e:370:7334') is False
    assert is_ip_v6('2001:0000:85a3:0000:0000:8a2e:370:7334') is False
    assert is_ip_v6('2001:0000:85a3::8a2e:370:7334') is False
    assert is_ip_v6('2001:0000:85a3:0::8a2e:370:7334') is False

# Generated at 2022-06-21 21:29:44.773430
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') == True
    assert is_isbn_10('150-6715214') == True
    assert is_isbn_10('150-6715214', normalize=False) == False


# Generated at 2022-06-21 21:29:50.635558
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker("978013468599").is_isbn_13() == True
    assert __ISBNChecker("97801346859").is_isbn_13() == False
    assert __ISBNChecker("978013468597").is_isbn_13() == False
    assert __ISBNChecker("9780134685988").is_isbn_13() == False
    assert __ISBNChecker("978013468598X").is_isbn_13() == False


# Generated at 2022-06-21 21:30:04.987846
# Unit test for function is_string
def test_is_string():
    assert is_string(42) == False
    assert is_string('42') == True
    assert is_string(u'42') == True
    assert is_string(b'42') == False
    assert is_string([]) == False

# Generated at 2022-06-21 21:30:14.107632
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card("3400 0000 0000 009") == True
    assert is_credit_card("6011 0000 0000 0004") == True
    assert is_credit_card("3088 0000 0000 0009") == True
    assert is_credit_card("3800 0000 0000 009") == True
    assert is_credit_card("3000 0000 0000 04") == True
    assert is_credit_card("5610 0000 0000 0008") == True
    assert is_credit_card("8000000000000063") == True
    assert is_credit_card("8000000000000064") == True
    assert is_credit_card("8000000000000065") == True
    assert is_credit_card("8000000000000066") == True
    assert is_credit_card("8000000000000067") == True

# Generated at 2022-06-21 21:30:15.894698
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog')
    assert not is_pangram('The quick brown fox jumps over the lazy dog.')
    assert not is_pangram('Hello world')
    return True


# Generated at 2022-06-21 21:30:18.521400
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('42.0') == True
    assert is_decimal('42') == False
# End of unit test for function is_decimal



# Generated at 2022-06-21 21:30:25.897226
# Unit test for function is_credit_card
def test_is_credit_card():
    assert(is_credit_card('4242424242424242', 'VISA') == True)
    assert(is_credit_card('4242 4242 4242 4242') == True)
    assert(is_credit_card('4242 4242') == False)
    assert(is_credit_card('4242 4242 4242 4242', 'MASTERCARD') == False)
    assert(is_credit_card('5105105105105100', 'MASTERCARD') == True)
    assert(is_credit_card('378282246310005', 'AMERICAN_EXPRESS') == True)
    assert(is_credit_card('6011111111111117', 'DISCOVER') == True)
    assert(is_credit_card('30569309025904', 'DINERS_CLUB') == True)

# Generated at 2022-06-21 21:30:33.511340
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') == True
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf') == True
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf', allow_hex = True) == True
# Unit test is_snake_case

# Generated at 2022-06-21 21:30:44.498842
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4224355662994929', card_type='VISA')
    assert is_credit_card('5473599032983278', card_type='MASTERCARD')
    assert is_credit_card('342903111122085', card_type='AMERICAN_EXPRESS')
    assert is_credit_card('302653195313', card_type='DINERS_CLUB')
    assert is_credit_card('6011400373949200', card_type='DISCOVER')
    assert is_credit_card('3589478517943348', card_type='JCB')

    assert is_credit_card('4224355662994929')
    assert is_credit_card('5473599032983278')

# Generated at 2022-06-21 21:30:48.345193
# Unit test for function is_camel_case
def test_is_camel_case():
    # Given
    input_string = 'MyString'

    # When
    result = is_camel_case(input_string)

    # Then
    assert result == True



# Generated at 2022-06-21 21:30:56.418834
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42') == True
    assert is_integer('42.0') == False
    assert is_integer('+1') == True
    assert is_integer('-1') == True
    assert is_integer('.1') == False
    assert is_integer('-3e-2') == False
    assert is_integer('3e-2') == False
    assert is_integer('-3e+2') == False
    assert is_integer('3e+2') == False
    assert is_integer('0.2') == False
    assert is_integer('2.') == True



# Generated at 2022-06-21 21:31:09.456892
# Unit test for function is_number
def test_is_number():
    assert is_number('42')
    assert is_number('19.99')
    assert is_number('1e5')
    assert is_number('1e+5')
    assert is_number('1e-5')
    assert is_number('-9.12')
    assert is_number('1')
    assert is_number('1,2')
    assert is_number('1,2.3')
    assert is_number('1,2e3')
    assert is_string('1,2e-3')
    assert is_number('-3,14e-3')
    assert is_number('3E3')
    assert not is_number('1 2 3')
    assert not is_number('foo')
    assert not is_number(None)


# Generated at 2022-06-21 21:31:19.757825
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    assert __ISBNChecker('0306406152')
    assert __ISBNChecker('978-0306406154')
    assert __ISBNChecker('978-0306406154', False)



# Generated at 2022-06-21 21:31:28.462509
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') == True
    assert is_isbn_10('150-6715214') == True
    assert is_isbn_10('150-6715214', normalize=False) == False
    assert is_isbn_10('978-3-16-148410-0') == False
    assert is_isbn_10('') == False
    assert is_isbn_10(' ') == False
    assert is_isbn_10('   ') == False
    assert is_isbn_10('hello') == False
    assert is_isbn_10('1234567899') == True
    assert is_isbn_10('12345678998') == False
    assert is_isbn_10('12345-67899-8') == True
    assert is_isbn

# Generated at 2022-06-21 21:31:34.826183
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    assert __ISBNChecker('0000000000').input_string == '0000000000'
    assert __ISBNChecker('1234567890').input_string == '1234567890'
    assert __ISBNChecker('123-456-789-x').input_string == '123456789X'

    try:
        __ISBNChecker(123)
    except InvalidInputError:
        pass


# PUBLIC API


# Error handling:
# - Raise an Exception if the input is not string
# - Return None if the input is a string that does not conform the pattern
# - Return the found pattern if the input is a string that conforms the pattern

# Generated at 2022-06-21 21:31:46.931372
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    assert __ISBNChecker('9780395377527').input_string == '9780395377527', \
        "input_string is not correct"

    assert __ISBNChecker('9780395377527', False).input_string == '9780395377527', \
        "__ISBNChecker('9780395377527', False).input_string is not correct"

    assert __ISBNChecker('9780395377527', True).input_string == '9780395377527', \
        "__ISBNChecker('9780395377527', True).input_string is not correct"


# Generated at 2022-06-21 21:31:47.790923
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('-27') == True


# Generated at 2022-06-21 21:31:50.394986
# Unit test for function is_string
def test_is_string():
    assert is_string('')
    assert is_string('afsd')

    assert not is_string(12)
    assert not is_string(12.3)



# Generated at 2022-06-21 21:31:53.303250
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title')
    assert not is_slug('My blog post title')



# Generated at 2022-06-21 21:31:56.724949
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('my string is <strong>bold</strong>') == True
    assert contains_html('my string is not bold') == False
test_contains_html()


# Generated at 2022-06-21 21:32:07.354712
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    assert is_string(__ISBNChecker('978-87-93272-57-7').input_string)
    assert __ISBNChecker('978-87-93272-57-7').input_string == '9788793272577'
    assert __ISBNChecker('9788793272577', normalize=False).input_string == '9788793272577'

    # test various false inputs
    assert __ISBNChecker('978-87-93272-57-7', normalize=False).input_string == '978-87-93272-57-7'
    assert not __ISBNChecker('978-87-93272-57-9').is_isbn_13()
    assert not __ISBNChecker('978-87-93272-57-9').is_isbn_10()

# Generated at 2022-06-21 21:32:14.385714
# Unit test for function is_string
def test_is_string():
    assert is_string('') == True
    assert is_string('hello') == True
    assert is_string(' ') == True
    assert is_string(1) != True
    assert is_string(True) != True
    assert is_string(False) != True
    assert is_string(None) != True
    assert is_string([]) != True
    assert is_string({}) != True


# Generated at 2022-06-21 21:32:33.411314
# Unit test for function is_email
def test_is_email():
    assert not is_email(None)
    assert not is_email('')
    assert not is_email(' ')
    assert not is_email('.')
    assert not is_email('\@gmail.com')
    assert not is_email('.@gmail.com')

    assert is_email('a@a.a')
    assert is_email('my_email@gmail.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-123provider.com')
    assert is_email('123@gmail.com')

    assert is_email('"\\ \\"a\\" "\\@gmail.com')
    assert is_email('"John Doe" <john.doe@gmail.com>')

# Generated at 2022-06-21 21:32:35.225633
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('hello')==False
    assert is_isogram('dermatoglyphics')==True
test_is_isogram()


# Generated at 2022-06-21 21:32:40.153803
# Unit test for function words_count
def test_words_count():
    assert words_count('hello world') == 2
    assert words_count('hello') == 1
    assert words_count('1 2 3 4') == 4
    assert words_count('nothing') == 1
    assert words_count('one,two,three.stop') == 4
    assert words_count('one,two,three.stop') == 4
    assert words_count('') == 0
    assert words_count('this is a very long text, with multiple sentences.') == 13

test_words_count()


# Generated at 2022-06-21 21:32:51.365373
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-3-16-148410-0').is_isbn_13()  # True
    assert __ISBNChecker('9780316148410').is_isbn_13()  # True
    assert __ISBNChecker('0-316-148410-9').is_isbn_13()  # False
    assert __ISBNChecker('9783161484106').is_isbn_13()  # True
    assert __ISBNChecker('978316148410X').is_isbn_13()  # True
    assert __ISBNChecker('978316148410x').is_isbn_13()  # True
    assert __ISBNChecker('978316148410').is_isbn_13()  # True

# Generated at 2022-06-21 21:32:55.118676
# Unit test for function is_ip_v4
def test_is_ip_v4():
        assert is_ip_v4("255.200.100.75") == True
        assert is_ip_v4("nope") == False
        assert is_ip_v4("255.200.100.999") == False

# Generated at 2022-06-21 21:33:04.247152
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    try:
        checker = __ISBNChecker(None)
        assert False

    except InvalidInputError:
        assert True

    try:
        checker = __ISBNChecker(True)
        assert False

    except InvalidInputError:
        assert True

    try:
        checker = __ISBNChecker(1)
        assert False

    except InvalidInputError:
        assert True

    try:
        checker = __ISBNChecker('')
        assert False

    except InvalidInputError:
        assert True

    try:
        checker = __ISBNChecker('1234')
        assert True

    except InvalidInputError:
        assert False

    assert checker.input_string == '1234'


# Generated at 2022-06-21 21:33:07.719509
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog') == True
    assert is_pangram('hello world') == False
test_is_pangram()

# Generated at 2022-06-21 21:33:12.764563
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580') # returns true
    assert is_isbn_13('978-0312498580') # returns true
    assert is_isbn_13('978-0312498580', normalize=False) # returns false


# Generated at 2022-06-21 21:33:21.592327
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('MyString') == True
    assert is_camel_case('myString') == True
    assert is_camel_case('mystring') == False
    assert is_camel_case('myString12') == True
    assert is_camel_case('1mystring') == False
    assert is_camel_case('') == False
    assert is_camel_case(None) == False
    assert is_camel_case('-') == False
    assert is_camel_case('my-string') == False
    assert is_camel_case('-mystring') == False



# Generated at 2022-06-21 21:33:24.852572
# Unit test for function is_isogram
def test_is_isogram():
    print ("Testing is_isogram ...")
    assert (is_isogram('dermatoglyphics') == True)
    assert (is_isogram('hello') == False)
    print ("PASSED")
test_is_isogram()

