

# Generated at 2022-06-21 21:23:41.224878
# Unit test for function is_isogram
def test_is_isogram():
    print('testing function is_isogram')
    for str in range(4):
        if is_isogram(str) == True:
            print('pass')
        else:
            print('fail')
    for str in "Dermatoglyphics" and "isogram":
        if is_isogram(str) == True:
            print('pass')
        else:
            print('fail')
    for str in "moose" and "isIsogram" and "aba" and "moOse":
        if is_isogram(str) == False:
            print('pass')
        else:
            print('fail')


# Generated at 2022-06-21 21:23:50.778153
# Unit test for function is_palindrome
def test_is_palindrome():
    failures = []

# Generated at 2022-06-21 21:24:02.465170
# Unit test for function is_email
def test_is_email():
    assert is_email("joe@example.com") == True
    assert is_email("joe.schmoe@example.com") == True
    assert is_email("joe@[192.168.0.1]") == True
    assert is_email("joe+label@example.com") == True
    assert is_email("\"Joe Schmoe\"@example.com") == True
    assert is_email("joe.schmoe@example.com") == True
    assert is_email("joe.schmoe@example.com") == True
    assert is_email("\"Joe Schmoe\"@example.com") == True
    assert is_email("joe.schmoe@123.example.com") == True
    assert is_email("joe.schmoe@example.co.uk") == True

# Generated at 2022-06-21 21:24:14.560667
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title') == True
    assert is_slug('My blog post title') == False
    assert is_slug('a-bc-def') == True
    assert is_slug('a-bc-def-') == False
    assert is_slug('a-bc-def-123') == True
    assert is_slug('a-bc-def-12-3') == True
    assert is_slug('a-bc-def-123-') == False
    assert is_slug('a-bc-def-123-g') == True
    assert is_slug('-a-bc-def') == False
    assert is_slug('a-bc-def-') == False
    assert is_slug('a--bc') == True

# Generated at 2022-06-21 21:24:17.262251
# Unit test for function is_ip
def test_is_ip():
    ip=is_ip('255.200.100.75')
    ip6=is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334')
    ip3=is_ip('1.2.3')
    print(ip,ip6,ip3)
test_is_ip()


# Generated at 2022-06-21 21:24:18.974901
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75')
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334')
    assert not is_ip('1.2.3')

# Generated at 2022-06-21 21:24:22.249047
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    checker = __ISBNChecker('978-0-306-40615-7')

    assert checker.input_string == '9780306406157'



# Generated at 2022-06-21 21:24:27.792332
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('9781420931693').is_isbn_13() is True
    assert __ISBNChecker('1234567890123').is_isbn_13() is False
    assert __ISBNChecker('12345678901234').is_isbn_13() is False



# Generated at 2022-06-21 21:24:37.853206
# Unit test for function is_credit_card
def test_is_credit_card():
    # The following should return false
    assert not is_credit_card('')
    assert not is_credit_card(None)
    assert not is_credit_card('not-a-credit-card')
    # The following should return true
    assert is_credit_card('3095151402668509')
    assert is_credit_card('3566002020360505')
    assert is_credit_card('5555555555554444')
    assert is_credit_card('5105105105105100')
    assert is_credit_card('4111111111111111')
    assert is_credit_card('6011111111111117')
    assert is_credit_card('6011000990139424')
    assert is_credit_card('38520000023237')
    assert is_credit_card('6200000000000005')

# Generated at 2022-06-21 21:24:48.599366
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('myString') == False
    assert is_camel_case('my String') == False
    assert is_camel_case('My String') == False
    assert is_camel_case('0My String') == False
    assert is_camel_case('MyString0') == True
    assert is_camel_case('myString0') == False
    assert is_camel_case('0myString') == False
    assert is_camel_case('MyString') == True
    assert is_camel_case('MyString10') == True
    assert is_camel_case('M') == True
    assert is_camel_case('M1') == True
    assert is_camel_case('m') == False



# Generated at 2022-06-21 21:24:58.836559
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('foo_bar_baz') == True
    assert is_snake_case('foo') == False

# Generated at 2022-06-21 21:25:02.936973
# Unit test for function is_isogram
def test_is_isogram():
    pass
    # assert(is_isogram("lumberjacks")) == True
    # assert(is_isogram("isograms")) == True
    # assert(is_isogram("isograms")) == True
    # assert(is_isogram("isogramssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss

# Generated at 2022-06-21 21:25:09.315039
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('dermatoglyphics') == True
    assert is_isogram('isograms') == True
    assert is_isogram('aba') == False
    assert is_isogram('moOse') == False
    assert is_isogram('') == True
    return "Function 'is_isogram' passed unit test!"
print(test_is_isogram())


# Generated at 2022-06-21 21:25:15.740629
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0201896834').is_isbn_10() == False
    assert __ISBNChecker('0201896831').is_isbn_10() == True
    assert __ISBNChecker('0201896830').is_isbn_10() == False
    assert __ISBNChecker('0201896831-X').is_isbn_10() == True

# Generated at 2022-06-21 21:25:23.571092
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('CamelCase') == True
    assert is_camel_case('invalidCamelCase') == False
    assert is_camel_case('_camelCase') == True
    assert is_camel_case('lowercase') == False
    assert is_camel_case('UPPERCASE') == False
    assert is_camel_case('any.string') == False
    assert is_camel_case('1stCamelCase') == False
    assert is_camel_case('camelCase1') == True



# Generated at 2022-06-21 21:25:35.644724
# Unit test for function is_ip_v4
def test_is_ip_v4():
    """
    *Example:*

    >>> test_is_ip_v4()
    True

    :return: True for a successful test.
    """
    assert is_ip_v4('255.200.100.75')
    assert is_ip_v4('0.0.0.0')
    assert is_ip_v4('127.0.0.1')
    assert is_ip_v4('192.168.0.1')
    assert not is_ip_v4('')
    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999')

    # 495 was a bug in a previous version
    assert is_ip_v4('55.55.55.495')
    return True
test_is_ip_v4()

# Generated at 2022-06-21 21:25:39.927756
# Unit test for function is_isbn_10
def test_is_isbn_10():
    #assert is_isbn_10('isbn_10') == False, "The string is not ISBN 10"
    assert is_isbn_10('1506715214') == True, "The String is ISBN 10"

# Generated at 2022-06-21 21:25:48.171590
# Unit test for function is_integer
def test_is_integer():
    positive_test_cases = ['42', '-42', '42.0', '42000000', '42000000.0', '42000000E100', '42000000E100', '42000000.0E100']
    negative_test_cases = ['', '42.', ' 42 ', ' 42000000 ']

    for test_case in positive_test_cases:
        assert is_integer(test_case)
    
    for test_case in negative_test_cases:
        assert not is_integer(test_case)
    return True


# Generated at 2022-06-21 21:25:53.715052
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram("Dermatoglyphics") == True
    assert is_isogram("isogram") == True
    assert is_isogram("aba") == False
    assert is_isogram("moOse") == False
    assert is_isogram("isIsogram") == False
    assert is_isogram("") == True

if __name__ == "__main__":
    test_is_isogram()


# Generated at 2022-06-21 21:25:57.945182
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():

    # Correct params
    assert __ISBNChecker('978-0-306-40615-7')
    # Incorrect params
    try:
        __ISBNChecker(None)
    except InvalidInputError:
        pass


# PUBLIC API



# Generated at 2022-06-21 21:26:11.646645
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    assert __ISBNChecker('978-0-306-40615-7', normalize=False).input_string == '978-0-306-40615-7'
    assert __ISBNChecker('978-0-306-40615-7').input_string == '9780306406157'


# Generated at 2022-06-21 21:26:20.209165
# Unit test for function is_camel_case
def test_is_camel_case():
    assert not is_camel_case(None)
    assert not is_camel_case('')
    assert not is_camel_case(' ')
    assert not is_camel_case('0myString')
    assert not is_camel_case('mystring')
    assert not is_camel_case('myString!')
    assert not is_camel_case('MyString$')
    assert is_camel_case('MyString')
    assert not is_camel_case('0')
    assert not is_camel_case('myString1')
    assert is_camel_case('myString2345')



# Generated at 2022-06-21 21:26:25.485405
# Unit test for function contains_html
def test_contains_html():
    assert contains_html("<html>")
    assert contains_html("<html />")
    assert contains_html("<p>Hello world!</p>")
    assert not contains_html("<p>Hello world!")
    assert not contains_html("Hello world!</p>")
    assert not contains_html("<a>hello</b>")
    assert contains_html("<b>hello</b>")
    assert contains_html("<a href=\"http://example.com\">hello</a>")
    assert contains_html("<abbr title=\"Title\">A</abbr>")
    assert contains_html("<abbr title=\"Title\"><a href=\"http://example.com\">A</a></abbr>")
    assert contains_html("<a>1<a>2</a>")

# Generated at 2022-06-21 21:26:27.702319
# Unit test for function is_string
def test_is_string():
    assert is_string('foo')
    assert not is_string(b'foo')



# Generated at 2022-06-21 21:26:33.106840
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title')
    assert is_slug('my-blog-post-title-', '-')
    assert is_slug('my_blog_post_title', '_')
    assert is_slug('my blog post title') is False
    assert is_slug('my-b-log-post-title') is False



# Generated at 2022-06-21 21:26:37.876470
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf')
    assert not is_uuid('6f8aa2f9686c4ac387665712354a04cf')
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True)



# Generated at 2022-06-21 21:26:41.283192
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:0db8:85a3:0000:0000:8a2e:0370:7334'), True
    assert is_ip_v6('2001:0db8:85a3:0000:0000:8a2e:0370:?'), False
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334'), True
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?'), False


# Generated at 2022-06-21 21:26:47.701486
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    assert __ISBNChecker('0-306-40615-2').input_string == '03064406152'
    assert __ISBNChecker('0-306-40615-2', False).input_string == '0-306-40615-2'

    with pytest.raises(InvalidInputError): __ISBNChecker(None)



# Generated at 2022-06-21 21:26:52.109804
# Unit test for function is_snake_case
def test_is_snake_case():
    assert (is_snake_case(input_string=None) == False)
    assert (is_snake_case('foo_bar_baz') == True)
    assert (is_snake_case('foo') == False)
    assert (is_snake_case('HelloWorld') == False)
    assert (is_snake_case('hello-world') == True)
# end test_is_snake_case



# Generated at 2022-06-21 21:26:58.512565
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('1.2.3.4')
    assert is_ip_v4('255.0.0.0')
    assert not is_ip_v4('256.0.0.0')
    assert not is_ip_v4('255.0.0.0q')
    assert not is_ip_v4('-255.0.0.0')
    assert not is_ip_v4('')
    assert not is_ip_v4('2.2.2.')
    assert not is_ip_v4('.2.2.2')
    assert not is_ip_v4('.2.2.2.')
    assert not is_ip_v4('a.2.2.2')

# Generated at 2022-06-21 21:27:14.653150
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('42.0') == True
    assert is_decimal('42') == False



# Generated at 2022-06-21 21:27:25.753387
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    isbn_checker = __ISBNChecker('121456789')
    assert isbn_checker.is_isbn_10() is False
    assert isbn_checker.is_isbn_13() is False
    isbn_checker = __ISBNChecker('10603205')
    assert isbn_checker.is_isbn_10() is True
    assert isbn_checker.is_isbn_13() is False
    isbn_checker = __ISBNChecker('97810603205')
    assert isbn_checker.is_isbn_10() is True
    assert isbn_checker.is_isbn_13() is True
    isbn_checker = __ISBNChecker('106032059X')
    assert isbn_checker.is_isbn_

# Generated at 2022-06-21 21:27:29.970458
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title') == True
    assert is_slug('My blog post title') == False

# Generated at 2022-06-21 21:27:32.657254
# Unit test for function is_isbn_13
def test_is_isbn_13():
    input_string = '9780312498580'
    print(is_isbn_13(input_string))

test_is_isbn_13()


# Generated at 2022-06-21 21:27:36.310761
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('42.0') == True
    assert is_decimal('42') == False
    # Test for invalid input
    try:
        is_decimal(4)
    except Exception:
        pass
    else:
        assert False


# Generated at 2022-06-21 21:27:38.141834
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog')
    assert not is_pangram('Hello World!')

# Generated at 2022-06-21 21:27:41.993513
# Unit test for function is_isbn_10
def test_is_isbn_10():
    expected = True
    actual = is_isbn_10('1506715214')
    assert expected == actual

    expected = True
    actual = is_isbn_10('150-6715214')
    assert expected == actual

    expected = False
    actual = is_isbn_10('150-6715214', normalize=False)
    assert expected == actual


# Generated at 2022-06-21 21:27:47.685513
# Unit test for function is_ip_v4
def test_is_ip_v4():
    #Testing ip validity
    assert(is_ip_v4('255.200.100.75') == True)
    assert(is_ip_v4('nope') == False)
    assert(is_ip_v4('255.200.100.999') == False)
    #Testing empty/null values
    assert(is_ip_v4('') == False)
    assert(is_ip_v4('   ') == False)
    assert(is_ip_v4(None) == False)
    assert(is_ip_v4(0.0) == False)
    assert(is_ip_v4(0) == False)
    assert(is_ip_v4() == False)
    assert(is_ip_v4(False) == False)

# Generated at 2022-06-21 21:27:57.318695
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    print('is_isbn_13')
    assert __ISBNChecker('978-81-7597-052-9').is_isbn_13() is True
    assert __ISBNChecker('9788175995399').is_isbn_13() is True
    assert __ISBNChecker('9788101152581').is_isbn_13() is True
    assert __ISBNChecker('9788175970501').is_isbn_13() is True
    assert __ISBNChecker('979-822-857-321').is_isbn_13() is True

    assert __ISBNChecker('978-81-7597-052-9', normalize=False).is_isbn_13() is True

# Generated at 2022-06-21 21:27:59.552305
# Unit test for function is_ip_v6
def test_is_ip_v6():
    ip = '2001:db8:85a3:0000:0000:8a2e:370:7334'
    assert is_ip_v6(ip)
    assert not is_ip_v6(ip+'?')


# Generated at 2022-06-21 21:28:33.555905
# Unit test for function is_json
def test_is_json():
    assert(is_json('{"name": "Peter"}'))
    assert(is_json('[1, 2, 3]'))
    assert(not is_json('{nope}'))



# Generated at 2022-06-21 21:28:38.313975
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert(is_ip_v4('255.200.100.75'))
    assert(not is_ip_v4('nope'))
    assert(not is_ip_v4('255.200.100.999'))
    print('Test passed for is_ip_v4()')
# test_is_ip_v4()


# Generated at 2022-06-21 21:28:43.183209
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-21 21:28:47.428574
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('1.2')
    assert not is_decimal('2')
    assert is_decimal('+1.3e-3')
    assert not is_decimal('ABCD')
    assert not is_decimal('')
    assert not is_decimal('  ')

# Generated at 2022-06-21 21:28:52.485310
# Unit test for function words_count
def test_words_count():
    assert words_count('hello world') == 2
    assert words_count('one,two,three.stop') == 4
    assert words_count('! @ # % ... []') == 0
    assert words_count('some more words here') == 4

test_words_count()


# Generated at 2022-06-21 21:28:54.387189
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('978-0-596-52068-7') == True
    assert is_isbn('0-596-52068-9') == True
    assert is_isbn('0-596-52068-7') == False

# Generated at 2022-06-21 21:29:00.004401
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    # Case 1: Invalid input
    assert False == __ISBNChecker('').is_isbn_13()
    assert False == __ISBNChecker('123456789012345').is_isbn_13()
    assert False == __ISBNChecker('A12345678901X').is_isbn_13()
    assert False == __ISBNChecker('12345678901X').is_isbn_13()

    # Case 2: Valid input
    assert True == __ISBNChecker('978-3-16-148410-0').is_isbn_13()
    assert True == __ISBNChecker('9783161484100').is_isbn_13()
    assert True == __ISBNChecker('978-316-148410-1').is_isbn_13()

# Generated at 2022-06-21 21:29:08.005858
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('app-0a-c')
    assert is_slug('app0-a-c', separator = '0')
    assert not is_slug('app-0a-c-')
    assert not is_slug('app-0a-c-', separator = '0')
    assert not is_slug('a-bc')
    assert not is_slug('a0bc', separator = '0')
    assert not is_slug('-a-bc')
    assert not is_slug('-a0bc', separator = '0')
    assert not is_slug('a-bc-')
    assert not is_slug('a0bc-', separator = '0')
    assert not is_slug('-a-bc-')

# Generated at 2022-06-21 21:29:18.736952
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert not __ISBNChecker('').is_isbn_13()
    assert not __ISBNChecker('978-613-0-60286-6').is_isbn_13()
    assert not __ISBNChecker('978-0-13-149505-0').is_isbn_13()
    assert not __ISBNChecker('77978031236861').is_isbn_13()
    assert not __ISBNChecker('978-0-13-149505-1').is_isbn_13()

    assert __ISBNChecker('9786130060286').is_isbn_13()
    assert __ISBNChecker('9786130060286', False).is_isbn_13()
    assert __ISBNChecker('978613006028').is_isbn_13()
    assert __

# Generated at 2022-06-21 21:29:22.798577
# Unit test for function is_number
def test_is_number():
    assert is_number('42') == True
    assert is_number('19.99') == True
    assert is_number('-9.12') == True
    assert is_number('1e3') == True
    assert is_number('1 2 3') == False
    assert is_number('') == False



# Generated at 2022-06-21 21:29:58.711313
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string('hello') == True
    assert is_full_string('hello world') == True
    assert is_full_string('hello\nworld') == True
    assert is_full_string('hello\tworld') == True
    assert is_full_string('hello, world') == True
    assert is_full_string('hello\u0020world') == True
    assert is_full_string('') == False
    assert is_full_string(' ') == False
    assert is_full_string('\n') == False
    assert is_full_string('\t') == False
    assert is_full_string('\u0020') == False
    assert is_full_string(None) == False

# Generated at 2022-06-21 21:30:02.538047
# Unit test for function is_url
def test_is_url():
    if is_url('https://www.google.com') is True:
        print('True')

# Generated at 2022-06-21 21:30:12.674590
# Unit test for function is_ip
def test_is_ip():
    print("is_ip_v6('2001:db8:85a3:0000:0000:8a2e:0370:7334')")
    print(is_ip_v6('2001:db8:85a3:0000:0000:8a2e:0370:7334'))
    print("is_ip_v4('255.200.100.75')")
    print(is_ip_v4('255.200.100.75'))
    print("is_ip('255.200.100.75')")
    print(is_ip('255.200.100.75'))
    print("is_ip('2001:db8:85a3:0000:0000:8a2e:0370:7334')")

# Generated at 2022-06-21 21:30:16.074572
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') # returns true
    assert is_json('[1, 2, 3]') # returns true
    assert is_json('{nope}') # returns false


# Generated at 2022-06-21 21:30:21.332274
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('4.2')
    assert not is_decimal('42')
    assert not is_decimal('42 0')
    assert not is_decimal('42.0 ')
    assert not is_decimal(' 42')
    assert not is_decimal('42 ')
    assert not is_decimal('42 .0')

test_is_decimal()



# Generated at 2022-06-21 21:30:27.822437
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') # returns true
    assert not is_ip_v4('nope') # returns false (not an ip)
    assert not is_ip_v4('255.200.100.999') # returns false (999 is out of range)

test_is_ip_v4()



# Generated at 2022-06-21 21:30:34.163249
# Unit test for function is_string
def test_is_string():
    assert is_string('hello')
    assert not is_string('')
    assert not is_string(123)
    assert not is_string(['hello'])
    assert not is_string(True)
    assert not is_string(('hello',))
    assert not is_string({'hello': 'hi'})
    assert not is_string(b'hello')
    assert not is_string(None)



# Generated at 2022-06-21 21:30:37.207669
# Unit test for function is_slug
def test_is_slug():
    assert (is_slug('my-blog-post-title'))
    assert (not(is_slug('My blog post title')))
    assert (not(is_slug('myblogposttitle')))



# Generated at 2022-06-21 21:30:45.447209
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('9780000000000').is_isbn_13()
    assert __ISBNChecker('9788371838823').is_isbn_13()
    assert __ISBNChecker('9780192823394').is_isbn_13()
    assert __ISBNChecker('978-0-19-282339-4').is_isbn_13()
    assert __ISBNChecker('978 1 928233 9 4', normalize=False).is_isbn_13(
    ) == False

# Generated at 2022-06-21 21:30:56.597865
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') and not is_email('my.email.@the-provider.com')
    assert is_email(r'a@a.com') and not is_email(r'a.@a.com')
    assert is_email(r'a@a.com') and not is_email(r'a..@a.com')
    assert is_email(r'a@a.com') and not is_email(r'a @a.com')
    assert is_email(r'a@a.com') and not is_email(r' a@a.com')
    assert is_email(r'a@a.com') and not is_email(r'a@ a.com')

# Generated at 2022-06-21 21:31:19.891489
# Unit test for function is_slug
def test_is_slug():
  assert is_slug('my-blog-post-title', '-') == True
  assert is_slug('My blog post title', '-') == False
  assert is_slug('my-blog-post-title', '_') == False

test_is_slug()



# Generated at 2022-06-21 21:31:31.026580
# Unit test for function is_snake_case
def test_is_snake_case():
    # Test with posiotive cases with different separators.
    assert is_snake_case('foo_bar_baz') == True
    assert is_snake_case('foo-bar-baz') == True
    assert is_snake_case('foo-_-baz') == True
    assert is_snake_case('foo__baz') == True
    # Test with negative cases.
    assert is_snake_case('FOO-bar-baz') == False
    assert is_snake_case('foo-bar-123') == False
    assert is_snake_case('foo--bar') == False
    assert is_snake_case('foo') == False
    assert is_snake_case('foo-bar-') == False
    assert is_snake_case('') == False
    assert is_sn

# Generated at 2022-06-21 21:31:35.126934
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('0-395-19395-8')
    assert is_isbn('0-321-14653-0')
    assert is_isbn('978-0-306-40615-7')
    assert not is_isbn('978-0-306-40615-2')

test_is_isbn()


# Generated at 2022-06-21 21:31:39.584389
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4("255.255.255.255")
    assert not is_ip_v4("256.255.255.255")


# Generated at 2022-06-21 21:31:49.268400
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case("snake_case", "_") == True
    assert is_snake_case("snake_case") == True
    assert is_snake_case("snake-case", "-") == True
    assert is_snake_case("snake-case") == True
    assert is_snake_case("snake case", " ") == True
    assert is_snake_case("snake.case", ".") == True
    assert is_snake_case("snake:case", ":") == True
    assert is_snake_case("snake|case", "|") == True
    assert is_snake_case("snake+case", "+") == True
    assert is_snake_case("snake_case_1", "_") == True

# Generated at 2022-06-21 21:31:50.785350
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('<p>hello <strong>world</strong></p>') == True

# Generated at 2022-06-21 21:31:53.304101
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1234567890') == True
    assert is_isbn_10('-123456789X') == True
    assert is_isbn_10('-1234567890') == False
    assert is_isbn_10('123-456789-0') == True



# Generated at 2022-06-21 21:31:57.536917
# Unit test for function is_string
def test_is_string():
    assert is_string('foo') == True
    assert is_string(b'foo') == False
    assert is_string(True) == False
    assert is_string(2) == False
    assert is_string(3.3) == False


# Generated at 2022-06-21 21:31:59.761364
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('<html>')
    assert not contains_html('text')


# Generated at 2022-06-21 21:32:05.470792
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('1603860054') == False
    assert is_isbn_13('01603860054') == False
    assert is_isbn_13('9781603860050') == True
    assert is_isbn_13('978-1603860050') == True
    assert is_isbn_13('978-1603860050', False) == False



# Generated at 2022-06-21 21:32:54.283976
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999')


# Generated at 2022-06-21 21:32:58.131373
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('dermatoglyphics') == True
    assert is_isogram('isogram') == True
    assert is_isogram('moose') == False
    assert is_isogram('isIsogram') == False
    assert is_isogram('') == True



# Generated at 2022-06-21 21:33:03.876276
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    checker = __ISBNChecker('978-1-56619-909-4')
    result = checker.is_isbn_13()
    assert result == True

    checker = __ISBNChecker('978-1-56619-909-5')
    result = checker.is_isbn_13()
    assert result == False

    checker = __ISBNChecker('978-1-56619-909-a')
    result = checker.is_isbn_13()
    assert result == False
    

# Generated at 2022-06-21 21:33:15.827171
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    valid_cases = [
        ('0306406152', True),
        ('030640614X', True),
        ('0306406148', True),
        ('0306406141', True),
        ('0306406133', True),
        ('0321127420', True),
        ('0201914654', True),
        ('0321563840', True)
    ]

    invalid_cases = [
        ('030640615X', False),
        ('030640615A', False),
        ('030640615', False),
        ('03064061519', False),
        ('', False)
    ]

    for (case, expected) in valid_cases:
        assert __ISBNChecker(case).is_isbn_10() is expected


# Generated at 2022-06-21 21:33:23.661924
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    input_string = '978-3-16-148410-0'
    normalize = True
    obj_1 = __ISBNChecker(input_string=input_string, normalize=normalize)
    input_string = '978-3-16-148410-0'
    normalize = False
    obj_2 = __ISBNChecker(input_string=input_string, normalize=normalize)
    input_string = '9783161484100'
    normalize = True
    obj_3 = __ISBNChecker(input_string=input_string, normalize=normalize)
    input_string = '9783161484100'
    normalize = False
    obj_4 = __ISBNChecker(input_string=input_string, normalize=normalize)