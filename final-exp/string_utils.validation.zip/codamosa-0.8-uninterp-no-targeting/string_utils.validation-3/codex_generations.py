

# Generated at 2022-06-21 21:23:37.545128
# Unit test for function words_count
def test_words_count():
    assert words_count('hello world') == 2
    assert words_count('one,two,three.stop') == 4
    assert words_count('one two three') == 3

# Generated at 2022-06-21 21:23:41.273450
# Unit test for function words_count
def test_words_count():
    assert 1 == words_count('\t')
    assert 1 == words_count('hello')
    assert 2 == words_count('hello world!')
    assert 2 == words_count('hello\tworld!')
    assert 3 == words_count('one,two,three')
    assert 3 == words_count('one,two,three.ok')
    assert 0 == words_count('! @ # % ... []')



# Generated at 2022-06-21 21:23:43.071029
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') == True
    assert is_isbn_10('150-6715214') == True
    assert is_isbn_10('150-6715214', normalize=False) == False
test_is_isbn_10()



# Generated at 2022-06-21 21:23:48.425495
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?') == False
    assert is_ip_v6('nope') == False
    assert is_ip_v6('255.200.100.999') == False


# Generated at 2022-06-21 21:23:52.243263
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal("123.0") == True
    assert is_decimal("-123.0") == True
    assert is_decimal("-1") == False
    assert is_decimal(123) == False
    assert is_decimal(123.0) == False
    assert is_decimal("1-1") == False


# Generated at 2022-06-21 21:23:56.362542
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string(None) == False
    assert is_full_string('') == False
    assert is_full_string(' ') == False
    assert is_full_string('hello') == True

# Generated at 2022-06-21 21:24:00.772634
# Unit test for function is_number
def test_is_number():
    assert is_number('42') 
    assert is_number('19.99') # returns true
    assert is_number('-9.12') # returns true
    assert is_number('1e3') # returns true
    assert is_number('1 2 3') == False
    

# Generated at 2022-06-21 21:24:07.334020
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75') # returns true
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') # returns true
    assert is_ip('1.2.3') # returns false

# Generated at 2022-06-21 21:24:08.482692
# Unit test for function is_string
def test_is_string():
    assert is_string('foo') == True


# Generated at 2022-06-21 21:24:19.228314
# Unit test for function contains_html
def test_contains_html():
    # Test 1
    expected = True
    actual = contains_html('The quick brown fox jumps over the lazy dog')
    assert expected == actual
    # Test 2
    expected = False
    actual = contains_html('The quick brown fox jumps over the lazy dog')
    assert expected == actual
    # Test 3
    expected = True
    actual = contains_html('The quick brown fox jumps over the lazy dog')
    assert expected == actual
    # Test 4
    expected = False
    actual = contains_html('The quick brown fox jumps over the lazy dog')
    assert expected == actual
    # Test 5
    expected = True
    actual = contains_html('The quick brown fox jumps over the lazy dog')
    assert expected == actual
    # Test 6
    expected = False
    actual = contains_html('The quick brown fox jumps over the lazy dog')
   

# Generated at 2022-06-21 21:24:30.661344
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('fsfsf') == False, 'fsfsf should not be snake case'
    assert is_snake_case('shiratama') == False, 'shiratama should not be snake case'
    assert is_snake_case('foo_bar_baz') == True, 'foo_bar_baz should be snake case'
    assert is_snake_case('foo_bar_') == True, 'foo_bar_ should be snake case'
    assert is_snake_case('foo-bar-baz') == False, 'foo-bar-baz should not be snake case'
    assert is_snake_case('foo-bar-baz', separator='-') == True, 'foo-bar-baz should be snake case'


# Generated at 2022-06-21 21:24:32.350898
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('dermatoglyphics') == True
    assert is_isogram('hello') == False
    assert is_isogram('isogram') == True
    assert is_isogram('moose') == False
    assert is_isogram('Dermatoglyphics') == True

# Generated at 2022-06-21 21:24:35.184026
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-21 21:24:36.899769
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75') == True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip('1.2.3') == False

# Generated at 2022-06-21 21:24:42.388837
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') == True, 'error asserting is_uuid'
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf') == False, 'error asserting is_uuid'
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True) == True, 'error asserting is_uuid'


# Generated at 2022-06-21 21:24:50.354273
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    import unittest

    class __ISBNChecker_is_isbn_10(unittest.TestCase):
        def test_good_cases(self):
            good_cases = [
                ("7-111-22222-X", True),
                ("0-306-40615-2", True),
                ("3-16-148410-0", True),
                ("0-316-148410-0", True),
                ("7-111-22222-0", True),
                ("7-111-22222-1", True)
            ]

            for good_case in good_cases:
                with self.subTest(good_case = good_case):
                    result = __ISBNChecker(good_case[0]).is_isbn_10()

# Generated at 2022-06-21 21:24:56.876795
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf')
    assert not is_uuid('6f8aa2f9686c4ac387665712354a04cf')
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True)



# Generated at 2022-06-21 21:25:06.167280
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('i topi non avevano nipoti') == True
    assert is_palindrome('TOPO') == False
    assert is_palindrome('TOPO', ignore_case=True) == True
    assert is_palindrome('i topi non avevano nipoti', ignore_spaces=True) == True
    assert is_palindrome('i topi non avevano nipoti', ignore_spaces=True, ignore_case=True) == True
    assert is_palindrome('ROTFL') == False
    assert is_palindrome('LOL') == True
    assert is_palindrome('Lol') == False
    assert is_palindrome('Lol', ignore_case=True) == True
    assert is_palindrome('') == True


# Generated at 2022-06-21 21:25:10.064247
# Unit test for function is_integer
def test_is_integer():
    assert is_integer("42") == True
    assert is_integer("-1") == True
    assert is_integer("42.0") == False
    assert is_integer("42.5") == False
    assert is_integer("1e2") == False
    
    

# Generated at 2022-06-21 21:25:21.715820
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('"John.Doe"@example.com')
    assert is_email('user+mailbox/department=shipping@example.com')
    assert is_email('!#$%&*+-/=?^_`.{|}~@example.com')
    assert is_email('"Fred Bloggs"@example.com')
    assert is_email('"Joe\\Blow"@example.com')
    assert is_email('"Abc\\@def"@example.com')
    assert is_email('"Fred Bloggs"@example.com')
    assert is_email('"Joe.\\\\Blow"@example.com')
    assert is_email('"Abc\\\\@def"@example.com')
   

# Generated at 2022-06-21 21:25:31.447469
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('150-6715214',False) == False
    assert is_isbn_10('150-6715214') == True
    assert is_isbn_10('1506715214') == True
# is_isbn_10 Test
test_is_isbn_10()



# Generated at 2022-06-21 21:25:43.907242
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0-306-40615-2').is_isbn_10()
    assert __ISBNChecker('3-89319-746-0').is_isbn_10()
    assert __ISBNChecker('3-8228-2104-X').is_isbn_10()
    assert __ISBNChecker('0-8044-2957-X').is_isbn_10()
    assert __ISBNChecker('0-9752298-0-X').is_isbn_10()
    assert __ISBNChecker('0-9752298-1-8').is_isbn_10()
    assert __ISBNChecker('0-9752298-2-6').is_isbn_10()

# Generated at 2022-06-21 21:25:55.320307
# Unit test for function is_palindrome

# Generated at 2022-06-21 21:25:59.089387
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') is True
    assert is_email('@gmail.com') is False
    assert is_email('foo') is False
    assert is_email('foo@gmail') is False
    assert is_email('foo@') is False
    assert is_email('') is False



# Generated at 2022-06-21 21:26:08.538790
# Unit test for function is_uuid
def test_is_uuid():
    # Test true
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') == True, "'6f8aa2f9-686c-4ac3-8766-5712354a04cf' should be true"
    assert is_uuid('6f8aa2f968-6c-4a-c3-8766-5712354a04cf') == True, "'6f8aa2f968-6c-4a-c3-8766-5712354a04cf' should be true"
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf') == True, "'6f8aa2f9686c4ac387665712354a04cf' should be true"

# Generated at 2022-06-21 21:26:15.116385
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75')
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334')
    assert is_ip('1.2.3') == False
test_is_ip()


# Generated at 2022-06-21 21:26:18.283366
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') is True
    assert is_ip_v4('nope') is False
    assert is_ip_v4('255.200.100.999') is False


# Generated at 2022-06-21 21:26:23.286492
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('Dermatoglyphics') == True
    assert is_isogram('isogram') == True
    assert is_isogram('aba') == False
    assert is_isogram('moOse') == False
    assert is_isogram('isIsogram') == False
    assert is_isogram('') == True
test_is_isogram()


# Generated at 2022-06-21 21:26:27.439304
# Unit test for function contains_html
def test_contains_html():
    assert (contains_html('my string is <strong>bold</strong>'))
    assert (not contains_html('my string is not bold'))

# Generated at 2022-06-21 21:26:31.284213
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('<strong>bold</strong>') == True
    assert contains_html('my string is not bold') == False
    assert contains_html('my string is <bold>bold</bold>') == True
test_contains_html()



# Generated at 2022-06-21 21:26:52.391534
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram("h")
    assert not is_isogram("hello")
    assert is_isogram("")
    assert is_isogram("Dermatoglyphics")
    assert is_isogram("isogram")
    assert not is_isogram("moose")
    assert is_isogram("aba")
    assert not is_isogram("moOse")
    assert is_isogram("thumbscrewjapingly")
    assert not is_isogram("")
    assert is_isogram("Emily Jung Schwartzkopf")
    assert not is_isogram("accentor")
    assert is_isogram("angola")
    assert not is_isogram("hellohello")
    assert is_isogram("six-year-old")

# Generated at 2022-06-21 21:26:54.045194
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') == True
    assert is_isbn('1506715214') == True


# Generated at 2022-06-21 21:26:58.357728
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('MyString')
    assert not is_camel_case('mystring')
    assert not is_camel_case('')
    assert not is_camel_case(None)


# Generated at 2022-06-21 21:27:03.727565
# Unit test for function is_number
def test_is_number():
    assert is_number(input_string='42') == True
    assert is_number(input_string='19.99') == True
    assert is_number(input_string='-9.12') == True
    assert is_number(input_string='1e3') == True
    assert is_number(input_string='1 2 3') == False
test_is_number()



# Generated at 2022-06-21 21:27:08.687589
# Unit test for function is_integer
def test_is_integer():
    assert not (is_integer('3.2'))
    assert not (is_integer('3.0'))
    assert is_integer('3')
    assert is_integer('+3')
    assert is_integer('-3')
    assert is_integer('1e2')
    assert is_integer('1e-2')
    assert is_integer('1e+2')
    assert not (is_integer('1e.2'))



# Generated at 2022-06-21 21:27:18.332110
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('4638b795-068b-4e55-9c8a-11eb7aef52db') == True
    assert is_uuid('4638b795068b4e559c8a11eb7aef52db') == False
    assert is_uuid('4638b795068b4e559c8a11eb7aef52db', allow_hex=True) == True
    assert is_uuid('4638b795068b4e559c8a11eb7aef52db', allow_hex=False) == False
    assert is_uuid(None) == False


# Generated at 2022-06-21 21:27:24.733884
# Unit test for function is_json
def test_is_json():
    print("Testing is_json")
    test_str = '{ "foo": 1, "bar": 2 }'
    expected_output = True
    actual_output = is_json(test_str)
    print('Expected: %s, Actual: %s' % (expected_output, actual_output))
    print('Tested is_json() successfully')
#Unit test for function is_json


# Generated at 2022-06-21 21:27:36.417058
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('') == False
    assert is_credit_card(' ') == False
    assert is_credit_card(None) == False
    assert is_credit_card('1234') == False
    assert is_credit_card('1234-5678-1234-5678') == False
    assert is_credit_card('1234-5678-1234-567a') == False
    assert is_credit_card('4916-3160-3071-2759') == True
    assert is_credit_card('4417-1234-5678-9101') == True
    assert is_credit_card('4012-8888-8888-1881') == True
    assert is_credit_card('4111-1111-1111-1111') == True

# Generated at 2022-06-21 21:27:40.377797
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title')
    assert is_slug('my_blog_post_title', separator='_')
    assert is_slug('my.blog.post.title', separator='.')
    assert not is_slug('My blog post title')
    assert not is_slug('My-blog-post-title')



# Generated at 2022-06-21 21:27:43.209345
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214')
    assert is_isbn_10('150-6715214')
    assert is_isbn_10('150-6715214', normalize=False)
test_is_isbn_10()



# Generated at 2022-06-21 21:27:54.453170
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580')
    assert is_isbn_13('978-0312498580')
    assert not is_isbn_13('978-0312498580', normalize=False)



# Generated at 2022-06-21 21:28:01.670452
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    assert __ISBNChecker('1234567890123').is_isbn_13()
    assert not __ISBNChecker('1234567890124').is_isbn_13()
    assert not __ISBNChecker('12345678901').is_isbn_13()
    assert not __ISBNChecker('123456789012').is_isbn_13()
    assert __ISBNChecker('1234567890').is_isbn_10()
    assert not __ISBNChecker('1234567891').is_isbn_10()
    assert not __ISBNChecker('123456789').is_isbn_10()
    assert not __ISBNChecker('12345678901').is_isbn_10()
    assert __ISBNChecker('123-456789012').is_

# Generated at 2022-06-21 21:28:07.158716
# Unit test for function is_number
def test_is_number():
    assert is_number('42') == True
    assert is_number('19.99') == True
    assert is_number('-9.12') == True
    assert is_number('1e3') == True
    assert is_number('1 2 3') == False

# Generated at 2022-06-21 21:28:12.006033
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1593278224') == True
    assert is_isbn_10('1593-278224') == True
    assert is_isbn_10('1593-278224', False) == False
    assert is_isbn_10('1593278224', False) == True


# Generated at 2022-06-21 21:28:20.045259
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    # positive cases
    assert __ISBNChecker('978-3-16-148410-0').is_isbn_13()
    assert __ISBNChecker('978316148410').is_isbn_13()
    assert __ISBNChecker('978-0-306-40615-7').is_isbn_13()
    assert __ISBNChecker('978-0-306-40615-7').is_isbn_13()
    assert __ISBNChecker('9780306406157').is_isbn_13()
    assert __ISBNChecker('978 0 306 40615 7').is_isbn_13()
    assert __ISBNChecker('978-0-306-40615-7').is_isbn_13()

# Generated at 2022-06-21 21:28:29.221619
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    assert not __ISBNChecker('').is_isbn_13()
    assert not __ISBNChecker('9780262033848').is_isbn_13()
    assert __ISBNChecker('978-0262033848').is_isbn_13()
    assert __ISBNChecker('9780262033848', normalize=False).is_isbn_13()

    assert not __ISBNChecker('').is_isbn_10()
    assert not __ISBNChecker('9780262033848').is_isbn_10()
    assert not __ISBNChecker('978-0262033848').is_isbn_10()
    assert not __ISBNChecker('9780262033848', normalize=False).is_isbn_10()

# Generated at 2022-06-21 21:28:33.607142
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580') == True
    assert is_isbn_13('978-0312498580') == True
    assert is_isbn_13('978-0312498580', normalize=False) == False
test_is_isbn_13()

# Generated at 2022-06-21 21:28:39.576834
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') == True
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf') == False
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True) == True
test_is_uuid()



# Generated at 2022-06-21 21:28:44.053690
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string('') == False
    assert is_full_string(None) == False
    assert is_full_string(' ') == False
    assert is_full_string('hello') == True


# Generated at 2022-06-21 21:28:50.727259
# Unit test for function is_isbn_13
def test_is_isbn_13():
    #is_isbn_13('9780312498580') # returns true
    #is_isbn_13('978-0312498580') # returns true
    #is_isbn_13('978-0312498580', normalize=False) # returns false
    assert is_isbn_13('9780312498580')
    assert is_isbn_13('978-0312498580')
    assert not is_isbn_13('978-0312498580', normalize=False)

test_is_isbn_13()



# Generated at 2022-06-21 21:29:19.950308
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('my..email@the-provider.com') == False # false because of the consecutive dots
    assert is_email('@gmail.com') == False # false because the first part is missing
    assert is_email('my.email@gmail.com')
    assert is_email('my.email@gmail.co.uk')
    assert is_email('m.y.e.mail@gmail.com')
    assert is_email('my@ema.il@gmail.com') == False # false because we have two @
    assert is_email('my.email.@gmail.com') == False # false because the first part ends with a dot
    assert is_email('my.email@gmail.com.') == False # false because the domain part ends with a dot

# Generated at 2022-06-21 21:29:29.679450
# Unit test for function is_number
def test_is_number():
    assert is_number('42')
    assert is_number('42.5')
    assert is_number('-42')
    assert is_number('-42.5')
    assert is_number('1e3')

    assert not is_number('')
    assert not is_number('42,5')
    assert not is_number('10 1')
    assert not is_number('10,0.0')
    assert not is_number('foo')
    assert not is_number('12bar')
    assert not is_number(None)
    assert not is_number([])
    assert not is_number(True)
    assert not is_number({})

    # invalid number
    with pytest.raises(InvalidInputError):
        is_number(5)



# Generated at 2022-06-21 21:29:33.381087
# Unit test for function is_number
def test_is_number():
    assert is_number('42') == True
    assert is_number('19.99') == True
    assert is_number('-9.12') == True
    assert is_number('1e3') == True
    assert is_number('1 2 3') == False


# Generated at 2022-06-21 21:29:38.426078
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('MyString')
    assert is_camel_case('myString')
    assert not is_camel_case('mystring')
    assert not is_camel_case('MyString42')
    assert not is_camel_case('42MyString')
    assert not is_camel_case('42MyString42')
    assert not is_camel_case('My string')
    assert not is_camel_case('hello world')
    assert not is_camel_case('helloWorld')


# Generated at 2022-06-21 21:29:40.643099
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('LOL') is True
    assert is_palindrome('Lol') is False
    assert is_palindrome('Lol', ignore_case=True) is True
    assert is_palindrome('ROTFL') is False

# Generated at 2022-06-21 21:29:42.405915
# Unit test for function contains_html
def test_contains_html():
    assertTrue(contains_html('my string is <strong>bold</strong>'))
    assertTrue(contains_html('my string is <span class="my-class">not bold</span>'))
    assertFalse(contains_html('my string is not bold'))


# Generated at 2022-06-21 21:29:51.642061
# Unit test for function is_email

# Generated at 2022-06-21 21:30:01.725522
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid("3dc4d4e8-a4a9-4c4e-a887-f8b67f1cddc7")
    assert is_uuid("09061e9e-b5fb-11e8-96f8-529269fb1459")
    assert is_uuid("6f8aa2f9-686c-4ac3-8766-5712354a04cf")
    assert is_uuid("6f8aa2f9686c4ac387665712354a04cf", allow_hex=True)

    assert not is_uuid("6f8aa2f9686c4ac387665712354a04cf", allow_hex=False)

# Generated at 2022-06-21 21:30:07.498143
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('03081059').is_isbn_10() == True
    assert __ISBNChecker('0306406152').is_isbn_10() == False
    assert __ISBNChecker('030640615').is_isbn_10() == False
    assert __ISBNChecker('030640615X').is_isbn_10() == True


# PUBLIC API


# Generated at 2022-06-21 21:30:08.459085
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card("4111111111111111") == True

# Generated at 2022-06-21 21:30:23.823613
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    _isbn1 = __ISBNChecker('978-0-306-40615-7').is_isbn_13()  # True
    _isbn2 = __ISBNChecker('978-0-306-40615-8').is_isbn_13()  # False
    _isbn3 = __ISBNChecker('978-0-306-40615-9').is_isbn_13()  # False

    assert _isbn1 == True
    assert _isbn2 == False
    assert _isbn3 == False


# Generated at 2022-06-21 21:30:34.215513
# Unit test for function is_url
def test_is_url():
    import pytest
    assert is_url('http://www.mysite.com')
    assert is_url('https://mysite.com')
    assert not is_url('.mysite.com')
    assert not is_url('//mysite.com')
    assert not is_url('mysite.com')
    assert not is_url(123)
    assert not is_url('')
    assert not is_url('http://')
    assert not is_url('https://')
    assert not is_url('http:')
    assert not is_url('https:')


# Generated at 2022-06-21 21:30:37.626619
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') == True
    assert is_isbn_10('150-6715214') == True
    assert is_isbn_10('150-6715214', normalize=False) == False



# Generated at 2022-06-21 21:30:49.761370
# Unit test for function contains_html
def test_contains_html():
    def assert_contains_html(expected: bool, input_string: str):
        assert expected == contains_html(input_string), input_string

    assert_contains_html(True, '<html>')
    assert_contains_html(True, '<a href="/my-link">')
    assert_contains_html(True, '<not a tag>')
    assert_contains_html(True, '<html><body>')
    assert_contains_html(True, '<html><b>')
    assert_contains_html(True, '</body></html>')
    assert_contains_html(True, '<nospaces>')
    assert_contains_html(True, '<one.class>')

# Generated at 2022-06-21 21:30:50.428546
# Unit test for function is_isbn_10
def test_is_isbn_10():
   assert is_isbn_10('1133947161')

# Generated at 2022-06-21 21:30:53.815717
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert is_ip_v4('0.0.0.0')
    assert is_ip_v4('255.255.255.255')
    assert not is_ip_v4('999.255.255.255')
    assert not is_ip_v4('999.256.255.255')
    assert not is_ip_v4('999.255.256.255')
    assert not is_ip_v4('999.255.255.256')
    assert not is_ip_v4('256.255.255.255')



# Generated at 2022-06-21 21:30:58.513985
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('978-0312498580', normalize=True) == True
    assert is_isbn('1506715214', normalize=True) == True
    assert is_isbn('978-0312498580', normalize=False) == False

is_isbn('978-0312498580', normalize=True)

# End unit test


# Generated at 2022-06-21 21:31:07.580006
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    if not is_isbn_10('0-306-40615-2'):
        raise Exception("Invalid ISBN 10 value")

    if not is_isbn_13('978-0-306-40615-7'):
        raise Exception("Invalid ISBN 13 value")

    if is_isbn_10('978-0-306-40615-7'):
        raise Exception("Invalid ISBN 10 value")

    if is_isbn_13('0-306-40615-2'):
        raise Exception("Invalid ISBN 13 value")


# PUBLIC API



# Generated at 2022-06-21 21:31:09.993557
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title') == True
 
is_slug('my-blog-post-title')


# Generated at 2022-06-21 21:31:17.039616
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('dermatoglyphics') == True
    assert is_isogram('moose') == False
    assert is_isogram('isIsogram') == False
    assert is_isogram('') == True
    assert is_isogram('aba') == False
    assert is_isogram('moOse') == False
    assert is_isogram('thumbscrewjapingly') == True
    assert is_isogram('abc') == True
    assert is_isogram('aabbccddeeffgghhiijjkkllmmnnooppqqrrssttuuvvwwxxyyzz') == True
test_is_isogram()


# Generated at 2022-06-21 21:31:28.431909
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') == True
    assert is_isbn_10('150-6715214') == True
    assert is_isbn_10('150-6715214', normalize=False) == False



# Generated at 2022-06-21 21:31:31.730091
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string(None) == False
    assert is_full_string('') == False
    assert is_full_string(' ') == False
    assert is_full_string('hello') == True
    return True



# Generated at 2022-06-21 21:31:34.609679
# Unit test for function is_isogram
def test_is_isogram():
    assert(is_isogram("abcdefghijklmnopqrstuvwxyz") == True)

is_isogram("abcdefghijklmnopqrstuvwxyz")

# Generated at 2022-06-21 21:31:45.651152
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-0-306-40615-7').is_isbn_13()
    assert __ISBNChecker('9780306406157').is_isbn_13()
    assert __ISBNChecker('978-0-306-40615-7').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-1').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615').is_isbn_13() is False
    assert __ISBNChecker('a978-0-306-40615-7').is_isbn_13() is False


# Generated at 2022-06-21 21:31:51.618165
# Unit test for function is_uuid
def test_is_uuid():
  assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') == True
  assert is_uuid('6f8aa2f9686c4ac387665712354a04cf') == False
  assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True) == True

# Invoke the unit test
test_is_uuid()


# Generated at 2022-06-21 21:32:03.992278
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('2002:4559:1FE2::4559:1FE2') == True
    assert is_ip('255.200.100.75') == True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip('1.2.3') == False
    assert is_ip('1.2.3.4.5') == False
    assert is_ip('1.2.3.4') == True
    assert is_ip('1.2.3.4.5.6.7.8.9.10') == False
    assert is_ip('1.2.3.4.5.6.7.8.9') == True

# Generated at 2022-06-21 21:32:10.056187
# Unit test for function is_full_string
def test_is_full_string():
    try:
        assert is_full_string(None) == False
        assert is_full_string('') == False
        assert is_full_string(' ') == False
        assert is_full_string('hello') == True
        print("test_is_full_string passed")
    except:
        print("test_is_full_string failed")
test_is_full_string()



# Generated at 2022-06-21 21:32:19.951121
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('myCamelCaseString') is True
    assert is_camel_case('MyCamelCaseString') is True
    assert is_camel_case('my Camel Case String') is True
    assert is_camel_case(' my Camel Case String') is False
    assert is_camel_case('my Camel Case String ') is False
    assert is_camel_case('myCamelCaseString ') is False
    assert is_camel_case('') is False
    assert is_camel_case(' ') is False
    assert is_camel_case(None) is False
    assert is_camel_case(123) is False
    assert is_camel_case(1) is False
    assert is_camel_case('Abc') is True
    assert is_camel_

# Generated at 2022-06-21 21:32:25.778002
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('LOL') == True 
    assert is_palindrome('Lol') == False
    assert is_palindrome('Lol', ignore_case=True) == True
    assert is_palindrome('ROTFL') == False
    assert is_palindrome('LOL', ignore_spaces=True) == True
    assert is_palindrome('Lol', ignore_case=True) == True
    assert is_palindrome('ROTFL', ignore_spaces=True) == False
    assert is_palindrome('') == False
test_is_palindrome()


# Generated at 2022-06-21 21:32:29.766077
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():

    assert __ISBNChecker('9783836221191').is_isbn_13() is True
    assert __ISBNChecker('978-3-8362-2119-1').is_isbn_13() is True

# Generated at 2022-06-21 21:32:48.830948
# Unit test for function is_ip
def test_is_ip():
    ip_valid = ['255.200.100.75', '2001:db8:85a3:0000:0000:8a2e:370:7334', '127.0.0.1']
    ip_invalid = ['255.200.100.999', '2001:db8:85a3:0000:0000:8a2e:370:', '???']
    for ip in ip_valid:
        assert is_ip(ip), "is_ip() should return true for IP: {}".format(ip)
    for ip in ip_invalid:
        assert not is_ip(ip), "is_ip() should return false for IP: {}".format(ip)

test_is_ip()


# Generated at 2022-06-21 21:32:58.428154
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('my html text')
    assert contains_html('my html text <p>some text</p>')
    assert contains_html('my html text <p class="some-class">some text</p>')
    assert contains_html('my html text <p class="some-class" data-value="some data">some text</p>')
    assert contains_html('my html text <p class="some-class" data-value="some data">some text</p>')
    assert contains_html('my html text <p class="some-class" data-value="some data" data-value2="some data">some text</p>')
    assert not contains_html('my plain text')

# Generated at 2022-06-21 21:33:01.440383
# Unit test for function words_count
def test_words_count():
    assert words_count('1, 2, 3') == 3

words_count('1, 2, 3')


# Generated at 2022-06-21 21:33:06.653203
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?') == False


# Generated at 2022-06-21 21:33:16.932595
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('MyString')
    assert not is_camel_case('mystring')
    assert not is_camel_case('my string')
    assert not is_camel_case('123456789')
    assert not is_camel_case('123456789A')
    assert not is_camel_case('MyString123456789')
    assert not is_camel_case('MyString123456789A')
    assert not is_camel_case('_MyString')
    assert not is_camel_case('MyString_')
    assert is_camel_case('MyString123456789A')


# public api