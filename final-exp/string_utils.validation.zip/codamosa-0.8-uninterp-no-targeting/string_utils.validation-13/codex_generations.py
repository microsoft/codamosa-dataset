

# Generated at 2022-06-21 21:23:47.410924
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string("Hello world") == True
    assert is_full_string("  Hello world  ") == True
    assert is_full_string("") == False
    assert is_full_string(" ") == False
    assert is_full_string("\t ") == False
    assert is_full_string("\t") == False
    assert is_full_string("\n") == False
    assert is_full_string(" \n ") == False



# Generated at 2022-06-21 21:23:50.489639
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert(is_isbn_10('1506715214') == True)
    assert(is_isbn_10('150-6715214') == True)
    assert(is_isbn_10('150-6715214', normalize=False) == False)


# Generated at 2022-06-21 21:23:55.401557
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-1-56619-909-4').is_isbn_13() == True
    assert __ISBNChecker('979-1-56619-909-4').is_isbn_13() == False


# Generated at 2022-06-21 21:23:57.776483
# Unit test for function is_string
def test_is_string():
    assert is_string('foo') is True
    assert is_string(b'foo') is False
test_is_string()



# Generated at 2022-06-21 21:24:07.446532
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42')
    assert is_integer('+42')
    assert is_integer('-42')
    assert is_integer('0')
    assert is_integer('42e2')
    assert is_integer('+42e2')
    assert is_integer('-42e2')
    assert is_integer('0e3')
    assert not is_integer('42.0')
    assert not is_integer('42.0e2')
    assert not is_integer('+42.0')
    assert not is_integer('+42.0e2')
    assert not is_integer('-42.0')
    assert not is_integer('-42.0e2')
    assert not is_integer('0.0')
    assert not is_integer('0.0e3')

# Generated at 2022-06-21 21:24:09.416254
# Unit test for function is_string
def test_is_string():
    assert is_string('foo')
    assert not is_string(b'foo')


# Generated at 2022-06-21 21:24:12.037267
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') # returns true
    assert is_url('https://mysite.com') # returns true
    assert not is_url('.mysite.com') # returns false


# Generated at 2022-06-21 21:24:14.106204
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('dermatoglyphics') == True
    assert is_isogram('hello') == False



# Generated at 2022-06-21 21:24:18.731564
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    input_string = '978-0596517748'
    normalize = True
    assert is_string(input_string), 'Input is not string.'
    assert is_full_string(input_string), 'Input is not full string (contain space, tab, newline, etc.).'


# PUBLIC API



# Generated at 2022-06-21 21:24:21.547292
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('MyString') == True
    assert is_camel_case('myString') == False


# Generated at 2022-06-21 21:24:40.201712
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('aaf45336-0e20-469a-8ad9-c60b3fa1a607') is True
    assert is_uuid('aaf453360e20469a8ad9c60b3fa1a607') is False
    assert is_uuid('aaf453360e20469a8ad9c60b3fa1a607', allow_hex=True) is True
    assert is_uuid('aaf453360e20469a8ad9c60b3fa1a607', allow_hex=False) is False
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') is True

# Generated at 2022-06-21 21:24:42.903268
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('ThisIsAlsoACamelCase') == True
    assert is_camel_case('thisIsNotACamelCase') == False


# Generated at 2022-06-21 21:24:45.607894
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn("9780312498580") == True
    assert is_isbn("1506715214") == True
    assert is_isbn("150-6715214") == True
    assert is_isbn("150-6715214", normalize=False) == False
test_is_isbn()

# Generated at 2022-06-21 21:24:48.129218
# Unit test for function words_count
def test_words_count():
    assert words_count('') == 0
    assert words_count('hello') == 1
    assert words_count('hello world') == 2
    assert words_count('hello world!') == 2
    assert words_count('hello, world') == 2



# Generated at 2022-06-21 21:24:58.024270
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    print('Testing method is_isbn_10 of class __ISBNChecker')
    test_cases = [
        ('0306406152', True),
        ('9781420951448', False),
        ('061-140-0652', True),
        ('1420951448', False)
    ]

    for string, expected_result in test_cases:
        checker = __ISBNChecker(string, normalize=True)
        assert checker.is_isbn_10() == expected_result, f'{string}'

test___ISBNChecker_is_isbn_10()



# Generated at 2022-06-21 21:24:59.725828
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580') == True
    assert is_isbn_13('978-0312498580') == True
    assert is_isbn_13('978-0312498580', normalize = False) == False


# Generated at 2022-06-21 21:25:03.552055
# Unit test for function words_count
def test_words_count():
    assert words_count("one,two,three.stop") == 4
    assert words_count("one two, three. stop!ok") == 4
    assert words_count("! @ # % ... []") == 0
    assert words_count("this is a string with six words") == 6



# Generated at 2022-06-21 21:25:07.775940
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('dermatoglyphics') is True
    assert is_isogram('isogram') is True
    assert is_isogram('horse') is True
    assert is_isogram('dog') is False
    
test_is_isogram()


# Generated at 2022-06-21 21:25:19.671823
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4242424242424242', card_type='VISA') is True
    assert is_credit_card('5555555555554444', card_type='MASTERCARD') is True
    assert is_credit_card('378282246310005', card_type='AMERICAN_EXPRESS') is True
    assert is_credit_card('30569309025904', card_type='DINERS_CLUB') is True
    assert is_credit_card('6011111111111117', card_type='DISCOVER') is True
    assert is_credit_card('3530111333300000', card_type='JCB') is True
    assert is_credit_card('0000000000000000', card_type='VISA') is False

# Generated at 2022-06-21 21:25:22.701605
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('myString') == True
    assert is_camel_case('mystring') == False
    assert is_camel_case('MyString') == True
    assert is_camel_case('9MyString') == False


# Generated at 2022-06-21 21:25:34.768824
# Unit test for function is_string
def test_is_string():
    assert is_string('foo'), 'is_string returned False but expected True'
    assert not is_string(b'foo'), 'is_string returned True but expected False'



# Generated at 2022-06-21 21:25:40.384450
# Unit test for function is_ip_v6
def test_is_ip_v6():
    # Test valid input
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334')

    # Test for false input
    assert not is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?')


# Generated at 2022-06-21 21:25:51.393745
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('dermatoglyphics') == True
    assert is_isogram('friendship') == True
    assert is_isogram('bana') == True
    assert is_isogram('ban') == True
    assert is_isogram('abcdefghijklmnopqrstuvwxyz') == True
    assert is_isogram('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ') == True
    assert is_isogram('abcdef ghijklmnopqrstuvwxyz') == True
    assert is_isogram('abcdefghijklmnopqrst uvwxyz') == True
    assert is_isogram('abcdefghijklmnopqrstuvwxy') == True
    assert is_is

# Generated at 2022-06-21 21:25:53.210873
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75')
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334')
    assert not is_ip('1.2.3')

test_is_ip()


# Generated at 2022-06-21 21:25:58.435612
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('abcdefghijklmnopqrstuvwxyz')
    assert is_pangram('a quick brown fox jumps over the lazy dog')
    assert is_pangram('pack my box with five dozen liquor jugs')
    assert not is_pangram('hello world')


# Generated at 2022-06-21 21:26:03.847674
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com')
    assert is_url('https://mysite.com')
    assert not is_url('mysite.com')
    assert not is_url('www.mysite.com')
    assert not is_url('.mysite.com')



# Generated at 2022-06-21 21:26:14.532732
# Unit test for function is_url
def test_is_url():
    assert is_url('https://www.mysite.com') == True
    assert is_url('https://www.mysite.com/article/this-is-a-test.html') == True
    assert is_url('https://www.mysite.com/article/this-is-a-test.html?myparam=myvalue') == True
    assert is_url('https://www.mysite.com/article/this-is-a-test.html?myparam=myvalue#this-is-a-section') == True
    assert is_url('www.mysite.com') == False
    assert is_url('this is not a url') == False


# Generated at 2022-06-21 21:26:20.282861
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker("0306406152").is_isbn_10() == True
    assert __ISBNChecker("0306406151").is_isbn_10() == False
    assert __ISBNChecker("1A19A48EE6A8").is_isbn_10() == False
    assert __ISBNChecker("1A19A48EE6A1").is_isbn_10() == True


# Generated at 2022-06-21 21:26:31.277367
# Unit test for function is_isbn
def test_is_isbn():
    from . import string_converter

# Generated at 2022-06-21 21:26:33.106541
# Unit test for function is_integer
def test_is_integer():
  assert is_integer('42') == True
  assert is_integer('42.0') == False




# Generated at 2022-06-21 21:26:49.394828
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('dermatoglyphics') == True
    assert is_isogram('isogram') == True
    assert is_isogram('aba') == False
    assert is_isogram('moOse') == False
    assert is_isogram('isIsogram') == False
    assert is_isogram('') == True

# Generated at 2022-06-21 21:26:51.019336
# Unit test for function is_string
def test_is_string():
    assert is_string('foo')
    assert not is_string(b'foo')


# Generated at 2022-06-21 21:26:56.409342
# Unit test for function is_json
def test_is_json():
    assert is_json("{'name': 'Peter'}") == True
    assert is_json("['name', 'Peter']") == True
    assert is_json("[hello, 2, 3]") == False
    assert is_json("{nope}") == False


# Generated at 2022-06-21 21:27:07.623481
# Unit test for function is_integer
def test_is_integer():
    assert(is_integer('42') == True)
    assert(is_integer('42.0') == False)
    assert(is_integer(-42) == True)
    assert(is_integer(42.0) == False)
    assert(is_integer('42e5') == True)
    assert(is_integer('42E5') == True)
    assert(is_integer('42e5') == True)
    assert(is_integer(42) == True)
    assert(is_integer('42') == True)
    assert(is_integer('-42') == True)
    assert(is_integer('42.0') == False)
    assert(is_integer('-42.0') == False)
    assert(is_integer('42e5') == True)

# Generated at 2022-06-21 21:27:13.172614
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string(None) == False
    assert is_full_string('') == False
    assert is_full_string(' ') == False
    assert is_full_string('hello') == True
# Test is_full_string()
test_is_full_string()



# Generated at 2022-06-21 21:27:18.378980
# Unit test for function is_palindrome
def test_is_palindrome():
    """
    Test case for function isPalindrome
    :return:
    """
    assert is_palindrome('otto') == True
    assert is_palindrome('ot to') == True
    assert is_palindrome('otto ') == True
    assert is_palindrome(' otto') == True
    assert is_palindrome('ott o') == True



# Generated at 2022-06-21 21:27:21.735857
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    input_string = '0-7475-3269-9'
    assert __ISBNChecker(input_string).is_isbn_10() == True

# Generated at 2022-06-21 21:27:31.744219
# Unit test for function is_number
def test_is_number():
    assert is_number('-9.12') == True
    assert is_number('-1') == True
    assert is_number('0') == True
    assert is_number('1') == True
    assert is_number('0.1') == True

# Generated at 2022-06-21 21:27:33.139970
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') == True
    assert is_isbn('1506715214') == True

# Generated at 2022-06-21 21:27:35.685476
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram("The quick brown fox jumps over the lazy dog") == True
    assert is_pangram("hello world") == False
test_is_pangram()


# Generated at 2022-06-21 21:27:44.162886
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('my string is <strong>bold</strong>') is True
    assert contains_html('my string is not bold') is False
    assert contains_html('my string is not bold <script>alert("xss");</script>') is True
    assert contains_html(None) is False
    assert contains_html('') is False
    assert contains_html(0) is False
    assert contains_html(list()) is False
    assert contains_html(set()) is False
    assert contains_html(dict()) is False
    assert contains_html({'asda':'asdas1'}) is False


# Generated at 2022-06-21 21:27:47.164632
# Unit test for function is_full_string
def test_is_full_string():
    assert not is_full_string(None)
    assert not is_full_string('')
    assert not is_full_string(' ')
    assert is_full_string('hello')


# Generated at 2022-06-21 21:27:51.228825
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}')
    assert is_json('[1, 2, 3]')
    assert not is_json('{nope}')


# Generated at 2022-06-21 21:27:54.150515
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('dermatoglyphics')
    assert not is_isogram('apple')


# Generated at 2022-06-21 21:27:59.748702
# Unit test for function contains_html
def test_contains_html():
    assert not contains_html('my string is not bold')
    assert contains_html('my string is <strong>bold</strong>')
    assert contains_html('my string is <strong>bold</strong> and <strong></strong>')
    assert contains_html('<br>')
    assert contains_html('<hr>')
    assert contains_html('<text>')
    assert contains_html('<br><br>')
    assert contains_html('<br/><hr/>')
    assert contains_html('<br><hr>')
    assert contains_html('<a href="some_url">some text</a>')
    assert contains_html('<a href="/some_url">some text</a>')
    assert contains_html('<a href="http://some_url">some text</a>')
    assert contains_html

# Generated at 2022-06-21 21:28:04.572823
# Unit test for function is_string
def test_is_string():
    assert is_string('foo')
    assert not is_string(b'foo')
    assert not is_string(1)
    assert not is_string(object())
    assert not is_string({'a': 1})
    assert not is_string([1, 2])


# Generated at 2022-06-21 21:28:14.954598
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('0-306-40615-2').is_isbn_13()  # valid ISBN 13
    assert __ISBNChecker('0306406152').is_isbn_13()  # valid ISBN 13
    assert not __ISBNChecker('0-306-40615-3').is_isbn_13()  # invalid ISBN 13
    assert not __ISBNChecker('0-306-40615-0').is_isbn_13()  # invalid ISBN 13
    assert not __ISBNChecker('03064061514').is_isbn_13()  # invalid ISBN 13
    assert not __ISBNChecker('030640615').is_isbn_13()  # invalid ISBN 13
    assert not __ISBNChecker('').is_isbn_13()  # empty string

# Generated at 2022-06-21 21:28:22.269123
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') == True
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf') == False
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True) == True

# Generated at 2022-06-21 21:28:27.573305
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('myString') # passes
    assert not is_camel_case('my_string') # passes
    assert not is_camel_case('My_string') # passes
    assert not is_camel_case(None) # passes
    assert not is_camel_case('') # passes
    assert not is_camel_case('42') # passes
    assert not is_camel_case('my-string') # passes


# Generated at 2022-06-21 21:28:33.014958
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('MyString') is True, "is_camel_case('MyString') should return True"
    assert is_camel_case('mystring') is False, "is_camel_case('mystring') should return False"
    assert is_camel_case('MyString123') is True, "is_camel_case('MyString123') should return True"
    assert is_camel_case('MyString123!') is False, "is_camel_case('MyString123!') should return False"
    assert is_camel_case('1MyString') is False, "is_camel_case('1MyString') should return False"



# Generated at 2022-06-21 21:28:43.341705
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('') == False
    assert is_snake_case('foo') == False
    assert is_snake_case('foo_bar') == True
    assert is_snake_case('foo_bar_baz') == True
    assert is_snake_case('foo_bar_baz_9') == True
    assert is_snake_case('foo_bar_baz_9_') == False
    assert is_snake_case('_foo_bar_baz_9') == False
    assert is_snake_case('foo-bar-baz', '-') == True
    assert is_snake_case('FooBar') == False
    assert is_snake_case('9_foo_bar') == False



# Generated at 2022-06-21 21:28:49.940353
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('6011111111111117') == True
    assert is_credit_card('4111111111111111') == True
    assert is_credit_card('5105105105105100') == True
    assert is_credit_card('378282246310005') == True
    assert is_credit_card('1234567890123456') == False
    assert is_credit_card('A1B2C3D4E5F6G7H8') == False
    print("Test is_credit_card() passed")


# Generated at 2022-06-21 21:29:01.910108
# Unit test for function is_number
def test_is_number():
    assert is_number('0123') == True
    assert is_number('-123') == True
    assert is_number('-123') == True
    assert is_number('-123.123') == True
    assert is_number('-123e3') == True
    assert is_number('-123.123e3') == True
    assert is_number('-123.123e-3') == True

    assert is_number('123e-') == False
    assert is_number('123e- ') == False
    assert is_number('123e--3') == False
    assert is_number('123e.') == False
    assert is_number('123e.3') == False
    assert is_number('123.123e3.3') == False
    assert is_number('abc') == False

# Generated at 2022-06-21 21:29:08.887504
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf')
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True)
    assert not is_uuid('6f8aa2f9686c4ac387665712354a04cf')
    assert not is_uuid('6f8aa2f9686c4ac387665712354a04cf11')
    assert not is_uuid('6f8aa2f9686c4ac387665712354a04c')
    assert not is_uuid('6f8aa2f9686c4acj87665712354a04c')

# Generated at 2022-06-21 21:29:19.393741
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf')
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True)
    assert not is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=False)
    assert not is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cz')
    assert not is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a0')

# Generated at 2022-06-21 21:29:27.520552
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('1506715214') == True
    assert is_isbn('150-6715214') == True
    assert is_isbn('150-6715214', normalize=False) == False
    assert is_isbn('9780312498580') == True
    assert is_isbn('978-0312498580') == True
    assert is_isbn('978-0312498580', normalize=False) == False
    assert is_isbn('123') == False
    assert is_isbn('') == False

if __name__ == "__main__":
    test_is_isbn()

# Generated at 2022-06-21 21:29:34.807451
# Unit test for function is_ip_v6
def test_is_ip_v6():
    #test_cases = {'2001:db8:85a3:0000:0000:8a2e:370:7334':True,'2001:db8:85a3:0000:0000:8a2e:370:?':False}
    test_cases = {'2001:db8:85a3:0000:0000:8a2e:370:7334':True}
    for key in test_cases:
        assert(is_ip_v6(key) == test_cases[key])
    print("test_is_ip_v6 Passed")

test_is_ip_v6()


# Generated at 2022-06-21 21:29:41.668293
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') is True
    assert is_isbn_10('150-6715214') is True
    assert is_isbn_10('150-6715214', normalize=False) is False
    assert is_isbn_10('1506715215') is False
    assert is_isbn_10('150671521x') is False
    assert is_isbn_10('978') is False
    assert is_isbn_10('') is False

# Generated at 2022-06-21 21:29:51.396789
# Unit test for function is_integer
def test_is_integer():
    assert(is_integer("45")==True)
    assert(is_integer("4.4")==False)
    assert(is_integer("4.4e45")==False)
    assert(is_integer("-4.4e45")==False)
    assert(is_integer("-45")==True)
    assert(is_integer("NaN")==False)
    assert(is_integer("-Infinity")==False)
    assert(is_integer("Infinity")==False)
    assert(is_integer("-Infinitye45")==False)
    assert(is_integer("4.4e+45")==False)
    assert(is_integer("4.4+45")==False)
    assert(is_integer("4.4e-45")==False)

# Generated at 2022-06-21 21:29:58.709820
# Unit test for function is_number
def test_is_number():
    assert is_number('123') == True
    assert is_number('-123.5') == True
    assert is_number('123e5') == True
    assert is_number('0') == True
    assert is_number('-0.0') == True
    assert is_number('.0123') == True
    assert is_number('123abc') == False
    assert is_number('abc') == False
    assert is_number('1 2 3') == False
    assert is_number('I am 123 years old') == False


# Generated at 2022-06-21 21:30:08.486188
# Unit test for function contains_html
def test_contains_html():
    res = contains_html('my string is <strong>bold</strong>')
    assert_true(res)
    res = contains_html('my string is not bold')
    assert_false(res)


# Generated at 2022-06-21 21:30:17.508865
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    # check error
    try:
        checker = __ISBNChecker('abc')
        assert False
    except InvalidInputError:
        assert True

    # check input string is not modified
    checker = __ISBNChecker('123456789X')
    assert checker.input_string == '123456789X'

    checker = __ISBNChecker('123-456789-X', False)
    assert checker.input_string == '123-456789-X'

    # check input string is modified
    checker = __ISBNChecker('123-456789-X')
    assert checker.input_string == '123456789X'


# PUBLIC API


# Generated at 2022-06-21 21:30:19.928956
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.222.0.255')
    assert not is_ip_v4('255.222.0.256')
    assert not is_ip_v4('255.222.0.2566')
    assert not is_ip_v4('255.222.0.256a')



# Generated at 2022-06-21 21:30:28.393754
# Unit test for function is_uuid
def test_is_uuid():
  assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') == True
  assert is_uuid('6f8aa2f9686c4ac387665712354a04cf') == False
  assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True) == True

test_is_uuid()



# Generated at 2022-06-21 21:30:39.281477
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('') is False
    assert is_snake_case(' ') is False
    assert is_snake_case('MyNameIsJohn') is False
    assert is_snake_case('my_name_is_john') is True
    assert is_snake_case('my-name-is-john') is True
    assert is_snake_case('my_name.is_john') is True
    assert is_snake_case(' my_name_is_john ') is True
    assert is_snake_case('-my_name_is_john') is False
    assert is_snake_case('my_name_is_john-') is True
    assert is_snake_case('my name is john') is False

# Generated at 2022-06-21 21:30:44.047725
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214')
    assert is_isbn_10('150-6715214')
    assert is_isbn_10('150-6715214', normalize=False)
test_is_isbn_10()




# Generated at 2022-06-21 21:30:55.690925
# Unit test for function is_uuid
def test_is_uuid():
    # Check if we are returning true value
    if (is_uuid("6f8aa2f9-686c-4ac3-8766-5712354a04cf") == True and is_uuid("6f8aa2f9-686c-4ac3-8766-5712354a04cf", True) == True and is_uuid("6f8aa2f9686c4ac387665712354a04cf", True) == True):
        print("Pass")
    else:
        print("Fail")
    # Check if we are returning false value

# Generated at 2022-06-21 21:30:57.382019
# Unit test for function is_ip_v4
def test_is_ip_v4():
    return is_ip_v4('255.200.100.75')
test_is_ip_v4()


# Generated at 2022-06-21 21:31:01.233387
# Unit test for function is_json
def test_is_json():
	assert is_json("{'name': 'Peter'}")
	assert is_json("['name', 'Peter']")
	assert not is_json("{nope}")
	return
	

# Generated at 2022-06-21 21:31:04.157074
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    obj = __ISBNChecker('123456789')
    assert obj.input_string == '123456789'


# PUBLIC API



# Generated at 2022-06-21 21:31:20.053240
# Unit test for function is_pangram

# Generated at 2022-06-21 21:31:26.277909
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case("MyString")
    assert not is_camel_case("mystring")
    assert not is_camel_case("")
    assert not is_camel_case(" ")
    assert not is_camel_case("  ")
    assert not is_camel_case("foo bar")
    assert not is_camel_case("fooBar")
    assert not is_camel_case("FOOBar")
    assert not is_camel_case(None)



# Generated at 2022-06-21 21:31:29.323459
# Unit test for function words_count
def test_words_count():
    assert words_count('hello world') == 2
    assert words_count('one,two,three.stop') == 4
test_words_count()


# Generated at 2022-06-21 21:31:32.178418
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4("255.200.100.75")
    assert not is_ip_v4("nope")
    assert not is_ip_v4("255.200.100.999")


# Generated at 2022-06-21 21:31:34.900996
# Unit test for function is_number
def test_is_number():
    assert is_number('42')
    assert is_number('19.99')
    assert is_number('-9.12')
    assert is_number('1e3')
    assert not is_number('1 2 3')


# Generated at 2022-06-21 21:31:43.158806
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog')
    assert is_pangram('Pack my box with five dozen liquor jugs.')
    assert is_pangram('Mr. Jock, TV quiz PhD, bags few lynx.')
    assert is_pangram('Jackdaws love my big sphinx of quartz.')
    assert not is_pangram('hello world')

test_is_pangram()

 


# Generated at 2022-06-21 21:31:49.217077
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('MyString') == True
    assert is_camel_case('myString') == True
    assert is_camel_case('MYSTRING') == False
    assert is_camel_case('1String') == False
    assert is_camel_case('String$') == False
    assert is_camel_case('a') == False
test_is_camel_case()



# Generated at 2022-06-21 21:32:01.048712
# Unit test for function is_email
def test_is_email():

    assert(is_email('my.email@the-provider.com') == True)
    assert(is_email('@gmail.com') == False)
    assert(is_email('ilovepython@gmail.com') == True)
    assert(is_email('ilovepythoncom') == False)
    assert(is_email('ilovepython.com.com') == True)
    assert(is_email('ilovepython@.com') == False)
    assert(is_email('.ilovepython@gmail.com') == False)
    assert(is_email('ilovepython@gmail.com') == True)
    assert(is_email('emaiilovepython@gmail.com') == True)
    assert(is_email('emaiilovepythoncom') == False)

# Generated at 2022-06-21 21:32:12.214498
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    assert __ISBNChecker('9789383442601').is_isbn_13()
    assert not __ISBNChecker('9789383442601').is_isbn_10()

    assert not __ISBNChecker('9383442601').is_isbn_13()
    assert __ISBNChecker('9383442601').is_isbn_10()

    assert not __ISBNChecker('978-9383442601').is_isbn_13()
    assert not __ISBNChecker('93834-42601').is_isbn_10()

    assert __ISBNChecker('978-9383442601', normalize=False).is_isbn_13()
    assert __ISBNChecker('93834-42601', normalize=False).is_isbn_10()

   

# Generated at 2022-06-21 21:32:16.393598
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string(None) == False
    assert is_full_string('') == False
    assert is_full_string(' ') == False
    assert is_full_string("hello") == True
    
    

# Generated at 2022-06-21 21:32:33.327972
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('9781337133713').is_isbn_13()
    assert __ISBNChecker('978-1337133713').is_isbn_13()
    assert __ISBNChecker('978-1-33713-371-3').is_isbn_13()
    assert not __ISBNChecker('978-1-33713-371-4').is_isbn_13()



# Generated at 2022-06-21 21:32:35.598163
# Unit test for function is_isbn_10
def test_is_isbn_10():
    isbn =  "123-00-1235-6789"
    assert(is_isbn_10(isbn))
test_is_isbn_10()



# Generated at 2022-06-21 21:32:44.051405
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title')
    assert not is_slug('My blog post title')
    assert not is_slug('')
    assert not is_slug('my- blog-post-title')
    assert not is_slug('--my blog post title')
    assert not is_slug('not_a_slug')
    assert not is_slug('slug')
    assert not is_slug('my-blog-post-title-')
    assert is_slug('my-blog-post-title', separator='-')
    assert is_slug('my_blog_post_title', separator='_')
    assert is_slug('my.blog.post.title', separator='.')

# Generated at 2022-06-21 21:32:52.228662
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6("2001:db8:85a3:0000:0000:8a2e:370:7334") == True
    assert is_ip_v6("2001:db8:85a3:0000:0000:8a2e:370:7777") == False
    assert is_ip_v6("2001:db8:85a3:0000:0000:8a2e:370:7334") != False
    assert is_ip_v6("2001:db8:85a3:0000:0000:8a2e:370:7777") != True


# Generated at 2022-06-21 21:32:55.792010
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') is True
    assert is_json('[1, 2, 3]') is True
    assert is_json('{nope}') is False
    assert is_json('abc') is False


# Generated at 2022-06-21 21:33:03.069956
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') # true
    assert is_email('@gmail.com') # false
    assert is_email("my.email@the-provider.com") # true
    assert is_email("\\\\\\@gmail.com") # false
    assert is_email("\\\\\\my.email@the-provider.com") # true
print("Test pass!")
test_is_email()


# Generated at 2022-06-21 21:33:09.959776
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') == True
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf') == False
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True) == True



# Generated at 2022-06-21 21:33:14.045647
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog') == True
    assert is_pangram('hello world') == False

is_pangram('The quick brown fox jumps over the lazy dog') == True


# Generated at 2022-06-21 21:33:18.632966
# Unit test for function is_url
def test_is_url():
    assert is_url("https://www.mysite.com") 
    assert is_url("file:///C:/folder/file.extension")
    assert is_url("mysite.com") is False
    assert is_url("www.mysite.com") is False


# Generated at 2022-06-21 21:33:24.075639
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('4.0') == False
    assert is_integer('4.') == False
    assert is_integer('4') == True
    assert is_integer(' 4') == True
    assert is_integer('4 ') == True
    assert is_integer('4a') == False
    assert is_integer('4e5') == True
    assert is_integer('-4') == True
    assert is_integer('+4') == True
    assert is_integer('+4.0') == False
