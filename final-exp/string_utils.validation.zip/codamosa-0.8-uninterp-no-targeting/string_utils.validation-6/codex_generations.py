

# Generated at 2022-06-21 21:23:38.609665
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('42.0') == True
    assert is_decimal('42') == False
    
    
    
    
    
    
    

# Generated at 2022-06-21 21:23:42.864372
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    checker = __ISBNChecker('1234567890123')
    assert checker.is_isbn_13() == True



# Generated at 2022-06-21 21:23:43.773571
# Unit test for function words_count
def test_words_count():
    assert words_count("Cece è carina") == 3
# +
test_words_count()

# Generated at 2022-06-21 21:23:54.451979
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf')
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf')
    assert not is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True)
    assert not is_uuid('6f8aa2f9686c4ac387665712354a04cf')
    assert is_uuid(UUID('6f8aa2f9-686c-4ac3-8766-5712354a04cf'))
    assert is_uuid(UUID('6f8aa2f9686c4ac387665712354a04cf'))
    assert not is_

# Generated at 2022-06-21 21:24:05.077057
# Unit test for function is_uuid
def test_is_uuid():
    import random
    import string
    blocks = [5, 4, 4, 4, 12]
    uuid = string.ascii_letters + string.digits
    for i in range(0,1000):
        hex_uuid = ''.join([random.choice(uuid) for i in range(0,32)])
        assert is_uuid(hex_uuid, True) == True
        assert is_uuid(hex_uuid, False) == False
        for hyphen in [4, 7, 10, 13, 16, 19]:
            assert is_uuid(hex_uuid[0:hyphen] + '-' + hex_uuid[hyphen:], True) == False

# Generated at 2022-06-21 21:24:08.674605
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title')
    assert not is_slug('My blog post title')
    assert is_slug('My blog post title', ' ')



# Generated at 2022-06-21 21:24:16.169129
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com')
    assert is_url('https://mysite.com')
    assert is_url('.mysite.com') == False
    assert is_url('http://www.mysite.com', allowed_schemes=['http', 'https'])
    assert is_url('https://mysite.com', allowed_schemes=['http', 'https'])
    assert is_url('ftp://mysite.com', allowed_schemes=['http', 'https']) == False



# Generated at 2022-06-21 21:24:18.329521
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    checker = __ISBNChecker('97457637819')
    assert checker.is_isbn_13()

# Generated at 2022-06-21 21:24:28.872663
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    checker = __ISBNChecker("1234", False)
    assert checker.is_isbn_10() == True
    checker = __ISBNChecker("12345", False)
    assert checker.is_isbn_10() == False
    checker = __ISBNChecker("0123456789X", False)
    assert checker.is_isbn_10() == True
    checker = __ISBNChecker("01234567891", False)
    assert checker.is_isbn_10() == False
    checker = __ISBNChecker("0123456789", False)
    assert checker.is_isbn_10() == False


# Generated at 2022-06-21 21:24:33.285373
# Unit test for function is_number
def test_is_number():
    assert is_number(1) == True
    assert is_number('42') == True
    assert is_number('19.99') == True
    assert is_number('-9.12') == True
    assert is_number('1e3') == True
    assert is_number('1 2 3') == False
    assert is_number(None) == False
    


# Generated at 2022-06-21 21:24:44.897785
# Unit test for function is_string
def test_is_string():
    # Tests for basic strings
    assert(is_string('foo') == True)
    assert(is_string('foo bar') == True)
    assert(is_string('foo bar baz') == True)

    # Test for empty strings
    assert(is_string('') == True)

    # Tests for other types
    assert(is_string(b'foo') == False)


# Generated at 2022-06-21 21:24:46.588522
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42')
    assert not is_integer('42.0')



# Generated at 2022-06-21 21:24:55.055340
# Unit test for function words_count
def test_words_count():
    assert words_count('ok!') == 0
    assert words_count('hello') == 1
    assert words_count('hello world!') == 2
    assert words_count('hello, world!!') == 2
    assert words_count('hello, world. I\'m here!') == 4
    assert words_count('hello.world!!') == 2
    assert words_count('hello.    world!!') == 2
    assert words_count('hello.world!!') == 2
    assert words_count('') == 0
    assert words_count(None) == 0



# Generated at 2022-06-21 21:24:59.197914
# Unit test for function is_isbn_13
def test_is_isbn_13():
    # True
    assert is_isbn_13('9780312498580')
    assert is_isbn_13('9780312498580\n')
    assert is_isbn_13('978-0312498580')
    assert is_isbn_13('978-0312498580\n')
    assert is_isbn_13('978 0312498580')
    assert is_isbn_13('978 0312498580\n')
    assert is_isbn_13('97910312498580')
    assert is_isbn_13('979-10312498580')
    assert is_isbn_13('979-10312498580\n')
    assert is_isbn_13('979 10312498580')

# Generated at 2022-06-21 21:25:01.047116
# Unit test for function is_number
def test_is_number():
    try:
        assert is_number(42)
    except InvalidInputError:
        pass



# Generated at 2022-06-21 21:25:06.061767
# Unit test for function words_count
def test_words_count():
    assert words_count('one,two,three.stop') == 4
    assert words_count('hello world') == 2
    assert words_count('Hello World!') == 2
    assert words_count('Hello, World!') == 2
    assert words_count('HelloWorld!') == 1
    assert words_count('hello123 world123') == 2
    assert words_count('hello 123 world 123') == 2
    assert words_count('Hello 12. World 12.') == 2
    assert words_count('HelloWorld!') == 1
    assert words_count('Hello-World') == 1
    assert words_count('Hello!-World') == 1
    assert words_count('Hello!-World!') == 1
    assert words_count('Hello-World!') == 1
    assert words_count('Hello-World!') == 1
    assert words

# Generated at 2022-06-21 21:25:09.371521
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') == True
    assert is_isbn_10('150-6715214') == True
    assert is_isbn_10('150-6715214', normalize=False) == False

test_is_isbn_10()



# Generated at 2022-06-21 21:25:12.876647
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') is True
    assert is_ip_v4('nope') is False
    assert is_ip_v4('255.200.100.999') is False


# Generated at 2022-06-21 21:25:15.433423
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') # returns true
    assert not is_uuid('6f8aa2f9686c4ac387665712354a04cf') # returns false
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True) # returns true
# PII related


# Generated at 2022-06-21 21:25:18.881244
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('MyString') == False
    assert is_snake_case('mystring_under') == True
    assert is_snake_case('my string') == False


# Generated at 2022-06-21 21:25:27.049722
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string('') == False
    assert is_full_string(' ') == False
    assert is_full_string('a') == True
    assert is_full_string(1) == False


# Generated at 2022-06-21 21:25:30.538066
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com')
    assert is_url('https://mysite.com')
    assert not is_url('.mysite.com')
test_is_url()



# Generated at 2022-06-21 21:25:35.867507
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('dermatoglyphics') == True
    assert is_isogram('isogram') == True
    assert is_isogram('moose') == False
    assert is_isogram('isIsogram') == False
    assert is_isogram('') == True
test_is_isogram()



# Generated at 2022-06-21 21:25:40.582028
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('foo') is False
    assert is_snake_case('foo_bar') is True
    assert is_snake_case('foo-bar') is True
    assert is_snake_case('1foo-bar') is False


# Generated at 2022-06-21 21:25:51.513078
# Unit test for function is_credit_card
def test_is_credit_card():
    assert(is_credit_card('4111111111111111')) # Visa with valid length
    assert(not is_credit_card('411111111111111')) # Visa with invalid length
    assert(is_credit_card('5555555555554444')) # MasterCard with valid length
    assert(is_credit_card('5555555555554444', card_type='MASTERCARD')) # MasterCard with valid length and card type
    assert(is_credit_card('378282246310005')) # American Express with valid length
    assert(is_credit_card('378282246310005',  card_type='AMERICAN_EXPRESS')) # American Express with valid length and card type
    assert(is_credit_card('30569309025904')) # Diner's Club with valid length

# Generated at 2022-06-21 21:25:53.131356
# Unit test for function is_ip
def test_is_ip():
    assert not is_ip('1.2.3')
    assert is_ip('255.200.100.75')
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334')



# Generated at 2022-06-21 21:25:56.071187
# Unit test for function is_uuid
def test_is_uuid():
    pass
#unit test for function is_decimal

# Generated at 2022-06-21 21:26:03.587272
# Unit test for function is_email
def test_is_email():
    assert is_email('elninoraju@gmail.com')
    assert is_email('elninoraju@yahoo.com')
    assert is_email('elninoraju@rediff.com')
    assert not is_email('elnino.raju@rediff.com')
    assert not is_email('.elninoraju@rediff.com')



# Generated at 2022-06-21 21:26:15.931118
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('1')
    assert is_integer('-1')
    assert is_integer('5e5')
    assert is_integer('-5e5')
    assert not is_integer('1.0')
    assert not is_integer('-1.0')
    assert not is_integer('.0')
    assert not is_integer('-.0')
    assert is_integer('0')
    assert is_integer('-0')
    assert not is_integer('a')
    assert not is_integer('0a')
    assert not is_integer('a0')
    assert not is_integer(' ')
    assert not is_integer('-')
    assert not is_integer('.')
    assert not is_integer('01')
    assert not is_integer('10')
    assert not is_integer('00')

# Generated at 2022-06-21 21:26:20.059170
# Unit test for function is_ip_v6
def test_is_ip_v6():
    _is_ip_v6 = is_ip_v6("2001:db8:85a3:0000:0000:8a2e:370:7334")
    try:
        assert _is_ip_v6 == True, "Testcase failed"
    except:
        traceback.print_exc()



# Generated at 2022-06-21 21:26:33.417526
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('') is False
    assert is_credit_card(None) is False
    assert is_credit_card('foo') is False

    # VISA
    assert is_credit_card('4716805157009383') is True
    assert is_credit_card('4111-1111-1111-1111') is True
    assert is_credit_card('4222222222222') is False
    # MASTERCARD
    assert is_credit_card('5402218231129807') is True
    assert is_credit_card('5404-2218-2311-2980') is True
    assert is_credit_card('5441387576251231') is False
    # AMERICAN_EXPRESS
    assert is_credit_card('375926647828129') is True

# Generated at 2022-06-21 21:26:37.333582
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    checker = __ISBNChecker('9781409319809')
    assert checker.input_string == '9781409319809'
    checker = __ISBNChecker('978-1-4093-1980-9', normalize = False)
    assert checker.input_string == '978-1-4093-1980-9'


# Generated at 2022-06-21 21:26:39.782606
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    checker = __ISBNChecker('978-3-16-148410-0')
    assert checker.input_string == '9783161484100'


# PUBLIC API



# Generated at 2022-06-21 21:26:43.431392
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999')


# Generated at 2022-06-21 21:26:46.789245
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    isbn_checker = __ISBNChecker('0307269651')
    assert isbn_checker.is_isbn_10()


# PUBLIC API



# Generated at 2022-06-21 21:26:51.144097
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('1.2')
    assert is_decimal('-1.2')
    assert is_decimal('1.2e3')
    assert is_decimal('1.2e-3')
    assert not is_decimal('foo')
    assert not is_decimal('1234')



# Generated at 2022-06-21 21:26:57.860741
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('foo_bar_123') == True
    assert is_snake_case('foo-bar-123') == True
    assert is_snake_case('foo-bar-123', separator='-') == True
    assert is_snake_case('foo.bar.123', separator='.') == True
    assert is_snake_case('foo,bar,123', separator=',') == True
    assert is_snake_case('foo123') == False
    assert is_snake_case('foo') == False
    assert is_snake_case('Foo') == False
    assert is_snake_case('') == False
    assert is_snake_case('foo-bar-123') == False
    assert is_snake_case('foo.bar.123') == False



# Generated at 2022-06-21 21:27:05.604014
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome("ROTFL", ignore_spaces = True) == False
    assert is_palindrome("i topi non avevano nipoti", ignore_spaces = False) == True
    assert is_palindrome("Lol", ignore_case = True) == True
    assert is_palindrome("otto", ignore_case = False) == True
    assert is_palindrome("", ignore_case = False) == False
    assert is_palindrome("Loll", ignore_case = True) == False
test_is_palindrome()



# Generated at 2022-06-21 21:27:10.325901
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580')
    assert is_isbn('1506715214')
    assert is_isbn('9780312498580')
    assert is_isbn('978-0312498580')
    assert is_isbn('978-0312498580', normalize=False) == False
test_is_isbn()


# Generated at 2022-06-21 21:27:13.722705
# Unit test for function is_decimal
def test_is_decimal():
    assert(is_decimal('42.0') == True)
    assert(is_decimal('42') == False)


# Generated at 2022-06-21 21:27:25.412859
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    checker = __ISBNChecker('0439400487')
    assert checker.is_isbn_10()

    # isbn-13 but not isbn-10
    checker = __ISBNChecker('0-306-40615-2')
    assert not checker.is_isbn_10()


# PUBLIC API



# Generated at 2022-06-21 21:27:37.298237
# Unit test for function is_palindrome
def test_is_palindrome():
    """
    Check if the function "parlindrome" works correctly.

    *Examples:*

    >>> test_is_palindrome()
    """
    temp_str_1 = "otto"
    temp_str_2 = "rotfl"
    assert is_palindrome(temp_str_1) == True
    assert is_palindrome(temp_str_2) == False
    assert is_palindrome(temp_str_1, ignore_case = True) == True
    assert is_palindrome(temp_str_2, ignore_case = True) == False
    assert is_palindrome(temp_str_1, ignore_spaces = True) == True
    assert is_palindrome(temp_str_2, ignore_spaces = True) == False

# Generated at 2022-06-21 21:27:42.956125
# Unit test for function is_ip
def test_is_ip():
    assert(is_ip('10.20.1.0') == True)
    assert(is_ip('255.200.100.75') == True)
    assert(is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True)
    assert(is_ip('1.2.3') == False)
    try:
        assert(is_ip(None) == True)
    except Exception:
        assert(True)
    print("test_is_ip passed.")
test_is_ip()


# Generated at 2022-06-21 21:27:46.393994
# Unit test for function is_url
def test_is_url():
    assert is_url('https://www.mysite.com/index.html') == True
    assert is_url('http://www.mysite.com/index.html') == True
    assert is_url('http://mysite.com') == True
    assert is_url('www.mysite.com') == True
    assert is_url('http://192.168.1.10') == True
    assert is_url('mysite.com') == False
test_is_url()



# Generated at 2022-06-21 21:27:51.491310
# Unit test for function is_ip
def test_is_ip():
    assert is_ip("255.200.100.75") == True
    assert is_ip("2001:db8:85a3:0000:0000:8a2e:370:7334") == True
    assert is_ip("1.2.3") == False
test_is_ip()



# Generated at 2022-06-21 21:27:55.377320
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False



# Generated at 2022-06-21 21:27:57.129386
# Unit test for function is_email
def test_is_email():
    assert is_email(input_string="test@test.test") == True
    assert is_email(input_string="test") == False

# Generated at 2022-06-21 21:28:07.514354
# Unit test for function is_uuid
def test_is_uuid():
    #Test 1: True
    input_string = '6f8aa2f9-686c-4ac3-8766-5712354a04cf'
    allow_hex = False
    output = is_uuid(input_string, allow_hex)
    assert output == True
    
    #Test 2: False 
    input_string = '6f8aa2f9686c4ac387665712354a04cf'
    allow_hex = False
    output = is_uuid(input_string, allow_hex)
    assert output == False
    
    #Test 3: True
    input_string = '6f8aa2f9686c4ac387665712354a04cf'
    allow_hex = True
    output = is_uuid(input_string, allow_hex)
    assert output

# Generated at 2022-06-21 21:28:12.672111
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580')
    assert is_isbn_13('978-0312498580')
    assert is_isbn_13('978-03-1249-8580')
    assert not is_isbn_13('9780312498580', normalize=False)
    
test_is_isbn_13()


# Generated at 2022-06-21 21:28:15.222333
# Unit test for function contains_html
def test_contains_html():
    assert not contains_html('my string')
    assert contains_html('my string<br>')
    assert contains_html('<p>my string</p>')
    assert not contains_html('')

# Generated at 2022-06-21 21:28:23.482057
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('42.0')
    assert not is_decimal('42')


# Generated at 2022-06-21 21:28:26.494734
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') == True
    assert is_url('https://mysite.com') == True
    assert is_url('.mysite.com') == False



# Generated at 2022-06-21 21:28:28.998771
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') == True
    assert is_url('https://mysite.com') == True
    assert is_url('.mysite.com') == False


# Generated at 2022-06-21 21:28:31.746609
# Unit test for function is_slug
def test_is_slug():
    assert(is_slug('my-blog-post-title') == True)
    assert(is_slug('My blog post title') == False)


# Generated at 2022-06-21 21:28:40.954903
# Unit test for function is_number
def test_is_number():
    assert is_number('42') == True # Python Integer
    assert is_number('-42') == True # Python Integer
    assert is_number('001') == True # Python Integer
    assert is_number('+42') == True # Python Integer
    assert is_number('1.0') == True # Python Float
    assert is_number('-1.0') == True # Python Float
    assert is_number('1.1') == True # Python Float
    assert is_number('9999999999999999999999999999999999999999999999999999') == True # Python Long
    assert is_number('+9999999999999999999999999999999999999999999999999999') == True # Python Long
    assert is_number('-9999999999999999999999999999999999999999999999999999') == True # Python Long
    assert is_number('000') == True # Python

# Generated at 2022-06-21 21:28:41.859875
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram("the quick brown fox jumps over the lazy dog")


# Generated at 2022-06-21 21:28:51.347869
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn("978-0-306-40615-7")
    assert is_isbn("0007269706")
    assert not is_isbn("00307269706")
    assert not is_isbn("978-0306-40615-78")
    assert not is_isbn("000726970")
    assert not is_isbn("978-0306 40615-7")
    assert not is_isbn("000726970 6")
    assert is_isbn("0-306-40615-2")
    assert is_isbn("0-9752298-0-X")
    assert is_isbn("9780306406157")
    assert is_isbn("9780307506157")
    assert not is_isbn("9780307506150")

# Generated at 2022-06-21 21:28:53.787483
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('42.0') == True
    assert is_decimal('42') == False


# Generated at 2022-06-21 21:29:01.658497
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('9780470059029').is_isbn_13()
    assert not __ISBNChecker('978-0470059029').is_isbn_13()
    assert __ISBNChecker('9780470059029', normalize=False).is_isbn_13()
    assert not __ISBNChecker('978047005902').is_isbn_13()
    assert not __ISBNChecker('9780470059025').is_isbn_13()



# Generated at 2022-06-21 21:29:06.430030
# Unit test for function is_ip
def test_is_ip():
    assert is_ip("192.168.0.1")
    assert not is_ip("1.2.3")
    assert is_ip("2001:db8:85a3:0000:0000:8a2e:370:7334")

# Generated at 2022-06-21 21:29:18.389823
# Unit test for function is_snake_case
def test_is_snake_case():
    _snake_case_strings = [
        'foo_bar_baz',
        'foo_bar__baz',
        'foo49_bar_baz',
        '_foo1_bar_baz',
        '49foo1_bar_baz',
        '_',
        '__foo',
        'foo_',
        '_foo',
        '_foo_',
        '_49foo',
        '4'
    ]


# Generated at 2022-06-21 21:29:22.657507
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('dermatoglyphics')
    assert is_isogram('isogram')
    assert not is_isogram('moose')
    assert not is_isogram('isIsogram')
    assert not is_isogram('')
    
test_is_isogram()

# Generated at 2022-06-21 21:29:28.936019
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') # returns true
    assert is_isbn_10('150-6715214') # returns true
    assert not is_isbn_10('150-6715214', normalize=False) # returns false


# Generated at 2022-06-21 21:29:38.348707
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') == True
    assert is_isbn_10('150-6715214') == False
    assert is_isbn_10('150-6715214', normalize=False) == True
    assert is_isbn_10('150.6715214') == False
    assert is_isbn_10('150.6715214', normalize=False) == True
    assert is_isbn_10('a', normalize=False) == False
    assert is_isbn_10('a') == False
    assert is_isbn_10('123456789a') == False
    assert is_isbn_10('123456789a', normalize=False) == False
    assert is_isbn_10('1234567891') == True
    assert is_isbn_10

# Generated at 2022-06-21 21:29:49.974076
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    ISBN = __ISBNChecker("9780306406157")
    assert ISBN.is_isbn_13()
    assert not ISBN.is_isbn_10()
    ISBN = __ISBNChecker("0306406152")
    assert ISBN.is_isbn_10()
    assert not ISBN.is_isbn_13()
    ISBN = __ISBNChecker("030640615X")
    assert not ISBN.is_isbn_10()
    assert not ISBN.is_isbn_13()
    ISBN = __ISBNChecker("030640615X")
    assert not ISBN.is_isbn_10()
    assert not ISBN.is_isbn_13()
    ISBN = __ISBNChecker("9780306406156")
    assert not ISBN.is_isbn_13()

# Generated at 2022-06-21 21:29:55.413091
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580')
    assert is_isbn_13('978-0312498580')
    assert is_isbn_13('978-0312498580', normalize=False) is False
# Test is_isbn_13
test_is_isbn_13()


# Generated at 2022-06-21 21:30:05.288112
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4111111111111111') == True
    assert is_credit_card('6011111111111117') == True
    assert is_credit_card('5105105105105100') == True
    assert is_credit_card('5105105105105106') == True
    assert is_credit_card('378282246310005') == True
    assert is_credit_card('378734493671000') == True
    assert is_credit_card('30569309025904') == True
    assert is_credit_card('38520000023237') == True
    assert is_credit_card('6011111111111117') == True
    assert is_credit_card('3530111333300000') == True
    assert is_credit_card('3566002020360505') == True
    assert is_credit_

# Generated at 2022-06-21 21:30:08.061491
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com')
    assert is_url('https://mysite.com')
    assert not is_url('.mysite.com')
    assert is_url('telnet://www.mysite.com', ['telnet', 'http'])



# Generated at 2022-06-21 21:30:13.984377
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('LOL')
    assert is_palindrome('Lol', ignore_case=True)
    assert is_palindrome('i topi non avevano nipoti')
    assert is_palindrome('i topi non avevano nipoti', ignore_spaces=True)
    assert not is_palindrome('ROTFL')
    assert not is_palindrome('Lol')
    assert not is_palindrome('i topi avevano nipoti')


# Generated at 2022-06-21 21:30:17.579704
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580') is True
    assert is_isbn_13('978-0312498580') is True
    assert is_isbn_13('978-0312498580') is True
    assert is_isbn_13('9780312498580', normalize=False) is True
    print("test_is_isbn_13() passed!")

test_is_isbn_13()


# Generated at 2022-06-21 21:30:43.425040
# Unit test for function is_email
def test_is_email():
    assert is_email("xxx@yahoo.com") == True
    assert is_email("xxx-100@yahoo.com") == True
    assert is_email("xxx.100@yahoo.com") == True
    assert is_email("xxx111@xxx.com") == True
    assert is_email("xxx-100@xxx.net") == True
    assert is_email("xxx.100@xxx.com.au") == True
    assert is_email("xxx@1.com") == True
    assert is_email("xxx@gmail.com.com") == True
    assert is_email("xxx+100@gmail.com") == True
    assert is_email("xxx-100@yahoo-test.com") == True
    # border cases
    assert is_email("xxx") == False

# Generated at 2022-06-21 21:30:49.237956
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('mango') is False
    assert is_isogram('hello') is False
    assert is_isogram('Dermatoglyphics') is True
    assert is_isogram('isogram') is True
    assert is_isogram('') is True

    print('Test Successful')
test_is_isogram()


# Generated at 2022-06-21 21:30:58.591791
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4242424242424242', 'VISA') == True
    assert is_credit_card('5555555555554444', 'MASTERCARD') == True
    assert is_credit_card('378282246310005', 'AMERICAN_EXPRESS') == True
    assert is_credit_card('30569309025904', 'DINERS_CLUB') == True
    assert is_credit_card('6011111111111117', 'DISCOVER') == True
    assert is_credit_card('3530111333300000', 'JCB') == True
    assert is_credit_card('4242424242424242', 'UNKNOWN') == False
test_is_credit_card()



# Generated at 2022-06-21 21:31:01.929775
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string('a') == True
    assert is_full_string('')==False
    assert is_full_string('    ')==False

# Generated at 2022-06-21 21:31:07.473757
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75') == True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip('1.2.3') == False
    
test_is_ip()


# Generated at 2022-06-21 21:31:16.660608
# Unit test for function is_json
def test_is_json():
  assert is_json("[]") == True
  assert is_json("{}") == True
  assert is_json("{]") == False
  assert is_json("[]}") == False
  assert is_json("[") == False
  assert is_json("]") == False
  assert is_json("]") == False
  assert is_json("{}") == True
  assert is_json("{name: 'Peter'}") == False
  assert is_json('{"name": "Peter"}') == True
  assert is_json("{'name': 'Peter'}") == False
  assert is_json('{"name": 1}') == True
  assert is_json('["a", "b", "c"]') == True
  assert is_json('["a", "b", 1]') == True
  assert is_

# Generated at 2022-06-21 21:31:21.851728
# Unit test for function is_isogram
def test_is_isogram():
    print ("Test is_isogram")
    assert is_isogram('dermatoglyphics') == True
    assert is_isogram('isogram') == True
    assert is_isogram('aba') == False
    assert is_isogram('moOse') == False
    assert is_isogram('isIsogram') == False
    assert is_isogram('') == True
    assert is_isogram('dermatoglyphics') == True
    assert is_isogram('isogram') == True

# Generated at 2022-06-21 21:31:24.555037
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert True is is_isbn_13("978-0-306-40615-7")

# Generated at 2022-06-21 21:31:29.472896
# Unit test for function is_url
def test_is_url():
    assert is_url(r'http://www.mysite.com') == True
    assert is_url(r'https://mysite.com') == True
    assert is_url(r'mysite.com') == False
    assert is_url(r'.mysite.com') == False
# -------------------------------------------------------


# Generated at 2022-06-21 21:31:32.599958
# Unit test for function is_pangram
def test_is_pangram():
    print(is_pangram('The quick brown fox jumps over the lazy dog'))  # returns true
    print(is_pangram('hello world'))  # returns false

test_is_pangram()


# Generated at 2022-06-21 21:31:51.657125
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75') == True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip('1.2.3') == False, 'Not a valid IP'
    return True

test_is_ip()


# Generated at 2022-06-21 21:32:02.878546
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('otto') is True
    assert is_palindrome('otto', ignore_spaces=True) is True
    assert is_palindrome('ROTFL') is False
    assert is_palindrome('ROTFL', ignore_spaces=True) is False
    assert is_palindrome('i topi non avevano nipoti') is True
    assert is_palindrome('i topi non avevano nipoti', ignore_spaces=True) is False
    assert is_palindrome('Madam, I\'m Adam', ignore_case=True) is True
    assert is_palindrome('Madam, I\'m Adam', ignore_spaces=True, ignore_case=True) is True



# Generated at 2022-06-21 21:32:05.769914
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog') == True
    assert is_pangram('hello world') == False
test_is_pangram()

# Generated at 2022-06-21 21:32:17.289690
# Unit test for function is_url
def test_is_url():
    assert is_url('http://abc.com')
    assert is_url('https://abc.com')
    assert not is_url('abc')
    assert not is_url('.abc')
    assert is_url('http://abc.com', ['http'])
    assert not is_url('https://abc.com', ['http'])
    assert is_url('http://abc.com:8080')
    assert is_url('http://www.abc.com/index.html')
    assert is_url('http://abc.com/index.html#abc')
    assert is_url('http://abc.com/index.html?abc')
    assert is_url('http://abc.com/index.html?abc=123')

# Generated at 2022-06-21 21:32:18.452375
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('moses')==True

# Generated at 2022-06-21 21:32:30.304773
# Unit test for function is_uuid
def test_is_uuid():
    testData = [
      ("6f8aa2f9-686c-4ac3-8766-5712354a04cf",True),
      ("6f8aa2f9686c4ac387665712354a04cf",False),
      ("6f8aa2f9686c4ac387665712354a04cf",True,True),
      ("6f8aa2f9686c4ac387665712354a04cf1",False),
      ("6f8aa2f9686c4ac387665712354a04cf1",True,True)
    ]
    for test in testData:
        result = is_uuid(test[0],test[2])
        if result!=test[1]:
            return False
    return True
print("Test for function: is_uuid")

# Generated at 2022-06-21 21:32:31.890413
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') is True
    assert is_isbn('1506715214') is True


# Generated at 2022-06-21 21:32:38.688554
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf')
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf') is False
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True)


# Generated at 2022-06-21 21:32:50.160600
# Unit test for function is_number
def test_is_number():
    assert is_number("0")
    assert is_number("1")
    assert is_number("-1")
    assert is_number("0.0")
    assert is_number("1.0")
    assert is_number("-1.0")
    assert is_number("1.1")
    assert is_number("-1.1")
    assert is_number("1e1")
    assert is_number("-1e1")
    assert is_number("1.1e1")
    assert is_number("-1.1e1")
    assert is_number("1.1e-1")
    assert is_number("-1.1e-1")
    assert is_number("1.1e10")
    assert is_number("-1.1e10")

# Generated at 2022-06-21 21:32:55.553588
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('9') == True
    assert is_integer('9.5') == False
    assert is_integer('-10') == True
    assert is_integer('3.14') == False
    assert is_integer('0xFF') == True
    assert is_integer('010') == True
    assert is_integer('2e2') == True