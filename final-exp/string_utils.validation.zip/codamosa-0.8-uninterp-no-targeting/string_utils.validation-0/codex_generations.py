

# Generated at 2022-06-21 21:23:33.771982
# Unit test for function is_url
def test_is_url():
    assert is_url('') == False
    assert is_url('http://www.mysite.com')
    assert is_url('https://mysite.com')
    assert is_url('    http://www.mysite.com')
    assert is_url('ftp://www.mysite.com')
    assert is_url('mysite.com') == False
    assert is_url(".mysite.com") == False

# Generated at 2022-06-21 21:23:39.438199
# Unit test for function is_full_string
def test_is_full_string():
    examples = (
        {'input_string': None},
        {'input_string': ''},
        {'input_string': ' '},
        {'input_string': 'hello'},
    )

    for example in examples:
        assert is_full_string(**example)
#is_full_string()



# Generated at 2022-06-21 21:23:45.879557
# Unit test for function is_json
def test_is_json():
    assert False == is_json("{nope}")
    assert False == is_json("test")
    assert False == is_json("1")
    assert False == is_json("")
    assert False == is_json("[{]")
    assert True == is_json("{}")
    assert True == is_json("[]")


# Generated at 2022-06-21 21:23:51.341768
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('019852686X').is_isbn_10() == True
    assert __ISBNChecker('019852686x').is_isbn_10() == True
    assert __ISBNChecker('019852686y').is_isbn_10() == False
    assert __ISBNChecker('0198526861').is_isbn_10() == True
    assert __ISBNChecker('0198526862').is_isbn_10() == False


# Generated at 2022-06-21 21:23:56.389139
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('dermatoglyphics')
    assert is_isogram('isogram')
    assert is_isogram('moose')
    assert is_isogram('isIsogram')
    assert is_isogram('')
    assert not is_isogram('aba')
    assert not is_isogram('moOse')
    assert not is_isogram('thumbscrewjapingly')
    assert not is_isogram('the quick brown fox')

is_isogram('dermatoglyphics')
is_isogram('isogram')

# test function is_full_string

# Generated at 2022-06-21 21:24:00.392955
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('1-933988-03-7').is_isbn_10()
    assert __ISBNChecker('978-1-934356-01-3').is_isbn_10() is False


# Generated at 2022-06-21 21:24:10.402748
# Unit test for function is_uuid
def test_is_uuid():
    #0
    print("Test case 0")
    print("Input:")
    print("'6f8aa2f9-686c-4ac3-8766-5712354a04cf'")
    print("Expected output:")
    print("True")
    print("Output:")
    print(is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf'))
    print()
    
    #1
    print("Test case 1")
    print("Input:")
    print("'6f8aa2f9686c4ac387665712354a04cf'")
    print("Expected output:")
    print("False")
    print("Output:")

# Generated at 2022-06-21 21:24:12.603931
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog')
    assert not is_pangram('hello world')
test_is_pangram()

# Generated at 2022-06-21 21:24:17.440475
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') is True
    assert is_isbn('1506715214') is True
    assert is_isbn('978-0312498580') is True
    assert is_isbn('978-0312498580', normalize=False) is False


# Generated at 2022-06-21 21:24:19.659526
# Unit test for function is_isogram
def test_is_isogram():
	assert is_isogram('Dermatoglyphics') == True
	assert is_isogram('isogram') == True
	assert is_isogram('aba') == False
	assert is_isogram('moOse') == False
	assert is_isogram('isIsogram') == False
	assert is_isogram('') == True


# Generated at 2022-06-21 21:24:42.354673
# Unit test for function is_slug
def test_is_slug():
    """Test for function is_slug."""
    assert is_slug('my-blog-post-title') == True
    assert is_slug('My blog post title') == False
    assert is_slug('a') == True
    assert is_slug('a-') == True
test_is_slug()

# Generated at 2022-06-21 21:24:45.138852
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334')
    assert not is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?')
test_is_ip_v6()


# Generated at 2022-06-21 21:24:49.644585
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf')
    assert not is_uuid('6f8aa2f9686c4ac387665712354a04cf')
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True)


# Generated at 2022-06-21 21:24:52.050303
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('42.0') == True
    assert is_decimal('42') == False


# Generated at 2022-06-21 21:24:55.536325
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') == True
    assert is_url('https://mysite.com') == True
    assert is_url('.mysite.com') == False


# Generated at 2022-06-21 21:24:59.246792
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') # returns true
    assert is_url('https://mysite.com') # returns true
    assert not is_url('mysite.com') # returns false


# Generated at 2022-06-21 21:25:00.385994
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram("the quick brown fox jumps over the lazy dog") == True
    assert is_pangram("hello world") == False
test_is_pangram()



# Generated at 2022-06-21 21:25:03.091041
# Unit test for function is_string
def test_is_string():
    string_test1 = "Hello"
    string_test2 = 123
    
    assert is_string(string_test1) == True
    assert is_string(string_test2) == False


# Generated at 2022-06-21 21:25:07.725325
# Unit test for function is_number
def test_is_number():
    assert is_number('42') == True
    assert is_number('19.99') == True
    assert is_number('-9.12') == True
    assert is_number('1e3') == True
    assert is_number('1 2 3') == False


# Generated at 2022-06-21 21:25:15.272428
# Unit test for function words_count
def test_words_count():
    # Test with a string
    assert words_count('hello world') == 2, "words_count('hello world') fails"
    assert words_count('one,two,three.stop') == 4, "words_count('one,two,three.stop') fails"

    # Test with a null string
    assert words_count('') == 0

    # Test with non string input data
    try:
        words_count([])
        assert False, "words_count([]) should raise an exception"
    except InvalidInputError:
        pass

    try:
        words_count({})
        assert False, "words_count({}) should raise an exception"
    except InvalidInputError:
        pass


# Generated at 2022-06-21 21:25:24.428685
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    obj = __ISBNChecker('978031234-5680')
    assert obj.is_isbn_13() is True


# Generated at 2022-06-21 21:25:25.793633
# Unit test for function words_count
def test_words_count():
    assert words_count('this is my test') == 4
    assert words_count('one, two, three. stop!') == 4

# Generated at 2022-06-21 21:25:33.531743
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('foo_bar_baz') == True
    assert is_snake_case('foo') == False
    assert is_snake_case('Foo_bar') == False
    assert is_snake_case('@-foo-bar') == False
    assert is_snake_case('foo-bar-baz', '-') == True
    assert is_snake_case('foo-bar-baz', '_') == False


# Generated at 2022-06-21 21:25:45.633017
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    checker = __ISBNChecker(
        input_string='9780984782857',
        normalize=True
    )
    assert checker.input_string == '9780984782857'

    checker = __ISBNChecker(
        input_string='978-0984782857',
        normalize=False
    )
    assert checker.input_string == '978-0984782857'

    checker = __ISBNChecker(
        input_string='978-0984782857',
        normalize=True
    )
    assert checker.input_string == '9780984782857'

    try:
        checker = __ISBNChecker(
            input_string='test',
            normalize=True
        )
    except InvalidInputError:
        pass



# Generated at 2022-06-21 21:25:50.172634
# Unit test for function is_uuid
def test_is_uuid():
    # A typical hex UUID looks like this:
    #   6f8aa2f9-686c-4ac3-8766-5712354a04cf
    print("----------------------")
    print("Start testing is_uuid")
    s = '6f8aa2f9-686c-4ac3-8766-5712354a04cf'
    assert is_uuid(s)
    print("testing is_uuid passed")



# Generated at 2022-06-21 21:25:52.657077
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram("hello") == False
    assert is_isogram("dermatoglyphics") == True
    print("test_is_isogram() passed")
test_is_isogram()


# Generated at 2022-06-21 21:26:03.934583
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-3-16-148410-0').is_isbn_13() == True

    assert __ISBNChecker('9788180320093').is_isbn_13() == True

    assert __ISBNChecker('9783161484100').is_isbn_13() == True

    assert __ISBNChecker('978316148410').is_isbn_13() == False

    assert __ISBNChecker('9783161484108').is_isbn_13() == False

    assert __ISBNChecker('9788180320095').is_isbn_13() == False

    assert __ISBNChecker('9788180320099').is_isbn_13() == False

    assert __ISBNChecker('978-3-16-148410-8').is_

# Generated at 2022-06-21 21:26:05.999798
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    c = __ISBNChecker('123456789x')
    c.is_isbn_10()

# PUBLIC API



# Generated at 2022-06-21 21:26:16.557019
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('otto') is True
    assert not is_palindrome('ROTFL')
    assert is_palindrome('i topi non avevano nipoti', ignore_spaces=True)
    assert not is_palindrome('A man, a plan, a canal, Panama!', ignore_spaces=False)
    assert is_palindrome('A man, a plan, a canal, Panama!', ignore_spaces=True)
    assert is_palindrome('i topi non avevano nipoti')
    assert not is_palindrome('to non avevano nipoti')


# Generated at 2022-06-21 21:26:18.096643
# Unit test for function is_json
def test_is_json():
    assert is_json('[1,2,3]') == True
    assert is_json('{"name": "Peter"}') == True
    assert is_json('{nope}') == False
    assert is_json('"name": "Peter"') == False


# Generated at 2022-06-21 21:26:32.059208
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('Dermatoglyphics') == True
    assert is_isogram('isogram') == True
    assert is_isogram('aba') == False
    assert is_isogram('moOse') == False
    assert is_isogram('isIsogram') == False
    assert is_isogram('') == True
    print("Test PASSED")

# Run test function
test_is_isogram()

# In[ ]:



# Generated at 2022-06-21 21:26:39.237480
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('a-z-a-e-i-o-u-y') == True
    assert is_slug('a-z-a-e-i-o-u-y-A-B-C-D') == True
    assert is_slug('A-Z-a-e-i-o-u-y-A-B-C-D') == False
    assert is_slug('a-z-a-e-i-o-u-y-A-B-C-D-') == True
    assert is_slug('a-z-a-e-i-o-u-y-AB-C-D-') == False

# Generated at 2022-06-21 21:26:46.687553
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('978-0-306-40615-7')
    assert is_isbn('0-306-40615-2')
    assert is_isbn('0-306-40615-', normalize=False)
    assert not is_isbn('0-306-40615-X')
    assert not is_isbn('978-0-306-40615-0')
    assert not is_isbn('979-0-306-40615-7')



# Generated at 2022-06-21 21:26:49.063774
# Unit test for function is_isogram
def test_is_isogram():
    # Test true case
    assert is_isogram('The quick brown fox jumps over the lazy dog') == True
    # Test false case (repeated letter)
    assert is_isogram('hello') == False


# Generated at 2022-06-21 21:26:51.624061
# Unit test for function words_count
def test_words_count():
    assert words_count('hello world') == 2
    assert words_count('one,two,three.stop') == 4
    assert words_count('') == 0
# Test
test_words_count()

# Generated at 2022-06-21 21:26:57.461117
# Unit test for function is_ip
def test_is_ip():
    assert not is_ip(123456)
    assert is_ip(ip_address('2001:db8:85a3:0000:0000:8a2e:370:7334'))
    assert is_ip(ip_address('255.200.100.75'))
    assert not is_ip('1.2.3')


# Generated at 2022-06-21 21:27:02.698649
# Unit test for function is_json
def test_is_json():
    jsonMatches = ['{"name": "Peter"}', '[1, 2, 3]']
    jsonNonMatches = ['{nope}']

    for str in jsonMatches:
        print(is_json(str))

    for str in jsonNonMatches:
        print(is_json(str))



# Generated at 2022-06-21 21:27:11.582176
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com')
    assert is_url('https://mysite.com')
    assert is_url('ftp://mysite.com')
    assert is_url('ftps://mysite.com')
    assert is_url('http://mysite.com')
    assert is_url('https://www.mysite.com')
    assert is_url('https://www.mysite.com/')
    assert is_url('https://www.mysite.com/mypath/')
    assert is_url('https://www.mysite.com/my/very/long/path/')
    assert is_url('https://www.mysite.com/my/very/long/path/with/a-file.html')

# Generated at 2022-06-21 21:27:15.798384
# Unit test for function is_string
def test_is_string():
    try:
        is_string('foo')
        print('Test case passed')
    except Exception as e:
        print('Test case fail:', e)
test_is_string()



# Generated at 2022-06-21 21:27:20.744631
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('dermatoglyphics') == True
    assert is_isogram('isogram') == True
    assert is_isogram('moose') == False
    assert is_isogram('isIsogram') == False
    assert is_isogram('') == True

# Generated at 2022-06-21 21:27:35.513409
# Unit test for function contains_html
def test_contains_html():
    """
    Tests function `contains_html`.
    """
    assert contains_html('my string is <strong>bold</strong>')
    assert contains_html('my string is <strong>bold</strong><script src="foo.js">')
    assert contains_html('<div style="foo: bar"><h1>my title</h1><p>my message</p></div>')
    assert not contains_html('my string is not bold')
    assert not contains_html('my string is <strong>bold</strong> but no script')



# Generated at 2022-06-21 21:27:43.367725
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    assert __ISBNChecker('978-0-306-40615-7').input_string == '9780306406157'
    assert __ISBNChecker('0-306-40615-2', normalize=False).input_string == '0-306-40615-2'
    assert __ISBNChecker('978-0-306-40615-7').input_string == '9780306406157'
    assert __ISBNChecker('0-306-40615-2', normalize=False).input_string == '0-306-40615-2'
    assert not __ISBNChecker('978-0-306-40615-7').is_isbn_10()
    assert __ISBNChecker('0-306-40615-2').is_isbn_10()

# Generated at 2022-06-21 21:27:48.169079
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    try:
        __ISBNChecker('')
    except InvalidInputError:
        pass

    assert __ISBNChecker('9780134685991').is_isbn_13() is True

    assert __ISBNChecker('0134685998').is_isbn_10() is True


# PUBLIC API


# check if the string is a valid uuid

# Generated at 2022-06-21 21:27:54.976306
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram(input_string="Dermatoglyphics") == True
    assert is_isogram(input_string="isogram") == True
    assert is_isogram(input_string="aba") == False
    assert is_isogram(input_string="moOse") == False
    assert is_isogram(input_string="isIsogram") == False
    assert is_isogram(input_string="") == True
    print ("All test cases passed!")
test_is_isogram()


# Generated at 2022-06-21 21:27:57.961910
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    # given
    input_string = '978-0-13-149505-0'

    # when
    checker = __ISBNChecker(input_string)

    # then
    assert checker.input_string == '9780131495050'



# Generated at 2022-06-21 21:28:02.630436
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') is True
    assert is_isbn('1506715214') is True
    assert is_isbn('15067152144') is False
    assert is_isbn('978-0312498580') is True
    assert is_isbn('978-0312498580', normalize=False) is False
    assert is_isbn('150-6715214', normalize=False) is False
    assert is_isbn('') is False
    assert is_isbn(None) is False
    
    
    

# Generated at 2022-06-21 21:28:06.058362
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')==True
    assert is_email('@gmail.com')==False
    
    

# Generated at 2022-06-21 21:28:10.968897
# Unit test for function is_palindrome
def test_is_palindrome():
    print(">>> Testing function is_palindrome...")
    assert is_palindrome('LOL') # returns true
    assert not is_palindrome('Lol') # returns false
    assert is_palindrome('Lol', ignore_case=True) # returns true
    assert not is_palindrome('ROTFL')

# Generated at 2022-06-21 21:28:17.404058
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1582972821')
    assert not is_isbn_10('1582972820')
    assert is_isbn_10('1582972821', normalize=False)
    assert is_isbn_10('1-58297-282-1')
    assert is_isbn_10('1-58297-282-1', normalize=False)
    assert not is_isbn_10('1-58297-281-1')
    assert not is_isbn_10('1-58297-281-1', normalize=False)


# Generated at 2022-06-21 21:28:19.276521
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}')
    assert is_json('[1, 2, 3]')
    assert is_json('{nope}') == False


# Generated at 2022-06-21 21:28:31.746650
# Unit test for function is_string
def test_is_string():
    assert is_string('foo')
    assert not is_string(b'foo')


# Generated at 2022-06-21 21:28:40.954693
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('9780131495050').is_isbn_13() is True
    assert __ISBNChecker('978-0-13-149505-0').is_isbn_13() is True
    assert __ISBNChecker('9780-265-10846-9').is_isbn_13() is True
    assert __ISBNChecker('9780260108469').is_isbn_13() is True
    assert __ISBNChecker('978-0-262-69781-0').is_isbn_13() is True
    assert __ISBNChecker('9780262697810').is_isbn_13() is True
    assert __ISBNChecker('978-0-262-16208-4').is_isbn_13() is True

# Generated at 2022-06-21 21:28:47.572810
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42')
    assert not is_integer('42.0')
    assert not is_integer('42.1')
    assert not is_integer('arg')
    assert not is_integer('')
    assert is_integer('0')
    assert is_integer('00')
    assert not is_integer('a')
    assert not is_integer('/')
    assert not is_integer(' ')



# Generated at 2022-06-21 21:29:00.197836
# Unit test for method is_isbn_10 of class __ISBNChecker

# Generated at 2022-06-21 21:29:02.479181
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('42.0') == True
    assert is_decimal('42') == False

test_is_decimal()



# Generated at 2022-06-21 21:29:06.636958
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome("a")
    assert is_palindrome("otto")
    assert is_palindrome("i topi non avevano nipoti")
    assert is_palindrome("i topi non avevano nipoti", ignore_spaces=True)
    assert not is_palindrome("rotfl")
test_is_palindrome()



# Generated at 2022-06-21 21:29:11.423782
# Unit test for function is_number
def test_is_number():
    assert is_number('42') == True
    
    assert is_number('19.99') == True
    
    assert is_number('-9.12') == True
    
    assert is_number('1e3') == True
    
    assert is_number('1 2 3') == False



# Generated at 2022-06-21 21:29:20.862850
# Unit test for function is_ip_v6
def test_is_ip_v6():
    """
    Test for function is_ip_v6.

    The test will pass if all of these assertions are correct.
    """
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334')
    assert not is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?')
    assert not is_ip_v6('2001:db8:85a3::8a2e:370:7334')
    assert is_ip_v6('2001:db8::8a2e:370:7334')
    assert not is_ip_v6('2001:db8:85a3:0:0:8a2e:370:7334:')

# Generated at 2022-06-21 21:29:28.130486
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('my string is <strong>bold</strong>')
    assert not contains_html('my string is not bold')
    assert not contains_html('')
    assert not contains_html(None)
    assert not contains_html('helloab!')
    assert not contains_html('helloab!<>')
    assert not contains_html('helloab!<>')
    assert not contains_html('helloab!<>')
    assert not contains_html('helloab!&<>')
    assert contains_html('helloab!&<>helloab!<>')


# Generated at 2022-06-21 21:29:31.115508
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title')
    assert is_slug('my-blog-post-title', separator='_')
    assert not is_slug('My blog post title')



# Generated at 2022-06-21 21:29:51.641918
# Unit test for function is_number
def test_is_number():
    assert is_number("12") == True
    assert is_number("12.34") == True
    assert is_number("-12.34") == True
    assert is_number("12.34e1") == True
    assert is_number("12.34e+1") == True
    assert is_number("12.34e-1") == True
    assert is_number("12e1") == True
    assert is_number("-12e+1") == True
    assert is_number("-12.5e-1.2") == False
    assert is_number("+12.5e-1.2") == False
    assert is_number("12.5.-1.2") == False
    assert is_number("12.5.+1.2") == False

# Generated at 2022-06-21 21:29:56.431057
# Unit test for function is_string
def test_is_string():
    assert is_string('foo') == True
    assert is_string(b'foo') == False
    assert is_string(None) == False
    assert is_string([]) == False
    assert is_string({}) == False
    assert is_string(True) == False
    assert is_string(123) == False



# Generated at 2022-06-21 21:30:00.562492
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid(UUID('6f8aa2f9-686c-4ac3-8766-5712354a04cf'))
    assert not is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf')
    assert not is_uuid(None)



# Generated at 2022-06-21 21:30:10.788708
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('42.01') == True
    assert is_decimal('42.0') == True
    assert is_decimal('42.01') == True
    assert is_decimal('42.0') == True
    assert is_decimal('42') == False
    assert is_decimal('42e1') == False
    assert is_decimal('42e10') == False
    assert is_decimal('42e-10') == False
    assert is_decimal('-42.01') == True
    assert is_decimal('-42.0') == True
    assert is_decimal('-42') == False
    assert is_decimal('-42e1') == False
    assert is_decimal('-42e10') == False
    assert is_decimal('-42e-10') == False

# Generated at 2022-06-21 21:30:12.426732
# Unit test for function is_string
def test_is_string():
    assert is_string('foo')
    assert not is_string(b'foo')
#


# Generated at 2022-06-21 21:30:20.795338
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('MyString') == True
    assert is_camel_case('mystring') == False
    assert is_camel_case('12345') == False
    assert is_camel_case('text-with-hyphen') == False
    assert is_camel_case('text_with_underscore') == False
    assert is_camel_case('TExt') == False
    assert is_camel_case('Text') == False
    assert is_camel_case('text') == False
    assert is_camel_case('Text5') == True
    assert is_camel_case('test5') == False


# Generated at 2022-06-21 21:30:26.565364
# Unit test for function is_number
def test_is_number():
    assert is_number("+42")
    assert is_number("-9.12")
    assert is_number("1e3")
    assert not is_number("12 3")
# Run unit tests for function is_number
if __name__ == "__main__":
    test_is_number()



# Generated at 2022-06-21 21:30:31.731161
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert is_ip_v4('0.0.0.0')
    assert not is_ip_v4('255.200.100.999')
    assert not is_ip_v4('nope')


# Generated at 2022-06-21 21:30:37.392250
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('ERDOS') == True
    assert is_isogram('dermatoglyphics') == True
    assert is_isogram('hello') == False
    assert is_isogram('lavender') == False
    assert is_isogram('leaves') == False
    assert is_isogram('highfive') == False
    assert is_isogram('zerg') == False

# Generated at 2022-06-21 21:30:42.246426
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case("MyString")
    assert is_camel_case("mystring") == False
    assert is_camel_case("my_string") == False
    assert is_camel_case("M") == False
    assert is_camel_case(None) == False



# Generated at 2022-06-21 21:31:01.811093
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title') == True
    assert is_slug('My blog post title') == False
    assert is_slug('my-blog-post-title', separator='_') == True
    assert is_slug('my--blog--post--title') == True
    assert is_slug('my--blog--post--title', separator='_') == True
    assert is_slug('my--blog--post--title', separator='__') == False

is_slug('my-blog-post-title') # return True
is_slug('My blog post title') # return False
is_slug('my-blog-post-title', separator='_') # return True
is_slug('my--blog--post--title') # return True

# Generated at 2022-06-21 21:31:10.873313
# Unit test for function is_ip
def test_is_ip():
    # for ipv4
    assert is_ip('255.200.100.75')
    assert not is_ip('1.2.3')
    assert not is_ip('255.200.100.999')
    assert not is_ip('nope')
    # for ipv6
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334')
    assert not is_ip('2001:db8:85a3:0000:0000:8a2e:370:?')
    assert not is_ip('localhost')


# Generated at 2022-06-21 21:31:14.623602
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string(None) == False
    assert is_full_string('') == False
    assert is_full_string(' ') == False
    assert is_full_string('hello') == True
# test_is_full_string()


# Generated at 2022-06-21 21:31:19.093980
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string(None) == False
    assert is_full_string('') == False
    assert is_full_string(' ') == False
    assert is_full_string('hello') == True
    print("Function(is_full_string) returns expected outputs")



# Generated at 2022-06-21 21:31:24.664789
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid("6f8aa2f9-686c-4ac3-8766-5712354a04cf") == True
    assert is_uuid("6f8aa2f9686c4ac387665712354a04cf") == False
    assert is_uuid("6f8aa2f9686c4ac387665712354a04cf", allow_hex=True) == True


# Generated at 2022-06-21 21:31:34.590917
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('192.168.1.1') == True
    assert is_ip_v4('192.168.1.0') == True
    assert is_ip_v4('192.168.1.255') == True
    assert is_ip_v4('192.168.1') == False
    assert is_ip_v4('255.255.255') == False
    assert is_ip_v4('255.1.168.1.255') == False
    assert is_ip_v4('1.1.1.256') == False
    assert is_ip_v4('1.1.1.1/1') == False
    assert is_ip_v4('1.1.1.1a') == False

# Generated at 2022-06-21 21:31:40.435421
# Unit test for function contains_html
def test_contains_html():
    assert(contains_html('my string is <strong>bold</strong>') == True)
    assert(contains_html('my string is not bold') == False)
    return "Unit test for function contains_html passed"
print(test_contains_html())


# Generated at 2022-06-21 21:31:46.674883
# Unit test for function words_count
def test_words_count():
    assert words_count('') == 0
    assert words_count('! @ # % ... []') == 0
    assert words_count('one,two,three.stop') == 4
    assert words_count('six seven eight.stop') == 5
    assert words_count('Hello world') == 2
    assert words_count('Hello world!') == 2
    assert words_count('Hello, world!') == 2
    assert words_count('Hello,world!') == 2



# Generated at 2022-06-21 21:31:50.246259
# Unit test for function is_number
def test_is_number():
    assert is_number('42') == True
    assert is_number('19.99') == True
    assert is_number('-9.12') == True
    assert is_number('1e3') == True
    assert is_number('1 2 3') == False



# Generated at 2022-06-21 21:32:02.350505
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4111-1111-1111-1111')
    assert is_credit_card('4111111111111111')
    assert is_credit_card('4111 1111 1111 1111')
    assert is_credit_card('4111-1111-1111-111') is False

    assert is_credit_card('5500 0000 0000 0004')
    assert is_credit_card('5555 5555 5555 4444')
    assert is_credit_card('5555-5555-5555-4444')
    assert is_credit_card('5500 0000 0000 0044') is False

    assert is_credit_card('2131-1800-0000-0008')
    assert is_credit_card('3528-0000-0000-0008')
    assert is_credit_card('35280000-0000-0008')



# Generated at 2022-06-21 21:32:16.722110
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('42.0')==True
    assert is_decimal('42')==False
    assert is_decimal('42.67')==True

# Generated at 2022-06-21 21:32:23.896229
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4111111111111111') == True
    assert is_credit_card('5555555555554444') == True
    assert is_credit_card('378282246310005') == True
    assert is_credit_card('6011111111111117') == True
    assert is_credit_card('5105105105105100') == True
    assert is_credit_card('3530111333300000') == True
    assert is_credit_card('4222222222222') == True
    assert is_credit_card('5105 1051 0510') == False
    assert is_credit_card('5105105105106') == False
    assert is_credit_card('abcdefghijklmnop') == False



# Generated at 2022-06-21 21:32:29.407827
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13(9780312498580) == True

# Generated at 2022-06-21 21:32:30.605777
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('dermatoglyphics')
    assert not is_isogram('hello')

# Generated at 2022-06-21 21:32:35.225173
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog') == True
    assert is_pangram('hello world') == False
    return True

test_is_pangram()

# TODO: add is_prime
# TODO: add is_strong_password
# TODO: add is_strong_password

# Generated at 2022-06-21 21:32:45.282378
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') == True
    assert is_isbn_10('150-6715214') == True
    assert is_isbn_10('150-6715214', normalize=False) == False
    assert is_isbn_10('', normalize=False) == False
    assert is_isbn_10('1-5-06715-214') == True
    assert is_isbn_10('1-5-0-6-7-1-5-2-1-4') == True
    print('test for is_isbn_10 are passed!')

test_is_isbn_10()


# Generated at 2022-06-21 21:32:49.365713
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('dermatoglyphics')
    assert not is_isogram('moose')
    assert not is_isogram('isogram')
            
test_is_isogram()
import unittest



# Generated at 2022-06-21 21:32:53.978352
# Unit test for function contains_html
def test_contains_html():
  assert contains_html('Lorem <b>ipsum</b> dolor...') == True, 'Failed if string contains html'
  assert contains_html('Lorem ipsum dolor...') == False, 'Failed if string does not contain html'
test_contains_html()


# Generated at 2022-06-21 21:33:03.699894
# Unit test for function is_email
def test_is_email():
    assert is_email("john.doe@google.com") == True
    assert is_email("john.doe@google.co.uk") == True
    assert is_email("john.doe@google.org") == True
    assert is_email("john.doe@google.net") == True
    assert is_email("john.doe@google.edu") == True
    assert is_email("john.doe@google.info") == True
    assert is_email("john.doe@google.biz") == True
    assert is_email("john.doe@google.gov") == True
    assert is_email("john.doe@google.io") == True
    assert is_email("john.doe@google.ac") == True
    assert is_email("john.doe@google.co") == True

# Generated at 2022-06-21 21:33:07.029050
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    checker = __ISBNChecker('978-84-376-0494-7')

    assert checker.is_isbn_13() is True



# Generated at 2022-06-21 21:33:24.846367
# Unit test for function is_palindrome
def test_is_palindrome():
   assert is_palindrome("otta")==True
   assert is_palindrome("Loll")==False
   assert is_palindrome("Loll",ignore_case=True)==True
   assert is_palindrome("otto")==True
   assert is_palindrome("i topi non avevano nipoti",ignore_spaces=True)==True
   assert is_palindrome("i topi non avevano nipot",ignore_spaces=True)==False
   assert is_palindrome("i to pi non avevano ni poti",ignore_spaces=True)==False