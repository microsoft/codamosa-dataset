

# Generated at 2022-06-21 21:23:40.373416
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('LOL') # returns true
    assert is_palindrome('Lol') # returns false
    assert is_palindrome('Lol', ignore_case=True) # returns true
    assert is_palindrome('ROTFL') # returns false
    assert is_palindrome('otto') # returns true
    assert is_palindrome('i topi non avevano nipoti') # returns false

# Generated at 2022-06-21 21:23:45.758578
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') is True
    assert is_json('[1, 2, 3]') is True
    assert is_json('{nope}') is False
    assert is_json('') is False
    assert is_json(5) is False


# Generated at 2022-06-21 21:23:52.768152
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('dermatoglyphics') is True
    assert is_isogram('isogram') is True
    assert is_isogram('aba') is False, "same chars may not be adjacent"
    assert is_isogram('moOse') is False, "same chars may not be same case"
    assert is_isogram('isIsogram') is False, "same chars may not be same case"
    assert is_isogram('hello') is False, "same chars may not be same case"

test_is_isogram()

# Creates a dictionary with the first letter of each word as the key and the rest of the word as value
# then returns a string of the words that start with the same letter

# Generated at 2022-06-21 21:23:56.250354
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75') == True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip('1.2.3') == False

if __name__ == '__main__':
    test_is_ip()
    print('Test is passed!')


# Generated at 2022-06-21 21:23:59.673508
# Unit test for function is_integer
def test_is_integer():
    """
    Check if the function work as expected
    """
    assert is_integer('45') == True
    assert is_integer('high') == False
# End of unit test for function is_integer



# Generated at 2022-06-21 21:24:03.038320
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') is True
    assert is_ip_v4('nope') is False
    assert is_ip_v4('255.200.100.999') is False


# Generated at 2022-06-21 21:24:06.356408
# Unit test for function is_decimal
def test_is_decimal():
    assert(is_decimal('42.0'))
    assert(is_decimal('42.1')) 
    assert(is_decimal('42.1000'))
    assert(not is_decimal('42'))



# Generated at 2022-06-21 21:24:12.844832
# Unit test for function is_decimal
def test_is_decimal():
    assert not is_decimal('')
    assert is_decimal('5.5')
    assert not is_decimal('4.0')
    assert not is_decimal('3.3E3')
    assert is_decimal('+18.7')
    assert is_decimal('-1.5')
    assert is_decimal('5.5')
    assert not is_decimal('4.0')
    assert not is_decimal('3.3E3')

test_is_decimal()



# Generated at 2022-06-21 21:24:24.685601
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('mystring') == True
    assert is_snake_case('my_string') == True
    assert is_snake_case('my__string') == True
    assert is_snake_case('_my_string') == True
    assert is_snake_case('my_string_') == True
    assert is_snake_case('my_string_with_number3') == True
    assert is_snake_case('123') == False
    assert is_snake_case('mystring1') == True
    assert is_snake_case('mystring1_') == True
    assert is_snake_case('_mystring1') == True
    assert is_snake_case('mystring3') == True
    assert is_snake_case('mystring_with_number3')

# Generated at 2022-06-21 21:24:35.633334
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com')
    assert is_url('http://www.mysite.com:8000')
    assert is_url('http://www.mysite.com/path/to/file.php')
    assert is_url('https://www.mysite.com')
    assert is_url('ftp://www.mysite.com')
    assert is_url('ftp://www.mysite.com:8000')
    assert is_url('https://www.mysite.com/path/to/file.php')
    assert is_url('https://www.mysite.com/path/to/file.php?foo=bar&test=test2')
    assert is_url('http://www.mysite.com/path/to/file.php#foo')

# Generated at 2022-06-21 21:24:52.764383
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn("9780312498580")
# Test if ISBN is valid
from warnings import catch_warnings, warn

from book_providers import get_book_information_by_isbn

with catch_warnings(record=True) as w:
    book_info = get_book_information_by_isbn("dummy")

    assert(len(w) == 1)
    assert(w[-1].category == UserWarning)
    assert("dummy: No book information found" in str(w[-1].message))
    assert(book_info is None)

test_isbn = "9780312498580"
book_info = get_book_information_by_isbn(test_isbn)

assert(book_info is not None)

# Generated at 2022-06-21 21:24:58.230190
# Unit test for function words_count
def test_words_count():
    assert words_count('') == 0
    assert words_count('hello world') == 2
    assert words_count('hello world of') == 3
    assert words_count('one,two,three.stop') == 4
    assert words_count('! @ # % ... []') == 0
    assert words_count('1,2,3') == 3

# Generated at 2022-06-21 21:25:00.953362
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('my string is <strong>bold</strong>') == True
    assert contains_html('my string is not bold') == False


# Generated at 2022-06-21 21:25:08.050687
# Unit test for function is_email

# Generated at 2022-06-21 21:25:17.831496
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal("1e") == False
    assert is_decimal("1.1e") == False
    assert is_decimal("1.1") == True
    assert is_decimal("1.1e2")== True
    assert is_decimal("e") == False
    assert is_decimal("1.") == True
    assert is_decimal("1") == False
    assert is_decimal("1e2") == True
    assert is_decimal(".") == False
    assert is_decimal("1e-2") == True
    assert is_decimal("1e+2") == True



# Generated at 2022-06-21 21:25:22.258745
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog.')
    assert is_pangram('The_quick_brown_fox_jumps_over_the_lazy_dog.')
    assert not is_pangram('The quick brown fox jumps over the lazy dog')
    assert not is_pangram('hello world')


# Generated at 2022-06-21 21:25:27.643523
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?') == False
    assert is_ip_v6('192.168.0.1') == False



# Generated at 2022-06-21 21:25:30.179667
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('foo_bar_baz') is True
    assert is_snake_case('foo') is False



# Generated at 2022-06-21 21:25:42.829605
# Unit test for function is_isogram
def test_is_isogram():
    data_true=[
        'abc','abcdefghijklmnopqrstuvwxyz','qwertyuiopasdfghjklzxcvbnm','qwertyuiopasdfghjklzxcvbnm0987654321',
        'acdfghijklmnpqrstuvwxyz','Dermatoglyphics','moose','isograms','34567890',
        'abcDEFghijklmnopqrstuVWXYZ','abcdefghijklmnopqrstuvwxyz0987654321']
    data_false=[
        'abcabc','abcABCD','abc ABCD','abcdefghijklmnopqrstuvwxyzA','hello','this is not',
        'this is not an isogram','is not an isogram','']

# Generated at 2022-06-21 21:25:45.146255
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('MyString') == True
    assert is_camel_case('mystring') == False



# Generated at 2022-06-21 21:26:02.542240
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('dermatoglyphics') == True, 'Dermatoglyphics'
    assert is_isogram('hello') == False, 'Hello'
    assert is_isogram('moOse') == False, 'Moose'
    assert is_isogram('isogram') == True, 'Isogram'
    assert is_isogram('aba') == False, 'Aba'
    assert is_isogram('moOse') == False, 'Moose'
    assert is_isogram('thumbscrewjapingly') == True, 'Thumbscrew-japingly'
    assert is_isogram('six-year-old') == True, 'Six-year-old'
    assert is_isogram('Emily Jung Schwartzkopf') == True, 'Emily Jung Schwartzkopf'

# Generated at 2022-06-21 21:26:04.581838
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506-715214')
    assert is_isbn_10('1506715214')


# Generated at 2022-06-21 21:26:10.887766
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?') == False
test_is_ip_v6()



# Generated at 2022-06-21 21:26:15.626814
# Unit test for function is_string
def test_is_string():
    try:
        assert is_string('foo')
        assert is_string('bar')
        assert is_string('')
        assert is_string(1) == False
        assert is_string(b'foo') == False
    except:
        print('Unit test failed for is_string')



# Generated at 2022-06-21 21:26:19.791193
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')  # returns true
    assert is_ip_v4('nope')  # returns false (not an ip)
    assert is_ip_v4('255.200.100.999')  # returns false (999 is out of range)


# Generated at 2022-06-21 21:26:23.188876
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid(uuid.uuid4())
    assert not is_uuid('foo')
    assert not is_uuid('6f8aa2f9686c4ac387665712354a04cf')
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True)



# Generated at 2022-06-21 21:26:27.340502
# Unit test for function is_string
def test_is_string():
    assert is_string('1') == True
    assert is_string(1) == False
    assert is_string('abc') == True
    assert is_string('') == True


# Generated at 2022-06-21 21:26:32.006184
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6("2001:db8:85a3:0000:0000:8a2e:370:7334") is True
    assert is_ip_v6("2001:db8:85a3:0000:0000:8a2e:370:?") is False

# Generated at 2022-06-21 21:26:34.658924
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}')
    assert is_json('[1, 2, 3]')
    assert not is_json('{nope}')


# Generated at 2022-06-21 21:26:36.837988
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580') == True
    assert is_isbn_13('978-0312498580') == True
    assert is_isbn_13('978-0312498580', normalize=False) == False


# Generated at 2022-06-21 21:26:56.444915
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('dermatoglyphics') == True
    assert is_isogram('hello') == False
    assert is_isogram('isogram') == True
    assert is_isogram('aba') == False
    assert is_isogram('moOse') == False
    assert is_isogram('isIsogram') == False
    assert is_isogram('') == True
    assert is_isogram('thumbscrew-japingly') == True
    assert is_isogram('thumbscrew-jappingly') == False
    assert is_isogram('six-year-old') == True
    assert is_isogram('Emily Jung Schwartzkopf') == True
    assert is_isogram('accentor') == False
    assert is_isogram('angola') == False


# Generated at 2022-06-21 21:27:05.049229
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    assert __ISBNChecker('9781408855652').input_string == '9781408855652'
    assert __ISBNChecker('978-0-13-4-789-9').input_string == '97801347899'

    try:
        __ISBNChecker(None)
        assert False
    except InvalidInputError:
        assert True

    assert __ISBNChecker('978-0-13-4-789-9', False).input_string == '978-0-13-4-789-9'

test___ISBNChecker()


# PUBLIC API



# Generated at 2022-06-21 21:27:13.426371
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert not __ISBNChecker('978-0-306-40615-7').is_isbn_10()
    assert __ISBNChecker('0553380168').is_isbn_10()
    assert __ISBNChecker('0-8041-7191-0').is_isbn_10()
    assert __ISBNChecker('0-471-97819-X').is_isbn_10()
    assert __ISBNChecker('978-0-306-40615-7').is_isbn_10()
    assert not __ISBNChecker('nonsense').is_isbn_10()
    assert not __ISBNChecker('0875420616').is_isbn_10()
    assert not __ISBNChecker('null').is_isbn_10()

# Generated at 2022-06-21 21:27:24.693966
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-slug') == True
    assert is_slug('my slug') == False
    assert is_slug('my_slug') == False
    assert is_slug('my\\slug') == False
    assert is_slug('my/slug') == False
    assert is_slug('my\\\\slug') == False
    assert is_slug('my//slug') == False
    assert is_slug('myslug') == True
    assert is_slug('my_slug', separator='_') == True
    assert is_slug('my-slug', separator='-') == True
    assert is_slug('my/slug', separator='/') == True
    assert is_slug('my\\slug', separator='\\') == True

# Generated at 2022-06-21 21:27:31.880614
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('MyString') == True
    assert is_camel_case('isThisCamelCase') == True
    assert is_camel_case('thisIsCamelCase3') == True
    assert is_camel_case('anotherCamelCase4') == True
    assert is_camel_case('camel') == False
    assert is_camel_case('1camelCase') == False
    assert is_camel_case('_camel_case') == False
    assert is_camel_case('-camel-case') == False
    assert is_camel_case('camel_case') == False
    assert is_camel_case('camel-case') == False
    assert is_camel_case('camel case') == False

# Generated at 2022-06-21 21:27:36.080856
# Unit test for function words_count
def test_words_count():
    assert words_count('Hello World') == 2
    assert words_count('') == 0
    assert words_count('\r\n\r') == 0
    assert words_count('\r\n') == 0
    assert words_count('\r\n one,two,three.stop') == 4

# Generated at 2022-06-21 21:27:43.786401
# Unit test for function is_email
def test_is_email():

    assert(is_email('abc@abc.abc') == True)
    assert(is_email('abc.abc@abc.abc') == True)
    assert(is_email('abc_abc@abc.abc') == True)
    assert(is_email('abc-abc@abc.abc') == True)
    assert(is_email('abc.abc+abc@abc.abc') == True)
    assert(is_email('abc.abc@abc.abc+abc') == True)
    assert(is_email('abc_abc@abc-abc.abc') == True)
    assert(is_email('abc@abc.a') == True)
    assert(is_email('abc@abc.ab') == True)
    assert(is_email('abc@gmail.com') == True)

# Generated at 2022-06-21 21:27:54.073248
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4111111111111111')
    assert is_credit_card('4111-1111-1111-1111')
    assert is_credit_card('4111 1111 1111 1111')
    assert is_credit_card('4111111111111')  # visa 13 digits
    assert is_credit_card('378282246310005')  # American Express
    assert is_credit_card('371449635398431')
    assert is_credit_card('6011111111111117')
    assert is_credit_card('5555555555554444')
    assert is_credit_card('5105105105105100')
    assert is_credit_card('1234567890123')  # 13 characters
    assert is_credit_card('123456789012345')  # 14 characters
   

# Generated at 2022-06-21 21:28:02.344988
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') # returns true
    assert is_email('@gmail.com') # returns false
    assert is_email('joe@mail.com') # returns true
    assert is_email('abc@abc.abc') # returns true
    assert is_email('joe@mail.com') # returns true
    assert is_email('"Joe Smith"@mail.com') # returns true
    assert is_email('"Joe\ Smith"@mail.com') # returns true
    assert is_email('my.email@the-provider.com') # returns true
    assert is_email('joe.@mail.com') # returns false
    assert is_email('joe@mail.com_') # returns false
    assert is_email('joe@mail..com') # returns false


# Generated at 2022-06-21 21:28:13.671325
# Unit test for function is_email
def test_is_email():
    # test invalid email
    assert is_email('@gmail.com') == False, 'email with no local part'
    assert is_email('.my.email@gmail.com') == False, 'email starts with dot'
    assert is_email('my.email@gmail.com..') == False, 'email ends with two dots'
    assert is_email('my.email@gmail..com') == False, 'email contains two dots in the domain part'
    assert is_email('') == False, 'email is empty'
    assert is_email(' ') == False, 'email is blank'
    assert is_email('my.email@') == False, 'email contains only one part'
    assert is_email('my.email@[127.0.0.1]') == False, 'email with IP address but not bracketed'

# Generated at 2022-06-21 21:28:26.316960
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580') == True
    assert is_isbn_13('1335400826') == False
    assert is_isbn_13('978-0312498580') == True
    assert is_isbn_13('978-0312498580', normalize=False) == False
    assert is_isbn_13('978 0 312 498580') == True
    assert is_isbn_13('978 0 312 498580', normalize=False) == False



# Generated at 2022-06-21 21:28:28.157055
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0747532699').is_isbn_10()


# PUBLIC API

# region [Validators]



# Generated at 2022-06-21 21:28:32.683380
# Unit test for function is_string
def test_is_string():
    assert is_string(123)  == False
    assert is_string(True)  == False
    assert is_string(False) == False
    assert is_string(None)  == False
    assert is_string('123') == True
    assert is_string(b'123') == False
    assert is_string(str)   == False


# Generated at 2022-06-21 21:28:39.493881
# Unit test for function is_isbn_10
def test_is_isbn_10():
    test_data = [
        ('1506715214', True),
        ('-1506715214', True),
        ('150-6715214', True),
        ('1 50-6 715-214', True),
        ('1506715214123', False),
        ('150-6715214-123', False),
        ('this is not_even_close_to_isbn_10', False),
    ]
    for data in test_data:
        assert is_isbn_10(data[0]) == data[1]



# Generated at 2022-06-21 21:28:44.007968
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('my string is <strong>bold</strong>')
    assert not contains_html('my string is not bold')
    assert not contains_html('my string is bold')



# Generated at 2022-06-21 21:28:51.200109
# Unit test for function is_number
def test_is_number():
    assert is_number('-9.12')
    assert is_number('19.99')
    assert is_number('86.02')
    assert is_number('1e3')
    assert is_number('-1.1e3')
    assert is_number('5.3e-3')
    assert is_number('5.3e+3')
    assert is_number('1e-3')
    assert not is_number('aa')
    assert not is_number('1.')
    assert not is_number('.1')
    assert not is_number('1.1.2')
    assert not is_number('1A')



# Generated at 2022-06-21 21:28:55.107061
# Unit test for function is_uuid
def test_is_uuid():
    test_uuid = '6f8aa2f9686c4ac387665712354a04cf'
    assert is_uuid(test_uuid, allow_hex=True)



# Generated at 2022-06-21 21:28:59.883699
# Unit test for function words_count
def test_words_count():
    assert words_count('Lorem ipsum dolor sit amet consectetur adipiscing elit') == 9
    assert words_count('one,two,three.stop') == 4
    assert words_count('! @ # % ... []') == 0
    
test_words_count()


# Generated at 2022-06-21 21:29:02.164775
# Unit test for function is_string
def test_is_string():
    # Test for a string
    assert is_string("hello")
    # Test for non-string
    assert is_string("7") == False


# Generated at 2022-06-21 21:29:05.451844
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('Pack my box with five dozen liquor jugs') == True
    assert is_pangram('The quick brown fox jumps over the lazy dog') == True
    assert is_pangram('hello world') == False
test_is_pangram()


# Generated at 2022-06-21 21:29:29.350383
# Unit test for function is_url
def test_is_url():
    assert (is_url('https://www.mysite.com') == True)
    assert (is_url('http://www.mysite.com') == True)
    assert (is_url('.mysite.com') == False)


# Generated at 2022-06-21 21:29:31.628883
# Unit test for function is_number
def test_is_number():
    if(is_number("42")):
        assert True
    else:
        assert False
test_is_number()



# Generated at 2022-06-21 21:29:36.706706
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') == True
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf') == False
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True) == True

# Generated at 2022-06-21 21:29:40.134244
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580')
    assert is_isbn('1506715214')
    assert not is_isbn('150-6715214', normalize=False)
    assert not is_isbn('978-0312498580', normalize=False)
    assert not is_isbn('9780312498580303')
    assert not is_isbn('978-0312498580303')



# Generated at 2022-06-21 21:29:45.573108
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75') == True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip('1.2.3') == False

test_is_ip()


# Generated at 2022-06-21 21:29:47.289068
# Unit test for function words_count
def test_words_count():
    assert words_count('hello world') == 2 # noqa
    assert words_count('olé world') == 2 # noqa
    assert words_count('one,two,three.stop') == 4 # noqa
    assert words_count('! @ # % ... []') == 0 # noqa



# Generated at 2022-06-21 21:29:53.688704
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('this-is-a-slug') == True
    assert is_slug('this is a slug') == False
    assert is_slug('this--is-a-slug---') == True
    assert is_slug('this-is-a-slug-') == False

# Generated at 2022-06-21 21:29:57.996589
# Unit test for function is_json
def test_is_json():

    assert(is_json('{"name": "Peter"}'))
    assert(is_json('[1, 2, 3]'))
    assert(not is_json('{nope}'))


# STATIC VARIABLE
# Create a static instance of the class __ISBNChecker
__ISBN_CHECKER = __ISBNChecker('')



# Generated at 2022-06-21 21:30:00.320249
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    obj = __ISBNChecker('978-0-306-40615-7')
    assert obj.is_isbn_13() == False

# Generated at 2022-06-21 21:30:02.385042
# Unit test for function is_string
def test_is_string():
    assert is_string("a") == True
    assert is_string(1) == False
    assert is_string({'a':1}) == False


# Generated at 2022-06-21 21:30:16.429435
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') == True
    assert is_url('.mysite.com') == False


# Generated at 2022-06-21 21:30:20.222799
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('MyString') == True
    assert is_camel_case('mystring') == False
    assert is_camel_case('MyString1') == True
    assert is_camel_case('Mystring2') == False


# Generated at 2022-06-21 21:30:21.730094
# Unit test for function is_email
def test_is_email():
    assert is_email('My.email@gmail.com') is True

# Generated at 2022-06-21 21:30:23.793453
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('42.0') == True
    assert is_decimal('42') == False


# Generated at 2022-06-21 21:30:36.605349
# Unit test for function is_ip
def test_is_ip():
    # ip_v4_list = ['255.200.100.75', 'nope', '255.200.100.999', 1.2.3]
    # ip_v6_list = ['2001:db8:85a3:0000:0000:8a2e:370:7334','2001:db8:85a3:0000:0000:8a2e:370:?']
    ip_v4_list = ['255.200.100.75', 'nope', '255.200.100.999']
    ip_v6_list = ['2001:db8:85a3:0000:0000:8a2e:370:7334','2001:db8:85a3:0000:0000:8a2e:370:?']
    assert is_ip(ip_v4_list[0])

# Generated at 2022-06-21 21:30:37.961367
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('1506715214')


# Generated at 2022-06-21 21:30:42.625875
# Unit test for function is_palindrome
def test_is_palindrome():
    # Test with a capital letter
    input_string1 = 'Anna'
    expected_result1 = True
    actual_result1 = is_palindrome(input_string1, ignore_case=True)
    assert actual_result1 == expected_result1

    # Test with a palindrome containing a space
    input_string2 = 'i topi non avevano nipoti'
    expected_result2 = True
    actual_result2 = is_palindrome(input_string2, ignore_spaces=True)
    assert actual_result2 == expected_result2

    # Test with an empty string
    input_string3 = ''
    expected_result3 = False
    actual_result3 = is_palindrome(input_string3)
    assert actual_result3 == expected_result3
    
    # Test with

# Generated at 2022-06-21 21:30:54.343523
# Unit test for function is_isbn
def test_is_isbn():
    # ISO13 isbn validation
    assert is_isbn('9780312498580') == True
    assert is_isbn('978-0312498580') == True
    assert is_isbn('978-0312498580-0') == False
    assert is_isbn('978-0312498580', normalize=False) == False
    # ISO10 isbn validation
    assert is_isbn('1506715214') == True
    assert is_isbn('150-6715214') == True
    assert is_isbn('150-6715214-0') == False
    assert is_isbn('150-6715214', normalize=False) == False
    # isbn validation fails
    assert is_isbn('978-0312498580-0') == False

# Generated at 2022-06-21 21:30:56.597816
# Unit test for function is_email
def test_is_email():
    rv = is_email('fengjiuyu.foo@baidu.com')
    assert rv == True


# Generated at 2022-06-21 21:30:58.509911
# Unit test for function is_string
def test_is_string():
    assert is_string('foo') == True
    assert is_string(b'foo') == False
test_is_string()



# Generated at 2022-06-21 21:31:14.257552
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?') == False


# Generated at 2022-06-21 21:31:25.051206
# Unit test for function is_credit_card
def test_is_credit_card():
    print('Testing function is_credit_card')

# Generated at 2022-06-21 21:31:27.515524
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('42') == False
    assert is_decimal('42.0') == True
    assert is_decimal('4.2') == True
    assert is_decimal('4.2e12') == True


# Generated at 2022-06-21 21:31:36.134080
# Unit test for function is_isbn_10
def test_is_isbn_10():
    """ Test is_isbn_10 function"""
    # Test valid ISBN 10
    assert is_isbn_10('1506715214') == True
    assert is_isbn_10('150-6715214') == True
    assert is_isbn_10('150-671521-4') == True
    assert is_isbn_10('150671521-4') == True
    assert is_isbn_10('1-506715214') == True
    assert is_isbn_10('1-50-671521-4') == True
    assert is_isbn_10('1-50671521-4') == True
    # Test not valid ISBN 10
    assert is_isbn_10('150671521', normalize=False) == False
    assert is_isbn_10('1506715215')

# Generated at 2022-06-21 21:31:42.007106
# Unit test for function is_ip
def test_is_ip():
    assert(is_ip('255.200.100.75') == True)
    assert(is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True)
    assert(is_ip('1.2.3') == False)


# Generated at 2022-06-21 21:31:46.931110
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580') == True
    assert is_isbn_13('978-0312498580') == True
    assert is_isbn_13('978-0312498580', normalize=False) == False
    assert is_isbn_13('8180312498580') == False

# Generated at 2022-06-21 21:31:54.147522
# Unit test for function is_uuid

# Generated at 2022-06-21 21:32:05.390170
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('9789321599600').is_isbn_13()
    assert __ISBNChecker('978-9321599600').is_isbn_13()
    assert __ISBNChecker('978-9321599600').is_isbn_13()
    assert not __ISBNChecker('978-932159960').is_isbn_13()
    assert not __ISBNChecker('978-932159960.').is_isbn_13()
    assert not __ISBNChecker('978-932159960a').is_isbn_13()
    assert not __ISBNChecker('978-9321').is_isbn_13()
    assert not __ISBNChecker('978-9321599600-A').is_isbn_13()

# Generated at 2022-06-21 21:32:09.919050
# Unit test for function is_full_string
def test_is_full_string():
    args_list = [
        ('hello', True),
        (' ', False),
        ('', False),
        (None, False)
    ]
    for args, expected_result in args_list:
        assert is_full_string(input_string=args) == expected_result



# Generated at 2022-06-21 21:32:12.021183
# Unit test for function is_email
def test_is_email():
    print(is_email('my.email@the-provider.com'))
    print(is_email('@gmail.com'))



# Generated at 2022-06-21 21:32:44.847750
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('rotor')
    assert is_palindrome('otto')
    assert not is_palindrome('rotor1')
    assert is_palindrome('o t t o ')
    assert not is_palindrome('o t t o ')
    assert is_palindrome('o t t o ', ignore_spaces=True)
    assert is_palindrome('Rotor')
    assert is_palindrome('Rotor', ignore_case=True)
    assert not is_palindrome('Rotor')
    assert is_palindrome('Lol', ignore_case=True)
    assert not is_palindrome('Lol')



# Generated at 2022-06-21 21:32:53.324379
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert not is_ip_v4(None)
    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999')
    assert not is_ip_v4('255.200.100')
    assert not is_ip_v4('255.200.100.75.10')

    assert is_ip_v4('255.200.100.75')
    assert is_ip_v4('0.0.0.0')
    assert is_ip_v4('255.255.255.255')



# Generated at 2022-06-21 21:33:04.812671
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    '''Unit test for is_isbn_13 method of class __ISBNChecker'''
    # Test case: isbn-13 '978-3-662-54328-5'
    isbn_13 = '978-3-662-54328-5'
    checker = __ISBNChecker(isbn_13)
    assert checker.is_isbn_13() == True, 'Checker should return True for isbn-13'
    # Test case: isbn-13 '978-3-662-54328-0'
    isbn_13 = '978-3-662-54328-0'
    checker = __ISBNChecker(isbn_13)
    assert checker.is_isbn_13() == False, 'Checker should return False for isbn-13'
    print

# Generated at 2022-06-21 21:33:09.812194
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') == True
    assert is_isbn('1506715214') == True
    assert is_isbn('9780312498580') == True
    assert is_isbn('978-0312498580') == True



# Generated at 2022-06-21 21:33:12.133571
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42') == True
    assert is_integer('42.0') == False


# Generated at 2022-06-21 21:33:13.630435
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') == True

# Generated at 2022-06-21 21:33:20.287700
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('otto') == True
    assert is_palindrome('i topi non avevano nipoti') == False
    assert is_palindrome('i topi non avevano nipoti', ignore_spaces=True) == True
    assert is_palindrome('OtTO') == False
    assert is_palindrome('OtTO', ignore_case=True) == True

