

# Generated at 2022-06-21 21:23:53.698099
# Unit test for function is_email
def test_is_email():
    assert is_email('me@example.com') == True
    assert is_email('a.nonymous@example.com') == True
    assert is_email('name+tag@example.com') == True
    assert is_email('very.common@example.com') == True
    assert is_email('disposable.style.email.with+symbol@example.com') == True
    assert is_email('other.email-with-dash@example.com') == True
    assert is_email('user@[IPv6:2001:DB8::1]') == True
    assert is_email('"much.more unusual"@example.com') == True
    assert is_email('"very.unusual.@.unusual.com"@example.com') == True

# Generated at 2022-06-21 21:23:59.209581
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('my"email@the.provider.com')
    assert is_email('my"email"@the.provider.com')
    assert is_email('my.email\\@the.provider.com')
    assert not is_email('my.email.@the.provider.com')
    assert not is_email('my.email\\.@the.provider.com')
    assert not is_email('@gmail.com')
    assert not is_email('my.email@gmail.com123')
    assert not is_email('my.ema il@gmail.com')
    assert not is_email('my.email@gmail.c!om')
    assert not is_email('.my-email@gmail.com')



# Generated at 2022-06-21 21:24:02.989128
# Unit test for function is_email
def test_is_email():
    assert is_email("my.email@the-provider.com") == True
    assert is_email("@gmail.com") == False
    assert is_email("") == False
    assert is_email("emmanuel.franci@univ-tours.fr") == True



# Generated at 2022-06-21 21:24:11.014482
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') is True
    assert is_isbn('978-0312498580') is True
    assert is_isbn('978-0312498580', normalize=False) is False
    assert is_isbn('1506715214') is True
    assert is_isbn('150-6715214') is True
    assert is_isbn('150-6715214', normalize=False) is False
    assert is_isbn('150-6715214', normalize=False) is False
    assert is_isbn('150-6715214', normalize=False) is False



# Generated at 2022-06-21 21:24:15.111305
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('1.1') == True
    assert is_decimal('-93.123') == True
    assert is_decimal('0.0') == True
    assert is_decimal('4e4') == False
    assert is_decimal('-42') == False

# Generated at 2022-06-21 21:24:19.032907
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214')
    assert is_isbn_10('150-6715214')
    assert not is_isbn_10('150-6715214', normalize=False)



# Generated at 2022-06-21 21:24:30.550345
# Unit test for function is_email
def test_is_email():
    assert is_email('user@gmail.com') == True
    assert is_email('user@.com') == False
    assert is_email('user@gmail..com') == False
    assert is_email('user@gmail.com.') == False
    assert is_email('user..@gmail.com') == False

    assert is_email('user@gmail.com') == True
    assert is_email('_user@gmail.com') == True
    assert is_email('user@gmail.co.uk') == True
    assert is_email('user@gmail..com') == False
    assert is_email('user@gmail.com.') == False
    assert is_email('user..@gmail.com') == False
    assert is_email('user.@gmail.com') == False

# Generated at 2022-06-21 21:24:32.706538
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog')



# Generated at 2022-06-21 21:24:35.151527
# Unit test for function is_integer
def test_is_integer():
    assert is_integer("42") == True
    assert is_integer("42.0") == False
    assert is_integer("42.5") == False


# Generated at 2022-06-21 21:24:37.017633
# Unit test for function is_ip
def test_is_ip():
    assert(is_ip('255.200.100.75') == True)
    assert(is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True)
    assert(is_ip('1.2.3') == False)

# Generated at 2022-06-21 21:24:46.458925
# Unit test for function is_pangram
def test_is_pangram():
    assert(is_pangram("The quick brown fox jumps over the lazy dog") == True)
    assert(is_pangram("hello world") == False)

# Generated at 2022-06-21 21:24:49.804048
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('5') == True
    assert is_integer('+5') == True
    assert is_integer('-5') == True
    assert is_integer('e5') == False
    assert is_integer('+5.5') == False
    assert is_integer('-5.5') == False



# Generated at 2022-06-21 21:24:54.184960
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') is True
    assert is_isbn('978-0312498580') is True
    assert is_isbn('978-0312498580', normalize=False) is False


# Generated at 2022-06-21 21:25:04.520641
# Unit test for function is_ip_v6
def test_is_ip_v6():
    # the following ip and MAC addresses have been found on the Internet
    assert is_ip_v6('2001:db8:85a3:0:0:8a2e:370:7334')
    assert is_ip_v6('2001:db8:85a3::8a2e:370:7334')
    assert is_ip_v6('2001:db8:85a3::8a2e:370:7334:%eth0')
    assert is_ip_v6('fe80::215:5dff:fe99:c72e')
    assert is_ip_v6('fe80::21a:6bff:fe10:a7a3')
    assert is_ip_v6('fe80::21a:6bff:fe10:a7a3%eth0')

    # invalid checks

# Generated at 2022-06-21 21:25:08.021168
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42') == True
    assert is_integer('42.0') == False
    assert is_integer('3.1415926') == False

# test for function is_integer
test_is_integer()



# Generated at 2022-06-21 21:25:12.372986
# Unit test for function is_uuid

# Generated at 2022-06-21 21:25:14.020076
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334')
    assert not is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?')


# Generated at 2022-06-21 21:25:19.618901
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    try:
        __ISBNChecker(1)
        assert False
    except InvalidInputError:
        assert True

    try:
        __ISBNChecker('')
        assert False
    except InvalidInputError:
        assert True

    assert __ISBNChecker('000')

test___ISBNChecker()


# PUBLIC API


# Generated at 2022-06-21 21:25:22.156086
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75')
    assert is_ip('255.200.100.75')
    assert not is_ip('1.2.3')

# Generated at 2022-06-21 21:25:27.542449
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('otto')
    assert is_palindrome('i topi non avevano nipoti')
    assert not is_palindrome('i topi non avevano nipoti', ignore_spaces=False)
    assert not is_palindrome('ROTFL')
    assert is_palindrome('Lol', ignore_case=True)

# Generated at 2022-06-21 21:25:42.830008
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4111111111111111') is True
    assert is_credit_card('4111111111111') is False
    assert is_credit_card('4012888888881881') is True
    assert is_credit_card('378282246310005') is True
    assert is_credit_card('6011111111111117') is True
    assert is_credit_card('5105105105105100') is True
    assert is_credit_card('5105105105105106') is False
    assert is_credit_card('9111111111111111') is False


# Generated at 2022-06-21 21:25:45.146723
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('my string is <strong>bold</strong>')
    assert not contains_html('my string is not bold')
    

# Generated at 2022-06-21 21:25:47.852831
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('978-0312498580') == True
    assert is_isbn_13('9780312498580') == True


# Generated at 2022-06-21 21:25:58.473901
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?') == False
    assert is_ip_v6('2001:db8:85a3::8a2e:370:?') == True
    assert is_ip_v6('::192.168.0.1') == True
    assert is_ip_v6('2001:db8::5') == True
    assert is_ip_v6('2001:db8::5:6') == True
    assert is_ip_v6('2002::') == True
    assert is_ip_v6('2001::') == True

# Generated at 2022-06-21 21:26:05.667857
# Unit test for function is_ip
def test_is_ip():
    assert is_ip("127.0.0.1")
    assert is_ip("2001:db8:85a3:0000:0000:8a2e:370:7334")
    assert not is_ip("255.255.255")

is_ip("127.0.0.1")
is_ip("2001:db8:85a3:0000:0000:8a2e:370:7334")
is_ip("255.255.255")


# Generated at 2022-06-21 21:26:12.728049
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email+user@the-provider.com')
    assert not is_email('my.email@the-provider.com.')
    assert not is_email('my.email@the-provider..com.')
    assert not is_email('@gmail.com')



# Generated at 2022-06-21 21:26:16.073226
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid("6f8aa2f9-686c-4ac3-8766-5712354a04cf") == True
    assert is_uuid("6f8aa2f9686c4ac387665712354a04cf") == False
    assert is_uuid("6f8aa2f9686c4ac387665712354a04cf", allow_hex=True) == True

# Generated at 2022-06-21 21:26:23.808031
# Unit test for function is_ip_v4
def test_is_ip_v4():
        assert is_ip_v4('255.200.100.75') == True
        assert is_ip_v4('nope') == False
        assert is_ip_v4('255.200.100.999') == False
        assert is_ip_v4('172.30.0.1') == True
        assert is_ip_v4('127.0.0.1') == True
        assert is_ip_v4('::1') == False
        assert is_ip_v4('255.255.255.0') == True
        assert is_ip_v4('192.168.1.1') == True
        assert is_ip_v4('172.31.1.12') == True
        assert is_ip_v4('172.31.46.255') == True

# Generated at 2022-06-21 21:26:34.615820
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('foo_bar_baz') # returns true
    assert not is_snake_case('foo') # returns false
    assert is_snake_case('foo_bar-baz', '_-') # returns true
    assert is_snake_case('foo-bar_baz', '_-') # returns true
    assert is_snake_case('foo_barbaz', '_-') # returns true
    assert is_snake_case('foo-barbaz', '_-') # returns true
    assert not is_snake_case('foo', '_-') # returns false
    assert not is_snake_case('foo bar baz', '_-') # returns false



# Generated at 2022-06-21 21:26:38.487194
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case("myString") == True
    assert is_camel_case("mystring") == False
    assert is_camel_case("1MyString") == False
    assert is_camel_case("") == False
    assert is_camel_case(None) == False
test_is_camel_case()



# Generated at 2022-06-21 21:26:48.261299
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('my string is <strong>bold</strong>') == True
    assert contains_html('my string is not bold') == False

# Generated at 2022-06-21 21:26:51.454724
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1-56619-909-X')
    assert not is_isbn_10('566190909')
    assert is_isbn_10('566190909', False)

# Generated at 2022-06-21 21:27:03.858854
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('MyString') == False
    assert is_snake_case('mystring') == False
    assert is_snake_case('foo-bar-baz') == True
    assert is_snake_case('foo_bar_baz') == True
    assert is_snake_case('foo-bar_baz') == True
    assert is_snake_case('foo_bar-baz') == True
    assert is_snake_case('foo', '-') == True
    assert is_snake_case('foo', '_') == True
    assert is_snake_case('foo', '.') == False
    assert is_snake_case('') == False
    assert is_snake_case('-') == False
    assert is_snake_case('_') == False


# Generated at 2022-06-21 21:27:09.045918
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('foo-bar') == True
    assert is_slug('foo') == True
    assert is_slug('foo-') == True
    assert is_slug('-foo') == False
    assert is_slug('Foo bar') == False
    assert is_slug('foo bar') == False
    assert is_slug(42) == False
test_is_slug()



# Generated at 2022-06-21 21:27:14.558299
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title') # returns true
    assert not is_slug('My blog post title') # returns false

is_slug('My blog post title')

# testing function. Returns True if the function works as expected, returns False if it doesn't


# Generated at 2022-06-21 21:27:25.669915
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('abcd') == True
    assert is_isogram('aBcde') == True
    assert is_isogram('abcdea') == False
    assert is_isogram('abcdeaB') == False
    assert is_isogram('aBcdeaB') == False
    assert is_isogram('Indivisibility') == True
    assert is_isogram('Indivisibilities') == False
    assert is_isogram('Indivi si bilities') == False
    assert is_isogram('Indivi si bilit ies') == False
    assert is_isogram('Indivi si bilit ies  ') == False
    assert is_isogram('Indivi si bilit ies ab') == False
    assert is_isogram('Indivi si bilit ies abb')

# Generated at 2022-06-21 21:27:37.530786
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('')
    assert is_palindrome(' ')
    assert is_palindrome('  ')
    assert is_palindrome('o')
    assert is_palindrome('oo')
    assert is_palindrome('ooo')
    assert is_palindrome('oooo')
    assert is_palindrome('aba')
    assert is_palindrome('abba')
    assert is_palindrome('abbba')
    assert is_palindrome('abbcba')
    assert is_palindrome('abcecba')
    assert is_palindrome('abcefcba')
    assert is_palindrome('abcdefgfedcba')
    assert is_palindrome('abcdefggfedcba')

# Generated at 2022-06-21 21:27:43.398301
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('Dermatoglyphics') == True  #skin patterns
    assert is_isogram('isogram') == True
    assert is_isogram('aba') == False #same character
    assert is_isogram('moOse') == False #same character, but different cases
    assert is_isogram('thumbscrewjapingly') == True #word ib english language
    assert is_isogram('thumbscrew-japingly') == True #hypenated words should not be counted
    assert is_isogram('') == True
print(test_is_isogram())

# Generated at 2022-06-21 21:27:53.504278
# Unit test for function is_full_string
def test_is_full_string():
    # input_string is not a string
    assert is_full_string(1) == False
    assert is_full_string(False) == False
    assert is_full_string(None) == False
    # input_string is an empty string
    assert is_full_string("") == False
    assert is_full_string(" ") == False
    # input_string is a full string
    assert is_full_string("hello") == True
    assert is_full_string("hello world") == True
    assert is_full_string("hello_world") == True
    assert is_full_string("hello-world") == True
    assert is_full_string("hello123456") == True
    assert is_full_string("hello.world") == True


# Generated at 2022-06-21 21:28:00.920342
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    from . import is_isbn_10

    # '99921-58-10-7'
    assert is_isbn_10('99921-58-10-7') is True

    # '960-425-059-0'
    assert is_isbn_10('960-425-059-0') is True

    # '80-902734-1-6'
    assert is_isbn_10('80-902734-1-6') is True

    # '0-9752298-0-X'
    assert is_isbn_10('0-9752298-0-X') is True

    # '0 9752298 0 X'
    assert is_isbn_10('0 9752298 0 X') is True


# Generated at 2022-06-21 21:28:12.094238
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?') == False


# Generated at 2022-06-21 21:28:20.093980
# Unit test for function is_json
def test_is_json():
    assert is_json("{name: 'Daniel'}")
    assert is_json("{'name': 'Daniel'}")
    assert is_json("{'name': 'Daniel', 'last_name': 'Jorge'}")
    assert not is_json("{'name: 'Daniel'}")
    assert not is_json("{name: 'Daniel'}")
    assert not is_json("{name=Daniel}")
    assert not is_json("{'name'=Daniel}")
    assert not is_json("{name: Daniel}")
    assert not is_json("{name: 'Daniel}")
    assert not is_json("name: 'Daniel'}")
    assert not is_json("{'name: Daniel'}")
    assert not is_json("{name: 'Daniel")
    assert not is_json

# Generated at 2022-06-21 21:28:24.370031
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75') == True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip('1.2.3') == False
test_is_ip()


# Generated at 2022-06-21 21:28:29.762540
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6("2001:db8:85a3:0000:0000:8a2e:370:7334")
    assert not is_ip_v6("2002:db8:85a3:0202:0000:8a2e:370:7334")
    assert not is_ip_v6("2001:db8:85a3:0000:0000:8a2e:370:?")


# Generated at 2022-06-21 21:28:34.355965
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?') == False


# Generated at 2022-06-21 21:28:38.506627
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0306406152').is_isbn_10() is True
    assert __ISBNChecker('0123456789').is_isbn_10() is True
    assert __ISBNChecker('012345678X').is_isbn_10() is True


# PUBLIC API



# Generated at 2022-06-21 21:28:40.437363
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42.0') == False


# Generated at 2022-06-21 21:28:47.574555
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('my_snake_case_string')
    assert is_snake_case('my-snake-case-string')
    assert not is_snake_case('my_snake_case_String')
    assert not is_snake_case('MySnakeCaseString')
    assert not is_snake_case('My_Snake_Case_String')
    assert not is_snake_case('My-Snake-Case-String')



# Generated at 2022-06-21 21:28:54.776709
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    checker = __ISBNChecker("978-3-16-148410-0")
    assert checker.input_string == "9783161484100"

    checker = __ISBNChecker("978-3-16-148410-0", normalize=False)
    assert checker.input_string == "978-3-16-148410-0"


# Generated at 2022-06-21 21:29:05.209667
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('978-0312498580') == True
    assert is_isbn_13('978-0312498580', normalize=False) == False
    assert is_isbn_13('978-0312498580', normalize=True) == True
    assert is_isbn_13(input_string='978-0312498580', normalize=True) == True
    assert is_isbn_13('978-0312498580', normalize=False) == False
    assert is_isbn_13(input_string='978-0312498580', normalize=False) == False
    assert is_isbn_13('978-0312498580') == True
    assert is_isbn_13(input_string='978-0312498580') == True

# Generated at 2022-06-21 21:29:16.920808
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('MyString')
    assert is_camel_case('myString')
    assert is_camel_case('myS3tring')
    assert is_camel_case('myString')
    assert is_camel_case('MyString123')
    assert is_camel_case('MyString_')
    assert is_camel_case('_MyString')
    assert is_camel_case('MyString_1')
    assert is_camel_case('MyString_12')
    assert not is_camel_case('')
    assert not is_camel_case('my string')
    assert not is_camel_case('mystring')
    assert not is_camel_case('123myString')
    assert not is_camel_case('_123myString')



# Generated at 2022-06-21 21:29:20.892361
# Unit test for function words_count
def test_words_count():
    print(words_count('hello world'))
    print(words_count('one,two,three.stop'))

test_words_count()


# Generated at 2022-06-21 21:29:29.555633
# Unit test for function is_email
def test_is_email():
    assert is_email('test@test.test') is True
    assert is_email('test@test') is True
    assert is_email('test@test.test.test.test.test.test.test.test.test') is True
    assert is_email('test@mail-servers.com') is True
    assert is_email('test@.test') is False
    assert is_email('test@.test.test') is False
    assert is_email('@test') is False
    assert is_email('@test.test') is False
    assert is_email('test@test..test.com') is False
    assert is_email('test@') is False



# Generated at 2022-06-21 21:29:38.480697
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('0')
    assert is_integer('1')
    assert is_integer('+1')
    assert is_integer('-1')
    assert is_integer('1e1')
    assert is_integer('1.0') is False
    assert is_integer('1.2') is False
    assert is_integer('1E1') is False
    assert is_integer('1.e+5') is False
    assert is_integer('2.e5') is False
    assert is_integer('2.2e5') is False
    assert is_integer('1e-4') is False
    assert is_integer('-1.2e+5') is False
    assert is_integer('+1.2e+5') is False
    assert is_integer('-1.2e-15') is False

# Generated at 2022-06-21 21:29:43.311988
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('my_string')
    assert is_snake_case('my-string', '-')
    assert not is_snake_case('my-string_')
    assert is_snake_case('my-string_', '-')
    assert is_snake_case('my-string_', '-_')
    assert not is_snake_case('MyString')
    assert not is_snake_case('1my_string')
    assert not is_snake_case('my_string_')
    assert not is_snake_case('my_string1_2')
    assert not is_snake_case('my_string_1')


# Generated at 2022-06-21 21:29:48.456073
# Unit test for function is_isbn
def test_is_isbn():
    isbn_10 = "1 500 908 583"
    isbn_13 = "978-0-306-40615-7"

    assert is_isbn(isbn_10)
    assert is_isbn(isbn_13)
    assert is_isbn(isbn_10, normalize=False)
    assert is_isbn(isbn_13, normalize=False)

    assert is_isbn_10(isbn_10)
    assert is_isbn_13(isbn_13)
    assert is_isbn_10(isbn_10, normalize=False)
    assert is_isbn_13(isbn_13, normalize=False)


# Generated at 2022-06-21 21:29:51.282069
# Unit test for function is_string
def test_is_string():
    assert is_string('fase')
    assert not is_string(b'fase')


# Generated at 2022-06-21 21:29:58.669712
# Unit test for function is_url
def test_is_url():
    assert is_url('https://www.google.com') == True
    assert is_url('http://www.google.com') == True
    assert is_url('https://google.com') == True
    assert is_url('http://google.com') == True
    assert is_url('www.google.com') == False
    assert is_url('google.com') == False
    assert is_url('/var/log') == False
    assert is_url('https://www.google.com.tr/search?q=python') == True


# Generated at 2022-06-21 21:30:00.705034
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?') == False
test_is_ip_v6()


# Generated at 2022-06-21 21:30:11.002453
# Unit test for function is_slug
def test_is_slug():
    # single word, no slug
    assert is_slug('software') == False
    assert is_slug('software', separator='-') == False
    assert is_slug('software-engineer') == False
    assert is_slug('software-engineer', separator='-') == False

    # classic separated by dash
    assert is_slug('software-engineer') == True
    assert is_slug('software-engineer', separator='-') == True

    # classic separated by underscore
    assert is_slug('software_engineer') == True
    assert is_slug('software_engineer', separator='_') == True
    assert is_slug('software-engineer', separator='_') == False

    # classic separated by dot
    assert is_slug('software.engineer') == True
   

# Generated at 2022-06-21 21:30:30.354950
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6("::1")
    assert is_ip_v6("::")
    assert is_ip_v6("::1")
    assert is_ip_v6("::ffff:127.0.0.1")
    assert is_ip_v6("::ffff:0:0")
    assert is_ip_v6("::ffff:0:127.0.0.1")
    assert is_ip_v6("::ffff:127.0.0.1")
    assert is_ip_v6("::ffff:7f00:1")
    assert not is_ip_v6("02001:0000:1234:0000:0000:C1C0:ABCD:0876")

# Generated at 2022-06-21 21:30:35.047274
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75')
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334')
    assert not is_ip('1.2.3')
    assert not is_ip(None)



# Generated at 2022-06-21 21:30:46.594418
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    assert __ISBNChecker('1479204969').is_isbn_13()
    assert __ISBNChecker('1479204969').is_isbn_10()

    assert __ISBNChecker('9781479204969').is_isbn_13()
    assert not __ISBNChecker('9781479204969').is_isbn_10()

    assert not __ISBNChecker('9781479204969123').is_isbn_13()
    assert not __ISBNChecker('9781479204969123').is_isbn_10()

    assert not __ISBNChecker('9781479204969-123').is_isbn_13()
    assert not __ISBNChecker('9781479204969-123').is_isbn_10()

    assert not __ISBN

# Generated at 2022-06-21 21:30:57.468438
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('thisIsACamelString') is True, "test_is_camel_case: string 'thisIsACamelString' is not camel case"
    assert is_camel_case('camelString') is True, "test_is_camel_case: string 'camelString' is not camel case"
    assert is_camel_case('thisIsACamelString1') is True, "test_is_camel_case: string 'thisIsACamelString1' is not camel case"
    assert is_camel_case('1ThisIsNotACamelString') is False, "test_is_camel_case: string '1ThisIsNotACamelString' is not camel case"

# Generated at 2022-06-21 21:31:00.290478
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid("6f8aa2f9-686c-4ac3-8766-5712354a04cf")

# Generated at 2022-06-21 21:31:12.132401
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('my_snake_string') == True
    assert is_snake_case('mySnakeString') == False
    assert is_snake_case('2', separator='-') == False
    assert is_snake_case('_', separator='_') == True
    assert is_snake_case('_', separator='-') == True
    assert is_snake_case('my-snake-string', separator='-') == True
    assert is_snake_case('my_snake_string', separator='-') == False
    assert is_snake_case('my-snake_string', separator='-') == False
    assert is_snake_case('my_snake-string', separator='-') == True



# Generated at 2022-06-21 21:31:14.357951
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42') is True
    assert is_integer('19.99') is False


# Generated at 2022-06-21 21:31:21.005121
# Unit test for function is_ip
def test_is_ip():
    inputs = [
        '255.200.100.75',
        '2001:db8:85a3:0000:0000:8a2e:370:7334',
        '1.2.3'
    ]
    expected_outputs = [
        True,
        True,
        False
    ]
    for i in inputs:
        assert(is_ip(i) == expected_outputs[inputs.index(i)])
test_is_ip()
 


# Generated at 2022-06-21 21:31:24.687095
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('MyString') == True
    assert is_camel_case('mystring') == False
    assert is_camel_case('8string') == False
    assert is_camel_case('8String') == True


# Generated at 2022-06-21 21:31:27.776456
# Unit test for function is_string
def test_is_string():
    assert is_string('abc')
    assert not is_string(123)
    assert not is_string(bytes('foo', 'utf-8'))


# Generated at 2022-06-21 21:31:39.434749
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog') == True
    assert is_pangram('hello world') == False
test_is_pangram()


# Generated at 2022-06-21 21:31:49.192424
# Unit test for function is_isogram
def test_is_isogram():
    assert not is_isogram("Hello")
    assert is_isogram("")
    assert is_isogram("Isogram")
    assert not is_isogram("Dermatoglyphics")
    assert not is_isogram("aba")
    assert not is_isogram("moOse")
    assert is_isogram("thumbscrew japingly")
    assert not is_isogram("six-year-old")
    assert not is_isogram("Emily Jung Schwartzkopf")
    assert not is_isogram("accentor")
    assert not is_isogram("angola")
    assert not is_isogram("africa")
    assert is_isogram("alphAbet")
    assert is_isogram("alphabet")
    assert is_isogram("thumbscrew-japingly")
    assert is_is

# Generated at 2022-06-21 21:31:55.822545
# Unit test for function is_palindrome
def test_is_palindrome():
    # create a list of strings
    l = ['madam', 'abba', 'abcba' , 'a', 'aa', 'ab', 'Madam', '12375']
    # create a list of expected results
    res = [True, True, True, True, True, False, True, False]
    # run the test
    assert [is_palindrome(s) for s in l] == res



# Generated at 2022-06-21 21:31:59.246851
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('TestingCamelCase') == True
    assert is_camel_case('testingCamelCase') == False
    assert is_camel_case('testingCamelCase1') == True



# Generated at 2022-06-21 21:32:07.368739
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6("2001:db8:85a3:0000:0000:8a2e:370:7334")
    assert not is_ip_v6("2001:db8:85a3:0000:0000:8a2e:370:7334:")
    assert not is_ip_v6("2001:db8:85a3:0000:0000:8a2e:370:?")
    assert is_ip_v6("2001:db8:85a3:0:0:8a2e:370:7334")
    assert is_ip_v6("2001:db8:85a3::8a2e:370:7334")
    assert is_ip_v6("2001:db8:85a3:0::8a2e:370:7334")
    assert is_ip

# Generated at 2022-06-21 21:32:15.625606
# Unit test for function is_camel_case
def test_is_camel_case():
    try:
        assert is_camel_case('myString') == True, "myString is camel case"
        assert is_camel_case('22myString') == False, "22myString is not camel case"
        assert is_camel_case('my_String') == False, "my_String is not camel case"
        assert is_camel_case('mystring') == False, "mystring is not camel case"
    except AssertionError as e:
        print(e)



# Generated at 2022-06-21 21:32:18.295270
# Unit test for function is_json
def test_is_json():
    print(is_json('{"name": "Peter"}'))
    print(is_json('[1, 2, 3]'))
    print(is_json('{nope}'))

test_is_json()


# Generated at 2022-06-21 21:32:25.595248
# Unit test for function is_ip_v4
def test_is_ip_v4():
    # Set up
    ipv4_true_1 = '255.200.100.75'
    ipv4_true_2 = '0.1.1.1'
    ipv4_true_3 = '127.0.0.1'
    ipv4_true_4 = '0.0.0.0'
    ipv4_true_5 = '255.255.255.255'
    ipv4_false_1 = 'nope'
    ipv4_false_2 = '255.200.100.999'
    ipv4_false_3 = '127.0.0.1.1'
    ipv4_false_4 = '0.0.0.256'
    ipv4_false_5 = '256.0.0.0'
    ipv4_false_

# Generated at 2022-06-21 21:32:36.379254
# Unit test for function words_count
def test_words_count():
    assert words_count('hello world') == 2
    assert words_count('one,two,three.stop') == 4
    assert words_count("!@#$%^&*()[]{}|:')<.,>?") == 0
    assert words_count('') == 0
    assert words_count('one') == 1
    assert words_count('one two') == 2
    assert words_count('one two$ three') == 3
    assert words_count('one.two three') == 3
    assert words_count('one.two,three') == 3
    assert words_count('one.two,three four') == 4
    assert words_count('one.two,three four stop') == 4
    assert words_count('one.two,three four.stop') == 4

# Generated at 2022-06-21 21:32:48.319214
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('').is_isbn_10() == False
    assert __ISBNChecker('11', False).is_isbn_10() == False
    assert __ISBNChecker('111', False).is_isbn_10() == False
    assert __ISBNChecker('11-1', False).is_isbn_10() == False
    assert __ISBNChecker('111-1', False).is_isbn_10() == False
    assert __ISBNChecker('1234567890').is_isbn_10() == False

    assert __ISBNChecker('1234567890X').is_isbn_10() == False
    assert __ISBNChecker('-1234567890X', False).is_isbn_10() == False

# Generated at 2022-06-21 21:33:04.468022
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4111111111111111') == True
    assert is_credit_card('4111111111111') == False
    assert is_credit_card('4012888888881881') == True
    assert is_credit_card('378282246310005') == True
    assert is_credit_card('6011111111111117') == True
    assert is_credit_card('5105105105105100') == True
    assert is_credit_card('5105 1051 0510 5106') == False
    assert is_credit_card('9111111111111111') == False



# Generated at 2022-06-21 21:33:08.862235
# Unit test for function is_ip
def test_is_ip():
    assert is_ip("255.200.100.75")
    assert is_ip("2001:db8:85a3:0000:0000:8a2e:370:7334")
    assert not is_ip("1.2.3")


# Generated at 2022-06-21 21:33:14.197012
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?') == False
    assert is_ip_v6(None) == False



# Generated at 2022-06-21 21:33:20.724827
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10("294037811X") == True
    assert is_isbn_10("294037811x") == True
    assert is_isbn_10("1506715214") == True
    assert is_isbn_10("1506715214") == True
    assert is_isbn_10("293-9-37-811-X") == True
test_is_isbn_10()


# Generated at 2022-06-21 21:33:26.458526
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('Dermatoglyphics') == True
    assert is_isogram('isogram') == True
    assert is_isogram('aba') == False
    assert is_isogram('moOse') == False
    assert is_isogram('isIsogram') == False
    assert is_isogram('') == True
    print ("Function is_isogram() passed all tests")
test_is_isogram()