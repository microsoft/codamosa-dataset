

# Generated at 2022-06-21 21:23:42.411092
# Unit test for function words_count
def test_words_count():
    assert words_count('this is a string') == 4
    assert words_count('the quick brown fox jumps over the lazy dog') == 9
    assert words_count('hello world!') == 2
    assert words_count('the quick ... brown') == 2
    assert words_count('the quick-brown') == 0
    assert words_count('hello_world') == 0
    assert words_count('hello-world') == 0
    assert words_count('one,two,three.stop') == 4
    assert words_count('one two three stop') == 4
    assert words_count('one!two?three.stop') == 4


# Generated at 2022-06-21 21:23:47.247430
# Unit test for function is_ip_v6
def test_is_ip_v6():
    input_string = '2001:db8:85a3:0000:0000:8a2e:370:7334'
    assert is_ip_v6(input_string)

    input_string = '2001:db8:85a3:0000:0000:8a2e:370:?'
    assert is_ip_v6(input_string) == False



# Generated at 2022-06-21 21:23:50.491250
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('12345') == True
    assert is_integer('-12345') == True
    assert is_integer('12345.5') == False
    assert is_integer('-12345.5') == False
    assert is_integer('') == False


# Generated at 2022-06-21 21:24:02.116257
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    # True case
    checker = __ISBNChecker('978-1234567890')
    assert checker.is_isbn_13() is True

    checker = __ISBNChecker('9781234567894')
    assert checker.is_isbn_13() is True

    checker = __ISBNChecker('9781234567894', normalize=False)
    assert checker.is_isbn_13() is True

    # False case
    checker = __ISBNChecker('1234567890')
    assert checker.is_isbn_13() is False

    checker = __ISBNChecker('978-123456789')
    assert checker.is_isbn_13() is False

    checker = __ISBNChecker('978-1234567891')

# Generated at 2022-06-21 21:24:07.961527
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') == True
    assert is_isbn_10('150-6715214') == True
    assert is_isbn_10('150-6715214', normalize=False) == False


# Generated at 2022-06-21 21:24:12.726151
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42') == True
    assert is_integer('42.0') == False
    assert is_integer(42) == False
    assert is_integer('42.0') == False
    assert is_integer('1e3') == True
    assert is_integer('1.0e2') == False
    assert is_integer('inf') == False
    assert is_integer('-inf') == False
    assert is_integer('nan') == False
    assert is_integer('42.42') == False
test_is_integer()



# Generated at 2022-06-21 21:24:15.760075
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') is True
    assert is_isbn('1506715214') is True
    assert is_isbn('978-0312498580') is True


# Generated at 2022-06-21 21:24:19.989441
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('LOL') == True
    assert is_palindrome('Lol') == False
    assert is_palindrome('Lol', ignore_case=True) == True
    assert is_palindrome('ROTFL') == False
test_is_palindrome()
 


# Generated at 2022-06-21 21:24:27.838570
# Unit test for function words_count
def test_words_count():
    assert words_count("hello world") == 2
    assert words_count("Hello, World!") == 2
    assert words_count("") == 0
    assert words_count("12345678") == 1
    assert words_count("I am 17 years old!") == 4
    assert words_count("one,two,three.stop") == 4
    assert words_count("Hey there, my name is Peter, I'm 17 and live in Berlin.") == 14
test_words_count()




# Generated at 2022-06-21 21:24:30.952069
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('my string is <strong>bold</strong>') == True
    assert contains_html('my string is not bold') == False
contains_html('my string is <strong>bold</strong>')

test_contains_html()


# Generated at 2022-06-21 21:24:38.477623
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title')
    assert not is_slug('My blog post title')

# Generated at 2022-06-21 21:24:43.453461
# Unit test for function is_pangram
def test_is_pangram():
    print('\nFunction: is_pangram')

    # Test with an empty string
    print(is_pangram(''))

    # Test with a valid sentence
    print(is_pangram('The quick brown fox jumps over the lazy dog'))
    
    # Test with a non valid sentence
    print(is_pangram('Hello World'))
    
    # Test with a non valid string
    print(is_pangram('12345678'))
    
    

# Generated at 2022-06-21 21:24:52.651176
# Unit test for function is_palindrome
def test_is_palindrome():
    if is_palindrome('LOL'):
        print('TEST 1 OK')
    else:
        print('TEST 1 ERROR')
    #
    if is_palindrome('Lol', ignore_case=True):
        print('TEST 2 OK')
    else:
        print('TEST 2 ERROR')
    #
    if is_palindrome('i topi non avevano nipoti', ignore_spaces=True):
        print('TEST 3 OK')
    else:
        print('TEST 3 ERROR')
    #
    if is_palindrome('12345678987654321', ignore_spaces=True) and is_palindrome('12345678987654321'):
        print('TEST 4 OK')
    else:
        print('TEST 4 ERROR')
    #


# Generated at 2022-06-21 21:24:59.821477
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') # returns true
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf') == False # returns false
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True) # returns true

test_is_uuid()


# Generated at 2022-06-21 21:25:07.476457
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4012888888881881') == True
    assert is_credit_card('4111111111111111') == True
    assert is_credit_card('4111111111111') == False
    assert is_credit_card('4012888888881881', card_type='VISA') == True
    assert is_credit_card('4111111111111111', card_type='VISA') == True
    assert is_credit_card('4111111111111', card_type='VISA') == False
    assert is_credit_card('5500000000000004', card_type='MASTERCARD') == True
    assert is_credit_card('5000000000000000', card_type='MASTERCARD') == False

# Generated at 2022-06-21 21:25:19.299764
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('foo_bar_baz') == True
    assert is_snake_case('foo') == False
    assert is_snake_case('foo_bar_baz', '_') == True
    assert is_snake_case('foo-bar-baz', '-') == True
    assert is_snake_case('foo-bar-baz', '_') == False
    assert is_snake_case('foo_bar_baz', '-') == False
    assert is_snake_case('_foo_bar_baz', '_') == True
    assert is_snake_case('-foo--bar-baz', '-') == True
    assert is_snake_case('foo_bar_baz_', '_') == True

# Generated at 2022-06-21 21:25:22.891238
# Unit test for function is_full_string
def test_is_full_string():
    assert (is_full_string('bar') == True)
    assert (is_full_string('') == False)
    assert (is_full_string('  ') == False)
    assert (is_full_string(None) == False)
test_is_full_string()



# Generated at 2022-06-21 21:25:34.885804
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:73a4') == True
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:73g4') == False
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:73a4') == True

# Generated at 2022-06-21 21:25:38.376508
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram("hello") == False
    assert is_isogram("dermatoglyphics") == True
    assert is_isogram("isogram") == True

# Generated at 2022-06-21 21:25:43.430044
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    input_string = '9780747533553'
    result = __ISBNChecker(input_string).is_isbn_13()
    assert result == True

    input_string = '978-0751511331'
    result = __ISBNChecker(input_string).is_isbn_13()
    assert result == True


# Generated at 2022-06-21 21:25:54.868711
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('first.lastname@the-provider.com')
    assert is_email('user-name@the-provider.com')
    assert is_email('user.name1@the-provider.com')
    assert is_email('user.name+spam@the-provider.com')
    assert is_email('"user name"@the-provider.com')
    assert is_email('"name@email"@the-provider.com')
    assert is_email('"name\"email"@the-provider.com')
    assert is_email('name\\@email@the-provider.com')
    assert is_email('user.name@gmail.co.uk')

# Generated at 2022-06-21 21:26:04.820520
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('').is_isbn_10() is False
    assert __ISBNChecker('Unicorns').is_isbn_10() is False
    assert __ISBNChecker('8362223336').is_isbn_10() is True
    assert __ISBNChecker('978-83-62223-33-6').is_isbn_10() is False
    assert __ISBNChecker('9788362223336').is_isbn_10() is False
    assert __ISBNChecker('8362223336', normalize=False).is_isbn_10() is True
    assert __ISBNChecker('978-83-62223-33-6', normalize=False).is_isbn_10() is False

# Generated at 2022-06-21 21:26:17.166606
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4111111111111111')
    assert is_credit_card('4111-1111-1111-1111')
    assert is_credit_card('4111 1111 1111 1111')

    assert not is_credit_card('4111111111111')
    assert not is_credit_card('41111-1111-1111-1111')
    assert not is_credit_card('41111.1111.1111.1111')

    assert is_credit_card('5105105105105100')
    assert is_credit_card('5105 1051 0510 5100')
    assert is_credit_card('5105-1051-0510-5100')

    assert not is_credit_card('5105105105105106')
    assert not is_credit_card('5105-1051-0510-5106')
   

# Generated at 2022-06-21 21:26:23.868710
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    assert __ISBNChecker('978-3-16-148410-0').is_isbn_13()
    assert __ISBNChecker('978-3-16-148410-0').is_isbn_10()
    assert not __ISBNChecker('978-3-16-148410-0').is_isbn_13()
    assert not __ISBNChecker('978-3-16-148410-0').is_isbn_10()


# PUBLIC API



# Generated at 2022-06-21 21:26:27.081517
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('LOL') == True
    assert is_isogram('hello') == False


# Generated at 2022-06-21 21:26:37.276151
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4111111111111111') == True
    assert is_credit_card('5105105105105100') == True
    assert is_credit_card('378282246310005') == True
    assert is_credit_card('371449635398431') == True
    assert is_credit_card('6011111111111117') == True
    assert is_credit_card('3530111333300000') == True
    assert is_credit_card('3566002020360505') == True
    assert is_credit_card('30569309025904') == True
    assert is_credit_card('6011000990139424') == True
    assert is_credit_card('5555555555554444') == True

    assert is_credit_card('4111111111111112') == False
   

# Generated at 2022-06-21 21:26:47.498738
# Unit test for function is_isbn
def test_is_isbn():
    # check valid
    assert is_isbn('9780312498580')
    assert is_isbn('1506715214')
    assert is_isbn('9780312498580', normalize=False)
    assert is_isbn('1506715214', normalize=False)
    assert is_isbn('978-0312498580')
    assert is_isbn('150-6715214')
    # check not valid
    assert not is_isbn('1234')
    assert not is_isbn('978-0312498580', normalize=False)
    assert not is_isbn('150-6715214', normalize=False)
# tests is_isbn
test_is_isbn()



# Generated at 2022-06-21 21:26:55.589939
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert(is_isbn_10('1506715214'))
    assert(is_isbn_10('1806715214'))
    assert(is_isbn_10('150-6715214'))
    assert(is_isbn_10('4529039000'))
    assert(is_isbn_10('452903900X'))
    assert(is_isbn_10('452903900x'))
    assert(is_isbn_10('4873115699'))
    assert(is_isbn_10('4873115699'))
    assert(is_isbn_10('4883598308'))

    assert(not is_isbn_10('150-6715214', normalize=False))
    assert(not is_isbn_10('9562780631'))


# Generated at 2022-06-21 21:27:00.397859
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title') is True
    assert is_slug('My blog post title') is False
    assert is_slug('my-blog-post-title', separator='.') is True
#Unit tests for function is_palindrome

# Generated at 2022-06-21 21:27:08.009281
# Unit test for function is_json
def test_is_json():
    assert is_json('{"foo": "bar"}') == True
    assert is_json('{foo: "bar"}') == False
    assert is_json("{foo: 1}") == False
    assert is_json('{"foo": 1}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json("['foo', 1, true]") == True
    assert is_json("[foo, 1, true]") == False
    assert is_json("[foo, 1, 'true']") == True
# End test code


# Generated at 2022-06-21 21:27:21.083243
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999')

test_is_ip_v4()



# Generated at 2022-06-21 21:27:27.405955
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('1234567891234').is_isbn_13()
    assert not __ISBNChecker('123456789123').is_isbn_13()
    assert not __ISBNChecker('12345678912345').is_isbn_13()
    assert not __ISBNChecker('123456789123x').is_isbn_13()
    assert not __ISBNChecker('x234567891234').is_isbn_13()


# Generated at 2022-06-21 21:27:34.041282
# Unit test for function is_pangram
def test_is_pangram():
    result = is_pangram("The quick brown fox jumps over the lazy dog")
    expected = True
    assert result == expected

    result = is_pangram("hello world")
    expected = False
    assert result == expected

test_is_pangram()
assert is_pangram("The quick brown fox jumps over the lazy dog") == True
assert is_pangram("hello world") == False

# Generated at 2022-06-21 21:27:37.568247
# Unit test for function is_pangram
def test_is_pangram():
    pangram = "The quick brown fox jumps over the lazy dog"
    not_a_pangram = "hello world"
    assert is_pangram(pangram) == True
    assert is_pangram(not_a_pangram) == False

# Generated at 2022-06-21 21:27:48.169495
# Unit test for function is_isogram
def test_is_isogram():
    assert(is_isogram('dermatoglyphics') == True)
    assert(is_isogram('isograms') == True)
    assert(is_isogram('isograms') == True)
    assert(is_isogram('subdermatoglyphic') == True)
    assert(is_isogram('aba') == False)
    assert(is_isogram('isIsogram') == False)
    assert(is_isogram('moose') == False)
    assert(is_isogram('isIsogram') == False)
    assert(is_isogram('aba') == False)
    assert(is_isogram('') == True)
test_is_isogram()

# Generated at 2022-06-21 21:27:49.649109
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal("1.0") == True
    assert is_decimal("1") == False


# Generated at 2022-06-21 21:27:52.297903
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10("1506715214")
    assert is_isbn_10("150-6715214")
    assert is_isbn_10("150-6715214", normalize=False)



# Generated at 2022-06-21 21:27:54.697344
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('42') == False
    assert is_decimal('42.0') == True
    assert is_decimal('1e3') == False


# Generated at 2022-06-21 21:27:57.355430
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    checker = __ISBNChecker('978-5-496-01383-8')
    assert checker.is_isbn_13() == True
    assert checker.is_isbn_10() == False
    return True


# Generated at 2022-06-21 21:28:00.360889
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') == True
    assert is_url('http://mysite.com') == True
    assert is_url('.mysite.com') == False
    assert is_url('') == False
    assert is_url(' ') == False


# Generated at 2022-06-21 21:28:13.755622
# Unit test for function is_number
def test_is_number():
    assert is_number('1e3') == True
    assert is_number('-9.12') == True
    assert is_number('19.99') == True
    assert is_number('42') == True
    assert is_number('1 2 3') == False

    return "Unit test for function is_number is successful"
print(test_is_number())


# Generated at 2022-06-21 21:28:18.651398
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('foo_bar_baz')  # returns true
    assert not is_snake_case('foo')  # returns false
    assert not is_snake_case('')  # returns false



# Generated at 2022-06-21 21:28:21.942569
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title')
    assert is_slug('my-blog-post-title', '_')
    assert not is_slug('My blog post title')



# Generated at 2022-06-21 21:28:30.282983
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    checker = __ISBNChecker('9780789029038')
    assert checker.is_isbn_10()

    checker = __ISBNChecker('978-3-16-148410-0')
    assert checker.is_isbn_10()

    checker = __ISBNChecker('978-3-16-148410-1')
    assert not checker.is_isbn_10()

    checker = __ISBNChecker('978078902903')
    assert not checker.is_isbn_10()

    checker = __ISBNChecker('9780abc929038')
    assert not checker.is_isbn_10()

    checker = __ISBNChecker('9780789029038', normalize=False)
    assert checker.is_is

# Generated at 2022-06-21 21:28:39.159781
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf')
    assert not is_uuid('6f8aa2f9686c4ac387665712354a04cf')
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True)
    assert not is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=False)
    assert not is_uuid('6f8aa2f9686c4ac387665712354a04cf-')



# Generated at 2022-06-21 21:28:48.744996
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    assert __ISBNChecker('978-1-84831-189-4').__dict__ == {'input_string': '9781848311894'}
    assert __ISBNChecker('978-1-84831-189-4', normalize=False).__dict__ == {'input_string': '978-1-84831-189-4'}
    try:
        __ISBNChecker(None)
        assert False
    except InvalidInputError:
        assert True
    try:
        __ISBNChecker(123)
        assert False
    except InvalidInputError:
        assert True


# Generated at 2022-06-21 21:28:52.096733
# Unit test for function is_url
def test_is_url():
    # And the unit test
    assert is_url('http://www.mysite.com', allowed_schemes=['http', 'https'])
    assert not is_url('mysite.com')


# Generated at 2022-06-21 21:28:56.950684
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') == True
    assert is_isbn_10('150-6715214') == True
    assert is_isbn_10('150-6715214', normalize=False) == False
test_is_isbn_10()



# Generated at 2022-06-21 21:29:01.106461
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580')
    assert not is_isbn_13('978-0312498580')
    assert not is_isbn_13('978-0312498580', normalize=False)

# Generated at 2022-06-21 21:29:06.989165
# Unit test for function is_full_string
def test_is_full_string():
    assert not is_full_string(None)
    assert not is_full_string('')
    assert not is_full_string(' ')
    assert not is_full_string('\0')
    assert not is_full_string('\n')
    assert not is_full_string('\t')
    assert not is_full_string('\r')
    assert is_full_string('a')
    assert is_full_string(' a ')
    assert is_full_string('a' * 512)
test_is_full_string()



# Generated at 2022-06-21 21:29:15.550002
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') == True
    assert is_isbn_10('150-6715214') == True
    assert is_isbn_10('150-6715214', normalize=False) == False


# Generated at 2022-06-21 21:29:25.511448
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') # returns true
    assert not is_email('@gmail.com') # returns false
    assert is_email('my.email@the-provider.com') # returns true
    assert not is_email('@gmail.com') # returns false
    assert is_email('Abc\\@def@example.com') # returns true
    assert is_email('Fred\\ Bloggs@example.com') # returns true
    assert is_email('Joe.\\\\Blow@example.com') # returns true
    assert is_email('email@example.com') # returns true
    assert is_email('firstname.lastname@example.com') # returns true
    assert is_email('email@subdomain.example.com') # returns true

# Generated at 2022-06-21 21:29:30.461719
# Unit test for function is_json
def test_is_json():
    json_example = '{"name": "Peter"}'
    list_example = '[1, 2, 3]'
    invalid_json = '{nope}'
    assert(is_json(json_example))
    assert(is_json(list_example))
    assert(not is_json(invalid_json))



# Generated at 2022-06-21 21:29:37.331680
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('Lorem-ipsum-dolor-sit-amet') == True, 'is_slug("Lorem-ipsum-dolor-sit-amet") returns False'
    assert is_slug('Lorem_ipsum_dolor_sit_amet') == False, 'is_slug("Lorem_ipsum_dolor_sit_amet") returns False'
    assert is_slug('Lorem ipsum dolor sit amet') == False, 'is_slug("Lorem ipsum dolor sit amet") returns False'

test_is_slug()


# Generated at 2022-06-21 21:29:49.113772
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    try:
        __ISBNChecker('asewrgtv')
    except InvalidInputError:
        pass

    try:
        __ISBNChecker(None)
    except InvalidInputError:
        pass

    try:
        __ISBNChecker(False)
    except InvalidInputError:
        pass

    try:
        __ISBNChecker(123)
    except InvalidInputError:
        pass

    isbn_13 = __ISBNChecker('9780-262-13472-9')
    assert isbn_13.input_string == '9780262134679'
    assert isbn_13.is_isbn_10() is False
    assert isbn_13.is_isbn_13() is True

    isbn_10 = __ISBNChecker('0-262-13472-3')
   

# Generated at 2022-06-21 21:29:56.600703
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    checker = __ISBNChecker('978-0-306-40615-7', True)
    assert checker.input_string == '9780306406157'
    checker = __ISBNChecker('9780306406157', True)
    assert checker.input_string == '9780306406157'
    checker = __ISBNChecker('9780306406157', False)
    assert checker.input_string == '9780306406157'



# Generated at 2022-06-21 21:29:58.668971
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('42.0') == True
    assert is_decimal('42') == False
test_is_decimal()



# Generated at 2022-06-21 21:30:08.803200
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-3-16-148410-0').is_isbn_13()
    assert __ISBNChecker('9783198651639').is_isbn_13()
    assert __ISBNChecker('9783161484100').is_isbn_13()
    assert __ISBNChecker('978-3-16-148410-0', normalize=False).is_isbn_13()
    assert __ISBNChecker('9783198651639', normalize=False).is_isbn_13()
    assert __ISBNChecker('9783161484100', normalize=False).is_isbn_13()
    assert not __ISBNChecker('978316148410').is_isbn_13()

# Generated at 2022-06-21 21:30:13.268089
# Unit test for function is_slug
def test_is_slug():

    # Test cases for types of slugs
    cases = [
        ('my-blog-post-title', '-', True),
        ('my_blog_post_title', '_', True),
        ('myblogposttitle', '', True),
        ('My blog post title', '-', False),
        ('My blog post title', '_', False),
        ('My blog post title', '', False),
        ('M&M', '-', False),
    ]

    # Iterate and test each case
    for slug, separator, expected_result in cases:
        actual_result = is_slug(slug, separator)
        assert actual_result == expected_result, (
            'Expected: {}. Actual: {}.'.format(expected_result, actual_result)
        )
test_is_slug()




# Generated at 2022-06-21 21:30:23.345194
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1853260304')
    assert is_isbn_10('1-853260-30-4')
    assert is_isbn_10('1-853260-30-4', normalize=False)
    assert not is_isbn_10('1-853260-30-4', normalize=True)
    assert not is_isbn_10('1-853260-30-3')
    assert not is_isbn_10('185326030X')
    assert not is_isbn_10('1234567890')
    assert not is_isbn_10('1-853260-30')
    assert not is_isbn_10('1-853260-301')
    assert is_isbn_10('0-684-84328-5')




# Generated at 2022-06-21 21:30:31.592612
# Unit test for function is_string
def test_is_string():
    assert is_string('foo')
    assert not is_string(b'foo')
    assert not is_string(None)
    assert not is_string(True)
    assert not is_string(False)



# Generated at 2022-06-21 21:30:42.706169
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert not is_email('@gmail.com')
    assert not is_email('my.address@gmail..com')
    assert is_email('"very.unusual.@.unusual.com"@example.com')
    assert is_email('" "@example.org')
    assert is_email('" "test@example.org')
    assert is_email('"test@test"@example.org')
    assert is_email('"very.(),:;<>[]\".VERY.\"very@\\\\ \\"very\\".unusual"@strange.example.com')
    assert is_email('" "@example.org')
    assert not is_email('test@test@test.test')
    assert not is_email('test@test')


# Generated at 2022-06-21 21:30:51.194166
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert(is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334'))
    assert(is_ip_v6('fdd1:db8:85a3:0000:0000:8a2e:370:7334') == False)
    assert(is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?') == False)
    assert(is_ip_v6('') == False)



# Generated at 2022-06-21 21:30:51.834846
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13("978-0312498580")==True


# Generated at 2022-06-21 21:30:53.216186
# Unit test for function words_count
def test_words_count():
    assert words_count('this is a string') == 4
    assert words_count('this is another,string') == 4
    assert words_count('this is a string,with a dot at the end.') == 7



# Generated at 2022-06-21 21:30:58.784217
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') is True
    assert is_url('https://mysite.com') is True
    assert is_url('.mysite.com') is False
    assert is_url('http://www.mysite.com', allowed_schemes=['https']) is False
    assert is_url('https://www.mysite.com', allowed_schemes=['https']) is True



# Generated at 2022-06-21 21:31:11.346879
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    checker = __ISBNChecker('9992158107')
    assert checker.is_isbn_13() == True

    checker = __ISBNChecker('99921-58107')
    assert checker.is_isbn_13() == True

    checker = __ISBNChecker('99921-58107x')
    assert checker.is_isbn_13() == False

    checker = __ISBNChecker('99921-581072')
    assert checker.is_isbn_13() == False

    checker = __ISBNChecker('9992158107', False)
    assert checker.is_isbn_13() == False

    checker = __ISBNChecker('999215810')
    assert checker.is_isbn_13() == False

    checker = __IS

# Generated at 2022-06-21 21:31:14.111444
# Unit test for function is_isogram
def test_is_isogram():
    string = input("enter a string:")
    assert 'dermatoglyphics' == string
    assert 'hello' == string


# Generated at 2022-06-21 21:31:23.548332
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0201485672').is_isbn_10() == True
    assert __ISBNChecker('0201481016').is_isbn_10() == False
    assert __ISBNChecker('0-201-48567-2').is_isbn_10() == True
    assert __ISBNChecker('0-201-48101-6').is_isbn_10() == False
    assert __ISBNChecker('978-3-16-148410-0').is_isbn_10() == True
    assert __ISBNChecker('978-3-16-148410-5').is_isbn_10() == False



# Generated at 2022-06-21 21:31:33.872426
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('978-0312498580') == True
    assert is_isbn('979-0312498580') == False
    assert is_isbn('978-0312498580') == True
    assert is_isbn('978-0314498580') == False
    assert is_isbn('1059-0312498585') == False
    assert is_isbn('978-0312498580',False) == True
    assert is_isbn('978-0312498580',True) == True
    assert is_isbn('101-0312498580') == False
    assert is_isbn('200-0312498580') == False
    assert is_isbn('0312498580') == False
    assert is_isbn('1506715214') == True
   

# Generated at 2022-06-21 21:31:44.864730
# Unit test for function is_ip_v4
def test_is_ip_v4():
    tests = [
        { 'input_string': '255.200.100.75', 'expected': True },
        { 'input_string': 'nope', 'expected': False },
        { 'input_string': '255.200.100.999', 'expected': False }
    ]
    for test in tests:
        assert is_ip_v4(test['input_string']) == test['expected']
test_is_ip_v4()


# Generated at 2022-06-21 21:31:47.956792
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker(input_string='978-3-16-148410-0').is_isbn_13() is True
    assert __ISBNChecker('0-306-40615-2').is_isbn_13() is False


# Generated at 2022-06-21 21:31:52.397868
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('MyString')
    assert not is_camel_case('')
    assert not is_camel_case('mystring')
    assert not is_camel_case('')
    assert not is_camel_case('my string')
    assert not is_camel_case('My String')
    assert not is_camel_case(None)



# Generated at 2022-06-21 21:32:04.431057
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('Lol') is False
    assert is_palindrome('Lol', ignore_case=True) is True
    assert is_palindrome('LOL') is True
    assert is_palindrome('ROTFL') is False
    assert is_palindrome('otttto') is True
    assert is_palindrome('otto') is True
    assert is_palindrome('ott') is False
    assert is_palindrome('ott', ignore_spaces=True) is False
    assert is_palindrome('') is True
    assert is_palindrome('i topi non avevano nipoti') is False
    assert is_palindrome('i topi non avevano nipoti', ignore_spaces=True) is True

# Generated at 2022-06-21 21:32:15.917382
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    valid_isbn_input = '978079132723'
    checker = __ISBNChecker(valid_isbn_input)
    if checker.input_string != valid_isbn_input:
        raise AssertionError('ISBN without "-" should be returned without "-"')

    valid_isbn_input = '978079132723-0'
    checker = __ISBNChecker(valid_isbn_input)
    if checker.input_string != valid_isbn_input.replace('-', ''):
        raise AssertionError('ISBN with "-" should be returned without "-"')

    valid_isbn_input = '978079132723-0'
    checker = __ISBNChecker(valid_isbn_input, normalize=False)

# Generated at 2022-06-21 21:32:19.309060
# Unit test for function is_number
def test_is_number():
    assert is_number('42')
    assert is_number('19.99')
    assert is_number('-9.12')
    assert is_number('1e3')
    assert not is_number('1 2 3')



# Generated at 2022-06-21 21:32:21.174838
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker("0462321379").is_isbn_10() == True


# PUBLIC API



# Generated at 2022-06-21 21:32:30.254859
# Unit test for function is_credit_card
def test_is_credit_card():
    input_string = '4626694767392985'
    card_type = 'VISA'
    assert is_credit_card(input_string, card_type) == True

    input_string = '4626694767392985'
    card_type = 'MASTERCARD'
    assert is_credit_card(input_string, card_type) == False

    input_string = '4626694767392985'
    card_type = 'AMERICAN_EXPRESS'
    assert is_credit_card(input_string, card_type) == False


# Generated at 2022-06-21 21:32:34.772260
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42')
    assert is_integer('-10')
    assert is_integer('1e5')
    assert not is_integer('42.2')
    assert not is_integer('-10.0')
    assert not is_integer('1e5.1')


# Generated at 2022-06-21 21:32:37.913352
# Unit test for function is_number
def test_is_number():
    assert is_number('42') == True
    assert is_number('19.99') == True
    assert is_number('-9.12') == True
    assert is_number('1e3') == True
    assert is_number('1 2 3') == False


# Generated at 2022-06-21 21:32:58.538666
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    invalid_isbn_10_inputs = [
        '0123456789',  # check digit is wrong
        '012345678X',  # check digit is wrong
        '0123456780',  # check digit is wrong
        '0123456789X',  # length is wrong
        '01234567890',  # length is wrong
        '012345678901',  # length is wrong
    ]


# Generated at 2022-06-21 21:33:06.510763
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') == True
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf') == False
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True) == True

# Generated at 2022-06-21 21:33:10.378381
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('42.0') == True
    assert is_decimal('42') == False
    assert is_decimal('100') == False

# Test function:is_decimal()
test_is_decimal()



# Generated at 2022-06-21 21:33:14.383142
# Unit test for function is_number
def test_is_number():
    assert(is_number("42"))
    assert(is_number("19.99"))
    assert(is_number("-9.12"))
    assert(is_number("1e3"))
    assert(not is_number("1 2 3"))



# Generated at 2022-06-21 21:33:16.838578
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('348825551776300') == True


# Generated at 2022-06-21 21:33:25.266172
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334')
    assert is_ip_v6('2001:db8:85a3:8d3:1319:8a2e:370:7348')
    assert is_ip_v6('2001:db8:85a3:8d3:1319:8a2e:370:7348')
    assert is_ip_v6('2001:db8::8d3:1319:8a2e:370:7348')
    assert is_ip_v6('2001:db8:85a3::8a2e:370:7348')