

# Generated at 2022-06-21 21:23:40.121478
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string(None) == False
    assert is_full_string('') == False
    assert is_full_string(' ') == False
    assert is_full_string('hello') == True

# Generated at 2022-06-21 21:23:50.648902
# Unit test for function is_palindrome
def test_is_palindrome():
    assert(is_palindrome('LOL', ignore_case=True))
    assert(is_palindrome('Lol', ignore_case=True))
    assert(is_palindrome("level"))
    assert(is_palindrome("was it a car or a cat I saw"))
    assert(is_palindrome("i topi non avevano nipoti"))
    assert(not is_palindrome("ROTFL", ignore_case=True))
    assert(not is_palindrome("level", ignore_case=True))
    assert(not is_palindrome("was it a car or a cat I saw", ignore_case=True))
    assert(not is_palindrome("i topi non avevano nipoti", ignore_case=True))



# Generated at 2022-06-21 21:24:02.293680
# Unit test for function is_palindrome
def test_is_palindrome():
    # base case
    assert is_palindrome('LOL')
    assert is_palindrome('Lol') == False
    assert is_palindrome('Lol', ignore_case=True)
    assert is_palindrome('ROTFL') == False
    # ignore_spaces
    assert is_palindrome('a man a plan a canal panama')
    assert is_palindrome('a man a plan a canal panama', ignore_spaces=True)
    # ignore_case
    assert is_palindrome('ROTOR')
    assert is_palindrome('ROTOR', ignore_case=True)
    # empty string
    assert is_palindrome('')
    assert is_palindrome(None) == False
test_is_palindrome()

# Generated at 2022-06-21 21:24:14.486194
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('LOL')
    assert is_palindrome('Lol')
    assert is_palindrome('Lol', ignore_case=True)
    assert not is_palindrome('ROTFL')
    assert not is_palindrome('lol')
    assert not is_palindrome('parking', ignore_spaces=True)
    assert not is_palindrome('parking', ignore_spaces=True, ignore_case=True)
    assert is_palindrome('non', ignore_spaces=True)
    assert is_palindrome('non', ignore_spaces=True, ignore_case=True)
    assert is_palindrome('i topi non avevano nipoti', ignore_spaces=True)

# Generated at 2022-06-21 21:24:26.735097
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4242424242424242')
    assert is_credit_card('4242424242424242', 'VISA')
    assert not is_credit_card('4242424242424242', 'MASTERCARD')
    assert is_credit_card('5555555555554444')
    assert is_credit_card('2223003122003222')
    assert is_credit_card('378282246310005')
    assert is_credit_card('6011111111111117')
    assert is_credit_card('3530111333300000')
    assert is_credit_card('3566002020360505')
    assert is_credit_card('6200000000000005')
    assert not is_credit_card('5')
    assert not is_credit_card('5')
   

# Generated at 2022-06-21 21:24:32.308783
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email.@the-provider.com') == False
    assert is_email('@gmail.com') == False
    assert is_email(' ') == False
    assert is_email('') == False
    assert is_email(None) == False


# Generated at 2022-06-21 21:24:40.915625
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('1') == True
    assert is_integer('0') == True
    assert is_integer('-1') == True
    assert is_integer('1e+5') == True
    assert is_integer('2.25') == False
    assert is_integer('2,25') == False
    assert is_integer('na') == False
    assert is_integer(' ') == False
    assert is_integer('\\n') == False
    assert is_integer('') == False
    assert is_integer(None) == False
    assert is_integer(False) == False
    assert is_integer(True) == False
    assert is_integer(0) == False
    assert is_integer(1) == False
    assert is_integer(-1) == False
    assert is_integer(1e+5) == False


# Generated at 2022-06-21 21:24:47.436452
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    assert __ISBNChecker('9780470059029').input_string == '9780470059029'
    assert __ISBNChecker('9780980200447').input_string == '9780980200447'
    assert __ISBNChecker('0-9752298-0-X').input_string == '097522980X'
    assert __ISBNChecker('0-9752298-0-X', False).input_string == '0-9752298-0-X'


# Generated at 2022-06-21 21:24:50.014307
# Unit test for function words_count
def test_words_count():
    assert words_count("Lorem ipsum dolor sit amet, consectetur adipiscing elit") == 11



# Generated at 2022-06-21 21:24:55.218543
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') == True
    assert is_isbn('1506715214') == True
    assert is_isbn('978-0312498580') == True
    assert is_isbn('978-0312498580', normalize=False) == False

# Generated at 2022-06-21 21:25:07.822359
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('3250310101').is_isbn_10() == True
    assert __ISBNChecker('32503-10101').is_isbn_10() == True
    assert __ISBNChecker('32503-10103').is_isbn_10() == False



# Generated at 2022-06-21 21:25:19.668322
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    # test case: input_string is not a string
    try:
        __ISBNChecker(input_string=(1, 2, 3))
        assert False, 'InvalidInputError was not raised'
    except InvalidInputError:
        assert True, 'InvalidInputError was raised'

    # test case: normalize is false
    assert not __ISBNChecker(input_string='123-456-789-0', normalize=False).is_isbn_13()

    # test case: valid ISBN-13 strings
    assert __ISBNChecker('1234567890123').is_isbn_13()
    assert __ISBNChecker('123 456 789 012 3').is_isbn_13()
    assert __ISBNChecker('9781234567894').is_isbn_13()
    assert __ISBNCheck

# Generated at 2022-06-21 21:25:27.091186
# Unit test for function is_isbn
def test_is_isbn():
    assert not is_isbn('')
    assert is_isbn('9788363869360')
    assert is_isbn('9788363869360', normalize=False)
    assert not is_isbn('9788363869360', normalize=False)
    assert is_isbn('9788363869360')
    assert is_isbn('9788363869360', normalize=False)
    assert is_isbn('9788363869360')
    assert is_isbn('9788363869360', normalize=False)
    assert is_isbn('9780718157838')
    assert is_isbn('9780718157838', normalize=False)
    assert is_isbn('9781506715214')

# Generated at 2022-06-21 21:25:31.554739
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('42') == False
    assert is_decimal('42.0') == True
    assert is_decimal('42.') == False
    assert is_decimal('.42') == False
    assert is_decimal('.042') == False


# Generated at 2022-06-21 21:25:44.546090
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214')
    assert is_isbn_10('150-6715214')
    assert is_isbn_10('150-6715214', normalize=False)

    # ------------
    # BAD CASES
    # ------------

    # empty string
    assert not is_isbn_10('') # invalid length
    assert not is_isbn_10(None) # invalid type
    # invalid check digit
    assert not is_isbn_10('1506715218')
    assert not is_isbn_10('150-6715218')
    assert not is_isbn_10('150-6715218', normalize=False)
    # invalid char
    assert not is_isbn_10('150671521')

# Generated at 2022-06-21 21:25:48.971320
# Unit test for function is_string
def test_is_string():
    assert is_string('foo')
    assert is_string('1234')
    assert is_string(u'\u2603')
    assert not is_string(None)
    assert not is_string(12345)
    assert not is_string(b'foo')
test_is_string()



# Generated at 2022-06-21 21:25:51.829905
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75')
    assert not is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334')
    assert not is_ip('1.2.3')
test_is_ip()


# Generated at 2022-06-21 21:25:53.997585
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13(input_string = '9780312498580')
    assert is_isbn_13(input_string = '978-0312498580')
    assert not is_isbn_13(input_string = '978-0312498580', normalize = False)
    return True
test_is_isbn_13()


# Generated at 2022-06-21 21:25:58.749641
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('192.168.1.1')
    assert not is_ip('192.168.1.300')
    assert is_ip('2001:0db8:85a3:0000:0000:8a2e:0370:7334')
    assert not is_ip('2001:0db8:85a3:0000:0000:8a2e:0370:7334::')
    assert is_ip('1:0:0:0:0:ffff:c000:0280')
    assert is_ip('1::ffff:c000:0280')
    assert not is_ip('2001:0db8:85a3:0000:0000:8a2e:0370:7334:')
    assert not is_ip('1.2')
    assert not is_ip('2001::7334')
   

# Generated at 2022-06-21 21:26:08.539202
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    checker = __ISBNChecker('978-0-306-40615-7')
    assert checker.is_isbn_13() is True
    assert checker.is_isbn_10() is False
    checker = __ISBNChecker('978-2-7441-4644-4')
    assert checker.is_isbn_13() is False
    assert checker.is_isbn_10() is False
    checker = __ISBNChecker('978-0-306-40615-8')
    assert checker.is_isbn_13() is False
    assert checker.is_isbn_10() is False
    checker = __ISBNChecker('978-0-306-40615-0')
    assert checker.is_isbn_13() is False

# Generated at 2022-06-21 21:26:23.264332
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6("2001:db8:85a3:0000:0000:8a2e:370:7334") is True
    assert is_ip_v6("2001:db8:85a3:0000:0000:8a2e:370:?") is False


# Generated at 2022-06-21 21:26:35.255983
# Unit test for function is_number
def test_is_number():
    assert is_number('39.87') == True
    assert is_number('39') == True
    assert is_number('39.87') == True
    assert is_number('-39.87') == True
    assert is_number('-39') == True
    assert is_number('-39.87') == True
    assert is_number('39.87e10') == True
    assert is_number('39e10') == True
    assert is_number('3456456456') == True
    assert is_number('+3456456456') == True
    assert is_number('-3456456456') == True
    assert is_number('-3 5') == False
    assert is_number('3.5j') == False
    assert is_number(str()) == False
    assert is_number(object()) == False
   

# Generated at 2022-06-21 21:26:45.870725
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    assert __ISBNChecker('0123456789ab').is_isbn_13()
    assert __ISBNChecker('123456789ab').is_isbn_10()
    assert __ISBNChecker('978-7-115-21590-7').is_isbn_13()
    assert __ISBNChecker('978-7-121-15535-2').is_isbn_13()
    assert __ISBNChecker('978-7-5097-0983-2').is_isbn_13()
    assert __ISBNChecker('978-7-8909-1321-8').is_isbn_13()
    assert __ISBNChecker('978-7-302-37181-6').is_isbn_13()

# Generated at 2022-06-21 21:26:54.626163
# Unit test for function is_email
def test_is_email():
    assert is_email('') == False
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('abc"defghi"xyz@example.com') == True
    assert is_email('a..cdef@example.com') == False
    assert is_email('a\\ @example.com') == False
    assert is_email('a.@example.com') == False
    assert is_email('a"b(c)d,e:f;g<h>i[j\k]l@example.com') == True
    assert is_email('a.b\@example.com') == False

# Generated at 2022-06-21 21:26:56.315632
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('foo') == True


# Generated at 2022-06-21 21:27:00.050287
# Unit test for function is_number
def test_is_number():
    assert is_number("999999999")
    assert is_number("3.14")
    assert is_number("-2.1E10")
    assert not is_number("2b2")



# Generated at 2022-06-21 21:27:02.196719
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580')
    assert is_isbn('1506715214')
    assert is_isbn('978-0312498580')
    assert is_isbn('978-0312498580', normalize=False) is False

# Generated at 2022-06-21 21:27:03.726776
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75')
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334')
    assert not is_ip('1.2.3')
test_is_ip()



# Generated at 2022-06-21 21:27:06.397226
# Unit test for function is_isogram
def test_is_isogram():
    """  Implement a unit test for is_isogram """
    assert(is_isogram('hello') == False)
    assert(is_isogram('') == True)
    assert(is_isogram('dermatoglyphics') == True)


# Generated at 2022-06-21 21:27:17.946956
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert not __ISBNChecker('').is_isbn_13()
    assert __ISBNChecker('9788179925861').is_isbn_13()
    assert __ISBNChecker('9788179925861', normalize=False).is_isbn_13()
    assert __ISBNChecker('978-81219-035-9', normalize=False).is_isbn_13()
    assert not __ISBNChecker('978-81219-035-9', normalize=True).is_isbn_13()
    assert not __ISBNChecker('9788120303596', normalize=False).is_isbn_13()
    assert __ISBNChecker('978-81-203-0359-6', normalize=True).is_isbn_13()

# Generated at 2022-06-21 21:27:38.512481
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:0db8:0000:0000:0000:ff00:0042:8329') == True
    assert is_ip_v6('2001:db8:85a3:0:0:8a2e:370:7334') == True
    assert is_ip_v6('2001:db8:85a3::8a2e:370:7334') == True
    assert is_ip_v6('2001:0db8:0000:0000:0000:ff00:0042:8329') == True
    assert is_ip_v6('2001:db8:85a3:0:0:8a2e:370:7334') == True
    assert is_ip_v6('::ffff:192.0.2.128') == True

# Generated at 2022-06-21 21:27:45.401123
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case("hello_world")
    assert is_snake_case("hello_world", separator="-")
    assert is_snake_case("hello_world", separator="_")
    assert is_snake_case("hello-world")
    assert is_snake_case("hello-world", separator="-")
    assert is_snake_case("hello-world", separator="_")
    assert not is_snake_case("hello world")
    assert not is_snake_case("12345")
    assert not is_snake_case("hello_")
    assert not is_snake_case("_world")
    assert not is_snake_case("hello_world", separator="+")
    assert not is_snake_case("+world", separator="+")


# Generated at 2022-06-21 21:27:46.535219
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}')
test_is_json()    

# Generated at 2022-06-21 21:27:47.684319
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('my string is <strong>bold</strong>')
    assert not contains_html('my string is not bold')

# Generated at 2022-06-21 21:27:50.317167
# Unit test for function words_count
def test_words_count():
    assert words_count("one two three") == 3
    assert words_count("one,two,three.stop") == 4
    assert words_count("! @ # % ... []") == 0
    assert words_count("") == 0



# Generated at 2022-06-21 21:28:00.877938
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4929804463622139') == True
    assert is_credit_card('5555555555554444') == True
    assert is_credit_card('6011111111111117') == True
    assert is_credit_card('6011-1111-1111-1117') == True
    assert is_credit_card('38520000023237') == True
    assert is_credit_card('3530111333300000') == True
    assert is_credit_card('6228888888888888') == True
    assert is_credit_card('6228888888888888') == True

    assert is_credit_card('4929804463622139', 'VISA') == True
    assert is_credit_card('5555555555554444', 'MASTERCARD') == True


# Generated at 2022-06-21 21:28:05.158388
# Unit test for function is_url
def test_is_url():
    assert is_url('.mysite.com') == False, 'is_url() failed'
    assert is_url('https://mysite.com') == True, 'is_url() failed'


# Generated at 2022-06-21 21:28:09.819481
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False
test_is_ip_v4()



# Generated at 2022-06-21 21:28:11.101976
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580') == True

# Generated at 2022-06-21 21:28:19.429122
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-0-306-40615-7').is_isbn_13() == True
    assert __ISBNChecker('978-1-56619-909-4').is_isbn_13() == True
    assert __ISBNChecker('978-1-4028-9462-6').is_isbn_13() == True
    assert __ISBNChecker('978-1-904-198-58-5').is_isbn_13() == True
    assert __ISBNChecker('978-8-8471-9446-0').is_isbn_13() == True
    assert __ISBNChecker('978-0-253-21645-8').is_isbn_13() == True

# Generated at 2022-06-21 21:28:29.186569
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker("9351327015924").is_isbn_10() == False, "Test #1 failed"
    assert __ISBNChecker("9351327015921").is_isbn_10() == True, "Test #2 failed"
    assert __ISBNChecker("9351327015922").is_isbn_10() == False, "Test #3 failed"


# PUBLIC API



# Generated at 2022-06-21 21:28:31.964035
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title') == True
    assert is_slug('My blog post title') == False
test_is_slug()



# Generated at 2022-06-21 21:28:40.079394
# Unit test for function is_integer
def test_is_integer():
    assert is_integer("1") == True
    assert is_integer("0") == True
    assert is_integer("-1") == True
    assert is_integer("+1") == True
    assert is_integer("-1.1") == False
    assert is_integer("1.1") == False
    assert is_integer("0.0") == False
    assert is_integer("1e5") == True
    assert is_integer("-1e5") == True
    assert is_integer("+1e5") == True
    assert is_integer("1.1e5") == False
    assert is_integer("1.1.1e5") == False



# Generated at 2022-06-21 21:28:47.025917
# Unit test for function is_isbn
def test_is_isbn():
    print('Test for is_isbn')
    assert is_isbn('9780312498580') == True
    assert is_isbn('1506715214') == True
    assert is_isbn('978-0312498580') == True
    assert is_isbn('978-0312498580', normalize=False) == False
    assert is_isbn('150-6715214', normalize=False) == False



# Generated at 2022-06-21 21:28:47.972402
# Unit test for function is_number
def test_is_number():
    assert is_number('') == False



# Generated at 2022-06-21 21:28:49.521562
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('034911822X').is_isbn_10()


# PUBLIC API


# Generated at 2022-06-21 21:29:01.506696
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('MyString') == False
    assert is_snake_case('mystring') == False
    assert is_snake_case('my_string') == True
    assert is_snake_case('my_string_') == True
    assert is_snake_case('my_string_2_') == True
    assert is_snake_case('_my_string') == True
    assert is_snake_case('_') == True
    assert is_snake_case('__') == True
    assert is_snake_case('___') == True
    assert is_snake_case('string_') == False
    assert is_snake_case('_string') == True
    assert is_snake_case('9_string_') == False

# Generated at 2022-06-21 21:29:08.717606
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    # Set up
    class TestClass:
        def __init__(self):
            # invalid input string
            try:
                __ISBNChecker(-1)
                assert False, 'Expected InvalidInputError!'
            except InvalidInputError:
                pass

            # isbn 13 valid
            assert __ISBNChecker('9789898989898').is_isbn_13()

            # isbn 13 invalid
            assert not __ISBNChecker('9789898989897').is_isbn_13()

            # isbn 10 valid
            assert __ISBNChecker('9898989898').is_isbn_10()

            # isbn 10 invalid
            assert not __ISBNChecker('9898989897').is_isbn_10()
    # Run unit tests

    # Clean up - none necessary
    return True

# Generated at 2022-06-21 21:29:14.607157
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('LOL') == True
    assert is_palindrome('Lol') == False
    assert is_palindrome('Lol', ignore_case=True) == True
    assert is_palindrome('ROTFL') == False
    return print('Test passed!')

test_is_palindrome()


# Generated at 2022-06-21 21:29:17.976984
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6("2001:db8:85a3:0000:0000:8a2e:370:7334")
    assert is_ip_v6("2001:db8:85a3:0000:0000:8a2e:370:7334")


# Generated at 2022-06-21 21:29:34.648414
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email+foo@the-provider.com')
    assert is_email('my.email+foo.bar@the-provider.com')
    assert is_email('my.email.foo@the-provider.com')
    assert is_email('"my.email@the-provider.com"@the-provider.com')
    assert is_email('"my.e\\ mail@the-provider.com"@the-provider.com')
    assert is_email('"my.e\\m\\a\\i\\l@the-provider.com"@the-provider.com')

# Generated at 2022-06-21 21:29:38.095489
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?') == False


# Generated at 2022-06-21 21:29:42.094203
# Unit test for function words_count
def test_words_count():
    assert words_count('hello world') == 2
    assert words_count('hello, world') == 2
    assert words_count('hello.world') == 2
    assert words_count('one,two,three') == 3
    assert words_count('one,two,three.stop') == 4
    assert words_count('one-two-three') == 3
    assert words_count('one') == 1
    assert words_count('one,two,three-stop.') == 4
    assert words_count('hello, world!') == 2
    assert words_count('hello world!?') == 2
    assert words_count('hello') == 1
    assert words_count('hello !') == 1
    assert words_count('Hello World!') == 2
    assert words_count('Hello World') == 2
    assert words_count('HelloWorld')

# Generated at 2022-06-21 21:29:48.055420
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    # GIVEN
    normalizations = [True, False]
    check_results = [True, False, False, False, False, False]
    # WHEN
    check_inputs = [
        '978-0-306-40615-7', '978-0-3064-0615-7',
        '978-0-306-40615-8', '978-0-3064-0615-7',
        '978-0-306-40615-4', '978-0-3064-0615-7',
    ]
    check_results = zip(check_inputs, check_results, normalizations)
    # THEN

# Generated at 2022-06-21 21:29:55.602641
# Unit test for function is_palindrome
def test_is_palindrome():
    assert(is_palindrome("otto") == True)
    assert(is_palindrome("yay") == False)
    assert(is_palindrome("rotor") == True)
    assert(is_palindrome("I topi non avevano nipoti") == True)
    assert(is_palindrome("I topi avevano nipoti") == False)
    
test_is_palindrome()

# Generated at 2022-06-21 21:30:05.476486
# Unit test for function is_url
def test_is_url():
    assert not is_url(None)
    assert not is_url('http:www.mysite.com')
    assert is_url('http://www.mysite.com')
    assert is_url('https://mysite.com')
    assert is_url('ftp://www.mysite.com')
    assert is_url('http://www.mysite-with-dash.com')
    assert not is_url('http:/www.mysite.com')
    assert not is_url('http://')
    assert not is_url('http://www.')
    assert not is_url('.mysite.com')
    assert not is_url('@mysite.com')
    assert not is_url('test@mysite.com')
    assert not is_url('http://www.mysite.com@')

# Generated at 2022-06-21 21:30:09.561729
# Unit test for function is_uuid
def test_is_uuid():
    print(is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf'))
    print(is_uuid('6f8aa2f9686c4ac387665712354a04cf'))
    print(is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True))
test_is_uuid()



# Generated at 2022-06-21 21:30:13.634979
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('My2String') == True
    assert is_camel_case('MyString') == True
    assert is_camel_case('myString') == False
    assert is_camel_case('2MyString') == False
    assert is_camel_case('my2String') == False


# Generated at 2022-06-21 21:30:19.287987
# Unit test for function is_palindrome
def test_is_palindrome():
    string1 = "otto"
    string2 = "I topi non avevano nipoti"
    string3 = "Rotfl"
    assert is_palindrome(string1, ignore_spaces=True, ignore_case=False)
    assert is_palindrome(string2, ignore_spaces=False, ignore_case=True)
    assert is_palindrome(string3, ignore_spaces=True, ignore_case=True)
    assert not is_palindrome(string1, ignore_spaces=True, ignore_case=True)
    assert not is_palindrome(string2, ignore_spaces=True, ignore_case=True)
    assert not is_palindrome(string3, ignore_spaces=True, ignore_case=False)

# Generated at 2022-06-21 21:30:28.389251
# Unit test for function is_json
def test_is_json():
    assert is_json({"name": "Peter"}) == True
    assert is_json([1, 2, 3]) == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('') == False
    assert is_json('{nope}') == False
    assert is_json('{}') == True
    assert is_json('[]') == True
# Test function is_json() with decorator

# Generated at 2022-06-21 21:30:34.476599
# Unit test for function words_count
def test_words_count():
    assert words_count('hello world') == 2
    assert words_count('one,two,three.stop') == 4


# Generated at 2022-06-21 21:30:38.569773
# Unit test for function is_json
def test_is_json():
    assert is_json('{"a": 1, "b": "str", "c": null}') is True
    assert is_json('[1, 2, 3]') is True
    assert is_json('1, 2, 3') is False

# TODO: Validate a GUID.
# is_guid



# Generated at 2022-06-21 21:30:40.079066
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title')
    assert not is_slug('My blog post title')
    assert not is_slug('  Really tidy slug like the title of a movie  ')


# Generated at 2022-06-21 21:30:42.608659
# Unit test for function is_decimal
def test_is_decimal():
    assert False == is_decimal('42')
    assert True == is_decimal('42.0')


# Generated at 2022-06-21 21:30:54.293302
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.emailthe-provider.com') == False
    assert is_email('my.email.@the-provider.com') == False
    assert is_email('my.email.@the-provider..com') == False
    assert is_email('my.email.@the-provider.com.') == False
    assert is_email('my.email.@.the-provider.com') == False
    assert is_email('my.email..@the-provider.com') == False
    assert is_email('my.email.@the-provider.c') == False

# Generated at 2022-06-21 21:31:02.111857
# Unit test for function is_email
def test_is_email():
    assert is_email('mail@a.com') 
    assert is_email('a@mail.com') 
    assert is_email('a@a.mail.com') 
    assert is_email('someone.with.dots@g.cn') 
    assert is_email('"someone.with.dots"@g.cn') 

    assert is_email('a.@mail.com') == False
    assert is_email('a@mail..com') == False
    assert is_email('a@mail.com ') == False
    assert is_email('a@mail@com ') == False
    assert is_email('a@@mail.com ') == False
    assert is_email('someone.with.dots@g.cn ') == False
    assert is_email('') == False
    assert is_

# Generated at 2022-06-21 21:31:13.705349
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('1') == True
    assert is_integer('-2') == True
    assert is_integer('3.0') == False
    assert is_integer('4a') == False
    assert is_integer('b5') == False
    assert is_integer('c6') == False
    assert is_integer('d7') == False
    assert is_integer('e8') == False
    assert is_integer('f9') == False
    assert is_integer('10') == True
    assert is_integer('11') == True
    assert is_integer('12') == True
    assert is_integer('12a') == False
    assert is_integer('') == False
    assert is_integer(' ') == False

test_is_integer()



# Generated at 2022-06-21 21:31:24.565752
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    print('\n===test___ISBNChecker_is_isbn_10===')
    print('Testing edge cases in _ISBNChecker_is_isbn_10:')
    ic = __ISBNChecker('2266111566')
    assert ic.is_isbn_10() == True
    ic = __ISBNChecker('0000000001')
    assert ic.is_isbn_10() == True
    ic = __ISBNChecker('0000000000')
    assert ic.is_isbn_10() == False
    ic = __ISBNChecker('1234567890')
    assert ic.is_isbn_10() == False
    ic = __ISBNChecker('123456789')
    assert ic.is_isbn_10() == False

# Generated at 2022-06-21 21:31:28.719380
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') == True
    assert is_isbn_10('150-6715214') == True
    assert is_isbn_10('150-6715214', normalize=False) == False

# Generated at 2022-06-21 21:31:31.204328
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('dermatoglyphics') == True
    assert is_isogram('Dermatoglyphics') == False
    assert is_isogram('hello') == False




# Generated at 2022-06-21 21:31:46.177494
# Unit test for function is_slug
def test_is_slug():
    # Positive cases
    assert is_slug('my-blog-post-title')
    assert is_slug('my-blog-post-title-with-dashes')
    # Negative cases
    assert not is_slug('My blog post title')
    assert not is_slug('My blog post title')
    assert not is_slug('My+blog+post+title')
    assert not is_slug('My blog, post title')
    assert not is_slug('My blog; post title')
    assert not is_slug('')
    assert not is_slug(None)


# Generated at 2022-06-21 21:31:57.025396
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('978-0312498580')
    assert is_isbn('9780312498580')
    assert is_isbn('1506715214')
    assert is_isbn('150-6715214')
    assert not is_isbn('978-0312498580', False)
    assert not is_isbn('9780312498580', False)
    assert not is_isbn('1506715214', False)
    assert not is_isbn('150-6715214', False)

    assert not is_isbn('978-0312498580', True)
    assert not is_isbn('9780312498580', True)
    assert not is_isbn('1506715214', True)
    assert not is_isbn('150-6715214', True)
   

# Generated at 2022-06-21 21:31:58.840768
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('HelloWorld')



# Generated at 2022-06-21 21:32:10.100298
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') == True, 'Should return true'
    assert is_url('https://mysite.com') == True, 'Should return true'
    assert is_url('mysite.com') == True, 'Should return true'
    assert is_url('.mysite.com') == False, 'Should return false'
    assert is_url('www.mysite.com') == False, 'Should return false'
    assert is_url('') == False, 'Should return false'
    assert is_url('http://www.mysite.com', allowed_schemes=['http']) == True, 'Should return true'
    assert is_url('https://mysite.com', allowed_schemes=['http']) == False, 'Should return false'

# Generated at 2022-06-21 21:32:14.953969
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0316769487').is_isbn_10() == True
    assert __ISBNChecker('8129105769').is_isbn_10() == True
    assert __ISBNChecker('1416949658').is_isbn_10() == True


# PUBLIC API



# Generated at 2022-06-21 21:32:16.805007
# Unit test for function is_string
def test_is_string():
    assert is_string('foo')
    assert not is_string(b'foo')


# Generated at 2022-06-21 21:32:18.950018
# Unit test for function is_isbn_13
def test_is_isbn_13():
    string = '978-0312498580'
    normalize = True
    assert is_isbn_13(string, normalize) == True


# Generated at 2022-06-21 21:32:29.668212
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf')
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True)
    assert not is_uuid('6f8aa2f9686c4ac387665712354a04cf')
    assert not is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=False)
    assert is_uuid(uuid.uuid4())
    assert not is_uuid(uuid.uuid4(), allow_hex=True)

test_is_uuid()


# Generated at 2022-06-21 21:32:35.982243
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75') is True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') is True
    assert is_ip('1.2.3') is False
test_is_ip()
 
# Full url example:
# scheme://username:password@www.domain.com:8042/folder/subfolder/file.extension?param=value&param2=value2#hash

# Generated at 2022-06-21 21:32:44.244173
# Unit test for function is_email
def test_is_email():
    assert is_email('"Abc\@def"@example.com') == True
    assert is_email('"Fred Bloggs"@example.com') == True
    assert is_email('"Joe\\Blow"@example.com') == True
    assert is_email('"Abc@def"@example.com') == True
    assert is_email('customer/department=shipping@example.com') == True
    assert is_email('$A12345@example.com') == True
    assert is_email('!def!xyz%abc@example.com') == True
    assert is_email('_somename@example.com') == True
    assert is_email('valid@special.museum') == True
    assert is_email('valid@localhost') == True

# Generated at 2022-06-21 21:33:02.425705
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog')
    assert not is_pangram('hello world')
    assert is_pangram('abcdefghijklmnopqrstuvwxyz')
    assert not is_pangram('ABCDEFGHIJKLMNOPQRSTUVWXYZ')
    assert is_pangram('The five boxing wizards jump quickly.')
    assert not is_pangram('The quick onyx goblin jumps over the lazy dwarf.')
    assert is_pangram('Grumpy wizards make toxic brew for the evil queen and jack.')
    assert not is_pangram('Not a pangram')

# Generated at 2022-06-21 21:33:06.512269
# Unit test for function words_count
def test_words_count():
    assert words_count('one,two,three.stop') == 4
    assert words_count('one one one') == 1
    assert words_count('! @ # % ... []') == 0
    
    
test_words_count()

# Generated at 2022-06-21 21:33:14.077441
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('978-3-16-148410-0')
    assert is_isbn('9783161484100')
    assert is_isbn('9783161484100', normalize=True)
    assert is_isbn('978-316-1484100', normalize=True)
    assert is_isbn('9783161484100', normalize=False)
    assert is_isbn('-0-12-352618-8')
    assert is_isbn('0-12-352618-8')
    assert is_isbn('0-12-352618-7')
    assert not is_isbn('978-0-12-352618-7')
    assert not is_isbn('978 0 12 352618 7')

# Generated at 2022-06-21 21:33:17.258733
# Unit test for function is_string
def test_is_string():
    assert is_string('foo')
    assert is_string('0123')
    assert not is_string(b'foo')
    assert not is_string(None)


# Generated at 2022-06-21 21:33:21.133267
# Unit test for function is_json
def test_is_json():
    assert(is_json('{"name": "Peter"}') == True)
    assert(is_json('[1, 2, 3]') == True)
    assert(is_json('{nope}') == False)
    
#test_is_json()

