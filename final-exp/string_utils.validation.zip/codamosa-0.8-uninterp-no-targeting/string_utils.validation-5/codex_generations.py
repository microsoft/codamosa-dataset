

# Generated at 2022-06-21 21:23:49.892629
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?') == False
    assert is_ip_v6('2001:db8:85a3:0000::8a2e:370:7334') == True
    assert is_ip_v6('2001:db8:85a3::8a2e:370:7334') == True
    assert is_ip_v6('2001:db8:85a3::8a2e:370:') == False
    assert is_ip_v6('2001:db8:85a3::8a2e:7334') == True
    assert is_ip_v6

# Generated at 2022-06-21 21:24:01.567185
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('abccba')
    assert is_palindrome('A man, a plan, a canal. Panama')
    assert is_palindrome('Dammit, I\'m mad!')
    assert is_palindrome('')
    assert is_palindrome('ab')

    assert not is_palindrome('nan')
    assert not is_palindrome('hello')

    # Test unicode
    assert is_palindrome('А роза упала на лапу Азора')
    assert is_palindrome('αρτι παυσανε οι δε νυν αφηνεν αρτι')

# Generated at 2022-06-21 21:24:06.497555
# Unit test for function words_count
def test_words_count():
    assert words_count('hello world') == 2
    assert words_count('one,two,three.stop') == 4



# Generated at 2022-06-21 21:24:12.320770
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-title') == True
    assert is_slug('my-blog-title-') == True
    assert is_slug('my-blog-title--') == True
    assert is_slug('') == False
    assert is_slug('myblogtitle') == False
    assert is_slug('my_blog-title') == False
    assert is_slug('my-blog-title',separator='_') == False


# Generated at 2022-06-21 21:24:15.461692
# Unit test for function words_count
def test_words_count():
    string_to_test = 'one two three four'
    print('test words_count: {}'.format(words_count(string_to_test)))


NEVER = 0
SOMETIMES = 1
ALWAYS = 2



# Generated at 2022-06-21 21:24:25.518302
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn(input_string = '9780312498580') == True
    assert is_isbn(input_string = '1506715214') == True
    assert is_isbn(input_string = '978-0312498580', normalize = True) == True
    assert is_isbn(input_string = '978-0312498580', normalize = False) == False
    assert is_isbn(input_string = '150-6715214', normalize = True) == True
    assert is_isbn(input_string = '150-6715214', normalize = False) == False
test_is_isbn()



# Generated at 2022-06-21 21:24:29.909896
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10(): 
    print("test___ISBNChecker_is_isbn_10")
    ic = __ISBNChecker("1234567890")
    res = ic.is_isbn_10()
    assert(res)

test___ISBNChecker_is_isbn_10()


# PUBLIC API



# Generated at 2022-06-21 21:24:33.927546
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    # Arrange
    input_string = '9780439136369'

    # Act
    valid = __ISBNChecker(input_string=input_string).is_isbn_13()

    # Assert
    assert valid is True


# Generated at 2022-06-21 21:24:38.632364
# Unit test for function is_string
def test_is_string():
    assert is_string('foo')
    assert not is_string([])
    assert not is_string(42)
    assert not is_string(42.0)
    assert not is_string(None)
    assert not is_string(b'foo')
    assert not is_string({'foo': 'bar'})
    assert not is_string(())
test_is_string()



# Generated at 2022-06-21 21:24:43.301078
# Unit test for function words_count
def test_words_count():
    # TODO (Testing): implement unit tests for function words_count
    assert words_count('Hello world') == 2
    assert words_count('one,two,three.stop') == 4
    assert words_count('! @ # % ... []') == 0
    assert isinstance(words_count('Il mio pc costa 400 eur'), int)
    #assert words_count('Il mio pc costa 400 eur') == 4
    assert words_count(123) == 0

# Generated at 2022-06-21 21:24:56.552108
# Unit test for function is_number
def test_is_number():
    assert is_number('42') == True
    assert is_number('19.99') == True
    assert is_number('-9.12') == True
    assert is_number('1e3') == True
    assert is_number('') == False



# Generated at 2022-06-21 21:25:06.012828
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('978-1-60309-453-5') == True
    assert is_isbn_10('978-1-60309-453-5', normalize=False) == False
    assert is_isbn_10('978.1.60309.453.5') == True
    assert is_isbn_10('978-1.60309.453-5') == True
    assert is_isbn_10('978-1.60309.453') == False
    assert is_isbn_10('1.60309.453-5') == False
    assert is_isbn_10('a.60309.453-5') == False
    assert is_isbn_10('1.60309.45a') == False
    assert is_isbn_10('a.60309.45a') == False

# Generated at 2022-06-21 21:25:08.681129
# Unit test for function contains_html
def test_contains_html():
    assert contains_html("<strong>hello</strong>") == True
    assert contains_html("Hello") == False
contains_html("<strong>hello</strong>")


# Generated at 2022-06-21 21:25:12.546849
# Unit test for function is_json
def test_is_json():
	assert is_json('{"name": "Peter"}')
	assert not is_json('{"name": "Peter"')
	assert not is_json('{"name": "Peter]')

# Generated at 2022-06-21 21:25:24.098210
# Unit test for function is_credit_card
def test_is_credit_card():
    print('\nTesting is_credit_card')
    assert is_credit_card('4111111111111111')
    assert is_credit_card('41111111111111111', card_type='VISA')
    assert is_credit_card('411111111111111111', card_type='VISA')
    assert is_credit_card('4012888888881881', card_type='VISA')
    assert is_credit_card('4222222222222')
    assert is_credit_card('5555555555554444')
    assert is_credit_card('5105105105105100')
    assert is_credit_card('371449635398431')
    assert is_credit_card('378282246310005')

# Generated at 2022-06-21 21:25:26.095784
# Unit test for function is_string
def test_is_string():
    assert is_string('foo') == True
    assert is_string(b'foo') == False

# Generated at 2022-06-21 21:25:28.288295
# Unit test for function is_string
def test_is_string():
    assert is_string('foo')
    assert not is_string(b'foo')


# Generated at 2022-06-21 21:25:30.190301
# Unit test for function is_json
def test_is_json():
    assert is_json(None) == False
    assert is_json('') == False
    assert is_json('{}') == False
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False



# Generated at 2022-06-21 21:25:39.540292
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('0.0.0.0') == True
    assert is_ip_v4('255.255.255.255') == True
    assert is_ip_v4('10.0.0.1') == True
    assert is_ip_v4('192.168.0.10') == True
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-21 21:25:50.736939
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card("1234567890123456", "VISA")
    assert not is_credit_card("12345678901234567","VISA")
    assert is_credit_card("1234567890123456", "AMERICAN_EXPRESS")
    assert not is_credit_card("12345678901234567","AMERICAN_EXPRESS")
    assert is_credit_card("1234567890123456", "DISCOVER")
    assert not is_credit_card("12345678901234567","DISCOVER")
    assert is_credit_card("1234567890123456", "DINERS_CLUB")
    assert not is_credit_card("12345678901234567","DINERS_CLUB")

# Generated at 2022-06-21 21:26:05.084428
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') == True
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf') == False
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True) == True



# Generated at 2022-06-21 21:26:11.375634
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False
    assert is_json('{nope') == False
    assert is_json('nope}') == False
    assert is_json('42') == False
    assert is_json(42) == False
    assert is_json('') == False
    assert is_json('{")') == False
    assert is_json('{"a": "1", "b": "2"}') == True
    assert is_json('{"a": "1", "b": [1, 2], "c": {"x": "2", "y": "3"}}') == True

# Generated at 2022-06-21 21:26:21.552583
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42') == True
    assert is_integer('-42') == True
    assert is_integer('42.0') == False
    assert is_integer('3e4') == True
    assert is_integer('3.14159') == False
    assert is_integer('0.0314e2') == False
    assert is_integer('-3E-2') == False
    assert is_integer('00042') == True
    assert is_integer('') == False
    assert is_integer('-0o123') == False
    assert is_integer('-0x123') == False
    assert is_integer('+0o123') == False
    assert is_integer('+0x123') == False
    assert is_integer('-98765432100') == True

# Generated at 2022-06-21 21:26:28.021907
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('foo_bar_baz', '_') # returns true
    assert is_snake_case('foo_bar_baz', '-') # returns false
    assert is_snake_case('foo-bar-baz', '-') # returns true
    assert is_snake_case('foo_bar-baz', '-') # returns false
    assert is_snake_case('foo-bar-baz') # returns true
    assert is_snake_case('foo_bar-baz') # returns false



# Generated at 2022-06-21 21:26:32.516397
# Unit test for function is_isbn_10
def test_is_isbn_10():
    ret = is_isbn_10('1506715214')
    assert ret == True
    ret = is_isbn_10('150-6715214')
    assert ret == True
    ret = is_isbn_10('150-6715214', normalize=False)
    assert ret == False

# Generated at 2022-06-21 21:26:35.697233
# Unit test for function is_number
def test_is_number():
    assert is_number('42')
    assert is_number('19.99')
    assert is_number('-9.12')
    assert is_number('1e3')
    assert is_number('1 2 3') is False


# Generated at 2022-06-21 21:26:43.271771
# Unit test for function is_isbn
def test_is_isbn():
    
    result = is_isbn("978-0312498580")
    assert not result == True
    result = is_isbn("9780312498580")
    assert result == True
    result = is_isbn("1506715214")
    assert result == True

    try:
        result = is_isbn("9780312498580", normalize = False)
        assert result == False

    except:
        result = assert_raises(is_isbn, ValueError)
        if result is not False:
            raise Exception("Expected FALSE")

test_is_isbn()

# Generated at 2022-06-21 21:26:50.849666
# Unit test for function is_string
def test_is_string():
    # Test 1:
    # Arrange
    test_args = ['foo']
    # Act
    actual = is_string(*test_args)
    # Assert
    assert actual == True, 'is_string(*test_args) should have returned True'

    # Test 2:
    # Arrange
    test_args = [b'foo']
    # Act
    actual = is_string(*test_args)
    # Assert
    assert actual == False, 'is_string(*test_args) should have returned False'



# Generated at 2022-06-21 21:26:57.649782
# Unit test for function is_number
def test_is_number():
    assert is_number('42') == True
    assert is_number('1234') == True
    assert is_number('3.14') == True
    assert is_number('-3.14') == True
    assert is_number('-.14') == True
    assert is_number('-2') == True
    assert is_number('1.0') == True
    assert is_number('1.00') == True
    assert is_number('1.000') == True
    assert is_number('1.0e4') == True
    assert is_number('1e4') == True
    assert is_number('-1e4') == True
    assert is_number('1E4') == True
    assert is_number('1e-4') == True
    assert is_number('1e4') == True
    assert is_

# Generated at 2022-06-21 21:26:58.874339
# Unit test for function is_isbn
def test_is_isbn():
    assert not is_isbn('9780312498580')
    assert not is_isbn('1506715214')

# Generated at 2022-06-21 21:27:18.288232
# Unit test for function is_number
def test_is_number():
    assert is_number("12") == True
    assert is_number("-12") == True
    assert is_number("-12.0") == True
    assert is_number("12.0") == True
    assert is_number("0.5") == True
    assert is_number("2e8") == True
    assert is_number("2e-8") == True
    assert is_number("2.1e8") == True
    assert is_number("2.1e-8") == True
    assert is_number("2.1e+8") == True
    assert is_number("123.456") == True
    assert is_number("1.0e+2") == True
    assert is_number("0b11001") == False
    assert is_number("0x2345") == False
    assert is_number

# Generated at 2022-06-21 21:27:20.071292
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580')
    assert is_isbn('1506715214')
    assert not is_isbn('978-0312498580', normalize=False)
    assert not is_isbn('150-6715214', normalize=False)

# Generated at 2022-06-21 21:27:21.754204
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') == True
    assert is_isbn('1506715214') == True
    assert is_isbn('9780312498580', False) == False
    assert is_isbn('1506715214', False) == False
test_is_isbn()



# Generated at 2022-06-21 21:27:30.353934
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    messages = [
        "TEST FAILED: __ISBNChecker: constructor: should raise InvalidInputError when input is not a string",
        "TEST FAILED: __ISBNChecker: constructor: should not raise InvalidInputError when input is a string",
    ]

    def test_case_1():
        try:
            __ISBNChecker(123)
        except InvalidInputError:
            return True
        except Exception as e:
            print(e)
            return False

    def test_case_2():
        try:
            __ISBNChecker("123")
            return True
        except Exception as e:
            print(e)
            return False

    results = [
        test_case_1(),
        test_case_2(),
    ]

    return results, messages



# Generated at 2022-06-21 21:27:33.049914
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('my string is <strong>bold</strong>') == True
    assert contains_html('my string is not bold') == False

test_contains_html()



# Generated at 2022-06-21 21:27:35.248528
# Unit test for function is_email
def test_is_email():
    assert is_email('foobar@gmail.com') == True
    assert is_email('foobar@gmail.com') == False



# Generated at 2022-06-21 21:27:37.113343
# Unit test for function is_string
def test_is_string():
    assert is_string('a') == True
    assert is_string(b'a') == False
    assert is_string(1) == False


# Generated at 2022-06-21 21:27:48.595029
# Unit test for function words_count
def test_words_count():
    """
    Tests words count function.
    """
    assert words_count("one,two,three.stop") == 4
    assert words_count("! @ # % ... []") == 0
    assert words_count("Hello/World") == 2
    assert words_count("Hello. World") == 2
    assert words_count("Hello") == 1
    assert words_count("Hello,World") == 2
    assert words_count("Hello, World") == 2
    assert words_count("Hello, \n World") == 2
    assert words_count("Hello,\nWorld") == 2
    assert words_count("Hello\nWorld") == 2
    assert words_count("Hello, \n \n World") == 2
    assert words_count("Hello,\n\nWorld") == 2

# Generated at 2022-06-21 21:27:59.543951
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4111 1111 1111 1111')
    assert is_credit_card('4111111111111111')
    assert is_credit_card('5500 0000 0000 0004')
    assert is_credit_card('5500000000000004')
    assert is_credit_card('3782 822463 10005')
    assert is_credit_card('378282246310005')
    assert is_credit_card('6011 1111 1111 1117')
    assert is_credit_card('6011111111111117')
    assert is_credit_card('3056 9309 0259 04')
    assert is_credit_card('30569309025904')
    assert is_credit_card('3852 0000 0232 37')
    assert is_credit_card('38520000023237')
    assert is_credit_card

# Generated at 2022-06-21 21:28:06.810442
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    checker = __ISBNChecker('978-0-306-40615-7')
    assert checker.is_isbn_13() == True
    checker = __ISBNChecker('978 0 306 40615 7')
    assert checker.is_isbn_13() == True
    checker = __ISBNChecker('0735666021')
    assert checker.is_isbn_13() == False


# Generated at 2022-06-21 21:28:22.168180
# Unit test for function is_palindrome
def test_is_palindrome():
    assert(is_palindrome('otto'))
    assert(is_palindrome('i topi non avevano nipoti'))
    assert(not is_palindrome('i topi non avevano nipoti', ignore_spaces=True))
    assert(is_palindrome('i topi non avevano nipoti', ignore_case=True))
    assert(is_palindrome('ROTFL', ignore_case=True))
    assert(is_palindrome('Amore, Roma.', ignore_spaces=True))
    assert(is_palindrome('A man, a plan, a canal: Panama'))
    assert(not is_palindrome('Amor, Roma.'))

# Generated at 2022-06-21 21:28:30.372947
# Unit test for function is_credit_card
def test_is_credit_card():
    assert not is_credit_card('credit_card')
    assert not is_credit_card('')
    assert not is_credit_card('123')
    assert not is_credit_card('423423')
    assert is_credit_card('4234234567897693')
    assert is_credit_card('4234234567897693', 'VISA')
    assert is_credit_card('4234234567897693', card_type='VISA')
    assert is_credit_card('2223005678901229', 'MASTERCARD')
    assert is_credit_card('2223005678901229', card_type='MASTERCARD')
    assert is_credit_card('34234234234234', 'AMERICAN_EXPRESS')

# Generated at 2022-06-21 21:28:32.912412
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('MyString') == True
    assert is_camel_case('myString') == True


# Generated at 2022-06-21 21:28:41.680167
# Unit test for function is_palindrome
def test_is_palindrome():
    print("TEST PALINDROME")
    assert is_palindrome('LOL') == True
    assert is_palindrome('Lol') == False
    assert is_palindrome('Lol', ignore_case=True) == True
    assert is_palindrome('Lol', ignore_spaces=True, ignore_case=True) == True
    assert is_palindrome('ROTFL') == False
    assert is_palindrome('otto') == True
    assert is_palindrome('i i') == False
    assert is_palindrome('i pi') == False
    assert is_palindrome('i topi non avevano nipoti') == False
    assert is_palindrome('i topi non avevano nipoti', ignore_spaces=True) == True
    assert is_

# Generated at 2022-06-21 21:28:43.182526
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('') == False



# Generated at 2022-06-21 21:28:55.569945
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:0db8:85a3:0000:0000:8a2e:0370:7334') == True
    assert is_ip_v6('2001:0db8:85a3:0000:0000:8a2e:0370:?') == False
    assert is_ip_v6('2001:0db8:85a3:0000:0000:8a2e:0370:012') == True
    assert is_ip_v6('2001:0db8:85a3:0000:0000:8a2e:0370::') == True
    assert is_ip_v6('2001:0db8:85a3::0000:8a2e:0370:7334') == True

# Generated at 2022-06-21 21:29:05.677450
# Unit test for function is_credit_card
def test_is_credit_card():

    assert is_credit_card('4306873942134') == True
    assert is_credit_card('299792458') == False
    assert is_credit_card('5.5') == False
    assert is_credit_card('4111111111111111') == True
    assert is_credit_card('4111111111111') == False
    assert is_credit_card('401288888888188f') == False
    assert is_credit_card('378282246310005') == True
    assert is_credit_card('6011111111111117') == True
    assert is_credit_card('5105105105105100') == True
    #assert is_credit_card('5105 1051 0510 5106') == False
    #assert is_credit_card('9111111111111111') == False
    assert is_credit_

# Generated at 2022-06-21 21:29:10.324465
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('MyString')
    assert is_camel_case('MyString2')
    assert is_camel_case('mystring') is False
    assert is_camel_case('') is False
    assert is_camel_case('1MyString') is False



# Generated at 2022-06-21 21:29:15.079526
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string(None) == False
    assert is_full_string("") == False
    assert is_full_string(" ") == False
    assert is_full_string("hello") == True
#test_is_full_string()



# Generated at 2022-06-21 21:29:22.291308
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    checker = __ISBNChecker('9781853260087')
    assert checker.input_string == '9781853260087'
    checker = __ISBNChecker('978-1-8532-6008-7')
    assert checker.input_string == '9781853260087'
    try:
        checker = __ISBNChecker(None)
        assert checker.input_string == '9781853260087'
    except InvalidInputError:
        pass
    try:
        checker = __ISBNChecker('9781853260087', False)
        assert checker.input_string == '9781853260087'
    except InvalidInputError:
        pass

test___ISBNChecker()


# Generated at 2022-06-21 21:29:35.701906
# Unit test for function words_count
def test_words_count():
    assert words_count('hello world') == 2
    assert words_count('one, two, three. stop') == 4
    assert words_count('one,two,three.stop') == 4
    assert words_count('') == 0
    assert words_count(' !@#$%^&*') == 0
    assert words_count('\n  ! * _ *%#') == 0
test_words_count()

# Generated at 2022-06-21 21:29:36.772013
# Unit test for function words_count
def test_words_count():
    assert words_count('hello world') == 2
    assert words_count('one,two,three.stop') == 4

# Generated at 2022-06-21 21:29:42.862205
# Unit test for function is_number
def test_is_number():
    assert is_number('42')
    assert is_number('19.99')
    assert is_number('-9.12')
    assert is_number('1e3')

    assert not is_number('1 2 3'), 'must not be a number'
    assert not is_number('foo'), 'must not be a number'



# Generated at 2022-06-21 21:29:46.462359
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string(None) is False
    assert is_full_string('') is False
    assert is_full_string(' ') is False
    assert is_full_string('hello') is True

# Generated at 2022-06-21 21:29:59.254532
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome("otto") == True
    assert is_palindrome("i topi non avevano nipoti") == False
    assert is_palindrome("i topi non avevano nipoti", ignore_spaces=True) == True
    assert is_palindrome("Otto") == False
    assert is_palindrome("Otto", ignore_case=True) == True
    assert is_palindrome("") == False
    assert is_palindrome(" ") == False
    assert is_palindrome(" aba ") == True
    assert is_palindrome(" aba ", ignore_spaces=True) == True
    assert is_palindrome(" abA ") == False
    assert is_palindrome(" abA ", ignore_case=True) == True




# Generated at 2022-06-21 21:30:09.025325
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    assert __ISBNChecker('9780321508520')


# PUBLIC API


# -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-#
#                                                                                                                   #
#                                              GENERAL TYPES CHECK                                                 #
#                                                                                                                   #
# -:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-#

# Check if input is a string

# Generated at 2022-06-21 21:30:13.161805
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    # checker = __ISBNChecker("")
    # assert_equals(checker.is_isbn_10(), None)
    checker = __ISBNChecker("978-04650-2262-1")
    assert_equals(checker.is_isbn_10(), True)


# PUBLIC API



# Generated at 2022-06-21 21:30:23.196673
# Unit test for function is_string
def test_is_string():
    assert is_string('') == True
    assert is_string('1') == True
    assert is_string('foobar') == True
    assert is_string('foo bar') == True
    assert is_string('  foo bar  ') == True
    assert is_string('FooBar') == True
    assert is_string('FooBarBaz') == True
    assert is_string('f') == True
    assert is_string('fo') == True
    assert is_string('foo') == True
    assert is_string(b'foo') == False
    assert is_string(True) == False
    assert is_string(False) == False
    assert is_string(0) == False
    assert is_string(1) == False
    assert is_string(0.0) == False

# Generated at 2022-06-21 21:30:36.152028
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my_blog_post_title', '_') == True
    assert is_slug('9_blog_post_title', '_') == True
    assert is_slug('blog_post_title_9', '_') == True
    assert is_slug('my-blog-post-title', '-') == True
    assert is_slug('9-blog-post-title', '-') == True
    assert is_slug('blog-post-title-9', '-') == True
    assert is_slug('my_blog_post_title', '-') == False
    assert is_slug('my-blog-post-title', '_') == False
    assert is_slug('my-blog-post--title', '-') == False

# Generated at 2022-06-21 21:30:37.594464
# Unit test for function words_count
def test_words_count():
    assert words_count("hello world") == 2
    assert words_count("one,two,three.stop") == 4


# Generated at 2022-06-21 21:30:48.152808
# Unit test for function is_decimal
def test_is_decimal():
    assert (is_decimal('3.14159')) == True
    assert (is_decimal('12345')) == False



# Generated at 2022-06-21 21:30:54.995769
# Unit test for function is_email
def test_is_email():
    assert is_email('a@a.com') is True
    assert is_email('a@a.com.com') is True
    assert is_email('a@a') is False
    assert is_email('abcd@a') is False
    assert is_email('@a.com') is False
    assert is_email('a@@a.com') is False
    assert is_email('a@a.com.a') is False
    assert is_email('a@a.com.12345') is False


# Generated at 2022-06-21 21:30:59.672145
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False
    print ('All test for function is_ip_v4 passed')
# Run all test for function is_ip_v4
test_is_ip_v4()


# Generated at 2022-06-21 21:31:11.862583
# Unit test for function is_url
def test_is_url():
    # testing valid urls
    assert is_url('http://website.com')
    assert is_url('http://www.website.com')
    assert is_url('http://www.website.com/')
    assert is_url('http://website.com/folder/subfolder/file.extension')
    assert is_url('http://website.com?param=value')
    assert is_url('http://www.website.com/#hash')
    assert is_url('http://website.com/folder/subfolder/file.extension?param=value&param2=value2#hash')
    assert is_url('http://website.com:80/?param=value&param2=value2#hash')

# Generated at 2022-06-21 21:31:19.801832
# Unit test for function is_email
def test_is_email():
    assert is_email('foo@gmail.com') == True
    assert is_email('foo@hotmail.com') == True
    assert is_email('foo@yahoo.com') == True
    assert is_email('foo@yahoo.com.in') == True
    assert is_email('foo@yahoo.co.in') == True
    assert is_email('foo@yahoo.com.co') == True
    assert is_email('foo@yahoo.in') == True
    assert is_email('foo@gmail.co.uk') == True
    assert is_email('foo@gmail.com.co.uk') == True
    assert is_email('foo@gmail.com.in') == True
    assert is_email('foo!@gmail.com.in') == False

# Generated at 2022-06-21 21:31:24.233610
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?') == False


# Generated at 2022-06-21 21:31:30.413609
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') == True
    assert is_isbn_10('150-6715214') == True
    assert is_isbn_10('150-6715214', normalize=False) == False
    assert is_isbn_10('978-0-306-40615-7') == False
    
test_is_isbn_10()



# Generated at 2022-06-21 21:31:37.698831
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    try:
        __ISBNChecker('')
    except InvalidInputError:
        pass
    else:
        assert False, 'InvalidInputError is expected'

    assert __ISBNChecker('-395507037-', normalize=False).is_isbn_10()
    assert not __ISBNChecker('-395507037-', normalize=False).is_isbn_13()
    assert not __ISBNChecker('-395507037-', normalize=False).is_isbn_10()
    assert __ISBNChecker('076457-9Z38', normalize=False).is_isbn_13()
    assert not __ISBNChecker('076457-9Z38', normalize=False).is_isbn_10()

# Generated at 2022-06-21 21:31:40.156711
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580')
    assert is_isbn('1506715214')



# Generated at 2022-06-21 21:31:43.668542
# Unit test for function is_string
def test_is_string():
    assert is_string('f') == True
    assert is_string(input('Please enter the string: ')) == True
    assert is_string('f') == False
    assert is_string(input('Please enter the string: ')) == False


# Generated at 2022-06-21 21:32:05.489627
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1853260699') == True
    assert is_isbn_10('0-201-53082-1') == True
    assert is_isbn_10('1-84415-476-3') == True
    assert is_isbn_10('0-9752298-0-X') == True
    assert is_isbn_10('0-9752298-0-2') == True
    assert is_isbn_10('0-9752298-0-4') == True
    assert is_isbn_10('0-9752298-0-6') == True
    assert is_isbn_10('0-9752298-0-8') == True
    assert is_isbn_10('0-9752298-1-X') == True
    assert is_isbn_

# Generated at 2022-06-21 21:32:07.398060
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case("foo-bar-baz")
    assert is_snake_case("fooBarBaz")



# Generated at 2022-06-21 21:32:09.867772
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('thumbscrewjapingly') == True

# Generated at 2022-06-21 21:32:18.991479
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('otto')
    assert is_palindrome('rotor')
    assert is_palindrome('i topi non avevano nipoti')
    assert is_palindrome('A man, a plan, a canal, Panama!')
    assert is_palindrome('Lagerregal')
    assert is_palindrome('Lagerregal', ignore_case=True)
    assert is_palindrome('i topi non avevano nipoti', ignore_spaces=True)
    assert not is_palindrome('i topi non avevano nipoti', ignore_case=True, ignore_spaces=True)

test_is_palindrome()


# Generated at 2022-06-21 21:32:31.099984
# Unit test for function is_email
def test_is_email():
    assert is_email('email@addresses.com')
    assert is_email('firstname.lastname@addresses.com')
    assert is_email('email@addresses.com')
    assert is_email('email@addresses.com')
    assert is_email('email@addresses.com')
    assert is_email('email@123.123.123.123')
    assert is_email('email@[123.123.123.123]')
    assert is_email('"email"@addresses.com')
    assert is_email('1234567890@addresses.com')
    assert is_email('email@addresses-domain.com')
    assert is_email('_______@addresses.com')
    assert is_email('email@addresses.name')

# Generated at 2022-06-21 21:32:33.936810
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string('hello')
    assert not is_full_string('')
    assert not is_full_string(' ')
    assert not is_full_string(None)



# Generated at 2022-06-21 21:32:40.179079
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog')
    assert not is_pangram('The quick brown fox jump over the lazy dog')
    assert is_pangram('The five boxing wizards jump quickly')
    assert not is_pangram('This is not a valid pangram')

if __name__ == '__main__':
    test_is_pangram()

# Generated at 2022-06-21 21:32:48.741290
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580') == True
    assert is_isbn_13('978-0312498580') == True
    assert is_isbn_13('978-0312498580', normalize=False) == False
    assert is_isbn_13('978-1-56619-909-4') == True
    assert is_isbn_13('978-1-56619-909-2') == False
    assert is_isbn_13('978-1-56619-909-1') == False

test_is_isbn_13()


# Generated at 2022-06-21 21:32:53.579250
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') == True
    assert is_isbn_10('150-6715214') == True
    assert is_isbn_10('150-6715214', normalize=False) == False
    print("Test for is_isbn_10: PASSED")


# Generated at 2022-06-21 21:32:58.542552
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string(None) == False
    assert is_full_string('') == False
    assert is_full_string(' ') == False
    assert is_full_string('hello') == True
    assert is_full_string('''hello
        ''') == True
test_is_full_string()



# Generated at 2022-06-21 21:33:08.096414
# Unit test for function words_count
def test_words_count():
    assert words_count("hello world") == 2
    assert words_count("one,two,three.stop") == 4
    assert words_count("") == 0
    assert words_count("  123  ") == 1
    assert words_count("  123 456! ¿¡¡¿  ") == 2
    assert words_count("!/%") == 0
    assert words_count(None) == 0

test_words_count()


# Generated at 2022-06-21 21:33:11.131453
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42') # returns true
    assert not is_integer('42.0') # returns false
    assert not is_integer('a') # returns false



# Generated at 2022-06-21 21:33:22.142792
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn("0306406152") == True
    assert is_isbn("0-306-40615-2") == True
    assert is_isbn("9780306406157") == True
    assert is_isbn("978-0-306-40615-7") == True
    assert is_isbn("978030640615") == False
    assert is_isbn("978-0-306-40615-6") == False
    assert is_isbn("978-0-306-40615-8") == False
    assert is_isbn("97803064061573") == False
    assert is_isbn("97803064061574") == False
    assert is_isbn("978-3142-55675-7") == False
    assert is_isbn("978-3142-55675-")

# Generated at 2022-06-21 21:33:24.847460
# Unit test for function is_full_string
def test_is_full_string():
    assert not is_full_string(None)
    assert not is_full_string('')
    assert not is_full_string(' ')
    assert is_full_string('hello')

