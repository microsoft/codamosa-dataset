

# Generated at 2022-06-21 21:23:40.634107
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('QWERTYUIOPASDFGHJKLZXCVBNM') == True
    assert is_pangram('qwertyuiopasdfghjklzxcvbnm') == True
    assert is_pangram('The quick brown fox jumps over the lazy dog') == True
    assert is_pangram('Hello World') == False
test_is_pangram()


# Tests
if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 21:23:45.435106
# Unit test for function is_number
def test_is_number():
    assert is_number('42') == True
    assert is_number('19.99') == True
    assert is_number('-9.12') == True
    assert is_number('1e3') == True
    assert is_number('1 2 3') == False



# Generated at 2022-06-21 21:23:48.641982
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('otto', False, False) is True
    assert is_palindrome('i topi non avevano nipoti', True, False) is True
    assert is_palindrome('Amore Roma', True, True) is True
    assert is_palindrome('! i topi non avevano nipoti', True, False) is False
    assert is_palindrome('!!! i topi non avevano nipoti !!!', True, False) is True



# Generated at 2022-06-21 21:23:51.973834
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75') 
    assert is_ip('255.200.100.75')
    assert is_ip('1.2.3') == False

#########################################################################################################
# Data validation
#########################################################################################################


# Generated at 2022-06-21 21:23:54.493087
# Unit test for function is_ip_v4
def test_is_ip_v4():
     assert is_ip_v4('255.200.100.75')


# Generated at 2022-06-21 21:23:58.584572
# Unit test for function is_string
def test_is_string():
    # obj is a string, return true
    assert is_string("TEST") == True
    # obj is not a string, return false
    assert is_string(12345) == False
    # obj = None, return false
    assert is_string(None) == False


# Generated at 2022-06-21 21:24:01.703035
# Unit test for function is_full_string
def test_is_full_string():
    assert not is_full_string(None)
    assert not is_full_string('')
    assert not is_full_string(' ')
    assert is_full_string('hello')



# Generated at 2022-06-21 21:24:07.784693
# Unit test for function is_isogram
def test_is_isogram():
    input_string = 'dermatoglyphics'
    assert is_isogram(input_string) == True
    input_string = 'hello'
    assert is_isogram(input_string) == False
test_is_isogram()



# Generated at 2022-06-21 21:24:10.756274
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-post') is True
    assert is_slug('my_post') is True


# Generated at 2022-06-21 21:24:13.508917
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert not is_ip_v4('nope')
    assert not is_ip_v4('0.0.0.256')
    assert is_ip_v4('0.0.0.0')
    assert is_ip_v4('200.123.45.67')
# Test unit for is_ip_v4
test_is_ip_v4()



# Generated at 2022-06-21 21:24:33.227173
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('I topi non avevano nipoti') is True
    assert is_palindrome('I topi non avevano nipoti', ignore_spaces=True) is False
    assert is_palindrome('I topi non avevano nipoti', ignore_case=True) is False
    assert is_palindrome('I topi non avevano nipoti', ignore_spaces=True, ignore_case=True) is False
    assert is_palindrome('i topi non avevano nipoti') is False
    assert is_palindrome('i topi non avevano nipoti', ignore_spaces=True) is False
    assert is_palindrome('i topi non avevano nipoti', ignore_case=True) is True

# Generated at 2022-06-21 21:24:36.233042
# Unit test for function is_camel_case
def test_is_camel_case():
    """ Test function is_camel_case. """
    assert is_camel_case('MyString') == True
    assert is_camel_case('mystring') == False
test_is_camel_case()


# Generated at 2022-06-21 21:24:40.590986
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4(None) == False
    assert is_ip_v4('') == False
    assert is_ip_v4(' ') == False
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-21 21:24:42.548530
# Unit test for function is_integer
def test_is_integer():
    assert(is_integer('14') == True)
    assert(is_integer('14.0') == False)


# Generated at 2022-06-21 21:24:44.365762
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580')
    assert is_isbn_13('978-0312498580')
    assert is_isbn_13('978-0312498580',normalize=False)

# Generated at 2022-06-21 21:24:45.940642
# Unit test for function words_count
def test_words_count():
    assert words_count('hello world') == 2, 'words_count() should return 2 if there are two words!'
    assert words_count('one,two,three.stop') == 4, 'words_count() should return 4 if there are four words!'
test_words_count()


# Generated at 2022-06-21 21:24:53.106821
# Unit test for function is_email
def test_is_email():
    #Correctly implemented strings
    assert(is_email('email@domain.com')==True)
    assert(is_email('firstname.lastname@domain.com')==True)
    assert(is_email('email@subdomain.domain.com')==True)
    assert(is_email('firstname+lastname@domain.com')==True)
    assert(is_email('email@123.123.123.123')==True)
    assert(is_email('email@[123.123.123.123]')==True)
    assert(is_email('"email"@domain.com')==True)
    assert(is_email('1234567890@domain.com')==True)
    assert(is_email('email@domain-one.com')==True)

# Generated at 2022-06-21 21:25:03.740590
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-1-56619-909-4').is_isbn_13()
    assert __ISBNChecker('978-1-56619-909-4', False).is_isbn_13()
    assert not __ISBNChecker('978-1-56619-909-3', False).is_isbn_13()
    assert __ISBNChecker('979-6-56619-909-7').is_isbn_13()
    assert __ISBNChecker('979-6-56619-909-7', False).is_isbn_13()
    assert not __ISBNChecker('979-6-56619-909-8', False).is_isbn_13()

# Generated at 2022-06-21 21:25:05.094753
# Unit test for function is_string
def test_is_string():
    assert is_string('foo') == True
    assert is_string(b'foo') == False



# Generated at 2022-06-21 21:25:08.220726
# Unit test for function is_ip_v6
def test_is_ip_v6():
    ip_v6 = "2001:db8:85a3:0000:0000:8a2e:370:7334"
    assert is_ip_v6(ip_v6) == True
    ip_v6 = "2001:db8:85a3:0000:0000:8a2e:370:?"
    assert is_ip_v6(ip_v6) == False



# Generated at 2022-06-21 21:25:25.509944
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    assert __ISBNChecker('978-3-16-148410-0').is_isbn_13()
    assert __ISBNChecker('978-3-16-148410-0').is_isbn_10() is False
    assert __ISBNChecker('316-148410-8').is_isbn_10()
    assert __ISBNChecker('316-148410-8').is_isbn_13() is False

    assert __ISBNChecker('978-3-16-148410-0', normalize=False).is_isbn_13()
    assert __ISBNChecker('978-3-16-148410-0', normalize=False).is_isbn_10() is False
    assert __ISBNChecker('316-148410-8', normalize=False).is_

# Generated at 2022-06-21 21:25:33.636204
# Unit test for function is_decimal
def test_is_decimal():
    assert(is_decimal('42.0')==True)
    assert(is_decimal('42')==False)
    assert(is_decimal('-42')==False)
    assert(is_decimal('42.04')==True)
    assert(is_decimal('-42.04')==True)
    assert(is_decimal('2.04e+2')==True)
    assert(is_decimal('2.04e-2')==True)

# Generated at 2022-06-21 21:25:37.763855
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('9780618341690').is_isbn_13(), "should be True"
    assert __ISBNChecker('0393045218').is_isbn_13(), "should be True"
    assert not __ISBNChecker('978061834169').is_isbn_13(), "should be False"
    assert not __ISBNChecker('9780618341691').is_isbn_13(), "should be False"
    assert not __ISBNChecker('978061834169X').is_isbn_13(), "should be False"


# ___ISBNChecker tests
test___ISBNChecker_is_isbn_13()


# Generated at 2022-06-21 21:25:40.168231
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True



# Generated at 2022-06-21 21:25:41.764549
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('myString') == True

# Generated at 2022-06-21 21:25:50.244791
# Unit test for function is_uuid
def test_is_uuid():
    assert not is_uuid(None)
    assert not is_uuid('')
    assert not is_uuid(' ')
    assert not is_uuid('6f8aa2f9686c4ac387665712354a04cf')
    assert not is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=False)
    assert not is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True)
    assert not is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf ', allow_hex=True)

# Generated at 2022-06-21 21:25:51.512205
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('9781408855652').is_isbn_13() is True
    assert __ISBNChecker('9781408855623').is_isbn_13() is False



# Generated at 2022-06-21 21:25:57.404633
# Unit test for function is_full_string
def test_is_full_string():
    test_input = ['', None, 'hello', ' ']
    test_output = [False, False, True, False]

    test_result = []
    for i in test_input:
        test_result.append(is_full_string(i))

    assert test_result == test_output, "Test function error"
#test_is_full_string()



# Generated at 2022-06-21 21:26:01.584942
# Unit test for function is_url
def test_is_url():
    assert (is_url('http://www.mysite.com', ['http']))
    assert (is_url('http://www.mysite.com', ['https']))


# Generated at 2022-06-21 21:26:07.146800
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker("0306406152").is_isbn_10() is True
    assert __ISBNChecker("0306406152").is_isbn_13() is False
    assert __ISBNChecker("9780306406157").is_isbn_13() is True
    assert __ISBNChecker("9780306406157").is_isbn_10() is False

test___ISBNChecker_is_isbn_10()

# Generated at 2022-06-21 21:26:18.324373
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580') # returns true
    assert is_isbn_13('978-0312498580') # returns true
    assert is_isbn_13('978-0312498580', normalize=False) # returns false

test_is_isbn_13()


# Generated at 2022-06-21 21:26:28.270385
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('foo_bar_baz')
    assert is_snake_case('a_b_c')
    assert not is_snake_case('abc')
    assert not is_snake_case('ab_c')
    assert not is_snake_case('a_bc')
    assert is_snake_case('foo', separator='-')
    assert is_snake_case('foo-bar-baz', separator='-')
    assert is_snake_case('a-b-c', separator='-')
    assert not is_snake_case('abc', separator='-')
    assert not is_snake_case('ab-c', separator='-')
    assert not is_snake_case('a-bc', separator='-')



# Generated at 2022-06-21 21:26:33.107071
# Unit test for function is_pangram
def test_is_pangram():
    english_pangram = "The quick brown fox jumps over the lazy dog"
    not_an_english_pangram = "hello world"
    assert is_pangram(english_pangram)
    assert is_pangram(not_an_english_pangram)==False

test_is_pangram()

# Generated at 2022-06-21 21:26:37.839309
# Unit test for function is_camel_case
def test_is_camel_case():
    #Given
    assert is_camel_case('MyString') == True
    assert is_camel_case('mystring') == False
    assert is_camel_case('string_') == False
    assert is_camel_case(None) == False
    assert is_camel_case('') == False
    assert is_camel_case(' ') == False
    
    


# Generated at 2022-06-21 21:26:39.687855
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog') == True
    assert is_pangram('hello world') == False


# Generated at 2022-06-21 21:26:43.266083
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('foo_bar')
    assert is_snake_case('foo-bar', separator='-')
    assert is_snake_case('foo-bar') == False



# Generated at 2022-06-21 21:26:47.448926
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram(str_1) == False
    assert is_pangram(str_2) == True
    assert is_pangram(str_3) == False
test_is_pangram()


# Generated at 2022-06-21 21:26:52.310118
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('9781449393090').is_isbn_13() is True
    assert __ISBNChecker('0306406152').is_isbn_13() is False
    assert __ISBNChecker('123412341234').is_isbn_13() is True
    assert __ISBNChecker('869069006613').is_isbn_13() is False



# Generated at 2022-06-21 21:26:54.930175
# Unit test for function words_count
def test_words_count():
    assert words_count('one,two,three.stop') == 4
    assert words_count('one two three stop') == 4
    assert words_count('! @ # % ... []') == 0
    assert words_count('one,two,three.stop,stop,stop') == 5
    assert words_count('one      two          three stop') == 4


# Generated at 2022-06-21 21:27:06.080945
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('192.168.0.1') is True
    assert is_ip('255.200.100.75') is True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') is True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:?') is False
    assert is_ip('1.2.3') is False
    assert is_ip('1.2.3.4.5') is False
    assert is_ip('1.2.3.4') is True
    assert is_ip('1.2.3.4.') is False
    assert is_ip('1.2.3.a') is False

# Generated at 2022-06-21 21:27:15.564995
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf')
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True)



# Generated at 2022-06-21 21:27:26.476499
# Unit test for function is_email

# Generated at 2022-06-21 21:27:38.241397
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram("The quick brown fox jumps over the lazy dog")
    assert not is_pangram("hello world")
    assert is_pangram("abcdefghijklmnopqrstuvwxyz")
    assert is_pangram("ABCDEFGHIJKLMNOPQRSTUVWXYZ")
    assert not is_pangram("abCdefghijklmnoPQRstuvwxyz")
    assert is_pangram("")
    assert is_pangram("abcdefghijklmnopqrstuvwxyz1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890")

# Generated at 2022-06-21 21:27:42.954246
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('MyCamelCaseString') == True
    assert is_camel_case('MyCamelCaseString3') == True
    assert is_camel_case('myCamelCaseString') == False
    assert is_camel_case('MyCamelCase_String') == False
    assert is_camel_case('MyCamelCase_String 3') == False
    assert is_camel_case('my_Camel_case_string') == False



# Generated at 2022-06-21 21:27:45.634860
# Unit test for function is_string
def test_is_string():
    assert is_string('foo') is True
    assert is_string(b'foo') is False
    assert is_string(None) is False
    assert is_string(237) is False


# Generated at 2022-06-21 21:27:46.867311
# Unit test for function contains_html
def test_contains_html():
    assert not contains_html('hello')
    assert contains_html('hello<br>')
test_contains_html()



# Generated at 2022-06-21 21:27:52.025071
# Unit test for function contains_html
def test_contains_html():
    # Error on non-string
    with pytest.raises(InvalidInputError):
        contains_html(10)
        contains_html((10, 10))

    # String
    assert contains_html('<a>') == True
    assert contains_html('</a>') == True
    assert contains_html('<a/>') == True
    assert contains_html('< img src="/my/image" >') == True
    assert contains_html('&lt;a&gt;') == True
    assert contains_html('<a>hello</a>') == True
    assert contains_html('< a > hello < / a >') == True
    assert contains_html('<a>hello') == True
    assert contains_html('hello</a>') == True

    # Not a string
    assert contains_html('') == False
   

# Generated at 2022-06-21 21:27:55.977289
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker("9780306406151").is_isbn_13() == True
    assert __ISBNChecker("978-0-306-40615-1", False).is_isbn_13() == True
    assert __ISBNChecker("030640615X").is_isbn_13() == False


# Generated at 2022-06-21 21:28:02.646772
# Unit test for function is_ip
def test_is_ip():
    assert (is_ip('[2001:db8:85a3:8d3:1319:8a2e:370:7348]'))
    assert (not is_ip('[2001:db8:85a3:8d3:1319:8a2e:370:7348'))
    assert (not is_ip('[2001:db8:85a3:8d3:1319:8a2e:370:7348'))
    assert (not is_ip('[2001:db8:85a3:8d3:1319:8a2e:370:7348'))
    assert (not is_ip('[2001:db8:85a3:8d3:1319:8a2e:370:7348'))

# Generated at 2022-06-21 21:28:07.710973
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    checker = __ISBNChecker('978-0-306-40615-7')
    assert checker.is_isbn_13() == True

    checker = __ISBNChecker('978-0-306-40615-3')
    assert checker.is_isbn_13() == False

# Generated at 2022-06-21 21:28:24.699866
# Unit test for function is_snake_case
def test_is_snake_case():
    assert not is_snake_case('foo')
    assert is_snake_case('foo_bar_baz')
    assert is_snake_case('foo-bar-baz', '-')
    assert is_snake_case('foo-bar-baz', separator='-')



# Generated at 2022-06-21 21:28:31.657541
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    # Normalize by default
    input_string = '978-607-31-0667-0'
    _checker = __ISBNChecker(input_string)
    assert _checker.input_string == '9786073106670'

    input_string = '978-607-31-0667-0'
    _checker = __ISBNChecker(input_string, normalize=False)
    assert _checker.input_string == '978-607-31-0667-0'

    # Raise error with invalid input
    try:
        input_string = 12345
        _checker = __ISBNChecker(input_string)
        assert False
    except InvalidInputError:
        assert True


# Generated at 2022-06-21 21:28:34.780901
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999')


# Generated at 2022-06-21 21:28:37.900606
# Unit test for function is_full_string
def test_is_full_string():
    try:
        assert is_full_string(None) == False
    except TypeError:
        pass
    assert is_full_string('') == False
    assert is_full_string(' ') == False
    assert is_full_string('hello') == True

test_is_full_string()



# Generated at 2022-06-21 21:28:48.756735
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-3-16-148410-0').is_isbn_13() == True
    assert __ISBNChecker('9783161484100').is_isbn_13() == True
    assert __ISBNChecker('978-316-148410-0').is_isbn_13() == False
    assert __ISBNChecker('97831614841001').is_isbn_13() == False
    assert __ISBNChecker('978316148410x0').is_isbn_13() == False
    assert __ISBNChecker('978316148410').is_isbn_13() == False
test___ISBNChecker_is_isbn_13()


# Generated at 2022-06-21 21:28:50.216804
# Unit test for function is_ip_v6
def test_is_ip_v6():
    return is_ip_v6('265.200.100.75')


# Generated at 2022-06-21 21:28:52.372501
# Unit test for function is_string
def test_is_string():
    assert is_string('foo')
    assert not is_string(b'foo')



# Generated at 2022-06-21 21:28:58.998008
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('MALAYALAM')
    assert is_palindrome('MALAYALAM', ignore_case=True)
    assert is_palindrome('otto')
    assert not is_palindrome('i topi non avevano nipoti')
    assert is_palindrome('i topi non avevano nipoti', ignore_spaces=True)



# Generated at 2022-06-21 21:29:00.955075
# Unit test for function is_string
def test_is_string():
    assert is_string('foo') == True
    assert is_string(b'foo') == False


# Generated at 2022-06-21 21:29:04.844175
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') == True
    assert is_isbn_10('150-6715214') == True
    assert is_isbn_10('150-6715214', normalize=False) == False

test_is_isbn_10()


# Generated at 2022-06-21 21:29:26.231597
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    _isbn_checker = __ISBNChecker('978-1-56619-909-4')

    assert _isbn_checker.is_isbn_13()
    assert not _isbn_checker.is_isbn_10()

    _isbn_checker = __ISBNChecker('0-9752298-0-X')

    assert _isbn_checker.is_isbn_10()
    assert not _isbn_checker.is_isbn_13()


# VALIDATOR FUNCTIONS



# Generated at 2022-06-21 21:29:30.558871
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?') == False


# Generated at 2022-06-21 21:29:38.479102
# Unit test for function is_ip
def test_is_ip():
    #positive
    assert is_ip("2001:db8:85a3:0000:0000:8a2e:370:7334")
    assert is_ip("2001:db8:85a3:0:0:8a2e:370:7334")
    assert is_ip("2001:db8:85a3::8a2e:370:7334")
    assert is_ip("2001:db8:85a3::8a2e:370:7334")
    assert is_ip("2001:db8:85a3:0:0:8a2e:370:7334")
    assert is_ip("2001:db8:85a3:0::8a2e:370:7334")
    assert is_ip("2001:db8:85a3::8a2e:370:7334")

# Generated at 2022-06-21 21:29:40.275335
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog') == True
    assert is_pangram('hello world') == False
    
test_is_pangram()

# Generated at 2022-06-21 21:29:41.838280
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog') is True
    assert is_pangram('hello world') is False
test_is_pangram()

# Generated at 2022-06-21 21:29:44.872685
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('my string is <strong>bold</strong>')

    assert not contains_html('my string is not bold')


# Generated at 2022-06-21 21:29:46.884931
# Unit test for function is_slug
def test_is_slug():
    assert is_slug("my-blog-post-title", separator = "-")
    assert not is_slug("My blog post title", separator = "-")
    
test_is_slug()

# Generated at 2022-06-21 21:29:50.197149
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string(None) == False
    assert is_full_string('') == False
    assert is_full_string(' ') == False
    assert is_full_string('hello') == True
test_is_full_string()



# Generated at 2022-06-21 21:30:00.562197
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('foo_bar_baz') == True
    assert is_snake_case('foobarbaz') == False
    assert is_snake_case('foo-bar-baz') == False
    assert is_snake_case('foo-bar-baz', separator='-') == True
    assert is_snake_case('foo_bar-baz', separator='-') == False
    assert is_snake_case('-foo-bar-baz', separator='-') == True
    assert is_snake_case('--foo-bar-baz', separator='-') == False
    assert is_snake_case('') == False
    assert is_snake_case('f') == False
    assert is_snake_case('1') == False
    assert is_

# Generated at 2022-06-21 21:30:02.638086
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0306406152').is_isbn_10()  # True


# PUBLIC API



# Generated at 2022-06-21 21:30:19.405402
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214')
    assert is_isbn_10('150-6715214')
    assert not is_isbn_10('150-6715214', normalize=False)



# Generated at 2022-06-21 21:30:26.327953
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580') == True
    assert is_isbn_13('978-0312498580') == True
    assert is_isbn_13('978-0312498580', False) == False
    assert is_isbn_13(9780312498580) == False

# Generated at 2022-06-21 21:30:37.759288
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214')
    assert is_isbn_10('150-6715214')
    assert is_isbn_10('150-6715214', normalize=False)
    assert not is_isbn_10('150-6715214', normalize=True)
    assert is_isbn_10('1-5067-1521-4')
    assert not is_isbn_10('0-521-86560-4')
    assert is_isbn_10('1-61696-222-0')
    assert is_isbn_10('0-9752298-0-X')
    assert is_isbn_10('0-9752298-0-x')
    assert not is_isbn_10('1-9752298-0-x')

# Generated at 2022-06-21 21:30:49.847670
# Unit test for function is_email
def test_is_email():
    assert is_email('john@doe.com') is True
    assert is_email('john.doe@gmail.com') is True
    assert is_email('john.doe@gmail.com') is True
    assert is_email('.john.doe@gmail.com') is False
    assert is_email('john.doe@gmail.com ') is False
    assert is_email('john.doe@gmail.com.it') is True
    assert is_email('john.doe@gmail.com.it.co.uk') is True
    assert is_email('john.doe@gmail.') is False
    assert is_email('john.doe@gmail.c') is False
    assert is_email('john.doe@gmail.com.') is False

# Generated at 2022-06-21 21:30:52.948049
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    # valid ISBN 13
    assert __ISBNChecker('9780672335784').is_isbn_13()
    # valid ISBN 10
    assert __ISBNChecker('0672335788').is_isbn_10()

# PUBLIC API


# Checks if input value is string or not

# Generated at 2022-06-21 21:30:56.139711
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False



# Generated at 2022-06-21 21:31:00.961870
# Unit test for function is_camel_case
def test_is_camel_case():
    assert(is_camel_case('MyString'))
    assert(not is_camel_case('mystring'))
    assert(not is_camel_case('myString'))


# Generated at 2022-06-21 21:31:02.210871
# Unit test for function is_integer
def test_is_integer():
    assert is_integer(1) == True



# Generated at 2022-06-21 21:31:05.582762
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}')
    assert is_json('[1, 2, 3]')
    assert is_json('{nope}') == False



# Generated at 2022-06-21 21:31:07.907760
# Unit test for function is_string
def test_is_string():
    assert is_string('foo') == True
    assert is_string(b'foo') == False


# Generated at 2022-06-21 21:31:23.812887
# Unit test for function is_isbn
def test_is_isbn():
    assert(is_isbn('9780312498580'))
    assert(is_isbn('1506715214'))


# Generated at 2022-06-21 21:31:34.020042
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('otto') is True
    assert is_palindrome('rotfl') is False

    assert is_palindrome('i topi non avevano nipoti') is True
    assert is_palindrome('il topo annusava la pasta') is True

    assert is_palindrome('i topi non avevano nipoti', ignore_spaces=True) is True
    assert is_palindrome('il topo annusava la pasta', ignore_spaces=True) is True

    assert is_palindrome('LOL') is True
    assert is_palindrome('ROTFL') is False

    assert is_palindrome('Lol') is False
    assert is_palindrome('ROTFl') is False


# Generated at 2022-06-21 21:31:46.458334
# Unit test for function words_count
def test_words_count():
    # Whitespace check
    assert words_count('one two three') == 3
    assert words_count('one two.three') == 3
    assert words_count('one two three!') == 3
    assert words_count('one two three?') == 3
    assert words_count('one two three]') == 3
    assert words_count('one two three)') == 3

    # Character check
    assert words_count('one_two_three') == 3
    assert words_count('one-two-three') == 3
    assert words_count('one/two/three') == 3

    # Multiple punctuation check
    assert words_count('one,,two,three') == 3
    assert words_count('one..two.three') == 3
    assert words_count('one...two...three') == 3

    # Both check
    assert words

# Generated at 2022-06-21 21:31:51.301106
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title') is True
    assert is_slug('My blog post title') is False
    assert is_slug('my_blog_post_title') is False
    assert is_slug('my_blog_post_title', '_') is True
    assert is_slug('my_blog_post_title', '-') is False



# Generated at 2022-06-21 21:32:03.186720
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('1234') == False
    assert is_credit_card('5204000000000212') == True
    assert is_credit_card('1234', card_type='VISA') == False
    assert is_credit_card('5204000000000212', card_type='VISA') == True
    assert is_credit_card('5204000000000212', card_type='MASTERCARD') == False
    assert is_credit_card('4444444444444448', card_type='VISA') == True


# Generated at 2022-06-21 21:32:05.221506
# Unit test for function is_string
def test_is_string():
    assert is_string('foo') == True
    assert is_string(b'foo') == False



# Generated at 2022-06-21 21:32:16.764334
# Unit test for function words_count

# Generated at 2022-06-21 21:32:24.350486
# Unit test for function is_isbn
def test_is_isbn():
    isbn10_ok = [
        '0436103182',
        '978-0436103188',
        '3-89896-477-0',
        '978-3-89896-477-2',
        '0-8044-2957-X',
        '978-0-8044-2957-6',
        '0819853002',
        '978-0819853009',
        '0-7710-4438-X',
        '978-0-7710-4438-3',
        '0-553-35937-5',
        '978-0-553-35937-1',
        '973-9431-42-3',
        '978-973-9431-42-5'
    ]

# Generated at 2022-06-21 21:32:26.461830
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string(None) == False
    assert is_full_string('') == False
    assert is_full_string(' ') == False
    assert is_full_string('hello') == True
    assert is_full_string('hello world') == True


# Generated at 2022-06-21 21:32:30.253511
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580') is True
    assert is_isbn_13('978-0312498580') is True
    assert is_isbn_13('978-0312498580', normalize=False) is False


# Generated at 2022-06-21 21:32:47.666992
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13("9780312498580") == True
    assert is_isbn_13("978-0312498580") == True
    assert is_isbn_13("978-0312498580",normalize=False) == False
    assert is_isbn_13("1-4302-1883-8") == False

# Generated at 2022-06-21 21:32:53.826319
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('Dermatoglyphics') == True, "Shouldn't be isogram"
    assert is_isogram('aba') == False, "Should be isogram"
    assert is_isogram('moOse') == False, "Should be isogram"
    assert is_isogram('') == True, "Should be isogram"
# Test for is_isogram
test_is_isogram()

# Generated at 2022-06-21 21:32:57.712275
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42')
    assert is_integer('-42')
    assert is_integer('+42')
    assert is_integer('1E+5')
    assert not is_integer('42.0')
    assert not is_integer('42e5')



# Generated at 2022-06-21 21:33:00.560339
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10("1506715214")
    assert is_isbn_10("150-6715214")
    assert not is_isbn_10("150-6715214", normalize=False)



# Generated at 2022-06-21 21:33:03.478077
# Unit test for function is_json
def test_is_json():
    assert is_json('{}')
    assert is_json('{"name": "Peter"}')
    assert is_json('[1, 2, 3, 4, 5]')
    assert not is_json('foo')



# Generated at 2022-06-21 21:33:07.165331
# Unit test for function is_number
def test_is_number():
    assert is_number("1")
    assert is_number("1.2")
    assert is_number("+1")
    assert is_number("-1")
    assert not is_number("hello")



# Generated at 2022-06-21 21:33:14.466304
# Unit test for function is_number
def test_is_number():
    assert is_number('42') == True
    assert is_number('19.99') == True
    assert is_number('-9.12') == True
    assert is_number('1e3') == True
    assert is_number('1 2 3') == False
    assert is_number('9.123456789012') == True
    assert is_number('3.40282347E+38') == True
    assert is_number(' -1') == False
    assert is_number('-3.4028234663852886e+38') == True
    assert is_number('-3.4028234663852886e+38') == True
    assert is_number('1e-10') == True
    assert is_number('123.45') == True
    assert is_number('-9.99') == True


# Generated at 2022-06-21 21:33:16.453756
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')



# Generated at 2022-06-21 21:33:25.047757
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    correct_inputs = ['9781408855652', '1408855651', '978-1-4088-5565-2']
    correct_outputs = [True, True, True]
    for i in range(len(correct_inputs)):
        assert __ISBNChecker(correct_inputs[i]).is_isbn_13() == correct_outputs[i]
        assert __ISBNChecker(correct_inputs[i]).is_isbn_10() == correct_outputs[i]
    incorrect_inputs = ['978140885565', '140885565', '978-1-4088-5565-123']
    incorrect_outputs = [False, False, False]