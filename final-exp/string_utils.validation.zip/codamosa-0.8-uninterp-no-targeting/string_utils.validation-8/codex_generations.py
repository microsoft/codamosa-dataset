

# Generated at 2022-06-21 21:23:55.402398
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-1-56619-909-4').is_isbn_13()
    assert __ISBNChecker('9781566199094').is_isbn_13()
    assert not __ISBNChecker('978-1-56619-909-5').is_isbn_13()
    assert not __ISBNChecker('0-7475-3269-9').is_isbn_13()
    assert not __ISBNChecker('not valid').is_isbn_13()
    assert not __ISBNChecker('978-1-56619-909-45').is_isbn_13()


# Generated at 2022-06-21 21:24:01.241527
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0790768134').is_isbn_10() == True
    assert __ISBNChecker('0790768135').is_isbn_10() == False
    assert __ISBNChecker('079076813').is_isbn_10() == False
    assert __ISBNChecker('XXXXXXXXXX').is_isbn_10() == False


# Generated at 2022-06-21 21:24:05.802819
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False

print('Test is_ip_v4: ', test_is_ip_v4())



# Generated at 2022-06-21 21:24:14.790742
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('') == False
    assert is_snake_case('foo') == False
    assert is_snake_case('foo_bar_baz') == True
    assert is_snake_case('foo-bar-baz') == True
    assert is_snake_case('foo-1-2-3') == True
    assert is_snake_case('foo_1_2_3') == True
    assert is_snake_case('foo_bar_baz', separator='-') == True
    assert is_snake_case('foo_bar_baz', separator='_') == True
    assert is_snake_case('foo_bar_baz', separator='#') == True



# Generated at 2022-06-21 21:24:17.514349
# Unit test for function is_isbn
def test_is_isbn():
    assert(is_isbn('9780312498580'))
    assert(is_isbn('1506715214'))


# Generated at 2022-06-21 21:24:23.252257
# Unit test for function is_number
def test_is_number():
    assert is_number('42')
    assert is_number('19.99')
    assert is_number('-9.12')
    assert is_number('1e3')
    assert not is_number('1 2 3') 
    assert not is_number('foo')
    assert not is_number('$')
    assert not is_number(True)



# Generated at 2022-06-21 21:24:34.646838
# Unit test for function is_isbn
def test_is_isbn():
    print("Test is_isbn: ", end='')
    assert is_isbn("9780312498580") is True
    assert is_isbn("1506715214") is True
    assert is_isbn("978-0312498580") is True
    assert is_isbn("978-0312498580", normalize=False) is False
    assert is_isbn("150-6715214") is True
    assert is_isbn("150-6715214", normalize=False) is False
    assert is_isbn("978-0-312-49858-0") is False
    assert is_isbn("978-0-312-49858-0", normalize=False) is False

# Generated at 2022-06-21 21:24:42.869371
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('foo_bar_baz') is True
    assert is_snake_case('foo') is False
    assert is_snake_case('_foo') is True
    assert is_snake_case('_foo_') is True
    assert is_snake_case('_') is False
    assert is_snake_case('42') is False
    assert is_snake_case('') is False
    assert is_snake_case(None) is False
    assert is_snake_case('foo_bar_baz', '-') is False
    assert is_snake_case('foo-bar-baz', '-') is True
    assert is_snake_case('foo_bar_baz', '_') is True
# End unit test for function is_snake_case



# Generated at 2022-06-21 21:24:45.531414
# Unit test for function contains_html
def test_contains_html():
    assert not contains_html('my string is not bold')
    assert contains_html('my string is <strong>bold</strong>')
test_contains_html()



# Generated at 2022-06-21 21:24:48.518858
# Unit test for function contains_html
def test_contains_html():
    assert not contains_html('my string is not bold')
    assert contains_html('my string is <strong>bold</strong>')
    assert contains_html('my string is <strong>bold</strong> and <span>other</span>')

# Generated at 2022-06-21 21:24:55.955909
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    checker = __ISBNChecker('9780425284629')
    assert checker.is_isbn_10()


# PUBLIC API



# Generated at 2022-06-21 21:25:05.693858
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('otto') == True
    assert is_palindrome('Otto') == False
    assert is_palindrome('Otto', ignore_case=True) == True
    assert is_palindrome('Rotfl') == False
    assert is_palindrome('ROTFL') == False
    assert is_palindrome('tacocat') == True
    assert is_palindrome('tacoc a t') == False
    assert is_palindrome('Tacoc a t') == False
    assert is_palindrome('tacoc a t', ignore_spaces=True) == True
    assert is_palindrome('tacoc a t', ignore_case=True, ignore_spaces=True) == True

# Generated at 2022-06-21 21:25:16.925843
# Unit test for function is_snake_case
def test_is_snake_case():
    assert not is_snake_case('foo')
    assert is_snake_case('foo_bar_baz')
    assert is_snake_case('foo_bar')
    assert is_snake_case('foo_Bar')
    assert is_snake_case('foo__bar')
    assert not is_snake_case('foo_bar_')
    assert is_snake_case('foo_bar_9')
    assert is_snake_case('foo_bar_9foo')
    assert is_snake_case('9_foo_bar_9foo')
    assert is_snake_case('-'*10)
    assert is_snake_case('9-'*10)
    assert is_snake_case('foobar', separator='-')

# Generated at 2022-06-21 21:25:25.771570
# Unit test for function is_palindrome
def test_is_palindrome():
    # true positives
    assert is_palindrome('otto')
    assert is_palindrome('i topi non avevano nipoti', ignore_spaces=True)
    assert is_palindrome('I topi non avevano nipoti', ignore_spaces=True, ignore_case=True)

    # false positives
    assert not is_palindrome('i topi non avevano nipoti')
    assert not is_palindrome('I TOpi non avevano nipoti')
    assert not is_palindrome('ROTFL')
test_is_palindrome()
 

# Generated at 2022-06-21 21:25:36.115967
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case(None) == False # shouldn't accept None, as it's not a string
    assert is_camel_case('') == False # shouldn't accept empty, as it's not a string
    assert is_camel_case(' ') == False # shouldn't accept an empty string, as it's not a string
    assert is_camel_case('MyString') == True # should return True, as it's a valid camel case
    assert is_camel_case('mystring') == False # should return False, as there's no uppercase character
    assert is_camel_case('9MyString') == False # should return False, as it starts with a number



# Generated at 2022-06-21 21:25:42.833571
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    checker = __ISBNChecker('0307888691')
    assert checker.is_isbn_10() == True, 'Expected result failed'
    checker = __ISBNChecker('0307888693')
    assert checker.is_isbn_10() == False, 'Expected result failed'

test___ISBNChecker_is_isbn_10()



# PUBLIC API


# Generated at 2022-06-21 21:25:52.957625
# Unit test for function is_url
def test_is_url():
    assert is_url(".mysite.com") == False
    assert is_url("mysite.com") == False
    assert is_url("htp://mysite.com") == False
    assert is_url("http://www.mysite.com") == True
    assert is_url("https://www.mysite.com") == True
    assert is_url("https://mysite.com") == True
    assert is_url("https://mysite.com/index.html") == True
    assert is_url("https://mysite.com:8080") == True
    assert is_url("mysite.com/index.html") == False
    assert is_url('') == False
    assert is_url(None) == False
    assert is_url(5) == False

# Generated at 2022-06-21 21:25:56.817903
# Unit test for function words_count
def test_words_count():
    assert words_count("one two three four five") == 5
    assert words_count("one, two, three, four, five") == 5
    assert words_count("one,two,three.stop") == 4
    assert words_count("") == 0
    assert words_count("! @ # % ... []") == 0
    assert words_count("   ") == 0
    assert words_count("have you ever heard about these:  CSS, HTML, JSON, SQL, IPC, MVC, MOA, SOLID?") == 8



# Generated at 2022-06-21 21:26:06.455279
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('') == False
    assert is_camel_case(' ') == False
    assert is_camel_case('thisIsCamelCase') == True
    assert is_camel_case('thisIsCamelCase123') == True
    assert is_camel_case('this_is_snake_case') == False
    assert is_camel_case('0thisIsCamelCase') == False
    assert is_camel_case('THIS_IS_SNAKE_CASE') == False
    assert is_camel_case('this IS NOT_CAMEL-CASE') == False



# Generated at 2022-06-21 21:26:08.293140
# Unit test for function is_json
def test_is_json():
    assert is_json({"name": "Peter"})
    assert is_json([1, 2, 3])
    assert not is_json({nope})



# Generated at 2022-06-21 21:26:26.438045
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('myString') == True
    assert is_camel_case('Mystring') == False
    assert is_camel_case('MyString') == True
    assert is_camel_case('myString99') == True
    assert is_camel_case('myString99-1') == False
    assert is_camel_case('99myString') == False
    assert is_camel_case('99') == False
    assert is_camel_case('') == False
# End unit test for function is_camel_case



# Generated at 2022-06-21 21:26:29.851613
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') == True
    assert is_isbn('1506715214') == True
    assert is_isbn('150-6715214') == True

# Generated at 2022-06-21 21:26:34.184113
# Unit test for function is_number
def test_is_number():
    assert(is_number('42') == True)
    assert(is_number('-19.99') == False)
    assert(is_number('-9.12') == True)
    assert(is_number('1e3') == True)
    assert(is_number('1 2 3') == False)



# Generated at 2022-06-21 21:26:35.748858
# Unit test for function is_isbn_13
def test_is_isbn_13():
    return not is_isbn_13("978-0312498580", normalize=False)



# Generated at 2022-06-21 21:26:40.738844
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10("0-8065-0971-X") == True
assert is_isbn_10("1847532709") == True
assert is_isbn_10("1-84753-270-9") == True
assert is_isbn_10("1-84753270-9") == True
assert is_isbn_10("0306406152") == True
assert is_isbn_10("9780306406157") == True
assert is_isbn_10("978-0306406157") == True
assert is_isbn_10("0-306-40615-2") == True
assert is_isbn_10("0-306-40615-X") == True
assert is_isbn_10("9780141000038") == True

# Generated at 2022-06-21 21:26:47.601359
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    checker = __ISBNChecker
    assert checker('0123456789').is_isbn_10() == True
    assert checker('0123456780').is_isbn_10() == False
    assert checker('a123456789').is_isbn_10() == False
    assert checker(1234567890).is_isbn_10() == False



# Generated at 2022-06-21 21:26:55.678191
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.255.255.255') == True
    assert is_ip_v4('0.0.0.0') == True
    assert is_ip_v4('192.168.0.1') == True
    assert is_ip_v4('192.168.000.001') == True
    assert is_ip_v4('192.168.0.0.0') == False
    assert is_ip_v4('192.168.0') == False
    assert is_ip_v4('256.168.0.0') == False
    assert is_ip_v4('') == False
    assert is_ip_v4('abc.def.ghi.jkl') == False

# Generated at 2022-06-21 21:26:59.686516
# Unit test for function contains_html
def test_contains_html():
   assert contains_html('<h1>bla bla bla</h1>')
   assert not contains_html('bla bla bla')


# Check if the email contains <>

# Generated at 2022-06-21 21:27:03.954074
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') == True 
    assert is_isbn('1506715214') == True 
    assert is_isbn('978-0312498580') == True 
    assert is_isbn('978-0312498580', normalize=False) == False
    assert is_isbn('150-6715214') == True 
    assert is_isbn('150-6715214', normalize=False) == False
test_is_isbn()



# Generated at 2022-06-21 21:27:10.668747
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('otto', False, False)
    assert not is_palindrome('ROTFL', False, False)
    assert is_palindrome('i topi non avevano nipoti', False, False)
    assert not is_palindrome('i topi non avevano nipoti', False, True)
    assert not is_palindrome('i topi non avevano nipoti', True, False)
    assert is_palindrome('i topi non avevano nipoti', True, True)



# Generated at 2022-06-21 21:27:18.047679
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    t = __ISBNChecker('123456789X')
    assert t.is_isbn_10()

# Generated at 2022-06-21 21:27:19.987450
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('978-0312498580') is True
test_is_isbn_13()


# Generated at 2022-06-21 21:27:29.405444
# Unit test for function is_snake_case
def test_is_snake_case():
    # group (1)
    assert is_snake_case('foo_bar')

    # group (2)
    assert not is_snake_case('_foobar')
    assert is_snake_case('_foo_bar')

    # group (3)
    assert is_snake_case('foo_')
    assert is_snake_case('_foo_')

    # group (4)
    assert not is_snake_case('foo')

    # group (5)
    assert not is_snake_case('foo@bar')
    assert is_snake_case('foo@bar', separator='@')
    assert is_snake_case('foo_bar', separator='@')

    # group (6)
    assert not is_snake_case('foo.bar')
    assert is_sn

# Generated at 2022-06-21 21:27:34.436013
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('foo_bar_baz')
    assert is_snake_case('foo-bar-baz','-')
    assert is_snake_case('foo-bar-baz','-')
    assert is_snake_case('foo.bar.baz','.')
    assert not is_snake_case('foo')



# Generated at 2022-06-21 21:27:38.142810
# Unit test for function is_ip
def test_is_ip():
    assert is_ip("255.200.100.75")
    assert not is_ip("2001:db8:85a3:0000:0000:8a2e:370:7334")
    assert not is_ip("1.2.3")
test_is_ip()


# Generated at 2022-06-21 21:27:50.353661
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('1.2.3.4')
    assert not is_ip_v4('1.2.3.a')
    assert not is_ip_v4('1.2.3')
    assert is_ip_v4('255.255.255.255')
    assert not is_ip_v4('256.255.255.255')
    assert not is_ip_v4('a.b.c.d')
    assert not is_ip_v4('8.8.8.8.8.8')
    assert not is_ip_v4('1.2.3.4.5')
    assert not is_ip_v4('1.2.3.4..')
    assert not is_ip_v4('1.2.3.4.')
    assert not is_

# Generated at 2022-06-21 21:27:58.375565
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('9780306406157').is_isbn_13() == True
    assert __ISBNChecker('978030640615').is_isbn_13() == False
    assert __ISBNChecker('978030640615').is_isbn_13() == False
    assert __ISBNChecker('9780306406152').is_isbn_13() == False
    assert __ISBNChecker('test').is_isbn_13() == False


# Generated at 2022-06-21 21:28:00.458960
# Unit test for function is_pangram
def test_is_pangram():
    pangram = 'The quick brown fox jumps over the lazy dog'
    assert is_pangram(pangram) == True
test_is_pangram()



# Generated at 2022-06-21 21:28:12.453852
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('Madam, I\'m Adam.') is True
    assert is_palindrome('Race car') is True
    assert is_palindrome('Yo, banana boy!') is True
    assert is_palindrome('Not a palindrome') is False
    assert is_palindrome('A man, a plan, a canal, Panama!') is True
    assert is_palindrome('RaCe CaR') is True
    assert is_palindrome('Was it a car or a cat I saw?') is True
    assert is_palindrome('Flee to me, remote elf.') is True
    assert is_palindrome('Dammit, I\'m mad!') is True
    assert is_palindrome('Never odd or even.') is True

# Generated at 2022-06-21 21:28:15.325793
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') == True
    assert is_isbn_10('150-6715214') == True
    assert is_isbn_10('150-6715214', normalize=False) == False


# Generated at 2022-06-21 21:28:23.444002
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('42.0')
    assert not is_decimal('42')
    assert is_decimal('4242e4')
    assert is_decimal('-4242e4')



# Generated at 2022-06-21 21:28:31.269396
# Unit test for function words_count
def test_words_count():
    assert words_count('') == 0
    assert words_count('hello') == 1
    assert words_count('foo bar baz') == 3
    assert words_count('one,two,three.stop') == 4

    # strings composed only by digits are considered words!
    # we can't use "str.isdigit()" because it doesn't accept negative numbers
    assert words_count('123456') == 1
    assert words_count('  123456  ') == 1
    assert words_count('  123456  -321  ') == 2
    assert words_count('  123456  -  321  ') == 2

    # words should be separated by any kind of punctuation
    assert words_count('one.two-three,four;five.six') == 6

    # considering only "real" words
    assert words_count

# Generated at 2022-06-21 21:28:34.737608
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214')
    assert is_isbn_10('150-6715214')
    assert not is_isbn_10('150-6715214', normalize=False)



# Generated at 2022-06-21 21:28:42.533947
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():

    assert __ISBNChecker('0307265613').is_isbn_10() == True
    assert __ISBNChecker('0-307-26561-3').is_isbn_10() == True
    assert __ISBNChecker('0307265662').is_isbn_10() == True
    assert __ISBNChecker('0-307-26566-2').is_isbn_10() == True
    assert __ISBNChecker('0375703867').is_isbn_10() == True
    assert __ISBNChecker('0-375-70386-7').is_isbn_10() == True
    assert __ISBNChecker('0375703875').is_isbn_10() == True
    assert __ISBNChecker('0-375-70387-5').is_isbn_10

# Generated at 2022-06-21 21:28:48.315677
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580') == True
    assert is_isbn_13('978-0312498580') == True
    assert is_isbn_13('978-0312498580', normalize=False) == False
    return 'function is_isbn_13(input_string: str, normalize: bool = True) passed'

print(test_is_isbn_13())


# Generated at 2022-06-21 21:29:00.330824
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('') is False
    assert is_palindrome(' ') is False
    assert is_palindrome('  ') is False
    assert is_palindrome('   ') is False
    assert is_palindrome('LOL') is True
    assert is_palindrome('Lol') is False
    assert is_palindrome('Lol', ignore_case=True) is True
    assert is_palindrome('ROTFL') is False
    assert is_palindrome('ROTFL', ignore_case=True) is False
    assert is_palindrome('ROTOR') is True
    assert is_palindrome('ROTOR', ignore_case=True) is True
    assert is_palindrome('a toyota') is False

# Generated at 2022-06-21 21:29:03.254218
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string(None) == False
    assert is_full_string('') == False
    assert is_full_string(' ') == False
    assert is_full_string('hello') == True



# Generated at 2022-06-21 21:29:06.903473
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string(None) == False
    assert is_full_string('') == False
    assert is_full_string(' ') == False
    assert is_full_string('hello') == True


# Generated at 2022-06-21 21:29:12.800140
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334') == True # return true
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?') == False # return false (invalid "?")


# Generated at 2022-06-21 21:29:14.606590
# Unit test for function is_string
def test_is_string():
    assert is_string('foo') == True
    assert is_string(b'foo') == False


# Generated at 2022-06-21 21:29:28.085026
# Unit test for function is_ip
def test_is_ip():
    assert(is_ip("2001:db8:85a3:0000:0000:8a2e:370:7334"))
    assert(is_ip("255.200.100.75"))

# Generated at 2022-06-21 21:29:30.722342
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('Dermatoglyphics') == True
    assert is_isogram('Cymograph') == True
    assert is_isogram('aba') == False

# Generated at 2022-06-21 21:29:32.459211
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42') # returns true
    assert not is_integer('42.0') # returns false


# Generated at 2022-06-21 21:29:36.638489
# Unit test for function is_ip_v4
def test_is_ip_v4():
    valid = ['192.168.1.1', '255.0.0.1', '113.124.124.124']
    invalid = ['256.0.0.1', '192.168.1', 'nope']

    for ip in valid:
        assert is_ip_v4(ip)

    for ip in invalid:
        assert not is_ip_v4(ip)

# Generated at 2022-06-21 21:29:37.642149
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('my string is <strong>bold</strong>') is True
    assert contains_html('my string is not bold') is False


# Generated at 2022-06-21 21:29:43.166256
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('<strong>bold</strong>') == True
    assert contains_html('<strong><img src="#"/></strong>') == True
    assert contains_html('<strong><img src="#">my image</img></strong>') == True
    assert contains_html('<strong>bold</p>') == True
    assert contains_html('<strong>bold</strong') == True
    assert contains_html('bold</strong>') == True
    assert contains_html('<strong>bold>') == True
    assert contains_html('<strong bold</strong>') == True
    assert contains_html('<a href=#" target="_blank" rel="noopener">test</a>') == True
    assert contains_html('< strong>bold</strong>') == True

# Generated at 2022-06-21 21:29:44.243633
# Unit test for function words_count
def test_words_count():
    """
    Testing words_count functionality.
    """
    assert words_count('hello world') == 2
    assert words_count('one,two,three.stop') == 4



# Generated at 2022-06-21 21:29:46.849997
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-21 21:29:48.941717
# Unit test for function is_json
def test_is_json():
    try:
        json.loads('{"name": "Peter"}')
    except:
        return False
    else:
        return True


# Generated at 2022-06-21 21:30:00.184938
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card("4111111111111111")
    assert is_credit_card("4111111111111")
    assert is_credit_card("4012888888881881")
    assert is_credit_card("378282246310005")
    assert is_credit_card("6011111111111117")
    assert is_credit_card("5105105105105100")
    assert is_credit_card("5105 1051 0510 5106")
    assert not is_credit_card("5105105105105106")
    assert is_credit_card("9111111111111111")
    assert not is_credit_card("4444444444444448")
    assert not is_credit_card("71111111111114")

# Function test for function is_credit_card

# Generated at 2022-06-21 21:30:16.681779
# Unit test for function words_count
def test_words_count():
    words = [
        "hello world",          # space
        "one,two,three.stop",   # punctuation
        "a.b,c:d?e-f"           # mixed
    ]
    assert words_count("") == 0
    assert words_count("! @ # % ... []") == 0
    assert words_count("hello world") == 2
    assert words_count("one,two,three.stop") == 4
    assert words_count("a.b,c:d?e-f") == 6



# Generated at 2022-06-21 21:30:24.617702
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    # Test with right input
    __ISBNChecker('0747532699')
    __ISBNChecker('9780747532693')
    # Test with possible wrong inputs
    try:
        __ISBNChecker(0)
    except Exception as e:
        assert type(e) == InvalidInputError
    try:
        __ISBNChecker(None)
    except Exception as e:
        assert type(e) == InvalidInputError
    try:
        __ISBNChecker('9780747532693 ')
    except Exception as e:
        assert type(e) == InvalidInputError
    try:
        __ISBNChecker(' ')
    except Exception as e:
        assert type(e) == InvalidInputError



# Generated at 2022-06-21 21:30:33.777859
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('foo_bar_baz')
    assert not is_snake_case('foo')
    assert is_snake_case('foo_bar', '-')
    assert is_snake_case('foo_bar', ':')
    assert not is_snake_case('foo', '-')
    assert is_snake_case('foo', ':')
    assert is_snake_case('foo_', '_') # should pass
    assert not is_snake_case('foo_', '-')



# Generated at 2022-06-21 21:30:37.842134
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('Dermatoglyphics') == True
    assert is_isogram('isogram') == True
    assert is_isogram('moose') == False
    assert is_isogram('isIsogram') == False
    assert is_isogram('aba') == False
    assert is_isogram('moOse') == False
    assert is_isogram('thumbscrewjapingly') == True
    assert is_isogram('abcdefghijklmnopqrstuvwxyz') == True
    assert is_isogram('ABCDEFGHIJKLMNOPQRSTUVWXYZ') == True
    assert is_isogram('') == True
    assert is_isogram(' ') == False
    assert is_isogram('- ') == False


# Generated at 2022-06-21 21:30:40.679141
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}')
    assert is_json('[1, 2, 3]')
    assert not is_json('{nope}')



# Generated at 2022-06-21 21:30:48.200280
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1565273147') == True
    assert is_isbn_10('1565273147', normalize=False) == True
    assert is_isbn_10('1565-273147', normalize=False) == False
    assert is_isbn_10('1565-273147') == True
# Function call to unit test is_isbn_10
test_is_isbn_10()


# Generated at 2022-06-21 21:30:51.165700
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string("") == False
    assert is_full_string(" ") == False
    assert is_full_string("12") == True
    assert is_full_string("12") != False


# Generated at 2022-06-21 21:30:57.336767
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('0123456789012').is_isbn_13() == True
    assert __ISBNChecker('0123456789013').is_isbn_13() == False
    assert __ISBNChecker('0-123-45678-9-0-1').is_isbn_13() == True
    assert __ISBNChecker('0-123-45678-9-0-2').is_isbn_13() == False


# Generated at 2022-06-21 21:31:09.994397
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('abcba') == True
    assert is_palindrome('deed') == True
    assert is_palindrome('de ed') == True
    assert is_palindrome('de ed', ignore_spaces=True) == True
    assert is_palindrome('de ed', ignore_case=True) == True
    assert is_palindrome('de ed', ignore_spaces=True, ignore_case=True) == True
    assert is_palindrome('deeq') == False
    assert is_palindrome('de ed', ignore_spaces=False) == False
    assert is_palindrome('de ed', ignore_case=False) == False
    assert is_palindrome('de ed', ignore_spaces=False, ignore_case=False) == False
    assert is_palind

# Generated at 2022-06-21 21:31:12.493717
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    checker = __ISBNChecker('1345552361')
    assert checker.is_isbn_10() == True

    checker = __ISBNChecker('1345552362')
    assert checker.is_isbn_10() == False



# Generated at 2022-06-21 21:31:26.172185
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    print("Testing is_isbn_13()...")
    assert __ISBNChecker("9780143125471").is_isbn_13()
    assert not __ISBNChecker("9780143125472").is_isbn_13()
    assert not __ISBNChecker("0143125471").is_isbn_13()
    print("Success")


# Generated at 2022-06-21 21:31:28.821894
# Unit test for function is_string
def test_is_string():
    assert is_string('foo')
    assert not is_string(b'foo')


# Generated at 2022-06-21 21:31:31.728784
# Unit test for function is_pangram
def test_is_pangram():
    # no panagram
    assert is_pangram('hello world') == False
    # panagram
    assert is_pangram('The quick brown fox jumps over the lazy dog') == True


# Generated at 2022-06-21 21:31:37.058785
# Unit test for function is_uuid
def test_is_uuid():
    result_is_uuid = is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf')
    assert result_is_uuid == True
    result_is_not_uuid = is_uuid('6f8aa2f9686c4ac387665712354a04cf')
    assert result_is_not_uuid == False
    result_is_uuid_hex = is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True)
    assert result_is_uuid_hex == True


# Generated at 2022-06-21 21:31:42.497275
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580') == True
    assert is_isbn_13('978-0312498580') == True
    assert is_isbn_13('978-0312498580', normalize=False) == False
test_is_isbn_13()


# Generated at 2022-06-21 21:31:43.952375
# Unit test for function is_url
def test_is_url():
    assert is_url("http://mysite.com")


# Generated at 2022-06-21 21:31:46.845008
# Unit test for function is_number
def test_is_number():
    assert is_number('-9.12') == True
    assert is_number('1e3') == True
    assert is_number('1 2 3') == False
test_is_number()



# Generated at 2022-06-21 21:31:49.723100
# Unit test for function is_string
def test_is_string():
    assert is_string('foo') == True, 'function is_string does not work as expected, please fix it'
    assert is_string(b'foo') == False, 'function is_string does not work as expected, please fix it'



# Generated at 2022-06-21 21:31:54.622292
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string(None) == False
    assert is_full_string('') == False
    assert is_full_string(' ') == False
    assert is_full_string('hello') == True
#test_is_full_string()



# Generated at 2022-06-21 21:31:59.816312
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram("Machine") == True
    assert is_isogram("isogram") == True
    assert is_isogram("aba") == False
    assert is_isogram("moOse") == False
    assert is_isogram("isIsogram") == False
    assert is_isogram("") == True
test_is_isogram()

# Generated at 2022-06-21 21:32:17.090321
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False

# Test cases for function is_ip_v4
#sys.tracebacklimit = 0
test_case = [('255.200.100.75', True), ('nope', False), ('255.200.100.999', False)]


# Generated at 2022-06-21 21:32:18.570672
# Unit test for function is_string
def test_is_string():
    assert is_string('foo')
    assert not is_string(b'foo')


# Generated at 2022-06-21 21:32:22.275391
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') # returns true
    assert is_url('https://mysite.com') # returns true
    assert not is_url('.mysite.com') # returns false


# Generated at 2022-06-21 21:32:24.083505
# Unit test for function is_string
def test_is_string():
    assert is_string('hello') == True
    assert is_string(b'hello') == False


# Generated at 2022-06-21 21:32:28.152397
# Unit test for function is_ip
def test_is_ip():
    assert is_ip("192.168.10.57")
    assert is_ip("2001:db8:85a3:0000:0000:8a2e:370:7334")
    assert not is_ip("1.2.3")


# Generated at 2022-06-21 21:32:37.449958
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title') == True
    assert is_slug('My blog post title') == False
    assert is_slug('') == False
    assert is_slug(None) == False
    assert is_slug('你好') == False
    assert is_slug('hello_world') == False
    assert is_slug('hello-world') == True
    assert is_slug('hello--world') == True
    assert is_slug('hello--world', '-') == True
    assert is_slug('hello--world', '-!').value() == False
    assert is_slug('hello-_world', '-_') == True

# Generated at 2022-06-21 21:32:48.696670
# Unit test for function is_isbn
def test_is_isbn():
    # fail_list = [
    #         "",
    #         None,
    #         0,
    #         "0",
    #         "1506715214",
    #         "9780312519440",
    #         "978-0312519440",
    # ]
    # for st in fail_list:
    #     is_isbn(st)
    # success_list = [
    #         "9780312498580",
    #         "978-0312498580",
    #         "0-312-498580",
    #         "978-0134663344"
    # ]
    # for st in success_list:
    #     is_isbn(st)
    is_isbn("9780312519440")

# Generated at 2022-06-21 21:32:53.528560
# Unit test for function is_number
def test_is_number():
    assert is_number('42') == True
    assert is_number('19.99') == True
    assert is_number('-9.12') == True
    assert is_number('1e3') == True
    assert is_number('1 2 3') == False
    assert is_number(42) == False

# Generated at 2022-06-21 21:32:57.797709
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    checker = __ISBNChecker('3526612621')
    assert(checker.is_isbn_13() == True)
    checker = __ISBNChecker('1-4302-5575-0')
    assert(checker.is_isbn_13() == False)


# Generated at 2022-06-21 21:33:02.069867
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert not is_isbn_13(None)
    assert not is_isbn_13('')
    assert not is_isbn_13('9780312498580')
    assert not is_isbn_13('978-0312498580')
    assert not is_isbn_13('978-0312498580', normalize=False)



# Generated at 2022-06-21 21:33:14.987834
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214')
    assert is_isbn_10('150-6715214')
    assert is_isbn_10('150-6715214', normalize=False) == False



# Generated at 2022-06-21 21:33:19.686130
# Unit test for function is_number
def test_is_number():
    assert is_number('42') == True
    assert is_number('19.99') == True
    assert is_number('-9.12') == True
    assert is_number('1e3') == True
    assert is_number('1 2 3') == False

