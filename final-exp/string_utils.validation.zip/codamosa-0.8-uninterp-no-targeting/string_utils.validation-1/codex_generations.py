

# Generated at 2022-06-21 21:23:50.896305
# Unit test for function is_credit_card
def test_is_credit_card():
    # test if credit_card is a string
    assert is_credit_card('4408041234567893') == True
    assert is_credit_card('5167910904612328') == True
    assert is_credit_card('372918856543002') == True
    assert is_credit_card('6011372227643590') == True
    assert is_credit_card('3566002020360505') == True
    assert is_credit_card('3528000700000000') == True
    assert is_credit_card('3589492047697002') == True

    # test if credit_card is not a string
    assert is_credit_card(4408041234567893) == False
    assert is_credit_card(5167910904612328) == False

# Generated at 2022-06-21 21:24:02.549761
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    print("Testing method is_isbn_13 of class __ISBNChecker ...")


# Generated at 2022-06-21 21:24:08.174105
# Unit test for function is_ip
def test_is_ip():
    assert is_ip("255.200.100.75")
    assert is_ip("2001:db8:85a3:0000:0000:8a2e:370:7334")
    assert not is_ip("1.2.3")



# Generated at 2022-06-21 21:24:11.596783
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') == True
    assert is_isbn_10('150-6715214') == True
    assert is_isbn_10('150-6715214', normalize=False) == False
test_is_isbn_10()



# Generated at 2022-06-21 21:24:15.645236
# Unit test for function words_count
def test_words_count():
    assert words_count('') == 0, 'Empty string!'
    assert words_count('hello world') == 2, 'Invalid count!'
    assert words_count('one,two,three.stop') == 4, 'Invalid count!'
    assert words_count('! @ # % ... []') == 0, 'Invalid count!'

test_words_count()


# Generated at 2022-06-21 21:24:19.574378
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    assert __ISBNChecker('978-1-56619-909-4').input_string == '9781566199094'
    assert __ISBNChecker('9781566199094').input_string == '9781566199094'


# PUBLIC API



# Generated at 2022-06-21 21:24:29.608665
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('42') == True
    assert is_decimal('42.123') == True
    assert is_decimal('-123') == True
    assert is_decimal('+123') == True
    assert is_decimal('123.123') == True
    assert is_decimal('-123.123') == True
    assert is_decimal('+123.123') == True
    assert is_decimal('b') == False
    assert is_decimal('1e-3') == False
    assert is_decimal('1E-3') == False
    assert is_decimal('1e+3') == False
test_is_decimal()



# Generated at 2022-06-21 21:24:39.397073
# Unit test for function is_email
def test_is_email():
    print("Testing test_is_email()")
    assert is_email('my.email@the-provider.com')
    assert not is_email('@gmail.com')
    assert not is_email('.my.email@the-provider.com')
    assert not is_email('my.email@the-provider.com/')
    assert not is_email('my.email@the-provider.com?')
    #
    assert is_email("abc\\@def@example.com")
    assert is_email("abc\\\\@example.com")
    assert not is_email("abc@def@example.com")
    assert not is_email("abc\\\\@def@example.com")
    assert is_email("\"quoted\\\"\"@example.com")
    assert is_email("a@b.c")

# Generated at 2022-06-21 21:24:41.752911
# Unit test for function is_string
def test_is_string():
    assert is_string('foo')
    assert not is_string(b'foo')
    assert not is_string(123)



# Generated at 2022-06-21 21:24:44.078116
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580') == True
    assert is_isbn_13('978-0312498580') == True
    assert is_isbn_13('978-0312498580', normalize=False) == False
test_is_isbn_13()

# Generated at 2022-06-21 21:24:56.430641
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title') == True, \
        "is_slug should be true for 'my-blog-post-title'."
    assert is_slug('My blog post title') == False, \
        "is_slug should be false for 'My blog post title'."



# Generated at 2022-06-21 21:25:03.666496
# Unit test for function words_count
def test_words_count():
    assert words_count('123abc') == 2, 'Test failed: words_count()'
    assert words_count('one') == 1, 'Test failed: words_count()'
    assert words_count('one,two,three.stop') == 4, 'Test failed: words_count()'
    assert words_count('hello world') == 2, 'Test failed: words_count()'
    assert words_count('! @ # %...[]') == 0, 'Test failed: words_count()'

test_words_count()

# Generated at 2022-06-21 21:25:08.412385
# Unit test for function is_url
def test_is_url():
    assert is_url('https://www.mysite.com') == True
    assert is_url('ftp://user@ip/path') == True
    assert is_url('http://192.168.0.1/page.html') == True
    assert is_url('www.mysite.com') == False
    assert is_url('mysite.com') == False
    assert is_url('mysite') == False
    assert is_url('/path/to/page.html') == False
    assert is_url('') == False
    assert is_url(None) == False



# Generated at 2022-06-21 21:25:15.738157
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-84-9362217-1').is_isbn_13()
    assert not __ISBNChecker('978-84-9362217-0').is_isbn_13()
    assert not __ISBNChecker('978-84-936221-75').is_isbn_13()
    assert not __ISBNChecker('978-84-9362217-A').is_isbn_13()


# Generated at 2022-06-21 21:25:19.181405
# Unit test for function is_full_string
def test_is_full_string():
    assert not is_full_string(None)
    assert not is_full_string('')
    assert not is_full_string(' ')
    assert is_full_string('hello')



# Generated at 2022-06-21 21:25:20.803065
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580') is True
    assert is_isbn_13('978-0312498580') is True
    assert is_isbn_13('978-0312498580', False) is False

# Generated at 2022-06-21 21:25:26.251266
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    checker = __ISBNChecker("080442957X")
    assert checker.is_isbn_10() == True

    checker = __ISBNChecker("080442957")
    assert checker.is_isbn_10() == False

    checker = __ISBNChecker("080442957XX")
    assert checker.is_isbn_10() == False


# Generated at 2022-06-21 21:25:33.970947
# Unit test for function is_url
def test_is_url():
    assert is_url("https://www.google.com") == True
    assert is_url("www.google.com") == False
    assert is_url("google.com") == False
    assert is_url("http://google.com") == True
    # assert is_url("https://google.com") == True
    assert is_url("www.google.com/search") == False
    assert is_url("www.google.com/search?q=hello") == False


# Generated at 2022-06-21 21:25:42.179131
# Unit test for function contains_html
def test_contains_html():
    assert( contains_html('') == False)
    assert( contains_html('<') == False)
    assert( contains_html('<>') == False)
    assert( contains_html('<asdf>') == True)
    assert( contains_html('<asdf>234</asdf>') == True)
    assert( contains_html('</asdf>234</asdf>') == True)
    assert( contains_html('234</asdf>234</asdf>') == True)
    assert( contains_html('234<asdf>234</asdf>') == True)
    assert( contains_html('<asdf>234<asdf>234</asdf>') == True)
    assert( contains_html('234<asdf>234<asdf>234</asdf>') == True)

# Generated at 2022-06-21 21:25:52.428571
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('42.0') == True
    assert is_decimal('42') == False
    assert is_decimal("45") == False
    assert is_decimal("-1") == False
    assert is_decimal("5.0") == True
    assert is_decimal("7.0") == True
    assert is_decimal("4.000") == True
    assert is_decimal("4.0") == True
    assert is_decimal("-4.0") == True
    assert is_decimal("-1.0") == True
    assert is_decimal("-2.0") == True
    assert is_decimal("0.0") == True
    assert is_decimal("0.00") == True
    assert is_decimal("0.000000") == True
    assert is_dec

# Generated at 2022-06-21 21:26:01.584950
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42')
    assert not is_integer('42.42')
    assert not is_integer('42.0')
    assert not is_integer('-42.0')


# Generated at 2022-06-21 21:26:04.914204
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') == True
    assert is_isbn_10('150-6715214') == False
    assert is_isbn_10('150-6715214', normalize=False) == False


# Generated at 2022-06-21 21:26:11.700094
# Unit test for function is_pangram
def test_is_pangram():
    try:
        assert is_pangram('The quick brown fox jumps over the lazy dog') == True # returns true
        assert is_pangram('hello world') == False
        assert is_pangram('Pack my box with five dozen liquor jugs') == True
    except:
        print("Error in function is_pangram")
       
test_is_pangram()        


# Generated at 2022-06-21 21:26:19.506285
# Unit test for function is_ip
def test_is_ip():
    # ipv4
    assert is_ip('255.200.100.75'), "v4 ip should be valid"
    assert not is_ip('1.2.3'), "v4 ip should not be valid"

    # ipv6
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334'), "v6 ip should be valid"
    assert not is_ip('2001:db8:85a3:0000:0000:8a2e:370:?'), "v6 ip should not be valid"



# Generated at 2022-06-21 21:26:22.364190
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75') is True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') is True
    assert is_ip('1.2.3') is False


# Generated at 2022-06-21 21:26:34.330704
# Unit test for function is_json
def test_is_json():
    j1 = '{"name": "Pete"}'
    j2 = '[1, 2, "three"]'
    no_j1 = '{nope}'
    no_j2 = 'heiheie'
    no_j3 = 'null'
    no_j4 = '[1, 2, 3,]'
    no_j5 = 'false'
    no_j6 = '[]'
    no_j7 = 's'
    assert is_json(j1) == True
    assert is_json(j2) == True
    assert is_json(no_j1) == False
    assert is_json(no_j2) == False
    assert is_json(no_j3) == True
    assert is_json(no_j4) == False
    assert is_json(no_j5)

# Generated at 2022-06-21 21:26:37.300126
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214')
    assert is_isbn_10('150-6715214')
    assert not is_isbn_10('150-6715214', normalize=False)



# Generated at 2022-06-21 21:26:39.748463
# Unit test for function is_string
def test_is_string():
    assert is_string('test') == True
    assert is_string('') == True
    assert is_string(10) == False
    assert is_string(b'test') == False


# Generated at 2022-06-21 21:26:43.794605
# Unit test for function contains_html
def test_contains_html():
  assert(contains_html("my string is <strong>bold</strong>") == True)
  assert(contains_html("my string is not bold") == False)

# Test for function contains_html
test_contains_html()

# Generated at 2022-06-21 21:26:53.734981
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    obj = __ISBNChecker('9781617293290')
    assert obj.input_string == '9781617293290'

    obj = __ISBNChecker('978-1-617-29329-0')
    assert obj.input_string == '9781617293290'

    obj = __ISBNChecker('978-1-617-29329-0', normalize=False)
    assert obj.input_string == '978-1-617-29329-0'

    try:
        __ISBNChecker(1233)
    except InvalidInputError:
        pass

    try:
        __ISBNChecker('978-1-617-29329-0', normalize=True)
    except InvalidInputError:
        pass


# Generated at 2022-06-21 21:27:04.915443
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com')
    assert is_url('https://mysite.com')
    assert is_url('https://mysite.com/page.html')
    assert is_url('https://www.mysite.com/page.html')
    assert is_url('https://www.mysite.com/folder/page.html')
    assert is_ftp('ftp://mysite.com')
    assert is_ftp('ftp://mysite.com/file.txt')
    assert is_ftp('ftp://mysite.com/folder/file.txt')
    assert is_url('htts://mysite.com') is False
    assert is_url('https://mysite') is False
    assert is_url('https://mysite.') is False
    assert is_url

# Generated at 2022-06-21 21:27:13.330343
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    # simulating list of isbn-10
    assert __ISBNChecker('0385472579', normalize=False).is_isbn_10() == True
    assert __ISBNChecker('038547257X', normalize=False).is_isbn_10() == True
    assert __ISBNChecker('0385472587', normalize=False).is_isbn_10() == True
    assert __ISBNChecker('0385472595', normalize=False).is_isbn_10() == True
    assert __ISBNChecker('0385472609', normalize=False).is_isbn_10() == True
    assert __ISBNChecker('0385472625', normalize=False).is_isbn_10() == True

# Generated at 2022-06-21 21:27:18.821722
# Unit test for function is_ip_v6
def test_is_ip_v6():
    # Checking for correct format
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334')
    # Checking for wrong format
    assert not is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?')
    # Empty value considered wrong
    assert not is_ip_v6('')


# Generated at 2022-06-21 21:27:23.445381
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('LOL')
    assert is_palindrome('I topi non avevano nipoti', ignore_spaces=True)
    assert not is_palindrome('I topi non avevano nipoti')
    assert is_palindrome('Lol', ignore_case=True)
    assert not is_palindrome('Lol')
    assert not is_palindrome('ROTFL')
    assert is_palindrome('LOL')
    print('Test is_palindrome passed')
test_is_palindrome()


# Generated at 2022-06-21 21:27:31.177332
# Unit test for function contains_html
def test_contains_html():

    assert contains_html('<p>Consectetur ea aute consequat eu quis commodo ut non aliqua ullamco dolor.</p>') is True
    assert contains_html('Consequat id dolor deserunt sint ad ex ullamco anim irure excepteur voluptate.') is False

# Generated at 2022-06-21 21:27:39.785958
# Unit test for function is_url
def test_is_url():
    assert not is_url(None)
    assert not is_url('')
    assert not is_url('www.mysite.com')
    assert not is_url('.mysite.com')
    assert not is_url('http://trailingdot.')
    assert is_url('http://www.mysite.com')
    assert is_url('https://mysite.com')
    assert is_url('http://mysite.com')
    assert is_url('http://mysite.com/page')
    assert is_url('http://mysite.com/page.html')
    assert is_url('http://mysite.com/page.html?id=123')
    assert is_url('http://mysite.com/page.html?id=123&name=test')

# Generated at 2022-06-21 21:27:47.282377
# Unit test for function is_slug
def test_is_slug():
    assert is_slug("test-is-slug-") == True
    assert is_slug("test-is-slug") == True
    assert is_slug("test-is-slug-2") == True
    assert is_slug("test-IS-SLUG") == False
    assert is_slug("test-is-slug-@") == False

# Generated at 2022-06-21 21:27:51.272217
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('6011121212121212') == True
    assert is_credit_card('601112121212121') == False
    assert is_credit_card('') == False



# Generated at 2022-06-21 21:27:53.819445
# Unit test for function is_full_string
def test_is_full_string():
    assert not is_full_string(None)
    assert not is_full_string('')
    assert not is_full_string(' ')
    assert is_full_string('hello')



# Generated at 2022-06-21 21:27:58.974758
# Unit test for function contains_html
def test_contains_html():
    assert not contains_html('')
    assert contains_html('<p>foo</p>')
    assert contains_html('<p>foo')
    assert contains_html('bar<br/>')
    assert contains_html('<a href="http://example.com">Example</a>')
    assert contains_html('<!--/**/-->')
    assert contains_html('<!----><p><a href="http://example.com">Example</a></p><br>')
    assert contains_html('<p>bar<script type="text/javascript">foo();</script></p>')
    assert contains_html('<span>foo<span>bar</span></span>')
    assert contains_html('<<p>foo</p>')
    assert contains_html('<p>>foo</p>')

# Generated at 2022-06-21 21:28:13.672560
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-83-914607-7-2').is_isbn_13()
    assert __ISBNChecker('9788391460772').is_isbn_13()
    assert __ISBNChecker('9788391460772', False).is_isbn_13()

    assert not __ISBNChecker('978-83-914607-7-1').is_isbn_13()
    assert not __ISBNChecker('9788391460771').is_isbn_13()
    assert not __ISBNChecker('9788391460771', False).is_isbn_13()


# Generated at 2022-06-21 21:28:24.978896
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    # assert __ISBNChecker('978-3-16-148410-0').input_string == '9783161484100'
    # assert not is_string(__ISBNChecker('978-3-16-148410-0').input_string)  # type: ignore
    assert __ISBNChecker('9783161484100', normalize=False).input_string == '9783161484100'
    # assert not is_string(__ISBNChecker('9783161484100', normalize=False).input_string)  # type: ignore
    assert __ISBNChecker('9783161484100', normalize=True).input_string == '9783161484100'
    # assert not is_string(__ISBNChecker('9783161484100', normalize=True).input_string)  # type:

# Generated at 2022-06-21 21:28:29.163215
# Unit test for function is_email
def test_is_email():
    test = is_email("jjkruggel@gmail.com")
    assert test == True
    test = is_email("jjkruggel@")
    assert test == False
    test = is_email("jjkru@gmail.com")
    assert test == True
    test = is_email("@gmail.com")
    assert test == False



# Generated at 2022-06-21 21:28:32.278052
# Unit test for function is_full_string
def test_is_full_string():
    assert not is_full_string(None)
    assert not is_full_string('')
    assert not is_full_string(' ')
    assert is_full_string('Hello')



# Generated at 2022-06-21 21:28:37.945078
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('foo_bar_baz') == True
    assert is_snake_case('foo') == False
    assert is_snake_case('foo_bar_baz', '-') == False
    assert is_snake_case('foo-bar-baz', '-') == True
    assert is_snake_case('fooBarBaz') == False



# Generated at 2022-06-21 21:28:44.053364
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert(is_ip_v4('255.200.100.75') == True)
    assert(is_ip_v4('nope') == False)
    assert(is_ip_v4('255.200.100.999') == False)
    log.info("[Test] is_ip_v4(input_string) function passed.")



# Generated at 2022-06-21 21:28:47.929215
# Unit test for function is_decimal
def test_is_decimal():
    testCase_list = ['42.0', '42']
    check_list = [True, False]
    for i in testCase_list:
        assert is_decimal(i) == check_list[testCase_list.index(i)]
test_is_decimal()



# Generated at 2022-06-21 21:28:53.306321
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker("0306406152").is_isbn_10()
    assert __ISBNChecker("0306406152").is_isbn_10()
    assert not __ISBNChecker("030640615").is_isbn_10()
    assert not __ISBNChecker("00306406152").is_isbn_10()
    assert not __ISBNChecker("030e406152").is_isbn_10()
    assert not __ISBNChecker("").is_isbn_10()
    assert not __ISBNChecker("a").is_isbn_10()



# Generated at 2022-06-21 21:29:04.156836
# Unit test for function is_credit_card
def test_is_credit_card():
    assert(is_credit_card('4929804463622139') == True)
    assert(is_credit_card('4929804463622139', card_type = 'VISA') == True)
    assert(is_credit_card('4716461583322103') == True)
    assert(is_credit_card('4716461583322103', card_type = 'VISA') == False)
    assert(is_credit_card('4716-2210-5188-5662') == True)
    assert(is_credit_card('4716221051885662') == True)
    assert(is_credit_card('4111111111111111') == True)
    assert(is_credit_card('4111111111111111', card_type = 'VISA') == False)

# Generated at 2022-06-21 21:29:07.632153
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string('paul') == True
    assert is_full_string('') == False
    assert is_full_string('     ') == False


# Generated at 2022-06-21 21:29:18.472216
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('MyString')
    assert is_camel_case('MYSTRING')
    assert is_camel_case('myString')
    assert is_camel_case('mystring')
    assert is_camel_case('myString4You')
    assert is_camel_case('MyString4YOU')
    assert is_camel_case('MyString4Y0U')
    assert is_camel_case('3MyString') == False
    assert is_camel_case('') == False
    assert is_camel_case('my string') == False
    assert is_camel_case('my string 4you') == False
    assert is_camel_case('MyString-4you') == False
    assert is_camel_case('MyString.4you') == False




# Generated at 2022-06-21 21:29:22.704608
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6("2001:db8:85a3:0000:0000:8a2e:370:7334") == True
    assert is_ip_v6("2001:db8:85a3:0000:0000:8a2e:370:?") == False



# Generated at 2022-06-21 21:29:28.935141
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    # Arrange
    c = None

    # Act
    c = __ISBNChecker('978-0-306-40615-7')

    # Assert
    assert c is not None, 'c should not be None since it is initialized successfully'


# Generated at 2022-06-21 21:29:37.450569
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('0.0.0.0') == True
    assert is_ip('255.255.255.255') == True
    assert is_ip('10.20.30.40') == True
    assert is_ip('255.0.0.0') == True
    assert is_ip('10.255.0.0') == True
    assert is_ip('10.0.255.0') == True
    assert is_ip('10.0.0.255') == True
    assert is_ip('2001:db8:85a3:08d3:1319:8a2e:0370:7334') == True
    assert is_ip('2001::') == True
    assert is_ip('0010:6553::9be9') == True

# Generated at 2022-06-21 21:29:41.490259
# Unit test for function is_full_string
def test_is_full_string():
    assert not is_full_string(None)
    assert not is_full_string('')
    assert not is_full_string(' ')
    assert is_full_string('hello')



# Generated at 2022-06-21 21:29:51.323219
# Unit test for function is_email
def test_is_email():
    assert is_email('x@x.x')
    assert is_email('foo@bar.com')
    assert is_email('foo@bar.foo.com')
    assert is_email('foo+bar@bar.com')
    assert is_email('"foo=bar"@bar.com')
    assert is_email('"foo@bar"@bar.com')
    assert is_email('"foo@bar"@bar.com,')
    assert is_email('"foo\\@bar"@bar.com')
    assert is_email('"first\"last"@example.com')
    assert is_email('"first@last"@iana.org')
    assert is_email('"first\last"@iana.org')
    assert is_email('customer/department=shipping@example.com')

# Generated at 2022-06-21 21:29:56.871705
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('LOL') is True # Test 1
    assert is_palindrome('Lol') is False # Test 2
    assert is_palindrome('Lol', ignore_case=True) is True # Test 3
    assert is_palindrome('ROTFL') is False # Test 4

test_is_palindrome()



# Generated at 2022-06-21 21:29:58.877303
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('42.0') == True
    assert is_decimal('42') == False
test_is_decimal()



# Generated at 2022-06-21 21:30:03.912208
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('') == False
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') == True
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf') == False
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True) == True

# Generated at 2022-06-21 21:30:13.548982
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4005519200000004')
    assert is_credit_card('4005519200000004', card_type='VISA')
    assert not is_credit_card('4005519200000004', card_type='MASTERCARD')
    assert is_credit_card('4444444444444448')
    assert is_credit_card('4532165661234548')
    assert not is_credit_card('4532165661234548', card_type='VISA')
    assert is_credit_card('4532165661234548', card_type='MASTERCARD')
    assert not is_credit_card('4532165661234548', card_type='AMERICAN_EXPRESS')
    assert is_credit_card('6011375537800272')

# Generated at 2022-06-21 21:30:33.152467
# Unit test for function is_palindrome
def test_is_palindrome():
    # Test palindrome: string with no white spaces
    assert is_palindrome('aabb') == False
    assert is_palindrome('aabba') == False
    assert is_palindrome('abcdabcd') == False
    assert is_palindrome('abcabcabcabc') == False
    assert is_palindrome('abcabcabcabcb') == False
    assert is_palindrome('abba') == True
    assert is_palindrome('abcba') == True
    assert is_palindrome('abccba') == True
    assert is_palindrome('abcdefedcba') == True
    # Test palindrome: string with white spaces
    assert is_palindrome('abb a') == False
    assert is_palindrome('ab ba') == True

# Generated at 2022-06-21 21:30:36.387942
# Unit test for function is_full_string
def test_is_full_string():
    assert not is_full_string(None)
    assert not is_full_string('')
    assert not is_full_string(' ')
    assert is_full_string('hello')


# Generated at 2022-06-21 21:30:45.737160
# Unit test for function is_camel_case
def test_is_camel_case():
    assert not is_camel_case(None)
    assert not is_camel_case('')
    assert not is_camel_case(' ')
    assert not is_camel_case('1')
    assert not is_camel_case('MyString1')
    assert not is_camel_case('myString')
    assert not is_camel_case('my1String')
    assert not is_camel_case('my1String')
    assert not is_camel_case('my-string')
    assert not is_camel_case('my_string')
    assert is_camel_case('MyString')



# Generated at 2022-06-21 21:30:51.108486
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?') == False
test_is_ip_v6()


# Generated at 2022-06-21 21:31:00.334321
# Unit test for function is_snake_case
def test_is_snake_case():
    # Define function inputs
    test_inputs = ['foo_bar_baz',
                   'foo_bar_baz',
                   'foo',
                   'foo_bar_baz',
                   'foo',
                   'foo-bar-baz']

    # Define expected outputs
    expected_outputs = [True,
                        False,
                        False,
                        True,
                        True,
                        True]

    # Define parameters
    test_parameters = [None,
                       None,
                       None,
                       '_',
                       '-',
                       '-']

    # Compare outputs
    for x, y, z in zip(test_inputs, expected_outputs, test_parameters):
        output = is_snake_case(x, z)
        assert output == y



# Generated at 2022-06-21 21:31:04.772249
# Unit test for function is_isogram
def test_is_isogram():
    # Test if the function can check isogram
    assert is_isogram('dermatoglyphics') == True
    # Test whether function can filter repeated char
    assert is_isogram('hello') == False
test_is_isogram()



# Generated at 2022-06-21 21:31:12.015828
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title') is True
    assert is_slug('my-böö-post-title') is True
    assert is_slug('my-blog-post-title-') is False
    assert is_slug('MY_BLOG_POST_TITLE') is False
    assert is_slug('my blog post title') is False
    assert is_slug('MY/blog-post-title') is False



# Generated at 2022-06-21 21:31:13.577389
# Unit test for function is_string
def test_is_string():
    test_obj = 'foo'
    assert is_string(test_obj)


# Generated at 2022-06-21 21:31:19.936458
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('MyString')
    assert is_camel_case('My NUMBER')
    assert is_camel_case('MyNUMBER')
    assert is_camel_case('My0NUMBER')
    assert is_camel_case('0MyNUMBER') is False
    assert is_camel_case('_MyNUMBER') is False
    assert is_camel_case('mystring') is False


# Generated at 2022-06-21 21:31:31.061757
# Unit test for function is_palindrome
def test_is_palindrome():
    assert(is_palindrome('mamma'))
    assert(is_palindrome('Anna'))
    assert(is_palindrome('Anna', ignore_case=True))
    assert(is_palindrome('Anna', ignore_case=True))
    assert(is_palindrome('Anna', ignore_case=True, ignore_spaces=True))
    assert(is_palindrome('A man, a plan, a canal, Panama.'))
    assert(not is_palindrome('A man, a plan, a canal, Panama', ignore_spaces=True))
    assert(is_palindrome('Madam, in Eden, I’m Adam.'))
    assert(is_palindrome('Never odd or even'))

# Generated at 2022-06-21 21:31:48.160254
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4716061701329552') is True
    assert is_credit_card('4716 0617 0132 9552') is True
    assert is_credit_card('4716-0617-0132-9552') is True
    assert is_credit_card('4716 0617 0132 9552') is True
    assert is_credit_card('4716 0617 0132 9552', card_type='VISA') is True
    assert is_credit_card('4716 0617 0132 9552', card_type='MASTERCARD') is False
    assert is_credit_card('4716 0617 0132 9552', card_type='AMERICAN_EXPRESS') is False
    assert is_credit_card('4716 0617 0132 9552', card_type='DINERS_CLUB') is False

# Generated at 2022-06-21 21:31:51.716715
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580') == True
    assert is_isbn_13('978-0312498580') == True
    assert is_isbn_13('978-0312498580', normalize=False) == False
    return True

# Generated at 2022-06-21 21:31:57.686643
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    try:
        __ISBNChecker(123)
    except InvalidInputError as e:
        pass
    else:
        raise Exception("Invalid input must raise InvalidInputError")

    try:
        __ISBNChecker("123")
    except InvalidInputError as e:
        raise Exception("String must not raise InvalidInputError")


# PUBLIC API



# Generated at 2022-06-21 21:32:09.275526
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('my string is <strong>bold</strong>') == True
    assert contains_html('my string is not bold') == False
    assert contains_html('my string is <a href="http://www.wikipedia.org/">Wikipedia</a>') == True
    assert contains_html('my string is &lt;strong&gt;bold&lt;/strong&gt;') == False
    assert contains_html('my string is a <a href="http://www.wikipedia.org/">Wikipedia</a>') == True
    assert contains_html('my string is a <a href="http://www.wikipedia.org/">Wikipedia</a> article') == True
    assert contains_html('<a href="http://www.wikipedia.org/">Wikipedia</a>') == True

# Generated at 2022-06-21 21:32:16.265700
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') is True
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf') is False
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True) is True
test_is_uuid()
    

# Generated at 2022-06-21 21:32:17.584566
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580') is True

# Generated at 2022-06-21 21:32:20.116815
# Unit test for function is_number
def test_is_number():
    assert is_number('42')
    assert is_number('19.99')
    assert is_number('-9.12')
    assert is_number('1e3')
    assert not is_number('1 2 3')


# Generated at 2022-06-21 21:32:31.140776
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case(None) == False
    assert is_camel_case('') == False
    assert is_camel_case(' ') == False
    assert is_camel_case(' myString') == False
    assert is_camel_case('  myString') == False
    assert is_camel_case('myString ') == False
    assert is_camel_case('myString  ') == False
    assert is_camel_case('MyString') == True
    assert is_camel_case('_MyString') == False
    assert is_camel_case('myString') == False
    assert is_camel_case('my_string') == False



# Generated at 2022-06-21 21:32:34.926260
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title') is True
    assert is_slug('My blog post title') is False
    assert is_slug('my-blog-post-title', '_') is True
    

# Generated at 2022-06-21 21:32:45.334397
# Unit test for function is_isbn
def test_is_isbn():
    isbn1 = is_isbn('9788467720236')
    assert(isbn1)

    isbn2 = is_isbn('978-8471540446')
    assert(isbn2)

    isbn3 = is_isbn('9780312498580')
    assert(isbn3)

    isbn4 = is_isbn('978-84-15-40446-1')
    assert(isbn4)

    isbn5 = is_isbn('9780312498580', normalize=False)
    assert(not isbn5)

    isbn6 = is_isbn('9788475251373')
    assert(not isbn6)


# Generated at 2022-06-21 21:32:53.780144
# Unit test for function is_email
def test_is_email():
    value="123@456.com"
    if is_email(value):
        print("right")
    else:
        print("wrong")


# Generated at 2022-06-21 21:33:05.967262
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('9780132350884').is_isbn_13()
    assert __ISBNChecker('9791130323492').is_isbn_13()
    assert __ISBNChecker('9780596516178').is_isbn_13()

    assert not __ISBNChecker('9780132350881').is_isbn_13()
    assert not __ISBNChecker('9791130323491').is_isbn_13()
    assert not __ISBNChecker('9780596516175').is_isbn_13()

    # Invalid inputs
    invalid_input = [
        None,
        '',
        '    ',
        0,
        b'',
    ]


# Generated at 2022-06-21 21:33:17.805283
# Unit test for function is_isogram
def test_is_isogram():
    cases = [
        ('', True),
        ('isogram', True),
        ('eleven', False),
        ('subdermatoglyphic', True),
        ('Alphabet', False),
        ('thumbscrew-japingly', True),
        ('6-1-6', True),
        ('Emily Jung Schwartzkopf', True),
        ('dermatoglyphics', True),
        ('moose', False),
        ('helicopter', False),
        ('heeellooo', False),
        (None, False),
        (123, False),
        ({}, False),
        ([], False),
        (False, False),
        (True, False),
        (('a', 'b'), False)
    ]
