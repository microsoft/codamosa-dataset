

# Generated at 2022-06-21 21:23:37.573995
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('42.0') == True
    assert is_decimal('42') == False
    assert is_decimal('42.000') == True


# Generated at 2022-06-21 21:23:40.291112
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') == True
    assert is_isbn_10('150-6715214') == True
    assert is_isbn_10('150-6715214', normalize=False) == False


# Generated at 2022-06-21 21:23:43.182319
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42') == True
    assert is_integer('42.0') == False



# Generated at 2022-06-21 21:23:45.430449
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('isogram') == True
    assert is_isogram('Isogram') == True
    assert is_isogram('Dermatoglyphics') == True
    assert is_isogram('moOse') == False
    assert is_isogram('abCD') == False
    assert is_isogram('AaBbCc') == False
    assert is_isogram('') == True


# Generated at 2022-06-21 21:23:49.868330
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580')
    assert is_isbn_13('978-0312498580')
    assert is_isbn_13('978-0312498580', normalize=False) 



# Generated at 2022-06-21 21:24:01.198421
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('my_string')
    assert is_snake_case('my_string-test')
    assert is_snake_case('my-string-test')
    assert is_snake_case('my_string_test')
    assert is_snake_case('my-string_test')
    assert is_snake_case('my-string_test') is False
    assert is_snake_case('my-string-test') is False
    assert is_snake_case('my_string-test') is False
    assert is_snake_case('1st_string') is False
    assert is_snake_case('_st_string') is False
    assert is_snake_case('st_string') is False



# Generated at 2022-06-21 21:24:05.773480
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    checker = __ISBNChecker('978-0-596-52068-7', True)
    assert checker.is_isbn_13() == True

    checker = __ISBNChecker('0-596-52068-9', True)
    assert checker.is_isbn_13() == False



# Generated at 2022-06-21 21:24:15.525515
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram("The quick brown fox jumps over the lazy dog.") == True
    assert is_pangram("The_quick_brown_fox_jumps_over_the_lazy_dog") == False
    assert is_pangram("Thequickbrownfoxjumpsoverthelazydog") == False
    assert is_pangram("The quick brown fox jumps over the lazy dog. ") == True
    assert is_pangram("The quick brown fox jumps over the lazy dog") == True
    assert is_pangram("The quick brown fox jumps over the lazy dog.") == True
    assert is_pangram("the quick brown fox jumps over the lazy dog.") == True
    assert is_pangram("thequickbrownfoxjumpsoverthelazydog.") == False

# Generated at 2022-06-21 21:24:16.798544
# Unit test for function is_isbn_13
def test_is_isbn_13():
    """
    Test function is_isbn_13() return true when the input is valid isbn13.
    :return:
    """
    assert is_isbn_13('978-0312498580')



# Generated at 2022-06-21 21:24:24.481493
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('1e5') == True
    assert is_integer('1.') == False
    assert is_integer('.1') == False
    assert is_integer('1.1') == False
    assert is_integer('-1') == True
    assert is_integer('+1') == True
    assert is_integer('123') == True
    assert is_integer('foo') == False
    assert is_integer('1e5foo') == False
# End test for function is_integer



# Generated at 2022-06-21 21:24:43.881276
# Unit test for function is_isogram
def test_is_isogram():
    assert not is_isogram("")
    assert not is_isogram("hi")
    assert is_isogram("abcdefghijklmnopqrstuvwxyz")
    assert is_isogram("ABCDEFGHIJKLMNOPQRSTUVWXYZ")
    assert is_isogram("1234567890")
    assert is_isogram("abcdefghijklmnopqrstuvwxyz1234567890")
    assert is_isogram("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890")

# Generated at 2022-06-21 21:24:49.782949
# Unit test for function is_json
def test_is_json():
    assert is_json('{}') == True
    assert is_json('[]') == True
    assert is_json('{"key": "value"}') == True
    assert is_json('{"key": "value"}') == True
    assert is_json('{"key": ["value", 1]}') == True
    assert is_json('{}') == True
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-21 21:24:56.729180
# Unit test for function is_uuid
def test_is_uuid():
    uuid = '6f8aa2f9-686c-4ac3-8766-5712354a04cf'
    uuid_hex = '6f8aa2f9686c4ac387665712354a04cf'
    assert is_uuid(uuid) == True
    assert is_uuid(uuid_hex) == False
    assert is_uuid(uuid_hex, allow_hex=True) == True



# Generated at 2022-06-21 21:25:02.254100
# Unit test for function is_camel_case
def test_is_camel_case():
    assert(is_camel_case('MyString')==True)
    assert(is_camel_case('mystring')==False)
    assert(is_camel_case('My_String')==False)
    assert(is_camel_case('My_String')==False)
    assert(is_camel_case('1234567')==False)



# Generated at 2022-06-21 21:25:07.873018
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('1506715214')== False
    assert is_isbn_13('978-0312498580')== True
    assert is_isbn_13('978-0312498580', normalize=False)==False
test_is_isbn_13()


# Generated at 2022-06-21 21:25:15.350401
# Unit test for function words_count
def test_words_count():
    # Should return 0
    assert(words_count('') == 0)
    assert(words_count('abc') == 0)
    assert(words_count('!@#%<>[]()') == 0)
    assert(words_count('dasd asdasd saasd asdasd 23') == 0)
    # Should return 1
    assert(words_count('one') == 1)
    assert(words_count('123') == 1)
    assert(words_count('one-two-three') == 1)
    assert(words_count('one,two,three') == 1)
    assert(words_count('one-two,three') == 1)
    assert(words_count('one-two,three.stop') == 1)

# Generated at 2022-06-21 21:25:19.717517
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999')
    
test_is_ip_v4()

# Generated at 2022-06-21 21:25:20.858079
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog') is True
    assert is_pangram('hello world') is False 

# Generated at 2022-06-21 21:25:25.928244
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('my string is <strong>bold</strong>') is True
    assert contains_html('my string is <strong class="bold">bold</strong>') is True
    assert contains_html('my string is not bold') is False
    assert contains_html('my string is <pre>\n    not\n    bold\n</pre>') is True


# Generated at 2022-06-21 21:25:38.681388
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('is_snake_case') is True
    assert is_snake_case('is_snake_case_with_number_2') is True
    assert is_snake_case('_is_snake_case') is True

    assert is_snake_case('is_snake_case_with_number_2') is True

    assert is_snake_case('_is_snake-case') is False
    assert is_snake_case('is_snake-case') is False
    assert is_snake_case('_is-snake-case') is False
    assert is_snake_case('is-snake-case') is False

    assert is_snake_case('_is_snake_case', '-') is True

# Generated at 2022-06-21 21:25:49.860802
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334') # returns true
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?') # returns false (invalid "?")

# Generated at 2022-06-21 21:25:51.317719
# Unit test for function is_full_string
def test_is_full_string():
    # Test for function is_full_string
    assert is_full_string(None) == False
    assert is_full_string('') == False
    assert is_full_string(' ') == False
    assert is_full_string('hello') == True


# Generated at 2022-06-21 21:26:01.536298
# Unit test for function is_pangram
def test_is_pangram():
    # Test example
    test_str = "The quick brown fox jumps over the lazy dog"
    assert is_pangram(test_str) is True

    # Test example with space
    test_str = "hello world"
    assert is_pangram(test_str) is False

    # Test empty string
    test_str = ""
    assert is_pangram(test_str) is False

    # Test special characters
    test_str = "This is & pangram phrase with sp€cial characters"
    assert is_pangram(test_str) is True

    # Test numbers
    test_str = "This is a pangram phrase with n0123456789"
    assert is_pangram(test_str) is True
test_is_pangram()
 

# Generated at 2022-06-21 21:26:13.102207
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('978-0312498580', normalize=False)==True
    assert is_isbn_13('978-0312498580')==True
    assert is_isbn_13('9780312498580')==True
    assert is_isbn_13('978 0 312498580')==True
    assert is_isbn_13('978 0 312498580', normalize=False)==False
    assert is_isbn_13('97803124985')==False
    assert is_isbn_13('9780312498580a')==False
    assert is_isbn_13('978-03124985')==False
    assert is_isbn_13('978-0312498580a')==False

# Generated at 2022-06-21 21:26:16.263243
# Unit test for function is_isbn
def test_is_isbn():
  assert is_isbn('9780312498580') == True


# Generated at 2022-06-21 21:26:23.381826
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('AString') == True
    assert is_camel_case('MyString') == True
    assert is_camel_case('myString') == True
    assert is_camel_case('mystring') == False
    assert is_camel_case('') == False
    assert is_camel_case('mYString') == False
    assert is_camel_case('M') == False
    assert is_camel_case('M1') == True
    assert is_camel_case('1M') == False
    assert is_camel_case('1string') == False
    assert is_camel_case('My_String') == False



# Generated at 2022-06-21 21:26:26.248334
# Unit test for function is_string
def test_is_string():
    assert is_string('foo')
    assert not is_string(100)



# Generated at 2022-06-21 21:26:31.328216
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('my_string_with_underscore')
    assert is_snake_case('my_string_with_underscore', '_')
    assert is_snake_case('my-string-with-dash', '-')
    assert is_snake_case('my-string-with-dash') == False



# Generated at 2022-06-21 21:26:40.022456
# Unit test for function is_snake_case
def test_is_snake_case():
    assert not is_snake_case('')
    assert is_snake_case('foo')
    assert is_snake_case('foo_bar_baz')
    assert is_snake_case('foo-bar-baz', '-')
    assert not is_snake_case('foo-bar_baz')
    assert is_snake_case('fooBAR')
    assert is_snake_case('foo1bar')
    assert not is_snake_case('foo bar')
    assert not is_snake_case('1foo')
    assert not is_snake_case('foo-bar')
    assert not is_snake_case('foo=bar')
    assert is_snake_case('foo=bar', '=')



# Generated at 2022-06-21 21:26:42.309579
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('my string is <strong>bold</strong>') == True
    assert contains_html('my string is not bold') == False

# Generated at 2022-06-21 21:26:51.197151
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    checker = __ISBNChecker('3598215088')
    assert checker.is_isbn_10() is True

# Generated at 2022-06-21 21:26:54.207503
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42') is True
    assert is_integer('42.0') is False


# Generated at 2022-06-21 21:26:58.465664
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('mystring') == False
    assert is_camel_case('MyString') == True
    assert is_camel_case('myString') == True
    assert is_camel_case('Mystring') == False


# Generated at 2022-06-21 21:27:00.910679
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert is_ip_v4('255.200.100.75')
    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999')
    assert not is_ip_v4('')



# Generated at 2022-06-21 21:27:04.780335
# Unit test for function is_number
def test_is_number():
    assert is_number('42') == True
    assert is_number('19.99') == True
    assert is_number('-9.12') == True
    assert is_number('1e3') == True
    assert is_number('1 2 3') == False



# Generated at 2022-06-21 21:27:10.741418
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('MyString') == True
    assert is_camel_case('mystring') == False
    assert is_camel_case('123MyString') == False
    assert is_camel_case('my-string') == False
    assert is_camel_case('my_string') == False
    assert is_camel_case('my string') == False
    assert is_camel_case('') == False
    assert is_camel_case('123') == False



# Generated at 2022-06-21 21:27:19.722178
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('a-b-c')
    assert is_slug('a-b-c-d')
    assert is_slug('f')
    assert not is_slug('f-')
    assert not is_slug('-f')
    assert not is_slug('a_b')
    assert not is_slug('A-b-c')
    assert not is_slug('a- b- c')
    assert not is_slug('')
    assert not is_slug(123)
    assert not is_slug(None)


# Generated at 2022-06-21 21:27:29.372427
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:0:0:8a2e:370:7334') == True
    assert is_ip_v6('2001:0db8:85a3:0000:0000:8a2e:0370:7334') == True
    assert is_ip_v6('2001:db8:85a3::8a2e:370:7334') == True
    assert is_ip_v6('::') == True
    assert is_ip_v6('::1') == True
    assert is_ip_v6('1::1') == True
    assert is_ip_v6('::') == True #TESTING THIS SINGLE LINE ONLY, PASSED
    assert is_ip_v6('::0:0:0:0:0:') == False #

# Generated at 2022-06-21 21:27:38.573937
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    valid_isbn_10s = (
        '0306406152',
        '1883577489',
        '188357749X',
    )
    invalid_isbn_10s = (
        '030640615X',
        '1883577482',
        '1883577488',
        '188357748X',
    )
    for input_string in valid_isbn_10s:
        checker = __ISBNChecker(input_string)
        assert checker.is_isbn_10()
    for input_string in invalid_isbn_10s:
        checker = __ISBNChecker(input_string)
        assert not checker.is_isbn_10()


# PUBLIC API (EXPORTED)



# Generated at 2022-06-21 21:27:43.979380
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('foo') is False
    assert is_snake_case('foo_bar') is True
    assert is_snake_case('foo_bar_baz') is True
    assert is_snake_case('foo_bar_baz_1') is True
    assert is_snake_case('fooBar') is False
    assert is_snake_case('fooBarBaz') is False
    assert is_snake_case('fooBarBaz1') is False
    assert is_snake_case('FooBAR') is False
    assert is_snake_case('FOOBAR') is False
    assert is_snake_case('FOOBARBAZ') is False
    assert is_snake_case('FOOBARBAZ1') is False

# Generated at 2022-06-21 21:27:56.865828
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580')
    assert is_isbn('1506715214')
    assert is_isbn('978-0312498580')
    assert is_isbn('150-6715214')
    assert not is_isbn('121')
    assert not is_isbn('978-031')


# Generated at 2022-06-21 21:28:01.975147
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580')
    assert is_isbn('1506715214')
    assert is_isbn('978-0312498580')
    assert is_isbn('978-0312498580', False)
    assert not is_isbn('978-0312498580', True)
    assert not is_isbn('0', True)
    assert not is_isbn('0', False)


# =============================================================================
# PARSERS
# =============================================================================

# Generated at 2022-06-21 21:28:06.759716
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580')
    assert is_isbn_13('978-0312498580')
    assert not is_isbn_13('978-0312498580', normalize=False)


# Generated at 2022-06-21 21:28:16.193610
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('').is_isbn_10() == False
    assert __ISBNChecker('012345678').is_isbn_10() == False

    assert __ISBNChecker('0123456789').is_isbn_10() == True
    assert __ISBNChecker('0123456789', normalize=False).is_isbn_10() == True
    assert __ISBNChecker('8881837188').is_isbn_10() == True

    assert __ISBNChecker('0123456789a').is_isbn_10() == False
    assert __ISBNChecker('01234567a9').is_isbn_10() == False
    assert __ISBNChecker('0123456788').is_isbn_10() == False
    assert __ISBNCheck

# Generated at 2022-06-21 21:28:19.045695
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title')
    assert not is_slug('My blog post title')
    
test_is_slug()


# Generated at 2022-06-21 21:28:22.723008
# Unit test for function is_email
def test_is_email():
    assert(is_email('my.email@the-provider.com') == True)
    assert(is_email('@gmail.com') == False)
    assert(is_email('dummy@hotmail.com')==True)



# Generated at 2022-06-21 21:28:25.145190
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') == True
    assert is_isbn_10('150-6715214') == True
    assert is_isbn_10('150-6715214', normalize=False) == False


# Generated at 2022-06-21 21:28:26.900197
# Unit test for function words_count
def test_words_count():
    assert words_count('one two three') == 3
    assert words_count('one,two,three.stop') == 4


# Generated at 2022-06-21 21:28:31.216448
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    checker = __ISBNChecker('978-3-16-148410-0')
    assert checker.is_isbn_13() is True

    checker = __ISBNChecker('978-2-16-148410-0')
    assert checker.is_isbn_13() is False

    checker = __ISBNChecker('1234567890')
    assert checker.is_isbn_13() is False

# Generated at 2022-06-21 21:28:36.975720
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert(is_ip_v6("2001:db8:85a3:0000:0000:8a2e:370:7334") == True)
    assert(is_ip_v6("2001:db8:85a3:0000:0000:8a2e:370:?") == False)
    assert(is_ip_v6("x?.x.?.x") == False)


# Generated at 2022-06-21 21:28:45.518094
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog') == True
    assert is_pangram('hello world') == False


# Generated at 2022-06-21 21:28:53.364129
# Unit test for function is_credit_card
def test_is_credit_card():
    assert(True == is_credit_card('1234567890123456'))
    assert(True == is_credit_card('1234567890123456', 'VISA'))
    assert(False == is_credit_card('1234567890123456', 'MASTERCARD'))
    assert(True == is_credit_card('1234567890123456', 'AMERICAN_EXPRESS'))
    assert(False == is_credit_card('1234567890123456', 'DINERS_CLUB'))
    assert(True == is_credit_card('1234567890123456', 'DISCOVER'))
    assert(False == is_credit_card('1234567890123456', 'JCB'))


# Generated at 2022-06-21 21:28:59.158824
# Unit test for function is_json
def test_is_json():
    assert is_json("{'name': 'Peter'}") == False
    assert is_json("{'name':'Peter'}") == True
    assert is_json("{'nope':'Peter'}") == True
    assert is_json("{'name':'Peter'}") == True
    assert is_json("'name':'Peter'") == False


# Generated at 2022-06-21 21:29:01.649416
# Unit test for function is_uuid
def test_is_uuid():
    uuid4 = "2eca72a9-7a32-4fba-a3ee-708e3d7f8c34"
    assert is_uuid(uuid4)
    assert is_uuid(uuid4, allow_hex = True)

test_is_uuid()

# Generated at 2022-06-21 21:29:05.075225
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    cases = ['978-3-16-148410-0', '9783161484100', '978 3 16 148410 0']

    for each in cases:
        checker = __ISBNChecker(each)

        assert checker.is_isbn_13()

# Generated at 2022-06-21 21:29:08.811556
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com')
    assert is_url('https://mysite.com')
    assert not is_url('.mysite.com')
################################################################################



# Generated at 2022-06-21 21:29:11.618495
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('MyString') == True
    assert is_camel_case('mystring') == False



# Generated at 2022-06-21 21:29:17.366201
# Unit test for function is_full_string
def test_is_full_string():
    """
    is_full_string function test, checks if the function works as expected

    :return: None
    """
    assert not is_full_string(None) # null check
    assert not is_full_string('') # empty string check
    assert not is_full_string(' ') # space check

    assert is_full_string('hello') # returns true

test_is_full_string()



# Generated at 2022-06-21 21:29:25.556576
# Unit test for function is_decimal
def test_is_decimal():
    assert(is_decimal('1.0') == True)
    assert(is_decimal('3.14') == True)
    assert(is_decimal('1') == False)
    assert(is_decimal('02') == False)
    assert(is_decimal('01') == False)
    assert(is_decimal('00.') == False)
    assert(is_decimal('') == False)
    assert(is_decimal('asd') == False)
    assert(is_decimal('0.1.2') == False)



# Generated at 2022-06-21 21:29:29.796769
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42') == True
    assert is_integer('42.0') == False
    assert is_integer('12e5') == True
    assert is_integer('+1') == True
    assert is_integer('-1') == True



# Generated at 2022-06-21 21:29:41.901991
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') is True
    assert is_json('[1, 2, 3]') is True
    assert is_json('{nope}') is False
    assert is_json('') is False
    assert is_json('a') is False


# Generated at 2022-06-21 21:29:47.703080
# Unit test for function is_number
def test_is_number():
    assert is_number('1') == True
    assert is_number('-1') == True
    assert is_number('1.2') == True
    assert is_number('2e-2') == True
    assert is_number('  1') == False
    assert is_number('  1 ') == False
    assert is_number('1a') == False


# Generated at 2022-06-21 21:29:53.409403
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75') == True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip('1.2.3') == False


# Generated at 2022-06-21 21:29:58.573117
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0-7475-3269-9').is_isbn_10() == True
    assert __ISBNChecker('978-1-56619-909-4').is_isbn_10() == True
    assert __ISBNChecker('1-56619-909-3').is_isbn_10() == True
    assert __ISBNChecker('1-56619-909-2').is_isbn_10() == False


# Generated at 2022-06-21 21:30:08.713962
# Unit test for function is_integer
def test_is_integer():
    class TestInput:
        def __init__(self, input_string):
            self.input_string = input_string

        def __eq__(self, other):
            return isinstance(other, TestInput) and self.input_string == other.input_string
    class TestOutput:
        def __init__(self, exp_output):
            self.exp_output = exp_output

        def __eq__(self, other):
            return isinstance(other, TestOutput) and self.exp_output == other.exp_output

    class TestIsInteger:

        def __init__(self, test_inputs : List[TestInput], test_outputs : List[TestOutput]):
            self.test_inputs = test_inputs
            self.test_outputs = test_outputs


# Generated at 2022-06-21 21:30:11.582261
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') == True
    assert is_isbn('1506715214') == True
    assert is_isbn('1506715214', normalize=False) == False
    assert is_isbn('978-0312498580') == True
    assert is_isbn('978-0312498580', normalize=False) == False
    assert is_isbn('151-6715214') == False


# Generated at 2022-06-21 21:30:12.714816
# Unit test for function words_count
def test_words_count():
    assert words_count("hello world") == 2


# Generated at 2022-06-21 21:30:14.343123
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334')
    assert not is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?')



# Generated at 2022-06-21 21:30:20.536711
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    import unittest

    class TestMethods(unittest.TestCase):
        def test_is_isbn_13(self):
            tester = __ISBNChecker('9786168920928')
            self.assertTrue(tester.is_isbn_13())

            tester = __ISBNChecker('9786168920929')
            self.assertFalse(tester.is_isbn_13())

    unittest.main()

# Generated at 2022-06-21 21:30:25.010582
# Unit test for function is_number
def test_is_number():
    assert is_number("42")
    assert is_number("19.99")
    assert is_number("-9.12")
    assert is_number("1e3")
    assert not is_number("1 2 3")
# Test run
test_is_number()



# Generated at 2022-06-21 21:30:35.000110
# Unit test for function words_count
def test_words_count():
    assert words_count('') == 0
    assert words_count('hello') == 1
    assert words_count('hello world') == 2
    assert words_count('hello  world') == 2
    assert words_count('one,two,three.stop') == 4


# endregion
# region text modifications


# Generated at 2022-06-21 21:30:37.960950
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string('hello') == True
    assert is_full_string('') == False
    assert is_full_string(' ') == False
    assert is_full_string(None) == False


# Generated at 2022-06-21 21:30:50.420889
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13("9780312498580") == True
    assert is_isbn_13("978-0312498580") == True
    assert is_isbn_13("978-0312498580", normalize=False) == False
    assert is_isbn_13("978-0-312-49858-0") == True
    assert is_isbn_13("978-0-3124-9858-0") == False
    assert is_isbn_13("978-0-312-4985-80") == False
    assert is_isbn_13("978-0-3124-9858-0", normalize=False) == False
    assert is_isbn_13("978-0-312-4985-80", normalize=False) == False
    assert is_isbn_13

# Generated at 2022-06-21 21:30:51.390511
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('my string is <strong>bold</strong>')
    assert not contains_html('my string is not bold')

# Generated at 2022-06-21 21:30:55.740509
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') == True
    assert is_isbn('1506715214') == True
    assert is_isbn('9780312498580') == True
    assert is_isbn('1506715214') == True
test_is_isbn()    



# Generated at 2022-06-21 21:31:02.644098
# Unit test for function is_number
def test_is_number():
    assert(is_number("abc") == False)
    assert(is_number("12.3") == True)
    assert(is_number("-12.3") == True)
    assert(is_number("+12.3") == True)
    assert(is_number("12.3e-5") == True)
    assert(is_number("12.3e+5") == True)
    assert(is_number("12.3e5") == True)
    assert(is_number("123") == True)
    assert(is_number("-123") == True)
    assert(is_number("+123") == True)
    assert(is_number("1e10") == True)
    assert(is_number("1.23") == True)
    assert(is_number("-1.23") == True)

# Generated at 2022-06-21 21:31:08.797677
# Unit test for function is_json
def test_is_json():
    result = is_json('{"name": "Peter"}')
    assert result == True
    result = is_json('[1, 2, 3]')
    assert result == True
    result = is_json('{nope}')
    assert result == False
    result = is_json('')
    assert result == False

test_is_json()


# Generated at 2022-06-21 21:31:14.698562
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42') == True
    assert is_integer('-42') == True
    assert is_integer('42.0') == False
    assert is_integer('-42.0') == False
    assert is_integer('4.2') == False
    assert is_integer('4,2') == False
    assert is_integer('4 2') == False
    assert is_integer('test') == False

test_is_integer()


# Generated at 2022-06-21 21:31:17.919406
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42')
    assert not is_integer('42.0')
    assert not is_integer('42.57')
    assert is_integer('1e3')



# Generated at 2022-06-21 21:31:27.258733
# Unit test for function is_string
def test_is_string():
    assert is_string('foo') == True
    assert is_string('fóó') == True
    assert is_string(b'foo') == False
    assert is_string('fóó'.encode('utf8')) == False
    assert is_string('') == True
    assert is_string(27) == False
    assert is_string(2.7) == False
    assert is_string(True) == False
    assert is_string(None) == False
    assert is_string(['f', 'o', 'o']) == False
    assert is_string(('f', 'o', 'o')) == False
    assert is_string({'f', 'o', 'o'}) == False
    assert is_string({'f': 'o', 'o': 'o'}) == False

# Generated at 2022-06-21 21:31:42.739863
# Unit test for function contains_html
def test_contains_html():
  assert contains_html("<p>") == True
  assert contains_html("</a>") == True
  assert contains_html("") == False


# Generated at 2022-06-21 21:31:52.178705
# Unit test for function is_ip_v6
def test_is_ip_v6():
    string_that_is_ip_v6 = '2001:db8:85a3:0000:0000:8a2e:370:7334'
    string_that_is_not_ip_v6 = '2001-db8-85a3-0000-0000-8a2e-370-7334'
    assert(is_ip_v6(string_that_is_ip_v6)==True)
    assert(is_ip_v6(string_that_is_not_ip_v6)==False)
    # TO DO: add more test statements of the form:
    # string_that_is_not_ip_v6 = '2001-db8-85a3-0000-0000-8a2e-370-7334'
    # assert(is_ip_v6(string_that_is_

# Generated at 2022-06-21 21:31:57.173985
# Unit test for function words_count
def test_words_count():
    assert words_count('hello world') == 2
    assert words_count('one,two,three.stop') == 4
    assert words_count('! @ # % ... []') == 0
    assert words_count('one,two,three.stop?') == 5



# Generated at 2022-06-21 21:32:00.209074
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    checker = __ISBNChecker('978-0-306-40615-7')
    assert checker.is_isbn_13() == True

# Generated at 2022-06-21 21:32:11.332747
# Unit test for function is_credit_card
def test_is_credit_card():
    assert not is_credit_card(' ')
    assert not is_credit_card('')
    assert not is_credit_card(None)
    assert is_credit_card(None,'VISA') is False
    assert not is_credit_card('-1')
    assert not is_credit_card('1')
    assert is_credit_card('4111111111111111')
    assert is_credit_card('4111111111111111', 'VISA')
    assert not is_credit_card('4111111111111111', 'MASTERCARD')
    assert is_credit_card('5105105105105100')
    assert is_credit_card('5105105105105100', 'MASTERCARD')
    assert not is_credit_card('5105105105105100', 'VISA')
    assert is_credit_card

# Generated at 2022-06-21 21:32:14.342309
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42') == True
    assert is_integer('42.0') == False

test_is_integer()



# Generated at 2022-06-21 21:32:17.975550
# Unit test for function is_number
def test_is_number():
    assert is_number('-21.2')
    assert is_number('+1')
    assert is_number('-11.2')
    assert is_number('1')
    assert is_number('0')
    assert is_number('-1')


# Generated at 2022-06-21 21:32:30.208102
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10("123456789X") == True
    assert is_isbn_10("12 3456 789X") == True
    assert is_isbn_10("12-3456-789X") == True
    assert is_isbn_10("12-3456-789X", normalize=False) == False
    assert is_isbn_10("123456789X", normalize=False) == True
    assert is_isbn_10("9780471958697") == True
    assert is_isbn_10("978 0 471 58697") == True
    assert is_isbn_10("978-0-471-58697") == True
    assert is_isbn_10("978-0-471-58697", normalize=False) == False

# Generated at 2022-06-21 21:32:39.379473
# Unit test for function is_ip_v4
def test_is_ip_v4():
    """
    Tests the function is_ip_v4
    """
    assert is_ip_v4('255.255.255.255') == True
    assert is_ip_v4('192.168.1.1') == True
    assert is_ip_v4('1.1.1.1') == True
    assert is_ip_v4('255.255.255.256') == False
    assert is_ip_v4('-1.1.1.1') == False
    assert is_ip_v4('1.1.1.-1') == False
    assert is_ip_v4('1.1.1') == False
    assert is_ip_v4('1.1.1.1.1') == False
    assert is_ip_v4('') == False


# Generated at 2022-06-21 21:32:47.433592
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') == True
    assert is_isbn_10('1506715214', normalize = False) == True
    assert is_isbn_10('150-6715214') == True
    assert is_isbn_10('150-6715214', normalize = False) == False
    assert is_isbn_10('1506715215') == False
    assert is_isbn_10('150-6715215') == False
    assert is_isbn_10('150-6715215', normalize = False) == False



# Generated at 2022-06-21 21:33:05.822605
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    # Normalize
    __ISBNChecker('978-9730228236')
    __ISBNChecker('9789730228236')

    # Non Normalize
    __ISBNChecker('978-9730228236', False)
    __ISBNChecker('9789730228236', False)

# PUBLIC API



# Generated at 2022-06-21 21:33:08.265785
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog')
    assert not is_pangram('hello world')



# Generated at 2022-06-21 21:33:18.985788
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid(None) == False
    assert is_uuid('   ') == False
    assert is_uuid('{6f8aa2f9-686c-4ac3-8766-5712354a04cf}') == False
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf') == False

    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') == True
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True) == True

test_is_uuid()


# Generated at 2022-06-21 21:33:23.190836
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334') # returns true
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?') # returns false (invalid "?")

test_is_ip_v6()
