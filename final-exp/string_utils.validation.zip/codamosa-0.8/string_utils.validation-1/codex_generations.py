

# Generated at 2022-06-12 07:12:44.410287
# Unit test for function is_email
def test_is_email():
    assert is_email(None) == False
    assert is_email('') == False
    assert is_email('hello') == False
    assert is_email('hello.@a.com') == False
    assert is_email('hello@com') == False
    assert is_email('hello@google.c') == False
    assert is_email('hello@google.com') == True
    assert is_email('hello@google.corporate.com') == True
    assert is_email('hello.roger@google.com') == True
    assert is_email('john.jones@google.corporate.com') == True
    assert is_email('john.jones@google.corporate.com') == True
    assert is_email('john18@google.corporate.com') == True

# Generated at 2022-06-12 07:12:52.369006
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('127.0.0.1') == True
    assert is_ip_v4('0.0.0.0') == True
    assert is_ip_v4('255.255.255.255') == True
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False
    assert is_ip_v4(' ') == False


# Generated at 2022-06-12 07:12:56.417277
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False



# Generated at 2022-06-12 07:13:00.806588
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    checker = __ISBNChecker('9788701375609')
    assert checker.is_isbn_13() == True
    checker = __ISBNChecker('9788701375608')
    assert checker.is_isbn_13() == False


# Generated at 2022-06-12 07:13:07.489650
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False
    assert is_ip_v4('192.168.0.1')==True
    assert is_ip_v4('192.168.0.255')==True
    assert is_ip_v4('192.168.0.')==False
    assert is_ip_v4('0')==False
    assert is_ip_v4('0.0.0.0')==True
test_is_ip_v4()


# Generated at 2022-06-12 07:13:17.486001
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert is_ip_v4('255.200.100.0')
    assert is_ip_v4('255.200.0.0')
    assert not is_ip_v4('256.200.0.0')
    assert not is_ip_v4('255.200.0')
    assert not is_ip_v4('255.200')
    assert not is_ip_v4('255')
    assert not is_ip_v4('')


# Generated at 2022-06-12 07:13:23.704598
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False

if __name__ == "__main__":test_is_ip_v4()



# Generated at 2022-06-12 07:13:25.529978
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42') is True
    assert is_integer('42.0') is False



# Generated at 2022-06-12 07:13:26.495029
# Unit test for function is_ip
def test_is_ip():
    assert not is_ip("12345")


# Generated at 2022-06-12 07:13:30.377873
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580')
    assert is_isbn('1506715214')
    assert not is_isbn('1')
    assert not is_isbn('150-67-1521-4')


# Generated at 2022-06-12 07:13:47.615267
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('1.2.3.4') == True
    assert is_ip('1.2.3.4.') == False
    assert is_ip('1.2.3.4.5') == False
    assert is_ip('1.2.3') == False
    assert is_ip('0.0.0.0') == True
    assert is_ip('255.255.255.255') == True
    assert is_ip('256.255.255.255') == False
    assert is_ip('255.255.255.256') == False
    assert is_ip('1.2.3.04') == True


# Generated at 2022-06-12 07:13:57.863964
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    # Case 1
    assert __ISBNChecker('048665088X').is_isbn_10() == True

    # Case 2
    assert __ISBNChecker('04866508X8').is_isbn_10() == False

    # Case 3
    # assert __ISBNChecker('048665088X').is_isbn_10() == False

    # Case 4
    assert __ISBNChecker('0-596-52068-9').is_isbn_10() == True

    # Case 5
    assert __ISBNChecker('0 3160 6778 7').is_isbn_10() == False

    # Case 6
    assert __ISBNChecker('0-321-14653-0').is_isbn_10() == True

    # Case 7

# Generated at 2022-06-12 07:13:59.294616
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}')



# Generated at 2022-06-12 07:14:02.550165
# Unit test for function is_ip
def test_is_ip():
    assert is_ip("192.168.0.1")
    assert is_ip("192.168.0.1") == is_ip("192.168.0.1")

# Generated at 2022-06-12 07:14:06.206508
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}')
    assert is_json('[1, 2, 3]')
    assert not is_json('{nope}')



# Generated at 2022-06-12 07:14:16.611774
# Unit test for function is_json
def test_is_json():
    assert is_json('[1, 2, 3]') is True
    assert is_json('{nope}') is False
    assert is_json('"{"name": "Peter"}"') is False
    assert is_json('{"name": "Peter"}') is True
    assert is_json('{"name": "Peter", "num": 3.14}') is True
    assert is_json('{"name": "Peter", "num": 3.14, "list": [1, 2, 3]}') is True
    assert is_json('{"name": "Peter", "num": 3.14, "list": [1, 2, 3], "bool": true}') is True
    assert is_json('{"name": "Peter", "num": 3.14, "list": [1, 2, 3], "bool": false}') is True

# Generated at 2022-06-12 07:14:23.772351
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('9783659142315').is_isbn_13()
    assert __ISBNChecker('9793659142315').is_isbn_13()
    assert __ISBNChecker('9783659142315', normalize=False).is_isbn_13()

    assert not __ISBNChecker('123456').is_isbn_13()
    assert not __ISBNChecker('97836591423112').is_isbn_13()
    assert not __ISBNChecker('97836591423112', normalize=False).is_isbn_13()


# Generated at 2022-06-12 07:14:28.068745
# Unit test for function is_email
def test_is_email():
    assert is_email('xyz@gmail.com')
    assert is_email('xyz@abb.com')
    assert is_email('xyz.abc@abb.com')


# Generated at 2022-06-12 07:14:31.837744
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False



# Generated at 2022-06-12 07:14:42.480927
# Unit test for function is_credit_card
def test_is_credit_card():
    # Test if is_credit_card will find a valid card number
    assert is_credit_card("4123456789123456") == True
    # Test if is_credit_card will find an invalid card number
    assert is_credit_card("412345678912345") == False
    # Test if is_credit_card will set card_type default value of None
    assert is_credit_card("4123456789123456") == True
    # Test if is_credit_card will find a valid card number when card type is provided
    assert is_credit_card("4123456789123456", "VISA") == True
    # Test if is_credit_card will find an invalid card number when card type is provided
    assert is_credit_card("341234567891234", "VISA") == False
    # Test

# Generated at 2022-06-12 07:14:57.323397
# Unit test for function is_email
def test_is_email():
    assert is_email(None) == False
    assert is_email('') == False
    assert is_email(' ') == False
    assert is_email('abc@hotmail.com') == True
    assert is_email('abc@hotmail') == False
    assert is_email('abc@hotmail.') == False
    assert is_email('abc@hotmail..com') == False
    assert is_email('.abc@hotmail.com') == False
    assert is_email('abc..def@hotmail.com') == False
    assert is_email('"' '"@hotmail.com') == True
    assert is_email('""@hotmail.com') == False
    assert is_email('abc\ @def@hotmail.com') == False

# Generated at 2022-06-12 07:15:09.683891
# Unit test for function is_url
def test_is_url():
    assert is_url('https://www.google.com') == True
    assert is_url('https://www.google.com/?gws_rd=ssl') == True
    assert is_url('https://www.google.com/url?q=http://www.eurecom.fr/&sa=U&ei=iTZDVb-rIeaIsQHf84G4DQ&ved=0CAYQFjAA&sig2=q7Vu8-hS-7Vdg9y909UzOA&usg=AFQjCNHyn6ZwYbrG_8W-36LnV1bDhQi9XQ') == False
    assert is_url('http://en.wikipedia.org/wiki/HTTP_404') == True

# Generated at 2022-06-12 07:15:18.436788
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    isbn_10_list = [
        '0306406152',
        '030640616X',
        '0123456798',
        '0415391881',
    ]
    isbn_10_fail_list = [
        '0306406156',
        '0205080057',
        '0415391889',
        '0415391888',
    ]
    for isbn_10 in isbn_10_list:
        assert __ISBNChecker(isbn_10).is_isbn_10(), f'{isbn_10} should be ISBN 10'
    for isbn_10 in isbn_10_fail_list:
        assert not __ISBNChecker(isbn_10).is_isbn_10(), f'{isbn_10} should not be ISBN 10'


# Generated at 2022-06-12 07:15:21.011574
# Unit test for function is_ip
def test_is_ip():
    assert not is_ip('nope')
    assert not is_ip('2001:db8:85a3:0000:0000:8a2e:370:?')
    assert not is_ip('1.2.3')
    assert not is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334')
    assert not is_ip('255.200.100.75')



# Generated at 2022-06-12 07:15:23.423983
# Unit test for function is_url
def test_is_url():
    assert is_url('https://www.somewhere.com/some-folder/some-file.html')
# end test



# Generated at 2022-06-12 07:15:33.982407
# Unit test for function is_email
def test_is_email():
    assert is_email('support@pypi.org') == True
    assert is_email('support@pypi.org.') == False
    assert is_email('support_pypi.org.') == False
    assert is_email('"supp"ort@pypi.org.') == False
    assert is_email('"supp.ort"@pypi.org') == True
    assert is_email('..support@pypi.org') == False
    assert is_email('support\t@pypi.org') == True
    assert is_email('support\n@pypi.org') == True
    assert is_email('support\r@pypi.org') == True
    assert is_email('support\\@pypi.org') == True



# Generated at 2022-06-12 07:15:45.691258
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():

    cases = [
        ('0072226123', True),
        ('0-07-222612-3', True),
        ('3-8076-2226-7', True),
        ('978-3-546-20578-7', False),
        ('978-0-07-222612-5', False),
        ('978-0-07-222612-6', False),
        ('978-0-07-222612-7', False),
        ('978-0-07-222612-8', False),
        ('978-0-07-222612-9', False),
    ]

    for case in cases:
        isbn = __ISBNChecker(case[0])
        assert isbn.is_isbn_10() == case[1]
        assert not isbn.is_isbn

# Generated at 2022-06-12 07:15:50.278148
# Unit test for function is_ip
def test_is_ip():
  assert is_ip("255.200.100.75") == True
  assert is_ip("2001:db8:85a3:0000:0000:8a2e:370:7334") == True
  assert is_ip("1.2.3") == False
test_is_ip()

# Generated at 2022-06-12 07:15:54.532666
# Unit test for function is_ip_v4
def test_is_ip_v4():
    # Positive test
    assert is_ip_v4('255.200.100.75')
    # Negative test
    assert not is_ip_v4('nope')

if __name__ == '__main__':
    print('Test is_ip_v4()')
    test_is_ip_v4()



# Generated at 2022-06-12 07:16:06.056175
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('0076045183').is_isbn_13() == True
    assert __ISBNChecker('0076045181').is_isbn_13() == False
    assert __ISBNChecker('9780076045187').is_isbn_13() == True
    assert __ISBNChecker('9780076045181').is_isbn_13() == False
    assert __ISBNChecker('9786').is_isbn_13() == False
    assert __ISBNChecker('97865702309').is_isbn_13() == False
    assert __ISBNChecker('9786570230').is_isbn_13() == False
    assert __ISBNChecker('978-65702309236').is_isbn_13() == True

# Generated at 2022-06-12 07:16:17.084471
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
  assert __ISBNChecker('0747532699').is_isbn_10() == True
  assert __ISBNChecker('0679783269').is_isbn_10() == True
  assert __ISBNChecker('0747532697').is_isbn_10() == False
  assert __ISBNChecker('0374260244').is_isbn_10() == True
  assert __ISBNChecker('0-9752298-0-X').is_isbn_10() == True
  assert __ISBNChecker('0-9752298-0-5').is_isbn_10() == True


# Generated at 2022-06-12 07:16:21.093090
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999')
test_is_ip_v4()



# Generated at 2022-06-12 07:16:30.268604
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@gmail.com')
    assert is_email('my..email@gmail.com')
    assert not is_email('@gmail.com')
    assert not is_email('myemail@')
    assert not is_email('myemail@dotcom')
    assert not is_email('myemail@dot.com.')
    assert is_email('my.email@dot.com')
    assert is_email('my.email@dot.c')
    assert not is_email('myemail@dot.com12')
    assert is_email('"my.email@gmail.com"@gmail.com')
    assert is_email('"my.email@gmail"@gmail.com')
    assert is_email('"my.email at gmail.com"@gmail.com')

# Generated at 2022-06-12 07:16:33.757745
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert(is_ip_v4('255.200.100.75'))
    assert(not is_ip_v4('nope'))
    assert(not is_ip_v4('255.200.100.999'))

test_is_ip_v4()


# Generated at 2022-06-12 07:16:41.399432
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('0316148420').is_isbn_13() is True
    assert __ISBNChecker('0-312-14861-2').is_isbn_13() is True
    assert __ISBNChecker('978-0-262-20152-7').is_isbn_13() is True
    assert __ISBNChecker('9780262519632').is_isbn_13() is True
    assert __ISBNChecker('1932100554').is_isbn_13() is True

    assert __ISBNChecker('0316148420', normalize=False).is_isbn_13() is False
    assert __ISBNChecker('0-312-14861-2', normalize=False).is_isbn_13() is False

# Generated at 2022-06-12 07:16:52.737909
# Unit test for function is_email
def test_is_email():
    from pprint import pprint
    from random import randint
    from string import ascii_letters

    # reference test cases from: https://github.com/badges/shields/blob/master/tests/static/badge.test.js

# Generated at 2022-06-12 07:17:02.747810
# Unit test for function is_json
def test_is_json():
    assert is_json('[[], []]') == True
    assert is_json('[{}, []]') == True
    assert is_json('[[]]') == True
    assert is_json('[{}]') == True
    assert is_json('{}') == True
    assert is_json('{[]}') == True
    assert is_json('{[{}]}') == True
    assert is_json('[[{}]]') == True
    assert is_json('[{[]}]') == True
    assert is_json('[{[]}]') == True
    assert is_json('{[{[]}]}') == True
    assert is_json('[]') == True
    assert is_json('{}') == True
    assert is_json('[{}]') == True

# Generated at 2022-06-12 07:17:11.323682
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('a').is_isbn_10() is False
    assert __ISBNChecker('0').is_isbn_10() is False
    assert __ISBNChecker('00').is_isbn_10() is False
    assert __ISBNChecker('000').is_isbn_10() is False
    assert __ISBNChecker('0000').is_isbn_10() is False
    assert __ISBNChecker('00000').is_isbn_10() is False
    assert __ISBNChecker('000000').is_isbn_10() is False
    assert __ISBNChecker('0000000').is_isbn_10() is False
    assert __ISBNChecker('00000000').is_isbn_10() is False

# Generated at 2022-06-12 07:17:13.953525
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4("255.200.100.75")
    assert not is_ip_v4("nope")
    assert not is_ip_v4("255.200.100.999")
test_is_ip_v4()



# Generated at 2022-06-12 07:17:18.231239
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    input_string = '0345391802'
    checker = __ISBNChecker(input_string)
    expected = True
    actual = checker.is_isbn_10()
    print(expected == actual)


# PUBLIC API



# Generated at 2022-06-12 07:17:28.754492
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    checker = __ISBNChecker('')
    assert checker.is_isbn_10() == False
    checker = __ISBNChecker('0-306-40615-2')
    assert checker.is_isbn_10() == True
    checker = __ISBNChecker('0306406152')
    assert checker.is_isbn_10() == True
    checker = __ISBNChecker('0-306-40615-2')
    assert checker.is_isbn_10() == True
    checker = __ISBNChecker('0-306-40615-4')
    assert checker.is_isbn_10() == False
    checker = __ISBNChecker('0-306-40615-1')
    assert checker.is_isbn_10() == False


# Generated at 2022-06-12 07:17:37.625043
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():

    def check_one(number: str, expect: bool) -> None:
        p = __ISBNChecker(number)
        assert p.is_isbn_10() == expect

    check_one('', False)
    check_one('0-306-40615-2', True)
    check_one('0-306-40615-2-', False)
    check_one('0-306-40615', False)
    check_one('0306406152', True)
    check_one('0306781690', False)


# PUBLIC API



# Generated at 2022-06-12 07:17:42.749785
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    # arrange
    ISBNChecker = __ISBNChecker(input_string='0306406157')
    # act
    result = ISBNChecker.is_isbn_10()
    # assert
    assert result == True


# PUBLIC API



# Generated at 2022-06-12 07:17:49.009876
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False
    assert is_ip_v4('255.200.100.256') == False
    assert is_ip_v4('255.200.100.0') == True
    assert is_ip_v4('255.200.100.255') == True
    assert is_ip_v4('255.200.100.-1') == False
    
    
    
    
    
    

# Generated at 2022-06-12 07:17:57.701400
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0000000000').is_isbn_10()
    assert not __ISBNChecker('').is_isbn_10()
    assert not __ISBNChecker('0').is_isbn_10()
    assert not __ISBNChecker('1234').is_isbn_10()
    assert not __ISBNChecker('123456789Z').is_isbn_10()
    assert __ISBNChecker('0123456789').is_isbn_10()
    assert __ISBNChecker('01234567894').is_isbn_10()
    assert not __ISBNChecker('0A23456789').is_isbn_10()


# Generated at 2022-06-12 07:18:03.704563
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('1234567890').is_isbn_10() is True
    assert __ISBNChecker('9971502100').is_isbn_10() is True
    assert __ISBNChecker('9971502109').is_isbn_10() is False
    assert __ISBNChecker('abcdefghij').is_isbn_10() is False


# PUBLIC API


# Generated at 2022-06-12 07:18:06.272326
# Unit test for function is_json
def test_is_json():
    assert is_json("{'name':'lmx'}") == False
    assert is_json("{\"name\":\"lmx\"}") == True


# Generated at 2022-06-12 07:18:10.005445
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') is True
    assert is_ip_v4('nope') is False
    assert is_ip_v4('255.200.100.999') is False



# Generated at 2022-06-12 07:18:16.023410
# Unit test for function is_ip_v4
def test_is_ip_v4():
  assert is_ip_v4('255.200.100.75') == True
  assert is_ip_v4('nope') == False
  assert is_ip_v4('255.200.100.999') == False
# Test function
test_is_ip_v4()


# Generated at 2022-06-12 07:18:19.932295
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    # Arrange
    checker = __ISBNChecker('9789656786160')

    # Assert
    assert checker.is_isbn_13()

# Generated at 2022-06-12 07:18:25.039593
# Unit test for function is_json
def test_is_json():
    assert(is_json("{'nope': 'hello'}") == False)
    return
test_is_json()


# Generated at 2022-06-12 07:18:28.059667
# Unit test for function is_email
def test_is_email():
    expected = 'username@gmail.com'
    actual = is_email(expected)
    assert actual == True



# Generated at 2022-06-12 07:18:37.398820
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('me@home') == False
    assert is_email('me.at@home.com') == True
    assert is_email('me&at@home.com') == False
    assert is_email('me.@home.com') == False
    assert is_email('me@home.com.') == False
    assert is_email('me@home..com') == False
    assert is_email('me@home.com..') == False
    assert is_email('.me@home.com') == False
    assert is_email('me@.home.com') == False
    assert is_email('me.@home.com') == False

# Generated at 2022-06-12 07:18:39.250810
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-1-56619-909-4').is_isbn_13()



# Generated at 2022-06-12 07:18:41.702734
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('9992158107').is_isbn_10() is True



# Generated at 2022-06-12 07:18:44.786844
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert not is_email('my.email@@the-provider.com')
    assert not is_email('myemail@the-provider.com')



# Generated at 2022-06-12 07:18:51.617356
# Unit test for function is_email
def test_is_email():
    assert is_email('.@gmail.com') == False
    assert is_email('@gmail.com') == False
    assert is_email('a@gmail.com') == True
    assert is_email('abc@abc.abc') == True
    assert is_email('abc@gmail.com') == True
    assert is_email('abc@gmail.com.') == False
    assert is_email('abc..@gmail.com') == False
    assert is_email('abc@gmail..com') == False
    assert is_email('abc@gmail.com.com') == True
    assert is_email('" "ab@gmail.com') == True
    assert is_email('""ab@gmail.com') == True
    assert is_email('ab" "c@gmail.com') == True

# Generated at 2022-06-12 07:18:56.830566
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    checker = __ISBNChecker('978-1-60309-045-6')
    assert checker.is_isbn_13() is True

    checker = __ISBNChecker('978-1-60309-044-9')
    assert checker.is_isbn_13() is False


# Generated at 2022-06-12 07:19:04.658048
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():

    tests = [
        ('9781316622669', True),
        ('9781316642389', False),
        ('978131662266', False),
        ('97813166226690', False),
        ('97813166226695', False),
        ('97813166226699', True),
        ('978AAAAA226699', False),
        ('9781316622669998', False),
    ]

    for (input_string, expected) in tests:
        actual = __ISBNChecker(input_string).is_isbn_13()
        assert actual == expected, f'__ISBNChecker("{input_string}").is_isbn_13() = {actual}, but expected = {expected}'


# Generated at 2022-06-12 07:19:07.287316
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-12 07:19:12.333735
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}'), "Check if JSON is a JSON"

# ----------------------------------------------------------------------------



# Generated at 2022-06-12 07:19:23.798403
# Unit test for function is_json
def test_is_json():
    assert is_json('{}') == True
    assert is_json('{ "name" : "Peter", "surname" : "PAN" }') == True
    assert is_json('{ "name" : "Peter", "surname" : "PAN" ') == False
    assert is_json('{}][') == False
    assert is_json('{ "test" : [] }') == True
    assert is_json('[]') == True
    assert is_json('{ "test" : [0, 1, 2] }') == True
    assert is_json('[0, 1, 2]') == True
    assert is_json('{ "test" : [0, 1, 2]] }') == False
    assert is_json('[0, 1, 2]][') == False

# Generated at 2022-06-12 07:19:35.292609
# Unit test for function is_email
def test_is_email():
    assert is_email('name@example.com')
    assert is_email('firstname.lastname@example.com')
    assert is_email('email@subdomain.example.com')
    assert is_email('firstname+lastname@example.com')
    assert is_email('email@123.123.123.123')
    assert is_email('email@[123.123.123.123]')
    assert is_email('"email"@example.com')
    assert is_email('1234567890@example.com')
    assert is_email('email@example-one.com')
    assert is_email('_______@example.com')
    assert is_email('email@example.name')
    assert is_email('email@example.museum')
    assert is_email('email@example.co.jp')

# Generated at 2022-06-12 07:19:43.367359
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    checker = __ISBNChecker('978-3-16-148410-0')
    assert checker.is_isbn_13()

    checker = __ISBNChecker('9783161484100', False)
    assert checker.is_isbn_13()

    checker = __ISBNChecker('978-1-56619-909-4')
    assert checker.is_isbn_13()

    checker = __ISBNChecker('978-1-56619-909-1')
    assert not checker.is_isbn_13()

    checker = __ISBNChecker('978-1-56619-909-5')
    assert not checker.is_isbn_13()


# Generated at 2022-06-12 07:19:49.334579
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999')
    assert not is_ip_v4('255.200.100.')
    assert not is_ip_v4('')
    assert not is_ip_v4(None)



# Generated at 2022-06-12 07:19:59.727397
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0747532699').is_isbn_10() == True
    assert __ISBNChecker('0-7475-3269-9').is_isbn_10() == True
    assert __ISBNChecker('0 7475 3269 9').is_isbn_10() == True
    assert __ISBNChecker('0747532698').is_isbn_10() == False
    assert __ISBNChecker('0747532699').is_isbn_10() == True
    assert __ISBNChecker('0-7475-3269-X').is_isbn_10() == True
    assert __ISBNChecker('0 7475 3269 X').is_isbn_10() == True
    assert __ISBNChecker('0747532690').is_isbn_10() == False



# Generated at 2022-06-12 07:20:07.542666
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-3-16-148410-0').is_isbn_13()
    assert __ISBNChecker('978-3-16-148410-0', normalize=False).is_isbn_13()
    assert not __ISBNChecker('978-3-16-148410-1').is_isbn_13()
    assert not __ISBNChecker('978-3-16-148410-1', normalize=False).is_isbn_13()



# Generated at 2022-06-12 07:20:12.107575
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999')
    assert is_ip_v4('0.0.0.0')

# Generated at 2022-06-12 07:20:20.266443
# Unit test for function is_ip_v4
def test_is_ip_v4():
    # Assert that is_ip_v4 returns True when '255.200.100.75' is passed
    assert is_ip_v4('255.200.100.75')
    
    # Assert that is_ip_v4 returns True when 'nope' is passed
    assert is_ip_v4('nope')

    # Assert that is_ip_v4 returns True when '255.200.100.999' is passed
    assert is_ip_v4('255.200.100.999')
    
test_is_ip_v4()

# Generated at 2022-06-12 07:20:22.584817
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-3-16-148410-0').is_isbn_13() == True


# Generated at 2022-06-12 07:20:30.050145
# Unit test for function is_json
def test_is_json():
    assert (is_json('{"name": "Peter"}')) == True
    assert (is_json('[1, 2, 3]')) == True
    assert (is_json('{nope}')) == False


# Generated at 2022-06-12 07:20:39.096894
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') is True, 'My custom email is not valid'
    assert is_email('@gmail.com') is False, '@gmail.com is not valid'
    assert is_email('"my email"@gmail.com') is True, '"my mail"@gmail.com is valid'
    assert is_email('my@email@gmail.com') is True, 'my@email@gmail.com is valid'
    assert is_email('my\\@email@gmail.com') is True, 'my\\@email@gmail.com is valid'
    assert is_email('\\@email@gmail.com') is True, '\\@email@gmail.com is valid'

# Generated at 2022-06-12 07:20:46.658505
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert(__ISBNChecker('0201485672').is_isbn_10())
    assert(__ISBNChecker('0399146019').is_isbn_10())
    assert(__ISBNChecker('1593271827').is_isbn_10())
    assert(not __ISBNChecker('1593271828').is_isbn_10())
    assert(not __ISBNChecker('1-59327-182-7').is_isbn_10())
    assert(not __ISBNChecker('1-59327-182-8').is_isbn_10())

# Generated at 2022-06-12 07:20:48.214947
# Unit test for function is_json
def test_is_json():
    pass



# Generated at 2022-06-12 07:20:50.083437
# Unit test for function is_json
def test_is_json():
    assert is_json('""')
    assert is_json('"text"')
    assert is_json('["text", "more text"]')
    assert is_json('{"name": "Peter"}')
    assert not is_json('{nope}')



# Generated at 2022-06-12 07:20:58.622247
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    data = [
        '0306406152',
        '030640615s',
        '030640615',
        '030640615a',
        '03064061512',
        '030640615112',
    ]
    actual = [
        __ISBNChecker(data[0]).is_isbn_10(),
        __ISBNChecker(data[1]).is_isbn_10(),
        __ISBNChecker(data[2]).is_isbn_10(),
        __ISBNChecker(data[3]).is_isbn_10(),
        __ISBNChecker(data[4]).is_isbn_10(),
        __ISBNChecker(data[5]).is_isbn_10(),
    ]

# Generated at 2022-06-12 07:21:04.579936
# Unit test for function is_json
def test_is_json():
    assert is_json("{'key': 'value'}") == False
    assert is_json("{'key': 'value'}" , True) == True
    assert is_json(None, False) == False
    assert is_json("{'key': 'value'}", False) == False
    assert is_json("{'key': 'value'}", True) == True



# Generated at 2022-06-12 07:21:06.484116
# Unit test for function is_email
def test_is_email():
    assert is_email("abcd@gmail.com")
    assert is_email("abcd@yahoo.com")



# Generated at 2022-06-12 07:21:10.383343
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999')



# Generated at 2022-06-12 07:21:14.186615
# Unit test for function is_json
def test_is_json():
    assert is_json('{"a": "value"}') == True
    assert is_json('[{"a": "value"}]') == True
    assert is_json('{"a": "value", "b":"value"}]') == False
    assert is_json('[{"a": "value", "b":"value"}') == False

test_is_json()



# Generated at 2022-06-12 07:21:21.157280
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    
test_is_email()


# Generated at 2022-06-12 07:21:23.965615
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False


# Generated at 2022-06-12 07:21:30.929143
# Unit test for function is_ip_v4
def test_is_ip_v4():
    # 1. Positive test: the input must be a valid IP v4, without being in the private range;
    assert is_ip_v4('255.200.100.75'), '255.200.100.75 is a valid IP v4, not in the private range.'
    #assert is_ip_v4('192.168.1.1'), '192.168.1.1 is a valid IP v4, in the private range.'
    #assert is_ip_v4('10.0.0.1'), '10.0.0.1 is a valid IP v4, in the private range.'

    # 2. Negative test: the input must be a valid IP v4, not in the private range;

# Generated at 2022-06-12 07:21:40.752885
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('097522980X').is_isbn_10() == True
    assert __ISBNChecker('097522980Y').is_isbn_10() == False
    assert __ISBNChecker('097522980-').is_isbn_10() == True
    assert __ISBNChecker('097522980-').is_isbn_10() == True
    assert __ISBNChecker('097522980-').is_isbn_10() == True
    assert __ISBNChecker('0').is_isbn_10() == False
    assert __ISBNChecker('097559300X1100').is_isbn_10() == False
    assert __ISBNChecker('097559300X').is_isbn_10() == True



# Generated at 2022-06-12 07:21:43.733539
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('192.168.10.200')
    assert not is_ip_v4('2000.168.10.200')



# Generated at 2022-06-12 07:21:46.524208
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}')
    assert is_json('[1, 2, 3]')
    assert not is_json('{nope}')
    assert not is_json('abc')

test_is_json()


# Generated at 2022-06-12 07:21:51.830501
# Unit test for function is_email
def test_is_email():
    assert is_email('abc@def.com') == True
    assert is_email('abc@def.com.np') == True
    assert is_email('abc@gmail.com') == True
    assert is_email('abc@yahoo.com') == True
    assert is_email('abc@hotmail.com') == True
    assert is_email('abc@live.com') == True



# Generated at 2022-06-12 07:21:58.037077
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    a1 = __ISBNChecker("0439708184").is_isbn_10()
    a2 = __ISBNChecker("048677920X").is_isbn_10()
    a3 = __ISBNChecker("9810235714").is_isbn_10()
    a4 = __ISBNChecker("0439708185").is_isbn_10()
    assert a1 == True
    assert a2 == True
    assert a3 == True
    assert a4 == False


# PUBLIC API



# Generated at 2022-06-12 07:21:59.779165
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') # returns true



# Generated at 2022-06-12 07:22:04.894626
# Unit test for function is_ip_v4
def test_is_ip_v4():
    cases = {
        '255.200.100.75': True,
        'nope': False,
        '255.200.100.999': False
    }
    for (test_case, expected_result) in cases.items():
        assert is_ip_v4(test_case) == expected_result



# Generated at 2022-06-12 07:22:13.977622
# Unit test for function is_email
def test_is_email():
    assert is_email("abc@abc.com") == True
    assert is_email("abc.abc@abc.com") == True
    assert is_email("abc@abc.com.vn") == True
    assert is_email("abc@abc.vn") == True
    assert is_email("abc@abc.vn.vn") == True
    assert is_email("abc@abc.vn.us") == True
    assert is_email("abc.abc@abc.vn.us") == True
    assert is_email("abc.abc@abc.abc.vn.us") == True
    assert is_email("abc@gmail.com") == True
    assert is_email("abc@yahoo.com") == True
    assert is_email("abc.abc@gmail.com") == True