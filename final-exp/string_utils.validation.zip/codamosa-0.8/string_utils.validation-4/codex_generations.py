

# Generated at 2022-06-12 07:12:41.042516
# Unit test for function is_url
def test_is_url():
    assert is_url("http://www.mysite.com") is True
    assert is_url("https://mysite.com") is True
    assert is_url("abc@mysite.com") is False


# Generated at 2022-06-12 07:12:47.509523
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    checker = __ISBNChecker("1234567890")
    assert checker.is_isbn_10()

    checker = __ISBNChecker("123-4567890")
    assert checker.is_isbn_10()
    
    checker = __ISBNChecker("1-23-4567890")
    assert checker.is_isbn_10()

    checker = __ISBNChecker("0-8044-2957-X")
    assert checker.is_isbn_10()

    checker = __ISBNChecker("080442957X")
    assert checker.is_isbn_10()
    

# Generated at 2022-06-12 07:12:52.121145
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75') is True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') is True
    assert is_ip('1.2.3') is False


# Generated at 2022-06-12 07:12:57.493764
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    isbn = __ISBNChecker('978-1-9460-5142-9')
    assert isbn.is_isbn_13() == True
    isbn = __ISBNChecker('978-1-9490-4933-7')
    assert isbn.is_isbn_13() == False


# Generated at 2022-06-12 07:13:05.302508
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('0-306-40615-2').is_isbn_13() == True
    assert __ISBNChecker('0306406152').is_isbn_13() == True
    assert __ISBNChecker('978-0-306-40615-7').is_isbn_13() == True
    assert __ISBNChecker('9780306406157').is_isbn_13() == True
    assert __ISBNChecker('978-0-306-40615-5').is_isbn_13() == False
    


# Generated at 2022-06-12 07:13:08.024939
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False


# Generated at 2022-06-12 07:13:17.709768
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') is True
    assert is_url('https://mysite.com') is True
    assert is_url('.mysite.com') is False
    assert is_url('https://mysite.com', ['http', 'https', 'ftp']) is True
    assert is_url('.mysite.com', ['http', 'https', 'ftp']) is False
    assert is_url('ftp://mysite.com', ['http', 'https', 'ftp']) is True



# Generated at 2022-06-12 07:13:20.973761
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}')
    assert is_json('[1, 2, 3]')
    assert not is_json('{nope}')


# Generated at 2022-06-12 07:13:27.068836
# Unit test for function is_ip_v4
def test_is_ip_v4():
    # Test 0: Expected to pass
    assert is_ip_v4('255.200.100.75') is True
    # Test 1: Expected to fail
    assert is_ip_v4('nope') is False
    # Test 2: Expected to fail
    assert is_ip_v4('255.200.100.999') is False



# Generated at 2022-06-12 07:13:30.947924
# Unit test for function is_json
def test_is_json():
    print(is_json('{"name": "Peter"}'))
    print(is_json('[1, 2, 3]'))
    print(is_json('{nope}'))

test_is_json()


# Generated at 2022-06-12 07:13:51.683802
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('097522980X').is_isbn_10() == True
    assert __ISBNChecker('097522980x').is_isbn_10() == True
    assert __ISBNChecker('097522980X', normalize=False).is_isbn_10() == True
    assert __ISBNChecker('097522980x', normalize=False).is_isbn_10() == True
    assert __ISBNChecker('097522980').is_isbn_10() == False
    assert __ISBNChecker('097522980-0').is_isbn_10() == False
    assert __ISBNChecker('097522980A').is_isbn_10() == False



# Generated at 2022-06-12 07:13:59.725896
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False
    assert is_ip_v4('255.200.100.0') == True
    assert is_ip_v4('255.200.0.0') == True
    assert is_ip_v4('255.0.0.0') == True
    assert is_ip_v4('0.0.0.0') == True
    assert is_ip_v4('255.255.255.255') == True



# Generated at 2022-06-12 07:14:03.943781
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}')
    assert not is_json('{nope}')
    assert is_json('[1, 2, 3]')
    assert not is_json('{"nope"')



# Generated at 2022-06-12 07:14:15.613353
# Unit test for function is_email
def test_is_email():
    assert is_email('') == False
    assert is_email('email.com') == False
    assert is_email('@email.com') == False
    assert is_email('my.email@example.com') == True
    assert is_email('my.email+extension@example.com') == True
    assert is_email('myemail@example.com') == True
    assert is_email('my&email@example.com') == True
    assert is_email('my.email&other.email@example.com') == True
    assert is_email('my.email@example.com.') == False
    assert is_email('"my.email@example.com"') == True
    assert is_email('"my.email@example.com') == False

# Generated at 2022-06-12 07:14:24.394901
# Unit test for function is_email
def test_is_email():
    assert is_email('m_y.emai-l@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com ') == False
    assert is_email('my..email@the-provider.com') == False
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.co.uk') == True
    assert is_email('my.email') == False
    assert is_email('my.email@') == False
    assert is_email('.my.email@the-provider.com') == False
    assert is_email('my.email@the-providerinfo@the-provider.com') == False

# Generated at 2022-06-12 07:14:33.419251
# Unit test for function is_isbn
def test_is_isbn():
    assert(is_isbn("9780312498580") is True)
    assert(is_isbn("978-0312498580") is True)
    assert(is_isbn("978-0312498580", normalize=False) is False)
    assert(is_isbn("1506715214") is True)
    assert(is_isbn("150-6715214") is True)
    assert(is_isbn("150-6715214", normalize=False) is False)



# Generated at 2022-06-12 07:14:43.733345
# Unit test for function is_email
def test_is_email():
    assert is_email('email@example.com') == True
    assert is_email('firstname.lastname@example.com') == True
    assert is_email('email@subdomain.example.com') == True
    assert is_email('firstname+lastname@example.com') == True
    assert is_email('email@123.123.123.123') == True
    assert is_email('email@[123.123.123.123]') == True
    assert is_email('"email"@example.com') == True
    assert is_email('1234567890@example.com') == True
    assert is_email('email@example-one.com') == True
    assert is_email('_______@example.com') == True
    assert is_email('email@example.name') == True

# Generated at 2022-06-12 07:14:53.417842
# Unit test for function is_email
def test_is_email():
    assert is_email('hello@gmail.com') == True
    assert is_email('hello.gmail.com') == False
    assert is_email('hello@gmail') == False
    assert is_email('hello.gmail@com') == False
    assert is_email('hello@gmail.com') == True
    assert is_email('hello@gmail.com.net') == True
    assert is_email('hello@gmail.com.net.org') == True
    assert is_email('hello.gmail@gmail.com') == True
    assert is_email('hello.gmail@gmail') == False
    assert is_email('hellogmail@gmail.com') == True



# Generated at 2022-06-12 07:15:01.949713
# Unit test for function is_email
def test_is_email():
    print("Test is_email function:")
    assert is_email("somename@somedomain.com"), "somename@somedomain.com must be true"
    assert is_email("jsmith@[192.168.2.1]"), "jsmith@[192.168.2.1] must be true"
    assert is_email("email..email@domain.com"), "email..email@domain.com must be true"
    assert not is_email("email@domain@domain.com"), "email@domain@domain.com must be false"
    assert not is_email("あいうえお@domain.com"), "あいうえお@domain.com must be false"

# Generated at 2022-06-12 07:15:12.563008
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn_13('9780312498580') is True
    assert is_isbn_13('978-0312498580') is True
    assert is_isbn_13('978-0312498580', normalize=False) is False
    assert is_isbn_13('978-0312498580', normalize=True) is True
    assert is_isbn_13('9780312498580', normalize=False) is False
    assert is_isbn_13('9780312498580', normalize=True) is True
    assert is_isbn_13('9780312498580') is True
    assert is_isbn_10('1506715214') is True
    assert is_isbn_10('150-6715214') is True
    assert is_isbn_10

# Generated at 2022-06-12 07:15:30.604197
# Unit test for function is_credit_card

# Generated at 2022-06-12 07:15:42.659970
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('') == False
    assert is_credit_card('1234567812345678') == False
    assert is_credit_card('1234 5678 1234 5678') == False
    assert is_credit_card('1234 5678 1234 5678') == False
    assert is_credit_card('1234 5678 1234 5678', 'VISA') == False
    assert is_credit_card('4111 1111 1111 1111') == True
    assert is_credit_card('4111 1111 1111 1111') == True
    assert is_credit_card('4111 1111 1111 1111', 'VISA') == True
    assert is_credit_card('4111 1111 1111 1111', 'MASTERCARD') == False

# Generated at 2022-06-12 07:15:50.670047
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card("4111111111111111") == True
    assert is_credit_card("4111111111111") == False
    assert is_credit_card("4012888888881881") == True
    assert is_credit_card("378282246310005") == True
    assert is_credit_card("6011111111111117") == True
    assert is_credit_card("5105105105105100") == True
    assert is_credit_card("5105 1051 0510 5106") == False
    assert is_credit_card("9111111111111111") == False



# Generated at 2022-06-12 07:15:58.673229
# Unit test for function is_email
def test_is_email():
    assert not is_email(None)
    assert is_email('')
    assert is_email('smth@gmail.com')
    assert is_email('something.@gmail.com')
    assert not is_email('something ...@gmail.com')
    assert not is_email('something..else@gmail.com')
    assert not is_email('@gmail.com')
    assert not is_email('smth@')
    assert not is_email('smth@.')
    assert not is_email('smth@..')
    assert not is_email('smth@gmail.com.')
    assert not is_email('smth@gmail.com..')
    assert not is_email('smth@gmail..com')
    assert is_email('smth.something@gmail.com')

# Generated at 2022-06-12 07:16:06.055929
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}')
    assert is_json('[1, 2, 3]')
    assert is_json('[{"name": "Peter"}]')
    assert is_json('[1, 2, [3, 4]]')
    assert not is_json('{nope}')
    assert not is_json('1, 2, 3')
    assert not is_json('"hello world"')



# Generated at 2022-06-12 07:16:08.058537
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-3-16-148410-0').is_isbn_13() is True



# Generated at 2022-06-12 07:16:12.774888
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    checker = __ISBNChecker('0306406152')
    assert checker.is_isbn_10() == True

    checker = __ISBNChecker('9780306406157')
    assert checker.is_isbn_10() == False


# PUBLIC API



# Generated at 2022-06-12 07:16:21.832360
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4444444444444444') == True
    assert is_credit_card('4444444444444444', 'VISA') == True
    assert is_credit_card('4444444444444444', 'MASTERCARD') == False
    assert is_credit_card('5105105105105103') == True
    assert is_credit_card('5105105105105103', 'MASTERCARD') == True
    assert is_credit_card('5105105105105103', 'DISCOVER') == False
    assert is_credit_card('5555555555555555') == True
    assert is_credit_card('2221000000000009') == True
    assert is_credit_card('2221000000000009', 'MASTERCARD') == False
    assert is_

# Generated at 2022-06-12 07:16:29.415210
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    try:
        __ISBNChecker(None).is_isbn_13()
        assert False

    except InvalidInputError:
        pass

    assert __ISBNChecker('978-0-306-40615-7').is_isbn_13()
    assert __ISBNChecker('978 0 306 40615 7').is_isbn_13()
    assert __ISBNChecker('9780306406157').is_isbn_13()
    assert not __ISBNChecker('97803064061570').is_isbn_13()
    assert not __ISBNChecker('978030640615').is_isbn_13()



# Generated at 2022-06-12 07:16:33.280191
# Unit test for function is_json
def test_is_json():
    assert is_json('{ "a": 3 }')
    assert not is_json('{a:3}') # invalid json
    assert not is_json('') # invalid json
    assert not is_json('') # invalid json
    assert not is_json(' ') # invalid json


# Generated at 2022-06-12 07:16:52.431721
# Unit test for function is_ip_v4
def test_is_ip_v4():
    # Test valid inputs
    assert is_ip_v4("127.0.0.1") == True
    assert is_ip_v4("192.168.0.1") == True
    assert is_ip_v4("255.255.255.255") == True

    # Test invalid inputs
    assert is_ip_v4("foo.bar") == False
    assert is_ip_v4("1.2.3.4.5") == False
    assert is_ip_v4("12345") == False
    assert is_ip_v4("") == False
    assert is_ip_v4(" ") == False
    assert is_ip_v4("127.0.0.1.1") == False
    assert is_ip_v4("127.0.0.256") == False



# Generated at 2022-06-12 07:16:59.056884
# Unit test for function is_email
def test_is_email():
    test_cases = [
        #("example@gmail.com", True),
        ("huy.le@duytan.edu.vn", True),
        ("huy.le", False),
        ("huy.le@duytan.edu.vn.com", False),
        ("huy.le@duytan.edu.vn.ac.vn", True),
        ("huy.le@duytan.edu.vn.vn", True)
    ]

    for test_case in test_cases:
        input, expected = test_case
        assert is_email(input) == expected
        print(input, expected, is_email(input))

test_is_email()


# TODO: add more credit cards validation

# Generated at 2022-06-12 07:17:02.787217
# Unit test for function is_email
def test_is_email():
    assert is_email("someone@example.com") == True
    assert is_email("someone@example") == False
    assert is_email("someone.example.com") == False
    assert is_email("@example.com") == False
    assert is_email("abc@abc.abc") == True


# Generated at 2022-06-12 07:17:07.400386
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False
    assert is_json(None) == False
    assert is_json('') == False

# Generated at 2022-06-12 07:17:12.186509
# Unit test for function is_json
def test_is_json():
    # Check when it is true
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True

    # Check when it is false
    assert is_json('{nope}') == False
    assert is_json(None) == False



# Generated at 2022-06-12 07:17:15.633637
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-12 07:17:25.876859
# Unit test for function is_email
def test_is_email():
    assert is_email("test@test.com")
    assert not is_email("test@test@test.com")
    assert not is_email("test@test .com")
    assert not is_email("test@test..com")
    assert not is_email("test@test. com")
    assert not is_email("test@test.c om")
    assert not is_email("test@test.com ")
    assert not is_email("test@test.com  ")
    assert is_email('"my.email@the-provider.com"')
    assert is_email("my.email@the-provider.com")
    assert not is_email("@gmail.com")
    assert not is_email("my.emailgmail.com")
    assert is_email("my.email+filter@gmail.com")

# Generated at 2022-06-12 07:17:37.783474
# Unit test for function is_email
def test_is_email():
    # Test valid email addresses
    assert is_email('MyValid.Email89@the-provider.com') == True
    assert is_email('MyValid.Email89.the-provider.com') == False

    # Test invalid email addresses
    assert is_email('MyValid.Email89@the-') == False
    assert is_email('MyValid.Email89@.com') == False
    assert is_email('MyValid.Email89@com') == False
    assert is_email('MyValid.Email89@') == False
    assert is_email('@gmail.com') == False
    assert is_email('') == False
    assert is_email(None) == False
    assert is_email('_.._') == False


# Generated at 2022-06-12 07:17:48.290573
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    positive = [
        '9780470059029',
        '978-0-13-149505-0',
        '978 0 471 48648 0',
        '978-0-262-13472-9',
    ]

    negative = [
        '9780470059028',
        '978-0-13-149505-7',
        '978 0 471 48648 1',
        '978-0-262-13472-5',
    ]

    checker = __ISBNChecker('dummy')

    for p in positive:
        res = checker.is_isbn_13(p)
        assert res == True

    for n in negative:
        res = checker.is_isbn_13(n)
        assert res == False



# Generated at 2022-06-12 07:17:58.428711
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    # happy path
    assert __ISBNChecker('0981531647').is_isbn_10()
    assert __ISBNChecker('098153164X').is_isbn_10()
    assert __ISBNChecker('1579125150').is_isbn_10()
    assert __ISBNChecker('157912516X').is_isbn_10()
    assert __ISBNChecker('0143116387').is_isbn_10()
    assert __ISBNChecker('0143116395').is_isbn_10()
    assert __ISBNChecker('0143039008').is_isbn_10()
    assert __ISBNChecker('0143039016').is_isbn_10()
    assert __ISBNChecker('097674442X').is_isbn_10()

# Generated at 2022-06-12 07:18:10.297736
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    checker = __ISBNChecker('0471958697')
    assert checker.is_isbn_10()
    checker = __ISBNChecker('0747532699')
    assert checker.is_isbn_10()
    checker = __ISBNChecker('0747532696')
    assert not checker.is_isbn_10()


# PUBLIC API



# Generated at 2022-06-12 07:18:23.236665
# Unit test for function is_email
def test_is_email():
    assert is_email('first.last@domain.com')
    assert is_email('first.last+tag@domain.com')
    assert is_email('first.last@sub.domain.com')
    assert is_email('first@domain.com')
    assert is_email('first+last@domain.com')
    assert is_email('first-last@domain.com')
    assert is_email('first_last@domain.com')
    assert is_email('"first.last"@domain.com')
    assert is_email('"first@last"@domain.com')
    assert is_email('first.last@domain.museum')
    assert is_email('first.last@domain.travel')
    assert is_email('first.last@domain.mobi')

# Generated at 2022-06-12 07:18:27.251054
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    # test ISBN-10 true
    a = __ISBNChecker('0312539070').is_isbn_10()
    assert a == True
    b = __ISBNChecker('0425290313').is_isbn_10()
    assert b == True
    # test ISBN-10 false
    c = __ISBNChecker('0425290312').is_isbn_10()
    assert c == False


# PUBLIC API



# Generated at 2022-06-12 07:18:37.025382
# Unit test for function is_email
def test_is_email():
    assert is_email("mail@domain.com")
    assert not is_email("mail@@domain.com")
    assert not is_email("mail@domain.")
    assert not is_email("mail.domain.com")
    assert not is_email("mail.@domain.com")
    assert not is_email(".mail@domain.com")
    assert not is_email("mail@domain.com.")
    assert not is_email("mail@-domain.com")
    assert not is_email("mail@domain-.com")
    assert not is_email("mail@domain..com")
    assert not is_email("mail @domain.com")
    assert not is_email("mail@ domain.com")
    assert not is_email("mail@domain.com ")
    assert not is_email("@domain.com")

# Generated at 2022-06-12 07:18:44.414505
# Unit test for function is_email
def test_is_email():
    
    assert is_email(None) == False
    assert is_email('') == False
    assert is_email(' ') == False
    assert is_email('hello') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('@gmail.com') == False
    
test_is_email()



# Generated at 2022-06-12 07:18:51.395879
# Unit test for function is_email
def test_is_email():
    assert is_email('test@test.com'), "simple email"
    assert is_email('test@test.com.uk'), "email with two domain parts"
    assert is_email('test.test@test.com'), "email with two parts, dot separated"
    assert is_email('test.test@test.com'), "email with two parts, dot separated"
    assert is_email('test+test@test.com'), "email with two parts, + separated"
    assert is_email('te\\@st@test.com'), "escaped @"
    assert is_email('te\\!st@test.com'), "escaped !"
    assert is_email('te\\-st@test.com'), "escaped -"
    assert is_email('te\\#st@test.com'), "escaped #"
    assert is_

# Generated at 2022-06-12 07:18:54.300680
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    checker = __ISBNChecker('981-234-567-9')
    assert checker.is_isbn_13() is True



# Generated at 2022-06-12 07:18:57.652261
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}')
    assert is_json('[1, 2, 3]')
    assert not is_json('{nope}')



# Generated at 2022-06-12 07:19:03.660701
# Unit test for function is_email
def test_is_email():
    assert is_email("myemail@gmail.com") == True
    assert is_email("myemail@hotmail.com") == True
    assert is_email("myemail@yahoo.com") == True
    assert is_email("myemail@ucsc.com") == True

    assert is_email("@gmail.com") == False
    assert is_email("") == False
    assert is_email("my.email@the.provider.com") == True
    assert is_email("my.email@the.provider.com") == True



# Generated at 2022-06-12 07:19:13.313900
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    checker = __ISBNChecker('9789028449374')
    assert checker.is_isbn_13()

    checker = __ISBNChecker('9789028449377')
    assert not checker.is_isbn_13()

    checker = __ISBNChecker('9789028449375')
    assert not checker.is_isbn_13()

    checker = __ISBNChecker('978902844937')
    assert not checker.is_isbn_13()

    checker = __ISBNChecker('9789028449370')
    assert not checker.is_isbn_13()

    checker = __ISBNChecker('9789028449d70')
    assert not checker.is_isbn_13()

# Generated at 2022-06-12 07:19:25.279465
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('3726137583').is_isbn_10() is True
    assert __ISBNChecker('555614606X').is_isbn_10() is True
    assert __ISBNChecker('555614606Y').is_isbn_10() is False
    assert __ISBNChecker('555614606X').is_isbn_10() is True
    assert __ISBNChecker('978-0-306-40615-7').is_isbn_10() is True
    assert __ISBNChecker('978-0-306-40615-6').is_isbn_10() is False


# Generated at 2022-06-12 07:19:36.342640
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('foo@bar.info') == True
    assert is_email('foo@bar') == False
    assert is_email('foo@gmail.com') == True
    assert is_email('foo.bar.baz@gmail.com') == True
    assert is_email('foo.bar@gmail.com') == True
    assert is_email('foo@bar.baz.info') == True
    assert is_email('foo@bar.baz-1.xyz') == True
    assert is_email('foo@bar.baz_1.xyz') == True
    assert is_email('foo@bar.baz-1_2.xyz') == True

# Generated at 2022-06-12 07:19:45.545971
# Unit test for function is_json
def test_is_json():
    assert is_json(json.dumps({"animal": "dog"}))==True
    assert is_json(json.dumps({"PID": "1808695", "name": "TRISTAN, YAOYAO"}))==True
    # assert is_json(json.dumps({"PID": "1808695", "name": "TRISTAN, YAOYAO", "course": "CMPSC48"}))==True
    assert is_json(["PID", {"name": "TRISTAN, YAOYAO"}])==True
    assert is_json({"PID": "1808695", "name": "TRISTAN, YAOYAO", "course": "CMPSC48"})==True

# Generated at 2022-06-12 07:19:51.987109
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('1234567890123').is_isbn_13() is False
    assert __ISBNChecker('978-3-16-148410-0').is_isbn_13() is True
    assert __ISBNChecker('9783161484100').is_isbn_13() is True
    assert __ISBNChecker('978-3836221191').is_isbn_13() is True
    assert __ISBNChecker('978-3836215910').is_isbn_13() is True
    assert __ISBNChecker('978-3-8362-2159-1').is_isbn_13() is True
    assert __ISBNChecker('9783836221591').is_isbn_13() is True

# Generated at 2022-06-12 07:19:56.408651
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert is_ip_v4('nope') is False
    assert is_ip_v4('255.200.100.999') is False



# Generated at 2022-06-12 07:20:04.415153
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker("978-0-306-40615-7").is_isbn_13() == True
    assert __ISBNChecker("9780306406157").is_isbn_13() == True
    
    assert __ISBNChecker("978-0-306-40615-5").is_isbn_13() == False
    assert __ISBNChecker("9780306406155").is_isbn_13() == False


# Generated at 2022-06-12 07:20:09.070264
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False
    return True

test_is_ip_v4()



# Generated at 2022-06-12 07:20:17.263206
# Unit test for function is_email
def test_is_email():
    assert is_email("my.email@the-provider.com") == True
    assert is_email("@gmail.com") == False
    assert is_email("my+email@the-provider.com") == True
    assert is_email("my!email@the-provider.com") == False
    assert is_email("my_email@the-provider.com") == True
# Test for functionality of is_email
test_is_email()



# Generated at 2022-06-12 07:20:23.766150
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0123456789').is_isbn_10() == True
    assert __ISBNChecker('012345678X').is_isbn_10() == True
    assert __ISBNChecker('0123456788').is_isbn_10() == False
    assert __ISBNChecker('012345678a').is_isbn_10() == False
    assert __ISBNChecker('012345678').is_isbn_10() == False
    assert __ISBNChecker('01234567890').is_isbn_10() == False
    try:
        print(__ISBNChecker('').is_isbn_10())
    except InvalidInputError:
        print(True)
    else:
        print(False)

# Generated at 2022-06-12 07:20:28.824893
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False # not an ip
    assert is_ip_v4('255.200.100.999') == False # 999 is out of range

# Generated at 2022-06-12 07:20:44.089331
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert is_ip_v4('255.200.100.75')
    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999')
test_is_ip_v4()


# Generated at 2022-06-12 07:20:52.885203
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('1').is_isbn_10() == False
    assert __ISBNChecker('0123456789').is_isbn_10() == True
    assert __ISBNChecker('0128678127').is_isbn_10() == True
    assert __ISBNChecker('034532629X').is_isbn_10() == False
    assert __ISBNChecker('03453262X').is_isbn_10() == False
    assert __ISBNChecker('03453262').is_isbn_10() == False

# Generated at 2022-06-12 07:20:56.402822
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True # returns true
    assert is_ip_v4('nope') == False # returns false (not an ip)
    assert is_ip_v4('255.200.100.999') == False # returns false (999 is out of range)


# Generated at 2022-06-12 07:21:01.428491
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False
test_is_ip_v4()



# Generated at 2022-06-12 07:21:10.459520
# Unit test for function is_email
def test_is_email():
    assert is_email('me@micros.sant0s.on')
    assert not is_email('me.micros.sant0s.on')
    assert not is_email('.@.com')
    assert is_email('me@micros.sant0s.on.br')
    assert is_email('me@micros.sant0s.on.uk')
    assert not is_email('me@micros.sant0s.on.br.uk')
    assert not is_email('me@.sant0s.on.uk')
    assert is_email(r'me\@micros.sant0s.on.uk')
    assert is_email(r'me+@micros.sant0s.on.uk')

# Generated at 2022-06-12 07:21:17.090334
# Unit test for function is_email
def test_is_email():
    assert is_email('myemail@mysite.com') == True
    assert is_email('my email@mysite.com') == False
    assert is_email('myemail@mysite.com.1') == True
    assert is_email('myemail.1@mysite.com') == True
    assert is_email('myemail.@mysite.com') == True
    assert is_email('myemail..1@mysite.com') == False
    assert is_email('myemail@mysite.1') == True
    assert is_email('myemail@mysite..com') == False
    assert is_email('myemail@mysite.a1') == False
    assert is_email('myemail@mysite.com.') == False
    assert is_email('myemail@mysite.com.a') == False




# Generated at 2022-06-12 07:21:28.047295
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    isbn13_list = [
        '9781934356371',
        '9780143115762',
        '9789043021259',
        '9780980200447',
        '9780143039884',
        '9781412808738',
        '9780545010221',
        '9780802130204',
        '9780812971701'
    ]
    isbn13_wrong_list = [
        '9781934356378',
        '9780143115613',
        '9789043021229',
        '9780980200947',
        '9780143034884',
        '9781412808728',
        '9780545010222',
        '9780802130204',
        '9780812972701'
    ]

   

# Generated at 2022-06-12 07:21:39.153693
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.emailthe-provider.com') == False
    assert is_email('my.email.the-provider.com') == False
    assert is_email('my.email@the-provider.con') == False
    assert is_email('my.email@the-provider.c') == False
    assert is_email('my.email@the-provider.c') == False
    assert is_email('abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz@gmail.com') == True

# Generated at 2022-06-12 07:21:47.137671
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('048665088X').is_isbn_10()
    assert not __ISBNChecker('048665088X ', False).is_isbn_10()
    assert __ISBNChecker('1-4028-9462-7').is_isbn_10()
    assert __ISBNChecker('-7-4028-9462-7').is_isbn_10()
    assert not __ISBNChecker('-7-4028-9462-7', False).is_isbn_10()
    assert not __ISBNChecker('249181527AB').is_isbn_10()


# PUBLIC API



# Generated at 2022-06-12 07:21:51.516594
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('') == False
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-12 07:22:06.998560
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False

test_is_ip_v4()


# Generated at 2022-06-12 07:22:09.509108
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-0-306-40615-7').is_isbn_13() == True
    assert __ISBNChecker('978-0-306-40615-3').is_isbn_13() == False

