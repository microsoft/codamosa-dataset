

# Generated at 2022-06-12 07:12:38.228166
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0307273602').is_isbn_10()
    assert __ISBNChecker('0312599492').is_isbn_10()
    assert __ISBNChecker('0425265210').is_isbn_10()
    assert __ISBNChecker('0425222793').is_isbn_10()
    assert not __ISBNChecker('0307273603').is_isbn_10()


# PUBLIC API



# Generated at 2022-06-12 07:12:40.607165
# Unit test for function is_email
def test_is_email():
    import doctest
    doctest.testmod(verbose=True)

# See: https://en.wikipedia.org/wiki/Luhn_algorithm

# Generated at 2022-06-12 07:12:48.102290
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42')
    assert is_integer('-42')
    assert is_integer('+42')
    assert is_integer('0')
    assert is_integer('0.0') == False
    assert is_integer('-0.0') == False
    assert is_integer('+0.0') == False
    assert is_integer('42.0') == False
    assert is_integer('-42.0') == False
    assert is_integer('+42.0') == False
    assert is_integer('42e0')
    assert is_integer('-42e0')
    assert is_integer('+42e0')
    assert is_integer('42e-1') == False
    assert is_integer('-42e-1') == False
    assert is_integer('+42e-1') == False


# Generated at 2022-06-12 07:13:00.323121
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4929372339124732', card_type='VISA')
    assert not is_credit_card('4929372339124732', card_type='MASTERCARD')
    assert not is_credit_card('4929372339124732', card_type='AMERICAN_EXPRESS')
    assert is_credit_card('5105105105105100', card_type='MASTERCARD')
    assert not is_credit_card('5105105105105100', card_type='VISA')
    assert is_credit_card('378282246310005', card_type='AMERICAN_EXPRESS')
    assert not is_credit_card('378282246310005', card_type='MASTERCARD')

# Generated at 2022-06-12 07:13:02.318891
# Unit test for function is_integer
def test_is_integer():
    assert not is_integer('42.0')
    assert is_integer('42')



# Generated at 2022-06-12 07:13:12.360886
# Unit test for function is_ip_v4
def test_is_ip_v4():
    # Tests for is_ip_v4
    print("Testing is_ip_v4")
    a1 = b'255.200.100.75'
    a2 = b'nope'
    a3 = b'255.200.100.999'
    a4 = b'255.200.100.75.'
    a5 = b'255.200.100.75..'
    a6 = b'255.200.100'
    a7 = b'255.200.100.256'
    a8 = b'255.200.100.-1'
    a9 = b'255.200.100.a'
    a10 = b'255.-200.100.75'
    a11 = b'255.200.100.256.1'
    a12 = b'1.0.0.0'


# Generated at 2022-06-12 07:13:21.455049
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('john.doe@the-provider.com') == True
    assert is_email('john-doe@the-provider.com') == True
    assert is_email('john_doe@the-provider.com') == True
    assert is_email('john+doe@the-provider.com') == True
    assert is_email('john=doe@the-provider.com') == True
    assert is_email('"john doe"@the-provider.com') == True
    assert is_email('john.doe@the-provider') == True
    assert is_email('john.doe@-the-provider.com') == False

# Generated at 2022-06-12 07:13:26.320309
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4444444444444444') == True
    assert is_credit_card('4444444444444444', 'VISA') == True
    assert is_credit_card('4444444444444444', 'VISA') == True


# Generated at 2022-06-12 07:13:29.729799
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75')
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334')
    assert not is_ip('1.2.3')
    return True


# Generated at 2022-06-12 07:13:34.067135
# Unit test for function is_email
def test_is_email():
    assert is_email('lee@gmail.com') is True
    assert is_email('lee@gmail.com') is True
    assert is_email('lee@g.im') is False
    assert is_email('lee@hotmail.com') is True



# Generated at 2022-06-12 07:13:59.082267
# Unit test for function is_email
def test_is_email():
    assert is_email('abc@abc.abc') == True
    assert is_email('abc@abc') == True
    assert is_email('@abc.abc') == False
    assert is_email('abc?@abc.abc') == False
    assert is_email('abc!@abc.abc') == False
    assert is_email('abc#@abc.abc') == False
    assert is_email('abc$@abc.abc') == False
    assert is_email('abc%@abc.abc') == False
    assert is_email('abc^@abc.abc') == False
    assert is_email('abc&@abc.abc') == False
    assert is_email('abc*@abc.abc') == False
    assert is_email('abc(@abc.abc') == False
    assert is_email('abc)@abc.abc')

# Generated at 2022-06-12 07:14:07.003906
# Unit test for function is_isbn
def test_is_isbn():
    try:
        assert is_isbn('123456789x') == True
        assert is_isbn('978-0312498580') == True
        assert is_isbn('123456789x', normalize=False) == False
        assert is_isbn('978-0312498580', normalize=False) == True
        assert is_isbn('123456789') == False
    except:
        return False
    return True


# Generated at 2022-06-12 07:14:10.997309
# Unit test for function is_json
def test_is_json():
    lower_bound = '{"name": "Peter"}'
    upper_bound = '[1, 2, 3]'
    assert is_json(lower_bound) == True
    assert is_json(upper_bound) == True
    assert is_json('{nope}') == False



# Generated at 2022-06-12 07:14:14.517195
# Unit test for function is_url
def test_is_url():
    assert is_url("http://www.mysite.com") == True
    assert is_url("https://mysite.com") == True
    assert is_url(".mysite.com") == False


# Generated at 2022-06-12 07:14:17.245090
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.my-site.com') == True
    assert is_url('https://mysite.com') == True
    assert is_url('.mysite.com') == False



# Generated at 2022-06-12 07:14:19.970529
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-12 07:14:26.705072
# Unit test for function is_email
def test_is_email():
    assert is_email('test@test.test') == True
    assert is_email('test@test.testtesttesttesttesttest.test') == False
    assert is_email('t est@test.test') == False
    assert is_email('t(est@test.test') == False
    assert is_email('test@test..test') == False
    assert is_email('test@test.t.est') == False
    assert is_email('test@.test.test') == False
    assert is_email('test@test.te st') == False
    assert is_email('test@test.test') == True
    assert is_email('"\\\test"@test.test') == True

# Generated at 2022-06-12 07:14:37.881780
# Unit test for function is_url
def test_is_url():
    assert not is_url(None)
    assert not is_url('')
    assert not is_url(' ')
    assert not is_url(' http://mysite.com')
    assert not is_url('http://mysite.com ')
    assert not is_url('http:/mysite.com')
    assert not is_url('http://')
    assert not is_url('https://')
    assert is_url('http://mysite.com')
    assert is_url('https://mysite.com')
    assert is_url('http://www.mysite.com')
    assert is_url('http://www.mysite.com/')
    assert is_url('http://www.mysite.com/folder')
    assert is_url('http://www.mysite.com/folder/file.ext')


# Generated at 2022-06-12 07:14:42.934884
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True, 'is_json failed to identify valid json'
    assert is_json('[1, 2, 3]') == True, 'is_json failed to identify valid json'
    assert is_json('{nope}') == False, 'is_json failed to identify invalid json'



# Generated at 2022-06-12 07:14:46.743442
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}')
    assert is_json('[1, 2, 3]')
    assert not is_json('{nope}')
    assert not is_json({"name": "Peter"})


# Generated at 2022-06-12 07:14:54.487382
# Unit test for function is_json
def test_is_json():
    assert is_json(None) == False
    assert is_json('a') == False
    assert is_json('{a:}') == False
    assert is_json('[{}]') == True


# Generated at 2022-06-12 07:15:06.862089
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('1234567890123').is_isbn_13() == True
    assert __ISBNChecker('1234567890123').is_isbn_13() == True
    assert __ISBNChecker('1234567890123').is_isbn_13() == True
    assert __ISBNChecker('1234567890123').is_isbn_13() == True
    assert __ISBNChecker('978-0134757599').is_isbn_13() == True
    assert __ISBNChecker('978-0134757599').is_isbn_13() == True
    assert __ISBNChecker('978-0134757599').is_isbn_13() == True
    assert __ISBNChecker('978-0134757599').is_isbn_

# Generated at 2022-06-12 07:15:12.688527
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0393049841').is_isbn_10() == True
    assert __ISBNChecker('039304984X').is_isbn_10() == True
    assert __ISBNChecker('039304984Y').is_isbn_10() == False


# PUBLIC API

# Define types to be used on annotations
STRING_TYPE = str
NUMBER_TYPE = int

# Exceptions to use errors
INVALID_INPUT = InvalidInputError



# Generated at 2022-06-12 07:15:24.051562
# Unit test for function is_url
def test_is_url():
    assert is_url('') == False
    assert is_url('h') == False
    assert is_url('ht') == False
    assert is_url('htt') == False
    assert is_url('http') == False
    assert is_url('http:') == False
    assert is_url('http:/') == False
    assert is_url('http://') == False
    assert is_url('http:///') == False
    assert is_url('http:///f') == False
    assert is_url('http:///fo') == False
    assert is_url('http:///foo') == False
    assert is_url('http:///foo/b') == False
    assert is_url('http:///foo/bar') == False
    assert is_url('http://foo') == True

# Generated at 2022-06-12 07:15:26.639937
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') # returns true
    assert not is_ip_v4('nope') # returns false (not an ip)
    assert not is_ip_v4('255.200.100.999') # returns false (999 is out of range)

test_is_ip_v4()



# Generated at 2022-06-12 07:15:31.063173
# Unit test for function is_ip_v4
def test_is_ip_v4():
    while True:
        ip_v4_str = input("Input IP address: ")
        if is_ip_v4(ip_v4_str):
            print("True")
            break
        else:
            print("False")



# Generated at 2022-06-12 07:15:41.321186
# Unit test for function is_ip_v4
def test_is_ip_v4():

    test_param_1 = '255.200.100.75'
    test_result_1 = is_ip_v4(test_param_1)

    test_param_2 = 'nope'
    test_result_2 = is_ip_v4(test_param_2)

    test_param_3 = '255.200.100.999'
    test_result_3 = is_ip_v4(test_param_3)

    assert test_result_1 == True
    assert test_result_2 == False
    assert test_result_3 == False

test_is_ip_v4()


# Generated at 2022-06-12 07:15:43.962085
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('192.168.15.0') == True
    assert is_ip_v4('255.200.100.999') == False

# Generated at 2022-06-12 07:15:47.273462
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False



# Generated at 2022-06-12 07:15:56.818879
# Unit test for function is_email
def test_is_email():
    assert is_email(".test@test.com")==False
    assert is_email("test@test.com")==True
    assert is_email("test@test-test.com")==True
    assert is_email("test@test_test.com")==True
    assert is_email("test@test.test.com")==True

# Generated at 2022-06-12 07:16:12.366802
# Unit test for function is_email
def test_is_email():
    # tests with invalid email strings
    invalid_emails = [
        '',
        '@gmail.com',
        'fred@',
        'fred@gmail',
        'fred@dns.invalid',
        'fred.@dns.invalid',
        'fred..barney@dns.invalid',
        'fred@barney..dns.invalid',
        'fred@dns.invalid.',
        'fred@dns.invalid. '
    ]
    for email in invalid_emails:
        assert is_email(email) == False

    # tests with valid email addresses

# Generated at 2022-06-12 07:16:16.101639
# Unit test for function is_url
def test_is_url():
    assert is_url(".mysite.com") == False
    assert is_url("http://www.mysite.com") # returns true
    assert is_url("https://mysite.com") # returns true
    assert is_url(".mysite.com") == False


# Generated at 2022-06-12 07:16:17.829030
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com')
    assert is_url('https://mysite.com')
    assert not is_url('.mysite.com')



# Generated at 2022-06-12 07:16:25.898075
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('.my.email@the-provider.com') == False
    assert is_email('email.@the-provider.com') == False
    assert is_email('email.the-provider.com') == False
    assert is_email('email.@the-provider') == False
    assert is_email('email.@') == False
    assert is_email('email@the-provider.com') == True
    assert is_email('email.@the.provider.com') == False
    assert is_email('"email.@"@the-provider.com') == True
    assert is_email('email.@-provider.com') == False

# Generated at 2022-06-12 07:16:30.799861
# Unit test for function is_url
def test_is_url():
    assert(is_url("https://en.wikipedia.org/wiki/URL") == True)
    assert(is_url("https://www.google.com/?gws_rd=ssl") == True)
    assert(is_url("https://github.com/") == True)
    assert(is_url("ftp://ftp.funet.fi/pub/standards/RFC/rfc959.txt") == True)
    assert(is_url("ftp:ftp.funet.fi/pub/standards/RFC/rfc959.txt") == False)


# Generated at 2022-06-12 07:16:41.866630
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.to') == True
    assert is_email('.my.email@the-provider.com') == False
    assert is_email('my.email@the-provider..com') == False
    assert is_email('my.email@the-provider.com.') == False
    assert is_email('my.email@the-provider.com@') == False
    assert is_email('my.email..@the-provider.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email+spam@the-provider.com') == True
    assert is_email('my..email@the-provider.com') == False

# Generated at 2022-06-12 07:16:50.873784
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('1234567890123').is_isbn_13()
    assert not __ISBNChecker('1234567890123').is_isbn_13()
    assert not __ISBNChecker('12345678901234').is_isbn_13()
    assert not __ISBNChecker('1234567890122').is_isbn_13()
    assert not __ISBNChecker('1234567890129').is_isbn_13()
    assert not __ISBNChecker('12345678901x3').is_isbn_13()


# Generated at 2022-06-12 07:16:58.625961
# Unit test for function is_email
def test_is_email():
    assert is_email('foo') == False
    assert is_email('foo@') == False
    assert is_email('@bar') == False
    assert is_email('') == False
    assert is_email('foo@bar') == True
    assert is_email('a.b@test.com') == True
    assert is_email('a@b.c') == True
    assert is_email('"a.b"@test.com') == True
    assert is_email('"a@b"@test.com') == True
    assert is_email('foo@bar.com') == True
    assert is_email('foo@bar.net') == True
    assert is_email('foo@bar.org') == True
    assert is_email('foo+test@bar.com') == True

# Generated at 2022-06-12 07:17:09.706177
# Unit test for function is_url
def test_is_url():
    assert is_url("https://www.mkyong.com:8080/spring-web-maven-json/api/foo/get") == True
    assert is_url("http://www.mkyong.com:8080/spring-web-maven-json/api/foo/get") == True
    assert is_url("http://www.mkyong.com:8080/spring-web-maven-json/api/foo/get") == True
    assert is_url("www.mkyong.com:8080/spring-web-maven-json/api/foo/get") == False
    assert is_url("/spring-web-maven-json/api/foo/get") == False
    assert is_url("/spring-web-maven-json/api/foo/get") == False

# Generated at 2022-06-12 07:17:22.102090
# Unit test for function is_email
def test_is_email():
    assert not is_email(None)
    assert not is_email('')
    assert not is_email('missing_at_sign')
    assert not is_email('missing_at_sign@')
    assert not is_email('missing_at_sign.com')
    assert not is_email('missing.at.sign@')
    assert not is_email('missing.at.sign@com')
    assert not is_email('missing_at_sign.com')
    assert not is_email('.firstname.lastname@domain.com')
    assert not is_email('firstname..lastname@domain.com')
    assert not is_email('firstname.lastname@domain.com.')
    assert not is_email('firstname.lastname@domain..com')

# Generated at 2022-06-12 07:17:30.734336
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    t = __ISBNChecker("123456789X")
    assert t.is_isbn_10() == True
    
# Unit test method is_isbn_13 of class __ISBNChecker

# Generated at 2022-06-12 07:17:37.463782
# Unit test for function is_json
def test_is_json():
    assert is_json("""{
        "integer": 1,
        "double": 2.0,
        "string": "test",
        "boolean": true,
        "null": null,
        "object": {
            "foo": "bar",
            "baz": null
        },
        "array": [
            "foo",
            "bar",
            "baz"
        ]
    }""")



# Generated at 2022-06-12 07:17:48.290563
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the.provider.com')
    assert is_email('my+email@the.provider.com')
    assert is_email('myemail@the-provider.com')
    assert is_email('myemail1@the-provider.com')
    assert is_email('my_email@the-provider.com')
    assert is_email('my_email@the.provider.com')
    assert is_email('my.email_1@the-provider.com')
    assert is_email('my.email1@the-provider.com')
    assert is_email('my.email1@the.provider.com')

# Generated at 2022-06-12 07:17:58.428671
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-3-16-148410-0').is_isbn_13() is True
    assert __ISBNChecker('9783161484100').is_isbn_13() is True
    assert __ISBNChecker('978 - 3 - 16 - 148410 - 0').is_isbn_13() is True

    assert __ISBNChecker('978-316-14-8410-0').is_isbn_13() is False
    assert __ISBNChecker('978316148410').is_isbn_13() is False
    assert __ISBNChecker('9783161484100 ').is_isbn_13() is False
    assert __ISBNChecker(' 9783161484100').is_isbn_13() is False

# Generated at 2022-06-12 07:18:00.756835
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker(input_string='887754055X').is_isbn_10()



# Generated at 2022-06-12 07:18:03.115461
# Unit test for function is_json
def test_is_json():
    assert is_json('{}') == True
    assert is_json('[]') == True
    assert is_json('{}[]') == False


# Generated at 2022-06-12 07:18:07.120814
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') == True
    assert is_url('https://mysite.com') == True
    assert is_url('.mysite.com') == False
    assert is_url('') == False
    assert is_url(None) == False



# Generated at 2022-06-12 07:18:10.761830
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}')
    assert is_json('[1, 2, 3]')
    assert is_json('{"name": "Peter"}')

    assert not is_json('{nope}')


# Generated at 2022-06-12 07:18:15.779426
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False

test_is_ip_v4()



# Generated at 2022-06-12 07:18:23.975576
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.200.10') == True
    assert is_ip_v4('200.200.10') == False
    assert is_ip_v4('fake_ip') == False
    assert is_ip_v4('255.256.200.10') == False
    assert is_ip_v4('255.200.200.999') == False
    assert is_ip_v4('192.168.1.1') == True
    assert is_ip_v4('192.168.1.1.1') == False


# Generated at 2022-06-12 07:18:33.633453
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False
test_is_ip_v4()



# Generated at 2022-06-12 07:18:39.062811
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') == True
    assert is_url('https://mysite.com') == True
    assert is_url('.mysite.com') == False
    assert is_url('https://www.google.com')


# Generated at 2022-06-12 07:18:48.547773
# Unit test for function is_email
def test_is_email():
    assert is_email('email@domain.com') == True
    assert is_email('firstname.lastname@domain.com') == True
    assert is_email('email@subdomain.domain.com') == True
    assert is_email('1234567890@domain.com') == True
    assert is_email('email@domain-one.com') == True
    assert is_email('_______@domain.com') == True
    assert is_email('email@domain.name') == True
    assert is_email('email@domain.co.jp') == True
    assert is_email('firstname-lastname@domain.com') == True
    assert is_email('\"email\"@domain.com') == True
    assert is_email('1234567890@domain-one.com') == True

# Generated at 2022-06-12 07:18:57.769049
# Unit test for function is_json
def test_is_json():
    assert is_json('{"key": "value"}') is True
    assert is_json('[1, 2, 3]') is True
    assert is_json('{nope}') is False
    assert is_json('{"key": "value", "key2": "value2"}') is True
    assert is_json('[1, 2, 3, 4]') is True
    assert is_json('{"1": "a", "2": "b", "3": "c"}') is True
    assert is_json('{"key": "value", "key2": "value2", "key3": "value3"}') is True



# Generated at 2022-06-12 07:19:01.414429
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com')
    assert is_url('https://mysite.com')
    assert is_url('mysite.com')
    assert not is_url('ftp://mysite.com')
    assert not is_url('.mysite.com')


# Generated at 2022-06-12 07:19:07.287494
# Unit test for function is_json
def test_is_json():
    """
    Valid JSON double quoted strings.
    """
    assert is_json('"foobar"') is True
    assert is_json('"foo\\"bar"') is True

    """
    Valid JSON single quoted strings.
    """
    assert is_json("'foobar'") is True
    assert is_json("'foo\\'bar'") is True

    """
    Invalid JSON strings.
    """
    assert is_json('foobar') is False
    assert is_json("foo'bar") is False
    assert is_json('foo"bar') is False


# Generated at 2022-06-12 07:19:13.560966
# Unit test for function is_email
def test_is_email():
    assert is_email('EMAIL@EMAIL.COM') is True
    assert is_email('EMAIL@GMAIL.COM') is True
    assert is_email('EMAIL@GMAIL.COM') is True
    assert is_email('EMAIL@GMAIL.COM') is True
    assert is_email('EMAIL@GMAIL.COM') is True
    assert is_email('EMAIL@GMAIL.COM') is True
    assert is_email('EMAIL@GMAIL.COM') is True
    assert is_email('EMAIL@GMAIL.COM') is True
    assert is_email('EMAIL@GMAIL.COM') is True
    assert is_email('EMAIL@GMAIL.COM') is True
    assert is_email('EMAIL@GMAIL.COM') is True

# Generated at 2022-06-12 07:19:18.748463
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    isbn = __ISBNChecker('452815713')
    assert isbn.is_isbn_10() == True

    isbn.input_string = '4528157131'
    assert isbn.is_isbn_10() == False

    isbn.input_string = '4528157'
    assert isbn.is_isbn_10() == False

    isbn.input_string = '4528157134'
    assert isbn.is_isbn_10() == False

    isbn.input_string = '4528157a4'
    assert isbn.is_isbn_10() == False


# public api



# Generated at 2022-06-12 07:19:20.801287
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    checker = __ISBNChecker('978-0-306-40615-7')
    assert checker.is_isbn_13()



# Generated at 2022-06-12 07:19:23.927437
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False

test_is_ip_v4()



# Generated at 2022-06-12 07:19:36.372217
# Unit test for function is_email
def test_is_email():
	#assert is_email('foo@bar.com') == True
	assert is_email('.foo@bar.com') == False
	assert is_email('foo.@bar.com') == False
	assert is_email('foo@bar.com.') == False
	assert is_email('foo@.bar.com') == False
	assert is_email('foo@bar..com') == False
	assert is_email('foo@bar.com.') == False
	assert is_email('foo..@bar.com') == False
	assert is_email('foo.bar@baz..com') == False



# Generated at 2022-06-12 07:19:45.568343
# Unit test for function is_email
def test_is_email():
    # Local variables
    emails = []
    # Set test emails
    emails.append('me@domain.com')
    emails.append('me.me+me1@domain.com')
    emails.append('me-me1@domain.com')
    emails.append('me+me1@domain-domain.com')
    emails.append('me.me-me1@domain-domain.com')
    emails.append('me+me-me1@domain-domain-domain.com')
    emails.append('me-me+me1@domain-domain-domain.com')
    emails.append('me-me+me1@domain-domain-domain-domain.com')
    emails.append('me-me+me1@domain-domain-domain-domain.com')

# Generated at 2022-06-12 07:19:47.295859
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') == True
    assert is_url('https://mysite.com') == True
    assert is_url('.mysite.com') == False

# Generated at 2022-06-12 07:19:50.799009
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False



# Generated at 2022-06-12 07:19:55.066663
# Unit test for function is_json
def test_is_json():
	assert is_json('{"name": "Peter"}') == True
	assert is_json('[1, 2, 3]') == True
	assert is_json('{nope}') == False


# Generated at 2022-06-12 07:19:59.464186
# Unit test for function is_url
def test_is_url():
    assert is_url('http://mysite.com') == True
    assert is_url('https://mysite.com') == True
    assert is_url('ftp://mysite.com') == True
    assert is_url('https://www.mysite.com') == True
    assert is_url('mysite.com') == False


# Generated at 2022-06-12 07:20:04.724728
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    # arrange
    input_string = "3836221195"
    expected = 'is_isbn_10'

    # act
    actual = __ISBNChecker(input_string).is_isbn_10()

    # assert
    assert actual == True



# Generated at 2022-06-12 07:20:09.777265
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')  # returns true
    assert not is_ip_v4('nope') # returns false (not an ip)
    assert not is_ip_v4('255.200.100.999') # returns false (999 is out of range)

test_is_ip_v4()


# Generated at 2022-06-12 07:20:21.159884
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('9781234567890').is_isbn_10() is False
    assert __ISBNChecker('123456789X').is_isbn_10() is True
    assert __ISBNChecker('123456789').is_isbn_10() is False
    assert __ISBNChecker('1234567890').is_isbn_10() is False
    assert __ISBNChecker('123456789A').is_isbn_10() is False
    assert __ISBNChecker('978-1-234-56789-0').is_isbn_10() is False
    assert __ISBNChecker('1-234-56789-X').is_isbn_10() is True

# Generated at 2022-06-12 07:20:25.587710
# Unit test for function is_url
def test_is_url():
    assert is_url("https://www.google.com") == True
    assert is_url("http://www.my-site.com") == True
    assert is_url("http://www.my site.com") == False
    assert is_url("www.mysite.com") == False
    assert is_url("mysite.com") == False



# Generated at 2022-06-12 07:20:37.543388
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') == True
    assert is_url('https://mysite.com') == True
    assert is_url('.mysite.com') == False
    allowed_schemes = ['https', 'ftp']
    assert is_url('https://mysite.com', allowed_schemes) == True
    assert is_url('ftp://mysite.com', allowed_schemes) == True
    assert is_url('http://mysite.com', allowed_schemes) == False


# Generated at 2022-06-12 07:20:46.988596
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0747532699').is_isbn_10() is True
    assert __ISBNChecker('0306406152').is_isbn_10() is True
    assert __ISBNChecker('0385533225').is_isbn_10() is True
    assert __ISBNChecker('0439023521').is_isbn_10() is True
    assert __ISBNChecker('0596516178').is_isbn_10() is True
    assert __ISBNChecker('0596806752').is_isbn_10() is True
    assert __ISBNChecker('0596806844').is_isbn_10() is True
    assert __ISBNChecker('0399144463').is_isbn_10() is True

# Generated at 2022-06-12 07:20:58.001958
# Unit test for function is_email
def test_is_email():
    assert is_email("user@example.com") == True
    assert is_email("user@e-x-a-m-p-l-e.com") == True
    assert is_email("user@example.co.uk") == True
    assert is_email("user.name@example.com") == True
    assert is_email("user_name@example.com") == True
    assert is_email("user@aaa.example.com") == True
    assert is_email("user@aaa.bbb.example.com") == True
    assert is_email("") == False
    assert is_email("user") == False
    assert is_email("user@") == False
    assert is_email("user@aaa") == False
    assert is_email("user@aaa.") == False

# Generated at 2022-06-12 07:21:08.985411
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('9789401234567').is_isbn_13() is True
    assert __ISBNChecker('9789401234560').is_isbn_13() is True
    assert __ISBNChecker('9789401234568').is_isbn_13() is False
    assert __ISBNChecker('9789401234569').is_isbn_13() is False
    assert __ISBNChecker('978940123456').is_isbn_13() is False
    assert __ISBNChecker('97894012345679').is_isbn_13() is False
    assert __ISBNChecker('978A401234567').is_isbn_13() is False
    assert __ISBNChecker('97894O1234567').is_isbn_13() is False


# Generated at 2022-06-12 07:21:16.733435
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    values = [
        '978-3-16-148410-0',
        '978-3-16-148410-0',
        '978316148410',
    ]

    for value in values:

        assert __ISBNChecker(value).is_isbn_13() is True


# Generated at 2022-06-12 07:21:20.985484
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') == True
    assert is_url('https://mysite.com') == True
    assert is_url('.mysite.com') == False


# Generated at 2022-06-12 07:21:28.437405
# Unit test for function is_ip_v4
def test_is_ip_v4():
    """Function to test the is_ip_v4 function."""
    assert is_ip_v4('255.200.100.75')
    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999')
    assert not is_ip_v4('255.200.100.75/24')
    assert not is_ip_v4('255.200.100.75\24')
    assert not is_ip_v4('255.200.100.75\24')
    assert not is_ip_v4('255.200.100.75:22')


# Generated at 2022-06-12 07:21:34.946704
# Unit test for function is_json
def test_is_json():
    assert is_json('{"n":1, "name":"Peter"}') == True, 'is_json Failed'
    assert is_json('[1, 2, 3]') == True, 'is_json Failed'
    assert is_json('{"nope"}') == True, 'is_json Failed'
    assert is_json('{"nope"}') == False, 'is_json Failed'


# Generated at 2022-06-12 07:21:42.605177
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.google.com') == True
    assert is_url('https://www.google.com') == True
    assert is_url('https://google.com') == True
    assert is_url('mailto://google.com') == False
    assert is_url('mailto:google.com') == True
    assert is_url('mailto:google.com@google.com') == True
    assert is_url('www.google.com') == False
    assert is_url('google.com') == False
    assert is_url('google.com/login') == False
    assert is_url('google.com/login/') == False
    assert is_url('google.com/login?a=1') == False
    assert is_url('http://www.google.com/login?a=1')

# Generated at 2022-06-12 07:21:45.940221
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999')

# Test the function
test_is_ip_v4()


# Generated at 2022-06-12 07:22:00.581074
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert not is_email('my.email@the-provider.')
    assert not is_email('.email@the-provider.com')
    assert not is_email('my.email@the-provider.com.')
    assert not is_email('my.email.@the-provider.com')
    assert is_email('"much.more unusual"@example.com')
    assert is_email('"very.unusual.@.unusual.com"@example.com')
    assert is_email("!#$%&'*+-/=?^_`{}|~@example.org")
    assert not is_email("Abc.example.com")
    assert not is_email("A@b@c@example.com")

# Generated at 2022-06-12 07:22:06.717259
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert(__ISBNChecker('1234567891').is_isbn_10())
    assert(__ISBNChecker('1854879432').is_isbn_10())
    assert(__ISBNChecker('0000000000').is_isbn_10())
    assert(__ISBNChecker('1').is_isbn_10())


# PUBLIC API

