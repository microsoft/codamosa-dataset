

# Generated at 2022-06-12 07:12:40.800042
# Unit test for function is_json
def test_is_json():
    assert is_json("{'first_name': 'Peter'}") == True
    assert is_json("{'first_name': 'Peter' ") == False
    assert is_json("'first_name': 'Peter'}") == False
    assert is_json("{first_name: 'Peter'}") == False
    assert is_json("{first_name': 'Peter'}") == False



# Generated at 2022-06-12 07:12:42.388009
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580')
    assert is_isbn('1506715214')



# Generated at 2022-06-12 07:12:55.546508
# Unit test for function is_email
def test_is_email():
    assert is_email('test@test.test')
    assert not is_email('test@test')
    assert is_email('test@do.main.it')
    assert not is_email('test@do,main.it')
    assert is_email('test@do.main.it')
    assert not is_email('test@do,main.it')
    assert is_email('email@domain-one.com')
    assert not is_email('email@domain.web')
    assert is_email('firstname.lastname@domain.com')
    assert not is_email('email@123.123.123.123')
    assert is_email('email@[123.123.123.123]')
    assert not is_email('"email"@domain.com')

# Generated at 2022-06-12 07:12:59.755027
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75')
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334')
    assert not is_ip('1.2.3')

# Generated at 2022-06-12 07:13:04.960823
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True, 'ip v4 test failed'
    assert is_ip_v4('nope') == False, 'ip v4 test failed'
    assert is_ip_v4('255.200.100.999') == False, 'ip v4 test failed'


# Generated at 2022-06-12 07:13:12.970810
# Unit test for function is_url
def test_is_url():
    # Valid Urls
    assert is_url("https://www.mysite.com")
    assert is_url("https://www.mysite.com/a/b/c")
    assert is_url("https://www.mysite.com/a/b/c/")
    assert is_url("http://www.mysite.com")
    assert is_url("ftp://www.mysite.com")
    assert is_url("hppt://www.google.com")
    assert is_url("www.google.com")
    assert is_url("google.com")
    assert is_url("http://foo.co.uk/blah_blah")
    assert is_url("http://foo.co.uk/blah_blah/")

# Generated at 2022-06-12 07:13:21.985698
# Unit test for function is_json
def test_is_json():
    assert is_json("") == False
    assert is_json("{}") == True
    assert is_json("{'foo': 'bar'}") == False
    assert is_json("{'foo': 'bar', 'baz': 1}") == True
    assert is_json("{'foo': 'bar', 'baz': '1'}") == True
    assert is_json("{'foo': 'bar', 'baz': True}") == True
    assert is_json("{'foo': 'bar', 'baz': True, 'quux': [1,2,3]}") == True
    assert is_json("{'foo': 'bar', 'baz': True, 'quux': [1,2,3, 'abc']}") == True

# Generated at 2022-06-12 07:13:25.995240
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert(is_ip_v4('255.200.100.75'))
    assert(not is_ip_v4('nope'))
    assert(not is_ip_v4('255.200.100.999'))



# Generated at 2022-06-12 07:13:34.022988
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker("978-3-16-148410-0").is_isbn_13() == True
    assert __ISBNChecker("978-3-16-148410-1").is_isbn_13() == False
    assert __ISBNChecker("978-3-16-148410-2").is_isbn_13() == False
    assert __ISBNChecker("978-3-16-148410-3").is_isbn_13() == False
    assert __ISBNChecker("978-3-16-148410-4").is_isbn_13() == False
    assert __ISBNChecker("978-3-16-148410-5").is_isbn_13() == False

# Generated at 2022-06-12 07:13:38.312482
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    from .testing import assert_bool_equals
    isbn_checker = __ISBNChecker("1234567890123")
    assert_bool_equals(isbn_checker.is_isbn_13, True)

# Generated at 2022-06-12 07:13:50.354686
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4111111111111111') == True
    assert is_credit_card('4111111111111') == False
    assert is_credit_card('4012888888881881') == True
    assert is_credit_card('378282246310005') == True
    assert is_credit_card('6011111111111117') == True
    assert is_credit_card('5105105105105100') == True
    assert is_credit_card('5105 1051 0510 5106') == False
    assert is_credit_card('9111111111111111') == False


# Generated at 2022-06-12 07:13:56.180980
# Unit test for function is_credit_card
def test_is_credit_card():
    # Valid credit card
    cardnumber = '378282246310005'
    if is_credit_card(cardnumber):
        print('Valid')
    else:
        print('Invalid')

    # Invalid credit card
    cardnumber = '378282246310006'
    if is_credit_card(cardnumber):
        print('Valid')
    else:
        print('Invalid')



# Generated at 2022-06-12 07:13:59.682246
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') # returns true
    assert is_json('[1, 2, 3]') # returns true
    assert not is_json('{nope}') # returns false
# call test function
test_is_json()



# Generated at 2022-06-12 07:14:11.871166
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4444011224346499') == True, "AssertionError"
    assert is_credit_card('4444011224346499', 'VISA') == True, "AssertionError"
    assert is_credit_card('4444011224346499', 'MASTERCARD') == False, "AssertionError"
    assert is_credit_card('148571135789994') == True, "AssertionError"
    assert is_credit_card('148571135789994', 'MASTERCARD') == True, "AssertionError"
    assert is_credit_card('148571135789994', 'DISCOVER') == False, "AssertionError"

# Generated at 2022-06-12 07:14:16.145251
# Unit test for function is_json
def test_is_json():
    assert (is_json('{"name": "Peter"}')) == True
    assert (is_json('[1, 2, 3]')) == True
    assert (is_json('{nope}')) == False


# Generated at 2022-06-12 07:14:24.736013
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('039302326X').is_isbn_10() is True
    assert __ISBNChecker('039302326x').is_isbn_10() is True
    assert __ISBNChecker('039302326').is_isbn_10() is False
    assert __ISBNChecker('039302326XX').is_isbn_10() is False
    assert __ISBNChecker('039302326X1').is_isbn_10() is False
    assert __ISBNChecker('039302326XX').is_isbn_10() is False
    assert __ISBNChecker('039302326X').is_isbn_13() is False
    assert __ISBNChecker('039302326x').is_isbn_13() is False

# Generated at 2022-06-12 07:14:33.434029
# Unit test for function is_email
def test_is_email():
    assert not is_email(' ')
    assert not is_email('')
    assert not is_email('myemail@myprovider') # domain name is missing
    assert not is_email('my.email@')# domain name is missing
    assert not is_email('my.email@provider.') # domain name is missing
    assert not is_email('.my.email@provider.com') # leading dot in local part
    assert not is_email('my.email@provider..com') # consecutive dots in domain name
    assert not is_email('my,email@provider.com') # invalid character in local part
    assert not is_email('my"email@provider.com') # invalid character in local part
    assert not is_email('my.email@provider.com.') # trailing dot in domain part

# Generated at 2022-06-12 07:14:43.732233
# Unit test for function is_credit_card
def test_is_credit_card():
    assert not is_credit_card('foobar')
    assert is_credit_card('4111111111111111')
    assert is_credit_card('5500000000000004')
    assert is_credit_card('6011000000000004')
    assert is_credit_card('6011111111111117')
    assert is_credit_card('6011000990139424')
    assert is_credit_card('3530111333300000')
    assert is_credit_card('3566002020360505')
    assert is_credit_card('5555555555554444')
    assert is_credit_card('5105105105105100')
    assert is_credit_card('4111111111111111', 'VISA')
    assert not is_credit_card('4111111111111111', 'MASTERCARD')
    assert not is_

# Generated at 2022-06-12 07:14:46.481546
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    result=__ISBNChecker('1429957210').is_isbn_10()
    assert result == True


# Generated at 2022-06-12 07:14:57.180055
# Unit test for function is_email
def test_is_email():
    assert not is_email('')
    assert not is_email('@gmail.com')
    assert not is_email('junk')
    assert not is_email('junk@localhost')
    assert is_email('junk@gmail.com')
    assert is_email('junk@gmail.com')
    assert is_email('junk@gmail.com')
    assert is_email('junk@gmail.com')
    assert is_email('junk@gmail.com')
    assert is_email('junk@gmail.com')
    assert is_email('junk@gmail.com')
    assert is_email('junk@gmail.com')
    assert is_email('junk@gmail.com')
    assert is_email('junk@gmail.com')

# Generated at 2022-06-12 07:15:12.301618
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('8535902775').is_isbn_10() == True
    assert __ISBNChecker('8535902771').is_isbn_10() == False
    assert __ISBNChecker('8535902055').is_isbn_10() == True
    assert __ISBNChecker('8535902050').is_isbn_10() == False
    assert __ISBNChecker('1250123110').is_isbn_10() == True
    assert __ISBNChecker('1250123112').is_isbn_10() == False
    assert __ISBNChecker('1934356100').is_isbn_10() == True
    assert __ISBNChecker('1934356109').is_isbn_10() == False

# Generated at 2022-06-12 07:15:23.874161
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('9789814561749').is_isbn_13()
    assert __ISBNChecker('9780606374040').is_isbn_13()
    assert __ISBNChecker('9788807900421').is_isbn_13()
    assert __ISBNChecker('9780143127796').is_isbn_13()
    assert __ISBNChecker('9780143127796').is_isbn_13()
    assert __ISBNChecker('9780307273543').is_isbn_13()
    assert __ISBNChecker('9780307273550').is_isbn_13()
    assert __ISBNChecker('9780307273567').is_isbn_13()

# Generated at 2022-06-12 07:15:34.590632
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@gmail.com') == True
    assert is_email('my.email.@gmail.com') == False
    assert is_email('my.email@gmail') == False
    assert is_email('@gmail.com') == False
    assert is_email('my.emailgmail.com') == False
    assert is_email('.my.email@gmail.com') == False
    assert is_email(' my.email@gmail.com') == False
    assert is_email('.my.email@gmail.com') == False
    assert is_email('my.email@gmail.com ') == False
    assert is_email('my..email@gmail.com') == False
    assert is_email('test@localhost') == True
    assert is_email('test.test@locahost') == False
   

# Generated at 2022-06-12 07:15:38.750861
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999')

# Generated at 2022-06-12 07:15:49.318731
# Unit test for function is_email

# Generated at 2022-06-12 07:15:53.294529
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    arg = ['1234567890',
           '123456789X',
           '978012408090',
           '97801240809X',
           ]
    for value in arg:
        ret = __ISBNChecker(value).is_isbn_10()
        assert ret == True



# Generated at 2022-06-12 07:15:57.242854
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    expected = [[True, '9781234567901']]
    for exp_is_isbn_13, value in expected:
        isbn = __ISBNChecker(value, True)
        actual_is_isbn_13 = isbn.is_isbn_13()
        assert actual_is_isbn_13 == exp_is_isbn_13

# Generated at 2022-06-12 07:16:08.478421
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('9788363808022').is_isbn_13()
    assert not __ISBNChecker('9788363808023').is_isbn_13()

    assert not __ISBNChecker('978-8363808022').is_isbn_13()
    assert not __ISBNChecker('9788363808022-').is_isbn_13()
    assert not __ISBNChecker('9788363808022--').is_isbn_13()
    assert not __ISBNChecker('978-8363808022-').is_isbn_13()
    assert not __ISBNChecker('-9788363808022-').is_isbn_13()

    assert __ISBNChecker('9788363808022-', normalize=False).is_isbn

# Generated at 2022-06-12 07:16:15.434068
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('0-306-40615-2').is_isbn_13() == False
    assert __ISBNChecker('978-0-306-40615-7').is_isbn_13() == True
    assert __ISBNChecker('978-0-306-40615').is_isbn_13() == False
    assert __ISBNChecker('0-306-40615-7').is_isbn_13() == False

# Generated at 2022-06-12 07:16:24.854689
# Unit test for function is_email
def test_is_email():
    print("Testing function is_email")
    assert(is_email("email@domain.com"))
    assert(is_email("firstname.lastname@domain.com"))
    assert(is_email("email@subdomain.domain.com"))
    assert(is_email("firstname+lastname@domain.com"))
    assert(is_email("email@123.123.123.123"))
    assert(is_email("email@[123.123.123.123]"))
    assert(is_email("\"email\"@domain.com"))
    assert(is_email("1234567890@domain.com"))
    assert(is_email("email@domain-one.com"))
    assert(is_email("_______@domain.com"))
    assert(is_email("email@domain.name"))

# Generated at 2022-06-12 07:16:36.894718
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@gmail.com') == True
    assert is_email('my.emailgmail.com') == False
    assert is_email('my.email@gmailcom') == False
    assert is_email('my.emailgmail') == False
    assert is_email('my.email@') == False
    assert is_email('my.email') == False
    assert is_email('@my.gmail') == False
    assert is_email('my.email@.com') == False
    assert is_email('.my.email@gmail.com') == False
    assert is_email('my..email@gmail.com') == False
    assert is_email('my.email@gmail..com') == False
    assert is_email('my.email@gmail.c.m') == False

# Generated at 2022-06-12 07:16:40.041258
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    # Case 1: passed
    assert __ISBNChecker('978-0470616963').is_isbn_13() == True

    # Case 2: failed
    assert __ISBNChecker('978-0470616962').is_isbn_13() == False


# Generated at 2022-06-12 07:16:51.699719
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4("192.168.1.2")
    assert not is_ip_v4("192.168.1.256")
    assert not is_ip_v4("333.222.111.000")
    assert not is_ip_v4("111.")
    assert not is_ip_v4("111.222")
    assert not is_ip_v4("111.222.333")
    assert not is_ip_v4("111.222.333.444.555")
    assert not is_ip_v4("")
    assert not is_ip_v4("123.123.123.123.")
    assert not is_ip_v4("123.123.123.123.123")
    assert not is_ip_v4("123,123,123,123")

# Unit tests for function

# Generated at 2022-06-12 07:16:56.314937
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False
    print('All test passed!')

test_is_ip_v4()



# Generated at 2022-06-12 07:16:58.018764
# Unit test for function is_email
def test_is_email():
    assert is_email('abc.abc@abc.abc') == True
test_is_email()



# Generated at 2022-06-12 07:17:09.277254
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') is True
    assert is_email('@gmail.com') is False
    assert is_email('my.email@the-provider.com') is True
    assert is_email('"a, b"@c.d') is True
    assert is_email('"a\\"b"@c.d') is True
    assert is_email('c.@d.e') is False
    assert is_email('"a"b@c.d') is False
    assert is_email('"a.@b"@c.d') is False
    assert is_email('"a\\"@b"@c.d') is False
    assert is_email('a@b.ccc') is True

# Generated at 2022-06-12 07:17:16.362319
# Unit test for function is_json
def test_is_json():
    json_object = '{"name": "Peter"}'
    list_object = '[1, 2, 3]'
    invalid_json = '{nope}'

    assert(is_json(json_object))
    assert(is_json(list_object))
    assert(not is_json(invalid_json))



# Generated at 2022-06-12 07:17:24.698597
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    valid_isbns = ('0306406152', '156881111X', '156881116X', '1568811154', '1568811146', '1568811138', '156881112X', '1568811118', '1568811101')
    invalid_isbns = ('0306406153', '156881119X', '156881110X')

    for isbn in valid_isbns:
        assert __ISBNChecker(isbn).is_isbn_10()

    for isbn in invalid_isbns:
        assert __ISBNChecker(isbn).is_isbn_10() is False


# Generated at 2022-06-12 07:17:30.008011
# Unit test for function is_email
def test_is_email():
    assert is_email(None) == False
    assert is_email('') == False
    assert is_email('   ') == False
    assert is_email('foo') == False
    assert is_email('foo@') == False
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True

# Credit card number regex reference: https://en.wikipedia.org/wiki/Payment_card_number
# Luhn algorithm implementation: https://gist.github.com/alxndr-k/e1efb2793c62a1314e28a1c20a9d3d97

# Generated at 2022-06-12 07:17:39.288121
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('').is_isbn_13() == False
    assert __ISBNChecker('9781919714178').is_isbn_13() == True
    assert __ISBNChecker('978-1-919714-17-8').is_isbn_13() == True
    assert __ISBNChecker('978-1-919714-17-8', False).is_isbn_13() == False
    assert __ISBNChecker('97819197141789').is_isbn_13() == False
    assert __ISBNChecker('978191971417G').is_isbn_13() == False


# Generated at 2022-06-12 07:17:49.758231
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-1-56619-909-4').is_isbn_13() is False
    assert __ISBNChecker('9781566199094').is_isbn_13() is True
    assert __ISBNChecker('9781566199095').is_isbn_13() is False
    assert __ISBNChecker('978156619909').is_isbn_13() is False
    assert __ISBNChecker('97815661990948').is_isbn_13() is False
    assert __ISBNChecker('97815-6-61-90905').is_isbn_13() is False
    assert __ISBNChecker('97815-6-61-90904').is_isbn_13() is True

# Generated at 2022-06-12 07:17:55.695610
# Unit test for function is_json
def test_is_json():
    assert is_json('{"a": 1, "b": 2}')
    assert is_json("[1, 2, 3]")
    assert is_json("{'name': 'Peter'}")
    assert is_json("{'a': 1, 'b': 2, 'c': 3}")
    assert is_json("[\"a\", \"b\", \"c\"]")
    assert not is_json("nope")


# Generated at 2022-06-12 07:18:00.996909
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999') # 999 is out of range
# Unit test: is_ip_v4

# Test each function

# Generated at 2022-06-12 07:18:10.185850
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert not __ISBNChecker('978-4-7674-6656-8').is_isbn_13()
    assert __ISBNChecker('9784767466562').is_isbn_13()
    assert __ISBNChecker('9781234567890').is_isbn_13()
    assert __ISBNChecker('9781qazxsw23e').is_isbn_13()
    assert not __ISBNChecker('1234567890123').is_isbn_13()
    assert not __ISBNChecker('12345678901').is_isbn_13()
    assert not __ISBNChecker('12345678901234').is_isbn_13()



# Generated at 2022-06-12 07:18:23.199716
# Unit test for function is_email
def test_is_email():
    assert is_email("") == False
    assert is_email("@gmail.com") == False
    assert is_email("me@gmail.com") == True
    assert is_email("m.e@gmail.com") == True
    assert is_email("me@gmail.c") == False
    assert is_email("me@.c") == False
    assert is_email("me@gmail.c") == False
    assert is_email("me@gmail.com.") == False
    assert is_email("me@gmail.com.") == False
    assert is_email("me\\\\@gmail.com") == False
    assert is_email("me\\\\@gmail.com") == False
    assert is_email(".me@gmail.com") == False
    assert is_email("me.me@gmail.com") == True
    assert is_

# Generated at 2022-06-12 07:18:26.787424
# Unit test for function is_json
def test_is_json():
    assert is_json('[0]') == True
    assert is_json('[1,2,3]') == True
    assert is_json('{"a":"b"}') == True
    assert is_json('[0') == False
    assert is_json('[0]123') == False
    assert is_json('[0.123]') == True



# Generated at 2022-06-12 07:18:36.994915
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') is True
    assert is_email('my.email.at.the-provider.com') is True
    assert is_email('my@my-provider.com') is True
    assert is_email('my.email@the-provider.com') is True
    assert is_email('my.email@the-provider.co.uk') is True
    assert is_email('my.email@the-provider.com.uk') is True
    assert is_email('my.email@the-provider.ltd.uk') is True
    assert is_email('my.email@the-provider.co.uk.com.gov.org.net.edu.info') is True

# Generated at 2022-06-12 07:18:41.525548
# Unit test for function is_json
def test_is_json():
    assert is_json("{'name': 'Peter'}") # returns true
    assert is_json("[1, 2, 3]") # returns true
    assert is_json("{nope}") == False # returns false


# Generated at 2022-06-12 07:18:44.286906
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4("127.0.0.1")
    assert not is_ip_v4("255.200.100.999")
test_is_ip_v4()



# Generated at 2022-06-12 07:18:47.787505
# Unit test for function is_email
def test_is_email():
    assert  is_email('@gmail.com') == True
    assert  is_email('apple.com') == False
    assert  is_email('apple.com@gmail') == False
    assert  is_email('apple@gmail.com') == True

# TESTED IS_EMAIL



# Generated at 2022-06-12 07:19:01.076634
# Unit test for function is_json
def test_is_json():
    # this function basically is a wrapper around the builtin json.loads
    # which returns a dictionary by parsing a json string (eg: '{"key": "value"}')
    # or a list if the json string represents a list (eg: '[1, 2, 3]')
    # so the idea of the test is to have both a valid json string
    # and eventually check if an input exception raises
    valid_json_string = json.dumps({'key': 'value'})
    assert is_json('') == False, 'Empty string should not be valid json'
    assert is_json('invalid-json') == False, 'Invalid string should not be valid json'
    assert is_json(valid_json_string) == True, 'Valid json string should be valid json'

# Generated at 2022-06-12 07:19:02.290570
# Unit test for function is_json
def test_is_json():
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-12 07:19:05.986257
# Unit test for function is_json
def test_is_json():
    if is_json("{\"name\": \"Peter\"}") != True:
        print("Error test1")
    if is_json("[1, 2, 3]") != True:
        print("Error test2")
    if is_json("{nope}") != False:
        print("Error test3")

test_is_json()



# Generated at 2022-06-12 07:19:10.241084
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    # Arrange
    checker = __ISBNChecker('1234567890123')

    # Act
    result = checker.is_isbn_13()

    # Assert
    assert result == True

    # Arrange
    checker = __ISBNChecker('8186803496')

    # Act
    result = checker.is_isbn_13()

    # Assert
    assert result == False


# Generated at 2022-06-12 07:19:12.132764
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0143105419').is_isbn_10()


# PUBLIC API



# Generated at 2022-06-12 07:19:17.372187
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-12 07:19:25.543576
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    #测试数据长度等于13
    str_test1 = '1234567890123'
    #测试数据长度不等于13
    str_test2 = '12345678901'
    #测试数据包含非数字字符
    str_test3 = '12345678901*'
    #测试数据满足isbn13算法
    str_test4 = '9787313033163'
    #测试数据不满足isbn13算法

# Generated at 2022-06-12 07:19:32.130629
# Unit test for function is_json
def test_is_json():
    input_string_list = [
        '{"name": "Peter"}',
        '[1, 2, 3]',
        '{nope}'
    ]
    for i in range(len(input_string_list)):
        print(is_json(input_string_list[i]))

test_is_json()


# Generated at 2022-06-12 07:19:34.945687
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4("255.200.100.75") == True
    assert is_ip_v4("nope") == False
    assert is_ip_v4("255.200.100.999") == False

# Generated at 2022-06-12 07:19:44.112841
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    # test basic
    assert __ISBNChecker('9783867279863').is_isbn_13() is True

    # test not isbn_13
    assert __ISBNChecker('0-306-40615-2').is_isbn_13() is False

    # test with -
    assert __ISBNChecker('978-3867279863').is_isbn_13() is True

    # test invalid
    assert __ISBNChecker('9783867279864').is_isbn_13() is False

    # test number
    assert __ISBNChecker('9783867279864').is_isbn_13() is False

# Generated at 2022-06-12 07:19:55.486888
# Unit test for function is_email
def test_is_email():
    assert is_email('test@test.test')
    assert is_email('a@b.c')
    assert is_email('test+test@test.test')
    assert is_email('test-test@test.test')
    assert is_email('test_test@test.test')
    assert is_email('test.test@test.test')
    assert is_email('test-test@test.test')
    assert is_email('test_test@test.test')
    assert is_email('test@test.c')
    assert is_email('test@test.co')
    assert is_email('test@test.cou')
    assert is_email('test@test.coun')
    assert is_email('test@test.count')
    assert is_email('test@test.countr')

# Generated at 2022-06-12 07:19:58.865859
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4("255.200.100.75") == True
    assert is_ip_v4("nope") == False
    assert is_ip_v4("255.200.100.999") == False



# Generated at 2022-06-12 07:20:06.966279
# Unit test for function is_json
def test_is_json():
    # Tests for valid json
    assert is_json('{"name": "Peter"}')
    assert is_json('[1, 2, 3]')
    assert is_json('{"name": "Peter", "age": 45}')

    # Tests for invalid json
    assert not is_json('{nope}')
    assert not is_json('{"name": "Peter", "age": "45"}')
    assert not is_json('[1, 2, 3')
    assert not is_json('1, 2, 3]')



# Generated at 2022-06-12 07:20:13.004609
# Unit test for function is_json
def test_is_json():
    test_cases = [
        ['{\"name\": \"Peter\"}', True],
        ['[1, 2, 3]', True],
        ['{nope}', False],
        [' {nope}', False],
        ['[', False],
        ['{', False],
        ['', False],
        [None, False],
    ]
    for case, expected_result in test_cases:
        result = is_json(case)
        assert result == expected_result



# Generated at 2022-06-12 07:20:19.678472
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker("1234567890").is_isbn_10()
    assert __ISBNChecker("0123456789").is_isbn_10()
    assert not __ISBNChecker("01234567890").is_isbn_10()
    assert not __ISBNChecker("0181783808").is_isbn_10()
    assert __ISBNChecker("0194549042").is_isbn_10()

    return True

# Generated at 2022-06-12 07:20:23.113425
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-12 07:20:33.252598
# Unit test for function is_email
def test_is_email():
    #Test good email
    assert is_email('my.email@the-provider.com')
    #Test good email with www
    assert is_email('example.email@the-provider.com')
    #Test bad email with @ at start
    assert is_email('@gmail.com') == False
    #Test bad email with no @ symbol
    assert is_email("gmail.com") == False
    #Test bad email with no . symbol
    assert is_email("myemail@gmailcom") == False
    #Test bad email with no local-part
    assert is_email("@gmail.com") == False



# Generated at 2022-06-12 07:20:39.871869
# Unit test for function is_email
def test_is_email():
    assert is_email("joe@example.com") == True
    assert is_email("joe+b@example.com") == True
    assert is_email("joe.b@example.com") == True
    assert is_email("joe_b@example.com") == True
    assert is_email("joe-b@example.com") == True
    assert is_email("joe..b@example.com") == True
    assert is_email("joe!b@example.com") == False
    assert is_email("@example.com") == False
    assert is_email("joe@example") == False
    assert is_email("joe@exampl.com") == True


# Generated at 2022-06-12 07:20:48.561779
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    surface = __ISBNChecker(input_string='').is_isbn_13
    # given
    assert surface('') is False
    assert surface('978-0-306-40615-7') is False
    assert surface('123456789') is False
    assert surface('1234567890123') is False
    assert surface('978-0-306-40615-8') is False
    assert surface('978-0-306-40615-5') is False
    assert surface('978-0-306-40615-6') is False
    # when
    assert surface('978-0-306-40615-7') is True
    assert surface('1234567890123') is True
    assert surface('978-0-306-40615-8') is True

# Generated at 2022-06-12 07:20:52.706748
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-12 07:21:08.549661
# Unit test for function is_email
def test_is_email():
    assert is_email('matteo@gmail.com')
    assert not is_email('matteo@@gmail.com')
    assert is_email('matteo@samples.com')
    assert not is_email('matteo.com')
    assert not is_email('matteo@gmail')
    assert not is_email('matteo@gmail.')
    assert not is_email('matteo@gmail.c')
    assert not is_email('matteo@gmail.abc')
    assert not is_email('-matteo@gmail.com')
    assert is_email('matteo@gmail.com.')
    assert not is_email('matteo.@gmail.com')
    assert not is_email('matteo@gmail.com-')

# Generated at 2022-06-12 07:21:12.542154
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert (is_ip_v4('255.200.100.75') == True)
    assert (is_ip_v4('nope') == False)
    assert (is_ip_v4('255.200.100.999') == False)


# Generated at 2022-06-12 07:21:15.207594
# Unit test for function is_email
def test_is_email():
        assert is_email('my.email@the-provider.com') == True
        assert is_email('@gmail.com') == False

# Generated at 2022-06-12 07:21:19.293797
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False
test_is_ip_v4()



# Generated at 2022-06-12 07:21:26.717809
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    test_cases = [
        {
            'input': '0306406152',
            'output': True
        },
        {
            'input': 'A9307507281',
            'output': False
        },
        {
            'input': '0306406150',
            'output': False
        }
    ]
    for case in test_cases:
        assert case['output'] == __ISBNChecker(case['input']).is_isbn_10()

# Generated at 2022-06-12 07:21:38.422282
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker("978-0-306-40615-7").is_isbn_13() == True
    assert __ISBNChecker("978-0-307-13440-2").is_isbn_13() == True
    assert __ISBNChecker("0-306-40615-2").is_isbn_13() == False
    assert __ISBNChecker("0-307-13440-3").is_isbn_13() == False
    assert __ISBNChecker("9780306406157").is_isbn_13() == True
    assert __ISBNChecker("9780307134402").is_isbn_13() == True
    assert __ISBNChecker("978 0 306 40615 7").is_isbn_13() == False

# Generated at 2022-06-12 07:21:42.548192
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') # return true
    assert not is_json('[1, 2, 3]') # returns false
    assert not is_json('{nope}') # returns false

test_is_json()



# Generated at 2022-06-12 07:21:50.004712
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker("9780262033848").is_isbn_13() is True
    assert __ISBNChecker("978-0262033848").is_isbn_13() is False
    assert __ISBNChecker("9780262033849").is_isbn_13() is False
    assert __ISBNChecker("978026203384").is_isbn_13() is False
    assert __ISBNChecker("97802620338484").is_isbn_13() is False
    assert __ISBNChecker("9780262033848X").is_isbn_13() is False
    assert __ISBNChecker("9780262033848X", normalize=True).is_isbn_13() is True

# Generated at 2022-06-12 07:21:57.598364
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0306406152').is_isbn_10() is True
    assert __ISBNChecker('030640615X').is_isbn_10() is True
    assert __ISBNChecker('0306406153').is_isbn_10() is False
    assert __ISBNChecker('030640615').is_isbn_10() is False
    assert __ISBNChecker('0306406155X').is_isbn_10() is False
    assert __ISBNChecker('030640615FX').is_isbn_10() is False


# PUBLIC API



# Generated at 2022-06-12 07:22:08.514396
# Unit test for function is_email
def test_is_email():
    # TEST FOR BEGINNER
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@@the-provider.com') == False
    assert is_email('my.email@the-provider..com') == False
    assert is_email('.my.email@the-provider.com') == False
    assert is_email('my.email@the-provider...com') == False
    assert is_email('my.email@the-provider.com.') == False
    assert is_email('my.email..@the-provider.com.') == False
    assert is_email('my.email@the-provider..com') == False