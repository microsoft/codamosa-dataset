

# Generated at 2022-06-12 07:12:30.661598
# Unit test for function is_credit_card
def test_is_credit_card():
    cc_number_good = '4111111111111111'
    cc_number_bad = '10000000000000'
    assert is_credit_card(cc_number_good, card_type='VISA') == True
    assert is_credit_card(cc_number_bad, card_type='VISA') == False

# Generated at 2022-06-12 07:12:35.791352
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') is True
    assert is_ip_v4('nope') is False
    assert is_ip_v4('255.200.100.999') is False



# Generated at 2022-06-12 07:12:45.124260
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580')
    assert is_isbn('978-0312498580')

    assert is_isbn('1506715214')
    assert is_isbn('150-6715214')

    assert is_isbn('978-0-13-959894-8')
    assert is_isbn('978-0-13-959894-8', normalize=False)

    assert not is_isbn('978-0-13-959894-8', normalize=True)
    assert not is_isbn('978-0-13-959894-8', normalize=True)

    assert not is_isbn('9780312498580', normalize=False)
    assert not is_isbn('1506715214', normalize=False)


# Generated at 2022-06-12 07:12:49.516298
# Unit test for function is_ip
def test_is_ip():
	assert is_ip("255.200.100.75")==True
	assert is_ip("2001:db8:85a3:0000:0000:8a2e:370:7334")==True
	assert is_ip("1.2.3")==False
test_is_ip()


# Generated at 2022-06-12 07:13:01.767505
# Unit test for function is_credit_card
def test_is_credit_card():
    # Test of is_credit_card with card type in a normal situation
    assert is_credit_card("5424000000000015", card_type= "MASTERCARD") == True
    # Test of is_credit_card with no card type in a normal situation
    assert is_credit_card("5424000000000015") == True
    # Test of is_credit_card with no card type in a wrong situation
    assert is_credit_card("542400000000042") == False
    # Test of is_credit_card with card type in a wrong situation
    assert is_credit_card("542400000000042", card_type= "MASTERCARD") == False
    # Test of is_credit_card with a not existing card type

# Generated at 2022-06-12 07:13:08.761860
# Unit test for function is_json
def test_is_json():
    on_true = ['{"name": "Peter"}',
               '[1, 2, 3]']
    on_false = ['{nope}',
                '{ nope}',
                '{"nope"',
                '"nope"}']
    for case in on_true:
        assert is_json(case) == True, 'Input value is {}'.format(case)
    for case in on_false:
        assert is_json(case) == False, 'Input value is {}'.format(case)
    print('Test Case is Pass!')
test_is_json()


# Generated at 2022-06-12 07:13:14.847775
# Unit test for function is_json
def test_is_json():
    assert is_json('[1, 2, 3]')
    assert is_json('{"name": "Peter"}')
    assert is_json('{"name": ["Peter", "Paul", "Mary"]}')
    assert is_json('{"name": {"first": "Peter", "last": "Smith"}}')

    assert is_json('{"name": "Peter"\n"age": 42\n}')
    assert not is_json('{"name": "Peter"\n"age": 42\n')

    assert not is_json('')

    assert not is_json('name')
    assert not is_json('{nope')
    assert not is_json('nope}')

    assert is_json('{}')
    assert is_json('[]')

    assert is_json('{"name": "Peter"}', True)


# Generated at 2022-06-12 07:13:18.284766
# Unit test for function is_json
def test_is_json():
    assert is_json({"name": "Peter"})
    assert is_json([1, 2, 3])
    assert is_json('{nope}')
    return 'test_is_json passed'
print(test_is_json())


# Generated at 2022-06-12 07:13:22.581371
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com')
    assert is_url('https://mysite.com')
    assert is_url('.mysite.com') == False
test_is_url()



# Generated at 2022-06-12 07:13:30.793406
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') is True
    assert is_ip_v4('nope') is False
    assert is_ip_v4('255.200.100.999') is False
    assert is_ip_v4('255.200.100') is False
    assert is_ip_v4('255.200.100.a') is False
    assert is_ip_v4('255.200.100.0') is True
    assert is_ip_v4('255.200.100.255') is True

# Generated at 2022-06-12 07:13:50.958264
# Unit test for function is_url
def test_is_url():
    assert is_url('http://mysite.com')
    assert is_url('https://mysite.com')
    assert not is_url('www.mysite.com')
    assert not is_url('.mysite.com')
    assert not is_url('http://')
    assert not is_url('http://mysite.')
    assert not is_url('http://mysite.com.')
    assert is_url('mailto:info@mysite.com')
    assert is_url('data:image/png;base64,iVBOR...')
    assert is_url('http://www.domain.com', ['http', 'https'])
    assert not is_url('http://www.domain.com', ['ftp'])



# Generated at 2022-06-12 07:13:53.297238
# Unit test for function is_email
def test_is_email():
    assert(is_email('my.email@the-provider.com') == True)


# Generated at 2022-06-12 07:14:00.646019
# Unit test for function is_email
def test_is_email():
    assert is_email('a@example.com')
    assert is_email('A@example.com')
    assert is_email('A.B@example.com')
    assert is_email('A-B@example.com')
    assert is_email('A_B@example.com')
    assert is_email('Abc.123@example.com')
    assert is_email('a"b(c)d,e:f;g<h>i[j\k]l@example.com')
    assert is_email('just"not"right@example.com')
    assert is_email('this is"not\allowed@example.com')
    assert is_email('this\ still\"not\\allowed@example.com')
    assert not is_email('john..doe@example.com')

# Generated at 2022-06-12 07:14:06.156121
# Unit test for function is_email
def test_is_email():
    assert is_email("my.email@the-provider.com") == True
    assert is_email("@gmail.com") == False
    assert is_email("") == False
    assert is_email("https://the-provider.com") == False




# Generated at 2022-06-12 07:14:16.577276
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('first.last@the-provider.com')
    assert is_email('email.with.a.very.long.tail@the-provider.com')
    assert is_email('email.with.a.long.tail.between4and64.so.it.is.valid@the-provider.com')
    assert is_email('first_last@the-provider.com')
    assert is_email('first_last@the-provider.com')
    assert is_email('first.last@the-provider.com')
    assert is_email('first_last@the-provider.com')
    assert is_email('first.last@the-provider.com')

# Generated at 2022-06-12 07:14:19.759045
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') == True
    assert is_url('https://mysite.com') == True
    assert is_url('.mysite.com') == False
    assert is_url('') == False



# Generated at 2022-06-12 07:14:22.368538
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False



# Generated at 2022-06-12 07:14:32.285092
# Unit test for function is_json
def test_is_json():
    # Error test
    input_string = 22
    ex_msg = 'The input must be a string'
    actual_result = is_json(input_string)
    expected_result = False
    assert actual_result == expected_result
    
    # Error test
    input_string = ""
    ex_msg = 'The input must be a non-empty string'
    actual_result = is_json(input_string)
    expected_result = False
    assert actual_result == expected_result

    # Case test
    input_string = '{"name": "Peter"}'
    actual_result = is_json(input_string)
    expected_result = True
    assert actual_result == expected_result

    # Case test
    input_string = '[1, 2, 3]'

# Generated at 2022-06-12 07:14:34.161428
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') == True
    assert is_url('https://mysite.com') == True
    assert is_url('.mysite.com') == False


# Generated at 2022-06-12 07:14:41.222500
# Unit test for function is_json
def test_is_json():
    assert is_json('hello') == False
    assert is_json(5) == False
    assert is_json([1,2,3]) == True
    assert is_json({'name': 'John'}) == True
    assert is_json('{name: "John"}') == False
    assert is_json('{"name": "John"}') == True


# Generated at 2022-06-12 07:14:56.997555
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('my\ \.email@the-provider.com')
    assert is_email('"myspace@nospaces"@gmail.com')
    assert not is_email('@gmail.com')
    assert not is_email('head..tail@domain.com')
    assert not is_email('head@tail.com.')
    assert not is_email('.head@tail.com')
    assert not is_email('head.tail@domain.com.')
    assert not is_email('head.@tail.com')

    assert is_email('"\\"very.unusual.@.unusual.com\\"@example.com')

# Generated at 2022-06-12 07:15:01.645539
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') is True
    assert is_ip_v4('nope') is False
    assert is_ip_v4('255.200.100.999') is False
test_is_ip_v4()



# Generated at 2022-06-12 07:15:03.308937
# Unit test for function is_email
def test_is_email():
    assert is_email('') == False



# Generated at 2022-06-12 07:15:10.731832
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert is_ip_v4('172.16.254.1')
    assert not is_ip_v4('nope')
    assert not is_ip_v4('172.16.256.1')
    assert not is_ip_v4('172.16.255.1.1')
    assert not is_ip_v4('172.16.255.1 ')
    assert not is_ip_v4('172.16.255.1\t')


# Generated at 2022-06-12 07:15:18.639704
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    print('Testing method is_isbn_13 of class __ISBNChecker')

    # Test 1
    isbn = __ISBNChecker('0306406152')
    print('Test 1', '✓' if isbn.is_isbn_13() else '✗', f'isbn.is_isbn_13() = {isbn.is_isbn_13()}, should be True')

    # Test 2
    isbn = __ISBNChecker('978-0306406157')
    print('Test 2', '✓' if isbn.is_isbn_13() else '✗', f'isbn.is_isbn_13() = {isbn.is_isbn_13()}, should be True')

    # Test 3
    isbn = __ISBNChecker('978-5945276636')

# Generated at 2022-06-12 07:15:30.453719
# Unit test for function is_email
def test_is_email():
    assert is_email('abcd@protonmail.com') is True
    assert is_email('a.b@protonmail.com') is True
    assert is_email('a.b.c@protonmail.com') is True
    assert is_email('a.b.c.d@protonmail.com') is True
    assert is_email('a_b_c_d@protonmail.com') is True
    assert is_email('a-b-c-d@protonmail.com') is True
    assert is_email('a.b_c.d@protonmail.com') is True
    assert is_email('a-b_c-d@protonmail.com') is True
    assert is_email('a.b-c.d@protonmail.com') is True

# Generated at 2022-06-12 07:15:36.547573
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False
# Test
test_is_ip_v4()

# ------------------------------------------------------------------------

# Function: to_camel_case

# Generated at 2022-06-12 07:15:43.334854
# Unit test for function is_ip_v4
def test_is_ip_v4():
    print("Testing is_ip_v4...", end="")
    assert is_ip_v4('128.8.8.8')
    assert is_ip_v4('255.255.255.255')
    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999')
    assert not is_ip_v4('255.200')
    print("Ok!")
test_is_ip_v4()



# Generated at 2022-06-12 07:15:53.652122
# Unit test for function is_email
def test_is_email():
    # Test 1: Correct email -> True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.co.uk') == True
    assert is_email('my.email+spam@the-provider.com') == True
    assert is_email('-@the-provider.com') == True
    assert is_email('a@email.com') == True

    # Test 2: Correct email, with quotes -> True
    assert is_email('"my.email"@the-provider.com') == True
    assert is_email('"my.email+spam"@the-provider.com') == True
    assert is_email('"my.email@spam"@the-provider.com') == True

# Generated at 2022-06-12 07:16:00.155847
# Unit test for function is_email
def test_is_email():
    assert is_email('me@gmail.com') # standard case
    assert is_email('me.123@gmail.com.it') # subdomain case
    assert is_email('me_123@gmail.com.it') # underscore in email
    assert is_string('me_123@gmail.com.it')
    assert is_email('me-123@gmail.com.it') # dash in email
    assert is_email('me+123@gmail.com.it') # plus in email
    assert is_email('user@local') # no TLD
    assert is_email('user@localhost') # localhost
    assert is_email('"me rick"@gmail.com') # escaped spaces in email
    assert is_email('me\ rick@gmail.com') # escaped spaces in email

# Generated at 2022-06-12 07:16:13.142738
# Unit test for function is_email
def test_is_email():
    assert is_email('d.pierangeli@stud.uniroma3.it')
    assert not is_email('d.pierangeli@stud.uniroma3.')
    assert not is_email('d.pierangeli@stud.uniroma3.i')
    assert not is_email('d.pierangeli@.it')
    assert not is_email('d.pierangeli@stud.uniromat.it')
    assert not is_email('d.pierangeli@stud.uniroma3.i')
    assert not is_email('d.pierangeli@stud.uniroma3.it1')
    assert not is_email('d.pierangeli@studio.uniroma3.it')

# Generated at 2022-06-12 07:16:23.151093
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('9781783554812').is_isbn_10() == False
    assert __ISBNChecker('0451450523').is_isbn_10() == True
    assert __ISBNChecker('0062225669').is_isbn_10() == True
    assert __ISBNChecker('0765333679').is_isbn_10() == True
    assert __ISBNChecker('0544105147').is_isbn_10() == True
    assert __ISBNChecker('978-0-19-979114-6').is_isbn_10() == True
    assert __ISBNChecker('0-19-979114-6').is_isbn_10() == True
    assert __ISBNChecker('0-19-979114-2').is_isbn_10

# Generated at 2022-06-12 07:16:29.691161
# Unit test for function is_json
def test_is_json():
    assert is_json('{"test":true}') == True
    assert is_json('{"test":false}') == True
    assert is_json({"test":True}) == False
    assert is_json('{"test":') == False
    assert is_json('{"test":true') == False
    assert is_json('{"test":"true"}') == True
    assert is_json('{"test":333}') == True
    assert is_json('{"test":333.333}') == True
    assert is_json('{"test":[1,2,3]}') == True
    assert is_json('{"test":{"name":"peter"}}') == True



# Generated at 2022-06-12 07:16:32.843085
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False
    print("Function is_json() works fine")


# Generated at 2022-06-12 07:16:42.839551
# Unit test for function is_email
def test_is_email():
    assert is_email('1test@test.com') == True
    assert is_email('test@test.com') == True
    assert is_email('test@test.com') == True
    assert is_email('test.1test@test.com') == True
    assert is_email('test.test@test.com') == True
    assert is_email('test_test@test.com') == True
    assert is_email('.test@test.com') == False
    assert is_email('test@.test.com') == False
    assert is_email('test@test..com') == False
    assert is_email('test@test.com.') == False
    assert is_email('test@test@test.com') == False
    assert is_email('test@test') == False

# Generated at 2022-06-12 07:16:54.203066
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    print(__ISBNChecker('1234567890').is_isbn_10())  # True
    print(__ISBNChecker('12345678X9').is_isbn_10())  # True
    print(__ISBNChecker('123456789X').is_isbn_10())  # True
    print(__ISBNChecker('0234567890').is_isbn_10())  # False

    assert __ISBNChecker('1234567890').is_isbn_10()
    assert __ISBNChecker('12345678X9').is_isbn_10()
    assert __ISBNChecker('123456789X').is_isbn_10()
    assert not __ISBNChecker('0234567890').is_isbn_10()


# Generated at 2022-06-12 07:16:56.219073
# Unit test for function is_email
def test_is_email():
    assert is_email("a@b.com") == True


# Generated at 2022-06-12 07:17:04.953421
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my+email@the-provider.com')
    assert not is_email('@gmail.com')
    assert is_email('"my.email"@the-provider.com')
    assert is_email('"my.email"@the-provider.com')
    assert is_email('"my.email"@the-provider.com')
    assert is_email("my.e'ma'il@the-provider.com")
    assert is_email('"Johnny O\'Hara"@example.com')
    assert is_email('"O\'Hara"@example.com')

# Generated at 2022-06-12 07:17:11.895327
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('1234567890123').is_isbn_13() == True
    assert __ISBNChecker('1234567890129').is_isbn_13() == False
    assert __ISBNChecker('12345678901234').is_isbn_13() == False
    assert __ISBNChecker('1234567890123a').is_isbn_13() == False
    assert __ISBNChecker('123-4567890123').is_isbn_13() == True
    assert __ISBNChecker('123-456789012-3').is_isbn_13() == True
    assert __ISBNChecker('123-45678901234').is_isbn_13() == False

# Generated at 2022-06-12 07:17:18.239821
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my+email@the-provider.com')
    assert is_email('my_email@the-provider.com')
    assert is_email('email@[127.0.0.2]')
    assert not is_email('.user@example.com')
    assert not is_email('user.@example.com')
    assert not is_email('user..name@example.com')
    assert not is_email('user+@example.com')
    assert not is_email('user_@example.com')
    assert not is_email('user@.example.com')
    assert not is_email('user@example..com')

# Generated at 2022-06-12 07:17:24.061701
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('9780440180296').is_isbn_10() == True
    assert __ISBNChecker('9791090701634').is_isbn_10() == False



# Generated at 2022-06-12 07:17:25.696804
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('3423214120').is_isbn_10()


# PUBLIC API


# string

# Generated at 2022-06-12 07:17:31.396163
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    checker = __ISBNChecker('0136091810')
    assert checker.is_isbn_10()

    checker = __ISBNChecker('0205003008')
    assert checker.is_isbn_10()

    checker = __ISBNChecker('1259001322')
    assert checker.is_isbn_10()

    checker = __ISBNChecker('0002006513')
    assert not checker.is_isbn_10()

    checker = __ISBNChecker('007020662X')
    assert not checker.is_isbn_10()

    checker = __ISBNChecker('020111116X')
    assert checker.is_isbn_10()

    checker = __ISBNChecker('047105983X')

# Generated at 2022-06-12 07:17:33.548154
# Unit test for function is_email
def test_is_email():
    text = "myemail@gmail.com"
    assert is_email(text) == True


# Generated at 2022-06-12 07:17:41.277288
# Unit test for function is_email
def test_is_email():
    assert is_email('test@test.com') == True
    assert is_email('Ũnicöde@test.com') == True
    assert is_email('test.test@test.com') == True
    assert is_email('test.test@test.school.org') == True
    assert is_email('test+test@test.school.org') == True
    assert is_email('"test@test"@test.school.org') == True
    assert is_email('test@test.school.org', ['test.school.org']) == True
    assert is_email('test@test.school.org', ['other.school.org']) == False
    assert is_email('test@school.org', ['test.school.org']) == False

# Generated at 2022-06-12 07:17:48.729705
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('192.168.0.1')
    assert is_ip_v4('255.255.255.255')
    assert not is_ip_v4('192.168.0.1\t')
    assert not is_ip_v4('192.168.0.1\n')
    assert not is_ip_v4('192.168.0.1\r')
    assert not is_ip_v4('123.123.123.123\t')
    assert not is_ip_v4('123.123.123.123\n')
    assert not is_ip_v4('123.123.123.123\r')

# Generated at 2022-06-12 07:17:54.224881
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert not __ISBNChecker('0345391802').is_isbn_10()
    assert not __ISBNChecker('034539180X').is_isbn_10()
    assert __ISBNChecker('0345391801').is_isbn_10()
    assert __ISBNChecker('0670126443').is_isbn_10()

# Generated at 2022-06-12 07:18:02.652763
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('9781853260087').is_isbn_13() is False
    assert __ISBNChecker('9781853260087', False).is_isbn_13() is False
    assert __ISBNChecker('978-18-5326-008-7').is_isbn_13() is True
    assert __ISBNChecker('978-18-5326-008-7', False).is_isbn_13() is False

# Generated at 2022-06-12 07:18:04.935599
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    checker = __ISBNChecker('9780071112308')
    assert checker.is_isbn_13() == True



# Generated at 2022-06-12 07:18:13.031085
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('1234567890').is_isbn_10() == True
    assert __ISBNChecker('070440020X').is_isbn_10() == True
    assert __ISBNChecker('0-00-714773-X').is_isbn_10() == True
    assert __ISBNChecker('0-201-63385-X').is_isbn_10() == True
    assert __ISBNChecker('0-201-63385-8').is_isbn_10() == False # 10-digit ISBN, check-digit = 8


# Generated at 2022-06-12 07:18:22.778542
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') # returns true
    assert is_ip_v4('nope') == False # returns false (not an ip)
    assert is_ip_v4('255.200.100.999') == False # returns false (999 is out of range)


# Generated at 2022-06-12 07:18:29.267244
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert not __ISBNChecker('A064298733').is_isbn_10()
    assert not __ISBNChecker('9788374707561').is_isbn_10()
    assert not __ISBNChecker('9788374707561').is_isbn_10()
    assert not __ISBNChecker('8374707568').is_isbn_10()
    assert not __ISBNChecker('8374707561').is_isbn_10()
    assert not __ISBNChecker('837470756').is_isbn_10()
    assert not __ISBNChecker('83747075P').is_isbn_10()
    assert not __ISBNChecker('83747075a').is_isbn_10()

# Generated at 2022-06-12 07:18:30.820041
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert not is_email('@gmail.com')



# Generated at 2022-06-12 07:18:39.140659
# Unit test for function is_email
def test_is_email():
    assert is_email('contact@john.doe') == True
    assert is_email('contact@john.doe.org') == True
    assert is_email('contact.john@doe.org') == True
    assert is_email('contact@john.doe.org.uk') == True
    assert is_email('john@doe.org') == True
    assert is_email('John.Smith@hostname.subdomain.domain.top-level-domain') == True
    assert is_email('john.smith@hostname.subdomain.domain.top-level-domain') == True
    assert is_email('john.smith@hostname.subdomain.domain.top-level-domain.com') == True
    assert is_email('my.email@the-provider.com') == True

# Generated at 2022-06-12 07:18:41.966604
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    isbnChecker = __ISBNChecker("")
    assert isbnChecker.is_isbn_13() == False


# Generated at 2022-06-12 07:18:45.973349
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False
    assert is_ip_v4('255.200.100.256') == False



# Generated at 2022-06-12 07:18:49.521750
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-1-123-45678-9').is_isbn_13() == True
    assert __ISBNChecker('978-1-123-45678-9X').is_isbn_13() == False
    assert __ISBNChecker('978-1-123-45678-9X0').is_isbn_13() == False

# Generated at 2022-06-12 07:18:54.847637
# Unit test for function is_json
def test_is_json():
    # Check if json string with valid format is identified as json
    assert is_json('{"name": "Peter"}') == True

    # Check if json string with array of ints is identified as json
    assert is_json('[1, 2, 3]') == True

    # Check if non-json string is not identified as json
    assert is_json('{nope}') == False



# Generated at 2022-06-12 07:19:00.418718
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker("0060253847").is_isbn_10()
    assert not __ISBNChecker("00602538").is_isbn_10()
    assert not __ISBNChecker("00602538470").is_isbn_10()
    assert not __ISBNChecker("0060253848").is_isbn_10()


# Generated at 2022-06-12 07:19:04.395797
# Unit test for function is_email
def test_is_email():
    assert is_email('shivamchaudhary@gmail.com') == True
    assert is_email('shivamchaudhary@gmail.com') == True
    assert is_email('shivamchaudhary@gmail.com') == True
    assert is_email('shivamchaudhary@gmail.com') == True



# Generated at 2022-06-12 07:19:21.890775
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('9780131495050').is_isbn_13()
    assert __ISBNChecker('978-0134-38-000-7').is_isbn_13()
    assert __ISBNChecker('978-013-149-505-0').is_isbn_13()

    assert __ISBNChecker('9780131495051').is_isbn_13() is False
    assert __ISBNChecker('978-0134-38-000-8').is_isbn_13() is False
    assert __ISBNChecker('978-013-149-505-1').is_isbn_13() is False

    assert __ISBNChecker('978013149505').is_isbn_13() is False

# Generated at 2022-06-12 07:19:26.538827
# Unit test for function is_json
def test_is_json():
    a = '{"name": "Peter"}'
    b = '[1, 2, 3]'
    c = '{'
    assert is_json(a) == True
    assert is_json(b) == True
    assert is_json(c) == False


# Generated at 2022-06-12 07:19:36.220094
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-3-16-148410-0').is_isbn_13() == True  # testing: with dash
    assert __ISBNChecker('9783161484100').is_isbn_13() == True  # testing: without dash
    assert __ISBNChecker('978-316-148-41-00').is_isbn_13() == True  # testing: with dash and spacing
    assert __ISBNChecker('9783161484100X').is_isbn_13() == False  # testing: with char X at the end
    assert __ISBNChecker('9783161484100M').is_isbn_13() == False  # testing: with char M at the end


# PUBLIC API



# Generated at 2022-06-12 07:19:45.489561
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0-306-40615-2').is_isbn_10()
    assert __ISBNChecker('156881111X').is_isbn_10()
    assert __ISBNChecker('978-1933988665').is_isbn_10()

    assert not __ISBNChecker('0-306-40615-3').is_isbn_10()
    assert not __ISBNChecker('156881111Y').is_isbn_10()
    assert not __ISBNChecker('978-193398866').is_isbn_10()
    assert not __ISBNChecker('978a1933988665').is_isbn_10()
    assert not __ISBNChecker('Cannot').is_isbn_10()

# Generated at 2022-06-12 07:19:51.844907
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    isbn_checker = __ISBNChecker(input_string = '978-1-56619-909-4')
    assert isbn_checker.is_isbn_13() == True

    isbn_checker = __ISBNChecker(input_string = '9781566919094')
    assert isbn_checker.is_isbn_13() == True
    
    isbn_checker = __ISBNChecker(input_string = '9781566919095')
    assert isbn_checker.is_isbn_13() == False
    
    isbn_checker = __ISBNChecker(input_string = '1234567890123')
    assert isbn_checker.is_isbn_13() == False


# Generated at 2022-06-12 07:20:01.353776
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert not __ISBNChecker('084930615X').is_isbn_10()
    assert not __ISBNChecker('084930615X').is_isbn_13()
    assert not __ISBNChecker('084930615X').is_isbn_10(False)
    assert not __ISBNChecker('084930615X').is_isbn_13(False)
    assert __ISBNChecker('084930615X', False).is_isbn_10()
    assert __ISBNChecker('084930615X', False).is_isbn_13()
    assert __ISBNChecker('084930615X', False).is_isbn_10()
    assert __ISBNChecker('084930615X', False).is_isbn_13()



# Generated at 2022-06-12 07:20:05.194114
# Unit test for function is_email
def test_is_email():
    if is_email('my.email@the-provider.com'):
        print('Test is_email: passed')
    else:
        print('Test is_email: failed')



# Generated at 2022-06-12 07:20:14.184852
# Unit test for function is_email
def test_is_email():
    assert is_email('test@test.com') == True
    assert is_email('man.fred99@gmail.com') == True
    assert is_email('man.fred99@gmailcom') == False
    assert is_email('man.fred99@gmail.com.co') == True
    assert is_email('manfred99@gmail.com.co') == True
    assert is_email('@gmail.com') == False
    assert is_email('fred@gmail..com') == False
    assert is_email('"fred@example.com"@example.com') == True
    assert is_email('"very.unusual.@.unusual.com"@example.com') == True

# Generated at 2022-06-12 07:20:20.976872
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-0-306-40481-5').is_isbn_13()
    assert not __ISBNChecker('978-0-306-40481-0').is_isbn_13()
    assert __ISBNChecker('9784334017922').is_isbn_13()
    assert not __ISBNChecker('9784334017921').is_isbn_13()
    assert not __ISBNChecker('9784334017921abc').is_isbn_13()


# Generated at 2022-06-12 07:20:22.810107
# Unit test for function is_email
def test_is_email():
    assert is_email(email) == True
    assert is_email(email_no_valid) == False 



# Generated at 2022-06-12 07:20:37.911148
# Unit test for function is_json
def test_is_json():
    assert is_json('{"key": "value"}') is True
    assert is_json('[1,2,3,4]') is True
    assert is_json('[]') is True
    assert is_json('{}') is True
    assert is_json('true') is False
    assert is_json('foo') is False
    assert is_json('"bar"') is False
    assert is_json('null') is False
    assert is_json('{"key": "value' ) is False
    assert is_json('') is False



# Generated at 2022-06-12 07:20:40.164971
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    checker = __ISBNChecker("978-1-56619-909-4")
    assert checker.is_isbn_13() == True



# Generated at 2022-06-12 07:20:46.659056
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False
    assert is_json(']') == False
    assert is_json('{') == False
    assert is_json('[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[') == False


# Generated at 2022-06-12 07:20:57.783661
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@my-provider.com')
    assert not is_email('my.email@@my-provider.com')
    assert is_email('my.email@my-provider.com')
    assert not is_email('my.email@my-provider')
    assert not is_email('.@')
    assert not is_email('@gmail.com')
    assert not is_email('')
    assert is_email('teste@gmail.com')
    assert is_email('teste.teste@gmail.com')
    assert is_email('teste.teste.teste@gmail.com')
    assert is_email('mail@hostname.com')
    assert is_email('mail@domain.com.br')

# Generated at 2022-06-12 07:21:04.026923
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-0-306-40615-7').is_isbn_13() is True
    assert __ISBNChecker('1576839627').is_isbn_13() is True
    assert __ISBNChecker('978-0-306-40615-0').is_isbn_13() is False



# Generated at 2022-06-12 07:21:13.941796
# Unit test for method is_isbn_10 of class __ISBNChecker

# Generated at 2022-06-12 07:21:25.550602
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert not __ISBNChecker('0306406152').is_isbn_10()
    assert not __ISBNChecker('0306406151').is_isbn_10()
    assert not __ISBNChecker('033048352X').is_isbn_10()
    assert not __ISBNChecker('0330483528').is_isbn_10()
    assert __ISBNChecker('0330483529').is_isbn_10()
    assert __ISBNChecker('033048352X').is_isbn_10()
    assert not __ISBNChecker('0330483531').is_isbn_10()
    assert not __ISBNChecker('0306406153').is_isbn_10()


# Generated at 2022-06-12 07:21:27.591905
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    isbn = __ISBNChecker('123456789X')
    result = isbn.is_isbn_10()
    assert result == True

# Generated at 2022-06-12 07:21:35.583676
# Unit test for function is_json
def test_is_json():
    assert is_json("[]") is True
    assert is_json("{}") is True
    assert is_json("{123}") is False
    assert is_json('"str"') is False
    # check for overflow error
    assert is_json("{\"foo\": \"bar\"" + "}" * 2048 + "}") is False
    assert is_json("{\"foo\": [\"bar\"" + "]" * 2048 + "}") is False



# Generated at 2022-06-12 07:21:42.960572
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999')

#
# is_ip_v6 not implemented yet
#
# def is_ip_v6(input_string: Any) -> bool:
#     """
#     Checks if a string is a valid ip v6.
#
#     *Examples:*
#
#     >>> is_ip_v6('2001:db8:a0b:12f0::1') # returns true
#
#     :param input_string: String to check.
#     :type input_string: str
#     :return: True if an ip v6, false otherwise.
#     """
#     return False



# Generated at 2022-06-12 07:21:53.773411
# Unit test for function is_email
def test_is_email():
    is_email('my.email@the-provider.com')
    # returns true
    is_email('@gmail.com')
    # returns false



# Generated at 2022-06-12 07:21:56.307578
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('1234567890').is_isbn_10() == True, 'Method is_isbn_10 of class __ISBNChecker should return True'

# Generated at 2022-06-12 07:21:59.690811
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    checker = __ISBNChecker('0134612140')
    assert checker.is_isbn_10()

    checker = __ISBNChecker('0735619670')
    assert not checker.is_isbn_10()

# Generated at 2022-06-12 07:22:04.796996
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') # returns true
    assert not is_ip_v4('nope') # returns false (not an ip)
    assert not is_ip_v4('255.200.100.999') # returns false (999 is out of range)


# Generated at 2022-06-12 07:22:08.269536
# Unit test for function is_json
def test_is_json():
    assert is_json("no json") == False
    assert is_json("{\"name\": \"Peter\"}") == True  
    assert is_json("[1, 2, 3]") == True
    assert is_json("{nope}") == False