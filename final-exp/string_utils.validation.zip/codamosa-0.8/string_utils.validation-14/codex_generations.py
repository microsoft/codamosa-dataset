

# Generated at 2022-06-12 07:12:38.921855
# Unit test for function is_email
def test_is_email():
    assert is_email('abc') == False
    assert is_email('abc@def.com') == True
    assert is_email('abc@.com') == False
    assert is_email('abc@def.com.') == False



# Generated at 2022-06-12 07:12:40.946907
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42') == True
    assert is_integer('42.0') == False

# --------------------------------------------------------------------


# Generated at 2022-06-12 07:12:43.522513
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4("255.200.100.75")
    assert not is_ip_v4("nope")
    assert not is_ip_v4("255.200.100.999")



# Generated at 2022-06-12 07:12:47.780595
# Unit test for function is_ip
def test_is_ip():
    assert(is_ip("localhost"))
    assert(is_ip("127.0.0.1"))
    assert(is_ip("2001:db8:85a3:0000:0000:8a2e:370:7334"))

# Generated at 2022-06-12 07:12:59.957851
# Unit test for function is_email
def test_is_email():
    assert is_email('foo.bar@myprovider.com') == True
    assert is_email('foo.bar@my.provider.com') == True
    assert is_email('foo.bar@myprovider.com') == True
    assert is_email('foo.bar@my.provider.com') == True
    # ...
    assert is_email('"foo.bar"@myprovider.com') == True
    assert is_email('"foo.bar@my.provider.com"@myprovider.com') == True
    assert is_email('"foo.bar"@myprovider.com') == True
    assert is_email('"foo.bar@my.provider.com"@myprovider.com') == True
    # ...

# Generated at 2022-06-12 07:13:03.191839
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') == True
    assert is_url('https://mysite.com') == True
    assert is_url('.mysite.com') == False


# Generated at 2022-06-12 07:13:08.696753
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') ==True
    assert is_ip_v4('nope') ==False
    assert is_ip_v4('255.200.100.999') ==False


# Generated at 2022-06-12 07:13:15.019527
# Unit test for function is_ip_v4
def test_is_ip_v4():
    # assert if ipv4
    assert(is_ip_v4('255.200.100.75'))
    # assert if not ipv4
    assert(not is_ip_v4('nope'))
    assert(not is_ip_v4('255.200.100.999'))

# Generated at 2022-06-12 07:13:18.400363
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True


# Generated at 2022-06-12 07:13:29.901568
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4111111111111111', card_type='VISA')
    assert is_credit_card('4111111111111111')
    assert is_credit_card('4111 1111 1111 1111')
    assert not is_credit_card('4111111111111112')
    assert is_credit_card('5105105105105100')
    assert not is_credit_card('5105105105105106')
    assert is_credit_card('378282246310005')
    assert is_credit_card('3714 4963 5398 431')
    assert not is_credit_card('371449635398432')
    assert not is_credit_card('3714 4963 5309 8431')
    assert is_credit_card('6011111111111117')
    assert is_credit_

# Generated at 2022-06-12 07:13:45.916892
# Unit test for function is_isbn
def test_is_isbn():
    # isbn 13
    assert is_isbn('9780312498580') == True
    assert is_isbn('978-0312498580') == True
    assert is_isbn('978-0312498580', normalize=False) == False

    # isbn 10
    assert is_isbn('1506715214') == True
    assert is_isbn('150-6715214') == True
    assert is_isbn('150-6715214', normalize=False) == False

# Generated at 2022-06-12 07:13:53.350688
# Unit test for function is_json
def test_is_json():
    assert is_json(None)
    assert is_json('{}')
    assert is_json('[]')
    assert is_json('{ "hello": "world" }')
    assert is_json('{ "name": "Peter", "age": 27}')
    assert not is_json('{"name": "Peter", "age": 27')
    assert not is_json('[] {}')
    assert not is_json('[]}')
    assert not is_json('{[}')
    assert not is_json('hello world')
    assert not is_json('')



# Generated at 2022-06-12 07:13:57.654086
# Unit test for function is_json
def test_is_json():
    invalid = ['{nope}', '{a: b}', '{"name": "Peter", 123}']
    for i in invalid:
        assert not is_json(i)

is_uuid = lambda input_string: is_full_string(input_string) and UUID_RE.match(input_string) is not None



# Generated at 2022-06-12 07:14:01.135220
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    input_string = '978-3-16-148410-0'
    normalize = False
    assert __ISBNChecker(input_string, normalize).is_isbn_13() == True

    input_string = '9783161484100'
    normalize = True
    assert __ISBNChecker(input_string, normalize).is_isbn_13() == True


# Generated at 2022-06-12 07:14:13.483268
# Unit test for function is_email
def test_is_email():
    assert(is_email('my.email@the-provider.com') == True)
    assert(is_email('.mysite.com') == False)
    assert(is_email('@gmail.com') == False)
    assert(is_email('my.em.ail@the-provider.com') == True)
    assert(is_email('my..em.ail@the-provider.com') == False)
    assert(is_email('my..em.ail@the-provider.com') == False)
    assert(is_email('my"\\"em.ail@the-provider.com') == True)

    assert(is_email('"my email"@the-provider.com') == True)
    assert(is_email('"my\\ email"@the-provider.com') == True)

# Generated at 2022-06-12 07:14:15.275575
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-12 07:14:16.858750
# Unit test for function is_json
def test_is_json():
    assert not is_json('{nope}')
    assert is_json('{"name": "Peter"}')


# Generated at 2022-06-12 07:14:22.107938
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') # returns true
    assert is_json('[1, 2, 3]') # returns true

    ## TODO
    ## is_json function should not return True when trying to load this string
    assert is_json('[1, 2, ]') # returns true



# Generated at 2022-06-12 07:14:25.550328
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False
    


# Generated at 2022-06-12 07:14:29.559891
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False



# Generated at 2022-06-12 07:14:45.046844
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker("0000000000").is_isbn_10() == False
    assert __ISBNChecker("1111111111").is_isbn_10() == False
    assert __ISBNChecker("2222222222").is_isbn_10() == False
    assert __ISBNChecker("3333333333").is_isbn_10() == False
    assert __ISBNChecker("4444444444").is_isbn_10() == False
    assert __ISBNChecker("5555555555").is_isbn_10() == False
    assert __ISBNChecker("6666666666").is_isbn_10() == False
    assert __ISBNChecker("7777777777").is_isbn_10() == False
    assert __ISBNChecker("8888888888").is_is

# Generated at 2022-06-12 07:14:49.287674
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False

# Generated at 2022-06-12 07:14:52.465536
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-12 07:14:56.078933
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False

test_is_ip_v4()


# Generated at 2022-06-12 07:15:08.733974
# Unit test for function is_json
def test_is_json():
    assert is_json('[{"name":"Peter"}]') == True
    assert is_json('{"name": "Peter"}') == True
    assert is_json('{"name":"Peter","age":20}') == True
    assert is_json('{"name":"Peter","age": 20}') == True
    assert is_json('{"name":"Peter","age":20.5}') == True
    assert is_json('{"name":"Peter","age": "20"}') == True
    assert is_json('{"name":"Peter","address": {"line":"1st Avenue","city":"New York","state":"NY","zip":10001}}') == True
    assert is_json('[1,2,3]') == True
    assert is_json('[ ]') == True
    assert is_json('[1, "a", 2]') == True

# Generated at 2022-06-12 07:15:14.045672
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999')
    assert not is_ip_v4('255.200.100')
    assert not is_ip_v4('255.200.100.')
    assert not is_ip_v4('255.200.100.75-10')
    assert not is_ip_v4('')
    assert not is_ip_v4(None)



# Generated at 2022-06-12 07:15:16.305729
# Unit test for function is_email
def test_is_email():
    assert not is_email("a@b.c")
test_is_email()



# Generated at 2022-06-12 07:15:26.654467
# Unit test for function is_email
def test_is_email():
    assert is_email('user1@gmail.com') == True
    assert is_email('user.1@gmail.com') == True
    assert is_email('user.@gmail.com') == False
    assert is_email('user.1+2@gmail.com') == False
    assert is_email('user1+2@gmail.com') == False
    assert is_email('user1+2@gmail.com') == False
    assert is_email('user+2@gmail.com') == False
    assert is_email('user1+@gmail.com') == False
    assert is_email('user1+2@gmail.com') == False
    assert is_email('user1+2@gmail.com') == False
    assert is_email('user1+2@gmail.com') == False

# Generated at 2022-06-12 07:15:35.512726
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0306406152').is_isbn_10() is True
    assert __ISBNChecker('030640614X').is_isbn_10() is True
    assert __ISBNChecker('030640614').is_isbn_10() is False
    assert __ISBNChecker('0306406140').is_isbn_10() is False
    assert __ISBNChecker('0-306-40614-X').is_isbn_10() is False
    assert __ISBNChecker('0-306-40614-1').is_isbn_10() is False
    assert __ISBNChecker('0-306-40614-0').is_isbn_10() is False



# Generated at 2022-06-12 07:15:45.912672
# Unit test for function is_email
def test_is_email():
    assert is_email('my-email@foo.bar.com') == True
    assert is_email('name@example.com') == True
    assert is_email('name=foo@example.com') == True
    assert is_email('"foo bar"@example.com') == True
    assert is_email('hi@example.com') == True
    assert is_email('foo@example-bar.com') == True
    assert is_email('foo@example_bar.com') == True

    assert is_email('name@example.com') == True
    assert is_email('foo()*@example.com') == False
    assert is_email('foo@example..com') == False
    assert is_email('foo@example.c') == False
    assert is_email('foo @example.com') == False
    assert is_

# Generated at 2022-06-12 07:15:55.530703
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@') == False
    assert is_email('my.email') == False
    assert is_email('my.email@[127.0.0.1') == False



# Generated at 2022-06-12 07:16:01.086007
# Unit test for function is_email
def test_is_email():
  assert is_email('example@domain.com')==True
  assert is_email('example@domain')==False
  assert is_email('example@gmail123')==False
  assert is_email('example@123gmail.com')==False
  assert is_email('example.domain.com')==False
  assert is_email('example123@domain.com')==True
  assert is_email('example@domain.om')==False
  assert is_email('example@domain.com@domain.com')==False
  assert is_email('example@domain.com.')==False

# Generated at 2022-06-12 07:16:11.837638
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('myemail@the-provider.com') == True
    assert is_email('my_e-mail@prov.com') == True
    assert is_email('my@e-mail@@prov.com') == False
    assert is_email('my.@e-mail@prov.com') == False
    assert is_email('.my.@e-mail@prov.com') == False
    assert is_email('my.email@e-mail.prov.com') == True
    assert is_email('.my.email@e-mail.prov.com') == False
    assert is_email('my..email@e-mail.prov.com') == False

# Generated at 2022-06-12 07:16:22.115599
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4("127.0.0.1")
    assert is_ip_v4("255.255.255.255")
    assert not is_ip_v4("127.0.0.256")
    assert not is_ip_v4("127.0.0.0.1")
    assert not is_ip_v4("2001:db8:85a3:8d3:1319:8a2e:370:7348")
    assert not is_ip_v4("2001:db8:85a3:8d3:1319:8a2e:370:7348/64")
    assert not is_ip_v4("foo")
    assert not is_ip_v4("127.0.0.0/24")

# Generated at 2022-06-12 07:16:23.788883
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') # returns true
    assert is_email('@gmail.com') # returns false



# Generated at 2022-06-12 07:16:34.505214
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.255.255.255') == True
    assert is_ip_v4('255.255.255.256') == False
    assert is_ip_v4('255.255.255') == False
    assert is_ip_v4('256.255.255.255') == False
    assert is_ip_v4('255.255.255.25') == True
    assert is_ip_v4('25.255.255.25') == True
    assert is_ip_v4('25.255.255.255') == True
    assert is_ip_v4('25.255.25.255') == True
    assert is_ip_v4('25.25.255.255') == True
    assert is_ip_v4('25.25.25.255') == True
   

# Generated at 2022-06-12 07:16:37.948926
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') # returns true
    assert is_ip_v4('nope') == False # returns false (not an ip)
    assert is_ip_v4('255.200.100.999') == False # returns false (999 is out of range)


# Generated at 2022-06-12 07:16:44.896829
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert not is_email('@gmail.com')
    assert not is_email(' hello.world@gmail.com')
    assert is_email('hello.world@gmail.com')
    assert is_email('hello.world@gmail.com')
    assert is_email('hello.world-at-gmail.com')
    assert is_email('hello.world@gmail.com')
    assert is_email('hello.world@gmail.com')
    assert is_email('hello.world@gmail.com')
    assert is_email('hello.world@gmail.com')
    assert is_email('hello.world@gmail.com')
    assert is_email('.hello.world@gmail.com')

# Generated at 2022-06-12 07:16:52.914098
# Unit test for function is_ip_v4
def test_is_ip_v4():
    print(is_ip_v4('10.0.0.255')) # True
    print(is_ip_v4('255.200.100.75')) # True
    print(is_ip_v4('nope')) # False (not an ip)
    print(is_ip_v4('255.200.100.999')) # False (999 is out of range)
    print(is_ip_v4('10.0.256.255')) # False (256 is out of range)
test_is_ip_v4()


# Generated at 2022-06-12 07:16:57.600733
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0596527500').is_isbn_10() == True
    assert __ISBNChecker('596527500').is_isbn_10() == True
    assert __ISBNChecker('596527500X').is_isbn_10() == False


# TESTING



# Generated at 2022-06-12 07:17:13.056071
# Unit test for function is_ip_v4
def test_is_ip_v4():
    """
    Functionality test for function is_ip_v4.
    :return: True is function is working.
    """
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False
    return True




# Generated at 2022-06-12 07:17:20.965052
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    checker = __ISBNChecker('0306406152')
    assert checker.is_isbn_10() == True
    checker = __ISBNChecker('0306406156')
    assert checker.is_isbn_10() == False
    checker = __ISBNChecker('030640615X')
    assert checker.is_isbn_10() == False
    checker = __ISBNChecker('030640615x')
    assert checker.is_isbn_10() == False



# Generated at 2022-06-12 07:17:24.405815
# Unit test for function is_email
def test_is_email():
    # Test for the case where the string is not a valid email
    assert is_email('@gmail.com') == False

    # Test for the case where the string is a valid email
    assert is_email('"' + 'my.email@the-provider.com' + '"') == True

# Test function
test_is_email()



# Generated at 2022-06-12 07:17:28.957251
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0306406152').is_isbn_10() is True
    assert __ISBNChecker('0-306-40615-2').is_isbn_10() is True
    assert __ISBNChecker('080442957X').is_isbn_10() is True
    assert __ISBNChecker('0-8044-2957-X').is_isbn_10() is True
    assert __ISBNChecker('0306406151').is_isbn_10() is False


# PUBLIC API



# Generated at 2022-06-12 07:17:39.758582
# Unit test for function is_json
def test_is_json():
    assert(is_json('[]') == True)
    assert(is_json('{}') == True)
    assert(is_json('{"name": "Peter"}') == True)
    assert(is_json('[1, 2, 3]') == True)
    assert(is_json('{"name": "Peter", "age": 42}') == True)
    assert(is_json("{'name': 'Peter', 'age': 42}") == True)
    assert(is_json('{"name": "Peter", "age": "42"}') == True)
    assert(is_json("{'name': 'Peter', 'age': '42'}") == True)
    assert(is_json("a string") == False)
    assert(is_json("12.34") == False)

# Generated at 2022-06-12 07:17:42.913594
# Unit test for function is_json
def test_is_json():
    assert is_json('{"a":1}') == True
    assert is_json(b'{"a":1}') == False



# Generated at 2022-06-12 07:17:46.023410
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999')


# Generated at 2022-06-12 07:17:51.874933
# Unit test for function is_ip_v4
def test_is_ip_v4():
    print(is_ip_v4('255.200.100.75'))
    print(is_ip_v4('nope'))
    print(is_ip_v4('255.200.100.999'))

# Test call
test_is_ip_v4()


# Generated at 2022-06-12 07:18:04.225714
# Unit test for function is_email
def test_is_email():
    assert is_email('john.doe@example.com') == True
    assert is_email('john.doe+spam@example.com') == True
    assert is_email('john@example.com') == True
    assert is_email('johndo@example.com') == True
    assert is_email('johndoe@example.com') == True
    assert is_email('johndoel@example.com') == True
    assert is_email('johndoe@example.test') == True
    assert is_email('john.doe@example-test.com') == True
    assert is_email('john.doe@example.test.com') == True
    assert is_email('john.doe+spam@example-test.com') == True

# Generated at 2022-06-12 07:18:05.180289
# Unit test for function is_email
def test_is_email():
    assert is_email(email)



# Generated at 2022-06-12 07:18:25.843747
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    is_isbn_13_good_inputs = [
        '9791158390067',
        '978-3-16-148410-0',
        '978-616-39-0056-4',
        '978-616-39-0056-4',
        '978-616-39-006-4',
    ]

    is_isbn_13_bad_inputs = [
        '9791158390061',
        '979-115839006-1',
        '978-3-16-148410-2',
        '978-616-39-0056-3',
        '978-616-39-0055-4',
    ]


# Generated at 2022-06-12 07:18:32.214747
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') # returns true
    assert is_ip_v4('nope') == False # returns false (not an ip)
    assert is_ip_v4('255.200.100.999') == False # returns false (999 is out of range)

test_is_ip_v4()



# Generated at 2022-06-12 07:18:37.146166
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert not is_ip_v4(None)
    assert is_ip_v4('255.200.100.75')
    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999')
    assert is_ip_v4('0.0.0.0')
    assert is_ip_v4('255.255.255.255')
test_is_ip_v4()


# Generated at 2022-06-12 07:18:44.454955
# Unit test for function is_json
def test_is_json():
    test_string1 = '{"name": "Peter"}'
    test_string2 = '[1, 2, 3]'
    test_string3 = '{nope}'
    test_string4 = ''

    assert is_json(test_string1) == True
    assert is_json(test_string2) == True
    assert is_json(test_string3) == False
    assert is_json(test_string4) == False

    return "test_is_json OK"


# Generated at 2022-06-12 07:18:55.383704
# Unit test for function is_email
def test_is_email():
    assert is_email("me@gmail.com") is True
    assert is_email("me.email@the-provider.com") is True
    assert is_email("me_email@the-provider.com") is True
    assert is_email("me-email@the-provider.com") is True
    assert is_email("me.e-mail@the-provider.com") is True
    assert is_email("me@the-provider.com") is True
    assert is_email("me@the-provider.com") is True
    assert is_email("me@the-provider.co.uk") is True
    assert is_email("me@the-provider.net") is True
    assert is_email("me@the-provider.org") is True

# Generated at 2022-06-12 07:19:04.571080
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    print('Running test___ISBNChecker_is_isbn_13...', end=' ')

    assert __ISBNChecker('978-0-306-40615-7').is_isbn_13() == True
    assert __ISBNChecker('978-0-306-40615-6').is_isbn_13() == False
    assert __ISBNChecker('123-4-56-789012-3').is_isbn_13() == True
    assert __ISBNChecker('123-4-56-789012-2').is_isbn_13() == False
    assert __ISBNChecker('123-4-56-789012-1').is_isbn_13() == False
    assert __ISBNChecker('978-0-306-40615-p').is_isbn_13() == False
   

# Generated at 2022-06-12 07:19:06.938737
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    tester = __ISBNChecker('8122784007')
    assert tester.is_isbn_10() is True


# Generated at 2022-06-12 07:19:10.398356
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}')
    assert is_json('[1, 2, 3]')
    assert not is_json('{nope}')
    assert not is_json([1, 2, 3])



# Generated at 2022-06-12 07:19:13.099698
# Unit test for function is_email
def test_is_email():
    assert(is_email("my.email@the-provider.com") == True)
    assert(is_email("@gmail.com") == False)

# Function for checking credit card numbers

# Generated at 2022-06-12 07:19:17.373327
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}')
    assert is_json('[1, 2, 3]')
    assert not is_json('{nope}')



# Generated at 2022-06-12 07:19:44.480467
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    checker = __ISBNChecker('978-8365088484')
    assert checker.is_isbn_13() == True
    checker = __ISBNChecker('9788365088484')
    assert checker.is_isbn_13() == True
    checker = __ISBNChecker('8365088487')
    assert checker.is_isbn_13() == False



# Generated at 2022-06-12 07:19:53.254637
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0123456789').is_isbn_10() is True
    assert __ISBNChecker('012345678X').is_isbn_10() is True

    assert __ISBNChecker('012345678').is_isbn_10() is False
    assert __ISBNChecker('0').is_isbn_10() is False
    assert __ISBNChecker('0X').is_isbn_10() is False
    assert __ISBNChecker('0').is_isbn_10() is False
    assert __ISBNChecker('0').is_isbn_10() is False
    assert __ISBNChecker('0').is_isbn_10() is False


# PUBLIC API



# Generated at 2022-06-12 07:20:01.997945
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('99921-58-10-7').is_isbn_10() is True
    assert __ISBNChecker('9971-5-0210-0').is_isbn_10() is True
    assert __ISBNChecker('960-425-059-0').is_isbn_10() is True
    assert __ISBNChecker('80-902734-1-6').is_isbn_10() is True
    assert __ISBNChecker('85-359-0277-5').is_isbn_10() is True
    assert __ISBNChecker('1-84356-028-3').is_isbn_10() is True
    assert __ISBNChecker('0-684-84328-5').is_isbn_10() is True

# Generated at 2022-06-12 07:20:08.273647
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('0-9767139-1-1').is_isbn_13()
    assert __ISBNChecker('9780976713912').is_isbn_13()
    assert not __ISBNChecker('9780976713915').is_isbn_13()
    assert not __ISBNChecker('0-9767139-1-2').is_isbn_13()
    assert not __ISBNChecker('0-9767139-1-Z').is_isbn_13()

# Generated at 2022-06-12 07:20:12.784342
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') is True
    assert is_json('{"name": "Peter", "age":24}') is True
    assert is_json('[1,2,3,4]') is True
    assert is_json('{"nope}') is False
    assert is_json('{"nope}') is False



# Generated at 2022-06-12 07:20:22.076229
# Unit test for function is_email
def test_is_email():
    assert is_email('a@b.com') == True
    assert is_email('a@b.com') == True
    assert is_email('a@b.com') == True
    assert is_email('name@gmail.com') == True
    assert is_email('"is not"@gmail.com') == False
    assert is_email('"is not"@gmail') == True
    assert is_email('is not"@gmail.com') == False
    assert is_email('is not@@gmail.com') == False
    assert is_email('is not@gmail.com') == True
    assert is_email('is not"@gmail.com') == False
    assert is_email('is not"@gmail.com') == False
    assert is_email('is not"@gmail.com') == False
    assert is_email

# Generated at 2022-06-12 07:20:34.585526
# Unit test for function is_json
def test_is_json():
    #testcase -1-
    try:
        assert is_json(None) != True, 'testcase-1-1 failed!'
        assert is_json(0) != True, 'testcase-1-2 failed!'
    except:
        print('testcase-1-3 failed!')
    try:
        assert is_json('{}') != True, 'testcase-1-4 failed!'
        assert is_json('[]') != True, 'testcase-1-5 failed!'
    except:
        print('testcase-1-6 failed!')

# Generated at 2022-06-12 07:20:36.564512
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    checker = __ISBNChecker('0471958697')
    assert checker.is_isbn_10()


# PUBLIC API



# Generated at 2022-06-12 07:20:46.109645
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0306406152').is_isbn_10() == True
    assert __ISBNChecker('0306406746').is_isbn_10() == True
    assert __ISBNChecker('0306404486').is_isbn_10() == True
    assert __ISBNChecker('0306404494').is_isbn_10() == True
    assert __ISBNChecker('0262181829').is_isbn_10() == True
    assert __ISBNChecker('0262181845').is_isbn_10() == True
    assert __ISBNChecker('0201610090').is_isbn_10() == True
    assert __ISBNChecker('0201610124').is_isbn_10() == True

# Generated at 2022-06-12 07:20:57.231363
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    checker = __ISBNChecker('978014017739')
    assert checker.is_isbn_10() == False

    checker = __ISBNChecker('0307276399')
    assert checker.is_isbn_10() == True

    checker = __ISBNChecker('0307276399-')
    assert checker.is_isbn_10() == True

    checker = __ISBNChecker('0307276399-1')
    assert checker.is_isbn_10() == False

    checker = __ISBNChecker('0307276399-10')
    assert checker.is_isbn_10() == False

test___ISBNChecker_is_isbn_10()

# Generated at 2022-06-12 07:21:45.426445
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False

# uncomment to run the above test
# test_is_ip_v4()


# Generated at 2022-06-12 07:21:52.392082
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0-306-40615-2').is_isbn_10() == True, 'ISBN-10 Test 1'
    assert __ISBNChecker('0306406152').is_isbn_10() == True, 'ISBN-10 Test 2'
    assert __ISBNChecker('0-306-40615-1').is_isbn_10() == False, 'ISBN-10 Test 3'
    assert __ISBNChecker('0306406150').is_isbn_10() == False, 'ISBN-10 Test 4'


# PUBLIC API



# Generated at 2022-06-12 07:21:55.320749
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False



# Generated at 2022-06-12 07:22:06.349176
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert(is_ip_v4('0.0.0.0'))
    assert(not is_ip_v4('0.0.0'))
    assert(not is_ip_v4('0.0.-1.0'))
    assert(not is_ip_v4('0.0.256.0'))
    assert(not is_ip_v4('0.0.0. 256'))
    assert(not is_ip_v4(' 0.0.0.0'))
    assert(not is_ip_v4('0.0.0.0 '))
    assert(is_ip_v4('0.0.0.0'))
    assert(is_ip_v4('127.0.0.1'))