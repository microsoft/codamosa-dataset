

# Generated at 2022-06-12 07:12:37.982126
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('3530111333300000') == True
    assert is_credit_card('1234567890') == False
    assert is_credit_card('3530111333300000',card_type='VISA') == True
    assert is_credit_card('3530111333300000',card_type='MASTERCARD') == False
    assert is_credit_card('3530111333300000',card_type='UNKNOWN') == False


# Generated at 2022-06-12 07:12:43.082185
# Unit test for function is_url
def test_is_url():
    assert is_url("http://www.google.com") == True
    assert is_url("https://www.google.com") == True
    assert is_url("http://google.com") == True
    assert is_url("https://google.com") == True
    assert is_url("google.com") == True
    assert is_url("/path/to/file") == False
test_is_url()
    

# Generated at 2022-06-12 07:12:53.880331
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4("12.127.0.1")
    assert is_ip_v4("0.0.0.0")
    assert is_ip_v4("255.255.255.255")
    assert not is_ip_v4("hello")
    assert not is_ip_v4("256.0.0.0")
    assert not is_ip_v4("99.256.0.0")
    assert not is_ip_v4("99.99.9999.0")
    assert not is_ip_v4("hello.0.0.0")
    assert not is_ip_v4("hello.hello.hello.hello")



# Generated at 2022-06-12 07:12:58.577724
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    ISBNChecker = __ISBNChecker("1209-1-23h-0-0")
    # ISBNChecker = __ISBNChecker("1209-1-23h-0-0", False)
    assert ISBNChecker.is_isbn_10()

# Generated at 2022-06-12 07:13:03.151168
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('1234567890').is_isbn_10() == True
    assert __ISBNChecker('1234567892').is_isbn_10() == True
    assert __ISBNChecker('1234567891').is_isbn_10() == False

# Generated at 2022-06-12 07:13:08.946303
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False
test_is_ip_v4()



# Generated at 2022-06-12 07:13:20.396257
# Unit test for method is_isbn_13 of class __ISBNChecker

# Generated at 2022-06-12 07:13:31.136681
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert not is_ip_v4('nope')  # not an ip
    assert not is_ip_v4('255.200.100.999')  # 999 is out of range
    assert not is_ip_v4('255.200.100')  # not enough parts
    assert not is_ip_v4('256.200.100.75')  # 256 is out of range

    assert is_ip_v4('255.200.100.75')  # valid ip
    assert is_ip_v4(None) is False  # passing a None will return False
    assert is_ip_v4('') is False  # an empty string is not an ip
    assert is_ip_v4('      ') is False  # a string composed by spaces is not a valid ip

# Generated at 2022-06-12 07:13:37.093722
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75') # returns true
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') # returns true
    assert is_ip('1.2.3') # returns false
    
test_is_ip()


# Generated at 2022-06-12 07:13:48.592205
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('1.2.3.4') is True
    assert is_ip_v4('200.100.75.0') is True
    assert is_ip_v4('123.123.123.123') is True
    assert is_ip_v4('255.255.255.255') is True
    assert is_ip_v4('0.0.0.0') is True
    assert is_ip_v4('255.255.255.256') is False
    assert is_ip_v4('255.255.255.') is False
    assert is_ip_v4('255.255.255') is False
    assert is_ip_v4('255.255.2551') is False
    assert is_ip_v4('255.255.2551.13') is False

# Generated at 2022-06-12 07:13:57.798959
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('joe.bloggs@domain.co.uk') == True
    assert is_email('"blah blah blah"@my.domain.com') == True



# Generated at 2022-06-12 07:14:00.843007
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0-684-84328-5').is_isbn_10() is True
    assert __ISBNChecker('0-684-84328-0').is_isbn_10() is False
    assert __ISBNChecker('0-684-84328-s').is_isbn_10() is False



# Generated at 2022-06-12 07:14:13.433763
# Unit test for function is_email
def test_is_email():
    assert not is_email(None)
    assert not is_email('')
    assert not is_email(' ')
    assert not is_email('a')
    assert not is_email('.text@text.text')
    assert not is_email('tex@.text.text')
    assert not is_email('tex@text..text')
    assert is_email('text@text.text')
    assert is_email('text@text.text.text')
    assert is_email('tex@text.text.text')
    assert is_email('tex@text.text.text.text')
    assert is_email('"First Last"@text.text')
    assert is_email('"First.Last"@text.text')
    assert is_email('"First Last"@text')

# Generated at 2022-06-12 07:14:20.269486
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') and is_isbn_13('9780312498580') and not is_isbn_10('9780312498580')
    assert not is_isbn('9780312498580', normalize=False)
    assert is_isbn('1506715214') and is_isbn_10('1506715214') and not is_isbn_13('1506715214')
    assert not is_isbn('1506715214') and not is_isbn_10('1506715214') and not is_isbn_13('1506715214')
    assert is_isbn('9780312498580') and is_isbn_13('9780312498580') and not is_isbn_10('9780312498580')
    assert is_

# Generated at 2022-06-12 07:14:30.630382
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('127.0.0.1') is True
    assert is_ip_v4('200.100.50.1') is True
    assert is_ip_v4('255.255.255.255') is True
    assert is_ip_v4('127.0.0.x') is False
    assert is_ip_v4('256.255.255.255') is False
    assert is_ip_v4('127.0.0.') is False
    assert is_ip_v4('') is False
    assert is_ip_v4('nope') is False
    assert is_ip_v4(None) is False

# Generated at 2022-06-12 07:14:36.287582
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('0.0.0.0') == True
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('999.200.100.75') == False
    assert is_ip_v4('255.200.100.999') == False



# Generated at 2022-06-12 07:14:40.277896
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False
    assert is_ip_v4('not-an-ip') == False



# Generated at 2022-06-12 07:14:48.217447
# Unit test for function is_email
def test_is_email():
    assert is_email('foo@bar.com') == True
    assert is_email('foo@gmail.com') == True
    assert is_email('foo@yahoo.com') == True
    assert is_email('foo@somewhere.com') == True
    assert is_email('foo@hotmail.com') == True
    assert is_email('foo@mail.com') == True
    assert is_email('foo@outlook.com') == True
    assert is_email('foo@icloud.com') == True
    assert is_email('foo@aol.com') == True
    assert is_email('foo@github.com') == True
    assert is_email('foo@zoho.com') == True
    assert is_email('foo@gmx.com') == True

# Generated at 2022-06-12 07:14:55.049369
# Unit test for function is_email
def test_is_email():
    assert(is_email('my.email_12@the-provider.com') == True)
    assert(is_email('my.email_12@the-provider.com') != False)
    assert(is_email('my.email@the-provider.com') == True)
    assert(is_email('my.email@the-provider.com') != False)
    assert(is_email('my.emai@the-provider.com') == True)
    assert(is_email('my.emai@the-provider.com') != False)
    assert(is_email('my.emai@the-provide.com') == True)
    assert(is_email('my.emai@the-provide.com') != False)

# Generated at 2022-06-12 07:15:08.042840
# Unit test for function is_email
def test_is_email():
    assert is_email("john.doe@example.com")
    assert is_email("john.doe@example.co.uk")
    assert is_email("john@1local-address.com")
    assert is_email("john.doe@ipv4.example.com")
    assert is_email("john.doe@ipv6.example.com")
    assert is_email("john.doe@ipv6-literal.example.com")
    assert is_email("john.doe@ipv6-literal.example.com")
    assert is_email("john.doe@a.com")
    assert is_email("john.doe@[1.1.1.1]")

# Generated at 2022-06-12 07:15:17.943759
# Unit test for function is_json
def test_is_json():
    assert is_json('ciao') is False
    assert is_json('') is False
    assert is_json('{"name": "Peter"}') is True
    assert is_json('[]') is True
    assert is_json('{nope}') is False



# Generated at 2022-06-12 07:15:29.531542
# Unit test for function is_email
def test_is_email():
    assert is_email('email@gmail.com') == True
    assert is_email('s.s@wipro.com') == True
    assert is_email('.s.s@wipro.com') == False
    assert is_email('s..s@wipro.com') == False
    assert is_email('s(s@wipro.com') == True
    assert is_email('s.s@wipro.co.in') == True
    assert is_email('s.s@wipro.ac') == True
    assert is_email('s.s@wipro.co') == True
    assert is_email('s.s@wipro.com.com') == False
    assert is_email('s.s@wipro..com') == False

# Generated at 2022-06-12 07:15:34.157276
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    data = [
        '0306406152', # valid ISBN-10
        '966-630-895-8', # valid ISBN-13
    ]

    for isbn in data:
        assert __ISBNChecker(isbn).is_isbn_10() == True
# Test for method is_isbn_10
test___ISBNChecker_is_isbn_10()



# Generated at 2022-06-12 07:15:38.646996
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999')

# Generated at 2022-06-12 07:15:45.911264
# Unit test for function is_email
def test_is_email():
   assert not is_email('@gmail.com'), 'Email cannot start with \'@\''
   assert not is_email('foo.<bar@gmail.com'), 'Email cannot contain \'<\''
   assert not is_email('foo>bar@gmail.com'), 'Email cannot contain \'>\''
   assert not is_email('foo#bar@gmail.com'), 'Email cannot contain \'#\''
   assert is_email('foo@gmail.com'), 'Should be a valid email'
   assert is_email('foo<bar@gmail.com'), 'Email can contain \'<\' if escaped'


# Generated at 2022-06-12 07:15:52.850911
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    checker = __ISBNChecker(input_string='978-0-306-40615-7')
    assert checker.is_isbn_13()

    checker = __ISBNChecker(input_string='0-306-40615-2')
    assert checker.is_isbn_13() is False

    checker = __ISBNChecker(input_string='0-306-40615-1')
    assert checker.is_isbn_13() is False

# Generated at 2022-06-12 07:15:55.647409
# Unit test for function is_json
def test_is_json():
    asserts = [
        ('{"name": "Peter"}', True),
        ('[1, 2, 3]', True),
        ('{nope}', False),
    ]

    print('Testing function is_json')
    for t in asserts:
        print(t)
        assert is_json(t[0]) == t[1]



# Generated at 2022-06-12 07:15:58.806563
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-12 07:16:10.402837
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('1.1.1.1')  # simple ip
    assert is_ip_v4('255.255.255.255')  # max ip
    assert is_ip_v4('0.0.0.0')  # min ip
    assert is_ip_v4('255.1.1.1')  # numbers between 1 and 254
    assert not is_ip_v4('')  # empty string
    assert not is_ip_v4('a.a.a.a')  # letters instead of numbers
    assert not is_ip_v4('1.1.1')  # one number missing
    assert not is_ip_v4('0.0.0.256')  # number out of range
    assert not is_ip_v4('999.999.999.999') 

# Generated at 2022-06-12 07:16:14.914760
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999')

    assert is_ip_v4('0.0.0.0')
    assert is_ip_v4('255.255.255.255')



# Generated at 2022-06-12 07:16:25.419373
# Unit test for function is_json
def test_is_json():
    assert is_json('{}')
    assert not is_json('{1}')

test_is_json()



# Generated at 2022-06-12 07:16:31.262046
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('1234567890').is_isbn_10() == True
    assert __ISBNChecker('123456789').is_isbn_10() == False
    assert __ISBNChecker('12345678901').is_isbn_10() == False
    assert __ISBNChecker('a234567890').is_isbn_10() == False

# Generated at 2022-06-12 07:16:39.556994
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}')
    assert is_json('[1, 2, 3]')
    assert is_json('[]')
    assert is_json('{}')
    assert not is_json('-123')
    assert is_json('{"name": "Peter", "age": 42}')
    assert is_json('{"name": "Peter", "age": 42, "tags": ["lorem", "ipsum"]}')
    assert is_json('{"name": "Peter", "age": 42, "tags": ["lorem", "ipsum"], "pi": 3.14}')
    assert is_json('[1, 2, 3]')
    assert is_json('["lorem", "ipsum", "dolor"]')

# Generated at 2022-06-12 07:16:46.711695
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True

# Generated at 2022-06-12 07:16:49.627722
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('1234567890123').is_isbn_13()
    assert not __ISBNChecker('123456789012345').is_isbn_13()



# Generated at 2022-06-12 07:16:52.781472
# Unit test for function is_email
def test_is_email():
    assert is_email('test@test.com')
    assert not is_email('test@test.')
    assert not is_email('testtest.com')
    assert not is_email('')



# Generated at 2022-06-12 07:16:55.358525
# Unit test for function is_ip_v4
def test_is_ip_v4():
  return is_ip_v4("255.200.100.75")

print(test_is_ip_v4())



# Generated at 2022-06-12 07:16:59.083437
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    # Test valid ISBN 10
    assert __ISBNChecker('0-7475-3269-9').is_isbn_10()

    # Test invalid ISBN 10
    assert not __ISBNChecker('0-7475-3269-8').is_isbn_10()

# Generated at 2022-06-12 07:17:06.830104
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    obj = __ISBNChecker(input_string='0306406152')
    assert obj.is_isbn_10() == True
    obj = __ISBNChecker(input_string='0306406156')
    assert obj.is_isbn_10() == False
    obj = __ISBNChecker(input_string='030640615')
    assert obj.is_isbn_10() == False
    obj = __ISBNChecker(input_string='03064061521')
    assert obj.is_isbn_10() == False
    obj = __ISBNChecker(input_string='0306406a5')
    assert obj.is_isbn_10() == False

# Generated at 2022-06-12 07:17:15.325935
# Unit test for function is_email
def test_is_email():
    assert is_email(None) == False
    assert is_email('') == False
    assert is_email(' ') == False
    assert is_email('email') == False
    assert is_email('email@provider') == False
    assert is_email('email@provider.') == False
    assert is_email('email@provider..com') == False
    assert is_email('email@provider.com') == True
    assert is_email('email.name@provider.com') == True
    assert is_email('"My Name" <email@provider.com>') == True
    assert is_email('<a href="mailto:email@provider.com" rel="nofollow">email</a>') == True
    assert is_email('email+tag@provider.com') == True

# Generated at 2022-06-12 07:17:28.014037
# Unit test for function is_email
def test_is_email():
    assert is_email("abcd@yaas.com")
    assert is_email("email@domain.com")
    assert is_email("firstname.lastname@domain.com")
    assert is_email("email@subdomain.domain.com")
    assert is_email("firstname+lastname@domain.com")
    assert is_email("email@123.123.123.123")
    assert is_email("email@[123.123.123.123]")
    assert is_email("\"email\"@domain.com")
    assert is_email("1234567890@domain.com")
    assert is_email("email@domain-one.com")
    assert is_email("_______@domain.com")
    assert is_email("email@domain.name")

# Generated at 2022-06-12 07:17:39.125144
# Unit test for function is_email
def test_is_email():
    assert is_email('fbar@baz.com')
    assert is_email('foo@bar.baz.fr')
    assert is_email('foo123@baz.com')
    assert is_email('foo_bar@baz.com')
    assert is_email('foo+bar@gmail.com')
    assert is_email('"foo\ bar"@baz.com')
    assert is_email("\"foo\\ bar\"@baz.com")
    assert is_email("\"foo\\@bar\"@baz.com")
    assert is_email("foo.bar@baz.com")
    assert is_email("foo.bar.baz@baz.com")
    assert is_email("foo..bar@baz.com")

# Generated at 2022-06-12 07:17:45.513382
# Unit test for function is_json
def test_is_json():
    assert is_json(input_string='{"name": "Peter"}') == True
    assert is_json(input_string='[1, 2, 3]') == True
    assert is_json(input_string='{"nope"}') == False
    assert is_json(input_string='{nope}') == False

test_is_json()

# Generated at 2022-06-12 07:17:56.732896
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') is True
    assert is_email('my.email.the-provider.com') is False
    assert is_email('@gmail.com') is False
    assert is_email('my.email@gmail.com') is True
    assert is_email('my.email@the-provider.com.uk') is True
    assert is_email('my.email+filter@the-provider.com') is True
    assert is_email('my.email@the-provider.com ') is False
    assert is_email('my .email@the-provider.com') is True
    assert is_email('my.email@the-provider.com.') is False
    assert is_email('my.email1@the-provider.com') is True
   

# Generated at 2022-06-12 07:18:02.285539
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert (is_ip_v4('255.200.100.75') is True)
    assert (is_ip_v4('nope') is False)
    assert (is_ip_v4('255.200.100.999') is False)
    
if __name__ == '__main__':
    test_is_ip_v4()

# Generated at 2022-06-12 07:18:04.399166
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False

# Generated at 2022-06-12 07:18:08.168506
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False

# Generated at 2022-06-12 07:18:15.418465
# Unit test for function is_json
def test_is_json():
    s = '{"a": 1, "b": 2}'
    assert is_json(s) == True
    s = '{"a": 1, "b": 2}'
    assert is_json(s) == True
    s = '["a": 1, "b": 2]'
    assert is_json(s) == False
    s = 'abc'
    assert is_json(s) == False
    s = '{"a": "1", "b": "2"}'
    assert is_json(s) == True
    s = '["a", "b", "c"]'
    assert is_json(s) == True


# Generated at 2022-06-12 07:18:25.449382
# Unit test for function is_email
def test_is_email():
    assert is_email(None) == False
    assert is_email('') == False
    assert is_email('.mysite.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('"firstname.lastname"@the-provider.com') == True
    assert is_email("\"firstname.lastname@the-provider.com\"@the-provider.com") == True
    assert is_email("firstname.lastname\"@the-provider.com") == True

# Generated at 2022-06-12 07:18:29.426921
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False



# Generated at 2022-06-12 07:18:42.690444
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') is True
    assert is_json('[1, 2, 3]') is True
    assert is_json('[1, 2, 3]') is True
    assert is_json('[]') is True
    assert is_json('{nope}') is False
    assert is_json('1.') is False
    assert is_json('[') is False
    assert is_json('{') is False


# Generated at 2022-06-12 07:18:53.306805
# Unit test for function is_email
def test_is_email():
    assert is_email('foo@bar.com') == True
    assert is_email('x@x.au') == True
    assert is_email('foo@bar.com.au') == True
    assert is_email('foo+bar@bar.com') == True
    assert is_email('foo@bar.coffee') == True
    assert is_email('foo@bar.coffee.') == False
    assert is_email('foo@bar.c') == False
    assert is_email('foo@bar') == False
    assert is_email('foo') == False
    assert is_email('@bar.com') == False
    assert is_email('foo@') == False
    assert is_email('foo@bar') == False
    assert is_email('foo@bar.') == False

# Generated at 2022-06-12 07:19:03.340251
# Unit test for function is_json
def test_is_json():
    assert is_json('{}')==True
    assert is_json('{"key":"value"}')==True
    assert is_json('{"key": {}}') ==True
    assert is_json('{"key": {"key2":"value2"}}')==True
    assert is_json('{1}')==False
    assert is_json('{key:"value"}')==False
    assert is_json('{{key:"value"}}')==False
    assert is_json('{"key,":"value"}')==False
    assert is_json('["key","value"]')==True
    assert is_json('["key"]')==True
    assert is_json('["key","value",{"key2":"value2"}]')==True
    assert is_json('[1,2,3]')==True

# Generated at 2022-06-12 07:19:10.128677
# Unit test for function is_email
def test_is_email():
    assert is_email('alizain@umich.edu') == True
    assert is_email('foo.bar@example.org') == True
    assert is_email('foo@example.com') == True
    assert is_email('foo@example.co.jp') == True
    assert is_email('foo@example') == False
    assert is_email('foo.bar@com') == False
    assert is_email('foo.bar@gmail.com') == True
    assert is_email('') == False
    assert is_email(' ') == False


# Credit card example:

# Generated at 2022-06-12 07:19:17.282312
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert not __ISBNChecker('0').is_isbn_13()
    assert __ISBNChecker('9780470059029').is_isbn_13()
    assert not __ISBNChecker('9780470059028').is_isbn_13()
    assert not __ISBNChecker('9780470059028', normalize=False).is_isbn_13()


# Generated at 2022-06-12 07:19:20.254426
# Unit test for function is_json
def test_is_json():
    for input_string in ['{"name": "Peter"}', '[1, 2, 3]', '{nope}']:
        print(is_json(input_string))
        print(is_json)



# Generated at 2022-06-12 07:19:23.763636
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')

    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999')
    assert not is_ip_v4('255.200.100.75.80')


# Generated at 2022-06-12 07:19:35.304966
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False
    assert is_json('{"k1": "v1", "k2": "v2"}') == True
    assert is_json('{"k1": "v1", "k2": "v2", "k3": {"k3_1": "v3_1"}}') == True
    assert is_json('{"k1": ["v1_1", "v1_2", "v1_3"], "k2": "v2"}') == True
    assert is_json('["v1_1", "v1_2", "v1_3"]') == True

# Generated at 2022-06-12 07:19:43.367023
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    print(__ISBNChecker('3830338499').is_isbn_10() == True)
    print(__ISBNChecker('0307166106').is_isbn_10() == False)
    print(__ISBNChecker('030716610K').is_isbn_10() == False)
    print(__ISBNChecker('030716610X').is_isbn_10() == True)
    print(__ISBNChecker('030716610x').is_isbn_10() == True)
    print(__ISBNChecker('0307166106 ').is_isbn_10() == True)
    print(__ISBNChecker('  3830338499').is_isbn_10() == True)

# Generated at 2022-06-12 07:19:53.021890
# Unit test for function is_email
def test_is_email():
    assert is_email('email@domain.com') is True
    assert is_email('firstname.lastname@domain.com') is True
    assert is_email('email@subdomain.domain.com') is True
    assert is_email('firstname+lastname@domain.com') is True
    assert is_email('email@123.123.123.123') is True
    assert is_email('email@[123.123.123.123]') is True
    assert is_email('"email"@domain.com') is True
    assert is_email('1234567890@domain.com') is True
    assert is_email('email@domain-one.com') is True
    assert is_email('_______@domain.com') is True
    assert is_email('email@domain.name') is True

# Generated at 2022-06-12 07:20:13.632063
# Unit test for function is_email
def test_is_email():
    assert(is_email("nom@gmail.com") == True)
    assert(is_email("nom@esp.ce") == True)
    assert(is_email("a@a") == True)
    assert(is_email("pépé@a") == True)
    assert(is_email("pépé@e.e") == True)
    assert(is_email("1234567890123456789012345678901234567890123456789012345678901234@a") == True)
    assert(is_email("1234567890123456789012345678901234567890123456789012345678901234@my-domain.com") == True)
    assert(is_email("\"nom\"@esp.ce") == True)

# Generated at 2022-06-12 07:20:20.414786
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email().the-provider.com') == False
    assert is_email('my email@the-provider.com') == False
    assert is_email('my email@the-provider') == False
    assert is_email('my-email@the-provider') == False
    
test_is_email()


# Generated at 2022-06-12 07:20:28.314396
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    valid_isbn_13_1 = __ISBNChecker('978-1783553612')
    assert valid_isbn_13_1.is_isbn_13()

    valid_isbn_13_2 = __ISBNChecker('9781783553612')
    assert valid_isbn_13_2.is_isbn_13()

    invalid_isbn_13 = __ISBNChecker('978-1783553618')
    assert not invalid_isbn_13.is_isbn_13()



# Generated at 2022-06-12 07:20:33.632468
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999')
test_is_ip_v4()



# Generated at 2022-06-12 07:20:36.500030
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') is True
    assert is_json('[1, 2, 3]') is True
    assert is_json('{nope}') is False
    assert is_json('') is False


# Generated at 2022-06-12 07:20:39.276835
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-12 07:20:48.218622
# Unit test for function is_email
def test_is_email():
    assert is_email('test@test.com')
    assert is_email('test@123.123.123.123')
    assert is_email('test@a.b.c.d.e.f.g.h.i.j.k.l.m.n.o.p.q.r.s.t.u.v.w.x.y.z.a.b.c.d.e.f.g.h.i.j.k.l.m.n.o.p.q.r.s.t.u.v.w.x.y.z.a.c')

# Generated at 2022-06-12 07:20:52.645703
# Unit test for function is_email
def test_is_email():
    # assumptions
    assert(not is_email(''))
    assert(not is_email('@'))
    assert(not is_email('test.com'))
    assert(not is_email('test@com'))
    assert(not is_email('test@test.c'))
    assert(not is_email('test@test.co.'))
    assert(not is_email('test@test.com '))
    assert(not is_email('test-@test.com'))
    assert(not is_email('test_@test.com'))
    assert(not is_email('test-_@test.com'))
    assert(not is_email('test+_@test.com'))
    assert(not is_email('test+-@test.com'))

# Generated at 2022-06-12 07:21:00.174831
# Unit test for function is_email
def test_is_email():
    assert is_email('email@domain.com')
    assert is_email('firstname.lastname@domain.com')
    assert is_email('email@subdomain.domain.com')
    assert is_email('firstname+lastname@domain.com')
    assert is_email('1234567890@domain.com')
    assert is_email('email@domain-one.com')
    assert is_email('_______@domain.com')
    assert is_email('email@domain.name')
    assert is_email('email@domain.co.jp')
    assert is_email('firstname-lastname@domain.com')
    assert not is_email(None)
    assert not is_email('')
    assert not is_email('plainaddress')

# Generated at 2022-06-12 07:21:05.930040
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    checker = __ISBNChecker('978-1-86197-876-7', normalize=False)
    assert checker.is_isbn_13() == True

    checker = __ISBNChecker('978-1-86197-876-8', normalize=False)
    assert checker.is_isbn_13() == False


# Generated at 2022-06-12 07:21:27.697158
# Unit test for function is_json
def test_is_json():
	assert is_json(None) == False
	assert is_json(False) == False
	assert is_json(True) == False
	assert is_json(1) == False
	assert is_json(1.0) == False
	assert is_json({}) == False
	assert is_json([]) == False
	assert is_json(dict()) == False
	assert is_json(list()) == False
	assert is_json(set()) == False
	assert is_json('') == False
	assert is_json('""') == False
	assert is_json('{}') == True
	assert is_json('{"foo":"bar"}') == True
	assert is_json('null') == False
	assert is_json(b'{}') == False
	assert is_json({'foo':'bar'}) == False

# Generated at 2022-06-12 07:21:35.899820
# Unit test for function is_email
def test_is_email():
    assert is_email("my.email@a.com") == True
    assert is_email("my.email@a") == False
    assert is_email("my.email@a.com.cn") == True
    assert is_email("my.email@a.c") == False
    assert is_email("my.email@a.a.com") == True
    assert is_email("my.email@") == False
    assert is_email("my.email") == False
    assert is_email("") == False


# Generated at 2022-06-12 07:21:43.164767
# Unit test for function is_email
def test_is_email():
    assert is_email('email@domain.com') == True
    assert is_email('firstname.lastname@domain.com') == True
    assert is_email('email@subdomain.domain.com') == True
    assert is_email('firstname+lastname@domain.com') == True
    assert is_email('email@123.123.123.123') == True
    assert is_email('email@[123.123.123.123]') == True
    assert is_email('"email"@domain.com') == True
    assert is_email('1234567890@domain.com') == True
    assert is_email('email@domain-one.com') == True
    assert is_email('_______@domain.com') == True
    assert is_email('email@domain.name') == True

# Generated at 2022-06-12 07:21:50.299755
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0747532699').is_isbn_10()
    assert __ISBNChecker('0306406152').is_isbn_10()
    assert __ISBNChecker('1400079179').is_isbn_10()
    assert __ISBNChecker('0380795272').is_isbn_10()
    assert __ISBNChecker('1582348254').is_isbn_10()
    assert __ISBNChecker('1853260428').is_isbn_10()
    assert not __ISBNChecker('1853260420').is_isbn_10()
    assert not __ISBNChecker('185326042').is_isbn_10()
    assert not __ISBNChecker('0133687888').is_isbn_10()
    assert not __ISBNCheck

# Generated at 2022-06-12 07:22:00.279794
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():

    assert __ISBNChecker('0201103311').is_isbn_10()
    assert __ISBNChecker('9780470059029').is_isbn_10()
    assert __ISBNChecker('1940111116').is_isbn_10()
    assert __ISBNChecker('159446339X').is_isbn_10()
    assert __ISBNChecker('0789751984').is_isbn_10()
    assert __ISBNChecker('45-61035-2-07').is_isbn_10()
    assert __ISBNChecker('45-61035-2-07', normalize=False).is_isbn_10()

    assert not __ISBNChecker('007-6092019991').is_isbn_10()

# Generated at 2022-06-12 07:22:09.653720
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('9781593275846').is_isbn_10() is False
    assert __ISBNChecker('0-596-52068-9').is_isbn_10()

    assert __ISBNChecker('1593275900').is_isbn_10()
    assert __ISBNChecker('1593275900', False).is_isbn_10()

    assert __ISBNChecker('1-59327-590-0').is_isbn_10() is False
    assert __ISBNChecker('1-59327-590-0', False).is_isbn_10()

    assert __ISBNChecker('0-596-0000-0', False).is_isbn_10() is False