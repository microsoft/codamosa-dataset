

# Generated at 2022-06-12 07:12:45.124708
# Unit test for function is_email
def test_is_email():
    assert(is_email("lilong@gmail.com"))
    assert(is_email("lilong@taobao.com"))
    assert(is_email("lilong@baidu.com"))
    assert(is_email("lilong@qq.com"))
    assert(is_email("lilong@163.com"))
    assert(is_email("lilong@sohu.com"))
    assert(is_email("lilong@sina.com"))
    assert(is_email("lilong@qq.com"))
    assert(is_email("lilong@foxmail.com"))
    assert(is_email("lilong@126.com"))
    assert(is_email("lilong@hotmail.com"))
    assert(is_email("lilong@live.cn"))

# Generated at 2022-06-12 07:12:50.598309
# Unit test for function is_ip_v4
def test_is_ip_v4():
    """
    Tests for function is_ip_v4
    """
    ip_v4_strings = ['255.200.100.75','0.0.0.0','1.2.3.4','192.168.1.1','255.255.255.254']
    ip_v4_zero_strings = ['0.0.0.0']
    ip_v4_255_strings = ['255.255.255.255']

    # ip addresses that should not be accepted
    ip_v4_bad_strings = ['nope','256.0.0.0','255.256.0.0','255.255.256.0','255.255.255.256']


    # check that valid ip v4 addresses are identified correctly
    for ip_v4_string in ip_v4_strings:
        assert is_

# Generated at 2022-06-12 07:13:02.734938
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('9780132910774').is_isbn_13()
    assert not __ISBNChecker('978013291077').is_isbn_13()
    assert not __ISBNChecker('97801329107').is_isbn_13()
    assert not __ISBNChecker('132910774').is_isbn_13()
    assert not __ISBNChecker('97801329107749').is_isbn_13()
    assert not __ISBNChecker('97801329107741').is_isbn_13()
    assert not __ISBNChecker('97801329107748').is_isbn_13()
    assert not __ISBNChecker('9780132910771').is_isbn_13()

# Generated at 2022-06-12 07:13:05.333270
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False

test_is_ip_v4()


# Generated at 2022-06-12 07:13:08.672151
# Unit test for function is_isbn
def test_is_isbn():
    """
    Test for function is_isbn
    """
    assert is_isbn('9780312498580')
    assert is_isbn('1506715214')
    assert not is_isbn('978')


# Generated at 2022-06-12 07:13:16.025658
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('1234567890').is_isbn_10()
    assert not __ISBNChecker('123456789').is_isbn_10()
    assert not __ISBNChecker('1234567890123').is_isbn_10()
    assert not __ISBNChecker('0123456789').is_isbn_10()



# Generated at 2022-06-12 07:13:22.932450
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4("1.2.3.4") == True
    assert is_ip_v4("1.2.3.400") == False
    assert is_ip_v4("1.2.3") == False
    assert is_ip_v4("1.2.3.4.5") == False
    assert is_ip_v4("1.2.3.a") == False


# Generated at 2022-06-12 07:13:32.782107
# Unit test for function is_isbn
def test_is_isbn():
    assert(is_isbn("9780312498580"))
    assert(is_isbn("1506715214"))
    assert(not is_isbn("978-0312498580", normalize=False))
    assert(not is_isbn("150-6715214", normalize=False))
    assert(not is_isbn("-150-6715214", normalize=False))
    assert(not is_isbn("1506715214-"))
    assert(not is_isbn("-1506715214-"))
    assert(not is_isbn("-150-6715214-"))
    assert(not is_isbn("150-6715214-"))
    assert(not is_isbn("a50-6715214-"))
    assert(not is_isbn("a+-6715214-"))

# Generated at 2022-06-12 07:13:39.375391
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('9789866642233').is_isbn_13() == True
    assert __ISBNChecker('9789866642234').is_isbn_13() == False
    assert __ISBNChecker('9789866642235').is_isbn_13() == False


# PUBLIC API

# is_string

# Generated at 2022-06-12 07:13:49.955055
# Unit test for function is_url
def test_is_url():
    assert is_url("https://www.toppr.com/")
    assert is_url("https://www.toppr.com/s?s=javascrip")
    assert is_url("https://www.toppr.com/s?s=javascrip&ref=toppr.com")
    assert is_url("https://www.toppr.com/s?s=javascrip&ref=toppr.com")
    assert is_url("http://www.toppr.com")
    assert is_url("http://www.toppr.com/")
    assert is_url("http://toppr.com")
    assert is_url("http://toppr.com/")

# Generated at 2022-06-12 07:14:01.308450
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    case_1 = '0306406152'
    case_2 = '0789751984'
    case_3 = '1449363751'
    case_4 = '1451686579'
    case_5 = '8829964059'
    case_6 = '8829964050'
    case_7 = '8829964056'

    checker_1 = __ISBNChecker(case_1)
    checker_2 = __ISBNChecker(case_2)
    checker_3 = __ISBNChecker(case_3)
    checker_4 = __ISBNChecker(case_4)
    checker_5 = __ISBNChecker(case_5)
    checker_6 = __ISBNChecker(case_6)
    checker_7 = __ISBN

# Generated at 2022-06-12 07:14:05.595843
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75')
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334')
    assert not is_ip('1.2.3')

# Generated at 2022-06-12 07:14:09.826753
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75') == True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip('1.2.3') == False



# Generated at 2022-06-12 07:14:16.187463
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('127.0.0.1') is True
    assert is_ip_v4('255.200.100.75') is True

    assert is_ip_v4('nope') is False
    assert is_ip_v4('255.200.100.999') is False
    assert is_ip_v4('87.87.87') is False
    assert is_ip_v4('300.10.20.30') is False


# Generated at 2022-06-12 07:14:24.763334
# Unit test for function is_email
def test_is_email():
    assert is_email('test@test.test') == True
    assert is_email('test.test.test@test.com') == True
    assert is_email('test+test@test.test') == True
    assert is_email('test-test@test.test') == True
    assert is_email('test.test@test.test') == True
    assert is_email('test-test.test@test.test') == True
    assert is_email('test+test-test.test@test.test') == True
    assert is_email('test+test@example.com') == True
    assert is_email('test.test@example.com') == True
    assert is_email('test-test@example.com') == True
    assert is_email('test_test@example.com') == True

# Generated at 2022-06-12 07:14:33.462783
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4111111111111111', card_type='VISA')
    assert is_credit_card('5454545454545454', card_type='MASTERCARD')
    assert is_credit_card('378282246310005', card_type='AMERICAN_EXPRESS')
    assert is_credit_card('30569309025904', card_type='DINERS_CLUB')
    assert is_credit_card('6011111111111117', card_type='DISCOVER')
    assert is_credit_card('3530111333300000', card_type='JCB')

# def is_ip_v4(input_string: Any) -> bool:
#     """
#     Checks if a string is a valid IP v4 address.
#
#     :param input_string: String to

# Generated at 2022-06-12 07:14:39.324262
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('my\\ email@gmail.com')
    assert is_email('"Mailbox, Dotted"@m.example.com')
    assert is_email('"Mailbox, Dotted"@m.example.com')
    assert not is_email('@gmail.com')
    assert not is_email('myemail@provider.com')



# Generated at 2022-06-12 07:14:43.281019
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == 1
    assert is_ip_v4('nope') == 0
    assert is_ip_v4('255.200.100.999') == 0

# Test for function test_is_ip_v4

# Generated at 2022-06-12 07:14:54.445852
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert not is_email('@gmail.com')
    assert not is_email('hello')
    assert not is_email('.hello@gmail.com')
    assert not is_email('hel..lo@gmail.com')
    assert not is_email('hello.@gmail.com')
    assert not is_email('hello@gmail.com..')
    assert not is_email('hello@.gmail.com')
    assert not is_email('hello.gmail.com')
    assert is_email('hello@gmail.com')
    assert is_email('hel+lo@gmail.com')
    assert is_email('hellogmail.com')
    assert is_email('hello@gmail.com')

# Generated at 2022-06-12 07:14:58.809690
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    
test_is_email()


# Generated at 2022-06-12 07:15:08.865978
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('1.1.1.1') == True
    assert is_ip_v4('255.255.255.255') == True
    assert is_ip_v4('256.255.255.255') == False
    assert is_ip_v4('123.123.123') == False
    assert is_ip_v4('abc') == False

# Generated at 2022-06-12 07:15:11.920296
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0123456789').is_isbn_10() == True
    assert __ISBNChecker('0123456788').is_isbn_10() == False
    return True

test___ISBNChecker_is_isbn_10()


# Generated at 2022-06-12 07:15:14.233340
# Unit test for function is_email
def test_is_email():
    if is_email("my.email@gmail.com"):
        print("The email is valid")
    else:
        print("The email is invalid")


# Generated at 2022-06-12 07:15:24.356075
# Unit test for function is_email

# Generated at 2022-06-12 07:15:28.824860
# Unit test for function is_ip_v4
def test_is_ip_v4():
    # v1: full test
    assert is_ip_v4('255.200.100.75')
    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999')
    assert is_ip_v4('0.0.0.0')
    assert is_ip_v4('1.2.3.4')
    assert is_ip_v4('100.100.100.100')
    # v2: boundary checks
    assert is_ip_v4('0.0.0.0')
    assert not is_ip_v4('0.0.0.')
    assert is_ip_v4('255.255.255.255')
    assert not is_ip_v4('255.255.255.999')
    assert not is_

# Generated at 2022-06-12 07:15:36.872513
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4111111111111111') == True, "Valid Credit card"
    assert is_credit_card('5105 1051 0510 5100') == True, "Valid Credit card"
    assert is_credit_card('5105105105105100') == True, "Valid Credit card"
    assert is_credit_card('5105105105105') == False, "Invalid Credit card"
    assert is_credit_card('5105105105105100','VISA') == True, "Valid VISA Credit card"
    assert is_credit_card('5105105105105100','MASTERCARD') == True, "Valid MASTERCARD Credit card"
    assert is_credit_card('5105105105105100','AMERICAN_EXPRESS') == False, "Invalid Credit card"

# Generated at 2022-06-12 07:15:39.851799
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') # returns true
    assert not is_email('@gmail.com') # returns false
test_is_email()



# Generated at 2022-06-12 07:15:46.226055
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('192.168.1.1')
    assert not is_ip_v4('192.168.1.1.1')
    assert not is_ip_v4('nope')
    assert not is_ip_v4('192.168.1.999')
    assert not is_ip_v4('192.168.1')
    assert not is_ip_v4('192.168')
    assert not is_ip_v4('192')


# Generated at 2022-06-12 07:15:50.490695
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    checker = __ISBNChecker('9780596007126')
    assert checker.is_isbn_13() == True

    checker = __ISBNChecker('9780596007121')
    assert checker.is_isbn_13() == False



# Generated at 2022-06-12 07:15:58.562234
# Unit test for function is_email
def test_is_email():
    assert is_email('foo@bar.com') == True
    assert is_email('foo@bar.co') == True
    assert is_email('foo@bar.baz') == True
    assert is_email('foo@bar.biz') == True
    assert is_email('foo@bar.co.uk') == True
    assert is_email('foo@bar.ca') == True
    assert is_email('foo@bar.cn') == True
    assert is_email('foo@bar.cz') == True
    assert is_email('foo@bar.de') == True
    assert is_email('foo@bar.dk') == True
    assert is_email('foo@bar.edu') == True
    assert is_email('foo@bar.fr') == True
    assert is_email('foo@bar.gov') == True
   

# Generated at 2022-06-12 07:16:05.807073
# Unit test for function is_email
def test_is_email():
    print("Testing function is_email")
    assert is_email(".@gmail.com") == False
    assert is_email("asdasd.") == False
    assert is_email("asdasd@") == False
    assert is_email("@gmail.com") == False
    assert is_email("asdasd@gmailcom") == False
    assert is_email("asdasd@gmail.c") == False
    assert is_email("asdasd@gmail.com") == True
    print("Passed!")


# Generated at 2022-06-12 07:16:08.478422
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    print('Running test___ISBNChecker_is_isbn_10()')
    checker = __ISBNChecker('1409306496')
    assert checker.is_isbn_10()

# Generated at 2022-06-12 07:16:11.155313
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('10240.0.0.1') == False
    assert is_ip_v4('10240.0.0.1') != True


# Generated at 2022-06-12 07:16:13.688095
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') is True
    assert is_json('[1, 2, 3]') is True
    assert is_json('{nope}') is False



# Generated at 2022-06-12 07:16:23.835124
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') is True
    assert is_email('not.an.email') is False
    assert is_email('@gmail.com') is False
    assert is_email('a@gmail.com') is True
    assert is_email('valid.email@domain.com') is True
    assert is_email('a " valid.email@domain.com') is True
    assert is_email('a " va\\"li.d\\"\\ email@domain.com') is True
    assert is_email('user@localhost.com') is True
    assert is_email('a "va" li"d "email@domain.com') is True
    assert is_email('email.with-uncommonTLD@domain.museum') is True
    assert is_email('a@bar.com')

# Generated at 2022-06-12 07:16:27.871397
# Unit test for function is_json
def test_is_json():
    assert(is_json('{"name": "Peter"}'))
    assert(is_json('[1, 2, 3]'))
    assert not(is_json('{nope}'))


# Generated at 2022-06-12 07:16:37.125291
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') is True
    assert is_email('@gmail.com') is False
    assert is_email('my email@gmail.com') is True
    assert is_email('my.email@gmail.com') is True
    assert is_email('my email@gmail.com') is True
    assert is_email('my.email@gmail.com') is True
    assert is_email('"test."@gmail.com') is True
    assert is_email('"test.a"@gmail.com') is True
    assert is_email('"test.."@gmail.com') is True
    assert is_email('"test"@gmail.com') is True
    assert is_email('test.a@gmail.com') is False

# Generated at 2022-06-12 07:16:41.758082
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False
    assert is_json(None) == False
    assert is_json('{') == False
    assert is_json('"hello": "name"') == False



# Generated at 2022-06-12 07:16:52.431737
# Unit test for function is_json
def test_is_json():
    assert is_json("{}")
    assert is_json("{\"key\":\"value\"}")
    assert is_json("{\"key\":[{\"key1\":\"value1\"}]}")
    assert is_json("[\"key\",\"value\"]")
    assert is_json("[\"key\",{\"key1\":\"value1\"}]")
    assert is_json("[]")
    assert not is_json("{key\":\"value\"}")
    assert not is_json("[] key\":\"value\"}")
    assert not is_json("{key\":\"value\"}")
    assert not is_json("{key\":value\"}")
    assert not is_json("{key:\"value\"}")



# Generated at 2022-06-12 07:17:02.461359
# Unit test for function is_json

# Generated at 2022-06-12 07:17:14.076799
# Unit test for function is_email
def test_is_email():
    assert is_email("foo@bar.com") == True
    assert is_email("foo.bar@bar.com") == True
    assert is_email("foo..bar@bar.com") == False
    assert is_email("foo@bar..com") == False
    assert is_email("foo@bar.com.") == False
    assert is_email("foo@bar.com.uk") == True
    assert is_email("foo@bar..com") == False
    assert is_email("foo@bar..com.uk") == False


# Generated at 2022-06-12 07:17:17.611952
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-12 07:17:25.353638
# Unit test for function is_email
def test_is_email():
    assert is_email('bob@gmail.com')
    assert is_email('bob@gmail.com')==True
    assert is_email('"my.email"@the-provider.com')==True
    assert is_email('"@gmail.com')==False
    assert is_email('bob@gmail.com ')==False
    assert is_email('foo.@example.com')==False
    assert is_email('foo@example.com ')==False
    assert is_email('foo@example.com ')==False
    assert is_email('foo@@example.com ')==False



# Generated at 2022-06-12 07:17:28.407096
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0306406152').is_isbn_10() is True
    assert __ISBNChecker('0-306-40615-2').is_isbn_10() is True
    assert __ISBNChecker('030640615A').is_isbn_10() is False
    assert __ISBNChecker('0306406158').is_isbn_10() is False



# Generated at 2022-06-12 07:17:39.352342
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    test_cases = [
        ('978-81-265-7066-6', True),
        ('81-265-7066-1', False),
        ('978-81-265-7066-0', True),
        ('978-81-265-7066-1', False),
        ('978-81-265-7066-3', False),
        ('978-81-265-7066-5', False),
        ('978-81-265-7066-7', False),
        ('978-81-265-7066-8', False),
        ('978-81-265-7066-9', False),
    ]

    for test_case in test_cases:
        assert __ISBNChecker(test_case[0]).is_isbn_13() == test_case[1]



# Generated at 2022-06-12 07:17:44.522851
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4("255.200.100.75") == True
    assert is_ip_v4("nope") == False
    assert is_ip_v4("255.200.100.999") == False

test_is_ip_v4()



# Generated at 2022-06-12 07:17:53.716890
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-1-56619-909-4').is_isbn_13() == True
    assert __ISBNChecker('9781566919094').is_isbn_13() == True
    assert __ISBNChecker('1234567890123').is_isbn_13() == False
    assert __ISBNChecker('abc').is_isbn_13() == False
    assert __ISBNChecker('').is_isbn_13() == False
    assert __ISBNChecker('').is_isbn_13(False) == False

# Generated at 2022-06-12 07:17:58.647053
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[6, 2, 3]') == True
    assert is_json('{"nope"}') == False


# Generated at 2022-06-12 07:18:09.677567
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0765342261').is_isbn_10()==True
    assert __ISBNChecker('123456789X').is_isbn_10()==True
    assert __ISBNChecker('076534226').is_isbn_10()==False
    assert __ISBNChecker('0765342262').is_isbn_10()==False
    assert __ISBNChecker('0-7653-4226-1').is_isbn_10()==True
    assert __ISBNChecker('076-53422-61').is_isbn_10()==True
    assert __ISBNChecker('0-7653-4226-1').is_isbn_10()==True
    assert __ISBNChecker('076534226-1').is_isbn_10

# Generated at 2022-06-12 07:18:13.921618
# Unit test for function is_email
def test_is_email():
    assert(is_email('my.email@the-provider.com') == True)
    print('Passed!')
# test_is_email()



# Generated at 2022-06-12 07:18:30.276852
# Unit test for function is_email
def test_is_email():
	assert is_email('ab@cd.com') == True
	assert is_email('abc.com') == False
	assert is_email('abc@com') == False
	assert is_email('@abc.com') == False
	assert is_email('') == False


# Generated at 2022-06-12 07:18:37.479058
# Unit test for function is_email
def test_is_email():
    assert is_email("someone@example.com")  == True
    assert is_email("someone@example.com")  == True
    assert is_email("@example.com")         == False
    assert is_email("name@example.3com")    == False
    assert is_email("name@example.c")       == False
    assert is_email("name@example.c")       == False
    assert is_email("someone@example.co")   == True
    assert is_email("someone@example.co.u") == True
    assert is_email("someone@example.cok")  == True
    assert is_email("someone@example.c9k")  == True



# Generated at 2022-06-12 07:18:38.307167
# Unit test for function is_json
def test_is_json():
    return is_json('{"name": "Peter"}') == True

# Generated at 2022-06-12 07:18:42.592360
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999')
# Unit test: is_ip_v4


# Generated at 2022-06-12 07:18:48.959956
# Unit test for function is_json
def test_is_json():
    assert is_json('{}') == True
    assert is_json('[]') == True
    assert is_json('"hello"') == True
    assert is_json(None) == False
    assert is_json(0) == False
    assert is_json(True) == False
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{"name": "Peter", "age": 42}') == True
    assert is_json('{nope}') == False
    
test_is_json()



# Generated at 2022-06-12 07:18:54.074463
# Unit test for function is_email
def test_is_email():
    assert not is_email('@gmail.com')
    assert is_email('my.email@gmail.com')
    assert is_email('my.very.long.head@gmail.com')
    assert is_email('"my email"@gmail.com')
    assert is_email('"my.email"@gmail.com')
    assert is_email('my\\ email@gmail.com')
    assert is_email('my\\.email@gmail.com')
    assert is_email('"my\\.email"@gmail.com')
    assert not is_email('"my.email@gmail.com')
    assert not is_email('my.email@gmail.com"')
    assert is_email('"my@email"@gmail.com')
    assert not is_email('my@email@gmail.com')

# Generated at 2022-06-12 07:19:03.780170
# Unit test for function is_email
def test_is_email():
    assert is_email('foo@gmail.com') == True
    assert is_email('foo.bar@gmail.com') == True
    assert is_email('foo.bar.baz@gmail.com') == True
    assert is_email('foo.bar@gmail.com') == True
    assert is_email('foo.bar.baz@gmail.com') == True
    assert is_email('foo.bar+baz@gmail.com') == True
    assert is_email('foo.bar-baz@gmail.com') == True
    assert is_email('foo_bar@gmail.com') == True
    assert is_email('foo-bar@gmail.com') == True
    assert is_email('foo123@gmail.com') == True
    assert is_email('foo123.bar@gmail.com') == True

# Generated at 2022-06-12 07:19:06.664851
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False 


# Generated at 2022-06-12 07:19:09.301621
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():    
    assert __ISBNChecker("978-0-306-40615-7").is_isbn_13() == True
    assert __ISBNChecker("978-0-306-40615-6").is_isbn_13() == False

# Generated at 2022-06-12 07:19:17.399156
# Unit test for function is_email
def test_is_email():
    assert is_email('user@mail.com') is True
    assert is_email('user@mail.com.br') is True
    assert is_email('user@mail.co.uk') is True
    assert is_email('user+mail.com') is True
    assert is_email('user-mail@mail.com') is True
    assert is_email('user_mail@mail.com') is True
    assert is_email('toto.titi') is False
    assert is_email('toto.@titi.fr') is False
    assert is_email('Toto.titi@truc.fr') is True
    assert is_email('"Toto.titi"@truc.fr') is True
    assert is_email('Toto.titi@truc.fr') is True



# Generated at 2022-06-12 07:19:33.009784
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False
    assert is_json('{"name":') == False
    assert is_json('[1, 2') == False


# Generated at 2022-06-12 07:19:40.548416
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('9781782161069').is_isbn_13()
    assert __ISBNChecker('9781782161069', normalize=False).is_isbn_13()
    assert __ISBNChecker('978-1-78216-106-9').is_isbn_13()
    assert __ISBNChecker('978-1-78216-106-9', normalize=False).is_isbn_13()

# Generated at 2022-06-12 07:19:51.420660
# Unit test for function is_email
def test_is_email():
    assert is_email('test@test.com') == True
    assert is_email('test@test.c') == False
    assert is_email('test@test') == False
    assert is_email('test') == False
    assert is_email('test.com') == False
    assert is_email('@test.com') == False
    assert is_email('@') == False
    assert is_email('test@') == False
    assert is_email('test@test') == False
    assert is_email('"test"@test.com') == True
    assert is_email('test.test@test.com') == True
    assert is_email('test@test.com.com') == True
    assert is_email('.test@test.com') == False
    assert is_email('test@test.com.') == False

# Generated at 2022-06-12 07:19:53.410041
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0306406152').is_isbn_10()

# Generated at 2022-06-12 07:20:00.360262
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    tests = [
        (False, '9780545010221'),
        (True, '9788771327248'),
        (True, '9789123553390'),
        (True, '9788771322250'),
        (True, '9781849438074'),
    ]

    for expected, input_string in tests:
        actual = __ISBNChecker(input_string).is_isbn_13()
        assert actual == expected, f'Expected {expected}, but got {actual}'



# Generated at 2022-06-12 07:20:10.218255
# Unit test for function is_email
def test_is_email():
    assert not is_email(None)
    assert not is_email('foo')
    assert not is_email('me@')
    assert not is_email('@me')
    assert not is_email('a.b.c@d')
    assert not is_email('a..b@gmail.com')
    assert not is_email('"me@gmail"@gmail.com')
    assert is_email('me@gmail.com')
    assert is_email('me@gmail.com')
    assert is_email('"me@gmail.com"@gmail.com')
    assert is_email('me@gmail.co.uk')
    assert is_email('me@gmail.c.uk')
    assert is_email('me.me@gmail.c.uk')
    assert is_email('me.me@gmail.com')


# Generated at 2022-06-12 07:20:12.620015
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker(input_string='978-92-871-6074-4').is_isbn_13()


# Generated at 2022-06-12 07:20:16.905370
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert True == is_ip_v4('255.200.100.75')
    assert False == is_ip_v4('nope')
    assert False == is_ip_v4('255.200.100.999')



# Generated at 2022-06-12 07:20:25.020344
# Unit test for function is_email
def test_is_email():
    assert is_email("foo.bar@baz.com")
    assert is_email("foo.bar@baz.co.uk")
    assert is_email("Foo Bar <foo.bar@baz.org>")
    assert is_email("Foo.Bar.Example@Example.Com")
    assert is_email("Foo..Bar.Example@Example.Com")
    assert not is_email("foo.bar@baz")
    assert not is_email("foo@bar@baz.com")
    assert not is_email("foo.bar@baz.com.")

test_is_email()



# Generated at 2022-06-12 07:20:29.184876
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    input_string = "978-1-56619-909-4"
    checker = __ISBNChecker(input_string)

    assert checker.is_isbn_13() is True

# Generated at 2022-06-12 07:20:51.289116
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True


# Generated at 2022-06-12 07:20:59.257833
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    test_cases = [
        ('978-81-7597-082-2', True),
        ('0-306-40615-2', False)
    ]
    print('Unit test for method is_isbn_13 of class __ISBNChecker')
    for test_case in test_cases:
        try:
            checker = __ISBNChecker(test_case[0])
            assert checker.is_isbn_13() == test_case[1], 'Test case "{}" failed {} expected, got {}'.format(
                test_case[0], test_case[1], checker.is_isbn_13())
        except Exception as e:
            print('Test case "{}" failed, reason: {}'.format(test_case[0], e))
    print("\nTest completed!\n")

#Unit

# Generated at 2022-06-12 07:21:03.748698
# Unit test for function is_json
def test_is_json():
    print(is_json('{"name": "Peter"}'))
    print(is_json('[1, 2, 3]'))
    print(is_json('{nope}'))

test_is_json()



# Generated at 2022-06-12 07:21:09.519634
# Unit test for function is_json
def test_is_json():
    assert is_json('{}') == True
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False
    assert is_json('"name"') == False
    assert is_json('') == False
    assert is_json(None) == False


# Generated at 2022-06-12 07:21:12.433226
# Unit test for function is_ip_v4
def test_is_ip_v4():
    # Arrange
    input_str = '255.200.100.75'
    # Act
    check = is_ip_v4(input_str)
    # Assert
    assert check == True


# Generated at 2022-06-12 07:21:14.167187
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('1462076874').is_isbn_10() == True
    

# Generated at 2022-06-12 07:21:19.156047
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert(is_ip_v4('255.200.100.75') == True)
    assert(is_ip_v4('nope') == False)
    assert(is_ip_v4('255.200.100.999') == False)
    print('passed!')



# Generated at 2022-06-12 07:21:27.199862
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0201005399').is_isbn_10()
    assert not __ISBNChecker('0201005300').is_isbn_10()
    assert __ISBNChecker('0-201-00534-8').is_isbn_10()
    assert not __ISBNChecker('0-201-00534-9').is_isbn_10()
    assert not __ISBNChecker('1-232-33333-9').is_isbn_10()


'''
    Strings
'''



# Generated at 2022-06-12 07:21:30.322757
# Unit test for function is_email
def test_is_email():
    assert is_email("my.email@the-provider.com") == True
    assert is_email("@gmail.com") == False



# Generated at 2022-06-12 07:21:40.541989
# Unit test for function is_email
def test_is_email():
    assert is_email('me@example.com')
    assert is_email('firstname.lastname@example.com')
    assert is_email('firstname+lastname@example.com')
    assert is_email('"email\"@example.com')
    assert is_email('1234567890@example.com')
    assert is_email('email@example-one.com')
    assert is_email('email@example.name')
    assert is_email('email@example.co.jp')
    assert is_email('firstname-lastname@example.com')
    assert is_email('_______@example.com')
    assert is_email('''much."more\\ unusual"@example.com''')
    assert is_email('''"very.unusual.@.unusual.com"@example.com''')
