

# Generated at 2022-06-12 07:12:39.236370
# Unit test for function is_ip_v4
def test_is_ip_v4():
    """
    Check that function works as expected
    """
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False

test_is_ip_v4()


# Generated at 2022-06-12 07:12:40.320006
# Unit test for function is_json
def test_is_json():
    return is_json('{nope}')
# print(test_is_json())



# Generated at 2022-06-12 07:12:45.647876
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False
    assert is_json('1') == False
    assert is_json('') == False



# Generated at 2022-06-12 07:12:57.389675
# Unit test for function is_email
def test_is_email():
    assert is_email('test@gmail.com') == True
    assert is_email('test@gmail..com') == False

# Generated at 2022-06-12 07:13:08.173405
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') is True
    assert is_url('https://mysite.com') is True
    assert is_url('.mysite.com') is False
    assert is_url('http://mysite.com:8080/a/b/c?a=1&b=2#abc') is True
    assert is_url('http://mysite.com:8080/a/b/c?a=1&b=2=3#abc') is False
    assert is_url('http://mysite.com:8080/a/b/c?a=1&b=2', allowed_schemes=['http', 'https']) is True

# Generated at 2022-06-12 07:13:09.944394
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
test_is_ip()



# Generated at 2022-06-12 07:13:20.787790
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('1'), 'is_integer("1")'
    assert is_integer('0'), 'is_integer("0")'
    assert is_integer('-0'), 'is_integer("-0")'
    assert is_integer('-1'), 'is_integer("-1")'
    assert is_integer('+1'), 'is_integer("+1")'
    assert is_integer('123'), 'is_integer("123")'
    assert is_integer('+123'), 'is_integer("+123")'
    assert is_integer('-123'), 'is_integer("-123")'
    assert is_integer('1e3'), 'is_integer("1e3")'
    assert is_integer('1.1e2'), 'is_integer("1.1e2")'

# Generated at 2022-06-12 07:13:26.179767
# Unit test for function is_json
def test_is_json():
    # This is a recursive function: it will call itself n times, until n > 0
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}')== False
test_is_json()


# Generated at 2022-06-12 07:13:27.761500
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert( is_ip_v4('127.0.0.1'))


# Generated at 2022-06-12 07:13:30.909966
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('9780134757599').is_isbn_13() is True
    assert __ISBNChecker('9791159039792').is_isbn_13() is True

# Generated at 2022-06-12 07:13:51.658273
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card(None) is False
    assert is_credit_card('not a number') is False
    assert is_credit_card('1234567890123456') is False
    assert is_credit_card('0000000000000000') is False
    assert is_credit_card('4111111111111111') is True
    assert is_credit_card('4000000000000000') is True
    assert is_credit_card('5411111111111115') is True
    assert is_credit_card('5500000000000004') is True
    assert is_credit_card('6111111111111111') is True
    assert is_credit_card('341111111111111') is True
    assert is_credit_card('37111111111111') is True
    assert is_credit_card('6011111111111111') is True



# Generated at 2022-06-12 07:13:55.164372
# Unit test for function is_json
def test_is_json():
    # Test cases for is_json
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False
    assert is_json('null') == True



# Generated at 2022-06-12 07:14:06.741235
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('my+alias@gmail.com')
    assert is_email('my_alias@gmail.com')
    assert is_email('my.alias@gmail.com')
    assert is_email('my-alias@gmail.com')
    assert is_email('my\\ alias@gmail.com')
    assert is_email('"my alias"@gmail.com')
    assert is_email('"my.alias"@gmail.com')
    assert is_email('"my-alias"@gmail.com')
    assert is_email('"my\\ alias"@gmail.com')
    assert is_email('"my\\@alias"@gmail.com')
    assert not is_email(' ')

# Generated at 2022-06-12 07:14:13.709281
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') == True
    assert is_isbn('1506715214') == True
    assert is_isbn('978-0312498580') == True
    assert is_isbn('150-6715214') == True
    assert is_isbn('978-0312498580', normalize=False) == False
    assert is_isbn('150-6715214', normalize=False) == False


# Generated at 2022-06-12 07:14:16.025792
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn("9780312498580") == True
    assert is_isbn("1506715214") == True

test_is_isbn()



# Generated at 2022-06-12 07:14:24.678242
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card("4929804463622139") == True
    assert is_credit_card("4929804463622139", card_type="VISA") == True
    assert is_credit_card("4929804463622139", card_type="MASTERCARD") == False
    assert is_credit_card("5500 0000 0000 0004") == True
    assert is_credit_card("5500 0000 0000 0004", card_type="MASTERCARD") == True
    assert is_credit_card("5500 0000 0000 0004", card_type="VISA") == False
    assert is_credit_card("378282246310005") == True
    assert is_credit_card("378282246310005", card_type="AMERICAN_EXPRESS") == True

# Generated at 2022-06-12 07:14:35.277990
# Unit test for function is_json
def test_is_json():
    import json
    assert is_json('{}')
    assert is_json('{"name": "Peter"}')
    assert is_json('[]')
    assert is_json('[1, 2, 3]')
    #assert not is_json('{nope}') # this fails
    #assert not is_json('[1, 2, 3') # this fails
    assert not is_json('{')
    assert not is_json('{[')
    assert not is_json('{[}')
    assert not is_json('[1, 2, 3]]')
    assert not is_json('[1, 2, 3]')



# Generated at 2022-06-12 07:14:44.957260
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('378282246310005') == True
    assert is_credit_card('4012888888881881') == True
    assert is_credit_card('9111111111111111') == True
    assert is_credit_card('5555555555554444') == True
    assert is_credit_card('5105105105105100') == True
    assert is_credit_card('6011123456789012') == True
    assert is_credit_card('6011111111111117') == True
    assert is_credit_card('6011000990139424') == True
    assert is_credit_card('371449635398431') == True
    assert is_credit_card('378734493671000') == True


# Generated at 2022-06-12 07:14:49.538704
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}')  # returns true
    assert is_json('[1, 2, 3]')  # returns true
    assert not is_json('{nope}')  # returns false
test_is_json()



# Generated at 2022-06-12 07:14:58.871867
# Unit test for function is_email
def test_is_email():

    assert is_email("hello@email.com") == True
    assert is_email("hello.world@email.com") == True
    assert is_email("firstname.lastname@email.co.uk") == True
    assert is_email("firstname.lastname@email.com.cn") == True
    assert is_email("hello-world@email.com") == True
    assert is_email("hello_world@email.com") == True
    assert is_email("hello-world@email.com") == True
    assert is_email("hello+world@email.com") == True
    assert is_email("hello'world@email.com") == True
    assert is_email("hello=world@email.com") == True
    assert is_email("hello#world@email.com") == True

# Generated at 2022-06-12 07:15:10.653264
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    checker = __ISBNChecker('978-1-4028-9462-6')
    assert checker.is_isbn_13()

    checker = __ISBNChecker('978-1-4028-9462-5')
    assert not checker.is_isbn_13()



# Generated at 2022-06-12 07:15:16.739247
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.255.255.255') == True
    assert is_ip_v4('192.168.0.1') == True
    assert is_ip_v4('0.0.0.0') == True
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False
    
test_is_ip_v4()


# Generated at 2022-06-12 07:15:23.873433
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') is True
    assert is_email('.my.email@the-provider.com') is False
    assert is_email('my.email@the-provider.com.au') is True
    assert is_email('my.email@the-provider.co.uk') is True
    assert is_email('@gmail.com') is False
    assert is_email(None) is False
    assert is_email('') is False
    assert is_email(' ') is False
test_is_email()


# Generated at 2022-06-12 07:15:29.160637
# Unit test for function is_json
def test_is_json():
    test_json = '{"name": "Peter"}'
    assert is_json(test_json) == True


# UUID is a 128 bits number represented as a series of hexadecimal characters
# this function accepts both uppercase and lowercase letters and allows hyphens.

# Generated at 2022-06-12 07:15:32.053187
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('9791091175666').is_isbn_10() == True
    assert __ISBNChecker('9782845991135').is_isbn_10() == False

# Generated at 2022-06-12 07:15:43.830319
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-0-306-40615-7').is_isbn_13() is True
    assert __ISBNChecker('978-0-306-40615-0').is_isbn_13() is False
    assert __ISBNChecker('0-306-40615-7').is_isbn_13() is False
    assert __ISBNChecker(123456789).is_isbn_13() is False
    assert __ISBNChecker('not-a-isbn').is_isbn_13() is False
    assert __ISBNChecker('').is_isbn_13() is False
    assert __ISBNChecker(None).is_isbn_13() is False

# Generated at 2022-06-12 07:15:53.982236
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}')
    assert is_json('[1, 2, 3]')
    assert not is_json('{nope}')
    assert is_json('{"name": "Peter", "age": 42}')
    assert is_json('{"name": "Peter", "friends": ["Mary", "John"]}')
    assert is_json('{"name": "Peter", "friends": ["Mary", {"spouse": "John"}]}')
    assert is_json('{"name": "Peter", "dob": "1943-10-13"}')
    assert is_json('{"name": "Peter", "dob": "October 13, 1943"}')
    assert not is_json('{"name": "Peter" "age": 42}')

# Generated at 2022-06-12 07:15:57.632258
# Unit test for function is_json
def test_is_json():
    assert not is_json('{nope}')
    assert is_json('{"name": "Peter"}')
    assert is_json('[1, 2, 3]')
    assert not is_json('Peter')
    assert not is_json('')
    assert not is_json(None)



# Generated at 2022-06-12 07:16:08.275235
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False
    assert is_json("") == False
    assert is_json("I am not a Json") == False
    assert is_json("I am not a Json 1") == False
    assert is_json("I am not a Json 1") == False
    assert is_json("I am not a Json 1") == False
    assert is_json("I am not a Json 1") == False
    assert is_json("I am not a Json 1") == False


# Generated at 2022-06-12 07:16:18.718510
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email+spam@the-provider.com')
    assert is_email('my.email_+-=@the-provider.com')
    assert not is_email('@gmail.com')
    assert not is_email('.@gmail.com')
    assert not is_email('me@.gmail.com')
    assert not is_email('me@gmail..com')
    assert not is_email('me@.gmail.com')
    assert not is_email('me@gmail..com')
    assert not is_email('me@gmail.com.')
    assert not is_email('me@gmail.com.')
    assert not is_email('me@gmail.com..')

# Generated at 2022-06-12 07:16:28.046854
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0143125701').is_isbn_10() is True
    assert __ISBNChecker('0143125702').is_isbn_10() is False
    assert __ISBNChecker('0-14312570-1').is_isbn_10() is True
    assert __ISBNChecker('0-14312570-2').is_isbn_10() is False


# PUBLIC API


# convert any type to string

# Generated at 2022-06-12 07:16:37.273210
# Unit test for function is_email
def test_is_email(): # add a docstring
    """
    This function tests whether is_email function works properly or not by testing with various combinations of cases.
    """
    # Test emai with '@'
    assert is_email('a@b') == True
    # Test email with space
    assert is_email('a@ b') == True
    # Test email with '.'
    assert is_email('a.b@c') == True
    # Test email with '?'
    assert is_email('a?b@c') == True
    # Test email with '!'
    assert is_email('a!b@c') == True
    # Test email with '#'
    assert is_email('a#b@c') == True
    # Test email with '$'
    assert is_email('a$b@c') == True
    # Test email with '

# Generated at 2022-06-12 07:16:44.680996
# Unit test for function is_email
def test_is_email():
    assert not is_email('')
    assert not is_email('@gmail.com')
    assert is_email('my.email@the-provider.com')
    assert not is_email('my.email@the-provider.com.')
    assert is_email('my.email@the-provider.com.br')
    assert is_email('my.email@the-provider.com.au')
    assert is_email('my.email@the-provider.com.fr')
    assert not is_email('my.email@.com')
    assert not is_email('my.email@')
    assert not is_email('my.email@@the-provider.com')
    assert not is_email('my.email@the-provider')

# Generated at 2022-06-12 07:16:56.072227
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('my-email@the-provider.com')
    assert is_email('my-email+tag@the-provider.com')
    assert is_email('my-email@the-provider-ext.com')
    assert is_email('my-email@the-provider.company')
    assert is_email('my-email@t.company')
    assert is_email('my-email@t.co')
    assert is_email('my-email@t.company.extension')
    assert is_email('my-email@t.company.ex')
    assert is_email('my-email@t.company.e')
    assert is_email('my-email@t.company.c')

# Generated at 2022-06-12 07:17:04.887862
# Unit test for function is_ip_v4
def test_is_ip_v4():
    """
    Test function is_ip_v4
    """

    # valid ip
    assert is_ip_v4("127.0.0.1")
    # invalid ip
    assert not is_ip_v4("127.0.0.256")
    # invalid ip
    assert not is_ip_v4("127.0.0.1.1")
    # invalid ip
    assert not is_ip_v4("127.0.0.1/24")
    # invalid ip
    assert not is_ip_v4("127.0.0.1 00")
    # invalid ip
    assert not is_ip_v4("127.0.0.1.00")
    # invalid ip
    assert not is_ip_v4("127.0.0.1.0000")
    # invalid ip

# Generated at 2022-06-12 07:17:09.838228
# Unit test for function is_json
def test_is_json():
    correct_json_string="{'a': 'b', 'c': {'d': [1, 2, 3]}, 'e': true}"
    assert is_json(correct_json_string), "Json string was rejected"
    incorrect_json_string="{a:b, c:{d:[1,2,3]}, e:true}"
    assert not is_json(incorrect_json_string), "Missing quotes were permitted"
test_is_json()   



# Generated at 2022-06-12 07:17:18.505018
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999')
test_is_ip_v4()

import re
NUMBER_RE = re.compile('^[-+]?[0-9]*\.?[0-9]+([eE][-+]?[0-9]+)?$')

# Generated at 2022-06-12 07:17:21.106375
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
# Test Finished



# Generated at 2022-06-12 07:17:26.532550
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert is_ip_v4('10.200.100.75')
    assert not is_ip_v4('10.200.100.999')
    assert not is_ip_v4('.10.200.100.75')
    assert not is_ip_v4('10.200.100.')
    assert not is_ip_v4('10.200.100')
    assert not is_ip_v4('')
    assert not is_ip_v4(None)



# Generated at 2022-06-12 07:17:30.680827
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-12 07:17:39.890736
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-0-306-40615-7').is_isbn_13() is True
    assert __ISBNChecker('978-0-306-40615-8').is_isbn_13() is False
    assert __ISBNChecker('978-0-30640615-7').is_isbn_13() is True
    assert __ISBNChecker('978-0-30640615-8').is_isbn_13() is False



# Generated at 2022-06-12 07:17:44.618546
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}')
    assert is_json('[1, 2, 3]')
    assert not is_json('{nope}')
    assert not is_json('nope {nope}')
    assert not is_json('')


# Generated at 2022-06-12 07:17:51.566013
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('9780201896831').is_isbn_13() == True
    assert __ISBNChecker('9781568811551').is_isbn_13() == True
    assert __ISBNChecker('9780201896832').is_isbn_13() == False
    assert __ISBNChecker('9781568811552').is_isbn_13() == False

# Generated at 2022-06-12 07:17:55.001450
# Unit test for function is_ip_v4
def test_is_ip_v4():
  assert (is_ip_v4('255.200.100.75'))
  assert (not is_ip_v4('nope'))
  assert (not is_ip_v4('255.200.100.999'))

test_is_ip_v4()



# Generated at 2022-06-12 07:18:06.570103
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4("192.168.0.1")
    assert not is_ip_v4("192.168.0.256")
    assert not is_ip_v4("192.168.0.1.1")
    assert not is_ip_v4("192.168.0.0/20")
    assert not is_ip_v4("blah.168.0.0")
    assert not is_ip_v4("")
    assert not is_ip_v4(None)
    assert not is_ip_v4(False)
    assert not is_ip_v4([])
    assert not is_ip_v4({})
    assert not is_ip_v4(42)
    assert not is_ip_v4(3.14)



# Generated at 2022-06-12 07:18:10.514506
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-5-9908789-3-3').is_isbn_13()
    assert __ISBNChecker('978-5-9908789-3-3', normalize=False).is_isbn_13()


# Generated at 2022-06-12 07:18:15.309152
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('81112233445').is_isbn_10()
    assert __ISBNChecker('9791170197001').is_isbn_10()
    assert not __ISBNChecker('811122334456').is_isbn_10()
    assert not __ISBNChecker('9791170197001').is_isbn_13()



# Generated at 2022-06-12 07:18:21.498244
# Unit test for function is_json
def test_is_json():
    assert not is_json("{'name': 'Peter'}")
    assert is_json('{"name": "Peter"}')
    assert is_json('[1, 2, 3]')
    assert not is_json('{nope}')
    assert not is_json(None)
    assert not is_json("")


# Generated at 2022-06-12 07:18:28.772643
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0789464118').is_isbn_10()
    assert not __ISBNChecker('078946411').is_isbn_10()
    assert not __ISBNChecker('078946411a').is_isbn_10()
    assert not __ISBNChecker('07894641a1').is_isbn_10()
    assert not __ISBNChecker('07894641112').is_isbn_10()
    assert not __ISBNChecker('07894641110').is_isbn_10()
    assert not __ISBNChecker('12345-12345').is_isbn_10()
    assert __ISBNChecker('12345-12345', normalize=False).is_isbn_10()



# Generated at 2022-06-12 07:18:37.822939
# Unit test for function is_email
def test_is_email():
    print("Testing is_email(input_string)")
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('me.example@gmail.com') == True
    assert is_email('me@abc123') == False
    assert is_email('me-example@gmail.com') == True
    assert is_email('me.example@gmail.com') == True
    assert is_email('me.example@gmail.c') == False
    assert is_email('me.example@gmail.com') == True
    assert is_email('me.example@gmail.com') == True
    assert is_email('"me.example"@gmail.com') == True
    assert is_email('me.example@gmail.com') == True

# Generated at 2022-06-12 07:18:44.690475
# Unit test for function is_email
def test_is_email():
    print("Testing is_email")
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
test_is_email()



# Generated at 2022-06-12 07:18:46.003292
# Unit test for function is_json
def test_is_json():
    assert is_json("{'a': 'b'}")



# Generated at 2022-06-12 07:18:54.959704
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('hello..world@gmail.com') == False
    assert is_email('hello world@gmail.com') == True
    assert is_email('john.doe@gmail.com') == True
    assert is_email('hello.world@gmail.com') == True
    assert is_email('johndoe@gmail.com') == True
    assert is_email('john.doe@gmail.com') == True
    assert is_email('john@gmail.com') == True



# Generated at 2022-06-12 07:19:04.306700
# Unit test for function is_email
def test_is_email():
    assert is_email("abc@abc.abc")
    assert is_email("abc@abc.aaa")
    assert not is_email("abc@abc.aaaaa")
    assert not is_email("abc@abc.a")
    assert not is_email("")
    assert not is_email("abc")
    assert not is_email("a")
    assert is_email("abc@abc.aa")
    assert not is_email("@abc.aa")
    assert is_email("abc@abc.a")
    assert not is_email("abc@abc.aaaa")
    assert is_email('"\\@"@example.com')
    assert is_email("a@a.a")
    assert not is_email("a@a.aa")
    assert is_email("abc@abc.aa")
    assert not is_email

# Generated at 2022-06-12 07:19:10.112848
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    results = [
        (__ISBNChecker('1400083277').is_isbn_10(), True),
        (__ISBNChecker('039480019X').is_isbn_10(), True),
        (__ISBNChecker('1-86197-876-X').is_isbn_10(), True),
        (__ISBNChecker('978-0-4303-4453-4').is_isbn_10(), False),
    ]
    for (result, expected) in results:
        if result != expected:
            raise AssertionError(result)


# Generated at 2022-06-12 07:19:16.661735
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker("978-0-306-40615-7").is_isbn_13()
    assert not __ISBNChecker("978-0-306-40615-1").is_isbn_13()
    assert not __ISBNChecker("xxx-0-306-40615-1").is_isbn_13()



# Generated at 2022-06-12 07:19:21.890345
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    is_isbn_10_test1 = __ISBNChecker('0-558-83656-5')
    assert is_isbn_10_test1.is_isbn_10() is True

    is_isbn_10_test2 = __ISBNChecker('1567312508')
    assert is_isbn_10_test2.is_isbn_10() is False



# Generated at 2022-06-12 07:19:24.373120
# Unit test for function is_json
def test_is_json():
  assert is_json('{"name": "Peter"}') == True
  assert is_json('{"nop}') == False


# Generated at 2022-06-12 07:19:35.577549
# Unit test for function is_email
def test_is_email():
    assert is_email('me.you@home.com') == True
    assert is_email('me.you@home.com') == True
    assert is_email('me_you@home.com') == True
    assert is_email('me-you@home.com') == True
    assert is_email('me+you@home.com') == True
    assert is_email('me_you@home.com') == True
    assert is_email('me_you@home.com') == True
    assert is_email('me_you@home.com') == True
    assert is_email('me-you@home.com') == True
    assert is_email('me+you@home.com') == True
    assert is_email('me_you@home.com') == True



# Generated at 2022-06-12 07:19:40.862817
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    checker = __ISBNChecker('0-306-40615-2')
    assert checker._ISBNChecker__is_isbn_10() is True

    checker = __ISBNChecker('3-493-65741-3')
    assert checker._ISBNChecker__is_isbn_10() is False


# Generated at 2022-06-12 07:19:47.201692
# Unit test for function is_json
def test_is_json():
    assert is_json('1')==False


# Generated at 2022-06-12 07:19:54.912962
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com.')
    assert is_email('my.email@the-provider.com.a')
    assert is_email('m.y.e.m.a.i.l@the-provider.com')
    assert is_email('my-email@the-provider.com')
    assert is_email('my_e.ma.il@the-provider.com')
    assert is_email('my!email@the-provider.com')
    assert is_email('my_email@the-provider.com')
    assert is_email('my$email@the-provider.com')
    assert is_email('   my.email@the-provider.com')
   

# Generated at 2022-06-12 07:19:59.349978
# Unit test for function is_email
def test_is_email():
    assert is_email('test@test.com') is True
    assert is_email('a.b@a.b') is True
    assert is_email('test@test.com.') is False
    assert is_email('@gmail.com') is False
    assert is_email('test') is False
    assert is_email('') is False



# Generated at 2022-06-12 07:20:09.883842
# Unit test for function is_json
def test_is_json():
    assert is_json("{'foo':'bar'}") == False
    assert is_json('{"foo": "bar"}') == True
    assert is_json("{'foo':'bar', 'qux':'quux'}") == False
    assert is_json('{"foo": "bar", \'qux\': \'quux\'}') == True
    assert is_json("['foo', 'bar']") == False
    assert is_json('["foo", "bar"]') == True
    assert is_json('{"foo": "bar"}') == True
    assert is_json("{'foo': 'bar', 'qux': 'quux'}") == False
    assert is_json("['foo', 'bar', 'qux', 'quux']") == False

# Generated at 2022-06-12 07:20:17.846296
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert (is_ip_v4("255.200.100.75") == True)
    assert (is_ip_v4("1000.200.100.75") == False)
    assert (is_ip_v4("nope") == False)
    assert (is_ip_v4("1.2.3.4.5") == False)
    assert (is_ip_v4("255.200.100.999") == False)



# Generated at 2022-06-12 07:20:24.876269
# Unit test for function is_ip_v4
def test_is_ip_v4():
    # Test 1
    assert is_ip_v4('127.0.0.1') == True

    # Test 2
    assert is_ip_v4('192.168.0.1') == True

    # Test 3
    assert is_ip_v4('192.168.0.256') == False

    # Test 4
    assert is_ip_v4('192.168.0.256') == False

    # Test 5
    assert is_ip_v4('abcde') == False



# Generated at 2022-06-12 07:20:27.697012
# Unit test for function is_json
def test_is_json():
    return is_json('{1,2,3}')==False
print(test_is_json())
#Unit test for function is_json

# Generated at 2022-06-12 07:20:29.246464
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False



# Generated at 2022-06-12 07:20:36.385224
# Unit test for function is_email
def test_is_email():
    assert is_email("email@gmail.com")==True
    assert is_email("email@gmail")==False
    assert is_email("emailgmail.com")==False
    assert is_email("@gmail.com")==False
    assert is_email("a@.com")==False
    assert is_email("a..b@gmail.com")==False
    assert is_email("a@b..com")==False
test_is_email()



# Generated at 2022-06-12 07:20:40.165455
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    input_string = '123456789X'
    isbn_checker = __ISBNChecker(input_string)
    assert isbn_checker.is_isbn_10() is True, 'test___ISBNChecker_is_isbn_10() failed'

test___ISBNChecker_is_isbn_10()

# Generated at 2022-06-12 07:20:55.820868
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0073523318').is_isbn_10() is True
    assert __ISBNChecker('0-0073523318').is_isbn_10() is True
    assert __ISBNChecker('0073523318').is_isbn_10() is True
    assert __ISBNChecker('0205080057').is_isbn_10() is True
    assert __ISBNChecker('0-2050-8005-7').is_isbn_10() is True
    assert __ISBNChecker('0-375-42525-6').is_isbn_10() is True
    assert __ISBNChecker('1-931228-36-7').is_isbn_10() is True
    assert __ISBNChecker('1-931228-37-5').is_isbn

# Generated at 2022-06-12 07:21:06.760520
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') is True
    assert is_email('@gmail.com') is False
    assert is_email('a@com') is True
    assert is_email('a1@com') is True
    assert is_email('a@com.au') is True
    assert is_email('a1@com.au') is True
    assert is_email('a@com.au.uk') is True
    assert is_email('a1@com.au.uk') is True
    assert is_email('a.b@com.au.uk') is True
    assert is_email('a.b@com.co.uk') is True
    assert is_email('.a@com.co.uk') is False

# Generated at 2022-06-12 07:21:10.562451
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('9780140449134').is_isbn_13() is True
    assert __ISBNChecker('0-553-21307-8').is_isbn_13() is False
    assert __ISBNChecker('0-553-213-07-8').is_isbn_13() is False



# Generated at 2022-06-12 07:21:17.127057
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-4-87311-715-2').is_isbn_13()
    assert not __ISBNChecker('978-4-87311-715-1').is_isbn_13()
    assert __ISBNChecker('978-3-16-148410-0').is_isbn_13()
    assert not __ISBNChecker('978-3-16-148410-1').is_isbn_13()
    assert __ISBNChecker('979-4-87311-715-2').is_isbn_13()
    assert not __ISBNChecker('979-4-87311-715-1').is_isbn_13()

# Generated at 2022-06-12 07:21:28.108040
# Unit test for function is_email
def test_is_email():
    assert is_email("a") == False
    assert is_email("a@a.a")
    assert is_email("a.a.a@a.a") == False
    assert is_email("aa@a.a")
    assert is_email("aa$@a.a")
    assert is_email("aa=@a.a")
    assert is_email("aa^@a.a")
    assert is_email("aa`@a.a")
    assert is_email("aa´@a.a")
    assert is_email("aa~@a.a")
    assert is_email("aa?@a.a")
    assert is_email("aa&@a.a")
    assert is_email("aa'@a.a")
    assert is_email("aa*@a.a")

# Generated at 2022-06-12 07:21:36.806521
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0140449116').is_isbn_10() == True
    assert __ISBNChecker('0140449117').is_isbn_10() == False
    assert __ISBNChecker('0-8044-2957-X').is_isbn_10() == True
    assert __ISBNChecker('0-8044-2957-Y').is_isbn_10() == False
    assert __ISBNChecker('0-8044-2957-8').is_isbn_10() == False


# PUBLIC API



# Generated at 2022-06-12 07:21:41.830137
# Unit test for function is_email
def test_is_email():
    assert is_email("") == False
    assert is_email("@gmail.com") == False
    assert is_email("email") == False
    assert is_email("email@") == False
    assert is_email("email@gmail") == False
    assert is_email("email@gmail.c") == False
    assert is_email("email@gmail.com") == True
    assert is_email("my.email@the-provider.com") == True
    test_is_email()
    print("Function is_email passed all test")



# Generated at 2022-06-12 07:21:44.055248
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    checker = __ISBNChecker('0425261260')
    assert checker.is_isbn_10()


# PUBLIC API



# Generated at 2022-06-12 07:21:49.332780
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4("192.168.13.12") == True
    assert is_ip_v4("192.168.13.12.") == False
    assert is_ip_v4("192.168.13..12") == False
    assert is_ip_v4("192.168.13") == False
    assert is_ip_v4("192.168.13.a") == False
    assert is_ip_v4("192.168.13.256") == False
    assert is_ip_v4("192.168.13.-12") == False


# Generated at 2022-06-12 07:21:59.413990
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('7111333111').is_isbn_10() == True
    assert __ISBNChecker('7111333112').is_isbn_10() == False
    assert __ISBNChecker('7111333113').is_isbn_10() == False
    assert __ISBNChecker('7111333114').is_isbn_10() == False
    assert __ISBNChecker('7111333115').is_isbn_10() == False
    assert __ISBNChecker('7111333116').is_isbn_10() == False
    assert __ISBNChecker('7111333117').is_isbn_10() == False
    assert __ISBNChecker('7111333118').is_isbn_10() == False
    assert __ISBNChecker

# Generated at 2022-06-12 07:22:16.447224
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    def test_is_isbn_13(input_string: str, expected_result: bool) -> bool:
        checker = __ISBNChecker(input_string)
        return checker.is_isbn_13() == expected_result

    assert test_is_isbn_13('0000000000000', False)
    assert test_is_isbn_13('0000000000001', False)
    assert test_is_isbn_13('1234567890123', True)

