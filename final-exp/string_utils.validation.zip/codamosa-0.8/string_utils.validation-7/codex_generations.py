

# Generated at 2022-06-12 07:12:47.126098
# Unit test for function is_ip_v4
def test_is_ip_v4():
    # str ip_address
    assert is_ip_v4('192.168.0.1') == True
    assert is_ip_v4('192.168.0.1') == True
    assert is_ip_v4('191.168.0.1') == True
    assert is_ip_v4('249.168.0.1') == False
    assert is_ip_v4('259.168.0.1') == False
    assert is_ip_v4('192.168.01') == False
    assert is_ip_v4('192.168.01') == False
    assert is_ip_v4('192.168.1.1e2') == False
    assert is_ip_v4('192.168.1.1e2') == False

# Generated at 2022-06-12 07:12:54.794504
# Unit test for function is_ip_v4
def test_is_ip_v4():
    # Test case 1: Check ip v4
    ip = '255.200.100.75'
    assert is_ip_v4(ip) == True
    
    # Test case 2: Check ip v4
    ip = 'nope'
    assert is_ip_v4(ip) == False
    
    # Test case 3: Check ip v4
    ip = '255.200.100.999'
    assert is_ip_v4(ip) == False
    
# ------------------------------------------------------


# Generated at 2022-06-12 07:13:05.833843
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert not __ISBNChecker('1').is_isbn_10()
    assert __ISBNChecker('0-306-40615-2').is_isbn_10()
    assert __ISBNChecker('3-16-148410-0').is_isbn_10()
    assert __ISBNChecker('1-84356-028-3').is_isbn_10()
    assert not __ISBNChecker('0-306-40615-1').is_isbn_10()
    assert not __ISBNChecker('0-306-40615-3').is_isbn_10()
    assert not __ISBNChecker('0-306-40615-4').is_isbn_10()
    assert not __ISBNChecker('0-306-40615-5').is_isbn_10()


# Generated at 2022-06-12 07:13:08.343058
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    checker = __ISBNChecker("978-3-16-148410-0")
    assert checker.is_isbn_13() is True


# PUBLIC API



# Generated at 2022-06-12 07:13:09.561773
# Unit test for function is_json
def test_is_json():
    pass



# Generated at 2022-06-12 07:13:13.274523
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') == True # true
    assert is_isbn('1506715214') == True # true


# Generated at 2022-06-12 07:13:17.799639
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('LOL')
    assert not is_palindrome('ROTFL')
    assert is_palindrome('Lol', ignore_case=True)
    assert not is_palindrome('Lol')
    
    
test_is_palindrome()



# Generated at 2022-06-12 07:13:23.819612
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert not is_ip_v4('nope') # returns false (not an ip)
    assert not is_ip_v4('255.200.100.999') # returns false (999 is out of range)
    assert is_ip_v4('255.200.100.75') # returns true


# Generated at 2022-06-12 07:13:27.069053
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75')
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334')
    assert not is_ip('1.2.3')



# Generated at 2022-06-12 07:13:29.913660
# Unit test for function is_email
def test_is_email():
    print('start test email!')
    print(is_email('my.email@the-provider.com'))
    return


# Generated at 2022-06-12 07:13:44.007067
# Unit test for function is_credit_card
def test_is_credit_card():
    # incorrect card type
    try:
        is_credit_card('5263 3104 9186 8128', 'wrong-type')
    except KeyError:
        assert True
    else:
        assert False
    # any card type
    assert is_credit_card('5263 3104 9186 8128', 'MASTERCARD') == is_credit_card('5263 3104 9186 8128')
    # VISA
    assert is_credit_card('4111 1111 1111 1111', 'VISA')
    # MASTERCARD
    assert is_credit_card('5263 3104 9186 8128', 'MASTERCARD')
    # AMERICAN_EXPRESS
    assert is_credit_card('3484 4085 6220 861', 'AMERICAN_EXPRESS')
    # DINERS_CLUB

# Generated at 2022-06-12 07:13:45.565657
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4111111111111111') == True



# Generated at 2022-06-12 07:13:53.192218
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') == True
    assert is_url('https://mysite.com') == True
    assert is_url('mysite.com') == False
    assert is_url('.mysite.com') == False
    assert is_url('http://www.mysite.com', ['http', 'https']) == True
    assert is_url('https://mysite.com', ['http', 'https']) == True
    assert is_url('ftp://mysite.com', ['http', 'https']) == False
test_is_url()



# Generated at 2022-06-12 07:13:55.131211
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True, "1st test failed"
    assert is_email('@gmail.com') == False, "2nd test failed"



# Generated at 2022-06-12 07:13:57.868449
# Unit test for function is_json

# Generated at 2022-06-12 07:13:58.907932
# Unit test for function is_email
def test_is_email():
    assert(is_email('*@example.com') == True)


# Generated at 2022-06-12 07:14:11.040939
# Unit test for function is_json
def test_is_json():
    assert is_json('{"foo": "bar"}') == True #normal case
    assert is_json('{}') == True #empty cases
    assert is_json('{"foo": ["bar", "baz"]}') == True #list case
    assert is_json('{"foo": [] }') == True #empty list case
    assert is_json('{"foo": ["bar", "baz", [], {"key": "value"}, "baz"]}') == True #list with items cases
    assert is_json('{"foo": "bar" , "baz": "qux"}') == True #normal multiple case
    assert is_json('foo') == False #not json case
    assert is_json('["foo", {"bar": "baz"}]') == True #list case

# Generated at 2022-06-12 07:14:13.481458
# Unit test for function is_json
def test_is_json():
    assert not is_json("{}")
    assert not is_json("[]")


# Generated at 2022-06-12 07:14:17.760724
# Unit test for function is_json
def test_is_json():
    json_string = '{"name": "Peter"}'
    assert is_json(json_string) == True
    json_string = '[1, 2, 3]'
    assert is_json(json_string) == True
    json_string = '{nope}'
    assert is_json(json_string) == False


# Generated at 2022-06-12 07:14:27.493521
# Unit test for function is_url
def test_is_url():
    from .testing import make_test_check

    make_test_check(False, [None, '', 'mysite.com'])
    make_test_check(True, ['http://www.mysite.com', 'https://mysite.com', 'http://192.168.0.60/test.html', 'http://mysite.com.au/test.html',
                           'http://www.mysite.com/test.html', 'https://www.mysite.com/test.html'])
    make_test_check(False, ['www.mysite.com', 'mysite'])



# Generated at 2022-06-12 07:14:44.956425
# Unit test for function is_email
def test_is_email():
    assert not is_email(None)
    assert not is_email('')
    assert not is_email(' ')
    assert not is_email('myemail@')
    assert not is_email('myemail@.')
    assert not is_email('@gmail.com')
    assert not is_email('my email@gmail.com')
    assert not is_email('.myemail@gmail.com')
    assert not is_email('my email@gmail.com')
    assert not is_email('me@a.b..c')
    assert not is_email('me@gmail.com.')
    assert is_email('myemail@gmail.com')
    assert is_email('a.b.c@gmail.com')
    assert is_email('a-b.c@gmail.com')

# Generated at 2022-06-12 07:14:55.956818
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert(is_ip_v4('192.168.0.1'))
    assert(is_ip_v4('0.0.0.0'))
    assert(is_ip_v4('10.244.116.40'))
    assert(not is_ip_v4('10.244.116.400'))
    assert(not is_ip_v4('10.244.116.4.0'))
    assert(not is_ip_v4('10.244.116.4 0'))
    assert(not is_ip_v4('10.244.116.4 '))
    assert(not is_ip_v4('1010.244.116.4'))
    assert(not is_ip_v4('10.2441.116.4'))

# Generated at 2022-06-12 07:14:57.571089
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4("255.200.100.75")

# Generated at 2022-06-12 07:15:01.013705
# Unit test for function is_email
def test_is_email():
    print(is_email('_Abcdefghijklmnopqrstuvwxyz@gmail.com'))

test_is_email()


# Generated at 2022-06-12 07:15:11.926401
# Unit test for function is_email
def test_is_email():
    assert is_email('first.last@server.com')
    assert is_email('first.last+tag@gmail.com')
    assert is_email('first.last@the-provider.com')
    assert is_email('first.last@the_provider.com')
    assert is_email('first.last@the-prov.ider.com')
    assert is_email('first.last@the-prov.i.der.com')
    assert is_email('first.last@the-prov.i-der.com')
    assert is_email('first.last@the-prov.ider.')
    assert is_email('first.last@.provider.com')
    assert is_email('-@server.com')
    assert is_email('_@server.com')

# Generated at 2022-06-12 07:15:13.597019
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('1234567890128').is_isbn_13()

# Generated at 2022-06-12 07:15:17.666302
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    isbn_checker = __ISBNChecker('0817402775', True)
    result = isbn_checker.is_isbn_10()
    assert isinstance(result, bool)
    assert result == True

# Generated at 2022-06-12 07:15:19.679618
# Unit test for function is_email
def test_is_email():
    assert is_email("my.email@the-provider.com") == True
    assert is_email("@gmail.com") == False


# Generated at 2022-06-12 07:15:31.459014
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert not is_email('@gmail.com')
    assert not is_email('no-domain.com')
    assert not is_email('no-user@')
    assert not is_email('@')
    assert not is_email('no-domain')
    assert not is_email('no-user@')
    assert not is_email('no-user@no-domain')
    assert is_email('"my.email"@the-provider.com')
    assert is_email('"my.email"@the-provider.com')
    assert is_email('"my.email"@the-provider.com')
    assert is_email(r'i\ need\@escaping@the-provider.com')

# Generated at 2022-06-12 07:15:36.744441
# Unit test for function is_email
def test_is_email():
    import re
    import pytest
    email_address = input('please enter your email address')
    assert re.match(EMAIL_RE, email_address)
    with pytest.raises(Exception):
        is_email(email_address)



# Generated at 2022-06-12 07:15:43.875244
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')==True
    assert is_email('my.email@the-provider.com')!=False
    assert is_email('@gmail.com')==False
    assert is_email(1)==False

# Generated at 2022-06-12 07:15:46.607800
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-12 07:15:56.462546
# Unit test for function is_email
def test_is_email():
    assert is_email("mohamed.gomaa@gmail.com") == True , "Error in test_is_email"
    assert is_email("mohamed.gmail.com") == False , "Error in test_is_email"
    assert is_email("mohamed.gomaa@gmail") == False , "Error in test_is_email"        
    assert is_email("gmail.com") == False , "Error in test_is_email"
    assert is_email("mohamed.gomaa@gmail.") == False , "Error in test_is_email"
    assert is_email("mohamed.gomaa@1gmail.com") == False , "Error in test_is_email"

# Generated at 2022-06-12 07:16:07.573867
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-0-306406-15-7').is_isbn_13() == True
    assert __ISBNChecker('978-3-16-148410-0').is_isbn_13() == True
    assert __ISBNChecker('978-0-306406-15-8').is_isbn_13() == False
    assert __ISBNChecker('978-0-306406-15').is_isbn_13() == False
    assert __ISBNChecker('978-0-306406-15-f').is_isbn_13() == False
    assert __ISBNChecker('978-0-306406-15-o').is_isbn_13() == False



# Generated at 2022-06-12 07:16:12.018625
# Unit test for function is_json
def test_is_json():
    assert is_json("{'name': 'Peter'}") is True
    assert is_json("[1, 2, 3]") is True
    assert is_json("{nope}") is False


# Generated at 2022-06-12 07:16:15.742637
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}')
    assert is_json('[1, 2, 3]')
    assert not is_json('{nope}')
    assert not is_json('')
    assert not is_json('   ')



# Generated at 2022-06-12 07:16:18.259943
# Unit test for function is_email
def test_is_email():
    assert is_email('foo@gmail.com')
    assert not is_email('foo@bar')


# Generated at 2022-06-12 07:16:26.000714
# Unit test for function is_email
def test_is_email():
    assert is_email("something@gmail.com") is True
    assert is_email("something@.gmail.com") is False
    assert is_email("something@gmail.com.") is False
    assert is_email("something.@gmail.com") is False
    assert is_email("somethinggmail.com") is False
    assert is_email("something@gmailcom") is False
    assert is_email("something @gmail.com") is False
    assert is_email("some thing@gmail.com") is False
    assert is_email("some thing@gm ail.com") is True
    assert is_email("some thing@gm.ail.com") is True
    assert is_email("some thing@gm..ail.com") is False
    assert is_email("some thing@gm\\.ail.com") is True


# Generated at 2022-06-12 07:16:30.274278
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True, 'should return True if string is a valid JSON'
    assert is_json('{nope}') == False, 'should return False if string is not a valid JSON'
test_is_json()


# Generated at 2022-06-12 07:16:35.872663
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('192.168.0.1')
    assert not is_ip_v4('192.168.0.1.2')
    assert not is_ip_v4('1.2.3')
    assert not is_ip_v4('hello')
    assert not is_ip_v4('192.168.0.1.2')
    assert not is_ip_v4('192.168.0.1.2')

# Generated at 2022-06-12 07:16:42.661100
# Unit test for function is_email
def test_is_email():
    #print(is_email('a_b@gmail.com'))
    return is_email('a_b@gmail.com')
print(test_is_email())



# Generated at 2022-06-12 07:16:54.160291
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    # Valid ISBN-13
    assert __ISBNChecker('978-1-4231-1342-4').is_isbn_13() is True
    assert __ISBNChecker('978-1-4231-1342-4', normalize=False).is_isbn_13() is True
    assert __ISBNChecker('9781423113424').is_isbn_13() is True
    assert __ISBNChecker('9781423113424', normalize=False).is_isbn_13() is True

    # Invalid ISBN-13
    assert __ISBNChecker('978-1-4231-1342-2').is_isbn_13() is False
    assert __ISBNChecker('978-1-4231-1342-2', normalize=False).is_isbn_13() is False


# Generated at 2022-06-12 07:17:03.672303
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker("9781617294433").is_isbn_13() is True
    assert __ISBNChecker("978-1617294433").is_isbn_13() is True
    assert __ISBNChecker("9781617294434").is_isbn_13() is False
    assert __ISBNChecker("978-1617294434").is_isbn_13() is False
    assert __ISBNChecker("9781-617294434").is_isbn_13() is False
    assert __ISBNChecker("978-16172944339").is_isbn_13() is False
    assert __ISBNChecker("978-161729443").is_isbn_13() is False


# Generated at 2022-06-12 07:17:11.513188
# Unit test for function is_email
def test_is_email():
    assert is_email('asd@abc.com')
    assert is_email('12345@abc.com')
    assert is_email('_-123-@abc.com')
    assert is_email('a_b._c@abc.com')
    assert is_email('a-b.c@abc.com')
    assert is_email('a.b-c@abc.com')
    assert is_email('a.b_c@abc.com')
    assert is_email('a.b.c@abc.com')
    assert is_email('a.b-c@abc.com')
    assert is_email('.a.b-c@abc.com')
    assert not is_email('a@b')
    assert not is_email('@abc.com')

# Generated at 2022-06-12 07:17:16.717160
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0747532699').is_isbn_10() is True
    assert __ISBNChecker('0451526538').is_isbn_10() is True
    assert __ISBNChecker('045152653X').is_isbn_10() is True
    assert __ISBNChecker('0451526543').is_isbn_10() is True
    assert __ISBNChecker('045152655').is_isbn_10() is False
    assert __ISBNChecker('04515265q').is_isbn_10() is False


# PUBLIC API



# Generated at 2022-06-12 07:17:24.947804
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker("9780201485677").is_isbn_10()
    assert __ISBNChecker("957-661-409-2").is_isbn_10()
    assert __ISBNChecker("9576614092").is_isbn_10()
    assert not __ISBNChecker("0596802447").is_isbn_10()
    assert not __ISBNChecker("").is_isbn_10()
    assert not __ISBNChecker("random string").is_isbn_10()
    assert not __ISBNChecker(1234567890).is_isbn_10()


# Generated at 2022-06-12 07:17:27.758288
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0596527500').is_isbn_10() is True
    assert __ISBNChecker('596527500').is_isbn_10() is False
    assert __ISBNChecker(9573317249).is_isbn_10() is False

# Generated at 2022-06-12 07:17:31.231824
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    isbn_checker = __ISBNChecker('9780134190440')
    assert isbn_checker.is_isbn_13() == True

# Generated at 2022-06-12 07:17:35.321392
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker("9780262033848").is_isbn_13()
    assert __ISBNChecker("978-0262033848").is_isbn_13()
    assert __ISBNChecker("978 0262033848").is_isbn_13()

    assert not __ISBNChecker("9780262033841").is_isbn_13()
    assert not __ISBNChecker("978 0262033841").is_isbn_13()
    assert not __ISBNChecker("978-0262033841").is_isbn_13()


# Generated at 2022-06-12 07:17:41.929872
# Unit test for function is_email
def test_is_email():
    assert is_email('email@domain.com')
    assert is_email('firstname.lastname@domain.com')
    assert is_email('email@subdomain.domain.com')
    assert is_email('firstname+lastname@domain.com')
    assert is_email('email@domain.name.com')
    assert is_email('1234567890@domain.com')
    assert is_email('email@domain-one.com')
    assert is_email('email@domain.name')
    assert is_email('email@domain.co.jp')
    assert is_email('firstname-lastname@domain.com')
    assert not is_email('plainaddress')
    assert not is_email('#@%^%#$@#$@#.com')
    assert not is_email('@domain.com')
   

# Generated at 2022-06-12 07:17:57.701596
# Unit test for function is_email
def test_is_email():
    emails = [
        "\"very.(),:;<>[]\\\".VERY.\\\"very@\\ \\\"very\\\".unusual\"@strange.example.com",
        "\"()<>[]:,;@\\\\\\\"!#$%&'-/=?^_`{}| ~.a\"@example.org",
        """much."()<>[]\,;:\\"!#$%&'-/=?^_`{}| ~.more\\"\\ unusual""@example.com""",
        "example-indeed@strange-example.com",
        "\"example-indeed@strange-example.com\"",
        "example@s.example",
        "\" \"@example.org"
    ]
    for email in emails:
        assert is_email(email)



# Generated at 2022-06-12 07:18:00.504713
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999')
    assert is_ip_v4('255.200.100.75')



# Generated at 2022-06-12 07:18:10.897802
# Unit test for function is_email
def test_is_email():
    # Tests that the function is_email returns the same value as
    # EmailTest.isCorrectEmail
    import numpy as np
    from EmailTest import EmailTest

    nb_tests = 1000
    str_length = np.random.randint(5, 50, size=nb_tests)

    for i in range(nb_tests):
        email = ''
        for j in range(str_length[i]):
            email += chr(np.random.randint(32, 127)) # Random character from ASCII table
        email = email.replace("'", "") # We do not want any apostrophes in the email

        # Test if the function returns the same value as EmailTest.isCorrectEmail

# Generated at 2022-06-12 07:18:16.341433
# Unit test for function is_json
def test_is_json():
    assert is_json('{}')
    assert is_json('[]')
    assert is_json('{"name": "David"}')
    assert is_json('[1, 2, 3]')
    assert not is_json('{nope}')
    assert not is_json('')
    assert not is_json(None)
    assert not is_json('{name: "David"}')

    # Exception testing
    try:
        is_json([]); assert False
    except TypeError:
        assert True



# Generated at 2022-06-12 07:18:22.355364
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-1-56619-909-4').is_isbn_13()

    assert not __ISBNChecker('978-1-56619-909-3').is_isbn_13()

    assert not __ISBNChecker('1').is_isbn_13()



# Generated at 2022-06-12 07:18:28.144302
# Unit test for function is_json
def test_is_json():
    assert is_json("{key1: yolo}") == False
    assert is_json("{}") == True
    assert is_json("[]") == True
    assert is_json("[1, 2, 3]") == True
    assert is_json("[\"1\", \"2\", \"3\"]") == True
    assert is_json("\"[1, 2, 3]\"") == False
    assert is_json(1) == False
    assert is_json("[1,]") == False
    assert is_json("{\"key\": \"value\", \"key2\": \"value2\"}") == True



# Generated at 2022-06-12 07:18:37.453299
# Unit test for function is_ip_v4
def test_is_ip_v4():
    for i in ["192.168.20.52", "10.0.0.22", "255.255.255.255", "0.0.0.0"]:
        assert is_ip_v4(i) == True
    for j in ["192.168.20.0.22", "256.0.0.1", "0.0.0.257", "192.256.0.1", "192.168.20.256", "192.168.20", "192.168.20.300"]:
        assert is_ip_v4(j) == False
    for k in [""] + [None]:
        assert is_ip_v4(k) == False

# Generated at 2022-06-12 07:18:41.172471
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False



# Generated at 2022-06-12 07:18:43.679613
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker("8376542278").is_isbn_10() == True
test___ISBNChecker_is_isbn_10()

# Generated at 2022-06-12 07:18:50.972938
# Unit test for function is_email
def test_is_email():
    assert(is_email('me@example.com') == True)
    assert(is_email('me+you@example.com') == True)
    assert(is_email('.me@example.com') == False)
    assert(is_email('me.@example.com') == False)
    assert(is_email('me@example.') == False)
    assert(is_email('me.@example.com.') == False)
    assert(is_email('example.com') == False)
    assert(is_email('me@example') == False)
    assert(is_email('me@exam@ple.com') == False)
    # checks quotes
    assert(is_email('"this is me"@example.com') == True)

# Generated at 2022-06-12 07:18:58.067221
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('9501418815').is_isbn_10() == True

test___ISBNChecker_is_isbn_10()

# Generated at 2022-06-12 07:19:02.815304
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    # ISBNS
    assert __ISBNChecker('3-16-148410-0').is_isbn_10()
    assert __ISBNChecker('3-16-148410-0', False).is_isbn_10()

    # Non-ISBNS
    assert not __ISBNChecker('3-16-148410', False).is_isbn_10()


# PUBLIC API



# Generated at 2022-06-12 07:19:10.542105
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    # test case #1
    checker = __ISBNChecker('9797375643359')
    assert checker.is_isbn_13() is True

    # test case #2
    checker = __ISBNChecker('9798420208232')
    assert checker.is_isbn_13() is True

    # test case #3
    checker = __ISBNChecker('978-3-16-148410-0')
    assert checker.is_isbn_13() is True

    # test case #4
    checker = __ISBNChecker('978-3-16-148410-9')
    assert checker.is_isbn_13() is False

    # test case #5

# Generated at 2022-06-12 07:19:17.965645
# Unit test for function is_email
def test_is_email():
    # test function
    def test_email(email):
        print("{} -> {}".format(email, is_email(email)))

    # test emails
    test_email('foo@bar.com')
    test_email('x@x.x')
    test_email('foo@bar.com.au')
    test_email('foo+bar@bar.com')
    test_email('hans.m端ller@test.com')
    test_email('hans@m端ller.com')
    test_email('test|123@m端ller.com')
    test_email('"foo\\@bar"@example.com')
    test_email('"test\\blah"@example.com')
    test_email('"test\\blah"@example.com')

# Generated at 2022-06-12 07:19:21.890595
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0141182806').is_isbn_10() == True
    assert __ISBNChecker('0380001757').is_isbn_10() == True
    assert __ISBNChecker('0380001758').is_isbn_10() == False


# Generated at 2022-06-12 07:19:34.177212
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('192.168.2.1')
    assert not is_ip_v4('192.168.2')
    assert not is_ip_v4('192.168.256.1')
    assert not is_ip_v4('26.18.116.82')
    assert is_ip_v4('26.18.116.82') is False
    assert is_ip_v4('192.168.2') is False
    assert is_ip_v4('192.168.256.1') is False
    assert is_ip_v4('0.0.0.0')
    assert is_ip_v4('255.255.255.255')
    assert is_ip_v4('127.0.0.1')

test_is_ip_v4()



# Generated at 2022-06-12 07:19:44.800180
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('"my.email"@the-provider.com')
    assert is_email('"my.email"@the-provider.com')
    assert is_email('"my email"@the-provider.com')
    assert is_email('first.last@the-provider.com')
    assert is_email('first_last@the-provider.com')
    assert is_email('first-last@the-provider.com')
    assert is_email('first\ last@the-provider.com')
    assert is_email('first.last@the-provider.com')
    assert is_email('first.last@the-provider.com')
    

# Generated at 2022-06-12 07:19:53.051279
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    checker = __ISBNChecker('3-16-148410-0', normalize=False)
    assert checker.is_isbn_10()

    checker = __ISBNChecker('0-321-14653-0', normalize=False)
    assert not checker.is_isbn_10()

    checker = __ISBNChecker('0-321@14653-0', normalize=False)
    assert not checker.is_isbn_10()

    checker = __ISBNChecker('0-321-146530', normalize=False)
    assert not checker.is_isbn_10()



# Generated at 2022-06-12 07:19:57.719362
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') # returns true
    assert is_json('[1, 2, 3]') # returns true
    assert not is_json('{nope}') # returns false
    assert not is_json(None) # returns false



# Generated at 2022-06-12 07:20:04.414438
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert not is_ip_v4('not an ip')
    assert not is_ip_v4('9.9.9.999')
    assert not is_ip_v4('999.999.999.999')
    assert not is_ip_v4(999)

    assert is_ip_v4('255.200.100.50')



# Generated at 2022-06-12 07:20:22.701259
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert is_ip_v4('127.0.0.1')
    assert is_ip_v4('192.168.1.1')
    assert is_ip_v4('192.168.10.1')
    assert is_ip_v4('192.168.100.1')
    assert is_ip_v4('192.168.100.11')
    assert not is_ip_v4('127.0.0.256')
    assert not is_ip_v4('127.0')
    assert not is_ip_v4('127.0..0')


# Generated at 2022-06-12 07:20:32.781970
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-2-1234-5680-3').is_isbn_13()
    assert __ISBNChecker('978 2 1234 5680 3').is_isbn_13()
    assert __ISBNChecker('9782123456803').is_isbn_13()
    # test fails
    assert not __ISBNChecker('9782123456802').is_isbn_13()
    with raises(InvalidInputError):
        __ISBNChecker(9782123456803)
    with raises(InvalidInputError):
        __ISBNChecker([])


# Generated at 2022-06-12 07:20:39.759563
# Unit test for function is_email

# Generated at 2022-06-12 07:20:47.867245
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('').is_isbn_10() is False
    assert __ISBNChecker('1234567').is_isbn_10() is False
    assert __ISBNChecker('12345678901').is_isbn_10() is False
    assert __ISBNChecker('12345678901234').is_isbn_10() is False
    assert __ISBNChecker('978-1234567890').is_isbn_10() is False
    assert __ISBNChecker('1234567890').is_isbn_10() is True
    assert __ISBNChecker('978-1234567897').is_isbn_10() is True


# Generated at 2022-06-12 07:20:50.882637
# Unit test for function is_json
def test_is_json():
    return is_json('{a:1}')
test_is_json()



# Generated at 2022-06-12 07:20:54.238000
# Unit test for function is_json
def test_is_json():
    assert is_json("{'name':'Peter'}")
    assert is_json("{}")
    assert is_json("[]")
    assert not is_json("{'name':'Peter'")
    assert not is_json("Peter")


# Generated at 2022-06-12 07:21:06.254830
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('9780553593716').is_isbn_13()
    assert __ISBNChecker('978-0553-59371-6').is_isbn_13()
    assert __ISBNChecker('9780553593716', normalize=False).is_isbn_13()
    assert not __ISBNChecker('9780553593715').is_isbn_13()
    assert not __ISBNChecker('978055359371').is_isbn_13()
    assert not __ISBNChecker('97805535937151').is_isbn_13()
    assert not __ISBNChecker('9780553593716').is_isbn_13()
    assert not __ISBNChecker('978055359371G').is_isbn_13()

    assert __

# Generated at 2022-06-12 07:21:13.044800
# Unit test for function is_email
def test_is_email():
    text = '123456'
    assert False == is_email(text)
    print(is_email(text))

    text = '123456@qq'
    assert False == is_email(text)
    print(is_email(text))

    text = '123456@gmail.com'
    assert True == is_email(text)
    print(is_email(text))

test_is_email()


# Visa, MasterCard, American Express, Diners Club, Discover, and JCB

# Generated at 2022-06-12 07:21:25.231528
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com'), 'my.email@the-provider.com'
    assert is_email('my.email.here@the-provider.com'), 'my.email.here@the-provider.com'
    assert is_email('my\\.email.here@the-provider.com'), 'my\\.email.here@the-provider.com'
    assert not is_email('my.email..here@the-provider.com'), 'my.email..here@the-provider.com'
    assert not is_email('@gmail.com'), '@gmail.com'
    assert not is_email('.my.email@the-provider.com'), '.my.email@the-provider.com'

# Generated at 2022-06-12 07:21:30.800815
# Unit test for function is_email
def test_is_email():
    assert is_email('me@localhost')
    assert is_email('me@example.com')
    assert is_email('me.you@example.com')
    assert is_email('a.b@example.com')
    assert is_email('a.b.c@example.com')
    assert '@' in 'me@example.com'
    assert 'a' in 'me@example.com'
    assert not is_email('@example.com')
    assert not is_email('me.example.com')
    assert not is_email('me@.example.com')
    assert not is_email('me@example,com')
test_is_email()


# Generated at 2022-06-12 07:21:43.659015
# Unit test for function is_email
def test_is_email():
    assert is_email('hello@gmail.com')
    assert is_email('hello@gmail.com')
    assert is_email('hello+1@gmail.com')
    assert not is_email('@gmail.com')
    assert not is_email('hello@gmailcom')
    assert not is_email('hello@gmail.com.')
    assert not is_email('hello@gmail')

    # test with escaped quotes and escaped at-signs
    assert is_email('"John Doe"@gmail.com')
    assert is_email('John\ Doe@gmail.com')
    assert is_email('John" Doe"@gmail.com')
    assert is_email('John\\ Doe\\"@gmail.com')

    # test with escaped spaces
    assert is_email('"John Doe"@gmail.com')
    assert is_email

# Generated at 2022-06-12 07:21:50.582212
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert not is_email('.my.email@the-provider.com')
    assert not is_email('my.email.@the-provider.com')
    assert not is_email('my.email@the-provider..com')
    assert not is_email('my..email@the-provider.com')
    assert not is_email('.@gmail.com')
    assert not is_email('@gmail.com')
    assert not is_email('@')
    assert not is_email('@gmail')
    assert not is_email('domenico@example.com') # dot missing after domenico
    assert not is_email('a"very\\ unusual\\"@example.com') # space not accepted in the username

    assert is_email

# Generated at 2022-06-12 07:21:53.239467
# Unit test for function is_json
def test_is_json():
    assert is_json('{"Name": "Peter"}') == True
    assert is_json('{"Nope"}') == False
    assert is_json('name=Peter') == False


# Generated at 2022-06-12 07:22:04.128246
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('-738-45641-X').is_isbn_10()
    assert __ISBNChecker('7-0483-5495-1').is_isbn_10()
    assert __ISBNChecker('7-0483-5495-1').is_isbn_10()
    assert __ISBNChecker('7-0483-5495-1').is_isbn_10()
    assert __ISBNChecker('7-0483-5495-1').is_isbn_10()
    assert __ISBNChecker('7-0483-5495-1').is_isbn_10()
    assert __ISBNChecker('7-0483-5495-1').is_isbn_10()

# Generated at 2022-06-12 07:22:13.481980
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')# returns true
    assert is_email('@gmail.com')# returns false
    assert is_email('"name"@gmail.com')# returns true
    assert is_email('my..email@the-provider.com')# returns false
    assert is_email('"name1 name2"@test.com')# returns true
    assert is_email('name1" name2"@test.com')# returns false
    assert is_email('"name1\ name2"@test.com')# returns true
    assert is_email('name1\@" name2"@test.com')# returns false
    assert is_email('name1\@"name2"@test.com')# returns true
    assert is_email('@')# returns false