

# Generated at 2022-06-12 07:12:29.172748
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75')
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334')
    assert is_ip('1.2.3')



# Generated at 2022-06-12 07:12:41.921744
# Unit test for function is_email
def test_is_email():
    assert is_email(input_string='my.email@the-provider.com') == True
    assert is_email(input_string='my..email@the-provider.com') == False
    assert is_email(input_string='my.email@the-provider.c') == False
    assert is_email(input_string='my.email@the-provider.cm') == True
    assert is_email(input_string='my.email @the-provider.cm') == False
    assert is_email(input_string='.my.email@the-provider.com') == False
    assert is_email(input_string='my.email@the-provider.com.') == False
    assert is_email(input_string='my.email@the-provider.com_') == False
    assert is_

# Generated at 2022-06-12 07:12:54.533891
# Unit test for function is_credit_card
def test_is_credit_card():
    '''Test function is_credit_card
    '''
    assert is_credit_card("49854665545454545"),"check prefix"    
    assert is_credit_card("4985466554545454"),"check size"
    assert not is_credit_card("498546655454545"),"check size"
    assert is_credit_card("49854665545454545", card_type="VISA"), "check type"
    assert not is_credit_card("49854665545454545", card_type="MASTERCARD"), "check type"
    assert not is_credit_card("49854665545454545", card_type="DISCOVER"), "check type"


# Generated at 2022-06-12 07:13:05.052746
# Unit test for function is_palindrome
def test_is_palindrome():
    try:
        assert is_palindrome('otto') is True
        assert is_palindrome('ROTFL') is False
        assert is_palindrome('anno') is False
        assert is_palindrome('a nna') is False
        assert is_palindrome('a nna', ignore_spaces=True) is True
        assert is_palindrome('A nna', ignore_spaces=True, ignore_case=True) is True
        assert is_palindrome('2312') is False
        assert is_palindrome('23-12', ignore_spaces=True) is False
        assert is_palindrome('23-12', ignore_spaces=True, ignore_case=True) is True
    except:
        print('Got a false positive')

test_is_palindrome()
 

# Generated at 2022-06-12 07:13:08.272648
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    ISBN_CHECKER = __ISBNChecker('9781843548044')
    assert ISBN_CHECKER.is_isbn_13() == True



# Generated at 2022-06-12 07:13:16.287816
# Unit test for function is_palindrome
def test_is_palindrome():

    assert is_palindrome('LOL')  == True
    assert is_palindrome('Lol')  == False
    assert is_palindrome('Lol', ignore_case=True)  == True
    assert is_palindrome('ROTFL')  == False
    return True

if __name__ == '__main__':
    test_is_palindrome()


# Generated at 2022-06-12 07:13:26.041875
# Unit test for function is_credit_card
def test_is_credit_card():
    # valid
    assert is_credit_card('4111111111111111') # VISA
    assert is_credit_card('378282246310005') # AMERICAN_EXPRESS
    assert is_credit_card('30569309025904') # DINERS_CLUB
    assert is_credit_card('6011111111111117') # DISCOVER
    assert is_credit_card('3530111333300000') # JCB
    assert is_credit_card('5431111111111111') # MASTERCARD
    # invalid
    assert not is_credit_card('1')



# Generated at 2022-06-12 07:13:29.862830
# Unit test for function is_json
def test_is_json():
  #test that true is returned for valid json
  assert is_json('{"name": "Peter"}') == True
  #test that false is returned for invalid json
  assert is_json('{nope}') == False
test_is_json()



# Generated at 2022-06-12 07:13:34.573651
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580')
    assert is_isbn('1506715214')
    assert not is_isbn('150-6715214', normalize=False)

if __name__ == "__main__":
    test_is_isbn()

# Generated at 2022-06-12 07:13:36.608661
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')

# Generated at 2022-06-12 07:13:47.309770
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True, "test_is_json failed to return True when put a valid json"
    assert is_json('[1, 2, 3]') == True, "test_is_json failed to return True when put a valid json"
    assert is_json('{nope}') == False, "test_is_json failed to return False when put a invalid json"


# Version 4 and version 5 uuids

# Generated at 2022-06-12 07:13:57.484866
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    valid_isbn_10 = (
        '0-306-40615-?', '0 306 40615 2', '0306406152', '0-7645-0437-2',
        '0-7645-0437-X', '1853260087',  '1-853260-08-7',  '1853260-087',
        '1-853260-08-X', '978-1-56619-909-4', '9781566199094', '0-674-01753-6'
    )


# Generated at 2022-06-12 07:14:00.359567
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') # returns true
    assert not is_ip_v4('nope') # returns false (not an ip)
    assert not is_ip_v4('255.200.100.999') # returns false (999 is out of range)


# Generated at 2022-06-12 07:14:03.736161
# Unit test for function is_email
def test_is_email():
    assert len(re.findall("\w+\.\w+@\w+\.\w+", is_email("my.email@the-provider.com"))) > 0


# Generated at 2022-06-12 07:14:06.580234
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('42.0') == True
    assert is_decimal('42') == False


# Generated at 2022-06-12 07:14:16.836767
# Unit test for function is_email
def test_is_email():
    assert is_email("") == False
    assert is_email("a") == False
    assert is_email("ab") == False
    assert is_email("abc") == False
    assert is_email("abc@") == False
    assert is_email("abc@d") == False
    assert is_email("abc@de") == False
    assert is_email("abc@def") == False
    assert is_email("abc@def.") == False
    assert is_email("abc@def.a") == False
    assert is_email("abc@def.abc") == True
    assert is_email("abc@def.abcd") == True
    assert is_email("abc@def.abcde") == True
    assert is_email("abc@def.abcdef") == False
    assert is_email("abc@def.abcdefg")

# Generated at 2022-06-12 07:14:19.715773
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999')


# Generated at 2022-06-12 07:14:23.281615
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}')
    assert not is_json('ABC')
    assert is_json('[1, 2, 3]')
    assert not is_json('{nope}')
    assert not is_json('')
    assert not is_json(None)



# Generated at 2022-06-12 07:14:28.228770
# Unit test for function is_decimal
def test_is_decimal():
    try:
        print(is_decimal('-1.1'))
        print(is_decimal('-1.1'))
        print(is_decimal('1.1'))
        print(is_decimal('1e1'))
        print(is_decimal('1'))
        
    except InvalidInputError:
        print(InvalidInputError)




# Generated at 2022-06-12 07:14:39.153675
# Unit test for function is_email

# Generated at 2022-06-12 07:14:54.223983
# Unit test for function is_email
def test_is_email():
    assert is_email('') == False
    assert is_email('a@b.c') == True
    assert is_email('a@b.com') == True
    assert is_email('a.b@c.d.e.com') == True
    assert is_email('(comment)a@b.com') == True
    assert is_email('(comment)(comment)a@b.com') == True
    assert is_email('(comment)(comment)a@b.com.c') == False
    assert is_email('a@b.com.c.d') == False
    assert is_email('a@b.com.c.d.e') == False
    assert is_email('a@b-c.com') == True
    assert is_email('a@b-c.com.c') == False
   

# Generated at 2022-06-12 07:15:06.516320
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0306406152').is_isbn_10() == True
    assert __ISBNChecker('030640615X').is_isbn_10() == True
    assert __ISBNChecker('0380795272').is_isbn_10() == True
    assert __ISBNChecker('076790818X').is_isbn_10() == True
    assert __ISBNChecker('0306406181').is_isbn_10() == True
    assert __ISBNChecker('03807952').is_isbn_10() == False
    assert __ISBNChecker('03807952720').is_isbn_10() == False
    assert __ISBNChecker('03807952721').is_isbn_10() == False

# Generated at 2022-06-12 07:15:14.557033
# Unit test for function is_url

# Generated at 2022-06-12 07:15:16.716388
# Unit test for function is_url
def test_is_url():
    assert True == is_url('http://www.mysite.com')
    assert False == is_url('.mysite.com')



# Generated at 2022-06-12 07:15:22.984924
# Unit test for function is_json
def test_is_json():
    assert(is_json("{}"))
    assert(is_json("[]"))
    assert(is_json("{\"name\":\"Peter\"}"))
    assert(is_json("{\"name\":\"Peter\",\"Age\":23}"))
    assert(not is_json("{name:Peter}"))
    assert(not is_json(""))
    assert(not is_json("   "))
    assert(not is_json("\n"))
    assert(not is_json("\t"))



# Generated at 2022-06-12 07:15:26.480631
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-12 07:15:29.272964
# Unit test for function is_url
def test_is_url():
    assert is_url("https://www.google.com.vn/") == True



# Generated at 2022-06-12 07:15:32.474015
# Unit test for function is_url
def test_is_url():
    assert is_url('https://www.mysite.com')
    assert is_url('http://mysite.com', ['http'])
    assert not is_url('ftp://mysite.com', ['http'])



# Generated at 2022-06-12 07:15:37.524161
# Unit test for function is_email
def test_is_email():

    assert is_email('test@test.com') == True
    assert is_email('test@test.com') == True
    assert is_email('') == False



# Generated at 2022-06-12 07:15:47.272635
# Unit test for function is_url
def test_is_url():
    assert is_url('https://www.google.com')
    assert is_url('http://www.google.com')
    assert is_url('http://google.com')
    assert is_url('http://www.google.com/')
    assert is_url('http://www.google.com/abc/def')
    assert is_url('http://www.google.com/abc/def/')
    assert not is_url('')
    assert not is_url('https://g')
    assert not is_url('google.com')
    assert not is_url('google')
    assert not is_url('ftp://www.google.com')
    assert not is_url('www.google.com')
    assert not is_url('/abc/def')



# Generated at 2022-06-12 07:15:57.512656
# Unit test for function is_email
def test_is_email():
    assert is_email("test@test.com") == True
    assert is_email("firstname.lastname@domain.com") == True
    assert is_email("email@subdomain.domain.com") == True
    assert is_email("firstname+lastname@domain.com") == True
    assert is_email("email@123.123.123.123") == True
    assert is_email("email@[123.123.123.123]") == True
    assert is_email("“email”@domain.com") == True
    assert is_email("1234567890@domain.com") == True
    assert is_email("email@domain-one.com") == True
    assert is_email("_______@domain.com") == True
    assert is_email("email@domain.name") == True
    assert is_

# Generated at 2022-06-12 07:16:01.006037
# Unit test for function is_email
def test_is_email():
    print(is_email('my.email@the-provider.com'))
    print(is_email('@gmail.com'))
    print(is_email('"\\@"@gmail.com'))



# Generated at 2022-06-12 07:16:06.905003
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    input_string_1 = '1234567890123'
    input_string_2 = '978080442957'
    input_string_3 = '9781843560283'

    checker = __ISBNChecker(input_string_1)
    assert_condition = checker.is_isbn_13()

    assert assert_condition == True

# Generated at 2022-06-12 07:16:17.462004
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0981215309').is_isbn_10() == True
    assert __ISBNChecker('0789726240').is_isbn_10() == True
    assert __ISBNChecker('0596002815').is_isbn_10() == True
    assert __ISBNChecker('0201544683').is_isbn_10() == True
    assert __ISBNChecker('0321125215').is_isbn_10() == True
    assert __ISBNChecker('09812153095').is_isbn_10() == False
    assert __ISBNChecker('0').is_isbn_10() == False
    assert __ISBNChecker('0123456789').is_isbn_10() == False


# Generated at 2022-06-12 07:16:25.680866
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('myemail@the-provider.com')
    assert is_email('my+email@the-provider.com')
    assert is_email('my.email+something@the-provider.com')
    assert is_email('something.my.email@the-provider.com')
    assert is_email('my.email+something@the-provider.com')
    assert is_email('"my.email"@the-provider.com')
    assert is_email('my\.email@the-provider.com')
    assert is_email('my\.email+test@the-provider.com')
    assert is_email('"something\.my\.email"@the-provider.com')

# Generated at 2022-06-12 07:16:28.000623
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('9780306406157').is_isbn_10() == True



# Generated at 2022-06-12 07:16:33.839390
# Unit test for function is_json
def test_is_json():
    assert is_json('{"key": "value"}') == True # Test case 1
    assert is_json('{"key": "value"}') == True # Test case 2
    assert is_json('{"key": "value"}') == True # Test case 3
    # False cases
    assert is_json('{"key": "value"}') == False
    assert is_json('{"key" "value"}') == False
    assert is_json('{"key": "value"}') == False


# Generated at 2022-06-12 07:16:37.986481
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('joe.foo@microsoft.com') == True
    assert is_email('my.email.the-provider.com') == False
    assert is_email('@gmail.com') == False
    assert is_email('joe.foo@microsoft') == False

# Generated at 2022-06-12 07:16:44.915662
# Unit test for function is_email
def test_is_email():
    assert is_email("my.email@the-provider.com")
    assert is_email("my_email@the-provider.com")
    assert is_email("my_email@the-provider-local.com")
    assert is_email("my$email@the-provider-local.com")
    assert is_email("my$email@the-provider-local.co.uk")
    assert is_email("myemail@the-provider-local.co.uk")
    assert not is_email("my_email")
    assert not is_email("my$email")
    assert not is_email("my_email.com")
    assert not is_email("my_email@")
    assert not is_email("myemail@the-provider")
    assert not is_email("@gmail.com")


# Generated at 2022-06-12 07:16:56.265721
# Unit test for function is_email
def test_is_email():
    import random
    import unittest
    
    # list of valid emails taken from 
    # https://mailcheck.github.io/demo/

# Generated at 2022-06-12 07:17:03.709726
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert True == is_ip_v4('255.200.100.75')
    assert False == is_ip_v4('nope')
    assert False == is_ip_v4('255.200.100.999')


# Generated at 2022-06-12 07:17:10.097530
# Unit test for function is_json
def test_is_json():
    assert is_json("{'nope': 'nothing'}") == False
    assert is_json("[1,3,5]") == True
    assert is_json("") == False
    assert is_json("{'name': 'Lala'}") == True
    assert is_json("{}") == True
    assert is_json("[{'name': 'Lala'}]") == True
    assert is_json('{"name": "Peter"}') == True
    assert is_json('{"name" "Peter"}') == False
    assert is_json('{"name": "Peter", "age": 34}') == True
    assert is_json('[{"name": "Peter", "age": 34}, {"name": "Bob"}]') == True
    assert is_json('[1,2,3]') == True



# Generated at 2022-06-12 07:17:15.808703
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False
test_is_ip_v4()



# Generated at 2022-06-12 07:17:25.906494
# Unit test for function is_email
def test_is_email():
    from Utils.TestUtils import TestUtils
    from re import search

    assert not is_email(None)
    assert not is_email('')
    assert not is_email('  ')
    assert not is_email('name@domain.com.')
    assert not is_email('@domain.com.')
    assert not is_email('.name@domain.com.')
    assert not is_email('name..name@domain.com.')
    assert not is_email('name@domain@domain.com.')
    assert not is_email('name')
    assert not is_email('name@.com')
    assert not is_email('foo@bar.com ')
    assert not is_email(' foo@bar.com')
    assert not is_email('\tfoo@bar.com')

# Generated at 2022-06-12 07:17:32.713480
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('9780306406157').is_isbn_10() is False
    assert __ISBNChecker('0306406152').is_isbn_10() is True
    assert __ISBNChecker('030640615X').is_isbn_10() is False



# Generated at 2022-06-12 07:17:38.012140
# Unit test for function is_json
def test_is_json():
    assert not is_json(None)
    assert not is_json('')
    assert not is_json('{}')
    assert not is_json('{')
    assert not is_json('}')
    assert not is_json('{:')
    assert is_json('{}')
    assert is_json('[]')
    assert is_json('{"a": "b"}')



# Generated at 2022-06-12 07:17:48.759467
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    checker = __ISBNChecker('91-7373-0897-6')
    assert checker.is_isbn_10() is False
    assert checker.is_isbn_13() is False

    checker.input_string = '91-7373-0897-7'
    assert checker.is_isbn_10() is False
    assert checker.is_isbn_13() is False

    checker.input_string = '91737308977'
    assert checker.is_isbn_10() is False
    assert checker.is_isbn_13() is True

    checker.input_string = '978-3-16-148410-0'
    assert checker.is_isbn_10() is False
    assert checker.is_isbn_13() is True

# Generated at 2022-06-12 07:17:58.586072
# Unit test for function is_email
def test_is_email():
    assert is_email('example@domain.com') == True
    assert is_email('example@domain.gov') == True
    assert is_email('my.example@domain.gov') == True
    assert is_email('firstname.lastname@domain.gov') == True
    assert is_email('firstname-lastname@domain.gov') == True
    assert is_email('firstname+lastname@domain.gov') == True
    assert is_email('firstname_lastname@domain.gov') == True
    assert is_email('firstname_lastname@domain.name.gov') == True
    assert is_email('firstname.lastname+subject@domain.name.gov') == True
    assert is_email('firstname.lastname+subject@domain.com') == True

# Generated at 2022-06-12 07:18:01.865546
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4("0.0.0.0")
    assert not is_ip_v4("256.256.256.256")

# Generated at 2022-06-12 07:18:05.573577
# Unit test for function is_email
def test_is_email():
    assert is_email("my.email@the-provider.com") == True
    assert is_email("@gmail.com") == False
    assert is_email("email.gmail@gmail") == True
# Test output
print("Test is_email: PASSED")


# Generated at 2022-06-12 07:18:15.723873
# Unit test for function is_json
def test_is_json():
    # TODO: find a way to mock json.loads
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False



# Generated at 2022-06-12 07:18:25.165285
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():

    checker = __ISBNChecker('9788328032242')
    assert checker.is_isbn_13() == True

    checker = __ISBNChecker('978-1-56619-909-4')
    assert checker.is_isbn_13() == True

    checker = __ISBNChecker('978832803224')
    assert checker.is_isbn_13() == False

    checker = __ISBNChecker('978832803224A')
    assert checker.is_isbn_13() == False

    checker = __ISBNChecker('978-1-56619-909-4', False)
    assert checker.is_isbn_13() == False



# Generated at 2022-06-12 07:18:28.819065
# Unit test for function is_email
def test_is_email():
    assert(is_email('my.email@the-provider.com') == True)
    assert(is_email('@gmail.com') == False)



# Generated at 2022-06-12 07:18:37.202891
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    from unittest import TestCase, main
    from random import randint

    class Test(TestCase):
        def setUp(self):
            pass

        def test_is_isbn_10_valid(self):
            input_string = '0132350882'
            output_string = __ISBNChecker(input_string).is_isbn_10()
            self.assertTrue(output_string)

        def test_is_isbn_10_invalid(self):
            input_string = '0132350881'
            output_string = __ISBNChecker(input_string).is_isbn_10()
            self.assertFalse(output_string)

    main()



# Generated at 2022-06-12 07:18:38.253839
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker("123456789").is_isbn_10() == True

# Generated at 2022-06-12 07:18:43.567382
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-0-306-40615-7').is_isbn_13() is True
    assert __ISBNChecker('0-306-40615-2').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-7', normalize=False).is_isbn_13() is False


# Generated at 2022-06-12 07:18:48.192342
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False
    print('Success: test_is_ip_v4')


# Generated at 2022-06-12 07:18:51.945660
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False

test_is_ip_v4()


# Generated at 2022-06-12 07:19:00.705012
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('0-4351-5112-X').is_isbn_13() == True
    assert __ISBNChecker('978-4351-5112-X').is_isbn_13() == True
    assert __ISBNChecker('978-4351-5112-1').is_isbn_13() == False
    assert __ISBNChecker('978-4351-5112-X').is_isbn_13() == True
    assert __ISBNChecker('978-4351-5112-X', normalize=False).is_isbn_13() == False


# Generated at 2022-06-12 07:19:08.793184
# Unit test for function is_email
def test_is_email():
    assert is_email('info@acme.com') is True
    assert is_email('info[at]acme.com') is False
    assert is_email('info@acme.com') is True
    assert is_email('info@acme.com.net') is True
    assert is_email('info@acme.subdomain.com') is True
    assert is_email('info+mailing@acme.com') is True
    assert is_email('info.myname@acme.com') is True
    assert is_email('info.my.name@acme.com') is True
    assert is_email('info.my.name@subdomain.acme.com') is True
    assert is_email('info.my-name@subdomain.acme.com') is True

# Generated at 2022-06-12 07:19:24.597348
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-0-306-40615-7').is_isbn_13()
    assert __ISBNChecker('978-0306406157').is_isbn_13()
    assert __ISBNChecker('9780306406157').is_isbn_13()
    assert not __ISBNChecker('978-0-306-40615-5').is_isbn_13()
    assert not __ISBNChecker('978-0-306-40615-1').is_isbn_13()
    assert not __ISBNChecker('978-46-2').is_isbn_13()
    assert not __ISBNChecker('97846').is_isbn_13()
    assert not __ISBNChecker('978-46').is_isbn_13()
    assert not __ISBNCheck

# Generated at 2022-06-12 07:19:32.661449
# Unit test for function is_json
def test_is_json():
    # test cases
    print ("testing is_json()")
    print (is_json('{"name": "Peter"}'))
    print (is_json('[1, 2, 3]'))
    print (is_json('{nope}'))
    print ("====")
    # test empty input
    print ("testing is_json() for empty input")
    print (is_json(''))
    print ("====")



# Generated at 2022-06-12 07:19:34.509265
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') is True
    assert is_email('@gmail.com') is False


# Generated at 2022-06-12 07:19:44.863223
# Unit test for function is_email
def test_is_email():
    assert(is_email("louise.smith@gmail.com"))
    assert(is_email("louise.smith@gmail.com.uk"))
    assert(not is_email("@gmail.com"))
    assert(not is_email(""))
    assert(not is_email("louise.smith@.com"))
    assert(not is_email("louise.smith@gmail..com"))
    assert(not is_email("louise.smith@@gmail.com"))
    assert(not is_email("louise.smith@gmail.com@gmail.com"))
    assert(is_email("louise.smith@gmail.com."))
    assert(not is_email("louise.smith@gmail.com.."))
    assert(is_email("matthew.jones@gmail.co"))


# Generated at 2022-06-12 07:19:53.111412
# Unit test for function is_json
def test_is_json():
    print("inside test_is_json(), input_string is not a string")
    try:
        is_json(None)
    except Exception as e:
        print(e.__class__.__name__)
    print("inside test_is_json(), input_string is passed as a list.")
    try:
        is_json([])
    except Exception as e:
        print(e.__class__.__name__)
    print("inside test_is_json(), input_string is passed as an object.")
    try:
        is_json(object)
    except Exception as e:
        print(e.__class__.__name__)



# Generated at 2022-06-12 07:20:01.908390
# Unit test for function is_email

# Generated at 2022-06-12 07:20:09.432601
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0').is_isbn_10() == True
    assert __ISBNChecker('1').is_isbn_10() == False
    assert __ISBNChecker('1234567891').is_isbn_10() == True
    assert __ISBNChecker('1234567892').is_isbn_10() == False
    assert __ISBNChecker('3').is_isbn_10() == False
    assert __ISBNChecker('a').is_isbn_10() == False
    assert __ISBNChecker('1111111111').is_isbn_10() == False


# Generated at 2022-06-12 07:20:20.787532
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('1234567890123').is_isbn_13()
    assert __ISBNChecker('978-0-306-40615-7',normalize=False).is_isbn_13()
    assert not __ISBNChecker('978-0-306-40615-7').is_isbn_13()
    assert not __ISBNChecker('12345678901234').is_isbn_13()
    assert not __ISBNChecker('1234567890123A').is_isbn_13()
    assert not __ISBNChecker('').is_isbn_13()
    assert not __ISBNChecker(None).is_isbn_13()
    try:
        __ISBNChecker(123)
    except InvalidInputError as e:
        assert True

# Generated at 2022-06-12 07:20:24.602593
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False
#test_is_ip_v4()



# Generated at 2022-06-12 07:20:36.761883
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert not is_email('@gmail.com')
    assert is_email('"email"@the-provider.com')
    assert is_email('\\"email\\"@the-provider.com')
    assert is_email('"email\\ with\\"space@the-provider.com')
    assert is_email('email.with.dots@the-provider.com')
    assert is_email('email"with"quotes@the-provider.com')
    assert is_email('email\\"with\\"quotes@the-provider.com')
    assert is_email('email\\.with"quotes"and.dots@the-provider.com')

# Generated at 2022-06-12 07:20:52.930697
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False
    
    print("test_is_json() passed")



# Generated at 2022-06-12 07:21:00.334879
# Unit test for function is_email
def test_is_email():
    assert(not is_email(None))
    assert(not is_email(''))
    assert(not is_email(' '))
    assert(not is_email('hello'))
    assert(not is_email('my.email@the-provider.com'))
    assert(not is_email('@gmail.com'))
    assert(not is_email("my.email@the-provider.com"))
    assert(is_email("my.email@the-provider.com"))
    assert(is_email("my.email@the-provider.com"))
    assert(is_email("my.email@the-provider.com"))
    assert(is_email("my.email@the-provider.com"))
    assert(is_email("my.email@the-provider.com"))

# Generated at 2022-06-12 07:21:05.368464
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('5477207964').is_isbn_13() == True
    assert __ISBNChecker('123456789X').is_isbn_13() == False
    assert __ISBNChecker('1234567890').is_isbn_13() == False

# Generated at 2022-06-12 07:21:08.284401
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999')


# Generated at 2022-06-12 07:21:15.951434
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    # IS 0000000014 and not 0000000000
    valid = '0133026886'
    assert __ISBNChecker(valid).is_isbn_10() is True, valid

    valid = '1879135786'
    assert __ISBNChecker(valid).is_isbn_10() is True, valid

    invalid = '1879135787'
    assert __ISBNChecker(invalid).is_isbn_10() is False, invalid

    invalid = '187913578'
    assert __ISBNChecker(invalid).is_isbn_10() is False, invalid

    invalid = '18791357881'
    assert __ISBNChecker(invalid).is_isbn_10() is False, invalid



# Generated at 2022-06-12 07:21:20.461840
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0-633-20990-5').is_isbn_10() == True
    assert __ISBNChecker('0-633-20995-5').is_isbn_10() == False

# Generated at 2022-06-12 07:21:29.243859
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('9780262121980').is_isbn_13() is True
    assert __ISBNChecker('97802621219809').is_isbn_13() is False
    assert __ISBNChecker('9780262121980').is_isbn_13(False) is True
    assert __ISBNChecker('97802621219809').is_isbn_13(False) is False
    assert __ISBNChecker('9780262121980', False).is_isbn_13() is True
    assert __ISBNChecker('97802621219809', False).is_isbn_13() is False
    assert __ISBNChecker('9780262121980', False).is_isbn_13(False) is True

# Generated at 2022-06-12 07:21:36.929955
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0439708184', normalize=False).is_isbn_10()
    assert not __ISBNChecker('0439708185', normalize=False).is_isbn_10()
    assert not __ISBNChecker('043970818', normalize=False).is_isbn_10()
    assert not __ISBNChecker('04397081843', normalize=False).is_isbn_10()


# PUBLIC API


# type check functions

# Generated at 2022-06-12 07:21:42.666318
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    input_list = [
        ("9780451450523", True),
        ("9780451450529", False),
        ("978045145052", False),
    ]

    for input_string, expected in input_list:
        result = __ISBNChecker(input_string).is_isbn_13()
        assert result == expected



# Generated at 2022-06-12 07:21:46.933483
# Unit test for function is_json
def test_is_json():
    assert is_json('[1,2,3]')
    assert is_json('{"name": "Peter"}')
    assert not is_json('{nope}')
    assert not is_json('{{' )
    assert not is_json('}}' )
    assert not is_json('{"name": "Peter", "a": 123,  "abc": 123}')


# Generated at 2022-06-12 07:22:15.565920
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4("192.168.1.1")
    assert not is_ip_v4("192.168.1.256")
    assert not is_ip_v4("192.168.1")
    assert not is_ip_v4("256.168.1.1")
    assert not is_ip_v4("192.168.1.-1")
    assert not is_ip_v4("192.168.ab.1")
