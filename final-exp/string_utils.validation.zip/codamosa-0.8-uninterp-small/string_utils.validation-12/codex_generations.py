

# Generated at 2022-06-26 01:52:26.424118
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75') == True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip('1.2.3') == False


# Generated at 2022-06-26 01:52:34.822994
# Unit test for function is_json
def test_is_json():
    if (is_json('') == True):
        raise Exception
    if (is_json(' ') == True):
        raise Exception
    if (is_json('{}') == False):
        raise Exception
    if (is_json('[]') == False):
        raise Exception
    if (is_json('{\"name\":\"Frank\"}') == False):
        raise Exception
    if (is_json('[1,2,3]') == False):
        raise Exception
    if (is_json('\"name\"') == False):
        raise Exception
    if (is_json('[]') == False):
        raise Exception



# Generated at 2022-06-26 01:52:44.024634
# Unit test for function is_json
def test_is_json():
    # Init
    str_0 = '{"name": "Peter"}'
    str_1 = '[1,2, 3]'
    str_2 = '{nope}'

    # Run
    bool_0 = is_json(str_0)
    bool_1 = is_json(str_1)
    bool_2 = is_json(str_2)

    # Check
    assert bool_0 == True
    assert bool_1 == True
    assert bool_2 == False


# Generated at 2022-06-26 01:52:50.767830
# Unit test for function is_ip_v4
def test_is_ip_v4():
    # Test 1
    input_string_1 = '255.200.100.75'
    expected_output_1 = True
    actual_output_1 = is_ip_v4(input_string_1)
    assert expected_output_1 == actual_output_1

    # Test 2
    input_string_2 = 'nope'
    expected_output_2 = False
    actual_output_2 = is_ip_v4(input_string_2)
    assert expected_output_2 == actual_output_2

    # Test 3: invalid IP address
    input_string_3 = '275.200.100.75'
    expected_output_3 = False
    actual_output_3 = is_ip_v4(input_string_3)
    assert expected_output_3 == actual_output_3


#

# Generated at 2022-06-26 01:52:53.377575
# Unit test for function is_ip
def test_is_ip():
    str_0 = 'vzRrT.rk.jn'
    bool_0 = is_ip(str_0)


# Generated at 2022-06-26 01:53:02.358363
# Unit test for function is_email
def test_is_email():
    str_0 = "julie@gmail.com"
    bool_0 = is_email(str_0)
    str_1 = "julie@gmail.com"
    bool_1 = is_email(str_1)
    str_2 = "julia.huang@gmail.com"
    bool_2 = is_email(str_2)
    str_3 = "julia.huang@gmail.com"
    bool_3 = is_email(str_3)
    str_4 = 'Brian\\" "The_Boss"\\"@work.com'
    bool_4 = is_email(str_4)
    str_5 = 'Brian\\" "The_Boss"\\"@work.com'
    bool_5 = is_email(str_5)

# Generated at 2022-06-26 01:53:13.417915
# Unit test for function is_url
def test_is_url():
    str_0 = 'pi'
    str_1 = 'http://www.python.org/'
    str_2 = 'pi.0'
    str_3 = '2.0'
    str_4 = 'http://localhost/'
    str_5 = 'http://localhost'
    str_6 = 'http://'
    str_7 = '3.0'
    str_8 = '2.0\\U'

    # Localhost test
    bool_0 = is_url(str_0)
    assert bool_0

    # Python test
    bool_1 = is_url(str_1)
    assert bool_1

    # Do not append position mark
    bool_2 = is_url(str_2)
    assert bool_2

    # Do not append position mark
    bool_3 = is_url

# Generated at 2022-06-26 01:53:18.657781
# Unit test for function is_json
def test_is_json():
    # Test 1
    str_0 = '{"name": "Peter"}'
    bool_0 = is_json(str_0)
    if bool_0 == True:
        print(True)
    else: 
        print(False)
    
    # Test 2
    str_1 = '[1, 2, 3]'
    bool_1 = is_json(str_1)
    if bool_1 == True:
        print(True)
    else: 
        print(False)

    # Test 3
    str_2 = '{nope}'
    bool_2 = is_json(str_2)
    if bool_2 == True:
        print(True)
    else: 
        print(False)

# Generated at 2022-06-26 01:53:29.953128
# Unit test for function is_json
def test_is_json():
    assert(not is_json(None))
    assert(not is_json(""))
    assert(is_json("{}"))
    assert(is_json("[]"))
    assert(is_json("{\"a\":1}"))
    assert(is_json("[\"a\":1]"))
    assert(not is_json("{a}"))
    assert(not is_json("[a]"))
    assert(not is_json("{a:1}"))
    assert(not is_json("[a:1]"))
    assert(not is_json("{\"a\":1,b:1}"))
    assert(not is_json("[\"a\":1,b:1]"))
    assert(not is_json("{a:1,b:2}"))

# Generated at 2022-06-26 01:53:35.169291
# Unit test for function is_json
def test_is_json():
    assert(is_json('{"name": "Peter"}') == True)
    assert(is_json('[1, 2, 3]') == True)
    assert(is_json('{nope}') == False)
    assert(is_json('{"name": "Peter",]') == False)
    assert(is_json('{"name": Peter"}') == False)


# Generated at 2022-06-26 01:53:57.482726
# Unit test for function is_credit_card
def test_is_credit_card():
    input_string_0 = "3714 49635398431"
    card_type_0 = "AMERICAN_EXPRESS"
    bool_0 = is_credit_card(input_string_0, card_type_0)


# Generated at 2022-06-26 01:54:05.768828
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    str_0 = 'G \t-Nm%H(p8Vemg'
    str_1 = 'G \t-NmH(p8Vemg'
    cheker_0 = __ISBNChecker(str_0)
    cheker_1 = __ISBNChecker(str_1)
    cheker_2 = __ISBNChecker(123)

    assert cheker_0.is_isbn_13()
    assert cheker_1.is_isbn_13()

    try:
        cheker_2.is_isbn_13()
        assert False
    except InvalidInputError:
        assert True



# Generated at 2022-06-26 01:54:08.096753
# Unit test for function is_json
def test_is_json():
    str_0 = '{"name": "Peter"}'
    bool_0 = is_json(str_0)
    assert bool_0 == True


# Generated at 2022-06-26 01:54:15.581169
# Unit test for function is_isbn
def test_is_isbn():
    str_0 = 'G \t-Nm%H(p8Vemg'
    bool_0 = is_isbn(str_0)

    str_1 = 'RdM'
    bool_1 = is_isbn(str_1)

    str_2 = '1a'
    bool_2 = is_isbn(str_2)

    str_3 = 'Eo98'
    bool_3 = is_isbn(str_3)

    str_4 = 'O'
    bool_4 = is_isbn(str_4)

    str_5 = '6'
    bool_5 = is_isbn(str_5)

    str_6 = 'n'
    bool_6 = is_isbn(str_6)

    str_7 = '6926Q'
    bool

# Generated at 2022-06-26 01:54:19.232552
# Unit test for function is_url
def test_is_url():
    assert(is_url('http://www.mysite.com') is True)
    assert(is_url('https://mysite.com') is True)
    assert(is_url('.mysite.com') is False)


# Generated at 2022-06-26 01:54:24.887911
# Unit test for function is_json
def test_is_json():
    print('\nUNIT TEST FOR is_json')
    str_0 = '{\"name\": \"Peter\"}'
    bool_0 = is_json(str_0)
    print(bool_0)

    str_1 = '[1, 2, 3]'
    bool_1 = is_json(str_1)
    print(bool_1)



# Generated at 2022-06-26 01:54:33.329593
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    # Check if length of input is not 13.
    obj___ISBNChecker_0 = __ISBNChecker('YYY9876543210')
    b___ISBNChecker_0 = obj___ISBNChecker_0.is_isbn_13()
    assert(b___ISBNChecker_0 == False)

    # Check if sum of weighted digits is not a multiple of 10.
    obj___ISBNChecker_1 = __ISBNChecker('9781234567897')
    b___ISBNChecker_1 = obj___ISBNChecker_1.is_isbn_13()
    assert(b___ISBNChecker_1 == False)

    # Check if one of the digits is not an integer.
    obj___ISBNChecker_2 = __ISBNChecker('9781234567890')
    b

# Generated at 2022-06-26 01:54:46.114824
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    # Case 1
    str_1 = '979-10-95546-07-8'
    bool_1 = __ISBNChecker(str_1).is_isbn_13()
    assert bool_1 == True

    # Case 2
    str_2 = '978-2-7605-1073-9'
    bool_2 = __ISBNChecker(str_2).is_isbn_13()
    assert bool_2 == True

    # Case 3
    str_3 = '978-2-1234-5680-3'
    bool_3 = __ISBNChecker(str_3).is_isbn_13()
    assert bool_3 == True

    # Case 4
    str_4 = '978-2-1234-5680-4'
    bool_4 = __ISBNCheck

# Generated at 2022-06-26 01:54:49.680384
# Unit test for function is_email
def test_is_email():
    str_1 = 'bA \t-yKVb~d"+Ch.5\t'
    bool_1 = is_email(str_1)


# Generated at 2022-06-26 01:54:55.616123
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    str_0 = '7648902834'
    obj_0 = __ISBNChecker(str_0)
    # Type test
    bool_0 = isinstance(obj_0, __ISBNChecker)
    # Method test
    bool_1 = obj_0.is_isbn_10()


##
# PUBLIC API
##

# Return True if input is a string, False otherwise

# Generated at 2022-06-26 01:55:02.914568
# Unit test for function is_isbn
def test_is_isbn():
    str_0 = 'aV6wQ&F\t-k!a@'
    bool_0 = is_isbn(str_0)


# Generated at 2022-06-26 01:55:12.779953
# Unit test for function is_json
def test_is_json():
    str_0 = '{"name": "Peter"}'
    str_1 = '[1, 2, 3]'
    str_2 = '{nope}'
    bool_0 = is_json(str_0)
    bool_1 = is_json(str_1)
    bool_2 = is_json(str_2)
    assert bool_0 == True, 'The output of "is_json" should be true'
    assert bool_1 == True, 'The output of "is_json" should be true'
    assert bool_2 == False, 'The output of "is_json" should be false'
    print('Test passed')


# Generated at 2022-06-26 01:55:17.618534
# Unit test for function is_credit_card
def test_is_credit_card():
        num_0 = 'G \t-Nm%H(p8Vemg'
        num_1 = 'H+I0d@{8?0WDF'
        assert is_credit_card(num_0) == False
        assert is_credit_card(num_1) == False


# Generated at 2022-06-26 01:55:22.555067
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    str_0 = '978-3-16-148410-0'
    string_checker = __ISBNChecker(str_0)
    bool_0 = string_checker.is_isbn_10()
    # AssertionError: assert False


# Generated at 2022-06-26 01:55:31.000833
# Unit test for function is_isbn
def test_is_isbn():
    is_isbn('lh1pM0b5cb8Z0W')
    is_isbn('1111111111111')
    is_isbn('Ux5xU1J6Z3fH')
   
    is_isbn('V7yfY6toR')
    is_isbn('NwKW8Zv7')
    is_isbn('QD5Y5K5N1')
    is_isbn('EdBzZgV6Jb')
    is_isbn('YWyawV7y')
    is_isbn('aTp1aS7')
    is_isbn('OJ3Y3s4s2')
    is_isbn('wZWb0F7')
    is_isbn('B0y0B8D7')


# Generated at 2022-06-26 01:55:42.773778
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    """__ISBNChecker is_isbn_13() unit test"""
    str_0 = '1935181881'
    str_1 = '0309062063'
    str_2 = '9780143105348'
    str_3 = '1400902308'
    str_4 = '0307388237'
    str_5 = '978-1-56619-909-4'
    str_6 = '0-393-04008-4'
    str_7 = '9780393040081'
    str_8 = '978-0143105348'
    str_9 = '978-0-393-04008-1'
    str_10 = '0-321-99278-4'
    str_11 = '978-0-306-40615-7'
    str_

# Generated at 2022-06-26 01:55:52.750317
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    str_1 = '3-598-21500-8'
    isbn_checker = __ISBNChecker(str_1)
    bool_1 = isbn_checker.is_isbn_10()

    str_2 = '978-3-598-21500-2'
    isbn_checker = __ISBNChecker(str_2)
    bool_2 = isbn_checker.is_isbn_10()

    str_3 = '1'
    isbn_checker = __ISBNChecker(str_3)
    bool_3 = isbn_checker.is_isbn_10()

    str_4 = 'G \t-Nm%H(p8Vemg'
    isbn_checker = __ISBNChecker(str_4)

# Generated at 2022-06-26 01:55:56.785250
# Unit test for function is_isbn
def test_is_isbn():
    # Test case 0
    str_0 = 'G \t-Nm%H(p8Vemg'
    bool_0 = is_isbn(str_0)
    # Test case 1
    str_1 = '<7`{C'
    bool_1 = is_isbn(str_1)
    # Test case 2
    str_2 = '2#nGmJy'
    bool_2 = is_isbn(str_2)
    # Test case 3
    str_3 = '[5y!G'
    bool_3 = is_isbn(str_3)
    # Test case 4
    str_4 = '5WNE'
    bool_4 = is_isbn(str_4)
    # Test case 5
    str_5 = 'HWq3T'
    bool

# Generated at 2022-06-26 01:56:04.078660
# Unit test for function is_credit_card
def test_is_credit_card():
    str_0 = '3714 496353 98431'
    # str_0 = '3714-496353-98431'
    # bool_0 = is_credit_card(str_0)
    bool_1 = is_credit_card(str_0, 'AMERICAN_EXPRESS')
    # print('bool_0:{}\nbool_1:{}'.format(bool_0, bool_1))



# Generated at 2022-06-26 01:56:10.327046
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Anna", "lastname": "Smith"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('[1,2,3]') == True
    assert is_json('{}') == True
    assert is_json('[') == False
    assert is_json('abc') == False
    assert is_json('{"name": "Anna", "lastname": "Smith"') == False


# Generated at 2022-06-26 01:56:24.466278
# Unit test for function is_credit_card
def test_is_credit_card():
    # Test case 1
    str_1 = '421222098675023'
    card_type_1 = 'VISA'
    bool_result_1 = is_credit_card(str_1,card_type_1)
    expected_1 = True
    assert bool_result_1 == expected_1
    # Test case 2
    str_2 = ' \t %KSD^Gd$XW'
    card_type_2 = None
    bool_result_2 = is_credit_card(str_2,card_type_2)
    expected_2 = False
    assert bool_result_2 == expected_2
    # Test case 3
    str_3 = '4398905282757345'
    card_type_3 = 'MASTERCARD'
    bool_result_3 = is_credit_

# Generated at 2022-06-26 01:56:28.190774
# Unit test for function is_json
def test_is_json():
    given = '[1,2,'
    expected = False

    result = is_json(given)

    assert expected == result


# Generated at 2022-06-26 01:56:38.760982
# Unit test for function is_email
def test_is_email():
    str_0 = '8W6U1C6/3G)on'
    bool_0 = is_email(str_0)
    print(bool_0)
    str_1 = 'B.1EI!8s!zPY'
    test_is_email.bool_1 = is_email(str_1)
    str_2 = '4,!k@V7$^[xM'
    test_is_email.bool_2 = is_email(str_2)
    str_3 = 'qN#@!1^lN/=g'
    test_is_email.bool_3 = is_email(str_3)
    str_4 = 'S.t\`7V&2iMh'

# Generated at 2022-06-26 01:56:41.363519
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    str_0 = 'G \t-Nm%H(p8Vemg'
    bool_0 = __ISBNChecker(str_0).is_isbn_10()


# Generated at 2022-06-26 01:56:48.972435
# Unit test for function is_email
def test_is_email():
    result = is_email("my.email@the-provider.com")
    expected_result = True
    if result == expected_result:
        print("=== Test case 0 passed ===")
        print(" my.email@the-provider.com is a valid email")
    else:
        print("=== Test case 0 failed ===")
        print("Expected: " + str(expected_result))
        print(", but result is " + str(result))


# Generated at 2022-06-26 01:56:49.933934
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    test_case_0()


# Generated at 2022-06-26 01:57:01.966259
# Unit test for function is_url
def test_is_url():
    str_0 = 'YuJwKR5'
    str_1 = 'http://www.foo.com/blah_blah'
    str_2 = 'http://www.foo.com/blah_blah_(wikipedia)'
    str_3 = 'http://www.foo.com/blah_blah_(wikipedia)_(again)'
    str_4 = 'http://www.foo.com/unicode_(✪)_in_parens'
    str_5 = 'http://www.foo.com/blah_(wikipedia)#cite-1'
    str_6 = 'http://www.foo.com/blah_(wikipedia)_blah#cite-1'
    str_7 = 'http://www.foo.com/unicode_(✪)_in_parens'

# Generated at 2022-06-26 01:57:09.732116
# Unit test for function is_email
def test_is_email():
    # Unit test for is_email
    EM_TEST_STRING = 'a@a.a'
    assert is_email(EM_TEST_STRING)
    EM_TEST_STRING = 'a@a.com'
    assert is_email(EM_TEST_STRING)
    EM_TEST_STRING = 'ab.cd@a.a'
    assert is_email(EM_TEST_STRING)
    EM_TEST_STRING = 'a..b.cd@a.a'
    assert is_email(EM_TEST_STRING)
    EM_TEST_STRING = 'a.b.cd@a.a'
    assert is_email(EM_TEST_STRING)
    EM_TEST_STRING = 'a.b.cd@a.com'

# Generated at 2022-06-26 01:57:11.744790
# Unit test for function is_email
def test_is_email():
    str_0 = '\t}-zRX'
    bool_0 = is_email(str_0)



# Generated at 2022-06-26 01:57:24.808986
# Unit test for function is_json
def test_is_json():
    input_string_0 = '{\"name\": \"John\"}'
    input_string_1 = '{\"1\"}'
    input_string_2 = []
    input_string_3 = 1
    input_string_4 = '{'
    expected_0 = True
    expected_1 = False
    expected_2 = False
    expected_3 = False
    expected_4 = False

    def assertions(actual_0, actual_1, actual_2, actual_3, actual_4, expected_0, expected_1, expected_2, expected_3, expected_4):
        assert actual_0 == expected_0
        assert actual_1 == expected_1
        assert actual_2 == expected_2
        assert actual_3 == expected_3
        assert actual_4 == expected_4

    # Define input arguments for

# Generated at 2022-06-26 01:57:37.766109
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('1.1.1.1') == True
    assert is_ip_v4('1.1.1') == False
    assert is_ip_v4('999.999.999.999') == False
    assert is_ip_v4('1.1.1.1.1') == False
    assert is_ip_v4('1.1.-1.1') == False
    assert is_ip_v4('1.1.1.1.1.1') == False
    assert is_ip_v4('1.1.1') == False
    assert is_ip_v4('172.16.254.1') == True
    assert is_ip_v4('54.77.78.110.1') == False

# Generated at 2022-06-26 01:57:42.291385
# Unit test for function is_email
def test_is_email():
    str_0 = 'A@B'
    bool_0 = is_email(str_0)
    str_1 = 'A@B'
    bool_1 = is_email(str_1)
    print(bool_0)
    print(bool_1)


# Generated at 2022-06-26 01:57:50.847821
# Unit test for function is_email
def test_is_email():
    bool_0 = is_email('?p')
    assert not bool_0
    bool_0 = is_email('$')
    assert not bool_0
    bool_0 = is_email('@gmail.com')
    assert not bool_0
    bool_0 = is_email('my.email@the-provider.com')
    assert bool_0


# Generated at 2022-06-26 01:57:53.744384
# Unit test for function is_email
def test_is_email():
    str1 = 'my.email@the-provider.com'
    assert(is_email(str1) == True)


# Generated at 2022-06-26 01:57:59.259900
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    str_0 = '978-351-601-08-3'
    bool_0 = __ISBNChecker(str_0).is_isbn_13()
    bool_1 = __ISBNChecker('978351601075').is_isbn_13()


# Generated at 2022-06-26 01:58:01.737708
# Unit test for function is_email
def test_is_email():
    str_0 = 'rW3kvOHjKGU'
    bool_0 = is_email(str_0)


# Generated at 2022-06-26 01:58:05.714620
# Unit test for function is_url
def test_is_url():
    str_0 = 'http://www.mysite.com'
    bool_0 = is_url(str_0)
    str_1 = 'https://mysite.com'
    bool_1 = is_url(str_1)
    str_2 = '.mysite.com'
    bool_2 = is_url(str_2)


# Generated at 2022-06-26 01:58:18.969209
# Unit test for function is_email
def test_is_email():
    str_0 = 'm>A:}\'|mvO_p0W8Y'
    bool_0 = is_email(str_0)
    print(bool_0)
    str_1 = '8R1e\'D7K_z\'.w5-5'
    bool_1 = is_email(str_1)
    print(bool_1)
    str_2 = '8R1e\'D7K_zkjU6^`'
    bool_2 = is_email(str_2)
    print(bool_2)
    str_3 = '8R1e\'D7K_zkjU6^`'
    bool_3 = is_email(str_3)
    print(bool_3)

# Generated at 2022-06-26 01:58:29.133941
# Unit test for function is_credit_card
def test_is_credit_card():
    str_0 = 'G \t-Nm%H(p8Vemg'
    str_1 = 'hX9{i`2'
    str_2 = 'k*hKw=iPp{'
    str_3 = 'X9{i`2'
    str_4 = 'iPp{'
    str_5 = '1'
    str_6 = '2'
    str_7 = '3'
    str_8 = '4'
    str_9 = '5'
    str_10 = '6'
    str_11 = '7'
    str_12 = '8'
    str_13 = '9'
    str_14 = '0'
    str_15 = 'a'
    str_16 = 'b'
    str_17 = 'c'
   

# Generated at 2022-06-26 01:58:37.167305
# Unit test for function is_email
def test_is_email():
    # Testing the first case
    # Should return False
    assert is_email("djh@gmail.com") == True

    # Testing the second case
    # Should return False
    assert is_email("djhgmail.com") == False

    # Testing the third case
    # Should return False
    assert is_email("@gmail.com") == False

     # Testing the fourth case
    # Should return False
    assert is_email("djh@gmail") == False

    # Testing the fifth case
    # Should return False
    assert is_email(".gmail.com") == False

    # Testing the sixth case
    # Should return False
    assert is_email("dj..h@gmail.com") == False

    # Testing the seventh case
    # Should return False

# Generated at 2022-06-26 01:58:45.143685
# Unit test for function is_email
def test_is_email():
    assert not is_email(None)
    assert not is_email('')
    assert is_email('my.email@the-provider.com')
    assert not is_email('@gmail.com')


# Generated at 2022-06-26 01:58:51.603639
# Unit test for function is_url
def test_is_url():
    str_0 = 'http://www.mysite.com'
    bool_0 = is_url(str_0)
    assert bool_0 == True
    str_1 = 'https://mysite.com'
    bool_1 = is_url(str_1)
    assert bool_1 == True
    str_2 = '.mysite.com'
    bool_2 = is_url(str_2)
    assert bool_2 == False


# Generated at 2022-06-26 01:59:01.106433
# Unit test for function is_url
def test_is_url():
    assert is_url('ftp://ftp.is.co.za/rfc/rfc1808.txt') == True
    assert is_url('http://www.ietf.org/rfc/rfc2396.txt') == True
    assert is_url('http://www.ietf.org/rfc/rfc2396.txt') == True
    assert is_url('http://www.example.com/scheme-list/') == True
    assert is_url('http://www.iana.org/assignments/uri-schemes.html') == True
    assert is_url('http://www.iana.org/assignments/uri-schemes.html') == True
    assert is_url('http://www.iana.org/assignments/uri-schemes.html') == True


# Generated at 2022-06-26 01:59:12.488596
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False
    assert is_json('{"foo": "bar", "baz": [1, 2, 3]}') == True
    assert is_json('{"foo": "bar", "baz": [1, 2, 3]') == False
    assert is_json('{"foo": "bar", "baz": [1, 2, 3}, "test": [1, 2, 3]}') == False
    assert is_json('{"foo": "bar", "baz": [1, 2, 3], "test": {"foo": "bar", "baz": [1, 2, 3]}}') == True

# Generated at 2022-06-26 01:59:16.646673
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    str_0 = '978-0-596-52068-7'
    mychecker = __ISBNChecker(str_0)
    mychecker.is_isbn_13()
    return True



# Generated at 2022-06-26 01:59:18.626059
# Unit test for function is_email
def test_is_email():
    str_0 = 'SX(}a'
    bool_0 = is_email(str_0)


# Generated at 2022-06-26 01:59:26.974637
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    str_0 = 'G \t-Nm%H(p8Vemg'
    checker_0 = __ISBNChecker(str_0, False)
    bool_0 = checker_0.is_isbn_13()
    assert not bool_0, f"Failed to check that ISBN '{str_0}' is not a valid ISBN 13"
    str_1 = '91234-567890-12'
    checker_1 = __ISBNChecker(str_1)
    bool_1 = checker_1.is_isbn_13()
    assert bool_1, f"Failed to check that ISBN '{str_1}' is a valid ISBN 13"


# Generated at 2022-06-26 01:59:29.871179
# Unit test for function is_json
def test_is_json():
    # Test case 0
    str_0 = 'd6J4PQq3AC'
    bool_0 = is_json(str_0)
    assert bool_0 == False



# Generated at 2022-06-26 01:59:34.414143
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') == True
    assert is_url('https://mysite.com') == True
    assert is_url('.mysite.com') == False

# End of Unit test for function is_url


# Generated at 2022-06-26 01:59:42.507000
# Unit test for function is_email
def test_is_email():
    assert(is_email('user@domain.com') == True)
    assert(is_email('user@domain.com\n') == False)
    assert(is_email('user@domain') == False)
    assert(is_email('user@domain.') == True)
    assert(is_email('user@domain.a') == True)
    assert(is_email('user@domain.a') == True)
    assert(is_email('user@domain.a') == True)



# Generated at 2022-06-26 02:00:00.032320
# Unit test for function is_json
def test_is_json():
    print("test is_json")
    str_0 = '[{"address": "123 main st", "phone": "123-456-7890", "name": "joe"}]'
    bool_0 = is_json(str_0)
    print('\t', bool_0)
    str_1 = '{"address": "123 main st", "phone": "123-456-7890", name: "joe"}'
    bool_1 = is_json(str_1)
    print('\t', bool_1)
    str_2 = '[{"address": "123 main st", "phone": "123-456-7890", "name": "joe"}]'
    bool_2 = is_json(str_2)
    print('\t', bool_2)

# Generated at 2022-06-26 02:00:07.998129
# Unit test for function is_json
def test_is_json():
    str_0 = '{"name": "Peter"}'
    bool_0 = is_json(str_0)
    str_1 = '[1, 2, 3]'
    bool_1 = is_json(str_1)
    str_2 = '{nope}'
    bool_2 = is_json(str_2)
    str_3 = '{"foo": "bar"}'
    bool_3 = is_json(str_3)


# Generated at 2022-06-26 02:00:16.451495
# Unit test for function is_ip_v4
def test_is_ip_v4():
    str_0 = '255.200.100.75'
    str_1 = 'nope'
    str_2 = '255.200.100.999'
    bool_0 = is_ip_v4(str_0)
    bool_1 = is_ip_v4(str_1)
    bool_2 = is_ip_v4(str_2)
    print(bool_0)
    print(bool_1)
    print(bool_2)
    return


# Generated at 2022-06-26 02:00:24.742153
# Unit test for function is_credit_card
def test_is_credit_card():
    cardNum_1 = '4942731362798620'
    cardNum_2 = '4388576018402626'
    cardNum_3 = '6011111111111117'
    cardNum_4 = '6011000990139424'
    cardNum_5 = '30569309025904'
    cardNum_6 = '3530111333300000'
    cardNum_7 = '3566002020360505'
    cardNum_8 = ''
    cardNum_9 = '4242424242424242'
    cardNum_10 = '2221001212222100'

    assert is_credit_card(cardNum_1, 'VISA')
    assert not is_credit_card(cardNum_2, 'VISA')

# Generated at 2022-06-26 02:00:37.292887
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    # Test 1
    str_0 = ''
    bool_0 = __ISBNChecker(str_0).is_isbn_13()
    # Assertion
    assert bool_0 == False, 'Result should be False'
    # Test 2
    str_0 = '_*(Uxk'
    bool_0 = __ISBNChecker(str_0).is_isbn_13()
    # Assertion
    assert bool_0 == False, 'Result should be False'
    # Test 3
    str_0 = '*yw)p# '
    bool_0 = __ISBNChecker(str_0).is_isbn_13()
    # Assertion
    assert bool_0 == False, 'Result should be False'
    # Test 4

# Generated at 2022-06-26 02:00:49.349118
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    str_0 = '0-306-40615-2'
    str_1 = '17292023614'
    str_2 = '979-10-910491-0'
    str_3 = '978-3-16-148410-0'
    str_4 = '9783161484100'
    bool_0 = __ISBNChecker(str_0).is_isbn_13()
    bool_1 = __ISBNChecker(str_1).is_isbn_13()
    bool_2 = __ISBNChecker(str_2).is_isbn_13()
    bool_3 = __ISBNChecker(str_3).is_isbn_13()
    bool_4 = __ISBNChecker(str_4).is_isbn_13()


# Generated at 2022-06-26 02:01:00.037037
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com.it')
    assert is_email('my.email@the-provider.info')
    assert is_email('my.email@the-provider.com.it.co.uk')
    assert is_email('my.email@the-provider.info.org.it')
    assert is_email('my.email@the-provider.com.co.uk.it')
    assert is_email('my.email@the-provider.info.org.it.co.uk')
    assert is_email('my-email@the-provider.com')
    assert is_email('my_email@the-provider.com')

# Generated at 2022-06-26 02:01:04.062841
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    str_0 = '978-0-306-40615-7'
    __ISBNChecker_0 = __ISBNChecker(str_0)
    bool_0 = __ISBNChecker_0.is_isbn_13()
    assert bool_0 == True



# Generated at 2022-06-26 02:01:06.243235
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False


# Generated at 2022-06-26 02:01:16.626765
# Unit test for function is_credit_card
def test_is_credit_card():
    str_0 = '371449635398431'
    str_1 = '378282246310005'
    str_2 = '6011111111111117'
    str_3 = '3530111333300000'
    str_4 = '5555555555554444'
    str_5 = '4916998639505382'
    str_6 = '4222222222222'
    str_7 = '371449635398431'
    str_8 = '378282246310005'
    str_9 = '6011111111111117'
    str_10 = '3530111333300000'
    str_11 = '5555555555554444'
    str_12 = '4916998639505382'

# Generated at 2022-06-26 02:01:31.745145
# Unit test for function is_credit_card
def test_is_credit_card():
    # Test case 0
    str_0 = 'G \t-Nm%H(p8Vemg'
    str_1 = 'VISA'
    bool_0 = is_credit_card(str_0, str_1)
    # Test case 1
    str_0 = '1E9}e'
    str_1 = 'AMERICAN_EXPRESS'
    bool_1 = is_credit_card(str_0, str_1)
    # Test case 2
    str_0 = 'Jh&3JB4{g'
    str_1 = 'MASTERCARD'
    bool_2 = is_credit_card(str_0, str_1)
    # Test case 3
    str_0 = '0Zh?x.+'
    str_1 = 'JCB'
    bool_

# Generated at 2022-06-26 02:01:41.624880
# Unit test for function is_credit_card
def test_is_credit_card():
    assert(is_credit_card('4111111111111111', 'VISA') == True)
    assert(is_credit_card('4111111111111111') == True)
    assert(is_credit_card('6011111111111117', 'DISCOVER') == True)
    assert(is_credit_card('6011111111111117') == True)
    assert(is_credit_card('5431111111111111', 'MASTERCARD') == True)
    assert(is_credit_card('5431111111111111') == True)
    assert(is_credit_card('5311111111111111', 'MASTERCARD') == True)
    assert(is_credit_card('5311111111111111') == True)
    assert(is_credit_card('5511111111111111', 'MASTERCARD') == True)

# Generated at 2022-06-26 02:01:56.576570
# Unit test for function is_email
def test_is_email():
    str_0 = '=e'
    str_1 = '#;b0L'
    str_2 = ':?G&0'
    str_3 = ''
    str_4 = ''
    str_5 = ''
    str_6 = ''
    str_7 = '\u0006&@z'
    str_8 = '\u0006&@z'
    str_9 = '\u0006&@z'
    str_10 = '\u0006&@z'
    str_11 = ''
    str_12 = ''
    str_13 = ''
    str_14 = ''
    str_15 = ''
    str_16 = ''
    str_17 = ''
    str_18 = ' '
    str_19 = '\u0008A\u000e'
   

# Generated at 2022-06-26 02:02:05.899078
# Unit test for function is_json
def test_is_json():
    str_0 = '{"name": "Peter"}'
    bool_0 = is_json(str_0)
    str_1 = '[1, 2, 3]'
    bool_1 = is_json(str_1)
    str_2 = '{nope}'
    bool_2 = is_json(str_2)
    str_3 = '[1, 2, 3}'
    bool_3 = is_json(str_3)
