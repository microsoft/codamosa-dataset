

# Generated at 2022-06-26 01:52:35.163741
# Unit test for function is_ip_v4
def test_is_ip_v4():
    str_0 = '255.200.100.75'
    bool_0 = is_ip_v4(str_0)
    print(str(bool_0))
    str_1 = 'nope'
    bool_1 = is_ip_v4(str_1)
    print(str(bool_1))
    str_2 = '255.200.100.999'
    bool_2 = is_ip_v4(str_2)
    print(str(bool_2))

    # Start Timer
    start_time = time.time()
    for i in range(1000):
        is_ip_v4(str_0)
        is_ip_v4(str_1)
        is_ip_v4(str_2)
    # End Timer
    end_time = time.time

# Generated at 2022-06-26 01:52:36.112453
# Unit test for function is_isbn
def test_is_isbn():
    str_0 = str(input())
    bool_0 = is_isbn(str_0)
    print(bool_0)


# Generated at 2022-06-26 01:52:46.114567
# Unit test for function is_ip_v4
def test_is_ip_v4():
    print('\n[+] Running unit test for function is_ip_v4(str)')
    assert(is_ip_v4('10.16.128.0') == True)
    assert(is_ip_v4('255.16.128.0') == True)
    assert(is_ip_v4('255.200.100.75') == True)
    assert(is_ip_v4('255.200.100.999') == False)
    assert(is_ip_v4('255.200.100.999') == False)
    print('[+] Success')


# Generated at 2022-06-26 01:52:48.040833
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}')
    assert is_json('[1, 2, 3]')
    assert not is_json('{nope}')


# Generated at 2022-06-26 01:52:58.407365
# Unit test for function is_json
def test_is_json():
    assert(is_json('{}'))
    assert(is_json('{"a": 1}'))
    assert(not is_json('{"a": 1.1}'))
    assert(not is_json('{"a", 1}'))
    assert(not is_json('{"": ""}'))
    assert(is_json('[]'))
    assert(is_json('[1]'))
    assert(not is_json('[1.1]'))
    assert(not is_json('[1,2,3]'))
    assert(not is_json('[,]'))
    assert(not is_json('1'))
    assert(not is_json(''))



# Generated at 2022-06-26 01:53:05.933448
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome("a")
    assert is_palindrome("level")
    assert is_palindrome("was it a car or a cat I saw")
    assert is_palindrome("saippuakivikauppias")
    assert not is_palindrome("step")
    assert not is_palindrome("stepp")



# Generated at 2022-06-26 01:53:15.390531
# Unit test for function is_email
def test_is_email():
    assert is_email('foo@bar.com') == True
    assert is_email('foo+bar@bar.com') == True
    assert is_email('foo@bar') == False
    assert is_email('foo') == False
    assert is_email('') == False
    assert is_email(None) == False
    assert is_email('foo+bar@barcom') == False
    assert is_email('foo@') == False
    assert is_email('foo@bar.com ') == False
    assert is_email('@bar.com') == False
    assert is_email('foo@bar.com.') == False
    assert is_email('foo@bar..com') == False
    assert is_email('foo@bar.com..') == False
    assert is_email('foobar.com') == False

# Generated at 2022-06-26 01:53:20.169661
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True # Default
    assert is_ip_v4('nope') == False # Default
    assert is_ip_v4('255.200.100.999') == False # Default

test_is_ip_v4()
test_case_0()

# Generated at 2022-06-26 01:53:28.589027
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    chk = __ISBNChecker('1617290858')
    assert chk.is_isbn_10() == True
    chk = __ISBNChecker('YOUR_ISBN_10_NUMBER_HERE')
    assert chk.is_isbn_10() == False
    chk = __ISBNChecker('978-1617290854')
    assert chk.is_isbn_10() == True
    chk = __ISBNChecker('your_isbn_10_number_here')
    assert chk.is_isbn_10() == False




# Generated at 2022-06-26 01:53:33.634700
# Unit test for function is_url
def test_is_url():
    # Test case 0
    str_0 = 'http://www.mysite.com'
    allowed_schemes = ['http', 'https']
    bool_0 = is_url(str_0, allowed_schemes)
    # Return value
    # assert bool_0 == True


# Generated at 2022-06-26 01:53:46.075538
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert not is_email('@gmail.com')


# Generated at 2022-06-26 01:53:53.407472
# Unit test for function is_ip_v4
def test_is_ip_v4():
    str_0 = 'step'
    bool_0 = is_ip_v4(str_0)


if __name__ == '__main__':
    start = time.time()
    # test_is_ip_v4()
    test_case_0()
    stop = time.time()
    print(stop - start)

# Generated at 2022-06-26 01:54:04.804800
# Unit test for function is_credit_card
def test_is_credit_card():
    print("Testing function is_credit_card")
    str_0 = '4111111111111111'
    str_1 = '4111111111111'
    str_2 = '378282246310005'
    str_3 = '6011111111111117'
    str_4 = '5105105105105100'
    str_5 = '5555555555554444'
    str_6 = '30569309025904'
    str_7 = '3530111333300000'
    str_8 = '3566002020360505'
    str_9 = '6331101999990016'
    bool_0 = is_credit_card(str_0)
    bool_1 = is_credit_card(str_1)
    bool_2 = is_credit_card(str_2)


# Generated at 2022-06-26 01:54:07.472939
# Unit test for function is_json
def test_is_json():
    str_0 = '{}'
    assert(is_json(str_0))

# Generated at 2022-06-26 01:54:15.221052
# Unit test for function is_ip
def test_is_ip(): 
    # Test case 0
    str_0 = 'localhost'
    str_1 = '127.0.0.1'
    str_2 = '256.0.0.1'
    str_3 = '127.0.0.0'
    str_4 = '192.168.0.1'
    str_5 = '2001:db8:85a3:0000:0000:8a2e:370:7334'

    bool_0 = is_ip(str_0)
    bool_1 = is_ip(str_1)
    bool_2 = is_ip(str_2)
    bool_3 = is_ip(str_3)
    bool_4 = is_ip(str_4)
    bool_5 = is_ip(str_5)

    assert (True == bool_0)

# Generated at 2022-06-26 01:54:19.601180
# Unit test for function is_email
def test_is_email():
    str_0 = 'samin@hongik.ac.kr'
    if(is_email(str_0) == True):
        print("is_email correct")
    else:
        print("is_email wrong")

test_case_0()
test_is_email()


# Generated at 2022-06-26 01:54:24.891553
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    # Input Parameter:
    input_str = '9781250135162'

    # Expected Return Value:
    expected_ret_value = True
    
    # Actual Return Value:
    actual_ret_value = __ISBNChecker(input_str).is_isbn_13()

    # Verify
    assert expected_ret_value == actual_ret_value

    # Input Parameter:
    input_str = '978125013516'

    # Expected Return Value:
    expected_ret_value = False
    
    # Actual Return Value:
    actual_ret_value = __ISBNChecker(input_str).is_isbn_13()

    # Verify
    assert expected_ret_value == actual_ret_value

    # Input Parameter:
    input_str = '978125013516A'



# Generated at 2022-06-26 01:54:27.456446
# Unit test for function is_email
def test_is_email():
    str_0 = 'my.email@the-provider.com'
    bool_0 = is_email(str_0)
    assert bool_0


# Generated at 2022-06-26 01:54:34.748963
# Unit test for function is_email
def test_is_email():
    # Test case 0
    str_0 = 'step@umich.edu.gov'
    bool_0 = is_email(str_0)
    print(bool_0)
    # Output: True

    # Test case 1
    str_1 = '"abc@def"@example.com'
    bool_1 = is_email(str_1)
    print(bool_1)
    # Output: True

    # Test case 2
    str_2 = 'a\\ b@example.com'
    bool_2 = is_email(str_2)
    print(bool_2)
    # Output: True

    # Test case 3
    str_3 = 'a@b@c@example.com'
    bool_3 = is_email(str_3)
    print(bool_3)
    # Output:

# Generated at 2022-06-26 01:54:43.558471
# Unit test for function is_credit_card
def test_is_credit_card():
    # Test failure
    card_0 = '1234-5678-9012-3456'
    card_1 = '1234-5678-9012-345'
    card_2 = '1234-5678-9012-3456'
    card_3 = '1234-5678-9012-3456'
    card_4 = '1234-5678-9012-3456'
    card_5 = '1234-5678-9012-3456'

    # Test success
    card_6 = '4539148803436467'


# Generated at 2022-06-26 01:55:00.987017
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('978-0312498580') == True 
    assert is_isbn('978-0-312-49858-0') == True 
    assert is_isbn('9780312498580') == True 
    assert is_isbn('978-0312498580', normalize=False) == False 
    assert is_isbn('978-0-312-49858-0', normalize=False) == False 
    assert is_isbn('9780312498580', normalize=False) == True 
    assert is_isbn('1506715214') == True 
    assert is_isbn('150-6715214') == True 
    assert is_isbn('15-0-67152-14') == True 

# Generated at 2022-06-26 01:55:13.233079
# Unit test for function is_email
def test_is_email():
    from unittest import TestCase

    class is_email_TestCase(TestCase):
        def test_case_0(self):
            str_0 = 'step'
            bool_0 = is_integer(str_0)

        def test_case_1(self):
            str_0 = 'ste'
            str_1 = 'p'
            str_2 = str_0 + str_1
            bool_0 = is_integer(str_2)

        def test_case_2(self):
            str_0 = 'a'
            str_1 = 'step'
            str_2 = str_0 + str_1
            bool_0 = is_integer(str_2)

        def test_case_3(self):
            str_0 = 'ste'
            str_1 = 'p'
            str

# Generated at 2022-06-26 01:55:16.761338
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    __ISBNChecker_0 = __ISBNChecker('978-1234567890')
    bool_0 = __ISBNChecker_0.is_isbn_13()


# Generated at 2022-06-26 01:55:19.487511
# Unit test for function is_json
def test_is_json():
    str_0 = '"foo": "bar";'
    bool_0 = is_json(str_0)
    assert bool_0


# Generated at 2022-06-26 01:55:22.222371
# Unit test for function is_palindrome
def test_is_palindrome():
    a = "otto"
    b = "i topi non avevano nipoti"
    c = "LOL"
    d = "ROTFL"
    assert is_palindrome(a, True)
    assert is_palindrome(b, True)
    assert is_palindrome(a, False)
    assert is_palindrome(b, False)
    assert is_palindrome(c, False, True)
    assert not is_palindrome(d, False, True)

# Generated at 2022-06-26 01:55:29.511543
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    # Test case 0
    str_0 = '1234'
    bool_0 = __ISBNChecker(str_0).is_isbn_10()
    assert(bool_0 == True)

    # Test case 1
    str_0 = '91234'
    bool_0 = __ISBNChecker(str_0).is_isbn_10()
    assert(bool_0 == False)

    # Test case 2
    str_0 = '-1234'
    bool_0 = __ISBNChecker(str_0).is_isbn_10()
    assert(bool_0 == False)

    # Test case 3
    str_0 = '0-1234'
    bool_0 = __ISBNChecker(str_0).is_isbn_10()
    assert(bool_0 == False)

# Generated at 2022-06-26 01:55:34.543633
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('otto')
    assert is_palindrome('i topi non avevano nipoti', ignore_spaces=True)
    assert is_palindrome('oTTo', ignore_case=True)
    assert not is_palindrome('step')


# Generated at 2022-06-26 01:55:37.316968
# Unit test for function is_isbn
def test_is_isbn():
    str_0 = ''
    bool_0 = is_isbn(str_0)
    return (str_0, bool_0)


# Generated at 2022-06-26 01:55:40.968678
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@') == False


# Generated at 2022-06-26 01:55:43.412231
# Unit test for function is_json
def test_is_json():
    test_input_string = '{"name": "Peter"}'
    is_json(test_input_string)


# Generated at 2022-06-26 01:56:06.347973
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    obj_0 = __ISBNChecker('0123456789')
    bool_0 = obj_0.is_isbn_10()
    assert(bool_0 == True)
    obj_1 = __ISBNChecker('012345678')
    bool_1 = obj_1.is_isbn_10()
    assert(bool_1 == False)
    obj_0 = __ISBNChecker('0123456788')
    bool_0 = obj_0.is_isbn_10()
    assert(bool_0 == True)
    obj_0 = __ISBNChecker('012345678X')
    bool_0 = obj_0.is_isbn_10()
    assert(bool_0 == True)
    obj_1 = __ISBNChecker('012345678Z')
    bool

# Generated at 2022-06-26 01:56:09.576216
# Unit test for function is_email
def test_is_email():
    str_0 = 'my.email@the-provider.com'
    bool_0 = is_email(str_0)
    print(bool_0)

test_is_email()


# Generated at 2022-06-26 01:56:18.499208
# Unit test for function is_email
def test_is_email():
    str_res_0 = 'test'
    str_res_1 = 't.est'
    str_res_2 = 'test@test'
    str_res_3 = 'test@test.com'
    str_res_4 = 'te.s.t@test.com'
    str_res_5 = 'te st@test.com'
    str_res_6 = 't.e.st@test.com'
    str_res_7 = 't\xe8\x8b\xb1\xe5\x9b\xbd@test.com'
    str_res_8 = 't\xe8\x8b\xb1\xe5\x9b\xbd@test.com'

# Generated at 2022-06-26 01:56:30.602075
# Unit test for function is_json
def test_is_json():
    str_0 = '{}'
    bool_0 = is_json(str_0)
    assert bool_0 is False
    str_1 = '{'
    bool_1 = is_json(str_1)
    assert bool_1 is False
    str_2 = '}'
    bool_2 = is_json(str_2)
    assert bool_2 is True
    str_3 = '[]'
    bool_3 = is_json(str_3)
    assert bool_3 is True
    str_4 = '['
    bool_4 = is_json(str_4)
    assert bool_4 is False
    str_5 = ']'
    bool_5 = is_json(str_5)
    assert bool_5 is False
    str_6 = '-1'
    bool_6

# Generated at 2022-06-26 01:56:33.441260
# Unit test for function is_json
def test_is_json():
    str_0 = '{"name": "Peter"}'
    bool_0 = is_json(str_0)
    #assert bool_0 is True



# Generated at 2022-06-26 01:56:42.056033
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    # Case 0
    try:
        str_0 = 'step'
        __ISBNChecker(str_0)
        assert False
    except InvalidInputError as e:
        assert isinstance(e, InvalidInputError)
        assert e.message == str_0
        assert e.expected_type == 'str'
    # Case 1
    try:
        str_1 = '9791220208066'
        __ISBNChecker(str_1)
        assert False
    except InvalidInputError as e:
        assert isinstance(e, InvalidInputError)
        assert e.message == str_1
        assert e.expected_type == 'str'
    # Case 2

# Generated at 2022-06-26 01:56:49.577746
# Unit test for function is_email
def test_is_email():
    str_0 = "foobar@gmail.com"
    bool_0 = is_email(str_0)
    str_1 = "baz.com"
    bool_1 = is_email(str_1)
    str_2 = "qux.hello.world@gmail.com"
    bool_2 = is_email(str_2)
    str_3 = "haha@"
    bool_3 = is_email(str_3)


# Generated at 2022-06-26 01:56:52.369408
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    checker = __ISBNChecker('9788377545824')
    result = checker.is_isbn_13()

    assert result is True


# Generated at 2022-06-26 01:56:57.785858
# Unit test for function is_json
def test_is_json():
    str_0 = '{"name": "Peter"}'

    assert(is_json(str_0))

    str_0 = '[1, 2, 3]'

    assert(is_json(str_0))
    
    str_0 = '{"name": "Peter"'

    assert(not is_json(str_0))



# Generated at 2022-06-26 01:57:03.173555
# Unit test for function is_email
def test_is_email():
    # Test Case 1
    str_1 = 'someone@example.com'
    bool_1 = is_email(str_1)
    assert bool_1 == True
    
    # Test Case 2
    str_2 = 'plainaddress'
    bool_2 = is_email(str_2)
    assert bool_2 == False


# Generated at 2022-06-26 01:57:22.309165
# Unit test for function is_ip_v4
def test_is_ip_v4():
    str_0 = '0.0.0.0'
    bool_0 = is_ip_v4(str_0)
    assert(bool_0)

    str_0 = '255.0.0.0'
    bool_0 = is_ip_v4(str_0)
    assert(bool_0)

    str_0 = '0.255.0.0'
    bool_0 = is_ip_v4(str_0)
    assert(bool_0)

    str_0 = '0.0.255.0'
    bool_0 = is_ip_v4(str_0)
    assert(bool_0)

    str_0 = '0.0.0.255'
    bool_0 = is_ip_v4(str_0)
    assert(bool_0)

# Generated at 2022-06-26 01:57:27.273140
# Unit test for function is_email
def test_is_email():
    str_0 = 'steven@gmail.com'
    str_1 = 'stephen@yahoo.com'
    str_2 = 'jieyu@berkely.edu'
    str_3 = 'jieyu@cs.berkeley.edu'

    assert(is_email(str_0) == True)
    assert(is_email(str_1) == True)
    assert(is_email(str_2) == True)
    assert(is_email(str_3) == True)



# Generated at 2022-06-26 01:57:30.112857
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    test_case_0()


# Generated at 2022-06-26 01:57:37.156619
# Unit test for function is_json
def test_is_json():
    # test case 0
    str_0 = 'step'
    assert(is_json(str_0) == False)

    # test case 1
    str_1 = '{ "name": "Peter" }'
    assert(is_json(str_1) == True)

    # test case 2
    str_2 = '[1, 2, 3]'
    assert(is_json(str_2) == True)

    # test case 3
    str_3 = '[1, 2, 3'
    assert(is_json(str_3) == False)

    # test case 4
    str_4 = '{nope}'
    assert(is_json(str_4) == False)


# Generated at 2022-06-26 01:57:40.580673
# Unit test for function is_email
def test_is_email():
    str_0 = 'step'
    bool_0 = is_email(str_0)

    # Output:
    print(bool_0)

test_is_email()



# Generated at 2022-06-26 01:57:49.159831
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    # set up
    str = '978-3-16-148410-0'
    # run the method under test
    res = __ISBNChecker(str).is_isbn_13()
    # assert
    assert res


# Generated at 2022-06-26 01:57:54.598791
# Unit test for function is_email
def test_is_email():
    test_val = ('hello' + '@' + 'world.com')
    assert is_email(test_val) == True
    test_val = ('hello' + '@' + 'world')
    assert is_email(test_val) == False
    test_val = ('hello' + '@' + ['world', 'com'])
    assert is_email(test_val) == False


# Generated at 2022-06-26 01:57:58.807536
# Unit test for function is_ip_v4
def test_is_ip_v4():
    list_0 = list()
    list_0.append('255.255.255.255')
    list_0.append('10.0.0.0')
    list_0.append('0.0.0.0')
    list_0.append('0.0.0.256')
    list_0.append('255.0.0.')
    list_0.append('0.0.0.255')
    list_0.append('0.0.0.255.')
    list_0.append('255.255.255.255')
    list_0.append('255.255.255.255')
    list_0.append('255.255.255.255')
    list_0.append('255.255.255.255')
    list_0.append('255.255.255.0')

# Generated at 2022-06-26 01:58:06.971945
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    input_string = '9780814209510'
    normalize = True
    test_0 = __ISBNChecker(input_string, normalize)
    bool_0 = test_0.is_isbn_13()

    input_string = '9780814209510'
    normalize = True
    test_1 = __ISBNChecker(input_string, normalize)
    bool_1 = test_1.is_isbn_13()

    input_string = '9780814209510'
    normalize = True
    test_2 = __ISBNChecker(input_string, normalize)
    bool_2 = test_2.is_isbn_13()

    input_string = '9780814209510'
    normalize = True

# Generated at 2022-06-26 01:58:12.157289
# Unit test for function is_json
def test_is_json():
    # assert for a string that is json
    assert(is_json('["foo", {"bar":["baz",null,1.0,2]}]') == True)

    # assert for a string that is not json
    assert(is_json('bar') == False)


# Generated at 2022-06-26 01:58:28.334281
# Unit test for function is_email
def test_is_email():
    # Test case 0:
    # "test@test.test"
    str_0 = 'test@test.test'
    # Expected result:
    bool_0 = True

    # Test case 1:
    # "test@test"
    str_1 = 'test@test'
    # Expected result:
    bool_1 = False

    # Test case 2:
    # "test.test@test"
    str_2 = 'test.test@test'
    # Expected result:
    bool_2 = True

    # Test case 3:
    # "test-test@test"
    str_3 = 'test-test@test'
    # Expected result:
    bool_3 = True

    # Test case 4:
    # "test@test.test.test"

# Generated at 2022-06-26 01:58:30.419499
# Unit test for function is_json
def test_is_json():
    print('Test for function is_json')
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False
    print('Test successful')


# Generated at 2022-06-26 01:58:37.701814
# Unit test for function is_email
def test_is_email():
    # check if @ is given
    str_0 = 'my.emailthe-provider.com'
    bool_0 = is_email(str_0)
    # check if the domain has at least one dot
    str_1 = 'my.email@the-provider'
    bool_1 = is_email(str_1)
    # check if the maximum length of the email address is exceeded

# Generated at 2022-06-26 01:58:47.714527
# Unit test for function is_json
def test_is_json():
    print('')
    print('Test for function is_json')
    print('Test 1: "{"name": "Peter"}"')
    str_0 = '{"name": "Peter"}'
    bool_0 = is_json(str_0)
    print(bool_0)
    print('Test 2: "[1, 2, 3]"')
    str_1 = '[1, 2, 3]'
    bool_1 = is_json(str_1)
    print(bool_1)
    print('Test 3: "{nope}"')
    str_2 = '{nope}'
    bool_2 = is_json(str_2)
    print(bool_2)


# Generated at 2022-06-26 01:58:58.178985
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    # Test is_isbn_13 with input string '978-3-16-148410-0'
    result = __ISBNChecker('978-3-16-148410-0').is_isbn_13()
    expected = True
    assert result == expected, "Expected call to __ISBNChecker('978-3-16-148410-0').is_isbn_13() to return True, got " + repr(result)

    # Test is_isbn_13 with input string '978-3-16-148410-1'
    result = __ISBNChecker('978-3-16-148410-1').is_isbn_13()
    expected = False

# Generated at 2022-06-26 01:59:07.084995
# Unit test for function is_email
def test_is_email():
    assert is_email('foo123@gmail.com'), 'Test Failed for good email'
    assert not is_email('.foo123@gmail.com'), 'Test Failed for email containing a dot in the head'
    assert not is_email('foo123@.gmail.com'), 'Test Failed for email containing a dot in the tail'
    assert not is_email('.foo123@.gmail.com'), 'Test Failed for email containing dots in the head and tail'
    assert not is_email('foo123@gmail.com.'), 'Test Failed for email containing a tailing dot'
    assert not is_email('foo..123@gmail.com'), 'Test Failed for email containing multiple consecutive dots in the head'
    assert not is_email('"foo.123"@gmail.com'), 'Test Failed for email containing a dot in a quoted head'
    assert not is_

# Generated at 2022-06-26 01:59:19.433828
# Unit test for method is_isbn_10 of class __ISBNChecker

# Generated at 2022-06-26 01:59:22.579422
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    instance_0 = __ISBNChecker(None, )
    try:
        instance_0.is_isbn_13()

    except (AttributeError, InvalidInputError):
        pass


# Generated at 2022-06-26 01:59:26.489983
# Unit test for function is_json
def test_is_json():
    str_0 = '{"name": "Peter"}'
    bool_0 = is_json(str_0)
    assert bool_0 == True
    str_1 = '[1, 2, 3]'
    bool_1 = is_json(str_1)
    assert bool_1 == True
    str_2 = '{nope}'
    bool_2 = is_json(str_2)
    assert bool_2 == False


# Generated at 2022-06-26 01:59:38.694612
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    str_0 = '0309085964'
    str_1 = '0309085964'
    str_2 = '0309085964'
    str_3 = '0309085964'
    str_4 = '0309085964'
    str_5 = '0309085964'
    str_6 = '0309085964'
    str_7 = '0309085964'
    str_8 = '0309085964'
    str_9 = '0309085964'
    str_10 = '0309085964'
    bool_0 = __ISBNChecker(str_1).is_isbn_10()
    bool_1 = __ISBNChecker(str_2).is_isbn_10()
    bool_2 = __ISBNChecker

# Generated at 2022-06-26 01:59:54.949910
# Unit test for function is_json
def test_is_json():
    print('Test function is_json')
    print('Test case 1:')
    str_1 = '{"name": "Peter"}'
    bool_1 = is_json(str_1)
    print (bool_1)
    print('Test case 2:')
    str_2 = '[1,2,3]'
    bool_2 = is_json(str_2)
    print (bool_2)
    print('Test case 3:')
    str_3 = '{nope}'
    bool_3 = is_json(str_3)
    print (bool_3)


# Generated at 2022-06-26 02:00:07.729684
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    obj_0 = __ISBNChecker('1234567890')
    bool_0 = obj_0.is_isbn_10()
    assert bool_0

    obj_1 = __ISBNChecker('1234567891')
    bool_1 = obj_1.is_isbn_10()
    assert not bool_1

    obj_2 = __ISBNChecker('1234567899')
    bool_2 = obj_2.is_isbn_10()
    assert not bool_2

    obj_3 = __ISBNChecker('1234567898')
    bool_3 = obj_3.is_isbn_10()
    assert bool_3

    obj_4 = __ISBNChecker('123456789')
    bool_4 = obj_4.is_isbn_10()

# Generated at 2022-06-26 02:00:10.463470
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    isbn_checker = __ISBNChecker('9780306406157')
    res_bool = isbn_checker.is_isbn_13()


# Generated at 2022-06-26 02:00:17.011188
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    bool_0 = __ISBNChecker('-').is_isbn_13()
    bool_1 = __ISBNChecker('978-0-306-40615-7').is_isbn_13()
    bool_2 = __ISBNChecker('978-0-306-40615-8').is_isbn_13()


# Generated at 2022-06-26 02:00:20.699836
# Unit test for function is_json
def test_is_json():
    assert(is_json('{"name": "Peter"}') == True)
    assert(is_json('[1, 2, 3]') == True)
    assert(is_json('{nope}') == False)


# Generated at 2022-06-26 02:00:27.455174
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    str_0 = '0439682584'
    str_1 = '0439682583'
    obj = __ISBNChecker(str_0)
    bool_0 = obj.is_isbn_10()
    obj = __ISBNChecker(str_1)
    bool_1 = obj.is_isbn_10()
    assert (bool_0 == True)
    assert (bool_1 == False)


# Generated at 2022-06-26 02:00:40.146552
# Unit test for function is_email
def test_is_email():
    dict_0 = {}
    dict_0['test_key0'] = 'test_value0'
    dict_0['test_key1'] = 'test_value1'
    dict_0['test_key2'] = 'test_value2'
    dict_0['test_key3'] = 'test_value3'
    dict_0['test_key4'] = 'test_value4'
    dict_0['test_key5'] = 'test_value5'
    dict_0['test_key6'] = 'test_value6'
    dict_0['test_key7'] = 'test_value7'
    dict_0['test_key8'] = 'test_value8'
    dict_0['test_key9'] = 'test_value9'

# Generated at 2022-06-26 02:00:51.371354
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my\\.email@the-provider.com') == True
    assert is_email('a\\@gmail.com') == False
    assert is_email('a@gmail.com') == True
    assert is_email('""@a.com') == True
    assert is_email('"\\"@a.com') == True
    assert is_email('"\""@a.com') == True
    assert is_email('"""@a.com') == True

# Generated at 2022-06-26 02:01:01.795874
# Unit test for function is_email
def test_is_email():
    #
    # This test case verifies that the program correctly identifies
    # valid email addresses.
    #
    assert is_email('alex@gmail.com') == True, 'Test Failed'
    assert is_email('alex.h.seitz@gmail.com') == True, 'Test Failed'
    assert is_email('alex.h.seitz@uni.edu') == True, 'Test Failed'
    #
    # This test case verifies that the program correctly identifies
    # invalid email addresses.
    #
    assert is_email('') == False, 'Test Failed'
    assert is_email('alexseitz.com') == False, 'Test Failed'
    assert is_email('alex@seitzcom') == False, 'Test Failed'

test_is_email()


# Generated at 2022-06-26 02:01:11.375576
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    inputs = [
        ['978-0-306-40615-7', True],
        ['0-306-406155-1', True],
        ['978-0-306-406155-7', False],
        ['978-0-306-406155-', False],
        ['978-0-306-406155-0', False],
        ['978-0-306-406155-5', True],
        ['978-0-306-40615-5', False],
    ]

    for input_string, expected in inputs:
        actual = __ISBNChecker(input_string).is_isbn_13()
        assert actual == expected


# Generated at 2022-06-26 02:01:21.880099
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    str_0 = '9780192100206'
    print('Testing: ', str_0)
    assert(True == __ISBNChecker(str_0).is_isbn_13())
    # print(__ISBNChecker(str_0).is_isbn_13())
    assert(False == __ISBNChecker(str_0).is_isbn_10())
    # print(__ISBNChecker(str_0).is_isbn_10())


# Generated at 2022-06-26 02:01:32.415861
# Unit test for function is_json
def test_is_json():
    print('\nTest is_json')

# Generated at 2022-06-26 02:01:42.090279
# Unit test for function is_ip_v4
def test_is_ip_v4():
    string_0 = '127.0.0.1'
    string_1 = '123.24.3.22'
    string_2 = '256.0.0.0'
    string_3 = 'a.b.c.d'
    string_4 = 'abcd.123.0.0'
    string_5 = '23.a.43.0'
    string_6 = '123.34.56.78'
    string_7 = '1.2.3.4'

    assert is_ip_v4(string_0), 'Expected True, Received False'
    assert is_ip_v4(string_1), 'Expected True, Received False'
    assert not is_ip_v4(string_2), 'Expected False, Received True'

# Generated at 2022-06-26 02:01:53.494831
# Unit test for function is_ip_v4
def test_is_ip_v4():
    str_0 = 'www.google.com'
    str_1 = '255.200.100.75'
    str_2 = '255.200.100.999'
    assert is_ip_v4(str_0) == False
    assert is_ip_v4(str_1) == True
    assert is_ip_v4(str_2) == False

if __name__ == '__main__':
    test_case_0()
    test_is_ip_v4()

# Generated at 2022-06-26 02:02:02.166283
# Unit test for function is_json
def test_is_json():
    json_str_0 = '{"number": 1}'
    bool_0 = is_json(json_str_0)
    # Expected result is True
    assert bool_0 == True
    json_str_1 = '{"string": "foo"}'
    bool_1 = is_json(json_str_1)
    # Expected result is True
    assert bool_1 == True
    json_str_2 = '{"array": [1, 2]}'
    bool_2 = is_json(json_str_2)
    # Expected result is True
    assert bool_2 == True
    json_str_3 = '{"nested": {"object": "yes"}}'
    bool_3 = is_json(json_str_3)
    # Expected result is True
    assert bool_3 == True
   