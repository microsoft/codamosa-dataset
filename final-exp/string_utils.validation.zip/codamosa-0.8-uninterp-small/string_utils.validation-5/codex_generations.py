

# Generated at 2022-06-26 01:52:20.635681
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('') == False
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-26 01:52:31.543637
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    # Init __ISBNChecker
    string_0 = '9790812250431'
    __ISBNChecker_0 = __ISBNChecker(string_0)

    # Test case 0
    bool_0 = __ISBNChecker_0.is_isbn_13()

    # Test case 1
    string_0 = '9790812250430'
    __ISBNChecker_1 = __ISBNChecker(string_0)
    bool_1 = __ISBNChecker_1.is_isbn_13()

    # Test case 2
    string_0 = '979081225043'
    __ISBNChecker_2 = __ISBNChecker(string_0)
    bool_2 = __ISBNChecker_2.is_isbn_13()

    # Test case 3
   

# Generated at 2022-06-26 01:52:32.570119
# Unit test for function is_ip_v4
def test_is_ip_v4():
    test_case_0()


# Generated at 2022-06-26 01:52:34.464472
# Unit test for function is_isbn
def test_is_isbn():
    print("******* test_is_isbn *******")
    assert is_isbn('9780312498580') == True
    assert is_isbn('1506715214') == True
    assert is_isbn('978-0312498580') == True
    assert is_isbn('150-6715214') == True


# Generated at 2022-06-26 01:52:46.785258
# Unit test for function is_json
def test_is_json():
    assert is_json("{}") == True
    assert is_json("{ }") == False
    assert is_json("{\"name\": \"John\"}") == True
    assert is_json("{\"name\": \"John\", \"surname\": \"Smith\"}") == True
    assert is_json("{\"name\": \"John\", \"surname\": \"Smith\", \"age\": 25}") == True
    assert is_json("{\"name\": \"John\", \"surname\": \"Smith\", age\": 25}") == False
    assert is_json("{\"name\": \"John\", }") == False
    assert is_json("{name\": \"John\"}") == False
    assert is_json("name\": \"John\"}") == False
    assert is_json("\"name\": \"John\"") == False
    assert is_json

# Generated at 2022-06-26 01:52:58.858409
# Unit test for function is_email
def test_is_email():
    INPUT_0 = 'my.email@the-provider.com'
    EXPECTED_0 = True
    EXEC_0 = is_email(INPUT_0)
    assert EXEC_0 == EXPECTED_0, 'Test email 0 failed: %s' % EXEC_0

    INPUT_1 = '@gmail.com'
    EXPECTED_1 = False
    EXEC_1 = is_email(INPUT_1)
    assert EXEC_1 == EXPECTED_1, 'Test email 0 failed: %s' % EXEC_1

    INPUT_2 = 'my.email@the-provider.com'
    EXPECTED_2 = True
    EXEC_2 = is_email(INPUT_2)

# Generated at 2022-06-26 01:53:00.952049
# Unit test for function is_ip_v4
def test_is_ip_v4():
    # given
    bool_0 = True
    bool_1 = is_isogram(bool_0)
    # when
    string = is_ip_v4(bool_1)
    # then
    assert not string


# Generated at 2022-06-26 01:53:12.465914
# Unit test for function is_ip
def test_is_ip():
    assert(is_ip('192.168.1.1') is True)
    assert(is_ip('10.0.0.1') is True)
    assert(is_ip('2001:0db8:85a3:0000:0000:8a2e:0370:7334') is True)
    assert(is_ip('2001:db8:85a3:0:0:8a2e:370:7334') is True)
    assert(is_ip('fe80:0:0:0:204:61ff:fe9d:f156') is True)
    assert(is_ip('255.255.255.255') is True)
    assert(is_ip('0.0.0.0') is True)

# Generated at 2022-06-26 01:53:14.775329
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    bool_1 = test___ISBNChecker_is_isbn_10_0()
    assert bool_1 == True


# Generated at 2022-06-26 01:53:18.967853
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') is True
    assert is_ip_v4('nope') is False
    assert is_ip_v4('255.200.100.999') is False


# Generated at 2022-06-26 01:53:27.425315
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    __ISBNChecker_0 = __ISBNChecker("", True)
    bool_0 = __ISBNChecker_0.is_isbn_13()
    test___ISBNChecker_is_isbn_13 = bool_0
    return test___ISBNChecker_is_isbn_13


# Generated at 2022-06-26 01:53:37.882765
# Unit test for function is_email
def test_is_email():
    assert(is_email("my.email@the-provider.com") == True)
    assert(is_email("my.email@the-provider.com") == True)
    assert(is_email("my.email@the-provider.com") == True)
    assert(is_email("my.email@the-provider.com") == True)
    assert(is_email("my.email@the-provider.com") == True)
    assert(is_email("my.email@the-provider.com") == True)
    assert(is_email("my.email@the-provider.com") == True)
    assert(is_email("my.email@the-provider.com") == True)
    assert(is_email("my.email@the-provider.com") == True)
   

# Generated at 2022-06-26 01:53:51.184320
# Unit test for function is_credit_card
def test_is_credit_card():
    bool_0 = is_credit_card("371449632741004")
    bool_1 = is_credit_card("5105105105105100")
    bool_2 = is_credit_card("6011580782575338")
    bool_3 = is_credit_card("3530111333300000")
    bool_4 = is_credit_card("3566002020360505")
    bool_5 = is_credit_card("123")
    bool_6 = is_credit_card("0000000000000000")
    bool_7 = is_credit_card("00000000000000001")
    bool_8 = is_credit_card("000000000000000000000000000000")
    test_0 = "4656915381349054"
    bool_9 = is_credit_card(test_0)

# Generated at 2022-06-26 01:53:54.656147
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@gmail.com') == True


# Generated at 2022-06-26 01:54:05.626503
# Unit test for function is_credit_card
def test_is_credit_card():
    assert(is_credit_card('601111') == True)
    assert(is_credit_card('6011111111111117') == True)
    assert(is_credit_card('510510') == True)
    assert(is_credit_card('371449635398431') == True)
    assert(is_credit_card('378282246310005') == True)
    assert(is_credit_card('30569309025904') == True)
    assert(is_credit_card('38520000023237') == True)
    assert(is_credit_card('3530111333300000') == True)
    assert(is_credit_card('3566002020360505') == True)
    assert(is_credit_card('5555555555554444') == True)

# Generated at 2022-06-26 01:54:07.772823
# Unit test for function is_email
def test_is_email():
    bool_0 = is_email("john.doe@gmail.com")
    assert bool_0 == True


# Generated at 2022-06-26 01:54:12.008262
# Unit test for function is_credit_card
def test_is_credit_card():
    card_type = "VISA"
    input_string = "4580459043543543"
    expected = True
    actual = is_credit_card(input_string, card_type)
    assert (expected == actual)
    print("Expected:" + str(expected))
    print("Actual:" + str(actual))
    print("Success.")


# Generated at 2022-06-26 01:54:15.698601
# Unit test for function is_url
def test_is_url():
    assert(is_url('http://www.mysite.com'))
    assert(is_url('https://mysite.com'))
    assert(not is_url('.mysite.com'))


# Generated at 2022-06-26 01:54:23.424240
# Unit test for function is_email
def test_is_email():
    test = 'test@test.test'
    test_b = '@test.test'
    test_c = 'testtest.test'
    test_d = 'test@testtest'
    test_e = 'test@test.testtest'
    test_f = 'test@.test'
    test_g = 'test..test@test.test'
    test_h = 'test@test.test..'
    test_i = 'test@test.test.'
    test_j = 'test.@test.test'
    test_k = '.test@test.test'
    test_l = 'testtest.test@test.test'
    test_m = '\\test@test.test'
    test_n = '\\test.test@test.test'

# Generated at 2022-06-26 01:54:28.366934
# Unit test for function is_credit_card
def test_is_credit_card():
    # Test case 0
    card_type = "DINERS_CLUB"
    input_string = "3864575437"
    expected_output = True
    actual_output = is_credit_card(input_string, card_type)
    print(actual_output)
    assert  actual_output == expected_output


test_is_credit_card()



# Generated at 2022-06-26 01:54:35.794614
# Unit test for function is_json
def test_is_json():
    assert is_json(True) == True
# Tuple test for function is_json

# Generated at 2022-06-26 01:54:47.640805
# Unit test for function is_email
def test_is_email():
    assert(is_email("abc@gmail.com") == True)
    assert(is_email("123-567@mail.com") == True)
    assert(is_email("abc@mail.com") == True)
    assert(is_email("abc@gmail.com.cn") == True)
    assert(is_email("abc_123@mail.com") == True)
    assert(is_email("abc123@mail.com") == True)
    assert(is_email("abc123@yahoo.com.cn") == True)
    assert(is_email("abc.123@mail.com") == True)
    assert(is_email("abc.123@gmail.com") == True)
    assert(is_email("ab.c123@mail.com") == True)

# Generated at 2022-06-26 01:54:50.729186
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True

    assert is_email('@gmail.com') == False


# Generated at 2022-06-26 01:54:51.769245
# Unit test for function is_json
def test_is_json():
    test_case_0()

# Generated at 2022-06-26 01:55:02.424645
# Unit test for function is_url
def test_is_url():
    assert is_url('http:') == False
    assert is_url('http:www.google.com') == False
    assert is_url('www.google.com') == False
    assert is_url('google.com') == False
    assert is_url('http://www.google.com') == True
    assert is_url('https://www.google.com') == True
    assert is_url('https://www.google.com/search?q=something&oq=something&aqs=chrome..69i57j69i59&sourceid=chrome&ie=UTF-8') == True
    assert is_url('https://www.google.com/search?q=something&oq=something&aqs=chrome..69i57j69i59&sourceid=chrome&ie=UTF-8#tiger') == True
   

# Generated at 2022-06-26 01:55:14.475029
# Unit test for function is_json
def test_is_json():
    # Expected value: False
    # Actual value: False
    bool_0 = 'abcdefghijklmnopqrstuvwxyz'
    assert not is_json(bool_0)
    # Expected value: False
    # Actual value: False

# Generated at 2022-06-26 01:55:25.728269
# Unit test for function is_email
def test_is_email():
    assert(is_email(None) == False)
    assert(is_email("") == False)
    assert(is_email("test") == False)
    assert(is_email("test@") == False)
    assert(is_email("test@gmail.com") == True)
    assert(is_email("test@gmail.com.") == True)
    assert(is_email("te.st@gmail.com") == True)
    assert(is_email("te.st@gmail.com.") == True)
    assert(is_email("te.st@gmail.com.5") == True)
    assert(is_email("te.st@gmail.c.om") == True)
    assert(is_email("te.st@gmail.com.5..") == False)

# Generated at 2022-06-26 01:55:37.267980
# Unit test for function is_email
def test_is_email():
    assert is_email("foo@bar.com") == True
    assert is_email("foo.bar+baz@bar.com") == True
    assert is_email("foo@bar.museum") == True
    assert is_email("foo@bar.travel") == True
    assert is_email("foo.bar@bar.coop") == True
    assert is_email("foo@bar.com.au") == True
    assert is_email("foo+bar@bar.com") == True
    assert is_email("foo@bar..com") == False
    assert is_email("foobar@bar.com") == True
    assert is_email("foo@bar.com.") == False
    assert is_email("foo_bat@bar.com") == True
    assert is_email("foo@bar.co.uk") == True
   

# Generated at 2022-06-26 01:55:45.054953
# Unit test for function is_url
def test_is_url():
    cases = [
        # Invalid urls
        ([''], []),
        (['not a url'], []),
        (['.mysite.com'], []),
        (['my.site.com', 'https'], [])
    ]
    for inputs, expected in cases:
        actual = is_url(*inputs)
        message = "is_url({0}) returned {1}, not {2}".format(inputs, actual, expected)
        assert actual == expected, message


# Generated at 2022-06-26 01:55:54.187845
# Unit test for function is_email
def test_is_email():
    assert is_email("") == False
    assert is_email(None) == False
    assert is_email(".@.".split()) == False
    assert is_email(["hello", "world"]) == False
    assert is_email("@gmail.com") == False
    assert is_email("my.email@the-provider.com") == True
    assert is_email("my..email@the-provider.com") == False
    assert is_email("my@email@the-provider.com") == False
    assert is_email("my.email@the-provider.com!") == False
    assert is_email("my.email@the-provider.com.") == False
    assert is_email("\"my.email@the-provider.com\"") == False

# Generated at 2022-06-26 01:56:01.297135
# Unit test for function is_email
def test_is_email():
    assert(is_email('my.email@the-provider.com') # returns true
    )


# Generated at 2022-06-26 01:56:06.347468
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False

    # Check for buggy line
    assert is_json('bool_1 = is_isogram(bool_0)') == False


# Generated at 2022-06-26 01:56:08.815759
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False


# Generated at 2022-06-26 01:56:11.990635
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') == True
    assert is_url('https://mysite.com') == True
    assert is_url('.mysite.com') == False


# Generated at 2022-06-26 01:56:19.686849
# Unit test for function is_url
def test_is_url():

    # Test case 0
    try:
        test_case_0()
        assert 0
    except Exception as e:
        assert e.__str__() == "Input value is not a string or is empty."

    # Test case 1
    try:
        bool_0 = False
        bool_1 = is_url(bool_0)
        assert 0
    except Exception as e:
        assert e.__str__() == "Input value is not a string or is empty."

    # Test case 2
    try:
        list_var_0 = ['1', '7', '8', '5']
        bool_0 = False
        bool_1 = is_url(list_var_0)
        assert 0
    except Exception as e:
        assert e.__str__() == "Input value is not a string or is empty."

   

# Generated at 2022-06-26 01:56:30.042406
# Unit test for function is_email
def test_is_email():
    assert is_email('foo@gmail.com'), 'is_email failure'
    assert is_email('foo@gmail.net'), 'is_email failure'
    assert is_email('foo@gmail.org'), 'is_email failure'
    assert is_email('foo.bar@gmail.com'), 'is_email failure'

    assert not is_email('foo@gmail'), 'is_email failure'
    assert not is_email('@a.b'), 'is_email failure'
    assert not is_email('foo@.b'), 'is_email failure'

    # local domain not supported
    assert not is_email('foo@bar'), 'is_email failure'



# Generated at 2022-06-26 01:56:32.543006
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    bool_0 = __ISBNChecker("0001471868")
    bool_1 = bool_0.is_isbn_10()


# Generated at 2022-06-26 01:56:34.840117
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False


# Generated at 2022-06-26 01:56:39.252837
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    # Arrange
    expectedOutput = True
    input_string = "0393045218"
    isbnCheckerInst = __ISBNChecker(input_string)

    # Act
    isValidIsbn = isbnCheckerInst.is_isbn_10()

    # Assert
    assert expectedOutput == isValidIsbn


# Generated at 2022-06-26 01:56:41.919093
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    str_0 = 'a_str'
    __ISBNChecker_0 = __ISBNChecker(str_0)
    assert not __ISBNChecker_0.is_isbn_10()


# Generated at 2022-06-26 01:57:01.328000
# Unit test for function is_ip_v4
def test_is_ip_v4():
    print("Starting tests for function is_ip_v4")
    in_0 = "255.200.100.75"
    expected_0 = True
    res_0 = is_ip_v4(in_0)
    assert (res_0 == expected_0)

    in_1 = "nope"
    expected_1 = False
    res_1 = is_ip_v4(in_1)
    assert (res_1 == expected_1)

    in_2 = "255.200.100.999"
    expected_2 = False
    res_2 = is_ip_v4(in_2)
    assert (res_2 == expected_2)

    print("Test for function is_ip_v4 complete")


# Generated at 2022-06-26 01:57:03.810683
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert (__ISBNChecker('1234567890').is_isbn_10() == False), 'For "[\'1234567890\']" expected: False'


# Generated at 2022-06-26 01:57:05.622306
# Unit test for function is_email
def test_is_email():
    assert is_email('herr.doctor@protonmail.com') == True
    assert is_email('herr.doctorprotonmail.com') == False


# Generated at 2022-06-26 01:57:07.704875
# Unit test for function is_ip_v4
def test_is_ip_v4():
    ip_0 = "14.127.242.00"
    bool_0 = is_ip_v4(ip_0)
    print(bool_0)



# Generated at 2022-06-26 01:57:09.360905
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    obj = __ISBNChecker("")
    obj.is_isbn_10()


# Generated at 2022-06-26 01:57:11.056824
# Unit test for function is_url
def test_is_url():
    bool_0 = True
    bool_1 = is_url(bool_0)


# Generated at 2022-06-26 01:57:21.461542
# Unit test for function is_email
def test_is_email():
    """
    Test if the function is_email returns the correct value.

    :return: None
    """
    # Case 1: Valid email
    assert is_email("nnayak@vassar.edu") is True

    # Case 2: Invalid email with invalid characters
    assert is_email("nnayak~@vassar.edu") is False
    assert is_email("nna@yak@vassar.edu") is False

    # Case 3: Invalid email with invalid length
    assert is_email("nnayak@vassar.com") is False


# Generated at 2022-06-26 01:57:24.991660
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    input_string_0 = '9781474040952'
    isbn_checker = __ISBNChecker(input_string_0)
    actual = isbn_checker.is_isbn_13()
    expected = True
    assert actual == expected


# Generated at 2022-06-26 01:57:28.679388
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-0-306-40615-7').is_isbn_13() == True


# Generated at 2022-06-26 01:57:31.500028
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    checker = __ISBNChecker('0316068047')
    assert (checker.is_isbn_10() == True)


# Generated at 2022-06-26 01:57:39.464778
# Unit test for function is_email
def test_is_email():
    assert is_email("bob@gmail.com") == True
    assert is_email("bob@gmail.com") == False
test_is_email()


# Generated at 2022-06-26 01:57:44.081647
# Unit test for function is_ip_v4
def test_is_ip_v4():
    if is_ip_v4('255.200.100.75'):
        print("test is_ip_v4 PASS")
    assert is_ip_v4('255.200.100.75')
    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999')


# Generated at 2022-06-26 01:57:56.358795
# Unit test for function is_url
def test_is_url():
    bool_0 = is_url("http://www.github.com/Django")
    assert (bool_0 == True), "is_url Test-0: http://www.github.com/Django"

    bool_1 = is_url("http://www.google.com/")
    assert (bool_1 == True), "is_url Test-1: http://www.google.com/"

    bool_2 = is_url("https://www.google.com/")
    assert (bool_2 == True), "is_url Test-2: https://www.google.com/"

    bool_3 = is_url("google.com")
    assert (bool_3 == False), "is_url Test-3: google.com"

    bool_4 = is_url("https://www.github.com/")

# Generated at 2022-06-26 01:58:01.354884
# Unit test for function is_json
def test_is_json():
    assert is_json('test') == False
    assert is_json('{"test"}') == False
    assert is_json('{"test":"success"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-26 01:58:06.725089
# Unit test for function is_email
def test_is_email():
    input_string = 'somebody@example.com'
    str_0 = is_email(input_string)
    print(str_0)


# Generated at 2022-06-26 01:58:11.499389
# Unit test for function is_email
def test_is_email():
    assert is_email('l@a.com') == True
    assert is_email('l@a.com') == True
    assert is_email('la.com') == False
    assert is_email('la.com.com') == False



# Generated at 2022-06-26 01:58:13.680984
# Unit test for function is_json
def test_is_json():
    assert (is_json('"abc"')) == True
    assert (is_json({"abc"})) == False


# Generated at 2022-06-26 01:58:24.374557
# Unit test for function is_email
def test_is_email():
    # tests
    assert is_email('test@test.com') == True
    assert is_email('test.test@test.com') == True
    assert is_email('test.@test.com') == False
    assert is_email('test@test') == False
    assert is_email('test@.') == False
    assert is_email('test@test.com.') == False
    assert is_email('test@test.com ') == False
    assert is_email(' test@test.com') == False
    assert is_email('te st@test.com ') == False
    assert is_email('test @.com') == False
    return {'function_name':'is_email', 'test_case':0}


# Generated at 2022-06-26 01:58:29.669787
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    # Test cases
    isbn_0 = __ISBNChecker("0345391802")
    result_0 = isbn_0.is_isbn_10()
    # Unit tests
    assert result_0 == True
    # Test cases
    isbn_0 = __ISBNChecker("9824012909")
    result_0 = isbn_0.is_isbn_10()
    # Unit tests
    assert result_0 == True
    # Test cases
    isbn_0 = __ISBNChecker("1369283454")
    result_0 = isbn_0.is_isbn_10()
    # Unit tests
    assert result_0 == True
    # Test cases
    isbn_0 = __ISBNChecker("0970161049")

# Generated at 2022-06-26 01:58:31.281874
# Unit test for function is_email
def test_is_email():
    assert is_email("mariob@gmail.com") == True


# Generated at 2022-06-26 01:58:46.216422
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    # assert __ISBNChecker('030640615').is_isbn_10()
    assert __ISBNChecker('0-306-40615-2').is_isbn_10()
    assert not __ISBNChecker('0-306-40615-3').is_isbn_10()
    assert not __ISBNChecker('foo').is_isbn_10()
    assert __ISBNChecker('0306406152').is_isbn_10()
    assert not __ISBNChecker('0306406153').is_isbn_10()
    assert not __ISBNChecker('foo').is_isbn_10()
    assert __ISBNChecker('9780306406157').is_isbn_10()
    assert not __ISBNChecker('9780306406158').is_isbn_10()


# Generated at 2022-06-26 01:58:48.888226
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    checker = __ISBNChecker("ABCD-9012-3456")
    bool_0 = checker.is_isbn_10()


# Generated at 2022-06-26 01:58:50.376534
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    test_case_0()

# PUBLIC API



# Generated at 2022-06-26 01:58:57.370472
# Unit test for function is_ip_v4
def test_is_ip_v4():
    # check valid input
    assert is_ip_v4('255.200.100.75')
    assert is_ip_v4('255.200.100.10')
    # check invalid input
    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999')
    assert not is_ip_v4('255.200.100')
    assert not is_ip_v4('255.200.100.10.75')


# Generated at 2022-06-26 01:59:01.080253
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    try:
        __ISBNChecker(bool_0, True)
        pass_0 = True
    except InvalidInputError:
        pass_0 = False
    try:
        __ISBNChecker(str_0, True)
        pass_1 = True
    except InvalidInputError:
        pass_1 = False


# Generated at 2022-06-26 01:59:05.595679
# Unit test for function is_email
def test_is_email():
    assert is_email('a@b.com') == True
    assert is_email('c@d.com') == True
    assert is_email('e@f.com') == True
    assert is_email('g@h.com') == True
    assert is_email('i@j.com') == True
    
    

# Generated at 2022-06-26 01:59:16.143113
# Unit test for function is_email
def test_is_email():
    # test_case_0
    # fails because '@gmail.com is not a valid email
    # assert is_email(bool_0) == bool_1

    # test_case_1
    test_case_1 = 'my.email@the-provider.com'
    bool_1 = True
    bool_2 = is_email(test_case_1)
    assert bool_1 == bool_2

    # test_case_2
    # test_case_2 = '@gmail.com'
    # bool_1 = False
    # bool_2 = is_email(test_case_2)
    # assert bool_1 == bool_2



# Generated at 2022-06-26 01:59:23.078306
# Unit test for function is_email
def test_is_email():
    # Test case 0
    bool_0 = True
    bool_1 = is_isogram(bool_0)
    if not bool_1:
        print('Expected an example, but got: {0}'.format(is_email(bool_0)))

    bool_0 = False
    bool_1 = is_isogram(bool_0)
    if not bool_1:
        print('Expected an example, but got: {0}'.format(is_email(bool_0)))


# Generated at 2022-06-26 01:59:26.663696
# Unit test for function is_email
def test_is_email():
    print("Unit test for function is_email")
    bool_0 = True
    bool_1 = is_isogram(bool_0)
    print("The output should be True")
    print("The output is " + str(bool_1))

test_case_0()
test_is_email()


# Generated at 2022-06-26 01:59:29.397646
# Unit test for function is_email
def test_is_email():
    input_string = 'test.test@test.test'
    expected = True
    actual = is_email(input_string)
    assert expected == actual


# Generated at 2022-06-26 01:59:47.231713
# Unit test for function is_email
def test_is_email():
    input_string_1 = 'example.com'
    expected_output = False
    output = is_email(input_string_1)
    assert output == expected_output, 'Got: %s instead of %s for input %s.' % (output, expected_output, input_string_1)

    input_string_2 = 'joe.bloggs@gmail.com'
    expected_output = True
    output = is_email(input_string_2)
    assert output == expected_output, 'Got: %s instead of %s for input %s.' % (output, expected_output, input_string_2)

    input_string_3 = 'joe.blog@gmail.com'
    expected_output = True
    output = is_email(input_string_3)

# Generated at 2022-06-26 01:59:56.118534
# Unit test for function is_json
def test_is_json():
  # Testing if a valid json string is identified as json
  string_0 = '{"name": "Peter"}'
  bool_0 = is_json(string_0)
  if bool_0 == True:
    print("Passed case 0: Valid json string")

  # Testing if a non-json string is identified as json
  string_1 = '{nope}'
  bool_1 = is_json(string_1)
  if bool_1 == False:
    print("Passed case 1: Non-json string")


# Generated at 2022-06-26 01:59:58.180065
# Unit test for function is_email
def test_is_email():
  bool_0 = True
  bool_1 = is_email(bool_0)


# Generated at 2022-06-26 02:00:09.649334
# Unit test for function is_email
def test_is_email():
    email_0 = 'a@a.a'
    email_1 = 'a@a.com'
    email_2 = 'foo@bar.baz'
    email_3 = 'ab+cd@gmail.com'
    email_4 = 'foo@bar+baz.com'
    email_5 = 'foo@bar.baz.info'
    email_6 = 'foo@bar.baz.info.info'
    email_7 = 'foo.bar@baz.info'
    email_8 = 'foo@bar.baz.i'
    email_9 = 'foo@bar.baz.infop'
    email_10 = 'foo@bar.baz.infor'
    email_11 = 'foo@bar.baz.infop'

# Generated at 2022-06-26 02:00:21.684143
# Unit test for function is_email
def test_is_email():
    bool_0 = is_email("email@email.com")
    assert bool_0 == True
    bool_1 = is_email("email@email")
    assert bool_1 == False
    bool_2 = is_email("email.com")
    assert bool_2 == False
    bool_3 = is_email("email@email.com.email")
    assert bool_3 == True
    bool_4 = is_email("email.email@email.com")
    assert bool_4 == True
    bool_5 = is_email("email@email.com.com")
    assert bool_5 == True
    bool_6 = is_email("Email@email.com")
    assert bool_6 == False
    bool_7 = is_email("email.email@email")
    assert bool_7 == False

# Generated at 2022-06-26 02:00:25.145731
# Unit test for function is_ip_v4
def test_is_ip_v4():
    input_0 = "0.0.0.1"
    expected_0 = True
    output_0 = is_ip_v4(input_0)
    assert output_0 == expected_0


# Generated at 2022-06-26 02:00:27.415571
# Unit test for function is_json
def test_is_json():
    bool_0 = is_json("{}")
    print(str(bool_0)) # Expected True


# Generated at 2022-06-26 02:00:35.194325
# Unit test for function is_email
def test_is_email():
    # Testing edge cases
    # Edge case 1
    str_0 = "my.email@the-provider.com"
    bool_0 = is_email(str_0)
    # Edge case 2
    str_1 = "@gmail.com"
    bool_1 = is_email(str_1)
    # Edge case 3
    str_2 = "email@domain.com"
    bool_2 = is_email(str_2)


# Generated at 2022-06-26 02:00:38.908480
# Unit test for function is_ip_v4
def test_is_ip_v4():
    print(is_ip_v4("255.200.100.75"))
    print(is_ip_v4("nope"))
    print(is_ip_v4("255.200.100.999"))


# Generated at 2022-06-26 02:00:47.650292
# Unit test for function is_ip_v4
def test_is_ip_v4():
    # True case
    input_string = "192.168.1.1"
    expected_result = True
    actual_result = is_ip_v4(input_string)
    check_actual_expected_results(actual_result, expected_result)
    #False case
    input_string = "192.168.1.0"
    expected_result = False
    actual_result = is_ip_v4(input_string)
    check_actual_expected_results(actual_result, expected_result)



# Generated at 2022-06-26 02:00:55.517229
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    test_case_0()


# Generated at 2022-06-26 02:01:00.084085
# Unit test for function is_email
def test_is_email():
    assert is_email("abc@example.com")
    assert is_email("abc.123@example.com")
    assert is_email("user+mailbox/department=shipping@example.com")
    assert is_email("\"just\"a\"box\"@example.com")
    assert not is_email("abc@example")


# Generated at 2022-06-26 02:01:11.115379
# Unit test for function is_email
def test_is_email():
    assert is_email("user@gmail.com") is True, "Simple email"
    assert is_email("user@hello.com") is True, "Email with dot in domain"
    assert is_email("user@hello.net") is True, "Email with other domain"
    assert is_email("gmail.com") is False, "Domain"
    assert is_email("user@gmail") is False, "Without dot in domain"
    assert is_email(".gmail.com") is False, "Starting with dot"
    assert is_email("") is False, "Empty email"
    assert is_email(123) is False, "Integer as email"
    assert is_email(b"user@gmail.com") is False, "Binary email"
    assert is_email("user@gmail.com ") is False, "Email with trailing space"

# Generated at 2022-06-26 02:01:14.784832
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    input_string = '1234567890'
    expected = True 
    actual = __ISBNChecker(input_string).is_isbn_10()
    msg = "Expected: " + str(expected) + "\nActual: " + str(actual)
    assert actual == expected, msg


# Generated at 2022-06-26 02:01:23.668556
# Unit test for function is_ip_v4
def test_is_ip_v4():
    # Test case 1
    input_string_0 = "255.200.100.75"
    expected_result_0 = True
    is_ip_v4_result = is_ip_v4(input_string_0)
    print("Testing input: " + input_string_0)
    print("Expected result: " + str(expected_result_0))
    print("Actual result: " + str(is_ip_v4_result))
    assert(expected_result_0 == is_ip_v4_result)

    # Test case 2
    input_string_1 = "255.200.100.999"
    expected_result_1 = False
    is_ip_v4_result = is_ip_v4(input_string_1)
    print("Testing input: " + input_string_1)

# Generated at 2022-06-26 02:01:26.677481
# Unit test for function is_ip_v4
def test_is_ip_v4():
    print("Test is_ip_v4")
    assert is_ip_v4("255.200.100.75") == True
    print("is_ip_v4 correctly works")


# Generated at 2022-06-26 02:01:30.683878
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('9781449365035').is_isbn_13() == True
    assert __ISBNChecker('1447164889').is_isbn_13() == False


# Generated at 2022-06-26 02:01:37.865646
# Unit test for function is_email
def test_is_email():
    assert is_email('abc@abc.abc') == True
    assert is_email('\(abc@abc.abc') == True
    assert is_email('abc@abc.abc') == True
    assert is_email('ab..c@abc.abc') == True
    assert is_email('abc@abc.abc') == True
    assert is_email('abc@abc.abc') == True
    assert is_email('abc@abc.abc') == True
    assert is_email('abc@abc.abc') == True



# Generated at 2022-06-26 02:01:39.406028
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-26 02:01:53.326821
# Unit test for function is_email
def test_is_email():

    bool_0 = True
    bool_1 = is_email(bool_0)

    # case 1:
    str_1 = "my.email@the-provider.com"
    bool_2 = is_email(str_1)
    if bool_2:
        print("email: " + str_1 + " is valid")
    else:
        print("email: " + str_1 + " is invalid")

    # case 2:
    str_2 = "my.email@the-provider."
    bool_3 = is_email(str_2)
    if bool_3:
        print("email: " + str_2 + " is valid")
    else:
        print("email: " + str_2 + " is invalid")

    # case 3:
    str_3 = "abc@abc@abc"