

# Generated at 2022-06-26 01:52:25.177884
# Unit test for function is_integer
def test_is_integer():
    # Test case 0
    def test_case_0():
        str_0 = 'Oc?Ptsxmy\\u}IO<s%('
        bool_0 = is_integer(str_0)
        return bool_0
    bool_0 = test_case_0()
    return bool_0


# Generated at 2022-06-26 01:52:26.592473
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}')


# Generated at 2022-06-26 01:52:36.688735
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    checker = __ISBNChecker('978-1-56619-909-4')
    bool_0 = checker.is_isbn_13()
    bool_1 = checker.is_isbn_13()
    bool_2 = checker.is_isbn_13()
    bool_3 = checker.is_isbn_13()
    bool_4 = checker.is_isbn_13()
    bool_5 = checker.is_isbn_13()
    bool_6 = checker.is_isbn_13()
    bool_7 = checker.is_isbn_13()
    bool_8 = checker.is_isbn_13()
    bool_9 = checker.is_isbn_13()


# Generated at 2022-06-26 01:52:41.833305
# Unit test for function is_email
def test_is_email():
    str_0 = 'Nx}P@{b'
    bool_0 = is_email(str_0)
    assert bool_0


# Generated at 2022-06-26 01:52:49.551372
# Unit test for function is_ip_v4
def test_is_ip_v4():
    str_0 = '2a01:110::1'
    bool_0 = is_ip_v4(str_0)
    if bool_0:
        print('expected bool_0 to be false, but it was %s' % (bool_0))
        return False
    str_1 = '255.255.255.255'
    bool_1 = is_ip_v4(str_1)
    if not bool_1:
        print('expected bool_1 to be true, but it was %s' % (bool_1))
        return False
    str_2 = '255.255.255.256'
    bool_2 = is_ip_v4(str_2)
    if bool_2:
        print('expected bool_2 to be false, but it was %s' % (bool_2))
       

# Generated at 2022-06-26 01:52:51.402401
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('127.0.0.1') == True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip('localhost') == False

# Generated at 2022-06-26 01:52:54.304843
# Unit test for function is_ip_v4
def test_is_ip_v4():
    str_0 = 'Oc?Ptsxmy\\u}IO<s%('
    bool_0 = is_ip_v4(str_0)



# Generated at 2022-06-26 01:52:59.972219
# Unit test for function is_ip_v4
def test_is_ip_v4():
    str_0 = '255.200.100.75'
    bool_0 = is_ip_v4(str_0)
    assert bool_0 == True
    str_1 = 'nope'
    bool_1 = is_ip_v4(str_1)
    assert bool_1 == False
    str_2 = '255.200.100.999'
    bool_2 = is_ip_v4(str_2)
    assert bool_2 == False


# Generated at 2022-06-26 01:53:11.811822
# Unit test for function is_json
def test_is_json():
    assert is_json('{"foo": "bar"}') == True
    assert is_json('{"foo": bar}') == False 
    assert is_json('{"foo": }') == False
    assert is_json('{"foo": }') == False
    assert is_json('{"foo": "bar}"') == False
    assert is_json('{"foo": "bar", "foo": "bar"}') == True
    assert is_json('{"foo": "bar" "foo2": "bar2"}') == False
    assert is_json('{"foo": "bar", "foo2": "bar2"}') == True
    assert is_json('{"foo": [{"foo": "bar", "foo2": "bar2"}]}') == True

# Generated at 2022-06-26 01:53:24.085029
# Unit test for function is_json
def test_is_json():
    str_0 = ''
    str_1 = 'Y'
    str_2 = '['
    str_3 = '{"name": "Peter"}'
    str_4 = '{"name": "Peter"}'
    str_5 = '{"name": "Peter"}'
    str_6 = '{"name": "Peter"}'
    str_7 = '{"name": "Peter"}'
    str_8 = '{"name": "Peter"}'
    str_9 = '{"name": "Peter"}'
    str_10 = '{"name": "Peter"}'
    str_11 = '{"name": "Peter"}'
    str_12 = '{"name": "Peter"}'
    str_13 = '{"name": "Peter"}'
    str_14 = '{"name": "Peter"}'

# Generated at 2022-06-26 01:53:39.094761
# Unit test for function is_integer
def test_is_integer():
    str_0 = 'Oc?Ptsxmy\\u}IO<s%('
    bool_0 = is_integer(str_0)
    assert bool_0 == False
    str_1 = '@'
    bool_1 = is_integer(str_1)
    assert bool_1 == False
    str_2 = '5'
    bool_2 = is_integer(str_2)
    assert bool_2 == True
    str_3 = '.'
    bool_3 = is_integer(str_3)
    assert bool_3 == False
    str_4 = ''
    bool_4 = is_integer(str_4)
    assert bool_4 == False
    str_5 = '7'
    bool_5 = is_integer(str_5)
    assert bool_5 == True
    str_

# Generated at 2022-06-26 01:53:42.143683
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    str_0 = '9781118912705'
    bool_0 = __ISBNChecker(str_0).is_isbn_13()


# Generated at 2022-06-26 01:53:50.273835
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('-85') == True
    assert is_integer('-0.1') == False
    assert is_integer('0') == True
    assert is_integer('819') == True
    assert is_integer('70.0') == False
    assert is_integer('70.00') == False
    assert is_integer('39.73') == False
    assert is_integer('0.0') == False



# Generated at 2022-06-26 01:53:56.440017
# Unit test for function is_email
def test_is_email():
    str_0 = 'B^'
    # is_email(str_0)
    str_1 = '>C'
    # is_email(str_1)
    str_2 = '@N}h_?#z0BVu:~>'
    # is_email(str_2)


# Generated at 2022-06-26 01:53:59.565351
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    str_0 = '123456789X'
    bool_0 = __ISBNChecker(str_0).is_isbn_10()
    print(bool_0)


# Generated at 2022-06-26 01:54:01.471324
# Unit test for function is_email
def test_is_email():
    str_0 = 'uV7X3;tB=r@r#%%R]#V*'
    bool_0 = is_email(str_0)
    return bool_0


# Generated at 2022-06-26 01:54:05.264096
# Unit test for function is_json
def test_is_json():
    assert True == is_json('{"name": "Peter"}')
    assert True == is_json('[1, 2, 3]')
    assert False == is_json('{nope}')
    print("Unit test for is_json passed!")


# Generated at 2022-06-26 01:54:15.698172
# Unit test for function is_integer
def test_is_integer():
    assert is_integer("42") is True
    assert is_integer("-42") is True
    assert is_integer("+42") is True
    assert is_integer("1e3") is True
    assert is_integer("1") is True
    assert is_integer("-1") is True
    assert is_integer("+1") is True
    assert is_integer("42.0") is False



# Generated at 2022-06-26 01:54:19.314988
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    obj___ISBNChecker_0 = __ISBNChecker('5892365498741')
    bool_0 = obj___ISBNChecker_0.is_isbn_13()
    assert bool_0 == True


# Generated at 2022-06-26 01:54:20.909533
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('otto') == True, "Unable to determine if otto is a palindrome"


# Generated at 2022-06-26 01:54:35.355410
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    test_input_string = "9781449358068"
    test_result = __ISBNChecker(test_input_string).is_isbn_13()
    assert test_result


# Generated at 2022-06-26 01:54:47.314014
# Unit test for function is_credit_card
def test_is_credit_card():
    # Test 1
    str_0 = 'L-w5r5qge:ay:)0*_'
    bool_0 = is_credit_card(str_0, 'DINERS_CLUB')
    assert bool_0
    # Test 2
    str_1 = 'y8L-w5r5qge:ay:)0*_'
    bool_1 = is_credit_card(str_1, 'DINERS_CLUB')
    assert not bool_1
    # Test 3
    str_2 = 'q>W8aE+xK?l+,wS,lS+WK'
    bool_2 = is_credit_card(str_2, 'JCB')
    assert bool_2
    # Test 4

# Generated at 2022-06-26 01:54:51.248420
# Unit test for function is_credit_card
def test_is_credit_card():
    input_ = ("VISA", "4242424242424242")
    expected_ = True
    actual_ = is_credit_card(*input_)
    assert expected_ == actual_


# Generated at 2022-06-26 01:54:59.161818
# Unit test for function is_url
def test_is_url():
    # Test 1
    input_string = 'http://www.mysite.com'
    allowed_schemes = ['http', 'https']
    expected_output = True
    assert is_url(input_string, allowed_schemes) == expected_output

    # Test 2
    input_string = 'mysite.com'
    allowed_schemes = ['http', 'https']
    expected_output = False
    assert is_url(input_string, allowed_schemes) == expected_output

test_is_url()


# Generated at 2022-06-26 01:55:03.089075
# Unit test for function is_email
def test_is_email():
    print(is_email('hello, world!@smtp.gmail.com'))
    print(is_email('hello, world!@smtp'))
    print(is_email('hello, world!@com'))
    print(is_email('hello, world!@'))
    print(is_email('hello, world!'))


# Generated at 2022-06-26 01:55:04.177298
# Unit test for function is_json
def test_is_json():
    pass


# Generated at 2022-06-26 01:55:07.735767
# Unit test for function is_url
def test_is_url():
    assert(is_url('http://www.mysite.com') == True)
    assert(is_url('https://mysite.com') == True)
    assert(is_url('.mysite.com') == False)


# Generated at 2022-06-26 01:55:09.485601
# Unit test for function is_isbn
def test_is_isbn():
    assert(is_isbn('3724808681'))
    assert(is_isbn('3724808681-5'))
    assert(is_isbn('9791092140066'))
    assert(is_isbn('979-10-92140-06-6'))

# Generated at 2022-06-26 01:55:10.713574
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn("1491943146") == True
    assert is_isbn("149194314X") == False
    assert is_isbn("149194314x") == False


# Generated at 2022-06-26 01:55:12.581829
# Unit test for function is_url
def test_is_url():
    assert is_url('https://www.google.com') == True


# Generated at 2022-06-26 01:55:20.880032
# Unit test for function is_isbn
def test_is_isbn():
    expected_bool_0=True
    actual_bool_0 = False
    try:
        test_case_0()
        actual_bool_0 = True
    except:
        pass
    assert expected_bool_0==actual_bool_0


# Generated at 2022-06-26 01:55:28.680521
# Unit test for function is_email
def test_is_email():
    str_0 = 'e>Dl=*aT$8)Ys@sz^m9kc%' # for testing normal email
    bool_0 = is_email(str_0) # should return True
    print("test_is_email(): First test case passed.")
    str_1 = '@gmail.com' # for testing email starting with @
    bool_1 = is_email(str_1) # should return False
    print("test_is_email(): Second test case passed.")
    str_2 = 'email@example..com' # for testing email containing consecutive dots
    bool_2 = is_email(str_2) # should return False
    print("test_is_email(): Third test case passed.")
    str_3 = 'hi"lo@gmail.com' # for testing email containing escaped spaces
    bool_3

# Generated at 2022-06-26 01:55:34.501994
# Unit test for function is_email
def test_is_email():
    input_string_0 = 'v:?)$P[+xfm@&0K(f3'
    expected_output_0 = False
    actual_output_0 = is_email(input_string_0)
    assert actual_output_0 == expected_output_0, 'Failed: test_is_email'


# Generated at 2022-06-26 01:55:38.552265
# Unit test for function is_isbn
def test_is_isbn():
    # Test 0: Default test
    try:
        print('Test 0: Default test')
        test_case_0()
    except:
        print('test_case_0 failed')


# Main function

# Generated at 2022-06-26 01:55:41.657966
# Unit test for function is_email
def test_is_email():
    str_0 = '@gmail.com'
    bool_0 = is_email(str_0)
    str_1 = '@gmail.com'
    bool_1 = is_email(str_1)



# Generated at 2022-06-26 01:55:52.043509
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert not is_email('@gmail.com')

    assert is_email('abc@def.ghi')
    assert is_email('abc-def@ghi.com')
    assert is_email('abc.def@ghi.com')
    assert is_email('abc+def@ghi.com')
    assert is_email('abc.def@ghi-jkl.com')
    assert is_email('abc.def@ghi-jkl-mno.com')
    assert is_email('abc-def@ghi-jkl-mno.com')

    assert is_email('abc@def.ghi.com')
    assert is_email('abc-def@ghi-jkl-mno.com')

    assert is_email

# Generated at 2022-06-26 01:56:04.083183
# Unit test for function is_credit_card
def test_is_credit_card():
    str_0 = 'T0CSJ'
    str_1 = 'T0CSJ'
    bool_0 = is_credit_card(str_0, str_1)
    #print(bool_0)

    str_2 = 'XE0-0+c/'
    str_3 = 'XE0-0+c/'
    #print(is_credit_card(str_2, str_3))

    str_4 = 'Y2'
    str_5 = 'Y2'
    #print(is_credit_card(str_4, str_5))

    str_6 = 'Y2'
    str_7 = 'Y2'
    #print(is_credit_card(str_6, str_7))

    str_8 = '9L7@'

# Generated at 2022-06-26 01:56:09.302742
# Unit test for function is_isbn
def test_is_isbn():
    assert True == is_isbn('1A2B3C4D5E6F7G8H9I0J')
    assert False == is_isbn('1A2B3C4D5E6F7G8H9I0K')
    assert True == is_isbn('9781853260087')
    assert False == is_isbn('9781853260088')
    assert True == is_isbn('3-598-21500-2')
    assert False == is_isbn('3-598-21500-3')
    assert True == is_isbn('1-61729-085-4')
    assert False == is_isbn('1-61729-085-5')
    assert True == is_isbn('0-306-40615-2')
    assert False == is_

# Generated at 2022-06-26 01:56:13.655334
# Unit test for function is_email
def test_is_email():
    str_0 = '<"@^]nB&e`[sx+T>TQkb{zGR}n*J'
    str_1 = ''
    bool_0 = is_email(str_0)
    bool_1 = is_email(str_1)


# Generated at 2022-06-26 01:56:18.006400
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card("4716461583322103", "VISA")
    assert is_credit_card("6331101999990016", "DISCOVER")
    assert is_credit_card("4024007176512380", "VISA")
    assert not is_credit_card("6011000990139424", "MASTERCARD")    
    
    
    

# Generated at 2022-06-26 01:56:30.187694
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True 
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-26 01:56:40.186547
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    str_0 = 'v:?)$P[+xfm@&0K(f3'
    str_1 = '9791311221'
    str_2 = '2-233-08445-2'
    str_3 = '3-233-08445-2'
    str_4 = '3-233-08445-'
    str_5 = '3-233-08445-12'
    bool_0 = __ISBNChecker(str_0).is_isbn_13()
    bool_1 = __ISBNChecker(str_1).is_isbn_13()
    bool_2 = __ISBNChecker(str_2).is_isbn_13()
    bool_3 = __ISBNChecker(str_3).is_isbn_13()
    bool_4 = __ISBN

# Generated at 2022-06-26 01:56:51.775158
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    # test case 1
    str_1 = '978-0-596-52068-7'
    isbn_1 = __ISBNChecker(str_1, normalize=True)
    bool_1 = isbn_1.is_isbn_13()

    # test case 2
    str_2 = '978 0 596 52068 7'
    isbn_2 = __ISBNChecker(str_2, normalize=True)
    bool_2 = isbn_2.is_isbn_13()

    # test case 3
    str_3 = '978-0-596-52068-5'
    isbn_3 = __ISBNChecker(str_3, normalize=True)
    bool_3 = isbn_3.is_isbn_13()

    # test case 4
    str_4

# Generated at 2022-06-26 01:57:03.513578
# Unit test for function is_email
def test_is_email():
    str_0 = 'I6%cM6v(q3?:w-g!l2}KH^'
    bool_0 = is_email(str_0)
    bool_1 = is_email('buggs.bunny@acme.com')
    bool_2 = is_email('buggs.bunny@acme.co.uk')
    bool_3 = is_email('buggs.bunny@acme.co.')
    bool_4 = is_email('buggs.bunny@acme..com')
    bool_5 = is_email('.buggs.bunny@acme.com')
    bool_6 = is_email('buggs.bunny@.acme.com')

# Generated at 2022-06-26 01:57:11.332858
# Unit test for function is_email
def test_is_email():
    # Initialization
    str_0 = '<>@\\'
    # Check if the first argument of the function raises an exception
    try:
        # Call the function
        is_email(str_0)
    except Exception:
        # AssertionError
        assert True
    except ValueError:
        # AssertionError
        assert True
    # Check the conditions of decision if in main
    if (not is_full_string(str_0)):
        # The first branch of the decision evaluates to TRUE
        # AssertionError
        assert True
    # Check the conditions of decision if in main
    if len(str_0) > 320:
        # The second branch of the decision evaluates to TRUE
        # AssertionError
        assert True
    # Check the conditions of decision if in main

# Generated at 2022-06-26 01:57:18.849908
# Unit test for function is_ip_v4
def test_is_ip_v4():
    str_0 = '255.200.100.75'
    str_1 = 'nope'
    str_2 = '255.200.100.999'
    bool_0 = is_ip_v4(str_0)
    bool_1 = is_ip_v4(str_1)
    bool_2 = is_ip_v4(str_2)


# Generated at 2022-06-26 01:57:21.895996
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    __isbn_checker = __ISBNChecker('3866360570')
    bool_0 = __isbn_checker.is_isbn_10()


# Generated at 2022-06-26 01:57:35.266901
# Unit test for function is_email
def test_is_email():
    assert (is_email('my.email@the-provider.com') == True)
    assert (is_email('@gmail.com') == False)
    assert (is_email('myemail@the-provider.com') == True)
    assert (is_email('my.emailthe-provider.com') == False)
    assert (is_email('my.email@the-provider') == False)
    assert (is_email('my.email@the-provider.c') == False)
    assert (is_email('my.email@the-provider.co') == True)
    assert (is_email('my.email@the-provider.com.') == False)
    assert (is_email('my.email@the-provider.com?') == False)

# Generated at 2022-06-26 01:57:39.356872
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    checker = __ISBNChecker('978-3-16-148410-0', False)
    checker.is_isbn_13()



# Generated at 2022-06-26 01:57:43.964038
# Unit test for method is_isbn_13 of class __ISBNChecker

# Generated at 2022-06-26 01:57:56.220761
# Unit test for function is_email
def test_is_email():
    str_0 = 'my.email@the-provider.com'
    bool_0 = is_email(str_0)

    assert (bool_0 == True)
    print('Success!')

test_is_email()


# Generated at 2022-06-26 01:58:00.876531
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    str_0 = '-?:[MR?U5GE6X9_6I'
    isbn_checker = __ISBNChecker(str_0)
    bool_0 = isbn_checker.is_isbn_13()


# Generated at 2022-06-26 01:58:12.439801
# Unit test for function is_ip_v4
def test_is_ip_v4():
    """
    Returns:

    """
    assert is_ip_v4('192.168.100.100') == True
    assert is_ip_v4('192.168.200.100') == True
    assert is_ip_v4('192.168.300.100') == True
    assert is_ip_v4('192.168.400.100') == True
    assert is_ip_v4('192.168.500.100') == True
    return is_ip_v4


# Generated at 2022-06-26 01:58:24.000116
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    str_0 = '1-2-3-4-5-6-7-8-9-9'
    str_1 = '1-2-3-4-5-6-7-8-9'
    str_2 = '1-2-3-4-5-6-7-8-9-10'
    bool_0 = __ISBNChecker(str_0).is_isbn_13()
    bool_1 = __ISBNChecker(str_1).is_isbn_13()
    bool_2 = __ISBNChecker(str_2).is_isbn_13()
    bool_3 = True
    bool_4 = __ISBNChecker(str_2).is_isbn_13()
    assert bool_0 == bool_3
    assert bool_1 == bool_3
   

# Generated at 2022-06-26 01:58:29.397049
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@provider.co.uk')
    assert not is_email('@gmail.com')
    assert not is_email('a@a.b')
    assert not is_email('a@.com')
    assert is_email('a@gmail.com')
    assert is_email('first_name.last_name@domain.com')
    assert is_email('a.b@gmail.com')
    assert is_email('"my name"@the-provider.com')
    assert is_email('"my.name"@the-provider.com')
    assert is_email('first_name.last_name+extra@domain.com')

# Generated at 2022-06-26 01:58:32.465953
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False

# Generated at 2022-06-26 01:58:39.818917
# Unit test for function is_email
def test_is_email():
    str_0 = 'my.email@the-provider.com'
    expected_0 = True
    actual_0 = is_email(str_0)

    str_1 = '@gmail.com'
    expected_1 = False
    actual_1 = is_email(str_1)

    str_2 = 'my.email@the-provider.comX'
    expected_2 = False
    actual_2 = is_email(str_2)


# Test function for is_email
# test_is_email()


# Generated at 2022-06-26 01:58:42.765571
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False

# Test case for `is_isbn`

# Generated at 2022-06-26 01:58:53.616560
# Unit test for function is_email
def test_is_email():
    # test case 1
    s_0 = '@'
    b_0 = is_email(s_0)
    assert not b_0

    # test case 2
    s_0 = 'my.email@the-provider.com'
    b_0 = is_email(s_0)
    assert b_0

    # test case 3
    s_0 = 'my.email@the-provider.com'
    b_0 = is_email(s_0)
    assert b_0

    # test case 4
    s_0 = '.my.email@the-provider.com'
    b_0 = is_email(s_0)
    assert b_0

    # test case 5
    s_0 = 'my.email.@the-provider.com'

# Generated at 2022-06-26 01:58:56.481923
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    str_0 = 'A240-3M-7(39+@8I'
    bool_0 = __ISBNChecker(str_0).is_isbn_13()


# Generated at 2022-06-26 01:59:15.366574
# Unit test for function is_email
def test_is_email():
    str_0 = '"v:?)$P["'
    str_1 = 'v:?)$P[+xfm@&0K(f3'
    str_2 = 'iXNy7xoKjTkV1T'
    str_3 = 'O&OjKue7!@3#X'
    str_4 = 'v:?)$P[+xfm@&0K(f3'
    str_5 = '@!'
    str_6 = '['
    str_7 = ']aeMt'
    str_8 = 'X'
    str_9 = '~'
    str_10 = ':)'
    str_11 = ';'
    str_12 = '`'
    str_13 = 'mP'
    str_14 = 'zMA@'

# Generated at 2022-06-26 01:59:19.371059
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    str_0 = '1-2345-6789-0'
    str_1 = '1234567890123'
    checker = __ISBNChecker(str_1)
    bool_0 = checker.is_isbn_13()


# Generated at 2022-06-26 01:59:28.167743
# Unit test for function is_email
def test_is_email():
    # Input data
    str_0 = '{`L#f,%+s'
    str_1 = '\\'
    str_2 = '\\*nj'
    str_3 = 'EFjK.>7in<a'
    str_4 = 'D'
    str_5 = '6jFQXHJE[8'
    str_6 = '"Kjn#`4\\#n'
    str_7 = 'aa.0'
    str_8 = '<)G;2a|'
    str_9 = 'Mf~'
    # Call the tested function
    bool_0 = is_email(str_0)
    bool_1 = is_email(str_1)
    bool_2 = is_email(str_2)
    bool_3 = is_email

# Generated at 2022-06-26 01:59:29.570991
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    raise NotImplementedError("Not implemented yet")


# Generated at 2022-06-26 01:59:41.587876
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('132769111').is_isbn_10()
    assert __ISBNChecker('192509431').is_isbn_10()
    assert __ISBNChecker('128919583').is_isbn_10()
    assert __ISBNChecker('193668017').is_isbn_10()
    assert __ISBNChecker('121781822').is_isbn_10()
    assert __ISBNChecker('124699081').is_isbn_10()
    assert __ISBNChecker('206927062').is_isbn_10()
    assert __ISBNChecker('188073875').is_isbn_10()
    assert __ISBNChecker('103745034').is_isbn_10()

# Generated at 2022-06-26 01:59:57.314327
# Unit test for function is_email
def test_is_email():
    # case 0
    str_0 = 'my.email@the-provider.com'
    str_1 = '@gmail.com'
    str_2 = 'my.email@@the-provider.com'
    str_3 = 'my..email@the-provider.com'
    str_4 = 'my.email.@the-provider.com'
    str_5 = 'my.email@the.provider.com'
    str_6 = 'my.email@-the-provider.com'
    str_7 = 'my.email@-the-provider.com'
    str_8 = 'my.email@-the-provider.com'
    str_9 = 'my.email@-the-provider.com'

# Generated at 2022-06-26 02:00:02.148831
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    input_string = '9788125948233'
    isbn_checker = __ISBNChecker(input_string, normalize=False)
    result = isbn_checker.is_isbn_13()
    assert result


# Generated at 2022-06-26 02:00:03.995475
# Unit test for function is_email
def test_is_email():
    isEmail = is_email('my.email@the-provider.com')


# Generated at 2022-06-26 02:00:09.303709
# Unit test for function is_json
def test_is_json():
    assert is_json('{}') == True, 'Test #0'
    assert is_json('{"key": "value"}') == True, 'Test #1'
    assert is_json('[1, 2, 3]') == True, 'Test #2'
    assert is_json('{nope}') == False, 'Test #3'


# Generated at 2022-06-26 02:00:21.390532
# Unit test for function is_email
def test_is_email():
    str_0 = ".my-email@the-provider.com"
    bool_0 = is_email(str_0)

    str_1 = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
    bool_1 = is_

# Generated at 2022-06-26 02:00:32.187440
# Unit test for function is_email
def test_is_email():
    str_0 = 'f#Ps(1Yi1.I#x!+[X'
    bool_0 = is_email(str_0)
    return bool_0


# Generated at 2022-06-26 02:00:44.514604
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('1.1.1.1') == True, 'Test 0 failed.'
    assert is_ip_v4('999.999.999.999') == False, 'Test 1 failed.'
    assert is_ip_v4('999.999.999') == False, 'Test 2 failed.'
    assert is_ip_v4('a.a.a.a') == False, 'Test 3 failed.'
    assert is_ip_v4('999.999.999.999.999') == False, 'Test 4 failed.'
    assert is_ip_v4('999.999.999.999.999') == False, 'Test 5 failed.'
    assert is_ip_v4('999.999.-999.999') == False, 'Test 6 failed.'

# Generated at 2022-06-26 02:00:51.758960
# Unit test for function is_json
def test_is_json():
    str_0 = '{"name": "Peter"}'
    str_1 = '[1, 2, 3]'
    str_2 = '{nope}'
    bool_0 = is_json(str_0)
    bool_1 = is_json(str_1)
    bool_2 = is_json(str_2)

    if __name__ == "__main__":
        print('boolean value is: ', bool_0)
        print('boolean value is: ', bool_1)
        print('boolean value is: ', bool_2)


# Generated at 2022-06-26 02:00:54.325214
# Unit test for function is_email
def test_is_email():
    str_1 = '"Abc\\@def"@example.com'
    bool_1 = is_email(str_1)
    assert bool_1 == True



# Generated at 2022-06-26 02:01:04.904891
# Unit test for function is_email
def test_is_email():
    assert (is_email('joe@example.com') == True)
    assert (is_email('joe @ example.com') == False)
    assert (is_email('joe+example.com') == False)
    assert (is_email('joe&example.com') == False)
    assert (is_email('joe#example.com') == False)
    assert (is_email('joe$example.com') == False)
    assert (is_email('joe^example.com') == False)
    assert (is_email('joe(example.com') == False)
    assert (is_email('joe)example.com') == False)
    assert (is_email('joe=example.com') == False)
    assert (is_email('joe[example.com') == False)
   

# Generated at 2022-06-26 02:01:15.369662
# Unit test for function is_email

# Generated at 2022-06-26 02:01:24.301886
# Unit test for function is_json
def test_is_json():
    str_0 = ''
    bool_0 = is_json(str_0)
    assert bool_0 == 0

    str_1 = '9tf5)5NbG'
    bool_1 = is_json(str_1)
    assert bool_1 == 0

    str_2 = 'xv*n;h$rGt\r'
    bool_2 = is_json(str_2)
    assert bool_2 == 0

    str_3 = '$>tR1f|F}*'
    bool_3 = is_json(str_3)
    assert bool_3 == 0

    str_4 = 'p/o!:HDP.I]'
    bool_4 = is_json(str_4)
    assert bool_4 == 0

    str_5 = '4tlX|s'

# Generated at 2022-06-26 02:01:26.880146
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}')
    assert is_json('[1, 2, 3]')
    assert not is_json('{nope}')



# Generated at 2022-06-26 02:01:35.591981
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@@the-provider.com') == False
    assert is_email('toto@company.com') == True
    assert is_email('toto@company') == False
    assert is_email('@toto.com') == False
    assert is_email('toto@') == False
    assert is_email('toto.com') == False
    assert is_email(None) == False
    assert is_email('') == False


# Generated at 2022-06-26 02:01:37.129863
# Unit test for function is_email
def test_is_email():
    print('Start test_is_email...')
    test_case_0()


# Generated at 2022-06-26 02:01:52.665295
# Unit test for function is_email
def test_is_email():
    assert(is_email(str_0) == bool_0)


# Generated at 2022-06-26 02:02:01.457681
# Unit test for function is_ip_v4
def test_is_ip_v4():
    # Check whether '172.16.254.1' is an ip v4
    assert is_ip_v4('172.16.254.1')
    # Check whether '172.16.254.1' is an ip v4
    assert not is_ip_v4('127.0.0.0.1')
    # Check whether '255.200.100.75' is an ip v4
    assert is_ip_v4('255.200.100.75')
    # Check whether 'nope' is an ip v4
    assert not is_ip_v4('nope')
    # Check whether '255.200.100.999' is an ip v4
    assert not is_ip_v4('255.200.100.999')
    # Check whether '255.200.100.999' is an ip v4
