

# Generated at 2022-06-26 01:52:31.597526
# Unit test for function is_email
def test_is_email():
    assert is_email("j@yahoo.com") == True
    assert is_email("joe.smith@gmail.com") == True
    assert is_email("joe.smith@yahoo.com") == True
    assert is_email("joe.smith@att.net") == True
    assert is_email("joe.smith@outlook.com") == True
    assert is_email("joe.smith@icloud.com") == True
    assert is_email("joe.smith@zoho.com") == True
    assert is_email("joe@live.com") == True
    assert is_email("joe.smith@live.com") == True



# Generated at 2022-06-26 01:52:44.386916
# Unit test for function is_ip_v4
def test_is_ip_v4():
    str_0 = "255.0.0.0"
    str_1 = "255.255.255.0"
    str_2 = "255.255.255.255"
    str_3 = "0.0.0.0"
    str_4 = "0.0.0.255"
    str_5 = "0.0.255.0"
    str_6 = "0.0.255.255"
    str_7 = "0.255.0.0"
    str_8 = "0.255.0.255"
    str_9 = "0.255.255.0"
    str_10 = "0.255.255.255"
    str_11 = "255.0.0.255"
    str_12 = "255.0.255.0"
    str_13

# Generated at 2022-06-26 01:52:56.296677
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    inp_0 = '9780139495822' # True
    inp_1 = '978-0-13-949582-2' # True
    inp_2 = '978-0-13-949582-0' # False
    inp_3 = '978-0-13-949582-4' # False
    inp_4 = '' # False
    inp_5 = '978-0-13-949582-2-' # False
    inp_6 = None # None
    inp_7 = 9 # None

    obj_0 = __ISBNChecker(inp_0)
    obj_1 = __ISBNChecker(inp_1)
    obj_2 = __ISBNChecker(inp_2)
    obj_3 = __ISBNChecker(inp_3)


# Generated at 2022-06-26 01:52:58.646992
# Unit test for function is_ip_v4
def test_is_ip_v4():
    ip_v4_0 = "255.200.100.75"
    bool_0 = is_ip_v4(ip_v4_0)


# Generated at 2022-06-26 01:53:06.821972
# Unit test for function is_ip
def test_is_ip():
    assert is_ip("192.168.0.1") == True
    assert is_ip("256.168.343.1") == False
    assert is_ip("abcd:ef12:3456:7890:abcd:ef12:3456:7890") == True
    assert is_ip("abcd:ef12:3456:7890:abcd:ef12:3456:789g") == False


# Generated at 2022-06-26 01:53:15.934357
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    str_0 = "0123456789"
    str_1 = "1098765432"
    str_2 = "2731615297"
    str_3 = "3948561273"
    str_4 = "1440215325"
    str_5 = "3423423423"
    obj_0 = __ISBNChecker(__ISBNChecker, str_0)
    obj_0.is_isbn_10()
    bool_0 = obj_0.is_isbn_10()
    obj_0.is_isbn_10()
    obj_0.is_isbn_10()
    obj_1 = __ISBNChecker(__ISBNChecker, str_1)
    obj_1.is_isbn_10()
    bool_1 = obj_1.is_is

# Generated at 2022-06-26 01:53:27.291085
# Unit test for function is_json
def test_is_json():
    if not is_json('{"name": "Peter"}'):
        raise ValueError('ERROR')
    if not is_json('[1, 2, 3]'):
        raise ValueError('ERROR')
    if is_json('{nope}'):
        raise ValueError('ERROR')
    if is_json(None):
        raise ValueError('ERROR')
    if is_json('320'):
        raise ValueError('ERROR')
    if is_json(''):
        raise ValueError('ERROR')
    if is_json('abcd'):
        raise ValueError('ERROR')
    if is_json(23):
        raise ValueError('ERROR')
    if not is_json('{a: "b"}'):
        raise ValueError('ERROR')
    if not is_json('{"a": "b"}'):
        raise

# Generated at 2022-06-26 01:53:34.671722
# Unit test for function is_ip_v4
def test_is_ip_v4():
    str_0 = '<_(lPdk*$}B\'Vv}0+k@:'
    bool_0 = is_ip_v4(str_0)
    assert not bool_0

    str_0 = 'nope'
    bool_0 = is_ip_v4(str_0)
    assert not bool_0

    str_0 = '255.200.100.999'
    bool_0 = is_ip_v4(str_0)
    assert not bool_0



# Generated at 2022-06-26 01:53:37.425197
# Unit test for function is_ip_v4
def test_is_ip_v4():
    str_0 = "3s1%cX9_OiTZ!UE)w$j&"
    bool_0 = is_ip_v4(str_0)



# Generated at 2022-06-26 01:53:50.633056
# Unit test for function is_email
def test_is_email():
    assert is_email('foo@bar.com') == True
    assert is_email('foo.bar@baz.com') == True
    assert is_email('.foo@bar.com') == False
    assert is_email('foo@bar.com.') == False
    assert is_email('foo@bar.c') == False
    assert is_email('foo@bar.commmmmmm') == False
    assert is_email('foo@bar.com.') == False
    assert is_email('foo@bar.bar') == True
    assert is_email('foo@bar.bar.') == False
    assert is_email('foo.@bar.com') == False
    assert is_email('foo@bar.baz.com') == True
    assert is_email('foo@bar..com') == False

# Generated at 2022-06-26 01:54:07.166117
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    str_0 = "0889372699"
    str_1 = "0889372999"
    str_2 = "0889372691"
    str_3 = "0889372698"
    str_4 = "0889372690"
    str_5 = "0889372693"
    str_6 = "0889372692"
    str_7 = "0889372697"
    str_8 = "0889372696"
    str_9 = "0889372695"
    str_10 = "0889372694"

# Generated at 2022-06-26 01:54:15.041092
# Unit test for function is_email
def test_is_email():
    # From Pex
    assert is_email("i.g@mail.com")
    assert is_email("i.g@gmail.com")
    assert not is_email("i.g@gmail.com ")
    assert not is_email("i.g@gmail.com a")
    assert is_email("i.g@gmail.com ")
    assert is_email("i.g@gmail.com \n")
    assert is_email("i.g@gmail.com\n")
    assert is_email("i.g@gmail.com?a=1")
    assert is_email("i.g@gmail.com?a=1&b=2")
    assert is_email("i.g@gmail.com?")
    assert is_email("i.g@gmail.com#")
    assert is_email

# Generated at 2022-06-26 01:54:23.114443
# Unit test for function is_url
def test_is_url():
    # Test 1
    str_1 = "http://www.mysite.com"
    assert is_url(str_1) == True
    # Test 2
    str_2 = "https://mysite.com"
    assert is_url(str_2) == True
    # Test 3
    str_3 = ".mysite.com"
    assert is_url(str_3) == False
    # Test 4
    str_4 = "ftp://mysite.com"
    assert is_url(str_4) == True
    # Test 5
    str_5 = "www.mysite.com"
    assert is_url(str_5) == False
    # Test 6
    str_6 = "http://mysite.com"
    list_0 = ['http', 'https', 'ftp']

# Generated at 2022-06-26 01:54:25.515098
# Unit test for function is_url
def test_is_url():
    str_0 = 'http:www.domain.com'
    bool_0 = is_url(str_0)


# Generated at 2022-06-26 01:54:42.556560
# Unit test for function is_ip_v4
def test_is_ip_v4():

    str_0 = "dI"
    str_1 = "1k[Ni"
    str_2 = "P(_:Z"
    str_3 = "w"
    str_4 = "Y"
    str_5 = "&<b"
    str_6 = "6"
    str_7 = "eS"
    str_8 = "U>%8"
    str_9 = "hV7"
    str_10 = "-"
    str_11 = "("
    bool_0 = is_ip_v4(str_0)
    bool_1 = is_ip_v4(str_1)
    bool_2 = is_ip_v4(str_2)
    bool_3 = is_ip_v4(str_3)
    bool_4 = is_ip_v

# Generated at 2022-06-26 01:54:50.776820
# Unit test for function is_email
def test_is_email():
    str_0 = "kton1331@gmail.com"
    str_1 = "kton1331gmail.com"
    bool_0 = is_email(str_0)
    bool_1 = is_email(str_1)
    print('str_0: ' + str_0)
    print('str_1: ' + str_1)
    print('bool_0: ' + str(bool_0))
    print('bool_1: ' + str(bool_1))


# Generated at 2022-06-26 01:55:01.626895
# Unit test for function is_json
def test_is_json():
    str_0 = "[1, 2, 3]"
    str_1 = "{nope}"
    str_2 = '{  "name": "John",  "age": 30}'
    str_3 = "[1, 2, 3"
    
    # Call is_json with all possible values
    bool_0 = is_json(str_0)
    bool_1 = is_json(str_1)
    bool_2 = is_json(str_2)
    bool_3 = is_json(str_3)
    # We expect bool_0 == bool_1 == bool_3 == False and bool_2 == True
    # Check if all expectations meet
    assert bool_0 == False
    assert bool_1 == False
    assert bool_2 == True
    assert bool_3 == False
    # If all the expectations meet,

# Generated at 2022-06-26 01:55:14.369015
# Unit test for function is_url
def test_is_url():
    assert(True == is_url('HTTP://WWW.REDDIT.COM'))
    assert(False == is_url('.REDDIT.COM'))
    assert(True == is_url('HTTPS://WWW.REDDIT.COM'))
    assert(True == is_url('HTTP://WWW.REDDIT.COM/'))
    assert(True == is_url('HTTP://WWW.REDDIT.COM/R/PYTHON/'))
    assert(True == is_url('HTTP://WWW.REDDIT.COM/R/PYTHON'))
    assert(True == is_url('HTTP://WWW.REDDIT.COM/R/PYTHON/COMMENTS/AY7YGK/NEW_TO_PYTHON/'))

# Generated at 2022-06-26 01:55:21.999126
# Unit test for function is_url
def test_is_url():
    str_0 = "https://www.google.com"
    bool_0 = is_url(str_0)
    str_1 = "www.googlecom"
    bool_1 = is_url(str_1)
    str_2 = "https://google.com"
    bool_2 = is_url(str_2)
    str_3 = "google.com"
    bool_3 = is_url(str_3)
    


# Generated at 2022-06-26 01:55:25.487486
# Unit test for function is_json
def test_is_json():
    str_0 = "y"
    str_1 = "{"
    bool_0 = is_json(str_0)
    assert bool_0 == False
    bool_1 = is_json(str_1)
    assert bool_1 == False



# Generated at 2022-06-26 01:55:33.653585
# Unit test for function is_url
def test_is_url():
    url = "https://mysite.com"
    assert is_url(url) == True
    assert is_url(url, ["https","http"]) == True


# Generated at 2022-06-26 01:55:45.607614
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('1234') == False # Test 1
    assert is_isbn('1234567890123') == False # Test 2
    assert is_isbn('123456789012345') == False # Test 3
    assert is_isbn('123412341234123') == False # Test 4
    assert is_isbn('978-0312498580') == True # Test 5
    assert is_isbn('978-0312498580', normalize=False) == False # Test 6
    assert is_isbn('9780312498580') == True # Test 7
    assert is_isbn('9780312498580', normalize=False) == False # Test 8
    assert is_isbn('12-3456789012') == True # Test 9

# Generated at 2022-06-26 01:55:49.073524
# Unit test for function is_credit_card
def test_is_credit_card():
    card_type = 'AMERICAN_EXPRESS'
    input_string = '3776-8819-368-648'
    output = is_credit_card(input_string, card_type)
    assert output == True


# Generated at 2022-06-26 01:55:57.571045
# Unit test for function is_json
def test_is_json():
    str_0 = '{"my_list": [1, 2, 3], "my_string": "Hello", "my_integer": 123, "my_float": 123.4, "my_bool": True}'
    bool_0 = is_json(str_0)
    str_1 = '{"my_list": [1, 2, 3], "my_string": "Hello", "my_integer": 123, "my_float": 123.4, "my_bool": false}'
    bool_1 = is_json(str_1)
    str_2 = '{"my_list": [1, 2, 3], "my_string": "Hello", "my_integer": 123, "my_float": 123.4, "my_bool": False}'
    bool_2 = is_json(str_2)
    str_3

# Generated at 2022-06-26 01:56:09.405799
# Unit test for function is_email

# Generated at 2022-06-26 01:56:18.378640
# Unit test for function is_url
def test_is_url():
    """Testing the function is_url"""
    str_0 = "http://www.google.com"
    str_1 = "https://www.google.com"
    str_2 = "http:/www.google.com"
    str_3 = "www.google.com"
    str_4 = "http://google.com"
    str_5 = "http://tableau.com/"
    str_6 = "https://tableau.com/support"
    str_7 = "https://tableau.com/support/"
    str_8 = "www.tableau.com"
    str_9 = "www.tableau.com/"
    str_10 = "www.tableau.com/support"
    str_11 = "https://tableau.com/support/main/en-us/get-started"
    str

# Generated at 2022-06-26 01:56:20.626140
# Unit test for function is_isbn
def test_is_isbn():
    str_0 = "978 0 312 4958"
    assert is_isbn(str_0, True) is True


# Generated at 2022-06-26 01:56:27.294874
# Unit test for function is_email
def test_is_email():
    # assertEqual(expected, is_email(input_string))
    assertEqual(True, is_email('my.email@the-provider.com'))
    assertEqual(False, is_email('@gmail.com'))
    assertEqual(True, is_email('my.email@the-provider.com'))
    assertEqual(False, is_email(None))


# Generated at 2022-06-26 01:56:31.249196
# Unit test for function is_email
def test_is_email():
    str_0 = "my.email@the-provider.com"
    bool_0 = is_email(str_0)

    str_1 = "@gmail.com"
    bool_1 = is_email(str_1)



# Generated at 2022-06-26 01:56:39.757143
# Unit test for function is_credit_card
def test_is_credit_card():
    str_0 = "zZ"
    bool_0 = is_credit_card(str_0)
    bool_1 = is_credit_card(str_0, "VISA")
    bool_2 = is_credit_card(str_0, "MASTERCARD")
    bool_3 = is_credit_card(str_0, "AMERICAN_EXPRESS")
    bool_4 = is_credit_card(str_0, "DINERS_CLUB")
    bool_5 = is_credit_card(str_0, "DISCOVER")
    bool_6 = is_credit_card(str_0, "JCB")


# Generated at 2022-06-26 01:56:56.653890
# Unit test for function is_email
def test_is_email():
    str_0 = '#SvG~B7;?3)Mk-X9<x'
    bool_0 = is_email(str_0)
    str_0 = '/1[5B'
    bool_0 = is_email(str_0)
    str_0 = "/1[5B"
    bool_0 = is_email(str_0)
    str_0 = 'Z0.6D_?6;'
    bool_0 = is_email(str_0)
    str_0 = 'Z0.6D_?6;'
    bool_0 = is_email(str_0)
    str_0 = 'Z0.6D_?6;'
    bool_0 = is_email(str_0)

# Generated at 2022-06-26 01:57:06.909926
# Unit test for function is_email
def test_is_email():
    assert(is_email('abc@example.com') == True)
    assert(is_email('.abc@example.com') == False)
    assert(is_email('abc..123@example.com') == False)
    assert(is_email('abc@.example.com') == False)
    assert(is_email('abc@example.com.') == False)
    assert(is_email('abc@examplecom') == False) # do not have '.'
    assert(is_email('abc@-example.com') == False)
    assert(is_email('abc@.example.com.') == False)
    assert(is_email('abc@-example-.com') == False)
    assert(is_email('abc@example.com-') == False)

# Generated at 2022-06-26 01:57:19.155940
# Unit test for function is_credit_card
def test_is_credit_card():
    # Check the actual results
    assert_1 = is_credit_card('371449635398431')
    assert_1_expected = True
    assert_2 = is_credit_card('371449635398431', 'AMERICAN_EXPRESS')
    assert_2_expected = True
    assert_3 = is_credit_card('371449635398431', 'VISA')
    assert_3_expected = False
    assert_4 = is_credit_card('3')
    assert_4_expected = False
    assert_5 = is_credit_card('371449635398431', 'foo')
    assert_5_expected = False
    assert_6 = is_credit_card('371449635398431', 'foo')
    assert_6_expected = False


# Generated at 2022-06-26 01:57:35.194573
# Unit test for function is_email
def test_is_email():
    str_0 = "\"P^;d>W8DA3qy|tE!{X<sF^W8Gv2)!Z."
    bool_0 = is_email(str_0)
    assert_not_equals(bool_0, True)
    str_1 = "\"\C1r'0yQ2msa5*"
    bool_1 = is_email(str_1)
    assert_not_equals(bool_1, True)
    str_2 = "email"
    bool_2 = is_email(str_2)
    assert_not_equals(bool_2, True)
    str_3 = "email@"
    bool_3 = is_email(str_3)
    assert_not_equals(bool_3, True)


# Generated at 2022-06-26 01:57:45.833611
# Unit test for function is_ip_v4
def test_is_ip_v4():
    # Test 1:
    str_1 = "0.0.0.0"
    bool_1 = is_ip_v4(str_1)
    assert bool_1 == True, "Failed!"
    
    # Test 2:
    str_2 = "192.168.0.255"
    bool_2 = is_ip_v4(str_2)
    assert bool_2 == True, "Failed!"

    # Test 3:
    str_3 = "256.1.1.1"
    bool_3 = is_ip_v4(str_3)
    assert bool_3 == False, "Failed!"

    # Test 4:
    str_4 = ""
    bool_4 = is_ip_v4(str_4)
    assert bool_4 == False, "Failed!"

   

# Generated at 2022-06-26 01:57:53.650219
# Unit test for function is_email
def test_is_email():
    str_1 = "My#.Email@The-Provider.com"
    str_2 = "my.email@the-provider.com"
    str_3 = "@gmail.com"
    bool_1 = is_email(str_1)
    bool_2 = is_email(str_2)
    bool_3 = is_email(str_3)
    assert bool_1 == True
    assert bool_2 == True
    assert bool_3 == False


# Generated at 2022-06-26 01:57:58.743372
# Unit test for function is_email
def test_is_email():
    str_0 = 'david@gmail.com' 
    assert is_email(str_0) == True
    str_1 = 'saimondavid@gmail.com'
    assert is_email(str_1) == False


# Generated at 2022-06-26 01:58:04.460524
# Unit test for function is_email
def test_is_email():
    str_0 = 'N6ge5U6I#)@{]B'
    assert is_email(str_0) == False
    str_1 = '|>!!-m2QTf'
    assert is_email(str_1) == False
    str_2 = 'Z^'
    assert is_email(str_2) == False
    str_3 = 'w'
    assert is_email(str_3) == False


# Generated at 2022-06-26 01:58:06.477606
# Unit test for function is_json
def test_is_json():
    str_0 = "pp"
    bool_0 = is_json(str_0)



# Generated at 2022-06-26 01:58:19.647730
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    checker = __ISBNChecker("029785938X")
    assert checker.is_isbn_10() == True
    checker = __ISBNChecker("0765381363")
    assert checker.is_isbn_10() == True
    checker = __ISBNChecker("0439023521")
    assert checker.is_isbn_10() == True
    checker = __ISBNChecker("1611761591")
    assert checker.is_isbn_10() == True
    checker = __ISBNChecker("0765326353")
    assert checker.is_isbn_10() == True
    checker = __ISBNChecker("0802123457")
    assert checker.is_isbn_10() == True

# Generated at 2022-06-26 01:58:29.090604
# Unit test for function is_json
def test_is_json():
    str_0 = "]"
    bool_0 = is_json(str_0)
    print("[*] is_json: " + str(bool_0))


# Generated at 2022-06-26 01:58:31.810682
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    bool_1 = __ISBNChecker("3-598-21508-8").is_isbn_10()
    assert bool_1 == True


# Generated at 2022-06-26 01:58:34.260428
# Unit test for function is_json
def test_is_json():
    result = is_json('{"name": "Peter"}')
    assert result == True

if __name__ == "__main__":
    test_case_0()
    test_is_json()

# Generated at 2022-06-26 01:58:45.061059
# Unit test for function is_email
def test_is_email():
    # test case 0
    str_0 = 'fvH}Gk{DkkU5.I1.%%6@"H@"'
    ret_0 = is_email(str_0)
    assert ret_0 == True

    # test case 1
    str_1 = '"QuGjZa"@n6v(E6kWG6UQj6n'
    ret_1 = is_email(str_1)
    assert ret_1 == True

    # test case 2
    str_2 = 'Ez.q3@j(@z@$f_\\C2}d\\3\\a'
    ret_2 = is_email(str_2)
    assert ret_2 == False

    # test case 3

# Generated at 2022-06-26 01:58:54.730922
# Unit test for function is_email
def test_is_email():
    assert is_email("abc@abc.com") == True
    assert is_email("abc@@abc.com") == False
    assert is_email("abc@abc.") == False
    assert is_email("abc@.abc") == False
    assert is_email("abc@abc.c") == True
    assert is_email("abc@abc.ccc") == True
    assert is_email("abc@abc.cccc") == False
    assert is_email("abc@abc.ccccc") == False
    assert is_email("@abc.com") == False
    assert is_email("abc@@abc.com") == False
    assert is_email("abc@abc") == False
    


# Generated at 2022-06-26 01:58:57.178317
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    # Case 0
    checker_0 = __ISBNChecker("a")
    bool_0 = checker_0.is_isbn_10()


# Generated at 2022-06-26 01:59:04.044279
# Unit test for function is_ip_v4
def test_is_ip_v4():
    str_0 = "192.168.0.1"
    str_1 = "192.168.000.001"
    str_2 = "300.168.0.1"
    str_3 = "192.300.0.1"
    str_4 = "192.168.256.1"
    str_5 = "192.168.0.256"
    str_6 = "192.168.0.0"
    str_7 = "192.168.00.01"
    str_8 = "0.0.0.0"
    str_9 = "255.255.255.255"
    str_10 = "192.168.0.a"
    str_11 = "192.168.0.a"
    str_12 = "000.000.000.000"
    str_13

# Generated at 2022-06-26 01:59:06.900664
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    str_0 = '0306406152'
    bool_0 = __ISBNChecker(str_0).is_isbn_10()
    assert bool_0 == True


# Generated at 2022-06-26 01:59:11.153827
# Unit test for function is_email
def test_is_email():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()

# Unit testfor function get_file_type

# Generated at 2022-06-26 01:59:22.496094
# Unit test for function is_email
def test_is_email():
    assert is_email("dennis@gmail.com") == True
    assert is_email("dennis") == False
    assert is_email("dennis@gmail.com.com") == True
    assert is_email("@gmail.com") == False
    assert is_email("dennis_@gmail.com") == True
    assert is_email("dennis__@gmail.com") == True
    assert is_email("dennis . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .@gmail.com") == True

# Generated at 2022-06-26 01:59:40.640163
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    # Default normalize = True
    assert __ISBNChecker('0306406152').is_isbn_10() == True
    assert __ISBNChecker('0-306-40615-2').is_isbn_10() == True
    assert __ISBNChecker('0-306-40615-0').is_isbn_10() == False
    assert __ISBNChecker('0_306_40615_2').is_isbn_10() == False
    assert __ISBNChecker('030640615').is_isbn_10() == False

    # Set normalize = False
    assert __ISBNChecker('0306406152', normalize = False).is_isbn_10() == True
    assert __ISBNChecker('0-306-40615-2', normalize = False).is_isbn_10

# Generated at 2022-06-26 01:59:43.804322
# Unit test for function is_email
def test_is_email():
    value = "<_(lPdk*$}B'Vv}0+k@:"
    result = False
    if is_email(value):
        result = True
    return result


# Generated at 2022-06-26 01:59:49.685345
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    str_0 = "-XoG.A7iP"
    str_1 = "8.t1:7:4:4"
    str_2 = "9.6.7"
    str_3 = "8;t1:7:4:4"
    str_4 = "978-3-16-148410-0"
    bool_0 = __ISBNChecker(str_0).is_isbn_13()
    bool_1 = __ISBNChecker(str_1).is_isbn_13()
    bool_2 = __ISBNChecker(str_2).is_isbn_13()
    bool_3 = __ISBNChecker(str_3).is_isbn_13()
    bool_4 = __ISBNChecker(str_4).is_isbn_13()


# Generated at 2022-06-26 01:59:51.013543
# Unit test for function is_email
def test_is_email():
    test_case_0()


# Generated at 2022-06-26 01:59:55.061576
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-26 02:00:00.083105
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    isbnchecker = __ISBNChecker('9788366181354')
    assert isbnchecker.is_isbn_13() == True

    isbnchecker = __ISBNChecker('9788366181355')
    assert isbnchecker.is_isbn_13() == False



# Generated at 2022-06-26 02:00:07.677033
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    str_0 = "97-123456789X"
    str_1 = "97-123456789x"

    test_0 = __ISBNChecker(str_0, True)
    test_1 = __ISBNChecker(str_1, True)

    bool_0 = test_0.is_isbn_13()
    bool_1 = test_1.is_isbn_13()


# Generated at 2022-06-26 02:00:10.011942
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    bool_0 = __ISBNChecker("", True).is_isbn_13()
    assert (bool_0 == False)


# Generated at 2022-06-26 02:00:15.275298
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999')



# Generated at 2022-06-26 02:00:23.625462
# Unit test for function is_json
def test_is_json():
    str_0 = "_:LI1sF{4h]0E)W"
    bool_0 = is_json(str_0)
    str_1 = "L"
    bool_1 = is_json(str_1)
    str_2 = "^F5i;N5l5hB"
    bool_2 = is_json(str_2)
    str_3 = "6nBBm;HmFoh90Y"
    bool_3 = is_json(str_3)
    str_4 = ";9^"
    bool_4 = is_json(str_4)
    str_5 = "rU,D6UoX"
    bool_5 = is_json(str_5)


# Generated at 2022-06-26 02:00:38.861718
# Unit test for function is_ip_v4
def test_is_ip_v4():
    str_0 = "0.0.0.0"
    bool_0 = is_ip_v4(str_0)
    bool_1 = True

    assert bool_0 == bool_1


# Generated at 2022-06-26 02:00:50.600481
# Unit test for function is_email
def test_is_email():
    str_0 = "<_(lPdk*$}B'Vv}0+k@:"
    bool_0 = is_email(str_0)
    assert bool_0 == False

    str_0 = "J"
    bool_0 = is_email(str_0)
    assert bool_0 == False

    str_0 = "d"
    bool_0 = is_email(str_0)
    assert bool_0 == False

    str_0 = "|@g]"
    bool_0 = is_email(str_0)
    assert bool_0 == False

    str_0 = "e"
    bool_0 = is_email(str_0)
    assert bool_0 == False

    str_0 = "N"
    bool_0 = is_email(str_0)
    assert bool_

# Generated at 2022-06-26 02:01:01.124686
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4("255.255.255.255") == True
    assert is_ip_v4("10.10.10.10") == True
    assert is_ip_v4("100.100.100.100") == True
    assert is_ip_v4("200.200.200.200") == True
    assert is_ip_v4("150.150.150.150") == True
    assert is_ip_v4("255.0.0.0") == True
    assert is_ip_v4("0.255.0.0") == True
    assert is_ip_v4("0.0.255.0") == True
    assert is_ip_v4("0.0.0.255") == True
    assert is_ip_v4("0.0.0.0") == True

# Generated at 2022-06-26 02:01:12.225086
# Unit test for function is_ip_v4
def test_is_ip_v4():
    ip_v4_1 = "255.1.1.1"
    assert(is_ip_v4(ip_v4_1)) == True

    ip_v4_2 = "256.1.1.1"
    assert(is_ip_v4(ip_v4_2)) == False

    ip_v4_3 = "255.1.1"
    assert(is_ip_v4(ip_v4_3)) == False

    ip_v4_4 = "255.1.1.1.1"
    assert(is_ip_v4(ip_v4_4)) == False

    ip_v4_5 = "256.1.1.1.1"
    assert(is_ip_v4(ip_v4_5)) == False
    return 1

# Generated at 2022-06-26 02:01:20.544499
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    test_case_0()

    str_0 = "9780306406157"
    bool_0 = __ISBNChecker(str_0).is_isbn_13()
    assert bool_0

    str_0 = "978-0-306-40615-7"
    bool_0 = __ISBNChecker(str_0, normalize=False).is_isbn_13()
    assert bool_0

    str_0 = "978 0306 40615 7"
    bool_0 = __ISBNChecker(str_0, normalize=False).is_isbn_13()
    assert bool_0

    str_0 = "978 0306 406157"
    bool_0 = __ISBNChecker(str_0, normalize=False).is_isbn_13()
    assert bool_0

    str

# Generated at 2022-06-26 02:01:31.115171
# Unit test for function is_json
def test_is_json():
    str_0 = "{}"
    bool_0 = is_json(str_0)
    assert (bool_0 == True)

    str_0 = "{"
    bool_0 = is_json(str_0)
    assert (bool_0 == False)

    str_0 = "{\"name\":"
    bool_0 = is_json(str_0)
    # true
    assert (bool_0 == True)

    str_0 = "{\"name\":\"peter\"}"
    bool_0 = is_json(str_0)
    assert (bool_0 == True)

    str_0 = "{\"name\":\"peter\"}}"
    bool_0 = is_json(str_0)
    assert (bool_0 == False)


# Generated at 2022-06-26 02:01:41.120433
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():

    # Test Case 0
    str_0 = "9780596101459"
    bool_0 = __ISBNChecker(str_0).is_isbn_13()

    # Test Case 1
    str_1 = "3-598-21508-8"
    bool_1 = __ISBNChecker(str_1).is_isbn_13()

    # Test Case 2
    str_2 = "978-0-596-10132-5"
    bool_2 = __ISBNChecker(str_2).is_isbn_13()

    # Test Case 3
    str_3 = "0-596-10132-5"
    bool_3 = __ISBNChecker(str_3).is_isbn_13()

    # Test Case 4
    str_4 = "978-0596101325"

# Generated at 2022-06-26 02:01:49.967195
# Unit test for function is_json
def test_is_json():
    str_0 = ""
    bool_0 = is_json(str_0)
    assert not bool_0 and (bool_0 == is_json(str_0))

    str_0 = "abc"
    bool_0 = is_json(str_0)
    assert not bool_0 and (bool_0 == is_json(str_0))



# Generated at 2022-06-26 02:01:53.338105
# Unit test for function is_json
def test_is_json():
    str_1 = "[\"a\",[1,2,3],\"b\"]"
    assert is_json(str_1) == True


# Generated at 2022-06-26 02:01:56.986451
# Unit test for function is_email
def test_is_email():
    try:
        assert is_email('my.email@the-provider.com') is True
        assert is_email('@gmail.com') is False
    except AssertionError:
        print("Test for is_email failed!")
    print("Test for is_email passed!")
