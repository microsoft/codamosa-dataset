

# Generated at 2022-06-26 01:52:26.508030
# Unit test for function is_ip
def test_is_ip():
    arg0 = '255.100.100.100'
    arg1 = '2001:db8:85a3:0000:0000:8a2e:370:7334'
    try:
        ret0 = is_ip(arg0)
        ret1 = is_ip(arg1)
    except Exception:
        print('Exception')


# Generated at 2022-06-26 01:52:37.033117
# Unit test for function is_email
def test_is_email():
    assert is_email("user@gmail.com") == True
    assert is_email("email@.com") == False
    assert is_email("email@.com.") == False
    assert is_email("email@.com..") == False
    assert is_email("email@.com....") == False
    assert is_email("email..@.com.com") == False
    assert is_email("email..@.com") == False
    assert is_email("user@domain") == False
    assert is_email("user@domain.com.a") == False
    assert is_email("") == False
    # Need to finish the rest
    assert is_email(" ") == False
    assert is_email("email@com") == False
    assert is_email("domincom") == False

# Generated at 2022-06-26 01:52:48.336271
# Unit test for function is_email
def test_is_email():
    # Test Case #0
    str_0 = 'Xy\x18\x1b\x17&\\'
    bool_0 = is_email(str_0)
    # Test Case #1
    str_1 = 'b&{w<J'
    bool_1 = is_email(str_1)
    # Test Case #2
    str_2 = 'JnZ?_'
    bool_2 = is_email(str_2)
    # Test Case #3
    str_3 = '$\x8c'
    bool_3 = is_email(str_3)
    # Test Case #4
    str_4 = '<Jl'
    bool_4 = is_email(str_4)
    # Test Case #5
    str_5 = '*'

# Generated at 2022-06-26 01:52:57.808343
# Unit test for function is_email
def test_is_email():
   if __name__ == '__main__':
      input_string = 'abc@abc.com'
      if is_email(input_string): 
         print("Valid Email") 
      else: 
         print("Invalid Email")

      input_string = 'abc.xyz@abc.com'
      if is_email(input_string): 
         print("Valid Email") 
      else: 
         print("Invalid Email")

      input_string = 'ab-xyz@abc.net'
      if is_email(input_string): 
         print("Valid Email") 
      else: 
         print("Invalid Email")


# Generated at 2022-06-26 01:53:04.430080
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert not is_ip_v4('something')
    assert is_ip_v4('255.200.1.1')
    assert not is_ip_v4('256.1.1.1')
    assert not is_ip_v4('1.260.1.1')


# Generated at 2022-06-26 01:53:14.383307
# Unit test for function is_ip_v4
def test_is_ip_v4():
    str_0 = '~hK\x0e'
    str_1 = '\x0f\x1c\\\x1a'
    str_2 = '8\x1c\x1d\x1bW\x1e\x11\x1d\x11\x19X\x1c\x1b\x1e\x1b'
    str_3 = '\x1c\x1a\x1a\x1f\x1a\x1f\x1e\x1d'
    bool_0 = is_ip_v4(str_0)
    bool_1 = is_ip_v4(str_1)
    bool_2 = is_ip_v4(str_2)
    bool_3 = is_ip_v4(str_3)

# Generated at 2022-06-26 01:53:25.089298
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False
    assert is_ip_v4('1.1.1.1') == True
    assert is_ip_v4('255.255.255.255') == True
    assert is_ip_v4('255.255.256.255') == False
    assert is_ip_v4('255.255.255') == False
    assert is_ip_v4('0.0.0.0') == True
    assert is_ip_v4('-1.3.3.3') == False


# Generated at 2022-06-26 01:53:35.805232
# Unit test for function is_ip_v4
def test_is_ip_v4():
    str_0 = '5.5.5.5'
    bool_0 = is_ip_v4(str_0)
    str_1 = '5.5.5.5.5'
    bool_1 = is_ip_v4(str_1)
    str_2 = '5.5.5.5.'
    bool_2 = is_ip_v4(str_2)
    str_3 = '.5.5.5.5'
    bool_3 = is_ip_v4(str_3)
    str_4 = '5.5.5'
    bool_4 = is_ip_v4(str_4)
    str_5 = '5.5.5.'
    bool_5 = is_ip_v4(str_5)

# Generated at 2022-06-26 01:53:39.635660
# Unit test for function is_credit_card
def test_is_credit_card():
    card_type = 'VISA'
    input_string = '4024007138865452'
    expectedOutput = True
    output = is_credit_card(input_string, card_type)
    assert output == expectedOutput


# PUBLIC API


# Generated at 2022-06-26 01:53:43.278572
# Unit test for function is_ip_v4
def test_is_ip_v4():
    str_0 = '192.168.23.15'
    bool_0 = is_ip_v4(str_0)


if __name__ == '__main__':
    test_case_0()
    test_is_ip_v4()

# Generated at 2022-06-26 01:54:14.105436
# Unit test for function is_isbn
def test_is_isbn():
    try:
        print("Testing function is_isbn")
        test_is_isbn_0()
        test_is_isbn_1()
        test_is_isbn_2()
        test_is_isbn_3()
        test_is_isbn_4()
        test_is_isbn_5()
        test_is_isbn_6()
        test_is_isbn_7()
        test_is_isbn_8()
        test_is_isbn_9()
        test_is_isbn_10()
        test_is_isbn_11()
        test_is_isbn_12()
    except Exception as e:
        print("Error: " + str(e))
        assert False

# is_isbn for basic case

# Generated at 2022-06-26 01:54:16.109321
# Unit test for function is_isbn
def test_is_isbn():
    print('Testing `is_isbn`...')
    isbn_0 = '9780312498580'
    x_0 = is_isbn(isbn_0)
    assert(x_0)


# Generated at 2022-06-26 01:54:21.341060
# Unit test for function is_url
def test_is_url():
    # is_url('http://www.mysite.com') # returns true
    assert is_url('http://www.mysite.com') == True
    # is_url('https://mysite.com') # returns true
    assert is_url('https://mysite.com') == True
    # is_url('.mysite.com') # returns false
    assert is_url('.mysite.com') == False



# Generated at 2022-06-26 01:54:31.131970
# Unit test for function is_credit_card
def test_is_credit_card():
    # pass in empty string and should be False
    assert not is_credit_card("")

    # pass in all the letters and should be False
    assert not is_credit_card("aklsdkadfj")

    # pass in 1.23 and should be False
    assert not is_credit_card("1.23")

    # pass in -1.23 and should be False
    assert not is_credit_card("-1.23")

    # pass in nothing and should be False
    assert not is_credit_card()

    # pass in 'None' and should be False
    assert not is_credit_card(None)

    # pass in all the digits and should be True
    assert is_credit_card("1234567891234567")

    # pass in all the digits with spaces and should be False
    assert not is_credit_

# Generated at 2022-06-26 01:54:39.725351
# Unit test for function is_isbn
def test_is_isbn():
    assert (is_isbn('1506715214') == True)
    assert (is_isbn('150-6715214') == True)
    assert (is_isbn('978-0312498580') == True)
    assert (is_isbn('9780312498580') == True)
    assert (is_isbn('978-0312498580', normalize=False) == False)
    assert (is_isbn('150-6715214', normalize=False) == False)


# Generated at 2022-06-26 01:54:45.269185
# Unit test for function is_url
def test_is_url():
    str_0 = 'foo://username:password@example.com:8042/over/there?name=ferret#nose'
    bool_0 = is_url(str_0)
    print(bool_0)
    print(is_url('foo://")@example.com:8042/over/there?name=ferret#nose'))



# Generated at 2022-06-26 01:54:54.571200
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-0134743356').is_isbn_13()
    assert not __ISBNChecker('9780134743356').is_isbn_13()
    assert not __ISBNChecker('9780134743357').is_isbn_13()
    assert not __ISBNChecker('97801347433551').is_isbn_13()
    assert not __ISBNChecker('9780134743').is_isbn_13()
    assert not __ISBNChecker('9780134A43357').is_isbn_13()


# Generated at 2022-06-26 01:54:55.448690
# Unit test for function is_email
def test_is_email():
    pass


# Generated at 2022-06-26 01:54:58.051448
# Unit test for function is_email
def test_is_email():
    str_0 = '"a"@example.'
    bool_0 = is_email(str_0)
    assert bool_0 == False


# Generated at 2022-06-26 01:55:00.636901
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') == True
    assert is_isbn('1506715214') == True


# Generated at 2022-06-26 01:55:13.375039
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    str_0 = '[*9ES5J'
    bool_0 = __ISBNChecker(str_0).is_isbn_13()


# Generated at 2022-06-26 01:55:25.005665
# Unit test for function is_credit_card
def test_is_credit_card():
    card_type = 'VISA'
    input_string = '4263982640269299' 
    bool_0 = is_credit_card(input_string, card_type)
    #assert(bool_0) is True
    card_type = 'MASTERCARD'
    input_string = '5411231600000003'
    bool_1 = is_credit_card(input_string, card_type)
    #assert(bool_1) is True
    card_type = 'AMERICAN_EXPRESS'
    input_string = '34239627738063'
    bool_2 = is_credit_card(input_string, card_type)
    #assert(bool_2) is True
    card_type = 'DINERS_CLUB'

# Generated at 2022-06-26 01:55:32.803386
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0-306-40615-2').is_isbn_10() is True
    assert __ISBNChecker('0-30640615-2').is_isbn_10() is True
    assert __ISBNChecker('9780306406157').is_isbn_10() is False
    assert __ISBNChecker('978030640615-2').is_isbn_10() is False
    assert __ISBNChecker('0-30640615-2', normalize=False).is_isbn_10() is False



# Generated at 2022-06-26 01:55:38.492519
# Unit test for function is_url
def test_is_url():
    str_0 = 'S^]hn8'
    allowed_schemes_0 = ['http']
    bool_0 = is_url(str_0, allowed_schemes_0)

    str_1 = 'Z|W8fl9X'
    bool_1 = is_url(str_1)


# Generated at 2022-06-26 01:55:49.363271
# Unit test for function is_email
def test_is_email():
    assert is_email('') == False
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True

# Generated at 2022-06-26 01:55:52.981465
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.example.com') == True
    assert is_url('https://example.com') == True
    assert is_url('ftp://my_ftp_site.com') == True
    assert is_url('www.fake-example.com') == False


# Generated at 2022-06-26 01:56:02.505712
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    result = __ISBNChecker('F}Oltiyg(').is_isbn_10()
    assert result == False


# def test_case_1():
#     str_0 = '0'
#     bool_0 = is_isbn_10(str_0)
#
# # Unit test for method is_isbn_10 of class __ISBNChecker
# def test___ISBNChecker_is_isbn_10():
#     result = __ISBNChecker('0').is_isbn_10()
#     assert result == False



# Generated at 2022-06-26 01:56:05.299223
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    str_0 = 'F}Oltiyg('
    bool_0 = __ISBNChecker(str_0).is_isbn_10()


# Generated at 2022-06-26 01:56:08.079845
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    str_0 = 'F}Oltiyg('
    bool_0 = __ISBNChecker(str_0).is_isbn_10()


# Generated at 2022-06-26 01:56:17.516707
# Unit test for function is_credit_card
def test_is_credit_card():
    str_0 = '(36.45E-3)'
    card_type_0 = 'AMEX'
    # The correct output is 'False'
    bool_0 = is_credit_card(str_0, card_type_0)
    str_1 = '{=S\x7fv%j}[@'
    # The correct output is 'False'
    bool_1 = is_credit_card(str_1)
    str_2 = 'C#\x0eV<\x14\x7f("`'
    # The correct output is 'True'

    bool_2 = is_credit_card(str_2)
    str_3 = 'pS\x1c\x0c{;+:)jhE'
    # The correct output is 'True'
    bool_3 = is_

# Generated at 2022-06-26 01:56:27.183961
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    # Instantiation
    str_0 = 'Attrdkr1i4'
    obj = __ISBNChecker(str_0)
    # Method call
    bool_0 = obj.is_isbn_13()
    return bool_0


# Generated at 2022-06-26 01:56:30.725178
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') == True
    assert is_url('.mysite.com') == False
    assert is_url('http://mysite.com/') == True


# Generated at 2022-06-26 01:56:33.506441
# Unit test for function is_email
def test_is_email():
    str_0 = 'my.email@the-provider.com'
    bool_0 = is_email(str_0)

    assert bool_0 == True


# Generated at 2022-06-26 01:56:42.114341
# Unit test for function is_ip_v4
def test_is_ip_v4():
    # Normal case - '255.200.100.75'
    str_1 = '255.200.100.75'
    bool_0 = is_ip_v4(str_1)

    # Normal case - '127.0.0.1'
    str_2 = '127.0.0.1'
    bool_1 = is_ip_v4(str_2)

    # Normal case - '0.0.0.0'
    str_3 = '0.0.0.0'
    bool_2 = is_ip_v4(str_3)

    # Normal case - '192.168.0.1'
    str_4 = '192.168.0.1'
    bool_3 = is_ip_v4(str_4)

    # Normal case - '10.0.0

# Generated at 2022-06-26 01:56:54.278578
# Unit test for function is_url
def test_is_url():
    assert is_url('https://www.google.com') == True
    assert is_url('https://www.google.com.') == False
    assert is_url('http://www.google.com') == True
    assert is_url('http://google.com.') == False
    assert is_url('google.com') == False
    assert is_url('www.google.com') == False
    assert is_url('www.google.com/test/') == False
    assert is_url('/test/') == False
    assert is_url(' 2') == False
    assert is_url('2') == False
    assert is_url('') == False
    assert is_url('http://www.google.com/test/abcd') == True

# Generated at 2022-06-26 01:57:05.181244
# Unit test for function is_email
def test_is_email():
    # Test input: str_0 = '@gmail.com'
    str_0 = '@gmail.com'
    # Returned expected result: bool_0 = False
    bool_0 = False
    # Result function call: bool_1 = is_email(str_0)
    bool_1 = is_email(str_0)
    # Test comparison: assert to check if bool_0 equals to bool_1
    assert bool_0 == bool_1

    # Test input: str_1 = 'my.email@the-provider.com'
    str_1 = 'my.email@the-provider.com'
    # Returned expected result: bool_2 = True
    bool_2 = True
    # Result function call: bool_3 = is_email(str_1)

# Generated at 2022-06-26 01:57:11.545753
# Unit test for function is_email
def test_is_email():
    assert(is_email('firstname.lastname@example.com') == True)
    assert(is_email('firstname.lastname@subdomain.example.com') == True)
    assert(is_email('firstname+lastname@example.com') == True)
    assert(is_email('firstname-lastname@example.com') == True)
    assert(is_email('firstname_lastname@example.com') == True)
    assert(is_email('firstname@subdomain.subsubdomain.subsubsubdomain.example.com') == True)
    assert(is_email('firstname-lastname@subdomain.subsubdomain.subsubsubdomain.example.com') == True)

# Generated at 2022-06-26 01:57:24.661418
# Unit test for function is_credit_card
def test_is_credit_card():
    str_0 = '~i#x1d-T1)'
    val_0 = is_credit_card(str_0)
   # Result:
    assert(val_0 == False)
    str_1 = '7)Rnj(0N^'
    card_type_1 = 'AMERICAN_EXPRESS'
    val_1 = is_credit_card(str_1, card_type_1)
   # Result:
    assert(val_1 == False)
    str_2 = 'U6!1rIp5%'
    val_2 = is_credit_card(str_2)
   # Result:
    assert(val_2 == False)
    str_3 = '_dIbutNY'
    val_3 = is_credit_card(str_3)
   # Result:

# Generated at 2022-06-26 01:57:32.206893
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    # Setup
    str_0 = 'E4}D;3q4A3d'
    normalize_0 = True

    # Invoke method
    _ISBNChecker_0 = __ISBNChecker(str_0, normalize_0)
    bool_0 = _ISBNChecker_0.is_isbn_13()

    # Check
    assert(bool_0)


# Generated at 2022-06-26 01:57:44.989974
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card( "5212528112170133") == True
    assert is_credit_card( "2720992227752539") == False
    assert is_credit_card( "4539613251139196") == False
    assert is_credit_card( "6011818604036475") == True
    assert is_credit_card( "3484107111308555") == False
    assert is_credit_card( "377729375356099") == True
    assert is_credit_card( "5444574591721141") == False
    assert is_credit_card( "3529886390411686") == False
    assert is_credit_card( "4092164070128762") == True
    assert is_credit_card( "6011923450684214") == False

# Generated at 2022-06-26 01:57:55.288934
# Unit test for function is_ip_v4
def test_is_ip_v4():
    # assert_equals(actual_function, expected_function)
    assert_equals(is_ip_v4('255.200.100.75'), True)
    assert_equals(is_ip_v4('nope'), False)
    assert_equals(is_ip_v4('255.200.100.999'), False)


# Generated at 2022-06-26 01:57:58.439012
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    str_0 = 'F}Oltiyg('
    bool_0 = __ISBNChecker(str_0).is_isbn_10()


# Generated at 2022-06-26 01:58:06.796490
# Unit test for function is_email
def test_is_email():
    if not is_email('my.email@the-provider.com'):
        raise ValueError('expected True, got False')
    elif is_email('@gmail.com'):
        raise ValueError('expected False, got True')
    elif not is_email('my.email@the-provider.com.'):
        raise ValueError('expected True, got False')
    elif not is_email('a\\ b@gmail.org'):
        raise ValueError('expected True, got False')
    elif not is_email('"\\abcd@gmail.org"'):
        raise ValueError('expected True, got False')
    elif not is_email('" a@b.org"'):
        raise ValueError('expected True, got False')

# Generated at 2022-06-26 01:58:19.949617
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my-email@gmail.com') == True
    assert is_email('my.email@gmail.com') == True
    assert is_email('my.email@gmail.com') == True
    assert is_email('my..email@gmail.com') == False
    assert is_email('my.email@gmail.com') == True
    assert is_email('my@email.@gmail.com') == False
    assert is_email('123@gmail.com') == True
    assert is_email('A_ORG@gmail.com') == True
    assert is_email('A@gmail.com') == True

# Generated at 2022-06-26 01:58:30.305159
# Unit test for function is_email
def test_is_email():
    str_0 = 'nnl@'
    bool_0 = is_email(str_0)
    if (bool_0):
        assert(False)
    str_0 = 'F}Oltiyg('
    bool_0 = is_email(str_0)
    if (bool_0):
        assert(False)
    str_0 = '_-'
    bool_0 = is_email(str_0)
    if (not bool_0):
        assert(False)
    str_0 = '.y}@'
    bool_0 = is_email(str_0)
    if (bool_0):
        assert(False)
    str_0 = 'iiennn@'
    bool_0 = is_email(str_0)
    if (bool_0):
        assert(False)
   

# Generated at 2022-06-26 01:58:37.656359
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    # Test 1
    str_0 = 'F}Oltiyg('
    bool_0 = __ISBNChecker(str_0).is_isbn_10()
    assert isinstance(bool_0, bool)
    assert not bool_0

    # Test 2
    str_0 = '7}A@9Z^V8'
    bool_0 = __ISBNChecker(str_0).is_isbn_10()
    assert isinstance(bool_0, bool)
    assert not bool_0

    # Test 3
    str_0 = '<r`>ZHbJ0'
    bool_0 = __ISBNChecker(str_0).is_isbn_10()
    assert isinstance(bool_0, bool)
    assert not bool_0

    # Test 4

# Generated at 2022-06-26 01:58:48.831426
# Unit test for function is_email
def test_is_email():
    string_0 = '}}}}'
    string_1 = '1'
    string_2 = 'rJ{k'
    string_3 = '))O&'
    string_4 = '+'
    string_5 = '?g'
    string_6 = 'uV7'
    string_7 = 'T'
    string_8 = 'w'
    string_9 = '9h*'
    string_10 = '4'
    string_11 = '"sdkdfkdfkd`~}'
    string_12 = '"f4'
    string_13 = '"sbfd'
    string_14 = '1'
    string_15 = '`]]]'
    string_16 = '"f4'
    string_17 = '"sdfs'

# Generated at 2022-06-26 01:58:59.181396
# Unit test for function is_email
def test_is_email():

    # test case 0
    str_0 = 'pqd@Hl&z:V7d'
    bool_0 = is_email(str_0)

    assert bool_0 == False

    # test case 1
    str_1 = '@W0~5'
    bool_1 = is_email(str_1)

    assert bool_1 == False

    # test case 2
    str_2 = 'i0j0QZ #8R'
    bool_2 = is_email(str_2)

    assert bool_2 == False

    # test case 3
    str_3 = '@t$@,`Yv-8'
    bool_3 = is_email(str_3)

    assert bool_3 == False

    # test case 4
    str_4 = 'x|<K>'


# Generated at 2022-06-26 01:59:03.444028
# Unit test for function is_json
def test_is_json():
    str_0 = '{"name": "Peter"}'
    bool_0 = is_json(str_0)

    str_1 = '{nope}'
    bool_1 = is_json(str_1)

    str_2 = '[1, 2, 3]'
    bool_2 = is_json(str_2)
    
    return bool_2


# Generated at 2022-06-26 01:59:15.609211
# Unit test for function is_ip_v4
def test_is_ip_v4():
    str_0 = 'w8yvai/H"R'
    str_1 = 'N^lk9XO,*'
    str_2 = 'f^1x<;6a}'
    str_3 = 'dH.X]P<J}'
    str_4 = '7S+Jpf0,e'
    str_5 = 'K|T&@h)'
    str_6 = '7%x'
    str_7 = 'f4GZ>|s=9'
    str_8 = '~`Dj`$]x'
    str_9 = ':H?Z6\XQ'
    str_10 = 'B"oH*'
    str_11 = 'Y&c'
    str_12 = 'p'

# Generated at 2022-06-26 01:59:22.090636
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    str_0 = 'F}Oltiyg('


# Generated at 2022-06-26 01:59:27.301435
# Unit test for function is_ip_v4
def test_is_ip_v4():
    str_0 = '255.200.100.75'
    bool_0 = is_ip_v4(str_0)
    assert bool_0 == True
    str_1 = 'nope'
    bool_1 = is_ip_v4(str_1)
    assert bool_1 == False
    str_2 = '255.200.100.999'
    bool_2 = is_ip_v4(str_2)
    assert bool_2 == False



# Generated at 2022-06-26 01:59:37.688742
# Unit test for function is_email
def test_is_email():
    if is_email('my.email@the-provider.com'):
        print("Test 1 passed")
    else:
        print("Test 1 not passed")
    if is_email('@gmail.com') is False:
        print("Test 2 passed")
    else:
        print("Test 2 not passed")
    if is_email('my..email@the-provider.com') is False:
        print("Test 3 passed")
    else:
        print("Test 3 not passed")
    if is_email('my.email@the-provider.com.') is False:
        print("Test 4 passed")
    else:
        print("Test 4 not passed")



# Generated at 2022-06-26 01:59:46.794561
# Unit test for function is_json
def test_is_json():
    # Test 0
    try:
        assert callable(is_json)
    except AssertionError as e:
        print('Failed is_json test 0')

    # Test 1
    str_1 = '{}'
    try:
        assert is_json(str_1) == True
    except AssertionError as e:
        print('Failed is_json test 1')

    # Test 2
    str_2 = '{}0'
    try:
        assert is_json(str_2) == False
    except AssertionError as e:
        print('Failed is_json test 2')

    # Test 3
    str_3 = ''

# Generated at 2022-06-26 01:59:52.135162
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert(is_ip_v4('255.200.100.75')) == True
    assert(is_ip_v4('nope')) == False
    assert(is_ip_v4('255.200.100.999')) == False


# Generated at 2022-06-26 02:00:04.227216
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    # Test case 0
    str_0 = '3-598-21508-8'
    bool_0 = __ISBNChecker(str_0, True).is_isbn_13()
    assert bool_0 == True

    # Test case 1
    str_0 = '3-598-21508-9'
    bool_0 = __ISBNChecker(str_0, True).is_isbn_13()
    assert bool_0 == False

    # Test case 2
    str_0 = '3-598-P1581-X'
    bool_0 = __ISBNChecker(str_0, True).is_isbn_13()
    assert bool_0 == False

    # Test case 3
    str_0 = '3-598-2X507-9'
    bool_0 = __ISBNChecker

# Generated at 2022-06-26 02:00:07.474929
# Unit test for function is_email
def test_is_email():
    print("Testing function is_email")
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-26 02:00:08.899559
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    test_case_0()


# Generated at 2022-06-26 02:00:15.322622
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') is True
    assert is_ip_v4('127.0.0.1') is True
    assert is_ip_v4('192.168.0.0') is True
    assert is_ip_v4('0.0.0.0') is True


# Generated at 2022-06-26 02:00:24.125091
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    test_cases = [
        {
            'input': '9788853004335',
            'expected': True
        },
        {
            'input': '978-88-530-0433-5',
            'expected': True
        },
        {
            'input': '97888530 04335',
            'expected': True
        },
        {
            'input': '97888330 04335',
            'expected': False
        },
        {
            'input': '978-88-530-0433-6',
            'expected': False
        },
        {
            'input': '978-88-530-0433-9',
            'expected': False
        }
    ]


# Generated at 2022-06-26 02:00:35.522310
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()


# Generated at 2022-06-26 02:00:40.235497
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    str_0 = '978-0545139700'
    isbn_c_0 = __ISBNChecker(str_0, False)
    bool_0 = isbn_c_0.is_isbn_13()


# PUBLIC API



# Generated at 2022-06-26 02:00:43.196707
# Unit test for function is_ip_v4
def test_is_ip_v4():
    str_0 = 'Zkz}ZVH'
    bool_0 = is_ip_v4(str_0)


# Generated at 2022-06-26 02:00:45.497951
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    str_0 = 'F}Oltiyg('
    test_case_0()



# PUBLIC API



# Generated at 2022-06-26 02:00:53.753264
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    str_1 = '5'
    __ISBNChecker_0 = __ISBNChecker(str_1)
    bool_1 = __ISBNChecker_0.is_isbn_13()
    if bool_1:
        print('Test __ISBNChecker.is_isbn_13 case 1 passed')
    else:
        print('Test __ISBNChecker.is_isbn_13 case 1 failed')
    str_2 = '12345'
    __ISBNChecker_1 = __ISBNChecker(str_2)
    bool_2 = __ISBNChecker_1.is_isbn_13()
    if bool_2:
        print('Test __ISBNChecker.is_isbn_13 case 2 passed')

# Generated at 2022-06-26 02:01:04.212893
# Unit test for function is_json
def test_is_json():
    # json_0 = '{"name": "Peter"}'
    # json_1 = '{"name": "Peter"}'
    json_0 = '{"name": "Peter"}'
    json_1 = '{"name": "Peter"}'
    json_2 = '{<script>alert(1)</script>}'  # XSS1
    json_3 = '{<SCRIPT>alert(1)</SCRIPT>}'  # XSS2
    result_0 = is_json(json_0)
    result_1 = is_json(json_1)
    result_2 = is_json(json_2)
    result_3 = is_json(json_3)
    # print('result_0 = is_json(json_0)')
    # print('result_0: %s', result_0)
   

# Generated at 2022-06-26 02:01:14.885663
# Unit test for function is_json
def test_is_json():
    # Test with valid json
    assert is_json("{\"name\": \"Peter\"}") is True
    assert is_json("[1, 2, 3]") is True
    # Test with invalid json
    assert is_json("{nope}") is False
    assert is_json("[1, nope, 3]") is False
    # Test with invalid input type
    try:
        is_json(1)
        assert False
    except InvalidInputError:
        assert True
    try:
        is_json({'name': 'peter'})
        assert False
    except InvalidInputError:
        assert True
    try:
        is_json(None)
        assert False
    except InvalidInputError:
        assert True
    # Test with empty string
    assert is_json("") is False


# Generated at 2022-06-26 02:01:23.751850
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    # Test unit for method is_isbn_13 of class __ISBNChecker
    __ISBNChecker_0 = __ISBNChecker('4567890123456', True)
    assert __ISBNChecker_0.is_isbn_13() == True

    __ISBNChecker_0 = __ISBNChecker('8881837188', False)
    assert __ISBNChecker_0.is_isbn_13() == False

    # Test unit for method is_isbn_13 of class __ISBNChecker
    __ISBNChecker_12 = __ISBNChecker('999101010', True)
    assert __ISBNChecker_12.is_isbn_13() == False

    # Test unit for method is_isbn_13 of class __ISBNChecker
    __ISBNChecker_1

# Generated at 2022-06-26 02:01:27.506007
# Unit test for function is_email
def test_is_email():
    email_0 = '@gmail.com'
    bool_0 = is_email(email_0)
    str_0 = 'F}Oltiyg('
    bool_0 = is_isbn_10(str_0)
    print(bool_0)


# Generated at 2022-06-26 02:01:38.750529
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    str_0 = 'F}Oltiyg('
    str_1 = '1234567890123'
    str_2 = '12345678901234'
    str_3 = '0000000000000'
    str_4 = '1234567890123'
    str_5 = '1234567890123'
    str_6 = '1234567890123'
    str_7 = '0000000000000'
    str_8 = '1234567890123'
    str_9 = '1234567890123'
    str_10 = '1234567890123'
    str_11 = '1234567890123'
    isbn_0 = __ISBNChecker(str_0)
    isbn_1 = __ISBNChecker(str_1)
    isbn_2

# Generated at 2022-06-26 02:01:54.258089
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    str_0 = '4D-4=4C=4'
    obj_0 = __ISBNChecker(str_0)
    assert obj_0.is_isbn_10() == False, "Expected false but got %s" % obj_0.is_isbn_10()


# Generated at 2022-06-26 02:01:56.598885
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    obj = __ISBNChecker('3736000537')
    assert obj.is_isbn_13() == True


# Generated at 2022-06-26 02:02:02.782549
# Unit test for function is_json
def test_is_json():
    assert (is_json(
        '{"name": "Peter"}') == True)
    assert (is_json('[1, 2, 3]') == True)
    assert (is_json('{nope}') == False)
