

# Generated at 2022-06-26 01:52:20.304101
# Unit test for function is_email
def test_is_email():
    # Test case 0
    str_0 = '`m<:I)pdy%c4F]l4m'
    bool_0 = is_email(str_0)
    # Test case 1
    str_1 = 'irnY\|'
    bool_1 = is_email(str_1)
    # Test case 2
    str_2 = '0DYQ(F&amx?>9,BD'
    bool_2 = is_email(str_2)
    # Test case 3
    str_3 = 'p9K_"F"r!2v%(W1'
    bool_3 = is_email(str_3)
    # Test case 4
    str_4 = ':<W/~wmA(.'
    bool_4 = is_email(str_4)
   

# Generated at 2022-06-26 01:52:29.804686
# Unit test for function is_url
def test_is_url():
    assert not is_url(45432)
    assert is_url('http://www.w3schools.com/')
    assert is_url('https://www.nasa.gov/')
    assert is_url('mailto:abc@abc.com')
    assert is_url('file:///usr/local')
    assert is_url('http://www.w3schools.com/my%20test.asp?name=ståle&car=saab')
    assert is_url('.mysite.com')
    assert is_url('http://10.0.0.1')
    assert is_url('10.0.0.1')


# Generated at 2022-06-26 01:52:34.334898
# Unit test for function is_ip_v4
def test_is_ip_v4():
    str_0 = 'k9jK4&zQg`uv'
    bool_0 = is_ip_v4(str_0)


if __name__ == '__main__':
    test_case_0()
    test_is_ip_v4()

# Generated at 2022-06-26 01:52:42.139707
# Unit test for function is_ip
def test_is_ip():
    # Check if valid ip v4
    assert is_ip('255.200.100.75')

    # Check if valid ip v6
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334')

    # Check if not ip
    assert not is_ip('1.2.3')


# Generated at 2022-06-26 01:52:44.516449
# Unit test for function is_email
def test_is_email():
    str_0 = ' fc?r2bz8/xVG2s(}'
    bool_0 = is_email(str_0)


# Generated at 2022-06-26 01:52:47.285591
# Unit test for function is_json
def test_is_json():
    assert(is_json('{"name": "Peter"}') == True)
    assert(is_json('[1, 2, 3]') == True)
    assert(is_json('{nope}') == False)


# Generated at 2022-06-26 01:52:54.404931
# Unit test for function is_ip_v4
def test_is_ip_v4():
    str_0 = 'UQG6N9jK1`y'
    str_1 = 'Y\j'
    str_2 = '6'
    bool_0 = is_ip_v4(str_0)
    bool_1 = is_ip_v4(str_1)
    bool_2 = is_ip_v4(str_2)
    pass

# Generated at 2022-06-26 01:53:05.081510
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    str_0 = '9780658009451'
    str_1 = '9780658009452'
    isbn_checker_0 = __ISBNChecker(str_0)
    isbn_checker_1 = __ISBNChecker(str_1)

    bool_0 = isbn_checker_0.is_isbn_13()
    # assert bool_0 == True
    # assert bool_0 == False

    bool_1 = isbn_checker_1.is_isbn_13()
    # assert bool_1 == True
    # assert bool_1 == False

    str_2 = '9780658009453'
    isbn_checker_2 = __ISBNChecker(str_2)
    bool_2 = isbn_checker_2.is_isbn_13

# Generated at 2022-06-26 01:53:14.841248
# Unit test for function is_json
def test_is_json():
    print("Test is_json")
    # AssertionError: AssertionError('{"name": "Peter"}' is not JSON)
    # assert (is_json('{"name": "Peter"}') == True)

    # AssertionError: AssertionError('[1, 2, 3]' is not JSON)
    # assert (is_json('[1, 2, 3]') == True)

    # AssertionError: AssertionError('{nope}' is not JSON)
    # assert (is_json('{nope}') == False)

    # AssertionError: AssertionError('{"period":{"max":"3"}}' is not JSON)
    # assert (is_json('{"period":{"max":"3"}}') == True)

    # AssertionError: AssertionError('12' is not JSON

# Generated at 2022-06-26 01:53:16.181079
# Unit test for function is_json
def test_is_json():
    test_case_0()

# Main function

# Generated at 2022-06-26 01:53:27.335308
# Unit test for function is_json
def test_is_json():
    assert is_json('{name: "Peter"}'), 'Failed when testing positive case'
    assert is_json('{}'), 'Failed when testing positive case'
    assert not is_json('{nope}'), 'Failed when testing negative case'


# Generated at 2022-06-26 01:53:32.584402
# Unit test for function is_json
def test_is_json():
    input_string = '{"name": "Peter"}'
    assert is_json(input_string) == True
    input_string = '[1, 2, 3]'
    assert is_json(input_string) == True
    input_string = '{nope}'
    assert is_json(input_string) == False


# Generated at 2022-06-26 01:53:34.157498
# Unit test for function is_email
def test_is_email():
    test_case_0()
    test_case_1()


# Generated at 2022-06-26 01:53:38.787081
# Unit test for function is_url
def test_is_url():
    input_string = 'http://www.google.com'
    str_0 = 'http://www.google.com'
    allowed_schemes = ['http']
    test_val = is_url(input_string, allowed_schemes)

    # print('Result: ' + str_0)
    # print('Valid: ' + str(test_val))
    if not test_val:
        raise Exception('Unit test failed')



# Generated at 2022-06-26 01:53:52.450378
# Unit test for function is_email
def test_is_email():
    assert is_email('john@example.com') == True
    assert is_email('joe.bloggs@co.uk') == True
    assert is_email('8d2db9e9-65b4-4c32-a0a8-7c1fd57fd4a4@customer.example.com') == True
    assert is_email('John.Bloggs@example.com') == True
    assert is_email('joe+bloggs@gmail.com') == True
    assert is_email('joe.bloggs+ext@gmail.com') == True
    assert is_email('"joe.bloggs"@gmail.com') == True
    assert is_email('"joe\\"bloggs"@gmail.com') == True

# Generated at 2022-06-26 01:53:58.764523
# Unit test for function is_email
def test_is_email():
    assert is_email("") == False
    assert is_email("a@a.a") == True
    assert is_email("a@a.a.a.a") == True
    assert is_email("a@@a.a") == False
    assert is_email("a@a") == False
    assert is_email("a.a") == False
    assert is_email("aaa") == False
    assert is_email("@a.a") == False
    assert is_email("a..a@a.a") == False
    assert is_email("a.a@a..a") == False
    assert is_email("a@aa.aa.aa") == True
    assert is_email("a@aa.aa.aa.aa") == False
    assert is_email("a@a.aa.aa.aa") == False


# Generated at 2022-06-26 01:54:07.465898
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') == True
    assert is_url('http://') == False
    assert is_url('http://mysite.com') == True
    assert is_url('http://mysite.com/') == True
    assert is_url('http://mysite.com/test.html') == True
    assert is_url('http://mysite.com:80') == True
    assert is_url('http://mysite.com:80/') == True
    assert is_url('http://mysite.com:80/test.html') == True
    assert is_url('http://www.mysite.com') == True
    assert is_url('https://mysite.com') == True
    assert is_url('https://mysite.com/test.html') == True

# Generated at 2022-06-26 01:54:10.431572
# Unit test for function is_isbn
def test_is_isbn():
    str_0 = 's=}0K0USry1ZM'
    bool_1 = is_isbn(str_0)
    print('test_is_isbn():', bool_1)


# Generated at 2022-06-26 01:54:21.131353
# Unit test for function is_credit_card
def test_is_credit_card():
    str_0 = 'B0B0B0B0B0B0B0B0'
    str_1 = 'B0B0B0B0B0B0B0B0'
    str_2 = 'B0B0B0B0B0B0B0B0'
    str_3 = 'B0B0B0B0B0B0B0B0'
    str_4 = 'B0B0B0B0B0B0B0B0'
    str_5 = 'B0B0B0B0B0B0B0B0'
    str_6 = 'B0B0B0B0B0B0B0B0'
    str_7 = 'B0B0B0B0B0B0B0B0'

# Generated at 2022-06-26 01:54:30.944198
# Unit test for function is_url
def test_is_url():
    with PrintTimer('is_url', 'str_0'):
        str_0 = 'https://www.facebook.com/'
        bool_0 = is_url(str_0)
    # Unit test 2
    with PrintTimer('is_url', 'str_0'):
        str_0 = 'https://www.facebook.com/'
        bool_0 = is_url(str_0)
    # Unit test 3
    with PrintTimer('is_url', 'str_0'):
        str_0 = 'https://www.facebook.com/'
        bool_0 = is_url(str_0)
    # Unit test 4
    with PrintTimer('is_url', 'str_0'):
        str_0 = 'https://www.facebook.com/'

# Generated at 2022-06-26 01:54:42.983365
# Unit test for function is_json
def test_is_json():
    json_0 = '{"name": "Peter"}'
    json_1 = '[1, 2, 3]'
    json_2 = '{nope}'
    bool_0 = is_json(json_0)
    bool_1 = is_json(json_1)
    bool_2 = is_json(json_2)


# Generated at 2022-06-26 01:54:47.482496
# Unit test for function is_isbn
def test_is_isbn():
    # Non string input
    try:
        is_isbn(0)
        assert False
    except InvalidInputError:
        assert True

    # String length not equal to 10 or 13 digits
    assert not is_isbn('1234567891011')

    # Invalid isbn length
    assert not is_isbn('123456789')

    # Empty string
    assert not is_isbn('')

    # None
    assert not is_isbn(None)

    # Non digit character
    assert not is_isbn('123456789a')

    # Valid isbn 10
    assert is_isbn('039304841X')

    # Valid isbn 13
    assert is_isbn('978-0393048414')

    # Valid isbn 10 with hyphens

# Generated at 2022-06-26 01:54:51.812322
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    str_0 = '3-598-21500-2'
    obj_0 = __ISBNChecker(str_0)
    bool_0 = obj_0.is_isbn_10()
    assert bool_0


# Generated at 2022-06-26 01:54:53.232440
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    input_str_0 = '0307265761'
    checker_0 = __ISBNChecker(input_str_0)
    bool_0 = checker_0.is_isbn_10()
    # assert



# Generated at 2022-06-26 01:54:55.815287
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    str_0 = '9'
    bool_0 = __ISBNChecker(str_0).is_isbn_13()


# Generated at 2022-06-26 01:55:00.050941
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    input_string = '1249530036'
    checker = __ISBNChecker(input_string)
    ret = checker.is_isbn_10()
    assert ret == True



# PUBLIC API


# Check if string is a letter

# Generated at 2022-06-26 01:55:01.526108
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False


# Generated at 2022-06-26 01:55:06.173351
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-26 01:55:09.456749
# Unit test for function is_ip_v4
def test_is_ip_v4():
    str_1 = 'C-L!z8=4Hj'
    bool_0 = is_ip_v4(str_1)
    assert bool_0 == False


# Generated at 2022-06-26 01:55:17.467910
# Unit test for function is_json
def test_is_json():
    str_1 = '{"name": "Peter"}'
    str_2 = '[1, 2, 3]'
    str_3 = '{nope}'
    assert is_json(str_1) == True, 'test_is_json: test_case_1'
    assert is_json(str_2) == True, 'test_is_json: test_case_2'
    assert is_json(str_3) == False, 'test_is_json: test_case_3'


# Generated at 2022-06-26 01:55:30.816326
# Unit test for function is_email
def test_is_email():
    #test case 1
    str_1 = 'testemail@gmail.com'
    bool_1 = is_email(str_1)
    if bool_1 == True:
        print(str_1 + ' is a valid email address.')
    else:
        print(str_1 + ' is an invalid email address.')
    #test case 2
    str_2 = 'testemail@@gmail.com'
    bool_2 = is_email(str_2)
    if bool_2 == True:
        print(str_2 + ' is a valid email address.')
    else:
        print(str_2 + ' is an invalid email address.')


# Generated at 2022-06-26 01:55:32.799374
# Unit test for function is_email
def test_is_email():
    result = is_email("sdv@gmail.com")
    assert result == True


# Generated at 2022-06-26 01:55:44.733892
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    isbn_13_input = '978-3-16-148410-0'
    assert __ISBNChecker(isbn_13_input).is_isbn_10() == False
    isbn_13_input = '978-3-16-148410-0'
    assert __ISBNChecker(isbn_13_input).is_isbn_10(normalize = False) == False
    isbn_13_input = '978-3-16-148410-0'
    assert __ISBNChecker(isbn_13_input).is_isbn_10(False) == False
    isbn_10_input = '0-8493-2632-2'
    assert __ISBNChecker(isbn_10_input).is_isbn_10() == True
    isbn_10_

# Generated at 2022-06-26 01:55:46.678948
# Unit test for function is_email
def test_is_email():
    str_0 = '@gmail.com'
    bool_0 = is_email(str_0)


# Generated at 2022-06-26 01:55:55.150555
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    # Test case 1
    str_0 = "1578984657123"
    bool_0 = __ISBNChecker(str_0).is_isbn_10()
    Assert(bool_0, True)
    # Test case 2
    str_1 = "123"
    bool_1 = __ISBNChecker(str_1).is_isbn_10()
    Assert(bool_1, False)
    # Test case 3

# Generated at 2022-06-26 01:55:58.521527
# Unit test for function is_email
def test_is_email():
    input_string = 'my.email@the-provider.com'
    output = is_email(input_string)
    expected_output = True
    assert output == expected_output 


# Generated at 2022-06-26 01:56:02.773895
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    class_0 = __ISBNChecker(str_0, True)
    bool_0 = class_0.is_isbn_13()
    assert bool_0 == False
    return 


# Generated at 2022-06-26 01:56:05.940344
# Unit test for function is_isbn
def test_is_isbn():
    str_0 = '9780312498580'
    bool_0 = is_isbn(str_0)
    str_1 = '150-6715214'
    bool_1 = is_isbn(str_1)
    str_2 = '978031249858'
    bool_2 = is_isbn(str_2)
    str_3 = '150-6715214'
    bool_3 = is_isbn(str_3, False)


# Generated at 2022-06-26 01:56:16.075974
# Unit test for function is_email
def test_is_email():
    # Test Case 1
    str_1 = 'foo@bar.com'
    bool_1 = is_email(str_1)
    print("bool_1 = ", bool_1)

    # Test Case 2
    str_2 = 'foo@bar.xyz'
    bool_2 = is_email(str_2)
    print("bool_2 = ", bool_2)

    # Test Case 3
    str_3 = 'foo@bar.xyz.abc'
    bool_3 = is_email(str_3)
    print("bool_3 = ", bool_3)

    # Test Case 4
    str_4 = 'foo.bar@xyz.abc'
    bool_4 = is_email(str_4)
    print("bool_4 = ", bool_4)

    # Test Case 5
    str

# Generated at 2022-06-26 01:56:27.183501
# Unit test for function is_email
def test_is_email():
    assert is_email('root@localhost') == True
    assert is_email('root@localhost-') == False
    assert is_email('root@localhost.') == True
    assert is_email('root@localhost.tld') == True
    assert is_email('root@localhost_tld') == True
    assert is_email('root@localhost.tld.') == True
    assert is_email('root@localhost.tld?q=1') == False
    assert is_email('root@localhost.tld&q=1') == False
    assert is_email('root@localhost.tld?1') == False
    assert is_email('root@localhost.tld?q=12') == False
    assert is_email('root@localhost.tld?q=12&p=1') == False

# Generated at 2022-06-26 01:56:37.559343
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}')


# Generated at 2022-06-26 01:56:40.045710
# Unit test for function is_json
def test_is_json():
    assert(is_json('{"name": "Peter"}'))
    assert(not is_json('[1, 2, 3]'))
    assert(not is_json('{nope}'))


# Generated at 2022-06-26 01:56:42.232976
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert not is_email('@gmail.com')


# Generated at 2022-06-26 01:56:54.419128
# Unit test for function is_email
def test_is_email():
    str_0 = '"_):-1<X"@e*[~(Rbo!:z6U&g5@5d6*3y:$:V<v-8M{W99"r>hZ`uY7'
    bool_0 = is_email(str_0)
    print(bool_0)



# Generated at 2022-06-26 01:57:03.982313
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    for length in range(4):
        for test_str in map(lambda x: '9' * x, range(length, 14)):
            num_checker = __ISBNChecker(test_str)
            num_is_isbn_13 = num_checker.is_isbn_13()
            num_is_not_13 = num_is_isbn_13 == False

            if len(test_str) == 13:
                assert test_str.isdecimal() == num_is_isbn_13, num_is_not_13
            else:
                assert num_is_not_13, num_is_not_13


# Generated at 2022-06-26 01:57:12.075395
# Unit test for function is_email
def test_is_email():
    """
    Test case for function is_email

    Verifies the function returns True for valid email
    and False for invalid email.
    """
    assert is_email("foo@bar.com")
    assert is_email("foo@bar.com.au")
    assert is_email("foo+bar@bar.com")
    assert is_email("hans.m端ller@test.com")
    assert is_email("hans@m端ller.com")
    assert is_email("test|123@m端ller.com")
    assert is_email("test123+ext@gmail.com")
    assert is_email("some.name.midd.leNa.me+extension@GoogleMail.com")
    assert is_email("foobar@192.168.0.1")

# Generated at 2022-06-26 01:57:13.964085
# Unit test for function is_email
def test_is_email():
    if is_email('abc@abc.com') == False:
        if is_email('"abc@abc"@abc.com') == True:
            raise
        if is_email('abc"abc"@abc.com') == True:
            raise
    else:
        raise


# Generated at 2022-06-26 01:57:19.997270
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False # not an ip
    assert is_ip_v4('255.200.100.999') == False # 999 is out of range


# Generated at 2022-06-26 01:57:25.592811
# Unit test for function is_json
def test_is_json():
    str_0 = '{"name": "Peter"}'
    ret = is_json(str_0)



# Generated at 2022-06-26 01:57:36.338451
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4111111111111111', card_type='VISA') == True
    assert is_credit_card('4111111111111111', card_type='MASTERCARD') == False

    assert is_credit_card('4111111111111111') == False
    assert is_credit_card('1234-4321-5678-9012') == False

    assert is_credit_card('6011111111111117') == True    # Discover
    assert is_credit_card('340011111111111') == True     # American Express
    assert is_credit_card('5100000010001004') == True    # MasterCard
    assert is_credit_card('6011 1234 5678 9012') == False
    assert is_credit_card('6011-1234-5678-9012') == False



# Generated at 2022-06-26 01:57:56.161751
# Unit test for function is_json
def test_is_json():
    str_0 = '[1, 2, 3]'
    str_1 = '{nope}'
    str_2 = '{300,200}'
    str_3 = '{300:200}'
    str_4 = '{300: "200"}'
    str_5 = '{300:200, "abc": "cde"}'
    str_6 = '{300:200, abc: "cde"}'
    str_7 = '[300,200]'
    str_8 = '{"abc":300}'
    str_9 = '{"abc":300, "def":200}'
    str_10 = '{"abc":300, def:200}'
    str_11 = '{"abc":300, "def":200, "ghi":100}'

# Generated at 2022-06-26 01:58:05.210722
# Unit test for function is_email
def test_is_email():
    # if __name__ != '__main__':
    #     raise RuntimeError('is_email must be invoked by name')
    assert (is_email('foo@example.com') == True)
    assert (is_email('foo.bar@example.com') == True)
    assert (is_email('fizz buzz@example.com') == False)
    assert (is_email('foo@example..com') == False)
    assert (is_email('"foo@example"@example.com') == False)
    assert (is_email('foo bar@example.com') == False)
    assert (is_email('') == False)
    assert (is_email('foo@192.168.0.1') == True)


# Generated at 2022-06-26 01:58:18.512449
# Unit test for function is_email
def test_is_email():
    assert is_email('this.is@valid.email') == True
    assert is_email('this.isnot.valid.email') == False
    assert is_email('this(is@notvalid.email') == False
    assert is_email('this.is@not.valid') == False
    assert is_email('this.is@not.valid.com.') == False
    assert is_email('@gmail.com') == False
    assert is_email('收件人@domain.com') == True
    assert is_email('firstname.lastname@domain.com') == True
    assert is_email('"firstname\\ lastname"@domain.com') == True
    assert is_email('"firstname@lastname"@domain.com') == True
    assert is_email('"email"@domain.com')

# Generated at 2022-06-26 01:58:19.967488
# Unit test for function is_json
def test_is_json():
    assert is_json('{ "name": "Peter" }') == True
    assert is_json('{nope}') == False
    assert is_json('0123456789') == False


# Generated at 2022-06-26 01:58:22.574458
# Unit test for function is_json
def test_is_json():
    str_0 = '{"lat": "45.65", "lon": "23.99"}'
    bool_0 = is_json(str_0)


# Generated at 2022-06-26 01:58:28.292523
# Unit test for function is_json
def test_is_json():
    # Test 1 - Positive test case
    str = '{"foo": 42}'
    assert is_json(str) == True

    # Test 2 - Negative test case
    str = '{"foo": 42'
    assert is_json(str) == False

    # Test 3 - Negative test case
    str = '"foo": 42'
    assert is_json(str) == False

    print("All test case for function is_json() passed successfully.")


# Generated at 2022-06-26 01:58:36.749495
# Unit test for function is_email
def test_is_email():
    str_0 = '7LuN4-0uV7-sxFxR-nGdt'
    str_1 = 'J`k-q3Kt-X@'
    str_2 = 'KTAJ-SOQI-2$8a-Kj;^'
    str_3 = 'p8WG-RxFx-@'
    str_4 = '8k;^-Kj-q3KtX'
    str_5 = '=!:'
    str_6 = '"8;@'
    str_7 = 'F72W-5Dx1-=!:'
    str_8 = 'w'
    str_9 = '6o2U-Zk1<-`*T&'

# Generated at 2022-06-26 01:58:39.546413
# Unit test for function is_email
def test_is_email():
    str_0 = '" "'
    bool_0 = is_email(str_0)


# Generated at 2022-06-26 01:58:42.877405
# Unit test for function is_ip_v4
def test_is_ip_v4():
    str_0 = 'sG*v|^_;ScaC1'
    bool_0 = is_ip_v4(str_0)
    print(bool_0)

test_case_0()
test_is_ip_v4()

# Generated at 2022-06-26 01:58:52.830435
# Unit test for function is_email
def test_is_email():
    assert is_email('a@gmail.com') is True
    assert is_email('a@hotmail.com') is True
    assert is_email('a@yahoo.com') is True
    assert is_email('a@live.com') is True
    assert is_email('a@aol.com') is True
    assert is_email('a@outlook.com') is True
    assert is_email('a@ibm.com') is True
    assert is_email('a@yandex.com') is True
    assert is_email('a@zoho.com') is True
    assert is_email('a@protonmail.com') is True
    assert is_email('a@mailserver.com') is True



# Generated at 2022-06-26 01:59:00.776529
# Unit test for function is_json
def test_is_json():
    str_0 = 'fzG&nH@ZSy18BFV)<{3uXnV'
    bool_0 = is_json(str_0)
    print(bool_0)


# Generated at 2022-06-26 01:59:03.210160
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    isbn_checker = __ISBNChecker("978-1593275846")
    bool_0 = isbn_checker.is_isbn_13()


# Generated at 2022-06-26 01:59:05.879788
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    isbn_checker = __ISBNChecker('8484508533', False)
    isbn_10 = isbn_checker.is_isbn_10()


# Generated at 2022-06-26 01:59:13.395228
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    str_0 = '3-598-21500-X'
    str_1 = '3-598-2150-X'
    obj_0 = __ISBNChecker(str_0)
    obj_1 = __ISBNChecker(str_1)
    bool_0 = obj_0.is_isbn_10()
    bool_1 = obj_1.is_isbn_10()
    assert bool_0 == True
    assert bool_1 == False


# Generated at 2022-06-26 01:59:17.100944
# Unit test for function is_json
def test_is_json():
    # Test case 0
    input_string = '{"name": "Peter"}'
    expected = True
    actual = is_json(input_string)
    assert actual == expected


# Generated at 2022-06-26 01:59:21.306719
# Unit test for function is_json
def test_is_json():
    print('Unit test for function is_json')
    f = open('sample_json.txt', 'r')
    input_string = f.read()
    is_json(input_string)
    f.close()

test_is_json()


# Generated at 2022-06-26 01:59:24.145638
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    str_0 = 'fjkdfjkdf'
    obj_0 = __ISBNChecker(str_0)
    bool_0 = obj_0.is_isbn_10()


# Generated at 2022-06-26 01:59:25.627011
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    str_0 = '-123456789-x'
    bool_0 = __ISBNChecker(str_0).is_isbn_10()


# Generated at 2022-06-26 01:59:27.767191
# Unit test for function is_email
def test_is_email():
    str_0 = 'h8"&}?.v|qe4b'
    bool_0 = is_email(str_0)


# Generated at 2022-06-26 01:59:34.158775
# Unit test for function is_json
def test_is_json():
    str_0 = '{"name": "Peter"}'
    bool_0 = is_json(str_0)
    assert bool_0

    str_1 = '[1, 2, 3]'
    bool_1 = is_json(str_1)
    assert bool_1

    str_2 = '{nope}'
    bool_2 = is_json(str_2)
    assert not bool_2

# Generated at 2022-06-26 01:59:59.341990
# Unit test for function is_json
def test_is_json():
    str_0 = '{"name": "Peter"}'
    bool_0 = is_json(str_0)
    bool_1 = True
    assert bool_0 == bool_1


# Generated at 2022-06-26 02:00:03.286602
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    actual = __ISBNChecker('0590353403')
    expected = True

    if actual == expected:
        print('True')
    else:
        print('False')


# Generated at 2022-06-26 02:00:07.284041
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    isbn_checker = __ISBNChecker('978-0-306-40615-7')
    result = isbn_checker.is_isbn_13()
    assert result == True


# Generated at 2022-06-26 02:00:19.215672
# Unit test for function is_ip_v4
def test_is_ip_v4():
    # Test for a simple IP address
    str_0 = '127.0.0.1'
    bool_0 = is_ip_v4(str_0)

    # Test for a simple IP address with multiple decimal points
    str_1 = '127.0.0.1.1'
    bool_1 = is_ip_v4(str_1)

    # Test for a simple IP address with actual numbers
    str_2 = '127.0.1.1'
    bool_2 = is_ip_v4(str_2)

    print(bool_0, bool_1, bool_2)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 02:00:32.273927
# Unit test for function is_json
def test_is_json():
    print("Test for function is_json")
    assert is_json("[1, 2, 3]") == True
    assert is_json("") == False
    assert is_json("  ") == False
    assert is_json("{nope}") == False
    assert is_json("{}") == True
    assert is_json("[]") == True
    assert is_json("{}") == True
    assert is_json("1") == False
    assert is_json("[") == False
    assert is_json("][") == False
    assert is_json("[1, 2, 3") == False
    assert is_json("[1, 2, 3] ]") == False
    assert is_json("[[1, 2, 3]]") == True
    assert is_json("[[1, 2, 3]") == False

# Generated at 2022-06-26 02:00:44.589058
# Unit test for function is_json
def test_is_json():
    str_0 = ' fc?r2bz8/xVG2s(}'
    test_case_1(str_0)

# Generated at 2022-06-26 02:00:48.117969
# Unit test for function is_email
def test_is_email():
    str_0 = 'jzha343@illinois.edu'
    bool_0 = is_email(str_0)
    assert bool_0 == True


# Generated at 2022-06-26 02:00:59.310323
# Unit test for function is_email
def test_is_email():
    str_0 = "Hej med dig min ven0@yahoo.com"
    str_1 = "abc..123@gmail.com"
    str_2 = "abc.123@gmail.com"
    str_3 = "abc123@aol.com"
    str_4 = "abc.@aol.com"
    str_5 = "abc@123.com"
    str_6 = '@gmail.com'
    str_7 = 'abc()[].,;:<>@gmail.com'
    str_8 = 'abc."def".xyz@gmail.com'
    str_9 = 'abc."def".xyz@abc.com'
    str_10 = 'abc.@gmail.com'
    str_11 = 'abc"def"ghi@gmail.com'

# Generated at 2022-06-26 02:01:09.138793
# Unit test for function is_ip_v4
def test_is_ip_v4():
    test_pass = 0
    test_fail = 0
    # Test 1: string is not full
    str_0 = '\n'
    bool_0 = is_ip_v4(str_0)
    if bool_0 == False:
        test_pass += 1
    else:
        test_fail += 1
    # Test 2: string is full, but is not a number
    str_0 = '255.200.100.75+'
    bool_0 = is_ip_v4(str_0)
    if bool_0 == False:
        test_pass += 1
    else:
        test_fail += 1
    # Test 3: string is full, but is not a number
    str_0 = '255.200.100.75+'

# Generated at 2022-06-26 02:01:12.388447
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    isbn_0 = __ISBNChecker(str_0)
    bool_0 = isbn_0.is_isbn_13()


# Generated at 2022-06-26 02:01:20.365982
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    int_0 = 0
    int_1 = 1
    int_2 = -1
    __ISBNChecker_0 = __ISBNChecker(str_0)
    int_3 = __ISBNChecker_0.is_isbn_10()


# PUBLIC API


# Generated at 2022-06-26 02:01:31.254461
# Unit test for function is_email
def test_is_email():
    email_0 = 'wittmann.mark'
    email_1 = 'wittmann.@mark'
    email_2 = 'wittmann.mark@'
    email_3 = 'wittmann.mark@gmail.com'
    email_4 = 'wittmann.mark+@gmail.com'
    email_5 = 'wittmann.mark++@gmail.com'
    email_6 = 'wittmann.mark..@gmail.com'
    email_7 = 'wittmann.mark@gmail.com.'
    email_8 = 'wittmann.mark..+@gmail.com'
    email_9 = 'wittmann.mark.+@gmail.com'
    email_10 = 'wittmann.mark.+@gmail.com'

# Generated at 2022-06-26 02:01:34.026700
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}')
    assert is_json('[1, 2, 3]')
    assert is_json('')
    assert not is_json('{nope}')



# Generated at 2022-06-26 02:01:43.147761
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    isbn_checker_0 = __ISBNChecker('')
    bool_0 = isbn_checker_0.is_isbn_10()
    assert not bool_0, "__ISBNChecker_is_isbn_10_0 failed"
    isbn_checker_1 = __ISBNChecker('', False)
    bool_1 = isbn_checker_1.is_isbn_10()
    assert not bool_1, "__ISBNChecker_is_isbn_10_1 failed"
    isbn_checker_2 = __ISBNChecker("9X}x", True)
    bool_2 = isbn_checker_2.is_isbn_10()
    assert not bool_2, "__ISBNChecker_is_isbn_10_2 failed"
   

# Generated at 2022-06-26 02:01:57.326861
# Unit test for function is_email
def test_is_email():
    input_string_0 = 'email@te_st.com'
    input_string_1 = 'ema+il@@te_st@.com'
    input_string_2 = "em\\ ail@te_st.com"
    input_string_3 = '\"ema il\"@te_st.com'
    input_string_4 = 'email@te_st..com'
    input_string_5 = 'email@te_st.com@'
    input_string_6 = 'email@te_st.com@123'
    input_string_7 = 'email@te_st.com@123.'
    input_string_8 = 'email@te_st.com@123.com'
    input_string_9 = 'email@te_st.com@123.com@'

# Generated at 2022-06-26 02:01:59.804498
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    isbn_0 = __ISBNChecker('978-94-015-5964-8')
    bool_0 = isbn_0.is_isbn_13()


# Generated at 2022-06-26 02:02:11.416018
# Unit test for function is_email
def test_is_email():
    assert is_email('name@example.com') == True
    assert is_email('name@example.co.uk') == True
    assert is_email('name@example-example.com') == True
    assert is_email('standardized.email@example.com') == True
    assert is_email('standardized.email+name@example.com') == True
    assert is_email('standardized.email@subdomain.example.com') == True
    assert is_email('standardized.email@example.com') == True
    assert is_email('standardized.email+name@example.com') == True
    assert is_email('john.smith@example.com') == True
    assert is_email('john_smith@example.com') == True