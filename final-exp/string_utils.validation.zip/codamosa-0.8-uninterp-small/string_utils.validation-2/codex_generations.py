

# Generated at 2022-06-26 01:52:17.191543
# Unit test for function is_isbn
def test_is_isbn():
    #test.test_is_isbn
    print("test_is_isbn")
    assert (is_isbn("9780312498580") == True)


# Generated at 2022-06-26 01:52:25.262013
# Unit test for function is_ip_v4
def test_is_ip_v4():
    # Check against correct IP
    bool_0 = is_ip_v4("192.168.0.1")
    assert bool_0
    # Check against incorrect IP
    bool_1 = is_ip_v4("999.168.0.1")
    assert not bool_1
    # Check against incorrect IP
    bool_2 = is_ip_v4("999.168.0.1.2")
    assert not bool_2


# Generated at 2022-06-26 01:52:27.477213
# Unit test for function is_email
def test_is_email():
    input_string = 'test case'
    compare = is_email(input_string)
    assert compare == False


# Generated at 2022-06-26 01:52:30.876634
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    isbn_checker_0 = __ISBNChecker(input_string = "X0BHZQ-hZJjae")
    assert isbn_checker_0.is_isbn_10() == False


# Generated at 2022-06-26 01:52:43.982883
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    # is_isbn_10(self)
    # Tests if isbn 10 is valid
    string_0 = ' '
    bool_0 = __ISBNChecker(string_0).is_isbn_10()
    assert bool_0 == False
    string_1 = '0n9'
    bool_1 = __ISBNChecker(string_1).is_isbn_10()
    assert bool_1 == False
    string_2 = '0n9'
    bool_2 = __ISBNChecker(string_2).is_isbn_10()
    assert bool_2 == False
    string_3 = '0n9'
    bool_3 = __ISBNChecker(string_3).is_isbn_10()
    assert bool_3 == False
    string_4 = '0n9'
   

# Generated at 2022-06-26 01:52:53.043908
# Unit test for function is_decimal
def test_is_decimal():
    assert not is_decimal(['Test'])
    assert not is_decimal(None)
    assert not is_decimal(42)
    assert not is_decimal('A string that is not a number')
    assert is_decimal('124.12')
    assert is_decimal('-124.12')
    assert is_decimal('.12')
    assert is_decimal('1e3')
    assert not is_decimal('12e3.15')
    assert not is_decimal('.1.2')

test_is_decimal()


# Generated at 2022-06-26 01:53:01.669024
# Unit test for function is_email
def test_is_email():
    string_0 = "this \"is\" a \"test\""
    string_1 = "'hi'"
    string_2 = "\"hi\""
    string_3 = "\"hi\"'test'"
    string_4 = "\"hi\"test\""
    string_5 = "test"
    string_6 = "\"test"
    string_7 = "test\""
    string_8 = "\"test\""
    string_9 = "test\"\"\""
    string_10 = "\"test\"\"\"\""
    string_11 = "\"test\"\"\"\"\""
    string_12 = "\"\"\"\"\""
    string_13 = "'\"\"\"\"\"\"'\""
    string_14 = "\"\"\"\"\"\"\""
    string_15 = "'"
    string_16

# Generated at 2022-06-26 01:53:07.189364
# Unit test for function is_email
def test_is_email():
    assert is_email('') == False
    assert is_email('myemail@gmail.com') == True
    assert is_email('myemail.gmail.com') == False
    assert is_email('myemail@gmail.com.') == False
    assert is_email('myemail@gmail..com') == False



# Generated at 2022-06-26 01:53:11.707068
# Unit test for function is_ip_v4
def test_is_ip_v4():
    # <Input data for Unit test>
    list_0 = []
    bool_0 = is_slug(list_0)
    # </Input data for Unit test>

    # <Expected output for Unit test>
    return bool_0
    # </Expected output for Unit test>


# Generated at 2022-06-26 01:53:16.482134
# Unit test for function is_ip
def test_is_ip():
    ip_v4 = '95.57.233.186'
    ip_v6 = '2001:db8::1428:57ab'
    assert is_ip(ip_v4) == True
    assert is_ip(ip_v6) == True



# Generated at 2022-06-26 01:53:32.731757
# Unit test for function is_credit_card
def test_is_credit_card():
    #
    #  TODO: Student must continue the test by adding more test cases.
    #
    assert is_credit_card('4567890123456789') # American Express
    assert is_credit_card('4444444444444444') # American Express
    assert is_credit_card('5555555555555555') # Mastercard
    assert is_credit_card('5478901234567890') # Mastercard
    assert is_credit_card('4111-1111-1111-1111') # Visa
    assert is_credit_card('4111111111111111') # Visa
    assert is_credit_card('230000000000009')  # Diners Club
    assert is_credit_card('2300000000000009')  # Diners Club
    assert is_credit_card('309600000000009')  # D

# Generated at 2022-06-26 01:53:34.163129
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75')
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334')


# Generated at 2022-06-26 01:53:36.928807
# Unit test for function is_ip
def test_is_ip():
    assert(is_ip('255.200.100.75') == True)
    assert(is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True)
    assert(is_ip('1.2.3') == False)


# Generated at 2022-06-26 01:53:49.832604
# Unit test for function is_credit_card
def test_is_credit_card():
    print("*** TEST: is_credit_card ***")

    assert is_credit_card("378282246310005", 'AMERICAN_EXPRESS') == True
    assert is_credit_card("371449635398431", 'AMERICAN_EXPRESS') == True
    assert is_credit_card("378734493671000", 'AMERICAN_EXPRESS') == True
    assert is_credit_card("371449635398431", 'AMERICAN_EXPRESS') == True
    assert is_credit_card("378734493671000", 'AMERICAN_EXPRESS') == True
    assert is_credit_card("378282246310005", 'AMERICAN_EXPRESS') == True
    assert is_credit_card("5555555555554444", 'MASTERCARD') == True

# Generated at 2022-06-26 01:53:53.782889
# Unit test for function is_email
def test_is_email():
    assert is_email('fortnite.kid@gmail.com')
    assert not is_email('fortnite.kid@.com')
    assert not is_email('fortnite..kid@gmail.com')



# Generated at 2022-06-26 01:54:04.762059
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4242424242424242424242', 'VISA')
    assert is_credit_card('5555555555554444', 'MASTERCARD')
    assert is_credit_card('378282246310005', 'AMERICAN_EXPRESS')
    assert is_credit_card('30569309025904', 'DINERS_CLUB')
    assert is_credit_card('6011111111111117', 'DISCOVER')
    assert is_credit_card('3530111333300000', 'JCB')
    assert is_credit_card('4242424242424242424242')
    assert not is_credit_card('123456789')
    assert not is_credit_card(None)


# Generated at 2022-06-26 01:54:20.407353
# Unit test for function is_email
def test_is_email():
    # Generate a test case input with random value
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()
    test_

# Generated at 2022-06-26 01:54:22.144216
# Unit test for function is_email
def test_is_email():
    # Check if function returns correct value for correct data
    assert (is_email('my.email@the-provider.com') == True)
    
    

# Test to see if function returns False for a wrong value

# Generated at 2022-06-26 01:54:25.266178
# Unit test for function is_email
def test_is_email():
    str_0 = 'test@test.test'
    str_1 = 'testtest.test'

    assert is_email(str_0) == True
    assert is_email(str_1) == False


# Generated at 2022-06-26 01:54:27.750771
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    str_0 = "978-81-7597-008-8"
    bool_0 = __ISBNChecker(str_0).is_isbn_10()


# Generated at 2022-06-26 01:54:44.693717
# Unit test for function is_json
def test_is_json():
    '''
    Test function
    '''
    json_obj = '''
    {
        "name": "Peter",
        "age": 23,
        "married": true,
        "children": ["Paul", "John"],
        "address": {
            "street": "Baker Street",
            "city": "London"
        }
    }
    '''
    assert is_json(json_obj)
    bool_0 = is_json(json_obj)
    json_list = '[1, 2, 3, 4]'
    assert is_json(json_list)
    bool_1 = is_json(json_list)
    json_broken = '{nope}'
    assert not is_json(json_broken)
    bool_2 = is_json(json_broken)


# Generated at 2022-06-26 01:54:56.981425
# Unit test for function is_url
def test_is_url():
    prefix = 'https://'
    domain = 'www.google.com'
    path = '/test/test'
    params = '?test=test'
    # Parameter types
    # [1.1] String
    # String
    test_url_0 = prefix + domain + path
    # [1.2] Empty String
    # String
    test_url_1 = ""
    # [2.1] None
    # NoneType
    test_url_2 = ""
    # [2.2]
    # int
    test_url_3 = 0
    # [2.3]
    # float
    test_url_4 = 0.1
    # [2.4]
    # long
    test_url_5 = 1234567890
    # [3.1]
    # list
    test_

# Generated at 2022-06-26 01:55:05.118107
# Unit test for function is_email
def test_is_email():
	print(is_email("john.doe@company.com"))
	print(is_email("john.doe@localhost"))
	print(is_email("john.doe@0.0.0.0"))
	print(is_email("john.doe@company.com"))
	print(is_email("john.doe@company.com"))
	print(is_email("john.doe@company.com") == True)
	print(is_email("john.doe@company.com") == True)
	print(is_email("john.doe@company.com") == True)
	print(is_email("john.doe@company.com") == True)
	print(is_email("john.doe@company.com") == True)

# Generated at 2022-06-26 01:55:17.072975
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}'), "Basic test failed"
    assert is_json('[1, 2, 3]'), "Basic test failed"
    assert not is_json('{nope}'), "Basic test failed"
    assert is_json('[]'), "Basic test failed"
    assert is_json('{}'), "Basic test failed"

# Generated at 2022-06-26 01:55:22.372095
# Unit test for function is_json
def test_is_json():
    input_string = 'test case'
    bool_0 = is_json(input_string)
    assert(bool_0 == False)

    input_string = '[1, 2, 3]'
    bool_0 = is_json(input_string)
    assert(bool_0 == True)


# Generated at 2022-06-26 01:55:27.581533
# Unit test for function is_json
def test_is_json():
    input_string1 = '{"name": "Peter"}'
    output = is_json(input_string1)
    print(output)
    assert output == True
    input_string2 = '[1, 2, 3]'
    output = is_json(input_string2)
    print(output)
    assert output == True
    input_string3 = '{nope}'
    output = is_json(input_string3)
    print(output)
    assert output == False



# Generated at 2022-06-26 01:55:33.609150
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    __ISBNChecker0 = __ISBNChecker("", normalize=True)
    bool_0 = __ISBNChecker0.is_isbn_13()
    __ISBNChecker0 = __ISBNChecker(False, normalize=True)
    bool_1 = __ISBNChecker0.is_isbn_13()


# Generated at 2022-06-26 01:55:40.183051
# Unit test for function is_url
def test_is_url():
    try:
        assert(is_url("http://www.google.com"))
        assert(is_url("google.com"))
        assert(is_url("http://google.com"))
        assert(is_url("http://google.com:8042"))
    except Exception:
        raise AssertionError("Error in function is_url")
    else:
        print("Test passed")


# Generated at 2022-06-26 01:55:50.773151
# Unit test for function is_json
def test_is_json():
    # Check that the input is a string
    try:
        assert is_json(123) == False
    except:
        raise AssertionError()
    # Check that the input string is a json format
    try:
        assert is_json('{nope}') == False
    except:
        raise AssertionError()
    # Check that the input is an empty string
    try:
        assert is_json('') == False
    except:
        raise AssertionError()
    # Check that the input string is a valid json
    try:
        assert is_json('{"name": "Peter"}') == True
    except:
        raise AssertionError()
    # Check that the input string is a valid json

# Generated at 2022-06-26 01:55:52.504078
# Unit test for function is_json
def test_is_json():
    print('Testing is_json()')
    list_0 = []
    bool_0 = is_json(list_0)
    assert bool_0



# Generated at 2022-06-26 01:55:59.946092
# Unit test for function is_url
def test_is_url():
    input_string = 'http://www.mysite.com'
    assert is_url(input_string)



# Generated at 2022-06-26 01:56:03.629577
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    obj___ISBNChecker = __ISBNChecker("978-1-60309-452-8")
    bool_0 = obj___ISBNChecker.is_isbn_13()


# Generated at 2022-06-26 01:56:10.720673
# Unit test for function is_url
def test_is_url():
    # Call function with arguments: ('http://www.acme.com')
    bool_0 = is_url('https://www.mysite.com')

    # Call function with arguments: ('https://mysite.com')
    bool_1 = is_url('https://mysite.com')

    # Call function with arguments: ('.mysite.com')
    bool_2 = is_url('.mysite.com')

    if bool_0 == bool_1 == bool_2:
        return True
    else:
        return False



# Generated at 2022-06-26 01:56:18.499668
# Unit test for function is_url
def test_is_url():
    expected = (True,False,True,False,True,False,False)
    actual = []
    str1 = "http://www.google.com"
    str2 = "http://google.com"
    str3 = "google.com"
    str4 = "http://www.google.com"
    str5 = "ftp://www.google.com"
    str6 = "https://www.google.com"
    str7 = "www.google.com"
    urllist = [str1,str2,str3,str4,str5,str6,str7]
    for str in urllist:
        actual.append(is_url(str))
    assert expected == actual

# Generated at 2022-06-26 01:56:30.648241
# Unit test for function is_json
def test_is_json():
    assert is_json('{ "name": "John Doe" }') == True
    assert is_json('[1,2,3]') == True
    assert is_json('{nope }') == False
    assert is_json('[]') == True
    assert is_json('{}') == True
    assert is_json('{"hello":1}') == True
    assert is_json('{"hello": 1}') == True
    assert is_json('{"hello": }') == False
    assert is_json('{"hello": ""}') == True
    assert is_json('{}') == True
    assert is_json('[]') == True
    assert is_json('"hello"') == False
    assert is_json('') == False
    assert is_json('a ') == False
    assert is_json('a')

# Generated at 2022-06-26 01:56:33.439829
# Unit test for function is_email
def test_is_email():
    input_string = "foo"
    assert is_email(input_string) == False
    assert is_email("foo@gmail.com") == True



# Generated at 2022-06-26 01:56:40.050097
# Unit test for function is_url
def test_is_url():
	assert(is_url('http://www.mysite.com') == 1)
	assert(is_url('.mysite.com') == 1)
	assert(is_url('www.mysite.com') == 1)
	assert(is_url('mysite.com') == 1)
	assert(is_url('https://mysite.com') == 1)
	assert(is_url('ftp://mysite.com') == 1)
	assert(is_url('file://mysite.com') == 1)


# Generated at 2022-06-26 01:56:51.614704
# Unit test for function is_email
def test_is_email():
    list_0 = []
    list_1 = []
    list_2 = []
    list_3 = []
    list_4 = []
    list_5 = []
    list_6 = []
    list_7 = []
    list_8 = []
    list_9 = []
    # We check that each element of list_0 is a valid email
    for x in list_0:
        bool_0 = is_email(x)
        assert bool_0 == True

    # We check that each element of list_1 is a valid email
    for x in list_1:
        bool_0 = is_email(x)
        assert bool_0 == True

    # We check that each element of list_2 is a valid email
    for x in list_2:
        bool_0 = is_email(x)

# Generated at 2022-06-26 01:56:54.372945
# Unit test for function is_email
def test_is_email():
    assert is_email('t@t') == True
    assert is_email('t.t@t.t') == True


# Generated at 2022-06-26 01:56:56.808428
# Unit test for function is_email
def test_is_email():
    str_0 = 'my.email@the-provider.com'
    bool_0 = is_email(str_0)



# Generated at 2022-06-26 01:57:04.266638
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('3956233338').is_isbn_10() == True


# Generated at 2022-06-26 01:57:06.071938
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    c = __ISBNChecker('979-10-95546-26-2')
    assert c.is_isbn_13() == True


# Generated at 2022-06-26 01:57:16.866953
# Unit test for method is_isbn_10 of class __ISBNChecker

# Generated at 2022-06-26 01:57:21.588289
# Unit test for function is_email
def test_is_email():
    assert is_email("test@test.com") == True
    assert is_email("test@test") == False
    assert is_email("testtest.com") == False
    assert is_email("test@test.") == False


# Generated at 2022-06-26 01:57:28.271168
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    # TODO: Build test
    def __is_isbn_10(input_string: str, expected: bool):
        actual = __ISBNChecker(input_string).is_isbn_10()
        assert actual == expected, f'Expected: {expected}, actual: {actual}'

    __is_isbn_10('9442533107', True)
    __is_isbn_10('1853260415', True)
    __is_isbn_10('0906391100', True)
    __is_isbn_10('0906391101', False)
    __is_isbn_10('', False)
    __is_isbn_10(' ', False)
    __is_isbn_10('090639110', False)

# Generated at 2022-06-26 01:57:32.797324
# Unit test for function is_json
def test_is_json():
    try:
        # Start timer
        start_time_0 = time.time()

        # Start timer
        start_time_1 = time.time()
        dict_0 = {'a': 1, 'b': 2, 'c': 3}
        dict_1 = json.dumps(dict_0)
        bool_0 = is_json(dict_1)
        # Stop and print timer
        print("%s seconds" %(time.time() - start_time_1))

    except Exception as exception_0:
        print("Exception raised: ")
        print(exception_0)
        # Stop and print timer
        print("%s seconds" %(time.time() - start_time_0))



# Generated at 2022-06-26 01:57:41.400959
# Unit test for function is_email
def test_is_email():
    assert is_email('brian-23@hackerrank.com') == True    # Sample test
    assert is_email('brian-23@hackerrankcom') == False    # String ends with .com
    assert is_email('ala-ma-kota@brian.com') == True      # It should pass
    assert is_email('ala@ma@kota.com') == False           # String contains multiple @ signs



# Generated at 2022-06-26 01:57:43.260869
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    # initialize input arguments

    # call the method
    is_isbn_10()


# Generated at 2022-06-26 01:57:49.759875
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    parameters_list = [(1234,), (0,), (-1234,), (12.34,), (True,), (False,), (None,)]
    for parameters in parameters_list:
        try:
            instance = __ISBNChecker(parameters[0])
            instance.is_isbn_10()
        except InvalidInputError:
            pass
        else:
            print('Failed to raise InvalidInputError at', parameters)

    instance = __ISBNChecker('12345')
    test_method = instance.is_isbn_10
    assert False == test_method()
    assert False == test_method()
    assert False == test_method()
    assert False == test_method()
    assert False == test_method()
    assert False == test_method()
    assert False == test_method()
    assert False

# Generated at 2022-06-26 01:57:58.539591
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('0-306406152-5').is_isbn_13() == False
    assert __ISBNChecker('0-8254-3960-8').is_isbn_13() == False
    assert __ISBNChecker('978-0-306406152').is_isbn_13() == True
    assert __ISBNChecker('9783036406152').is_isbn_13() == True
    assert __ISBNChecker('978-3-16-148410-0').is_isbn_13() == True
    assert __ISBNChecker('978-3-16-148410-1').is_isbn_13() == False
    assert __ISBNChecker('978-0-306406152').is_isbn_13() == True

# Generated at 2022-06-26 01:58:06.330243
# Unit test for function is_email
def test_is_email():
    # Test case 0
    test_case_0()
    assert(is_email('123@45.67'))



# Generated at 2022-06-26 01:58:09.251773
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    _isbn_checker_0 = __ISBNChecker("9876543210")
    assert _isbn_checker_0.is_isbn_10()


# Generated at 2022-06-26 01:58:22.136496
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    checker = __ISBNChecker(' 9780470059029')
    assert checker.is_isbn_10() == True
    checker = __ISBNChecker(' 9780471486480')
    assert checker.is_isbn_10() == True
    checker = __ISBNChecker(' 9780470059029')
    assert checker.is_isbn_10() == True
    checker = __ISBNChecker(' 9780470059029')
    assert checker.is_isbn_10() == True
    checker = __ISBNChecker(' 9780470059029')
    assert checker.is_isbn_10() == True
    checker = __ISBNChecker(' 9780470059029')
    assert checker.is_isbn_10() == True
   

# Generated at 2022-06-26 01:58:25.510056
# Unit test for function is_email
def test_is_email():
    # Call function is_email
    bool_1 = is_email("my.email@the-provider.com")
    bool_2 = is_email("@gmail.com")
    # Output:
    # True
    # False


# Generated at 2022-06-26 01:58:29.303514
# Unit test for function is_json
def test_is_json():
    print("Start test is_json")
    assert is_json('{"name": "Peter"}')
    assert is_json('[1, 2, 3]')
    assert not is_json('{nope}')
    print("End test is_json")


# Generated at 2022-06-26 01:58:35.369768
# Unit test for function is_json
def test_is_json():
    # Is string json?
    assert is_json('{"name": "Peter"}') # returns true
    assert is_json('[1, 2, 3]') # returns true

    # Is string not json?
    assert not is_json('{nope}') # returns false
    assert not is_json('[trololo, blabla]') # returns false
    assert not is_json('{"name": trololo, "blabla": "nope"}') # returns false

    print("[SUCCESS] test_is_json")




# Generated at 2022-06-26 01:58:46.101301
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    test_cases = [
        (True, "9780470059029"),
        (True, "978-0-13-149505-0"),
        (True, "978 0 471 48648 0"),
        (True, "87-21-02006-4"),
        (False, "87-21-02006-3"),
        (False, "8721-02006-4"),
        (False, "978-0-13-149505-X"),
        (False, "978 0 471 48648"),
        (False, "9780470059028")
    ]

    for expected, input_string in test_cases:
        checker = __ISBNChecker(input_string)

        assert checker.is_isbn_13() == expected

    #print('test___ISBNChecker_is_isbn

# Generated at 2022-06-26 01:58:49.972359
# Unit test for function is_json
def test_is_json():
    print("Test is_json()")
    assert is_json("{'name': 'James'}") == False
    assert is_json("{\"name\": \"Peter\"}") == True
    assert is_json("[1,2,3]") == True


# Generated at 2022-06-26 01:58:54.780764
# Unit test for function is_json
def test_is_json():
    # assert test_case_0()
    assert is_json("") == False
    assert is_json("[1, 2, 3]") == True
    assert is_json("{nope}") == False
    assert is_json("123") == False
    assert is_json("abc") == False



# Generated at 2022-06-26 01:58:56.480403
# Unit test for function is_json
def test_is_json():
    bool_0 = is_json('{"name": "Peter"}')
    assert bool_0 == True


# Generated at 2022-06-26 01:59:08.051196
# Unit test for function is_json
def test_is_json():
    # Test case 0
    str_0 = '{"name": "Peter"}'
    bool_0 = is_json(str_0)
    assert bool_0 == True

    # Test case 1
    str_1 = '[1, 2, 3]'
    bool_1 = is_json(str_1)
    assert bool_1 == True

    # Test case 2
    str_2 = '{nope}'
    bool_2 = is_json(str_2)
    assert bool_2 == False


# Generated at 2022-06-26 01:59:20.171565
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('test@test.test') == True
    assert is_email('.test@test.test') == False
    assert is_email('test@test.test.') == False
    assert is_email('test.@test.test') == False
    assert is_email('test.t@test.test') == True
    assert is_email('test..t@test.test') == False
    assert is_email('"t..e"@test.test') == True
    assert is_email('""t..e""@test.test') == True
    assert is_email('""t..e""@test.test.com') == True

# Generated at 2022-06-26 01:59:28.596435
# Unit test for function is_email
def test_is_email():
	str_ = ''
	str_1 = 'my.email@the-provider.com'
	str_2 = 'my.emailthe-provider.com'
	str_3 = 'invalid_char*<'
	str_4 = 'invalid_char@*<'
	
	passed = 0
	
	if is_email(str_1) == True:
		passed = passed + 1
	else:
		print('Failed for input: ', str_1)
	if is_email(str_2) == False:
		passed = passed + 1
	else:
		print('Failed for input: ', str_2)
	if is_email(str_3) == False:
		passed = passed + 1

# Generated at 2022-06-26 01:59:30.738527
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False


# Generated at 2022-06-26 01:59:33.260221
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    num = __ISBNChecker("9780140449134")
    assert num.is_isbn_13() == True


# Generated at 2022-06-26 01:59:42.816334
# Unit test for function is_email
def test_is_email():
    try:
        assert is_email('email@gmail.com') == True
        assert is_email('.email@gmail.com') == False
        assert is_email('email..@gmail.com') == False
        assert is_email('email@gmail') == False
        assert is_email('email@.gmail.com') == False
        assert is_email('email@.gmail.com') == False
    except AssertionError:
        print("Assertion failed")

# === Main ===
if __name__ == '__main__':
    test_is_email()
    test_case_0()



# Generated at 2022-06-26 01:59:52.146869
# Unit test for function is_email
def test_is_email():
    bool_0 = is_email('my.email@the-provider.com')
    bool_1 = is_email('@gmail.com')
    bool_2 = is_email('myemail@the-provider.com')

    if(bool_0 == True and bool_1 == False and bool_2 == True):
        print("PASS")
    else:
        print("FAIL")


# Generated at 2022-06-26 01:59:56.434468
# Unit test for function is_email
def test_is_email():
    assert(is_email('my.email@the-provider.com') == True)
    assert(is_email('@gmail.com') == False)
    assert(is_email('my.email@the-provider.com') == True)


# Generated at 2022-06-26 02:00:01.699425
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert (is_ip_v4('255.200.100.75') == True)
    assert (is_ip_v4('nope') == False)
    assert (is_ip_v4('255.200.100.999') == False)


# Generated at 2022-06-26 02:00:10.891039
# Unit test for function is_email
def test_is_email():
    string_0 = "mlyousef@grinnell.edu"
    string_1 = '"mlyousef"@grinnell.edu'
    string_2 = 'mlyousef@grinnell'
    string_3 = "mlyousef@grinnell.edu".replace('m', 'M')
    string_4 = '"mlyousef"@grinnell.edu'.replace('m', 'M')
    string_5 = 'Mlyousef@grinnell.edu'
    string_6 = "mlyousef@grinnell.edu"
    string_7 = "mlyousef@grinnell.edu"
    string_8 = '"mlyousef"@grinnell.edu'
    string_9 = "mlyousef@grinnell.edu"
   

# Generated at 2022-06-26 02:00:22.403059
# Unit test for function is_json
def test_is_json():
    print('Testing function is_json')
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{"name": "Peter"}') == True
    assert is_json('{"name": "Peter"') == False
    assert is_json('[1, 2, 3') == False
    assert is_json('hello') == False
    assert is_json('') == False
    assert is_json(10) == False
    print('Passed!')


# Generated at 2022-06-26 02:00:24.830971
# Unit test for function is_email
def test_is_email():
    input_string = "my.email@the-provider.com"
    output = is_email(input_string)
    assert output == True


# Generated at 2022-06-26 02:00:37.393603
# Unit test for function is_email
def test_is_email():
    # Test case with the standard email format
    # Returns true
    is_email("helloworld@gmail.com")
    # Test case with email address contain . at the end
    # Returns false
    is_email("helloworld@gmail.com.")
    # Test case with email address contain . at the start
    # Returns false
    is_email(".helloworld@gmail.com")
    # Test case with email address with space in the middle
    # Returns false
    is_email("hello.world@gmail.com")
    # Test case with double @ sign
    # Returns false
    is_email("hello@world@gmail.com")
    # Test case with double @ sign and escaped @ sign in the end
    # Returns false
    is_email("hello@world@gmail.\com")
    # Test case with escaped @ sign in

# Generated at 2022-06-26 02:00:40.245378
# Unit test for function is_email
def test_is_email():
    input_string_0 = ['abc@gmail.com', 'abc@gmail.com', 'abc@gmail.com']
    assert is_email(input_string_0)


# Generated at 2022-06-26 02:00:44.367901
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    __ISBNChecker_instance = __ISBNChecker(input_string = '1234567890123')
    assert __ISBNChecker_instance.is_isbn_13() == True


# Generated at 2022-06-26 02:00:47.928469
# Unit test for function is_json
def test_is_json():
    assert is_json({"name": "Peter"})
    assert is_json([1, 2, 3])
    assert not is_json({nope})


# Generated at 2022-06-26 02:00:59.012950
# Unit test for function is_email
def test_is_email():
    assert is_email('foo@bar.com') == True
    assert is_email('foo@bar.com') == True
    assert is_email('foo@bar.co.uk') == True
    assert is_email('foo+bar@bar.com') == True
    assert is_email('foo@bar.com.au') == True
    assert is_email('foo@bar.net') == True
    assert is_email('foo@bar.com.br') == True
    
    assert is_email('invalidemail@') == False
    assert is_email('@invalid.com') == False
    assert is_email('test@example.com\nHello') == False
    assert is_email('test@ -example.com') == False
    assert is_email('test@111.222.333.44444') == False
   

# Generated at 2022-06-26 02:01:08.875364
# Unit test for function is_ip_v4
def test_is_ip_v4():
    # Test case #0
    bool_0 = is_ip_v4("192.86.32.54")
    assert bool_0, "Condition not met - test case #0"
    # Test case #1
    bool_0 = is_ip_v4("255.200.100.75")
    assert bool_0, "Condition not met - test case #1"
    # Test case #2
    bool_0 = is_ip_v4("3.2.2.2")
    assert bool_0, "Condition not met - test case #2"
    # Test case #3
    bool_0 = is_ip_v4("255.200.100.999")
    assert not bool_0, "Condition not met - test case #3"
    # Test case #4
    bool_0 = is_ip_v4

# Generated at 2022-06-26 02:01:17.782231
# Unit test for function is_email
def test_is_email():
    assert is_email("john.smith@gmail.com") == True
    assert is_email("somebody@gmail.com") == True
    assert is_email("somebody@hotmail.com") == True
    assert is_email("somebody@yahoo.com") == True
    assert is_email("somebody@qq.com") == True
    assert is_email("some body@qq.com") == False
    assert is_email("somebody @qq.com") == False
    assert is_email("somebody@ qq.com") == False
    assert is_email("somebody@qq.c om") == False
    assert is_email("some body@qq.c om") == False


# Generated at 2022-06-26 02:01:22.856326
# Unit test for function is_email
def test_is_email():
    assert is_email("vouga@kth.se") == True
    assert is_email("vouga@kthse") == False
    assert is_email("vougakth.se") == False
    assert is_email("vouga@kth.com") == True
    assert is_email("vouga@gmail.com") == True
    assert is_email("vouga@hotmail.com") == True
    assert is_email("vouga@gmail.se") == False
    assert is_email("vouga") == False
    assert is_email("vouga@") == False
    assert is_email("vouga@kth") == False
    assert is_email("vouga+@kth.se") == True
    assert is_email("vouga@+kth.se")

# Generated at 2022-06-26 02:01:33.526405
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    bool_0 = __ISBNChecker("2553004233680").is_isbn_13()
    assert bool_0 == True


# Generated at 2022-06-26 02:01:38.788660
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    # Prepare test data
    input_string = '9789571331186'
    normalize = False

    # Execute tested code
    checker = __ISBNChecker(input_string, normalize)
    checker.is_isbn_13()

    # Check result
    assert is_isbn_13(input_string)


# Generated at 2022-06-26 02:01:41.311908
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    input_string = '9789063693977'
    isbn_checker = __ISBNChecker(input_string)
    expected_value = True
    actual_value = isbn_checker.is_isbn_13()
    assert actual_value == expected_value


# Generated at 2022-06-26 02:01:50.246824
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    # setup
    input_string = '123'
    isbn_checker = __ISBNChecker(input_string)

    # Run the test
    expected_result = False
    actual_result = isbn_checker.is_isbn_10()

    # Check if the test has passed
    assert actual_result == expected_result


# PUBLIC API



# Generated at 2022-06-26 02:01:54.611848
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False



# Generated at 2022-06-26 02:02:06.254766
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    checker = __ISBNChecker(input_string="1234567890123")
    assert checker.is_isbn_13() == False
    checker = __ISBNChecker(input_string="978-1-123-45678-9")
    assert checker.is_isbn_13() == False
    checker = __ISBNChecker(input_string="978-1-123-45678-9")
    assert checker.is_isbn_13() == False
    checker = __ISBNChecker(input_string="9781234567896")
    assert checker.is_isbn_13() == True
