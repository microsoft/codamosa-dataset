

# Generated at 2022-06-26 01:52:21.276081
# Unit test for function is_credit_card
def test_is_credit_card():
    print('Testing is_credit_card')

    # Test case 0
    print('\tTest case 0')
    card_type_0 = 'VISA'
    input_string_0 = ''
    str_0 = is_credit_card(input_string_0, card_type_0)


# Generated at 2022-06-26 01:52:29.050444
# Unit test for function is_email
def test_is_email():
    assert is_email('a.b@c.com') == True
    assert is_email('a.b@c.c') == True
    assert is_email('a.b@c.c') == True
    assert is_email('a..b@c.c') == False
    assert is_email('.a@c.c') == False
    assert is_email('a@c.com') == True
    assert is_email('a@c...com') == False
    assert is_email('a@c.c') == True
    assert is_email('a@c.c') == True
    assert is_email('a@c.c') == True
    assert is_email('a@c.c') == True
    assert is_email('a@c.c') == True

# Generated at 2022-06-26 01:52:41.949195
# Unit test for function is_url
def test_is_url():
    # Test for case 0
    float_0 = None
    allowed_schemes_0 = None
    bool_0 = is_url(float_0, allowed_schemes_0)

    # Test for case 1
    str_1 = 'scenario1'
    allowed_schemes_1 = ['http', 'https']
    bool_1 = is_url(str_1, allowed_schemes_1)

    # Test for case 2
    str_2 = 'scenario2'
    allowed_schemes_2 = ['http', 'https']
    bool_2 = is_url(str_2, allowed_schemes_2)

    # Test for case 3
    str_3 = 'scenario3'
    bool_3 = is_url(str_3)

    # Test for case 4
   

# Generated at 2022-06-26 01:52:53.739331
# Unit test for function is_email
def test_is_email():
    input_string0 = 'a'
    input_string1 = 'a@a'
    input_string2 = 'a@a.a'
    input_string3 = 'a@a.a.a'
    input_string4 = 'a@a.a.a.a'
    input_string5 = 'a@a.a.a.a.a'
    input_string6 = 'a@a.a.a.a.a.a'
    input_string7 = 'a@a.a.a.a.a.a.a'
    input_string8 = 'a@a.a.a.a.a.a.a.a'
    input_string9 = 'a@a.a.a.a.a.a.a.a.a'

# Generated at 2022-06-26 01:53:01.504108
# Unit test for function is_ip_v4
def test_is_ip_v4():
    # test case 0
    input_string_0 = None
    assert is_ip_v4(input_string_0) == False, "Test 0 Failed for Function is_ip_v4"
    #print("Test 0 Passed for Function is_ip_v4")
    # test case 1
    input_string_1 = ""
    assert is_ip_v4(input_string_1) == False, "Test 1 Failed for Function is_ip_v4"
    #print("Test 1 Passed for Function is_ip_v4")
    # test case 2
    input_string_2 = "255.200.100.75"
    assert is_ip_v4(input_string_2) == True, "Test 2 Failed for Function is_ip_v4"
    #print("Test 2 Passed for Function is_ip_v4")

# Generated at 2022-06-26 01:53:10.582132
# Unit test for function is_json
def test_is_json():
    float_0 = None
    bool_0 = is_json(float_0)
    # print(bool_0)
    float_0 = '{"name": "Peter"}'
    bool_0 = is_json(float_0)
    # print(bool_0)
    bool_0 = is_json('{nope}')
    # print(bool_0)
    bool_0 = is_json([1, 2, 3])
    # print(bool_0)
    bool_0 = is_json('[1, 2, 3]')
    # print(bool_0)



# Generated at 2022-06-26 01:53:15.330257
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert True == __ISBNChecker('9787208094882').is_isbn_10()
    assert True != __ISBNChecker('9787208094882').is_isbn_10()
    assert True != __ISBNChecker('9787208094882').is_isbn_10()
    assert True != __ISBNChecker('9787208094882').is_isbn_10()
    # TODO: implement more tests


# Generated at 2022-06-26 01:53:16.668077
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') == True
    assert is_isbn('1506715214') == True


# Generated at 2022-06-26 01:53:27.783602
# Unit test for function is_json
def test_is_json():
    float_1 = -3.32
    float_2 = 3.2E+28
    float_3 = float("1e-06")
    float_4 = float("inf")

    str_0 = ""
    str_1 = "abc"
    str_2 = "abc@def.com"
    str_3 = "abc@gmail.com"
    str_4 = "abc!def"
    str_5 = "http://www.google.com"
    str_6 = "https://www.google.com"
    str_7 = "Fred"
    str_8 = "True"
    str_9 = "1"
    str_10 = "3.2"
    str_11 = None
    str_12 = "[1, 2, 3]"

# Generated at 2022-06-26 01:53:38.147509
# Unit test for function is_json
def test_is_json():
    json_0 = '{}'
    json_1 = '[1, 2, 3]'
    json_2 = '{nope}'
    json_3 = ''
    json_4 = None

    json_5 = ''
    json_6 = '{"name": "Peter"}'
    json_7 = '{{}}'

    bool_0 = is_json(json_0)
    bool_1 = is_json(json_1)
    bool_2 = is_json(json_2)
    bool_3 = is_json(json_3)
    bool_4 = is_json(json_4)
    bool_5 = is_json(json_5)
    bool_6 = is_json(json_6)
    bool_7 = is_json(json_7)



# Generated at 2022-06-26 01:53:45.177969
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    float_0 = __ISBNChecker("921/10-X")
    bool_0 = float_0.is_isbn_13()


# Generated at 2022-06-26 01:53:51.317317
# Unit test for function is_ip_v4
def test_is_ip_v4():
    # expected_return_value = None

    # testing actual return value vs expected return value
    # assert expected_return_value == is_ip_v4('192.168.0.1')

    # testing if function throws expected exceptions
    is_ip_v4('192.168.0.1')

    return



# Generated at 2022-06-26 01:54:03.450208
# Unit test for function is_ip
def test_is_ip():
    # Case 0
    input_string = "127.1.1.1"
    assert(is_ip(input_string) == True)
    # Case 1
    input_string = "127.1.1."
    assert(is_ip(input_string) == False)
    # Case 2
    input_string = "127.1.1.a"
    assert(is_ip(input_string) == False)
    # Case 3
    input_string = "127.1.1.1"
    assert(is_ip(input_string) == True)
    # Case 4
    input_string = "2001:db8:85a3:0000:0000:8a2e:370:7334"
    assert(is_ip(input_string) == True)
    # Case 5

# Generated at 2022-06-26 01:54:06.035123
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
  float_0 = 0
  __ISBNChecker_instance0 = __ISBNChecker("test_value")
  bool_0 = __ISBNChecker_instance0.is_isbn_10()


# Generated at 2022-06-26 01:54:14.229835
# Unit test for function is_email
def test_is_email():
    email = "abc@abc.abc"
    assert is_email(email)
    email = "1@abc.abc"
    assert is_email(email)
    email = "a.b@abc.abc"
    assert is_email(email)
    email = "a.b.c@abc.abc"
    assert is_email(email)
    email = "a.123@abc.abc"
    assert is_email(email)
    email = "a.a.a.a.a@abc.abc"
    assert is_email(email)
    email = "abc@abc.abc"
    assert is_email(email)
    email = "abc@12.a"
    assert is_email(email)
    email = "abc@12."
    assert is_email(email)

# Generated at 2022-06-26 01:54:16.794336
# Unit test for function is_url
def test_is_url():
    string_0 = "http://www.google.com"
    bool_0 = is_url(string_0)

###
# is_url
###

# Generated at 2022-06-26 01:54:23.362112
# Unit test for function is_email
def test_is_email():
    assert(is_email("my.email@the-provider.com"))
    assert(not is_email("@gmail.com"))
    assert(not is_email(None))
    assert(not is_email(". email@the-provider.com"))

    assert(not is_email("my.emailthe-provider.com"))
    assert(not is_email("my.email@the-providercom"))
    assert(not is_email("my.email@the-provider"))
    assert(not is_email("my.email%com"))
    assert(not is_email("my.email%com@gmail.com"))
    assert(not is_email("my.email%com@gmail"))


# Generated at 2022-06-26 01:54:27.670048
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    float_0 = 2.3
    __ISBNChecker_0 = __ISBNChecker(float_0)
    float_1 = 2.3
    bool_0 = __ISBNChecker_is_isbn_10(__ISBNChecker_0, float_1)


# Generated at 2022-06-26 01:54:42.856088
# Unit test for function is_email
def test_is_email():
    a = is_email('asd@asd.com')
    assert a == True
    b = is_email('@cs.com')
    assert b == False
    #c = is_email(float_0)
    #assert c == False
    d = is_email('asd@@@asd.com')
    assert d == False
    e = is_email('asd.asd.com')
    assert e == False
    f = is_email('asd@.com')
    assert f == False
    g = is_email('asd@com')
    assert g == False
    h = is_email('asd@asd@.com')
    assert h == False
    i = is_email('asd@asd@com')
    assert i == False

# Generated at 2022-06-26 01:54:54.838217
# Unit test for function is_ip
def test_is_ip():
    x_ip = [':1.1','0:0:0:0:0:0:0:0:1','0:0:0:0:0:0:0:1','0:0:0:0:0:0:0:02','256.1.1.1','1.256.1.1','1.1.256.1','1.1.1.256','1.1.1.1.1','.1.1.1.1','1.1.1.','1.1..1','1.1.1.1.1.1','1..1.1.1.','1.1.1.1.1.']

# Generated at 2022-06-26 01:55:10.883147
# Unit test for function is_email
def test_is_email():
    assert is_email("bill.gates@microsoft.com") == True
    assert is_email("b@aol.com") == True
    assert is_email("b.a@aol.com") == True
    assert is_email("bill.gates@domain-of-length.123") == True
    assert is_email("bill.gates@b-a-z-a-r.com") == True
    assert is_email("bill.gates@microsoft") == True
    assert is_email("bill.gate!s@microsoft.com") == False
    assert is_email("bill.gates@micro-soft.com") == True
    assert is_email("bill.gates@microsoft.123") == True
    assert is_email("bill.gates@microsoft.a") == True

# Generated at 2022-06-26 01:55:23.235564
# Unit test for function is_ip_v4
def test_is_ip_v4():
    str_0 = "255.200.100.75"
    str_1 = "nope"
    str_2 = "255.200.100.999"
    str_3 = str()
    str_4 = None

    # Asserts that the result of calling is_ip_v4 with arguments "255.200.100.75" is True
    assert is_ip_v4(str_0) == True

    # Asserts that the result of calling is_ip_v4 with arguments "nope" is False
    assert is_ip_v4(str_1) == False

    # Asserts that the result of calling is_ip_v4 with arguments "255.200.100.999" is False
    assert is_ip_v4(str_2) == False

    # Asserts that the result of calling is

# Generated at 2022-06-26 01:55:24.354092
# Unit test for function is_url
def test_is_url():
    a = is_url("https://mysite.com")
    b = is_url("Invalid.url")


# Generated at 2022-06-26 01:55:29.009475
# Unit test for function is_url
def test_is_url():
    url_0 = "ftp://okea.com"
    bool_0 = is_url(url_0)
    assert bool_0
    url_1 = "www.okea.com"
    bool_1 = is_url(url_1)
    assert bool_1
    url_2 = "www.okea.com"
    bool_2 = is_url(url_2)
    assert bool_2


# Generated at 2022-06-26 01:55:34.314090
# Unit test for function is_email
def test_is_email():
    str_1 = "my.email@the-provider.com"
    bool_0 = is_email(str_1)
    #assert bool_0 == True
    str_2 = "@gmail.com"
    bool_1 = is_email(str_2)
    #assert bool_1 == False


# Generated at 2022-06-26 01:55:42.129095
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    string_0 = "464"
    boolean_0 = __ISBNChecker(string_0, True).is_isbn_10()
    assert boolean_0 == False

    string_1 = "464"
    boolean_1 = __ISBNChecker(string_1).is_isbn_10()
    assert boolean_1 == False

    string_2 = "464"
    boolean_2 = __ISBNChecker(string_2).is_isbn_10()
    assert boolean_2 == False


# Generated at 2022-06-26 01:55:44.260686
# Unit test for function is_url
def test_is_url():
    str_0 = None
    bool_0 = is_url(str_0)


# Generated at 2022-06-26 01:55:53.653202
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('9786759034106').is_isbn_13() is True
    assert __ISBNChecker('9786759034107').is_isbn_13() is False
    assert __ISBNChecker('978675903410').is_isbn_13() is False
    assert __ISBNChecker('97867590341061').is_isbn_13() is False
    assert __ISBNChecker('9786759034106a').is_isbn_13() is False
    assert __ISBNChecker('9786759034106 ').is_isbn_13() is False
    assert __ISBNChecker('').is_isbn_13() is False
    assert __ISBNChecker(None).is_isbn_13() is False


# Generated at 2022-06-26 01:56:01.088685
# Unit test for function is_url
def test_is_url():
    assert(is_url('http://www.mysite.com'))
    assert(is_url('https://mysite.com'))
    assert(not is_url('.mysite.com'))
    assert(is_url('https://mysite.com', allowed_schemes=['https']))
    assert(not is_url('mysite.com', allowed_schemes=['https']))


# Generated at 2022-06-26 01:56:04.639467
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') == True
    assert is_url('https://mysite.com') == True
    assert is_url('.mysite.com') == False


# Generated at 2022-06-26 01:56:15.931457
# Unit test for function is_email
def test_is_email():
    # Test cases where input_string is not a string
    bool_0 = is_email(float(1))
    bool_1 = is_email(int(1))
    bool_2 = is_email(dict())
    bool_3 = is_email(tuple())
    bool_4 = is_email(list())

    # Test cases where input_string is a string
    bool_5 = is_email(str())
    bool_6 = is_email(str('none'))
    bool_7 = is_email(str('me@ufl.edu'))
    bool_8 = is_email(str('me@cs.ufl.edu'))
    bool_9 = is_email(str('me@cs.ufl.edu.edu'))

# Generated at 2022-06-26 01:56:26.937576
# Unit test for function is_email
def test_is_email():
    INPUT_0 = 'wdodiio@gmail.com'
    EXPECTED_0 = True
    OUTPUT_0 = is_email(INPUT_0)
    assert EXPECTED_0 == OUTPUT_0

    INPUT_1 = 'xyz.abc@host.com'
    EXPECTED_1 = True
    OUTPUT_1 = is_email(INPUT_1)
    assert EXPECTED_1 == OUTPUT_1

    INPUT_2 = 'not_valid@.com'
    EXPECTED_2 = False
    OUTPUT_2 = is_email(INPUT_2)
    assert EXPECTED_2 == OUTPUT_2

    INPUT_3 = 'very.common@example.com'
    EXPECTED_3 = True

# Generated at 2022-06-26 01:56:30.445913
# Unit test for function is_ip_v4
def test_is_ip_v4():
    str_0 = "4.4.4.4"
    bool_0 = is_ip_v4(str_0)
    print(bool_0)
    return


# Generated at 2022-06-26 01:56:35.714164
# Unit test for function is_ip_v4
def test_is_ip_v4():
    # Test case 0
    input_string_0 = ""
    bool_0 = is_ip_v4(input_string_0)
    # Test case 1
    #input_string_1 = "255.200.100.75"
    #bool_1 = is_ip_v4(input_string_1)
    test_case_0()


# Generated at 2022-06-26 01:56:37.603336
# Unit test for function is_email
def test_is_email():
    assert is_email("abc@gmail.com")
    assert not is_email("abcgmail.com")
    

# Generated at 2022-06-26 01:56:39.531458
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False


# Generated at 2022-06-26 01:56:43.136343
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    instance___ISBNChecker_is_isbn_13 = __ISBNChecker('1234')
    bool_0 = instance___ISBNChecker_is_isbn_13.is_isbn_13()


# Generated at 2022-06-26 01:56:54.948804
# Unit test for function is_email
def test_is_email():
    assert not is_email('a@b.com')
    assert not is_email('a@b.com')
    assert not is_email('a@b.com')
    assert not is_email('a@b.com')
    assert not is_email('a@b.com')
    assert not is_email('a@b.com')
    assert not is_email('a@b.com')
    assert not is_email('a@b.com')
    assert not is_email('a@b.com')
    assert not is_email('a@b.com')
    assert not is_email('a@b.com')
    assert not is_email('a@b.com')
    assert not is_email('a@b.com')
    assert not is_email('a@b.com')    

# Generated at 2022-06-26 01:56:57.428188
# Unit test for function is_json
def test_is_json():
    str_0 = 'abcabcabcabcabc'
    bool_0 = is_json(str_0)


# Generated at 2022-06-26 01:57:02.468942
# Unit test for function is_ip_v4
def test_is_ip_v4():
    # Test 1
    assert is_ip_v4('255.200.100.75') == True

    # Test 2
    assert is_ip_v4('nope') == False

    # Test 3
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-26 01:57:15.181714
# Unit test for function is_email
def test_is_email():
    email_0 = "ta@sfu.ca"
    email_1 = "ta_sfu.ca"
    email_2 = ""
    email_3 = "ta@sfu"
    email_4 = ".ta@sfu.ca"
    
    bool_0 = is_email(email_0)
    bool_1 = is_email(email_1)
    bool_2 = is_email(email_2)
    bool_3 = is_email(email_3)
    bool_4 = is_email(email_4)


# Generated at 2022-06-26 01:57:24.008364
# Unit test for function is_email
def test_is_email():
    print("Testing is_email()")

    email_0 = "john.doe@gmail.com"
    bool_0 = is_email(email_0)

    # Test number of arguments
    # TypeError: is_email() takes 1 positional argument but 2 were given
    # bool_1 = is_email(email_0, "com")

    float_0 = None
    # is_email() argument must be str, not float
    # bool_2 = is_email(float_0)

    print("End of testing is_email()")


# Generated at 2022-06-26 01:57:30.162982
# Unit test for function is_email
def test_is_email():
    # AssertionError: False is not true : expected True but got False.
    str_0 = "gjfqfiuvqg@gmail.com"
    bool_0 = is_email(str_0)
    assert bool_0


# Generated at 2022-06-26 01:57:34.351398
# Unit test for function is_email
def test_is_email():
    email_0 = 'myemail@gmail.com'
    bool_0 = is_email(email_0)

    email_1 = ''
    bool_1 = is_email(email_1)

    email_2 = 'hello.msg'
    bool_2 = is_email(email_2)

    email_3 = 'hello'
    bool_3 = is_email(email_3)

    email_4 = '@'
    bool_4 = is_email(email_4)

    email_5 = None
    bool_5 = is_email(email_5)

    email_6 = 'hello@'
    bool_6 = is_email(email_6)

    email_7 = 'hello@hello.com'
    bool_7 = is_email(email_7)


# Generated at 2022-06-26 01:57:40.365526
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    float_0 = None
    str_0 = 'h0(0cr:d;L=T.WzI$+@nXJN'
    bool_0 = __ISBNChecker(str_0).is_isbn_10()


# Generated at 2022-06-26 01:57:52.138843
# Unit test for function is_email
def test_is_email():
    if is_email(None):
        raise ValueError('Should be false')
    if is_email(''):
        raise ValueError('Should be false')
    if is_email(' '):
        raise ValueError('Should be false')

    if not is_email('my.email@the-provider.com'):
        raise ValueError('Should be true')
    if is_email('@gmail.com'):
        raise ValueError('Should be false')



# Generated at 2022-06-26 01:58:01.180393
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('"my\\"email"@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True


# Generated at 2022-06-26 01:58:12.438772
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert True == is_ip_v4('255.255.255.255')
    assert False == is_ip_v4('255.255.255.256')
    assert False == is_ip_v4('256.255.255.255')
    assert False == is_ip_v4('255.256.255.255')
    assert False == is_ip_v4('255.255.256.255')
    assert False == is_ip_v4('255.255.255.256')



# Generated at 2022-06-26 01:58:23.999535
# Unit test for function is_email
def test_is_email():
    assert not is_email('')  # noqa: E712
    assert not is_email(" ")  # noqa: E712
    assert not is_email("!@kth.se")  # noqa: E712
    assert is_email("stud2.se@kth.se")  # noqa: E712
    assert is_email("\"kalle anka\"@kth.se")  # noqa: E712
    assert is_email("name.lastname.@kth.se")  # noqa: E712
    assert is_email("name.lastname@kth.se")  # noqa: E712
    assert is_email("name.lastname.test@kth.se")  # noqa: E712
    assert is_email("name lastname@kth.se")  # no

# Generated at 2022-06-26 01:58:29.396845
# Unit test for function is_credit_card

# Generated at 2022-06-26 01:58:37.065743
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    __ISBNChecker_instance = __ISBNChecker('979-10-95539-00-4')
    result = __ISBNChecker_instance.is_isbn_13()
    assert result == True


# Generated at 2022-06-26 01:58:48.293216
# Unit test for function is_email
def test_is_email():
    # Functionality test
    assert is_email('testemail') == False
    assert is_email('test@email.com') == True
    assert is_email('test@email.com.ca') == True
    assert is_email('test@email.com.ca.us') == True
    assert is_email('1test@email.com.ca.us') == True
    assert is_email('1test@email.com.ca.us') == True
    assert is_email('tes.t@email.com.ca.us') == True
    assert is_email('tes.t@email.123.ca.us') == True
    assert is_email('tes.t@email.ca.us') == True
    assert is_email('testemail.com') == False

    # Edge and Corner case test

# Generated at 2022-06-26 01:58:58.717086
# Unit test for function is_credit_card
def test_is_credit_card():
    print('Test #1')
    float_0 = None
    assert(is_credit_card(float_0) == False)
    print('Test #2')
    str_0 = ';6.3&6:2;6N$06N@D'
    assert(is_credit_card(str_0) == False)
    print('Test #3')
    str_0 = ';6.3&6:2;6`$06N@D'
    assert(is_credit_card(str_0) == False)
    print('Test #4')
    str_0 = ';6.3&6:2;6`$06N@D'
    assert(is_credit_card(str_0, 'AMERICAN_EXPRESS') == False)
    print('Test #5')
    str_0

# Generated at 2022-06-26 01:59:07.948449
# Unit test for function is_credit_card
def test_is_credit_card():
    VISA = '4111111111111111'
    MASTERCARD = '5500000000000004'
    AMERICAN_EXPRESS = '340000000000009'
    DINERS_CLUB = '30000000000004'
    DISCOVER = '6011000000000004'
    JCB = '3088000000000009'
    assert is_credit_card(VISA, card_type='VISA') == True
    assert is_credit_card(MASTERCARD, card_type='MASTERCARD') == True
    assert is_credit_card(AMERICAN_EXPRESS, card_type='AMERICAN_EXPRESS') == True
    assert is_credit_card(DINERS_CLUB, card_type='DINERS_CLUB') == True

# Generated at 2022-06-26 01:59:10.768910
# Unit test for function is_email
def test_is_email():
    str_0 = None
    bool_0 = is_email(str_0)


# Generated at 2022-06-26 01:59:14.940300
# Unit test for function is_json
def test_is_json():
    dict_0 = {'a': 'b'}
    str_0 = str(dict_0)
    bool_0 = is_json(str_0)
    if bool_0:
        raise Exception('Bad garbage!')


# Generated at 2022-06-26 01:59:25.185355
# Unit test for function is_credit_card
def test_is_credit_card():
    # Tests for function is_credit_card
    assert is_credit_card('4388576018402625')
    assert is_credit_card('4388576018402625', 'VISA')
    assert is_credit_card('5454545454545454')
    assert is_credit_card('5454545454545454', 'MASTERCARD')
    assert is_credit_card('371449635398431')
    assert is_credit_card('371449635398431', 'AMERICAN_EXPRESS')
    assert is_credit_card('30569309025904')
    assert is_credit_card('30569309025904', 'DINERS_CLUB')
    assert is_credit_card('6011000990139424')

# Generated at 2022-06-26 01:59:35.629208
# Unit test for function is_ip_v4

# Generated at 2022-06-26 01:59:45.856987
# Unit test for function is_json
def test_is_json():
   assert is_json('{"name": "Peter"}') == True
   assert is_json('{"name": "Peter", "age": "23"}') == True
   assert is_json('{"name": "Peter", "age": "23"}') == True
   assert is_json('[1, 2, 3]') == True
   assert is_json('{nope}') == False
   assert is_json(None) == False
   assert is_json(float('inf')) == False
   assert is_json(1.0/0.0) == False
   assert is_json(float('nan')) == False
   assert is_json(float('NaN')) == False
   assert test_case_0() is None
   assert is_json(1) == False
   assert is_json('string') == False
   assert is_

# Generated at 2022-06-26 01:59:56.333977
# Unit test for function is_json
def test_is_json():
    str_0 = '{"name": "Peter"}'
    result_0 = is_json(str_0)
    str_1 = '[1, 2, 3]'
    result_1 = is_json(str_1)
    str_2 = '{nope}'
    result_2 = is_json(str_2)
    print(f"is_json('{str_0}') -> {result_0}")
    print(f"is_json('{str_1}') -> {result_1}")
    print(f"is_json('{str_2}') -> {result_2}")


# Generated at 2022-06-26 02:00:04.305171
# Unit test for function is_json
def test_is_json():
    print("\n\n##########\nRunning tests for function is_json")
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()


# Generated at 2022-06-26 02:00:07.551216
# Unit test for function is_email
def test_is_email():
	assert(is_email("abc@abc.com")==True)
	assert(is_email("abc@abc")==False)



# Generated at 2022-06-26 02:00:11.549150
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    float_0 = None
    bool_0 = __ISBNChecker(float_0, True)
    bool_1 = bool_0.is_isbn_10()
    bool_2 = bool_0.is_isbn_10()


# Generated at 2022-06-26 02:00:15.320950
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    isbn_0 = __ISBNChecker('x')
    isbn_0.is_isbn_13()


# Generated at 2022-06-26 02:00:24.125078
# Unit test for function is_email
def test_is_email():
    assert is_email("my.email@gmail.com") == True
    assert is_email("my.email@gmail.com") != False
    assert is_email("my.email.@gmail.com") == False
    assert is_email("my.email.@gmail.com") != True
    assert is_email("my..email.@gmail.com") == False
    assert is_email("my..email.@gmail.com") != True
    assert is_email("my.email@gmail.com.com") == True
    assert is_email("my.email@gmail.com.com") != False
    assert is_email("my.email@gmail.com.com.com") == True
    assert is_email("my.email@gmail.com.com.com") != False

# Generated at 2022-06-26 02:00:29.870760
# Unit test for function is_json
def test_is_json():
    str_1 = '{"name": "Peter"}'
    str_2 = '[1, 2, 3]'
    str_3 = '{nope}'
    assert is_json(str_1) == True
    assert is_json(str_2) == True
    assert is_json(str_3) == False


# Generated at 2022-06-26 02:00:42.108926
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert False == __ISBNChecker('978-0-596-52068-7').is_isbn_13()
    assert False == __ISBNChecker('978-0-596-52068-7').is_isbn_13()
    assert False == __ISBNChecker('978-0-596-52068-7').is_isbn_13()
    assert False == __ISBNChecker('978-0-596-52068-7').is_isbn_13()
    assert False == __ISBNChecker('978-0-596-52068-7').is_isbn_13()
    assert False == __ISBNChecker('978-0-596-52068-7').is_isbn_13()
    assert False == __ISBNChecker('978-0-596-52068-7').is_isbn

# Generated at 2022-06-26 02:00:44.945095
# Unit test for function is_json
def test_is_json():
    test_str_0 = '{"name": "Peter"}'
    bool_0 = is_json(test_str_0)

#

# Generated at 2022-06-26 02:00:47.853982
# Unit test for function is_email
def test_is_email():
    str_0 = "test@gmail.com"
    bool_0 = is_email(str_0)
    return bool_0



# Generated at 2022-06-26 02:00:54.407073
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker("") is False, 'Expected __ISBNChecker("") is False'
    assert __ISBNChecker(" ") is False, 'Expected __ISBNChecker(" ") is False'
    assert __ISBNChecker("") is False, 'Expected __ISBNChecker("") is False'
    assert __ISBNChecker(" ") is False, 'Expected __ISBNChecker(" ") is False'
    assert __ISBNChecker("") is False, 'Expected __ISBNChecker("") is False'
    assert __ISBNChecker(" ") is False, 'Expected __ISBNChecker(" ") is False'
    assert __ISBNChecker("") is False, 'Expected __ISBNChecker("") is False'

# Generated at 2022-06-26 02:01:09.138471
# Unit test for function is_json
def test_is_json():
    assert not is_json(None)
    assert not is_json(0)
    assert not is_json(0.0)
    assert not is_json(0.0)
    assert not is_json(())
    assert not is_json([])
    assert not is_json({})
    assert not is_json('{')
    assert not is_json('}')
    assert not is_json('[')
    assert not is_json(']')
    assert is_json('{}')
    assert is_json('[]')
    assert is_json('{"a":1,"b":2}')
    assert is_json('[1,2,3]')
    assert not is_json('[1,null,3]')
    assert is_json('""')
    assert is_json('0')

# Generated at 2022-06-26 02:01:14.391079
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    # Create instance with arguments
    float_0 = None
    __isbn_checker_0 = __ISBNChecker(float_0)
    # Assign parameters as needed
    int_0 = 0
    # Call method with arguments
    __isbn_checker_0.is_isbn_13(*[int_0])


# Generated at 2022-06-26 02:01:18.201388
# Unit test for function is_email
def test_is_email():
	# input_string is not a string
	bool_0 = is_email(3)
	# input_string is a string, but not an email
	bool_1 = is_email("")
	# input_string is an email
	bool_2 = is_email("hello")
	assert bool_2 == False
	

# Generated at 2022-06-26 02:01:27.949017
# Unit test for function is_email
def test_is_email():
    # invalid email 1
    email_1 = ''
    assert is_email(email_1) == False

    # invalid email 2
    email_2 = None
    assert is_email(email_2) == False

    # invalid email 3
    email_3 = 'abc@abc'
    assert is_email(email_3) == False

    # invalid email 4
    email_4 = 'abc@'
    assert is_email(email_4) == False

    # invalid email 5
    email_5 = '@abc'
    assert is_email(email_5) == False

    # invalid email 6
    email_6 = 'abc@abc.'
    assert is_email(email_6) == False

    # invalid email 7
    email_7 = 'abc@.abc'

# Generated at 2022-06-26 02:01:31.459235
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    isbn_checker = __ISBNChecker('0439708184')
    bool_0 = isbn_checker.is_isbn_10()
    assert bool_0 == True


# Generated at 2022-06-26 02:01:33.891110
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    return


# Generated at 2022-06-26 02:01:40.434939
# Unit test for function is_ip_v4
def test_is_ip_v4():
    print(is_ip_v4('127.0.0.1'))  # True
    print(is_ip_v4('256.10.234.4'))  # False
    print(is_ip_v4('127.0.0.f'))  # False
    print(is_ip_v4('127.0.0.1.1'))  # False
    print(is_ip_v4(120.12))  # False

# Generated at 2022-06-26 02:01:55.161799
# Unit test for function is_json
def test_is_json():
    # original_json = {"name":"Peter"}
    assert is_json('{"name": "Peter"}') == True, "Error: is_json('{\"name\": \"Peter\"}') != True"
    # original_json = {"name":"Peter", "age":35}
    assert is_json('{"name": "Peter", "age": 35}') == True, "Error: is_json('{\"name\": \"Peter\", \"age\": 35}') != True"
    # original_json = {"name":"Peter", "age":35, "wife":"Sara"}
    assert is_json('{"name": "Peter", "age": 35, "wife": "Sara"}') == True, "Error: is_json('{\"name\": \"Peter\", \"age\": 35, \"wife\": \"Sara\"}') != True"
    # original_json =

# Generated at 2022-06-26 02:01:57.518421
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    float_0 = None
    bool_0 = __ISBNChecker(float_0).is_isbn_10()