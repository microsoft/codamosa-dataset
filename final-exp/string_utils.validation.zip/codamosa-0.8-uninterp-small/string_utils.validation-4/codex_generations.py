

# Generated at 2022-06-26 01:52:31.157401
# Unit test for function is_credit_card
def test_is_credit_card():
    if not is_credit_card('4916603231464963'):
        raise RuntimeError('Test failed 1')
    
    if not is_credit_card('4916-6032-3146-4963'):
        raise RuntimeError('Test failed 2')
    
    if not is_credit_card('4916603231464963', 'VISA'):
        raise RuntimeError('Test failed 3')
    
    if not is_credit_card('5301250070000191', 'MASTERCARD'):
        raise RuntimeError('Test failed 4')
    
    if not is_credit_card('378282246310005', 'AMERICAN_EXPRESS'):
        raise RuntimeError('Test failed 5')
    

# Generated at 2022-06-26 01:52:44.110271
# Unit test for function is_email
def test_is_email():
    str_0 = '@gmail.com'
    bool_0 = is_email(str_0)
    assert (not bool_0)
    str_1 = 'my.email@the-provider.com'
    bool_1 = is_email(str_1)
    assert (bool_1)
    str_2 = 'hello_crazy@world.fr'
    bool_2 = is_email(str_2)
    assert (bool_2)
    str_3 = 'hello_CRZ@world.fr'
    bool_3 = is_email(str_3)
    assert (bool_3)
    str_4 = 'hello_crazy@world.fr'
    bool_4 = is_email(str_4)
    assert (bool_4)
    
    
    

# Generated at 2022-06-26 01:52:45.668136
# Unit test for function is_json
def test_is_json():
    result = is_json('{ nope }')
    expected = False
    assert result == expected


# Generated at 2022-06-26 01:52:47.439505
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert test_case_0()

if __name__ == '__main__':
    test_is_ip_v4()

# Generated at 2022-06-26 01:52:59.145471
# Unit test for function is_email
def test_is_email():
    test_cases = [
        ('my.email@the-provider.com', True),
        ('@gmail.com', False),
        ('this.is.not.an.email', False),
        ('my.email@the-provider.317', False),
        ('my.email@the-provider.c', True),
        ('my.email@the-provider.com@', False),
        ('my.email@the-provider.com@anotherprovider.com', False),
        ('my.email@the-provider.com.', False),
        ('my.email@the-provider.com.thereisastringafter', False)
    ]
    for test_case in test_cases:
        assert(is_email(test_case[0]) == test_case[1])


# Generated at 2022-06-26 01:53:02.650793
# Unit test for function is_ip_v4
def test_is_ip_v4():
    str_1 = '255.255.255.255'
    bool_1 = is_ip_v4(str_1)


# Generated at 2022-06-26 01:53:13.610120
# Unit test for function is_email
def test_is_email():
    # Test sample from documentation
    email_0 = 'my.email@the-provider.com'
    assert is_email(email_0)
    # Test for empty string
    email_1 = ''
    assert not is_email(email_1)
    # Test for symbol only string
    email_2 = '@'
    assert not is_email(email_2)
    # Test for string with space
    email_3 = 'my.email@the provider.com'
    assert not is_email(email_3)
    # Test for string with dot at start
    email_4 = '.my.email@the-provider.com'
    assert not is_email(email_4)
    # Test for string with ".." in head
    email_5 = 'my..email@the-provider.com'

# Generated at 2022-06-26 01:53:19.043840
# Unit test for function is_email
def test_is_email():
    assert is_email('a@a.com')
    assert is_email('a.a@a.com')
    assert is_email('"a a"@a.com')
    assert is_email('a\a@a.com')
    assert is_email('a-a@a.com')
    assert not is_email('a')
    assert not is_email('a@')
    assert not is_email('@a')
    assert not is_email('a@a')
    assert not is_email('a@a.c')
    assert not is_email('a a@a.com')
    assert not is_email('a"a"@a.com')
    assert not is_email('a\\a@a.com')
    assert not is_email('a\\@a.com')

# Generated at 2022-06-26 01:53:30.365084
# Unit test for function is_email
def test_is_email():
    # Valid inputs
    assert(is_email('') == False)
    assert(is_email('at@gmail.com') == False)
    assert(is_email('my.email@the-provider.com') == True)
    assert(is_email('my.email@the-provider.co.uk') == True)
    assert(is_email('my.longer.email@the-provider.com') == True)
    assert(is_email('my&email@the-provider.com') == True)
    assert(is_email('my email@the-provider.com') == True)
    assert(is_email('my\\.email@the-provider.com') == True)

    # Invalid inputs
    assert(is_email('@gmail.com') == False)

# Generated at 2022-06-26 01:53:32.726580
# Unit test for function is_email
def test_is_email():
    str_0 = 'tst@tst.com'
    bool_0 = is_email(str_0)


# Generated at 2022-06-26 01:53:52.448866
# Unit test for function is_isbn
def test_is_isbn():
    '''
    Test values for is_isbn:
    str_0 = '07X>GO'
    str_1 = '9780312498580'
    str_2 = '1506715214'
    bool_0 = is_ip_v4(str_0)
    bool_1 = is_isbn(str_1)
    bool_2 = is_isbn(str_2)
    '''
    # Test method:
    test_case_0()
    # Test code:
    str_0 = '07X>GO'
    str_1 = '9780312498580'
    str_2 = '1506715214'
    bool_0 = is_ip_v4(str_0)
    bool_1 = is_isbn(str_1)

# Generated at 2022-06-26 01:53:53.038817
# Unit test for function is_ip_v4
def test_is_ip_v4():
    test_case_0()


# Generated at 2022-06-26 01:54:04.522723
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    str_0 = '9780471486480'
    str_1 = '978-0-471-48648-0'
    str_2 = '978 0 471 48648 0'
    str_3 = '978-0-471-48648-1'
    str_4 = '978-0-471-48648-5'
    str_5 = '978047148648'
    str_6 = '97804714864811'
    str_7 = '97804714864815'
    str_8 = '97804714864816'
    str_9 = '97804714864818'

    checker = __ISBNChecker(str_0)
    str_0_is_isbn_13 = checker.is_isbn_13()

    checker = __ISBNChecker

# Generated at 2022-06-26 01:54:14.594336
# Unit test for function is_credit_card
def test_is_credit_card():
    str_0 = '21A-C4'
    bool_0 = is_credit_card(str_0)
    assert bool_0
    str_1 = 'E4A4A4'
    bool_1 = is_credit_card(str_1)
    assert not bool_1


# Generated at 2022-06-26 01:54:17.663049
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') == True
    assert is_url('https://mysite.com') == True
    assert is_url('.mysite.com') == False



# Generated at 2022-06-26 01:54:28.123514
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580')
    assert is_isbn('1506715214')
    assert not is_isbn('978-0312498580')
    assert is_isbn('978-0312498580', normalize=False)
    assert not is_isbn('150-6715214')
    assert is_isbn('150-6715214', normalize=False)
    assert not is_isbn('978-0312498580', normalize=True)
    assert is_isbn('978-0312498580', normalize=True)
    assert not is_isbn('150-6715214')
    assert is_isbn('150-6715214', normalize=False)
    assert not is_isbn('A$0')

# Generated at 2022-06-26 01:54:32.486409
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    book1 = __ISBNChecker('0306406152')
    print(book1.is_isbn_10())
    book2 = __ISBNChecker('123456789x')
    print(book2.is_isbn_10())
    book3 = __ISBNChecker('123456789')
    print(book3.is_isbn_10())


# Generated at 2022-06-26 01:54:38.164467
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    str_0 = '978-1-56619-909-4' 
    isbnChecker_0 = __ISBNChecker(str_0) 
    bool_0 = isbnChecker_0.is_isbn_13() 
    assert bool_0 == True


# Generated at 2022-06-26 01:54:41.445457
# Unit test for function is_email
def test_is_email():
    string_0 = '@gmail.com'
    bool_0 = is_email(string_0)
    assert bool_0 == False


# print(bin(math.nan))

# Generated at 2022-06-26 01:54:44.377288
# Unit test for function is_url
def test_is_url():
    # Test case 1
    str_0 = 'http://www.google.com'
    bool_0 = is_url(str_0)
    return bool_0


# Generated at 2022-06-26 01:54:55.388076
# Unit test for function is_email
def test_is_email():
    email_0 = 'my.email@the-provider.com'
    email_1 = '@gmail.com'
    assert(is_email(email_0))
    assert(not is_email(email_1))



# Generated at 2022-06-26 01:55:04.457497
# Unit test for function is_email
def test_is_email():
    # Test case 0

    #TODO: add is_full_string, so that it checks that the string is also non-empty
    #TODO: add a tolerance parameter that allows to specify the maximum allowed length

    # first simple "pre check": it must be a non empty string with max len 320 and cannot start with a dot
    assert(is_full_string('hello') == True)
    assert(is_full_string(' ') == False)
    assert(is_full_string('') == False)
    assert(is_full_string(''*320) == False)
    assert(is_full_string(' '*320) == False)
    assert(is_full_string(' '*321) == False)

    #TODO: rename input_string to email_string
    #TODO: add more tests
   

# Generated at 2022-06-26 01:55:09.411079
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75') is True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') is True
    assert is_ip('1.2.3') is False
    assert is_ip('') is False



# Generated at 2022-06-26 01:55:13.326638
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999')


# Generated at 2022-06-26 01:55:24.963983
# Unit test for function is_credit_card
def test_is_credit_card():
    # VISA
    assert is_credit_card('4111111111111111')
    assert is_credit_card('4111 1111 1111 1111')
    assert not is_credit_card('41111111111111110')

    # MASTERCARD
    assert is_credit_card('5555555555554444')
    assert is_credit_card('5555 5555 5555 4444')
    assert not is_credit_card('55555555555544440')

    # AMERICAN_EXPRESS
    assert is_credit_card('378282246310005')
    assert is_credit_card('3782 822463 10005')
    assert not is_credit_card('378282246310000')

    # DINERS_CLUB

# Generated at 2022-06-26 01:55:28.782391
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('0-7352-0462-0').is_isbn_13() == False
    assert __ISBNChecker('0735204620').is_isbn_13() == True
    assert __ISBNChecker('0 73520462 0').is_isbn_13() == False


# Generated at 2022-06-26 01:55:41.290927
# Unit test for function is_credit_card
def test_is_credit_card():
    # Test 0 passed
    str_0 = '4929-5100-1144-8997'
    card_type_0 = 'VISA'
    bool_0 = is_credit_card(str_0, card_type_0)
    print(bool_0)

    # Test 1 failed
    str_1 = '507-725-3025'
    card_type_1 = 'VISA'
    bool_1 = is_credit_card(str_1, card_type_1)
    print(bool_1)

    # Test 2 passed
    str_2 = '2293418863'
    card_type_2 = 'AMERICAN_EXPRESS'
    bool_2 = is_credit_card(str_2, card_type_2)
    print(bool_2)


# Generated at 2022-06-26 01:55:48.465168
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('1111222233334444') == True
    assert is_credit_card('C9820E2D9F7C4531') == True
    assert is_credit_card('7FB26E2D9F7C4531') == True
    assert is_credit_card('7FB26G2D9F7C4531') == False
    assert is_credit_card('7FB26G2D9F7C4531', 'visa') == False


# Generated at 2022-06-26 01:55:56.111064
# Unit test for function is_ip
def test_is_ip():

    # Test 1:
    str_0 = '07X>GO'
    bool_0 = is_ip(str_0)

    # Test 2:
    str_0 = '@5V5<5'
    bool_0 = is_ip(str_0)

    # Test 3:
    str_0 = '644'
    bool_0 = is_ip(str_0)

    # Test 4:
    str_0 = '1.2.3'
    bool_0 = is_ip(str_0)

    # Test 5:
    str_0 = '1.2.'
    bool_0 = is_ip(str_0)

    # Test 6:
    str_0 = '255.200.100.75'
    bool_0 = is_ip(str_0)

    # Test 7:

# Generated at 2022-06-26 01:56:08.036157
# Unit test for function is_email
def test_is_email():
    assert not is_email('bogus.email@')
    assert is_email('bogus.email#@bogus.com')
    assert is_email('bogus.email@invalid-domain')
    # Expected: True
    assert is_email('bogus.email@bogus.com')
    assert is_email('bogus.email@bogus.com.')
    assert is_email('bogus.email@[123.123.123.123]')
    assert not is_email('bogus.email@[123.123.123.123')
    assert is_email('bogus.email@bogus.com')
    assert is_email('"bogus.email"@bogus.com')

# Generated at 2022-06-26 01:56:22.769526
# Unit test for function is_json
def test_is_json():
    # Unit test for function is_json
    # Testing for input '{"name": "Peter"}' with expected value true
    print("\nUnit test for function is_json")
    print("Testing for input '{\"name\": \"Peter\"}' with expected value true")
    str_0 = '{"name": "Peter"}'
    bool_0 = is_json(str_0)
    print("Input '{\"name\": \"Peter\"}' has been evaluated to value " + str(bool_0))
    assert bool_0
    # Testing for input '[1, 2, 3]' with expected value true
    print("\nTesting for input '[1, 2, 3]' with expected value true")
    str_0 = '[1, 2, 3]'
    bool_0 = is_json(str_0)

# Generated at 2022-06-26 01:56:34.926611
# Unit test for function is_url
def test_is_url():
    str_0 = 'no url'
    expected_0 = False
    actual_0 = is_url(str_0)

    str_1 = 'http://'
    expected_1 = False
    actual_1 = is_url(str_1)

    str_2 = 'http://www'
    expected_2 = False
    actual_2 = is_url(str_2)

    str_3 = 'http://www.'
    expected_3 = True
    actual_3 = is_url(str_3)

    str_4 = 'http://www.google.com'
    expected_4 = True
    actual_4 = is_url(str_4)

    str_5 = 'https://www.google.com'
    expected_5 = True
    actual_5 = is_url(str_5)

   

# Generated at 2022-06-26 01:56:37.226299
# Unit test for function is_email
def test_is_email():
    str_0 = '"user@domain.com"'
    bool_0 = is_email(str_0)




# Generated at 2022-06-26 01:56:40.900563
# Unit test for function is_url
def test_is_url():
    str_0 = '15.12.16'
    str_1 = '/home/ubuntu/workspace/test.txt'
    bool_0 = is_url(str_0)
    bool_1 = is_url(str_1)
    print(bool_0)
    print(bool_1)


# Generated at 2022-06-26 01:56:52.624535
# Unit test for function is_url
def test_is_url():
    # Test case 0
    str_0 = 'http://www.google.com'
    bool_0 = is_url(str_0)
    assert bool_0

    # Test case 1
    str_1 = ''
    bool_1 = is_url(str_1)
    assert not bool_1

    # Test case 2
    str_2 = 'www.google.com'
    bool_2 = is_url(str_2)
    assert not bool_2

    # Test case 3
    str_3 = 'http://foo.com/blah_blah'
    bool_3 = is_url(str_3)
    assert bool_3

    # Test case 4
    str_4 = 'http://foo.com/blah_blah/'
    bool_4 = is_url(str_4)

# Generated at 2022-06-26 01:57:04.216449
# Unit test for function is_ip_v4
def test_is_ip_v4():
    print('Start test_is_ip_v4.')
    # Create hashmap to store test cases
    test_cases = []
    # Start
    str_0 = '255.200.100.75'
    str_1 = 'nope'
    str_2 = '255.200.100.999'
    # Store in hashmap
    test_cases.append((str_0, True))
    test_cases.append((str_1, False))
    test_cases.append((str_2, False))
    # Test
    for (str_i, bool_target) in test_cases:
        bool_i = is_ip_v4(str_i)
        assert (bool_i is bool_target), "Error of is_ip_v4() with param = {0}.".format(str_i)


# Generated at 2022-06-26 01:57:13.040929
# Unit test for function is_email
def test_is_email():
    #checks is email is valid
    assert is_email('my.email@the-provider.com') == True
    #checks if email is valid but with a space in local part
    assert is_email('my.email @the-provider.com')== False
    #checks if email is valid but with '..' after the local part
    assert is_email('my.email..@the-provider.com') == False
    #checks if email is valid with a space after the local part
    assert is_email('my.email @the-provider.com') == False
    #checks if email is valid with a dot at the end of the local part
    assert is_email('my.email.@the-provider.com') == False
    #checks if email is valid with a dot at the end of the local part

# Generated at 2022-06-26 01:57:25.202464
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') is True
    assert is_email('@gmail.com') is False
    assert is_email('test') is False
    assert is_email('test@') is False
    assert is_email('test@.') is False
    assert is_email('test.@') is False
    assert is_email('t@e@t.it') is False
    assert is_email('test@test.com') is True
    assert is_email('test@a.com') is True
    assert is_email('test@test.test') is True
    assert is_email('test@test.test.test') is True
    assert is_email('test@test.test.test.test') is True
    assert is_email('test@test.test.test.test.test')

# Generated at 2022-06-26 01:57:31.884520
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    try:
        result_1 = __ISBNChecker('877195869x').is_isbn_10()
        print("result_1: {}".format(result_1))
    except InvalidInputError as e:
        print("InvalidInputError: {}".format(e))
    except:
        print("Unknown exception")


# Generated at 2022-06-26 01:57:37.544108
# Unit test for function is_email
def test_is_email():
    input_string_0 = 'pgil@Yale.edu'
    bool_0 = is_email(input_string_0)
    expected_result = True
    assert bool_0 == expected_result



# Generated at 2022-06-26 01:57:42.981052
# Unit test for function is_email
def test_is_email():
    pass



# Generated at 2022-06-26 01:57:46.164589
# Unit test for function is_json
def test_is_json():
    str_0 = '{"name": "Peter"}'
    bool_0 = is_json(str_0)
    print(bool_0)
    str_1 = '[1, 2, 3]'
    bool_1 = is_json(str_1)
    print(bool_1)
    str_2 = '{nope}'
    bool_2 = is_json(str_2)
    print(bool_2)

test_is_json()



# Generated at 2022-06-26 01:57:57.530802
# Unit test for function is_url
def test_is_url():
    input_string = 'https://www.google.com'
    result = is_url(input_string)
    assert result

    input_string = 'https://www.google.com'
    result = is_url(input_string)
    assert result

    input_string = 'https://www.google.com'
    result = is_url(input_string)
    assert result

    input_string = 'https://www.google.com'
    result = is_url(input_string)
    assert result

    input_string = 'https://www.google.com'
    result = is_url(input_string)
    assert result

    input_string = 'https://www.google.com'
    result = is_url(input_string)
    assert result


# Generated at 2022-06-26 01:58:04.209481
# Unit test for function is_json
def test_is_json():
    input_string_0 = '{"name": "Peter"}'
    bool_0 = is_json(input_string_0)
    assert bool_0 == True

    input_string_1 = '[1, 2, 3]'
    bool_1 = is_json(input_string_1)
    assert bool_1 == True

    input_string_2 = '{nope}'
    bool_2 = is_json(input_string_2)
    assert bool_2 == False



# Generated at 2022-06-26 01:58:08.255558
# Unit test for function is_url
def test_is_url():
    url = 'http://www.mywebsite.com'
    allowed_schemes = ['http']
    expected = True
    actual = is_url(url,allowed_schemes)
    assert expected == actual


# Generated at 2022-06-26 01:58:21.172744
# Unit test for function is_json
def test_is_json():
    # This function was copied from stackoverflow
    def is_json(myjson):
        try:
            json_object = json.loads(myjson)
        except ValueError as e:
            return False
        return True

    # This is the case that we expect to return true
    str_0 = '{"name": "Peter"}'
    str_1 = '[1, 2, 3]'
    json_0 = {"name": "Peter"}
    json_1 = [1, 2, 3]

    # this is the case that we expect to return false
    str_2 = '{nope}'
    str_3 = '1234'

    # some corner cases
    bool_0 = is_json(None)
    bool_1 = is_json('')
    bool_2 = is_json(str_0)
   

# Generated at 2022-06-26 01:58:31.417804
# Unit test for function is_email
def test_is_email():
    assert_1 = 'my.email@the-provider.com'
    assert_2 = '@gmail.com'
    assert_3 = 'my.email@aol.com'
    assert_4 = 'a@aol.com'
    assert_5 = '.a@aol.com'
    assert_6 = '\ a@aol.com '
    result_1 = is_email(assert_1)
    result_2 = is_email(assert_2)
    result_3 = is_email(assert_3)
    result_4 = is_email(assert_4)
    result_5 = is_email(assert_5)
    result_6 = is_email(assert_6)
    assert result_1 == True
    assert result_2 == False
    assert result_3 == True

# Generated at 2022-06-26 01:58:32.551948
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    input_string = '096753954'
    instance = __ISBNChecker(input_string)
    assert instance.is_isbn_10() == True


# Generated at 2022-06-26 01:58:38.578528
# Unit test for function is_url
def test_is_url():
    # ===================
    # Test case 0: 'www.google.com' returns true
    expected_case_0 = True
    actual_case_0 = is_url('www.google.com')
    assert (expected_case_0 == actual_case_0), "expected value: " + str(expected_case_0) + " actual value: " + str(actual_case_0)

    # ===================
    # Test case 1: 'http://www.google.com' returns true
    expected_case_1 = True
    actual_case_1 = is_url('http://www.google.com')
    assert (expected_case_1 == actual_case_1), "expected value: " + str(expected_case_1) + " actual value: " + str(actual_case_1)

    # ===================
    # Test case

# Generated at 2022-06-26 01:58:42.657298
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    # Arrange
    isbn_checker_0 = __ISBNChecker('07X>GO')
    # Act
    bool_0 = isbn_checker_0.is_isbn_13()
    # Assert
    assert(bool_0 == False)


# Generated at 2022-06-26 01:59:00.707455
# Unit test for function is_email
def test_is_email():
    assert is_email('test@example.com') == True
    assert is_email('test') == False
    assert is_email('test@') == False
    assert is_email('test@example') == False
    assert is_email('@example.com') == False
    assert is_email('test@example..com') == False
    assert is_email('test..test@example.com') == False
    assert is_email('test@example.com.1.2.3.4.5.6.7.8.9.0') == False
    assert is_email('test@example.com.1.2.3.4.5.6.7.8.9') == True
    assert is_email('test@example.com.1.2.3.4.5.6.7.8.9.') == False


# Generated at 2022-06-26 01:59:03.534197
# Unit test for function is_ip_v4
def test_is_ip_v4():
    try:
        test_case_0()
    except:
        print("Exception thrown, but not expected")
        return 1
    else:
        pass # test passed
    return 0


# Generated at 2022-06-26 01:59:06.636306
# Unit test for function is_ip_v4
def test_is_ip_v4():
    #str_0 = "123.123.123.123"
    str_0 = "127.0.0.1"
    bool_0 = is_ip_v4(str_0)


# Generated at 2022-06-26 01:59:10.344035
# Unit test for function is_ip_v4
def test_is_ip_v4():
    str_0 = "172.16.254.1"
    bool_0 = is_ip_v4(str_0)
    assert bool_0 == True


# Generated at 2022-06-26 01:59:12.735471
# Unit test for function is_json
def test_is_json():
    test_case_1 = "[{'name': 'Peter'}]"
    assert is_json(test_case_1) == True


# Generated at 2022-06-26 01:59:23.870541
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    str_0 = "~_'N5"
    str_1 = '978-3-16-148410-0'
    str_2 = '9780786417997'
    str_3 = '978-1-56679-843-9'
    str_4 = "978156679843"
    str_5 = '978-3-16-148410-0'
    str_6 = '978-3-16-148410-0'
    str_7 = '978-3-16-148410-0'
    str_8 = '978-3-16-148410-0'
    str_9 = '978-3-16-148410-0'
    str_10 = '978-3-16-148410-0'

# Generated at 2022-06-26 01:59:27.521896
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    isbn_checker = __ISBNChecker('1234567891234')
    assert isbn_checker.is_isbn_13() == True

    isbn_checker = __ISBNChecker('123456789123')
    assert isbn_checker.is_isbn_13() == False


# Generated at 2022-06-26 01:59:33.829913
# Unit test for function is_email
def test_is_email():
    str_0 = "jfkdlsa"
    str_1 = "4341.3"
    str_2 = ".4341.3"
    str_3 = "frank@google.com"
    bool_0 = is_email(str_0)
    bool_1 = is_email(str_1)
    bool_2 = is_email(str_2)
    bool_3 = is_email(str_3)


# Generated at 2022-06-26 01:59:40.852212
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True, 'Expected true'
    assert is_email('@gmail.com') == False, 'Expected false'
    assert is_email('"my.email"@the-provider.com') == True, 'Expected true'
    assert is_email('"my.email\\@"@the-provider.com') == True, 'Expected true'


# Generated at 2022-06-26 01:59:48.500901
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') # returns true
    assert is_json('[1, 2, 3]') # returns true
    assert not is_json('{nope}') # returns false
    assert not is_json('{[]') # returns false
    assert not is_json('{"name": "Peter"}') # returns true
    assert not is_json('{"name": "Peter}') # returns true
    assert not is_json('{"name": "Peter ,}') # returns true
    assert not is_json('{"name": "Peter ,}') # returns true
    assert not is_json('{"name": "Peter ]}') # returns true
    assert not is_json('{"name": "Peter ]}') # returns true
    assert not is_json('{"name": "Peter [}') # returns true

# Generated at 2022-06-26 01:59:59.341172
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():

    # in invalid case
    obj_0 = __ISBNChecker('1852_8x')
    bool_0 = obj_0.is_isbn_10()

    
    # in valid case
    obj_1 = __ISBNChecker('0-306-40615-2')
    bool_1 = obj_1.is_isbn_10()



# Generated at 2022-06-26 02:00:04.081911
# Unit test for function is_json
def test_is_json():
    str_0 = ""

    bool_0 = is_json(str_0)
    assert bool_0 == False

    str_1 = "{\"name\": \"Peter\"}"
    bool_1 = is_json(str_1)
    assert bool_1 == True


# Generated at 2022-06-26 02:00:07.717774
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    str_0 = "99921-58-10-7"
    bool_0 = __ISBNChecker(str_0, True).is_isbn_13()


# Generated at 2022-06-26 02:00:20.342172
# Unit test for function is_email
def test_is_email():
    # first simple "pre check": it must be a non empty string with max len 320 and cannot start with a dot
    s = "~_'N5@baidu.com"
    #print(is_email(s))
    #assert(is_email(s))
    #assert(not is_email(""))
    #assert(not is_email(" "))
    #assert(not is_email("~_'N5"))
    #assert(not is_email("1~_'N5"))
    #assert(not is_email("~_'N5@baidu"))
    #assert(not is_email("~_'N5@baidu."))
    #assert(not is_email("~_'N5@baidu.com."))
    #assert(not is_email("~_'N5

# Generated at 2022-06-26 02:00:31.816610
# Unit test for function is_ip_v4
def test_is_ip_v4():
    str_0 = "20.15.0.255"     # IP_V4
    str_1 = "20.999.0.255"    # IP_V4
    str_2 = "20.15.0.255."    # Not_IP_V4
    str_3 = "20.15.256.0"     # Not_IP_V4
    bool_0 = is_ip_v4(str_0)  # true
    bool_1 = is_ip_v4(str_1)  # false
    bool_2 = is_ip_v4(str_2)  # false
    bool_3 = is_ip_v4(str_3)  # false


# Generated at 2022-06-26 02:00:35.372455
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    str_0 = "~_'N5"
    __ISBNChecker_object_0 = __ISBNChecker(str_0);
    bool_0 = __ISBNChecker_object_0.is_isbn_10()


# Generated at 2022-06-26 02:00:40.516182
# Unit test for function is_json
def test_is_json():
    str_0 = "{'name': 'Peter'}"
    str_1 = "[1, 2, 3]"
    bool_0 = is_json(str_0)
    bool_1 = is_json(str_1)
    bool_2 = bool_0 and bool_1
    return bool_2



# Generated at 2022-06-26 02:00:44.545668
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    s = '978-1-56619-909-4'
    result = __ISBNChecker(s, normalize=True).is_isbn_13()
    assert result == True


# Generated at 2022-06-26 02:00:48.757040
# Unit test for function is_json
def test_is_json():
    assert(is_json("[{\"foo\": 1}]") == True)
    assert(is_json("foo") == False)
    assert(is_json("{\"foo\": \"bar\"}[]") == False)


# Generated at 2022-06-26 02:00:55.983222
# Unit test for function is_json
def test_is_json():
    """
    This test will pass if your function (is_json) works correctly,
    otherwise it will raise an AssertionError exception.
    """
    json_str = '{"key": "value"}'
    assert is_json(json_str)

    json_str = '{["1", "2", "3"]}'
    assert is_json(json_str)

    json_str = 'not valid json'
    assert not is_json(json_str)


# Generated at 2022-06-26 02:01:03.705496
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    str_0 = "39275873191"
    isbnChecker = __ISBNChecker(str_0, True)
    bool_0 = isbnChecker.is_isbn_13()


# Generated at 2022-06-26 02:01:06.000166
# Unit test for function is_json
def test_is_json():
    str_0 = "{'name': 'Peter'}"
    bool_0 = is_json(str_0)
    assert bool_0 == True



# Generated at 2022-06-26 02:01:16.403632
# Unit test for function is_email
def test_is_email():
    assert is_email("a@a")
    assert is_email("0@0")
    assert is_email("$@$")
    assert is_email("a@0")
    assert is_email("0@$")
    assert is_email("1@2.com")
    assert is_email("123@abc.abc")
    assert is_email("abcdefghijklmnopqrstuvwxyz@abcdefghijklmnopqrstuvwxyz.abcdefg")
    assert is_email("abcdefghijklmnopqrstuvwxyz0123456789@abcdefghijklmnopqrstuvwxyz0123456789.abcdefghijklmnopqrstuvwxyz0123456789")

# Generated at 2022-06-26 02:01:16.959349
# Unit test for function is_email
def test_is_email():
    pass


# Generated at 2022-06-26 02:01:19.893462
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-3-16-148410-0').is_isbn_13() == True
    assert __ISBNChecker('978-3-16-148410-2').is_isbn_13() == False


# Generated at 2022-06-26 02:01:21.597661
# Unit test for function is_email
def test_is_email():
    assert(is_email("test@test.com") == True)


# Generated at 2022-06-26 02:01:25.621484
# Unit test for function is_ip_v4
def test_is_ip_v4():
    # Test case 1
    assert is_ip_v4('255.200.100.75') == True
    # Test case 2
    assert is_ip_v4('nope') == False
    # Test case 3
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-26 02:01:28.646477
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    str_0 = "1234"
    checker = __ISBNChecker(str_0)
    bool_0 = checker.is_isbn_13()
    assert bool_0 == False


# Generated at 2022-06-26 02:01:31.790257
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    str_0 = "71~1"
    checker = __ISBNChecker(str_0)
    bool_0 = checker.is_isbn_13()


# Generated at 2022-06-26 02:01:37.877832
# Unit test for function is_json
def test_is_json():
    str_0 = '{"name": "Peter"}'
    str_1 = '[1, 2, 3]'
    str_2 = '{nope}'
    bool_0 = is_json(str_0)
    bool_1 = is_json(str_1)
    bool_2 = is_json(str_2)

    return (bool_0 == bool_1 == bool_2)


# Generated at 2022-06-26 02:01:57.017494
# Unit test for function is_email
def test_is_email():
    assert(is_email("my.email@the-provider.com") == True)
    assert(is_email("@gmail.com") == False)
    assert(is_email("my.email@the-provider.com") == True)
    assert(is_email("me@aol.tv") == True)
    assert(is_email("me-me@aol.tv") == True)
    assert(is_email("me_me@aol.tv") == True)
    assert(is_email("me@aol.tv.info") == True)
    assert(is_email("me@aol.tv.info.com") == True)
    assert(is_email("me@192.168.1.1") == True)

# Generated at 2022-06-26 02:02:10.269821
# Unit test for function is_email
def test_is_email():
    str_0 = "foo"
    bool_0 = is_email(str_0)
    print("is_email: " + str(bool_0))
    str_1 = "foo@gmail.com"
    bool_1 = is_email(str_1)
    print("is_email: " + str(bool_1))
    str_2 = "foo@gmail.com."
    bool_2 = is_email(str_2)
    print("is_email: " + str(bool_2))
    str_3 = "foo@gmail.com.co"
    bool_3 = is_email(str_3)
    print("is_email: " + str(bool_3))
    str_4 = "foo@.com"
    bool_4 = is_email(str_4)