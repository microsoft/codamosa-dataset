

# Generated at 2022-06-26 01:52:33.093601
# Unit test for function is_ip_v4
def test_is_ip_v4():
    test_case_0()

# Unit test runner

# Generated at 2022-06-26 01:52:35.339526
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    int_0 = -1234
    bool_0 = __ISBNChecker(int_0).is_isbn_10()


# Generated at 2022-06-26 01:52:46.515016
# Unit test for function is_ip_v4
def test_is_ip_v4():
    """
    Test if the function is_ip_v4 returns the correct output for different input.
    
    Since this function is a simple boolean check, we just have to check that it return True or False
    for the correct input.
    """
    # Test with a valid IP
    assert is_ip_v4('255.200.100.75') == True
    # Test with a non IP string
    assert is_ip_v4('nope') == False
    # Test with a IP but with an out of range number
    assert is_ip_v4('255.200.100.999') == False

if __name__ == '__main__':
    test_case_0()
    test_is_ip_v4()

# Generated at 2022-06-26 01:52:50.693047
# Unit test for function is_email
def test_is_email():
    my_email = "hello.world@gmail.com"
    assert(is_email(my_email) == True)


# Generated at 2022-06-26 01:52:54.826435
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    input_string = "9798026800603"
    expected_output = False
    is_isbn_10 = __ISBNChecker(input_string).is_isbn_10()
    assert expected_output == is_isbn_10


# Generated at 2022-06-26 01:52:57.231129
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}')
    assert is_json('[1, 2, 3]')
    assert not is_json('{nope}')

# Generated at 2022-06-26 01:52:59.703558
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-26 01:53:09.363934
# Unit test for function is_ip_v4
def test_is_ip_v4():
    output_1 = is_ip_v4("0.0.0.0")
    assert output_1 == True

    output_2 = is_ip_v4("255.255.255.255")
    assert output_2 == True

    output_3 = is_ip_v4("256.0.0.0")
    assert output_3 == False

    output_4 = is_ip_v4("00.00.00.00")
    assert output_4 == False

    output_5 = is_ip_v4("192.168.1.1")
    assert output_5 == True


# Generated at 2022-06-26 01:53:14.203871
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('1.1.1.1') == True
    assert is_ip_v4('1.1.1.0.0') == False

    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-26 01:53:21.416600
# Unit test for function is_json
def test_is_json():
    json_0 = '{"hey": "dude"}'
    assert is_json(json_0) == True
    json_1 = '{'
    assert is_json(json_1) == False
    json_2 = json.loads(json_0)
    assert is_json(json_2) == True
    json_3 = '"hey": "dude"'
    assert is_json(json_3) == False
    json_4 = 1
    assert is_json(json_4) == False



# Generated at 2022-06-26 01:53:37.460037
# Unit test for function is_ip
def test_is_ip():
    errorCount = 0

    # Test 1: should return true
    if is_ip('255.200.100.75') == False:
        print("Test 1 Fail")
        errorCount += 1

    # Test 2: should return true
    if is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == False:
        print("Test 2 Fail")
        errorCount += 1

    # Test 3: should return false
    if is_ip('1.2.3') == True:
        print("Test 3 Fail")
        errorCount += 1

    if errorCount > 0:
        print("\nFunction is_ip() failed ", errorCount, " tests.")
    else:
        print("\nFunction is_ip() passed all tests.")


# Generated at 2022-06-26 01:53:50.271101
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    str_1 = "978-0133440886"
    obj_1 = __ISBNChecker(str_1, True)
    bool_1 = obj_1.is_isbn_13()
    assert bool_1 == True

    str_1 = "978-0-13-344088-1"
    obj_1 = __ISBNChecker(str_1, True)
    bool_1 = obj_1.is_isbn_13()
    assert bool_1 == True

    str_1 = "978-0-13-344088-3"
    obj_1 = __ISBNChecker(str_1, True)
    bool_1 = obj_1.is_isbn_13()
    assert bool_1 == False


# Generated at 2022-06-26 01:53:55.990444
# Unit test for function is_json
def test_is_json():
    assert is_json("{\"foo\": \"bar\"}") == True
    assert is_json("{nope}") == False
    assert is_json("") == False
    assert is_json(" ") == False
    assert is_json(None) == False


# Generated at 2022-06-26 01:54:02.116975
# Unit test for function is_json
def test_is_json():
    # Test 1: Test valid JSON
    test1_result = is_json('{"name": "Peter"}')
    assert test1_result == True
    # Test 2: Test valid JSON
    test2_result = is_json('[1, 2, 3]')
    assert test2_result == True
    # Test 3: Test invalid JSON
    test3_result = is_json('{nope}')
    assert test3_result == False


# Generated at 2022-06-26 01:54:04.883442
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.google.com')
    assert is_url('.google.com') == False
    assert is_url(' ') == False


# Generated at 2022-06-26 01:54:08.783393
# Unit test for function is_ip
def test_is_ip():
    assert( is_ip("2001:db8:85a3:0000:0000:8a2e:370:7334") == True )

# Generated at 2022-06-26 01:54:15.949492
# Unit test for function is_isbn
def test_is_isbn():
    print("------------------- Unit Testing is_isbn -------------------")
    # Test case 1: 11 digits
    print("Test case 1:\nInput - 9780312498580, Output - ", is_isbn("9780312498580"))
    # Test case 2: 13 digits
    print("Test case 2:\nInput - 978-0312498580, Output - ", is_isbn("978-0312498580"))
    # Test case 3: 13 digits
    print("Test case 3:\nInput - 1506715214, Output - ", is_isbn("1506715214"))
    # Test case 4: 13 digits
    print("Test case 4:\nInput - 150-6715214, Output - ", is_isbn("150-6715214"))
    print("------------------- Unit Test Complete -------------------")
    return


# Generated at 2022-06-26 01:54:18.617877
# Unit test for function is_url
def test_is_url():
    # Test case 0
    test_case = 0
    int_0 = -1579
    bool_0 = is_isogram(int_0)


# Generated at 2022-06-26 01:54:27.752566
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn("14-12-36-27-45") == False
    assert is_isbn("85-13-36-27-45") == False
    assert is_isbn("14-12-36-27-45", True) == False
    assert is_isbn("85-13-36-27-45", True) == False
    assert is_isbn("14-13-36-27-45") == True
    assert is_isbn("85-12-36-27-45") == True
    assert is_isbn("abc") == False
    assert is_isbn("") == False


# Generated at 2022-06-26 01:54:32.749995
# Unit test for function is_email
def test_is_email():
    string_0 = '^7Vq3I@|'
    bool_0 = is_email(string_0)



# Generated at 2022-06-26 01:54:43.264606
# Unit test for function is_url
def test_is_url():
    assert is_url("http://www.google.com") is True
    assert is_url("https://www.google.com") is True
    assert is_url("www.google.com") is False
    assert is_url(".google.com") is False
    assert is_url("15.0.78.255") is False


# Generated at 2022-06-26 01:54:45.561282
# Unit test for function is_ip_v4
def test_is_ip_v4():
    int_0 = -1579
    bool_0 = is_ip_v4(int_0)

    assert bool_0 == False

# Generated at 2022-06-26 01:54:57.867620
# Unit test for function is_email
def test_is_email():
    assert is_email('abc@abc.com')    
    assert is_email('abc@abc.net')    
    assert is_email('abc@abc.net.')    
    assert not is_email('abc@abc.com.')    
    assert not is_email('abc@abc.net..')    
    assert not is_email("abc@abc.com\n")    
    assert not is_email("abc@abc.com\\")    
    assert not is_email('')    

# Generated at 2022-06-26 01:55:05.509414
# Unit test for function is_email
def test_is_email():
    str_0 = '"john.doe"@example.com'
    str_1 = '"john.doe"@example.com'
    int_0 = -1579
    bool_0 = is_email(int_0)
    bool_1 = is_email(str_0)
    bool_2 = is_email(str_1)

# Generated at 2022-06-26 01:55:14.369756
# Unit test for function is_credit_card
def test_is_credit_card():
    if not is_credit_card('4111'):
        raise Exception('Fail test_is_credit_card')
    if not is_credit_card('4111-1111-1111-1111'):
        raise Exception('Fail test_is_credit_card')
    if not is_credit_card('4111111111111111'):
        raise Exception('Fail test_is_credit_card')
    if not is_credit_card('6011111111111117'):
        raise Exception('Fail test_is_credit_card')
    print('Pass test_is_credit_card')


# Generated at 2022-06-26 01:55:16.867621
# Unit test for function is_url
def test_is_url():
    str_0 = 'http://www.mysite.com'
    bool_0 = is_url(str_0)


# Generated at 2022-06-26 01:55:27.084517
# Unit test for function is_url
def test_is_url():
    # Check is_url(input_string, allowed_schemes) for an invalid case
    # This should return false
    # The second argument is specified to be ['https']
    # Since the input_string does not start with 'https', this should return false
    # Setup
    input_string_0 = 'http://math.colorado.edu/~woit/wordpress/?p=1119'
    allowed_schemes_0 = ['https']

    # Invoke function
    bool_0 = is_url(input_string_0, allowed_schemes_0)

    # Check against expected
    assert (bool_0 == False), "Test case failed!"

    # Check is_url(input_string, allowed_schemes) for a valid case
    # This should return true
    # The second argument is specified to be ['http']

# Generated at 2022-06-26 01:55:33.519811
# Unit test for function is_url
def test_is_url():
   assertTrue(is_url(""))
   assertTrue(is_url(""))
   assertTrue(is_url(""))
   assertTrue(is_url(""))
   assertTrue(is_url(""))

   assertFalse(is_url(""))
   assertFalse(is_url(""))
   assertFalse(is_url(""))
   assertFalse(is_url(""))
   assertFalse(is_url(""))



# Generated at 2022-06-26 01:55:45.464383
# Unit test for function is_email
def test_is_email():
    assert(is_email("A@gmail.com") == True)
    assert(is_email("@gmail.com") == False)
    assert(is_email("A") == False)
    assert(is_email("A@gmail") == False)
    assert(is_email("A@gmail.com@gmail.com") == False)
    assert(is_email("abcd\\@gmail.com") == True)
    assert(is_email("abcd" + chr(92) + chr(92) + chr(92) + chr(92) + "abcd@gmail.com") == True)
    assert(is_email("abcd" + chr(92) + chr(92) + chr(92) + chr(92) + "abcd@gmail.com") == True)

# Unit test

# Generated at 2022-06-26 01:55:54.484549
# Unit test for function is_credit_card
def test_is_credit_card():
    assert (is_credit_card("4012888888881881"))
    assert (is_credit_card("4111111111111111"))
    assert (is_credit_card("378282246310005"))
    assert (is_credit_card("6011111111111117"))
    assert (is_credit_card("6011111111111117"))
    assert (is_credit_card("6011000990139424"))
    assert (is_credit_card("30569309025904"))
    assert (is_credit_card("3530111333300000"))
    assert (not is_credit_card("3530111333300001"))
    assert (not is_credit_card("353011133330000"))
    assert (not is_credit_card("35301113330000"))

# Generated at 2022-06-26 01:56:01.938114
# Unit test for function is_credit_card
def test_is_credit_card():
    print("Test is_credit_card function...")
    assert is_credit_card("4485038179937580") == True


# Generated at 2022-06-26 01:56:12.682564
# Unit test for function is_url
def test_is_url():
    url_0 = 'https://www.mysite.com'
    bool_0 = is_url(url_0)
    assert bool_0
    url_1 = 'file:///etc/passwd'
    bool_1 = is_url(url_1)
    assert bool_1
    url_2 = 'file:///etc/passwd'
    bool_2 = is_url(url_2)
    assert bool_2
    url_3 = 'https://www.w3.org/TR/html40/htmlweb.html'
    bool_3 = is_url(url_3)
    assert bool_3
    url_4 = '.../foo/bar'
    bool_4 = is_url(url_4)
    assert bool_4
    url_5 = '.../foo/bar/'


# Generated at 2022-06-26 01:56:19.991495
# Unit test for function is_credit_card
def test_is_credit_card():
    int_0 = 1
    int_1 = -1
    int_2 = -2
    int_3 = 0
    bool_0 = is_credit_card(int_1)
    bool_1 = is_credit_card(int_2)
    bool_2 = is_credit_card(int_3)
    bool_3 = is_credit_card(int_0)
    bool_4 = is_credit_card(int_0, card_type="VISA")
    bool_5 = is_credit_card(int_0, card_type="MASTERCARD")
    bool_6 = is_credit_card(int_0, card_type="AMERICAN EXPRESS")
    bool_7 = is_credit_card(int_0, card_type="DINERS CLUB")

# Generated at 2022-06-26 01:56:22.298828
# Unit test for function is_json
def test_is_json():
  assert is_json("{\"foo\": \"bar\"}") == True
  assert is_json("foo") == False



# Generated at 2022-06-26 01:56:32.855847
# Unit test for function is_json
def test_is_json():
    json_str_1 = '{ "name": "Peter"}'
    json_str_2 = '["Peter"]'
    json_str_3 = '{nope}'
    test_str_1 = is_json(json_str_1)
    test_str_2 = is_json(json_str_2)
    test_str_3 = is_json(json_str_3)
    print('json_str_1 is a JSON:', test_str_1)
    print('json_str_2 is a JSON:', test_str_2)
    print('json_str_3 is a JSON:', test_str_3)


# Generated at 2022-06-26 01:56:35.953378
# Unit test for function is_credit_card
def test_is_credit_card():
    card_type = "visa"
    input_string = "4242424242424242"
    assert is_credit_card(input_string, card_type) == True


# Generated at 2022-06-26 01:56:43.318399
# Unit test for function is_email
def test_is_email():
    st0 = "email@example.com"
    st1 = "firstname.lastname@example.com"
    st2 = "email@subdomain.example.com"
    st3 = "firstname+lastname@example.com"
    st4 = "email@123.123.123.123"
    st5 = "email@[123.123.123.123]"
    st6 = '"email"@example.com'
    st7 = "1234567890@example.com"
    st8 = "email@example-one.com"
    st9 = "_______@example.com"
    st10 = "email@example.name"
    st11 = "email@example.museum"
    st12 = "email@example.co.jp"

# Generated at 2022-06-26 01:56:47.023433
# Unit test for function is_url
def test_is_url():
    assert is_url("http://www.mysite.com")
    assert is_url("https://mysite.com")
    assert not is_url(".mysite.com")


# Generated at 2022-06-26 01:56:51.384376
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') is True
    assert is_ip_v4('nope') is False
    assert is_ip_v4('255.200.100.999') is False

    print("Test is_ip_v4 Completed")


# Generated at 2022-06-26 01:57:03.225656
# Unit test for function is_credit_card
def test_is_credit_card():
    input_string = "4444444444444444"
    card_type = "VISA"
    assert(is_credit_card(input_string, card_type))

    input_string = "5555555555555555"
    card_type = "MASTERCARD"
    assert(is_credit_card(input_string, card_type))

    input_string = "378282246310005"
    card_type = "AMERICAN_EXPRESS"
    assert(is_credit_card(input_string, card_type))

    input_string = "30569309025904"
    card_type = "DINERS_CLUB"
    assert(is_credit_card(input_string, card_type))

    input_string = "6011111111111117"
    card_

# Generated at 2022-06-26 01:57:12.073966
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    int_0 = 93564
    str_0 = str(int_0)
    checker = __ISBNChecker(str_0, True)
    result = checker.is_isbn_10()

    if result:
        pass
    else:
        raise Exception("Test for method is_isbn_10 of class __ISBNChecker is failed")



# Generated at 2022-06-26 01:57:24.932798
# Unit test for function is_email
def test_is_email():
    str_0 = 'q'
    str_1 = 'my.email@the-provider.com'
    str_2 = '.email@the-provider.com'
    str_3 = 'my..email@the-provider.com'
    str_4 = 'my email@the-provider.com'
    str_5 = '"my.email"@the-provider.com'
    str_6 = '"my..email@the-provider.com'
    str_7 = 'my..email@the-provider.com'
    str_8 = 'my.email@the-provider.com'
    str_9 = '\\ my.email@the-provider.com'
    str_10 = '\\ my.email@the-provider.com'

# Generated at 2022-06-26 01:57:28.268132
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    i = __ISBNChecker("0735619670")
    assert i.is_isbn_10() == True


# Generated at 2022-06-26 01:57:30.638639
# Unit test for function is_json
def test_is_json():
    result = is_json("{}")
    assert result == True



# Generated at 2022-06-26 01:57:35.795553
# Unit test for function is_json
def test_is_json():
    input_string_0 = '[1, 2, 3]'
    input_string_1 = '['
    input_string_2 = '{1: 1, 2: 2}'
    result_0 = is_json(input_string_0)
    result_1 = is_json(input_string_1)
    result_2 = is_json(input_string_2)
    assert result_0 == True
    assert result_1 == False
    assert result_2 == False


# Generated at 2022-06-26 01:57:42.591162
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    def __ISBNChecker_is_isbn_13_0(self):
        str_0 = '978-0-306-40615-7'
        bool_0 = self.is_isbn_13(str_0)
        if not bool_0:
            return False
        return True

    if not __ISBNChecker_is_isbn_13_0(__ISBNChecker):
        return False
    return True



# Generated at 2022-06-26 01:57:46.153595
# Unit test for function is_email
def test_is_email():
    if is_email('email@email.com') == False:
        raise ValueError('Incorrect Email')
    if is_email(1) != False:
        raise ValueError('Incorrect Email')
    if is_email('') != False:
        raise ValueError('Incorrect Email')
    print('test_is_email passed')


# Generated at 2022-06-26 01:57:52.874067
# Unit test for function is_ip_v4
def test_is_ip_v4():
    str_0 = "0.0.0.0"
    assert is_ip_v4(str_0)

    str_1 = "255.255.255.255"
    assert is_ip_v4(str_1)

    str_2 = "256.255.255.255"
    assert not is_ip_v4(str_2)


# Generated at 2022-06-26 01:57:56.710484
# Unit test for function is_url
def test_is_url():
    str_0 = "hello.world."
    bool_0 = is_url(str_0)
    assert not bool_0
    return


# Generated at 2022-06-26 01:58:01.663561
# Unit test for function is_json
def test_is_json():
    assert is_json("{'a': 'b', 'c': [1, 2]}")
    assert is_json("[1, 2, 3]")
    assert not is_json("{nope}")
    assert not is_json(None)
    assert not is_json("")


# Generated at 2022-06-26 01:58:18.405800
# Unit test for function is_email

# Generated at 2022-06-26 01:58:23.906394
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4("0.0.0.0") == True
    assert is_ip_v4("255.255.255.255") == True
    assert is_ip_v4("127.0.0.1") == True
    assert is_ip_v4("127.0.0.256") == False
    assert is_ip_v4("") == False


# Generated at 2022-06-26 01:58:28.325702
# Unit test for function is_ip_v4
def test_is_ip_v4():
    # Test 1
    input_string = "255.200.100.75"
    expected_value = True
    actual_value = is_ip_v4(input_string)
    assert actual_value == expected_value

    # Test 2
    input_string = "nope"
    expected_value = False
    actual_value = is_ip_v4(input_string)
    assert actual_value == expected_value

    # Test 3
    input_string = "255.200.100.999"
    expected_value = False
    actual_value = is_ip_v4(input_string)
    assert actual_value == expected_value

# Generated at 2022-06-26 01:58:36.316994
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False
    assert is_ip_v4('255.200.100.25') == True
    assert is_ip_v4('255.200.100.256') == False
    assert is_ip_v4('192.168.100.100') == True
    assert is_ip_v4('255.255.255.255') == True
    assert is_ip_v4('0.0.0.0') == True
    assert is_ip_v4('255.255.255.256') == False



# Generated at 2022-06-26 01:58:43.408006
# Unit test for function is_url
def test_is_url():
    input_value = "http://www.mysite.com"
    #input_value = "http://"
    #input_value = ""
    #input_value = "123"
    #input_value = None
    expected_result = True
    actual_result = is_url(input_value)
    #print(input_value, actual_result)
    if(actual_result != expected_result):
        print("function is_url failure!")


# Generated at 2022-06-26 01:58:46.317706
# Unit test for function is_json
def test_is_json():
    assert(is_json('{"name": "Peter"}'))
    assert(is_json('[1, 2, 3]'))
    assert(not is_json('{nope}'))
        

# Generated at 2022-06-26 01:58:54.095472
# Unit test for function is_email
def test_is_email():
    for i in range(5):
        int_0 = i
        bool_0 = is_isogram(int_0)

    string_0 = "foo"
    string_1 = "bar"
    bool_1 = is_isogram(string_0)

    for i in range(5):
        int_1 = i
        bool_2 = is_isogram(int_1)

    bool_3 = is_isogram(string_1)
    bool_2 = is_isogram(int_1)



# Generated at 2022-06-26 01:58:55.796723
# Unit test for function is_email
def test_is_email():
    # case 0
    str_0 = ''
    bool_0 = is_email(str_0)


# Generated at 2022-06-26 01:58:57.564170
# Unit test for function is_email
def test_is_email():
    # test
    assert is_email('my.email@the-provider.com') is True
    assert is_email('@gmail.com') is False


# Generated at 2022-06-26 01:58:59.962475
# Unit test for function is_email
def test_is_email():
    assert is_email('foo@bar.com')
    assert not is_email('foo@')
    assert not is_email('foo')
    assert not is_email('foo@bar')
    assert not is_email('foo@.com')
    

# Generated at 2022-06-26 01:59:15.165605
# Unit test for function is_email
def test_is_email():
    assert is_email('someuser@gmail.com')
    assert not is_email('gmail.com')
    assert is_email('me@domain.co.uk')
    assert not is_email('me@domain.com.uk')
    assert is_email('"me"@domain.co.uk')
    assert is_email('"me@you"@domain.co.uk')
    assert is_email('"me\\"you"@domain.co.uk')
    assert not is_email('"me\\you"@domain.co.uk')
    assert is_email('"me\\\\you"@domain.co.uk')
    assert is_email('"me\\\\\\"you"@domain.co.uk')
    assert is_email('me.you@domain.co.uk')

# Generated at 2022-06-26 01:59:25.381959
# Unit test for function is_email
def test_is_email():
    str_0 = "web@gmail.com"
    str_1 = "web@calpoly.edu"
    str_2 = ":jfdsajkf"

# Generated at 2022-06-26 01:59:28.333615
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False
    assert is_json(10) == False
    assert is_json(3.14) == False


# Generated at 2022-06-26 01:59:40.307791
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    for i in range(201):
        for j in range(201):
            for k in range(201):
                for l in range(201):
                    for m in range(201):
                        for n in range(201):
                            for p in range(201):
                                for q in range(201):
                                    for r in range(201):
                                        for s in range(201):
                                            for t in range(201):
                                                if t < 10:
                                                    s_2 = '0'
                                                else:
                                                    s_2 = ''
                                                if s < 10:
                                                    s_1 = '0'
                                                else:
                                                    s_1 = ''
                                                if r < 10:
                                                    q_3 = '0'

# Generated at 2022-06-26 01:59:44.183112
# Unit test for function is_email
def test_is_email():
    str_0 = 'usernametel@gmail.com'
    bool_0 = is_email(str_0)
    str_1 = 'Same'
    bool_1 = is_email(str_1)
    bool_2 = bool_0


# Generated at 2022-06-26 01:59:46.143869
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4("192.168.1.1") == True
    assert is_ip_v4("255.200.100.999") == False


# Generated at 2022-06-26 01:59:54.381599
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') is True
    assert is_ip_v4('nope') is False
    assert is_ip_v4('255.200.100.999') is False
    assert is_ip_v4('256.20.10.1') is False
    assert is_ip_v4('256.20.10.1') is False
    assert is_ip_v4('256.20.10.') is False


# Generated at 2022-06-26 02:00:02.148136
# Unit test for function is_email
def test_is_email():
    strings = ['myemail@gmail.com', 'yourname', 'sample.email@yahoo.com', '']
    expected = [ True, False, True, False]
    for i in range(0, len(strings)):
        # if is_email(strings[i]) == expected[i]:
        if (is_email(strings[i])):
            print('Test for is_email Successful!')
        else:
            print('Test for is_email Failed!')


# Generated at 2022-06-26 02:00:11.063221
# Unit test for function is_email
def test_is_email():
    # Test 1
    email_0 = 'my.email@the-provider.com'
    bool_0 = is_email(email_0)
    # Test 2
    email_1 = '@gmail.com'
    bool_1 = is_email(email_1)
    assert bool_1 == False
    # Test 3
    email_2 = 'abc@abc.abc'
    bool_2 = is_email(email_2)
    assert bool_2 == True
    # Test 4
    email_3 = 'email@.com'
    bool_3 = is_email(email_3)
    assert bool_3 == False
    # Test 5
    email_4 = 'email@com'
    bool_4 = is_email(email_4)
    assert bool_4 == False
    # Test 6
   

# Generated at 2022-06-26 02:00:22.469188
# Unit test for function is_url
def test_is_url():
    assert not is_url(int())
    assert not is_url(float())
    assert not is_url(bool())
    assert is_url('http://www.foo.com')
    assert not is_url('http://www.foo.com/bar=value')
    assert not is_url('.foo.com')
    assert is_url('https://foo.com')
    assert is_url('http://foo.com')
    assert is_url('ftp://bar.com')
    assert is_url('http://www.foo.co.uk')
    assert is_url('http://www.foo.com/bar')
    assert is_url('http://www.foo.com/bar/')
    assert is_url('http://www.foo.com/bar/faz/boo')

# Generated at 2022-06-26 02:00:27.454167
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-26 02:00:40.203567
# Unit test for function is_url
def test_is_url():
    # Test 1
    input_string = "http://www.mysite.com"
    allowed_schemes = None
    assert(is_url(input_string, allowed_schemes) == True)

    # Test 2
    input_string = ".mysite.com"
    allowed_schemes = None
    assert(is_url(input_string, allowed_schemes) == False)

    # Test 3
    input_string = "www.mysite.com"
    allowed_schemes = None
    assert(is_url(input_string, allowed_schemes) == False)

    # Test 4
    input_string = "http://www.mysite.com"
    allowed_schemes = ["https"]
    assert(is_url(input_string, allowed_schemes) == False)

# Generated at 2022-06-26 02:00:44.272564
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('8180774714').is_isbn_10() == True
    assert __ISBNChecker('818077471x').is_isbn_10() == False


# Generated at 2022-06-26 02:00:45.486101
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    test_case_0()


# Generated at 2022-06-26 02:00:52.465829
# Unit test for function is_email
def test_is_email():
    # test case 0
    email_0 = "nathan+4@gmail.com"
    ret_val_0 = is_email(email_0)
    assert ret_val_0 == True

    # test case 1
    email_1 = "nate@milt.com"
    ret_val_1 = is_email(email_1)
    assert ret_val_1 == True

    # test case 2
    email_2 = "josephine@darpa.mil"
    ret_val_2 = is_email(email_2)
    assert ret_val_2 == True


# Generated at 2022-06-26 02:00:56.236503
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com')
    assert is_url('https://mysite.com')
    assert not is_url('.mysite.com')


# Generated at 2022-06-26 02:01:00.083588
# Unit test for function is_email
def test_is_email():
    test_cases = [('my.email@the-provider.com', True),
                  ('@gmail.com', False),
                  ('myemail@a.b.c.d', True),]
    for case in test_cases:
        assert is_email(case[0]) == case[1]


# Generated at 2022-06-26 02:01:01.368679
# Unit test for function is_email
def test_is_email():
    assert is_email("asdf@love.com") is True


# Generated at 2022-06-26 02:01:12.429242
# Unit test for function is_email
def test_is_email():
    assert is_email("a@a.a") == True
    assert is_email("abc@abc.abc") == True
    assert is_email("abc@abc.abc.abc") == False
    assert is_email("a@a.a.a") == False
    assert is_email("abcd@abc.abc.abc") == False
    assert is_email("abc@abc.abc.abc.abc") == False
    assert is_email("a@a.a.a.a") == False
    assert is_email("@") == False
    assert is_email("a@") == False
    assert is_email("@a") == False
    assert is_email("abc@abc") == False
    assert is_email("abc@abc.") == False
    assert is_email("abc@abc.abc.abc.") == False
   

# Generated at 2022-06-26 02:01:15.368752
# Unit test for function is_url
def test_is_url():
    assert(is_url("http://www.mysite.com") == True)
    assert(is_url("https://mysite.com") == True)
    assert(is_url(".mysite.com") == False)



# Generated at 2022-06-26 02:01:19.573426
# Unit test for function is_json
def test_is_json():
    assert not is_json('test')

test_is_json()

test_case_0()


# Generated at 2022-06-26 02:01:21.558710
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker("9791026930055").is_isbn_13() == True


# Generated at 2022-06-26 02:01:24.729659
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-26 02:01:27.193069
# Unit test for function is_json
def test_is_json():
    x = '{"name": "Peter"}'
    y = '{"name": "Peter"}'
    assert is_json(x) == is_json(y)


# Generated at 2022-06-26 02:01:31.639962
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    int_0 = -1579
    __ISBNChecker_instance = __ISBNChecker(int_0)
    int_1 = -1579
    bool_0 = __ISBNChecker_instance.is_isbn_13(int_1)

# PUBLIC API



# Generated at 2022-06-26 02:01:38.711301
# Unit test for function is_ip_v4
def test_is_ip_v4():
    print("Unit tests for the function is_ip_v4")
    print("test_is_ip_v4:")
    case_0 = "255.200.100.75"
    case_1 = "nope"
    case_2 = "255.200.100.999"

    print(is_ip_v4(case_0))
    print(is_ip_v4(case_1))
    print(is_ip_v4(case_2))


# Main function

# Generated at 2022-06-26 02:01:40.238817
# Unit test for function is_json
def test_is_json():
    assert is_json("\"name\": \"Peter\"")
    assert not is_json("{nope}")


# Generated at 2022-06-26 02:01:45.513618
# Unit test for function is_email
def test_is_email():
    assert is_email('dummy@dummy.com') == True
    assert is_email('dummy@dummy.dummy') == True
    assert is_email('dummy.dummy@dummy.dummy') == True
    assert is_email('dummy..dummy@dummy...dummy') == True
    assert is_email('.@dummy.com') == False
    assert is_email('..@dummy.com') == False
    assert is_email('dummy@..dummy.com') == False
    assert is_email('dummy\\ dummy@dummy.com') == True
    assert is_email('dummy\\\\@dummy.com') == False
    assert is_email('dummy\\@dummy@dummy.com') == False

# Generated at 2022-06-26 02:01:49.306063
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.co.uk')
    assert is_email('my.email@the-provider.org')
    assert is_email('my.email@the-provider.net')
    assert is_email('my.email@the-provider.ca')
    assert is_email('my.email@the-provider.us')
    assert is_email('my.email@the-provider.com.cn')
    assert is_email('foo@bar.org')
    assert is_email('foo.bar@baz.com.cn')
    assert is_email('foo@bar.info')
    assert is_email('foo@bar.io')
    assert is_email('foo@bar.com')

# Generated at 2022-06-26 02:01:56.104732
# Unit test for function is_email
def test_is_email():
    str_0 = 'lO527'
    bool_0 = is_email(str_0)
    assert bool_0 == True
    str_1 = 'SfHJ@'
    bool_1 = is_email(str_1)
    assert bool_1 == False

###############################################################################

# Base-10 checksum checker from https://en.wikipedia.org/wiki/Luhn_algorithm

# Generated at 2022-06-26 02:02:10.178970
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    int_0 = 0
    int_1 = 1

    try:
        obj_0 = __ISBNChecker(int_0)
    except:
        int_2 = 1

    try:
        int_3 = obj_0.is_isbn_13()
    except:
        int_4 = 1

    try:
        obj_1 = __ISBNChecker(int_1)
    except:
        int_5 = 1

    try:
        int_6 = obj_1.is_isbn_13()
    except:
        int_7 = 1
