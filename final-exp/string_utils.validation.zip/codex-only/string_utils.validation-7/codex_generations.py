

# Generated at 2022-06-24 02:19:46.738942
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42') == True
    assert is_integer('42.0') == False


# Generated at 2022-06-24 02:19:51.428196
# Unit test for function is_full_string
def test_is_full_string():
    assert not is_full_string(None)
    assert not is_full_string('')
    assert not is_full_string(' ')
    assert not is_full_string('   ')
    assert is_full_string('hello')


# Generated at 2022-06-24 02:19:57.972317
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('Dermatoglyphics') is True
    assert is_isogram('isogram') is True
    assert is_isogram('aba') is False
    assert is_isogram('moose') is False
    assert is_isogram('isIsogram') is False
    assert is_isogram('') is True
test_is_isogram()


# Generated at 2022-06-24 02:20:04.414755
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10("1506715214") is True
    assert is_isbn_10("150-6715214") is True
    assert is_isbn_10("150-6715214", normalize=False) is False
    assert is_isbn_10("3866593631") is False
    assert is_isbn_10("38665936-31") is False
    assert is_isbn_10("1.506715214") is False
    assert is_isbn_10("1.506715214", normalize=False) is False
test_is_isbn_10()



# Generated at 2022-06-24 02:20:08.764490
# Unit test for function is_number
def test_is_number():
    assert is_number('123') == True
    assert is_number('abc') == False
    assert is_number('1-2') == False
    assert is_number('-123') == True
    assert is_number('-123.4') == True
    assert is_number('-123.4.5') == False
    assert is_number('-123.4e5') == True
    assert is_number('-123.4e5d') == False


# Generated at 2022-06-24 02:20:17.160936
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal(1.2) == True
    assert is_decimal(0.8) == True
    assert is_decimal(-1.2) == True
    assert is_decimal(-0.8) == True
    assert is_decimal('1.2') == True
    assert is_decimal('0.8') == True
    assert is_decimal('-1.2') == True
    assert is_decimal('-0.8') == True
    assert is_decimal('hello') == False


# Generated at 2022-06-24 02:20:23.617600
# Unit test for function is_ip_v4
def test_is_ip_v4():
    # Test case 1, test a valid ip address
    result = is_ip_v4('192.168.0.1')
    assert result == True
    # Test case 2, test an invalid ip address
    result = is_ip_v4('490.490.490.490')
    assert result == False


# Generated at 2022-06-24 02:20:34.771981
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title') == True
    assert is_slug('my-blog-post-title') == True
    assert is_slug('My-blog-post-title') == False
    assert is_slug('My blog post title') == False
    assert is_slug('my-blog-post-title', separator='_') == True
#     assert is_slug('my-blog-post-title', separator='_') == True
#     assert is_slug('my-blog-post-title', separator='_') == False
#     assert is_slug('my-blog-post-title', separator='_') == False
    



# Generated at 2022-06-24 02:20:46.348139
# Unit test for function contains_html
def test_contains_html():
    assert(contains_html('<strong>alice</strong>') == True)
    assert(contains_html('<strong> alice</strong>') == True)
    assert(contains_html('< strong> alice</strong>') == True)
    assert(contains_html('< strong alice</strong>') == True)
    assert(contains_html('< strong alice</strong>') == True)
    assert(contains_html('<strong alice /strong>') == True)
    assert(contains_html('<strong alice /strong>') == True)
    assert(contains_html('<strong alice <strong>') == True)

    assert(contains_html('< alice>') == False)
    assert(contains_html('alice>') == False)

# Generated at 2022-06-24 02:20:47.844976
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('032140088X').is_isbn_10() == True


# Generated at 2022-06-24 02:20:58.782915
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram("trotters") == True, "is_isogram (trotters) should be true."
    assert is_isogram("nope") == False, "is_isogram (nope) should be false."
    assert is_isogram("") == True, "is_isogram () should be true."
    assert is_isogram("thumbscrewjapingly") == True, "is_isogram (thumbscrewjapingly) should be true."
    assert is_isogram("six-year-old") == True, "is_isogram (six-year-old) should be true."
    assert is_isogram("six") == True, "is_isogram (six) should be true."


# Generated at 2022-06-24 02:21:03.514034
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome("") == False
    assert is_palindrome("mystring") == False
    assert is_palindrome("to o t") == False
    assert is_palindrome("abba") == True
    assert is_palindrome("tot") == True
    assert is_palindrome("otto") == True
    assert is_palindrome("A man, a plan, a canal: Panama") == True
    assert is_palindrome("race a car") == False
    assert is_palindrome("0P") == False
    assert is_palindrome("race car") == True
    assert is_palindrome("1 eye for of 1 eye.") == False
    assert is_palindrome("not a palindrome") == False
    assert is_palindrome("never odd or even") == True

# Generated at 2022-06-24 02:21:08.512767
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram("Dermatoglyphics") == True
    assert is_isogram("isogram") == True
    assert is_isogram("aba") == False
    assert is_isogram("moOse") == False
    assert is_isogram("isIsogram") == False
    assert is_isogram("") == True
test_is_isogram()


# Generated at 2022-06-24 02:21:13.573694
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert True == is_ip_v4('255.200.100.75')
    assert False == is_ip_v4('nope')
    assert False == is_ip_v4('255.200.100.999')



# Generated at 2022-06-24 02:21:19.030871
# Unit test for function is_decimal
def test_is_decimal():
    assert not is_decimal("hello")
    assert not is_decimal("10")
    assert is_decimal("10.0")


# Generated at 2022-06-24 02:21:21.836305
# Unit test for function words_count
def test_words_count():
    print('Testing words_count...', end='')
    assert words_count('hello world') == 2
    assert words_count('one,two,three.stop') == 4
    print('done.')

test_words_count()


# Generated at 2022-06-24 02:21:22.959037
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn("978-0312498580") # should return true
    assert is_isbn("1506715214") # should return true

# Generated at 2022-06-24 02:21:25.333472
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('hello') == False, 'is_isogram() has failed'
    assert is_isogram('dermatoglyphics') == True, 'is_isogram() has failed'



# Generated at 2022-06-24 02:21:26.511054
# Unit test for function is_isbn
def test_is_isbn():
    is_isbn('9780312498580')
    is_isbn('1506715214')

# Generated at 2022-06-24 02:21:32.615635
# Unit test for function is_ip_v4
def test_is_ip_v4():
    s = '255.200.100.75'
    assert is_ip_v4(s) == True
    s = 'nope'
    assert is_ip_v4(s) == False
    s = '255.200.100.999'
    assert is_ip_v4(s) == False
#is_ip_v4()
test_is_ip_v4()

# Generated at 2022-06-24 02:21:34.489531
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    _ = __ISBNChecker('978-84-376-0494-7', True)


# PUBLIC API



# Generated at 2022-06-24 02:21:38.194603
# Unit test for function contains_html
def test_contains_html():
    """ Unit test for function contains_html """
    # Arrange
    my_string = '<plop>tralala</plop>'

    # Act
    result = contains_html(my_string)

    # Assert
    assert result == True, "Should be true if contains html"

# Generated at 2022-06-24 02:21:43.618377
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('hello') == False
    assert is_isogram('dermatoglyphics') == True
    assert is_isogram('isogram') == True
    
    
    
    
    
    

# Generated at 2022-06-24 02:21:47.050577
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string('foo') == True
    assert is_full_string('') == False
    assert is_full_string(' ') == False



# Generated at 2022-06-24 02:21:50.433685
# Unit test for function is_number
def test_is_number():
    assert is_number('42')
    assert is_number('19.99')
    assert is_number('-9.12')
    assert is_number('1e3')
    assert not is_number('1 2 3')
    assert not is_number(42)



# Generated at 2022-06-24 02:21:56.643053
# Unit test for function is_url
def test_is_url():
    assert is_url("https://www.mysite.com")
    assert is_url("http://www.mysite.com")
    assert not is_url("www.mysite.com")
    assert not is_url("127.0.3.1")
    assert is_url("192.168.1.1")


# Generated at 2022-06-24 02:22:00.798369
# Unit test for function is_number
def test_is_number():
    print('Testing is_number')
    assert is_number('42')
    assert is_number('19.99')
    assert is_number('-9.12')
    assert is_number('1e3')
    assert is_number('1e-3')
    assert not is_number('1 2 3')
    print('Done')



# Generated at 2022-06-24 02:22:01.328682
# Unit test for function words_count
def test_words_count():
    assert words_count('Hello world') == 2



# Generated at 2022-06-24 02:22:06.884001
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf')
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True)
    assert not is_uuid('6f8aa2f9686c4ac387665712354a04cf')
    assert not is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=False)



# Generated at 2022-06-24 02:22:10.615403
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram("The quick brown fox jumps over the lazy dog") == True
    assert is_pangram("hello world") == False
test_is_pangram()



# Generated at 2022-06-24 02:22:16.516305
# Unit test for function is_full_string
def test_is_full_string():
    assert not is_full_string(None)
    assert not is_full_string('')
    assert not is_full_string(' ')
    assert is_full_string('hello')



# Generated at 2022-06-24 02:22:22.340742
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42') == True
    assert is_integer('42.0') == False
    assert is_integer('42.000') == False
    assert is_integer('1 2 3') == False



# Generated at 2022-06-24 02:22:25.986473
# Unit test for function is_pangram
def test_is_pangram():
    str = 'The quick brown fox jumps over the lazy dog'
    assert is_pangram(str) == True
    
    str = 'hello world'
    assert is_pangram(str) == False

test_is_pangram()
 


# Generated at 2022-06-24 02:22:31.833795
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('49927398716') == True
    assert is_credit_card('49927398717') == False
    assert is_credit_card('1234567812345678') == False
    assert is_credit_card('1234567812345670') == False
    assert is_credit_card('22210012341234') == True
    assert is_credit_card('22210012341234') == True
    assert is_credit_card('222100123412343') == False
    assert is_credit_card('378282246310005') == True
    assert is_credit_card('378282246310006') == False



# Generated at 2022-06-24 02:22:36.868047
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') # returns true
    assert is_isbn_10('150-6715214') # returns true
    assert is_isbn_10('150-6715214', normalize=False) == False


# Generated at 2022-06-24 02:22:38.451069
# Unit test for function is_string
def test_is_string():
    assert is_string('foo') == True
    assert is_string(b'foo') == False
    assert is_string(None) == False
test_is_string()


# Generated at 2022-06-24 02:22:47.393576
# Unit test for function is_url
def test_is_url():
	assert is_url('http://localhost:8080/test') == True
	assert is_url('http://wwww.polytech.univ-smb.fr') == True
	assert is_url('https://wwww.polytech.univ-smb.fr') == True
	assert is_url('http://wwww.polytech.univ-smb.fr') == True
	assert is_url('espace.polytech.univ-smb.fr/simple/simple') == True
	assert is_url('http://127.0.0.1:3000/api/products/search') == True
	assert is_url('https://127.0.0.1:3000/api/products/search') == True
	assert is_url('127.0.0.1:3000/api/products/search') == True


# Generated at 2022-06-24 02:22:53.578622
# Unit test for function is_json
def test_is_json():
    assert is_json(None) == False
    assert is_json("{}") == True
    assert is_json("[]") == True
    assert is_json("{\"name\": \"Peter\"}") == True
    assert is_json("[\"name\", \"Peter\"]") == True
    assert is_json("{\"name\" \"Peter\"}") == False
    assert is_json("{\"name\"}") == False
    assert is_json("name\" : \"Peter\"") == False



# Generated at 2022-06-24 02:22:57.672002
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214')
    assert is_isbn_10('150-6715214')
    assert not is_isbn_10('150-6715214', normalize=False)



# Generated at 2022-06-24 02:23:07.258215
# Unit test for function is_email
def test_is_email():
    assert is_email("my.email@the-provider.com")
    assert not is_email("@gmail.com")
    assert is_email("foo.bar+baz@bar.com")
    assert is_email("foo@bar.com")
    assert not is_email("foo@bar.c")
    assert not is_email("foo@bar.coh")
    assert not is_email("foo@bar.com,")
    assert not is_email("foo@bar.com.")
    assert not is_email("foo.bar@.com")
    assert not is_email("foo.bar@bar..com")
    assert is_email("foo+bar@the-provider.com")
    assert is_email("foo.bar@the-provider.com")

# Generated at 2022-06-24 02:23:16.237392
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case("MyString") == False
    assert is_snake_case("mystring") == False
    assert is_snake_case("my-string") == False
    assert is_snake_case("my_string") == True
    assert is_snake_case("_mystring") == False
    assert is_snake_case("mystring_") == False
    assert is_snake_case("my_string_to_check") == True
    assert is_snake_case("my-string-to-check") == True
    assert is_snake_case("my--string-to-check") == False
    assert is_snake_case("my-str1ng") == True
    assert is_snake_case("-my-string") == False

# Generated at 2022-06-24 02:23:19.921620
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42') == True
    assert is_integer('42.0') == False
    assert is_integer(42) == True
    
test_is_integer()



# Generated at 2022-06-24 02:23:23.922390
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75') == True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip('1.2.3') == False
test_is_ip()
 


# Generated at 2022-06-24 02:23:27.035353
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string(None) == False
    assert is_full_string('') == False
    assert is_full_string(' ') == False
    assert is_full_string('hello') == True

# Generated at 2022-06-24 02:23:31.155053
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('my string is <strong>bold</strong>') == True
    assert contains_html('my string is not bold') == False
test_contains_html()


# Generated at 2022-06-24 02:23:32.936330
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal(0)==False
    assert is_decimal(0.0)==True



# Generated at 2022-06-24 02:23:37.446696
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42') == True
    assert is_integer('-51') == True
    assert is_integer('-51.0') == False
    assert is_integer('51.') == False



# Generated at 2022-06-24 02:23:41.173310
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('otto') == True
    assert is_palindrome('Otto') == False
    assert is_palindrome('Otto', ignore_case=True) == True
    assert is_palindrome('I topi non avevano nipoti') == False
    assert is_palindrome('I topi non avevano nipoti', ignore_spaces=True) == True
    assert is_palindrome('ROTFL') == False
    assert is_palindrome('') == False
    assert is_palindrome('?#%!') == False
    assert is_palindrome(12345) == False

test_is_palindrome()

# Generated at 2022-06-24 02:23:46.968299
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True) == True
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') == False
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') == False
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') == False

# Generated at 2022-06-24 02:23:52.290034
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    assert __ISBNChecker('123').input_string == '123'
    assert __ISBNChecker('123', False).input_string == '123'
    assert __ISBNChecker('1-23').input_string == '123'
    assert __ISBNChecker('123-4', False).input_string == '123-4'


# Generated at 2022-06-24 02:23:56.608184
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('42.0')
    assert is_decimal('42.9')
    assert not is_decimal('42')
    assert not is_decimal('g')
# test_is_decimal()



# Generated at 2022-06-24 02:24:00.472984
# Unit test for function is_isogram
def test_is_isogram():
  assert is_isogram('lumberjacks')
  assert is_isogram('abcdefghijklmnopqrstuvwxyz')==True
  assert is_isogram('Hello World')==False
  assert is_isogram('')==True



# Generated at 2022-06-24 02:24:05.193649
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    assert __ISBNChecker('978-3-16-148410-0').input_string == '9783161484100'
    assert __ISBNChecker('9783161484100', normalize=False).input_string == '9783161484100'



# Generated at 2022-06-24 02:24:06.947114
# Unit test for function is_string
def test_is_string():
    assert is_string('foo') is True
    assert is_string(b'foo') is False


# Generated at 2022-06-24 02:24:11.874600
# Unit test for function words_count
def test_words_count():
    assert words_count('hello world') == 2
    assert words_count('one, two, three.stop') == 4
    assert words_count('! @ # % ... []') == 0
    assert words_count('hello', locale='en_US') == 1
    assert words_count('hello', locale='it_IT') == 1
    assert words_count('hello', locale='cs') == 1
    assert words_count('hello', locale='de_DE') == 1



# Generated at 2022-06-24 02:24:17.908281
# Unit test for function is_number
def test_is_number():
    assert(is_number('42') == True)
    assert(is_number('19.99') == True)
    assert(is_number('-9.12') == True)
    assert(is_number('1e3') == True)
    assert(is_number('1 2 3') == False)



# Generated at 2022-06-24 02:24:19.035443
# Unit test for function contains_html
def test_contains_html():
    assert contains_html("<b>Hello</b> <i>world</i>") == True
    print("Function works correctly")
test_contains_html()


# Generated at 2022-06-24 02:24:22.580951
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string('foo')
    assert is_full_string('F')
    assert not is_full_string('')
    assert not is_full_string('    ')
    assert not is_full_string(1)
    assert not is_full_string(None)



# Generated at 2022-06-24 02:24:28.281295
# Unit test for function is_string
def test_is_string():
    assert not is_string(None)
    assert not is_string(True)
    assert not is_string(False)
    assert not is_string(10)
    assert not is_string(10.10)
    assert not is_string(list())
    assert not is_string(dict())
    assert not is_string(b'foo')
    assert is_string('foo')


# Generated at 2022-06-24 02:24:39.838421
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    # Case 1: Input is correct
    checker = __ISBNChecker('5434534534534', True)
    assert checker.input_string == '543453453453'

    # Case 2: Input is not corrected
    try:
        checker = __ISBNChecker('5434534534534', False)
    except InvalidInputError:
        pass
    else:
        assert False, "Bad case."

    # Case 3: Input is empty
    try:
        checker = __ISBNChecker('', False)
    except InvalidInputError:
        pass
    else:
        assert False, "Bad case."

    # Case 4: Input is None
    try:
        checker = __ISBNChecker(None, False)
    except InvalidInputError:
        pass
    else:
        assert False

# Generated at 2022-06-24 02:24:42.891834
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    checker = __ISBNChecker(input_string='978-1-56619-909-4')

    if '9781566919094' != checker.input_string:
        return False

    return True

# PUBLIC API


# Generated at 2022-06-24 02:24:52.229054
# Unit test for function is_slug
def test_is_slug():
    for case, expected in [
        ('my-blog-post-title', True),
        ('My blog post title', False),
        ('-first-symbol-at-start-of-string', False),
        ('last-symbol-at-end-of-string-', False),
        ('unusual-char-_', False),
        ('unusual-char--', False),
        ('unusual-char--', False),
    ]:
        assert expected == is_slug(case)

# Generated at 2022-06-24 02:24:58.519157
# Unit test for function is_ip_v4
def test_is_ip_v4():
    print(is_ip_v4('255.200.100.75'))
    print(is_ip_v4('nope'))
    print(is_ip_v4('255.200.100.999'))

test_is_ip_v4()


# Generated at 2022-06-24 02:25:02.014121
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('') == False
    assert is_isbn_10('1506715214') == True
    assert is_isbn_10('150-6715214') == True
    assert is_isbn_10('150-6715214', normalize=False) == False
test_is_isbn_10()


# Generated at 2022-06-24 02:25:04.363318
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string(None) == False
    assert is_full_string('') == False
    assert is_full_string(' ') == False
    assert is_full_string('hello') == True

# ------------------------------------------------------------


# Generated at 2022-06-24 02:25:14.977696
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('1') == True
    assert is_integer('-1') == True
    assert is_integer('10') == True
    assert is_integer('-10') == True
    assert is_integer('9999') == True
    assert is_integer('-9999') == True
    assert is_integer('1234567890') == True
    assert is_integer('100000000000000000000') == True
    assert is_integer('0') == True
    assert is_integer('12.0') == False
    assert is_integer('12.3') == False
    assert is_integer('-12.3') == False
    assert is_integer('-12.0') == False
    assert is_integer('foo') == False
    assert is_integer('12+3') == False
    assert is_integer('1a') == False

# Generated at 2022-06-24 02:25:17.401468
# Unit test for function words_count
def test_words_count():
    assert words_count('hello world') == 2
    
    

# Generated at 2022-06-24 02:25:19.842393
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10("1506715214") == True
    assert is_isbn_10("150-6715214") == True
    assert is_isbn_10("150-6715214", normalize=False) == False
    assert is_isbn_10("0-0-00-00-0") == True

# Generated at 2022-06-24 02:25:28.723449
# Unit test for function is_palindrome
def test_is_palindrome():
    from random import randint
    from string import ascii_uppercase, digits

    random_string = ''.join([
        ascii_uppercase[randint(0, len(ascii_uppercase) - 1)],
        ascii_uppercase[randint(0, len(ascii_uppercase) - 1)],
        digits[randint(0, len(digits) - 1)],
        digits[randint(0, len(digits) - 1)]
    ])
    assert is_palindrome(random_string) is False
    assert is_palindrome(random_string, ignore_spaces=True) is False
    assert is_palindrome(random_string, ignore_case=True) is False

# Generated at 2022-06-24 02:25:31.642739
# Unit test for function is_full_string
def test_is_full_string():
    assert not is_full_string(None)
    assert not is_full_string('')
    assert not is_full_string(' ')

    assert is_full_string('hello')


# Generated at 2022-06-24 02:25:36.341798
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title') # returns true
    assert is_slug('My blog post title') # returns false

test_is_slug()


# Generated at 2022-06-24 02:25:46.244525
# Unit test for function is_palindrome
def test_is_palindrome():
    assert(is_palindrome('otto') is True)
    assert(is_palindrome('elemelamele') is True)
    assert(is_palindrome('ROTFL') is False)
    assert(is_palindrome('Otto') is False)
    assert(is_palindrome('Otto', ignore_case=True) is True)
    assert(is_palindrome('i topi non avevano nipoti') is True)
    assert(is_palindrome('i topi non avevano nipoti', ignore_spaces=True) is False)
    assert(is_palindrome('Ot:to') is False)

# Generated at 2022-06-24 02:25:56.241132
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('-1') is True
    assert is_integer('0') is True
    assert is_integer('1') is True
    assert is_integer('2') is True
    assert is_integer('+2') is True
    assert is_integer('-1e1') is True
    assert is_integer('2e2') is True
    assert is_integer('+2e+2') is True
    assert is_integer('-1.0') is False
    assert is_integer('0.0') is False
    assert is_integer('1.0') is False
    assert is_integer('2.0') is False
    assert is_integer('+2.0') is False
    assert is_integer('-1e1.0') is False
    assert is_integer('2e2.0') is False

# Generated at 2022-06-24 02:25:58.174333
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog')
    assert not is_pangram('hello world')



# Generated at 2022-06-24 02:26:04.303328
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42') == True
    assert is_integer('42.0') == False
    assert is_integer('42.1') == False
    assert is_integer('42hello') == False
    assert is_integer('-42') == True
    assert is_integer('-42.0') == False
    assert is_integer(' -42.0') == False
    assert is_integer('-42.1') == False
    assert is_integer('-42hello') == False
    assert is_integer('+42') == True
    assert is_integer('+42.0') == False
    assert is_integer(' +42.0') == False
    assert is_integer('+42.1') == False
    assert is_integer('+42hello') == False
    assert is_integer(' ') == False
    assert is_integer

# Generated at 2022-06-24 02:26:08.917393
# Unit test for function is_isbn
def test_is_isbn():
  assert is_isbn('9780312498580') == True
  assert is_isbn('1506715214') == True
  
  assert is_isbn('9780312498580', False) == True
  assert is_isbn('1506715214', False) == True

  assert is_isbn('978-0312498580') == True
  assert is_isbn('150-6715214') == True

  assert is_isbn('978-0312498580', False) == False
  assert is_isbn('150-6715214', False) == False
test_is_isbn()


# Generated at 2022-06-24 02:26:10.944782
# Unit test for function is_string
def test_is_string():
    assert is_string(str) == True
    assert is_string('str') == True
    assert is_string(b'str') == False


# Generated at 2022-06-24 02:26:17.853971
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email+alias@the-provider.com')
    assert is_email('my.email@subdomain.the-provider.com')
    assert is_email('my.email@subdomain.subdomain.the-provider.com')
    assert is_email('my.email@subdomain.subdomain.subdomain.the-provider.com')
    assert is_email('"my.email"@subdomain.subdomain.subdomain.the-provider.com')
    assert is_email('"my.e\\ mail"@subdomain.subdomain.subdomain.the-provider.com')

# Generated at 2022-06-24 02:26:21.073077
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214')==True
    assert is_isbn_10('150-6715214')==True
    assert is_isbn_10('150-6715214', normalize=False)==False
test_is_isbn_10()



# Generated at 2022-06-24 02:26:30.419421
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('LOL')
    assert not is_palindrome('Lol')
    assert is_palindrome('Lol', ignore_case=True)
    assert not is_palindrome('ROTFL')
    assert is_palindrome('i topi non avevano nipoti')
    assert is_palindrome('radar')
    assert not is_palindrome('radr')
    assert not is_palindrome('radar', ignore_case=True)
    assert is_palindrome('', strict=False)
    assert is_palindrome('radar', ignore_spaces=False)
    assert is_palindrome('i topi non avevano nipoti', ignore_spaces=False)


# Generated at 2022-06-24 02:26:36.467167
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title')
    assert not is_slug('My blog post title')
    assert not is_slug('my/blog/post/title')
    assert not is_slug('my_blog_post_title')

    assert is_slug('my_blog_post_title', separator='_')
    assert not is_slug('my-blog-post-title', separator='_')


# Generated at 2022-06-24 02:26:38.915162
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4("255.200.100.75")
    assert not is_ip_v4("nope")
    assert not is_ip_v4("255.200.100.999")
test_is_ip_v4()



# Generated at 2022-06-24 02:26:41.257645
# Unit test for function is_uuid
def test_is_uuid():
    uuid_ok = '6f8aa2f9-686c-4ac3-8766-5712354a04cf'
    uuid_ko = '6f8aa2f9686c4ac387665712354a04cf'

    assert is_uuid(uuid_ok)
    assert not is_uuid(uuid_ko)
    assert is_uuid(uuid_ko, True)



# Generated at 2022-06-24 02:26:44.535259
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75') == True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip('1.2.3') == False



# Generated at 2022-06-24 02:26:49.859062
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('NSString')
    assert is_camel_case('nsString')
    assert is_camel_case('UUID')
    assert is_camel_case('aBc')
    assert is_camel_case('aBc123')
    assert not is_camel_case('ns_string')
    assert not is_camel_case('123')
    assert not is_camel_case(1)
    assert not is_camel_case('')
    assert not is_camel_case(' ')



# Generated at 2022-06-24 02:26:52.383564
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    assert __ISBNChecker('978-0-306-40615-7').is_isbn_13()
    assert __ISBNChecker('0-306-40615-2').is_isbn_10()



# Generated at 2022-06-24 02:26:56.202088
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4("255.200.100.75") == True
    assert is_ip_v4("nope") == False
    assert is_ip_v4("255.200.100.999") == False
    assert is_ip_v4("") == False
    assert is_ip_v4(None) == False


# Generated at 2022-06-24 02:27:03.342357
# Unit test for function is_ip_v6
def test_is_ip_v6():
    print(is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334')) # returns true
    print(is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?')) # returns false (invalid "?")

test_is_ip_v6()

# Generated at 2022-06-24 02:27:09.273686
# Unit test for function is_string
def test_is_string():
    assert is_string("")
    assert is_string("  ")
    assert is_string("Foo")
    assert is_string("Foo bar")
    assert not is_string(b"Foo bar")
    assert not is_string(5)
    assert not is_string(5.5)
    assert not is_string(None)
    assert not is_string(True)
    assert not is_string(False)
    assert not is_string([])
    assert not is_string({})
    assert not is_string(())



# Generated at 2022-06-24 02:27:10.659269
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog') == True
    assert is_pangram('hello world') == False
test_is_pangram()

# Generated at 2022-06-24 02:27:12.759973
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog') == True
    assert is_pangram("abcdefghijklmnopqrstuvwxyz") == True
    assert is_pangram("") == False
    assert is_pangram("Hello, World!") == False

test_is_pangram()


# Generated at 2022-06-24 02:27:20.422954
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('') == False
    assert is_snake_case('  ') == False
    assert is_snake_case(' ') == False
    assert is_snake_case(None) == False
    assert is_snake_case(1) == False
    assert is_snake_case('1') == False
    assert is_snake_case('myString') == False
    assert is_snake_case('my_string') == True
    assert is_snake_case('_my_string') == True
    assert is_snake_case('my_String') == True
    assert is_snake_case('my_string_') == True
    assert is_snake_case('my_string_123') == True

# Generated at 2022-06-24 02:27:32.395764
# Unit test for function is_isbn_10
def test_is_isbn_10():
  assert is_isbn_10('1118335901') == True
  assert is_isbn_10('111-833590-1') == True
  assert is_isbn_10('11183-3590-1') == True
  assert is_isbn_10('11183-3590-4') == False
  assert is_isbn_10('1118335991') == False
  assert is_isbn_10('1118335901', normalize=False) == True
  assert is_isbn_10('111-833590-1', normalize=False) == False
  assert is_isbn_10('11183-3590-1', normalize=False) == False
  assert is_isbn_10('11183-3590-4', normalize=False) == False
  assert is_isbn_

# Generated at 2022-06-24 02:27:37.364800
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('MyString')
    assert not is_camel_case('mystring')
    assert not is_camel_case('My_string')
    assert not is_camel_case('.1MyString')
    assert not is_camel_case('1MyString@')


# Generated at 2022-06-24 02:27:43.655410
# Unit test for function is_isbn
def test_is_isbn():
    import sys
    import io
    old_stdout = sys.stdout
    sys.stdout = mystdout = io.StringIO()
    text = is_isbn('978-0312498580')
    print(text)
    sys.stdout = old_stdout
    assert mystdout.getvalue() == 'True\n'

test_is_isbn()

# Generated at 2022-06-24 02:27:48.944716
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('') == False
    assert is_isbn('978-0-13-426623-2') == True
    assert is_isbn('978-0-13-426623-2', normalize=False) == True
    assert is_isbn('978-0-13-426623-21', normalize=False) == False
    assert is_isbn('978-0312498580') == True
    assert is_isbn('1506715214') == True



# Generated at 2022-06-24 02:27:58.900602
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome("") == False
    assert is_palindrome("a") == True
    assert is_palindrome("aba") == True
    assert is_palindrome("abc") == False
    assert is_palindrome("abcdcba") == True
    assert is_palindrome("[""cba") == False
    assert is_palindrome("abba") == True
    assert is_palindrome("aba", ignore_case=True) == True
    assert is_palindrome("abBa") == False
    assert is_palindrome("abBa", ignore_case=True) == True
    assert is_palindrome("ab     Ba") == False
    assert is_palindrome("ab     Ba", ignore_spaces=True) == True

# Generated at 2022-06-24 02:28:02.697287
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') == True
    assert is_url('https://www.mysite.com') == True
    assert is_url('https://mysite.com') == True
    assert is_url('ftp://mysite.com') == True
    assert is_url('.mysite.com') == False
    
test_is_url()



# Generated at 2022-06-24 02:28:08.799004
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1,2, 3]') == True
    assert is_json('{nope}') == False                

# Generated at 2022-06-24 02:28:15.496314
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram("Dermatoglyphics")
    assert is_isogram("isogram")
    assert is_isogram("aba")
    assert is_isogram("moOse")
    assert is_isogram("isIsogram")
    assert is_isogram("")

    assert not is_isogram("moose")
    assert not is_isogram("isIsogram" )
    assert not is_isogram("aba" )
    assert not is_isogram("moOse")
    assert not is_isogram("thumbscrew-japingly")
    assert not is_isogram("six-year-old")
    assert not is_isogram("Emily Jung Schwartzkopf")

# Generated at 2022-06-24 02:28:23.112841
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title')
    assert is_slug('my-blog-post-title', '_')
    assert not is_slug('My blog post title')
    assert not is_slug('', '_')

# Generated at 2022-06-24 02:28:27.665927
# Unit test for function is_uuid
def test_is_uuid():

    # Create a random UUID
    r = uuid.uuid4()

    assert True == is_uuid(r, allow_hex=True)
    assert False == is_uuid(r)



# Generated at 2022-06-24 02:28:37.614801
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214')
    assert is_isbn_10('150-6715214')
    assert not is_isbn_10('150-6715214', normalize=False)
    assert not is_isbn_10('978-1-56975-489-2')
    assert not is_isbn_10('978-156975-489-2')
    assert not is_isbn_10('9781569754892')
    assert not is_isbn_10('9971502100')
    assert not is_isbn_10('9971502109')
    assert not is_isbn_10('9971502100', normalize=False)
    assert not is_isbn_10('9971502109', normalize=False)
    assert not is_isbn_

# Generated at 2022-06-24 02:28:42.178451
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('9780262510875').is_isbn_13()
    assert __ISBNChecker('9780262510870').is_isbn_13()
    assert not __ISBNChecker('9780262510871').is_isbn_13()



# Generated at 2022-06-24 02:28:49.452218
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?') == False
    assert is_ip_v6('2001:db8:85a3:0000:0000::7334') == True


# Generated at 2022-06-24 02:28:54.228669
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf')
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True)
    assert not is_uuid('6f8aa2f9686c4ac387665712354a04cf')

test_is_uuid()



# Generated at 2022-06-24 02:28:57.187103
# Unit test for function words_count
def test_words_count():
    assert words_count('hello world') == 2
    assert words_count('one,two,three.stop') == 4



# Generated at 2022-06-24 02:29:03.718901
# Unit test for function is_ip
def test_is_ip():
    assert(is_ip('255.255.255.255'))
    assert(is_ip('26.15.10.8'))
    assert(is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334'))
    assert(not is_ip('1.2.3'))
test_is_ip()

# Generated at 2022-06-24 02:29:14.528580
# Unit test for function is_decimal
def test_is_decimal():
    assert(is_decimal('42.0') == True)
    assert(is_decimal('42') == False)
    assert(is_decimal('42.0.0') == False)
    assert(is_decimal('42.0e') == False)
    assert(is_decimal('42.0e2') == True)
    assert(is_decimal('42.0e2.2') == False)
    assert(is_decimal('4') == False)
    assert(is_decimal('4.0') == True)
    assert(is_decimal('4.0e2') == True)
test_is_decimal()


# Generated at 2022-06-24 02:29:22.461841
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal("3.14") == True
    assert is_decimal("-3.14") == True
    assert is_decimal("314E-2") == True
    assert is_decimal("0.0314E+2") == True
    assert is_decimal("3.14more non-digit characters") == False
    assert is_decimal("  3.14") == False
    assert is_decimal("3.14  ") == False
    assert is_decimal("") == False
    assert is_decimal(".") == False
    assert is_decimal("+.8") == False
    assert is_decimal("3.") == False
    assert is_decimal("3.14.15") == False
    assert is_decimal("-") == False
    assert is_decimal("-.") == False


# Generated at 2022-06-24 02:29:26.935227
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('my string is <strong>bold</strong>')
    assert not contains_html('my string is not bold')



# Generated at 2022-06-24 02:29:36.508720
# Unit test for function is_number
def test_is_number():
    assert is_number("42")
    assert is_number("19.99")
    assert is_number("-9.12")
    assert is_number("1e3")
    assert is_number("-9.12")
    assert not is_number("1 2 3")



# Generated at 2022-06-24 02:29:39.660801
# Unit test for function is_isbn_13
def test_is_isbn_13():
    try:
        isbn13 = '9780312498580'
        assert is_isbn_13(isbn13) == True
    except AssertionError:
        print('test_is_isbn_13: test failed')
    else:
        print('test_is_isbn_13: test successed')
test_is_isbn_13()


# Generated at 2022-06-24 02:29:47.879416
# Unit test for function is_uuid