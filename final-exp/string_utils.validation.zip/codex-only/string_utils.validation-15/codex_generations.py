

# Generated at 2022-06-24 02:19:53.251696
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    # len input_string == 13
    try:
        __ISBNChecker("978-0-306-40615-7")
    except:
        assert False

    # len input_string == 13
    try:
        __ISBNChecker("030640615X")
    except:
        assert False

    # len input_string == 10
    try:
        __ISBNChecker("0-306-40615-X")
    except:
        assert False

    # len input_string == 10
    try:
        __ISBNChecker("022630112X")
    except:
        assert False

    # len input_string != 10, 13
    try:
        __ISBNChecker("022630112")
        assert False
    except:
        pass

    # input_string is not a string

# Generated at 2022-06-24 02:20:00.610320
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75') == True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip('1.2.3') == False
    assert is_ip('255.200.100.75') == True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip('1.2.3') == False



# Generated at 2022-06-24 02:20:02.844535
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string(' ') == False
    assert is_full_string('a') == True

# End test



# Generated at 2022-06-24 02:20:04.413338
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title') == True
    assert is_slug('My blog post title') == False
    assert is_slug('my_blog_post_title',separator='_') == True
    
    
test_is_slug()



# Generated at 2022-06-24 02:20:14.672383
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') == True
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf', allow_hex = True) == False
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex = True) == True
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf') == False
    assert is_uuid('6f8aa2f9686c4ac387665712354a04c') == False


# Generated at 2022-06-24 02:20:23.391596
# Unit test for function is_isbn_10
def test_is_isbn_10():
    for input_string in ['150-6715214', '1-50671-521-4', '1506715214', '0-7475-3269-9', '1-4169-5299-1',
                         '0-7475-3269-9, 0-7475-3269-0, 0-7475-3269-X', '1-4169-5299-5, 1-4169-5299-3']:
        assert is_isbn_10(input_string)



# Generated at 2022-06-24 02:20:35.463493
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:8d3:1319:8a2e:370:7348') == True
    assert is_ip_v6('2001:db8:85a3:0:0:8a2e:370:7348') == True
    assert is_ip_v6('2001:db8:85a3:8d3::1319:8a2e:370:7348') == True
    assert is_ip_v6('2001:db8:85a3:8d3:1319:8a2e:370:7348/64') == True
    assert is_ip_v6('2001:db8:85a3:8d3:1319:8a2e:370:7348::') == False

# Generated at 2022-06-24 02:20:39.840554
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog') == True
    assert is_pangram('hello world') == False
    assert is_pangram('This is the longest pangram in the World!') == True
    assert is_pangram('abcdefghijklmnopqrstuvwxyz') == True
    assert is_pangram('') == False
    assert is_pangram('a') == False

test_is_pangram()

# Generated at 2022-06-24 02:20:50.519025
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    # Set up
    def __test_match(test_input: str, expected: bool):
        actual = __ISBNChecker(test_input)
        assert expected == actual.is_isbn_13()

    def __test_not_match(test_input: str):
        actual = __ISBNChecker(test_input)
        assert False == actual.is_isbn_13()

    def __test_match_multi(test_inputs: List[str], expected: bool):
        for test_input in test_inputs:
            __test_match(test_input, expected)

    def __test_not_match_multi(test_inputs: List[str]):
        for test_input in test_inputs:
            __test_not_match(test_input)

    # Expected to match
    test

# Generated at 2022-06-24 02:20:52.005647
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal("42.0")
    assert not is_decimal("42")



# Generated at 2022-06-24 02:20:58.225375
# Unit test for function is_snake_case
def test_is_snake_case():
    assert not is_snake_case('')
    assert not is_snake_case('foo')
    assert not is_snake_case('FOO_BAR')
    assert is_snake_case('foo_bar')
    assert not is_snake_case('foo_')
    assert not is_snake_case('_foo')
    assert not is_snake_case(u'föö_bär')
    assert is_snake_case('foo_bar_1')
    assert not is_snake_case('foo_bar_')
    assert not is_snake_case('_foo_bar')
    assert is_snake_case('foo_bar_baz')
    assert is_snake_case('foo_bar_baz_1')
    assert not is_snake_case

# Generated at 2022-06-24 02:21:07.475445
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    assert __ISBNChecker('0747532699').__dict__ == {'input_string': '0747532699'}
    assert __ISBNChecker('978-3-13-148410-0').__dict__ == {'input_string': '9783131484100'}
    assert __ISBNChecker('3-13-148410-0').__dict__ == {'input_string': '3131484100'}
    assert __ISBNChecker('312-148410-0', normalize=False).__dict__ == {'input_string': '312-148410-0'}

test___ISBNChecker()



# Generated at 2022-06-24 02:21:12.806894
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580')
    assert is_isbn('978-0312498580')
    assert is_isbn('9780312498580', normalize=False)
    assert not is_isbn('978-0312498580', normalize=False)
    assert is_isbn('1506715214')
    assert is_isbn('150-6715214')
    assert is_isbn('150-6715214', normalize=False)
    assert not is_isbn('1506715214', normalize=False)


# Generated at 2022-06-24 02:21:19.885100
# Unit test for function is_isbn_10
def test_is_isbn_10():
    results = [False, True, True, False, True, False, True, False, True, True, False, False, False, False]
    items = ['4506715214', '1506715214', '150-6715214', '150/6715214', '1596176725',
             '1596176721', '345-337866881', '978-345-33786688', '978-345-337866881',
             '3-8266-7274-7', '3-8266-7274-X', '3-8266-7274-0', '3-8266-72748', '3-8266-72747']
    for item, expected_result in zip(items, results):
        assert is_isbn_10(item, False) == expected_result

# Generated at 2022-06-24 02:21:24.180500
# Unit test for function is_uuid
def test_is_uuid():
    print("test_is_uuid")

# Generated at 2022-06-24 02:21:26.917989
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-3-16-148410-0').is_isbn_13() == True
    assert __ISBNChecker('978-3-16-148410-1').is_isbn_13() == False


# Generated at 2022-06-24 02:21:29.707903
# Unit test for function is_number
def test_is_number():
    assert(is_number('42') == True)
    assert(is_number('19.99') == True)
    assert(is_number('-9.12') == True)
    assert(is_number('1e3') == True)
    assert(is_number('1 2 3') == False)
test_is_number()


# Generated at 2022-06-24 02:21:38.672967
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title')
    assert is_slug('my-blog-post-title', separator='_')
    assert is_slug('my-blog-post-title', separator='-')
    assert not is_slug('My blog post title')
    assert not is_slug('My-blog-post-title')
    assert not is_slug('My  blog-post-title')
    assert not is_slug('My-blog-post-title ')
    assert not is_slug('')



# Generated at 2022-06-24 02:21:49.811206
# Unit test for function is_slug
def test_is_slug():
    positive_tests = ['abc', 'abc-def-hij-klm', 'abc-123', '------------', 'abc-123-xyc', 'a', 'ab', 'a-b']
    negative_tests = ['', '1', '1-2-3', 'one-two-three', 'abcd-efgh-ijklm-', 'a-2', 'a-b-c-1', 'a-b-c-1-2']

    for value in positive_tests:
        assert is_slug(value)

    for value in negative_tests:
        assert not is_slug(value)
test_is_slug()



# Generated at 2022-06-24 02:21:54.564757
# Unit test for function is_number
def test_is_number():
    assert is_number(None)   == False
    assert is_number([])     == False
    assert is_number('42')   == True
    assert is_number('-19.99') == True
    assert is_number('-9.12')  == True
    assert is_number('1e3')    == True
    assert is_number('1 2 3')  == False
    assert is_number('')       == False
    print('Function is_number passed all test.')

# Generated at 2022-06-24 02:22:03.230070
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog')
    assert is_pangram('This Pangram contains four As, one B, two Cs, one D, thirty Es, six Fs, five Gs, \
            seven Hs, eleven Is, one J, one K, two Ls, two Ms, eighteen Ns, fifteen Os, two Ps, one Q, \
            five Rs, twenty-seven Ss, eighteen Ts, two Us, seven Vs, eight Ws, two Xs, three Ys, \
            & one Z.')
    assert not is_pangram('Hello, world!')
    assert not is_pangram('')
    assert not is_pangram(1234)
    assert not is_pangram(None)

test_is_pangram()


# Generated at 2022-06-24 02:22:10.449180
# Unit test for function is_uuid
def test_is_uuid():
    # We cannot use a default value in pytest as it has to be a "static value"
    is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') == True
    is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True) == True
    is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') == False
    is_uuid('6f8aa2f9686c4ac387665712354a04cf') == False
    is_uuid('6f8aa2f968-6c4ac3-8766-5712354a04cf') == False

# Generated at 2022-06-24 02:22:18.671062
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome("otto") == True
    assert is_palindrome("i topi non avevano nipoti") == True
    assert is_palindrome("i topi non avevano nipoti", ignore_spaces=True) == False
    assert is_palindrome("i topi non avevano nipoti", ignore_case=True) == True

test_is_palindrome()


# Generated at 2022-06-24 02:22:23.565409
# Unit test for function contains_html
def test_contains_html():
    print("test_contains_html")
    assert not contains_html("my string is not bold")
    assert contains_html("my string is <strong>bold</strong>")
test_contains_html()

contains_html("my string is <strong>bold</strong>")


# Generated at 2022-06-24 02:22:27.815113
# Unit test for function is_json
def test_is_json():
    print("Testing function is_json...", end="")
    assert is_json('{"name": "Peter"}') # returns true
    assert is_json('[1, 2, 3]') # returns true
    assert not is_json('{nope}') # returns false
    assert not is_json('') # returns false
    assert not is_json(None) # returns false
    print("Passed!")

test_is_json()



# Generated at 2022-06-24 02:22:33.629223
# Unit test for function is_slug
def test_is_slug():
    assert(is_slug('my-blog-post-title') is True)
    assert(is_slug('My blog post title') is False)
test_is_slug()


# Generated at 2022-06-24 02:22:38.337293
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') == True
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf') == False
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True) == True
test_is_uuid()



# Generated at 2022-06-24 02:22:48.445852
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('my_string') == True
    assert is_snake_case('My_string') == True
    assert is_snake_case('my-string') == False
    assert is_snake_case('my.string') == False
    assert is_snake_case('12345') == False
    assert is_snake_case('1mystring') == True
    assert is_snake_case('my_string_1') == True
    assert is_snake_case('my_string_') == False
    assert is_snake_case('_my_string') == False
    assert is_snake_case('my_string_') == False
    assert is_snake_case('my__string') == False
    assert is_snake_case('my-string') == False

# Generated at 2022-06-24 02:22:56.587021
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13("978-1506715214")==True
    assert is_isbn_13("1506715214")==False
    assert is_isbn_13("150-6715214",normalize=False)==False
    assert is_isbn_13("9780312498580")==True
    assert is_isbn_13("978-0312498580")==True
    assert is_isbn_13("978-0312498580",normalize=False)==False
    assert is_isbn_13("9780312498580")==True
    assert is_isbn_13("9780312498580")==True
    assert is_isbn_13("9780312498580")==True
    assert is_isbn_13("9780312498580")==True


# Generated at 2022-06-24 02:23:02.840820
# Unit test for function is_string
def test_is_string():
    assert is_string('Hello World')
    assert is_string('12345')
    assert is_string('True')
    assert is_string('False')
    assert is_string('None')
    assert is_string('')
    assert not is_string(b'12345')
    assert not is_string(12345)
    assert not is_string(True)
    assert not is_string(False)
    assert not is_string(None)
    print('Testing function is_string: Passed')


# Generated at 2022-06-24 02:23:10.253419
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6("::1")
    assert is_ip_v6("fe80:0000:0000:0000:0204:61ff:fe9d:f156")
    assert is_ip_v6("2001:db8::1")
    assert is_ip_v6("0000:0000:0000:0000:0000:0000:0000:0001")
    assert is_ip_v6("2001:db8:0000:1:1:1:1:1")
    assert is_ip_v6("2001:DB8:0000:1:1:1:1:1")
    assert is_ip_v6("2001:db8::")
    assert is_ip_v6("2001:db8:0:0:0:0:2:1")

# Generated at 2022-06-24 02:23:12.603510
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('1234567890123').is_isbn_13()
    assert not __ISBNChecker('1234567890122').is_isbn_13()



# Generated at 2022-06-24 02:23:24.053143
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4111111111111111') is True
    assert is_credit_card('4000 1234 5678 9123') is True
    assert is_credit_card('4000-1234-5678-9123') is True
    assert is_credit_card('4000.1234.5678.9123') is True
    assert is_credit_card('4000 1234 5678 912') is False
    assert is_credit_card('4000-1234-5678-912') is False
    assert is_credit_card('4000.1234.5678.912') is False
    assert is_credit_card('41111111111111111') is False
    assert is_credit_card('411111111111111') is False
    assert is_credit_card('411111111111') is False
    assert is_credit_

# Generated at 2022-06-24 02:23:31.501989
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title')
    assert is_slug('my-blog-post-title', '-')
    assert is_slug('my_blog_post_title', '_')
    assert is_slug('my-blog-post title') == False
    assert is_slug('My blog post title', '-') == False
    assert is_slug('My blog post title') == False
    assert is_slug('') == False
    assert is_slug(' ') == False
    assert is_slug('my__blog_post_title', '_')
    assert is_slug('my__blog_post_title', '') == False
    assert is_slug('my__blog_post_title') == False

# Generated at 2022-06-24 02:23:36.747624
# Unit test for function is_credit_card
def test_is_credit_card():
    c_visa = '4417119669820331'
    c_visa_short = '441711'
    c_visa_long = '44171196698203311'
    c_master = '5168361787375407'
    c_master_short = '516836'
    c_master_long = '51683617873754071'
    c_american = '342401974382691'
    c_american_short = '342401'
    c_american_long = '3424019743826911'
    c_diners = '305516473435745'
    c_diners_short = '305516'
    c_diners_long = '3055164734357451'

# Generated at 2022-06-24 02:23:38.645595
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string(None) == False
    assert is_full_string('') == False
    assert is_full_string(' ') == False
    assert is_full_string('hello') == True



# Generated at 2022-06-24 02:23:42.552518
# Unit test for function is_url
def test_is_url():
    """
    :return: boolean
    """
    url = "http://www.facebook.com"
    return is_url(url) == True


# Generated at 2022-06-24 02:23:47.681942
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75') == True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip('1.2.3') == False
    print('Test is_ip passed!')
    
test_is_ip()


# Generated at 2022-06-24 02:23:59.600912
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4111111111111111')
    assert is_credit_card('5500000000000004')
    assert is_credit_card('340000000000009')
    assert is_credit_card('30000000000004')
    assert is_credit_card('6011000000000004')
    assert is_credit_card('3088000000000004')
    assert not is_credit_card('0000000000000000')
    assert not is_credit_card('4111111111111112')
    assert not is_credit_card('3400000000000091')
    assert not is_credit_card('6011000000000011')
    # Visa
    assert is_credit_card('4111111111111111', card_type='VISA')
    # MasterCard
    assert is_credit_card('5500000000000004', card_type='MASTERCARD')

# Generated at 2022-06-24 02:24:03.496716
# Unit test for function is_json
def test_is_json():
    assert is_json("{'name':'Peter'}") is False
    assert is_json("{\"name\":\"Peter\"}") is True
    assert is_json("[1,2,3]") is True



# Generated at 2022-06-24 02:24:13.613319
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42') is True
    assert is_integer('42.0') is False
    assert is_integer('-42') is True
    assert is_integer('-42.0') is False
    assert is_integer('+42') is True
    assert is_integer('+42.0') is False
    assert is_integer('1e9') is True
    assert is_integer('-1e9') is True
    assert is_integer('1e9.0') is False
    assert is_integer('-1e9.0') is False
    assert is_integer('+1e9') is True
    assert is_integer('+1e9.0') is False
    assert is_integer('42.0') is False
    assert is_integer('-42.0') is False

# Generated at 2022-06-24 02:24:22.459901
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('foo_bar_baz', '_') == True
    assert is_snake_case('foo') == False
    assert is_snake_case('foo-bar-baz', '-') == True
    assert is_snake_case('foo-bar-baz') == False
    assert is_snake_case('foo_bar-baz', '-') == False
    assert is_snake_case('foo-bar_baz') == False
    assert is_snake_case('FOO-bar-baz', '-') == False

# Generated at 2022-06-24 02:24:24.029319
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42') is True
    assert is_integer('42.0') is False


# Generated at 2022-06-24 02:24:25.770810
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('43') is True
    assert is_integer('4.4') is False


# Generated at 2022-06-24 02:24:32.475811
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert(is_ip_v4('255.0.0.0') == True)
    assert(is_ip_v4('0.0.0.0') == True)
    assert(is_ip_v4('255.255.255.255') == True)
    assert(is_ip_v4('192.168.1.1') == True)
    assert(is_ip_v4('10.10.10.10') == True)
    assert(is_ip_v4('135.23.65.5') == True)
    assert(is_ip_v4('135.23.65.5 ') == True)
    assert(is_ip_v4(b'135.23.65.5') == True)

# Generated at 2022-06-24 02:24:42.965733
# Unit test for function is_isbn_10
def test_is_isbn_10():
    isbn_10_1_normalize_true = is_isbn_10('5-21-564-775-7')
    isbn_10_1_normalize_false = is_isbn_10('5-21-564-775-7', normalize=False)
    isbn_10_2_normalize_true = is_isbn_10('5215647757')
    isbn_10_2_normalize_false = is_isbn_10('5215647757', normalize=False)
    unit_test_utils.assert_true(isbn_10_1_normalize_true)
    unit_test_utils.assert_true(isbn_10_2_normalize_true)
    unit_test_utils.assert_false(isbn_10_1_normalize_false)

# Generated at 2022-06-24 02:24:55.028322
# Unit test for function is_isbn_10
def test_is_isbn_10():
    # Some valid ISBNs
    assert is_isbn_10('0471958697')
    assert is_isbn_10('0-321-14653-0')
    assert is_isbn_10('877 1 95 869x')
    assert is_isbn_10('0-8044-2957-X')
    assert is_isbn_10('0-9752298-0-X')
    assert is_isbn_10('978-0-306-40615-7')
    assert is_isbn_10('978 0 306 40615 7')
    assert is_isbn_10('7-111-22811-6')
    assert is_isbn_10('7-111-22811-x')
    assert is_isbn_10('7-111-22811-X')
    assert is_isbn

# Generated at 2022-06-24 02:25:01.995095
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}')
    assert is_json('[1, 2, 3]')
    assert not is_json('{nope}')
    assert is_json('{"_id": {"$oid": "5e47283b8a0f920a3bc3e0bc"}}')


# Generated at 2022-06-24 02:25:04.143613
# Unit test for function is_isbn_13
def test_is_isbn_13():
    print("Testing is_isbn_13()...")
    assert is_isbn_13("1566195614") == True
    assert is_isbn_13("978-1566195614") == True
    assert is_isbn_13("978-156619561") == False
    print("passed\n")


# Generated at 2022-06-24 02:25:10.881795
# Unit test for function is_isogram
def test_is_isogram():
    empty_string1 = ''
    empty_string2 = ' '
    string_true = 'dermatoglyphics'
    string_false = 'hello'
    string_false_numbers = '12345'
    string_false_mixed = 'hello 123'
    string_true_mixed = 'thumbscrew-japingly'
    string_false_mixed_spaces = 'moOse'
    string_false_symbols = 'moOse$%^&@'
    string_true_non_standard = 'Ĵaŭdeńskì'
    
    assert is_isogram(empty_string1), 'empty string 1'
    assert not is_isogram(empty_string2), 'empty string 2'
    assert is_isogram(string_true), 'string true'


# Generated at 2022-06-24 02:25:14.968381
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram(None) is False
    assert is_pangram('') is False
    assert is_pangram('hello world') is False
    assert is_pangram('The quick brown fox jumps over the lazy dog') is True
    assert is_pangram('Bored? Craving a pub quiz fix? Why, just come to the Royal Oak!') is True
    assert is_pangram('The quick brown fox jumped over the lazy dog') is False
    assert is_pangram('The five boxing wizards jump quickly') is True
    assert is_pangram('The quick fox jumps over the lazy dog.') is True
    assert is_pangram('_hyph_') is False
    assert is_pangram('-hyph-') is False

# Generated at 2022-06-24 02:25:23.022891
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('this_is_snake_case') == True
    assert is_snake_case('this-is-dash-snake-case') == True
    assert is_snake_case('this_is_wrong_snake_case') == False
    assert is_snake_case('this_is_wrong-snake-case') == False
    assert is_snake_case('this_is_wrong-snake-case', separator='-') == True
    assert is_snake_case('this_is_wrong_snake-case', separator='-') == True
    assert is_snake_case('this_is_wrong_snake-case') == False



# Generated at 2022-06-24 02:25:25.612930
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title')
    assert is_slug('My blog post title', '_')
    assert not is_slug('My blog post title')



# Generated at 2022-06-24 02:25:27.093721
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('42.0')
    assert not is_decimal('42')



# Generated at 2022-06-24 02:25:36.701611
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid(UUID_VALID_NPM)
    assert is_uuid(UUID_VALID_PYTHON)
    assert is_uuid(UUID_VALID_JAVA)
    assert is_uuid(UUID_VALID_JAVA_HEX)
    assert is_uuid(UUID_VALID_C)
    assert is_uuid(UUID_VALID_CSHARP)
    assert is_uuid(UUID_VALID_GO)
    assert is_uuid(UUID_VALID_JAVASCRIPT)
    assert is_uuid(UUID_VALID_NODE)
    assert is_uuid(UUID_VALID_RUBY)
    assert is_uuid(UUID_VALID_RUST)


# Generated at 2022-06-24 02:25:47.882834
# Unit test for function is_camel_case
def test_is_camel_case():
    # Given a string with the word 'TestString'
    # When is_camel_case is called
    # Then the result should be true
    assert is_camel_case('TestString') == True

    # Given a string with the word 'teststring'
    # When is_camel_case is called
    # Then the result should be false
    assert is_camel_case('teststring') == False

    # Given a string with the word 'testString'
    # When is_camel_case is called
    # Then the result should be false
    assert is_camel_case('testString') == False

    # Given a string with the word '123TestString'
    # When is_camel_case is called
    # Then the result should be true
    assert is_camel_case('123TestString') == True

   

# Generated at 2022-06-24 02:25:52.812623
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string(None) == False
    assert is_full_string('') == False
    assert is_full_string(' ') == False
    assert is_full_string('hello') == True



# Generated at 2022-06-24 02:25:56.859076
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') == True
    assert is_isbn_10('150-6715214') == True
    assert is_isbn_10('150-6715214', normalize=False) == False
    assert is_isbn_10('9781506715215') == False
    assert is_isbn_10('9875648745') == False


# Generated at 2022-06-24 02:25:58.038322
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42')
    assert not is_integer('42.0')



# Generated at 2022-06-24 02:26:00.496270
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string(None) == False
    assert is_full_string(' ') == False
    assert is_full_string('') == False
    assert is_full_string('hello') == True
# FUNCTION is_full_string PASSED



# Generated at 2022-06-24 02:26:06.286501
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('0.0.0.0') == True and is_ip_v4('255.255.255.255') == True # range
    assert is_ip_v4('127.0.0.1') == True and is_ip_v4('192.168.1.200') == True # valid
    assert is_ip_v4('nope') == False and is_ip_v4('999.999.999.999') == False # invalid



# Generated at 2022-06-24 02:26:16.062527
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog') == True
    assert is_pangram('hello world') == False
    assert is_pangram('') == False
    assert is_pangram('abcdefghijklmnopqrs') == False
    assert is_pangram('abcdefghijklmnopqrstuvwxyz') == True
    assert is_pangram('ABCDEFGHIJKLMNOPQRSTUVWXYZ') == True
    assert is_pangram('xyz08') == False
    assert is_pangram('bbb') == False
    assert is_pangram('12345') == False

test_is_pangram()
 


# Generated at 2022-06-24 02:26:21.986926
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('hello') == False
    assert is_isogram('dermatoglyphics') == True
    assert is_isogram('moose') == False
    assert is_isogram('aba') == False
    assert is_isogram('Dermatoglyphics') == True
    assert is_isogram('moOse') == False
    assert is_isogram('thumbscrewjapingly') == True
    assert is_isogram('ALPHAbet') == False
    assert is_isogram('thumbscrew-japingly') == True
    assert is_isogram('Hjelmqvist-Gryb-Zock-Pfund-Wax') == True
    assert is_isogram('Heizölrückstoßabdämpfung') == True

# Generated at 2022-06-24 02:26:30.743941
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    checker = __ISBNChecker("")
    assert checker.is_isbn_10() == False
    checker = __ISBNChecker("123456789")
    assert checker.is_isbn_10() == False
    checker = __ISBNChecker("1234567891")
    assert checker.is_isbn_10() == False
    checker = __ISBNChecker("123456789x")
    assert checker.is_isbn_10() == True
    checker = __ISBNChecker("1234567892x")
    assert checker.is_isbn_10() == False
    checker = __ISBNChecker("0307887448")
    assert checker.is_isbn_10() == True

# Generated at 2022-06-24 02:26:40.890291
# Unit test for function is_url
def test_is_url():
    assert is_url("https://mysite.com")
    assert not is_url("ftps://mysite.com")
    assert is_url("ftps://mysite.com", allowed_schemes=["ftps"])
    assert not is_url("https://mysite.com", allowed_schemes=["ftps"])
    assert is_url("https://mysite.com", allowed_schemes=["https", "ftps"])
    assert is_url("ftps://mysite.com", allowed_schemes=["https", "ftps"])


# Generated at 2022-06-24 02:26:45.462297
# Unit test for function is_url
def test_is_url():
    assert is_url(None) == False
    assert is_url('') == False
    assert is_url('http://www.mysite.com') == True
    assert is_url('https://mysite.com') == True
    assert is_url('.mysite.com') == False
    assert is_url('www.mysite.com') == False
    assert is_url('http://www.mysite.com', allowed_schemes=['http', 'https']) == True
    assert is_url('ftp://mysite.com', allowed_schemes=['http', 'https']) == False



# Generated at 2022-06-24 02:26:49.056622
# Unit test for function is_string
def test_is_string():
    assert is_string("hello") == True
    assert is_string(b"hello") == False
    assert is_string(u"hello") == False
    assert is_string('') == True
    assert is_string(0) == False
    assert is_string([]) == False



# Generated at 2022-06-24 02:26:55.771318
# Unit test for function is_decimal
def test_is_decimal():
        assert is_decimal("10.25") == True
        assert is_decimal("-10.25") == True
        assert is_decimal("10") == False
        assert is_decimal("-10") == False
        assert is_decimal("-10.10.25") == False
        assert is_decimal("10.10.25") == False
        assert is_decimal("") == False
        assert is_decimal(" ") == False
        assert is_decimal("hello") == False


# Generated at 2022-06-24 02:26:58.538235
# Unit test for function contains_html
def test_contains_html():
    string_no_html = 'my string is not bold'
    assert not contains_html(string_no_html)
    string_html = 'my string is <strong>bold</strong>'
    assert contains_html(string_html)
    raise Exception('Unit test failed')
test_contains_html()
#Unit test for function contains_html

# Generated at 2022-06-24 02:27:05.387923
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') == True
    assert is_isbn('1506715214') == True
    assert is_isbn('150-6715214') == True
    assert is_isbn('150-6715214', normalize=False) == False



# Generated at 2022-06-24 02:27:14.294971
# Unit test for function is_ip_v6
def test_is_ip_v6():
    # Should return true
    assert is_ip_v6("2001:db8:85a3:0000:0000:8a2e:370:7334")
    # Should return false
    assert not is_ip_v6("2001:db8:85a3:0000:0000:8a2e:370:?")
    # Should return false
    assert not is_ip_v6("terst")
    # Should return false
    assert not is_ip_v6("")



# Generated at 2022-06-24 02:27:16.992529
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') # returns true
    assert is_url('https://mysite.com') # returns true
    assert not is_url('.mysite.com') # returns false



# Generated at 2022-06-24 02:27:22.570315
# Unit test for function is_number
def test_is_number():
    assert is_number('123') is True
    assert is_number('123.0') is True
    assert is_number('123.01') is True
    assert is_number('-123.01') is True
    assert is_number('123e3') is True
    assert is_number('123.01e3') is True
    assert is_number('-123.01e3') is True
    assert is_number('.01e3') is True
    assert is_number('-.01e3') is True
    assert is_number('foobar') is False
    assert is_number('123foobar') is False
    assert is_number('123.0foobar') is False
    assert is_number('foobar123') is False
    assert is_number('foobar.123') is False



# Generated at 2022-06-24 02:27:32.206810
# Unit test for function is_url
def test_is_url():
    assert is_url("http://www.google.com") == True
    assert is_url("https://www.google.com") == True
    assert is_url("www.google.com") == False
    assert is_url("google.com") == False
    assert is_url("") == False
    assert is_url("hello") == False
    assert is_url("http://") == False
    assert is_url("hello http://www.google.com") == False
    assert is_url("hello http://") == False
    assert is_url("hello https://www.google.com") == False
    assert is_url("http://www.google.com hello") == False
    assert is_url("https://www.google.com hello") == False



# Generated at 2022-06-24 02:27:35.897885
# Unit test for function is_full_string
def test_is_full_string():
    assert not is_full_string(None)
    assert not is_full_string('')
    assert not is_full_string(' ')
    assert is_full_string('hello')
    assert not is_full_string(123)



# Generated at 2022-06-24 02:27:43.439420
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') is True
    assert is_isbn('1506715214') is True
    assert is_isbn('978-0312498580') is True
    assert is_isbn('150-6715214') is True
    assert is_isbn('978-0312498580', normalize=False) is False
    assert is_isbn('150-6715214', normalize=False) is False

# Generated at 2022-06-24 02:27:54.113111
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title') == True
    assert is_slug('my-blog-post-title',separator='_') == True
    assert is_slug('My blog post title',separator='-') == False
    assert is_slug('') == False
    assert is_slug(None) == False
    assert is_slug(123) == False
    assert is_slug(['1','2','3']) == False
    assert is_slug((1,2,3)) == False
    assert is_slug({'a':1,'b':2,'c':3}) == False
    assert is_slug('-my-blog-post-title') == False
    assert is_slug('my-blog-post-title-') == False

# Generated at 2022-06-24 02:27:55.850562
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog') == True
    assert is_pangram('hello world') == False



# Generated at 2022-06-24 02:28:00.702738
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') is True
    assert is_url('https://mysite.com') is True
    assert is_url('.mysite.com') is False


# Generated at 2022-06-24 02:28:11.825804
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('6996') == True, 'This is a palindrome'
    assert is_palindrome('hello') == False, 'This is not a palindrome'
    assert is_palindrome('A nut for a jar of tuna.') == True, 'This is a palindrome'
    assert is_palindrome('This is NOT a palindrome') == False, 'This is not a palindrome'
    assert is_palindrome('1234321') == True, 'This is a palindrome'
    assert is_palindrome('1') == True, 'This is a palindrome'
    assert is_palindrome('12') == False, 'This is not a palindrome'
    assert is_palindrome('12.21') == False, 'This is not a palindrome'
   

# Generated at 2022-06-24 02:28:22.460907
# Unit test for function is_url
def test_is_url():
    assert not is_url('username@mysite.com')
    assert not is_url('http://www.mysite')
    assert not is_url('http:://www.mysite.com')
    assert not is_url('http:/mysite.com')
    assert not is_url('http:www.mysite.com')
    assert not is_url('.mysite.com')
    assert not is_url('mysite.com')
    assert is_url('www.mysite.com')
    assert is_url('https://www.mysite.com')
    assert is_url('http://www.mysite.com')
    assert is_url('http://www.mysite.com/folder')
    assert is_url('http://www.mysite.com/folder/')

# Generated at 2022-06-24 02:28:28.605496
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    checker = __ISBNChecker('030788820X', False)
    assert checker.is_isbn_10()
    checker = __ISBNChecker('030788820x', False)
    assert not checker.is_isbn_10()
test___ISBNChecker_is_isbn_10()


# Generated at 2022-06-24 02:28:35.505121
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') == True
    assert is_isbn_10('150-6715214') == True
    assert is_isbn_10('150-6715214', normalize=False) == False
    assert is_isbn_10('150-6715214', normalize=True) == True
    assert is_isbn_10('150671521x') == False
    assert is_isbn_10('150671521X') == False


# Generated at 2022-06-24 02:28:40.125184
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0980157172').is_isbn_10() == True
    assert __ISBNChecker('0980157173').is_isbn_10() == False


# Generated at 2022-06-24 02:28:41.969243
# Unit test for function is_full_string
def test_is_full_string():
    assert not is_full_string(None)
    assert not is_full_string('')
    assert not is_full_string(' ')
    assert is_full_string('hello')
    assert is_full_string('hello world')



# Generated at 2022-06-24 02:28:53.418886
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    # testing normal use cases
    assert __ISBNChecker("9780198605682").is_isbn_13()
    assert __ISBNChecker("9780201379624").is_isbn_13()

    # testing wrong use cases
    assert not __ISBNChecker("978019860568").is_isbn_13()
    assert not __ISBNChecker("97801986056822").is_isbn_13()
    assert not __ISBNChecker("978019860568129").is_isbn_13()
    assert not __ISBNChecker("9780198605682-").is_isbn_13()
    assert not __ISBNChecker("9780198605682-1").is_isbn_13()
    assert not __ISBNChecker("9780198605682 2").is_isbn

# Generated at 2022-06-24 02:29:03.857057
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    checker = __ISBNChecker('194453954X')
    assert checker.is_isbn_10() == True
    
    checker = __ISBNChecker('1944-53954-0')
    assert checker.is_isbn_10() == True

    checker = __ISBNChecker('1944539540')
    assert checker.is_isbn_10() == True

    checker = __ISBNChecker('194453954Z')
    assert checker.is_isbn_10() == False
    
    checker = __ISBNChecker('194453954')
    assert checker.is_isbn_10() == False

    checker = __ISBNChecker('1944539541')
    assert checker.is_isbn_10() == False


# PUBLIC

# Generated at 2022-06-24 02:29:13.546550
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') == True
    assert is_isbn_10('150-6715214') == True
    assert is_isbn_10('150-6715214', normalize=False) == False
    assert is_isbn_10('15067152149') == False
    assert is_isbn_10('150-67152149') == False
    assert is_isbn_10('150-67152149', normalize=False) == False
    assert is_isbn_10('1506715219') == False
    assert is_isbn_10('150-6715219') == False
    assert is_isbn_10('150-6715219', normalize=False) == False
    assert is_isbn_10('1491967679') == False

# Generated at 2022-06-24 02:29:17.561412
# Unit test for function is_ip_v6
def test_is_ip_v6():
    result = is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334')
    assert result == True
    result = is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?')
    assert result == False
# Unit tests for function is_ip_v4

# Generated at 2022-06-24 02:29:20.448752
# Unit test for function is_string
def test_is_string():
    assert is_string('') == True, "Input is string."
    assert is_string(b'foo') == False, "Input is not string."


# Generated at 2022-06-24 02:29:22.003422
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13("978-1-933988-80-3") == True

# Generated at 2022-06-24 02:29:25.558345
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75')
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334')
    assert is_ip('1.2.3')==False
    assert is_ip('111.222.333') == False
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:?') == False
    
test_is_ip()



# Generated at 2022-06-24 02:29:34.048915
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') == True
    assert is_isbn('1506715214') == True
    assert is_isbn('150-6715214') == True
    assert is_isbn('150-6715214', normalize=False) == False



# Generated at 2022-06-24 02:29:41.934349
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('012-345-6789').is_isbn_10()
    assert __ISBNChecker('0123456789').is_isbn_10()
    assert __ISBNChecker('0-12-345678-9').is_isbn_10()
    assert __ISBNChecker('0-12-345678-9', False).is_isbn_10()
    assert __ISBNChecker('0-12-345678-9').is_isbn_10()
    assert not __ISBNChecker('0-12-345678-8').is_isbn_10()
    assert not __ISBNChecker('111--11111').is_isbn_10()


# PUBLIC API



# Generated at 2022-06-24 02:29:48.166647
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42') == True
    assert is_integer('-42') == True
    assert is_integer('+42') == True
    assert is_integer('4.2') == False
    assert is_integer('42.0') == False
    assert is_integer('42e3') == True
    assert is_integer('not an integer') == False
# End test_is_integer