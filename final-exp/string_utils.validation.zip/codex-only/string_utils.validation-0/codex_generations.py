

# Generated at 2022-06-24 02:19:48.527017
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580')
    assert is_isbn_13('978-0312498580')
    assert is_isbn_13('978-0-312-498580')
    assert is_isbn_13('978-0-312-498580', normalize=False)
    assert not is_isbn_13('978-0-312-498580', normalize=True)
    assert is_isbn_13('978-0312498580', normalize=False)
    assert not is_isbn_13('978-0312498580', normalize=True)



# Generated at 2022-06-24 02:19:53.454059
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('0-7475-3269-9') == True
    assert is_isbn_13('9780312498580') == True
    assert is_isbn_13('9780312498580', normalize=False) == True
    assert is_isbn_13('ISBN 978-0-12-498580-7') == False
    assert is_isbn_13('978 0 312 49858 0') == False
    
test_is_isbn_13()



# Generated at 2022-06-24 02:19:58.771369
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert is_ip_v4('nope') is False
    assert is_ip_v4('255.200.100.999') is False
    assert is_ip_v4('1.2.3.4')



# Generated at 2022-06-24 02:20:00.800837
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog') == True
    assert is_pangram('The five boxing wizards jump quickly') == True

# Generated at 2022-06-24 02:20:08.643930
# Unit test for function is_email
def test_is_email():
    assert is_email(None) == False
    assert is_email('') == False
    assert is_email(' ') == False
    assert is_email(' example@gmail.com') == True
    assert is_email('example@gmail.com ') == True
    assert is_email(' example@gmail.com ') == True
    assert is_email("example@gmail.com") == True
    assert is_email("example+new@gmail.com") == True
    assert is_email("example-new@gmail.com") == True
    assert is_email("example.new@gmail.com") == True
    assert is_email("example-new.example@gmail.com") == True
    assert is_email("example@gmail.com.de") == True

# Generated at 2022-06-24 02:20:10.991793
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334')
    assert not is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?')
    assert not is_ip_v6('nope')
    assert not is_ip_v6('')
test_is_ip_v6()



# Generated at 2022-06-24 02:20:19.892948
# Unit test for function is_credit_card
def test_is_credit_card():
    assert not is_credit_card(None)
    assert not is_credit_card('')
    assert not is_credit_card('-1')
    assert not is_credit_card('1-')
    assert not is_credit_card('-')
    assert not is_credit_card(' ')
    assert not is_credit_card('123')
    assert not is_credit_card('foo')
    assert not is_credit_card(1234)
    assert not is_credit_card(0)
    assert is_credit_card('1230')
    assert is_credit_card('0000000000000000')
    assert is_credit_card('0000000000000000000')
    assert is_credit_card('000000000000000000000000')
    assert is_credit_card('0000000000000000000000000000')
    assert is_credit_card('000000000000000000000000000000')

# Generated at 2022-06-24 02:20:24.478905
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    checker = __ISBNChecker('978-3-16-148410-0')
    assert checker.input_string == '9783161484100'

    checker = __ISBNChecker('0-9752298-0-X')
    assert checker.input_string == '097522980X'


# PUBLIC API



# Generated at 2022-06-24 02:20:27.108867
# Unit test for function is_ip
def test_is_ip():
    is_ip('255.200.100.75')
    is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334')

test_is_ip()

# Generated at 2022-06-24 02:20:29.776503
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75') == True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip('1.2.3') == False



# Generated at 2022-06-24 02:20:33.411434
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') == True
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf') == False
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True) == True

test_is_uuid()


# Generated at 2022-06-24 02:20:42.601516
# Unit test for function is_integer
def test_is_integer():
    # Valid integers tests
    assert is_integer('0') == True
    assert is_integer('1') == True
    assert is_integer('-2') == True
    assert is_integer('3') == True
    assert is_integer('4') == True
    assert is_integer('5') == True
    assert is_integer('6') == True
    assert is_integer('7') == True
    assert is_integer('8') == True
    assert is_integer('9') == True
    assert is_integer('+42') == True
    assert is_integer('-53') == True
    assert is_integer('2147483647') == True
    assert is_integer('-2147483648') == True
    assert is_integer('9223372036854775807') == True

# Generated at 2022-06-24 02:20:49.749111
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('1258371836', normalize=False).is_isbn_10() is True
    assert __ISBNChecker('0899661417', normalize=False).is_isbn_10() is True
    assert __ISBNChecker('0201453564', normalize=False).is_isbn_10() is True
    assert __ISBNChecker('0804420901', normalize=False).is_isbn_10() is True
    assert __ISBNChecker('0899661418', normalize=False).is_isbn_10() is False

# Generated at 2022-06-24 02:20:53.302701
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('42.0')
    assert not is_decimal('42')


# Generated at 2022-06-24 02:20:58.733041
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False

# Generated at 2022-06-24 02:21:00.573861
# Unit test for function words_count
def test_words_count():
    assert words_count('hello world') == 2
    assert words_count('one,two,three.stop') == 4
    assert words_count('! @ # % ... []') == 0

    

# Generated at 2022-06-24 02:21:06.634819
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') == True
    assert is_isbn('1506715214') == True
    assert is_isbn('123') == False
    assert is_isbn('') == False

# Generated at 2022-06-24 02:21:12.702433
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog') is True
    assert is_pangram('The quick brown fox jumps over the lazy dog.') is True
    assert is_pangram('The_quick_brown_fox_jumps_over_the_lazy_dog.') is True
    assert is_pangram('The1 quick brown fox jumps over the lazy dog.') is True
    assert is_pangram('The quick brown fox jumps over the lazy dog!') is True
    assert is_pangram('The-quick-brown-fox-jumps-over-the-lazy-dog-') is True
    assert is_pangram('Thequickbrownfoxjumpsoverthelazydog') is True
    assert is_pangram('HELLO WORLD') is True

# Generated at 2022-06-24 02:21:19.791309
# Unit test for function is_credit_card
def test_is_credit_card():
    assert not is_credit_card('1234123412341234') # Length is not enough
    assert not is_credit_card('12341234123412345') # Length is too much
    assert is_credit_card('6011111111111117')
    assert is_credit_card('371449635398431')
    assert is_credit_card('3566002020360505')
    assert is_credit_card('5555555555554444')
    assert is_credit_card('5105105105105100')
    assert is_credit_card('4111111111111111')
    assert is_credit_card('30569309025904')
    assert not is_credit_card('30569309025904', card_type='VISA')

# Generated at 2022-06-24 02:21:29.507419
# Unit test for function is_pangram

# Generated at 2022-06-24 02:21:38.041317
# Unit test for function is_number
def test_is_number():
    assert is_number("45") ==True
    assert is_number("-19") == True
    assert is_number("-19.23") == True
    assert is_number("-1e3") == True
    assert is_number("+123") == False
    assert is_number("-0.1") == True
    assert is_number("-") == False
    assert is_number("--0") == False
    assert is_number(".23") == True
# End of unit test function is_number



# Generated at 2022-06-24 02:21:49.380379
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('0136091812')
    assert is_isbn_10('0136091812', normalize=False)
    assert is_isbn_10('013-609181-2')
    assert is_isbn_10('013-609181-2', normalize=False)
    assert not is_isbn_10('013-609181-3')
    assert not is_isbn_10('013-609181-3', normalize=False)
    assert not is_isbn_10('013-6091812')
    assert not is_isbn_10('013-6091812', normalize=False)


# Generated at 2022-06-24 02:21:50.357081
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('my string is <strong>bold</strong>')
    assert not contains_html('my string is not bold')



# Generated at 2022-06-24 02:22:01.453403
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') != False
    assert is_email('@gmail.com') != True
    assert is_email('@gmail.com') == False
    assert is_email('.my.email@the-provider.com') != True
    assert is_email('.my.email@the-provider.com') == False
    assert is_email('my.email@the-provider.com') != False
    assert is_email('my.email@the-provider.com') == True
    assert is_email('"my.email@the-provider.com') != True
    assert is_email('"my.email@the-provider.com') == False

# Generated at 2022-06-24 02:22:06.112780
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') == True
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf') == False
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True) == True


# Generated at 2022-06-24 02:22:08.289320
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('42.0')==True
    assert is_decimal('42')==False
    
    
    

# Generated at 2022-06-24 02:22:16.406556
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert(is_isbn_10("1506715214") == True)
    assert(is_isbn_10("1506715215") == False)
    assert(is_isbn_10("150-6715214") == True)
    assert(is_isbn_10("150-6715214", normalize=False) == False)
    assert(is_isbn_10(156715214) == True)
    assert(not is_isbn_10(None))
    
test_is_isbn_10()


# Generated at 2022-06-24 02:22:24.495326
# Unit test for function is_string
def test_is_string():
    assert is_string('foo')
    assert is_string('')
    assert not is_string(True)
    assert not is_string(False)
    assert not is_string(1)
    assert not is_string(1.0)
    assert not is_string(b'foo')
    assert not is_string([])
    assert not is_string({})
    assert not is_string(None)



# Generated at 2022-06-24 02:22:30.450841
# Unit test for function words_count
def test_words_count():
    assert words_count('foo bar baz') == 3
    assert words_count('foo;bar-baz') == 3
    assert words_count('foo@bar.baz') == 3
    assert words_count('foo.bar baz?') == 3
    assert words_count('foo_bar baz!') == 3
    assert words_count('foo123bar baz') == 3
    assert words_count('foo bar!baz') == 3
    assert words_count('foo bar baz..') == 3
    assert words_count('foo bar,baz') == 3
    assert words_count('foo bar baz...') == 3
    assert words_count('foo bar baz“”') == 3
    assert words_count('foo bar baz‘’') == 3

# Generated at 2022-06-24 02:22:32.442821
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False
    
test_is_json()



# Generated at 2022-06-24 02:22:36.889408
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580')
    assert is_isbn_13('978-0312498580')
    assert not is_isbn_13('978-0312498580', normalize=False)



# Generated at 2022-06-24 02:22:40.173242
# Unit test for function is_camel_case
def test_is_camel_case():
    assert(is_camel_case('test') == False)
    assert(is_camel_case('testCase') == True)
    assert(is_camel_case('TestCase') == True)
    assert(is_camel_case('test1Case') == True)
    assert(is_camel_case('') == False)
    assert(is_camel_case(' ') == False)
    try:
        assert(is_camel_case(None) == False)
    except TypeError: pass



# Generated at 2022-06-24 02:22:42.758035
# Unit test for function words_count
def test_words_count():
    assert words_count('hello world') == 2
    assert words_count('one,two,three.stop') == 4
    assert words_count('one, two, three.stop') == 4
    assert words_count('@ # $ %') == 0

# Generated at 2022-06-24 02:22:49.190291
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('abcdefghijklmnopqrstuvwxyz') == True
    assert is_pangram('The quick brown fox jumps over the lazy dog') == True
    assert is_pangram('hello world') == False

test_is_pangram()


# Generated at 2022-06-24 02:23:00.182990
# Unit test for function words_count
def test_words_count():
    assert words_count('one two three') == 3
    assert words_count('one, two three') == 3
    assert words_count('one-two,three.four') == 4
    assert words_count('one-two three.four') == 4
    assert words_count('one-two three-four!') == 4
    assert words_count('one-two three-four') == 4
    assert words_count('one-two #three-four') == 2
    assert words_count('one-two three-four five') == 5
    assert words_count('one-two,three-four five') == 5
    assert words_count('one-two three;four five') == 5
    assert words_count('one-two,three-four five;') == 5
    assert words_count('one-two,three-four five;') == 5

# Generated at 2022-06-24 02:23:07.451776
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') == True
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf') == False
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True) == True
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=False) == False
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=None) == False

# Generated at 2022-06-24 02:23:08.116689
# Unit test for function is_snake_case
def test_is_snake_case():
    return is_snake_case('is_snake_case')


# Generated at 2022-06-24 02:23:16.284780
# Unit test for function is_email
def test_is_email():
    assert is_email('simple@example.com')
    assert is_email('very.common@example.com')
    assert is_email('disposable.style.email.with+symbol@example.com')
    assert is_email('other.email-with-hyphen@example.com')
    assert is_email('fully-qualified-domain@example.com')
    assert is_email('user.name+tag+sorting@example.com')
    assert is_email('x@example.com')
    assert is_email('example-indeed@strange-example.com')
    assert is_email('admin@mailserver1')
    assert is_email('example@s.solutions')
    assert is_email("example@s.solutions")
    assert is_email("\" \"@example.org")

# Generated at 2022-06-24 02:23:20.844352
# Unit test for function is_number
def test_is_number():
    assert(is_number('1')==True)
    assert(is_number('9f')==False)
    assert(is_number('-1')==True)
    assert(is_number('-1.0')==True)



# Generated at 2022-06-24 02:23:22.107059
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('my string is <strong>bold</strong>') == True
    assert contains_html('my string is not bold') == False
# Test passes


# Generated at 2022-06-24 02:23:26.654631
# Unit test for function is_isogram
def test_is_isogram():
    assert(is_isogram("Dermatoglyphics") == True)
    assert(is_isogram("isogram") == True)
    assert(is_isogram("aba") == False)
    assert(is_isogram("moOse") == False)
    assert(is_isogram("isIsogram") == False)
    assert(is_isogram("") == True)



# Generated at 2022-06-24 02:23:30.741580
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') == True
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf') == True
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf',allow_hex=True) == True
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf',allow_hex=False) == False
    assert is_uuid('6f8aa2f9686c4ac387665712354a04c') == False
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cg') == False
   

# Generated at 2022-06-24 02:23:36.077342
# Unit test for function is_ip
def test_is_ip():
    print ('Testing is_ip()')
    assert is_ip('255.200.100.75') == True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip('1.2.3') == False
test_is_ip()


# Generated at 2022-06-24 02:23:43.601656
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case(12) is False
    assert is_camel_case('') is False
    assert is_camel_case(' ') is False
    assert is_camel_case('Abc') is True
    assert is_camel_case('abC') is True
    assert is_camel_case('aBc') is True
    assert is_camel_case('abCDE') is True
    assert is_camel_case('ABcd') is True
    assert is_camel_case('abCD') is True
    assert is_camel_case('ABcdEfGHIjK') is True
    assert is_camel_case('1ABcd') is False
    assert is_camel_case('abCD1') is True

# Generated at 2022-06-24 02:23:55.934261
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10(1506715214) == True
    assert is_isbn_10(1523456789) == False
    assert is_isbn_10(987643215) == True
    assert is_isbn_10(1234567891) == False

# Generated at 2022-06-24 02:24:06.991151
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal("42.1")
    assert is_decimal("+42.1")
    assert is_decimal("-42.1")
    assert is_decimal("42.1e10")
    assert not is_decimal("42.1E10")
    assert not is_decimal("-42.1e10")
    assert not is_decimal("42.1e+10")
    assert not is_decimal("42.1e-10")
    assert not is_decimal("42.1f-10")
    assert not is_decimal("42.1d-10")
    assert not is_decimal("42.1d")
    assert not is_decimal("42.1F")
    assert not is_decimal("42.1D")

# Generated at 2022-06-24 02:24:11.592850
# Unit test for function is_camel_case
def test_is_camel_case():
    assert(is_camel_case('myString1'))
    assert(not is_camel_case('my_string1'))
    assert(not is_camel_case('MyString'))
    assert(not is_camel_case('my string'))
    assert(not is_camel_case('my$tr1ng'))
    assert(not is_camel_case('1myStr1ng'))



# Generated at 2022-06-24 02:24:22.380174
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4444333322221111') is True
    assert is_credit_card('444433332222111') is False
    assert is_credit_card('none_existing_card') is False
    assert is_credit_card('4444333322221111','VISA') is True
    assert is_credit_card('4444333322221111','MASTERCARD') is False

# Boolean type check is not working
# def test_is_credit_card_with_invalid_args():
#     with pytest.raises(KeyError):
#         assert is_credit_card('4444333322221111','NONE_EXISTING_CARD')
# https://github.com/noi-techpark/string-validator/issues/22



# Generated at 2022-06-24 02:24:27.676552
# Unit test for function is_ip_v4
def test_is_ip_v4():
  assert(is_ip_v4("255.200.100.75") == True)
  assert(is_ip_v4("nope") == False)
  assert(is_ip_v4("255.200.100.999") == False)
  print("should not return any error")
# call the function
test_is_ip_v4()


# Generated at 2022-06-24 02:24:33.580353
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-0061120084').is_isbn_13() == True
    assert __ISBNChecker('978-0061120084XX').is_isbn_13() == False
    assert __ISBNChecker('978-0061120084').is_isbn_10() == False
    assert __ISBNChecker('978-0061120084XX').is_isbn_10() == False
    assert __ISBNChecker('0-306-40615-2').is_isbn_13() == True
    assert __ISBNChecker('0-306-40615-22').is_isbn_13() == False
    assert __ISBNChecker('0-306-40615-2').is_isbn_10() == True

# Generated at 2022-06-24 02:24:41.664618
# Unit test for function is_url
def test_is_url():
    print(is_url('https://www.strava.com/oauth/authorize?client_id=35697&redirect_uri=http://localhost:4200/firstpage&response_type=code&scope=activity:read_all'))
    print(is_url('http://www.strava.com/oauth/authorize?client_id=35697&redirect_uri=http://localhost:4200/firstpage&response_type=code&scope=activity:read_all'))

# Test
test_is_url()


# Generated at 2022-06-24 02:24:50.761847
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card("4485248835959912") == True
    assert is_credit_card("4539175309567428") == True
    assert is_credit_card("2222400028847579") == True
    assert is_credit_card("2221002795017411") == True
    assert is_credit_card("601109995492") == True
    assert is_credit_card("601100009072") == True
    assert is_credit_card("3530111333300000") == True
    assert is_credit_card("3566002020140006") == True
    assert is_credit_card("5555555555554444") == True
    assert is_credit_card("5105105105105100") == True

# Generated at 2022-06-24 02:24:53.364495
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string(None) == False
    assert is_full_string('') == False
    assert is_full_string(' ') == False
    assert is_full_string('hello') == True



# Generated at 2022-06-24 02:25:03.136290
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4111 1111 1111 1111') == True
    assert is_credit_card('4111 1111 1111 111') == False
    assert is_credit_card('4111 1111 1111 11111') == False
    assert is_credit_card('4111 1111 1111 1111', card_type='VISA') == True
    assert is_credit_card('5111 1111 1111 1111', card_type='VISA') == False
    assert is_credit_card('5500 0000 0000 0004', card_type='MASTERCARD') == True
    assert is_credit_card('5500 0000 0000 0004', card_type='MASTERCARD') == True
    assert is_credit_card('5500 0000 0000 0004', card_type='VISA') == False

# Generated at 2022-06-24 02:25:08.997245
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram("Dermatoglyphics") == True
    assert is_isogram("isogram") == True
    assert is_isogram("aba") == False
    assert is_isogram("moOse") == False
    assert is_isogram("isIsogram") == False
    assert is_isogram("") == True
    
test_is_isogram()


# Generated at 2022-06-24 02:25:19.163943
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580')
    assert is_isbn('978-0312498580')
    assert is_isbn('978-0312498580', normalize=False) == False
    assert is_isbn('978 0 312 49858 0')
    assert is_isbn('978 0 3124 9858 0') == False
    assert is_isbn('1506715214')
    assert is_isbn('150-6715214')
    assert is_isbn('150-6715214', normalize=False) == False
    assert is_isbn('150 6 715 21 4')
    assert is_isbn('150 6 7152 14') == False
    assert is_isbn('abcd') == False

# Generated at 2022-06-24 02:25:27.412595
# Unit test for function words_count
def test_words_count():
    assert words_count("one,two,three.stop") == 4
    assert words_count("1,2,3.stop") == 4
    assert words_count("one,two,3.stop") == 4
    assert words_count("1,two,three.stop") == 4
    assert words_count("one,2,3.stop") == 4
    assert words_count("one,two,3.stop") == 4
    assert words_count("one,two,three.4") == 4
    assert words_count("one,2,three.4") == 4
    assert words_count("1,two,three.4") == 4
    assert words_count("one,two,3.4") == 4
    assert words_count("test") == 1
    assert words_count("t") == 1

# Generated at 2022-06-24 02:25:36.912842
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert not is_email('@gmail.com')
    assert is_email('"\\"very.unusual.@.unusual.com\\"@example.com"')
    assert is_email('"very.unusual.@.unusual.com"@example.com')
    assert not is_email('"very.(),:;<>[]\".VERY.\"very@\\\\ \\\"very\\".unusual"@strange.example.com')
    assert not is_email('"very.(),:;<>[]\".VERY.\"very@\\ \\\"very\\\".unusual"@strange.example.com')

# Generated at 2022-06-24 02:25:40.894072
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com')
    assert is_url('https://mysite.com')
    assert is_url('.mysite.com') == False



# Generated at 2022-06-24 02:25:43.495293
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('42.0') == True
    assert is_decimal('42') == False

test_is_decimal()


# Generated at 2022-06-24 02:25:50.254662
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    t1 = __ISBNChecker('978-1-449-30668-2')
    assert t1.is_isbn_13() == True

    t1 = __ISBNChecker('979-1-449-30668-2')
    assert t1.is_isbn_13() == False

    t1 = __ISBNChecker('978-1-449-3066-82')
    assert t1.is_isbn_13() == False

    t1 = __ISBNChecker('9781449306682')
    assert t1.is_isbn_13() == True

    t1 = __ISBNChecker('978144930668')
    assert t1.is_isbn_13() == False

    t1 = __ISBNChecker('9781449306683')
    assert t1

# Generated at 2022-06-24 02:25:52.501267
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10(1506715214)
    assert is_isbn_10('1506715214')


# Generated at 2022-06-24 02:25:56.426907
# Unit test for function is_ip
def test_is_ip():
   assert is_ip("") == False, "Empty string"
   assert is_ip(None) == False, "None string"
   assert is_ip("1.2.3") == False, "is_ip_v4"
   assert is_ip("2001:db8:85a3:0000:0000:8a2e:370:7334") == True, "is_ip_v6"

# Generated at 2022-06-24 02:25:59.461834
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title', separator='-') == True
    assert is_slug('My blog post title', separator='-') == False
    assert is_slug('My-Blog-Post-Title', separator='-') == False
    assert is_slug('My blog post title', separator='-') == False
    assert is_slug('my_blog_post_title', separator='_') == True

if __name__ == '__main__':
    test_is_slug()


# Generated at 2022-06-24 02:26:09.353240
# Unit test for function is_isbn_10

# Generated at 2022-06-24 02:26:12.868797
# Unit test for function is_string
def test_is_string():
    assert is_string('foo')
    assert not is_string(b'foo')
    assert not is_string(1)
    assert not is_string({'test': 'test'})
    assert not is_string([1, 2, 3])
# Test for function is_string
test_is_string()



# Generated at 2022-06-24 02:26:20.461625
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') # returns true
    assert is_ip_v4('nope') is False # returns false (not an ip)
    assert is_ip_v4('255.200.100.999') is False # returns false (999 is out of range)

test_is_ip_v4()


# Generated at 2022-06-24 02:26:30.606058
# Unit test for function is_isogram
def test_is_isogram():
	assert is_isogram('Hello') == True
	assert is_isogram('Dermatoglyphics') == True
	assert is_isogram('Babylon') == False
	assert is_isogram('isoGram') == True
	assert is_isogram('Thumbscrew-japingly') == True
	assert is_isogram('thumbscrew-jappingly') == True
	assert is_isogram('Hjelmqvist-Gryb-Zock-Pfund-Wax') == True
	assert is_isogram('Heizölrückstoßabdämpfung') == True
	assert is_isogram('the quick brown fox') == False
	assert is_isogram('Emily Jung Schwartzkopf') == True
	assert is_isogram('éléphant') == False

# Unit

# Generated at 2022-06-24 02:26:33.728841
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf')
    assert not is_uuid('6f8aa2f9686c4ac387665712354a04cf')
    return True
print(test_is_uuid())


# Generated at 2022-06-24 02:26:37.021866
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string('') == False
    assert is_full_string(' ') == False
    assert is_full_string('   ') == False
    assert is_full_string(None) == False
    assert is_full_string('hello') == True
    assert is_full_string('123') == True



# Generated at 2022-06-24 02:26:39.783227
# Unit test for function is_string
def test_is_string():
    assert is_string("hello")
    assert is_string("")
    assert not is_string(111)
    assert not is_string(b"bbbb")
    assert not is_string("   ")
    assert not is_string(True)
    assert not is_string(3.14)
    assert not is_string(None)


# Generated at 2022-06-24 02:26:42.877866
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog') == True
    assert is_pangram('hello world') == False
test_is_pangram()



# Generated at 2022-06-24 02:26:44.444071
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram("The quick brown fox jumps over the lazy dog")


# Generated at 2022-06-24 02:26:53.645862
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case("foo_bar_baz") == True
    assert is_snake_case("foo") == False
    assert is_snake_case("foo-bar-baz", '-') == True
    assert is_snake_case("_foo_bar_baz") == False
    assert is_snake_case("foo_bar_baz_") == False
    assert is_snake_case("foo_bar_baz1") == True
    assert is_snake_case("foo_bar_baz_1") == True
    assert is_snake_case("1_foo_bar_baz") == False
    assert is_snake_case("foo_bar_baz_1_") == False
    return True



# Generated at 2022-06-24 02:26:56.539301
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75') == True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip('1.2.3') == False
test_is_ip()


# Generated at 2022-06-24 02:27:02.568960
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('4@gmail.com') == True
    assert is_email('.@gmail.com') == False
    assert is_email('my..email@the-provider.com') == False
    assert is_email('my.email@the-provider.com.') == False
    assert is_email('my.email@the-provider.com\\') == False
    assert is_email('my.email@the-provider.com\\') == False
    assert is_email('"my.email@the-provider.com"') == True
    assert is_email('"my.email@the-provider.com') == False

# Generated at 2022-06-24 02:27:10.029543
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('1111111111').is_isbn_10()
    assert __ISBNChecker('0000000000').is_isbn_10()
    assert __ISBNChecker('9123456789').is_isbn_10()
    assert __ISBNChecker('9-10-123456-9').is_isbn_10()
    assert not __ISBNChecker('').is_isbn_10()
    assert not __ISBNChecker('1111').is_isbn_10()
    assert not __ISBNChecker('0-111-11111-1').is_isbn_10()

# Generated at 2022-06-24 02:27:20.369665
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card(None) == False
    assert is_credit_card('') == False
    assert is_credit_card('4688035024906668') == False
    assert is_credit_card('4929146487807668') == False
    assert is_credit_card('5459050005667493') == False
    assert is_credit_card('5540164984955054') == False
    assert is_credit_card('5709288321026992') == False
    assert is_credit_card('5780262988843848') == False
    assert is_credit_card('345707053878189') == False
    assert is_credit_card('352819673229759') == False
    assert is_credit_card('376719157579858') == False

# Generated at 2022-06-24 02:27:27.810424
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    assert __ISBNChecker('978-1-56389-654-7').input_string == '9781563896547'
    assert __ISBNChecker('978-1-56389-654-7', normalize=False).input_string == '978-1-56389-654-7'


# Generated at 2022-06-24 02:27:35.522662
# Unit test for function is_url
def test_is_url():
    assert is_url('http://example.org') == True
    assert is_url('http://www.example.org') == True
    assert is_url('https://example.org') == True
    assert is_url('https://www.example.org') == True
    assert is_url('http://example.org/') == True
    assert is_url('http://www.example.org/') == True
    assert is_url('https://example.org/') == True
    assert is_url('https://www.example.org/') == True
    assert is_url('http://example.org/test') == True
    assert is_url('http://example.org/test/') == True
    assert is_url('http://www.example.org/test') == True

# Generated at 2022-06-24 02:27:46.340943
# Unit test for function is_email
def test_is_email():
    assert is_email('test@gmail.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('test@@gmail.com') == False
    assert is_email('.gmail.com') == False
    assert is_email('test.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my@gmail.com') == True
    assert is_email('my+email@gmail.com') == True
    assert is_email('_@gmail.com') == True
    assert is_email('_@gmail.com') == True
    assert is_email('_@gmail.com') == True
    assert is_email('_@gmail.com') == True

# Generated at 2022-06-24 02:27:51.055575
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('otto')
    assert is_palindrome('i topi non avevano nipoti', ignore_spaces=True)
    assert is_palindrome('I topi non avevano nipoti', ignore_case=True, ignore_spaces=True)
    assert is_palindrome('ROTFL') == False
    assert is_palindrome('LOL', ignore_case=True)



# Generated at 2022-06-24 02:27:55.910505
# Unit test for function is_json
def test_is_json():
    assert(is_json('{"name": "Peter"}'))
    assert(not is_json('[1, 2, 3]'))
    assert(not is_json('{"nope}'))


# Generated at 2022-06-24 02:28:03.871835
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string("Keshav")==True
    assert is_full_string("")==False
    assert is_full_string(" ")==False
    assert is_full_string("Keshav, Keshav")==True
    assert is_full_string("Keshav, Keshav ")==True
    assert is_full_string("9")==True

# Generated at 2022-06-24 02:28:06.252206
# Unit test for function is_string
def test_is_string():
    assert (is_string('123')) == True
    assert (is_string(b'456')) == False
    assert (is_string(123)) == False


# Generated at 2022-06-24 02:28:09.461034
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580')
    assert is_isbn_13('978-0312498580')
    assert not is_isbn_13('978-0312498580', normalize=False)



# Generated at 2022-06-24 02:28:12.522677
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('my.email@the-provider.com') != False
    assert is_email('@gmail.com') == False
    assert is_email('@gmail.com') != True



# Generated at 2022-06-24 02:28:14.572265
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False



# Generated at 2022-06-24 02:28:22.593503
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42')
    assert is_integer('-42')
    assert is_integer('42.0') == False
    assert is_integer('42.3') == False
    assert is_integer('42.3') == False
    assert is_integer('+42')
    assert is_integer('+42.3') == False
    assert is_integer('+42.0') == False
    assert is_integer('+42.3') == False
    assert is_integer('-42.0') == False
    assert is_integer('1e5')
    assert is_integer('-1e5')
    assert is_integer('-1E5')


# Generated at 2022-06-24 02:28:29.683082
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') is True
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf') is False
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True) is True


# Generated at 2022-06-24 02:28:34.789095
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('8847309835').is_isbn_13()
    assert __ISBNChecker('4222821345').is_isbn_13()
    assert not __ISBNChecker('1478262903').is_isbn_13()
    assert not __ISBNChecker('978-8847309831').is_isbn_13()



# Generated at 2022-06-24 02:28:42.927982
# Unit test for function words_count
def test_words_count():
    tests = {
        'hello world': 2,
        'one,two,three.stop': 4,
        'one two. three': 3,
        '\nthis\n\tis\t\r\t\n\t a\n test\r\t': 7,
        '  \t\r \t \n \n\r  \t \t': 0,
        'CamelCase': 1
    }

    for k in tests:
        assert words_count(k) == tests[k]



# Generated at 2022-06-24 02:28:53.495082
# Unit test for function words_count

# Generated at 2022-06-24 02:28:55.993503
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title')
    assert is_slug('my-blog-post-title-')
    assert is_slug('my_2nd_blog_post_title', separator='_')
    assert not is_slug('hello world')



# Generated at 2022-06-24 02:29:04.374247
# Unit test for function contains_html
def test_contains_html():
    """
    Test function contains_html()
    """
    # TypeError when a non-string is passed
    try:
        contains_html(123)
    except InvalidInputError:
        pass
    except TypeError:
        assert False, 'contains_html() should raise a "InvalidInputError" when a non-string is passed'
    else:
        assert False, 'contains_html() should raise a "InvalidInputError" when a non-string is passed'

    # simple test
    assert contains_html('my text is <strong>bold</strong>') is True, 'contains_html() should detect any html tag'
    assert contains_html('my text is not bold') is False, 'contains_html() should return false if no html tag is found'

    # test with different tag types

# Generated at 2022-06-24 02:29:09.669738
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog')
    assert is_pangram('The QUICK brown fox jumps over the lazy dog')
    assert not is_pangram('hello world')
    assert not is_pangram('')


# Generated at 2022-06-24 02:29:18.287974
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('snake_regex') == True
    assert is_snake_case('snake_regex_') == False
    assert is_snake_case('') == False
    assert is_snake_case('snakeindia') == False
    assert is_snake_case('snake_india') == True
    assert is_snake_case('snake_india_1') == True
    assert is_snake_case('snake_india_1') == True
    assert is_snake_case('-') == False
    assert is_snake_case('snake-case') == False
    assert is_snake_case('snake_case') == True
    assert is_snake_case('foo-bar') == False

# Generated at 2022-06-24 02:29:25.933789
# Unit test for function is_number
def test_is_number():
    assert is_number('42') == True
    assert is_number('19.99') == True
    assert is_number('-9.12') == True
    assert is_number('1e3') == True
    assert is_number('1 2 3') == False
    assert is_number('abc') == False
    assert is_number('1e') == False
test_is_number()



# Generated at 2022-06-24 02:29:34.172031
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    checker = __ISBNChecker('978-985-68-3284-1')
    assert checker.is_isbn_13() == True
    checker = __ISBNChecker('9781617293884')
    assert checker.is_isbn_13() == True
    checker = __ISBNChecker('1234567890')
    assert checker.is_isbn_13() == False
    checker = __ISBNChecker('978-985-68-32840-1')
    assert checker.is_isbn_13() == False
    checker = __ISBNChecker('978-985-68-328-0-1')
    assert checker.is_isbn_13() == False



# Generated at 2022-06-24 02:29:37.500177
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') == True, "is_url returns the wrong result."
    assert is_url('https://mysite.com') == True, "is_url returns the wrong result."
    assert is_url('.mysite.com') == False, "is_url returns the wrong result."



# Generated at 2022-06-24 02:29:41.970387
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string(None) == False
    assert is_full_string('') == False
    assert is_full_string(' ') == False
    assert is_full_string('hello') == True
# Test function
test_is_full_string()

