

# Generated at 2022-06-24 02:19:45.933293
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42') == True
    assert is_integer('-42') == True
    assert is_integer('1e5') == True
    assert is_integer('19.99') == False



# Generated at 2022-06-24 02:19:47.909358
# Unit test for function words_count
def test_words_count():
    assert words_count('hello world') == 2
    assert words_count('one,two,three.stop') == 4
test_words_count()



# Generated at 2022-06-24 02:19:52.493936
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('Madam, I\'m Adam') is True
    assert is_palindrome('Madam, I\'m Adam', ignore_case=True) is True
    assert is_palindrome('Madam, I\'m Adam', ignore_spaces=True) is True
    assert is_palindrome('Madam, I\'m Adam', ignore_case=True, ignore_spaces=True) is True
    assert is_palindrome('Madam, I\'m Adam', ignore_case=False, ignore_spaces=False) is False
    assert is_palindrome('Madam, I\'m Adam', ignore_case=False, ignore_spaces=True) is False
    assert is_palindrome('Madam, I\'m Adam', ignore_case=True, ignore_spaces=False) is False
   

# Generated at 2022-06-24 02:20:01.511386
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    checker = __ISBNChecker('978-1-56619-909-4').is_isbn_13()
    assert checker == True

    checker = __ISBNChecker('978 0 471 48648 0').is_isbn_13()
    assert checker == True

    checker = __ISBNChecker('978 0 471 48648' ).is_isbn_13()
    assert checker == False

    checker = __ISBNChecker('978-1-56619-909-0').is_isbn_13()
    assert checker == False

    checker = __ISBNChecker('978-1-56619-909-4').is_isbn_13()
    assert checker == True


# Generated at 2022-06-24 02:20:03.488857
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('1234567812345678') is False
    assert is_credit_card('4111111111111111') is True

# Generated at 2022-06-24 02:20:13.248823
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    checker = __ISBNChecker('123456789X')
    assert checker.is_isbn_10() == True

    checker = __ISBNChecker('1234567899')
    assert checker.is_isbn_10() == False

    checker = __ISBNChecker('123456789')
    assert checker.is_isbn_10() == False

    checker = __ISBNChecker('1234567890')
    assert checker.is_isbn_10() == False

    checker = __ISBNChecker('9876543210')
    assert checker.is_isbn_10() == True

# Generated at 2022-06-24 02:20:17.705246
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') == True
    assert is_url('https://mysite.com') == True
    assert is_url('.mysite.com') ==  False


# Generated at 2022-06-24 02:20:21.748048
# Unit test for function is_string
def test_is_string():
    assert(is_string('foo') == True)
    assert(is_string(b'foo') == False)


# Generated at 2022-06-24 02:20:29.380781
# Unit test for function words_count
def test_words_count():
    assert words_count('hello world !') == 2
    assert words_count('one,two,three') == 3
    assert words_count('one!two?three') == 3
    assert words_count('one,two,three.') == 3
    assert words_count('one,two,three. stop!') == 4
    assert words_count('one,two,three. stop!') == 4
    assert words_count('one\ttwo\tthree') == 3
    assert words_count('one   two  three') == 3
    assert words_count('one') == 1
    assert words_count('') == 0
    assert words_count('!@#$%') == 0
    assert words_count('one,two..') == 2
    assert words_count('one,two. three') == 3

# Generated at 2022-06-24 02:20:31.704487
# Unit test for function is_full_string
def test_is_full_string():
    assert not is_full_string(None)
    assert not is_full_string('')
    assert not is_full_string(' ')
    assert is_full_string('hello')



# Generated at 2022-06-24 02:20:36.050370
# Unit test for function words_count
def test_words_count():
    assert words_count('hello world') == 2
    assert words_count('one,two,three.stop') == 4
    assert words_count('one!two,three.stop') == 4
    assert words_count('one!two,three.stop') == 4
    assert words_count('on-e!two,three.stop') == 4
    assert words_count('on-e!,tw_o,three.stop?') == 4
    assert words_count('') == 0
    assert words_count(' ') == 0
    assert words_count('@ # % ^  ') == 0
    # Unit test for function words_count
test_words_count()

#-----------------------------------------------------------------------------------------------------------------------

# camel_case function

# Generated at 2022-06-24 02:20:47.883587
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    assert __ISBNChecker('978-0-306-40615-7')
    assert __ISBNChecker('0306406154')
    assert __ISBNChecker('0-306-40615-4')
    assert __ISBNChecker('978-0-306-40615-7', False)

    try:
        __ISBNChecker(None)
        assert False
    except InvalidInputError:
        pass

    # check book that has ISBN-10
    assert __ISBNChecker('0-306-40615-4').is_isbn_10() is True
    assert __ISBNChecker('0-306-40615-4').is_isbn_13() is False

    # check book that has ISBN-13
    assert __ISBNChecker('978-0-306-40615-7').is_isbn

# Generated at 2022-06-24 02:20:54.397559
# Unit test for function is_snake_case
def test_is_snake_case():
    from nose.tools import assert_false, assert_true
    assert_false(is_snake_case('-snake-case-'))
    assert_true(is_snake_case('-snake-case-', separator='-'))



# Generated at 2022-06-24 02:21:01.490855
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580')
    assert is_isbn('978-0312498580')
    assert is_isbn('978-0312498580', normalize=False) == False
    assert is_isbn('1506715214')
    assert is_isbn('150-6715214')
    assert is_isbn('150-6715214', normalize=False) == False
    
test_is_isbn()



# Generated at 2022-06-24 02:21:07.150101
# Unit test for function is_number
def test_is_number():
    assert is_number('42') == True
    assert is_number('19.99') == True
    assert is_number('-9.12') == True
    assert is_number('1e3') == True
    assert is_number('1 2 3') == False


# Generated at 2022-06-24 02:21:09.528403
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker("123456789X").is_isbn_10() is True
    assert __ISBNChecker("1234567890").is_isbn_10() is True
    assert __ISBNChecker("1234567899").is_isbn_10() is False

# Generated at 2022-06-24 02:21:16.902637
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4111111111111111') == True, 'must return True for a valid Visa card number'
    assert is_credit_card('4111111111111111', 'VISA') == True, 'must return True for a valid Visa card number'

    assert is_credit_card('5500000000000004') == True, 'must return True for a valid Mastercard card number'
    assert is_credit_card('5500000000000004', 'MASTERCARD') == True, 'must return True for a valid Mastercard card number'

    assert is_credit_card('378282246310005') == True, 'must return True for a valid American Express card number'
    assert is_credit_card('378282246310005', 'AMERICAN_EXPRESS') == True, 'must return True for a valid American Express card number'

   

# Generated at 2022-06-24 02:21:19.981733
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('42.4')
    assert not is_decimal('42')


# Generated at 2022-06-24 02:21:29.660920
# Unit test for function is_credit_card
def test_is_credit_card():
    """
    Checks if is_credit_card works as expected.
    """

# Generated at 2022-06-24 02:21:33.218802
# Unit test for function is_pangram
def test_is_pangram():
    string_not_pangram = "A quick brown fox jumped over the lazy dog"
    string_is_pangram = "The quick brown fox jumps over the lazy dog"
    assert is_pangram(string_not_pangram) == False
    assert is_pangram(string_is_pangram) == True


# Generated at 2022-06-24 02:21:35.379012
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214')
    assert is_isbn_10('150-6715214')
    assert not is_isbn_10('150-6715214', normalize=False)
    assert not is_isbn_10('150-6715214', normalize=False)


# Generated at 2022-06-24 02:21:36.581189
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75')
    assert not is_ip('1.2.3')
test_is_ip()


# Generated at 2022-06-24 02:21:37.707120
# Unit test for function is_number
def test_is_number():
    assert(is_number('42') == True)


# Generated at 2022-06-24 02:21:50.719465
# Unit test for function is_email
def test_is_email():
    assert is_email('abc@abc.com') == True
    assert is_email('abc@abc.gov') == True
    assert is_email('abc@abc.info') == True
    assert is_email('abc@abc.mil') == True
    assert is_email('abc@abc.biz') == True
    assert is_email('abc@abc.name') == True
    assert is_email('abc@abc.net') == True
    assert is_email('abc@abc.org') == True
    assert is_email('abc@abc.pro') == True
    assert is_email('abc@abc.travel') == True
    assert is_email('abc@abc.cat') == True
    assert is_email('abc@abc.coop') == True
    assert is_email('abc@abc.int') == True

# Generated at 2022-06-24 02:22:00.070173
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('123456789X').is_isbn_10() is True
    assert __ISBNChecker('123456789x').is_isbn_10() is True

    assert __ISBNChecker('1234567890').is_isbn_10() is False
    assert __ISBNChecker('123456789999').is_isbn_10() is False

    assert __ISBNChecker('12345678s').is_isbn_10() is False  # ValueError
    assert __ISBNChecker(123456789).is_isbn_10() is False  # TypeError

# Generated at 2022-06-24 02:22:01.075115
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('my string is <strong>bold</strong>') is True
    assert contains_html('my string is not bold') is False

# Generated at 2022-06-24 02:22:03.518312
# Unit test for function is_integer
def test_is_integer():
    assert is_integer("42")
    assert not is_integer("42.0")
    assert not is_integer("42e2")
    assert not is_integer("-99.99")



# Generated at 2022-06-24 02:22:07.881041
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf')  # returns true
    assert not is_uuid('6f8aa2f9686c4ac387665712354a04cf')  # returns false
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True)  # returns true



# Generated at 2022-06-24 02:22:11.147466
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    instance = __ISBNChecker('123456789X')

    assert instance.input_string == '123456789X'


# Generated at 2022-06-24 02:22:18.697434
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('9780306406157').is_isbn_13() == True
    assert __ISBNChecker('978-0-306-40615-7').is_isbn_13() == True
    assert __ISBNChecker('030640615X').is_isbn_13() == False
    assert __ISBNChecker('978 0306 40615 7').is_isbn_13() == False



# Generated at 2022-06-24 02:22:27.353930
# Unit test for function is_decimal
def test_is_decimal():
    # Error should raise if input is not a string
    try:
        is_decimal(42.0)
        assert False, "Expected InvalidInputError"
    except InvalidInputError:
        pass
    # Not a number string
    assert is_decimal('foo') == False
    # A valid decimal string
    assert is_decimal('42.0') == True
    # Another valid decimal string
    assert is_decimal('-9.12') == True
    # Scientific notation is not a decimal
    assert is_decimal('-1e5') == False
    # Integer is not a decimal
    assert is_decimal('42') == False



# Generated at 2022-06-24 02:22:32.241451
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card("4567 7623 8901 6543") # True
    assert is_credit_card("4567 7623 8901 6543", card_type = "VISA") # True
    assert is_credit_card("4567 7623 8901 6543", card_type = "AMERICAN_EXPRESS") # False


# Generated at 2022-06-24 02:22:39.396828
# Unit test for function is_number
def test_is_number():
    assert is_number(42) == True
    assert is_number('19.99') == True
    assert is_number('-9.12') == True
    assert is_number('1e3') == True
    assert is_number('1 2 3') == False
    assert is_number('-9.12e6') == True
    assert is_number('1e-05') == True
    assert is_number('1') == True
    assert is_number('1.1') == True
    assert is_number('0x8') == False



# Generated at 2022-06-24 02:22:44.126226
# Unit test for function is_url
def test_is_url():
    actual = is_url('http://www.mysite.com')
    expected = True
    assert actual == expected

    actual = is_url('https://mysite.com')
    expected = True
    assert actual == expected

    actual = is_url('.mysite.com')
    expected = False
    assert actual == expected
test_is_url()



# Generated at 2022-06-24 02:22:54.292561
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('dermatoglyphics') == True
    assert is_isogram('isogram') == True
    assert is_isogram('moose') == False
    assert is_isogram('isIsogram') == False
    assert is_isogram('aba') == False
    assert is_isogram('moOse') == False
    assert is_isogram('thumbscrewjapingly') == True
    assert is_isogram('thumbscrew-japingly') == True
    assert is_isogram('6humbscrewjapingly') == True
    assert is_isogram('dermatoglyphics') == True
    assert is_isogram('Dermatoglyphics') == True
    assert is_isogram('subdermatoglyphic') == True

# Generated at 2022-06-24 02:22:58.055526
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') == True
    assert is_isbn('9780312498580', False) == False
    assert is_isbn('1506715214') == True
    assert is_isbn('1506715214', False) == False
test_is_isbn()    


# Generated at 2022-06-24 02:23:02.918719
# Unit test for function is_url
def test_is_url():
    assert is_url('https://address.com') == True
    assert is_url('/www.example.com') == False
    assert is_url('www.example.com') == False
    assert is_url('http://') == False



# Generated at 2022-06-24 02:23:14.491884
# Unit test for function is_isbn
def test_is_isbn():
    # Test first set of business rules
    assert is_isbn('1506715214') == True
    assert is_isbn('150-6715214') == True
    assert is_isbn('1506715214', normalize=False) == True
    assert is_isbn('150-6715214', normalize=False) == False
    assert is_isbn('9791177077144') == True
    assert is_isbn('979-1177077144') == True
    assert is_isbn('9791177077144', normalize=False) == True
    assert is_isbn('979-1177077144', normalize=False) == False
    assert is_isbn('9780312498580') == True
    assert is_isbn('978-0312498580') == True

# Generated at 2022-06-24 02:23:25.579013
# Unit test for function is_email
def test_is_email():
    assert is_email(None) == False
    assert is_email('joe.schmoe') == False
    assert is_email('.joe.schmoe@gmail.com') == False
    assert is_email('joe.schmoe@gmail..com') == False
    assert is_email('foo@bar.com') == True
    assert is_email('foo@bar.co') == True
    assert is_email('foo@domain.com') == True
    assert is_email('foo@bar.com.br') == True
    assert is_email('foo@bar.co.br') == True
    assert is_email('foo+bar@bar.com') == True
    assert is_email('foo bar@bar.com') == True
    assert is_email('foo bar@bar.com') == True

# Generated at 2022-06-24 02:23:37.051487
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card("https://www.google.com") == False
    assert is_credit_card("4929175713550727") == True
    assert is_credit_card("4929175713550727", card_type="VISA") == True
    assert is_credit_card("4929175713550727", card_type="MASTERCARD") == False
    #assert is_credit_card("4929175713550727", card_type="INVALID_CARD_TYPE")
    assert is_credit_card("5424180123456789") == True
    assert is_credit_card("5424180123456789", card_type="MASTERCARD") == True
    assert is_credit_card("34241801234567") == True

# Generated at 2022-06-24 02:23:45.916074
# Unit test for function is_ip_v6
def test_is_ip_v6():

    assert is_ip_v6("2001:db8:85a3:0000:0000:8a2e:370:7334") is True
    assert is_ip_v6("2001:db8:85a3:0000:0000:8a2e:370:?") is False

    assert is_ip_v6("0:0:0:0:0:0:0:0") is True
    assert is_ip_v6("10:1d4b::7334") is True
    assert is_ip_v6("0:0:0:0:0:0:0:0") is True
    assert is_ip_v6("::1") is True
    assert is_ip_v6("::") is True
    assert is_ip_v6("1::1") is True
    assert is_ip

# Generated at 2022-06-24 02:23:49.447795
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('foo_bar_baz', '_')
    assert is_snake_case('fooBar', '_') is False
    assert is_snake_case('foo', '_') is False



# Generated at 2022-06-24 02:24:01.113423
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('my+test@test.test')
    assert is_email('mytest@test.test')
    assert is_email('mytest@test.test')
    assert is_email('mytest+test@test.test')
    assert is_email('my+test@test.test')
    assert is_email('mytest@test.test')
    assert is_email('mytest@test.test')
    assert is_email('firstname.lastname@example.com')
    assert is_email('email@123.123.123.123')
    assert is_email('email@[123.123.123.123]')
    assert is_email('"email"@example.com')

# Generated at 2022-06-24 02:24:10.625553
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('9780134685991').is_isbn_13() is True
    assert __ISBNChecker('9780316066525').is_isbn_13() is True
    assert __ISBNChecker('9788175257665').is_isbn_13() is True
    assert __ISBNChecker('9780134685990').is_isbn_13() is False
    assert __ISBNChecker('9780316066524').is_isbn_13() is False
    assert __ISBNChecker('9788175257664').is_isbn_13() is False
    assert __ISBNChecker('9780134685991-').is_isbn_13() is False


# Generated at 2022-06-24 02:24:14.092749
# Unit test for function contains_html
def test_contains_html():
    assert is_true(contains_html('my string is <strong>bold</strong>'))
    assert is_true(contains_html('<script>alert("hello");</script>'))
    assert is_false(contains_html('my string is not bold'))
    assert is_false(contains_html('<a href="http://www.google.com">Google</a>'))


# Generated at 2022-06-24 02:24:23.135163
# Unit test for function is_email
def test_is_email():
    assert is_email('.testlocal@localhost') == False
    assert is_email('testlocal@localhost') == True
    assert is_email('testlocal.@localhost') == False
    assert is_email('testlocal..@localhost') == False
    assert is_email('testlocal@localhost.') == True
    assert is_email('testlocal@localhost.x') == True
    assert is_email('testlocal@.localhost.x') == False
    assert is_email('testlocal@localhost.x.') == False
    assert is_email('testlocal@localhost..x') == False
    assert is_email('testlocal@localhost..x.') == False

# Generated at 2022-06-24 02:24:27.053869
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') is True
    assert is_isbn_10('150-6715214') is True
    assert is_isbn_10('150-6715214', normalize=False) is False
test_is_isbn_10()



# Generated at 2022-06-24 02:24:32.596124
# Unit test for function words_count
def test_words_count():
    assert words_count('one two three') == 3
    assert words_count('one,two.three;') == 3
    assert words_count('one,two,three.stop') == 4
    assert words_count('a') == 1
    assert words_count('hello ') == 0
    assert words_count('one,two,three.stop') == 4
    assert words_count('one') == 1
    assert words_count("Gi'a scartate, e stracciate, e rotte,") == 10
    assert words_count("'Credo che sien le cose ardenti'") == 8
    assert words_count("d'un tufo, tutto pien di chiapp'  e di stracci; ") == 13

# Generated at 2022-06-24 02:24:43.032466
# Unit test for function is_credit_card
def test_is_credit_card():
    # Check with credit card type
    assert is_credit_card('4111111111111111', 'VISA') == True
    assert is_credit_card('5105105105105100', 'MASTERCARD') == True
    assert is_credit_card('378282246310005', 'AMERICAN_EXPRESS') == True
    assert is_credit_card('30569309025904', 'DINERS_CLUB') == True
    assert is_credit_card('6011111111111117', 'DISCOVER') == True
    assert is_credit_card('3530111333300000', 'JCB') == True

    # Check with non-matching credit card type
    assert is_credit_card('4111111111111111', 'MASTERCARD') == False

# Generated at 2022-06-24 02:24:50.828485
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('375556917985515') # is a valid VISA credit card number
    assert not is_credit_card('375556917985515', card_type='AMERICAN_EXPRESS') # not a valid AMERICAN_EXPRESS number
    assert is_credit_card('375556917985515', card_type='VISA')


# Generated at 2022-06-24 02:24:59.527499
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('otto') is True
    assert is_palindrome('oTOto') is False
    assert is_palindrome('oTOto', ignore_case=True) is True
    assert is_palindrome('i topi non avevano nipoti') is True
    assert is_palindrome('i topi non avevano nipoti', ignore_spaces=True) is False
    assert is_palindrome('ROTFL') is False
    assert is_palindrome('ROTFL', ignore_case=True) is False

test_is_palindrome()



# Generated at 2022-06-24 02:25:05.086490
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75') == True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip('1.2.3') == False
    

# Generated at 2022-06-24 02:25:12.717351
# Unit test for function contains_html
def test_contains_html():
    # Function signature:
    assert inspect.signature(text.contains_html).parameters["input_string"].annotation == str
    # Returns true
    assert text.contains_html('my string is <strong>bold</strong>')
    # Returns false
    assert not text.contains_html('my string is not bold')
    # Checks if it raises an exception if input type is not string
    with pytest.raises(text.InvalidInputError):
        text.contains_html(9)



# Generated at 2022-06-24 02:25:21.326584
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('0')
    assert is_integer('10')
    assert is_integer('-10')
    assert is_integer('+10')
    assert is_integer('100')
    assert is_integer('-100')
    assert is_integer('+100')
    assert is_integer('1e100')
    assert is_integer('+1e100')
    assert is_integer('-1e100')
    assert not is_integer('01')
    assert not is_integer('-1e-100')
    assert not is_integer('+1e-100')
    assert not is_integer('1.5')
    assert not is_integer('-1.5')
    assert not is_integer('+1.5')
    assert not is_integer('1.5e5')

# Generated at 2022-06-24 02:25:23.257357
# Unit test for function words_count
def test_words_count():
    assert words_count('hello world') == 2
    assert words_count('one,two,three.stop') == 4
test_words_count()


# Generated at 2022-06-24 02:25:30.620971
# Unit test for function is_palindrome
def test_is_palindrome():
    input_string = ['LOL', 'Lol']
    output = [True, True]
    for i in range(len(output)):
        assert is_palindrome(input_string[i],True) == output[i]

test_is_palindrome()

# Generated at 2022-06-24 02:25:38.533328
# Unit test for function is_email
def test_is_email():
    assert is_email(None) == False
    assert is_email("") == False
    assert is_email("@gmail.com") == False
    assert is_email(".my.email@the-provider.com") == False
    assert is_email("my.email@the-provider.com") == True
    assert is_email("adam@the-provider.com") == True
    assert is_email("ham@gmail.com") == True



# Generated at 2022-06-24 02:25:48.944449
# Unit test for function is_string

# Generated at 2022-06-24 02:25:52.344888
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4111111111111111') == True
    assert is_credit_card('378282246310005') == True
    assert is_credit_card('6011111111111117') == True



# Generated at 2022-06-24 02:25:54.461475
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog')
    assert not is_pangram('hello world')
test_is_pangram()

# Generated at 2022-06-24 02:26:09.034943
# Unit test for function is_snake_case
def test_is_snake_case():
    assert(is_snake_case('foo_bar_baz') == True)
    assert(is_snake_case('foo') == False)
    assert(is_snake_case('foo_bar-baz') == True)
    assert(is_snake_case('foo-bar_baz') == True)
    assert(is_snake_case('foo-bar-baz') == True)
    assert(is_snake_case('foo_bar_baz_') == False)
    assert(is_snake_case('_foo_bar_baz') == False)
    assert(is_snake_case('foo-') == False)
    assert(is_snake_case('_foo') == False)
    assert(is_snake_case('foo_') == False)

# Generated at 2022-06-24 02:26:16.517489
# Unit test for function is_credit_card
def test_is_credit_card():
    card_number = '123456789'
    assert not is_credit_card(card_number)

    assert is_credit_card('4242424242424242')
    assert not is_credit_card('1234567890098765')

    assert is_credit_card('5555555555554444')
    assert not is_credit_card('1234567890098765')

    assert is_credit_card('378282246310005')
    assert not is_credit_card('5105105105105100')

    assert is_credit_card('4111111111111111')
    assert not is_credit_card('1234567890098765')

    assert is_credit_card('6011111111111117')
    assert not is_credit_card('1234567890098765')


# Generated at 2022-06-24 02:26:18.633442
# Unit test for function is_number
def test_is_number():
    assert is_number('42') == True


# Generated at 2022-06-24 02:26:21.855409
# Unit test for function is_credit_card
def test_is_credit_card():
    # Example:4556737586899855
    assert is_credit_card('4556737586899855')
    # Example: 5500 0000 0000 0004
    assert is_credit_card('5500000000000004')
    assert not is_credit_card('5500000000000006')


# Generated at 2022-06-24 02:26:26.015340
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert(is_ip_v4('255.200.100.75'))
    assert(not is_ip_v4('nope'))
    assert(not is_ip_v4('255.200.100.999'))


# Generated at 2022-06-24 02:26:31.498904
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    assert __ISBNChecker('1234567890123').input_string == '1234567890123'
    assert __ISBNChecker('123-456-789-0123').input_string == '1234567890123'

    assert __ISBNChecker('123', False).input_string == '123'
    assert __ISBNChecker('123-45', False).input_string == '123-45'


# Generated at 2022-06-24 02:26:35.188226
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42') == True
    assert is_integer('42.0') == False


# Generated at 2022-06-24 02:26:38.761611
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') == True
    assert is_isbn_10('150-6715214') == True
    assert is_isbn_10('150-6715214', normalize=False) == False

test_is_isbn_10()



# Generated at 2022-06-24 02:26:46.602132
# Unit test for function is_email
def test_is_email():
    assert is_email('astrid@gmail.com') == True
    assert is_email('adb@hotmail.fr') == True
    assert is_email('.adb@hotmail.fr') == False
    assert is_email('adb.@hotmail.fr') == False
    assert is_email('adb.@hotmail.fr.') == False
    assert is_email('adb.@hotmail.fr..') == False
    assert is_email('adb.fr') == False
    assert is_email('adb.fr.') == False
    assert is_email('adb.()@fr.fr') == False
    assert is_email('adb.@fr.fr') == True
    assert is_email('adb..bb@fr.fr') == False

# Generated at 2022-06-24 02:26:50.648522
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334') # return True
    assert not is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334') # return False
    assert is_ip_v6('2001:db8:85a3:0:0:8a2e:370:7334') # return True
    assert is_ip_v6('2001:db8:85a3::8a2e:370:7334') # return True
    assert not is_ip_v6('2001:db8:85a3::8a2e:370:7334') # return False

# Generated at 2022-06-24 02:26:53.221284
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('dermatoglyphics') # For isogram
    assert is_isogram('moose') # For isogram
    assert not is_isogram('moOse') # For non-isogram
    assert not is_isogram('AAA') # For non-isogram

is_isogram('dermatoglyphics')


# Generated at 2022-06-24 02:27:01.961456
# Unit test for function is_full_string
def test_is_full_string():
    assert not is_full_string(None)
    assert not is_full_string('')
    assert not is_full_string(' ')
    assert is_full_string('hello')


# Generated at 2022-06-24 02:27:11.100732
# Unit test for function is_snake_case
def test_is_snake_case():
    assert(is_snake_case('a_b'))
    assert(not is_snake_case('_a_b'))
    assert(not is_snake_case('a_b_'))
    assert(not is_snake_case('-1_a-b'))
    assert(not is_snake_case('-1_a-b', '-'))
    assert(not is_snake_case('a_b-', '-'))
    assert(not is_snake_case('a-b_', '-'))
    assert(is_snake_case('a-b-c', '-'))
    assert(is_snake_case('a-b-c-', '-'))
    assert(not is_snake_case('a-b-c--', '-'))

# Generated at 2022-06-24 02:27:13.099078
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title') == True
    assert is_slug('My blog post title') == False
    assert is_slug('My-blog-post-title') == False
# Tested


# Generated at 2022-06-24 02:27:15.481845
# Unit test for function is_number
def test_is_number():
    assert not is_number('-1-') # returns false
    assert not is_number('-1.2.3') # returns false
    assert is_number('-1.2e2') # returns true



# Generated at 2022-06-24 02:27:20.905170
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('MyString') == False
    assert is_snake_case('my_string') == True
    assert is_snake_case('my-string') == True


# Generated at 2022-06-24 02:27:28.545824
# Unit test for function is_isbn_10
def test_is_isbn_10():
  assert is_isbn_10('1506715214') == True
  assert is_isbn_10('150-6715214') == True
  assert is_isbn_10('150-6715214', normalize=False) == False
  assert is_isbn_10('978-3-16-148410-0') == False
test_is_isbn_10()



# Generated at 2022-06-24 02:27:33.783536
# Unit test for function contains_html
def test_contains_html():
    assert(contains_html('my string is <strong>bold</strong>') == True)
    assert(contains_html('my string is not bold') == False)


# Generated at 2022-06-24 02:27:44.552309
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6("2001:db8:85a3:0000:0000:8a2e:370:7334") == True
    assert is_ip_v6("2001:db8:85a3:0:0:8a2e:370:7334") == True
    assert is_ip_v6("2001:db8:85a3::8a2e:370:7334") == True
    assert is_ip_v6("2001:db8:85a3::8a2e:370:7334") == True
    assert is_ip_v6("2001:0db8:85a3:0000:0000:8a2e:0370:7334") == True

# Generated at 2022-06-24 02:27:50.078954
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') # returns true
    assert is_isbn('1506715214') # returns true
    assert is_isbn('150-6715214') # returns true
    assert is_isbn('150-6715214', normalize=False) # returns false

# Generated at 2022-06-24 02:27:57.459314
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580') == True
    assert is_isbn_13('978-0312498580') == True
    assert is_isbn_13('978-0312498580', normalize=False) == False
    assert is_isbn_13('978-03-124985-80') == True
    assert is_isbn_13('978-0-31249-858-0') == True



# Generated at 2022-06-24 02:28:01.793134
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('MyString') == True
    assert is_camel_case('mystring') == False
    assert is_camel_case('myString') == False
    assert is_camel_case('my2string') == True
    assert is_camel_case('My_String') == False
    assert is_camel_case('2MyString') == False
    print('Function is_camel_case is correct')


# Generated at 2022-06-24 02:28:11.926489
# Unit test for function is_credit_card
def test_is_credit_card():
    print(is_credit_card('4024007101212223'))
    print(is_credit_card('4024007102345777'))
    print(is_credit_card('371449635398435'))
    print(is_credit_card('371449635398436'))
    print(is_credit_card('6011023456789022'))
    print(is_credit_card('60110010010010010'))
    print(is_credit_card('5019717010103710'))
    print(is_credit_card('6331105019873736'))
    print(is_credit_card('30569309025904'))
    print(is_credit_card('30569309026045'))

# Generated at 2022-06-24 02:28:18.222473
# Unit test for function is_number
def test_is_number():
    assert is_number('42') == True
    assert is_number('19.99') == True
    assert is_number('-9.12') == True
    assert is_number('1e3') == True
    assert is_number('1 2 3') == False
    assert is_number(None) == False


# Generated at 2022-06-24 02:28:21.732900
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf')
    assert not is_uuid('6f8aa2f9686c4ac387665712354a04cf')


# Generated at 2022-06-24 02:28:29.540586
# Unit test for function is_camel_case
def test_is_camel_case():
    assert not is_camel_case(None)
    assert not is_camel_case('')
    assert not is_camel_case(' ')
    assert not is_camel_case('1string')
    assert not is_camel_case('string')
    assert not is_camel_case('string ')
    assert is_camel_case('MyString')
    assert is_camel_case('myString')
    assert is_camel_case('myString1')
test_is_camel_case()



# Generated at 2022-06-24 02:28:33.783765
# Unit test for function is_json
def test_is_json():
    example1 = '{"name": "Peter"}'
    assert is_json(example1)
    example2 = '[1, 2, 3]'
    assert is_json(example2)
    example3 = '{nope}'
    assert not is_json(example3)
test_is_json()



# Generated at 2022-06-24 02:28:35.208801
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580')
    assert is_isbn('1506715214')


# Generated at 2022-06-24 02:28:38.591275
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42') == True
    assert is_integer('42.0') == False


# Generated at 2022-06-24 02:28:49.871439
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('9788402330685').is_isbn_13() == True
    assert __ISBNChecker('978-840-23-30685').is_isbn_13() == True
    assert __ISBNChecker('978840233068', normalize=False).is_isbn_13() == False
    assert __ISBNChecker('9788402330685', normalize=False).is_isbn_13() == True
    assert __ISBNChecker('97884023306853').is_isbn_13() == False
    assert __ISBNChecker('97884023306851').is_isbn_13() == False
    assert __ISBNChecker('978842').is_isbn_13() == False

# Generated at 2022-06-24 02:28:50.858846
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog')
    assert not is_pangram('hello world')


# Generated at 2022-06-24 02:28:57.033746
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker("0471958697").is_isbn_10() == True
    assert __ISBNChecker("0-321-14653-0").is_isbn_10() == True
    assert __ISBNChecker("88-439-1465-8").is_isbn_10() == True
    assert __ISBNChecker("0-596-52068-9").is_isbn_10() == True

    assert __ISBNChecker("").is_isbn_10() == False
    assert __ISBNChecker("1234567890").is_isbn_10() == False
    assert __ISBNChecker("12345678901").is_isbn_10() == False
    assert __ISBNChecker("10").is_isbn_10() == False

# Generated at 2022-06-24 02:29:03.473548
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('MyString')
    assert is_camel_case('MyString99')
    assert is_camel_case('My99String')
    assert not is_camel_case('mystring99')
    assert not is_camel_case('99string')
    assert not is_camel_case('string')



# Generated at 2022-06-24 02:29:10.199748
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    test_cases = [
        ('044841418X', True),
        ('978044841', False),
        ('044841', False),
        ('04484141800', False),
        ('044841418a', False)
    ]

    for test_case in test_cases:
        assert __ISBNChecker(test_case[0]).is_isbn_10() == test_case[1]


# Generated at 2022-06-24 02:29:22.117963
# Unit test for function is_integer
def test_is_integer():
    assert is_integer("3")
    assert is_integer("+3")
    assert is_integer("-3")
    assert is_integer("3e3")
    assert is_integer("+3e3")
    assert is_integer("-3e3")
    assert is_integer("3e+3")
    assert is_integer("+3e+3")
    assert is_integer("-3e+3")
    assert is_integer("3e-3")
    assert is_integer("+3e-3")
    assert is_integer("-3e-3")
    assert not is_integer(3)
    assert not is_integer("3.2")
    assert not is_integer("foo")
    assert not is_integer("")
    assert not is_integer(None)



# Generated at 2022-06-24 02:29:28.530471
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') # returns true
    assert is_isbn('1506715214') # returns true
    assert is_isbn('978-0312498580') # returns true
    assert not is_isbn('978-0312498580', normalize=False) # returns false



# Generated at 2022-06-24 02:29:37.043861
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.google.com') == True
    assert is_url('https://github.com') == True
    assert is_url('http://www.google') == False
    assert is_url('http:youtube.com') == False
    assert is_url('.youtube.com') == False
    print("Ok")

test_is_url()

# Email example:
# john.doe@corporation.com
# john.doe+spam@corporation.com
# john.doe.mail@corporation.com
# john.doe.mail+mymail@corporation.com
# john.doe.mail+mymail@subdomain.corporation.com
# john.doe.mail+mymail@subdomain.corporation.com.one.two.three

# Generated at 2022-06-24 02:29:47.179497
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') == True
    assert is_url('https://mysite.com') == True
    assert is_url('.mysite.com') == False
    assert is_url('mysite.com') == False
    assert is_url('') == False
    assert is_url('http://www.mysite.com.au') == True
    assert is_url('http://www.mysite.biz') == True
    assert is_url('https://www.mysite.co.uk') == True
    assert is_url('https://www.mysite.gov') == True
    assert is_url('http://www.mysite.mil') == True
    assert is_url('http://www.mysite.net') == True