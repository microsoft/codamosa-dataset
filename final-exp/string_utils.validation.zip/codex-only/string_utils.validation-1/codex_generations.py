

# Generated at 2022-06-24 02:19:41.488190
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('h')==True
    assert is_isogram('helo')==False
test_is_isogram()

# Generated at 2022-06-24 02:19:48.321414
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580')
    assert is_isbn_13('978-0312498580')
    assert is_isbn_13('978-0312498580', normalize=False)
    
    

# Generated at 2022-06-24 02:19:50.258814
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?') == False


# Generated at 2022-06-24 02:20:01.369549
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') is True
    assert is_isbn_10('150-6715214') is True
    assert is_isbn_10('150-6715214', normalize=False) is False
    assert is_isbn_10('1449372613') is True
    assert is_isbn_10('9573317249') is False
    assert is_isbn_10('99921-58-10-7') is True
    assert is_isbn_10('9971-5-0210-0') is True
    assert is_isbn_10('960-425-059-0') is True
    assert is_isbn_10('80-902734-1-6') is True
    assert is_isbn_10('85-359-0277-5') is True

# Generated at 2022-06-24 02:20:09.956970
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('LOL')
    assert not is_palindrome('Lol')
    assert is_palindrome('Lol', ignore_case=True)
    assert not is_palindrome('ROTFL')
    assert is_palindrome('Lollollo')
    assert is_palindrome('Lololo')
    assert is_palindrome('Lollololol')
    assert is_palindrome('Lololololol')
    assert not is_palindrome('Lollolololo')
    assert is_palindrome('Lololololo')
    assert not is_palindrome('Lollololo')
    assert is_palindrome('Lollololo')
test_is_palindrome()



# Generated at 2022-06-24 02:20:19.730100
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('foo_bar') #true
    assert is_snake_case('foo-bar') #true
    assert is_snake_case('foo-bar') #true
    assert is_snake_case('fool-bar') #true
    assert is_snake_case('fool_bar') #true
    assert is_snake_case('_foo_bar') #true
    assert is_snake_case('_foo-bar') #true
    assert is_snake_case('_foo-bar') #true
    assert is_snake_case('_fool-bar') #true
    assert is_snake_case('foo_bar_') #false
    assert is_snake_case('foo-bar_') #false
    assert is_snake_case('foo-bar_')

# Generated at 2022-06-24 02:20:24.021658
# Unit test for function is_json
def test_is_json():
    assert is_json('{\"name\": \"Peter\"}') is True
    assert is_json('[1, 2, 3]') is True
    assert is_json('{nope}') is False
    assert is_json('') is False
    assert is_json(4) is False
    assert is_json(None) is False
    assert is_json('\"Peter\"') is False
    assert is_json('Peter\"') is False
    assert is_json('[') is False
    assert is_json('[2, 3') is False
    assert is_json('{') is False
    assert is_json('{\"name\": \"Peter\")') is False
    assert is_json('[1, 2, [3, 4]]') is True
    assert is_json('[[], {}]') is True
    assert is_

# Generated at 2022-06-24 02:20:32.825576
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    checker = __ISBNChecker('978-3-16-148410-0', True)
    assert checker.is_isbn_13() is True

    checker = __ISBNChecker('978-3-16-148410-0', False)
    assert checker.is_isbn_13() is False

    checker = __ISBNChecker('978-3-16-148410-1', True)
    assert checker.is_isbn_13() is False

# Generated at 2022-06-24 02:20:34.024003
# Unit test for function is_pangram
def test_is_pangram():
    assert(is_pangram('The quick brown fox jumps over the lazy dog'))  # returns true
    assert(not is_pangram('hello world'))  # returns false


# Generated at 2022-06-24 02:20:38.075700
# Unit test for function is_string
def test_is_string():
    assert is_string('foo')
    assert not is_string(b'foo')


# Generated at 2022-06-24 02:20:46.512126
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('') == False
    assert is_camel_case('MyString') == True
    assert is_camel_case('mystring') == False
    assert is_camel_case('-MyString') == False
    assert is_camel_case('MyString-') == False
    assert is_camel_case('my-string') == False
    assert is_camel_case('my_string') == False



# Generated at 2022-06-24 02:20:48.314451
# Unit test for function is_json
def test_is_json():
    print("test_is_json function")
    assert is_json('{"name": "Peter"}') # returns true
    assert is_json('[1, 2, 3]') # returns true
    assert is_json('{nope}') == False # returns false



# Generated at 2022-06-24 02:20:54.726909
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string(None) == False
    assert is_full_string('') == False
    assert is_full_string(' ') == False
    assert is_full_string('hello') == True
test_is_full_string()


# Generated at 2022-06-24 02:21:01.369229
# Unit test for function words_count
def test_words_count():
    # simple words
    assert words_count('') == 0
    assert words_count('Hello') == 1
    assert words_count('Hello World') == 2
    assert words_count('Hello, World') == 2  # "," is not a word separator
    assert words_count('Hello , World') == 2  # "," is not a word separator
    assert words_count('Hello world!') == 2
    assert words_count('Hello  world!') == 2  # "  " is not a word separator
    assert words_count('Hello, World 123') == 2  # "123" is not a word
    assert words_count('Hello, World 123!') == 2  # "123!" is not a word
    assert words_count('Hello World 123!') == 2  # "123!" is not a word

    # complex words
   

# Generated at 2022-06-24 02:21:06.330773
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string(None) == False
    assert is_full_string('') == False
    assert is_full_string(' ') == False
    assert is_full_string('hello') == True


# Generated at 2022-06-24 02:21:07.847486
# Unit test for function is_string
def test_is_string():
    assert is_string('foo') == True
    assert is_string([]) == False


# Generated at 2022-06-24 02:21:15.279063
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('dermatoglyphics') == True
    assert is_isogram('') == True
    assert is_isogram('aba') == False
    assert is_isogram('moOse') == False
    assert is_isogram('thumbscrewjapingly') == True
    assert is_isogram('thumbscrew-japingly') == False
    assert is_isogram('6bcdic') == True
    assert is_isogram('6bcdi4') == False
    assert is_isogram(u'6bcdei4') == False
    assert is_isogram('6bcdei4') == False
    assert is_isogram('#6bcdei4') == False
    assert is_isogram(u'6bcdei4#') == False

# Generated at 2022-06-24 02:21:16.547022
# Unit test for function is_json
def test_is_json():
	assert is_json('{"name": "Peter"}') # returns true
	assert is_json('[1, 2, 3]') # returns true
	assert not is_json('{nope}') # returns false



# Generated at 2022-06-24 02:21:17.760803
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10("1-2-3-4-5-6-7-8-9-10") == True

# Generated at 2022-06-24 02:21:25.105684
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') is True
    assert is_email('my.email@the-provider.com') is True
    assert is_email('@gmail.com') is False
    assert is_email('\@gmail.com') is False
    assert is_email('"\ my.email"@the-provider.com') is False # (true version: 'my.email@the-provider.com')
    assert is_email('"\\ my.email"@the-provider.com') is True
    assert is_email('.my.email@the-provider.com') is False



# Generated at 2022-06-24 02:21:28.248951
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cg') is False
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') is True
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf') is False
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True) is True



# Generated at 2022-06-24 02:21:32.742636
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('MyString')
    assert not is_camel_case('mystring')
    assert not is_camel_case('123')



# Generated at 2022-06-24 02:21:41.041733
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10(1506715214), "1506715214 should be an ISBN 10 number"
    assert is_isbn_10('150-6715214'), "150-6715214 should be an ISBN 10 number"
    assert not is_isbn_10('150-6715214', normalize=False), "150-6715214 without normalize should NOT be an ISBN 10 number"
    assert not is_isbn_10('1506715214a'), "1506715214a should NOT be an ISBN 10 number"
    assert not is_isbn_10('1506715214-a'), "1506715214-a should NOT be an ISBN 10 number"
    assert not is_isbn_10('1506715214-aa'), "1506715214-aa should NOT be an ISBN 10 number"
    assert not is_isbn

# Generated at 2022-06-24 02:21:47.833678
# Unit test for function is_string
def test_is_string():
    assert is_string("yes") == True
    assert is_string("") == True
    assert is_string("1234") == True
    assert is_string("YES") == True

    assert is_string(b"yes") == False
    assert is_string("") == True
    assert is_string("1234") == True
    assert is_string("YES") == True


# Generated at 2022-06-24 02:21:49.106130
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram("the quick brown fox jumps over the lazy dog")


# Generated at 2022-06-24 02:21:50.989674
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') == True
    assert is_isbn('1506715214') == True
    assert is_isbn('150-6715214') == True
    assert is_isbn('150-6715214', normalize=False) == False
test_is_isbn()



# Generated at 2022-06-24 02:21:57.429995
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('myCamelCase') == True
    assert is_camel_case('myCamel3Case') == True
    assert is_camel_case('') == False
    assert is_camel_case('my_camel_case') == False
    assert is_camel_case('mycamelcase') == False



# Generated at 2022-06-24 02:22:06.714412
# Unit test for function is_number
def test_is_number():
    print("Test case for is_number()")
    assert is_number("3") == True
    assert is_number("3.14") == True
    assert is_number("-9") == True
    assert is_number("asdf") == False
    assert is_number("3.14asdf") == False
    assert is_number("3.14.15") == False
    assert is_number("3.14..15") == False
    assert is_number("3.1415e+8") == True
    assert is_number("3.1415.15e+8") == False
    assert is_number("3.1415e+ 8") == False
    assert is_number("3.1415e") == False
    assert is_number("e+8") == False
test_is_number()



# Generated at 2022-06-24 02:22:15.694550
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker("9971502100").is_isbn_10() == True 
    assert __ISBNChecker("9997150210").is_isbn_10() == False
    assert __ISBNChecker("99715021001").is_isbn_10() == False
    assert __ISBNChecker("").is_isbn_10() == False
    assert __ISBNChecker("9a971502100").is_isbn_10() == False
    assert __ISBNChecker("$$71502100").is_isbn_10() == False


# PUBLIC API


# is_string

# Generated at 2022-06-24 02:22:24.421458
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert is_ip_v4('0.0.0.0')
    assert is_ip_v4('255.255.255.255')
    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999')

test_is_ip_v4()



# Generated at 2022-06-24 02:22:34.328767
# Unit test for function is_uuid
def test_is_uuid():
    # positive test cases
    assert(is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf'))
    assert(is_uuid('6f8aa2f9686c4ac387665712354a04cf'))
    assert(is_uuid('6f8aa2f9686c4ac387665712354a04cf', True))
    # negative test cases
    assert(not is_uuid('6f8aa2f9686c4ac387665712354a04cf'))
    assert(not is_uuid('no uuid here'))
    assert(not is_uuid('6f8aa2f9686c4ac387665712354a04cf', True))

# Generated at 2022-06-24 02:22:39.427902
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6(123) == False
    assert is_ip_v6(None) == False
    assert is_ip_v6('') == False
    assert is_ip_v6('ff01::?1') == False
    assert is_ip_v6('ff01::111') == True
    assert is_ip_v6('1234567') == False



# Generated at 2022-06-24 02:22:40.548687
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}')
    assert is_json('[1, 2, 3]')
    assert not is_json('{nope}')


# Generated at 2022-06-24 02:22:44.230673
# Unit test for function is_string
def test_is_string():
    assert is_string('foo') == True
    assert is_string(b'foo') == False
    assert is_string(5) == False
    assert is_string(2.8) == False
    assert is_string(['foo']) == False


# Generated at 2022-06-24 02:22:55.533373
# Unit test for function is_email
def test_is_email():
	assert is_email('abc123@gmail.com') == True, 'Test 1 failed'
	assert is_email('abc123@yahoo.com') == True, 'Test 2 failed'
	assert is_email('abc123@hotmail.com') == True, 'Test 3 failed'
	assert is_email('t_123@tmail.com') == True, 'Test 4 failed'
	assert is_email('t123@tmail.com') == True, 'Test 5 failed'
	assert is_email('a@gmail.com') == True, 'Test 6 failed'
	assert is_email('abc.123@gmail.com') == True, 'Test 7 failed'
	assert is_email('abc-123@gmail.com') == True, 'Test 8 failed'

# Generated at 2022-06-24 02:22:59.764009
# Unit test for function is_number
def test_is_number():
    # Sample strings
    assert is_number('-3.3') == True
    assert is_number('1e-3') == True
    assert is_number('45') == True

    # Sample strings that should not be accepted
    assert is_number('1 2') == False
    assert is_number('Hello') == False
    assert is_number('1a') == False



# Generated at 2022-06-24 02:23:07.867560
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker("9788477113998").is_isbn_13() == True
    assert __ISBNChecker("97884771139980").is_isbn_13() == True
    assert __ISBNChecker("97884771139981").is_isbn_13() == False
    assert __ISBNChecker("9788477113999").is_isbn_13() == False
    assert __ISBNChecker("978847711399").is_isbn_13() == False
    assert __ISBNChecker("978847711399g").is_isbn_13() == False
    assert __ISBNChecker("97884771139981", normalize=False).is_isbn_13() == False


# Generated at 2022-06-24 02:23:09.588043
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580')
    assert is_isbn_13('978-0312498580')
    assert is_isbn_13('978-0312498580', normalize=False)
# end set_isbn_13


# Generated at 2022-06-24 02:23:11.486705
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title') == True
    assert is_slug('My blog post title') == False


# Generated at 2022-06-24 02:23:20.337984
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    item = __ISBNChecker("978-3-16-148410-0")
    assert item.is_isbn_13()
    assert item.is_isbn_10()

    item = __ISBNChecker("978-3-16-148410-5")
    assert item.is_isbn_13() is False
    assert item.is_isbn_10() is False

    item = __ISBNChecker("978-3-16-148410-0", False)
    assert item.is_isbn_13() is False
    assert item.is_isbn_10() is False

    try:
        __ISBNChecker(123)
        raise AssertionError()
    except InvalidInputError:
        pass


# Generated at 2022-06-24 02:23:29.052710
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('1234567890').is_isbn_10()
    assert __ISBNChecker('0-306-40615-2').is_isbn_10()
    assert __ISBNChecker('2-226-05930-5').is_isbn_10()
    assert __ISBNChecker('84-32-6894-4').is_isbn_10()
    assert __ISBNChecker('84-32-6894-4', False).is_isbn_10()
    assert not __ISBNChecker('978-2-226-05930-2').is_isbn_10()
    assert not __ISBNChecker('978-2-226-05930-3').is_isbn_10()

# Generated at 2022-06-24 02:23:35.245937
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert(__ISBNChecker('0215024145').is_isbn_10() == True)
    assert(__ISBNChecker('1-4134-5389-0').is_isbn_10() == True)
    assert(__ISBNChecker('1-931590-82-2').is_isbn_10() == False)
    assert(__ISBNChecker('1-4134-5389-1').is_isbn_10() == False)


# Generated at 2022-06-24 02:23:42.970365
# Unit test for function contains_html
def test_contains_html():
    # Normal use
    assert(contains_html('my string is <strong>bold</strong>') is True)
    assert(contains_html('my string is not bold') is False)
    # Test that it always returns a boolean
    assert(isinstance(contains_html('my string is <strong>bold</strong>'), bool) is True)
    # Test invalid input
    with pytest.raises(InvalidInputError) as error:
        contains_html(True)


# Generated at 2022-06-24 02:23:47.636172
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') # True
    assert is_ip('255.200.100.75') # True
    assert is_ip('1.2.3') # False
test_is_ip()



# Generated at 2022-06-24 02:23:59.554857
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('test', separator='_') == True
    assert is_slug('TEST', separator='_') == False
    assert is_slug('test-test', separator='_') == False
    assert is_slug('test_test', separator='_') == True
    assert is_slug('test_test_test', separator='_') == True
    assert is_slug('test', separator='') == True
    assert is_slug('test', separator='-') == True
    assert is_slug('test', separator='test') == False
    assert is_slug('test', separator=' ') == False
    assert is_slug('  test  ', separator='-') == False
    assert is_slug('test--test', separator='-') == False

# Generated at 2022-06-24 02:24:10.045742
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.google.com')
    assert is_url('http://www.google.com/')
    assert is_url('http://www.google.com:8080')
    assert is_url('http://www.google.com:8080/')

    assert is_url('https://www.google.com')
    assert is_url('https://www.google.com/')
    assert is_url('https://www.google.com:8080')
    assert is_url('https://www.google.com:8080/')

    assert is_url('ftp://user:password@www.site.com:8080/folder1/folder2/file.png')

    # invalid urls
    assert not is_url('google.com')
    assert not is_url('.google.com')

# Generated at 2022-06-24 02:24:13.445874
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') == True
    assert is_isbn_10('150-6715214') == True
    assert is_isbn_10('150-6715214', normalize=False) == False

# Generated at 2022-06-24 02:24:20.614797
# Unit test for function is_string
def test_is_string():
    assert is_string("") == True
    assert is_string("Hello World") == True
    assert is_string(123) == False
    assert is_string(True) == False
    assert is_string(False) == False
    assert is_string(None) == False
    assert is_string([]) == False
    assert is_string({"key": "value"}) == False
    assert is_string(("first", "second")) == False



# Generated at 2022-06-24 02:24:23.497835
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False

# Generated at 2022-06-24 02:24:32.173018
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('-0')
    assert is_integer('0')
    assert is_integer('42')
    assert is_integer('1.0')
    assert is_integer('1.00')
    assert is_integer('1.0e2')
    assert is_integer('1.00e2')
    assert is_integer('1.0e+2')
    assert is_integer('1.00e+2')
    assert is_integer('1.0e-2')
    assert is_integer('1.00e-2')
    assert not is_integer('-0.0')
    assert not is_integer('-0.00')
    assert not is_integer('42.0')
    assert not is_integer('42.00')
    assert not is_integer('1.0e-2.0')


# Generated at 2022-06-24 02:24:36.772549
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4("255.123.123.123")
    assert not is_ip_v4("255.123.123.123.123")
    assert not is_ip_v4("999.123.123.123")


# Generated at 2022-06-24 02:24:41.052608
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75') == True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip('1.2.3') == False
    print("test_is_ip() passed!")
test_is_ip()


# Generated at 2022-06-24 02:24:45.541804
# Unit test for function is_ip_v4
def test_is_ip_v4():
    """
    Unit test for function is_ip_v4
    """
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False
    assert is_ip_v4('255.200.100.1') == True
    assert is_ip_v4('255.200.100.5') == True
# /Unit test for function is_ip_v4


# Generated at 2022-06-24 02:24:55.220482
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert not __ISBNChecker('9788700631625').is_isbn_13()
    assert __ISBNChecker('978-8-70-063162-5').is_isbn_13()
    assert not __ISBNChecker('1234567890123').is_isbn_13()
    assert __ISBNChecker('0-306-40615-2').is_isbn_13()
    assert __ISBNChecker('0-306-40615-2', False).is_isbn_13()
    assert not __ISBNChecker('0306406152').is_isbn_13()
    assert __ISBNChecker('0306406152', False).is_isbn_13()
    assert not __ISBNChecker('0-9727515-0-3').is_isbn_13()

# Generated at 2022-06-24 02:24:59.884558
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42') == True
    assert is_integer('42.0') == False


# Generated at 2022-06-24 02:25:03.143980
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string('') == False
    assert is_full_string(None) == False
    assert is_full_string(' ') == False
    assert is_full_string('hello') == True

# Generated at 2022-06-24 02:25:05.676714
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False



# Generated at 2022-06-24 02:25:08.996818
# Unit test for function is_number
def test_is_number():
    assert is_number("42")
    assert is_number("19.99")
    assert is_number("-9.12")
    assert is_number("1e3")
    assert is_number("1 2 3")
test_is_number()



# Generated at 2022-06-24 02:25:17.046052
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('hello') == True
    assert is_camel_case('hi') == False
    assert is_camel_case('Hello') == False
    assert is_camel_case('HelloWorld') == True
    assert is_camel_case('HelloWorld123') == True
    assert is_camel_case('hello_world') == False
    assert is_camel_case('Hello World') == False
    assert is_camel_case(None) == False
    assert is_camel_case(2) == False
    assert is_camel_case(12) == False
    assert is_camel_case('12') == False



# Generated at 2022-06-24 02:25:18.951124
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('dermatoglyphics') == True
# Units test for function is_isogram

# Generated at 2022-06-24 02:25:24.201234
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42') == True
    assert is_integer('42.3') == False
    assert is_integer('-3e5') == True


# Generated at 2022-06-24 02:25:30.695618
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580') is True
    assert is_isbn_13('978-0312498580') is True
    assert is_isbn_13('978-0312498580', normalize=False) is False



# Generated at 2022-06-24 02:25:40.473058
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid(uuid4())
    assert not is_uuid(uuid4().hex)
    assert is_uuid(uuid4().hex, allow_hex=True)
    assert not is_uuid('this is not a valid UUID')
    assert not is_uuid('3ec3a186-6539-402d-b9ba-1ae9c4587a87a')  # invalid length
    assert not is_uuid('3ec3a186-6539-402d-b9ba-1ae9c4587a87-')  # invalid length
    assert not is_uuid('3ec3a186-6539-402d-b9ba-1ae9c4587a8')  # invalid length

# Generated at 2022-06-24 02:25:50.241919
# Unit test for function is_email
def test_is_email():
    assert is_email('email@example.com') == 1, 'Domain name'
    assert is_email('firstname.lastname@example.com') == 1, 'Dot in address field'
    assert is_email('email@subdomain.example.com') == 1, 'Subdomain'
    assert is_email('firstname+lastname@example.com') == 1, 'Plus in the address field'
    assert is_email('email@localhost') == 1, 'Localhost'
    assert is_email('email@127.0.0.1') == 1, 'IP address'
    assert is_email('"email"@example.com') == 1, 'Quoted email is considered valid'
    assert is_email('1234567890@example.com') == 1, 'Digits in address are valid'

# Generated at 2022-06-24 02:25:58.514774
# Unit test for function is_pangram
def test_is_pangram():
    # pangram examples
    assert is_pangram('The quick brown fox jumps over the lazy dog')
    assert is_pangram('Pack my box with five dozen liquor jugs.')
    assert is_pangram("Mr. Jock, TV quiz PhD, bags few lynx.")
    assert is_pangram("Two driven jocks help fax my big quiz.")
    assert is_pangram("The five boxing wizards jump quickly.")
    assert is_pangram("Five quacking Zephyrs jolt my wax bed.")
    assert is_pangram("Waltz, nymph, for quick jigs vex Bud.")
    assert is_pangram("Crazy Fredrick bought many very exquisite opal jewels.")
    assert is_pangram("Sixty zippers were quickly picked from the woven jute bag.")
    assert is_pangram

# Generated at 2022-06-24 02:26:04.057696
# Unit test for function is_snake_case
def test_is_snake_case():

    assert(is_snake_case('HelloWorld', '_'))
    assert(not is_snake_case('HelloWorld', '-'))
    # However, if you do not pass the delimiter it assumes that you are using '_' as the default delimiter
    assert(is_snake_case('HelloWorld'))



# Generated at 2022-06-24 02:26:07.143051
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf')
    assert not is_uuid('6f8aa2f9686c4ac387665712354a04cf')


# Generated at 2022-06-24 02:26:14.906799
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('foo_bar_baz') == True
    assert is_snake_case('foo') == False
    assert is_snake_case('foo-bar') == True
    assert is_snake_case('foo-bar', '-') == True
    assert is_snake_case('foo-bar', '-') == True
    assert is_snake_case('foo_bar', '-') == False
    assert is_snake_case('-foo-bar') == False
    assert is_snake_case('_foo_bar') == False
    assert is_snake_case('1_foo_bar') == False
    assert is_snake_case('foo_bar1') == True
    assert is_snake_case('foo_1_bar') == True
    assert is_snake

# Generated at 2022-06-24 02:26:20.974503
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') # returns true
    assert not is_email('@gmail.com') # returns false
    assert is_email('lionel.richie@gmail.com')
    assert is_email('lionel.richie@luis-avila.com')
    assert is_email('lionel.richie@mail.luis-avila.com')
    assert is_email('mail@luis-avila.com')
    assert is_email('lionel.richie+mail@luis-avila.com')
    assert is_email('lionel.richie@mail.luis-avila.com')
    assert is_email('lionel.richie@mail.foo.com')

# Generated at 2022-06-24 02:26:26.562282
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('0545139713') == True
    assert is_isbn_10('0545139713') == True
    assert is_isbn_10('0345482328') == True
    assert is_isbn_10('0306406152') == True
    
    

# Generated at 2022-06-24 02:26:33.951079
# Unit test for function is_slug
def test_is_slug():
  assert is_slug('my-blog-post-title')
  assert not is_slug('My blog post title')
  assert not is_slug('')
  assert not is_slug(None)
  assert not is_slug(123456789)
  assert not is_slug(True)
  assert not is_slug(False)
  assert not is_slug((5,5))
  assert not is_slug([1,2,3])
  assert not is_slug({'a':1})
  assert not is_slug(df)
test_is_slug()
is_slug('my-blog-post-title')


# Generated at 2022-06-24 02:26:37.008308
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') == True
    assert is_url('https://mysite.com') == True
    assert is_url('.mysite.com') == False
test_is_url()



# Generated at 2022-06-24 02:26:43.174329
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('MyString') == True
    assert is_camel_case('myString') == True
    assert is_camel_case('my3String') == True
    assert is_camel_case('3MyString') == False
    assert is_camel_case('My_String') == False
    assert is_camel_case('mystring') == False
    assert is_camel_case('') == False


# Generated at 2022-06-24 02:26:49.474348
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('<h1>hello</h1>')
    assert contains_html('hello<br>')
    assert contains_html('<b>hello</b>')
    assert contains_html('<hr>')
    assert contains_html('<hello!>')
    assert not contains_html('<helloworld>')
    assert not contains_html('hello')


# Generated at 2022-06-24 02:26:58.214287
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') 
    assert not is_email('@gmail.com')
    assert not is_email('<>')
    assert not is_email('<test@example.com>')
    assert is_email('test@example.com')
    assert not is_email('test')
    assert not is_email('test@example')
    assert is_email('test@example.com')
    assert is_email('test@example.co.uk')
    assert not is_email('testexample.com')
    assert not is_email('.test@example.com')
    assert not is_email('test@example.com.')
    assert not is_email('test@example..com')
    assert not is_email('a@a.a')
    assert not is_email

# Generated at 2022-06-24 02:27:09.452495
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('FooBar') == False
    assert is_snake_case('foo_bar') == True
    assert is_snake_case('foo_bar_baz_qux_quux') == True
    assert is_snake_case('foo_bar_baz_qux_quux', separator='-') == True
    assert is_snake_case('foo-bar-baz-qux-quux', separator='-') == True
    assert is_snake_case('foo-bar_baz_qux-quux', separator='-') == False
    assert is_snake_case('foo_bar-baz_qux-quux', separator='-') == False

# Generated at 2022-06-24 02:27:11.254309
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert not is_email('@gmail.com')



# Generated at 2022-06-24 02:27:13.297877
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580')
    assert is_isbn_13('978-0312498580')
    assert is_isbn_13('978-0312498580', normalize=False) == False


# Generated at 2022-06-24 02:27:18.226446
# Unit test for function is_snake_case
def test_is_snake_case():
    assert not is_snake_case('')
    assert not is_snake_case('foo')
    assert not is_snake_case('foo1')
    assert is_snake_case('foo_bar')
    assert is_snake_case('foo_bar_baz')
    assert is_snake_case('foo_bar-baz')
    assert not is_snake_case('foo_1bar')
    assert is_snake_case('foo_1bar_baz')



# Generated at 2022-06-24 02:27:20.463606
# Unit test for function words_count
def test_words_count():
    result = words_count("hello world")
    assert result == 2, "words_count failed"
test_words_count()


# Generated at 2022-06-24 02:27:26.736068
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False
    
    

# Generated at 2022-06-24 02:27:35.826179
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome("otto")
    assert is_palindrome("testo", ignore_case=True)
    assert is_palindrome("testo", ignore_spaces=True)
    assert is_palindrome("i topi non avevano nipoti", ignore_spaces=True)
    assert not is_palindrome("testo")
    assert not is_palindrome("testo", ignore_spaces=True)
    assert not is_palindrome("testo", ignore_case=True)
    assert not is_palindrome("i topi non avevano nipoti")
    assert not is_palindrome("i topi non avevano nipoti", ignore_case=True)
test_is_palindrome()


# Generated at 2022-06-24 02:27:46.689079
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('1230987465').is_isbn_10() == True
    assert __ISBNChecker('123-0987465').is_isbn_10() == True
    assert __ISBNChecker('123 0987465').is_isbn_10() == True
    assert __ISBNChecker('0123 0987465').is_isbn_10() == True

    assert __ISBNChecker('12309874650').is_isbn_10() == False
    assert __ISBNChecker('a2309874650').is_isbn_10() == False
    assert __ISBNChecker('a2309874650.1').is_isbn_10() == False
    assert __ISBNChecker('012w0987465').is_isbn_10() == False

# Generated at 2022-06-24 02:27:48.160275
# Unit test for function is_string
def test_is_string():
    assert is_string('bar') == True
    assert is_string(b'foo') == False
    return True


# Generated at 2022-06-24 02:27:56.018042
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    assert __ISBNChecker('978-3-16-148410-0', True).input_string == '9783161484100'
    assert __ISBNChecker('978-3-16-148410-0', False).input_string == '978-3-16-148410-0'
    assert __ISBNChecker('9783161484100').input_string == '9783161484100'
    assert __ISBNChecker('978-3-16-148410-0').input_string == '9783161484100'

    try:
        __ISBNChecker(None)
        assert False
    except InvalidInputError:
        assert True


# PUBLIC API

# is_string


# Generated at 2022-06-24 02:27:57.835367
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title') == True
    assert is_slug('My blog post title') == False
    
test_is_slug()

# Generated at 2022-06-24 02:28:07.427987
# Unit test for function words_count
def test_words_count():
    assert words_count('hello') == 1
    assert words_count('hello,world') == 2
    assert words_count('hello, world') == 2
    assert words_count('hello,world.') == 2
    assert words_count('hello,world.!') == 2
    assert words_count('hello\nworld.') == 2
    assert words_count('hello\nworld.!') == 2
    assert words_count('hello,world\n.') == 2
    assert words_count('hello,world\n.!') == 2
    assert words_count('hello,world.\n!') == 2
    assert words_count('! @ # % ... []') == 0
    assert words_count('123,456,789.stop') == 4

# Generated at 2022-06-24 02:28:11.719681
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('1234567890').is_isbn_10() is True
    assert __ISBNChecker('123456789X').is_isbn_10() is False
    assert __ISBNChecker('123456789x').is_isbn_10() is False
    assert __ISBNChecker('1234567899').is_isbn_10() is True
    assert __ISBNChecker('123456789').is_isbn_10() is False
    assert __ISBNChecker('12345678999').is_isbn_10() is False
    assert __ISBNChecker('').is_isbn_10() is False

# Generated at 2022-06-24 02:28:17.794911
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string(None) is False
    assert is_full_string('') is False
    assert is_full_string(' ') is False
    assert is_full_string('hello') is True
test_is_full_string()



# Generated at 2022-06-24 02:28:28.086510
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978 0 580 89000 9').is_isbn_13() == True
    assert __ISBNChecker('978-0-580-890009').is_isbn_13() == True
    assert __ISBNChecker('978-0-580-890009', normalize=False).is_isbn_13() == True
    assert __ISBNChecker('978-0-580-89000').is_isbn_13() == False
    assert __ISBNChecker('978-0-580-89000 9').is_isbn_13() == False
    assert __ISBNChecker('978-0-580-89000-9').is_isbn_13() == False
    assert __ISBNChecker('978 0 580 89000 9', normalize=False).is_isbn_13() == False

# Generated at 2022-06-24 02:28:33.900325
# Unit test for function is_isbn_10
def test_is_isbn_10():
    from bookish import is_isbn_10
    assert is_isbn_10('1506715214') == True
    assert is_isbn_10('150-6715214') == True
    assert is_isbn_10('150-6715214', normalize=False) == False
test_is_isbn_10()


# Generated at 2022-06-24 02:28:35.352201
# Unit test for function words_count
def test_words_count():
    assert words_count('hello world') == 2
    assert words_count('one,two,three.stop') == 4

# Generated at 2022-06-24 02:28:40.621065
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}')
    assert is_json('[1, 2, 3]')
    assert not is_json('{nope}')
    return "Unit test for function is_json successful"



# Generated at 2022-06-24 02:28:51.521322
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') is True
    assert is_isbn_10('150-6715214') is True
    assert is_isbn_10('150-6715214', normalize=False) is False
    assert is_isbn_10('-5--5') is False
    assert is_isbn_10('Hello') is False
    assert is_isbn_10('-') is False
    assert is_isbn_10('') is False
    assert is_isbn_10(None) is False
    assert is_isbn_10(20) is False
    assert is_isbn_10(True) is False
    assert is_isbn_10('10-8888-8888-X') is False
    assert is_isbn_10('10-88888888-X')

# Generated at 2022-06-24 02:28:54.774056
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75')
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334')
    assert is_ip('1.2.3') == False
test_is_ip()


# Generated at 2022-06-24 02:29:02.862367
# Unit test for function is_email
def test_is_email():
    assert (is_email('my.email@gmail.com')== True)
    assert (is_email('myemail@gmail.com')== True)
    assert (is_email('.myemail@gmail.com')== False)
    assert (is_email('my.emailgmail.com')== False)
    assert (is_email('@gmail.com')== False)
    assert (is_email('"test"@gmail.com')== True)
    assert (is_email('"tes\"t"@gmail.com')== True)
    assert (is_email('"test"test@gmail.com')== True)
test_is_email()



# Generated at 2022-06-24 02:29:07.424411
# Unit test for function is_string
def test_is_string():
    assert is_string('foo') == True
    assert is_string(b'foo') == False


# Generated at 2022-06-24 02:29:09.393101
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('2001:4860:4860::8888') == True

# Generated at 2022-06-24 02:29:18.102146
# Unit test for function is_credit_card
def test_is_credit_card():
    assert(is_credit_card("5105105105105100", "MASTERCARD") == True)
    assert(is_credit_card("51051051-0510-5100", "MASTERCARD") == True)
    assert(is_credit_card("5105105105105106", "MASTERCARD") == False)
    assert(is_credit_card("5105105115105100", "MASTERCARD") == False)
    assert(is_credit_card("4111111111111111", "VISA") == True)
    assert(is_credit_card("4012888888881881", "VISA") == True)
    assert(is_credit_card("4222222222222", "VISA") == True)

# Generated at 2022-06-24 02:29:20.532023
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title')
    assert not is_slug('My blog post title')



# Generated at 2022-06-24 02:29:30.772699
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    checker = __ISBNChecker('978-3-16-148410-0')
    assert checker.is_isbn_13(), '978-3-16-148410-0 must be a valid ISBN 13 code'
    checker = __ISBNChecker('979-10-97911-06-2')
    assert checker.is_isbn_13(), '979-10-97911-06-2 must be a valid ISBN 13 code'
    checker = __ISBNChecker('978-3-16-148410-8')
    assert not checker.is_isbn_13(), '978-3-16-148410-8 must not be a valid ISBN 13 code'
    checker = __ISBNChecker('978-3-16-148410-2')
    assert not check

# Generated at 2022-06-24 02:29:35.612190
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580') == True
    assert is_isbn_13('9780312498580', normalize=False) == False
    assert is_isbn_13('978-0312498580') == True
    assert is_isbn_13('978-0312498580', normalize=False) == False


# Generated at 2022-06-24 02:29:46.012532
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('127.0.0.1')
    assert is_ip('192.168.1.1')
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334')
    assert is_ip('2001:db8:85a3::8a2e:370:7334')
    assert not is_ip('localhost')
    assert not is_ip('2001:db8:85a3:0000:0000:8a2e:370')
    assert not is_ip('2001:db8:85a3:0000:0000:8a2e:370:')