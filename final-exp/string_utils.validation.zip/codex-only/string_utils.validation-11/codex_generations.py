

# Generated at 2022-06-24 02:19:48.357289
# Unit test for function is_ip
def test_is_ip():
    assert(is_ip('255.200.100.75'))
    assert(is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334'))
    assert(not is_ip('1.2.3'))


# Generated at 2022-06-24 02:19:51.088669
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string('') == False
    assert is_full_string(' ') == False
    assert is_full_string('\n') == False
    assert is_full_string('hello') == True


# Generated at 2022-06-24 02:20:02.104261
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('') == False
    assert is_snake_case('_') == False
    assert is_snake_case('0a') == False
    assert is_snake_case('a') == False
    assert is_snake_case('aa') == False
    assert is_snake_case('aa_') == False
    assert is_snake_case('aa_bb') == True
    assert is_snake_case('aa_bb_cc') == True
    assert is_snake_case('AA_BB_CC') == True
    assert is_snake_case('AA_BB_CC', '-') == False
    assert is_snake_case('aa-bb-cc', '-') == True
    assert is_snake_case('-a-b-') == False
   

# Generated at 2022-06-24 02:20:10.832743
# Unit test for function is_palindrome
def test_is_palindrome():
    tests = {
            'A man a plan a canal Panama': True,
            'tacocat': True,
            'otto': True,
            'racecar': True,
            'was it a car or a cat I saw': True,
            'No lemon, no melon': True,
            'Do geese see God': True,
            'Do nine men interpret?': True,
            'Never odd or even': True,
            'ROTFL': False,
            'Lol': False,
            'LOL': True,
            'I topi non avevano nipoti': True,
            'I topi non avevano nipotI': True
    }

    for input_string, expected_result in tests.items():
        assert is_palindrome(input_string) == expected_result
test_is

# Generated at 2022-06-24 02:20:11.778244
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title') == True
    assert is_slug('My blog post title') == False


# Generated at 2022-06-24 02:20:18.168119
# Unit test for function words_count
def test_words_count():
    assert words_count('hello world') == 2
    assert words_count('one,two,three.stop') == 4
    assert words_count('! @ # % ... []') == 0
    assert words_count('') == 0
    assert words_count(None) == 0

if __name__ == '__main__':
    test_words_count()

# Generated at 2022-06-24 02:20:24.788307
# Unit test for function is_number
def test_is_number():
    assert is_number('42'), 'is_number failed for 42'
    assert is_number('19.99'), 'is_number failed for 19.99'
    assert is_number('-9.12'), 'is_number failed for -9.12'
    assert is_number('1e3'), 'is_number failed for 1e3'
    assert not is_number('1 2 3'), 'is_number failed for "1 2 3"'



# Generated at 2022-06-24 02:20:30.079510
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') == True
    assert is_url('https://mysite.com') ==True
    assert is_url('.mysite.com') == False


# Generated at 2022-06-24 02:20:38.679725
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    checker = __ISBNChecker('978-3-16-148410-0')
    assert checker.is_isbn_13()

    checker = __ISBNChecker('9783161484100')
    assert checker.is_isbn_13()

    checker = __ISBNChecker('97831614841001')
    assert not checker.is_isbn_13()

    checker = __ISBNChecker('978316148410a')
    assert not checker.is_isbn_13()

    checker = __ISBNChecker('978316148410')
    assert not checker.is_isbn_13()



# Generated at 2022-06-24 02:20:50.415608
# Unit test for function is_slug
def test_is_slug():
    assert(is_slug('my-blog-post-title'))
    assert(is_slug('my-blog-post-title', separator='-') == True)
    assert(is_slug('my_blog_post_title', separator='_') == True)
    assert(is_slug('myblogposttitle', separator='') == True)
    assert(is_slug('my blog post title') == False)
    assert(is_slug('My Blog Post Title') == False)
    assert(is_slug('È stupendo') == False)
    assert(is_slug('è-stupendo') == True)
    assert(is_slug('è stupendo') == False)
    assert(is_slug('è_stupendo') == False)

# Generated at 2022-06-24 02:20:52.005412
# Unit test for function is_string
def test_is_string():
    assert is_string('foo') == True
    assert is_string(b'foo') == False


# Generated at 2022-06-24 02:20:58.070898
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False

test_is_ip_v4()



# Generated at 2022-06-24 02:21:08.405553
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('5105105105105100') == True
    assert is_credit_card('5105105105105106') == False
    assert is_credit_card('30569309025904') == False
    assert is_credit_card('30569309025904', card_type='AMERICAN_EXPRESS') == True
    assert is_credit_card('30569309025904', card_type='VISA') == False
    assert is_credit_card('30569309025904', card_type='MASTERCARD') == False
    assert is_credit_card('30569309025904', card_type='DISCOVER') == False
    assert is_credit_card('30569309025904', card_type='DINERS_CLUB') == False

# Generated at 2022-06-24 02:21:14.670683
# Unit test for function is_isogram
def test_is_isogram():
    expected = ((None  , False),
                (""    , True ),
                ("aAa" , False),
                ("a"   , True ),
                ("abc" , True ),
                ("abca", False))

    for (input_string, expected_result) in expected:
        assert is_isogram(input_string) is expected_result
test_is_isogram()


# Generated at 2022-06-24 02:21:26.236604
# Unit test for function is_slug
def test_is_slug():
    # Test with default parameters
    assert is_slug("my-blog-post-title")
    assert is_slug("my-blog-post--title")
    assert is_slug("my-blog-post---title")
    assert is_slug("-my-blog-post-title")
    assert is_slug("--my-blog-post-title")
    assert is_slug("---my-blog-post-title")
    assert is_slug("my-blog-post-title-")
    assert is_slug("my-blog-post-title--")
    assert is_slug("my-blog-post-title---")
    assert is_slug("my-blog-post-title")
    assert not is_slug(" My blog post title")

# Generated at 2022-06-24 02:21:28.512749
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('hello-world') # True
    assert is_slug('hello-world', '_') # True
    assert not is_slug('hello world') # False
    assert not is_slug('') # False



# Generated at 2022-06-24 02:21:37.662414
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('9780131495050').is_isbn_13()
    assert __ISBNChecker('978-0-13-149505-0', normalize=False).is_isbn_13()
    assert __ISBNChecker('978-0-13-149505-0', normalize=True).is_isbn_13()
    assert not __ISBNChecker('123456789').is_isbn_13()
    assert not __ISBNChecker('9780131495051').is_isbn_13()



# Generated at 2022-06-24 02:21:43.556720
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') == True
    assert is_isbn_10('150-6715214') == True
    assert is_isbn_10('150-6715214', normalize=False) == False


# Generated at 2022-06-24 02:21:48.100078
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4("192.168.1.1") == True
    assert is_ip_v4("999.168.1.1") == False
    assert is_ip_v4("192.168.a.1") == False



# Generated at 2022-06-24 02:21:59.128067
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    print('Test running...')

# Generated at 2022-06-24 02:22:02.861079
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False
    print('Test is_ip_v4 passed!')
test_is_ip_v4()



# Generated at 2022-06-24 02:22:05.390433
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580') == True
    assert is_isbn_13('978-0312498580') == True
    assert is_isbn_13('978-0312498580', normalize=False) == False
    assert is_isbn_13('97910312498580') == False
    
    
test_is_isbn_13()




# Generated at 2022-06-24 02:22:12.483127
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn("9780312498580")
    assert is_isbn("978-0312498580")
    assert not is_isbn("978-0312498580", normalize=False)
    assert is_isbn("1506715214")
    assert is_isbn("150-6715214")
    assert not is_isbn("150-6715214", normalize=False)



# Generated at 2022-06-24 02:22:13.144778
# Unit test for function words_count
def test_words_count():
    assert words_count('My Long string!!') == 3



# Generated at 2022-06-24 02:22:16.951043
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') == True
    assert is_url('https://mysite.com') == True
    assert is_url('.mysite.com') == False
test_is_url()

# Generated at 2022-06-24 02:22:28.085660
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4111111111111111')
    assert is_credit_card('4111111111111111',card_type='VISA')
    assert not is_credit_card('4111111111111111',card_type='MASTERCARD')
    assert is_credit_card('5500000000000004')
    assert is_credit_card('378282246310005')
    assert not is_credit_card('378282246310005',card_type='MASTERCARD')
    assert is_credit_card('6011111111111117')
    assert is_credit_card('3530111333300000')
    assert not is_credit_card('3530111333300000',card_type='AMERICAN_EXPRESS')
    assert is_credit_card('3566002020360505')
    assert is_credit_

# Generated at 2022-06-24 02:22:34.629896
# Unit test for function is_number
def test_is_number():
    assert is_number('42') == True
    assert is_number('19.99') == True
    assert is_number('-9.12') == True
    assert is_number('1e3') == True
    assert is_number('1 2 3') == False



# Generated at 2022-06-24 02:22:43.236053
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    assert __ISBNChecker('978-0-306-40615-7').input_string == '9780306406157'
    assert __ISBNChecker('0-306-40615-2').input_string == '030-640615-2'
    assert __ISBNChecker('0306406152').input_string == '0306406152'

    try:
        __ISBNChecker(1)
        assert False, 'exception not thrown'
    except:
        assert True


# PUBLIC API


# String checks

# Checks if input is a string

# Generated at 2022-06-24 02:22:49.582676
# Unit test for function is_url
def test_is_url():
    assert is_url("http://www.example.com")
    assert is_url("https://example.com")
    assert is_url("ftp://example.com")
    assert is_url("file://example.com")
    assert is_url("https://example.com/path/to/a/file.txt")
    assert not is_url("example.com")
    assert not is_url("www.example.com")
    assert is_url("http://1.1.1.1")
    assert is_url("https://user:pass@example.com")
    assert is_url("ftp://user:pass@example.com")
    assert is_url("file://user:pass@example.com")
    assert is_url("https://user:pass@example.com/path/to/a/file.txt")

# Generated at 2022-06-24 02:22:54.063762
# Unit test for function is_string
def test_is_string():
    assert is_string('foo') == True
    assert is_string(b'foo') == False

# Generated at 2022-06-24 02:23:01.215715
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    expected = False
    actual = __ISBNChecker('0123456789').is_isbn_10()
    assert actual == expected, "Test #1 - is_isbn_10 didn't return FALSE for an invalid ISBN-10"

    expected = True
    actual = __ISBNChecker('0785263448').is_isbn_10()
    assert actual == expected, "Test #2 - is_isbn_10 didn't return TRUE for an valid ISBN-10"

    expected = True
    actual = __ISBNChecker('9780785263447').is_isbn_10()
    assert actual == expected, "Test #3 - is_isbn_10 didn't return TRUE for an valid ISBN-10"

    expected = False
    actual = __ISBNChecker('97807852634473').is_isbn_10()


# Generated at 2022-06-24 02:23:03.666136
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('foo_bar') == True
    assert is_snake_case('foo') == False


# Generated at 2022-06-24 02:23:06.638608
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('hello') is False
    assert is_isogram('dermatoglyphics') is True
    assert is_isogram('moOse') is False
    assert is_isogram('moose') is True
    
test_is_isogram()


# Generated at 2022-06-24 02:23:16.184413
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('9781449337711').is_isbn_13()
    assert __ISBNChecker('978-1449337711').is_isbn_13()
    assert not __ISBNChecker('9781449337712').is_isbn_13()
    assert not __ISBNChecker('978-1449337712').is_isbn_13()
    assert not __ISBNChecker('978144933771').is_isbn_13()
    assert not __ISBNChecker('978-144933771').is_isbn_13()
    assert not __ISBNChecker('97814493377111').is_isbn_13()
    assert not __ISBNChecker('978-14493377111').is_isbn_13()

# Generated at 2022-06-24 02:23:26.959904
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('i topi non avevano nipoti', ignore_spaces=True) == True
    assert is_palindrome('i topi non avevano nipoti', ignore_spaces=False) == False
    assert is_palindrome('I topi non avevano nipoti', ignore_spaces = False, ignore_case = True) == True
    assert is_palindrome('I topi non avevano nipoti', ignore_spaces = False, ignore_case = False) == False
    assert is_palindrome('123452345', ignore_spaces=True) == False
    assert is_palindrome('123454321', ignore_spaces=True) == True
    assert is_palindrome('123456', ignore_spaces=True) == False 

# Generated at 2022-06-24 02:23:38.089236
# Unit test for function contains_html
def test_contains_html():

    assert contains_html('my string is <strong>bold</strong>')
    assert contains_html('my string is <strong>bold')
    assert contains_html('my string is <strong>bold')
    assert contains_html('my string is <strong>bold')
    assert contains_html('my string is <strong>bold')
    assert contains_html('my string is <strong>bold')
    assert contains_html('<strong>bold</strong>')
    assert contains_html('<li>')
    assert contains_html('</li>')
    assert contains_html('<a href="https://my.web">Awesome link</a>')
    assert contains_html('<li>')
    assert contains_html('<li>')
    assert contains_html('<li>')

# Generated at 2022-06-24 02:23:43.026193
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1-902616-41-7') == True     # valid ISBN 10
    assert is_isbn_10('1-902616-42-7') == False    # invalid ISBN 10


# Generated at 2022-06-24 02:23:48.480876
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('duplicates') is True
    assert is_isogram('isogram') is True
    assert is_isogram('eleven') is False
    assert is_isogram('subdermatoglyphic') is True
    assert is_isogram('Alphabet') is False
    assert is_isogram('alphAbet') is False

test_is_isogram()

# Generated at 2022-06-24 02:23:54.396711
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False
    assert is_json('') == False
    assert is_json(123) == False



# Generated at 2022-06-24 02:24:04.351039
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com')
    assert is_url('https://mysite.com')
    assert not is_url('www.mysite.com')
    assert not is_url('aaa')
    assert not is_url('...')
    assert not is_url('/..')
    assert not is_url('?&')
    assert not is_url('javadoc.io')
    assert is_url('javadoc.io', ['http', 'ftp'])
    assert not is_url('javadoc.io', ['http', 'ftp'])
    assert is_url('ftp://javadoc.io', ['http', 'ftp'])



# Generated at 2022-06-24 02:24:07.306059
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title') # returns true
    assert not is_slug('My blog post title') # returns false
is_slug('My blog post title')


# Generated at 2022-06-24 02:24:10.473374
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('-42') == True
    assert is_integer('+42') == True
    assert is_integer('42') == True
    assert is_integer('42.0') == False
    assert is_integer('42.00') == False



# Generated at 2022-06-24 02:24:15.791561
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string('hello') == True
    assert is_full_string('') == False
    assert is_full_string(None) == False
    assert is_full_string(' ') == False
# Test cases for function is_full_string
test_is_full_string()



# Generated at 2022-06-24 02:24:21.851173
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') == True
    assert is_isbn('1506715214') == True
    assert is_isbn('1455582349') == True
    assert is_isbn('978-0312498580') == True
    assert is_isbn('978-0312498580', normalize=False) == False
    assert is_isbn('1455582349', normalize=False) == False

# Generated at 2022-06-24 02:24:31.132937
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('my_string')
    assert is_snake_case('my_string', '_')

    assert not is_snake_case('mystring')
    assert not is_snake_case('mystring', '_')

    assert is_snake_case('my-string', '-')
    assert not is_snake_case('my_string', '-')

    assert is_snake_case('-mystring')
    assert is_snake_case('-mystring', '_')

    assert is_snake_case('string_with__extra-separators_')
    assert is_snake_case('string_with__extra-separators_', '_')

    assert is_snake_case('trailing-separators_', '_')
    assert is_snake_case

# Generated at 2022-06-24 02:24:36.761274
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('my string is <strong>bold</strong>')
    assert not contains_html('my string is not bold')

    # Since we are using a blind pattern, this will match any text
    assert contains_html('<my-string')
    assert contains_html('my-string>')



# Generated at 2022-06-24 02:24:45.741493
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('i topi non avevano nipoti') == False
    assert is_palindrome('i topi non avevano nipoti', ignore_spaces=True) == True
    assert is_palindrome('LOL') == True
    assert is_palindrome('Lol', ignore_case=True) == True
    assert is_palindrome('ROTFL') == False



# Generated at 2022-06-24 02:24:50.745715
# Unit test for function is_uuid
def test_is_uuid():
    input_string = '6f8aa2f9-686c-4ac3-8766-5712354a04cf'
    expected_output = True
    #output =  is_uuid(input_string)
    assert is_uuid(input_string) == expected_output, 'Test Failed'

test_is_uuid()



# Generated at 2022-06-24 02:24:52.159991
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog') == True
    assert is_pangram('hello world') == False
is_pangram('The quick brown fox jumps over the lazy dog')
 


# Generated at 2022-06-24 02:24:58.762478
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10("1506715214")
    assert not is_isbn_10("1506715215")
    assert is_isbn_10("150-6715214")
    assert not is_isbn_10("150-6715214", normalize=False)


# Generated at 2022-06-24 02:24:59.838655
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog')
    assert not is_pangram('hello world')



# Generated at 2022-06-24 02:25:04.910243
# Unit test for function is_integer
def test_is_integer():
    assert is_integer("+42") == True
    assert is_integer("-42") == True
    assert is_integer("42") == True
    assert is_integer("42.0") == False
    assert is_integer("42.00") == False
    assert is_integer("-42.00") == False
    assert is_integer("-42.0") == False
    assert is_integer("1e3") == True
    assert is_integer("word") == False
    assert is_integer(b'foo') == False



# Generated at 2022-06-24 02:25:16.059577
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('1234567890123').is_isbn_13() == True
    assert __ISBNChecker('9781234567890').is_isbn_13() == True
    assert __ISBNChecker('0-306-40615-2').is_isbn_13() == True
    assert __ISBNChecker('0-306-40615-2', normalize=False).is_isbn_13() == True

    assert __ISBNChecker('123456789012').is_isbn_13() == False
    assert __ISBNChecker('9781234567899').is_isbn_13() == False
    assert __ISBNChecker('0-306-40615-x').is_isbn_13() == False

# Generated at 2022-06-24 02:25:20.527076
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf', True)
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf')
    assert not is_uuid('6f8aa2f9686c4ac387665712354a04cf', True)
    assert not is_uuid('6f8aa2f9686c4ac387665712354a04cf')



# Generated at 2022-06-24 02:25:29.076818
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case("foo") is False
    assert is_snake_case("foo_bar_baz") is True
    assert is_snake_case("foobarbaz") is False
    assert is_snake_case("foo_Bar_baz") is True
    assert is_snake_case("foo_Bar_baz9") is True
    assert is_snake_case("FooBarBaz") is False
    assert is_snake_case("9FooBarBaz") is False
    assert is_snake_case("_FooBarBaz_") is True
    assert is_snake_case("foo-bar-baz") is False
    assert is_snake_case("foo-bar-baz", separator='-') is True

# Generated at 2022-06-24 02:25:35.072924
# Unit test for function is_number
def test_is_number():
    assert is_number(' 42') == True
    assert is_number('19.99') == True
    assert is_number('-9.13') == True
    assert is_number('1e4') == True
    assert is_number('1 2 3') == False


# Generated at 2022-06-24 02:25:39.116117
# Unit test for function is_isbn
def test_is_isbn():
  #Tests ISBN 13
  assert is_isbn('9780312498580') is True
  assert is_isbn('9780312498580', normalize=False) is True
  assert is_isbn('9780312498580') is True
  assert is_isbn('978-0312498580') is True
  assert is_isbn('978-0312498580', normalize=False) is True
  assert is_isbn('978-0312498580') is True
  
  #Tests ISBN 10
  assert is_isbn('1506715214') is True
  assert is_isbn('150-6715214') is True
  assert is_isbn('150-6715214', normalize=False) is True
  assert is_isbn('150-6715214') is True


# Generated at 2022-06-24 02:25:43.033256
# Unit test for function is_integer
def test_is_integer():
    print("Testing if it is an integer")
    assert(is_integer('42')==True)
    assert(is_integer('42.0')==False)

test_is_integer()



# Generated at 2022-06-24 02:25:49.065728
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('<a>') is True
    assert contains_html('<a href="test">') is True
    assert contains_html('<a href="test"/>') is True
    assert contains_html('<!doctype html>') is True
    assert contains_html('<!DOCTYPE html>') is True
    assert contains_html('<div data-test="test"></div>') is True
    assert contains_html('test <test>') is True
    assert contains_html('test') is False
    assert contains_html(123) is False
    assert contains_html(u'<a>') is True
    assert contains_html(b'<a>') is True



# Generated at 2022-06-24 02:25:50.501343
# Unit test for function is_json
def test_is_json():
    assert(is_json('{"name": "Peter"}') == True)
    assert(is_json('[1, 2, 3]') == True)
    assert(is_json('{nope}') == False)



# Generated at 2022-06-24 02:25:58.124431
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    checker = __ISBNChecker('1234', False)
    assert checker.input_string == '1234'

    checker = __ISBNChecker('123-4', False)
    assert checker.input_string == '123-4'

    checker = __ISBNChecker('1234', True)
    assert checker.input_string == '1234'

    checker = __ISBNChecker('123-4', True)
    assert checker.input_string == '1234'

    # Test that the constructor raises exception with invalid input
    try:
        __ISBNChecker(123)
        assert False
    except InvalidInputError:
        pass

    try:
        __ISBNChecker(123.4)
        assert False
    except InvalidInputError:
        pass


# Generated at 2022-06-24 02:26:00.828452
# Unit test for function is_number
def test_is_number():
    assert(is_number('42') == True)
    assert(is_number('19.99') == True)
    assert(is_number('-9.12') == True)
    assert(is_number('1e3') == True)
    assert(is_number('1 2 3') == False)



# Generated at 2022-06-24 02:26:06.710366
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('my string is <strong>bold</strong>') == True
    assert contains_html('my string is not bold') == False
    assert contains_html('<html>') == True
    assert contains_html('<html><head>') == True
    assert contains_html('') == False
    assert contains_html('<>') == False
    assert contains_html('this is a string') == False
    assert contains_html('this is a string<') == False
    assert contains_html('this is a string>') == False
    assert contains_html('this is a string<>') == False
    assert contains_html('<this is a string>') == False
    assert contains_html('this is a <string>') == False
    assert contains_html('this is a string') == False

# Generated at 2022-06-24 02:26:07.940462
# Unit test for function is_string
def test_is_string():
    assert is_string('foo') is True
    assert is_string(b'foo') is False


# Generated at 2022-06-24 02:26:14.011480
# Unit test for function is_pangram
def test_is_pangram():
  assert is_pangram("The quick brown fox jumps over the lazy dog.") == True
  assert is_pangram("The quick brown fox") == False
  print("is_pangram Passed.")
#test_is_pangram()


# Generated at 2022-06-24 02:26:24.369651
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('otto')
    assert is_palindrome('i topi non avevano nipoti')
    assert is_palindrome('otto', ignore_spaces=True)
    assert is_palindrome('i topi non avevano nipoti', ignore_spaces=True)
    assert is_palindrome('ROTFL', ignore_case=True)
    assert is_palindrome('ROTFL', ignore_case=True, ignore_spaces=True)
    assert is_palindrome('rOTFl', ignore_case=True)
    assert is_palindrome('rOTFl', ignore_case=True, ignore_spaces=True)
    assert is_palindrome('Non palindrome') is False

# Generated at 2022-06-24 02:26:29.115470
# Unit test for function is_full_string
def test_is_full_string():
    assert not is_full_string(None)
    assert not is_full_string('')
    assert not is_full_string(' ')
    assert is_full_string('hello')


# Generated at 2022-06-24 02:26:38.133141
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') is True
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf') is False
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True) is True
# ----------------------------------------------------

# Generated at 2022-06-24 02:26:41.936923
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog')
    assert not is_pangram('hello world')
    print("Test is_pangram passed")


# Generated at 2022-06-24 02:26:53.719917
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('my string is <strong>bold</strong>') == True
    assert contains_html('my string is not bold') == False
    assert contains_html('<') == True
    assert contains_html('>') == True
    assert contains_html('<>') == True
    assert contains_html('</>') == True
    assert contains_html('<img>') == True
    assert contains_html('<image>') == True
    assert contains_html('<abcde>') == True
    assert contains_html('<img class="my-class" src="my-image.png" />') == True
    assert contains_html('<img class="my-class" src="my-image.png" >') == True

# Generated at 2022-06-24 02:27:06.609481
# Unit test for function is_uuid
def test_is_uuid():

    assert is_uuid('00000000-0000-0000-0000-000000000000') is True
    assert is_uuid('00000000-0000-0000-0000-000000000000', allow_hex=True) is True
    assert is_uuid('000000000000-0000-0000-000000000000') is False
    assert is_uuid('00000000-0000-0000-0000-000000000000', allow_hex=False) is True
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') is True
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf') is False
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True) is True

# Generated at 2022-06-24 02:27:08.622577
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580')
    assert is_isbn('1506715214')
    assert not is_isbn('!')



# Generated at 2022-06-24 02:27:14.628452
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('<html>') is True
    assert contains_html('a<br/>b') is True
    assert contains_html('a<br />b') is True
    assert contains_html('a <br>b') is True
    assert contains_html('a<br/> b') is True
    assert contains_html('a <br /> b') is True
    assert contains_html('a <br> b') is True
    assert contains_html('a <br /> b') is True
    assert contains_html('a <br> b') is True
    assert contains_html('<a href="http://example.org">link</a>') is True
    assert contains_html('<a href=\'http://example.org\'>link</a>') is True

# Generated at 2022-06-24 02:27:26.339708
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('A'), "A"
    assert is_palindrome('AAA'), "AAA"
    assert is_palindrome('ABA'), "ABA"
    assert is_palindrome('ABBA'), "ABBA"
    assert is_palindrome('ABCBA'), "ABCBA"
    assert is_palindrome('ABCCBA'), "ABCCBA"
    assert is_palindrome('AAAA'), "AAAA"
    assert is_palindrome('AAABAA'), "AAABAA"
    assert not is_palindrome(''), ""
    assert not is_palindrome(' '), " "
    assert not is_palindrome('B'), "B"
    assert not is_palindrome('AB'), "AB"
    assert not is_palindrome('ABC'), "ABC"
   

# Generated at 2022-06-24 02:27:28.998190
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214')
    assert is_isbn_10('150-6715214')
    assert is_isbn_10('150-6715214', normalize=False)



# Generated at 2022-06-24 02:27:34.462852
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('the quick brown fox jumps over the lazy dog')
    assert not is_pangram('hello world')
    assert is_pangram('Pack my box with five dozen liquor jugs')


# Generated at 2022-06-24 02:27:40.606479
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('123.123') == True
    assert is_decimal('123.0') == True
    assert is_decimal('0.123') == True
    assert is_decimal('123') == False
    assert is_decimal('a') == False
    print('is_decimal ok')

test_is_decimal()



# Generated at 2022-06-24 02:27:46.017134
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('hello-world')
    assert is_slug('hello-world', separator='_')
    assert is_slug('hello-')
    assert is_slug('hello-world-')
    assert is_slug(r'hello-world-unicode-', separator=r'-')
    assert not is_slug(r'hello-world-unicode-', separator=' ')
    assert not is_slug('Hello World')



# Generated at 2022-06-24 02:27:56.587148
# Unit test for function words_count
def test_words_count():
    # Test exception
    input_string = None
    assert_exception(words_count, input_string)

    # Test basic
    assert words_count('') == 0
    assert words_count('hello') == 1
    assert words_count('hello world') == 2
    assert words_count('hello-world') == 1
    assert words_count('hello,world') == 2
    assert words_count('hello, world') == 2
    assert words_count('hello,world,') == 2
    assert words_count(',hello,world,') == 2

    # Test punctuation
    assert words_count('One.Two,three') == 3
    assert words_count('One.Two three') == 2
    assert words_count('One.two three') == 1
    assert words_count('One!Two three') == 1

# Generated at 2022-06-24 02:28:06.960473
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('otto') is True
    assert is_palindrome('oTto') is False
    assert is_palindrome('oTto', ignore_case=True) is True
    assert is_palindrome('abcd', False) is False
    assert is_palindrome(' a b c d  ', True) is False
    assert is_palindrome(' a b c d  ', True, True) is True
    assert is_palindrome(' i topi non avevano nipoti ', False) is True
    assert is_palindrome(' i topi non avevano nipoti ', True) is True
    assert is_palindrome(' i topi non avevano nipoti ', False, True) is True

# Generated at 2022-06-24 02:28:11.512994
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780596006937') == True
    assert is_isbn_13('111') == False
    assert is_isbn_13('978-0312498580') == True
    assert is_isbn_13('3-12-498580') == False
    assert is_isbn_13('97803124985') == False

# Generated at 2022-06-24 02:28:13.494758
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title')  # returns true
    assert is_slug('My blog post title')  # returns false



# Generated at 2022-06-24 02:28:20.864509
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert is_ip_v4('127.0.0.1')
    assert is_ip_v4('0.0.0.0')
    assert not is_ip_v4('256.200.100.75')
    assert not is_ip_v4('127.0.0.300')
    assert not is_ip_v4('1.1.1.1.1')



# Generated at 2022-06-24 02:28:24.713890
# Unit test for function is_ip
def test_is_ip():
  assert is_ip('255.200.100.75')==True
  assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334')==True
  assert is_ip('1.2.3')==False
test_is_ip()


# Generated at 2022-06-24 02:28:27.961892
# Unit test for function is_slug
def test_is_slug():
    assert not is_slug('my-blog-post-title')
    assert is_slug('My blog post title')
    assert is_slug('My blog post title', '-')
    assert is_slug('my-blog-post-title')
    assert not is_slug('my-blog-post-title')
    assert is_slug('my-blog-post-title')



# Generated at 2022-06-24 02:28:31.867118
# Unit test for function is_decimal
def test_is_decimal():
    assert (is_decimal('42.0')== True)
    assert (is_decimal('42')== False)    
#test_is_decimal()



# Generated at 2022-06-24 02:28:35.144349
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string('hello') == True
    assert is_full_string(' ') == False
    assert is_full_string('hello ') == True
    assert is_full_string('') == False
    assert is_full_string('hello world') == True
    assert is_full_string(None) == False


# Generated at 2022-06-24 02:28:39.859096
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False


# Generated at 2022-06-24 02:28:41.051993
# Unit test for function is_pangram
def test_is_pangram():
    value = is_pangram('The quick brown fox jumps over the lazy dog')
    assert value == True

# Generated at 2022-06-24 02:28:54.518172
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    test_cases = [
        {
            'input': '9780134664526',
            'output': True,
        },
        {
            'input': '9780132071696',
            'output': True,
        },
        {
            'input': '978013207169',
            'output': False,
        },
        {
            'input': '1790134664526',
            'output': False,
        },
        {
            'input': '978013466452F',
            'output': False,
        },
        {
            'input': '978-0134-6645-26',
            'output': False,
        },
    ]
    for test_case in test_cases:
        assert __ISBNChecker(test_case['input']).is_isbn_

# Generated at 2022-06-24 02:29:03.769892
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('foo_bar_baz') == True
    assert is_snake_case('foo_bar_baz_') == False
    assert is_snake_case('foo_bar_baz_1') == True
    assert is_snake_case('foo_bar') == True
    assert is_snake_case('foo') == False
    assert is_snake_case('foo-bar') == True
    assert is_snake_case('foo-bar', separator='-') == True
    assert is_snake_case('foo-bar') == False
    assert is_snake_case('foo+bar') == True
    assert is_snake_case('foo+bar', separator='+') == True
    assert is_snake_case('foo+bar') == False

# Generated at 2022-06-24 02:29:09.873023
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('abc') == True
    assert is_isogram('abcc') == False
    assert is_isogram('hello') == False
    assert is_isogram('alphAbet') == False
    assert is_isogram('dermatoglyphics') == True

# Generated at 2022-06-24 02:29:14.443446
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('978-3-12-498580-0') == True


# Generated at 2022-06-24 02:29:25.223777
# Unit test for function is_isogram
def test_is_isogram():
  assert is_isogram('dermatoglyphics') is True
  assert is_isogram('isogram') is True
  assert is_isogram('moose') is False
  assert is_isogram('isIsogram') is False
  assert is_isogram('') is True
  assert is_isogram('thumbscrew-japingly') is True
  assert is_isogram('thumbscrewjapingly') is True
  assert is_isogram('six-year-old') is True
  assert is_isogram('Emily Jung Schwartzkopf') is True
  assert is_isogram('accentor') is False
  assert is_isogram('angola') is False
  assert is_isogram('lumberjacks') is False

# Generated at 2022-06-24 02:29:34.487082
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('2911040179').is_isbn_10() == True
    assert __ISBNChecker('1911040179').is_isbn_10() == True
    assert __ISBNChecker('0-306-40615-2').is_isbn_10() == True
    assert __ISBNChecker('0-7475-3840-2').is_isbn_10() == True
    assert __ISBNChecker('0-451-62744-0').is_isbn_10() == True
    assert __ISBNChecker('0-312-96675-1').is_isbn_10() == True
    assert __ISBNChecker('0-965-02422-0').is_isbn_10() == True

# Generated at 2022-06-24 02:29:36.211327
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('foo_bar_baz') == True
    assert is_snake_case('foo') == False
    

# Generated at 2022-06-24 02:29:47.137614
# Unit test for function is_ip
def test_is_ip():
    valid_ip = []
    invalid_ip = []
    for i in range(256):
        ip = str(i)
        valid_ip.append(ip)
        invalid_ip.append(ip+'.')
        if i < 255:
            invalid_ip.append(ip+'.'+str(i))
    for i in range(1,255):
        for j in range(1,255):
            ip = str(i)+'.'+str(j)
            valid_ip.append(ip)
            invalid_ip.append(ip+'.')
            if i < 255 and j < 255:
                invalid_ip.append(ip+'.'+str(i)+'.'+str(j))
            for k in range(1,255):
                ip2 = ip+'.'+str(k)
               