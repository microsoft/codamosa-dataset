

# Generated at 2022-06-24 02:19:52.790674
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case(None) == False
    assert is_camel_case(False) == False
    assert is_camel_case(0) == False
    assert is_camel_case('') == False
    assert is_camel_case(' ') == False
    assert is_camel_case('0Hello') == False
    assert is_camel_case('my-string') == False
    assert is_camel_case('123') == False
    assert is_camel_case('my string') == False
    assert is_camel_case('MYSTRING') == False
    assert is_camel_case('myString') == True
    assert is_camel_case('myString123') == True



# Generated at 2022-06-24 02:19:55.606566
# Unit test for function is_ip
def test_is_ip():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('1.2.3') == False
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip_v6('1.2.3') == False
# End unit test
test_is_ip()

# Generated at 2022-06-24 02:20:00.280036
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}')
    assert is_json('[1, 2, 3]')
    assert not is_json('{nope}')
# is_json('{"name": "Peter"}')
# is_json('[1, 2, 3]')
# is_json('{nope}')


# Generated at 2022-06-24 02:20:09.300355
# Unit test for function is_palindrome
def test_is_palindrome():
    # Palindrome words
    assert is_palindrome("radar")
    assert is_palindrome("otto")
    assert is_palindrome("hannah")
    assert is_palindrome("lagerregal")

    # Palindrome phrases
    assert is_palindrome("i topi non avevano nipoti")
    assert is_palindrome("radar a las palabras")
    assert is_palindrome("radar a las palabras", ignore_spaces=True)
    assert is_palindrome("El radar era rotador")
    assert is_palindrome("A rosa de Saron, madura, não namora ninguém")

    # Non Palindrome words
    assert not is_palindrome("rador")

# Generated at 2022-06-24 02:20:14.411570
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42') == True
    assert is_integer('42.0') == False


# Generated at 2022-06-24 02:20:26.336314
# Unit test for function is_isbn_10
def test_is_isbn_10():

    assert(is_isbn_10("0-306-40615-2") == True)
    assert(is_isbn_10("1-56053-651-1") == True)
    assert(is_isbn_10("0-943396-04-2") == True)
    assert(is_isbn_10("0-9752298-0-X") == True)
    assert(is_isbn_10("0-9752298-0-X", normalize = False) == False)
    assert(is_isbn_10("0306406152") == True)
    assert(is_isbn_10("0306406152", normalize = False) == True)
    assert(is_isbn_10("0-306-40615-2", normalize = False) == False)

# Generated at 2022-06-24 02:20:35.073566
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog') is True
    assert is_pangram('The five boxing wizards jump quickly') is True
    assert is_pangram('Pack my box with five dozen liquor jugs') is True
    assert is_pangram('Two driven jocks help fax my big quiz') is True
    assert is_pangram('hello world') is False
    assert is_pangram('') is False
    assert is_pangram(1) is False

test_is_pangram()


# Generated at 2022-06-24 02:20:46.732477
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('anagram') == True
    assert is_isogram('dermatoglyphics') == True
    assert is_isogram('isogram') == True
    assert is_isogram('aba') == False
    assert is_isogram('moose') == False
    assert is_isogram('isIsogram') == False
    assert is_isogram('Hello') == False
    assert is_isogram('Dermatoglyphics') == True
    assert is_isogram('Uncopyrightable') == True
    assert is_isogram('thumbscrew-japingly') == True
    assert is_isogram('six-year-old') == True
    assert is_isogram('Emily Jung Schwartzkopf') == True
    assert is_isogram('accentor') == False

# Generated at 2022-06-24 02:20:51.860942
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com')
    assert is_url('http://mysite.com')
    assert is_url('http://mysite.com/folder/file')
    assert is_url('http://mysite.com/folder/file?param=value')
    assert not is_url('www.mysite.com')
    assert is_url('http://www.mysite.com', ['http'])
    assert not is_url('http://www.mysite.com', ['https'])


# Generated at 2022-06-24 02:20:54.282318
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('42.0') # returns true
    assert is_decimal('42') # returns false
# end unit test for function is_decimal



# Generated at 2022-06-24 02:20:56.466093
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214')
    assert is_isbn_10('150-6715214')
    assert not is_isbn_10('150-6715214', normalize=False)


# Generated at 2022-06-24 02:21:00.595537
# Unit test for function is_string
def test_is_string():
    assert is_string('foo')
    assert not is_string('1')
    assert not is_string(1)
    assert not is_string(True)
    assert is_string('')
    assert is_string(' ')
    assert is_string('1.0')
    assert is_string('1,0')
    assert is_string('foo and bar')
    assert is_string('foo bar')
    assert not is_string(u'foo')
    assert not is_string([])
    assert not is_string(())
    assert not is_string({})



# Generated at 2022-06-24 02:21:09.770207
# Unit test for function is_url
def test_is_url():
    assert is_url('.mysite.com',None) == False
    assert is_url('http://www.mysite.com',None) == True
    assert is_url('https://mysite.com',None) == True
    assert is_url('.mysite.com',['http','https']) == False
    assert is_url('http://www.mysite.com',['http','https']) == True
    assert is_url('https://mysite.com',['http','https']) == True
# Unit tests for function is_url
test_is_url()


# Generated at 2022-06-24 02:21:17.137860
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('MyString')
    assert is_camel_case('My_String')
    assert is_camel_case('My1String')
    assert is_camel_case('something12')
    assert is_camel_case('my2019string')
    assert is_camel_case('MYSTRING') is False
    assert is_camel_case('1mystring') is False
    assert is_camel_case('mystring1') is False
    assert is_camel_case('my_string') is False
    assert is_camel_case(' mystring') is False
    assert is_camel_case('mystring ') is False
    assert is_camel_case('my string') is False
    assert is_camel_case('my-string') is False
    assert is_c

# Generated at 2022-06-24 02:21:18.320128
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42') == True
    assert is_integer('42.0') == False

# Generated at 2022-06-24 02:21:20.480155
# Unit test for function is_ip
def test_is_ip():
    assert(is_ip('255.200.100.75') == True)
    assert (is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True)
    assert (is_ip('1.2.3') == False)
test_is_ip()



# Generated at 2022-06-24 02:21:25.731808
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    assert __ISBNChecker('1234567890123')
    assert __ISBNChecker('1234567890123', normalize=False)
    assert __ISBNChecker('123-456789012-3')
    assert __ISBNChecker('123-456789012-3', normalize=False)

    try:
        __ISBNChecker(123)
        assert False, 'Expected an error to be raised.'
    except InvalidInputError:
        pass


# PUBLIC API



# Generated at 2022-06-24 02:21:34.954280
# Unit test for function is_ip_v4
def test_is_ip_v4():

    print("\n\n** test ** is_ip_v4 **")

    # Empty string
    print("  Empty string:", is_ip_v4(""))

    # Not a string
    print("  Not a string:", is_ip_v4(42))

    # Too short string
    print("  Too short string:", is_ip_v4("..."))

    # Not good format
    print("  Not good format:", is_ip_v4("12.34.56.78.90"))

    # Out of range
    print("  Out of range:", is_ip_v4("123.456.789.900"))

    # Good ip
    print("  Good ip", is_ip_v4("123.234.345.456"))



# Generated at 2022-06-24 02:21:36.695350
# Unit test for function is_camel_case
def test_is_camel_case():
    input_string=input()
    assert is_camel_case(input_string)==True


# Generated at 2022-06-24 02:21:49.599133
# Unit test for function is_ip_v6

# Generated at 2022-06-24 02:21:51.084168
# Unit test for function is_number
def test_is_number():
    assert is_number('42') == True
    assert is_number('-42') == True


# Generated at 2022-06-24 02:21:57.215344
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6( 'cafe:cafe:cafe:cafe:cafe:cafe:ffff:ffff') == True
    assert is_ip_v6( '2001:db8:85a3:8d3:1319:8a2e:370:7334') == True
    assert is_ip_v6( '2001:db8:85a3:8d3:1319:8a2e:370:7334:NOPE') == False
    assert is_ip_v6( '2001:db8:85a3:8d3:1319:8a2e:370:7334::') == False
    assert is_ip_v6( '2001:db8:85a3:8d3:1319:8a2e:370:7334:') == False

# Generated at 2022-06-24 02:21:58.194146
# Unit test for function is_slug
def test_is_slug():
    assert is_slug("test-test"), True
test_is_slug()
 

# Generated at 2022-06-24 02:22:04.316962
# Unit test for function is_camel_case
def test_is_camel_case():
  input_string = 'MyString'
  assert is_camel_case(input_string) == True
  input_string = 'mystring'
  assert is_camel_case(input_string) == False
  input_string = 'my_string'
  assert is_camel_case(input_string) == False
  input_string = 'my-string'
  assert is_camel_case(input_string) == False
  input_string = None
  assert is_camel_case(input_string) == False



# Generated at 2022-06-24 02:22:16.388595
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card("4242424242424242") == True
    assert is_credit_card("4242424242123123") == False
    assert is_credit_card("4242424242424242", card_type="VISA") == True
    assert is_credit_card("4242424242424242", card_type="MASTERCARD") == False
    assert is_credit_card("5555555555554444") == True
    assert is_credit_card("5555555555554444", card_type="MASTERCARD") == True
    assert is_credit_card("5555555555554444", card_type="VISA") == False
    assert is_credit_card("378282246310005") == True

# Generated at 2022-06-24 02:22:21.218791
# Unit test for function is_integer
def test_is_integer():

    # Test case
    input_string = "42"
    expected = True
    actual = is_integer(input_string)

    print (actual == expected)


# Generated at 2022-06-24 02:22:28.919194
# Unit test for function is_isbn
def test_is_isbn():
    test_caso = ['978-0312498580', '1506715214']
    test_output = [True, True]
    test_output_str = ["Test caso isbn valido", "Test caso isbn non valido"]
    for i in range(len(test_caso)):
        if is_isbn(test_caso[i]) != test_output[i]:
            print(test_output_str[i] + " fallito")
            return False
    print("Tutti i test sono stati superati con successo")
    return True

test_is_isbn()


# Generated at 2022-06-24 02:22:40.362324
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    checker = __ISBNChecker('')

    assert not checker.is_isbn_13(), '%s should not be a valid ISBN-13' % checker.input_string

    checker = __ISBNChecker('1')
    assert not checker.is_isbn_13(), '%s should not be a valid ISBN-13' % checker.input_string

    checker = __ISBNChecker('978-0-306-40615-')
    assert checker.is_isbn_13(), '%s should be a valid ISBN-13' % checker.input_string

    checker = __ISBNChecker('978-0-306-40615-2')
    assert checker.is_isbn_13(), '%s should be a valid ISBN-13' % checker.input_string

    check

# Generated at 2022-06-24 02:22:49.082176
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-3-16-148410-0').is_isbn_13() is True
    assert __ISBNChecker('9788378391060').is_isbn_13() is True
    assert __ISBNChecker('9783161484100').is_isbn_13() is True
    assert __ISBNChecker('978-1-56619-909-4').is_isbn_13() is True
    assert __ISBNChecker('978-0-306-40615-7').is_isbn_13() is True
    assert __ISBNChecker('978-0-306-40615-0').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-').is_isbn_13() is False
    assert __IS

# Generated at 2022-06-24 02:22:53.991804
# Unit test for function is_string
def test_is_string():
    pass
assert is_string('foo') is True
assert is_string(b'foo') is False



# Generated at 2022-06-24 02:22:56.094601
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') == True
    assert is_isbn('1506715214') == True

# Generated at 2022-06-24 02:23:02.689161
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    c = __ISBNChecker('9415648041')
    assert c.is_isbn_13() == True
    c = __ISBNChecker('945648041')
    assert c.is_isbn_13() == False
    c = __ISBNChecker('9415648041a')
    assert c.is_isbn_13() == False
    c = __ISBNChecker('978-9415648041')
    assert c.is_isbn_13() == False



# Generated at 2022-06-24 02:23:05.463203
# Unit test for function is_full_string
def test_is_full_string():
    assert is_string('') == True
    assert is_string('') == True
    assert is_string('hello') == True


# Generated at 2022-06-24 02:23:11.158779
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('otto')
    assert is_palindrome('i topi non avevano nipoti', ignore_spaces=True)
    assert is_palindrome('Lol', ignore_case=True)

    assert not is_palindrome('rotfl')
    assert not is_palindrome('i topi non avevano nipoti')
    assert not is_palindrome('Lol')
    assert not is_palindrome('Lol', ignore_spaces=True)
    assert not is_palindrome('i topi non avevano nipoti', ignore_case=True)
    assert not is_palindrome('Lol', ignore_case=True, ignore_spaces=True)

    assert is_palindrome('')

# Generated at 2022-06-24 02:23:19.230856
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75') is True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') is True
    assert is_ip('1.2.3') is False

    print(is_ip('255.200.100.75'))
    print(is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334'))
    print(is_ip('1.2.3'))
test_is_ip()

# %%



# Generated at 2022-06-24 02:23:20.265973
# Unit test for function words_count
def test_words_count():
    assert words_count('hello world') == 2
    assert words_count('one,two,three.stop') == 4


# --- Comparisons


# Generated at 2022-06-24 02:23:26.653914
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') is True
    assert is_isbn('1506715214') is True
    assert is_isbn('978-0312498580') is True
    assert is_isbn('978-0312498580', normalize=False) is False
    assert is_isbn('150-6715214') is True
    assert is_isbn('150-6715214', normalize=False) is False
    assert is_isbn('this is not an isbn') is False



# Generated at 2022-06-24 02:23:33.672128
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker("9780470059029").is_isbn_10()
    assert not __ISBNChecker("978047005902").is_isbn_10() # wrong length
    assert not __ISBNChecker("97804700590x").is_isbn_10() # wrong char


# Generated at 2022-06-24 02:23:35.443250
# Unit test for function is_integer
def test_is_integer():
    assert is_integer("42") == True
    assert is_integer("42.0") == False


# Generated at 2022-06-24 02:23:42.492136
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog') == True
    assert is_pangram('hello world') == False
    assert is_pangram('abcdefghijklmopqrstuvwxyz') == True
    assert is_pangram('abcdefghijklmopqrstuvwxyz') == True
    assert is_pangram('abcdejklmopqrstuvwxyz') == False
    assert is_pangram('ABCDEFGHIJKLMOPQRSTUVWXYZ') == True
    assert is_pangram('ABCDEJKLMOPQRSTUVWXYZ') == False
    assert is_pangram('abcdefghijklmopqrstuvwxyz') == True

# Generated at 2022-06-24 02:23:48.766124
# Unit test for function is_pangram
def test_is_pangram():
    assert (is_pangram('abcdefghijklmnopqrstuvwxyz'))
    assert (not is_pangram('abcdefghijklmnopqrstuvwxy'))
    assert (is_pangram('The quick brown fox jumps over the lazy dog'))
    assert (not is_pangram('The quick brown fox jumps over the lazy goat'))


"""
Part 3: More tests
"""

# Generated at 2022-06-24 02:23:56.994126
# Unit test for function is_number
def test_is_number():
    assert is_number('42') == True
    assert is_number('12.1') == True
    assert is_number('12.1e4') == True
    assert is_number('-12.1e4') == True

    assert is_number('+42') == False
    assert is_number('12.1.1') == False
    assert is_number('12.1e4.2') == False
    assert is_number('-12.1e4e5') == False



# Generated at 2022-06-24 02:23:59.690619
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('42') == False, 'Not decimal value'
    assert is_decimal('42.0') == True, 'Decimal value'



# Generated at 2022-06-24 02:24:06.406403
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    checker = __ISBNChecker('0-321-14653-0')
    assert checker.is_isbn_10()

    checker = __ISBNChecker('-321-14653-0')
    assert not checker.is_isbn_10()

    checker = __ISBNChecker('0-321-14653-0', False)
    assert checker.is_isbn_10()


# PUBLIC API



# Generated at 2022-06-24 02:24:10.662259
# Unit test for function is_full_string
def test_is_full_string():
    assert not is_full_string(None)
    assert not is_full_string("")
    assert not is_full_string(" ")
    assert not is_full_string("  ")
    assert not is_full_string("\n\r\r\n")
    assert is_full_string("hello")
    assert is_full_string(" hello ")

# Generated at 2022-06-24 02:24:16.388990
# Unit test for function is_number
def test_is_number():
    assert is_number('42') is True
    assert is_number('19.99') is True
    assert is_number('-9.12') is True
    assert is_number('1e3') is True
    assert is_number('1 2 3') is False
    assert is_number('42.42.42') is False



# Generated at 2022-06-24 02:24:20.694646
# Unit test for function is_ip
def test_is_ip():
	assert (is_ip('192.168.100.100') == True)
	assert (is_ip('2001:db8:85a3:0000:0000:8a2e:370:') == False)
	assert (is_ip('255.200.100.75') == True)
	

# Generated at 2022-06-24 02:24:30.366134
# Unit test for function is_uuid
def test_is_uuid():

    # like the function, this function allows hex representation but it makes the tests clearer
    def test_uuid(s, expected):
        assert is_uuid(s) == expected
        assert is_uuid(s, allow_hex=True) == expected

    test_uuid('737da0b6-4b4e-4a4a-b77c-eac45fbf8f30', True)
    test_uuid('737da0b64b4e4a4ab77ceac45fbf8f30', False)
    test_uuid('737da0b6-4b4e-4a4a-b77c-eac45fbf8f3', False)

# Generated at 2022-06-24 02:24:41.635719
# Unit test for function is_json
def test_is_json():
    assertTrue(is_json('{}'))
    assertTrue(is_json('{ "a": 1 }'))
    assertTrue(is_json('{ "a": 1, "b": 2 }'))
    assertTrue(is_json('{ "a": "b", "c": "d"}'))
    assertTrue(is_json('["a", "b", "c"]'))
    assertTrue(is_json('[1, 2, 3]'))
    assertTrue(is_json('[{"a": 1, "b": 2}, {"c": 3, "d": 4}]'))
    assertTrue(is_json('[{"a": "b", "c": "d"}, {"e": "f", "g": "h"}]'))

    assertFalse(is_json('{'))

# Generated at 2022-06-24 02:24:47.655625
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('340000923409340') == True
    assert is_credit_card('340000923409340', card_type='AMERICAN_EXPRESS') == False
    assert is_credit_card('340000923409340', card_type='DINERS_CLUB') == False
    assert is_credit_card('340000923409340', card_type='DISCOVER') == False
    assert is_credit_card('340000923409340', card_type='JCB') == False
    assert is_credit_card('340000923409340', card_type='MASTERCARD') == False
    assert is_credit_card('340000923409340', card_type='VISA') == False

# Generated at 2022-06-24 02:24:50.868879
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('3826552043').is_isbn_10() is True
    assert __ISBNChecker('3827574985').is_isbn_10() is False


# PUBLIC API


# Generated at 2022-06-24 02:25:01.514933
# Unit test for function is_email
def test_is_email():
    from pytest import raises

    # assert
    assert is_email('test@test.test') == True
    assert is_email('tester@test.test') == True
    assert is_email('hello@test.com') == True
    assert is_email('test+2@test.test') == True
    assert is_email('test.test@gmail.hello.hell') == True
    assert is_email('test.test+2@gmail.hello.hell') == True
    assert is_email('test.2+2@gmail.hello.hell') == True
    assert is_email('test.2.2+2@gmail.hello.hell') == True
    assert is_email('hello+2@gmail.hello.hell') == True
    assert is_email('test@gmail.hello.hell') == True
    assert is_email

# Generated at 2022-06-24 02:25:08.557048
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999')
    assert not is_ip_v4('')
    assert not is_ip_v4(' ')


# Generated at 2022-06-24 02:25:18.091746
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75') == True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip('1.2.3') == False
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?') == False
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False
test_is_ip()


# Generated at 2022-06-24 02:25:24.746065
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com')
    assert is_url('https://mysite.com')
    assert is_url('ftp://mysite.com/file')
    assert is_url('www.mysite.com')
    assert is_url('www.mysite.com:8080/file')
    assert is_url('mysite.com/file')
    assert is_url('mysite.com:8080/file')
    assert not is_url('.mysite.com')
    assert not is_url('www.mysite.com/')



# Generated at 2022-06-24 02:25:30.212099
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title') == True
    assert is_slug('My-blog-post-title') == False
    
test_is_slug()


# Generated at 2022-06-24 02:25:41.456541
# Unit test for function is_url
def test_is_url():
    assert is_url("https://www.google.com")
    assert not is_url("ftp://www.google.com")
    assert not is_url("www.google.com")
    assert not is_url("wwww.google.com")
    assert not is_url("google.com")
    assert not is_url("https://google")
    assert not is_url("https://google.co")
    assert not is_url("https://google.company")
    assert not is_url("company.google.co")
    assert is_url("https://www.google.com/intl/en_us/about/")
    assert not is_url("https://www.google.com/intl/en_us/about")

# Generated at 2022-06-24 02:25:42.725224
# Unit test for function is_string
def test_is_string():
    assert is_string('foo') == True

# Generated at 2022-06-24 02:25:46.870794
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title') == True
    assert is_slug('my-blog_post_title') == False
    assert is_slug('My blog post title') == False

print('Test function is_slug: {}'.format(test_is_slug()))


# Generated at 2022-06-24 02:25:56.285394
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') is True
    assert is_url('https://mysite.com') is True
    assert is_url('www.mysite.com') is True
    assert is_url('mysite.com') is True
    assert is_url('ftp://myftp.com') is True
    assert is_url('ftp://myftp.com') is True
    assert is_url('ftp://myftp.com') is True
    assert is_url('http://www.mysite.com/path/to/file.ext') is True
    assert is_url('http://username:password@www.mysite.com/path/to/file.ext') is True
    assert is_url('.mysite.com') is False

# Generated at 2022-06-24 02:25:59.015371
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') == True
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf') == False
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True) == True
test_is_uuid()


# Generated at 2022-06-24 02:26:01.082272
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram("Dermatoglyphics") == True
    assert is_isogram("isogram") == True
    assert is_isogram("aba") == False
    assert is_isogram("moOse") == False
    assert is_isogram("isIsogram") == False
    assert is_isogram("") == True
    assert is_isogram("") == True


# Generated at 2022-06-24 02:26:07.636116
# Unit test for function is_uuid
def test_is_uuid():
    assert(is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') == True)
    assert(is_uuid('6f8aa2f9686c4ac387665712354a04cf') == False)
    assert(is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True) == True)


# Generated at 2022-06-24 02:26:14.806968
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram("Dermatoglyphics") == True
    assert is_isogram("isogram") == True
    assert is_isogram("aba") == False
    assert is_isogram("moOse") == False
    assert is_isogram("isIsogram") == False
    assert is_isogram("") == True
test_is_isogram()



# Generated at 2022-06-24 02:26:24.390638
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('') == False
    assert is_palindrome('a') == True
    assert is_palindrome('Lol', ignore_case=True) == True
    assert is_palindrome('ROTFL') == False
    assert is_palindrome('i topi non avevano nipoti') == False
    assert is_palindrome('i topi non avevano nipoti', ignore_spaces=True) == True
    assert is_palindrome('Dammit I’m mad') == True
    assert is_palindrome('Dammit I’m mad', ignore_spaces=True) == False
    assert is_palindrome('Dammit I’m mad', ignore_case=True) == False

# Generated at 2022-06-24 02:26:34.627400
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') == True
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf') == False
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True) == True
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04c') == False
    assert is_uuid('6f8aa2f9686c4ac387665712354a04c') == False
    assert is_uuid('6f8aa2f9686c4ac387665712354a04c', allow_hex=True)

# Generated at 2022-06-24 02:26:39.448521
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf')
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True)
    assert not is_uuid('6f8aa2f9686c4ac387665712354a04cf')
    assert not is_uuid('foo')


# Generated at 2022-06-24 02:26:44.484607
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('myString') == True
    assert is_camel_case('myString2') == True
    assert is_camel_case('1MyString') == False
    assert is_camel_case('1_myString') == False
    assert is_camel_case('my_String') == False


# Generated at 2022-06-24 02:26:50.033240
# Unit test for function is_uuid
def test_is_uuid():
    # Test with the UUID hex representation (default settings)
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf') == False
    # Test when the UUID hex representation is allowed
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True) == True
    # Test with a regular UUID string representation
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') == True

# Fixes GitHub issue #81

# Generated at 2022-06-24 02:26:53.966848
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580')
    assert is_isbn('1506715214')
    assert not is_isbn('978-0312498580', normalize=False)
    assert not is_isbn('150-6715214', normalize=False)
    assert not is_isbn('asd')

# Generated at 2022-06-24 02:26:59.386819
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome("otto") # returns true
    assert not is_palindrome("lolo") # returns false
    assert is_palindrome("i topi non avevano nipoti", ignore_spaces=True) # returns true
    assert is_palindrome("i topi non avevano nipoti") # returns false
    assert is_palindrome("I topi non avevano nipoti", ignore_spaces=True, ignore_case=True) # returns true
    assert is_palindrome("I topi non avevano nipoti", ignore_case=True) # returns false

test_is_palindrome()

 


# Generated at 2022-06-24 02:27:04.304021
# Unit test for function is_decimal
def test_is_decimal():
    assert(is_decimal('42.0') == True)
    assert(is_decimal('42') == False)
    return
test_is_decimal()



# Generated at 2022-06-24 02:27:05.537610
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('1572300101').is_isbn_10()

# Generated at 2022-06-24 02:27:11.253886
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('hello') == False
    assert is_isogram('Kim ') == False
    assert is_isogram('hello Kim ') == False
test_is_isogram()


# Generated at 2022-06-24 02:27:12.580309
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('my string is <strong>bold</strong>') 
    assert not contains_html('my string is not bold')
    
    

# Generated at 2022-06-24 02:27:15.385752
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string('') == False
    assert is_full_string(' ') == False
    assert is_full_string('hello') == True


# Generated at 2022-06-24 02:27:21.590673
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False
    assert is_json('{"name": "Peter}') == False


# Generated at 2022-06-24 02:27:29.937232
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') == True
    assert is_url('https://mysite.com') == True
    assert is_url('.mysite.com') == False
    assert is_url('http://www.mysite.com') == True
    assert is_url('https://www.mysite.com') == True
    assert is_url('https://www.mysite.com:8080') == True
    assert is_url('https://mysite.com:8080') == True
    assert is_url('https://www.mysite.com:8080/page') == True
    assert is_url('https://www.mysite.com:8080/page.html') == True
    assert is_url('https://www.mysite.com:8080/page.html?m=b')

# Generated at 2022-06-24 02:27:34.466898
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42') == True
    assert is_integer('42.0') == False
    assert is_integer('+42') == True
    assert is_integer('-42') == True
    

# Generated at 2022-06-24 02:27:36.299177
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False



# Generated at 2022-06-24 02:27:41.402975
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580') == True
    assert is_isbn_13('978-0312498580') == True
    assert is_isbn_13('978-0312498580', normalize=False) == False


# Generated at 2022-06-24 02:27:46.466628
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case("snake_case") is True
    assert is_snake_case("snake-case") is True
    assert is_snake_case("snake-case", separator="-") is True
    assert is_snake_case("snake-case", separator="_") is False
    assert is_snake_case("snake_case", separator="-") is False
    assert is_snake_case("snakeCase") is False
    assert is_snake_case("-snake_case") is False
    assert is_snake_case("snake__case") is False
    assert is_snake_case("snake_Case") is False
    assert is_snake_case("snake_case_") is False

# Generated at 2022-06-24 02:27:56.945366
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case("snake_case")
    assert is_snake_case("snake-case", '-')
    assert is_snake_case("zamel-case", '-')
    assert not is_snake_case("camelCase")
    assert not is_snake_case("kebab-case", '_')
    assert not is_snake_case("123snake_case")
    assert not is_snake_case("snake_case_b")
    assert not is_snake_case("snake_c")
    # The following tests are intended to be failed.
    # assert is_snake_case("camelCase")
    # assert is_snake_case("kebab-case", '_')
    # assert is_snake_case("123snake_case

# Generated at 2022-06-24 02:27:58.844797
# Unit test for function is_slug
def test_is_slug():
    assert_equal(is_slug('my-blog-post-title'), True)
    assert_equal(is_slug('My blog post title'), False)

# Unit tests for function is_list_of_strings

# Generated at 2022-06-24 02:28:01.630853
# Unit test for function is_pangram
def test_is_pangram():
    # assert True if the given result is equal to our expectation
    assert is_pangram('The quick brown fox jumps over the lazy dog') == True
    # assert True if the result is not equal to our expectation
    assert is_pangram('hello world') == False

# Generated at 2022-06-24 02:28:11.270871
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42')
    assert not is_integer('42.0')
    assert not is_integer('3.')
    assert not is_integer('foo')
    assert not is_integer('1 2')
    assert not is_integer('3.3')
    assert not is_integer('1e3')
    assert not is_integer('0xA')
    assert not is_integer('-0')
    assert not is_integer('-1')
    assert not is_integer('+1')
    assert not is_integer('0xA')
    assert not is_integer('1.1')
    assert not is_integer('1e-3')
    assert not is_integer('foo')
    assert not is_integer('1 2')



# Generated at 2022-06-24 02:28:13.269480
# Unit test for function is_string
def test_is_string():
    assert is_string('foo')
    assert not is_string(123)


# Generated at 2022-06-24 02:28:19.500736
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string(None) == False
    assert is_full_string('') == False
    assert is_full_string(' ') == False
    assert is_full_string('hello') == True
    return True
# print('Unit test for function is_full_string: {}'.format(test_is_full_string()))



# Generated at 2022-06-24 02:28:20.338306
# Unit test for function is_isbn_13
def test_is_isbn_13():
    output = is_isbn_13('9780312498580')
    assert True == output

# Generated at 2022-06-24 02:28:26.274696
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') == True, "Ne marche pas"
    assert is_isbn('1506715214') == True, "Ne marche pas"

is_isbn('9780312498580')
is_isbn('1506715214')


# Generated at 2022-06-24 02:28:36.283409
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('LOL')
    assert is_palindrome('Lol', ignore_case=True)
    assert is_palindrome('o toto')
    assert is_palindrome('o toto', ignore_spaces=True)
    assert is_palindrome('i topi non avevano nipoti')
    assert not is_palindrome('ROTFL')
    assert not is_palindrome('Lol', ignore_case=False)
    assert not is_palindrome('o tot')
    assert not is_palindrome('i topi non avevano nipot')



# Generated at 2022-06-24 02:28:48.387477
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('0.1')
    assert is_decimal('-0.1')
    assert is_decimal('0.01')
    assert is_decimal('-0.01')
    assert is_decimal('-0.00001')
    assert is_decimal('-0.000000000000000000000000000000000000000001')
    assert is_decimal('0.000000000000000000000000000000000000000001')
    assert is_decimal('0.000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001')
    assert is_decimal('-0.000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001')
    assert is_decimal('1e-10')
    assert is_decimal('+1e-10')
    assert is_decimal('-1e-10')
    assert is_decimal('1.1e-10')

# Generated at 2022-06-24 02:28:51.183031
# Unit test for function words_count
def test_words_count():
    """
    Test the function words_count.
    """
    assert words_count('hello world') == 2
    assert words_count('one,two,three.stop') == 4



# Generated at 2022-06-24 02:29:03.306768
# Unit test for method is_isbn_13 of class __ISBNChecker

# Generated at 2022-06-24 02:29:04.748634
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580')
    assert is_isbn('1506715214')
    assert not is_isbn('abcdefg')


# Generated at 2022-06-24 02:29:05.747062
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('978-0312498580', normalize=False)

# Generated at 2022-06-24 02:29:13.265788
# Unit test for function is_snake_case
def test_is_snake_case():
    assert not is_snake_case(None)
    assert not is_snake_case('')
    assert not is_snake_case('1234')
    assert not is_snake_case('1_234')
    assert not is_snake_case('MyString')
    assert is_snake_case('my_string')
    assert is_snake_case('my_STRING')
    assert is_snake_case('my-string', '-')
    assert is_snake_case('my.string', '.')



# Generated at 2022-06-24 02:29:14.935771
# Unit test for function contains_html
def test_contains_html():
    assert(contains_html('my string is <strong>bold</strong>') == True)


# Generated at 2022-06-24 02:29:18.432279
# Unit test for function is_string
def test_is_string():
    assert is_string('foo') is True
    assert is_string(b'foo') is False


# Generated at 2022-06-24 02:29:21.122349
# Unit test for function is_pangram
def test_is_pangram():
    word_a = ['The quick brown fox jumps over the lazy dog'] # True
    word_b = ['hello world'] #False
    for x in word_a:
        assert is_pangram(x) == True
        print('PASS')
    for x in word_b:
        assert is_pangram(x) == False
        print('PASS')

# Generated at 2022-06-24 02:29:27.896861
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    try:
        __ISBNChecker('')
        assert False, 'Incorrect input'
    except InvalidInputError:
        pass

    try:
        __ISBNChecker('')
        assert False, 'Incorrect input'
    except InvalidInputError:
        pass

    try:
        __ISBNChecker('1234567890123')
        assert False, 'Incorrect input'
    except InvalidInputError:
        pass


# PUBLIC API



# Generated at 2022-06-24 02:29:41.882307
# Unit test for function is_json
def test_is_json():
    assert is_json('{}') == True
    assert is_json('[]') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{"name": "Peter"}') == True
    assert is_json('{"name": "Peter", "number": 42}') == True
    assert is_json('{"name": "Peter", "number": 42.3}') == True
    assert is_json('{"name": "Peter", "number": "42"}') == True
    assert is_json('{"name": "Peter", "number": "42.3"}') == True
    assert is_json('{"name": "Peter", "number": "hello world"}') == True
    assert is_json('{"name": "Peter", "number": [42, 3]}') == True