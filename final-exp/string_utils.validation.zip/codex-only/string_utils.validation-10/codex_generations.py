

# Generated at 2022-06-24 02:19:51.620913
# Unit test for function is_pangram
def test_is_pangram():

  # Setup
  pangram_1 = "The quick brown fox jumps over the lazy dog"
  pangram_2 = "Pack my box with five dozen liquor jugs"
  pangram_3 = "How quickly daft jumping zebras vex"

  non_pangram_1 = "Hello World"
  non_pangram_2 = "The quick brown fox jumps over the lazy fox"
  non_pangram_3 = ""

  # Exercise and Verify
  assert is_pangram(pangram_1) == True
  assert is_pangram(pangram_2) == True
  assert is_pangram(pangram_3) == True

  assert is_pangram(non_pangram_1) == False
  assert is_pangram(non_pangram_2)

# Generated at 2022-06-24 02:19:56.226011
# Unit test for function is_pangram
def test_is_pangram():
    assert(is_pangram("The quick, brown fox jumps over the lazy dog!")==True)
    assert(is_pangram("The")!=True)
    return
if __name__ == '__main__':
	test_is_pangram()

# Generated at 2022-06-24 02:19:59.682420
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-24 02:20:07.701180
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('"this is my email"@gmail.com') == True
    assert is_email('my.email@local-provider.com') == True
    assert is_email('m\"y.email@local-provider.com')  == True
    assert is_email('my.email@local-provider.com') == True
    assert is_email('my.email@local-provider.com') == True
    assert is_email('my.email@local-provider.com') == True
    assert is_email('my.email@local-provider.com') == True
    assert is_email('my.email@local-provider.com') == True

# Generated at 2022-06-24 02:20:08.812228
# Unit test for function is_pangram
def test_is_pangram():
  assert is_pangram('The quick brown fox jumps over the lazy dog') == True
  assert is_pangram('hello world') == False
test_is_pangram()

# Generated at 2022-06-24 02:20:12.362475
# Unit test for function is_ip_v4
def test_is_ip_v4():
    print('Testing function is_ip_v4()')
    valid_ip_v4 = ['255.200.100.75','255.200.100.999']
    invalid_ip_v4 = ['nope']
    result = {}
    for test in valid_ip_v4:
        result[str(test)] = is_ip_v4(str(test))
        print(str(test), '--->', result[str(test)])
    for test in invalid_ip_v4:
        result[str(test)] = is_ip_v4(str(test))
        print(str(test), '--->', result[str(test)])
test_is_ip_v4()


# Generated at 2022-06-24 02:20:17.703265
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580') is True
    assert is_isbn_13('978-0312498580') is True
    assert is_isbn_13('978-0312498580', normalize=False) is False





# Generated at 2022-06-24 02:20:18.682137
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('my string is <strong>bold</strong>')
    assert not contains_html('my string is not bold')


# Generated at 2022-06-24 02:20:23.767778
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert  is_ip_v4('255.200.100.75')
test_is_ip_v4()

#is_ip_v4('255.200.100.75')
#is_ip_v4('nope')
#is_ip_v4('255.200.100.999')



# Generated at 2022-06-24 02:20:29.306892
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4("192.168.1.1") == True
test_is_ip_v4()



# Generated at 2022-06-24 02:20:31.039259
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    try:
        __ISBNChecker(234234)
        return False
    except InvalidInputError:
        pass

    return True



# Generated at 2022-06-24 02:20:35.771940
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title')
    assert not is_slug('My blog post title')
    assert is_slug('my-blog-post-title', '-')
    assert not is_slug('my-blog-post-title', '_')
    assert is_slug('my_blog_post_title', '_')
    assert not is_slug('my_blog_post_title', '-')



# Generated at 2022-06-24 02:20:39.671745
# Unit test for function is_number
def test_is_number():
    s='32'
    assert is_number(s)==True
    s='32.2'
    assert is_number(s)==True
    s='32.2e3'
    assert is_number(s)==True
    s='32.2e3a'
    assert is_number(s)==False
# is_number unit test end

# Generated at 2022-06-24 02:20:40.785053
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42')
    assert is_integer('42.0') == False


# Generated at 2022-06-24 02:20:42.430343
# Unit test for function is_string
def test_is_string():
    assert is_string('foo') == True


# Generated at 2022-06-24 02:20:48.406479
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') == True
    assert is_isbn_10('150-6715214') == True
    assert is_isbn_10('150-6715214', normalize=False) == False
test_is_isbn_10()



# Generated at 2022-06-24 02:20:50.687382
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999')


# Generated at 2022-06-24 02:21:00.807588
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    assert __ISBNChecker(input_string='1234567890123').is_isbn_13() is False
    assert __ISBNChecker(input_string='1234567890123').is_isbn_10() is False
    assert __ISBNChecker(input_string='978-1-56619-909-4').is_isbn_13() is True
    assert __ISBNChecker(input_string='978-1-56619-909-4').is_isbn_10() is False
    assert __ISBNChecker(input_string='0-306-406154-2').is_isbn_13() is False
    assert __ISBNChecker(input_string='0-306-406154-2').is_isbn_10() is True

# Generated at 2022-06-24 02:21:11.807571
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card(None) == False
    assert is_credit_card('') == False
    assert is_credit_card(' ') == False
    assert is_credit_card('   ') == False
    assert is_credit_card('a') == False
    assert is_credit_card('1234') == False
    assert is_credit_card('1234-2444-4444-4444') == False
    assert is_credit_card('1010-1010-1010-1010') == False
    assert is_credit_card('1234 1234 1234 1234') == False
    assert is_credit_card('1234-1234-1234-1234') == False
    assert is_credit_card('1234_1234_1234_1234') == False
    assert is_credit_card

# Generated at 2022-06-24 02:21:13.201676
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title', '-') == True
    assert is_slug('My blog post title', '-') == False

# Generated at 2022-06-24 02:21:20.947535
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42') == True
    assert is_integer('-42') == True
    assert is_integer('1e2') == True
    assert is_integer('-1e2') == True
    assert is_integer('1e-2') == True
    assert is_integer('-1e-2') == True
    assert is_integer('1 2 3') == False
    assert is_integer('1.2') == False
    assert is_integer('0.9') == False
    assert is_integer('-0.9') == False
    assert is_integer('1.2e2') == False
    assert is_integer('-1.2e2') == False
    assert is_integer('.7') == False
    assert is_integer('.2') == False
    assert is_integer('-.7') == False


# Generated at 2022-06-24 02:21:27.068886
# Unit test for function is_ip_v6
def test_is_ip_v6():
    print("####### TESTING FUNCTION: is_ip_v6 #############")
    print("Checking '2001:db8:85a3:0000:0000:8a2e:370:7334'")
    assert(is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334')==True)
    print("Checking '2001:db8:85a3:0000:0000:8a2e:370:?'")
    assert(is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?')==False)


# Generated at 2022-06-24 02:21:35.362737
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('text with <strong>html</strong>')
    assert contains_html('<b>test</b>')
    assert contains_html('<div></div>')
    assert contains_html('<br>')
    assert contains_html('text <b>with</b> <em>html</em> <img src="">')
    assert not contains_html('text without html')
    assert not contains_html('< not a valid tag')
    assert not contains_html('this is not < a tag >')


# Generated at 2022-06-24 02:21:42.336781
# Unit test for function contains_html
def test_contains_html():
    """
    Test function that checks if a given string contains HTML tags.
    """
    assert contains_html('') is False
    assert contains_html('my string') is False
    assert contains_html('my string is <strong>bold</strong>') is True

    assert contains_html('my string is <a href="#">clickable</a>') is True
    assert contains_html('my string is <a href="#">clickable</a>') is True
    assert contains_html('my string is <div>a section</div>') is True
    assert contains_html('my string is <b>bold</b>') is True
    assert contains_html('my string is <code>some code</code>') is True
    assert contains_html('my string is <i>italic</i>') is True

# Generated at 2022-06-24 02:21:46.523290
# Unit test for function is_palindrome
def test_is_palindrome():
    print("Test of is_palindrome()")
    # Test 1
    result = is_palindrome("otto")
    assert result == True

    # Test 2
    result = is_palindrome("i topi non avevano nipoti")
    assert result == False

    # Test 3
    result = is_palindrome("i topi non avevano nipoti", ignore_spaces=True)
    assert result == True

    # Test 4
    result = is_palindrome("ROTFL")
    assert result == False
# Unit test: execute the function test_is_palindrome()
test_is_palindrome()

# References:
# https://github.com/lepture/validator.js/blob/master/src/check.js
# https://github.com/re

# Generated at 2022-06-24 02:21:50.630433
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title')
    assert is_slug('my-blog-post-title', separator='-')
    assert not is_slug('My blog post title', separator='-')
    assert is_slug('My-blog-post-title', separator='-')


# Generated at 2022-06-24 02:22:01.682678
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.255.255.255')
    assert is_ip('192.168.0.1')
    assert is_ip('12.1.1.1')
    assert is_ip('0.0.0.0')
    assert is_ip('2001:db8:85a3::8a2e:370:7334')
    assert is_ip('2001:db8:85a3:0:0:8a2e:370:7334')
    assert is_ip('2001:db8:85a3::8a2e:370:7334')
    assert is_ip('2001:db8:85a3:0:0:8a2e:370:7334')

# Generated at 2022-06-24 02:22:05.727024
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    # data
    isbn_list = [
        '0747532699',
        '0747538498',
        '014144144X',
        '0747551005',
    ]

    # test
    for isbn in isbn_list:
        assert __ISBNChecker(isbn).is_isbn_10() is True


# Generated at 2022-06-24 02:22:10.569114
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert(is_ip_v4('255.200.100.75'))
    assert(not is_ip_v4('nope'))
    assert(not is_ip_v4('255.200.100.999'))


# Generated at 2022-06-24 02:22:17.283028
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75') == True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip('1.2.3') == False
    print('test_is_ip passed')
    

test_is_ip()


# Generated at 2022-06-24 02:22:25.296197
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580')
    assert not is_isbn('978031249858')
    assert is_isbn('1506715214')
    assert not is_isbn('15067152143')
    assert is_isbn('978-0312498580')
    assert is_isbn('978-0312498580', normalize=False)
    assert is_isbn('150-6715214')
    assert not is_isbn('150-6715214', normalize=False)

# Generated at 2022-06-24 02:22:31.094834
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string("a")
    assert not is_full_string(" ")
    assert not is_full_string("")
    assert not is_full_string(None)


# Generated at 2022-06-24 02:22:34.359620
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42') == True
    assert is_integer('42.0') == False


# Generated at 2022-06-24 02:22:38.953442
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid(uuid.uuid4()) == true


# https://en.wikipedia.org/wiki/International_Standard_Book_Number

# Generated at 2022-06-24 02:22:42.272639
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') # returns true
    assert is_ip_v4('nope') == False # returns false (not an ip)
    assert is_ip_v4('255.200.100.999') == False # returns false (999 is out of range)

if __name__ == "__main__":
    test_is_ip_v4()




# Generated at 2022-06-24 02:22:48.032837
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') is True
    assert is_isbn_10('150-6715214') is True
    assert is_isbn_10('150-6715214', normalize=False) is False


# Generated at 2022-06-24 02:22:50.589146
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True, "Should be True"
    assert is_json('[1, 2, 3]') == True, "Should be True"
    assert is_json('{nope}') == False, "Should be False"



# Generated at 2022-06-24 02:23:00.268292
# Unit test for function is_url
def test_is_url():
    assert is_url('https://www.google.com') == True
    assert is_url('https://google.com') == True
    assert is_url('ftp://google.com') == True
    assert is_url('http://google.com') == True
    assert is_url('www.google.com') == False
    assert is_url('google.com') == False
    assert is_url('://google.com') == False
    assert is_url('http://google.com') == True
    assert is_url('https://www.google.com',["https","http"]) == True
    assert is_url('ftp://google.com',["https","http"]) == False
    assert is_url('https://www.google.com',["https"]) == True

# Generated at 2022-06-24 02:23:04.522772
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?') == False


# Generated at 2022-06-24 02:23:10.433194
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid(None) == False
    assert is_uuid('') == False
    assert is_uuid(' ') == False
    assert is_uuid('foo') == False
    assert is_uuid('4f8aa2f9-686c-4ac3-8766-5712354a04cf') == True
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') == True
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf', allow_hex=True) == True
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf') == False

# Generated at 2022-06-24 02:23:12.180118
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-3-16-148410-0').is_isbn_13() == True


# Generated at 2022-06-24 02:23:12.656459
# Unit test for function is_decimal
def test_is_decimal():
    pass



# Generated at 2022-06-24 02:23:24.052863
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42')
    assert is_integer('+42')
    assert is_integer('-42')
    assert is_integer('42e5')
    assert is_integer('4.2e5') is False
    assert is_integer('42,5') is False
    assert is_integer('4,2e5') is False
    assert is_integer('4.2') is False
    assert is_integer('4')
    assert is_integer('0')
    assert is_integer('1')
    assert is_integer('+0')
    assert is_integer('-0')
    assert is_integer('+1')
    assert is_integer('-1')
    assert is_integer('-999999999999999999999999999999999999999999999999999')

# Generated at 2022-06-24 02:23:26.668373
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('a a') == True
    assert is_palindrome(' a a ') == True
    assert is_palindrome('ab a') == False
    assert is_palindrome('ab a', True) == True
    assert is_palindrome('ab a', False, True) == True
    assert is_palindrome('a ba', False, True) == True
    assert is_palindrome('ab BA', False, True) == True

test_is_palindrome()

# Generated at 2022-06-24 02:23:38.474406
# Unit test for function words_count
def test_words_count():
    assert words_count('hello world') == 2
    assert words_count('one,two,three.stop') == 4
    assert words_count('') == 0
    assert words_count(' ') == 0
    assert words_count('!' * 100) == 0
    assert words_count(',') == 0
    assert words_count(', ') == 0
    assert words_count(' ! ') == 0
    assert words_count(' hello world ') == 2
    assert words_count(' hello world. ') == 2
    assert words_count(' hello world    .  ') == 2
    assert words_count(' hello world\n.  ') == 2
    assert words_count(' hello\nworld\n. ') == 2
    assert words_count(' hello    world    . ') == 2

# Generated at 2022-06-24 02:23:45.006552
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    checker = __ISBNChecker('140007917X')
    assert checker.is_isbn_10() == True

    checker = __ISBNChecker('1400079173')
    assert checker.is_isbn_10() == False

    checker = __ISBNChecker('1234567890')
    assert checker.is_isbn_10() == False

    checker = __ISBNChecker('140007917')
    assert checker.is_isbn_10() == False


# Generated at 2022-06-24 02:23:50.126699
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') == True
    assert is_url('https://mysite.com') == True
    assert is_url('.mysite.com') == False
    assert is_url('http://192.168.0.1/') == True



# Generated at 2022-06-24 02:24:01.535108
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('fooBarBaz') == False
    assert is_snake_case('foo_bar_baz') == True
    assert is_snake_case('__foo_bar__') == True
    assert is_snake_case('') == False
    assert is_snake_case('Foo') == False
    assert is_snake_case('Foo-bar') == False
    assert is_snake_case('Foo_bar') == True
    assert is_snake_case('Foo bar') == False
    assert is_snake_case('1Foo_bar') == False
    assert is_snake_case('_Foo_bar') == True
    assert is_snake_case('1') == False
    assert is_snake_case('_') == False

# Generated at 2022-06-24 02:24:04.242012
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string('hello') == True
    assert is_full_string(' ') == False


# Generated at 2022-06-24 02:24:06.071448
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('978-0-306-40615-7')


# Generated at 2022-06-24 02:24:09.447411
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580') == True
    assert is_isbn_13('978-0312498580') == True
    assert is_isbn_13('978-0312498580', normalize=False) == False



# Generated at 2022-06-24 02:24:11.714745
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog') == True
    assert is_pangram('hello world') == False

# Unit tests for function is_palindrome

# Generated at 2022-06-24 02:24:12.743262
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('my string is <strong>bold</strong>') == True



# Generated at 2022-06-24 02:24:18.043998
# Unit test for function is_number
def test_is_number():
    assert is_number('42')
    assert is_number('19.99')
    assert is_number('-9.12')
    assert is_number('1e3')
    assert not is_number('1 2 3')



# Generated at 2022-06-24 02:24:23.330656
# Unit test for function is_url
def test_is_url():
    assert not is_url('ftp://ftp.rediris.es/mirror/GNU/gcc/gcc-9.2.0/gcc-9.2.0.tar.xz')
    assert is_url('https://www.gnu.org/')
    assert is_url('http://www.gnu.org/')
    assert not is_url('www.gnu.org/')
    assert not is_url('http://')


# Generated at 2022-06-24 02:24:30.846216
# Unit test for function words_count
def test_words_count():
    # noinspection SpellCheckingInspection
    TEST_CASES = (
        ('', 0),
        ('Hello World', 2),
        ('Hello, World & so on', 4),
        ('1 + 2 + 3', 3),
        ('Hello, World!', 2),
        ('Hello, World!!!', 2),
        ('one,two,three.stop', 4),
        ('...', 0),
        ('once upon a time', 3),
        ('one.two.three', 3),
        ('one, two, three', 3),
        ('1 2 3', 3),
        ('one--two--three', 3),
        ('one--two--three.', 3),
        ('one two three', 3),
        ('123', 1),
        ('45\t67\t88', 1)
    )

    # execute test cases


# Generated at 2022-06-24 02:24:41.976768
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('email+label@email.com')
    assert is_email('my.email@the-provider.com.br')
    assert is_email('my.email@the-provider.travel')
    assert is_email('admin@mailserver1')
    assert is_email('user@localserver')
    assert is_email('user@tt')
    assert is_email('user@255.255.255.255')
    assert is_email('user@[2001:db8:1ff::a0b:dbd0]')
    assert is_email('"my.email@the-provider.com"')
    assert is_email('"my.email@the-provider.com.br"')
    assert is_email

# Generated at 2022-06-24 02:24:43.796219
# Unit test for function is_isbn_13
def test_is_isbn_13():
  assert is_isbn_13('978-0312498580')
  
is_isbn_13('978-0312498580')


# Generated at 2022-06-24 02:24:55.063726
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    assert __ISBNChecker('1234567890123').input_string == '1234567890123'
    assert __ISBNChecker('1234567890123', normalize=True).input_string == '123456789012'
    assert __ISBNChecker('1234567890123', normalize=False).input_string == '1234567890123'
    assert __ISBNChecker('1234567890123a').input_string == '1234567890123a'
    assert __ISBNChecker('1234567890123a', normalize=True).input_string == '1234567890123a'
    assert __ISBNChecker('1234567890123a', normalize=False).input_string == '1234567890123a'
    assert __ISBNCheck

# Generated at 2022-06-24 02:24:58.910787
# Unit test for function is_ip
def test_is_ip():
    assert is_ip("7E:::") == False
    assert is_ip("255.200.100.75") == True
    assert is_ip("2001:db8:85a3:0000:0000:8a2e:370:7334") == True
    assert is_ip("1.2.3") == False

# Generated at 2022-06-24 02:25:09.657045
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog')
    assert is_pangram('Jackdaws love my big sphinx of quartz')
    assert is_pangram('Pack my box with five dozen liquor jugs.')
    assert is_pangram('How quickly daft jumping zebras vex')
    assert is_pangram('ABCDEFGHIJKLMNOPQRSTUVWXYZ')
    assert is_pangram('aBcDefghijKLMNopqrstuvwxyZ')
    assert is_pangram('!@#$%^&*()_+-={}|`~')
    assert is_pangram('1234567890')
    assert not is_pangram('abcdefghijklmnopqrstuvwxy')

# Generated at 2022-06-24 02:25:15.115081
# Unit test for function is_json
def test_is_json():
    test_string = "test string"
    assert not is_json(test_string)
    test_json = "{\"name\": \"Peter\"}"
    assert is_json(test_json)
    test_string = "{nope}"
    assert not is_json(test_string)
    return "test_is_json successful"


# Generated at 2022-06-24 02:25:24.457992
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334')
    assert is_ip_v6('2001:db8:85a3:0:0:8a2e:370:7334')
    assert is_ip_v6('2001:db8:85a3::8a2e:370:7334')
    assert is_ip_v6('2001:db8::8a2e:370:7334')
    assert is_ip_v6('2001:db8:85a3::8a2e:370:7334')
    assert is_ip_v6('2001:db8::')
    assert is_ip_v6('2001:db8:85a3::')

# Generated at 2022-06-24 02:25:31.308514
# Unit test for function is_full_string
def test_is_full_string():
    assert not is_full_string(None)
    assert not is_full_string('')
    assert not is_full_string(' ')
    assert not is_full_string('\n')
    assert not is_full_string('   ')
    assert not is_full_string([])
    assert is_full_string('hello')



# Generated at 2022-06-24 02:25:38.496770
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the-provider.com')
    assert not is_email('@gmail.com')
    assert is_email('"Abc\\@def"@example.com')
    assert is_email('"Fred Bloggs"@example.com')
    assert is_email('"Joe\\ Bloggs"@example.com')
    assert not is_email('"Abc@def"@example.com')



# Generated at 2022-06-24 02:25:48.963375
# Unit test for function is_snake_case
def test_is_snake_case():
    # case 1: input_string is a string
    assert is_snake_case("foo_bar", "_") # returns true

    # case 2: input_string is not a string
    assert is_snake_case(100, "_") == False # returns false

    # case 3: input_string is an empty string
    assert is_snake_case("", "_") == False # returns false

    # case 4: input_string is None
    assert is_snake_case(None, "_") == False # returns false

    # case 5: input_string starts by a number
    assert is_snake_case("1foo_bar", "_") == False # returns false

    # case 6: input_string consists of letters and digits
    assert is_snake_case("foo_bar_baz", "_") == True # returns true

    #

# Generated at 2022-06-24 02:25:53.116170
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4("10.11.12.13")
    assert is_ip_v4("0.0.0.0")
    assert is_ip_v4("255.255.255.255")
    assert not is_ip_v4("-10.11.12.13")
    assert not is_ip_v4("10.11.12.13.13")
    assert not is_ip_v4("10.11.12.13.13.14")
    assert not is_ip_v4("10.11.12.13.13.14.15")
    assert not is_ip_v4("256.11.12.13")
    assert not is_ip_v4("257.11.12.13")
    assert not is_ip_v4("255.11.12.13")

# Generated at 2022-06-24 02:25:54.719630
# Unit test for function is_decimal
def test_is_decimal():
    assert(is_decimal('42') == False)
    assert(is_decimal('42.0') == True)



# Generated at 2022-06-24 02:26:01.483106
# Unit test for function is_number
def test_is_number():
    assert is_number('1') == True
    assert is_number('-4') == True
    assert is_number('-4.2') == True
    assert is_number('-4.2e5') == True
    assert is_number('4.2e-5') == True
    assert is_number('4.2e+5') == True
    assert is_number('-4.2e+5') == True
    assert is_number('+4.2e+5') == True
    assert is_number('abc') == False
    assert is_number('123abc') == False
    try:
        is_number(None)
        assert False
    except:
        assert True
    try:
        is_number(['a'])
        assert False
    except:
        assert True

# Generated at 2022-06-24 02:26:11.164624
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13("9780312498580") == True
    assert is_isbn_13("978-0312498580") == True
    assert is_isbn_13("978-031-249858-0") == True
    assert is_isbn_13("978 031 249858 0") == True
    assert is_isbn_13("978 0 3124 9858 0") == True
    assert is_isbn_13("9780312498580", normalize=False) == False
    assert is_isbn_13("978031-249858-0", normalize=False) == False

    assert is_isbn_13("1398989898") == False
    assert is_isbn_13("978-03124985") == False

# Generated at 2022-06-24 02:26:15.053844
# Unit test for function is_isogram
def test_is_isogram():
  assert is_isogram('dermatoglyphics') == True
  assert is_isogram('isogram') == True
  assert is_isogram('aba') == False
  assert is_isogram('moOse') == False
  assert is_isogram('isIsogram') == False
  assert is_isogram('') == True
  print("Test is successful!")
test_is_isogram()


# Generated at 2022-06-24 02:26:18.464979
# Unit test for function is_credit_card
def test_is_credit_card():
    # EXCEPTION CASE
    with pytest.raises(KeyError):
        is_credit_card('1234', card_type='VISA')
    # VALID CASE
    assert is_credit_card('4111111111111111', card_type='VISA') is True
    # INVALID CASE
    assert is_credit_card('1234', card_type='VISA') is False



# Generated at 2022-06-24 02:26:21.738742
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?') == False


# Generated at 2022-06-24 02:26:24.692549
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42')
    assert not is_integer('42.0')



# Generated at 2022-06-24 02:26:25.768337
# Unit test for function is_json
def test_is_json():
    try:
        assert(is_json(None))
    except:
        print("test_is_json failed")

test_is_json()




# Generated at 2022-06-24 02:26:34.716903
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('fooBar')
    assert is_camel_case('fooBar2')
    assert is_camel_case('fooBar_2')

    assert not is_camel_case('FooBar')
    assert not is_camel_case('FooBar2')
    assert not is_camel_case('FooBar_2')
    assert not is_camel_case('')
    assert not is_camel_case(' ')
    assert not is_camel_case('foo bar')
    assert not is_camel_case('foo bar')
    assert not is_camel_case(2)
    assert not is_camel_case('2fooBar')
    assert not is_camel_case('@fooBar')

# Generated at 2022-06-24 02:26:36.341098
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('my string is <strong>bold</strong>')
    assert not contains_html('my string is not bold')



# Generated at 2022-06-24 02:26:46.100806
# Unit test for function is_number
def test_is_number():
    try:
        is_number(None)
    except Exception as e:
        print(type(e))
        print(e)
    assert(is_number(None) == False)
    assert(is_number('') == False)    
    assert(is_number('a') == False)    
    assert(is_number('0') == True)    
    assert(is_number('-1') == True)    
    assert(is_number('1') == True)    
    assert(is_number('1.0') == True)    
    assert(is_number('1e5') == True)    
    assert(is_number('1,456') == False)
    assert(is_number('1,456.0') == False)
    assert(is_number('1,456.9') == False)
   

# Generated at 2022-06-24 02:26:51.822501
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('email') == False
    assert is_email('email.com') == False
    assert is_email('@gmail.com') == False

# Generated at 2022-06-24 02:26:52.665307
# Unit test for function is_integer
def test_is_integer():
    assert is_integer(12)



# Generated at 2022-06-24 02:27:00.671057
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('1') == False
    assert is_decimal('1.0') == True

# Generated at 2022-06-24 02:27:07.945949
# Unit test for function words_count
def test_words_count():
    # Test signature
    args = [
        '',
        'one',
        'one two',
        'one,two.three',
        'one.two,three',
        'one,two.three.four'
    ]

    results = [0, 1, 2, 3, 3, 4]

    for index, arg in enumerate(args):
        result = words_count(arg)
        assert(result == results[index])

# Generated at 2022-06-24 02:27:11.569629
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog') == True
    assert is_pangram('hello world') == False
    assert is_pangram('The quick onyx goblin jumps over the lazy dwarf') == True
    assert is_pangram('Pack my box with five dozen liquor jugs') == True
    assert is_pangram('How quickly daft jumping zebras vex') == True
    assert is_pangram('ABCD45EFGH,IJK,LMNOPQR56STUVW3XYZ') == True
    assert is_pangram('abcd5efgh,ijklmnopqr6stuvw3xyz') == True

# Generated at 2022-06-24 02:27:20.667531
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    given_list = [
        "978-0-306-40615-5",
        "978-0-306-40615-2",
        "978-0-306-40615-3",
        "978-0-306-40615-7",
        "978-0-306-40615-8",
        "978-0-3064-0615-6",
        "978-0-3064-0615-0",
        "978-0-3064-0615-1",
        "978-0-3064-0615-3",
        "978-0-3064-0615-4",
        "978-0-3064-0615-8",
        "978-0-3064-0615-9",
        "978-0-3065-0615-9",
    ]

# Generated at 2022-06-24 02:27:30.437701
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram(input_string="") == False
    assert is_isogram(input_string="Dermatoglyphics") == True
    assert is_isogram(input_string="isogram") == True
    assert is_isogram(input_string="aba") == False
    assert is_isogram(input_string="moOse") == False
    assert is_isogram(input_string="isIsogram") == False
    assert is_isogram(input_string="") == False
    print("Passed")

test_is_isogram()
 


# Generated at 2022-06-24 02:27:35.324365
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334')
    assert not is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?')
    assert not is_ip_v6('192.168.1.1')



# Generated at 2022-06-24 02:27:41.994050
# Unit test for function is_ip
def test_is_ip():
    assert is_ip("2001:db8:85a3:0000:0000:8a2e:370:7334") == True
    assert is_ip("255.200.100.75") == True
    assert is_ip("") == False
    assert is_ip("1.2.3") == False


# Generated at 2022-06-24 02:27:44.953238
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580')
    assert is_isbn_13('978-0312498580')
    assert not is_isbn_13('978-0312498580', normalize=False)



# Generated at 2022-06-24 02:27:47.720574
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string('hello world!') == True



# Generated at 2022-06-24 02:27:56.355706
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334')
    assert not is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?')
    assert not is_ip_v6('2001:db8:85a3:0000:0000:8a2e:3')
    assert not is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334:7334')
    assert not is_ip_v6('')

# Generated at 2022-06-24 02:28:01.843663
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    isbn_ok = '0306406152'
    isbn_false = 'invalid_isbn'

    assert __ISBNChecker(isbn_ok).is_isbn_10() is True
    assert __ISBNChecker(isbn_false).is_isbn_10() is False

# Generated at 2022-06-24 02:28:03.039083
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42') is True
    assert is_integer('-42') is True


# Generated at 2022-06-24 02:28:06.459257
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('42.0')
    assert is_decimal('-42.0')
    assert is_decimal('42.0e6')
    assert not is_decimal('42')
    assert not is_decimal('-42')



# Generated at 2022-06-24 02:28:14.571856
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('dermatoglyphics') == True
    assert is_isogram('isogram') == True
    assert is_isogram('moose') == False
    assert is_isogram('isIsogram') == False
    assert is_isogram('aba') == False
    assert is_isogram('moOse') == False
    assert is_isogram('thumbscrewjapingly') == True
    assert is_isogram('thequickbrownfox') == False
    assert is_isogram('Emily Jung Schwartzkopf') == True
    assert is_isogram('accentor') == False
    assert is_isogram('archeyozoogeological') == True
    assert is_isogram('kyphoscoliotic') == False
    assert is_isogram('') == True

# Generated at 2022-06-24 02:28:19.724657
# Unit test for function is_uuid
def test_is_uuid():
    # UUID
    # Using the hexadecimal representation is not supported by default. It can be enabled with the optional argument.
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf')
    assert not is_uuid('6f8aa2f9686c4ac387665712354a04cf')
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True)

    # RFC 4122 examples:
    # - version 1 (time-based)
    assert is_uuid('f81d4fae-7dec-11d0-a765-00a0c91e6bf6')
    # - version 2 (DCE Security)

# Generated at 2022-06-24 02:28:22.584239
# Unit test for function is_full_string
def test_is_full_string():
    assert not is_full_string(None)
    assert not is_full_string('')
    assert not is_full_string(' ')
    assert not is_full_string('\n')
    assert is_full_string('hello')



# Generated at 2022-06-24 02:28:33.445652
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('Lorem ipsum dolor sit <strong>amet</strong>')
    assert contains_html('Lorem ipsum dolor sit <em>amet</em>')
    assert contains_html('Lorem ipsum dolor sit <script type="text/javascript">amet</script>')
    assert contains_html('Lorem ipsum dolor sit <span class="text-italic">amet</span>')
    assert contains_html('Lorem ipsum dolor sit <p>amet</p>')
    assert contains_html('Lorem ipsum dolor sit <h1>amet</h1>')
    assert contains_html('Lorem ipsum dolor sit <div id="myId">amet</div>')

# Generated at 2022-06-24 02:28:35.880449
# Unit test for function is_email
def test_is_email():
    assert is_email('foo.bar@the-provider.com') == True
    assert is_email('foo@gmail.com') == True
    assert is_email('foo@gmail.com') == True


# https://en.wikipedia.org/wiki/Luhn_algorithm

# Generated at 2022-06-24 02:28:44.373916
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') == True
    assert is_isbn('1506715214') == True
    assert is_isbn('978-0312498580') == True
    assert is_isbn('150-6715214') == True
    assert is_isbn('978-0312498580', normalize=False) == False
    assert is_isbn('150-6715214', normalize=False) == False
    assert is_isbn('150671521') == False

# Generated at 2022-06-24 02:28:58.492172
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    checker = __ISBNChecker('0-13-601515-6')
    assert checker.is_isbn_13() == True

    checker = __ISBNChecker('0-13-601515-7')
    assert checker.is_isbn_13() == False

    checker = __ISBNChecker('0-13-601515-7')
    assert checker.is_isbn_13() == False

    checker = __ISBNChecker('0000000000000')
    assert checker.is_isbn_13() == False

    checker = __ISBNChecker('000013-601515-7')
    assert checker.is_isbn_13() == False

    checker = __ISBNChecker('123413-601515-7')

# Generated at 2022-06-24 02:29:05.642611
# Unit test for function words_count
def test_words_count():
    assert words_count('one, two, three') == 3
    assert words_count('one two three') == 3
    assert words_count('one, two, three') == 3
    assert words_count('one, two, three.') == 3
    assert words_count('one, two, three...') == 3
    assert words_count('one, two, three. ') == 4
    assert words_count('one, two, three! ') == 4
    assert words_count('one, two , three. ') == 4
    assert words_count('one, two ,three. ') == 4
    assert words_count(' one, two, three.') == 4
    assert words_count('one, two ,three.') == 4
    assert words_count('one, two ,three . ') == 4

# Generated at 2022-06-24 02:29:10.232119
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('LOL')
    assert is_palindrome('Lol', ignore_case=True)
    assert is_palindrome('i topi non avevano nipoti', ignore_spaces=True)
    assert not is_palindrome('Lol')
    assert not is_palindrome('ROTFL')


#
# INTERNAL
#

# Generated at 2022-06-24 02:29:18.507082
# Unit test for function is_decimal
def test_is_decimal():
    assert(is_decimal('0') == False)
    assert(is_decimal('0.0') == True)
    assert(is_decimal('0.1') == True)
    assert(is_decimal('0.01') == True)
    assert(is_decimal('1.1') == True)
    assert(is_decimal('1.01') == True)
    assert(is_decimal('1') == False)
    assert(is_decimal('1e1') == True)
    assert(is_decimal('1.1e1') == True)
    assert(is_decimal('00') == False)
    assert(is_decimal('00.1') == True)
    assert(is_decimal('00.01') == True)

# Generated at 2022-06-24 02:29:28.682496
# Unit test for function is_slug
def test_is_slug():
	assert is_slug('my-blog-post-title')
	assert not is_slug('My blog post title')
	assert is_slug('my-blog_post-title')
	assert is_slug('My-blog-post-title')
	assert not is_slug(' My blog post title')
	assert not is_slug('my - blog - post - title')
	assert not is_slug('my-blog-post-title ')
	assert not is_slug('my-blog-post-title.')
	assert not is_slug('my-blog-post-title?')

test_is_slug()

# Validator functions


# Generated at 2022-06-24 02:29:37.192380
# Unit test for function words_count
def test_words_count():
    assert words_count('one,two,three') == 3
    assert words_count('one two three') == 3
    assert words_count('one,two,three,four') == 4
    assert words_count('one.two.three') == 3
    assert words_count('one.two.three!four') == 4
    assert words_count('one two three four') == 4
    assert words_count('one two three four ') == 4
    assert words_count(' one two three four ') == 4
    assert words_count('') == 0
    assert words_count('.') == 0
    assert words_count(',') == 0
    assert words_count(',,') == 0
    assert words_count(' ,') == 0
    assert words_count(' , ') == 0
    assert words_count(' ,') == 0

# Generated at 2022-06-24 02:29:39.791707
# Unit test for function is_number
def test_is_number():
    assert is_number('21') == True
    assert is_number('42') == True
    assert is_number('19.99') == True
    assert is_number('-9.12') == True
    assert is_number('1e3') == True
    assert is_number('1 2 3') == False


# Generated at 2022-06-24 02:29:41.068225
# Unit test for function is_isbn
def test_is_isbn():
        assert is_isbn('9780134079004') == True
        assert is_isbn('9780134079005') == False