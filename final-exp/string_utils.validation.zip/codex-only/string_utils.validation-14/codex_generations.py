

# Generated at 2022-06-24 02:19:45.785629
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('my string is <strong>bold</strong>') == True
    assert contains_html('my string is not bold') == False
    assert contains_html(1) == False


# Generated at 2022-06-24 02:19:50.447378
# Unit test for function is_integer
def test_is_integer():
    assert(is_integer('42') == True)
    assert(is_integer('42.0') == False)


# Generated at 2022-06-24 02:19:54.078311
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram("dermatoglyphics") == True
    assert is_isogram("isogram") == True
    assert is_isogram("aba") == False
    assert is_isogram("moOse") == False
    assert is_isogram("isIsogram") == False
    assert is_isogram("") == True
    
test_is_isogram()



# Generated at 2022-06-24 02:20:04.590775
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('hello_world') is True
    assert is_snake_case('hello_world', '-') is False
    assert is_snake_case('hello_world', '.') is True
    assert is_snake_case('hello.world.', '.') is False
    assert is_snake_case('HelloWorld') is False
    assert is_snake_case('hello-world') is True
    assert is_snake_case('hello-world', '-') is True
    assert is_snake_case('hello-world.') is False
    assert is_snake_case('hello-world.', '-') is False
    assert is_snake_case('HelloWorld') is False
    assert is_snake_case('hello world') is False
    assert is_snake_case

# Generated at 2022-06-24 02:20:09.531808
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-24 02:20:19.539463
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('IsCamelCase') is True, 'IsCamelCase'
    assert is_camel_case('isCamelCase') is False, 'isCamelCase'
    assert is_camel_case('isCamelCaseFalse') is True, 'isCamelCaseFalse'
    assert is_camel_case('MyString') is True, 'MyString'
    assert is_camel_case('mystring') is False, 'mystring'
    assert is_camel_case('My1stString') is True, 'My1stString'
    assert is_camel_case('my 1st string') is False, 'my 1st string'
    assert is_camel_case('1String') is False, '1String'
    assert is_camel_case('False') is True, 'False'

# Generated at 2022-06-24 02:20:23.359846
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    checker = __ISBNChecker('9780134685991')
    assert checker.is_isbn_13() == True
    checker2 = __ISBNChecker('978-0-13-46859-9-1')
    assert checker2.is_isbn_13() == True
    checker3 = __ISBNChecker('978-0-13-46859-9-2')
    assert checker3.is_isbn_13() == False


# Generated at 2022-06-24 02:20:31.148589
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?') == False
    assert is_shallow_ip_v6('2001:') == False


# Generated at 2022-06-24 02:20:34.989270
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('') == False
    assert is_ip_v4(None) == False
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('255.200.100.999') == False



# Generated at 2022-06-24 02:20:38.174250
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    __ISBNChecker("9784503129482").is_isbn_13()


# PUBLIC API



# Generated at 2022-06-24 02:20:45.162437
# Unit test for function is_string
def test_is_string():
    errors = []
    assert is_string('test') == True, errors.append("is_string('test') is returning false")
    assert is_string(b'foo') == False, errors.append("is_string(b'foo') is returning True")
    assert len(errors) == 0, "\n" + "\n".join(errors)


# Generated at 2022-06-24 02:20:52.829289
# Unit test for function is_email
def test_is_email():
    assert is_email("test@test.test")
    assert not is_email("test@testcom")
    assert not is_email("testtestcom")
    assert not is_email("test@testcom@test.test")
    assert is_email("") == False
    assert is_email("test@test.com"*10) == False
    assert is_email("test@test.com") != False
    assert is_email("test@test.test") != False
    assert is_email("test@test.t") == False

# Generated at 2022-06-24 02:20:59.079563
# Unit test for function is_email
def test_is_email():
    print("TESTING is_email")
    if not is_email("hongdavid@gmail.com"):
        print("ERROR: FAILED TO TEST is_email")
        return
    if not is_email("hong.david@gmail.com"):
        print("ERROR: FAILED TO TEST is_email")
        return
    if not is_email("hong_david@gmail.com"):
        print("ERROR: FAILED TO TEST is_email")
        return
    if not is_email("hong-david@gmail.com"):
        print("ERROR: FAILED TO TEST is_email")
        return
    if is_email("hongdavidgmail.com"):
        print("ERROR: FAILED TO TEST is_email")
        return

# Generated at 2022-06-24 02:20:59.971036
# Unit test for function words_count
def test_words_count():
    assert words_count("hello world!") == 2



# Generated at 2022-06-24 02:21:00.601101
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('my string is <strong>bold</strong>') == True



# Generated at 2022-06-24 02:21:10.642556
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram("") == True
    assert is_isogram("isogram") == True
    assert is_isogram("eleven") == False
    assert is_isogram("subdermatoglyphic") == True
    assert is_isogram("Alphabet") == False
    assert is_isogram("thumbscrew-japingly") == True
    assert is_isogram("six-year-old") == True
    assert is_isogram("Emily Jung Schwartzkopf") == True
    assert is_isogram("accentor") == False
    assert is_isogram("angola") == False
    print("All tests passed for function is_isogram.")


# Generated at 2022-06-24 02:21:14.481256
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') # returns true
    assert is_isbn('1506715214') # returns true
    assert is_isbn('978-0312498580') # returns true
    assert is_isbn('150-6715214') # returns true
    assert is_isbn('150-6715214', normalize=False) == False # returns false



# Generated at 2022-06-24 02:21:24.716010
# Unit test for function is_camel_case
def test_is_camel_case():
    # Test 1: Known value
    if is_camel_case('MyString') == True and is_camel_case('myString') == False:
        print('Test 1: Success')
        return True
    else:
        print('Test 1: Failed')
        return False

    # Test 2: Known value
    if is_camel_case('mystring') == False and is_camel_case('MYSTRING') == False:
        print('Test 2: Success')
        return True
    else:
        print('Test 2: Failed')
        return False

    # Test 3: Known value
    if is_camel_case('123MyString') == False and is_camel_case('myString123') == True:
        print('Test 3: Success')
        return True
    else:
        print('Test 3: Failed')

# Generated at 2022-06-24 02:21:26.016973
# Unit test for function words_count
def test_words_count():
    '''
    Test for function words_count
    '''
    assert words_count('one,two,three.stop') == 4
    assert words_count('hello world') == 2


# Generated at 2022-06-24 02:21:27.451557
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('<b>some bold text</b>') is True
    assert contains_html('some bold text') is False



# Generated at 2022-06-24 02:21:38.601768
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    input_string = '9781846590565'
    assert __ISBNChecker(input_string, normalize=False).is_isbn_10() is False
    input_string = '1846590565'
    assert __ISBNChecker(input_string, normalize=False).is_isbn_10() is True
    input_string = '1846590557'
    assert __ISBNChecker(input_string, normalize=False).is_isbn_10() is False
    input_string = '18465905'
    assert __ISBNChecker(input_string, normalize=False).is_isbn_10() is False
    # errors
    input_string = ''

# Generated at 2022-06-24 02:21:43.674765
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string(None) == False
    assert is_full_string('') == False
    assert is_full_string(' ') == False
    assert is_full_string('hello') == True



# Generated at 2022-06-24 02:21:53.086137
# Unit test for function is_email
def test_is_email():
    assert is_email('root@localhost') == True
    assert is_email('root@mail.localhost') == True
    assert is_email('root@mail.localhost.com') == True
    assert is_email('root.mail@localhost') == True
    assert is_email('root-mail@localhost') == True
    assert is_email('root_mail@localhost') == True
    assert is_email('root.mail@localhost.com') == True
    assert is_email('root-mail@localhost.com') == True
    assert is_email('root_mail@localhost.com') == True
    assert is_email('root.mail@localhost.com.br') == True
    assert is_email('root-mail@localhost.com.br') == True
    assert is_email('root_mail@localhost.com.br') == True
   

# Generated at 2022-06-24 02:21:55.966705
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') == True
    assert is_isbn('1506715214') == True

# Generated at 2022-06-24 02:22:04.435178
# Unit test for function is_snake_case

# Generated at 2022-06-24 02:22:16.350948
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('foo_bar_baz')
    assert not is_snake_case('foo')
    assert not is_snake_case('FooBar')
    assert not is_snake_case('fooBar')
    assert not is_snake_case('fooBarBaz')
    assert not is_snake_case('foo_bar')
    assert not is_snake_case('foo-bar-baz')
    assert not is_snake_case('foo1_bar1_baz1')
    assert is_snake_case('foo1_bar1_baz1', '_')
    assert is_snake_case('foo-bar-baz', '-')
    assert not is_snake_case('foo-bar-baz', '_')
    assert not is_sn

# Generated at 2022-06-24 02:22:27.127278
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('Foo_bar_baz') == True
    assert is_snake_case('foo') == False
    assert is_snake_case('foo_bar_baz') == True
    assert is_snake_case('fooBarBaz') == False
    assert is_snake_case('_foo') == False
    assert is_snake_case('foo_') == False
    assert is_snake_case('_foo_') == False
    assert is_snake_case('foo_bar_baz', separator='-') == False
    assert is_snake_case('foo-bar-baz', separator='-') == True


# Generated at 2022-06-24 02:22:38.863436
# Unit test for function is_isogram
def test_is_isogram():

    # Test is_isogram function
    print('Test is_isogram function')

    # Case 1: string that is a isogram
    test_str = 'dermatoglyphics'
    test_result = is_isogram(test_str)
    print('\tCase 1: ' + str(test_result))

    # Case 2: string that is not an isogram
    test_str = 'hello'
    test_result = is_isogram(test_str)
    print('\tCase 2: ' + str(test_result) + '\n')

# Test cases
test_is_isogram()


# Generated at 2022-06-24 02:22:43.378636
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0451450617').is_isbn_10() == True


# PUBLIC API



# Generated at 2022-06-24 02:22:45.974444
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13("9780312498580") == True
    assert is_isbn_13("978-0312498580") == True
    assert is_isbn_13("978-0312498580", normalize=False) == False


# Generated at 2022-06-24 02:22:53.830941
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') == True
    assert is_isbn_10('150-6715214') == True
    assert is_isbn_10('150-6715214', normalize=False) == False
    assert is_isbn_10('1-5067-1521-4') == True
    assert is_isbn_10('1-5067-1521-3') == False
    assert is_isbn_10('1-5067-1521-2') == False
    assert is_isbn_10('1-5067-1521-1') == False
    assert is_isbn_10('0-7818-0357-1') == False



# Generated at 2022-06-24 02:22:56.733801
# Unit test for function is_ip_v6
def test_is_ip_v6():
    return is_ip_v6("2001:db8:85a3:0000:0000:8a2e:370:7334")
print(test_is_ip_v6())


# Generated at 2022-06-24 02:23:05.228291
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert(is_ip_v4("127.0.0.1") == True)
    assert(is_ip_v4("192.168.1.1") == True)
    assert(is_ip_v4("0.0.0.0") == True)
    assert(is_ip_v4("255.255.255.255") == True)
    assert(is_ip_v4("1.2.3.4.5") == False)
    assert(is_ip_v4("256.2.3.4") == False)
    assert(is_ip_v4("1.2.3.4.") == False)
    assert(is_ip_v4(".1.2.3.4") == False)

# Generated at 2022-06-24 02:23:06.998877
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42') == True
    assert is_integer('42.0') == False
    assert is_integer('42.1') == False

# Generated at 2022-06-24 02:23:11.224587
# Unit test for function words_count
def test_words_count():
    assert words_count(None) == 0
    assert words_count('this is a test') == 4
    assert words_count('!@#$%^&*()_+') == 0

# Generated at 2022-06-24 02:23:12.989738
# Unit test for function is_pangram
def test_is_pangram():
  string = "The quick brown fox jumps over the lazy dog"
  assert is_pangram(string) == True, "Value is False"

test_is_pangram()


# Generated at 2022-06-24 02:23:14.187131
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('my string is <strong>bold</strong>') == True
    assert contains_html('my string is not bold') == False


# Generated at 2022-06-24 02:23:14.963403
# Unit test for function words_count
def test_words_count():
    assert words_count('one,two,three.stop') == 4



# Generated at 2022-06-24 02:23:25.622938
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card("4929260089091585") is True
    assert is_credit_card("2080395719364360") is False
    assert is_credit_card("6027947539380") is False
    assert is_credit_card("4929-2600-8909-1585") is False
    assert is_credit_card("4929260089091581") is False
    assert is_credit_card("4929260089091585", card_type="VISA") is True
    assert is_credit_card("374927324243723", card_type="AMERICAN_EXPRESS") is True
    assert is_credit_card("374927324243723", card_type="VISA") is False


# Generated at 2022-06-24 02:23:34.611975
# Unit test for function is_number
def test_is_number():
    assert is_number("10") == True
    assert is_number("-10") == True
    assert is_number("10.0") == True
    assert is_number("10.") == False
    assert is_number("-10.0") == True
    assert is_number("1e3") == True
    
    try:
        is_number(10)
    except Exception as e:
        print(e)
    try:
        is_number(10.1)
    except Exception as e:
        print(e)



# Generated at 2022-06-24 02:23:44.522893
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    # check for valid isbn 10
    checker = __ISBNChecker('1111111111')
    assert checker.is_isbn_10()

    # check for invalid isbn 10
    checker = __ISBNChecker('1111111112')
    assert not checker.is_isbn_10()

    # check for valid isbn 10
    checker = __ISBNChecker('0-306-40615-2')
    assert checker.is_isbn_10()

    # check for invalid isbn 10
    checker = __ISBNChecker('0-306-40615-5')
    assert not checker.is_isbn_10()


# PUBLIC API



# Generated at 2022-06-24 02:23:50.595093
# Unit test for function is_palindrome
def test_is_palindrome():
    # Correct strings
    assert is_palindrome('1')
    assert is_palindrome('111')
    assert is_palindrome('a man, a plan, a canal, Panama')
    assert is_palindrome('A man, a plan, a canal, Panama')
    assert is_palindrome('A man, a plan, a canal, Panama', ignore_case=True)
    assert is_palindrome('A man, a plan, a canal, Panama', ignore_spaces=True)
    assert is_palindrome('A man, a plan, a canal, Panama', ignore_case=True, ignore_spaces=True)

    # Incorrect strings
    assert not is_palindrome('2')
    assert not is_palindrome('112')
    assert not is_palindrome('A man')



# Generated at 2022-06-24 02:23:55.040591
# Unit test for function is_isogram
def test_is_isogram():
    str1 = 'dermatoglyphics'
    assert is_isogram(str1) == True
    str2 = 'hello'
    assert is_isogram(str2) == False

test_is_isogram()



# Generated at 2022-06-24 02:23:57.180826
# Unit test for function is_string
def test_is_string():
    assert is_string('foo') == True
    assert is_string(b'foo') == False
    assert is_string(123) == False


# Generated at 2022-06-24 02:23:59.665778
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('Anna') == True
    assert is_palindrome('OtTO') == True
    assert is_palindrome('TeSt') == False
    
test_is_palindrome()





# Generated at 2022-06-24 02:24:07.826256
# Unit test for function is_isbn
def test_is_isbn():
    isbn_10 = '9780312498580'
    isbn_13 = '1506715214'

    assert is_isbn(isbn_10) == True
    assert is_isbn(isbn_13) == True
    assert is_isbn('978-0312498580') == True
    assert is_isbn('978-0312498580', normalize=False) == False
    assert is_isbn('978-032148580') == False
    assert is_isbn('978a032148580') == False


# Generated at 2022-06-24 02:24:08.976215
# Unit test for function is_url
def test_is_url():
    url = 'http://www.mysite.com'
    print(is_url(url))



# Generated at 2022-06-24 02:24:20.491479
# Unit test for function is_credit_card
def test_is_credit_card():
    # Visa cards
    assert is_credit_card('4716-2210-5188-5662',card_type='VISA')
    assert is_credit_card('4929 7226 5379 7141',card_type='VISA')
    assert is_credit_card('4539 9473 7946 3168',card_type='VISA')
    # Mastercard cards
    assert is_credit_card('2149-9006-1149-2944',card_type='MASTERCARD')
    assert is_credit_card('5480 0533 2122 5945',card_type='MASTERCARD')
    assert is_credit_card('5238-8042-5702-9640',card_type='MASTERCARD')
    # American Express cards

# Generated at 2022-06-24 02:24:22.969350
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn("1506715214") == True
    assert is_isbn("9780312498580") == True

# Generated at 2022-06-24 02:24:28.281281
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com')
    assert is_url('http://mysite.com')
    assert is_url('https://mysite.com')
    assert is_url('http://www.mysite.com', ['http', 'https'])
    assert not is_url('https://mysite.com', ['ftp'])


# Generated at 2022-06-24 02:24:29.820094
# Unit test for function is_string
def test_is_string():
    assert(is_string('foo') == True)
    assert(is_string(b'foo') == False)


# Generated at 2022-06-24 02:24:39.453461
# Unit test for function is_snake_case
def test_is_snake_case():
    # valid cases
    assert is_snake_case('foo_bar') is True
    assert is_snake_case('foo_bar_baz') is True
    assert is_snake_case('foo_bar_baz_42') is True

    # invalid cases
    assert is_snake_case('') is False
    assert is_snake_case('foo') is False
    assert is_snake_case('foo_bar_baz_42_') is False
    assert is_snake_case('_foo_bar_baz') is False
    assert is_snake_case('4_foo_bar') is False



# Generated at 2022-06-24 02:24:46.012435
# Unit test for function is_string
def test_is_string():
    assert is_string('foo') is True
    assert is_string(b'foo') is False
    assert is_string(2) is False
    assert is_string(dict()) is False
    assert is_string(set()) is False
    assert is_string(tuple()) is False
    assert is_string(list()) is False
    assert is_string(None) is False
    assert is_string(True) is False


# Generated at 2022-06-24 02:24:53.163880
# Unit test for function is_email
def test_is_email():
    assert is_email('test@test.com') == True
    assert is_email('test.test@test.com') == True
    assert is_email('test@test.com.br') == True
    assert is_email('test(test)@test.com') == True
    assert is_email('test@test.co.uk') == True
    assert is_email('test+test@test.com') == True
    assert is_email('') == False
    assert is_email('test@') == False
    assert is_email('test') == False
    assert is_email('test@test.') == False
    assert is_email('test@testcom') == False
    assert is_email('test@.com') == False
    assert is_email('test@test.c') == False

# Generated at 2022-06-24 02:24:57.534879
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert(True == is_ip_v4('255.200.100.75'))
    assert(False == is_ip_v4('nope'))
    assert(False == is_ip_v4('255.200.100.999'))


# Generated at 2022-06-24 02:25:01.918569
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('foo_bar_baz') == True
    assert is_snake_case('foo') == False
    
test_is_snake_case()



# Generated at 2022-06-24 02:25:07.666879
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') is True
    assert is_isbn('978-0312498580') is True
    assert is_isbn('978-0312498580', normalize=False) is False



# Generated at 2022-06-24 02:25:11.544761
# Unit test for function is_url
def test_is_url():
    assert is_url("http://www.mysite.com") == True
    assert is_url("https://www.mysite.com") == True
    assert is_url("www.mysite.com") == False
    assert is_url("mysite.com") == False

# Generated at 2022-06-24 02:25:17.362026
# Unit test for function is_number
def test_is_number():
    assert is_number('42')
    assert is_number('19.99')
    assert is_number('-9.12')
    assert is_number('1e3')
    assert not is_number('1 2 3')
# END Unit test for function is_number



# Generated at 2022-06-24 02:25:19.038048
# Unit test for function is_ip
def test_is_ip():
    expected = True
    assert expected == is_ip('255.0.0.1')


# Generated at 2022-06-24 02:25:28.989040
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case("MyString") == True
    assert is_camel_case("mystring") == False
    assert is_camel_case("myString") == True
    assert is_camel_case("myAString") == True
    assert is_camel_case("myA1String") == True
    assert is_camel_case("1MyString") == False
    assert is_camel_case("1") == False
    assert is_camel_case("") == False
    assert is_camel_case("a") == True
    assert is_camel_case("A") == True
    assert is_camel_case("Hello") == True
    assert is_camel_case("HeLLo") == False
    assert is_camel_case("HeLlo") == True
    assert is_

# Generated at 2022-06-24 02:25:40.055817
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('') == False
    assert is_snake_case('hello') == False
    assert is_snake_case('hello_') == False
    assert is_snake_case('_hello') == True
    assert is_snake_case('_hello_') == True
    assert is_snake_case('hello_world') == True
    assert is_snake_case('hello_world_') == True
    assert is_snake_case('_hello_world') == True
    assert is_snake_case('_hello_world_') == True
    assert is_snake_case('hello-world') == True
    assert is_snake_case('hello-world-') == True
    assert is_snake_case('-hello-world') == True
    assert is_snake_

# Generated at 2022-06-24 02:25:44.097319
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75') == True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip('1.2.3') == False
test_is_ip()

# Generated at 2022-06-24 02:25:46.719799
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75') == True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip('1.2.3') == False
    return True



# Generated at 2022-06-24 02:25:50.189437
# Unit test for function is_string
def test_is_string():
    assert is_string("abc") == True


# Generated at 2022-06-24 02:25:56.161729
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('42.0')
    assert not is_decimal('42')
    assert is_decimal('-9.80')
    assert is_decimal('-9.80e-2')
    assert not is_decimal('9e+')
    assert not is_decimal('9.8.0')
    assert not is_decimal('foo')
    assert not is_decimal('')
    assert not is_decimal(' ')
    assert not is_decimal(None)
    assert not is_decimal(24)


# Generated at 2022-06-24 02:26:01.524411
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    assert __ISBNChecker('').input_string == ''
    assert __ISBNChecker('978-0-7356-6745-7', True).input_string == '9780735667457'
    assert __ISBNChecker('978-0-7356-6745-7', False).input_string == '978-0-7356-6745-7'
    assert __ISBNChecker('978-0-7356-6745-7').input_string == '9780735667457'

    try:
        __ISBNChecker(None)
        assert False
    except InvalidInputError:
        assert True



# Generated at 2022-06-24 02:26:04.928837
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('LOL') # returns true
    assert not is_palindrome('Lol') # returns false
    assert is_palindrome('Lol', ignore_case=True) # returns true
    assert not is_palindrome('ROTFL') # returns false



# Generated at 2022-06-24 02:26:15.727217
# Unit test for function is_email
def test_is_email():
    # True
    assert(is_email("testEmail@gmail.com"))
    assert(is_email("test1.email@gmail.com"))
    assert(is_email("test_email@gmail.com"))
    assert(is_email("test.emai1.l@gmail.com"))
    assert(is_email("test.email@gmail.com"))
    assert(is_email("test-email@gmail.com"))
    assert(is_email("test_email@gmail.com"))
    assert(is_email("test'email@gmail.com"))
    assert(is_email("test-email@gmail.com"))
    assert(is_email("test_email@gmail.com"))
    assert(is_email("test'email@gmail.com"))
    assert(is_email("test+email@gmail.com"))

# Generated at 2022-06-24 02:26:24.428624
# Unit test for function is_isogram
def test_is_isogram():
    """
    Tests for is_isogram function.
    """
    assert is_isogram('dermatoglyphics')
    assert is_isogram('isogram')
    assert is_isogram('moose')
    assert is_isogram('aba')
    assert not is_isogram('abcabc')
    assert not is_isogram('moOse')
    assert not is_isogram('isIsogram')
    assert not is_isogram('aba ')
    assert not is_isogram(' aba')
    assert not is_isogram('aba  ')
    assert not is_isogram('  aba')
    assert not is_isogram('++')
    assert not is_isogram(' ')
    assert not is_isogram('')
    assert not is_isogram(1)
    assert not is_

# Generated at 2022-06-24 02:26:26.902710
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert(is_isbn_10('1506715214') == True)
    assert(is_isbn_10('150-6715214', normalize=False) == False)

# Generated at 2022-06-24 02:26:31.991792
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    checker = __ISBNChecker('978-0-306-40615-7')
    return (
        checker.input_string == '9780306406157',
        is_string(checker.input_string),
        is_isbn_13(checker.input_string)
    )


# UTILITY FUNCTIONS



# Generated at 2022-06-24 02:26:36.845411
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert not is_ip_v4('999.200.100.75')
    assert not is_ip_v4('999.200.100.999')
    assert not is_ip_v4('999.200.1gh0.999')
    assert not is_ip_v4('999.200.10')



# Generated at 2022-06-24 02:26:42.524422
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4012888888881881') == True
    assert is_credit_card('378282246310005') == True
    assert is_credit_card('6011111111111117') == True
    assert is_credit_card('5105105105105100') == True
    assert is_credit_card('4111111111111111') == True
    assert is_credit_card('4111 1111 1111 1111') == True
    assert is_credit_card('4111-1111-1111-1111') == True
    assert is_credit_card('4111 1111 1111 1111') == True
    assert is_credit_card('') == False
    assert is_credit_card(' ') == False
    assert is_credit_card('378282246310005', 'AMEX') == True


# Generated at 2022-06-24 02:26:50.061192
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('abcdefghijklmnopqrstuvwxyz') == True
    assert is_pangram('abcdefghijklmnopqrstuvwxy') == False
    assert is_pangram('AbCdEfGhIjKlMnOpQrStUvWxYz') == True
    assert is_pangram('AbCdEfGhIjKlMnOpQrStUvWxY') == False
    assert is_pangram('AbCdEfGhIJklmnOpqrstuVWxYz') == True
    assert is_pangram('AbCdEfGhIJklmnoPQrstuVWxYz') == True

# Generated at 2022-06-24 02:26:53.954091
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580') == True
    assert is_isbn_13('978-0312498580') == True
    assert is_isbn_13('978-0312498580', normalize=False) == False


# Generated at 2022-06-24 02:26:56.874593
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('MyString') == True
    assert is_camel_case('myString') == True
    assert is_camel_case('my-string') == False
    assert is_camel_case('2_string') == False



# Generated at 2022-06-24 02:27:02.840821
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4000002043615021')
    assert is_credit_card('4000002043615021', card_type='VISA')
    assert not is_credit_card('4000002043615021', card_type='MASTERCARD')

    assert is_credit_card('5421380023175837')
    assert is_credit_card('5421380023175837', card_type='MASTERCARD')
    assert not is_credit_card('5421380023175837', card_type='DINERS_CLUB')

    assert is_credit_card('3783444444444444')
    assert is_credit_card('3783444444444444', card_type='AMERICAN_EXPRESS')

# Generated at 2022-06-24 02:27:08.354373
# Unit test for function words_count
def test_words_count():
    assert words_count("Hello world!") == 2
    assert words_count("The quick brown fox jumps over the lazy dog") == 9
    assert words_count("The quick brown fox jumps over the lazy dog.") == 9
    assert words_count("The quick brown fox jumps over the lazy dog...") == 9
    assert words_count("The quick brown fox") == 5
    assert words_count("HelloWorld") == 1
    assert words_count("") == 0

# Generated at 2022-06-24 02:27:16.096239
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') == True
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True) == True
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf') == False


# Generated at 2022-06-24 02:27:19.210278
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999')

if __name__ == '__main__':
    test_is_ip_v4()



# Generated at 2022-06-24 02:27:21.646221
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42')
    assert is_integer('42.0') == False
test_is_integer()


# Generated at 2022-06-24 02:27:32.487288
# Unit test for function is_url
def test_is_url():
    assert is_url("https://www.google.com/")
    assert is_url("https://www.google.com")
    assert is_url("https://www.google.co.ma")
    assert is_url("http://www.google.com/")
    assert is_url("http://www.google.com")
    assert is_url("https://www.googl.com")
    assert is_url("https://www.goo.com")
    assert is_url("https://www.go.com")
    assert is_url("http://www.g.com")
    assert is_url("http://www.g.com/")
    assert is_url("https://www.g.com")
    assert is_url("https://www.g.com/")
    assert is_url("http://g.com")

# Generated at 2022-06-24 02:27:44.259305
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6("2001:db8:85a3:0:0:8a2e:370:7334") == True
    assert is_ip_v6("02001:db8:85a3:0:0:8a2e:370:7334") == False
    assert is_ip_v6("2001:db8:85a3::8a2e:370:7334") == True
    assert is_ip_v6("2001:db8:85a3:0:0:8a2e:370:") == True
    assert is_ip_v6("1:0:0:1:1:0:0:1:0:0:1:1:0:0:1") == True

# Generated at 2022-06-24 02:27:54.882913
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('aa') == True
    assert is_palindrome('11') == True
    assert is_palindrome('aA') == False
    assert is_palindrome('aA', ignore_case=True) == True
    assert is_palindrome('Aa', ignore_case=True) == True
    assert is_palindrome('aaA', ignore_case=True) == True
    assert is_palindrome('A a', ignore_spaces=True) == True
    assert is_palindrome('A a', ignore_case=True) == False
    assert is_palindrome('A a', ignore_case=True, ignore_spaces=True) == True
    assert is_palindrome('abc') == False
    assert is_palindrome('aabbcc') == True

# Generated at 2022-06-24 02:28:05.590050
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('LOL') == True
    assert is_palindrome('i topi non avevano nipoti', ignore_spaces=True) == True
    assert is_palindrome('ROTFL') == False
    assert is_palindrome('i topi non avevano nipoti', ignore_spaces=True) == True
    assert is_palindrome('Amore, Roma.') == True
    assert is_palindrome('A man, a plan, a canal. Panama') == True
    assert is_palindrome('Test phrase') == False
    assert is_palindrome('') == True


# Generated at 2022-06-24 02:28:10.484511
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('<strong>text</strong>') is True
    assert contains_html('<div>') is True
    assert contains_html('unsafe') is False



# Generated at 2022-06-24 02:28:22.364842
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert(is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334') == True)
    assert(is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?') == False) # Invalid '?'
    assert(is_ip_v6('2001:db8:82:a3::8a2e:944a') == True)
    assert(is_ip_v6('2001:db8:82:a3::8a2e:944a:000') == False) # trailing 0's must be omitted
    assert(is_ip_v6('2001:db8::8a2e:944a:000') == True)

# Generated at 2022-06-24 02:28:32.604450
# Unit test for function is_pangram
def test_is_pangram():
    a = "The quick brown fox jumps over the lazy dog"
    b = "Pack my box with five dozen liquor jugs"
    c = "How razorback-jumping frogs can level six piqued gymnasts!"
    d = "The five boxing wizards jump quickly"
    e = "The quick onyx goblin jumps over the lazy dwarf"
    f = "Victor jagt zwölf Boxkämpfer quer über den großen Sylter Deich"
    g = "Ах чудна българска земьо, чудни морета"
    h = "Това е просто стринг"

# Generated at 2022-06-24 02:28:34.982079
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog') is True
    assert is_pangram('hello world') is False


# Generated at 2022-06-24 02:28:38.266042
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('192.168.0.1') == True
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False
    
# Run unit tests    
test_is_ip_v4()



# Generated at 2022-06-24 02:28:40.227987
# Unit test for function is_integer
def test_is_integer():
    assert is_integer("42")
    assert not is_integer("42.0")



# Generated at 2022-06-24 02:28:42.391699
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75') == True 
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip('1.2.3') == False



# Generated at 2022-06-24 02:28:47.414116
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title') == True
    assert is_slug('My blog post title') == False
test_is_slug()


# Generated at 2022-06-24 02:28:50.844076
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}')
    assert is_json('[1, 2, 3]')
    assert not is_json('{nope}')

test_is_json()



# Generated at 2022-06-24 02:29:00.920643
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580')
    assert not is_isbn('9780312498580', normalize=False)
    assert is_isbn('978-0312498580')
    assert is_isbn('978-0312498580', normalize=False)
    assert is_isbn('1506715214')
    assert not is_isbn('1506715214', normalize=False)
    assert is_isbn('150-6715214')
    assert is_isbn('150-6715214', normalize=False)



# Generated at 2022-06-24 02:29:02.971665
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580')
    assert not is_isbn_13('9780312498580', normalize=False)
    

# Generated at 2022-06-24 02:29:13.503830
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker("0-7475-3269-9").is_isbn_10() is True
    assert __ISBNChecker("978-0-306-40615-7").is_isbn_10() is False

    assert __ISBNChecker("80-7178-068-4").is_isbn_10() is True
    assert __ISBNChecker("0-306-40615-2").is_isbn_10() is True
    assert __ISBNChecker("0-87021-424-2").is_isbn_10() is True
    assert __ISBNChecker("1-57528-255-3").is_isbn_10() is True
    assert __ISBNChecker("1-57528-519-7").is_isbn_10() is True
    assert __ISBNCheck

# Generated at 2022-06-24 02:29:16.486096
# Unit test for function contains_html
def test_contains_html():

    actual = contains_html('my string is <strong>bold</strong>')
    expected = True
    assert actual == expected
    actual = contains_html('my string is not bold')
    expected = False
    assert actual == expected

# Generated at 2022-06-24 02:29:18.390508
# Unit test for function is_string
def test_is_string():
    assert is_string('foo')
    assert not is_string(b'foo')
# Test for success
test_is_string()

# Generated at 2022-06-24 02:29:29.859875
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('9781408855652').is_isbn_13() == True
    assert __ISBNChecker('978-1-4088-5565-2').is_isbn_13() == True
    assert __ISBNChecker('9781408855650').is_isbn_13() == False
    assert __ISBNChecker('978-1-4088-5565-0').is_isbn_13() == False
    assert __ISBNChecker('9781408855653').is_isbn_13() == False
    assert __ISBNChecker('978-1-4088-5565-3').is_isbn_13() == False
    assert __ISBNChecker('0001234567890').is_isbn_13() == True

# Generated at 2022-06-24 02:29:36.330531
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') == True
    assert is_isbn('1506715214') == True
    assert is_isbn('978-0312498580', normalize=False) == False

# Generated at 2022-06-24 02:29:38.768807
# Unit test for function is_pangram
def test_is_pangram():
    ## Test for "True"
    assert is_pangram('The quick brown fox jumps over the lazy dog')
    ## Test for "False"
    assert not is_pangram('hello world')
test_is_pangram()


# Generated at 2022-06-24 02:29:43.896889
# Unit test for function is_ip_v4
def test_is_ip_v4():
    # is_ip_v4(None)
    # INFO: In method 'is_ip_v4', line 294:
    # An empty string is required
    assert is_ip_v4('') == False
    # INFO: In method 'is_ip_v4', line 294:
    # An empty string is required
    assert is_ip_v4(' ') == False
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False
