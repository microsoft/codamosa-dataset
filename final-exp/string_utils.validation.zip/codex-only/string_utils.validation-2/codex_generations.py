

# Generated at 2022-06-24 02:19:45.693522
# Unit test for function is_ip_v6
def test_is_ip_v6():
    input_string = '2001:db8:85a3:0000:0000:8a2e:370:7334'
    print(is_ip_v6(input_string))

test_is_ip_v6()




# Generated at 2022-06-24 02:19:51.322793
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string('hello') is True and is_full_string('') is False
    assert is_full_string(' ') is False and is_full_string('12345') is True
test_is_full_string()



# Generated at 2022-06-24 02:19:57.307662
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string(None) == False
    assert is_full_string('') == False
    assert is_full_string(' ') == False
    assert is_full_string('hello') == True
# is_full_string test end


# Generated at 2022-06-24 02:19:59.101279
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram("The quick brown fox jumps over the lazy dog") == True
# test_is_pangram()



# Generated at 2022-06-24 02:20:02.481176
# Unit test for function is_slug
def test_is_slug():
    assert is_slug("my-blog-post-title")
    assert is_slug("my_blog_post_title",separator="_")
    assert not is_slug("My blog post title")
    assert not is_slug("My-blog-post-title")


# Generated at 2022-06-24 02:20:07.129673
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('9781234567890').is_isbn_13() == True


# Generated at 2022-06-24 02:20:11.884083
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75') == True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip('1.2.3') == False

test_is_ip()


# Generated at 2022-06-24 02:20:23.957628
# Unit test for function is_email
def test_is_email():
    assert is_email('foo@bar.com')
    assert is_email('x@x.au')
    assert is_email('foo+bar@bar.com')
    assert is_email('hans.m端ller@test.com')
    assert is_email('hans@m端ller.com')
    assert not is_email('invalidemail@')
    assert not is_email('invalid.com')
    assert not is_email('@invalid.com')
    assert is_email('test|123@m端ller.com')
    assert is_email('test123+ext@gmail.com')
    assert is_email('some.name.midd.leNa.me+extension@GoogleMail.com')
    assert is_email('"foobar"@example.com')
    assert is_email

# Generated at 2022-06-24 02:20:29.345536
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('my string is <strong>bold</strong>') is True
    assert contains_html('my string is not bold') is False


# Generated at 2022-06-24 02:20:37.302778
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('my-email@the-provider.com')
    assert not is_email('@gmail.com')
    assert not is_email('my..email@the-provider.com')
    assert not is_email('my.email@the-provider.com.')
    assert is_email('my.email@the-provider.com.', allowed_schemes=['mailto:'])
    assert not is_email('my.email@the-provider.com.', allowed_schemes=['http:'])
    assert is_email('"hello I am email"@example.com')
    assert is_email('"hello@I am email"@example.com')

# Generated at 2022-06-24 02:20:38.837841
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75')
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334')
    assert is_ip('1.2.3')==False
test_is_ip()


# Generated at 2022-06-24 02:20:39.361883
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42') == True


# Generated at 2022-06-24 02:20:45.911593
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram("Dermatoglyphics") == True
    assert is_isogram("isogram") == True
    assert is_isogram("aba") == False
    assert is_isogram("moOse") == False
    assert is_isogram("isIsogram") == False
    assert is_isogram("") == True


# Generated at 2022-06-24 02:20:49.452243
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('myString') == True
    assert is_camel_case('myString42') == True
    assert is_camel_case('42myString') == False
    assert is_camel_case('') == False
    assert is_camel_case('mystring') == False


# Generated at 2022-06-24 02:20:51.311704
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title') == True
    assert is_slug('My blog post title') == False
test_is_slug()



# Generated at 2022-06-24 02:20:58.138601
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')  # returns true
    assert is_ip_v4('nope') == False  # returns false (not an ip)
    assert is_ip_v4('255.200.100.999') == False  # returns false (999 is out of range)

test_is_ip_v4()


# Generated at 2022-06-24 02:20:59.356497
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('hello') is False

# Generated at 2022-06-24 02:21:05.626136
# Unit test for function is_ip_v6
def test_is_ip_v6():
    test_string1='2001:db8:85a3:0000:0000:8a2e:370:7334'
    test_string2='2001:db8:85a3:0000:0000:8a2e:370:?'
    assert(is_ip_v6(test_string1))
    assert(not is_ip_v6(test_string2))


# Generated at 2022-06-24 02:21:07.537862
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('MyString')
    assert not is_camel_case('mystring')



# Generated at 2022-06-24 02:21:11.266368
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('Dermatoglyphics') == True
    assert is_isogram('isogram') == True
    assert is_isogram('aba') == False
    assert is_isogram('moOse') == False
    assert is_isogram('isIsogram') == False
    assert is_isogram('') == True
test_is_isogram()


# Generated at 2022-06-24 02:21:13.652247
# Unit test for function is_full_string
def test_is_full_string():
    assert (is_full_string(None) == False)
    assert (is_full_string('') == False)
    assert (is_full_string(' ') == False)
    assert (is_full_string('hello') == True)


# Generated at 2022-06-24 02:21:20.055715
# Unit test for function is_isbn_13
def test_is_isbn_13():
    # Check ISBN 13
    assert is_isbn_13("978-0312498580") == True
    # Check ISBN 13 Invalid
    assert is_isbn_13("978-0312498580", False) == False

# Generated at 2022-06-24 02:21:25.891037
# Unit test for function words_count
def test_words_count():
    assert words_count('hello world') == 2
    assert words_count('one,two,three.stop') == 4
    assert words_count("I'm singing a song!") == 5
    assert words_count("! @ # % ... []") == 0



# Generated at 2022-06-24 02:21:31.785500
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0596000278').is_isbn_10() is True
    assert __ISBNChecker('0-596-00027-8').is_isbn_10() is True

    assert __ISBNChecker('0596000270').is_isbn_10() is False

# Generated at 2022-06-24 02:21:34.100565
# Unit test for function is_string
def test_is_string():
    assert is_string('foo')
    assert not is_string(b'foo')


# Generated at 2022-06-24 02:21:45.796236
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') == True
    assert is_isbn_10('150-6715214') == True
    assert is_isbn_10('150-6715214', normalize=False) == False
    assert is_isbn_10('0738707910') == True
    assert is_isbn_10('979-10-90646-00-5') == True
    assert is_isbn_10('1-56619-909-X') == True
    assert is_isbn_10('1-56619-909-X', normalize=False) == True
    assert is_isbn_10('156619909X') == True
    assert is_isbn_10('abcd') == False
    assert is_isbn_10('150-6715214') == True

# Generated at 2022-06-24 02:21:48.668864
# Unit test for function is_full_string
def test_is_full_string():
    assert not is_full_string(None)
    assert not is_full_string('')
    assert not is_full_string(' ')
    assert is_full_string('hello')
    
    

# Generated at 2022-06-24 02:21:50.591886
# Unit test for function is_string
def test_is_string():
    assert is_string('obj') == True, "Should return true"
    assert is_string(b'') == False, "Should return false"


# Generated at 2022-06-24 02:22:01.644834
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75')
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334')
    assert is_ip('0.0.0.0')
    assert not is_ip('1.2.3')
    assert not is_ip('255.200.100.699') # out range
    assert not is_ip('')
    assert not is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334:aaa') # two many tokens
    assert not is_ip('2001:db8:85a3:0000:0000:8a2e:370:') # not enough tokens

# Generated at 2022-06-24 02:22:09.149513
# Unit test for function is_integer
def test_is_integer():
    """
    Test function is_integer
    :return:
    """
    assert is_integer('42') == True
    assert is_integer('-42') == True
    assert is_integer('+42') == True
    assert is_integer('0') == True
    assert is_integer('42.1') == False
    assert is_integer('0.0') == False
    assert is_integer('+0.0') == False
    assert is_integer('-0.0') == False
    assert is_integer('42.0') == False
    assert is_integer('42e3') == True
    assert is_integer('42e-3') == True
    assert is_integer('42e+3') == True
    assert is_integer('42E3') == True
    assert is_integer('42E-3') == True


# Generated at 2022-06-24 02:22:14.486501
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title', separator='-')
    assert is_slug('my_blog_post_title', separator='_')
    assert is_slug('myblogposttitle', separator='')
    assert is_slug('myblogposttitle')
    assert not is_slug('My blog post title')



# Generated at 2022-06-24 02:22:17.709406
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42')
    assert not is_integer('3.14')
    assert not is_integer('-3.14')
    assert is_integer('42.0')
    assert not is_integer('42.1')
    assert not is_integer('1e3')



# Generated at 2022-06-24 02:22:24.939858
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('42.0') == True
    assert is_decimal('42') == False
    assert is_decimal('42.000') == True
    assert is_decimal('.42') == True
    assert is_decimal('-0.42') == True
    assert is_decimal('0.42') == True
    assert is_decimal('0.4.2') == False
test_is_decimal()


# Generated at 2022-06-24 02:22:26.949379
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('foo_bar_baz') is True
    assert is_snake_case('foo') is False


# Generated at 2022-06-24 02:22:31.193493
# Unit test for function is_isogram
def test_is_isogram():
    assert(is_isogram('dermatoglyphics') == True)
    assert(is_isogram('hello') == False)
    assert(is_isogram('hello world') == False)

# Generated at 2022-06-24 02:22:37.142846
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75')
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334')
    assert not is_ip('1.2.3')
test_is_ip()



# Generated at 2022-06-24 02:22:46.239424
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('978-5-906604-95-5').is_isbn_10() == False
    assert __ISBNChecker('5-906604-95-5').is_isbn_10() == False
    assert __ISBNChecker('978-5-9066049556').is_isbn_10() == False
    assert __ISBNChecker('5-9066049556').is_isbn_10() == False
    assert __ISBNChecker('978-5-906604-95-6').is_isbn_10() == True
    assert __ISBNChecker('5-906604-95-6').is_isbn_10() == True
    assert __ISBNChecker('978-5-9066049557').is_isbn_10() == True
   

# Generated at 2022-06-24 02:22:47.671407
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    assert __ISBNChecker(__ISBNChecker).__init__() is None


# PUBLIC API



# Generated at 2022-06-24 02:22:52.004462
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card("4111111111111111") is True
    assert is_credit_card("2222222222222222") is True
    assert is_credit_card("4111 1111 1111 1111") is True
    assert is_credit_card("4111-1111-1111-1111") is True
    assert is_credit_card("4a11-11a1-1111-1111") is False



# Generated at 2022-06-24 02:22:58.888691
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title')
    assert is_slug('my-blog-post-title', '_')
    assert is_slug('my-blog-post-title', '----')
    assert not is_slug('My blog post title')
    assert not is_slug('My blog post title', '_')
    assert not is_slug('_my-blog-post-title')



# Generated at 2022-06-24 02:23:04.678116
# Unit test for function contains_html
def test_contains_html():
    if not contains_html('<html> <head> <title>Page Title</title> </head> <body> <h1>This is a Heading</h1>'):
        print("Test 1 : True")
    else:
        print("Test 1 : False")
    if contains_html('This is a Heading'):
        print("Test 2 : True")
    else:
        print("Test 2 : False")
test_contains_html()


# Generated at 2022-06-24 02:23:09.190216
# Unit test for function is_ip_v6
def test_is_ip_v6():
    test_data = [
        # Input, expected result
        ['2001:db8:85a3:0000:0000:8a2e:370:7334', True],
        ['2001:db8:85a3:0000:0000:8a2e:370:?', False],
        ['2001:db8:85a3:0000:0000:8a2e:370:7334:1121', False]
    ]
    for ip, expected_result in test_data:
        assert is_ip_v6(ip) == expected_result
test_is_ip_v6()



# Generated at 2022-06-24 02:23:16.349054
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0545162076').is_isbn_10() == True
    assert __ISBNChecker('0545162077').is_isbn_10() == False
    assert __ISBNChecker('4942786157').is_isbn_10() == True
    assert __ISBNChecker('4942786158').is_isbn_10() == False
    assert __ISBNChecker('0596009208').is_isbn_10() == True
    assert __ISBNChecker('0596009209').is_isbn_10() == False
    assert __ISBNChecker('0761152673').is_isbn_10() == True
    assert __ISBNChecker('0761152674').is_isbn_10() == False

# Generated at 2022-06-24 02:23:23.039599
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram("Dermatoglyphics") == True
    assert is_isogram("isogram") == True
    assert is_isogram("moose") == False
    assert is_isogram("isIsogram") == False
    assert is_isogram("aba") == False
    assert is_isogram("moOse") == False
    assert is_isogram("thumbscrewjapingly") == True
    assert is_isogram("") == True

# Generated at 2022-06-24 02:23:24.651728
# Unit test for function is_string
def test_is_string():
    assert is_string('foo') is True and is_string(b'foo') is False


# Generated at 2022-06-24 02:23:30.023112
# Unit test for function is_ip_v6
def test_is_ip_v6():
    result = is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334')
    assert result==True, "True"
test_is_ip_v6()



# Generated at 2022-06-24 02:23:34.106603
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    try:
        __ISBNChecker('123', normalize=False)
    except InvalidInputError:
        pass

    assert __ISBNChecker('123-4').input_string == '1234'
    assert __ISBNChecker('123-4', normalize=False).input_string == '123-4'


# PUBLIC API



# Generated at 2022-06-24 02:23:45.151830
# Unit test for function is_email
def test_is_email():
    assert(is_email('my.email@the-provider.com') == True)
    assert(is_email('@gmail.com') == False)
    assert(is_email('.my.email@the-provider.com') == False)
    assert(is_email('my.email.a@the-provider.com') == True)
    assert(is_email('my.email@t.com') == True)
    assert(is_email('my.email@theprovider.com') == True)
    assert(is_email('my..email@theprovider.com') == False)
    assert(is_email('this is"not\\allowed"@example.com') == False)
    assert(is_email('this\\ still\\"not\\\\allowed"@example.com') == True)

# Generated at 2022-06-24 02:23:51.319461
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334')
    #assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?') # returns false (invalid "?")

# End of Unit test for function is_ip_v6



# Generated at 2022-06-24 02:23:56.411236
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?') == False


# Generated at 2022-06-24 02:24:07.437216
# Unit test for function is_number
def test_is_number():
    is_number('100')
    is_number('101')
    is_number('-100')
    is_number('-101')
    is_number('10.1')
    is_number('-10.1')
    is_number('2e2')
    is_number('-2e2')
    is_number('2e-2')
    is_number('2.2e2')
    is_number('2.2e-2')
    is_number('-2.2e2')
    is_number('-2.2e-2')

    is_number('1.2.3')
    is_number('1.2a')
    is_number('1.2')
    is_number('1.a')
    is_number('1e')

# Generated at 2022-06-24 02:24:18.440291
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert(not __ISBNChecker('').is_isbn_13())
    assert(not __ISBNChecker('978-1-60309-12345').is_isbn_13())
    assert(not __ISBNChecker('978-1-60309-12345-2').is_isbn_13())
    assert(not __ISBNChecker('978-1-60309-12345-1').is_isbn_13())
    assert(not __ISBNChecker('978-1-60309-1234-5').is_isbn_13())
    assert(not __ISBNChecker('978-1-60309-1234-6').is_isbn_13())
    assert(not __ISBNChecker('978-1-60309-123-45').is_isbn_13())

# Generated at 2022-06-24 02:24:26.891275
# Unit test for function is_json
def test_is_json():
    # a valid json string
    assert is_json('{"name": "Peter"}') == True
    # a valid json string
    assert is_json('[1, 2, 3]') == True
    # not a valid json string
    assert is_json('{nope}') == False
    # not a valid json when, in the string, the opening curly braces are not at pos 0
    assert is_json('  {"name": "Peter"}') == False
    # not a valid json when the second parameter, wrap_with_backslash is set to True
    assert is_json('  {"name": "Peter"}', wrap_with_backslash=True) == False
    # a valid json when the second parameter, wrap_with_backslash is set to True

# Generated at 2022-06-24 02:24:30.943425
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('otto')
    assert is_palindrome('i topi non avevano nipoti', ignore_spaces=True)
    assert not is_palindrome('topi')
    assert is_palindrome('OtTo', ignore_case=True)
    assert not is_palindrome('OtTo')
    assert is_palindrome('A man, a plan, a canal, Panama!')
    assert not is_palindrome('saippuakivikauppias', ignore_spaces=True)



# Generated at 2022-06-24 02:24:42.014256
# Unit test for function is_ip
def test_is_ip():
    assert_true(is_ip('1.2.3.4'))
    assert_true(is_ip('localhost'))
    assert_true(is_ip('127.0.0.1'))
    assert_true(is_ip('127.0.0.1:8080'))
    assert_true(is_ip('251.2.3.4'))
    assert_true(is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334'))
    assert_false(is_ip('www.google.it'))
    assert_false(is_ip('1.2.3'))
    assert_false(is_ip('a.b.c.d'))
    assert_false(is_ip(':::1'))

# Generated at 2022-06-24 02:24:48.290453
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert (is_isbn_10('1506715214'))
    assert (is_isbn_10('150-6715214'))
    assert (not is_isbn_10('150-6715214', normalize=False))
    return True



# Generated at 2022-06-24 02:24:52.443917
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn("9780312498580")
    assert is_isbn("1506715214")
    assert not is_isbn("9780312498580", normalize=False)
    assert not is_isbn("978-0312498580", normalize=False)

# Generated at 2022-06-24 02:25:04.520453
# Unit test for function words_count
def test_words_count():
    assert words_count("This is a test!") == 4
    assert words_count("This,is,a,test!") == 4
    assert words_count("This is a,test!") == 4
    assert words_count("This is! a test!") == 4
    assert words_count(" 'This' is a test!") == 4
    assert words_count(" 'This' is a test!") == 4
    assert words_count(" 'This' is a test!") == 4
    assert words_count(" 'This' is a test! ") == 4
    assert words_count(" 'This' is a \"test\"! ") == 4
    assert words_count(" 'This' is a \"test\"! ") == 4
    assert words_count("This is a' test!") == 4

# Generated at 2022-06-24 02:25:11.076965
# Unit test for function is_credit_card
def test_is_credit_card():
    card_types = ['VISA', 'MASTERCARD', 'AMERICAN_EXPRESS', 'DINERS_CLUB', 'DISCOVER', 'JCB']
    card_number = {
        'VISA': '4929 9937 5953 9107',
        'MASTERCARD': '5535 5107 8545 0500',
        'AMERICAN_EXPRESS': '3758 8444 8041 557',
        'DINERS_CLUB': '3000 0000 0005',
        'DISCOVER': '6011 0000 3718 8396',
        'JCB': '3528 6312 0149 5826',
    }
    for card in card_types:
        assert is_credit_card(card_number[card], card)
        assert is_credit_card(card_number[card])
        assert not is_

# Generated at 2022-06-24 02:25:21.189468
# Unit test for function is_email
def test_is_email():
    assert is_email('email@domain.com') == True
    assert is_email('firstname.lastname@domain.com') == True
    assert is_email('email@subdomain.domain.com') == True
    assert is_email('firstname+lastname@domain.com') == True
    assert is_email('email@123.123.123.123') == True
    assert is_email('1234567890@domain.com') == True
    assert is_email('email@domain-one.com') == True
    assert is_email('_______@domain.com') == True
    assert is_email('email@domain.name') == True
    assert is_email('email@domain.co.jp') == True
    assert is_email('firstname-lastname@domain.com') == True

# Generated at 2022-06-24 02:25:26.043738
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}')
    assert is_json('[1, 2, 3]')
    assert is_json('{"name": "Peter"}')
    assert is_json('[1, 2, 3]')
    assert is_json('{"name": "Peter"}')
    assert is_json('[1, 2, 3]')
    assert not is_json('{nope}')



# Generated at 2022-06-24 02:25:35.904045
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') is True
    assert is_url('http://www.mysite.com/') is True
    assert is_url('http://www.mysite.com:8080/') is True
    assert is_url('http://www.mysite.com/?test=test&test2=test2') is True
    assert is_url('http://www.mysite.com/test/test/test.php?test=test&test2=test2') is True
    assert is_url('http://www.mysite.com/test/test/test.php#test') is True
    assert is_url('http://www.mysite.com/test/test/test.php#test1#test2') is True

# Generated at 2022-06-24 02:25:38.338641
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?') == False


# Generated at 2022-06-24 02:25:47.921971
# Unit test for function is_snake_case
def test_is_snake_case():
    assert(is_snake_case('foo_bar_baz', '_') is True)
    assert(is_snake_case('fooBarBaz', '_') is False)
    assert(is_snake_case('fooBarBaz') is False)
    assert(is_snake_case('fooB-ar_baz', '-_') is True)
    assert(is_snake_case('fooB_ar-baz', '-_') is True)
    assert(is_snake_case('fooB-ar_baz', '_-') is True)
    assert(is_snake_case('fooB_ar-baz', '_-') is True)



# Generated at 2022-06-24 02:25:52.821338
# Unit test for function is_url
def test_is_url():
    assert  is_url('http://www.mysite.com') == True
    assert  is_url('https://mysite.com') == True
    assert  is_url('.mysite.com') == False


# Generated at 2022-06-24 02:26:07.209389
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4111111111111111', card_type='VISA') == True
    assert is_credit_card('5105105105105100', card_type='MASTERCARD') == True
    assert is_credit_card('378282246310005', card_type='AMERICAN_EXPRESS') == True
    assert is_credit_card('30569309025904', card_type='DINERS_CLUB') == True
    assert is_credit_card('6011111111111117', card_type='DISCOVER') == True
    assert is_credit_card('3530111333300000', card_type='JCB') == True

    assert is_credit_card('3530111333300000', card_type='VISA') == False

# Generated at 2022-06-24 02:26:14.946178
# Unit test for function is_integer
def test_is_integer():  # pragma: no cover
    from .validators import is_digit
    from .validators import is_integer
    from .validators import is_hexadecimal
    from .validators import is_octal
    from .validators import is_binary

    assert is_integer('42')
    assert is_integer('-23')
    assert is_integer('0')
    assert is_integer('-0')
    assert is_integer('4000000')
    assert is_integer('-4000000')
    assert is_integer('1e10')
    assert is_integer('-1e10')
    assert is_integer('1E10')
    assert is_integer('-1E10')
    assert is_integer('0xFF')
    assert is_integer('0x1A')

# Generated at 2022-06-24 02:26:20.999111
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('foo_bar_baz')
    assert is_snake_case('foo-bar-baz', '-')
    assert is_snake_case('foo__bar__baz', '__')
    assert not is_snake_case('foo__barbaz', '__')
    assert not is_snake_case('foobar__baz', '__')
    assert not is_snake_case('foo_bar_baz_', '_')
    assert not is_snake_case('foo_bar_baz_', '-')
    assert not is_snake_case('-foo_bar_baz_')
    assert not is_snake_case('foo123_foo123')
    assert not is_snake_case('foo123foo123')
    assert not is_

# Generated at 2022-06-24 02:26:29.375331
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('MyString') is True
    assert is_camel_case('mystring') is False
    assert is_camel_case('myStr1ing') is True
    assert is_camel_case('MyStr1ing') is True
    assert is_camel_case('My 1string') is False
    assert is_camel_case('1string') is False
    assert is_camel_case('1string') is False
    assert is_camel_case('string') is False
    assert is_camel_case('string1') is False
    assert is_camel_case('') is False



# Generated at 2022-06-24 02:26:34.229396
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card("4111111111111111") is True
    assert is_credit_card("5105105105105100") is True
    assert is_credit_card("378282246310005") is True
    assert is_credit_card("6011111111111117") is True
    assert is_credit_card("3530111333300000") is True
    assert is_credit_card("6221258100012345678") is True
# Test is_credit_card ends



# Generated at 2022-06-24 02:26:38.903792
# Unit test for function is_integer
def test_is_integer():
    assert is_integer(1234) == True
    assert is_integer('1234') == True
    assert is_integer('1e4') == True
    assert is_integer('-1234') == True

    assert is_integer(1234.5) == False
    assert is_integer('1234.5') == False
    assert is_integer('Hello there!') == False

test_is_integer()



# Generated at 2022-06-24 02:26:48.346940
# Unit test for function is_email
def test_is_email():
    assert is_email('example@localhost')
    assert is_email('example-1@localhost')
    assert is_email('example@localhost.com')
    assert is_email('example-1@localhost.net')
    assert is_email('example-1@localhost.co.uk')
    assert is_email('example-1@localhost.org')
    assert is_email('example-1@localhost.us')
    assert is_email('example-1@localhost.info')
    assert is_email('example-1@localhost.gov')
    assert is_email('example-1@localhost.mil')
    assert is_email('example.1@localhost')
    assert is_email('example-1@localhost-test.com')
    assert is_email('example_1@localhost')

# Generated at 2022-06-24 02:26:53.282848
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com')
    assert is_url('https://mysite.com')
    assert is_url('.mysite.com') == False


# Generated at 2022-06-24 02:27:02.504287
# Unit test for function is_number
def test_is_number():
    assert is_number('42') == True
    assert is_number('19.99') == True
    assert is_number('-9.12') == True
    assert is_number('1e3') == True
    assert is_number('1 2 3') == False

# Generated at 2022-06-24 02:27:06.938657
# Unit test for function is_uuid
def test_is_uuid():
    # arrange
    s = '6f8aa2f9-686c-4ac3-8766-5712354a04cf'
    s_bis = '6f8aa2f9686c4ac387665712354a04cf'

    # act
    res = is_uuid(s)
    res1 = is_uuid(s_bis)
    res2 = is_uuid(s_bis,True)

    # assert
    assert res == True
    assert res1 == False
    assert res2 == True



# Generated at 2022-06-24 02:27:13.684094
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf')
    assert not is_uuid('6f8aa2f9686c4ac387665712354a04cf')
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True)


# Generated at 2022-06-24 02:27:20.974439
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0596002815').is_isbn_10()
    assert __ISBNChecker('059610149X').is_isbn_10()
    assert __ISBNChecker('0596101497').is_isbn_10()
    assert __ISBNChecker('0-596-10149-7').is_isbn_10()

    assert not __ISBNChecker('0596002816').is_isbn_10()
    assert not __ISBNChecker('0596101490').is_isbn_10()
    assert not __ISBNChecker('1-596-10149-7').is_isbn_10()

    try:
        assert __ISBNChecker(5)
        assert False
    except InvalidInputError:
        assert True

# Generated at 2022-06-24 02:27:27.894528
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert(is_ip_v4('255.200.100.75') == True)
    assert(is_ip_v4('nope') == False)
    assert(is_ip_v4('255.200.100.999') == False)
# test_is_ip_v4()



# Generated at 2022-06-24 02:27:29.442198
# Unit test for function is_string
def test_is_string():
    assert is_string('foo') == True
    assert is_string(b'foo') == False


# Generated at 2022-06-24 02:27:38.135794
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    assert __ISBNChecker('123456789X').input_string == '123456789X'
    assert __ISBNChecker('123456789X', False).input_string == '123456789X'

    assert __ISBNChecker('123-456789-X').input_string == '123456789X'
    assert __ISBNChecker('123-456789-X', False).input_string == '123-456789-X'


# PUBLIC API

# Generated at 2022-06-24 02:27:47.554464
# Unit test for function is_snake_case
def test_is_snake_case():
    print("Test is_snake_case")
    assert is_snake_case("foo_bar") == True, "Error test 'foo_bar' not pass"
    assert is_snake_case("foo_bar_baz") == True, "Error test 'foo_bar_baz' not pass"
    assert is_snake_case("foo") == False, "Error test 'foo' not pass"
    assert is_snake_case("FOO_BAR") == False, "Error test 'FOO_BAR' not pass"
    assert is_snake_case("FOO_BAR_BAZ") == False, "Error test 'FOO_BAR_BAZ' not pass"
    assert is_snake_case("FOOBAR") == False, "Error test 'FOOBAR' not pass"

# Generated at 2022-06-24 02:27:50.159325
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog') == True
    assert is_pangram('hello world') == False
    
test_is_pangram()


# Generated at 2022-06-24 02:27:56.466402
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert(is_isbn_13('9780312498580') == True)
    assert(is_isbn_13('978-0312498580') == True)
    assert(is_isbn_13('978-0312498580', normalize=False) == False)
    
test_is_isbn_13()


# Generated at 2022-06-24 02:27:57.476903
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('<strong>Hello!</strong>')

# Generated at 2022-06-24 02:28:07.740307
# Unit test for function is_credit_card
def test_is_credit_card():
    # Yes
    assert(is_credit_card('4111111111111111', 'VISA'))
    assert(is_credit_card('4917610000000000003', 'VISA'))
    assert(is_credit_card('4444444444444448', 'VISA'))
    assert(is_credit_card('4444 3333 2222 1111', 'VISA'))
    assert(is_credit_card('4012888888881881', 'VISA'))
    assert(is_credit_card('4007000000027', 'VISA'))
    assert(is_credit_card('4012888888881881', 'VISA'))
    assert(is_credit_card('501800000004001', 'MASTERCARD'))

# Generated at 2022-06-24 02:28:15.496590
# Unit test for function is_credit_card
def test_is_credit_card():
    # is_credit_card(input_string: Any, card_type: str = None)
    print('is_credit_card({}) = {}'.format('', is_credit_card('')))
    print('is_credit_card({}) = {}'.format('a', is_credit_card('a')))
    print('is_credit_card({}) = {}'.format('1', is_credit_card('1')))
    print('is_credit_card({}) = {}'.format(1, is_credit_card(1))) # exception
    print('is_credit_card({}) = {}'.format('1111-2222-3333-4444', is_credit_card('1111-2222-3333-4444')))

# Generated at 2022-06-24 02:28:27.217397
# Unit test for function is_credit_card
def test_is_credit_card():
    assert not is_credit_card("a")
    assert not is_credit_card("a346547780077337")
    assert is_credit_card("346547780077337")
    assert not is_credit_card("55346547780077337")
    assert is_credit_card("55346547780077337", card_type="MASTERCARD")
    assert not is_credit_card("346547780077337", card_type="MASTERCARD")
    assert is_credit_card("5313677529402150")
    assert is_credit_card("5313677529402150", card_type="MASTERCARD")
    assert is_credit_card("346547780077337", card_type="AMERICAN_EXPRESS")
    assert is_credit

# Generated at 2022-06-24 02:28:30.223627
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') == True
    assert is_url('https://mysite.com') == True
    assert is_url('.mysite.com') == False



# Generated at 2022-06-24 02:28:38.059802
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') and not is_email('.my.email@the-provider.com')
    assert is_email('"my name with space"@the-provider.com')
    assert is_email('my.email+ext@the-provider.com')
    assert is_email('"my.email+ext"@the-provider.com')
    assert is_email('"my.email"@the-provider.com')
    assert not is_email('my.email@the-provider.com.')
    assert not is_email('my.email@the-provider.com\n')
    assert not is_email('my.email@the-provider.com\\n')

# Generated at 2022-06-24 02:28:41.002714
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') == True
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf') == False
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True) == True


# Generated at 2022-06-24 02:28:48.855283
# Unit test for function is_uuid
def test_is_uuid():
    u1 = '6f8aa2f9-686c-4ac3-8766-5712354a04cf'
    u2 = '6f8aa2f9686c4ac387665712354a04cf'
    assert not is_uuid(u1)
    assert is_uuid(u2, allow_hex=True)



# Generated at 2022-06-24 02:29:01.618307
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    try:
        _isbn_checker = __ISBNChecker(-1)
        raise AssertionError()
    except InvalidInputError:
        pass

    try:
        _isbn_checker = __ISBNChecker(None)
        raise AssertionError()
    except InvalidInputError:
        pass

    try:
        _isbn_checker = __ISBNChecker({})
        raise AssertionError()
    except InvalidInputError:
        pass

    try:
        _isbn_checker = __ISBNChecker(True)
        raise AssertionError()
    except InvalidInputError:
        pass

    try:
        _isbn_checker = __ISBNChecker('abc')
        raise AssertionError()
    except InvalidInputError:
        pass


# Generated at 2022-06-24 02:29:07.577365
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False


# Generated at 2022-06-24 02:29:12.669514
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('123')
    assert is_integer('123.0') == False
    assert is_integer('1.2') == False
    assert is_integer('1e5')
    assert is_integer('-1e5')
    assert is_integer('1e5.1') == False
    assert is_integer('-1.5e5') == False


# Generated at 2022-06-24 02:29:16.582589
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title')
    assert not is_slug('My blog post title')
    assert is_slug('my_blog_post_title', separator='_')
    assert is_slug('my.blog.post.title', separator='.')


# Generated at 2022-06-24 02:29:28.195726
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('9788792641343').is_isbn_13()
    assert __ISBNChecker('9788792641343', False).is_isbn_13()
    assert __ISBNChecker('9788792641343').is_isbn_13() == __ISBNChecker('9788792641343', False).is_isbn_13()

    assert not __ISBNChecker('9788792641340').is_isbn_13()
    assert not __ISBNChecker('9788792641340', False).is_isbn_13()
    assert __ISBNChecker('9788792641340').is_isbn_13() == __ISBNChecker('9788792641340', False).is_isbn_13()

# Generated at 2022-06-24 02:29:38.053484
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') is True
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf') is False
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True) is True




# Generated at 2022-06-24 02:29:41.158834
# Unit test for function words_count
def test_words_count():
    assert words_count('I am happy') == 3
    assert words_count('I am happy, very happy') == 5
    assert words_count('I am happy. Very happy!') == 5
    assert words_count('I am happy? Very happy!') == 5
    assert words_count('I am happy and very happy') == 6
    assert words_count('I am happy, but very happy!') == 6