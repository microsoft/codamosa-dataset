

# Generated at 2022-06-24 02:19:48.321868
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('foo_bar_baz')
    assert not is_snake_case('foo')
    assert is_snake_case('foo', '-')
    assert not is_snake_case('foo', '-')



# Generated at 2022-06-24 02:19:53.456365
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert not __ISBNChecker('1234567890123').is_isbn_13()
    assert not __ISBNChecker('12345678901234').is_isbn_13()
    assert not __ISBNChecker('1234567890123A').is_isbn_13()
    assert __ISBNChecker('978-3-642-27947-6').is_isbn_13()
    assert __ISBNChecker('9783642279476').is_isbn_13()
    return True

# Generated at 2022-06-24 02:20:02.032524
# Unit test for function is_decimal
def test_is_decimal():
    assert (is_decimal('18.5') == True)
    assert (is_decimal('0.5') == True)
    assert (is_decimal('1') == False)
    assert (is_decimal('3.456789') == True)
    assert (is_decimal('-4.78') == True)
    assert (is_decimal('-1') == False)
    assert (is_decimal('.5789') == True)
    assert (is_decimal('-.5') == True)
    assert (is_decimal('+.5') == True)
    assert (is_decimal('+.1234') == True)
    assert (is_decimal('-0.1234') == True)
    assert (is_decimal('12.34') == True)



# Generated at 2022-06-24 02:20:11.089769
# Unit test for function is_number
def test_is_number():
    assert is_number(None) == False
    assert is_number(2) == False
    assert is_number('42') == True
    assert is_number('19.99') == True
    assert is_number('-9.12') == True
    assert is_number('1e3') == True
    assert is_number('1 2 3') == False
    assert is_number('dummy') == False

test_is_number()



# Generated at 2022-06-24 02:20:19.856138
# Unit test for function is_string
def test_is_string():
    from random import randint
    from random import randrange
    from random import choice

    def __random_string(size: int = 0) -> str:
        return ''.join([choice(string.ascii_letters) for _ in range(size)])

    def __random_number_string(size: int = 0) -> str:
        return ''.join([choice(string.digits) for _ in range(size)])

    def __random_punctuation_string(size: int = 0) -> str:
        return ''.join([choice(string.punctuation) for _ in range(size)])

    def __random_printable_string(size: int = 0) -> str:
        return ''.join([choice(string.printable) for _ in range(size)])


# Generated at 2022-06-24 02:20:24.459515
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf')
    assert not is_uuid('6f8aa2f9686c4ac387665712354a04cf')



# Generated at 2022-06-24 02:20:33.741880
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('10.0.0.0') == True
    assert is_ip_v4('0.0.0.0') == True
    assert is_ip_v4('127.0.0.1') == True
    assert is_ip_v4('255.255.255.255') == True
    assert is_ip_v4('255.255.255.256') == False
    assert is_ip_v4('127.0.0.1.1') == False
    assert is_ip_v4('256.0.0.0') == False


# Generated at 2022-06-24 02:20:37.449788
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    checker = __ISBNChecker(input_string='978-3-16-148410-0')
    assert checker.is_isbn_13() == True
    
    checker = __ISBNChecker(input_string='978-3-16-148410-1')
    assert checker.is_isbn_13() == False

# Generated at 2022-06-24 02:20:38.908145
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False



# Generated at 2022-06-24 02:20:40.196734
# Unit test for function is_string
def test_is_string():
    assert is_string('foo') == True
    assert is_string(b'foo') == False
test_is_string()



# Generated at 2022-06-24 02:20:45.037435
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334')
    assert not is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?')


# Generated at 2022-06-24 02:20:52.774560
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('0-306-40615-2') # returns true
    assert is_isbn_13('0-394-41320-1') # returns true
    assert is_isbn_13('0-51-56908-5') # returns true
    assert is_isbn_13('0-74-75300-3') # returns true
    assert is_isbn_13('0-79-232022-0') # returns true
    assert is_isbn_13('0-80-442957-8') # returns true
    assert is_isbn_13('0-82-302343-5') # returns true
    assert is_isbn_13('0-85-452894-0') # returns true

# Generated at 2022-06-24 02:20:56.471555
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com')
    assert is_url('http://mysite.com')
    assert is_url('http://mysite.com/file.html')
    assert not is_url('http://mysite')
    assert not is_url('www.mysite.com')
    assert not is_url('.mysite.com')
    assert not is_url('http://')



# Generated at 2022-06-24 02:21:04.781691
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    checker = __ISBNChecker('978-0-306-40615-7')
    assert checker.input_string == '978-0-306-40615-7'

    checker = __ISBNChecker('978-0-306-40615-7', normalize=False)
    assert checker.input_string == '978-0-306-40615-7'

# PUBLIC API

# TODO: implement the function

# Generated at 2022-06-24 02:21:12.977505
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('another-email@the-provider.com')
    assert is_email('me@subdomain.provider.com')
    assert is_email('me.@subdomain.provider.com')
    assert is_email('me@subdomain.provider.co.uk')
    assert is_email('me@subdomain.provider.co.uk.x')
    assert is_email('me@subdomain.provider.co.uk.x.y')
    assert is_email('me@subdomain.provider.co.uk.x.y.z')
    assert is_email('me@subdomain.provider.co.uk.x.y.z.a')

# Generated at 2022-06-24 02:21:14.818561
# Unit test for function words_count
def test_words_count():
    assert words_count('hello world') == 2
    assert words_count('one,two,three.stop') == 4
    assert words_count('! @ # % ... []') == 0
    assert words_count('a') == 1
    assert words_count(None) == 0
    assert words_count('') == 0



# Generated at 2022-06-24 02:21:25.408814
# Unit test for function words_count
def test_words_count():
    assert words_count('hello world') == 2
    assert words_count('one,two,three.stop') == 4
    assert words_count('ice -- cream') == 3
    assert words_count('1 2 3') == 3
    assert words_count('it\'s my birthday!!!') == 2
    assert words_count('it.s my flower!!') == 2
    assert words_count('! @ # % ... []') == 0
    assert words_count(' a ') == 1  # count also leading/trailing spaces
    assert words_count('a b') == 2  # count also single chars
# Test
test_words_count()
 
# --------------------------------|
#     String encoding functions   |
# --------------------------------|


# Generated at 2022-06-24 02:21:31.138314
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert(is_ip_v4('255.200.100.75'))
    assert(not is_ip_v4('nope'))
    assert(not is_ip_v4('255.200.100.999'))


# Generated at 2022-06-24 02:21:33.706191
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title') # returns true

# Generated at 2022-06-24 02:21:37.491448
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4("123.300.100.75") == False
    assert is_ip_v4("255.200.100.75") == True
    assert is_ip_v4("255.200.100.999") == False
    assert is_ip_v4("nope") == False


# Generated at 2022-06-24 02:21:41.841728
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string(None) == False
    assert is_full_string('') == False
    assert is_full_string(' ') == False
    assert is_full_string('hello') == True


# Generated at 2022-06-24 02:21:47.922964
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('dermatoglyphics') == True
    assert is_isogram('isogram') == True
    assert is_isogram('moose') == False
    assert is_isogram('isIsogram') == False
    assert is_isogram('') == True
test_is_isogram()



# Generated at 2022-06-24 02:21:52.550779
# Unit test for function is_string
def test_is_string():
    assert is_string('foo') is True
    assert is_string(b'foo') is False
    assert is_string('') is True
    assert is_string(None) is False
    assert is_string(6.0) is False
    assert is_string(6) is False
    assert is_string(True) is False
    assert is_string('sdfsdfsdfsdfsdfsdf') is True


# Generated at 2022-06-24 02:21:55.181345
# Unit test for function is_string
def test_is_string():
    assert is_string('foo') == True
    assert is_string(b'foo') == False


# Generated at 2022-06-24 02:22:01.429183
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    checker = __ISBNChecker('978-85-352-6435-2')
    if not(checker.input_string == '9788535264322'):
        raise RuntimeError('Incorrect constructor of class __ISBNChecker')

test___ISBNChecker()


# PUBLIC API



# Generated at 2022-06-24 02:22:08.984900
# Unit test for function is_email
def test_is_email():
    assert is_email('maria.diaz@gmail.com')
    assert is_email('maria.diaz@hotmail.com')
    assert is_email('maria.diaz@aol.com')
    assert is_email('maria.diaz@outlook.com')
    assert is_email('maria.diaz@icloud.com')
    assert is_email('maria.diaz@yahoo.com')
    assert is_email('maria.diaz@me.com')
    assert is_email('maria.diaz@protonmail.com')
    assert is_email('maria.diaz@protonmail.ch')
    assert is_email('maria.diaz@protonmail.com')
    assert is_email('maria.diaz@tutanota.de')

# Generated at 2022-06-24 02:22:13.391111
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75')
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334')
    assert not is_ip('1.2.3')
test_is_ip()


# Generated at 2022-06-24 02:22:23.250645
# Unit test for function words_count
def test_words_count():
    assert words_count('hello world') == 2
    assert words_count('one,two,three.stop') == 4
    assert words_count('! @ # % ... []') == 0
    assert words_count('Hello World') == 2
    assert words_count('Hello,World!') == 2
    assert words_count(' Hello,World!') == 2
    assert words_count('Hello,World! ') == 2
    assert words_count('Hello ,World! ') == 3
    assert words_count('Hello, World! ') == 2
    assert words_count(' Hello ,World ! ') == 3
    assert words_count('one,two,three.stop') == 4
    assert words_count('one,two, three.stop') == 4
    assert words_count('one,two,three :stop') == 3
    assert words

# Generated at 2022-06-24 02:22:26.455598
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string(None) == False # test null value
    assert is_full_string('') == False # test empty string
    assert is_full_string(' ') == False # test blank string
    assert is_full_string('hello') == True # test non empty string


# Generated at 2022-06-24 02:22:35.182119
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-0-306-40615-7').is_isbn_13()
    assert __ISBNChecker('978-0-306-40615-8').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-9').is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-7', normalize=False).is_isbn_13() is False
    assert __ISBNChecker('978-0-306-40615-7', normalize=True).is_isbn_13() is True
    assert __ISBNChecker('9780306406157', normalize=True).is_isbn_13() is True

# Generated at 2022-06-24 02:22:38.434792
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('42.0')
    assert not is_decimal('42')

# Generated at 2022-06-24 02:22:43.606213
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True, "Testcase failed"
test_is_json()


# Generated at 2022-06-24 02:22:50.042253
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('madam') == True
    assert is_palindrome('Madam') == False
    assert is_palindrome('Madam', ignore_case=True) == True
    assert is_palindrome('ROTFL') == False
    assert is_palindrome('i topi non avevano nipoti') == False
    assert is_palindrome('i topi non avevano nipoti', ignore_spaces=True) == True
    assert is_palindrome('') == False
    assert is_palindrome(None) == False
    assert is_palindrome(1) == False



# Generated at 2022-06-24 02:22:53.662538
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('0881848492')
    assert not is_isbn_10('1893762154532')
    assert not is_isbn_10('1893762154532')
    assert is_isbn_10('89-7141-652-2')
    assert not is_isbn_10('89-7141-652-2', normalize=False)


# Generated at 2022-06-24 02:22:56.968096
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip_v6('2001:db8:z:0000:0000:8a2e:370:7334') == False


# Generated at 2022-06-24 02:23:07.223777
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram("")
    assert is_isogram("DERMATOGLYPHICS")
    assert is_isogram("Dermatoglyphics")
    assert is_isogram("isogram")
    assert not is_isogram("moose")
    assert not is_isogram("isIsogram")
    assert not is_isogram("aba")
    assert not is_isogram("moOse")
    assert not is_isogram("thumbscrewjapingly")
    assert not is_isogram("thumbscrew-japingly")
    assert not is_isogram("Hjelmqvist-Gryb-Zock-Pfund-Wax")
    assert not is_isogram("Heizölrückstoßabdämpfung")

# Generated at 2022-06-24 02:23:09.099041
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}')
    assert is_json('[1, 2, 3]')
    assert not is_json('{nope}')


# Generated at 2022-06-24 02:23:16.331052
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert not is_email('@gmail.com')
    assert is_email('my.email.')
    assert not is_email('my..email@gmail.com')
    assert not is_email('my.email.gmail@gmail.com')
    assert is_email('"very.(),:;<>[]\".VERY.\"very@\\ \"very\".unusual"@gmail.com')
    assert is_email('" "@gmail.com')
    assert is_email('"test\\\\blah"@example.com')
    assert is_email('"test\blah"@example.com')
    assert is_email('example@com')
    assert not is_email('just"not"right@gmail.com')

# Generated at 2022-06-24 02:23:17.819994
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}')
    assert is_json('[1, 2, 3]')
    assert not is_json('{nope}')

test_is_json()



# Generated at 2022-06-24 02:23:19.398353
# Unit test for function contains_html
def test_contains_html():
    assert contains_html("<html><head></head><body><p>Hello</p></body></html>")
    assert contains_html("<html></html>")
    #assert contains_html("Hello <i>world!</i>")


# Generated at 2022-06-24 02:23:23.040326
# Unit test for function is_string
def test_is_string():
    assert is_string('foobar'), 'Unit test for function is_string failed'
    assert not is_string(b'foobar'), 'Unit test for function is_string failed'
    assert not is_string(1), 'Unit test for function is_string failed'



# Generated at 2022-06-24 02:23:27.243687
# Unit test for function is_isbn
def test_is_isbn():
    '''
    This unit test is designed to test the is_isbn function in the string_check.py file.
    '''
    assert is_isbn_13('9780312498580') == True
    assert is_isbn_10('1506715214') == True
    assert is_isbn('9780312498580') == True
    assert is_isbn('1506715214') == True
    assert is_isbn_13('9780312498580', normalize=False) == False
    assert is_isbn_10('1506715214', normalize=False) == False
    assert is_isbn('9780312498580', normalize=False) == False
    assert is_isbn('1506715214', normalize=False) == False


# Generated at 2022-06-24 02:23:29.583404
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('joe_bloggs@bloggs.com') == True
    


# Generated at 2022-06-24 02:23:32.040749
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('foo_bar_baz') == True
    assert is_snake_case('foo') == False



# Generated at 2022-06-24 02:23:37.172101
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert not is_isbn_10('')
    assert not is_isbn_10('not a number')
    assert not is_isbn_10('15067152157')
    assert is_isbn_10('1506715214')
    assert is_isbn_10('150-6715214')
    assert not is_isbn_10('150-6715214', normalize=False)
    assert is_isbn_10('978-3-16-148410')



# Generated at 2022-06-24 02:23:39.026937
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75')  # returns true
    assert not is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334')  # returns true
    assert not is_ip('1.2.3')  # returns false



# Generated at 2022-06-24 02:23:41.367808
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('my string is <strong>bold</strong>') is True
    assert contains_html('my string is not bold') is False
#
#

# Generated at 2022-06-24 02:23:43.650089
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog') == True
    assert is_pangram('hello world') == False
test_is_pangram()



# Generated at 2022-06-24 02:23:47.542373
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-24 02:23:51.738632
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string('foo') == True
    assert is_full_string('') == False
    assert is_full_string(' ') == False
    assert is_full_string('do\n') == True



# Generated at 2022-06-24 02:23:56.826400
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('LOL')
    assert is_palindrome('Lol', ignore_case=True)
    assert is_palindrome('i topi non avevano nipoti', ignore_spaces=True)
    assert not is_palindrome('Lol')
    assert not is_palindrome('ROTFL')
    assert not is_palindrome('i topi non avevano nipoti')



# Generated at 2022-06-24 02:23:59.117092
# Unit test for function is_credit_card
def test_is_credit_card():
    card = '4242424242424242'
    assert is_credit_card(card, 'VISA') is True

# Generated at 2022-06-24 02:24:02.666228
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75')
    assert not is_ip_v4('nope')
    assert not is_ip_v4('255.200.100.999')


# Generated at 2022-06-24 02:24:10.518240
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('foo_bar_baz') == True
    assert is_snake_case('foo-bar-baz') == True
    assert is_snake_case('thequickbrownfoxjumpsoverthelazydog') == True
    assert is_snake_case('foo') == False
    assert is_snake_case('fooBarBaz') == False
    assert is_snake_case('FooBarBaz') == False
    assert is_snake_case('fooBARBaz') == False
    assert is_snake_case('') == False


# Generated at 2022-06-24 02:24:15.842347
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string(None) == False
    assert is_full_string('') == False
    assert is_full_string(' ') == False
    assert is_full_string('hello') == True
# Test the function is_full_string
test_is_full_string()



# Generated at 2022-06-24 02:24:25.385711
# Unit test for function contains_html
def test_contains_html():
    assert contains_html("<p>he<strong>llo</strong></p>") == True
    assert contains_html("hello") == False
    assert contains_html("<&>") == True
    assert contains_html("<h1>hello</h1>") == True
    assert contains_html("<!>") == True
    assert contains_html("<a >") == True
    assert contains_html("<a>") == True
    assert contains_html("<html >") == True
    assert contains_html("<html>") == True
    assert contains_html("<p >") == True
    assert contains_html("<p>") == True
    
test_contains_html()    

# Generated at 2022-06-24 02:24:31.613722
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn("9780312498580") == True
    assert is_isbn("1506715214") == True
    assert is_isbn("150-6715214") == True
    assert is_isbn("978-0312498580") == True
    assert is_isbn("150-6715214", normalize=False) == False
    assert is_isbn("978-0312498580", normalize=False) == False
    return "is_isbn() successful test"
print(test_is_isbn())


# Generated at 2022-06-24 02:24:38.347569
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker("1234").is_isbn_10() == False
    assert __ISBNChecker("123456789X").is_isbn_10() == True
    assert __ISBNChecker("1234567890").is_isbn_10() == True
    assert __ISBNChecker("1234567891").is_isbn_10() == False


# Generated at 2022-06-24 02:24:46.443330
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('MyString') == True
    assert is_camel_case('myString') == True
    assert is_camel_case('mystring') == False
    assert is_camel_case('Mystr1ng') == True
    assert is_camel_case('Mystr_ing') == False
    assert is_camel_case('myString1') == True
    assert is_camel_case('myString1_') == False

test_is_camel_case()



# Generated at 2022-06-24 02:24:52.246637
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('foo_bar_baz') # returns true
    assert is_snake_case('foo') # returns false
    assert is_snake_case('foo_bar_baz', separator='_') # returns true
    assert is_snake_case('foo', separator='_') # returns false
    assert is_snake_case('foo-bar-baz', separator='-') # returns true
    assert is_snake_case('foo', separator='-') # returns false


# Generated at 2022-06-24 02:24:55.157865
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('foo_bar_baz', "_")
    assert is_snake_case('foo') is False
    assert is_snake_case('foo-bar-baz', "-")
    assert is_snake_case('foo', "-") is False



# Generated at 2022-06-24 02:25:04.152892
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('0-486-27557-4') == True
    assert is_isbn_10('0-486-27557') == False
    assert is_isbn_10('0-486-27557-A') == False
    assert is_isbn_10('0-486-27557-4', normalize=False) == True
    assert is_isbn_10('0-486-275574', normalize=False) == False


# Generated at 2022-06-24 02:25:14.967850
# Unit test for function is_url
def test_is_url():
    assert not is_url('')
    assert not is_url(None)
    assert not is_url('mysite')
    assert not is_url('/mysite.com')
    assert not is_url('.mysite.com')
    assert not is_url('http://')               # subdomain cannot be empty
    assert not is_url('ftp://mysite')          # domain cannot be empty
    assert not is_url('https://mysite.')       # domain must have at least one character
    assert not is_url('http://www.mysite.')    # domain must have at least one character
    assert not is_url('ftp://www.mysite')      # domain must have at least one character
    assert not is_url('https://.com')          # subdomain cannot be empty

# Generated at 2022-06-24 02:25:23.336606
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('dermatoglyphics') == True
    assert is_isogram('Aba') == False
    assert is_isogram('Alphabet') == False
    assert is_isogram('thumbscrew-japingly') == True
    assert is_isogram('Hjelmqvist-Gryb-Zock-Pfund-Wax') == True
    assert is_isogram('Heizölrückstoßabdämpfung') == True
    assert is_isogram('the quick brown fox') == False
    assert is_isogram('Emily Jung Schwartzkopf') == True
    assert is_isogram('éléphant') == False

print('tests for is_isogram passed')


# Generated at 2022-06-24 02:25:29.961139
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('42.0') # returns true
    assert is_decimal('42') # returns false

test_is_decimal()



# Generated at 2022-06-24 02:25:36.232243
# Unit test for function words_count
def test_words_count():
    assert words_count('Hello world') == 2
    assert words_count('one,two,three.stop') == 4

# Testing module
if __name__ == '__main__':
    test_words_count()
    print('All tests passed!')

# EOF

# Generated at 2022-06-24 02:25:43.941959
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    valid_inputs = [
        '978-3-16-148410-0',
        '9783161484100',
        '0-321-99278-4',
        '0321992784',
    ]

    invalid_inputs = [
        '978-3-16-148410-0-',
        '21318167923-',
        '978-3-16-148410',
        '03219927841',
        '0-321-99278-5',
        '03219927845',
        '',
        None,
    ]

    for valid_input in valid_inputs:
        try:
            __ISBNChecker(valid_input)
        except:
            raise Exception('Valid input: "{}"'.format(valid_input))


# Generated at 2022-06-24 02:25:45.747357
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title') == True
    assert is_slug('My blog post title') == False
test_is_slug()


# Generated at 2022-06-24 02:25:47.560522
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('hello world') == False
    assert is_pangram('The quick brown fox jumps over the lazy dog') == True
test_is_pangram()


# Generated at 2022-06-24 02:25:50.343325
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?') == False


# Generated at 2022-06-24 02:25:52.574495
# Unit test for function is_string
def test_is_string():
    assert is_string('foo') == True
    assert is_string(b'foo') == False
test_is_string()



# Generated at 2022-06-24 02:25:58.276221
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker("030640615X").is_isbn_13() == True
    assert __ISBNChecker("978-1933988177").is_isbn_13() == True
    assert __ISBNChecker("978-1933988173").is_isbn_13() == True

    # wrong input
    assert __ISBNChecker("123456789").is_isbn_13() == False
    assert __ISBNChecker("foo").is_isbn_13() == False
    assert __ISBNChecker("").is_isbn_13() == False



# Generated at 2022-06-24 02:26:08.586380
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    assert __ISBNChecker('123456789X').input_string == '123456789X'
    assert __ISBNChecker('123456789X', False).input_string == '123456789X'
    assert __ISBNChecker('123-456-789-X').input_string == '123456789X'
    assert __ISBNChecker('123-456-789-X', False).input_string == '123-456-789-X'

    assert __ISBNChecker('978-2-1234-5680-3').input_string == '9782123456803'
    assert __ISBNChecker('978-2-1234-5680-3', False).input_string == '9782123456803'

    assert not __ISBNChecker(123).input_string

# Unit test

# Generated at 2022-06-24 02:26:13.110888
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334')
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7300')
    assert is_ip_v6('2001:0db8:85a3:0000:0000:8a2e:0370:7334')
    assert is_ip_v6('2001:0db8:85a3:000::8a2e:0370:7334')
    assert is_ip_v6('2001:db8:85a3::8a2e:370:7334')
    assert is_ip_v6('::')
    assert is_ip_v6('::1')

# Generated at 2022-06-24 02:26:17.689188
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('This text is normal') == False
    assert contains_html('This text contains <p>html</p>') == True
    assert contains_html('This text contains <p>html</p') == False
    assert contains_html('This text contains html<span>') == False



# Generated at 2022-06-24 02:26:20.258007
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') == True
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf') == False
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True) == True



# Generated at 2022-06-24 02:26:27.956983
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid(None) is False
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') is True
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf') is False
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True) is True



# Generated at 2022-06-24 02:26:31.071981
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580') == True
    assert is_isbn_13('978-0312498580') == True
    assert is_isbn_13('978-0312498580', normalize= False) == False

    
    

# Generated at 2022-06-24 02:26:35.766730
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('my string is <strong>bold</strong>') 
    assert not contains_html('my string is not bold')       
test_contains_html()



# Generated at 2022-06-24 02:26:43.042227
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    # Setup
    isbn_checker = __ISBNChecker("1234")

    # Exercise
    result_1 = isbn_checker.is_isbn_10()
    result_2 = isbn_checker.is_isbn_13()

    # Verify
    assert result_1 is False
    assert result_2 is False

# Generated at 2022-06-24 02:26:47.676836
# Unit test for function is_string
def test_is_string():
    assert is_string('foo') is True
    assert is_string(b'foo') is False
    assert is_string([]) is False
    assert is_string(('foo',)) is False
    assert is_string({}) is False
    assert is_string({'foo': 'bar'}) is False
    assert is_string(None) is False
    assert is_string(10) is False
    assert is_string(10.5) is False



# Generated at 2022-06-24 02:26:58.160728
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('') is False
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334') is True
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?') is False
    assert is_ip_v6('2001:db8:85a3:000x:0000:8a2e:370:7334') is False
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334:') is False
    assert is_ip_v6('2001:db8:85a3:0x00:0x00:8a2e:370:7334') is False
    assert is_ip

# Generated at 2022-06-24 02:27:00.804963
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    check = __ISBNChecker("978-0-306-40615-7")
    assert check.is_isbn_13() is True



# Generated at 2022-06-24 02:27:06.577308
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string(None) is False
    assert is_full_string('') is False
    assert is_full_string(' ') is False
    assert is_full_string('hello') is True
test_is_full_string()



# Generated at 2022-06-24 02:27:12.124966
# Unit test for function is_number
def test_is_number():
    assert is_number('42')
    assert is_number('19.99')
    assert is_number('-9.12')
    assert is_number('1e3')
    try:
        is_number('1 2 3')
        assert False
    except InvalidInputError:
        assert True
    
    

# Generated at 2022-06-24 02:27:20.736920
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert not is_email(None)
    assert not is_email(' ')
    assert not is_email('abc')
    assert not is_email('my.email@the-provider.com.so')
    assert not is_email('my.email@the-provider.coma')
    assert not is_email('@the-provider.com')
    assert is_email('"foo@bar"@example.com')
    assert is_email('foo"baz"@example.com')
    assert not is_email('foo"abc.def"@example.com')
    assert not is_email('"my.email"@the-provider.com')

# Generated at 2022-06-24 02:27:26.058280
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42')
    assert is_integer('3.14') == False
# end test_is_integer



# Generated at 2022-06-24 02:27:33.891006
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('MyString') # returns false
    assert is_snake_case('mystring') # returns false
    assert is_snake_case('my-string') # returns true
    assert is_snake_case('my_string') # returns true
    assert is_snake_case('my-string_') # returns false
    assert is_snake_case('MyString_', separator='-') # returns true
    assert is_snake_case('my-string2', separator='-') # returns true
    assert not is_snake_case('-my-string') # returns false
    assert not is_snake_case('2my-string') # returns false

# Generated at 2022-06-24 02:27:35.613163
# Unit test for function is_string
def test_is_string():
    assert is_string('foo') # should return true
    assert not is_string(b'foo') # should return false


# Generated at 2022-06-24 02:27:45.147001
# Unit test for function is_snake_case
def test_is_snake_case():
    assert (is_snake_case("data_people"))
    assert (is_snake_case("data-people"))
    assert (not is_snake_case("datapeople"))
    assert (not is_snake_case("datApeople"))
    assert (not is_snake_case("dat@people"))
    assert (not is_snake_case(""))
    assert (not is_snake_case("_"))
    assert (not is_snake_case("__"))
    assert (not is_snake_case("data_"))
    assert (not is_snake_case("_data"))
    assert (not is_snake_case("data$"))
    assert (not is_snake_case("data-people"))
    print("Pass test_is_snake_case")
    
    

# Generated at 2022-06-24 02:27:48.171380
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('42.0') == True
    assert is_decimal('42') == False


# Generated at 2022-06-24 02:27:50.403290
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog') == True
    assert is_pangram('hello world') == False
test_is_pangram()


# Generated at 2022-06-24 02:27:59.815052
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome("otto")
    assert is_palindrome("Otto")
    assert is_palindrome("Otto", ignore_case=True)
    assert is_palindrome("Rotfl", ignore_case=True)
    assert not is_palindrome("ROTFL")
    assert is_palindrome("I topi non avevano nipoti", ignore_spaces=True)
    assert not is_palindrome("I topi non avevano nipoti", ignore_spaces=False)
    assert is_palindrome("Was it a car or a cat I saw?")
    assert is_palindrome("Was it a car or a cat I saw?", ignore_case=True, ignore_spaces=True)

# Generated at 2022-06-24 02:28:11.748084
# Unit test for function is_credit_card

# Generated at 2022-06-24 02:28:16.508949
# Unit test for function is_isbn
def test_is_isbn():

    assert (is_isbn('1506715214') == True)
    assert (is_isbn('150-6715214') == True)
    assert (is_isbn('150-6715214', normalize=False) == False)
    assert (is_isbn('9780312498580') == True)
    assert (is_isbn('978-0312498580') == True)
    assert (is_isbn('978-0312498580', normalize=False) == False)
 

# Generated at 2022-06-24 02:28:24.481564
# Unit test for function is_slug
def test_is_slug():
    sep = os.getenv("ARMIESAPI_SLUGIFY_SEPARATOR", "-")
    assert is_slug("my-blog-post-title") == True
    assert is_slug("My blog post title", sep) == False
    assert is_slug("My blog post title") == False
    assert is_slug("") == False


# Generated at 2022-06-24 02:28:31.023845
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False



# Generated at 2022-06-24 02:28:37.677547
# Unit test for function is_email
def test_is_email():
    assert is_email('email@example.com') == True
    assert is_email('firstname.lastname@example.com') == True
    assert is_email('email@subdomain.example.com') == True
    assert is_email('firstname+lastname@example.com') == True
    assert is_email('email@123.123.123.123') == True
    assert is_email('1234567890@example.com') == True
    assert is_email('email@example-one.com') == True
    assert is_email('_______@example.com') == True
    assert is_email('email@example.name') == True
    assert is_email('email@example.museum') == True
    assert is_email('email@example.co.jp') == True

# Generated at 2022-06-24 02:28:41.815632
# Unit test for function is_url
def test_is_url():
    assert is_url(input_string = "http://www.mysite.com") == True
    assert is_url(input_string = "https://mysite.com") == True
    assert is_url(input_string = ".mysite.com") == False



# Generated at 2022-06-24 02:28:43.589179
# Unit test for function is_integer
def test_is_integer():
    assert is_integer("1") == True
    assert is_integer("-1") == True
    assert is_integer("1.0") == False
    assert is_integer("-1.0") == False

test_is_integer()



# Generated at 2022-06-24 02:28:52.250880
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('') == True
    assert is_isogram('isogram') == True
    assert is_isogram('eleven') == False
    assert is_isogram('subdermatoglyphic') == True
    assert is_isogram('Alphabet') == False
    assert is_isogram('thumbscrew-japingly') == True
    assert is_isogram('six-year-old') == True
    assert is_isogram('Emily Jung Schwartzkopf') == True
    assert is_isogram('accentor') == False
    assert is_isogram('angola') == False
    print('All tests passed!')
#test_is_isogram()


# Generated at 2022-06-24 02:28:59.613749
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('Laser') == True
    assert is_isogram('GP') == True
    assert is_isogram('GP111') == False
    assert is_isogram('GP!') == False
    assert is_isogram('') == True
    assert is_isogram(None) == False
    assert is_isogram(3.14) == False

# Generated at 2022-06-24 02:29:02.459987
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('123')
    assert not is_integer('123.0')
    assert not is_integer('foobar')
    assert not is_integer('-123')
    assert is_integer('2^2')



# Generated at 2022-06-24 02:29:03.976201
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title') == True
    assert is_slug('My blog post title') == False

# Generated at 2022-06-24 02:29:14.262958
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    obj = __ISBNChecker('0393048216')
    assert obj.is_isbn_10() == True

    obj = __ISBNChecker('0393048210')
    assert obj.is_isbn_10() == True

    obj = __ISBNChecker('039304821x')
    assert obj.is_isbn_10() == False

    obj = __ISBNChecker('0393048219')
    assert obj.is_isbn_10() == False

    obj = __ISBNChecker('0393048212')
    assert obj.is_isbn_10() == True

# Generated at 2022-06-24 02:29:16.099050
# Unit test for function words_count
def test_words_count():
    assert words_count('hello world') == 2
    assert words_count('one,two,three.stop') == 4

# Generated at 2022-06-24 02:29:18.302595
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10("9780470059029") == False


# Generated at 2022-06-24 02:29:21.188196
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    isbn = '01234567890'
    isbn_checker = __ISBNChecker(isbn, normalize=False)
    assert isbn_checker.input_string == isbn
    assert isbn_checker.is_isbn_10() == True
    assert isbn_checker.is_isbn_13() == False


# Generated at 2022-06-24 02:29:31.759178
# Unit test for function words_count
def test_words_count():
    assert words_count("a b c d") == 4
    assert words_count("one two three four") == 4
    assert words_count("one, two, three, four") == 4
    assert words_count("one , two , three , four") == 4
    assert words_count("one , two, three , four") == 4
    assert words_count("one,two,three,four") == 4
    assert words_count("one , two") == 2
    assert words_count("one,two") == 2
    assert words_count("one, two") == 2
    assert words_count("one,two three") == 3
    assert words_count("one,two,three four") == 4
    assert words_count("one,two,three, four") == 4
    assert words_count("one,two,theree , four") == 4

# Generated at 2022-06-24 02:29:37.910164
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') == True
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', True) == True
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', False) == False

# Generated at 2022-06-24 02:29:42.579064
# Unit test for function is_integer
def test_is_integer():
    assert is_integer(-1)
    assert is_integer('9')
    assert is_integer('-42')
    assert is_integer('-42.0')
    assert is_integer('0.0')
    assert is_integer('')
    assert is_integer(0)
    assert is_integer(1)

