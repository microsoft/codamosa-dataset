

# Generated at 2022-06-24 02:19:49.414176
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    _isbn = __ISBNChecker('978-0-306-40615-7')
    assert _isbn.input_string == '9780306406157'
    assert _isbn.is_isbn_13()

    _isbn = __ISBNChecker('978-0-306-40615-7', normalize=False)
    assert _isbn.input_string == '978-0-306-40615-7'
    assert not _isbn.is_isbn_13()

    _isbn = __ISBNChecker('0-306-40615-2')
    assert _isbn.input_string == '0306406152'
    assert _isbn.is_isbn_10()

    _isbn = __ISBNChecker('0-306-40615-2', normalize=False)


# Generated at 2022-06-24 02:19:53.533437
# Unit test for function words_count
def test_words_count():
    assert words_count('This is a simple sentence') == 5, 'words_count must find all words into a sentence'
    assert words_count('one,two,three.stop') == 4, 'words_count must treat commas and dots as word separators'
    assert words_count('! @ # % ...') == 0, 'words_count must ignore non-alnum chars'
test_words_count()


# Generated at 2022-06-24 02:20:02.136441
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    assert __ISBNChecker('978020137962').input_string == '978020137962'
    assert __ISBNChecker('-978020137962').input_string == '978020137962'
    assert __ISBNChecker('--978020137962').input_string == '978020137962'
    assert __ISBNChecker('-978020137962-8').input_string == '9780201379628'
    assert __ISBNChecker('-978020137962--').input_string == '978020137962'
    assert __ISBNChecker('9780201379-62').input_string == '978020137962'

# Generated at 2022-06-24 02:20:14.120824
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    # normalize
    assert __ISBNChecker('978-0-306-40615-7').input_string == '9780306406157'
    assert __ISBNChecker('9780306406157').input_string == '9780306406157'

    # invalid input
    assert not __ISBNChecker('').is_isbn_13()
    assert not __ISBNChecker(None).is_isbn_13()
    assert not __ISBNChecker(True).is_isbn_13()
    assert not __ISBNChecker(False).is_isbn_13()
    assert not __ISBNChecker(1).is_isbn_13()
    assert not __ISBNChecker(1.0).is_isbn_13()

    # is_isbn_13
    assert __ISBNChecker

# Generated at 2022-06-24 02:20:26.048559
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13("978-0312498580") == True
    assert is_isbn_13("978-0312498580", normalize=False) == False
    assert is_isbn_13("0340336418") == False
    assert is_isbn_13("0340336418", normalize=False) == False
    assert is_isbn_13("9780340336410") == True
    assert is_isbn_13("9780340336410", normalize=False) == True
    assert is_isbn_13("978034033641") == False
    assert is_isbn_13("978034033641", normalize=False) == False
    assert is_isbn_13("978034033641") == False

# Generated at 2022-06-24 02:20:29.776523
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf')
    assert not is_uuid('6f8aa2f9686c4ac387665712354a04cf')
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True)


# Generated at 2022-06-24 02:20:32.399283
# Unit test for function is_string
def test_is_string():
    assert is_string('foo') == True
    assert is_string(b'foo') == False
    assert is_string(12) == False
    assert is_string(12.2) == False



# Generated at 2022-06-24 02:20:36.928403
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('LOL') is True
    assert is_palindrome('1LOL1') is True
    assert is_palindrome('Lol') is False
    assert is_palindrome('Lol', ignore_case=True) is True
    assert is_palindrome('ROTFL') is False
    assert is_palindrome('1') is True
    assert is_palindrome('A man, a plan, a canal, Panama.', ignore_spaces=True, ignore_case=True) is True
    assert is_palindrome('A man, a plan, a canal, Panama.') is False
    assert is_palindrome('1LOL1', ignore_spaces=True) is True

test_is_palindrome()



# Generated at 2022-06-24 02:20:42.724974
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('moo') == False
    assert is_isogram('dermatoglyphics') == True
    assert is_isogram('moose') == False
    assert is_isogram('aba') == False
    assert is_isogram('isogram') == True

# Generated at 2022-06-24 02:20:43.969987
# Unit test for function is_json
def test_is_json():
    is_json('{"name": "Peter"}') # returns true
    is_json('[1, 2, 3]') # returns true
    is_json('{nope}') # returns false


# Generated at 2022-06-24 02:20:48.126119
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('42.0') == True
    assert is_decimal('42') == False
test_is_decimal()


# Generated at 2022-06-24 02:20:50.111372
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') # returns true
    assert is_json('[1, 2, 3]') # returns true
    assert not is_json('{nope}') # returns false


# Generated at 2022-06-24 02:21:00.749948
# Unit test for function is_ip
def test_is_ip():
    # Test cases
    tests = [('12345','False'),('2001:db8:85a3:0000:0000:8a2e:370:7334','True'),
             ('255.200.100.75','True'),('255.200.100.999','False'),
            ('2001:db8:85a3:0000:0000:8a2e:370:7334','True'),
            ('2001:db8:85a3:0000:0000:8a2e:370:?','False')]
    for elm,ans in tests:
        test = is_ip(elm)
        if test != ans:
            print('Error: is_ip({}) should be {}. Your function returns {}.'.format(elm, ans, test))

# Generated at 2022-06-24 02:21:07.111615
# Unit test for function is_number
def test_is_number():
    assert is_number('42') == True
    assert is_number('19.99') == True
    assert is_number('-9.12') == True
    assert is_number('1e3') == True
    assert is_number('1 2 3') == False


# Generated at 2022-06-24 02:21:09.769978
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214')
    assert is_isbn_10('150-6715214')
    assert is_isbn_10('150-6715214', normalize=False) is False

# Generated at 2022-06-24 02:21:12.715425
# Unit test for function is_snake_case
def test_is_snake_case():
    assert not is_snake_case('MyString')
    assert is_snake_case('my_string')
    assert is_snake_case('my_string_with_numbers1')
    assert not is_snake_case('1_string')
    assert not is_snake_case('-string_')
    assert is_snake_case('-string_', separator='-')
    assert not is_snake_case('my-string', separator='_')
    assert is_snake_case('my-string', separator='-')



# Generated at 2022-06-24 02:21:14.373339
# Unit test for function is_isbn_13
def test_is_isbn_13():
    s = '978-0312498580'
    if is_isbn_13(s):
        print("13-digit ISBN: ", s)

# Generated at 2022-06-24 02:21:16.692592
# Unit test for function is_isogram
def test_is_isogram():
    # Arrange
    input_string1 = 'dermatoglyphics'
    # Act
    result1 = is_isogram(input_string1)
    # Assert
    assert result1 == True

# Generated at 2022-06-24 02:21:26.424013
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    assert not __ISBNChecker('').is_isbn_13()
    assert __ISBNChecker('978-0-306-40615-7').is_isbn_13()
    assert __ISBNChecker('978-0-306-40615-7', False).is_isbn_13()
    assert not __ISBNChecker('978-0-306-40615-7').is_isbn_10()
    assert not __ISBNChecker('978-0-306-40615-7', False).is_isbn_10()
    assert __ISBNChecker('0-306-40615-2').is_isbn_10()
    assert __ISBNChecker('0-306-40615-2', False).is_isbn_10()


# PUBLIC API



# Generated at 2022-06-24 02:21:27.853701
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('MyString') # returns true
    assert not is_camel_case('mystring') # returns false


# Generated at 2022-06-24 02:21:31.674522
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert(is_ip_v4('255.200.100.75') == True)
    assert(is_ip_v4('nope') == False)
    assert(is_ip_v4('255.200.100.999') == False)


# Generated at 2022-06-24 02:21:38.565737
# Unit test for function is_slug
def test_is_slug():
    lst = [
        ('my-blog-post-title', True),
        ('My blog post title', False),
        ('My-blog-post-title', False),
        ('my_blog_post_title', False),
        ('my__post_title', True),
        ('nothing', True),
        ('', True),
        ('my', True)
    ]

    for item in lst:
        assert is_slug(item[0]) == item[1]
        assert is_slug(item[0], '_') == False


# Generated at 2022-06-24 02:21:46.514943
# Unit test for function words_count
def test_words_count():
    assert words_count('my string test') == 3
    assert words_count('my string, is cool') == 4
    assert words_count('one, two, three. stop.') == 4
    assert words_count('! @ # % ... []') == 0
    assert words_count('foo-bar') == 1
    # assert words_count(None) == 1 # Throws TypeError



# Generated at 2022-06-24 02:21:53.577013
# Unit test for function is_credit_card
def test_is_credit_card():
    assert not is_credit_card('')
    assert not is_credit_card(' ')
    assert not is_credit_card('000')
    assert not is_credit_card('0001')
    assert is_credit_card('4111111111111111', 'VISA')
    assert is_credit_card('4111111111111111')
    assert not is_credit_card('4111111111111111', 'MASTERCARD')
    assert is_credit_card('5555555555554444', 'MASTERCARD')
    assert is_credit_card('5555555555554444')
    assert not is_credit_card('5555555555554444', 'VISA')



# Generated at 2022-06-24 02:21:58.947057
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card("4556193808879017") == True
    assert is_credit_card("4556193808879070", "VISA") == False # Does not match the card type
    assert is_credit_card("4556193808879017", "MASTERCARD") == False # Does not match the card type
    assert is_credit_card("4556193808879017", "AMERICAN_EXPRESS") == False # Does not match the card type
    assert is_credit_card("4556193808879017", "DINERS_CLUB") == False # Does not match the card type
    assert is_credit_card("4556193808879017", "DISCOVER") == False # Does not match the card type

# Generated at 2022-06-24 02:22:00.693038
# Unit test for function is_string
def test_is_string():
    assert is_string('foo') == True
    assert is_string(b'foo') == False


# Generated at 2022-06-24 02:22:05.161212
# Unit test for function words_count
def test_words_count():
    assert words_count('one,two,three.stop') == 4
    assert words_count('one,two,three,stop') == 4
    assert words_count('one two three stop') == 4
    assert words_count('one two three stop.') == 4
    assert words_count('one two three stop. ') == 4
    assert words_count('one two three stop. \n') == 4
    assert words_count('one two three stop. \n\n') == 4
    assert words_count('one two three stop. \n\n ') == 4
    assert words_count('one two three stop. \n \n ') == 4
    assert words_count('one two three stop. \n \n \n') == 4
    assert words_count('one two three stop. \n \n\n') == 4

# Generated at 2022-06-24 02:22:17.363793
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13("1234567890123") == True
    assert is_isbn_13("1234567890123", True) == True
    assert is_isbn_13("1234567890123", False) == True
    assert is_isbn_13("123-456-78901-23") == True
    assert is_isbn_13("123-456-78901-23", True) == True
    assert is_isbn_13("123-456-78901-23", False) == False
    assert is_isbn_13("12345678901") == False
    assert is_isbn_13("12345678901", True) == False
    assert is_isbn_13("12345678901", False) == False
    assert is_isbn_13("") == False


# Generated at 2022-06-24 02:22:23.583276
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    checker = __ISBNChecker('123-456-789-123')
    assert checker.input_string == '123456789123'
    checker = __ISBNChecker('123456789123', normalize=False)
    assert checker.input_string == '123456789123'



# Generated at 2022-06-24 02:22:28.337420
# Unit test for function is_string
def test_is_string():
    assert is_string("foo") == True
    assert is_string(b'foo') == False
    assert is_string("") == True
    assert is_string("1") == True
    assert is_string("red,white,and blue") == True
    assert is_string(" ") == True
    assert is_string("\r") == True
    assert is_string("\r\n") == True
    assert is_string("\t") == True


# Generated at 2022-06-24 02:22:40.128119
# Unit test for function is_ip_v6
def test_is_ip_v6():
        assert is_ip_v6("fe80::208:74ff:fe00:a1f5") == True
        assert is_ip_v6("2001:db8:85a3:0000:0000:8a2e:370:7334")== True
        assert is_ip_v6("2001:db8:85a3:0:0:8a2e:370:7334") == True
        assert is_ip_v6("2001:db8:85a3::8a2e:370:7334") == True
        assert is_ip_v6("2001:0db8:85a3:0000:0000:8a2e:0370:7334") == True
        assert is_ip_v6("fe80::208:74zf:fe00:a1f5") == False
        assert is_

# Generated at 2022-06-24 02:22:46.895425
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0306406152').is_isbn_10()
    assert __ISBNChecker('359821765X').is_isbn_10()
    assert not __ISBNChecker('03064061').is_isbn_10()
    assert not __ISBNChecker('030640615').is_isbn_10()
    assert not __ISBNChecker('0306406153').is_isbn_10()
    assert not __ISBNChecker('030640615X').is_isbn_10()


# Generated at 2022-06-24 02:22:49.444381
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string(None) == False
    assert is_full_string('') == False
    assert is_full_string(' ') == False
    assert is_full_string('hello') == True

# Generated at 2022-06-24 02:23:00.239316
# Unit test for function is_slug
def test_is_slug():
    if is_slug("my-blog-post-title") != True:
        raise Exception("is_slug(input_string) fail test_is_slug(): string_with-separator")
    
    if is_slug("My blog post title") != False:
        raise Exception("is_slug(input_string) fail test_is_slug(): string_with_space")
    
    if is_slug("my_blog_post_title") != False:
        raise Exception("is_slug(input_string) fail test_is_slug(): string_with_underscore")
    
    if is_slug("a") != True:
        raise Exception("is_slug(input_string) fail test_is_slug(): string_length_1")
    

# Generated at 2022-06-24 02:23:01.860039
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}')


# Generated at 2022-06-24 02:23:05.785510
# Unit test for function is_number
def test_is_number():
    assert is_number('42') # true
    assert is_number('19.99') # true
    assert is_number('-9.12') # true
    assert is_number('1e3') # true
    assert not is_number('1 2 3') # false
    assert not is_number('yolo') # false



# Generated at 2022-06-24 02:23:15.894676
# Unit test for function is_email
def test_is_email():

    assert is_email('my.email@the-provider.com')
    assert is_email('my_email@the-provider.com')
    assert is_email('my_email@theprovider.com')
    assert is_email('myemail@theprovider.com')
    assert is_email('myemail@theprovider.net')
    assert is_email('myemail+@theprovider.com')
    assert is_email('myemail+@theprovider.net')
    assert is_email('my.email@theprovider.com')
    assert is_email('my.email@theprovider.net')
    assert is_email('my.email@theprovider.info')

    assert is_email('"myemail"@theprovider.com')

# Generated at 2022-06-24 02:23:24.439348
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    checker = __ISBNChecker('948123451X')
    assert checker.is_isbn_10() == True
    checker = __ISBNChecker('948123451X', False)
    assert checker.is_isbn_10() == True
    checker = __ISBNChecker('948123451')
    assert checker.is_isbn_10() == False
    checker = __ISBNChecker('948123451', False)
    assert checker.is_isbn_10() == False
# Unit tests for method is_isbn_13 of class __ISBNChecker

# Generated at 2022-06-24 02:23:29.969550
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') # True
    assert is_isbn_10('150-6715214') # True
    assert not is_isbn_10('150-6715214', normalize=False) # False
# End unit test

# Generated at 2022-06-24 02:23:34.056285
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog')
    assert is_pangram('The quick brown fox jumps over the lazy frog')
    assert is_pangram('abcdefghijklmnopqrstuvwxyz')
    assert not is_pangram('abcde')
    assert not is_pangram('abcde fghijk')
    assert not is_pangram('The quick brown fox jumps over the dog')
    assert not is_pangram('')
    assert not is_pangram(None)

# Generated at 2022-06-24 02:23:40.227921
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.0.0.0') == True
    assert is_ip('0.0.0.0') == True
    assert is_ip('255.255.255.255') == True
    assert is_ip('255.256.0.0') == False
    assert is_ip('255.255.256.0') == False
    assert is_ip('255.255.255.256') == False
    assert is_ip('2001:db8:85a3:0:0:8a2e:370:7334') == True
    assert is_ip('2001:db8:85a3::8a2e:370:7334') == True
    assert is_ip('2001:db8:85a3::') == True

# Generated at 2022-06-24 02:23:43.796725
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214')==True
    assert is_isbn_10('150-6715214')==True
    assert is_isbn_10('150-6715214', normalize=False)==False


# Generated at 2022-06-24 02:23:46.527705
# Unit test for function is_decimal
def test_is_decimal():
    assert (is_decimal('42.0') == True)
    assert (is_decimal('42') == False)



# Generated at 2022-06-24 02:23:55.540057
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580')
    assert is_isbn_13('978-0312498580')
    assert is_isbn_13('979-1091440647')
    assert is_isbn_13('9791091440647')
    assert is_isbn_13('9791091440647', normalize=False)
    assert not is_isbn_13('978-0312498580', normalize=False)
    assert not is_isbn_13('97910914406477')



# Generated at 2022-06-24 02:23:56.944896
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') == True


# Generated at 2022-06-24 02:24:07.607497
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0-306-40615-2').is_isbn_10()  # ISBN 10
    assert not __ISBNChecker('0-306-40615-2').is_isbn_13()  # ISBN 10
    assert not __ISBNChecker('0-306-40615-2').is_isbn_10()  # ISBN 10
    assert __ISBNChecker('0-306-40615-8').is_isbn_10()  # ISBN 10
    assert not __ISBNChecker('0-306-40615-8').is_isbn_13()  # ISBN 10
    assert not __ISBNChecker('0-306-40615-8').is_isbn_10()  # ISBN 10


# PUBLIC API



# Generated at 2022-06-24 02:24:14.633554
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert is_email('my.email@the.provider.com')
    assert is_email('my.email@the-provider-example.com')
    assert is_email('my.email@the-provider.example.com')
    assert is_email('my.email@the-provider.exampl.com')
    assert is_email('my.email@the-provider.example.co.uk')
    assert is_email('my.email@the-provider.example.co.au')
    assert is_email('my.email@the-provider.example.com.au')
    assert not is_email('my.email.the-provider.example.com.au')
    assert not is_email('@gmail.com')

# Generated at 2022-06-24 02:24:15.457502
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('1506715214')

# Generated at 2022-06-24 02:24:25.707964
# Unit test for function is_isbn

# Generated at 2022-06-24 02:24:29.779323
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string(None) == False
    assert is_full_string('') == False
    assert is_full_string(' ') == False
    assert is_full_string('hello') == True
test_is_full_string()


# Generated at 2022-06-24 02:24:32.671821
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('<p>hello</p>') == True
    assert contains_html('hello') == False

# TEST: contains_html
test_contains_html()


# Generated at 2022-06-24 02:24:42.235393
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('foo_bar_baz') == True
    assert is_snake_case('foo') == False
    assert is_snake_case('_foo') == False
    assert is_snake_case('foo_') == True
    assert is_snake_case('foo__bar') == True
    assert is_snake_case('foo_bar') == True
    assert is_snake_case('foo__bar_') == True
    assert is_snake_case('foo_Bar') == False
    assert is_snake_case('foo-bar') == False
    assert is_snake_case('foo-bar', separator='-') == True



# Generated at 2022-06-24 02:24:51.084991
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('013601267X').is_isbn_10() is True
    assert __ISBNChecker('013601267X', normalize=False).is_isbn_10() is False
    assert __ISBNChecker('').is_isbn_10() is False
    assert __ISBNChecker('0-13-601267-X').is_isbn_10() is True
    assert __ISBNChecker('0-201-63385-X').is_isbn_10() is False
    assert __ISBNChecker('013309814X').is_isbn_10() is True
    assert __ISBNChecker('013309811X').is_isbn_10() is False
    assert __ISBNChecker('013026026X').is_isbn_10() is True

# Generated at 2022-06-24 02:24:59.187460
# Unit test for function is_string
def test_is_string():
    assert is_string("foo") == True
    assert is_string("") == True
    assert is_string("123") == True
    assert is_string("fooBar") == True
    assert is_string("foo-bar") == True
    assert is_string("foo_bar") == True
    assert is_string("FOO-BAR") == True
    assert is_string("FOO_BAR") == True
    assert is_string("foo bar") == True
    assert is_string("fOo bAr") == True
    assert is_string("  foo  ") == True
    assert is_string("  123  ") == True
    assert is_string("  foo-bar  ") == True
    assert is_string("  foo_bar  ") == True

# Generated at 2022-06-24 02:25:03.643635
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580')
    assert is_isbn('1506715214')
    assert is_isbn('978-0312498580', normalize=False)
    assert is_isbn('150-6715214', normalize=False)



# Generated at 2022-06-24 02:25:10.668129
# Unit test for function is_ip_v6
def test_is_ip_v6():
  assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334')
  assert is_ip_v6('2001:db8:85a3:0000:8a2e:370:7334')
  assert not is_ip_v6('2001:db8:85a3:0000:8a2e:370:7334:z')
  assert not is_ip_v6('2001:db8:85a3:0000:8a2e:370:7334:')
  assert is_ip_v6('2001:db8:85a3::8a2e:370:7334')
  assert is_ip_v6('2001:db8::8a2e:370:7334')

# Generated at 2022-06-24 02:25:18.996128
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4("255.200.100.75")
    assert not is_ip_v4("nope")
    assert not is_ip_v4("255.200.100.999")
    assert not is_ip_v4("255.200.100.")
    assert not is_ip_v4("255.200.100.1 ")
    assert not is_ip_v4("255.200.100.1.5")
    assert not is_ip_v4("0")
    assert not is_ip_v4(0)



# Generated at 2022-06-24 02:25:24.707371
# Unit test for function contains_html
def test_contains_html():
    # with assert_equals
    assert_equals(contains_html('my string is <strong>bold</strong>'),True)
    assert_equals(contains_html('my string is not bold'),False)

# Generated at 2022-06-24 02:25:31.307882
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('myString')
    assert is_camel_case('URLPattern')
    assert is_camel_case('authorID')
    assert not is_camel_case('URLpattern')
    assert not is_camel_case('author_id')
    assert not is_camel_case('author id')


# Generated at 2022-06-24 02:25:40.184962
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('MyString')
    assert not is_camel_case('mystring')
    assert is_camel_case('myString')
    assert not is_camel_case('my string')
    assert not is_camel_case('my_string')
    assert not is_camel_case('My1String')
    assert is_camel_case('My1STRING')
    assert not is_camel_case('1Mystring')
    assert not is_camel_case('my_string')
    assert is_camel_case('')
    assert not is_camel_case('my_string')


# Generated at 2022-06-24 02:25:43.620197
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334')
    assert not is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?')
    
test_is_ip_v6()



# Generated at 2022-06-24 02:25:46.372839
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid("1b6c3010-9cf0-45ca-88d5-6f1ebb0f7bcc") == True


# Generated at 2022-06-24 02:25:50.757605
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-3-16-148410-0').is_isbn_13() is True



# Generated at 2022-06-24 02:25:57.788430
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('MyString') == True
    assert is_camel_case('myString') == True
    assert is_camel_case('mystring2') == True
    assert is_camel_case('my_string') == False
    assert is_camel_case('My_string') == False
    assert is_camel_case('My string') == False
    assert is_camel_case('myString ') == False
    assert is_camel_case('mystring ') == False
    assert is_camel_case(' mystring') == False
    assert is_camel_case('myString') == True



# Generated at 2022-06-24 02:26:06.917545
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome("Radar", True)
    assert not is_palindrome("Radar", False)
    assert is_palindrome("Level", True)
    assert not is_palindrome("Level", False)
    assert is_palindrome("Madam", True)
    assert not is_palindrome("Madam", False)
    assert is_palindrome("rotor", True)
    assert not is_palindrome("rotor", False)
    assert is_palindrome("Kayak", True)
    assert not is_palindrome("Kayak", False)
    assert is_palindrome("Radar", True)
    assert not is_palindrome("Radar", False)
    assert is_palindrome("Noon", True)

# Generated at 2022-06-24 02:26:09.351711
# Unit test for function contains_html
def test_contains_html():
    assert(contains_html("<em>test</em>") == True)
    assert(contains_html("<strong>test</strong>") == True)
    assert(contains_html("This is good <em>test</em>") == True)
    assert(contains_html("test") == False)
    assert(contains_html("Test") == False)



# Generated at 2022-06-24 02:26:11.231161
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('dermatoglyphics') == True
    assert is_isogram('aba') == False
    assert is_isogram('moOse') == False
    assert is_isogram('') == True
# Test function
test_is_isogram()

# Generated at 2022-06-24 02:26:14.345032
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75') == True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip('1.2.3') == False
test_is_ip()


# Generated at 2022-06-24 02:26:16.296183
# Unit test for function is_isbn
def test_is_isbn():
    nums = ['9780312498580', '1506715214']
    for num in nums:
        assert is_isbn(num)
test_is_isbn()


# noinspection PyAttributeOutsideInit

# Generated at 2022-06-24 02:26:24.735152
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    checker = __ISBNChecker('9780134708160')
    assert checker.is_isbn_13() is True
    assert checker.is_isbn_10() is False

    checker = __ISBNChecker('978-0-13-470816-0')
    assert checker.is_isbn_13() is True
    assert checker.is_isbn_10() is False

    checker = __ISBNChecker('0-321-14653-0')
    assert checker.is_isbn_13() is False
    assert checker.is_isbn_10() is True

    checker = __ISBNChecker('0-321-14653-0')
    assert checker.is_isbn_13() is False
    assert checker.is_isbn_10() is True

# Generated at 2022-06-24 02:26:30.737498
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('foo_bar_baz') == True
    assert is_snake_case('foo') == False
    assert is_snake_case('foo_bar-baz', '-') == True
    assert is_snake_case('foo', '-') == False
    assert is_snake_case('foo', '-') == False



# Generated at 2022-06-24 02:26:32.484587
# Unit test for function words_count
def test_words_count():
    assert words_count('hello world') == 2
    assert words_count('one,two,three.stop') == 4



# Generated at 2022-06-24 02:26:41.131152
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome("otto")
    assert is_palindrome("i topi non avevano nipoti", ignore_spaces=True)
    assert is_palindrome("lol", ignore_case=True)
    assert not is_palindrome("i topi non avevano nipoti")
    assert not is_palindrome("rotfl")
    assert not is_palindrome("rotfl", ignore_case=True)
    assert not is_palindrome("toto", ignore_spaces=True)

test_is_palindrome()


# Generated at 2022-06-24 02:26:43.396454
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert(is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334') == True)
    assert(is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?') == False)



# Generated at 2022-06-24 02:26:46.194976
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75') == True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip('1.2.3') == False
test_is_ip()


# Generated at 2022-06-24 02:26:54.373570
# Unit test for function is_email
def test_is_email():
    assert is_email("my.email@the-provider.com") == True, "should be true"
    assert is_email("my-email@the-provider.com") == True, "should be true"
    assert is_email("my_email@the-provider.com") == True, "should be true"
    assert is_email("my-email@the-provider.com") == True, "should be true"
    assert is_email("my.email@the-provider.com") == True, "should be true"
    assert is_email("my.email@the-provider.com") == True, "should be true"
    assert is_email("my_email@the-provider.com") == True, "should be true"
    assert is_email("my_email@the-provider.com")

# Generated at 2022-06-24 02:26:59.776514
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('foo_bar_baz')
    assert is_snake_case('foo-bar-baz', '-')
    assert is_snake_case('foo_bar-baz')
    assert is_snake_case('Foo_bar_baz')
    assert not is_snake_case('foo')
    assert not is_snake_case('foo/baz')
    assert not is_snake_case('foo5')
    assert not is_snake_case('foo5bar_baz')



# Generated at 2022-06-24 02:27:10.122547
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert True == is_ip_v6("2001:0db8:85a3:0000:0000:8a2e:0370:7334")
    assert True == is_ip_v6("2001:db8:85a3:0:0:8a2e:370:7334")
    assert True == is_ip_v6("2001:db8:85a3::8a2e:370:7334")
    assert False == is_ip_v6("2001:0db8:85a3::8a2e:370:7334:")
    assert False == is_ip_v6("2001:0db8:85a3::8a2e:370:7334:")

# Generated at 2022-06-24 02:27:17.429873
# Unit test for function is_ip_v4
def test_is_ip_v4():
    valid_ips = ['255.200.100.75', '0.0.0.0', '255.255.255.255']
    invalid_ips = ['nope', '255.200.100.999', '255.200.999.75']

    for v in valid_ips:
        assert is_ip_v4(v)

    for i in invalid_ips:
        assert not is_ip_v4(i)



# Generated at 2022-06-24 02:27:21.505364
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580')
    assert is_isbn('9780312498580', normalize=False)
    assert is_isbn('978-0312498580')
    assert not is_isbn('0-395-36341-1')
    assert is_isbn('550-80476-8-0')
    assert not is_isbn('139994729X')
    assert not is_isbn('9780312498580-99')
    assert not is_isbn('139994729X-99')



# Generated at 2022-06-24 02:27:29.898988
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('378282246310005') == True, "378282246310005 is AMEX"
    assert is_credit_card('371449635398431') == True, "371449635398431 is AMEX"
    assert is_credit_card('378734493671000') == True, "378734493671000 is AMEX"
    assert is_credit_card('30569309025904') == True, "30569309025904 is Diners Club"
    assert is_credit_card('38520000023237') == True, "38520000023237 is Diners Club"
    assert is_credit_card('6011111111111117') == True, "6011111111111117 is Discover"

# Generated at 2022-06-24 02:27:38.154268
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com')
    assert is_url('http://www.mysite.com#anchor')
    assert is_url('http://www.mysite.com?param=value')
    assert is_url('http://www.mysite.com?param=value&param2=value2')
    assert is_url('http://www.mysite.com#hash?param=value')
    assert is_url('http://www.mysite.com/#hash?param=value')
    assert is_url('http://www.domain.com:8042/page.html')
    assert is_url('http://username:password@www.mysite.com')
    assert is_url('http://username:password@www.mysite.com:8042')

# Generated at 2022-06-24 02:27:46.017472
# Unit test for function is_palindrome
def test_is_palindrome():
    # pylint: disable=unused-argument
    def run(s: str, expected: bool, *args, **kwargs):
        actual = is_palindrome(s, *args, **kwargs)
        assert actual == expected, f'{ACTUAL} != {expected}'

    run('LOL', True)
    run('Lol', False)
    run('Lol', True, ignore_case=True)
    run('ROTFL', False)

    run(
        'A man, a plan, a canal, Panama!',
        True,
        ignore_spaces=True,
        ignore_case=True
    )

# Generated at 2022-06-24 02:27:49.017120
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert(is_isbn_10('1234567890') == True)
    assert(is_isbn_10('962-81-2009-20') == True)
    assert(is_isbn_10('9628120092') == False)



# Generated at 2022-06-24 02:27:50.884302
# Unit test for function is_decimal
def test_is_decimal():
    assert(is_decimal('42.0')==False)
    assert(is_decimal('42')==True)


# Generated at 2022-06-24 02:27:55.205349
# Unit test for function is_integer
def test_is_integer():
    try:
        assert(is_integer("42") == True)
        assert(is_integer("42.0") == False)
    except:
        print("Unit Testing for function is_integer FAILED")
        return False
    print("Unit Testing for function is_integer Passed")
    return True

test_is_integer()



# Generated at 2022-06-24 02:28:00.953830
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') == True
    assert is_isbn_10('150-6715214') == True
    assert is_isbn_10('150-6715214', normalize=False) == False


# Generated at 2022-06-24 02:28:06.190185
# Unit test for function is_string
def test_is_string():
    assert is_string('foo') is True
    assert is_string('Foo') is True
    assert is_string('Fo0') is True
    assert is_string('') is True
    assert is_string(None) is False
    assert is_string(4) is False
    assert is_string(True) is False
    assert is_string([]) is False
    assert is_string({}) is False



# Generated at 2022-06-24 02:28:08.377183
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog') == True
    assert is_pangram('hello world') == False
test_is_pangram()


# Generated at 2022-06-24 02:28:10.634330
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') == True
    assert is_isbn('1506715214') == True

# Generated at 2022-06-24 02:28:22.597500
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4111111111111111', 'VISA') == True
    assert is_credit_card('4111111111111111') == True
    assert is_credit_card('411111111111111112') == False
    assert is_credit_card('4111111111111112') == False
    assert is_credit_card('411111111111112') == False

    assert is_credit_card('5555555555554444', 'MASTERCARD') == True
    assert is_credit_card('5555555555554444') == True
    assert is_credit_card('55555555555544452') == False
    assert is_credit_card('5555555555554442') == False
    assert is_credit_card('555555555555442') == False

    assert is_

# Generated at 2022-06-24 02:28:28.164572
# Unit test for function is_ip
def test_is_ip():
    assert is_ip("255.200.100.75") is True
    assert is_ip("2001:db8:85a3:0000:0000:8a2e:370:7334") is True
    assert is_ip("1.2.3") is False

# Generated at 2022-06-24 02:28:37.226083
# Unit test for function is_json
def test_is_json():
    assert is_json('') == False
    assert is_json(None) == False
    assert is_json('{}') == True
    assert is_json('[]') == True
    assert is_json('[1, 2]') == True
    assert is_json('{"key": "value"}') == True
    assert is_json('{"key": "value", "key2": "value2"}') == True
    assert is_json('{"key": "value", "key2": "value2", "key3": ["sub", "sub2"]}') == True
    assert is_json('{"key": "value", "key2": "value2", "key3": [{"sub": "sub2"}]}') == True



# Generated at 2022-06-24 02:28:41.992113
# Unit test for function is_isogram
def test_is_isogram():
    a = 1
    b = 1
    epsilon = 0.00001
    if abs(a-b) < epsilon:
        print("True")

    else:
        print("False")
# Unit tests for is_isogram
test_is_isogram()

print("\n")


# Generated at 2022-06-24 02:28:44.121292
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('my string is <strong>bold</strong>')
    assert not contains_html('my string is not bold')


# Generated at 2022-06-24 02:28:49.615832
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title')
    assert not is_slug('My blog post title')
    assert is_slug('my-blog-post-title', '_')
    assert not is_slug('my_blog_post_title')
    assert not is_slug('myblogposttitle')
    assert not is_slug('my|blog|post|title')



# Generated at 2022-06-24 02:29:01.459597
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4929804463622139', card_type='VISA')
    assert is_credit_card('5555555555554444', card_type='MASTERCARD')
    assert is_credit_card('378282246310005', card_type='AMERICAN_EXPRESS')
    assert is_credit_card('30569309025904', card_type='DINERS_CLUB')
    assert is_credit_card('6011111111111117', card_type='DISCOVER')
    assert is_credit_card('3530111333300000', card_type='JCB')


# test cases taken from wikipedia
# https://en.wikipedia.org/wiki/Camel_case

# Generated at 2022-06-24 02:29:04.934940
# Unit test for function is_slug
def test_is_slug():
    assert is_slug("john-doe-1")
    assert not is_slug("john doe 1")
    assert not is_slug("-john-doe-1")
    assert not is_slug("john-doe-1-")
    assert is_slug("john_doe_1")
    assert not is_slug("john.doe.1")



# Generated at 2022-06-24 02:29:14.414391
# Unit test for function is_camel_case
def test_is_camel_case():
  assert is_camel_case("MyString") == True
  assert is_camel_case("mystring") == False
  assert is_camel_case("My String") == False
  assert is_camel_case("1MyString") == True
  assert is_camel_case("MyString0") == True
  assert is_camel_case("0MyString0") == True
  assert is_camel_case("My_String") == False
  assert is_camel_case("My-String") == False
  assert is_camel_case("") == False
test_is_camel_case()



# Generated at 2022-06-24 02:29:16.557798
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42')
    assert is_integer('+42')
    assert is_integer('-42')
    assert is_integer('42.0') == False



# Generated at 2022-06-24 02:29:18.579339
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42') is True
    assert is_integer('42.0') is False



# Generated at 2022-06-24 02:29:21.470460
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334')
    assert is_ip('255.200.100.75')
    assert not is_ip('1.2.3')
    assert not is_ip('2001:db8:85a3:0000:0000:8a2e:370:?')


# Generated at 2022-06-24 02:29:22.702537
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title', separator='-')
    assert is_slug('My blog post title', separator='-') == False



# Generated at 2022-06-24 02:29:26.917562
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    isbn_checker = __ISBNChecker('1234567890')
    assert isbn_checker.is_isbn_10() == True

    isbn_checker = __ISBNChecker('1234567895')
    assert isbn_checker.is_isbn_10() == False


# Generated at 2022-06-24 02:29:39.654643
# Unit test for function is_number
def test_is_number():
    assert is_number(None) == False, 'None is not a number'
    assert is_number(' ') == False, '" " is invalid'
    assert is_number(' 42 ') == True, '" 42 " is valid'
    assert is_number('19.99') == True, '"19.99" is valid'
    assert is_number('-9.12') == True, '"-9.12" is valid'
    assert is_number('1E3') == True, '"1E3" is valid'
    assert is_number('1 2 3') == False, '"1 2 3" is invalid'


# Generated at 2022-06-24 02:29:47.604219
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid("6f8aa2f9-686c-4ac3-8766-5712354a04cf", allow_hex=False)
    assert is_uuid("6f8aa2f9686c4ac387665712354a04cf", allow_hex=True)
    assert not is_uuid("6f8aa2f9686c4ac387665712354a04cf", allow_hex=False)
    assert not is_uuid("6f8aa2f9-686c-4ac3-8766-5712354a04c", allow_hex=False)
    assert not is_uuid("6f8aa2f9686c4ac387665712354a04c", allow_hex=True)