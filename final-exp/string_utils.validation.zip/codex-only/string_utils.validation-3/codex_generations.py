

# Generated at 2022-06-24 02:19:47.371137
# Unit test for function is_integer
def test_is_integer():
    assert is_integer(1e5)
    assert is_integer("1e5")
    assert is_integer(10)
    assert not is_integer('10.00')
    assert not is_integer('10.')
    assert not is_integer('10.0.')
    assert not is_integer('10.00.')
    assert not is_integer('foo')
    assert not is_integer('1e-5')



# Generated at 2022-06-24 02:19:57.011146
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert(is_ip_v6("2001:db8:85a3:0000:0000:8a2e:370:7334"))
    assert(is_ip_v6("2001:db8:85a3:0:0:8a2e:370:7334"))
    assert(is_ip_v6("2001:db8:85a3::8a2e:370:7334"))
    assert(is_ip_v6("2001:db8:85a3::8a2e:370:7334"))
    # Shortened address (omission of leading zeros) is not accepted.
    assert(not is_ip_v6("2001:db8:85a3:0:0:8a2e:370:7334"))
    
    
    
    # Incomplete address is not accepted.

# Generated at 2022-06-24 02:20:03.506872
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string(None) == False
    assert is_full_string('') == False
    assert is_full_string(' ') == False
    assert is_full_string('hello ') == True
    assert is_full_string('hello\n ') == True



# Generated at 2022-06-24 02:20:06.027505
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('MyString')  # returns true
    assert is_camel_case('mystring')  # returns false
    assert not is_camel_case('mystring')  # returns false

# Generated at 2022-06-24 02:20:16.524697
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('0306406152') == True
    assert is_isbn_10('1789637754') == True
    assert is_isbn_10('1789637754') == True
    assert is_isbn_10('1935182021') == True
    assert is_isbn_10('0309085373') == True
    assert is_isbn_10('0465050654') == True
    assert is_isbn_10('0-439-88598-2') == True
    assert is_isbn_10('0-9752298-0-X') == True
    assert is_isbn_10('0-9752298-0-X', False) == False
    assert is_isbn_10('1593275846') == True

# Generated at 2022-06-24 02:20:25.778489
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('MyString')
    assert not is_camel_case('mystring')
    assert not is_camel_case('My String')
    assert not is_camel_case('My-String')
    assert not is_camel_case('My_String')
    assert not is_camel_case('mystring')
    assert not is_camel_case('my_String')
    assert not is_camel_case('My_string')
    assert not is_camel_case('1MyString')
    assert is_camel_case('MyString1')


# Generated at 2022-06-24 02:20:28.841442
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert(is_isbn_10("1506715214") == True)
    assert(is_isbn_10("150-6715214") == True)
    assert(is_isbn_10("150-6715214", normalize=False) == False)


# Generated at 2022-06-24 02:20:32.854386
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('abcde') == True
    assert is_isogram('z5a5') == False
    assert is_isogram('2hello') == False
    assert is_isogram('hello world') == False
    assert is_isogram('dermatoglyphics') == True
    print('is_isogram passed')

test_is_isogram()

# Generated at 2022-06-24 02:20:36.503546
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram("Dermatoglyphics") == True
    assert is_isogram("isogram") == True
    assert is_isogram("aba") == False
    assert is_isogram("moOse") == False
    assert is_isogram("isIsogram") == False
    assert is_isogram("") == True


# Generated at 2022-06-24 02:20:39.875097
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog') == True
    assert is_pangram('The quick brown fox jumps over the lazy dog!') == True
    assert is_pangram('The quick brown fox jumps over the lazy dog?') == True
    assert is_pangram('The quick brown fox jumps over the lazy dog.') == False
    assert is_pangram('Hello world') == False
    assert is_pangram('hello world') == False
    assert is_pangram('hello, world') == False
    assert is_pangram('') == False
    assert is_pangram(' ') == False
test_is_pangram()

# Generated at 2022-06-24 02:20:41.035525
# Unit test for function is_string
def test_is_string():
    assert is_string('bar') == True
    assert is_string(b'bar') == False
    assert is_string(1) == False



# Generated at 2022-06-24 02:20:41.742595
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('42.0') is True


# Generated at 2022-06-24 02:20:43.170516
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580')
    assert is_isbn('978-0312498580')
    assert not is_isbn('978-0312498580', normalize=False)



# Generated at 2022-06-24 02:20:50.074843
# Unit test for function is_ip_v6
def test_is_ip_v6():
    _input_strings = [
        '2001:db8:85a3:0000:0000:8a2e:370:7334',
    ]
    expected_result = True
    for _input_string in _input_strings:
        _test_result = is_ip_v6(_input_string)
    assert _test_result == expected_result



# Generated at 2022-06-24 02:20:54.292353
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False
    print("Unit test for function is_ip_v4 is succeeded")


# Generated at 2022-06-24 02:21:04.106110
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():

    # 1. Arrange
    isbnChecker = __ISBNChecker('0123456789')
    # 2. Act
    result = isbnChecker.is_isbn_10()

    # 3. Assert
    assert result == True

    # 1. Arrange
    isbnChecker = __ISBNChecker('012345678')
    # 2. Act
    result = isbnChecker.is_isbn_10()

    # 3. Assert
    assert result == False

    # 1. Arrange
    isbnChecker = __ISBNChecker('0123456780')
    # 2. Act
    result = isbnChecker.is_isbn_10()

    # 3. Assert
    assert result == True

    # 1. Arrange
    isbnChecker = __ISBNCheck

# Generated at 2022-06-24 02:21:10.242698
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case("iAmACamelCaseString")
    assert not is_camel_case("i_am_a_snakeCase_string")
    assert not is_camel_case("I_am_a_snakeCase_string")
    assert not is_camel_case("")
    assert not is_camel_case(" ")
    assert not is_camel_case(".String")
    assert not is_camel_case("1String")
    assert not is_camel_case(" String")



# Generated at 2022-06-24 02:21:12.874146
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') == True
    assert is_isbn_10('150-6715214') == True
    assert is_isbn_10('150-6715214', normalize=False) == False
test_is_isbn_10()



# Generated at 2022-06-24 02:21:15.191156
# Unit test for function is_camel_case
def test_is_camel_case():
    print("is_camel_case(input_string: Any)-> bool")
    print(is_camel_case('MyString'))
    print(is_camel_case('mystring'))


# Generated at 2022-06-24 02:21:22.090772
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('otto')
    assert is_palindrome('i topi non avevano nipoti')
    assert is_palindrome('io non ho paura')
    assert not is_palindrome('io ho paura')
    assert is_palindrome('otto', ignore_spaces=True)
    assert is_palindrome('i topi non avevano nipoti', ignore_spaces=True)
    assert is_palindrome('io non ho paura', ignore_spaces=True)
    assert not is_palindrome('io ho paura', ignore_spaces=True)
    assert is_palindrome('ROTFL')
    assert is_palindrome('Lol', ignore_case=True)
    assert not is_palindrome('Lol')

# Generated at 2022-06-24 02:21:25.910849
# Unit test for function is_camel_case
def test_is_camel_case():
    """test case for is_camel_case"""
    assert is_camel_case(input_string = 'MyString') == True, "is_camel_case returns invalid result" 
    assert is_camel_case(input_string = 'mystring') == False, "is_camel_case returns invalid result" 

test_is_camel_case()



# Generated at 2022-06-24 02:21:27.613651
# Unit test for function is_palindrome
def test_is_palindrome():
	assert(is_palindrome("LOL") == True)
	assert(is_palindrome("Lol") == False)
	assert(is_palindrome("Lol", ignore_case=True) == True)
	assert(is_palindrome("ROTFL") == False)

# Generated at 2022-06-24 02:21:29.444326
# Unit test for function words_count
def test_words_count():
    assert words_count('hello world') == 2
# The code below will call function "test_words_count" to check whether it works
test_words_count()


# Generated at 2022-06-24 02:21:40.505498
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580')
    assert is_isbn_13('978-0312498580')
    assert is_isbn_13('978-03-12498580')
    assert is_isbn_13('978-0-312-498580')
    assert is_isbn_13('978-0-312-498580-8')
    assert is_isbn_13('978-0-312-498580-8-')
    assert is_isbn_13('978-0-312-498580-8-1')
    assert is_isbn_13('978-0-312-498580-8-12')
    assert is_isbn_13('978-0-312-498580-8-123')
    assert is_isbn_13

# Generated at 2022-06-24 02:21:46.912961
# Unit test for function is_number
def test_is_number():
    assert is_number(42) == False
    assert is_number('42') == True
    assert is_number('19.99') == True
    assert is_number('-9.12') == True
    assert is_number('1e3') == True
    assert is_number('1 2 3') == False
#test_is_number()



# Generated at 2022-06-24 02:21:54.760013
# Unit test for function words_count
def test_words_count():
    assert words_count('asd asd') == 2
    assert words_count('asd asd') == 2
    assert words_count('asd asd') == 2
    assert words_count('asd asd') == 2
    assert words_count('asd asd') == 2
    assert words_count('asd asd') == 2
    assert words_count('asd asd') == 2
    assert words_count('asd asd') == 2
    assert words_count('asd asd') == 2
    assert words_count('asd asd') == 2
    assert words_count('asd asd') == 2
    assert words_count('asd asd') == 2
    assert words_count('asd asd') == 2
    assert words_count('asd asd') == 2
    assert words

# Generated at 2022-06-24 02:22:03.641276
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('0.12345') == True
    assert is_decimal('1.0') == True
    assert is_decimal('-1.234') == True
    assert is_decimal('1.0e3') == True
    assert is_decimal('1.0e+3') == True
    assert is_decimal('12345') == False
    assert is_decimal('hello') == False
    assert is_decimal('') == False
    assert is_decimal(None) == False



# Generated at 2022-06-24 02:22:04.965795
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('my string is <strong>bold</strong>') == True
    assert contains_html('my string is not bold') == False
    
    

# Generated at 2022-06-24 02:22:17.172478
# Unit test for function is_json
def test_is_json():
	assert not is_json(None)
	assert not is_json(True)
	assert not is_json([])
	assert not is_json({})
	assert is_json('{}')
	assert not is_json('{ 1: 2, 3: 4 }')
	assert is_json('{ "1": "2", "3": "4" }')
	assert not is_json('[ 1, 2, 3, 4 ]')
	assert is_json('[ "1", "2", "3", "4" ]')
	assert is_json('{"user": {"firstName": "John", "lastName": "Doe"}}')
	assert is_json('{"user": {"firstName": "John", "lastName": "Doe", "languages": [ "English", "French" ]}}')



# Generated at 2022-06-24 02:22:25.156514
# Unit test for function is_isogram
def test_is_isogram():
  assert(is_isogram("moose") == True)
  assert(is_isogram("isogram") == True)
  assert(is_isogram("aba") == False)
  assert(is_isogram("moOse") == False)
  assert(is_isogram("thumbscrewjapingly") == True)
  assert(is_isogram("") == True)
  print("All test passed")

test_is_isogram()


# Generated at 2022-06-24 02:22:31.863987
# Unit test for function is_json
def test_is_json():
    # True cases
    assert is_json("{\"a\": 1}") == True
    assert is_json("{\"a\": 1,  \"b\": true, \"c\": \"d\"}") == True
    assert is_json("{\"a\": 1.0,  \"b\": true, \"c\": \"d\"}") == True
    assert is_json("{\"a\": 1.0,  \"b\": true, \"c\": [\"d\"]}") == True
    assert is_json("{\"a\": 1.0,  \"b\": true, \"c\": [\"d\", \"e\"]}") == True
    assert is_json("{\"a\": 1.0,  \"b\": [true, 1], \"c\": [\"d\", \"e\", \"f\"]}") == True
    # False cases
    assert is_json

# Generated at 2022-06-24 02:22:36.521566
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('hello world') is False
    assert is_pangram('The quick brown fox jumps over the lazy dog') is True
    
test_is_pangram()
 
 

# Generated at 2022-06-24 02:22:41.723866
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4241777460291450') == True
    assert is_credit_card('1') == False
    assert is_credit_card('asd') == False
    assert is_credit_card('4539101952121635') == True
    assert is_credit_card('4716786616247434') == True
test_is_credit_card()



# Generated at 2022-06-24 02:22:42.989692
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4012888888881881') == True


# Generated at 2022-06-24 02:22:51.048876
# Unit test for function is_email
def test_is_email():
    """
    Test for the function is_email.
    """
    assert is_email('test@test.com') is True
    assert is_email('test.test@test.com') is True
    assert is_email('test_test@test.com') is True
    assert is_email('test-test@test.com') is True
    assert is_email('test+test@test.com') is True
    assert is_email('test=test@test.com') is True
    assert is_email('test/test@test.com') is True
    assert is_email('"test@test"@test.com') is True
    assert is_email('test\\@test@test.com') is True
    assert is_email('test\\ test@test.com') is True

# Generated at 2022-06-24 02:22:57.245378
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('5.5') == True
    assert is_decimal('5') == False
    assert is_decimal('-10.5') == True
    assert is_decimal('10') == False
    assert is_decimal('0.5') == True
    assert is_decimal(0.5) == False
    assert is_decimal('0') == False
    
    

# Generated at 2022-06-24 02:22:59.218057
# Unit test for function is_json
def test_is_json():
    assert is_json("")
    assert not is_json("{nope}")
    assert is_json("{\"name\": \"Peter\"}")


# Generated at 2022-06-24 02:23:02.790180
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}') # returns true
    assert is_json('[1, 2, 3]') # returns true
    assert not is_json('{nope}') # returns false


# Generated at 2022-06-24 02:23:08.398635
# Unit test for function is_palindrome
def test_is_palindrome():
    strings_to_check = [
        ('LOL', True),
        ('Lol', True),
        ('Lol', False, True),
        ('ROTFL', False),
        ('Otto', True),
        ('I topi non avevano nipoti', True, True),
        ('I topi non avevano nipoti', False, False),
        ('A rosa piscina, ah piscina rosa, a girar la rosa, a tomar la rosa', True, True)
    ]

    for input_string, ignore_spaces, ignore_case in strings_to_check:
        assert is_palindrome(input_string, ignore_spaces, ignore_case) is True

# Generated at 2022-06-24 02:23:16.307969
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('') is False
    assert is_decimal('1') is False
    assert is_decimal('1.') is False
    assert is_decimal('1.1') is True
    assert is_decimal('1.12') is True
    assert is_decimal('1.123') is True
    assert is_decimal('.1') is True
    assert is_decimal('.12') is True
    assert is_decimal('.123') is True
    assert is_decimal('-1') is False
    assert is_decimal('-1.') is False
    assert is_decimal('-1.1') is True
    assert is_decimal('-1.12') is True
    assert is_decimal('-1.123') is True

# Generated at 2022-06-24 02:23:22.677729
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf')
    assert not is_uuid('6f8aa2f9686c4ac387665712354a04cf')
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True)

# Generated at 2022-06-24 02:23:25.491392
# Unit test for function is_camel_case
def test_is_camel_case():
    print("IsCamelCase")
    assert is_camel_case("MyString") is True
    assert is_camel_case("mystring") is False
    assert is_camel_case("myString") is False
    assert is_camel_case("MyString123") is True
    assert is_camel_case("12345") is False
    print("Done")


# Generated at 2022-06-24 02:23:27.059604
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog') == True
    assert is_pangram('Lions, and tigers, and bears, oh my!') == True
    assert is_pangram('hello world') == False
test_is_pangram()


# Generated at 2022-06-24 02:23:32.814661
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('-5.5') == True
    assert is_decimal('5.5') == True
    assert is_decimal('5') == False
    assert is_decimal('-5') == False



# Generated at 2022-06-24 02:23:37.690373
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4("255.200.100.75") == True
    assert is_ip_v4("nope") == False
    assert is_ip_v4("255.200.100.999") == False


# Generated at 2022-06-24 02:23:39.701767
# Unit test for function is_string
def test_is_string():
    assert (is_string('foo')) == True
    assert (is_string(b'foo')) == False



# Generated at 2022-06-24 02:23:45.795958
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('dermatoglyphics') == True
    assert is_isogram('salad') == False
    assert is_isogram('moose') == True
    assert is_isogram('Kevin') == False
    assert is_isogram('12345678') == False
    assert is_isogram(' ') == False
    assert is_isogram('') == True
    assert is_isogram('hello') == False
    assert is_isogram('kevin') == True
    assert is_isogram('mo0se') == True

test_is_isogram()

# Generated at 2022-06-24 02:23:57.667364
# Unit test for function is_snake_case
def test_is_snake_case():
    assert(is_snake_case('some-string-to-test') is True)
    assert(is_snake_case('some-string_to_test') is True)
    assert(is_snake_case('some-string_to_test', separator='-') is True)
    assert(is_snake_case('SOME-STRING-TO-TEST') is True)
    assert(is_snake_case('some-string') is False)
    assert(is_snake_case('some-string_to_test-1') is True)
    assert(is_snake_case('some-string_to_test1-2') is True)
    assert(is_snake_case('some-string_to_test--1') is True)

# Generated at 2022-06-24 02:24:05.191775
# Unit test for function words_count
def test_words_count():
    assert words_count('') == 0
    assert words_count('hello world') == 2
    assert words_count('one,1000,three.stop') == 4
    assert words_count('! @ # % ... []') == 0
    assert words_count(b'hello world') == 2
    # with pytest.raises(InvalidInputError):
    #     words_count()
    # with pytest.raises(InvalidInputError):
    #     words_count('foo', 'bar')

# Generated at 2022-06-24 02:24:11.972677
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    checker = __ISBNChecker('978-1-78899-073-9')
    assert checker.is_isbn_13() == True

    checker = __ISBNChecker('0-306-40615-2')
    assert checker.is_isbn_10() == True

    checker = __ISBNChecker('1-78899-073-2')
    assert checker.is_isbn_13() == False

    checker = __ISBNChecker('0-306-40615')
    assert checker.is_isbn_10() == False


# PUBLIC API


# Generated at 2022-06-24 02:24:19.445127
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title') == True
    assert is_slug('My blog post title') == False
    assert is_slug('My-blog-post-title') == False

# Test main running function
input_string = "My-blog-post-title"
test_is_slug()

# The main function is defined that can be called from the python interpreter console
# It will execute the unit test functions automatically

# Generated at 2022-06-24 02:24:22.102393
# Unit test for function is_decimal
def test_is_decimal():
    assert(is_decimal('42.0') == True)
    assert(is_decimal('42') == False)


# Generated at 2022-06-24 02:24:24.335075
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    input_string = "0747532699"
    checker = __ISBNChecker(input_string)
    assert checker.is_isbn_10() == True


# Generated at 2022-06-24 02:24:26.466867
# Unit test for function is_ip_v4
def test_is_ip_v4():
    print(is_ip_v4('255.200.100.75'))
    
test_is_ip_v4()


# Generated at 2022-06-24 02:24:32.520225
# Unit test for function is_ip_v4
def test_is_ip_v4():
    name = 'is_ip_v4'
    true_cases = [
        '255.200.100.75',
        '1.1.1.1',
        '0.0.0.0'
        '255.0.0.0',
        '0.255.0.0',
        '0.0.255.0',
        '0.0.0.255',
        '255.255.255.255',
    ]

# Generated at 2022-06-24 02:24:35.946560
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') == True
    assert is_isbn('1506715214') == True



# Generated at 2022-06-24 02:24:40.671156
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('42') == False
    assert is_decimal('42.0') == True
    assert is_decimal('-9.12') == True
    assert is_decimal('1 2 3') == False
    assert is_decimal('1e3') == False
    assert is_decimal('-1e3') == False
    
    
    

# Generated at 2022-06-24 02:24:50.536947
# Unit test for function is_email
def test_is_email():
    assert is_email("name@domain.com") == True
    assert is_email("name@domain.org") == True
    assert is_email("name@domainadd.com") == True
    assert is_email("name@domain.co.com") == True
    assert is_email("name_name@domain.com") == True
    assert is_email("name-name@domain.com") == True
    assert is_email("name@-domain.com") == False
    assert is_email("name@domain-.com") == False
    assert is_email("name@domain.com-") == False
    assert is_email("name@domain.com.") == False
    assert is_email("-name@domain.com") == False
    assert is_email("name@domain.com-") == False

# Generated at 2022-06-24 02:24:53.171111
# Unit test for function is_camel_case
def test_is_camel_case():
    from utils.checker import is_camel_case

    assert is_camel_case('MyString') == True
    assert is_camel_case('mystring') == False



# Generated at 2022-06-24 02:24:57.162399
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram("The quick brown fox jumps over the lazy dog") == True
    assert is_pangram("hello world") == False
    assert is_pangram("abcdefghijklmnopqrstuvwxyz") == True
    assert is_pangram("") == False
    assert is_pangram("abcdefghijklm") == False
    assert is_pangram("abcdefghijklmnopqrstuvwxyz abcdefghijklmnopqrstuvwxyz") == True
    assert is_pangram("abcdefghijklmnopqrstuvwxyznn") == False
    assert is_pangram("abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz") == True


# Generated at 2022-06-24 02:25:04.740062
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('9780439708180').is_isbn_13() is True
    assert __ISBNChecker('9780316015844').is_isbn_13() is True
    assert __ISBNChecker('9780316015845').is_isbn_13() is True
    assert __ISBNChecker('9780316015846').is_isbn_13() is False


# Generated at 2022-06-24 02:25:09.226149
# Unit test for function words_count
def test_words_count():
    # Check empty string
    assert words_count('') == 0
    # Check that a single letter is counted as 1!
    assert words_count('a') == 1
    # Check standard case
    assert words_count('hello world') == 2
    # Check list of words
    assert words_count('one,two,three.stop') == 4
    # Check number + letter
    assert words_count('one1two2three3') == 3

# Generated at 2022-06-24 02:25:11.486565
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf')
    assert not is_uuid('6f8aa2f9686c4ac387665712354a04cf')
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True)



# Generated at 2022-06-24 02:25:21.246032
# Unit test for function is_number
def test_is_number():
    assert is_number("1")
    assert is_number("1.0")
    assert is_number("12345")
    assert is_number("1e5")
    assert is_number("1E5")
    assert is_number("1E+05")
    assert is_number("1E-05")
    assert is_number("1.2")
    assert is_number("+1.2")
    assert is_number("-1.2")
    assert is_number("-1.2E+05")
    assert is_number("0.000001")
    assert is_number(".1")
    assert is_number("123456789")
    assert is_number("10e100")
    assert is_number("10E100")
    assert is_number("10e+100")
    assert is_number

# Generated at 2022-06-24 02:25:24.162331
# Unit test for function is_camel_case
def test_is_camel_case():
    assert(is_camel_case('MyString') == True)
    assert(is_camel_case('myString') == False)
    assert(is_camel_case('mystring') == False)


# Generated at 2022-06-24 02:25:35.443297
# Unit test for function is_ip
def test_is_ip():
    # Test IP V4
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False

    # Test IP V6
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip_v6('2001:db8:85a3:0000:0000:8a2e:370:?') == False

    # Test IP
    assert is_ip('255.200.100.75') == True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True

# Generated at 2022-06-24 02:25:47.031058
# Unit test for function is_integer
def test_is_integer():
    assert(is_integer('42'))
    assert(is_integer('0x42'))
    assert(is_integer('8_842_658'))
    assert(is_integer('8__842_658'))
    assert(is_integer('8*842*658'))
    assert(is_integer('8'*842*658))
    assert(is_integer('8'*842*658*2))
    assert(is_integer('8'*842))
    assert(is_integer('8'*842))
    assert(not is_integer('-8'*842*658*2))
    assert(not is_integer('8'*842*658*2+'.'))

# Generated at 2022-06-24 02:25:53.261067
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title')
    assert is_slug('my-blog-post-title', separator='_')
    assert is_slug('my-blog-post-title', separator='+')

    assert not is_slug('My blog post title')
    assert not is_slug('my-blog-post-title-')
    assert not is_slug('my-blog-post-title-', separator='_')
    assert not is_slug('my-blog-post-title-', separator='+')



# Generated at 2022-06-24 02:26:04.197256
# Unit test for function is_uuid
def test_is_uuid():
  assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') == True
  assert is_uuid('6f8aa2f9686c4ac387665712354a04cf') == False
  assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True) == True
# Test for function is_url

# Generated at 2022-06-24 02:26:15.184133
# Unit test for function is_url
def test_is_url():
    assert is_url("http://www.mysite.com") == True
    assert is_url("https://mysite.com") == True
    assert is_url(".mysite.com") == False
    assert is_url("http://mysite.com.br") == True
    assert is_url("https://mysite.com.br") == True
    assert is_url(".mysite.com.br") == False
    assert is_url(".mysite.com.br") == False
    assert is_url("http://www.mysite.com.br") == True
    assert is_url("https://www.mysite.com.br") == True
    assert is_url(".www.mysite.com.br") == False
    assert is_url("http://www.mysite.com.br/") == True


# Generated at 2022-06-24 02:26:20.840350
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    assert __ISBNChecker('978-0-306-40615-7').input_string == '9780306406157'
    assert __ISBNChecker('978 0 306 40615 7', False).input_string == '978 0 306 40615 7'



# Generated at 2022-06-24 02:26:29.301189
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('otto')
    assert is_palindrome('i topi non avevano nipoti', ignore_spaces=True)
    assert is_palindrome('Lol', ignore_case=True)
    assert not is_palindrome('ROTFL')
    assert not is_palindrome('LOL')
    assert not is_palindrome('Lol')
    assert not is_palindrome('i topi non avevano nipoti')
    assert not is_palindrome('')
    assert not is_palindrome(None)

test_is_palindrome()



# Generated at 2022-06-24 02:26:33.673859
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('moose') == True
    assert is_isogram('test') == False
    assert is_isogram('abcdefghijklmnopqrstuvwxyz') == True
    assert is_isogram('ABCDEFGHIJKLMNOPQRSTUVWXYZ') == True
    assert is_isogram('2') == True
    assert is_isogram('') == True

# Generated at 2022-06-24 02:26:36.174201
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False


# Generated at 2022-06-24 02:26:37.719477
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42') == True
    assert is_integer('42.0') == False
    

# Generated at 2022-06-24 02:26:47.367033
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('5451-5256-5121-5217')
    assert is_credit_card('3852-1986-4858-9945')
    assert is_credit_card('3056-9309-6258-5904')
    assert not is_credit_card('3056-9309-6258-5905')
    assert not is_credit_card('3056-9309-6258-5906')
    assert is_credit_card('3484-8094-3281-9392')
    assert not is_credit_card('3584-8094-3281-9392')
    assert not is_credit_card('3484-8094-3281-9393')
    assert is_credit_card('3529-8904-9361-1234')
    assert not is_credit_

# Generated at 2022-06-24 02:26:55.637630
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0306406152').is_isbn_10() == True
    assert __ISBNChecker('0596002226').is_isbn_10() == False
    assert __ISBNChecker('030640615').is_isbn_10() == False
    assert __ISBNChecker('03064061520').is_isbn_10() == False
    assert __ISBNChecker('05960022262').is_isbn_10() == False
    return True


# Generated at 2022-06-24 02:27:01.879234
# Unit test for function words_count
def test_words_count():
    print('Testing function words_count... ', end='')
    
    cases = [
        ('hello world', 2),
        ('one, two, three.stop', 4),
        ('...', 0),
        ('', 0),
        ('  ', 0),
        ('one two three', 3),
        ('#one @two %three', 3),
        ('#one @two %three.', 3),
        ('one.two.three', 3),
        ('one,two,three', 3),
        ('one;two;three', 3)
    ]
    
    for input_string, expected_value in cases:
        assert words_count(input_string) == expected_value
    
    print('[OK]')


# Unit testing the file itself

# Generated at 2022-06-24 02:27:09.125542
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4111111111111111')
    assert is_credit_card('4111111111111')
    assert is_credit_card('4012888888881881')
    assert is_credit_card('378282246310005')
    assert is_credit_card('6011111111111117')
    assert is_credit_card('5105105105105100')
    assert is_credit_card('5105105105105106')
    assert is_credit_card('9111111111111111')



# Generated at 2022-06-24 02:27:15.353341
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('978-3-16-148410-0').is_isbn_13() is True
    assert __ISBNChecker('9780324548973').is_isbn_13() is True
    assert __ISBNChecker('978-0-321-548970').is_isbn_13() is False
    assert __ISBNChecker('9780321548975').is_isbn_13() is False
    assert __ISBNChecker('978-0-321-548977').is_isbn_13() is True


# Generated at 2022-06-24 02:27:26.498413
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    checker = __ISBNChecker('1234567891')
    assert checker.is_isbn_10()

    checker = __ISBNChecker('1234567892')
    assert not checker.is_isbn_10()

    checker = __ISBNChecker('1234567890')
    assert checker.is_isbn_10()

    checker = __ISBNChecker('1234567890')
    assert checker.is_isbn_10()

    checker = __ISBNChecker('abcdefghij')
    assert not checker.is_isbn_10()

    checker = __ISBNChecker('123456789')
    assert not checker.is_isbn_10()

    checker = __ISBNChecker('1234567890-' * 10)
   

# Generated at 2022-06-24 02:27:31.219977
# Unit test for function is_full_string
def test_is_full_string():
    print("Testing function is_full_string...", end="")
    assert(is_full_string(' ') == True)
    assert(is_full_string('shazam') == True)
    assert(is_full_string(None) == False)
    assert(is_full_string('') == False)
    print("Passed!")

test_is_full_string()



# Generated at 2022-06-24 02:27:35.507428
# Unit test for function is_number
def test_is_number():
    assert is_number('') == False
    assert is_number(' ') == False
    assert is_number('0 ') == False
    assert is_number('-1') == True
    assert is_number('-1.0') == True
    assert is_number('-1.0e1') == True


# Generated at 2022-06-24 02:27:40.797226
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('foo_bar_baz') == True
    assert is_snake_case('foo') == False


# Generated at 2022-06-24 02:27:43.741511
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75') == True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip('1.2.3') == False

test_is_ip()

# ==============================================================================
# SUPPORT FUNCTIONS
# ==============================================================================

# Generated at 2022-06-24 02:27:50.925169
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('123.123.123.123') == True
    assert is_ip_v4('123.123.123') == False
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False



# Generated at 2022-06-24 02:27:57.893924
# Unit test for function is_camel_case
def test_is_camel_case():
	assert is_camel_case(None) is False
	assert is_camel_case('') is False
	assert is_camel_case(' ') is False
	assert is_camel_case('1') is False
	assert is_camel_case('1123') is False
	assert is_camel_case('TestString') is True
	assert is_camel_case('TestString1') is True
	assert is_camel_case('Test1String1') is True
	assert is_camel_case('testString') is False
	assert is_camel_case('test') is False

# private function to recognize a snake case string

# Generated at 2022-06-24 02:28:05.181068
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid(str(uuid.uuid4()))
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf')
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf', True)
    assert not is_uuid('6f8aa2f9686c4ac387665712354a04cf')
    assert not is_uuid(12345678)



# Generated at 2022-06-24 02:28:13.709490
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('this-is-a-slug', '-') == True
    assert is_slug('this--is-a-slug', '-') == False
    assert is_slug('--screaming-snake--case', '_') == False
    assert is_slug('a-snake-case-string', '_') == False
    assert is_slug('this-is-a-slug') == True
    assert is_slug('this is a slug') == False
    assert is_slug('this_is_a_slug') == False
    assert is_slug('this-is-a-slug', ' ') == False
    assert is_slug('this-is-a-slug-', '-') == False
    assert is_slug('123', '-')

# Generated at 2022-06-24 02:28:24.468545
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert(__ISBNChecker("9780134685991").is_isbn_13()==True)
    assert(__ISBNChecker("978-0-13-468599-1").is_isbn_13()==True)
    assert(__ISBNChecker("978-0134685991").is_isbn_13()==True)
    assert(__ISBNChecker("9780134685990").is_isbn_13()==False)
    assert(__ISBNChecker("978-0-13-468599-2").is_isbn_13()==False)
    assert(__ISBNChecker("978-0134685992").is_isbn_13()==False)
    assert(__ISBNChecker("abcdefghijkl").is_isbn_13()==False)
   

# Generated at 2022-06-24 02:28:29.807430
# Unit test for function is_snake_case
def test_is_snake_case():
    assert not is_snake_case('foo')
    assert not is_snake_case('fooBar')
    assert not is_snake_case('FooBar')
    assert not is_snake_case('')
    assert not is_snake_case('FooBaz baz')
    assert not is_snake_case('foo bar baz')
    assert not is_snake_case('foo bar baz')
    assert is_snake_case('foo_bar')
    assert is_snake_case('foo_bar')
    assert is_snake_case('foo3_baz_bar')
    assert is_snake_case('foo-bar')
    assert is_snake_case('foo_bar')
    assert is_snake_case('foo3_baz_bar')

# Generated at 2022-06-24 02:28:35.466350
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') == True
    assert is_isbn('978-0312498580') == True
    assert is_isbn('1506715214') == True
    assert is_isbn('150-6715214') == True
    assert is_isbn('978-0312498580', normalize=False) == False
    assert is_isbn('150-6715214', normalize=False) == False



# Generated at 2022-06-24 02:28:47.696800
# Unit test for function is_snake_case
def test_is_snake_case():
    assert (is_snake_case('camel_case') == True)
    assert (is_snake_case('Pascal_case') == True)
    assert (is_snake_case('Snake_case_with_another_separator-') == True)
    assert (is_snake_case('CONSTANT_CASE') == True)
    assert (is_snake_case('snake_case_with_number_123') == True)
    assert (is_snake_case('snake_case_with_number_123') == True)

    assert (is_snake_case('snake_case_with_space ') == False)
    assert (is_snake_case('snake_case_with_unsupported_separator.') == False)

# Generated at 2022-06-24 02:28:48.638627
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('my string is <strong>bold</strong>')
    assert not contains_html('my string is not bold')


# Generated at 2022-06-24 02:29:01.500480
# Unit test for function is_json
def test_is_json():
    assert not is_json(None)
    assert not is_json('')
    assert not is_json('{nope}')
    assert not is_json('1')
    assert not is_json('42')
    assert not is_json('"hello"')
    assert not is_json('["hello"]')
    assert not is_json('{"hello"}')
    assert not is_json('{hello: "world"}')
    assert is_json('{}')
    assert is_json('[]')
    assert is_json('["hello", "world"]')
    assert is_json('{"hello": "world"}')
    assert is_json('"hello"')
    assert is_json('[1, 2, 3]')
    assert is_json('{"name": "George", "surname": "Johnson"}')



# Generated at 2022-06-24 02:29:09.742948
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal("0.32") == True
    assert is_decimal("12.32") == True
    assert is_decimal("-12.32") == True
    assert is_decimal("12.32E-02") == True
    assert is_decimal("12.3E+0") == False
    assert is_decimal("12.32E-02") == True
    
    



# Generated at 2022-06-24 02:29:16.445312
# Unit test for function is_json
def test_is_json():
    assert is_json('{ "name" : "Peter" }') == True
    assert is_json('{"name": "Peter"}') == True
    assert is_json('[1, 2, 3]') == True
    assert is_json('{nope}') == False
    assert is_json('') == False


# Generated at 2022-06-24 02:29:18.061559
# Unit test for function is_string
def test_is_string():
    assert is_string('foo')
    assert not is_string(b'foo')
test_is_string()



# Generated at 2022-06-24 02:29:29.559623
# Unit test for function is_palindrome
def test_is_palindrome():
    # this is the standard palindrome check
    assert is_palindrome('otto')
    # this is a palindrome without spaces
    assert is_palindrome('iotopinonavevanonipoti')
    # this is a palindrome with spaces, but any sequence of space is considered as a single space
    assert is_palindrome('i topi non avevano nipoti')
    # this is a palindrome with spaces but with different sequence of spaces
    assert is_palindrome('i    topi  non    avevano nipoti')
    # none of the 3 previous strings are palindrome if strict=True
    assert not is_palindrome('otto', ignore_spaces=True)
    assert not is_palindrome('iotopinonavevanonipoti', ignore_spaces=True)

# Generated at 2022-06-24 02:29:30.927104
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('42.0') == True
    assert is_decimal('42') == False
    


# Generated at 2022-06-24 02:29:37.592775
# Unit test for function is_isbn_13
def test_is_isbn_13():
    examples = ['978-1-56619-909-4', '978-0-306-40615-7', '978-0-9752298-0-X']
    examples += ['978-0-9752298-0-X', '978-1-56619-909-4', '978-0-306-40615-7']
    examples += ['978-0-30640615-7', '978-0-306-40615-7', '978-0-306-40615-7']

    for example in examples:
        assert(is_isbn_13(example))


# Generated at 2022-06-24 02:29:45.392748
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    assert __ISBNChecker('978-3-16-148410-0').is_isbn_13()
    assert not __ISBNChecker('978-3-16-148410-0').is_isbn_10()

    assert __ISBNChecker('0-684-84328-5', normalize=False).is_isbn_10()
    assert not __ISBNChecker('0-684-84328-5', normalize=False).is_isbn_13()


# PUBLIC API

