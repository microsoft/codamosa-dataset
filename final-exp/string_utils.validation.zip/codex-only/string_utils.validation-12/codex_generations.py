

# Generated at 2022-06-24 02:19:43.027805
# Unit test for function is_palindrome
def test_is_palindrome():
    print("test_is_palindrome")
    assert is_palindrome("LOL")
    assert not is_palindrome("Lol")
    assert is_palindrome("Lol", ignore_case=True)
    assert not is_palindrome("ROTFL")


if __name__ == "__main__":
    test_is_palindrome()



# Generated at 2022-06-24 02:19:50.288896
# Unit test for function is_email
def test_is_email():
    import os
    import sys
    sys.path.append(os.path.dirname(sys.modules[__name__].__file__))
    import email_lists

    for email in email_lists.VALID_EMAILS:
        assert is_email(email)

    for email in email_lists.INVALID_EMAILS:
        assert not(is_email(email))

    for email in email_lists.BORDERLINE_CASES:
        assert is_email(email)



# Generated at 2022-06-24 02:19:57.134884
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('MyString')
    assert not is_camel_case(1234)
    assert not is_camel_case('mystring')
    assert not is_camel_case('1String')
    assert not is_camel_case('my_string')
    assert not is_camel_case('my-string')



# Generated at 2022-06-24 02:20:02.936025
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com') == True
    assert is_email('@gmail.com') == False
    
test_is_email()

print("Function is_email() has passed test.")


# Generated at 2022-06-24 02:20:04.001114
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580') == True



# Generated at 2022-06-24 02:20:13.063388
# Unit test for function words_count
def test_words_count():
    assert words_count('hello') == 1
    assert words_count('hello world') == 2
    assert words_count('my name is') == 3
    assert words_count('my,name,is') == 3
    assert words_count('my name is peter') == 5
    assert words_count('my.name.is.peter') == 5
    assert words_count('1 2 3') == 3
    assert words_count('1,2,3') == 3
    assert words_count('1.2.3') == 3
    assert words_count('my name is 123') == 5
    assert words_count('my name is 123.test') == 6
    assert words_count('empty') == 1
    assert words_count('') == 0
    assert words_count(None) == 0
# Test is_string

# Generated at 2022-06-24 02:20:24.615428
# Unit test for function is_snake_case
def test_is_snake_case():
    assert not is_snake_case('hello')
    assert is_snake_case('hello_world')
    assert is_snake_case('hello_world', '_')
    assert not is_snake_case('hello_world', '-')
    assert is_snake_case('foo-bar')
    assert is_snake_case('foo-bar', '-')
    assert is_snake_case('foo_bar', '-')
    assert not is_snake_case('foo_bar-baz')
    assert not is_snake_case('foo_bar_baz')
    assert not is_snake_case('foo_bar_baz', '-')
    assert is_snake_case('_bar_baz')

# Generated at 2022-06-24 02:20:32.096915
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4444444444444448') is True # Visa
    assert is_credit_card('5555555555554444') is True # Mastercard
    assert is_credit_card('378282246310005') is True # American Express
    assert is_credit_card('30569309025904') is True # Diners Club
    assert is_credit_card('6011111111111117') is True # Discover
    assert is_credit_card('3530111333300000') is True # JCB
    assert is_credit_card('4111111111111111') is False # Unknown
    assert is_credit_card('4111111111111111', 'VISA') is True
    assert is_credit_card('4111111111111111', 'MASTERCARD') is False

# Generated at 2022-06-24 02:20:34.541714
# Unit test for function is_json
def test_is_json():
    assert is_json('{"name": "Peter"}')
    assert is_json('[1, 2, 3]')
    assert not is_json('{nope}')
    assert not is_json('nope')
    assert not is_json('{a:b}')
    assert not is_json('{"k":[]}')
    assert not is_json('{"k":[222]}')

# test_is_json()



# Generated at 2022-06-24 02:20:36.241800
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn_13('9780312498580') == True
    assert is_isbn_10('1506715214') == True


# Generated at 2022-06-24 02:20:48.090997
# Unit test for function is_number
def test_is_number():
    assert is_number('') == False
    assert is_number(None) == False
    assert is_number('42') == True
    assert is_number('19.99') == True
    assert is_number('-9.12') == True
    assert is_number('1e3') == True
    assert is_number('1 2 3') == False
    assert is_number('-1 2 3') == False
    assert is_number('-1.1 2 3') == False
    assert is_number('+1e5') == True
    assert is_number('+1') == True
    assert is_number('+1.2') == True
    assert is_number('-2') == True
    assert is_number('-2.5') == True
    assert is_number('-1e5') == True



# Generated at 2022-06-24 02:20:55.888430
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('MyString')
    assert not is_camel_case('mystring')
    assert not is_camel_case('my_string')
    assert not is_camel_case('')
    assert not is_camel_case(' ')
    assert is_camel_case('My1String')
    assert not is_camel_case('1MyString')



# Generated at 2022-06-24 02:20:57.845997
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title') is True
    assert is_slug('My blog post title') is False
    assert is_slug('my_blog_post_title', separator='_') is True
    assert is_slug('my_blog_post_title') is False

# Generated at 2022-06-24 02:21:01.918089
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42') == True
    assert is_integer('42.0') == False


# Generated at 2022-06-24 02:21:08.162256
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('dermatoglyphics') == True
    assert is_isogram('isogram') == True
    assert is_isogram('aba') == False
    assert is_isogram('moOse') == False
    assert is_isogram('isIsogram') == False
    assert is_isogram('') == True
test_is_isogram()


# Generated at 2022-06-24 02:21:12.808595
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('0312498580')
    assert is_isbn('0-312-498580')
    assert is_isbn('0-312-498580', True)
    assert is_isbn('0-312-498580', True)
    assert is_isbn('0-312-498580', False) == False
    assert is_isbn('9780312498580')
    assert is_isbn('978-0-312-498580')
    assert is_isbn('978-0-312-498580', True)
    assert is_isbn('978-0-312-498580', True)
    assert is_isbn('978-0312498580') == False
    assert is_isbn('978-0312498580', True)
    assert is_

# Generated at 2022-06-24 02:21:13.464813
# Unit test for function is_pangram
def test_is_pangram():
	assert is_pangram('The quick brown fox jumps over the lazy dog') == True

# Generated at 2022-06-24 02:21:15.739750
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') == True
    assert is_url('https://mysite.com') == True
    assert is_url('.mysite.com') == False

# Generated at 2022-06-24 02:21:22.642089
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('LOL')
    assert is_palindrome('Lol', ignore_case=True)
    assert is_palindrome('ROTFL', ignore_case=True)
    assert is_palindrome('I topi non avevano nipoti', ignore_spaces=True, ignore_case=True)
    assert is_palindrome('A man, a plan, a canal: Panama', ignore_spaces=True, ignore_case=True)
    assert is_palindrome('Amore, Roma')
    assert is_palindrome('nobodybno')
    assert is_palindrome('no bod\'y bno')
    assert is_palindrome(' abcdedcba ')
    assert is_palindrome(123321)

# Generated at 2022-06-24 02:21:32.412116
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('<strong>This string</strong>') is True
    assert contains_html('This string') is False
    assert contains_html('') is False
    assert contains_html('<p>This string</p><p>This string</p>') is True
    assert contains_html('<img src="images/logo.png" alt="Logo" style="border: 0;" />') is True
    assert contains_html('<p>This string</p><img src="images/logo.png" alt="Logo" style="border: 0;" />') is True
    assert contains_html('<p>This string<i>this string</i></p>') is True
    assert contains_html('<p>This string<i>this string<b>this</b></i></p><p>This string</p>')

# Generated at 2022-06-24 02:21:40.839896
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4716137046032420')
    assert is_credit_card('4716 1370 4603 2420')
    assert is_credit_card('5301 0103 0531 0098')
    assert is_credit_card('5301010310310198')
    assert is_credit_card('6011523441233756')
    assert is_credit_card('6011523441012756')
    assert is_credit_card('6011523441012756')
    assert is_credit_card('6011523441012756')
    assert is_credit_card('3566002020360505')
    assert is_credit_card('3566002020360505')
    assert is_credit_card('3566002020360505')

# Generated at 2022-06-24 02:21:49.428309
# Unit test for function is_decimal
def test_is_decimal():
    class Test:
        def __init__(self, input_string: str, result: bool):
            self.input_string = input_string
            self.result = result
    tests = [
        Test('42.0', True),
        Test('42', False)
    ]
    for test in tests:
        if is_decimal(test.input_string) != test.result:
            print(test.input_string)
            raise Exception(f"{test.input_string} is not a decimal")
test_is_decimal()



# Generated at 2022-06-24 02:21:51.796961
# Unit test for function is_email
def test_is_email():
    assert is_email('my.email@the-provider.com')
    assert not is_email('@gmail.com')



# Generated at 2022-06-24 02:22:02.400854
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('Dermatoglyphics') == True
    assert is_isogram('isogram') == True
    assert is_isogram('moose') == False
    assert is_isogram('isIsogram') == False
    assert is_isogram('aba') == False
    assert is_isogram('moOse') == False
    assert is_isogram('thumbscrewjapingly') == True
    assert is_isogram('thumbscrew-japingly') == True
    assert is_isogram('six-year-old') == True
    assert is_isogram('Emily Jung Schwartzkopf') == True
    assert is_isogram('accentor') == False
    assert is_isogram('angola') == False
    assert is_isogram('Angola') == False
test_is_isogram()

# Generated at 2022-06-24 02:22:04.410993
# Unit test for function words_count
def test_words_count():
    assert words_count('hello world') == 2
    assert words_count('one two three') == 3
    assert words_count('one,two,three.stop') == 4
    assert words_count('! @ # % ... []') == 0
    assert words_count('') == 0
test_words_count()



# Generated at 2022-06-24 02:22:13.214602
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case("foo_bar")
    assert is_snake_case("foo-bar_baz")
    assert is_snake_case("foo-bar-baz", '-')
    assert not is_snake_case("foo_bar_")
    assert not is_snake_case("_foo_bar")
    assert not is_snake_case("_u_foo_bar")
    assert not is_snake_case("foo_1bar")
    assert not is_snake_case("foo bar")



# Generated at 2022-06-24 02:22:18.247474
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('1234567890')
    assert is_integer('+123')
    assert is_integer('-456')
    assert is_integer('+789')
    assert is_integer('999')
    assert is_integer('+101112')
    assert is_integer('-121314')
    assert is_integer('151617')



# Generated at 2022-06-24 02:22:24.062567
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0-306-40615-2').is_isbn_10()
    assert __ISBNChecker('0306406152').is_isbn_10()
    assert not __ISBNChecker('0306406153').is_isbn_10()


# PUBLIC API


# STRING API



# Generated at 2022-06-24 02:22:25.482042
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') == True
    assert is_isbn_10('150-6715214') == True
    assert is_isbn_10('150-6715214', normalize=False) == False


# Generated at 2022-06-24 02:22:31.606529
# Unit test for function is_ip_v6
def test_is_ip_v6():
    # setup
    ip6 = '2001:db8:85a3:0:0:8a2e:370:7334'

    # run
    result = is_ip_v6(ip6)

    # assert
    assert result == True


# Generated at 2022-06-24 02:22:37.761317
# Unit test for function is_ip_v6
def test_is_ip_v6():
    s = '2001:db8:85a3:0000:0000:8a2e:370:7334'
    # runs test
    assert is_ip_v6(s)
    # check that it's not valid v6 if we add a char
    assert not is_ip_v6(s + '?')



# Generated at 2022-06-24 02:22:39.840374
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42')
    assert is_integer('4200')
    assert not is_integer('4.2')
    assert not is_integer('42.0')


# Generated at 2022-06-24 02:22:48.691369
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    # with invalid input string
    # IMPORTANT: no need to test outside of the constructor
    # since it's private and won't be called outside this file
    try:
        __ISBNChecker(1234)
        assert False
    except InvalidInputError:
        assert True

    # isbn 13
    assert __ISBNChecker('978-1-56619-909-4').is_isbn_13()
    assert __ISBNChecker('9791091140001').is_isbn_13()
    assert __ISBNChecker('9781566199094').is_isbn_13()
    assert __ISBNChecker('9781566199094').is_isbn_13()
    # not isbn 13

# Generated at 2022-06-24 02:23:00.122186
# Unit test for constructor of class __ISBNChecker

# Generated at 2022-06-24 02:23:08.775532
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    try:
        __ISBNChecker("")
        assert False
    except InvalidInputError:
        assert True

    assert __ISBNChecker("978-1-56619-909-4", normalize=False).input_string == "978-1-56619-909-4"
    assert __ISBNChecker("978-1-56619-909-4", normalize=True).input_string == "9781566199094"

    assert __ISBNChecker("9781566199094").input_string == "9781566199094"
    assert __ISBNChecker("9781566199094").is_isbn_13()
    assert not __ISBNChecker("9781566199094").is_isbn_10()


# Generated at 2022-06-24 02:23:18.079105
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com')
    assert is_url('https://mysite.com')
    assert is_url('http://mysite.com')
    assert is_url('http://192.168.1.1')
    assert not is_url('.mysite.com')
    assert not is_url('http:///mysite.com')
    assert not is_url('http://mysite.com/')
    assert not is_url('http://www.mysite')
    assert not is_url('http://mysite')
    assert not is_url(None)
    assert not is_url('mysite.com')
    assert not is_url('www.mysite.com')



# Generated at 2022-06-24 02:23:20.327835
# Unit test for function words_count
def test_words_count():
    words = [
        'uno, due, tre ... dov\'e il quattro?',
        'uno   due   tre',
        'uno.  due.  tre, stop!',
        'a',
        'a b',
        'a 1',
    ]

    for word in words:
        assert words_count(word) == 4



# Generated at 2022-06-24 02:23:28.202850
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('dermatoglyphics') is True
    assert is_slug('Slug') is True
    assert is_slug('hello@world.com') is False
    assert is_slug('hello.world') is False
    assert is_slug('hello world') is False
    assert is_slug('hello-world') is True
    assert is_slug('hello-world-') is False
    assert is_slug('hello world-') is False
    assert is_slug('hello world--') is False
    assert is_slug('hello--world') is False
    assert is_slug('hello--world--') is False
    assert is_slug('hello@world') is False



# Generated at 2022-06-24 02:23:31.367145
# Unit test for function is_json
def test_is_json():
    # TODO:
    # test for invalid json (broken opening/closing brackets)
    pass



# Generated at 2022-06-24 02:23:35.718969
# Unit test for function is_pangram
def test_is_pangram():
    assert is_pangram('The quick brown fox jumps over the lazy dog')
    assert not is_pangram('hello world')

is_pangram = test_is_pangram()


# Generated at 2022-06-24 02:23:40.540109
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    a = __ISBNChecker('0306406152')
    assert a.is_isbn_10() == True
a = __ISBNChecker('0306406152')
assert a.is_isbn_10() == True

# Generated at 2022-06-24 02:23:42.661221
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') == True
    assert is_isbn('1506715214') == True



# Generated at 2022-06-24 02:23:45.416259
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    assert __ISBNChecker('2423542221').is_isbn_10()
    assert __ISBNChecker('978-3-16-148410-0').is_isbn_13()

# PUBLIC API



# Generated at 2022-06-24 02:23:51.736984
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('123') == True
    assert is_integer('123.0') == False
    assert is_integer('.0') == False
    assert is_integer('.') == False
    assert is_integer('1e5') == True
    assert is_integer('0') == True
    assert is_integer('-1234') == True
    assert is_integer('+1234') == True



# Generated at 2022-06-24 02:23:56.073686
# Unit test for function is_number
def test_is_number():
    assert is_number('42')
    assert is_number('19.99')
    assert is_number('-9.12')
    assert is_number('1e3')
    assert not is_number('1 2 3')


# Generated at 2022-06-24 02:24:00.719503
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('Dermatoglyphics') == True
    assert is_isogram('isogram') == True
    assert is_isogram('aba') == False
    assert is_isogram('moOse') == False
    assert is_isogram('isIsogram') == False
    assert is_isogram('') == True



# Generated at 2022-06-24 02:24:02.666775
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal("42.0") == True
    assert is_decimal("42") == False


# Generated at 2022-06-24 02:24:12.881376
# Unit test for function is_palindrome
def test_is_palindrome():
    assert(is_palindrome("abc") == False)
    assert(is_palindrome("abcba") == True)
    assert(is_palindrome("abcab") == False)
    assert(is_palindrome("") == False)
    assert(is_palindrome("A B C ") == True)
    assert(is_palindrome(" A B c ") == False)
    assert(is_palindrome("A B C ", ignore_spaces=True) == True)
    assert(is_palindrome(" A B c ", ignore_spaces=True) == True)
    assert(is_palindrome("A B C ", ignore_case=True) == True)
    assert(is_palindrome(" A B c ", ignore_case=True) == True)

# Generated at 2022-06-24 02:24:23.895538
# Unit test for function is_snake_case
def test_is_snake_case():
    assert(is_snake_case('foo_bar_baz') == True)
    assert(is_snake_case('foo_bar_baz') == True)
    assert(is_snake_case('foo_bar-baz') == False)
    assert(is_snake_case('foo_bar-baz', separator = '-') == True)
    assert(is_snake_case('foo') == False)
    assert(is_snake_case('foo-') == False)
    assert(is_snake_case('foo-', separator = '-') == True)
    assert(is_snake_case('-foo') == False)
    assert(is_snake_case('-foo', separator = '-') == True)

# Generated at 2022-06-24 02:24:30.428824
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('foo_bar_baz')
    assert is_snake_case('foo-bar-baz')
    assert is_snake_case('foo-bar_baz-FOO')
    assert not is_snake_case('foo')
    assert not is_snake_case('1_foo')
    assert not is_snake_case('foo_bar_baz_')
    assert is_snake_case('foo-bar-baz-', separator='-')


# Generated at 2022-06-24 02:24:41.705550
# Unit test for function is_url
def test_is_url():
    # url with allowed schemes
    assert is_url('http://mysite.com', allowed_schemes=['http'])

    # url with not allowed schemes
    assert not is_url('https://mysite.com', allowed_schemes=['http'])
    assert not is_url('mailto:test@test.com', allowed_schemes=['http'])

    # url without scheme
    assert not is_url('test')

    # url with scheme
    assert is_url('http://www.stackoverflow.com')
    assert is_url('https://www.stackoverflow.com')
    assert is_url('ftp://ftp.stackoverflow.com')
    assert is_url('http://stackoverflow.com')

    # url with username and password

# Generated at 2022-06-24 02:24:53.404589
# Unit test for function words_count
def test_words_count():
    assert words_count("one, two. Three. Four, 5") == 5
    assert words_count("one, two. Three. Four, 5.") == 5
    assert words_count("one, two. Three. Four and five, 5") == 8
    assert words_count("24 word 45 and 19") == 4
    assert words_count("24 word 45 and 19.") == 4
    assert words_count("one, two. Three. Four and five, 5.") == 8
    assert words_count("тисяч десять one, two. Three. Four and five, 5.") == 10
    assert words_count("123456789_qwertyuiopasdfghjkl;'zxcvbnm ASDFGHJKLZXCVBNMQWERTYUIOP{}|:<>?") == 2

# Generated at 2022-06-24 02:25:00.419325
# Unit test for function is_uuid
def test_is_uuid():

    assert is_uuid('86f7e437-faa5-9298-8d57-5a73f5a5bfb7') == True
    assert is_uuid('45F974D5-8BF5-42E5-AAD5-5F3E873C3A0F') == True
    assert is_uuid('f7ac94d1fb940ecb84c8d262602a2f00') == False
    assert is_uuid('F7AC94D1FB940ECB84C8D262602A2F00') == False
    assert is_uuid('f7ac94d1fb940ecb84c8d262602a2f00',True) == True

# Generated at 2022-06-24 02:25:02.690915
# Unit test for function is_full_string
def test_is_full_string():
    assert not is_full_string(None)
    assert not is_full_string('')
    assert not is_full_string(' ')
    assert is_full_string('non empty')


# Generated at 2022-06-24 02:25:08.803786
# Unit test for function is_palindrome
def test_is_palindrome():
    # is_palindrome() tests
    assert is_palindrome('i topi non avevano nipoti')
    assert is_palindrome('i topi non avevano nipoti', ignore_spaces=True)
    assert not is_palindrome('i topi non avevano nipoti', ignore_case=True)
    assert is_palindrome('ABCDEDCBA')
    assert not is_palindrome('ABCDEDCB')
    assert is_palindrome('A man, a plan, a canal, Panama!')
    assert is_palindrome('A man, a plan, a canal, Panama!', ignore_spaces=True)
    assert not is_palindrome('A man, a plan, a canal, Panama!', ignore_case=True)
    assert not is_

# Generated at 2022-06-24 02:25:14.160317
# Unit test for function is_isbn_13
def test_is_isbn_13():
    # Assert the given string is a valid ISBN 13 number
    assert is_isbn_13('9780312498580') == True
    assert is_isbn_13('978-0312498580') == True
    assert is_isbn_13('978-0312498580', normalize=False) == False


# Generated at 2022-06-24 02:25:17.189829
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('1234567891011').is_isbn_13()
    assert not __ISBNChecker('123456789101').is_isbn_13()



# Generated at 2022-06-24 02:25:22.065771
# Unit test for function is_full_string
def test_is_full_string():
    # Variable storing all possible arguments and expected results
    possible_args_results = [
        (None, False),
        ('', False),
        (' ', False),
        ('hello', True),
    ]

    # Check every possible argument/expected result
    for arg, expected_result in possible_args_results:
        if is_full_string(arg) != expected_result:
            return False

    # All tests passed
    return True



# Generated at 2022-06-24 02:25:24.310987
# Unit test for function is_email
def test_is_email():
    assert is_email("my.email@the-provider.com") is True
    assert is_email("@gmail.com") is False


# Generated at 2022-06-24 02:25:29.459492
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') == True
    assert is_isbn_10('150-6715214') == True



# Generated at 2022-06-24 02:25:37.492923
# Unit test for function is_full_string
def test_is_full_string():
    assert not is_full_string(None)
    assert not is_full_string("")
    assert not is_full_string(" ")
    assert not is_full_string("\t")
    assert not is_full_string("\n")
    assert is_full_string("hello")
    assert not is_full_string("hello ")
    assert is_full_string("hello world !")
    assert is_full_string("  hello world  ")



# Generated at 2022-06-24 02:25:48.335979
# Unit test for function is_uuid
def test_is_uuid():
    f = is_uuid
    # examples taken from http://stackoverflow.com/a/19875304


# Generated at 2022-06-24 02:25:51.998661
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') == True
    assert is_isbn_10('150-6715214') == True
    assert is_isbn_10('150-6715214', normalize=False) == False
test_is_isbn_10()



# Generated at 2022-06-24 02:25:54.881283
# Unit test for function is_isbn_13
def test_is_isbn_13():
    assert is_isbn_13('9780312498580') == True
    assert is_isbn_13('978-0312498580') == True
    assert is_isbn_13('978-0312498580', normalize=False) == False



# Generated at 2022-06-24 02:26:06.562071
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('LOL')
    assert not is_palindrome('Lol')
    assert is_palindrome('Lol', ignore_case=True)
    assert not is_palindrome('ROTFL')
    assert is_palindrome('ROTFL', ignore_case=True)
    assert is_palindrome('i topi non avevano nipoti', ignore_spaces=True)
    assert is_palindrome('i topi non avevano nipoti', ignore_spaces=True, ignore_case=True)
# Unit tests

# Generated at 2022-06-24 02:26:13.559352
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4444444444444448', 'VISA')
    assert not is_credit_card('4444444444444448', 'AMERICAN_EXPRESS')
    assert is_credit_card('4444444444444448', 'MasterCard')
    assert is_credit_card('4444444444444448')
    assert not is_credit_card('44444444444444444448')
    assert not is_credit_card('')
    assert not is_credit_card(' ')
    assert not is_credit_card(None)
    assert not is_credit_card(23)



# Generated at 2022-06-24 02:26:24.295590
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('dermatoglyphics') == True
    assert is_isogram('isogram') == True
    assert is_isogram('moose') == False
    assert is_isogram('isIsogram') == False
    assert is_isogram('aba') == False
    assert is_isogram('moOse') == False
    assert is_isogram('thumbscrewjapingly') == True
    assert is_isogram('dermatoglyphics') == True
    assert is_isogram('isogram') == True
    assert is_isogram('isogram') == True
    assert is_isogram('moose') == False
    assert is_isogram('isIsogram') == False
    assert is_isogram('aba') == False
    assert is_isogram('moOse') == False
    assert is_

# Generated at 2022-06-24 02:26:29.730146
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string(None) == False
    assert is_full_string('') == False
    assert is_full_string(' ') == False
    assert is_full_string('hello') == True
    assert is_full_string(123) == False



# Generated at 2022-06-24 02:26:33.836282
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42') == True
    assert is_integer('42.0') == False
test_is_integer()



# Generated at 2022-06-24 02:26:37.154536
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title') == True
    assert is_slug('My blog post title') == False
    assert is_slug('my_blog_post_title') == True
    assert is_slug('My blog post title', separator='_') == False
test_is_slug()


# Generated at 2022-06-24 02:26:46.166878
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    checker = __ISBNChecker('1782161076')
    assert checker.is_isbn_10() == True
    checker = __ISBNChecker('9781782161079')
    assert checker.is_isbn_10() == False
    checker = __ISBNChecker('178216107')
    assert checker.is_isbn_10() == False
    checker = __ISBNChecker('9781')
    assert checker.is_isbn_10() == False
    checker = __ISBNChecker('978178216107')
    assert checker.is_isbn_10() == False
    checker = __ISBNChecker('9781782161071')
    assert checker.is_isbn_10() == False

test___ISBNChecker_is

# Generated at 2022-06-24 02:26:54.338046
# Unit test for function is_isbn
def test_is_isbn():
    # positive cases
    assert is_isbn('9780312498580') == True
    assert is_isbn('1506715214') == True
    assert is_isbn('978-0312498580') == True
    assert is_isbn('150-6715214') == True
    
    
    # negative cases
    assert is_isbn('9780312498580', normalize=False) == False
    assert is_isbn('1506715214', normalize=False) == False
    assert is_isbn('978-0312498580', normalize=False) == False
    assert is_isbn('150-6715214', normalize=False) == False
    assert is_isbn('15067 15214') == False
    assert is_isbn('1506715214 8') == False

# Generated at 2022-06-24 02:27:01.457384
# Unit test for function is_camel_case
def test_is_camel_case():
    assert(is_camel_case('MyString'))
    assert(not is_camel_case('mystring'))
    assert(not is_camel_case('2String'))
    assert(is_camel_case('ASDFG'))
    assert(is_camel_case('AsdfG'))
    assert(is_camel_case('aSdfG'))
    assert(not is_camel_case('abc'))
    assert(not is_camel_case('ABC'))
    assert(not is_camel_case('aBc'))
    assert(not is_camel_case(''))
    assert(not is_camel_case(None))
    assert(not is_camel_case(' '))

# Generated at 2022-06-24 02:27:11.066489
# Unit test for function is_string
def test_is_string():
    obj = '1234'
    assert is_string(obj) == True
    obj = "abcd"
    assert is_string(obj) == True
    obj = 'abc@gmail.com'
    assert is_string(obj) == True
    obj = "ab_cd"
    assert is_string(obj) == True
    obj = '_ab_cd'
    assert is_string(obj) == True
    obj = '''ab_cd
            abc _xyz'''
    assert is_string(obj) == True

    assert is_string(1234) == False
    assert is_string(123.1234) == False
    assert is_string(None) == False
    assert is_string((1,2,3,4)) == False

# Generated at 2022-06-24 02:27:16.617143
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    assert __ISBNChecker('9784873115201').input_string == '9784873115201'
    assert __ISBNChecker('978-487311-520-1').input_string == '9784873115201'
    assert __ISBNChecker('978-487311-520-1', normalize=False).input_string == '978-487311-520-1'
    try:
        __ISBNChecker(114514)
    except InvalidInputError:
        pass
    else:
        assert False


# Generated at 2022-06-24 02:27:26.585521
# Unit test for function is_json
def test_is_json():
    assert is_json('{}') is True
    assert is_json('[]') is True
    assert is_json('{"a":1}') is True
    assert is_json('{"a":[]}') is True
    assert is_json('{"a":{"b":2}}') is True
    assert is_json('{"a":[1,2,3]}') is True
    assert is_json('{"a":[1,{"b":[2,3]}]}') is True
    assert is_json('[1,2,3]') is True
    assert is_json('[1,[2,3]]') is True
    assert is_json('["a"]') is True
    assert is_json('{"a":"b"}') is True
    assert is_json('{"a":null}') is True

# Generated at 2022-06-24 02:27:35.934679
# Unit test for function is_palindrome
def test_is_palindrome():
    palindromes = ['otto', 'i topi non avevano nipoti', 'abba', 'radar', '010', '0', 'a', '_', '']
    for palindrome in palindromes:
        assert(is_palindrome(palindrome) == True), "Failed for palindrome: " + palindrome
    not_palindromes = ['radad', 'radar.', '0123456789', 'aBba']
    for not_palindrome in not_palindromes:
        assert(is_palindrome(not_palindrome) == False), "Failed for not palindrome: " + not_palindrome

    # Test ignore spaces case

# Generated at 2022-06-24 02:27:41.658884
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    checker = __ISBNChecker('isbn10-0123456789')
    assert checker.is_isbn_10()

    checker = __ISBNChecker('isbn13-1234567890123')
    assert checker.is_isbn_13()

# public API


# Generated at 2022-06-24 02:27:44.673219
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') == True
    assert is_isbn('1506715214') == True
# Importing the unittest module
import unittest

# Creating a class for the unit test

# Generated at 2022-06-24 02:27:49.552568
# Unit test for function is_slug
def test_is_slug():
    assert is_slug("my-blog-post-title") == True
    assert is_slug("My blog post title") == False
    assert is_slug("my - blog post title") == False
    assert is_slug("my.blog.post.title") == True
    assert is_slug("my.blog.post.title",separator='.') == True
    assert is_slug("my.blog.post.title",separator='!') == False


# Generated at 2022-06-24 02:27:57.492772
# Unit test for function is_palindrome
def test_is_palindrome():

    assert is_palindrome('otto')
    assert is_palindrome('i topi non avevano nipoti')
    assert is_palindrome('laval', ignore_spaces=True)
    assert is_palindrome('ROTFL', ignore_case=True)
    assert not is_palindrome('ROTFL')
    assert not is_palindrome('something')
    assert not is_palindrome('i topi avevano nipoti')
    assert not is_palindrome('laval')


# Generated at 2022-06-24 02:28:06.172204
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') 
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf',allow_hex=True)
    assert not is_uuid('6f8aa2f9686c4ac387665712354a04cf')
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf',allow_hex=True)
    assert not is_uuid(None)


# Generated at 2022-06-24 02:28:14.630757
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    checker = __ISBNChecker(input_string='978-1-63353-632-5')
    assert(checker.is_isbn_13())
    checker = __ISBNChecker(input_string='1234567890123')
    assert(not checker.is_isbn_13())
    checker = __ISBNChecker(input_string='12345678901234')
    assert(not checker.is_isbn_13())
    checker = __ISBNChecker(input_string='1234567890123')
    assert(not checker.is_isbn_13())

# Generated at 2022-06-24 02:28:18.685030
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string(None) is False
    assert is_full_string('') is False
    assert is_full_string(' ') is False
    assert is_full_string('hello')



# Generated at 2022-06-24 02:28:24.608034
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    checker = __ISBNChecker(input_string="978-3-12-732320-7")
    print(checker.input_string)
    assert checker.is_isbn_13()

test___ISBNChecker_is_isbn_13()


# PUBLIC API



# Generated at 2022-06-24 02:28:32.223251
# Unit test for function is_pangram
def test_is_pangram():
    assert not is_pangram('The quick brown dog jumps over the lazy fox')
    assert not is_pangram('hello world')
    assert is_pangram('The quick brown fox jumps over the lazy dog')
    assert is_pangram('Pack my box with five dozen liquor jugs')


# Generated at 2022-06-24 02:28:33.721502
# Unit test for function is_isbn
def test_is_isbn():
    assert is_isbn('9780312498580') == True
    assert is_isbn('1506715214') == True
    assert is_isbn('150-6715214') == True


# Generated at 2022-06-24 02:28:45.830864
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('my_snake_case_string') is True
    assert is_snake_case('my_snake_case_string', '_') is True
    assert is_snake_case('my-snake-case-string', '-') is True
    assert is_snake_case('my-snake_case_string', '-') is False
    assert is_snake_case('my-second-case-string', '_') is True
    assert is_snake_case('my_second_case_string', '-') is False
    assert is_snake_case('my-second-case-string-', '-') is False
    assert is_snake_case('-my-second-case-string-', '-') is False

# Generated at 2022-06-24 02:28:59.100799
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert(is_ip_v4("127.0.0.1") == True)
    assert(is_ip_v4("0.0.0.0") == True)
    assert(is_ip_v4("8.8.8.8") == True)
    assert(is_ip_v4("255.255.255.255") == True)
    assert(is_ip_v4("65535.0.0.0") == False)
    assert(is_ip_v4("255.256.255.255") == False)
    assert(is_ip_v4("255.255.255.2550") == False)
    assert(is_ip_v4("255.255.255.255.") == False)
    assert(is_ip_v4("255.255.255") == False)
   

# Generated at 2022-06-24 02:29:04.561703
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('foo_bar')
    assert is_snake_case('foo_bar_baz')
    assert is_snake_case('foo')
    assert is_snake_case('foo', '-')
    assert not is_snake_case('fooBar')
    assert not is_snake_case('fooBar', '-')
    assert not is_snake_case('_foo')
    assert not is_snake_case('foo$', '-')
    assert not is_snake_case('foo', '$')



# Generated at 2022-06-24 02:29:08.784811
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker('9780132171851').is_isbn_13() == True
    assert __ISBNChecker('9780132171852').is_isbn_13() == False

# Generated at 2022-06-24 02:29:17.796345
# Unit test for function is_number
def test_is_number():
    assert is_number("42") == True
    assert is_number("-42") == True
    assert is_number("-42.01") == True
    assert is_number("42.01") == True
    assert is_number("1e5") == True
    assert is_number("-1e5") == True
    assert is_number("-42.01e5") == True
    assert is_number("1 2 3") == False
    assert is_number("three") == False
    assert is_number("one two three") == False
    assert is_number("42a") == False
    assert is_number("") == False
    assert is_number(" ") == False
    assert is_number("five") == False
    assert is_number("hello") == False
    assert is_number("h3llo") == False
   

# Generated at 2022-06-24 02:29:21.615769
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') == true
    assert is_isbn_10('150-6715214') == true
    assert is_isbn_10('150-6715214', normalize=False) == false
    
    
    

# Generated at 2022-06-24 02:29:23.230407
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal("2.3") is True
    assert is_decimal("2") is False
    assert is_decimal("2.3.4") is False
    assert is_decimal("hello") is False
    assert is_decimal(2.3) is False



# Generated at 2022-06-24 02:29:34.253298
# Unit test for function is_email
def test_is_email():
    assert(is_email('my.email@g.com'))
    assert(is_email('m.y@gmail.com'))
    assert(is_email('my.email@the-provider.com'))
    assert(is_email('my.email@the_provider.com'))
    assert(is_email('my.email@the-provider.1.com'))
    assert(is_email('my.email@the_provider.1.com'))
    assert(is_email('my.email@the-provider.com'))
    assert(is_email('my.email@the_provider.com'))
    assert(is_email('my.email@the-provider.1.com'))

# Generated at 2022-06-24 02:29:42.118213
# Unit test for function is_full_string
def test_is_full_string():

    import pytest
    assert is_full_string(None) == False
    assert is_full_string('') == False
    assert is_full_string(' ') == False
    assert is_full_string('hello') == True
    # raise the error when input_string is not of type string
    with pytest.raises(InvalidInputError) as excinfo:
        is_full_string(123)
    assert "Invalid input: input_string parameter must be a string" == str(excinfo.value)