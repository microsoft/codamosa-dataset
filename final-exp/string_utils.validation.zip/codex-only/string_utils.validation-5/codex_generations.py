

# Generated at 2022-06-24 02:19:46.114954
# Unit test for function words_count
def test_words_count():
    assert words_count('hello world!') == 2

# Generated at 2022-06-24 02:19:48.899853
# Unit test for function is_number
def test_is_number():
    assert is_number('42')
    assert is_number('19.99')
    assert is_number('-9.12')
    assert is_number('1e3')
    assert not is_number('1 2 3')


# Generated at 2022-06-24 02:19:59.330643
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('0898452737').is_isbn_10()
    assert __ISBNChecker('0141031419').is_isbn_10()
    assert __ISBNChecker('0448451331').is_isbn_10()
    assert __ISBNChecker('1574231254').is_isbn_10()
    assert __ISBNChecker('1592400587').is_isbn_10()
    assert __ISBNChecker('0716721367').is_isbn_10()
    assert not __ISBNChecker('0716723167').is_isbn_10()
    assert not __ISBNChecker('0716720367').is_isbn_10()



# Generated at 2022-06-24 02:20:02.205307
# Unit test for function is_decimal
def test_is_decimal():
    assert(is_decimal('42.0') == True)
    assert(is_decimal('42') == False)

# Generated at 2022-06-24 02:20:05.163078
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75') # returns true
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') # returns true
    assert not is_ip('1.2.3') # returns false


# Generated at 2022-06-24 02:20:14.528797
# Unit test for function is_email
def test_is_email():
    assert is_email("abc@163.com")
    assert is_email("abc@163.com.cn")
    assert is_email("abc@163.com.com")
    assert is_email("abc@163.com.com.cn")
    assert is_email("abc.def@163.com")
    assert is_email("abc.def@163.com.cn")
    assert is_email("abc.def@163.com.com")
    assert is_email("abc.def@163.com.com.cn")
    assert is_email("abc_def@163.com")
    assert is_email("abc_def@163.com.cn")
    assert is_email("abc_def@163.com.com")
    assert is_email("abc_def@163.com.com.cn")

# Generated at 2022-06-24 02:20:15.658079
# Unit test for function is_slug
def test_is_slug():
  assert is_slug('my-blog-post-title') == True
  assert is_slug('My blog post title') == False
test_is_slug()

# Generated at 2022-06-24 02:20:19.300758
# Unit test for function words_count
def test_words_count():
    assert words_count('one,two,three.stop') == 4
    assert words_count('hello world') == 2
    assert words_count('! @ # % ... []') == 0
# End unit test for function words_count



# Generated at 2022-06-24 02:20:24.186815
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert(is_ip_v4('255.200.100.75'))
    assert(is_ip_v4('0.0.0.0'))
    assert(not is_ip_v4('nope'))
    assert(not is_ip_v4('999.200.100.75'))



# Generated at 2022-06-24 02:20:31.676016
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('foo_bar_baz') == True
    assert is_snake_case('Foo_Bar_Baz') == True
    assert is_snake_case('foo_bar_baz123') == True
    assert is_snake_case('foo_bar_baz_123') == True
    assert is_snake_case('_foo_bar_baz') == True
    assert is_snake_case('_foo_bar_baz_') == True
    assert is_snake_case('_-foo_bar_baz_') == True
    assert is_snake_case('foo_bar_baz_') == True
    assert is_snake_case('1_foo_bar_baz') == False
    assert is_snake_case('foo-bar-baz')

# Generated at 2022-06-24 02:20:39.870459
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    # test if it can detect a valid isbn number
    _checker = __ISBNChecker('0374532208')
    assert _checker.is_isbn_10() is True

    # test if it can detect an invalid isbn
    _checker = __ISBNChecker('02147483647')
    assert _checker.is_isbn_10() is False

    # test if the class will throw InvalidInputError for non string input
    try:
        __ISBNChecker(0)
        assert False
    except InvalidInputError:
        assert True

    # test if all dashes are removed
    _checker = __ISBNChecker('0-374-53220-8')
    assert _checker.is_isbn_10() is True

    # test if it can detect an invalid isbn with d

# Generated at 2022-06-24 02:20:43.591729
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('42.0') == True
    assert is_decimal('42') == False

test_is_decimal()



# Generated at 2022-06-24 02:20:47.003528
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert is_ip_v4('255.200.100.75') == True
    assert is_ip_v4('nope') == False
    assert is_ip_v4('255.200.100.999') == False



# Generated at 2022-06-24 02:20:57.093439
# Unit test for function is_snake_case
def test_is_snake_case():
    test_cases = [
        ['snake_case', True],
        ['snakecase', False],
        ['snake_case123', True],
        ['snake_case_123', True],
        ['123snake_case', False],
        ['_snake_case', False],
        ['_snake_case_', False],
        ['snake', False],
        ['snake_Case', False],
        ['', False],
        [None, False],
        [3, False],
        ['snake_case', True]
    ]
    for input, output in test_cases:
        assert is_snake_case(input) == output



# Generated at 2022-06-24 02:21:03.758595
# Unit test for function is_decimal
def test_is_decimal():
	assert is_decimal(12.45) == True
	assert is_decimal(24) == False
	assert is_decimal('12.45') == True
	assert is_decimal('24') == False
	assert is_decimal('2f') == False


# Generated at 2022-06-24 02:21:12.232289
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker('1234567890').is_isbn_10() is True
    assert __ISBNChecker('1234567891').is_isbn_10() is False
    assert __ISBNChecker('12345678').is_isbn_10() is False
    assert __ISBNChecker('').is_isbn_10() is False
    assert __ISBNChecker('ab8967891').is_isbn_10() is False
    assert __ISBNChecker(None).is_isbn_10() is False
    assert __ISBNChecker(1234567891).is_isbn_10() is False

    # Test ISBN10 number
    assert __ISBNChecker('0838933648').is_isbn_10() is True

# Generated at 2022-06-24 02:21:16.832423
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') == True
    assert is_url('https://mysite.com') == True
    assert is_url('.mysite.com') == False
    assert is_url('http://www.mysite.com', []) == True
    assert is_url('https://mysite.com', ['ftp', 'http']) == True
    assert is_url('http://www.mysite.com', ['http']) == True



# Generated at 2022-06-24 02:21:19.621551
# Unit test for function is_uuid
def test_is_uuid():
    assert(is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf')==True)
    assert(is_uuid('6f8aa2f9686c4ac387665712354a04cf')==False)
    assert(is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True)==True)

# Generated at 2022-06-24 02:21:22.433304
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('my string is <strong>bold</strong>')
    assert not contains_html('my string is not bold')
    assert not contains_html('&apy;')
contains_html('')




# Generated at 2022-06-24 02:21:30.855472
# Unit test for function is_email
def test_is_email():
    email1='panda.pile@gamil.com'
    assert is_email(email1)==True
    email2='panda.pile@@gamil.com'
    assert is_email(email2)==False
    email3='panda..pile@gmail.com'
    assert is_email(email3)==False
    email4='panda.pile.gmail.com'
    assert is_email(email4)==False
    email5='panda.pile@gmail.co'
    assert is_email(email5)==True
    email6='panda.pile@gmail.com'
    assert is_email(email6)==True
    email7=''
    assert is_email(email7)==False
    email8='        @gmail.com'

# Generated at 2022-06-24 02:21:40.627202
# Unit test for function is_email
def test_is_email():
    assert is_email("my.email@the-provider.com") == True
    assert is_email("@gmail.com") == False
    assert is_email("") == False
    assert is_email("a@a") == False
    assert is_email("a@a.a") == True
    assert is_email("a.a@a.a") == True
    assert is_email("a@a.a.a.a.a") == True
    assert is_email("a@a.a.a.a.a.a") == False
    assert is_email("a@a.a.a.a.a.a.") == False
    assert is_email(".........@.......com") == False
    assert is_email("@.com") == False
    assert is_email("name@") == False
    assert is_

# Generated at 2022-06-24 02:21:51.732484
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('-3.14159') == True
    assert is_decimal('3.14159') == True
    assert is_decimal('0.66') == True
    assert is_decimal('0.000000') == True
    assert is_decimal('0.0000000001') == True
    assert is_decimal('45.6789') == True
    assert is_decimal('-45.6789') == True
    assert is_decimal('45.6789') == True
    assert is_decimal('3.1415') == True
    assert is_decimal('1e5') == True
    assert is_decimal('-1E5') == True
    assert is_decimal('1.0E+5') == True
    assert is_decimal('1.0E-5') == True
   

# Generated at 2022-06-24 02:21:54.613477
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case("0camelCase") == False

# Generated at 2022-06-24 02:22:03.118184
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('5c5e0e18-83c1-4a95-a7c2-9e5c7cead157') == True
    assert is_uuid('5c5e0e1883c14a95a7c29e5c7cead157') == False
    assert is_uuid('5c5e0e1883c14a95a7c29e5c7cead157', True) == True


# Generated at 2022-06-24 02:22:07.467335
# Unit test for function is_ip_v4
def test_is_ip_v4():
    assert(is_ip_v4('255.200.100.75')==True)
    assert(is_ip_v4('nope')==False)
    assert(is_ip_v4('255.200.100.999')==False)




# Generated at 2022-06-24 02:22:13.910436
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com') is True
    assert is_url('https://mysite.com') is True
    assert is_url('ftp://mysite.com') is True
    assert is_url('http://mysite.com/directory?query1=value1&query2=value2') is True
    assert is_url('.mysite.com') is False



# Generated at 2022-06-24 02:22:25.260567
# Unit test for function is_email
def test_is_email():
    assert is_email('someone@gmail.com') == True
    assert is_email('@gmail.com') == False
    assert is_email('') == False
    assert is_email('foo@') == False
    assert is_email('foo@gmail..com') == False
    assert is_email('someone@gmail.com     ') == False
    assert is_email('someone@gmail.c') == False
    assert is_email('.someone@gmail.com') == False
    assert is_email('someone@gmail.com.') == False
    assert is_email('name."()<>[]:,;@gmail.com') == False
    assert is_email('name."()<>:,;@gmail.com') == False
    assert is_email('someone@gmail.com..') == False

# Generated at 2022-06-24 02:22:35.158927
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('') == False
    assert is_isogram('abbe') == False
    assert is_isogram('abcdefghijklmnopqrstuvwxyz') == True
    assert is_isogram('ABCDEFGHIJKLMNOPQRSTUVWXYZ') == True
    assert is_isogram('abcdegfhijklmnopqrstuvwxyz') == False
    assert is_isogram('abcdegfhijklmnopqrstuvwxya') == True
    assert is_isogram('abcdefghijklmnopqrstuvwxya') == False
    assert is_isogram('abcdefghijklmnopqrstuvwxyA') == False

# Generated at 2022-06-24 02:22:39.384201
# Unit test for function is_full_string
def test_is_full_string():
    assert not is_full_string(None)
    assert not is_full_string('')
    assert not is_full_string(' ')
    assert is_full_string('hello')


# Generated at 2022-06-24 02:22:46.069013
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    isbn_checker = __ISBNChecker('978-0-306-40615-7')
    assert isbn_checker.input_string == '9780306406157'
    isbn_checker = __ISBNChecker('978-0-306-40615-7', normalize=False)
    assert isbn_checker.input_string == '978-0-306-40615-7'



# Generated at 2022-06-24 02:22:54.757480
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('foo_bar_baz') == True
    assert is_snake_case('foo-bar-baz',separator='-') == True
    assert is_snake_case('foo-bar-baz',separator='_') == False
    assert is_snake_case('foo') == False
    assert is_snake_case('fooBar') == False
    assert is_snake_case('foo.bar') == False
    assert is_snake_case('foo bar') == False
    assert is_snake_case('foo-bar') == False
    assert is_snake_case('foo_bar') == True
    assert is_snake_case('__foo_bar__') == True



# Generated at 2022-06-24 02:23:00.103480
# Unit test for function is_number
def test_is_number():
    assert is_number('42') == True
    assert is_number('19.99') == True
    assert is_number('-9.12') == True
    assert is_number('1e3') == True
    assert is_number('1 2 3') == False
    assert is_number('hello') == False
    assert is_number(None) == False
    assert is_number(10) == False
    assert is_number('0xbadf00d') == False


# Generated at 2022-06-24 02:23:03.599610
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('LOL') == True
    assert is_palindrome('Lol') == False
    assert is_palindrome('Lol', ignore_case=True) == True
    assert is_palindrome('ROTFL') == False
test_is_palindrome()


# Generated at 2022-06-24 02:23:05.172072
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75') == True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') == True
    assert is_ip('1.2.3') == False


# Generated at 2022-06-24 02:23:10.649294
# Unit test for function words_count
def test_words_count():
    assert words_count('hello world') == 2
    assert words_count('one,two,three.stop') == 4
    assert words_count('! @ # % ... []') == 0

# Generated at 2022-06-24 02:23:17.476418
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('Dermatoglyphics') == True
    assert is_isogram('isogram') == True
    assert is_isogram('aba') == False
    assert is_isogram('moOse') == False
    assert is_isogram('isIsogram') == False
    assert is_isogram('') == True
test_is_isogram()


# Generated at 2022-06-24 02:23:19.750913
# Unit test for function is_string
def test_is_string():
    assert (is_string('foo') == True) == True
    assert (is_string(b'foo') == False) == True


# Generated at 2022-06-24 02:23:27.884476
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    try:
        __ISBNChecker('abc')
    except Exception:
        assert True
    else:
        assert False

    try:
        __ISBNChecker(123)
    except Exception:
        assert True
    else:
        assert False

    try:
        __ISBNChecker(None)
    except Exception:
        assert True
    else:
        assert False

    try:
        __ISBNChecker('')
    except Exception:
        assert True
    else:
        assert False

    try:
        __ISBNChecker('abc', False)
    except Exception:
        assert True
    else:
        assert False


# PUBLIC API


#
# Type checker
#

# Generated at 2022-06-24 02:23:35.404548
# Unit test for function is_integer
def test_is_integer():
    assert is_integer('42') == True
    assert is_integer('-42') == True
    assert is_integer('+42') == True
    assert is_integer('0x2A') == False
    assert is_integer('0b101010') == False
    assert is_integer('0o52') == False
    assert is_integer('1.0') == False
    assert is_integer('3.4') == False
    assert is_integer('-3.4') == False
    assert is_integer('1e5') == False



# Generated at 2022-06-24 02:23:39.782941
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') == True


# Generated at 2022-06-24 02:23:42.099690
# Unit test for function words_count
def test_words_count():
    assert words_count('hello world') == 2
    assert words_count('one,two,three.stop') == 4



# Generated at 2022-06-24 02:23:43.975011
# Unit test for function is_url
def test_is_url():
    assert is_url('http://www.mysite.com')

# Full email example:
# Albert.Einstein@domain.com

# Generated at 2022-06-24 02:23:50.987379
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6("2001:db8:85a3:0000:0000:8a2e:370:7334") == True
    assert is_ip_v6("2001:db8:85a3:0000:0000:8a2e:370:7334") == True
    assert is_ip_v6("2001:db8:85a3:0000:0000:8a2e:370:73?") == False



# Generated at 2022-06-24 02:23:51.653085
# Unit test for function words_count
def test_words_count():
    print(words_count('one, two'))

# Generated at 2022-06-24 02:24:01.583753
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    assert __ISBNChecker("0306406152").is_isbn_10() is True
    assert __ISBNChecker("0306406152", normalize=False).is_isbn_10() is True
    assert __ISBNChecker("0596006306").is_isbn_10() is True
    assert __ISBNChecker("0471117867").is_isbn_10() is True
    assert __ISBNChecker("9780471117867").is_isbn_10() is False
    assert __ISBNChecker("9780471117867", normalize=False).is_isbn_10() is False


# PUBLIC API


# test if input is a string

# Generated at 2022-06-24 02:24:06.309504
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75')
    assert not is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334')
    assert not is_ip('1.2.3')

test_is_ip()


# Generated at 2022-06-24 02:24:13.910181
# Unit test for function is_isbn_13
def test_is_isbn_13():
    """
    A test for the function is_isbn_13()
    """
    assert is_isbn_13('9780312498580') == True
    assert is_isbn_13('978-0312498580') == True
    assert is_isbn_13('978-0312498580',normalize=False) == False
    assert is_isbn_13('1357924680') == True
    assert is_isbn_13('978-0312498580',normalize=False) == False
    assert is_isbn_13('978-03-12498580',normalize=False) == False
    assert is_isbn_13('9789401456210') == True
    assert is_isbn_13('9789401456211') == False

# Generated at 2022-06-24 02:24:24.769086
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert __ISBNChecker("978-3-16-148410-0").is_isbn_13() == True
    assert __ISBNChecker("978-3-16-148410-1").is_isbn_13() == False
    assert __ISBNChecker("978-3-16-148410-1").is_isbn_13() == False
    assert __ISBNChecker("97803-16-148410-1").is_isbn_13() == False
    assert __ISBNChecker("97803-16-148410-0").is_isbn_13() == False
    assert __ISBNChecker("97803-16-148410-0").is_isbn_13() == False

# Generated at 2022-06-24 02:24:30.301571
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf')
    assert not is_uuid('6f8aa2f9686c4ac387665712354a04cf')
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True)

# Generated at 2022-06-24 02:24:35.998044
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('1506715214') == True
    assert is_isbn_10('150-6715214') == True
    assert is_isbn_10('150-6715214', normalize=False) == False
# /Unit test for function is_isbn_10



# Generated at 2022-06-24 02:24:40.048626
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('myString') is True
    assert is_camel_case('myVariable1String') is False
    assert is_camel_case('MyString') is True
    assert is_camel_case('mystring') is False
test_is_camel_case()



# Generated at 2022-06-24 02:24:41.897753
# Unit test for function is_slug
def test_is_slug():
    assert is_slug('my-blog-post-title')
    assert not is_slug('My blog post title')


# Generated at 2022-06-24 02:24:45.212763
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('moOse') == False
    assert is_isogram('moose') == True
    assert is_isogram('Moose') == False
    assert is_isogram('dermatoglyphics') == True
    assert is_isogram('hello') == False


# Generated at 2022-06-24 02:24:48.082216
# Unit test for function is_camel_case
def test_is_camel_case():
    assert is_camel_case('MyString')
    assert not is_camel_case('mystring')


# Generated at 2022-06-24 02:24:50.245780
# Unit test for function is_decimal
def test_is_decimal():
    assert is_decimal('42.0') == True
    assert is_decimal('42') == False
test_is_decimal()



# Generated at 2022-06-24 02:24:58.657833
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('moOse') == False
    assert is_isogram('isIsogram') == False
    assert is_isogram('Dermatoglyphics') == True
    assert is_isogram('aba') == False
    assert is_isogram('moose') == False
    assert is_isogram('isogram') == True
    assert is_isogram('') == True
    assert is_isogram('thumbscrewjapingly') == True
    assert is_isogram('thumbscrew-japingly') == True
    assert is_isogram('six-year-old') == True
    assert is_isogram('Emily Jung Schwartzkopf') == True
    assert is_isogram('accentor') == False
    assert is_isogram('angola') == False


# Generated at 2022-06-24 02:25:03.591071
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    checker = __ISBNChecker('9783952142040')
    if checker.is_isbn_13() != True:
        raise Exception('[Wrong Result] is_isbn_13() return False while it should return True!')


# End of Unit test


# Generated at 2022-06-24 02:25:06.540262
# Unit test for function is_slug
def test_is_slug():
    s = 'my-title'
    assert is_slug(s) is True
    assert is_slug(s, '_') is False
    assert is_slug('my-title!') is False


# Generated at 2022-06-24 02:25:15.200373
# Unit test for function is_uuid
def test_is_uuid():
    assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf')
    assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', allow_hex=True)
    assert is_uuid(UUID('6f8aa2f9-686c-4ac3-8766-5712354a04cf'))
    assert not is_uuid('6f8aa2f9686c4ac387665712354a04cf')
    assert not is_uuid(None)
    assert not is_uuid(6)

# Generated at 2022-06-24 02:25:18.033311
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    checker = __ISBNChecker(input_string='0833592462', normalize=False)
    assert checker.is_isbn_10()



# Generated at 2022-06-24 02:25:19.913523
# Unit test for function words_count
def test_words_count():
    assert words_count('hello world') == 2
    assert words_count('one,two,three.stop') == 4


# Generated at 2022-06-24 02:25:21.330744
# Unit test for function is_palindrome
def test_is_palindrome():
    s="otto"
    assert is_palindrome(s)==True
    s="i topi non avevano nipoti"
    assert is_palindrome(s)==False

# Generated at 2022-06-24 02:25:28.098294
# Unit test for function is_number
def test_is_number():
    assert is_number('42') == True
    assert is_number('19.99') == True
    assert is_number('-9.12') == True
    assert is_number('1e3') == True
    assert is_number('1 2 3') == False
    assert is_number('') == False
    assert is_number('foo') == False
    assert is_number('1+2') == False
    assert is_number('.') == False
    assert is_number('-') == False
    assert is_number('0x1a') == False
    assert is_number('1.') == False
    assert is_number('1.0.0') == False


# Generated at 2022-06-24 02:25:30.768785
# Unit test for function is_string
def test_is_string():
    assert is_string('123') == True
    assert is_string(b'123') == False
    assert is_string(123) == False



# Generated at 2022-06-24 02:25:37.288329
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    tester = __ISBNChecker('978-0-306-40615-7')
    assert tester.input_string == '9780306406157'

    tester = __ISBNChecker('9780306406157', normalize=False)
    assert tester.input_string == '9780306406157'


# PUBLIC API



# Generated at 2022-06-24 02:25:48.263391
# Unit test for function is_isbn_10
def test_is_isbn_10():
    assert is_isbn_10('4503148932')
    assert is_isbn_10('450-3148932')
    assert is_isbn_10('450-3148932', normalize=False)

    assert not is_isbn_10('4503148')
    assert not is_isbn_10('450-3148932', normalize=False)
    assert not is_isbn_10('450-314-8932', normalize=False)

    assert is_isbn_10('9100100100')
    assert is_isbn_10('9100-100-100')
    assert is_isbn_10('9100-100-100', normalize=False)
    assert not is_isbn_10('9100100100', normalize=False)


# Generated at 2022-06-24 02:25:52.599936
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    assert not __ISBNChecker('978-2-226-26107-5')
    assert __ISBNChecker('9782226261075')


# API


# Generated at 2022-06-24 02:25:54.184365
# Unit test for function is_string
def test_is_string():
    assert is_string('foo') == True
    assert is_string(b'foo') == False


# Generated at 2022-06-24 02:26:03.590091
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75') is True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:7334') is True
    assert is_ip('1.2.3') is False
    
test_is_ip()

# Generated at 2022-06-24 02:26:09.114177
# Unit test for function is_integer
def test_is_integer():
    assert is_integer(input_string='42')
    assert not is_integer(input_string='42.0')
    assert not is_integer(input_string='42,0')
    assert not is_integer(input_string='42.0.0')
    assert not is_integer(input_string='42,0.0,0')



# Generated at 2022-06-24 02:26:11.850330
# Unit test for function is_email
def test_is_email():
    assert is_email("my.email@the-provider.com") == False
    assert is_email("my.email@the-provider.com") == True

# Check credit card format

# Generated at 2022-06-24 02:26:13.163535
# Unit test for function is_ip
def test_is_ip():
    assert is_ip('255.200.100.75')==True
    assert is_ip('2001:db8:85a3:0000:0000:8a2e:370:?')==False



# Generated at 2022-06-24 02:26:17.309130
# Unit test for function is_number
def test_is_number():
    assert is_number('42') == True
    assert is_number('19.99') == True
    assert is_number('-9.12') == True
    assert is_number('1e3') == True
    assert is_number('1 2 3') == False


# Generated at 2022-06-24 02:26:21.578798
# Unit test for function is_number
def test_is_number():
    assert is_number('42')==True
    assert is_number('19.99')==True
    assert is_number('-9.12')==True
    assert is_number('1e3')==True
    assert is_number('1 2 3')==False


# Generated at 2022-06-24 02:26:24.986747
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('hello') == False
    assert is_isogram('dermatoglyphics') == True


# Generated at 2022-06-24 02:26:34.660693
# Unit test for function is_number
def test_is_number():
    assert is_number('1') == True
    assert is_number('1.1') == True
    assert is_number('-1') == True
    assert is_number('-1.1') == True
    assert is_number('1e4') == True
    assert is_number('42') == True
    assert is_number('-42') == True
    assert is_number('9007199254740991') == True
    assert is_number('9223372036854775807') == True
    assert is_number('-9007199254740991') == True
    assert is_number('-9223372036854775807') == True
    assert is_number('0.777') == True
    assert is_number('-0.777') == True

    assert is_number('foo') == False

# Generated at 2022-06-24 02:26:41.479214
# Unit test for function is_palindrome
def test_is_palindrome():
    """
    Check if the function "test_is_palindrome" works as expected.
    """
    assert is_palindrome(4) is False
    assert is_palindrome('') is False
    assert is_palindrome('LOL') is True
    assert is_palindrome('Lol') is False
    assert is_palindrome('Lol', ignore_case=True) is True
    assert is_palindrome('ROTFL') is False
    assert is_palindrome('Lol', ignore_spaces=True) is False
    assert is_palindrome('Lol', ignore_spaces=True, ignore_case=True) is False
    assert is_palindrome('Lol ', ignore_spaces=True, ignore_case=True) is False

# Generated at 2022-06-24 02:26:47.549165
# Unit test for function words_count
def test_words_count():
    assert words_count('hello world') == 2
    assert words_count('one,two,three.stop') == 4
    assert words_count('') == 0
    assert words_count('*&%$') == 0
test_words_count()



# Generated at 2022-06-24 02:26:58.108847
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome('LOL') == True
    assert is_palindrome('Lol') == False
    assert is_palindrome('Lol', ignore_case=True) == True
    assert is_palindrome('ROTFL') == False
    assert is_palindrome('') == False
    assert is_palindrome(' ') == True
    assert is_palindrome(' a ') == True
    assert is_palindrome(' a  ') == False
    assert is_palindrome('a') == True
    assert is_palindrome('aa') == True
    assert is_palindrome('a b') == False
    assert is_palindrome('a b', ignore_spaces=True) == True

# Generated at 2022-06-24 02:27:04.667370
# Unit test for function is_snake_case
def test_is_snake_case():
    assert is_snake_case('foo_bar_baz') == True
    assert is_snake_case('foo') == False
    assert is_snake_case('foo-bar-baz') == True
    assert is_snake_case('foo-bar-baz','-') == True



# Generated at 2022-06-24 02:27:07.070345
# Unit test for function is_palindrome
def test_is_palindrome():
    assert is_palindrome("otto")
    assert is_palindrome("i topi non avevano nipoti")
    assert is_palindrome("rotfl") is False



# Generated at 2022-06-24 02:27:10.386946
# Unit test for function words_count
def test_words_count():
    assert words_count('hello world') == 2
    assert words_count('one,two,three.stop') == 4
    assert words_count('Lorem, ipsum dolor sit amet consectetur adipisicing elit. Laboriosam sunt obcaecati? Quis, excepturi.') == 17

test_words_count()


# Generated at 2022-06-24 02:27:15.156153
# Unit test for function is_string
def test_is_string():
    assert type(is_string('foo')) == bool
    assert is_string('foo') == True
    assert is_string(b'foo') == False

# Generated at 2022-06-24 02:27:26.501135
# Unit test for function is_snake_case
def test_is_snake_case():
    assert(is_snake_case('foo',separator='_'))
    assert(not is_snake_case('foo-bar',separator='-'))
    assert(not is_snake_case('foo_bar',separator='_'))
    assert(is_snake_case('foo_bar',separator='_'))
    assert(is_snake_case('foo_bar_baz',separator='_'))
    assert(not is_snake_case('foo'))
    assert(not is_snake_case('foo_Bar_baz',separator='_'))
    assert(not is_snake_case('1foo_bar_baz',separator='_'))
    assert(not is_snake_case('foo_1_bar',separator='_'))

# Generated at 2022-06-24 02:27:35.864290
# Unit test for function is_email
def test_is_email():
    assert is_email('noreply@cenda.shop') == True, "email 1"
    assert is_email('hello.world@gmail.com') == True, "email 2"
    assert is_email('hello.world@outlook.com') == True, "email 3"
    assert is_email('hello.world@yahoo.com') == True, "email 4"
    assert is_email('hello.world@hotmail.com') == True, "email 5"
    assert is_email('hello-world@hotmail.com') == True, "email 6"
    assert is_email('hello_world@hotmail.com') == True, "email 7"
    assert is_email('hello world@hcmut.edu.vn') == True, "email 8"

# Generated at 2022-06-24 02:27:46.688785
# Unit test for constructor of class __ISBNChecker
def test___ISBNChecker():
    assert not __ISBNChecker('hello').is_isbn_13()
    assert not __ISBNChecker('1234567891012').is_isbn_13()
    assert not __ISBNChecker('12345678910123').is_isbn_13()
    assert not __ISBNChecker('9780132350883').is_isbn_13()
    assert __ISBNChecker('9780132350884').is_isbn_13()

    assert not __ISBNChecker('hello').is_isbn_10()
    assert not __ISBNChecker('123456789101').is_isbn_10()
    assert not __ISBNChecker('1234567891012').is_isbn_10()
    assert not __ISBNChecker('0-321-14653-0').is_is

# Generated at 2022-06-24 02:27:48.462079
# Unit test for function is_string
def test_is_string():
    assert(is_string('hello world') == True)
    assert(is_string(b'foo') == False)


# Generated at 2022-06-24 02:27:57.056987
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    checker = __ISBNChecker('0143034630')
    assert checker.is_isbn_10()

    checker = __ISBNChecker('8190790381')
    assert not checker.is_isbn_10()

    checker = __ISBNChecker('819079038x')
    assert checker.is_isbn_10()

    checker = __ISBNChecker('819079038x')
    assert checker.is_isbn_10()

    checker = __ISBNChecker('8190790381x')
    assert not checker.is_isbn_10()

    checker = __ISBNChecker('819079038')
    assert not checker.is_isbn_10()


# Generated at 2022-06-24 02:27:59.493154
# Unit test for function is_full_string
def test_is_full_string():
    assert is_full_string(None) # returns false
    assert is_full_string('') # returns false
    assert is_full_string(' ') # returns false
    assert is_full_string('hello') # returns true


# Generated at 2022-06-24 02:28:06.047332
# Unit test for function is_ip_v4
def test_is_ip_v4():
    print('Testing is_ip_v4')

    assert(is_ip_v4('255.200.100.75') == True)
    assert(is_ip_v4('nope') == False)
    assert(is_ip_v4('255.200.100.999') == False)



# Generated at 2022-06-24 02:28:07.015291
# Unit test for function words_count
def test_words_count():
    assert words_count('hello world') == 2
    assert words_count('one,two,three.stop') == 4
# Check if string is full

# Generated at 2022-06-24 02:28:09.594646
# Unit test for function is_string
def test_is_string():
    assert is_string('foo')
    assert is_string('')
    assert is_string(' ')
    assert not is_string(b'foo')
    assert not is_string(123)
    assert not is_string(True)
    assert not is_string(['foo'])
    assert not is_string({'foo': 'bar'})



# Generated at 2022-06-24 02:28:20.001547
# Unit test for function is_uuid
def test_is_uuid():
	assert is_uuid('6f8aa2f9-686c-4ac3-8766-5712354a04cf') is True
	assert is_uuid('6f8aa2f9686c4ac387665712354a04cf') is False
	assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', True) is True
	assert is_uuid('6f8aa2f9686c4ac387665712354a04cf', False) is False

# Generated at 2022-06-24 02:28:22.454805
# Unit test for function is_isogram
def test_is_isogram():
    assert is_isogram('isogram') == True
    assert is_isogram('zebra') == False
    assert is_isogram('moor') == False
    assert is_isogram('moOr') == True

# Generated at 2022-06-24 02:28:28.679358
# Unit test for function is_ip_v6
def test_is_ip_v6():
    assert is_ip_v6('2001:db8:85a3:0:0:8a2e:370:7334') == True
    assert is_ip_v6('2001:db8:85a3:0:0:8a2e:370:?') == False
    assert is_ip_v6('2001:db8:85a3:0:0:8a2e:370:') == False
    assert is_ip_v6('2001:db8:85a3::8a2e:370:7334') == True
    assert is_ip_v6('2001:db8::8a2e:370:7334') == True
    assert is_ip_v6('2001:db8::8a2e:370:') == False

# Generated at 2022-06-24 02:28:36.172973
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4111111111111111')
    assert is_credit_card('4012888888881881')
    assert is_credit_card('378282246310005')
    assert is_credit_card('6011111111111117')
    assert is_credit_card('5105105105105100')
    assert is_credit_card('5555555555554444')
    assert is_credit_card('3088888888888')
    assert is_credit_card('378734493671000')
    assert is_credit_card('30569309025904')
    assert not is_credit_card('3056930902590')
    assert not is_credit_card('305693090259045')
    assert not is_credit_card('41111111111111131')




# Generated at 2022-06-24 02:28:43.298726
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('my string is <strong>bold</strong>')
    assert not contains_html('my string is not bold')
    assert not contains_html('<')
    assert not contains_html('>')
    assert not contains_html('<>')
    assert contains_html('<>test')
    assert contains_html('>>test')
    assert contains_html('<<test')
    assert not contains_html('')

# Generated at 2022-06-24 02:28:48.708225
# Unit test for function is_number
def test_is_number():
    assert is_number('42') == True
    assert is_number('19.99') == True 
    assert is_number('-9.12') == True
    assert is_number('1e3') == True
    assert is_number('1 2 3') == False
# Test:
test_is_number()



# Generated at 2022-06-24 02:29:01.212518
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    assert(__ISBNChecker('9780132350884').is_isbn_13())
    assert(__ISBNChecker('978-0134685991').is_isbn_13())
    assert(__ISBNChecker('9780134685991').is_isbn_13())

    assert(not __ISBNChecker('').is_isbn_13())
    assert(not __ISBNChecker('978013468599').is_isbn_13())
    assert(not __ISBNChecker('9780134685912').is_isbn_13())
    assert(not __ISBNChecker('9780134685912').is_isbn_13())
    assert(not __ISBNChecker(None).is_isbn_13())


# Generated at 2022-06-24 02:29:12.356966
# Unit test for function is_credit_card
def test_is_credit_card():
    assert is_credit_card('4111111111111111', card_type='VISA')
    assert is_credit_card('4111111111111111')
    assert is_credit_card('5105105105105100', card_type='MASTERCARD')
    assert is_credit_card('378282246310005', card_type='AMERICAN_EXPRESS')
    assert is_credit_card('6011111111111117', card_type='DISCOVER')
    assert is_credit_card('30569309025904', card_type='DINERS_CLUB')
    assert is_credit_card('3530111333300000', card_type='JCB')
    assert not is_credit_card('5105105105105100', card_type='VISA')



# Generated at 2022-06-24 02:29:17.766359
# Unit test for method is_isbn_10 of class __ISBNChecker
def test___ISBNChecker_is_isbn_10():
    checker = __ISBNChecker('1234567890')
    assert checker.is_isbn_10()
    checker = __ISBNChecker('123456789')
    assert not checker.is_isbn_10()
    checker = __ISBNChecker('abcdefghij')
    assert not checker.is_isbn_10()
    checker = __ISBNChecker('10-12345678')
    assert not checker.is_isbn_10()


# Generated at 2022-06-24 02:29:19.259871
# Unit test for function words_count
def test_words_count():
    assert words_count('hello world') == 2



# Generated at 2022-06-24 02:29:30.319333
# Unit test for method is_isbn_13 of class __ISBNChecker
def test___ISBNChecker_is_isbn_13():
    checker = __ISBNChecker('978-1-56619-909-4', normalize=False)
    assert checker.is_isbn_13() == True

    checker = __ISBNChecker('978-1-56619-909-5')
    assert checker.is_isbn_13() == False

    checker = __ISBNChecker('9781566199094')
    assert checker.is_isbn_13() == True

    checker = __ISBNChecker('9781-56619-909-4') # invalid check digit
    assert checker.is_isbn_13() == False

    checker = __ISBNChecker('1-56619-909-4') # invalid check digit
    assert checker.is_isbn_13() == False

# Unit test

# Generated at 2022-06-24 02:29:41.921330
# Unit test for function contains_html
def test_contains_html():
    assert contains_html('this is not valid html') == False
    assert contains_html('<html><body>This is valid html</body></html>') == True
    assert contains_html('<html><body>This is valid html</body>') == True
    assert contains_html('<html><body>This is valid html') == True
    assert contains_html('html><body>This is valid html') == True
    assert contains_html('<html><body>This is valid html<') == True
    assert contains_html('<html<body>This is valid html>') == True
    assert contains_html('</html>') == True
    assert contains_html('<br />') == True
    assert contains_html('<') == True
    assert contains_html('>') == True
    assert contains_html('<>') == True
   