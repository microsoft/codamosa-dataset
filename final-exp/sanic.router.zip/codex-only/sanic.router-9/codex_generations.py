

# Generated at 2022-06-24 04:35:12.152517
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()

# Generated at 2022-06-24 04:35:18.496557
# Unit test for constructor of class Router
def test_Router():
    class testRouter(Router): 
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            # Test if DEFAULT_METHOD is "GET"
            assert self.DEFAULT_METHOD is "GET", "DEFAULT_METHOD is not GET"
            # Test if ALLOWED_METHODS is Http_METHODS
            assert self.ALLOWED_METHODS is HTTP_METHODS, "ALLOWED_METHODS is not HTTP_METHODS"

    _ = testRouter()


# Generated at 2022-06-24 04:35:24.370466
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add(uri="/test/{id:int}", methods=["post"], handler=lambda x: x)
    with patch.object(router, "dynamic_routes", {"test": None}):
        router.finalize()

        assert "Finalizing router" in caplog.text


# Generated at 2022-06-24 04:35:31.386326
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    def test_handler(request):
        return None
    router.add_route(uri='/', methods=['GET'], handler=test_handler)

    # unit test for passed
    router.finalize()
    # unit test for failed
    router.add_route(uri='/<__test_param>', methods=['GET'], handler=test_handler)
    try:
        router.finalize()
    except Exception as e:
        assert type(e) == SanicException

# Generated at 2022-06-24 04:35:40.291437
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router(app = None)
    router.dynamic_routes = {
        "route_name": Route(
            path = "/path/{parameter1}/{parameter2}",
            methods = ["GET", "POST"],
            handler = None,
            name = "route_name",
            strict = False,
            unquote = False,
            labels = ["__file_uri__", "parameter1", "parameter2"]
        )
    }

    router.finalize()

# Generated at 2022-06-24 04:35:45.955007
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()

    def fn():
        pass 

    try:
        router.add("/a/<var_id>", ["GET"], fn)
    except SanicException as e:
        if str(e) != "Invalid route: /a/<var_id>. Parameter names cannot use '__'.":
            raise SanicException("failed")


test_Router_finalize()

# Generated at 2022-06-24 04:35:50.548809
# Unit test for constructor of class Router
def test_Router():
    actual = Router({"prefix": "prefix"})
    assert actual.ctx.prefix == "prefix", "Should be 'prefix'"
    assert actual.ctx.hosts == [], "Should be ''"
    assert actual.ctx.version == None, "Should be 'None'"
    assert actual.ctx.app == None, "Should be 'None'"
    assert actual.ctx.static == None, "Should be 'None'"

# Generated at 2022-06-24 04:35:51.352607
# Unit test for constructor of class Router
def test_Router():
    assert Router(1) is not None

# Generated at 2022-06-24 04:35:58.957141
# Unit test for method add of class Router
def test_Router_add():
    from sanic import Sanic
    app = Sanic()
    router = Router(app)
    uri = '/uri'
    methods = ('GET', 'POST')
    handler = None
    host = 'host'
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = 'name'
    unquote = False
    result = router.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote)
    app.finalize_routes([router])
    res = router.find_route_by_view_name('name')
    assert res is not None
    assert res.uri == result.uri


# Generated at 2022-06-24 04:36:08.937680
# Unit test for constructor of class Router

# Generated at 2022-06-24 04:36:17.719314
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    from sanic.config import Config

    class CustomRouter(Router):
        def finalize(self, app: Sanic, config: Config):
            super().finalize(app, config)

            for route in self.dynamic_routes.values():
                if any(
                    label.startswith("__") and label not in ALLOWED_LABELS
                    for label in route.labels
                ):
                    raise SanicException(
                        f"Invalid route: {route}. Parameter names cannot use '__'."
                    )

    router = CustomRouter()

    def handler():
        pass
    router.add("/", ["GET"], handler, name="handler")

    from sanic.utils import sanic_endpoint_test

# Generated at 2022-06-24 04:36:22.521457
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router(None)
    route = Route(
        uri="/",
        handler=None,
        names=["name"],
        methods=["GET"],
        labels=["__test__"],
    )
    router.dynamic_routes = {None: route}
    router.finalize()

    assert router.dynamic_routes == {None: route}

# Generated at 2022-06-24 04:36:26.707891
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r.DEFAULT_METHOD == "GET"
    assert r.ALLOWED_METHODS == HTTP_METHODS

# Generated at 2022-06-24 04:36:36.357738
# Unit test for method add of class Router
def test_Router_add():
    from sanic import Sanic
    from sanic.response import json, text
    from sanic.views import CompositionView

    app = Sanic("test_sanic_router")
    router = app.router
    cb = lambda x: x
    iter_all = lambda x: None
    iter_sub_a = lambda x: None
    iter_sub_b = lambda x: None
    iter_sub_c = lambda x: None
    iter_sub_d = lambda x: None
    iter_sub_e = lambda x: None

    class ItemGet(CompositionView):
        methods = ["get"]

        class get(CompositionView):
            methods = ["sub_a", "sub_b"]


# Generated at 2022-06-24 04:36:41.272666
# Unit test for method finalize of class Router
def test_Router_finalize():
    class A:
        def __init__(self):
            self.router = A.Router()

        class Router(Router):
            def on_add_route(self, route: Route, **kwargs):
                pass

    A()
    A()

# Generated at 2022-06-24 04:36:45.334732
# Unit test for method finalize of class Router
def test_Router_finalize():
    route=Route(
        uri="/",
        handler="get"
    )
    router=Router()
    router.dynamic_routes['route']=route
    try:
        router.finalize()
    except SanicException as exception:
        print(exception)

test_Router_finalize()

# Generated at 2022-06-24 04:36:55.107422
# Unit test for method add of class Router
def test_Router_add():
    def test1(a):
        return a
    router = Router()
    router.add('/test',['GET'],test1)
    assert router.routes_all == [('/test', {'GET': 'GET'}),('/<path:path>', {'OPTIONS': 'OPTIONS'})]
    assert router.routes_static == [('/test', {'GET': 'GET'})]
    assert router.routes_dynamic == [('/<path:path>', {'OPTIONS': 'OPTIONS'})]
    assert router.routes_regex == [('/<path:path>', {'OPTIONS': 'OPTIONS'})]


# Generated at 2022-06-24 04:37:02.598832
# Unit test for method add of class Router
def test_Router_add():
    """
    Unit test for method add of class Router
    """
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic('test_Sanic')
    
    async def handler():
        return text('OK')
    
    route = Router.add(app.router, '/', ['GET'], handler)
    assert not isinstance(route, list)
    assert isinstance(route, Route)

# Generated at 2022-06-24 04:37:13.234264
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.request import Request
    from sanic.router import Router
    from sanic.response import HTTPResponse
    from sanic.testing import assert_datagram

    @app.route('/uri')
    async def handler(request):
        return HTTPResponse(text='OK')

    @app.route('/other_uri')
    async def other_handler(request):
        return HTTPResponse(text='OK')

    router = Router(app)
    router.add(uri='/uri', methods=['GET'], handler=handler, version=1)
    router.add(uri='/uri', methods=['GET'], handler=other_handler, version=2)
    
    assert len(router.routes_dynamic) == 1

# Generated at 2022-06-24 04:37:13.939367
# Unit test for method finalize of class Router
def test_Router_finalize():
    pass

# Generated at 2022-06-24 04:37:21.606601
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.model_utils import Route
    from sanic.constants import HTTP_METHODS

    # Define a router object
    router = Router()

    # Define a route object
    route_all = Route(
        path='/',
        route=None,
        method=HTTP_METHODS,  # list
        handler='A',
        name='A',
        strict_slashes=False,
        host=None,
        unquote=True
    )

    # Define a route object
    route_static = Route(
        path='/static/',
        route=None,
        method='GET',
        handler='B',
        name='B',
        strict_slashes=False,
        host=None,
        unquote=True
    )

    # Define a route object
    route_dynamic

# Generated at 2022-06-24 04:37:26.770677
# Unit test for constructor of class Router
def test_Router():
    router = Router()

    assert router.ctx == None
    assert router.routes == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}


# Generated at 2022-06-24 04:37:32.737392
# Unit test for method add of class Router
def test_Router_add():
    router = Router()

    def handler():
        pass

    route = router.add("/foo", ["get"], handler)

    assert len(router.routes) == 1
    assert router.routes[0].path == "/foo"
    assert router.routes[0].handler == handler
    assert route in router.routes
    assert "/foo" in router.routes_dynamic
    assert router.dynamic_routes["/foo"] == route


# Generated at 2022-06-24 04:37:40.964865
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    from sanic.router_helpers import dynamic_route, route
    from sanic.websocket import WebSocketProtocol
    from sanic_routing.route import Route
    from sanic.server import HttpProtocol
    import uvloop
    
    sanic_app = Sanic('test_Router_finalize')
    sanic_app_router = Router(sanic_app, host='127.0.0.1', port=8000, protocol=HttpProtocol, access_log=True, uvloop=uvloop.new_event_loop, run_async=True, enable_lifespan=True, enable_http2=True, error_handler=None, protocols=WebSocketProtocol)

# Generated at 2022-06-24 04:37:50.838795
# Unit test for method add of class Router
def test_Router_add():
    from random import randint
    router = Router()
    router.add("/", ["GET"], lambda x: x)
    router.add("/", ["GET"], lambda x: x)
    router.add("/", ["GET"], lambda x: x)
    router.add("/", ["GET"], lambda x: x)
    router.add("/", ["GET"], lambda x: x)

    for _ in range(3):
        router.add(str(randint(0, 1000)), ["GET"], lambda x: x)
        router.add(str(randint(0, 1000)), ["GET"], lambda x: x)
        router.add(str(randint(0, 1000)), ["GET"], lambda x: x)
        router.add(str(randint(0, 1000)), ["GET"], lambda x: x)

# Generated at 2022-06-24 04:37:53.745851
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add('/', ['GET'], None)
    assert router.routes_dynamic == {'/': [Route(path='/', handler=None, methods=['GET'], name=None, strict=False, unquote=False)]}


# Generated at 2022-06-24 04:38:01.599584
# Unit test for method add of class Router
def test_Router_add():
    router = Router()

    def mock_add(self, uri, handler):
        self.result = uri

    router.add = mock_add.__get__(router, type(router))

    @router.add("", lambda x: x)
    async def test(request):  # type: ignore
        return request

    assert test.__name__ == "test"
    assert router.result == "/test"


# Generated at 2022-06-24 04:38:04.853173
# Unit test for constructor of class Router
def test_Router():

    from sanic.router import Router
    from sanic.exceptions import SanicException

    try:
        router = Router()
        assert router is not None
    except SanicException as e:
        print(e)



# Generated at 2022-06-24 04:38:09.406465
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.response import text
    from sanic.utils import sanic_endpoint_test
    app = sanic_endpoint_test(Router.finalize, text('OK'))
    request, response = app.test_client.get('/')
    assert response.text == 'OK'

# Generated at 2022-06-24 04:38:18.632989
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Test with the valid format (parameter names do not use '__')
    router = Router(None)
    route = Route(
        path="/blah",
        handler=None,
        method="GET",
        strict_slashes=False,
        unquote=False,
        ctx=router,
        labels={"__file_uri__": 0}
    )
    router.dynamic_routes = {
        (route.strict_slashes, route.unquote): {route}
    }
    router.finalize()

    # Test with the invalid format (parameter names use '__')
    router = Router(None)

# Generated at 2022-06-24 04:38:23.480003
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        router = Router()
        router.add(uri="{__x__}/v1/api", methods=["GET"], handler=None, strict_slashes=False, stream=False, ignore_body=False, version=None, name=None, unquote=False, static=False)
    except Exception as e:
        print(e)
        assert isinstance(e, SanicException)
    else:
        assert False

# Generated at 2022-06-24 04:38:25.121559
# Unit test for constructor of class Router
def test_Router():
    instance = Router(app=None)
    if isinstance(instance, BaseRouter):
        assert True
    else:
        assert False


# Generated at 2022-06-24 04:38:29.917311
# Unit test for method add of class Router
def test_Router_add():
    from sanic.response import text

    router = Router()
    router.add(uri="/", methods=("GET",), handler=text("test"))

# Generated at 2022-06-24 04:38:34.866162
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add("/", ["GET"], "test")
    assert router.get('/', 'GET', 'host') == ("/", "test", {})

# Generated at 2022-06-24 04:38:38.650957
# Unit test for method add of class Router
def test_Router_add():
    app = Sanic("test_Router_add")

    app.router.add("/test/", ["GET","POST"], lambda: 1)

    # is valid
    if len(app.router.dynamic_routes) == 0:
        raise AssertionError("Router_add test failed")


# Generated at 2022-06-24 04:38:47.608459
# Unit test for method add of class Router
def test_Router_add():

    async def hello_handler(self, req, resp):
        resp.text = "Hello Sanic!"

    try:
        from sanic import Sanic
    except ImportError:
        pass
    else:
        # Init new Sanic app
        app = Sanic(__name__)

        # Init new router
        router = Router(ctx=app)

        # Add new route to router
        router.add(
            uri="/",
            methods=["GET"],
            handler=hello_handler,
            host=None,
            strict_slashes=False,
            stream=False,
            ignore_body=False,
            version=None,
            name="hello",
            unquote=False,
        )

        # Get route by view name

# Generated at 2022-06-24 04:38:57.981760
# Unit test for method add of class Router
def test_Router_add():
    from sanic.app import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.router import Router

    router=Router()

    class Request1(Request):
        def __init__(self):
            super().__init__(uri_template='')

        def __getattr__(self, *args):
            return None

    class Request2(Request):
        pass

    class Response(HTTPResponse):
        pass

    app = Sanic()
    router.add('/',methods=['POST'],handler=lambda x: Response(b'',status=200))
    assert router.get(path='/',method='POST',host='') == (None,lambda x: Response(b'',status=200),{})

# Generated at 2022-06-24 04:39:05.190333
# Unit test for method finalize of class Router
def test_Router_finalize():
    """Unit test for method finalize of class Router."""
    import pytest
    from sanic import Sanic
    from sanic.exceptions import SanicException
    app = Sanic("test_Router_finalize")

    router = Router.create(app)
    route = router.add("/", ["GET"])
    route.labels = {"__file_uri__": "test"}
    with pytest.raises(SanicException, match=".*use '__'.*"):
        router.finalize()

# Generated at 2022-06-24 04:39:10.432673
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.response import text
    router = Router()
    router.add("/", ["GET", "POST"], text("hello, world!"), name='home')
    router.finalize()
    path = '/'
    method = 'GET'
    host = '127.0.0.1'
    route, handler, params = router.get(path, method, host)
    assert route.name == 'home'

# Generated at 2022-06-24 04:39:20.457008
# Unit test for method finalize of class Router

# Generated at 2022-06-24 04:39:22.693123
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == 'GET'
    assert len(router.ALLOWED_METHODS) == 10


# Generated at 2022-06-24 04:39:30.894280
# Unit test for method finalize of class Router
def test_Router_finalize():
    uri = "/"
    methods = [
        "GET",
    ]
    handler = "handler"
    host = None
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = None
    unquote = False
    static = False

    router = Router()
    router.DEFAULT_METHOD = "GET"
    router.ALLOWED_METHODS = [
        "GET",
    ]
    router.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, 
        name, unquote, static)

    finalize = lambda : router.finalize()
    assert finalize() == None

# Generated at 2022-06-24 04:39:40.578784
# Unit test for method add of class Router
def test_Router_add():
    from unittest.mock import Mock
    import random
    import string
    import re
    from sanic.response import text, json
    from sanic.request import Request
    from sanic.views import HTTPMethodView
    from sanic.handlers import ErrorHandler
    
    @lru_cache(maxsize=ROUTER_CACHE_SIZE)
    def get(  # type: ignore
        self, path: str, method: str, host: Optional[str]
    ) -> Tuple[Route, RouteHandler, Dict[str, Any]]:
        try:
            return self.resolve(
                path=path,
                method=method,
                extra={"host": host},
            )
        except RoutingNotFound as e:
            return e
        except NoMethod as e:
            return

# Generated at 2022-06-24 04:39:45.085965
# Unit test for constructor of class Router
def test_Router():
    r = Router(None)
    assert r.routes == {}
    assert r.static_routes == {}
    assert r.dynamic_routes == {}
    assert r.regex_routes == {}
    assert r.name_index == {}
    assert r.app_detected == False

# Generated at 2022-06-24 04:39:45.708504
# Unit test for constructor of class Router
def test_Router():
    router = Router()


# Generated at 2022-06-24 04:39:53.517524
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    Unit test for method finalize of class Router
    """
    test_Router = Router()
    uri = '/test'
    methods = HTTP_METHODS
    handler = lambda: 1
    test_Router = test_Router.add(uri, methods, handler)
    res = test_Router.finalize()
    expected = test_Router
    assert res == expected


# Generated at 2022-06-24 04:39:56.428667
# Unit test for method finalize of class Router
def test_Router_finalize():
    pass

# Generated at 2022-06-24 04:39:57.734361
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.router_cache_size == ROUTER_CACHE_SIZE

# Generated at 2022-06-24 04:40:01.630754
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router



# Generated at 2022-06-24 04:40:04.322895
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    route = router.add('/', ['GET'], lambda: '', static=True)
    assert route.ctx.static is True



# Generated at 2022-06-24 04:40:06.499273
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router


# Unit test of function add in class Router

# Generated at 2022-06-24 04:40:08.797964
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router

# Generated at 2022-06-24 04:40:15.676654
# Unit test for method add of class Router
def test_Router_add():

    router = Router()

    uri = "/example"
    methods = ("GET", "POST")
    handler = lambda x: x
    host = None
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = None
    unquote = False
    static = False

    route = router.add(uri, methods, handler, host, strict_slashes, stream,
        ignore_body, version, name, unquote, static)
    assert hasattr(route, 'path')
    assert hasattr(route, 'handler')
    assert hasattr(route, 'methods')
    assert route.path == "/example"
    assert route.handler == handler
    assert route.methods == methods



# Generated at 2022-06-24 04:40:27.711355
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic_routing.route import Route
    from sanic_routing.router import Router

    def handler_view():
        return HTTPResponse()

    with pytest.raises(SanicException):
        router = Router(None)
        router.add("test__test", ["GET"], handler_view)
        router.finalize(None)

    with pytest.raises(SanicException):
        router = Router(None)
        router.add("test__file_uri__", ["GET"], handler_view)
        router.finalize(None)

    router = Router(None)
    router.add("test", ["GET"], handler_view)
    router.finalize(None)


# Generated at 2022-06-24 04:40:32.594903
# Unit test for method finalize of class Router
def test_Router_finalize():
    route = Route(label="1", path="", handler=None, method="GET", compile=False)
    # test for invalid route
    with pytest.raises(SanicException):
        Router(
            app=None,
            strict_slashes=False,
            default_subdomain=None,
            root_path="test_root_path",
        ).finalize([route])

# Generated at 2022-06-24 04:40:39.160702
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler

    router = Router(None)
    router.add("/", ["GET"], None, host=None, \
        strict_slashes=False, stream=False, ignore_body=False, version=None, \
        name=None, unquote=True, static=False)
    try:
        router.add("/", ["GET"], None, host=None, \
            strict_slashes=False, stream=False, ignore_body=False, \
            version=None, name=None, unquote=True, static=False)
    except SanicException as e:
        assert (str(e) == "Duplicated rule with path: / method: GET")

# Generated at 2022-06-24 04:40:40.765953
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router
    assert isinstance(router, BaseRouter)



# Generated at 2022-06-24 04:40:41.709606
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    pass

# Generated at 2022-06-24 04:40:45.489429
# Unit test for method finalize of class Router
def test_Router_finalize():
    from pathlib import Path
    import sys
    
    # execute create_app()
    sys.path.append(str(Path(__file__).parent.parent))
    from server import create_app
    app = create_app()
    
    # execute function finalize of class Router
    app.router.finalize()

# Generated at 2022-06-24 04:40:58.649981
# Unit test for method add of class Router
def test_Router_add():
    rtr = Router(None)

    host = "www.google.com"
    uri = "relative/path"
    methods = ["GET", "POST", "OPTIONS"]
    handler = lambda x: x
    strict_slashes = False
    stream = False
    ignore_body = False
    version = "1.0"
    name = "route_name"
    unquote = False

    # case 1: host is not an Iterable, ALLOWED_METHODS is satisfied
    # expected result: return a Route object

# Generated at 2022-06-24 04:41:02.566575
# Unit test for constructor of class Router
def test_Router():
    from sanic.router import Router
    router = Router()


# Generated at 2022-06-24 04:41:04.736694
# Unit test for method add of class Router
def test_Router_add():
    def handler():
        pass

    router = Router()
    router.add(uri='/', methods=['GET'], handler=handler)



# Generated at 2022-06-24 04:41:08.640977
# Unit test for constructor of class Router
def test_Router():
  a = Router(None)
  assert a.DEFAULT_METHOD == 'GET'


# Generated at 2022-06-24 04:41:11.112009
# Unit test for constructor of class Router
def test_Router():
    Router()


if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-24 04:41:14.394825
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add("/<a:int>/<b:int>", ["GET"], lambda request, a, b: "abc")
    router.add("/<a:int>/<b:int>", ["GET"], lambda request, a, b: "abc")
    router.finalize()

# Generated at 2022-06-24 04:41:18.147009
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router(None)
    # TODO: Need mock to test this part
    # with pytest.raises(SanicException):
    #     router.dynamic_routes = [Route(None, None, None, None, {"__foo": 1})]
    #     router.finalize()

# Generated at 2022-06-24 04:41:18.689847
# Unit test for method add of class Router
def test_Router_add():
    pass

# Generated at 2022-06-24 04:41:27.832470
# Unit test for method add of class Router
def test_Router_add():
    # 第一组
    uri = "/test"
    methods = ["GET"]
    handler = lambda x: x
    host = "www.sample.com"
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = None
    unquote = False
    static = False

    test_router = Router()
    test_route = test_router.add(
        uri=uri,
        methods=methods,
        handler=handler,
        host=host,
        strict_slashes=strict_slashes,
        stream=stream,
        ignore_body=ignore_body,
        version=version,
        name=name,
        unquote=unquote,
        static=static,
    )

# Generated at 2022-06-24 04:41:37.140297
# Unit test for method finalize of class Router
def test_Router_finalize():
    """testing for finalize of class Router"""

    #case1
    class SanicException(Exception):
        pass

    router = Router()
    router.dynamic_routes = {"key1" : {}, "key2": {}}
    router.dynamic_routes["key1"].labels = ["_file_uri", "__file_uri_"]
    router.dynamic_routes["key2"].labels = ["__file_uri_", "__file_ur_"]
    try:
        router.finalize()
    except SanicException as e:
        print(e)

    #case2
    router = Router()
    router.dynamic_routes = {"key1" : {}, "key2": {}}

# Generated at 2022-06-24 04:41:38.609447
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r.DEFAULT_METHOD == 'GET'
    assert r.ALLOWED_METHODS == HTTP_METHODS

# Generated at 2022-06-24 04:41:43.837112
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route(
                path="/uri/:var1",
                handler=None,
                methods=HTTP_METHODS,
                name=None,
                strict=False,
                unquote=False,
            )
    route.labels = ["__file_uri__", "a"]
    router.routes_dynamic["/uri/{var1}"] = (route, route.labels)
    router.finalize()

# Generated at 2022-06-24 04:41:54.984345
# Unit test for method add of class Router
def test_Router_add():
    class Dummy_Request:
        def __init__(self, path, method, host):
            self.path = path
            self.method = method
            self.host = host

    def handler(request, *args, **kwargs):
        return True

    router = Router(None)

    host = "0.0.0.0"
    uri = "/test"
    method = "GET"
    request = Dummy_Request(uri, method, host)

    router.add(uri, ["GET"], handler, host=host)
    assert router.get(uri, method, host) == (
        router.routes_dynamic["/"][0],
        handler,
        {},
    )

    uri = "/test/{param0}"
    router.add(uri, ["GET"], handler, host=host)

# Generated at 2022-06-24 04:41:57.099240
# Unit test for constructor of class Router
def test_Router():
    assert not Router().routes_dynamic
    assert not Router().routes_static
    assert not Router().routes_regex


# Generated at 2022-06-24 04:42:07.167184
# Unit test for method add of class Router
def test_Router_add():
    from sanic import Sanic

    app = Sanic('test_router')
    router = Router()
    router.add(uri='/', methods=['GET'], handler=app.test_handler)
    assert len(router.routes_all) == 1
    assert len(router.routes_static) == 0
    assert len(router.routes_dynamic) == 1
    assert len(router.routes_regex) == 1
    assert router.resolve("/", "GET", None)[1] == app.test_handler


if __name__ == "__main__":
    test_Router_add()

# Generated at 2022-06-24 04:42:13.802287
# Unit test for method add of class Router
def test_Router_add():
    methods = ["GET", "POST", "OPTIONS"]
    uri = "test_URI"
    handler = RouteHandler()
    host=None
    strict_slashes=False
    stream=False
    ignore_body=False
    version=None
    name=None
    route = Router().add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name)
    assert type(route) == Route

# Generated at 2022-06-24 04:42:17.404320
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    # check attributes of router
    assert router.ctx is None
    assert router.routes == dict()
    assert router.static_routes == dict()
    assert router.dynamic_routes == dict()
    assert router.regex_routes == dict()
    assert router.name_index == dict()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == tuple(["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS", "HEAD", "TRACE", "CONNECT"])


# Generated at 2022-06-24 04:42:19.723838
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, BaseRouter)

# Generated at 2022-06-24 04:42:21.736639
# Unit test for constructor of class Router
def test_Router():
    assert isinstance(Router(), Router)

# Generated at 2022-06-24 04:42:31.469107
# Unit test for method add of class Router
def test_Router_add(): 
    import pytest
    router = Router()
    assert router.add("uri", "methods", "handler") == None
    assert router.add("uri", "methods", "handler", host="host") == None
    assert router.add("uri", "methods", "handler", strict_slashes="strict_slashes") == None
    assert router.add("uri", "methods", "handler", stream="stream") == None
    assert router.add("uri", "methods", "handler", ignore_body="ignore_body") == None
    assert router.add("uri", "methods", "handler", version="version") == None
    assert router.add("uri", "methods", "handler", name="name") == None
    assert router.add("uri", "methods", "handler", unquote="unquote") == None

# Generated at 2022-06-24 04:42:33.300266
# Unit test for method add of class Router
def test_Router_add():
    def hello_handler(request):
        return response.text('Hello!' + request.args.get('name', 'Nobody'))

    router = Router()
    router.add('/hello', ['GET'], hello_handler)
    assert router.routes_all['/hello'].handler is hello_handler


# Generated at 2022-06-24 04:42:41.495551
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    Test finalize method of Router class
    """
    @lru_cache(maxsize=None)
    def resolve(self, path, method, extra):
        if self.routes:
            route = self.search(path)
            if route:
                if method in route.methods:
                    return route, route.resolve, extra
                raise NoMethod(method=method, allowed_methods=route.methods)
        raise RoutingNotFound(path=path)

    router = Router(name='test_Router_finalize', app=None)
    router.resolve = resolve
    router.dynamic_routes = {'path': Route('path', 'route', 'methods', 'ctx')}

# Generated at 2022-06-24 04:42:48.623051
# Unit test for constructor of class Router
def test_Router():
    # Simple test to check if instanciate the class
    router = Router()
    return router

if __name__ == "__main__":
    router = test_Router()
    print(router)
    # print(router.routes_all)
    # print(router.routes_dynamic)
    # print(router.routes_regex)
    # print(router.routes_static)

# Generated at 2022-06-24 04:42:51.677018
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.__class__.__name__ == "Router"

# Generated at 2022-06-24 04:42:55.395338
# Unit test for method finalize of class Router
def test_Router_finalize():

    from sanic import Sanic
    from sanic_routing.router import RoutingHandler

    app = Sanic("test_Router_finalize")
    routing_handler = RoutingHandler(app)
    router = routing_handler.router

    @app.route("/")
    def handler(request):
        pass

    router.finalize()

# Generated at 2022-06-24 04:43:03.151519
# Unit test for method finalize of class Router
def test_Router_finalize():
    # arrange
    uri = '/'
    methods = ['POST', 'GET']
    handler = RouteHandler
    # act
    route = Route(uri, methods, handler)
    # assert
    try:
        route.finalize()
    except SanicException as e:
        assert str(e)=="Invalid route: Route(/,['POST', 'GET'],RouteHandler). Parameter names cannot use '__'."



# Generated at 2022-06-24 04:43:09.380273
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Bad parameter names
    route = Route(
        method="GET",
        uri="{__file_uri__}",
        handler="handler",
        name="name",
        requirements={},
        host="host",
    )
    route.labels
    route.sanitize_parameters()
    
    router = Router()
    router.dynamic_routes['name'] = route
    router.finalize()
    assert True

# Generated at 2022-06-24 04:43:13.756725
# Unit test for method add of class Router
def test_Router_add():
    class TempClass:
        router = Router

    uri = "/dynamic/route/<int:id>"
    methods = ["GET", "POST", "OPTIONS"]
    host = "host"
    strict_slashes = False
    stream = False
    ignore_body = False
    version = "1.0"
    name = "name"
    unquote = False
    static = False
    temp_instance = TempClass()
    temp_instance.router.add(uri, methods, host, strict_slashes, stream,
                             ignore_body, version, name, unquote, static)
    pass



# Generated at 2022-06-24 04:43:21.291909
# Unit test for method add of class Router
def test_Router_add():
    url_string = "/test_data"

    router = Router()

    assert len(router.routes_all) == 0
    assert len(router.routes_static) == 0
    assert len(router.routes_dynamic) == 0
    assert len(router.routes_regex) == 0

    def dummy_handler(*args, **kwargs):
        return None

    router.add(url_string, ["GET"], dummy_handler, None, False, False, False, None, None, False, False)

    assert len(router.routes_all) == 1
    assert len(router.routes_static) == 1
    assert len(router.routes_dynamic) == 0
    assert len(router.routes_regex) == 0


# Generated at 2022-06-24 04:43:23.574290
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router

# Generated at 2022-06-24 04:43:31.263678
# Unit test for constructor of class Router
def test_Router():
    r1 = Router()
    r1.add("/hello/{name}", ("GET", "POST"), "handler")
    assert r1.find_route_by_view_name("handler", "/hello/lily") == "/hello/lily"
    assert r1.get("/hello/lily", "GET")[1] == "handler"
    assert r1.get("/hello/lily", "POST")[1] == "handler"
    assert r1.get("/hello/lily", "POST")[2]["name"] == "lily"
    assert r1.get("/hello/lily", "GET")[2]["name"] == "lily"

# Generated at 2022-06-24 04:43:35.656733
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)

# Generated at 2022-06-24 04:43:47.602762
# Unit test for method finalize of class Router
def test_Router_finalize():

    route1 = Route("/", None, ["__method"], None, False, False, False, None, None, False)
    route2 = Route("/", None, [], None, False, False, False, None, None, False)
    # Route1 is invalid, should raise exception
    with pytest.raises(SanicException) as e_info:
        router = Router()
        router.dynamic_routes = {"1": route1, "2": route2}
        router.finalize()
    assert e_info.value.args[0] == "Invalid route: <Route [GET] / {'__method': 'GET'}>. Parameter names cannot use '__'."

    # Route1 is valid
    router = Router()
    router.dynamic_routes = {"1": route1, "2": route2}


# Generated at 2022-06-24 04:43:52.483309
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    router = Router(ROUTER_CACHE_SIZE)
    router = Router(ROUTER_CACHE_SIZE, True)

if __name__ == '__main__':
    test_Router()

# Generated at 2022-06-24 04:43:53.495847
# Unit test for constructor of class Router
def test_Router():
    route = Router("test", "test")
    assert isinstance(route, Router)

# Generated at 2022-06-24 04:43:56.444795
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    from sanic.request import Request

    app = Sanic("test_Router_finalize")

    @app.route("/hello")
    async def handler(request: Request):
        pass

    url_for("handler")


# Generated at 2022-06-24 04:44:04.709220
# Unit test for method finalize of class Router
def test_Router_finalize():
    import sys
    import os
    import json
    import sanic
    sanic.__name__ = "sanic"
    from sanic.router import Router

    from unittest.mock import MagicMock, patch
    from unittest.mock import call

    try:
        from unittest.mock import AsyncMock
    except ImportError:
        from mock import AsyncMock

    def mock_exception(*args, **kwargs):
        return SanicException(
            f"Invalid route: {route}. Parameter names cannot use '__'."
        )

    # Define a mock decorator to be applied to the mock_method
    def my_decorator(function):
        def wrapper(*args, **kwargs):
            return function(*args, **kwargs)
        return wrapper


# Generated at 2022-06-24 04:44:06.733854
# Unit test for constructor of class Router
def test_Router():
    r = Router("")
    assert isinstance(r, Router)

# Generated at 2022-06-24 04:44:09.594137
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.__class__.__name__ == "Router"
    assert isinstance(router, BaseRouter)


# Generated at 2022-06-24 04:44:10.145141
# Unit test for method finalize of class Router
def test_Router_finalize():
    pass

# Generated at 2022-06-24 04:44:18.175602
# Unit test for method finalize of class Router
def test_Router_finalize():
    
    # Arrange
    router_object = Router()
    class Route:
        def __init__(self):
            self.labels = {
                "__file_uri__",
                "__custom"
            }
    dynamic_routes = {
        "dyn_route": Route()
    }
    router_object.dynamic_routes = dynamic_routes

    # Act
    try:
        router_object.finalize()
    except Exception as exception:
        actual = 1
    else:
        actual = 2

    # Assert
    assert actual == 1

# Generated at 2022-06-24 04:44:22.884380
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)
    assert router.DEFAULT_METHOD == 'GET'
    assert router.ALLOWED_METHODS == HTTP_METHODS

# Generated at 2022-06-24 04:44:24.754007
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)

#Unit test for property routes_all of class Router

# Generated at 2022-06-24 04:44:29.825379
# Unit test for constructor of class Router
def test_Router():
    @Router.get('/hi/', methods={'get'})
    def test():
        return 'hi'
    pass

# Generated at 2022-06-24 04:44:38.119407
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic_routing import Router  # type: ignore
    from sanic_routing.route import Route  # type: ignore

    class MyRoute(Route):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.labels = []

        def get_labels(self, path=None) -> List[str]:
            return self.labels

    add = Router.add
    Router.add = staticmethod(lambda *args, **kwargs: MyRoute(*args, **kwargs))
    Router.add(uri="/", methods=["GET"], handler="function")

    with pytest.raises(SanicException):
        Router.add(uri="/", methods=["GET"], handler="function", labels=["__file__"])


# Generated at 2022-06-24 04:44:45.872338
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    The following script is to test the finalize function
    in the Router class, all the error cases is ignored.
    """
    # test the finalize function when allowed_labels is 
    # ['__file_uri__']
    global ALLOWED_LABELS
    ALLOWED_LABELS = ['__file_uri__']

    class Router(BaseRouter):
        """
        The router implementation responsible for routing a :class:`Request` object
        to the appropriate handler.
        """

        DEFAULT_METHOD = "GET"
        ALLOWED_METHODS = HTTP_METHODS

        def finalize(self, *args, **kwargs):
            super().finalize(*args, **kwargs)


# Generated at 2022-06-24 04:44:48.790468
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    @router.add('/', ['GET', 'POST'], lambda x: x)
    def handler(x): return x


# Generated at 2022-06-24 04:44:59.001832
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    from sanic.exceptions import InvalidUsage
    from sanic_routing import BaseRouter
    from sanic_routing.router import Router
    from sanic_routing.exceptions import InvalidRoute

    app = Sanic()
    
    router = Router(app)
    assert router.__class__ == Router
    assert router.app == app
    assert router.ctx == app
    assert router.allowed_methods == ("HEAD", "OPTIONS", "GET", "POST", "PUT", "PATCH", "DELETE")
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.routes_all == []

# Generated at 2022-06-24 04:45:04.055993
# Unit test for method add of class Router
def test_Router_add():

    router = Router()
    router.add("/", ("POST",), "handler")
    assert router.routes_all
    hosts = [None]
    for route in router.routes_static:
        assert route.ctx.hosts == hosts
        assert route.ctx.static == True

    route = router.get("/", "POST", None)
    assert isinstance(route[0], Route)
    assert isinstance(route[1], RouteHandler)
    assert isinstance(route[2], dict)

    route = router.find_route_by_view_name("handler")
    assert isinstance(route, Route)


if __name__ == "__main__":
    test_Router_add()

# Generated at 2022-06-24 04:45:04.572145
# Unit test for method add of class Router
def test_Router_add():
    pass


# Generated at 2022-06-24 04:45:05.116596
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None

# Generated at 2022-06-24 04:45:06.161399
# Unit test for constructor of class Router
def test_Router():
    assert(Router())
