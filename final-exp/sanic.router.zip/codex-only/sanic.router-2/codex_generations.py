

# Generated at 2022-06-24 04:35:12.152693
# Unit test for method finalize of class Router
def test_Router_finalize(): # TODO: parametrize
    # default
    router = Router()
    try:
        router.finalize()
    except SanicException:
        assert False
    # with dynamic routes
    router = Router()
    router.dynamic_routes = {
        "testdynamicroute": Route(
            path="/api/{test_parameter}",
            methods=HTTP_METHODS,
            handler=None,  # type: ignore
            strict=False,
            name="testname",
            unquote=False,
            labels={"__file_uri__": "testfileuri", "test_parameter": "parameter"}
        )
    }
    try:
        router.finalize()
    except SanicException:
        assert False

# Generated at 2022-06-24 04:35:13.017015
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert not router.routes_all


# Generated at 2022-06-24 04:35:16.039485
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    @router.add(uri=r'/tests/')
    def test_add(request):
        return f"Hello, {request.url}"

    return True

# Generated at 2022-06-24 04:35:18.735463
# Unit test for constructor of class Router
def test_Router():
    # __init__
    assert Router()



# Generated at 2022-06-24 04:35:29.499754
# Unit test for method add of class Router
def test_Router_add():
    from sanic import Sanic
    uri = "www.baidu.com"
    methods = ["post", "get", "put"]
    async def handler(request):
        return "hello world"
    host = "www.baidu.com"
    strict_slashes = False
    stream = False
    ignore_body = False
    version = "1"
    name = None
    unquote = False
    static = False
    app = Sanic("test_add_route")

# Generated at 2022-06-24 04:35:30.757720
# Unit test for method add of class Router
def test_Router_add():
    pass


# Generated at 2022-06-24 04:35:36.152493
# Unit test for constructor of class Router
def test_Router():
    import pytest
    from sanic import Sanic
    from sanic.server import Stream

    app = Sanic()

    with pytest.raises(TypeError):
        Router(Sanic(), Stream())

# Generated at 2022-06-24 04:35:38.030559
# Unit test for constructor of class Router
def test_Router():
	router = Router()
	assert router != None

# Generated at 2022-06-24 04:35:48.335526
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic_routing import Router as BaseRouter
    from sanic_routing.route import Route


# Generated at 2022-06-24 04:35:51.798338
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route(router, "POST", "/test")
    route.add_uri_param({"__test": None})
    router.routes_dynamic["POST"]["/test"] = route
    try:
        router.finalize()
    except Exception as e:
        assert str(e) == "Invalid route: Route(path='/test',method='POST',handler=None). Parameter names cannot use '__'."
    

# Generated at 2022-06-24 04:35:58.505666
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ROUTER_CACHE_SIZE == 1024
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.ALLOWED_LABELS == ("__file_uri__", )


# Generated at 2022-06-24 04:36:08.868542
# Unit test for method add of class Router
def test_Router_add():
    from sanic import Sanic
    from sanic.models.handler_types import RouteHandler

    app = Sanic(__name__)
    router = app.router = Router(app)

    @app.websocket("/websocket")
    async def websocket(request, ws):
        pass

    router.add("/", ["GET"], websocket, host="example.com")
    assert len(router.host_index) == 1
    assert len(router.host_index["example.com"]) == 1
    route = router.host_index["example.com"][0]
    assert route.handler == websocket
    assert route.path == "/"
    assert route.ctx.rules["host"] == "example.com"
    assert route.ctx.ignore_body is False
    assert route.ctx.stream

# Generated at 2022-06-24 04:36:13.762816
# Unit test for method finalize of class Router
def test_Router_finalize():
    def handler():
        pass

    router = Router(test=True)
    router.add("/", "GET", handler, name="__file_uri__")

    # NOT RAISE
    router.finalize()

    router.add("/", "GET", handler, name="__file_name__")

    # RAISE
    try:
        router.finalize()
    except SanicException:
        pass

# Generated at 2022-06-24 04:36:16.156962
# Unit test for constructor of class Router
def test_Router():
  r = Router()
  assert r.DEFAULT_METHOD == "GET"
  assert r.ALLOWED_METHODS == HTTP_METHODS


# Generated at 2022-06-24 04:36:20.717514
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r._path_to_regex('/') == '^[^/]|[^/].*?'
    assert repr(r) == "<Router(0 routes)>"


# Generated at 2022-06-24 04:36:30.402016
# Unit test for method add of class Router
def test_Router_add():
    #Declare parameters
    uri = 'test'
    methods = ['GET', 'POST']
    handler = {}
    host = 'test_host'
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = None

    router = Router()
    #Call add
    result = router.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name)
    #Valid actions
    assert result.labels == {}
    assert result.methods == ['GET', 'POST']
    assert result.name == None
    assert result.path == '/test'
    assert result.regex_string == '^/test/?$'
    assert result.strict == False
    assert result.unquote == False

# Generated at 2022-06-24 04:36:40.981765
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic_routing.route import Route
    from sanic_routing.trie import Trie

    # invalid parameter:
    #   - class Router
    #   - method finalize
    #   - test case #0
    try:
        router = Router()
        for method in router.ALLOWED_METHODS:
            router.add_route(Route(None, method, None, None, None, None))

        router.finalize()
        assert False
    except Exception as ex:
        assert type(ex) is SanicException
        assert str(ex) == "Invalid route: {'__file_uri__': None}."

    # invalid parameter:
    #   - class Router
    #   - method finalize
    #

# Generated at 2022-06-24 04:36:43.369063
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    def test_handler():
        pass
    router.add("/", ["GET"], test_handler)



# Generated at 2022-06-24 04:36:54.096599
# Unit test for method add of class Router
def test_Router_add():
    import sanic

    app = sanic.Sanic()
    app.router.add("/home/<user>", ["GET"], lambda req, user: "hello", "1.0" )
    app.router.add("/home/<user>", ["POST"], lambda req, user: "hello", "1.0" )
    route = app.router.routes_dynamic.get("1.0/home/<user>")
    assert route.methods == {'GET', 'POST'}

    app2 = sanic.Sanic()
    app2.router.add("/home/<user>", ["GET", "POST"], lambda req, user: "hello", "1.0" )

# Generated at 2022-06-24 04:37:05.591618
# Unit test for method add of class Router
def test_Router_add():
    from sanic.router import Router
    from sanic.request import Request
    from sanic.response import json
    from sanic.views import CompositionView
    from sanic.views import HTTPMethodView
    import warnings

    def view_foo(*args, **kwargs):
        return "view_foo"

    def view_bar(*args, **kwargs):
        return "view_bar"

    class FooView(HTTPMethodView):
        def get(self, request: Request):
            return "foo_get"

        def put(self, request: Request):
            return "foo_put"

    class BarView(HTTPMethodView):
        def get(self, request: Request):
            return "bar_get"


# Generated at 2022-06-24 04:37:09.241412
# Unit test for constructor of class Router
def test_Router():
    class MockRouter(Router):
        def __init__(self):
            super().__init__("/test")
    assert isinstance(MockRouter(), MockRouter)

# Generated at 2022-06-24 04:37:12.655070
# Unit test for method finalize of class Router
def test_Router_finalize():
    with pytest.raises(SanicException):
        Router({"__test__": route("/", "GET", None)})

# Generated at 2022-06-24 04:37:12.967768
# Unit test for method finalize of class Router
def test_Router_finalize():
    pass

# Generated at 2022-06-24 04:37:14.228440
# Unit test for constructor of class Router
def test_Router():
    assert issubclass(Router, BaseRouter)

# Generated at 2022-06-24 04:37:21.585335
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert isinstance(r, BaseRouter)
    with pytest.raises(SanicException) as e:
        r.add("/test", ["GET"], "test")
    assert str(e.value) == "handler must be a function or list of functions"
    with pytest.raises(SanicException) as e:
        r.add("/test", ["GET"], ["test"])
    assert str(e.value) == "handler must be a function or list of functions"
    with pytest.raises(SanicException) as e:
        r.add("/test", 1, "test")
    assert str(e.value) == "methods must be an iterable"


if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-24 04:37:31.074741
# Unit test for constructor of class Router
def test_Router():

    # create a Sanic application instance
    app = Sanic()

    # initialize a Router instance
    router = Router()

    # test if basic variables are initialized properly
    assert router.ctx is None
    assert router.static_routes == []
    assert router.dynamic_routes == {}
    assert router.dynamic_routes_by_host == {}
    assert router.regex_routes == []
    assert router.routes == []
    assert router.routes_by_host == {}
    assert router.name_index == {}
    assert router.endpoints == set()

    # introduce a Sanic context
    router.ctx = app


# Generated at 2022-06-24 04:37:39.798583
# Unit test for method add of class Router
def test_Router_add():
    def handler(*args, **kwargs):
        pass

    def add(
        uri, methods, handler, host, strict_slashes, stream, ignore_body,
        version, name, unquote, static
    ):
        router = Router()
        route = router.add(
            uri, methods, handler, host, strict_slashes, stream, ignore_body,
            version, name, unquote, static
        )
        return route.path

    assert add("/", ("GET", "POST", "OPTIONS"), handler, None, False, False,
               False, None, None, False, False) == "/"
    assert add("/", ("GET", "POST", "OPTIONS"), handler, None, False, False,
               False, None, None, True, False) == "/"

# Generated at 2022-06-24 04:37:40.564232
# Unit test for constructor of class Router
def test_Router():
    router = Router()

# Generated at 2022-06-24 04:37:43.962815
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    from sanic import Sanic
    from sanic.response import text
    from sanic.router import Router

    app = Sanic("test_Router_finalize")

    @app.route("/")
    def handler(request):
        return text("OK")

    # create Router object
    router = Router(app)
    # add route to Router
    router.add("/", ["GET"], handler)
    # add route to Router with invalid label
    router.add("/{__foo}", ["GET"], handler)

    # call method finalize
    with pytest.raises(SanicException):
        router.finalize()



# Generated at 2022-06-24 04:37:44.686329
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert isinstance(r, BaseRouter)

# Generated at 2022-06-24 04:37:46.032571
# Unit test for constructor of class Router
def test_Router():
    r = Router()

# TODO:

# Generated at 2022-06-24 04:37:53.600650
# Unit test for method add of class Router
def test_Router_add():
    routes = Router()
    routes.add("/static/<name>", ['GET'], handler=None, name='static')
    assert routes.find_route_by_view_name('static') is not None
    routes.add("/files/<file>", ['GET'], handler=None, name='files')
    assert routes.find_route_by_view_name('files') is not None
    routes.add("/", ['GET'], handler=None, name='index')
    assert routes.find_route_by_view_name('index') is not None
    routes.add("/about", ['GET'], handler=None, name='about')
    assert routes.find_route_by_view_name('about') is not None

# Generated at 2022-06-24 04:38:05.586972
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        class A:
            class Router(Router):
                def __init__(self):
                    self.app = None
                    self.ctx = None
                    self.static_routes = {}
                    self.regex_routes = {}
                    self.dynamic_routes = {'bla': Route('__helper__', '', '', None, (), None, {}, None)}
            router = Router()
        router = A.Router()
        router.finalize()
    except SanicException as err:
        assert str(err) == "Invalid route: Route(__helper__). Parameter names cannot use '__'."
    router.dynamic_routes = {'bla': Route('__file_uri__', '', '', None, (), None, {}, None)}
    router.finalize

# Generated at 2022-06-24 04:38:12.535471
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router._get == router.get
    assert router.routes_all == router.routes
    assert router.routes_static == router.static_routes
    assert router.routes_dynamic == router.dynamic_routes
    assert router.routes_regex == router.regex_routes


# Generated at 2022-06-24 04:38:21.353348
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    test_uri = "test"
    test_methods = ["GET", "POST", "OPTIONS"]
    test_handler = None
    test_host = None
    test_strict_slashes = False
    test_stream = False
    test_ignore_body = False
    test_version = None
    test_name = None

    assert router.add(test_uri, test_methods, test_handler) != None


# Generated at 2022-06-24 04:38:25.205207
# Unit test for constructor of class Router
def test_Router():
    router = Router("test_uri", "test_method")
    assert router.path == "test_uri" and router.method == "test_method"


# Generated at 2022-06-24 04:38:36.748436
# Unit test for method add of class Router
def test_Router_add():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView

    class TestView(HTTPMethodView):
        async def get(self, request: Request) -> HTTPResponse:
            return await HTTPResponse(status=200)

        async def post(self, request: Request) -> HTTPResponse:
            return await HTTPResponse(status=200)

    app = Sanic()

    app.add_route(TestView.as_view(), "/")

    assert len(app.router.routes_all) == 2
    assert len(app.router.routes_regex) == 0

# Generated at 2022-06-24 04:38:39.589326
# Unit test for constructor of class Router
def test_Router():
    assert Router.__name__ == 'Router'


# Generated at 2022-06-24 04:38:46.766176
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Case for invalid route
    router = Router()
    route = Route(path="/:id/:__page/:name", handler=None, methods=["GET"])
    router.dynamic_routes = {route: route}
    with pytest.raises(SanicException):
        router.finalize()

    # Case for valid route
    router = Router()
    route = Route(path="/:id/:__file_uri__/:name", handler=None, methods=["GET"])
    router.dynamic_routes = {route: route}
    router.finalize()



# Generated at 2022-06-24 04:38:47.831023
# Unit test for constructor of class Router
def test_Router():
    router = Router()



# Generated at 2022-06-24 04:38:56.497084
# Unit test for method add of class Router
def test_Router_add():
    from sanic.app import Sanic
    from sanic.response import json
    from sanic_routing.route import Route
    from sanic_routing.router import Router

    app = Sanic()
    router = Router(uri_prefix = None, app = app, strict_slashes = True)
    methods = ["GET"]
    expected_host = 'host.com'
    expected_handler = json({"message": "Hello"})
    expected_strict_slashes = False
    expected_stream = False
    expected_ignore_body = False
    expected_version = None
    expected_name = 'test'
    expected_unquote = False
    expected_static = True
    expected_uri = '/'


# Generated at 2022-06-24 04:38:59.123529
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.ctx.app == None

# Generated at 2022-06-24 04:39:03.324801
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route('/test', None, ['__test'])
    router.routes_dynamic[0] = route
    router.finalize()
    router.routes_dynamic[0].labels = ['__file_uri__']
    router.finalize()

# Generated at 2022-06-24 04:39:10.759390
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic_routing.route import Route
    from sanic.app import Sanic
    app = Sanic(__name__)
    router = Router(app, "RouterTest")
    route = Route(router, "/test", None, name="test")
    route.labels.add("__file_uri__")
    route.labels.add("__test_label__")

    # First test (when it should work)
    try:
        router.finalize()
    except SanicException:
        assert 0

    # Second test (when it shouldn't work)
    assert 1

# Generated at 2022-06-24 04:39:16.521792
# Unit test for constructor of class Router
def test_Router():
    import sanic
    app = sanic.Sanic()
    router = Router(app)
    assert router.routes == {}
    assert router.routes_regex == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.ctx.app == app
    assert router.ctx.cache_size == 1024

# Generated at 2022-06-24 04:39:17.183894
# Unit test for constructor of class Router
def test_Router():
    Router()

# Generated at 2022-06-24 04:39:25.900518
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    result = router.add(uri='/uri', 
                        methods=['POST'], 
                        handler=None, 
                        host="", 
                        strict_slashes=False, 
                        stream=False, 
                        ignore_body=False, 
                        version=None, 
                        name=None)
    assert result.path == '/uri'
    assert result.methods == ['POST']

# Generated at 2022-06-24 04:39:34.213771
# Unit test for method add of class Router
def test_Router_add():
    from sanic.router import Router
    from sanic.views import HTTPMethodView
    router = Router()
    class testview(HTTPMethodView):
        def get(self, request):
            return "GET Hello"
        def post(self, request):
            return "POST Hello"
        def options(self, request):
            return "OPTIONS Hello"
        def put(self, request):
            return "PUT Hello"
        def delete(self, request):
            return "DELETE Hello"
        def head(self, request):
            return "HEAD Hello"
        def trace(self, request):
            return "TRACE Hello"
    

# Generated at 2022-06-24 04:39:44.475631
# Unit test for method finalize of class Router
def test_Router_finalize():
    from unittest import TestCase
    from unittest.mock import AsyncMock, Mock
    from sanic.router import Router

    class TestRouter(Router):
        def __init__(self, app=None):
            super().__init__(app)
            self.routes_all = [Mock()]

        def add(self, *args, **kwargs):
            mock = Mock()
            mock.labels = []
            return mock

    class TestCaseRoute(TestCase):
        def test_invalid_route(self):
            test_router = TestRouter()
            test_router.routes_all[0].labels.append("__test__")
            self.assertRaises(SanicException, test_router.finalize)


# Generated at 2022-06-24 04:39:51.259479
# Unit test for method finalize of class Router
def test_Router_finalize():
    # test normal case
    my_router = Router()
    assert my_router.finalize == BaseRouter.finalize
    # test case with param *args and **kwa
    my_router.finalize(1,2,3)

    # test case with excpetion
    my_router = Router()
    my_router.dynamic_routes = {"a": "a"}
    try:
        my_router.finalize()
    except BaseException as e:
        assert isinstance(e, SanicException)
        assert str(e) == "Invalid route: a. Parameter names cannot use '__'."


# Generated at 2022-06-24 04:39:56.528008
# Unit test for method finalize of class Router
def test_Router_finalize():
    with pytest.raises(SanicException):
        Router().finalize({
            "/<id:int>": {"methods": []},
            "/<name:string>": {"methods": []},
            "/<__file_uri__:string>": {"methods": []},
            "/<__hello:string>": {"methods": []},
            "/<name:string>/<id:int>": {"methods": []},
        })

# Generated at 2022-06-24 04:40:04.739476
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    app = Sanic("test")
    router = Router(app)
    try:
        router.add("/<__>/")
    except Exception as e:
        assert isinstance(e, SanicException)
        assert str(e) == "Invalid route: GET /<__>/. Parameter names cannot use '__'."
    else:
        assert False
        # No exception was raised

# Generated at 2022-06-24 04:40:14.041589
# Unit test for method add of class Router
def test_Router_add():
    from sanic.model.route import  Route
    def f(x):
        return x
    rid = Router()
    assert isinstance(rid.add('/123/456', ["GET", "POST", "OPTIONS"], f), Route)
    assert isinstance(rid.add('/123/456'), Route)
    assert isinstance(rid.add('/123/456', stream = True), Route)
    assert isinstance(rid.add('/123/456', static= True), Route)
    assert isinstance(rid.add('/123/456', strict_slashes=True), Route)
    assert isinstance(rid.add('/123/456', unquote=True), Route)


# Generated at 2022-06-24 04:40:26.939976
# Unit test for method add of class Router
def test_Router_add():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.router import Router as Router_
    from sanic.testing import create_test_server, SanicTestClient

    from .router_import_class.router import Router_ as Router_
    from .router_import_class.router import test_Router_add as test_Router_add

    app = Sanic()

    @app.route("/")
    async def handler(request):
        return text("OK")

    @app.route("/", methods=["POST"])
    async def handler(request):
        return text("OK")

    @app.get("/")
    async def handler(request):
        return text("OK")


# Generated at 2022-06-24 04:40:32.279191
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    Happy path.
    """
    router = Router()
    router.add(uri = "/uri", methods = ["GET"], handler = "handler",
    host = "host", strict_slashes = False, stream = False, ignore_body = False,
    version = "version", name = "name", unquote = False, static = False)

    # no exception is raised
    router.finalize()

# Generated at 2022-06-24 04:40:37.124456
# Unit test for method finalize of class Router
def test_Router_finalize():
    from unittest.mock import MagicMock
    from sanic.router import Router

    route = MagicMock()
    route.labels = ['__some']

    dynamic_routes = {'some': route}
    router = Router()
    router.dynamic_routes = dynamic_routes

    try:
        router.finalize()
    except Exception as e:
        assert e.args[0] == "Invalid route: <Mock id='4433444448'>." \
                            " Parameter names cannot use '__'."

# Generated at 2022-06-24 04:40:40.090132
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic_routing.router import Router
    class TestRouter(Router):
        def finalize(self, **kwargs):
            super().finalize(**kwargs)
    router = TestRouter(path="/")
    router.add("/", ["GET"], lambda req: None)
    assert router._get("/", "GET", host="localhost") is not None

# Generated at 2022-06-24 04:40:40.651114
# Unit test for constructor of class Router
def test_Router():
    pass

# Generated at 2022-06-24 04:40:48.024555
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Test with invalid route
    with pytest.raises(SanicException) as context:
        route = Route('/', lambda: 'OK', methods=['GET'])
        router = Router()
        router.dynamic_routes['/'] = [route]
        router.finalize()
    assert "Invalid route: " in str(context.value)
    # Test with valid route
    route = Route('/', lambda: 'OK', methods=['GET'], name='__file_uri__')
    router = Router()
    router.dynamic_routes['/'] = [route]
    router.finalize()
    assert router.dynamic_routes['/'] == [route]

# Generated at 2022-06-24 04:40:59.980494
# Unit test for constructor of class Router
def test_Router():
    # Constructor of class Router
    router = Router()

    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS

    # Test _get method
    # Case 1: path = "b", method = "GET", host = "sanic"
    try:
        router._get("b", "GET", "sanic")
    except NotFound:
        pass
    else:
        assert False

    # Test add method
    # Case 1: uri = "a", methods = ["GET", "POST"], handler = "a", host = "sanic"
    router.add("a", ["GET", "POST"], "a", host="sanic")

    # Test find_route_by_view_name method
    # Case 1: view_name = "a"
    assert router.find

# Generated at 2022-06-24 04:41:03.409735
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router(ctx=None)
    for route in router.dynamic_routes.values():
        if any(
            label.startswith("__") and label not in ALLOWED_LABELS
            for label in route.labels
        ):
            raise SanicException(
                f"Invalid route: {route}. Parameter names cannot use '__'."
            )

# Generated at 2022-06-24 04:41:13.529831
# Unit test for method finalize of class Router
def test_Router_finalize():
    uri = "/"
    methods = ('get',)
    handler = None
    strict_slashes = False
    stream = False
    ignore_body = False
    version = 1
    name = None
    unquote = False
    static = False
    router = Router()
    

# Generated at 2022-06-24 04:41:22.622934
# Unit test for constructor of class Router
def test_Router():
  # Test for _add_handler method.
  # Method should create at least 1 Route object in self.routes
  @app.route('/test_router', methods=['GET'])
  async def test_router(request):
    # do something
    return 'OK'
  router = Router()
  router._add_handler(app.router.routes[0])
  assert len(router.routes) == 1

  # Test for add method.
  # Method should create at least 1 Route object in self.routes
  router.add('/test_router', ['GET'], test_router, strict_slashes=True)
  assert len(router.routes) == 2

  # Test for finalize method.
  # Method should create at least 1 Route object in self.dynamic

# Generated at 2022-06-24 04:41:30.670461
# Unit test for method finalize of class Router
def test_Router_finalize():
	args = "A", "B"
	kwargs = {"C": 2, "D": 3}
	router = Router()
	route = Route("path","handler", "GET", "", False)
	route.labels.append("__file_uri__")
	route.labels.append("__another__")
	router.dynamic_routes["dynamic"] = route
	try:
		router.finalize(*args, **kwargs)
	except SanicException:
		assert True
	else:
		assert False

# Generated at 2022-06-24 04:41:35.139768
# Unit test for method add of class Router
def test_Router_add():
    r = Router()
    r.add("/", "GET", lambda: "abc")
    r.add("/abc", "GET", lambda: "abc")


# Generated at 2022-06-24 04:41:45.704370
# Unit test for method add of class Router
def test_Router_add():
    print("test_Router_add")
    from sanic.app import Sanic
    from sanic.request import Request
    from sanic.response import json, text
    from sanic_routing import Router, Route

    app = Sanic("sanic-router")

    @app.route("/", methods=["GET", "POST"])
    async def handler_1(request: Request):
        pass

    @app.route("/b", methods=["GET", "POST"])
    async def handler_2(request: Request):
        pass

    @app.route("/c", methods=["GET", "POST"])
    async def handler_3(request: Request):
        pass


# Generated at 2022-06-24 04:41:48.152294
# Unit test for constructor of class Router
def test_Router():
    assert Router.__name__ != "Router"

# Generated at 2022-06-24 04:41:55.346739
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    from sanic_routing import Routing

    app = Sanic()
    routing = Routing(app)
    router = Router(routing.ctx)

    # testing for invalid route
    route = Route(
        *args,
        **{"path": "/", "route_handler": None, "methods": ["GET"]}
    )
    route.labels = ("__parameter_name__",)
    router.dynamic_routes.update({"/": route})
    with pytest.raises(SanicException):
        router.finalize()



# Generated at 2022-06-24 04:42:05.750188
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router._get("/test", "GET", "host") == (None, None, {})
    assert router.get("/test", "GET", "host") == (None, None, {})
    assert router.get("/test", "GET", "host") == (None, None, {})
    # assert router.add("/test", "GET", None)  # TODO: This returns error
    assert router.find_route_by_view_name("/test") == None
    assert router.routes_all == {}
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []

# Generated at 2022-06-24 04:42:09.940160
# Unit test for method add of class Router
def test_Router_add():
    """ Unit test for method add of class Router """
    router = Router()
    route_added = router.routes_all
    assert len(route_added) == 0


# Generated at 2022-06-24 04:42:18.147404
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    from sanic.exceptions import SanicException
    
    with pytest.raises(SanicException):
        routes = [
            (r"/users/<id:int>", users, ["GET", "POST", "HEAD", "PUT", "OPTIONS"]),
            (r"/users/<id:int>/<__name>", users, ["GET", "POST", "HEAD", "PUT", "OPTIONS"]),
        ]
        router = Router()
        for uri, handler, methods in routes:
            router.add(uri, methods, handler)
        router.finalize()

# Generated at 2022-06-24 04:42:25.149288
# Unit test for method finalize of class Router
def test_Router_finalize():
    route = Route(path="/")
    route.labels = ["__foo__","__file_uri__"]
    router = Router(ctx=object())
    router.dynamic_routes = {"a":route}
    with pytest.raises(SanicException) as exception:
        router.finalize()
    assert str(exception.value) == "Invalid route: <Route / ()>. Parameter names cannot use '__'."

# Generated at 2022-06-24 04:42:34.087923
# Unit test for method finalize of class Router
def test_Router_finalize():
    err = None
    try:
        route = Route(
            path="/",
            handler="test_handler",
            methods=["GET"],
            labels=["test", "__file_uri__"]
        )
        routes = {
            "": route
        }
        router = Router()
        router.dynamic_routes = routes
        router.finalize()
    except Exception as e:
        err = e

    assert err
    assert err.args[0] == (
        "Invalid route: Route(path=/, handler='test_handler', methods=['GET'], "
        "labels=['test', '__file_uri__'], middlewares=[], stream=False, "
        "strict=False, name=None, unquote=False). Parameter names cannot use '__'."
    )

# Generated at 2022-06-24 04:42:37.715435
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        r = Router("", None)
        r.dynamic_routes = {"a": {"labels": ["__file_uri__"]}}
        r.finalize()
    except  RoutingNotFound:
        pass
    except SanicException:
        pass


# Generated at 2022-06-24 04:42:39.630003
# Unit test for method add of class Router
def test_Router_add():
    # TODO
    pass


# Generated at 2022-06-24 04:42:44.167262
# Unit test for constructor of class Router
def test_Router():
    try:
        router = Router(app = None)
    except Exception as e:
        assert False, "Create router failed. Exception: %s"%str(e)
    else:
        assert True


# Generated at 2022-06-24 04:42:53.158755
# Unit test for method add of class Router
def test_Router_add():
    from sanic.sanic import Sanic
    app = Sanic("test_Router_add")
    uri = "/test_Router_add"
    methods = ["GET", "POST", "OPTIONS"]
    host = None
    def handler(*args, **kwargs):
        return "test_Router_add"
    strict_slashes = False
    stream = False
    ignore_body = False
    version = 1.0
    name = None
    unquote = False
    static = False

    router = Router(app, app.error_handler)
    router.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)
    # Test the case where the function passed in is not a function
    # with pytest.raises(TypeError) as

# Generated at 2022-06-24 04:43:00.083291
# Unit test for method add of class Router
def test_Router_add():
    # Test 1: 
    # uri: "uri_test",
    # methods: ['OPTIONS', 'GET', 'HEAD'],
    # handler: "new_handler",
    # host: None,
    # strict_slashes: False,
    # stream: False,
    # ignore_body: False,
    # version: None,
    # name: None,
    # unquote: False,
    # static: False,
    router = Router()
    router.add(
        uri = "uri_test",
        methods = ['OPTIONS', 'GET', 'HEAD'],
        handler = "new_handler",
    )
    # router.add(
    #     uri = "uri_test",
    #     methods = ['OPTIONS', 'GET', 'HEAD'],
    #     handler =

# Generated at 2022-06-24 04:43:10.418168
# Unit test for method add of class Router
def test_Router_add():
    from sanic.exceptions import InvalidUsage
    from sanic.routing import Router

    router = Router()

    #add a route
    route = router.add(
        "/",
        ["get", "post"],
        lambda req: "OK",
        stream=True,
    )

    assert route.name == None
    assert route.stream == True
    assert route.ctx.ignore_body == False
    assert route.ctx.stream == True
    assert route.ctx.hosts == [None]
    assert route.ctx.static == False

    #add a route name
    route = router.add(
        "/post",
        ["get", "post"],
        lambda req: "OK",
        stream=True,
        name="add_post"
    )

    assert route.name == "add_post"
    assert route

# Generated at 2022-06-24 04:43:18.388079
# Unit test for constructor of class Router
def test_Router():
    import pytest
    from routemaster.router import Router  # type: ignore
    router = Router()
    assert router is not None
    assert len(router.routes_all) == 0
    assert len(router.routes_dynamic) == 0
    assert len(router.routes_static) == 0
    assert len(router.routes_regex) == 0

# Generated at 2022-06-24 04:43:25.060492
# Unit test for method add of class Router
def test_Router_add():
    uri = ""
    methods = "get"
    handler = ""
    host = "localhost"
    strict_slashes = False
    stream = True
    ignore_body = False
    version = "1.0"
    name = "test1"
    unquote = False
    static = True
    r = Router()
    r.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)


# Generated at 2022-06-24 04:43:33.143874
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Not a mock test
    # Because the class attribute of this class is a variable of type dict
    # the variable is initialized by the dict() constructor by default
    # and the value is not affected by the variable's state change
    # So it is not easy to directly test
    #
    # So here, test a scenario where the variable is not initialized
    # to execute code in the exception handling block
    route = Router()
    setattr(route, "dynamic_routes", None)

    try:
        route.finalize(route)
    except SanicException as e:
        assert isinstance(e, SanicException)
        assert e.args[0] == "No routes have been added to the router"
    
    setattr(route, "dynamic_routes", [])
    route.finalize(route)
    #

# Generated at 2022-06-24 04:43:35.255794
# Unit test for method finalize of class Router
def test_Router_finalize():
    pass



# Generated at 2022-06-24 04:43:40.122825
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert(r)
    name = "router"
    assert(r.name == name)


# Generated at 2022-06-24 04:43:48.675079
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    from sanic_routing.route import Route
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS

    router = Router()
    func_test: RouteHandler = lambda request: "OK"
    
    route = Route('/test', methods=HTTP_METHODS, handler=func_test, strict=False, unquote=False, name='test')
    router.dynamic_routes[id(route)] = route
    route = Route('/test2', methods=HTTP_METHODS, handler=func_test, strict=False, unquote=False, name='test')
    router.dynamic_routes[id(route)] = route

    router.finalize()
    with pytest.raises(SanicException) as excinfo:
        router._

# Generated at 2022-06-24 04:43:56.651036
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    for route in r.dynamic_routes.values():
        assert any(
            isinstance(label, str) and label not in ALLOWED_LABELS
            for label in route.labels
        ) == True

    r.finalize()
    for route in r.dynamic_routes.values():
        assert any(
            isinstance(label, str) and label not in ALLOWED_LABELS
            for label in route.labels
        ) == False

# Generated at 2022-06-24 04:44:04.894588
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic_routing import Router as RoutingRouter  # type: ignore
    from sanic_routing.route import Route  # type: ignore
    from sanic.constants import ROUTER_CACHE_SIZE  # type: ignore
    from sanic.exceptions import SanicException  # type: ignore

    route_handler = lambda: None
    uri = "/users/{user_id}"

    # Invalid route: route.labels contains one disallowed parameter name
    route = Route(None, None, None, uri, route_handler, None)
    route.labels = ["__disallowed_parameter_name__"]

    router = Router(cache_size=ROUTER_CACHE_SIZE, app=None)
    router.dynamic_routes["/users/{user_id}"] = route

# Generated at 2022-06-24 04:44:08.423818
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.name_index == {}
    assert router.ctx is not None
    #print("ok")

#Unit test for method get of class Router

# Generated at 2022-06-24 04:44:14.317802
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.exceptions import SanicException
    from sanic.router import Router
    r = Router()
    with pytest.raises(SanicException) as e_info:
        r.finalize()
    assert "Invalid route: " in str(e_info.value)

# Generated at 2022-06-24 04:44:19.251487
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r.DEFAULT_METHOD == "GET"
    assert r.ALLOWED_METHODS == HTTP_METHODS
    assert r.routes == {}
    assert r.name_index == {}
    assert r.dynamic_routes == {}
    assert r.regex_routes == {}
    assert r.static_routes == {}
    assert r.ctx == None


# Generated at 2022-06-24 04:44:22.659724
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add("/", ["GET", "POST", "OPTIONS"], handler)
    print(router.routes)

# Generated at 2022-06-24 04:44:29.064489
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == frozenset(HTTP_METHODS)
    assert router.routes == {}
    assert router.name_index == {}
    assert router.ctx.app is None
    assert router.ctx.router is router
    assert not hasattr(router, 'routes_all')
    assert not hasattr(router, 'routes_static')
    assert not hasattr(router, 'routes_dynamic')
    assert not hasattr(router, 'routes_regex')


# Generated at 2022-06-24 04:44:30.869426
# Unit test for method finalize of class Router
def test_Router_finalize():
    ok = True
    try:
        Router(None).finalize()
    except SanicException as e:
        ok = False
    assert ok

# Generated at 2022-06-24 04:44:38.179455
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    from sanic.exceptions import SanicException
    from sanic.router import Router
    from sanic.response import json
    from sanic.views import HTTPMethodView
    
    try:
        class MyClass(HTTPMethodView):
            def get(self, request, name):
                return json({'received': name})


        r = Router()
        r.add('/', ['GET'], MyClass.as_view(), name=MyClass.__name__)
        r.finalize()
    except SanicException as e:
        pytest.fail(f"Unexpected exception raised: {e}")
    
    
    
    

# Generated at 2022-06-24 04:44:42.217622
# Unit test for method finalize of class Router
def test_Router_finalize():
    assert Router().finalize(all=None, name=None, regex=None,
                             sort=None, converters=None) == None
    assert Router().finalize(all='', name='', regex='',
                             sort='', converters='') != None

# Generated at 2022-06-24 04:44:44.781114
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router


# Generated at 2022-06-24 04:44:48.854590
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}



# Generated at 2022-06-24 04:44:53.886705
# Unit test for constructor of class Router
def test_Router():
    router = Router()

    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}

# Generated at 2022-06-24 04:44:59.805707
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.blueprints import Blueprint

    router = Router()
    blueprint = Blueprint("inject", url_prefix="/inject")
    blueprint.inject(router)
    router.finalize()
    router.finalize()
    router.finalize(blueprint.name)

# Generated at 2022-06-24 04:45:04.069963
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    from sanic.response import text
    from sanic.router import Router

    app = Sanic()
    router = Router(app)

    @app.route('/', methods=["GET"])
    async def test1(request):
        return text('route')

    router.finalize()
# End unit test for method finalize of class Router

# Generated at 2022-06-24 04:45:06.520021
# Unit test for method add of class Router
def test_Router_add():
    """
    Test Router method add
    """
    # Create a new instance of Router object
    router = Router()

    # Call method add of object router
    router.add(uri='/', methods=('GET',), handler=None, host=None, strict_slashes=False, stream=False, ignore_body=False, version=None, name=None, unquote=False, static=False)