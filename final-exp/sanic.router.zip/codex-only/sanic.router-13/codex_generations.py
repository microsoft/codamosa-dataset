

# Generated at 2022-06-24 04:35:08.378630
# Unit test for method add of class Router
def test_Router_add():
    # Arrange
    uri = "/index.html"
    methods = ["GET", "POST", "OPTIONS"]
    handler = lambda request: 0
    host = "myhost"
    strict_slashes = True
    stream = True
    ignore_body = False
    version = 0
    name = "route1"
    unquote = True
    static = False
    router = Router()

    # Act
    router.add(
        uri=uri,
        methods=methods,
        handler=handler,
        host=host,
        strict_slashes=strict_slashes,
        stream=stream,
        ignore_body=ignore_body,
        version=version,
        name=name,
        unquote=unquote,
        static=static,
    )

    # Assert

# Generated at 2022-06-24 04:35:17.456438
# Unit test for method add of class Router
def test_Router_add():
    import sanic_routing
    def test_handler():
        return "test_result_from_test_handler"
    router = sanic_routing.Router()
    route = router.add("/test_path", ["GET"], test_handler, None, False, None, None, None, None, None, None)
    assert route.path == "/test_path"
    assert route.handler == test_handler
    assert route.methods == ("GET",)
    assert route.strict == False
    assert route.name == None
    assert isinstance(route.ctx, sanic_routing.route.Context)



# Generated at 2022-06-24 04:35:24.567864
# Unit test for constructor of class Router
def test_Router():
    route = Router()
    assert route.routes == {}
    assert route.static_routes == {}
    assert route.dynamic_routes == {}
    assert route.regex_routes == {}
    assert route.named_routes == {}
    assert route.file_uri_cache == {}
    assert route.ctx.hosts == []
    assert route.ctx.host == None


# Generated at 2022-06-24 04:35:27.035188
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)
    assert router.DEFAULT_METHOD == "GET"

# Generated at 2022-06-24 04:35:29.535362
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    uri = "/path/<name>/<age>"
    with raises(SanicException):
        router.add(uri=uri, methods=["get"], handler=None)

# Generated at 2022-06-24 04:35:36.310385
# Unit test for method finalize of class Router
def test_Router_finalize():
    class routerRouter(Router):
        def __init__(self, app, *args, **kwargs):
            super().__init__(app, *args, **kwargs)
            self.dynamic_routes = {
                'dynamic_1' : {"labels": ['__file_uri__', '__path_uri__']}
            }

    router_instance = routerRouter(None)
    router_instance.finalize()

# Generated at 2022-06-24 04:35:44.947910
# Unit test for method add of class Router
def test_Router_add():
    from sanic.response import text
    router = Router()
    route = router.add(
        uri="/", methods=["GET"], handler=text("ok"), strict_slashes=False, stream=False, ignore_body=True, version=None, name="index"
    )
    assert route.path == "/"
    assert route.methods == ["GET"]
    assert route.ctx.ignore_body is True
    assert route.ctx.stream is False
    assert route.ctx.name == "index"
    assert route.ctx.unquote is False


# Generated at 2022-06-24 04:35:52.543530
# Unit test for constructor of class Router
def test_Router():
    ### Construction of object Router
    router = Router()
    assert router.routes_all == []
    assert router.ctx == {}
    assert router.dynamic_routes == {}
    assert router.flat_routes == []
    assert router.name_index == {}
    assert router.regex_routes == []
    assert router.static_routes == {}



# Generated at 2022-06-24 04:35:58.562656
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes == {}
    assert router.static_routes == {}
    assert router.regex_routes == {}
    assert router.dynamic_routes == {}
    assert router.name_index == {}
    assert router._resolver is not None


# Generated at 2022-06-24 04:36:08.869172
# Unit test for method add of class Router
def test_Router_add():
  def test_handler():
    pass
  router = Router()

  def test_labels(label_name):
    labels = router.labels
    assert label_name not in labels
    router.add("/test", ["GET"], test_handler)
    router.add("/test", ["POST"], test_handler)
    router.add("/test", ["OPTIONS"], test_handler)
    labels = router.labels
    assert label_name in labels
    return labels[label_name]

  def add_labels(label_name, label_value):
    for method in ["GET", "POST", "OPTIONS"]:
      route = router._routes_static[str(label_value)].get(method)
      assert route is not None
      route.labels[label_name] = label_value

  #

# Generated at 2022-06-24 04:36:17.655045
# Unit test for method finalize of class Router
def test_Router_finalize():
    import sys
    import pytest
    if sys.version_info < (3, 6):
        pytest.skip('Test finalize skipped for Python < 3.6 (it uses f-strings)')

    from sanic.router import Router
    from sanic_routing import Route

    router = Router(app="", strict_slashes=False)
    # successful case
    route = Route(uri="/<param>", method="GET", handler=None, name=None,
                  host=None, strict_slashes=False, stream=False,
                  unquote=False, static=False)
    router.routes_dynamic = {"/<param>": route}
    assert router.finalize() is None

    # error case

# Generated at 2022-06-24 04:36:25.754799
# Unit test for method add of class Router
def test_Router_add():
    app = Sanic("test_app")

    @app.listener("before_server_start")
    async def before_server_start(app, loop):  # pylint: disable=unused-argument
        router = app.router

        route = router.add("/", ["GET"], "handler")
        assert isinstance(route, Route)
        assert "/" == route.path
        assert ("handler",) == route.handler

        assert router.routes_all
        assert router.routes_static  # pylint: disable=no-member
        assert not router.routes_regex

        sync_handler = lambda x, y: x

        route = router.add("/sync_handler", ["GET"], sync_handler)
        assert isinstance(route, Route)
        assert "/sync_handler" == route

# Generated at 2022-06-24 04:36:26.377774
# Unit test for constructor of class Router
def test_Router():
    pass

# Generated at 2022-06-24 04:36:36.165122
# Unit test for method add of class Router
def test_Router_add():
    import io
    from sanic import Sanic
    from sanic.response import text

    app = Sanic("test_Router_add")

    def handle(request):
        return text("OK")

    @app.route("/b")
    async def handle_get(request):
        return text("OK")

    @app.post("/b")
    async def handle_post(request):
        return text("OK")

    @app.route("/a", methods=["PUT", "PATCH"])
    async def handle_put_patch(request):
        return text("OK")

    @app.route("/c", methods=["GET", "POST"], stream=True)
    async def handle_stream(request):
        return text("OK")


# Generated at 2022-06-24 04:36:41.811556
# Unit test for method add of class Router
def test_Router_add():
    from sanic import Sanic
    from sanic.config import LOGGING
    router = Router(Sanic("test_add_router").config.LOGGING)
    router.add("/test/", ["GET", "POST", "OPTIONS"], lambda request: "test")
    if not router.routes_all:
        raise AssertionError("Expected True, got False")

# Generated at 2022-06-24 04:36:43.144957
# Unit test for method finalize of class Router
def test_Router_finalize():
    assert 1 == 1


# Generated at 2022-06-24 04:36:51.342390
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add('/', ['GET'], handler=1)
    router.add('/', ['POST'], handler=1, host=None)
    router.add('/', ['GET'], handler=1, host='*')
    router.add('/', ['GET', 'POST'], handler=1, host='*')
    router.add('/', ['GET'], handler=1, host=['*', '*'])
    


# Generated at 2022-06-24 04:36:56.262884
# Unit test for method add of class Router

# Generated at 2022-06-24 04:36:58.643597
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS

# Generated at 2022-06-24 04:37:02.387748
# Unit test for method finalize of class Router
def test_Router_finalize():
  app = Sanic('__main__')
  department_router = Router()
  department_router.add('/', None)
  assert department_router.finalize() == None

# Generated at 2022-06-24 04:37:12.548880
# Unit test for constructor of class Router
def test_Router():
    uri = "/"
    method = "get"
    host = "localhost"
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.get(uri,method,host) == ()
    uri = "/"
    method = "get"
    host = "localhost"
    assert router._get(uri,method,host) == ()
    assert router.add(uri,method,host) == []
    assert router.find_route_by_view_name("") == None
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []


# Generated at 2022-06-24 04:37:16.318331
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None
    assert router.routes_all == [], "Constructor {} does not return empty list.".format(router)

# Generated at 2022-06-24 04:37:25.063136
# Unit test for method add of class Router
def test_Router_add():
    r = Router()
    r.add("/test_add_1/<name>", ["GET", "POST", "OPTIONS"], lambda x, y: None)
    r.add("/test_add_1/<name>", ["GET", "POST", "OPTIONS"], lambda x, y: None)
    r.add("/test_add_2/<name>", ["GET", "POST", "OPTIONS"], lambda x, y: None)
    r.add("/test_add_2/<name>", ["GET", "POST", "OPTIONS"], lambda x, y: None)
    r.add("/test_add_3/<name>", ["GET", "POST", "OPTIONS"], lambda x, y: None)

# Generated at 2022-06-24 04:37:26.201839
# Unit test for constructor of class Router
def test_Router():
    router = Router()



# Generated at 2022-06-24 04:37:29.685287
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    methods = ["GET", "POST", "OPTIONS"]
    uri = "/"
    handler = RouteHandler()
    path = router.add(uri, methods, handler)
    assert path == Route()


# Generated at 2022-06-24 04:37:30.291724
# Unit test for method finalize of class Router
def test_Router_finalize():
    pass

# Generated at 2022-06-24 04:37:31.972029
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.root == Router.root
    assert router.ctx == Router.ctx

# Generated at 2022-06-24 04:37:33.278446
# Unit test for constructor of class Router
def test_Router():
    router=Router()
    assert isinstance(router,Router)

# Generated at 2022-06-24 04:37:37.208287
# Unit test for method finalize of class Router
def test_Router_finalize():
    URI = "/foo/<bar>"
    HOST_NAME = "localhost"

    def test_handler():
        pass

    router = Router()
    route = router.add(URI, ["GET"], test_handler, host=HOST_NAME)
    assert not route.finalized

    router.finalize()
    assert route.finalized


# Generated at 2022-06-24 04:37:38.332068
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)



# Generated at 2022-06-24 04:37:42.713468
# Unit test for method add of class Router
def test_Router_add():
    router = Router(None)
    def handler(request):
        return 'test_Router_add'
    
    route = router.add(uri='/',methods=['GET'],handler=handler)
    route_must_be = Route(
        path=b'/',
        methods=['GET'],
        handler=handler,
        host=None,
        name=None,
        strict=False,
        unquote=False,
        ctx=router.ctx,
    )
    assert route == route_must_be


# Generated at 2022-06-24 04:37:51.460802
# Unit test for method add of class Router
def test_Router_add():
    """
    Case to test add method of class Router
    """
    router = Router()
    route = router.add('/', ['GET'], None, name="hello")
    assert type(route) == Route
    assert route.uri == '/'
    assert route.ctx.hosts == [None]
    assert route.ctx.ignore_body == False
    assert route.ctx.stream == False
    assert route.ctx.static == False

    assert router.dynamic_routes['^/$'].uri == '/'
    assert router.name_index['hello'].uri == '/'


# Generated at 2022-06-24 04:37:54.338622
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.ctx == None
    assert router.name_index == {}
    assert router.static_routes == []
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}


# Generated at 2022-06-24 04:37:58.516595
# Unit test for method finalize of class Router
def test_Router_finalize():
    ROUTER = Router(ctx=None)
    route1 = Route(
        handler=None,
        method="GET",
        path="/",
        strict=False,
        name="test_route1",
        host=None,
        unquote=False,
    )
    ROUTER.add_route(route=route1)
    try:
        ROUTER.finalize()
    except SanicException as e:
        assert str(e) == "Invalid route: GET /  (test_route1) . Parameter names cannot use '__'."


# Generated at 2022-06-24 04:38:09.778431
# Unit test for constructor of class Router
def test_Router():
    from sanic.constants import HTTP_METHODS

    from sanic_routing.router import Router
    from sanic_routing.exceptions import NotFound
    from sanic_routing.exceptions import MethodNotSupported as MS
    from sanic_routing.route import Route
    from sanic.models.handler_types import RouteHandler
    from sanic.response import html, text

    router = Router()
    # default methods = ['GET']
    assert router.DEFAULT_METHOD == 'GET'
    assert router.get('/', 'GET') == (None, None, {})
    assert router.ALLOWED_METHODS == HTTP_METHODS
    # test _get()
    try:
        router._get('/', 'GET')
    except NotFound:
        pass
    # test get()

# Generated at 2022-06-24 04:38:16.571177
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router(None)
    # invalid route: {__file_uri__:aaa}
    with pytest.raises(SanicException):
        router.dynamic_routes['/a/<__file_uri__:aaa>'] = None
    # invalid route: {file_uri:aaa}
    with pytest.raises(SanicException):
        router.dynamic_routes['/a/<file_uri:aaa>'] = None
    # valid route: {file_uri:aaa}
    router.dynamic_routes = {}
    router.finalize()

# Generated at 2022-06-24 04:38:24.461233
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_regex == {}, "Router initialization error"
    assert router.routes_static == [], "Router initialization error"
    assert router.routes_dynamic == {}, "Router initialization error"
    assert router.static_routes == [], "Router initialization error"
    assert router.dynamic_routes == {}, "Router initialization error"
    assert router.regex_routes == {}, "Router initialization error"
    assert router.name_index == {}, "Router initialization error"
    assert router.ctx == {}, "Router initialization error"


# Generated at 2022-06-24 04:38:31.572672
# Unit test for method add of class Router
def test_Router_add():
    @lru_cache(maxsize=ROUTER_CACHE_SIZE)
    def get(self, path, method, host):
        try:
            return self.resolve(
                path=path,
                method=method,
                extra={"host": host},
            )
        except RoutingNotFound as e:
            raise NotFound("Requested URL {} not found".format(e.path))
        except NoMethod as e:
            raise MethodNotSupported(
                "Method {} not allowed for URL {}".format(method, path),
                method=method,
                allowed_methods=e.allowed_methods,
            )


# Generated at 2022-06-24 04:38:34.211236
# Unit test for constructor of class Router
def test_Router():
    test = Router()
    return test

# Generated at 2022-06-24 04:38:39.882892
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.dynamic_routes = {
        "a": "111",
        "b": "222",
    }
    def test():
        router.finalize()
    try:
        test()
    except Exception as e:
        assert e.__str__() == 'Invalid route: 111. Parameter names cannot use \'__\'.'
    router.dynamic_routes = {
        "__file_uri__": "111",
        "a": "222",
    }
    router.finalize()

# Generated at 2022-06-24 04:38:48.339420
# Unit test for method add of class Router
def test_Router_add():
    from sanic.request import Request

    router = Router()

    # Test add a router
    @router.add("/samurai/<id>", methods=["GET"])
    async def test_router(request: Request, id: int):
        return id

    # Test add a multiple router
    @router.add(
        uri="/samurai/<id>",
        methods=["GET", "POST"],
        host="sanic.com",
        strict_slashes=True,
        stream=True,
    )
    async def test_router2(request: Request, id: int):
        return id


# Generated at 2022-06-24 04:38:58.619969
# Unit test for method add of class Router
def test_Router_add():
    # type: () -> None
    import re
    import traceback
    import itertools

    # Init
    uri = "/test_uri"
    methods = ["GET", "POST", "OPTIONS"]
    handler=None
    host=None
    strict_slashes=False
    stream=False
    ignore_body=False
    version=None
    name=None
    unquote=False
    static=False
    router = Router(None, None)

# Generated at 2022-06-24 04:39:03.191473
# Unit test for method add of class Router
def test_Router_add():
    """
    test method add of class Router
    """
    routes = Router()
    host_list = ['1.2.3.4', '5.6.7.8']
    route=routes.add(uri='/', methods=['GET'], handler='handler', host=host_list)
    assert route.ctx.stream == False
    assert route.ctx.ignore_body == False
    assert route.ctx.hosts == ['1.2.3.4', '5.6.7.8']
    assert route.ctx.static == False

    routes = Router()
    routes.add(uri='/', methods=['POST'], handler='handler')


# Generated at 2022-06-24 04:39:08.219305
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"

    assert len(router.routes_all) == 0
    assert len(router.routes_static) == 0
    assert len(router.routes_dynamic) == 0
    assert len(router.routes_regex) == 0

# Generated at 2022-06-24 04:39:11.183323
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == []
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-24 04:39:22.772388
# Unit test for method add of class Router
def test_Router_add():
    import pytest

    router = Router()
    for path, result in [('/', True), ('/path', True), ('/path/with/multiple/parts', True), ('/', True), ('//', False)]:
        router.add(uri = path, methods = ["GET"], handler = "", strict_slashes = False, stream = False, ignore_body = False, version = None, name = None, unquote = False, static = False)
        assert len(router.routes) == l if result else l - 1
        assert len(router.dynamic_routes) == dl if result else dl - 1
        assert len(router.regex_routes) == rl if result else rl - 1
        assert len(router.static_routes) == sl if result else sl - 1




# Generated at 2022-06-24 04:39:30.559074
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()

    # Test 1:
    #   Assert router.dynamic_routes is empty
    assert not router.dynamic_routes

    # Test 2:
    #   Assert router.dynamic_routes is now populated
    router.add("{name:int}", ["GET"], lambda: None)
    assert router.dynamic_routes

    with pytest.raises(AssertionError):
        # Test 3:
        #   Assert that invalid route labels are captured by
        #   Router.finalize()
        router.add("{__name:int}", ["GET"], lambda: None)
        router.finalize()

# Generated at 2022-06-24 04:39:35.009987
# Unit test for constructor of class Router
def test_Router():
    """
    Test the constructor for the Router class
    """
    router = Router()
    assert router != None, "Router was not initialized"
    assert isinstance(router, Router), "Class of router initialization is incorrect"
    assert router.routes == {}, "Unexpected non-empty routes dictionary"

# Unit tests for function _get of class Router

# Generated at 2022-06-24 04:39:38.440725
# Unit test for method add of class Router
def test_Router_add():
    '''
    router = Router()
    router.add('/test', ['GET'], lambda : 'OK')
    print(router.routes_all)
    '''
    pass



# Generated at 2022-06-24 04:39:48.592384
# Unit test for method finalize of class Router
def test_Router_finalize():
    from hypothesis import given
    from hypothesis.strategies import text

    def test_route_check_labels(label_list: List[Tuple[str, str]],
                                allowed_labels: List[str]):
        """
        Tests that routes with invalid labels are not allowed.
        """

        class Error(Exception):
            pass

        class Router(BaseRouter):
            def add(**kwargs):
                route = Route(**kwargs)

                for key, value in label_list:
                    route.labels[key] = value

                return route

            def finalize(self):
                raise Error

        try:
            router = Router()
            router.add(path="/", methods=["POST"], handler=None)
            router.finalize()
        except Error:
            pass
        else:
            assert False

# Generated at 2022-06-24 04:39:58.372093
# Unit test for method finalize of class Router
def test_Router_finalize():
    class MyApp(sanic.Sanic):
        def test_call_add(self, uri: str, **options):
            self.router.add(uri, 'GET', lambda request: None, **options)

    app = MyApp()

    app.test_call_add(
        uri='/path/<__file_uri__:file_path>',
        host='example.com'
    )
    app.test_call_add(
        uri='/path/<__file_uri__:file_path>/',
        host='example.com'
    )


# Generated at 2022-06-24 04:40:00.247751
# Unit test for method add of class Router
def test_Router_add():
    from sanic_routing.router import Router
    router = Router()
    route = router.add("/test", ["GET"], lambda x: x)
    assert route.uri == "/test"

# Generated at 2022-06-24 04:40:10.494113
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.get("/", "GET", "localhost") == (None, None, {})
    assert router.get("/", "POST", "localhost") == (None, None, {})
    assert router.get("/", "DELETE", "localhost") == (None, None, {})
    assert router.get("/", "PUT", "localhost") == (None, None, {})
    assert router.get("/user", "GET", "localhost") == (None, None, {})
    assert router.get("/user", "POST", "localhost") == (None, None, {})
   

# Generated at 2022-06-24 04:40:13.650587
# Unit test for constructor of class Router
def test_Router():
    obj1 = Router()
    assert isinstance(obj1, Router)
    assert isinstance(obj1, BaseRouter)
    assert isinstance(obj1, object)
    assert isinstance(obj1._get_current_route_labels, LRU)


# Generated at 2022-06-24 04:40:26.533800
# Unit test for method add of class Router
def test_Router_add():
    import sys
    import asyncio
    from sanic.server import HttpProtocol, serve
    from sanic.handlers import ErrorHandler
    from sanic.websocket import WebSocketProtocol

    # Create Routers
    router = Router()

    # Create server
    app = Sanic("test_Router_add")

    app.config.REQUEST_MAX_SIZE = 100000000
    app.config.REQUEST_BUFFER_QUEUE_SIZE = 100
    app.config.REQUEST_TIMEOUT = 60
    app.config.RESPONSE_TIMEOUT = 60

    app.ws_protocol = WebSocketProtocol
    app.error_handler = ErrorHandler()

    app.router = router

    @app.route("/test", methods=["GET"])
    async def handler(request):
        return

# Generated at 2022-06-24 04:40:31.464134
# Unit test for method add of class Router
def test_Router_add():
    # Test for constructor:
    router = Router()

    # Test for method add:
    def fake_handler(request):
        return 'fake_handler'
    assert router.add("uri", ["GET", "POST", "OPTIONS"], fake_handler) == router.add("uri", ["GET", "POST", "OPTIONS"], fake_handler)


# Generated at 2022-06-24 04:40:32.825463
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None


# Generated at 2022-06-24 04:40:36.732736
# Unit test for constructor of class Router
def test_Router():
    assert(Router(None) is not None)

# Generated at 2022-06-24 04:40:37.942015
# Unit test for constructor of class Router
def test_Router():
    # Test with valid parameters
    router=Router()
    print(router)
    # Test with invalid parameters

# Generated at 2022-06-24 04:40:44.588004
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    from sanic.router import Router
    from sanic.constants import HTTP_METHODS

    router = Router()
    router.add("/users", HTTP_METHODS, handler=lambda x:x)

    def test_finalize():
        router.finalize()
    
    # Invalid route: Route(path='/users', methods=['CONNECT', 'DELETE', 'GET', 'HEAD', 'OPTIONS', 'PATCH', 'POST', 'PUT', 'TRACE'], handler=<function <lambda> at 0x000002B3BE3B2E18>, name=None, strict=False, unquote=False)
    # Parameter names cannot contain '__'
    with pytest.raises(SanicException):
        test_finalize()


# Generated at 2022-06-24 04:40:50.746765
# Unit test for constructor of class Router
def test_Router(): 
    router = Router()
    rdict = {'_allowed_methods': ['GET'], '_max_age': None, '_registrations': {}, '_first_registration': [], '_strict_slashes': True}
    assert router.__dict__ == rdict

# Generated at 2022-06-24 04:41:01.235864
# Unit test for method add of class Router
def test_Router_add():
    from sanic.exceptions import InvalidUsage
    from sanic.sanic import Sanic
    from sanic.response import raw, text
    from sanic.router import Router

    def test_handler():
        return text("test")

    app = Sanic(__name__)
    assert isinstance(app.router, Router)

    # Test with passing handler and valid route
    added_route = app.router.add('/test_route', [], test_handler)
    assert isinstance(added_route, Route)
    assert added_route.uri == '/test_route'
    assert added_route.methods == ['GET']
    assert added_route.handler == test_handler

    # Test with passing handler and invalid route

# Generated at 2022-06-24 04:41:02.438324
# Unit test for constructor of class Router
def test_Router():
    router = Router()

    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS

# Generated at 2022-06-24 04:41:05.477206
# Unit test for method finalize of class Router
def test_Router_finalize():
    import sanic
    app = sanic.Sanic(__name__)
    app.router.add('/<label_name>', ["GET"], app.async_route(lambda req: "OK"))
    app.router.finalize()

# Generated at 2022-06-24 04:41:16.206888
# Unit test for method add of class Router
def test_Router_add():
    from sanic.app import Sanic
    app = Sanic("test_app")
    router = Router()
    router.add("/test_uri", ["GET"], app.asgi)
    router.add("/test_uri", ["GET", "POST"], app.asgi)
    router.add("/test_uri", ["GET", "POST"], app.asgi, host="test")
    router.add("/test_uri", ["GET", "POST"], app.asgi, version="1")
    router.add("/test_uri", ["GET", "POST"], app.asgi, version=1.1)
    router.add("/test_uri", ["GET", "POST"], app.asgi, version=1.1, name="test")

# Generated at 2022-06-24 04:41:17.714448
# Unit test for constructor of class Router
def test_Router():
    Router()
if __name__ == "__main__":
    test_Router()


# Generated at 2022-06-24 04:41:27.775734
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Assert that routing is in place
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}

    # Test that the router can be finalized
    router.finalize()

    # Test that an exception is raised when an invalid route is added
    with pytest.raises(SanicException):
        router.add(uri="foo/bar/<__param>", methods=["GET"], handler="foo")

    # Test that an exception is raised when an invalid route is added
    with pytest.raises(SanicException):
        router.add(uri="foo/bar/<__param>", methods=["GET", "OPTIONS"], handler="foo")

# Generated at 2022-06-24 04:41:29.922133
# Unit test for constructor of class Router
def test_Router():
  r = Router()
  assert(isinstance(r, Router))


# Generated at 2022-06-24 04:41:35.298343
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    test_Router = Router()
    def test_route(handler):
        route = Route('GET', '/a/<id>', route_handler=handler, uri_template='')
        test_Router.dynamic_routes['/a/<id>'] = route
        route.labels = ['id']
    handler = lambda x : x
    with pytest.raises(SanicException):
        test_route(handler)

# Generated at 2022-06-24 04:41:40.870989
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)
    assert isinstance(router, BaseRouter)


# Generated at 2022-06-24 04:41:46.120740
# Unit test for method finalize of class Router
def test_Router_finalize():

    router = Router()
    router.ctx = BaseRouter.Ctx(app=None, router=router)
    router.static_routes = dict()
    router.dynamic_routes = dict()
    router.regex_routes = dict()

    @router.add("/test")
    def handler(request):
        pass

    with pytest.raises(SanicException):
        router.finalize()

# Generated at 2022-06-24 04:41:48.523248
# Unit test for method add of class Router
def test_Router_add():
    pass

# Generated at 2022-06-24 04:41:56.898576
# Unit test for method add of class Router
def test_Router_add():
    """
    Test the add method of class Router.
    """

    from sanic.request import Request

    @RouteHandler
    def handler(request: Request):
        return request

    router = Router()

    router.add(
        uri='/',
        methods=('GET',),
        handler=handler,
    )

    # Check router.routes
    assert len(router.routes) > 0, \
        'router.routes not set after Router.add is called'

    # Check router.static_routes
    assert len(router.static_routes) == 1, \
        'router.static_routes not set after Router.add is called'

    # Check router.dynamic_routes

# Generated at 2022-06-24 04:41:59.334115
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)

# Generated at 2022-06-24 04:42:08.642587
# Unit test for method add of class Router
def test_Router_add():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.utils import sanic_endpoint_test
    from sanic.router import Router
    from sanic.views import HTTPMethodView

    app = Sanic(__name__)
    router = Router(app, lambda app: app)

    async def handler(request):
        return text("OK")

    # test add
    router.add(uri="/", methods=["GET"], handler=handler, host="foo.bar")
    router.add(uri="/", methods=["GET"], handler=handler, host=["foo.bar"])
    router.add(uri="/", methods=["GET"], handler=handler, host=("foo.bar",))


# Generated at 2022-06-24 04:42:16.465880
# Unit test for constructor of class Router
def test_Router():
    uri = '/url'
    methods = ['POST', 'HEAD']
    handler = asyncio.coroutine(lambda request: None)
    host = '127.0.0.1'
    strict_slashes = False
    stream = False
    ignore_body = False
    version = 1.0
    name = 'name'
    unquote = False
    static = False

    route = Router().add(
        uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static
    )
    print(route.labels)

if __name__ == '__main__':
    test_Router()
    pass

# Generated at 2022-06-24 04:42:28.723692
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route(
        uri='/',
        methods=['GET'],
        handler=print,
        name='index',
        strict=False,
        unquote=False,
        requirements={'host': 'test.com'}
    )

    def test_route_addition(uri):
        router.add(
            uri,
            ['GET', 'POST'],
            print,
            host='test.com',
            strict_slashes=False,
            stream=False,
            ignore_body=False,
            version=1,
            name='index',
            unquote=False,
            static=False
        )


# Generated at 2022-06-24 04:42:32.551149
# Unit test for constructor of class Router
def test_Router():
    router = Router('test_Router', __name__)
    assert router.name == 'test_Router'

# Generated at 2022-06-24 04:42:40.899987
# Unit test for constructor of class Router
def test_Router():
    import os
    from sanic.models.handler_types import RouteHandler
    from sanic.response import json
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import ServerError
    import sanic.app

    app = sanic.app.Sanic(__name__)


    async def hello(request):
        return json({'hello': 'world'})



# Generated at 2022-06-24 04:42:51.455331
# Unit test for method add of class Router
def test_Router_add():
    class MyRouter(Router):
        def _get(
            self, path: str, method: str, host: Optional[str]
        ) -> Tuple[Route, RouteHandler, Dict[str, Any]]:
            res = super().get(path, method, host)
            return res, res

    router = MyRouter()

    # Test with version
    route = router.add('/', ['GET'], lambda x: x, version=1.0)

    assert route.path == '/v1/'

    # Test with stream
    route = router.add('/', ['GET'], lambda x: x, stream=True)

    assert route.ctx.stream == True

    # Test with ignore_body
    route = router.add('/', ['GET'], lambda x: x, ignore_body=True)


# Generated at 2022-06-24 04:42:53.498080
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    from sanic import Sanic

    app = Sanic()

    with pytest.raises(SanicException):
        app.add_route(None, "/")

# Generated at 2022-06-24 04:42:56.506887
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    with pytest.raises(SanicException) as err:
        router.finalize()
    assert str(err.value) == "Invalid route: <Route /[a-z]__[a-z]>. Parameter names cannot use '__'."

# Generated at 2022-06-24 04:42:58.261886
# Unit test for method add of class Router
def test_Router_add():
    # code here
    pass


# Generated at 2022-06-24 04:43:03.999375
# Unit test for method add of class Router
def test_Router_add():
    from sanic.response import text
    def test_handler(*args, **kwargs):
        return text("ok")

    router = Router()
    router.add(uri="/", methods=['GET'], handler=test_handler)
    if(router._router.get("/", "GET") != (None, None, None)):
        print("Test Router Add Passed")


# Generated at 2022-06-24 04:43:09.755998
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Test finalize
    route = Route(
        path='/test',
        methods=['GET'],
        handler=None,
        name=None,
        strict=False,
        unquote=True,
        requirements={'host': 'localhost'},
        errors={},
        ctx=None
    )
    router = Router()
    router.dynamic_routes = {
        'localhost': {route},
    }

    # Test for no exception
    router.finalize()

    # Test for exception
    router.dynamic_routes = {
        '__host': {route},
    }

# Generated at 2022-06-24 04:43:14.973363
# Unit test for method finalize of class Router
def test_Router_finalize():
    route = Route(
        uri="/url/<invalid_param_name>",
        handler=lambda request: None,
        methods=["GET"],
        name="handler_name",
    )

    router = Router(None)
    router.dynamic_routes["/url/<invalid_param_name>"] = route

    with pytest.raises(SanicException):
        router.finalize()



# Generated at 2022-06-24 04:43:16.116790
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router == Router.__init__()


# Generated at 2022-06-24 04:43:27.154815
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router(None)

    def _handler(req, resp):
        pass

    router.add('/', ['GET'], _handler)
    route = router.dynamic_routes.get(('^/$',))
    assert route.labels == ()


    def _handler(req, resp):
        pass

    router.add('/<user>', ['GET'], _handler)
    route = router.dynamic_routes.get(('^/<user>$',))
    assert route.labels == ('user',)

    router.add('/test/<a>/<b>/<c>', ['GET'], _handler)
    route = router.dynamic_routes.get(('^/test/<a>/<b>/<c>$',))

# Generated at 2022-06-24 04:43:30.153749
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router,BaseRouter)

# Generated at 2022-06-24 04:43:34.145195
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.dynamic_routes["test"] = Route(
        uri="/<test>",
        methods=["GET"],
        handler=None,
        name=None,
        strict=False,
        labels=["test"]
    )
    from pytest import raises
    with raises(SanicException):
        router.finalize()



# Generated at 2022-06-24 04:43:35.476633
# Unit test for constructor of class Router
def test_Router():
    router = Router(RouteHandler)
    assert(router.__class__.__name__ == "Router")


# Generated at 2022-06-24 04:43:38.549591
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert isinstance(r, Router)


# Generated at 2022-06-24 04:43:40.923564
# Unit test for constructor of class Router
def test_Router():
    routes = []
    assert len(routes) == 0


# Generated at 2022-06-24 04:43:41.568871
# Unit test for method finalize of class Router
def test_Router_finalize():
    pass

# Generated at 2022-06-24 04:43:44.460453
# Unit test for method finalize of class Router
def test_Router_finalize():
    url_map = {}
    uri = '/test'
    methods = ['GET']
    handler = None
    obj_Router = Router(url_map)
    obj_Router.finalize()

# Generated at 2022-06-24 04:43:46.895243
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_regex is not None
    assert router.routes_regex is not None
    assert router.routes_all is not None


# Generated at 2022-06-24 04:43:47.422881
# Unit test for constructor of class Router
def test_Router():
    pass

# Generated at 2022-06-24 04:43:48.776335
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_route_finalize(Router)

# Generated at 2022-06-24 04:43:56.113798
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route =  Route("uri", "method", "handler", "host", strict_slashes=False, stream=False, ignore_body=False, version=None, name=None, unquote=False, static=False)
    router.dynamic_routes["HOST"] = route
    with pytest.raises(SanicException):
        router.finalize("*args", **{"kwargs": "kwargs"})

# Generated at 2022-06-24 04:44:02.235978
# Unit test for method add of class Router
def test_Router_add():
    class MockApp:
        pass

    app = MockApp()

    router = Router(app)
    route = router.add("/home/<name>", "GET", lambda x: x)

    assert route.path == "/home/<name>"
    assert route.methods == ["GET"]
    assert route.handler == route.handler
    assert route.static == False
    assert route.ctx.ignore_body == False
    assert route.ctx.stream == False
    assert route.ctx.hosts == [None]
    assert route.ctx.requirements == {}


# Generated at 2022-06-24 04:44:06.480929
# Unit test for method finalize of class Router
def test_Router_finalize():
    # create a sanic server
    app = Sanic('test_Router_finalize')
    # get global router
    router = app.router

    # add route
    @app.route("/")
    def handler(request):
        return text("OK")

    # call finalize
    router.finalize()

    # invoke path "/"
    request, response = app.test_client.get("/")
    assert response.status == 200

# Generated at 2022-06-24 04:44:11.003615
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.response import text
    from sanic.exceptions import SanicException
    router = Router.from_spec(spec_dict=None)
    router.add(uri='/', methods=['GET'], handler=text, name='testname')
    router.finalize()
    assert router.name_index['testname']

# Generated at 2022-06-24 04:44:12.174289
# Unit test for constructor of class Router
def test_Router():
	router = Router()


# Generated at 2022-06-24 04:44:20.999731
# Unit test for constructor of class Router
def test_Router():
    from sanic.router import Router
    from sanic.context import RequestParameters

    def handler():
        pass

    request = RequestParameters(
        uri='/',
        method='GET',
        headers={},
        body=None,
        app=None,
        protocol="http",
        remote_addr="127.0.0.1",
        host="localhost",
        port="8000",
        transport=None,
        secure=False,
        server_name='localhost',
        server_port=8000,
    )

    router = Router(request)
    try:
        router.register(handler, '/', 'GET')
    except NotImplementedError:
        pass
    else:
        raise AssertionError("NotImplementedError not raised.")

    requests = []


# Generated at 2022-06-24 04:44:23.141362
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-24 04:44:26.223702
# Unit test for method finalize of class Router
def test_Router_finalize():
    import sanic
    app = sanic.Sanic()
    router = Router()
    def func(*args, **kwargs):
        pass

    router.add('/api/v1/users', func, method=['GET'])
    router.finalize(app=app)

# Generated at 2022-06-24 04:44:29.751057
# Unit test for method add of class Router
def test_Router_add():
    from sanic.views import HTTPMethodView

    router = Router(None)

    class Myview(HTTPMethodView):
        def get(self):
            pass

        def head(self):
            pass

        def post(self):
            pass

        def put(self):
            pass

    router.add(uri="/path/to/api", methods=["GET", "POST"], handler=Myview().dispatch)
    router.add(uri="/path/to/api", methods=["HEAD", "PUT"], handler=Myview().dispatch)


if __name__ == "__main__":
    test_Router_add()

# Generated at 2022-06-24 04:44:34.922844
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    class MockRoute:
        def __init__(self, labels):
            self.labels = labels

    with pytest.raises(SanicException):
        router.dynamic_routes = {'path': MockRoute(['__file_uri__'])}

    router.dynamic_routes = {'path': MockRoute(['__file_uri'])}
    router.finalize()

# Generated at 2022-06-24 04:44:40.154934
# Unit test for constructor of class Router
def test_Router():
    app = sanic.Sanic()
    app.router.add_route(
        uri='/',
        methods=['GET'],
        handler=app.handle_request,
        host=None,
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version=None,
        name=None,
        unquote=False,
        static=False
    )

    assert isinstance(app.router, Router)


# Generated at 2022-06-24 04:44:47.494671
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add("/",None,None,host = None)
    router.add("/",None,None,host = None,strict_slashes = False)
    router.add("/",None,None,host = None,strict_slashes = False, stream = False)
    router.add("/",None,None,host = None,strict_slashes = False, stream = False, ignore_body = False)
    router.add("/",None,None,host = None,strict_slashes = False, stream = False, ignore_body = False, version = None)
    router.add("/",None,None,host = None,strict_slashes = False, stream = False, ignore_body = False, version = None, name = None)

# Generated at 2022-06-24 04:44:57.220779
# Unit test for method add of class Router
def test_Router_add():
    """Test the method add of Router"""

    # Test 1: Add uri = '/test1' should be True
    print('Test 1: Add uri = \'/test1\' should be True')
    router1 = Router()
    uri1 = '/test1'
    methods1 = ['GET','POST','OPTIONS']
    handler1 = RouteHandler
    host1 = 'localhost'
    strict_slashes1 = False
    stream1 = False
    ignore_body1 = False
    version1 = '1'
    name1 = 'name1'
    unquote1 = False
    static1 = False
    router1.add(uri1,methods1,handler1,host1,strict_slashes1,stream1,ignore_body1,version1,name1,unquote1,static1)

# Generated at 2022-06-24 04:45:07.146748
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic_routing import RouteAdded
    from sanic.response import json, text
    from sanic.exceptions import ServerError
    from sanic.views import HTTPMethodView

    class TestView(HTTPMethodView):

        def get(self, request):
            return text("OK")


    router = Router()
    router.add(uri="", methods=["GET"], handler=TestView.as_handler())
    router.add(uri="", methods=["GET"], handler=lambda request: text("OK"))
    router.add(uri="", methods=["GET"], handler=lambda request: json({"a": 1}))
    router.add(uri="", methods=["GET"], handler=lambda request: text("OK"))