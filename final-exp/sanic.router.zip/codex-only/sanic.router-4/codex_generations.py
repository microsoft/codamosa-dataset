

# Generated at 2022-06-24 04:35:02.297587
# Unit test for constructor of class Router
def test_Router():
    # Router()
    router = Router()
    assert isinstance(router, BaseRouter)
    assert isinstance(router, Router)

# Generated at 2022-06-24 04:35:03.265868
# Unit test for constructor of class Router
def test_Router():
    assert isinstance(Router(), BaseRouter)



# Generated at 2022-06-24 04:35:05.319989
# Unit test for constructor of class Router
def test_Router():
    assert isinstance(Router(), BaseRouter)


# Generated at 2022-06-24 04:35:09.031719
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.ctx.sanic_router == router
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.is_initialized


# Generated at 2022-06-24 04:35:18.577777
# Unit test for method add of class Router

# Generated at 2022-06-24 04:35:22.478528
# Unit test for method finalize of class Router
def test_Router_finalize():
    router1 = Router(*args, **kwargs)
    router1.finalize(*args, **kwargs)



# Generated at 2022-06-24 04:35:28.494719
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == []
    assert router.routes_dynamic == []
    assert router.routes_static == []
    assert router.routes_regex == []
    assert router.all_methods == {}
    assert router.static_methods == {}
    assert router.dynamic_methods == {}
    assert router.regex_methods == {}
    assert router.name_index == {}


# Generated at 2022-06-24 04:35:40.241434
# Unit test for method add of class Router
def test_Router_add():
    ctx = {"app": "dummy_application_name", "sanic_router": "dummy_router"}
    import inspect
    routes = Router(ctx=ctx)
    class TestRouter(Router):
        def add(self, uri, methods, handler, host=None, strict_slashes=False,
                stream=False, ignore_body=False, version=None, name=None,
                unquote=False, static=False):
            from sanic.response import html
            return Router.add(self, uri, methods, handler, host, strict_slashes,
                    stream, ignore_body, version, name, unquote, static)
    routes = TestRouter(ctx=ctx)
    def test_router_add(routes):
        import sanic

# Generated at 2022-06-24 04:35:48.702443
# Unit test for method add of class Router
def test_Router_add():
    @lru_cache(maxsize=ROUTER_CACHE_SIZE)
    def get(self, path: str, method: str, host: Optional[str]) -> Tuple[Route, RouteHandler, Dict[str, Any]]:
        try:
            return self.resolve(path=path, method=method, extra={"host": host})
        except RoutingNotFound as e:
            raise NotFound("Requested URL {} not found".format(e.path))
        except NoMethod as e:
            raise MethodNotSupported("Method {} not allowed for URL {}".format(method, path), method=method, allowed_methods=e.allowed_methods)

# Generated at 2022-06-24 04:35:58.771756
# Unit test for method add of class Router
def test_Router_add():
    uri = '/'
    methods = ['GET']
    host = '127.0.0.1'
    def handler():
        pass
    strict_slashes = True
    stream = True
    ignore_body = False
    version = 1.0
    name = 'test'
    unquote = True
    static = True
    r = Router()
    r.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)
    assert r.routes_dynamic == {}
    assert r.routes_regex == {}

# Generated at 2022-06-24 04:36:08.868158
# Unit test for method add of class Router
def test_Router_add():
    test_routes = Router()
    app = Sanic("test_Router_add")

    @app.route("/")
    def handler(request):  # pylint: disable=unused-argument
        return text("Works!")

    routes = test_routes.routes_all
    assert len(routes) == 0

    route = test_routes.add(
        uri="/", methods=["GET"], handler=handler,
    )
    assert isinstance(route, Route)
    assert route.ctx.ignore_body is False
    assert route.ctx.hosts == [None]
    assert route.ctx.stream is False

    routes = test_routes.routes_all
    assert len(routes) == 1


# Generated at 2022-06-24 04:36:10.216587
# Unit test for method add of class Router
def test_Router_add():
    pass


# Generated at 2022-06-24 04:36:19.716638
# Unit test for method add of class Router
def test_Router_add():
    uri = "/app/hello"
    handler = None
    methods = ["GET", "POST", "OPTIONS"]
    host = None
    strict_slashes = True
    stream = False
    ignore_body = False
    version = None
    name = None
    unquote = False
    static = False
    
    
    # --------------- #
    # static route    #
    # --------------- #
    static_route_obj = Route(
            uri=uri,
            methods=methods,
            handler=handler,
            host=host,
            strict_slashes=strict_slashes,
            stream=stream,
            ignore_body=ignore_body,
            version=version,
            name=name,
            unquote=unquote,
            static=static,
        )
    # --------------- #


# Generated at 2022-06-24 04:36:26.682480
# Unit test for method add of class Router
def test_Router_add():
    import unittest

    class TestRouter(unittest.TestCase):

        def test_Router_add(self):
            router = Router()

            def foo(req):
                pass

            router.add("/path/to/foo", ["GET"], foo)

    unittest.main()

# Generated at 2022-06-24 04:36:35.019909
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    router.add('/path/to/test', ['GET', 'POST'], 'any_func')
    assert router.routes
    assert isinstance(router.routes, dict)
    assert router.static_routes
    assert isinstance(router.static_routes, dict)
    assert router.dynamic_routes
    assert isinstance(router.dynamic_routes, dict)
    assert router.regex_routes
    assert isinstance(router.regex_routes, list)
    assert router.name_index
    assert isinstance(router.name_index, dict)



# Generated at 2022-06-24 04:36:39.688120
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic_routing.compiler import UrlCompiler

    router = Router(UrlCompiler())
    router.add('/hello/:name', ['GET'], lambda x, y: 18)

    assert isinstance(router.finalize(), None)



# Generated at 2022-06-24 04:36:46.385515
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    route = router.add(
        uri="/",
        methods=["GET"],
        handler=None,
        host=None,
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version=None,
        name=None,
        unquote=False,
        static=False,
    )

    assert route.path == "/"
    assert route.handler == None
    assert route.methods == ["GET"]
    assert route.name == None
    assert route.strict == False
    assert route.unquote == False

    assert route.ctx.ignore_body == False
    assert route.ctx.stream == False
    assert route.ctx.hosts == [None]
    assert route.ctx.static == False

# Generated at 2022-06-24 04:36:52.043820
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    uri = '/dummy_uri'
    methods = ['dummy_method']
    handler = 'dummy_handler'
    params = dict(path=uri, handler=handler, methods=methods,)
    route = router.add(**params)
    assert route.path == uri
    assert route.handler == handler
    assert route.methods == methods
    assert router.resolve("/dummy_uri", "dummy_method", {}) == (route, handler, {})

# Generated at 2022-06-24 04:36:58.519045
# Unit test for method finalize of class Router
def test_Router_finalize():
    __label__ = None # '__label__' is a mandatory label
    def dummy(*arg, **kwargs):
        pass

    router = Router()

    # Test 1 (label starts with __ but it is allowed)
    router.add(uri="/", handler=dummy, methods=['GET'], name='__file_uri__')

    # Test 2 (label starts with __)
    try:
        router.add(uri="/test", handler=dummy, methods=['GET'], name='__invalid__')
    except SanicException:
        pass

    # Test 3 (label does not start with __)
    router.add(uri="/", handler=dummy, methods=['GET'], name='valid')

# Generated at 2022-06-24 04:37:07.158324
# Unit test for constructor of class Router
def test_Router():
    # Test when path is empty
    router = Router()
    assert router.routes_regex == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}

    # Test when path is not empty
    route = Route("/users/<id>", "<handler>", ("GET",))
    router = Router([route])
    assert router.routes_regex == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {"/users/<id>": [route]}


# Generated at 2022-06-24 04:37:10.937619
# Unit test for constructor of class Router
def test_Router():
    r = Router(None)

    assert isinstance(r, BaseRouter)
    assert isinstance(r.routes, dict)
    assert isinstance(r.static_routes, dict)
    assert isinstance(r.dynamic_routes, dict)
    assert isinstance(r.regex_routes, dict)
    assert isinstance(r.name_index, dict)

# Generated at 2022-06-24 04:37:21.209439
# Unit test for method add of class Router
def test_Router_add():
    # Case 1: add a handler successfully
    router = Router()
    method1 = "GET"
    method2 = "PUT"
    method3 = "POST"
    method4 = "DELETE"
    uri = '/test'
    handler = 'handler'
    host = 'test_host'
    strict_slashes = False
    stream = False
    ignore_body = False
    version = 'v3'
    name = 'name'
    unquote = False
    static = False
    # There are some troubles for Sanic-Routing when handling the parameter
    # 'host' which can be a str or a Iterable

    # Case 1.1: given a str, add a handler successfully

# Generated at 2022-06-24 04:37:29.966658
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes == {}
    assert router.dynamic_routes == {}
    assert router.static_routes == {}
    assert router.host_routes == {}
    assert router.name_index == {}
    assert router.ctx == {
        "app": None,
        "router": None,
    }
    assert router.requirement_registry == {
        "__default__": re.compile(".*"),
        "__regex__": re.compile(".*"),
    }
    assert router.static_cache == {}


# Generated at 2022-06-24 04:37:38.733723
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    uri = "some_uri"
    methods = ["GET", "POST", "OPTIONS"]
    handler = lambda : 0
    host = "some_host"
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = "some_name"
    unquote = False
    static = False
    router.add(
        uri=uri,
        methods=methods,
        handler=handler,
        host=host,
        strict_slashes=strict_slashes,
        stream=stream,
        ignore_body=ignore_body,
        version=version,
        name=name,
        unquote=unquote,
        static=static,
    )

# Generated at 2022-06-24 04:37:40.271320
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)



# Generated at 2022-06-24 04:37:50.402078
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_router = Router()

    # test with valid parameters
    test_path = "/test_path"
    test_methods = ("GET",)
    test_handler = lambda: print("this is a handler")
    test_host = "test_host"
    test_strict_slashes = False
    test_stream = False
    test_ignore_body = False
    test_version = 0
    test_name = "test_name"
    test_unquote = False
    test_static = False
    test_route = Route(
        test_router,
        test_path,
        test_handler,
        test_methods,
        test_name,
        test_strict_slashes,
        test_unquote,
    )
    assert test_route.ctx.hosts == (None,)


# Generated at 2022-06-24 04:37:55.760062
# Unit test for method add of class Router

# Generated at 2022-06-24 04:37:56.338359
# Unit test for method finalize of class Router
def test_Router_finalize():
    pass

# Generated at 2022-06-24 04:37:59.434070
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS

# Generated at 2022-06-24 04:38:01.211283
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)

# Generated at 2022-06-24 04:38:07.183501
# Unit test for method finalize of class Router
def test_Router_finalize():
    route = Route("/test/<number:id>", None, ["id"])
    router = Router()
    router.dynamic_routes = {"/test/<number:id>" : route}
    router.finalize()

# Generated at 2022-06-24 04:38:09.637447
# Unit test for method add of class Router
def test_Router_add():
    args = ['api/users', ['GET'], 'def', None]
    methods = ['GET']

    router = Router()
    routes = router.add(*args)
    assert routes.methods == methods


# Generated at 2022-06-24 04:38:18.796667
# Unit test for method finalize of class Router
def test_Router_finalize():
    import re
    def _finalize(self, rx):
        rx = rx.replace("(?:", "(")
        rx = rx.replace("(?P<", "(")
        rx = rx.replace(":([^>])", r"\1")
        rx = rx.replace(":(?P<", r"(?P<")
        rx = re.sub(r"\(\?\(.*\)\)", "", rx)
        return rx
    
    from sanic.router import Router
    # Make a test case for the method finalize of class Router
    # Test case 1

# Generated at 2022-06-24 04:38:20.726138
# Unit test for constructor of class Router
def test_Router():
    router = Router(None)
    assert isinstance(router, Router)


if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-24 04:38:24.320915
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert type(router) == Router


# Generated at 2022-06-24 04:38:28.241109
# Unit test for method add of class Router
def test_Router_add():
    import sanic_routing.model as sanic_routing
    from sanic_routing.route import Route
    router = sanic_routing.Router()
    uri = '/'
    methods = ['GET']
    handler = 'async def handler():\n   pass'
    assert type(router.add(uri, methods, handler)) == Route
# End of unit test

# Generated at 2022-06-24 04:38:30.109979
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert type(router) == Router


# Generated at 2022-06-24 04:38:41.605528
# Unit test for method add of class Router
def test_Router_add():
    from sanic import Sanic
    from .util import MockRequest
    from .util import MockResponse
    from .util import MockHandler


    def handler(request):
        return MockResponse(request)

    request = MockRequest.create(
        "GET", "http://localhost/", host="localhost", scheme="http"
    )

    app_router = Router(
        Sanic(__name__),
        "unit-test-route-add",
    )

    app_router.add("/", ["GET", "POST"], handler)
    (route, handler, params) = app_router.get(
        "/", "GET", "localhost"
    )

# Generated at 2022-06-24 04:38:44.267463
# Unit test for constructor of class Router
def test_Router():
    try:
        router = Router()
        assert router is not None
        print("Success")
    except Exception as e:
        print("Fail", e)


# Generated at 2022-06-24 04:38:55.531849
# Unit test for method add of class Router
def test_Router_add():
    address = "http://localhost:80"
    sanic_app = Sanic(__name__)
    # method add of class Router will use method add of class BaseRouter for
    #  adding Route
    router = Router()
    # modify uri
    params = dict(
        path="/test/<var>",
        host=address
    )
    route = router.add(**params)
    assert route.uri == f"http://localhost:80/test/<var>"
    # modify strict_slashes
    params = dict(
        path="/test/<var>",
        host=address,
        strict_slashes = True
    )
    route = router.add(**params)
    assert route.strict == True
    # modify host

# Generated at 2022-06-24 04:39:07.381943
# Unit test for method finalize of class Router
def test_Router_finalize():
    # arrange
    from unittest.mock import Mock, create_autospec
    from sanic.router import Router

    # mock
    uri = ''
    methods = 'get'
    handler = Mock()
    handler.__name__ = 'handler_name'
    host = Mock()
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = Mock()
    unquote = False
    static = False

    r = Router()
    r.static_routes = Mock()
    r.dynamic_routes = Mock()
    r.regex_routes = Mock()
    r.name_index = Mock()

# Generated at 2022-06-24 04:39:15.428010
# Unit test for constructor of class Router
def test_Router():
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView

    class MyView(HTTPMethodView):
        def get(self, request, name=None):
            return HTTPResponse(
                f"Hello {name}", status=200)

        def post(self, request):
            return HTTPResponse(
                f"Hello {request.json['name']}", status=201)

    router = Router()
    router.add('/<name:string>', ['GET', 'POST'], MyView.as_view())
    request = Request.triad_to_mock(
        'GET', 'http://127.0.0.1:8000/joe', '',
    )
    uri, handler,

# Generated at 2022-06-24 04:39:20.709381
# Unit test for method finalize of class Router
def test_Router_finalize():
    #1. Create a Router object with dynamic routes
    router = Router()
    router.add(uri='/{test1}',methods=["GET"],handler=None)

    try:
        #2. Invoke finalize method
        router.finalize()
    except:
        assert 0
    else:
        assert 1

# Generated at 2022-06-24 04:39:30.024911
# Unit test for method add of class Router
def test_Router_add():
    # type: () -> None
    from sanic.app import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse

    app = Sanic("sanic-test")

    async def async_handler(request):
        return HTTPResponse(text="OK")

    def sync_handler(request):  # type: ignore
        return HTTPResponse(text="OK")

    def sync_handler_with_variable_args(request, var):  # type: ignore
        return HTTPResponse(text="OK")

    def sync_handler_with_optional_args(request, opti=None):  # type: ignore
        return HTTPResponse(text="OK")

    async def async_handler_with_optional_args(request, opti=None):
        return HT

# Generated at 2022-06-24 04:39:32.218740
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.ctx.is_serving() is True
    assert router.ctx.is_finalized() is False
    return



# Generated at 2022-06-24 04:39:40.444431
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic_routing import Route

    router = Router()
    route = Route('test', RouteHandler)
    route.labels = ['label1', '__file_uri__', 'label2']
    router.dynamic_routes['test'] = route
    router.finalize()
    
    try:
        router.finalize()
    except SanicException:
        pass
    
    route.labels = ['label1', '__file_uri___', 'label2']
    try:
        router.finalize()
    except SanicException:
        pass

# Execute test of method finalize of class Router
test_Router_finalize()

# Generated at 2022-06-24 04:39:45.680344
# Unit test for constructor of class Router
def test_Router():
    r = Router(
        uri="hotel",
        methods=["GET", "POST", "OPTIONS"],
        handler=lambda x: x,
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version=None,
        name=None,
        unquote=False,
    )
    return r


# Generated at 2022-06-24 04:39:46.085923
# Unit test for method add of class Router
def test_Router_add():
    pass

# Generated at 2022-06-24 04:39:57.650794
# Unit test for method add of class Router
def test_Router_add():
    from sanic.exceptions import SanicException
    from sanic.request import Request
    from sanic.response import json, text
    import asyncio
    import pytest

    loop = asyncio.get_event_loop()
    router = Router()
    # when
    router.add('/', methods=['GET'], handler=lambda request: json([{'a':1},{'b':2}]), host='hosta.com')
    router.add('/', methods=['OPTIONS'], handler=lambda: text('a'), host='hostb.com')
    router.add('/', methods=['PUT', 'POST'], handler=lambda request: request, host='hostc.com')
    router.add('/', methods=['POST', 'GET'], handler=lambda request: request, host='hostd.com')


# Generated at 2022-06-24 04:40:10.192202
# Unit test for method add of class Router
def test_Router_add():
    # Definition of a route of the class Route
    def mock_Route(path, handler, methods, name, strict, unquote):
        class Route:
            def __init__(self, path, handler, methods, name, strict, unquote):
                self.ctx = {
                    'ignore_body' : False,
                    'path': path,
                    'hosts': None,
                    'methods': methods,
                    'handler': handler,
                    'name': name,
                    'strict': strict,
                    'stream': False,
                    'unquote': unquote,
                }
                self.labels = {}
            def __repr__(self):
                return self.ctx['path']

        return Route(path, handler, methods, name, strict, unquote)

    # Definition of an application of the class Sanic

# Generated at 2022-06-24 04:40:16.236904
# Unit test for method add of class Router
def test_Router_add():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.views import HTTPMethodView
    from sanic.response import HTTPResponse

    app = Sanic('test_Router_add')

    async def handler(request: Request) -> HTTPResponse:
        return HTTPResponse(body='OK')

    async def get_handler_async(request: Request) -> HTTPResponse:
        return HTTPResponse(body='OK')

    class HandlerView(HTTPMethodView):
        def get(self):
            pass

    app.router.add('/', methods=['GET'], handler=handler)
    app.router.add('/async', methods=['GET'], handler=get_handler_async)

    view = Handler

# Generated at 2022-06-24 04:40:22.049522
# Unit test for method finalize of class Router
def test_Router_finalize():
    def handle(request):
        return None

    routes = Router()
    routes.add("/a/b/c/", ["GET", "POST"], handle, strict_slashes=False)

    try:
        routes.finalize()
    except Exception as error:
        if error is not None:
            print("success")
    else:
        print("fail")


# Generated at 2022-06-24 04:40:22.731475
# Unit test for method finalize of class Router
def test_Router_finalize():
    assert True

# Generated at 2022-06-24 04:40:33.407503
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Construct objects for use in method finalize of class Router.
    class Label:
        def __init__(self, label):
            self.label = label
            self.name = label

    class RegexRoute:
        def __init__(self, labels):
            self.labels = labels

    class DynamicRoute:
        def __init__(self, labels):
            self.labels = labels

    class DynamicRoutes:
        def __iter__(self):
            return iter([DynamicRoute([Label('__file_uri__'), Label('a')]),
                         DynamicRoute([Label('__file_uri__'), Label('a')])])

    class Router:
        def __init__(self, dynamic_routes):
            self.dynamic_routes = dynamic_routes

    #Expect an exception to be thrown for

# Generated at 2022-06-24 04:40:37.953567
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    
    route = router.add(uri='/', methods=['GET'], handler=None)
    
    route.labels = [
        '__file_uri__',
        '__file_uri__',
        '__file_uri__',
        '__file_uri__',
        '__file_uri__',
    ]
    try:
        router.finalize()
        assert False
    except:
        assert True

# Generated at 2022-06-24 04:40:40.649287
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    r.add("/<test:test>",["get"],None)
    try:
        r.finalize()
    except Exception:
        assert True
    else:
        assert False

# Generated at 2022-06-24 04:40:42.945848
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)
    assert isinstance(router, BaseRouter)

# Generated at 2022-06-24 04:40:46.846168
# Unit test for method add of class Router
def test_Router_add():
    # Create a Router instance
    router = Router()
    # Add a route to the router
    route = router.add(uri="/", methods=["GET"], handler=None, host=None, strict_slashes=False, stream=False, ignore_body=False, version=None, name=None)
    assert isinstance(route, Route)
    assert route.path == "/"


# Generated at 2022-06-24 04:40:59.175174
# Unit test for method add of class Router
def test_Router_add():
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler

    router = Router()

    handler1: RouteHandler = lambda request: "OK"
    handler2: RouteHandler = lambda request: "OK"

    route: Route = router.add("/test/", ["GET"], handler1)
    assert len(router.routes_all) == 1
    assert len(router.routes_static) == 1
    assert len(router.routes_dynamic) == 0
    assert len(router.routes_regex) == 0
    assert route.hosts == [None]
    assert route.path == "/test/"
    assert route.methods == ["GET"]
    assert route.handler == handler1
    assert route.name == None

# Generated at 2022-06-24 04:41:02.302533
# Unit test for method finalize of class Router
def test_Router_finalize():
    assert hasattr(Router, 'finalize')

# Generated at 2022-06-24 04:41:11.024678
# Unit test for constructor of class Router
def test_Router():
    router = Router()

    # assert the router is a BaseRouter
    assert isinstance(router, BaseRouter)

    # assert the default_method is "GET"
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS

    # assert the method _get is decorated by lru_cache
    assert router._get.cache_info().hits == 0

    # assert the method add is decorated by lru_cache
    assert router.add.cache_info().hits == 0

    # assert the method find_route_by_view_name is decorated by lru_cache
    assert router.find_route_by_view_name.cache_info().hits == 0

    # assert the routes_all, routes_dynamic, routes_regex and routes_static are properties


# Generated at 2022-06-24 04:41:15.842931
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS


# Generated at 2022-06-24 04:41:17.318872
# Unit test for constructor of class Router
def test_Router():
    router = Router()


if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-24 04:41:22.761674
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == 'GET'
    assert router.ROUTER_CACHE_SIZE == 1024
    assert router.ALLOWED_METHODS == ['DELETE', 'OPTIONS', 'HEAD', 'PATCH', 'POST', 'PUT', 'GET']

# Generated at 2022-06-24 04:41:33.144874
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    from sanic.response import text
    from sanic.router import RouteExists

    app = Sanic(__name__)
    router = app.router

    @app.route("/")
    async def test(request):
        return text('OK')

    # verify that a route with non-allowed label for parameter is not allowed
    with pytest.raises(SanicException):
        router.add(uri="/test/<__test:int>", methods=["GET"], handler=test)

    # verify that a route with allowed label for parameter is allowed
    try:
        router.add(uri="/test/<__file_uri__:path>", methods=["GET"], handler=test)
    except Exception:
        # This should not fail
        assert False

    # verify that a route with repeated

# Generated at 2022-06-24 04:41:39.566034
# Unit test for method add of class Router
def test_Router_add():
    def handler():
        pass
    router = Router()
    router.add("uri","GET", handler,
               host = ["host1", "host2"],
               strict_slashes = True,
               stream = True,
               ignore_body = False,
               version = "2",
               name = "name")

# Generated at 2022-06-24 04:41:44.418003
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    uri = "v1/user/<id:int>"
    methods = ["GET", "POST"]
    def handler(request):
        pass
    router.add(uri, methods, handler)
    # Check the values of arguments
    assert uri == router.dynamic_routes[uri].ctx.path
    assert methods == router.dynamic_routes[uri].ctx.methods
    assert handler == router.dynamic_routes[uri].ctx.handler


# Generated at 2022-06-24 04:41:46.267445
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Allowed labels
    assert Router.ALLOWED_LABELS == ("__file_uri__",)


# Generated at 2022-06-24 04:41:50.649641
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS


# Generated at 2022-06-24 04:41:52.424497
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.dynamic_routes = {'1':0}
    router.finalize()

# Generated at 2022-06-24 04:42:01.054435
# Unit test for method add of class Router
def test_Router_add():
    # pylint: disable=unused-variable
    from sanic import Sanic

    app = Sanic("test_sanic_add")

    async def handler(request):
        return text("OK")

    router = Router(app)

    # Code to be tested
    router.add("/", ["get"], handler)
    assert isinstance(router.routes_all, list)
    assert isinstance(router.routes_static, list)
    assert isinstance(router.routes_dynamic, dict)
    assert isinstance(router.routes_regex, list)



# Generated at 2022-06-24 04:42:07.514001
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert isinstance(r, BaseRouter)
    assert r.DEFAULT_METHOD == "GET"
    assert r.ALLOWED_METHODS == ["GET", "POST", "DELETE", "PUT", "PATCH",
        "HEAD", "OPTIONS", 'TRACE']
    assert r.routes_all == {}
    assert r.routes_static == {}
    assert r.routes_dynamic == {}
    assert r.routes_regex == {}

# Generated at 2022-06-24 04:42:14.815454
# Unit test for method add of class Router
def test_Router_add():
    from sanic import Sanic
    from sanic.request import Request

    app = Sanic('test')
    @app.route('/test')
    async def test_route(request: Request) -> str:
        return "hello world"

    router_add_test_pass = False
    for route in app.router.routes_all:
        if route.uri == '/test':
            router_add_test_pass = True

    assert router_add_test_pass

# Unit tests for method add of class Router

# Generated at 2022-06-24 04:42:22.329508
# Unit test for method add of class Router
def test_Router_add():
    """
    In order to check the result of Router_add method
    """
    test = Router()
    uri = '/'
    methods = "GET"
    handler = RouteHandler
    host = None
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = None
    unquote = False
    static = False
    check = test.add(uri, methods, handler, host, strict_slashes, stream,
                    ignore_body, version, name, unquote, static)
    assert check.path == '/'
    assert check.methods == ("GET",)
    assert check.handler == RouteHandler

# Generated at 2022-06-24 04:42:31.862935
# Unit test for method add of class Router
def test_Router_add():
    from sanic.response import json
    router = Router()
    uri = "/"
    methods = ['GET', 'POST', 'PUT']
    handler = json
    host = "example.com"
    strict_slashes = False
    stream = False
    ignore_body = False
    version = "1"
    name = None
    unquote = False
    static = False

    #test without version parameter
    routes = router.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, name, unquote, static)
    assert routes.ctx.ignore_body == ignore_body
    assert routes.ctx.stream == stream
    assert routes.ctx.hosts == [host]
    assert routes.ctx.static == static

    #test with version parameter
    version = "1"

# Generated at 2022-06-24 04:42:32.658325
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    expected = Router()
    assert router == expected


# Generated at 2022-06-24 04:42:35.293415
# Unit test for constructor of class Router
def test_Router():
    assert Router.DEFAULT_METHOD == 'GET'
    assert Router.ALLOWED_METHODS == HTTP_METHODS
    assert Router.ROUTER_CACHE_SIZE == 1024


# Generated at 2022-06-24 04:42:43.328765
# Unit test for method finalize of class Router
def test_Router_finalize():
    # arrange
    router = Router()
    # assert
    with pytest.raises(SanicException):
        # act
        router.add(
            uri='/path/<name>',
            methods=['GET'],
            handler=lambda request: 'handler'
        )
        router.finalize()
    # assert
    with pytest.raises(SanicException):
        # act
        router.add(
            uri='/path/<__name>',
            methods=['GET'],
            handler=lambda request: 'handler'
        )
        router.finalize()
    # assert

# Generated at 2022-06-24 04:42:45.149182
# Unit test for method finalize of class Router
def test_Router_finalize():
    # declare
    router = Router()
    @router.route("/<__name:string>")
    async def handler(request, __name):
        pass
        
    # test
    try:
        router.finalize(None)
    except SanicException:
        assert True
    else:
        assert False, "Test fail!"

# Generated at 2022-06-24 04:42:49.372138
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS


if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-24 04:42:55.025297
# Unit test for method finalize of class Router
def test_Router_finalize():
    route_string = "test_test_test"
    method = "GET"

    def test_test_test():
        return "test_test"

    method_ = Router.add(
        uri=route_string,
        methods=[method],
        handler=test_test_test,
    )
    assert method_.labels == ("test", "test", "test")

# Generated at 2022-06-24 04:43:06.533981
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    uri = 'hello'
    handlers = router.add(uri, 'GET', 'HANDLER')
    assert len(router.routes) == 1
    assert handlers.path == uri
    assert handlers.handler == 'HANDLER'
    assert handlers.methods == 'GET'
    assert handlers.strict == False
    assert handlers.unquote == False
    assert handlers.static == False

    handlers = router.add(uri, 'GET', 'HANDLER', strict_slashes = True, unquote = True, static = True)
    assert len(router.routes) == 2
    assert handlers.path == uri
    assert handlers.handler == 'HANDLER'
    assert handlers.methods == 'GET'
    assert handlers.strict == True
    assert handlers.unquote

# Generated at 2022-06-24 04:43:10.971239
# Unit test for method add of class Router
def test_Router_add():
    def handler(request, *args, **kwargs):
        pass

    router = Router()
    router.add(uri="/v1/", methods=["GET"], handler=handler)

# Generated at 2022-06-24 04:43:19.177127
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    Test finalize method with 'valid' parameters
    """
    from sanic.server import serve


    app = Sanic('test')
    router = Router(app, "index", None)
    assert isinstance(router, Router)

    def func_1(request, *args, **kwargs):
        pass


    router.add("/route", ["GET"], func_1)
    router.finalize()
    assert True



# Generated at 2022-06-24 04:43:20.123978
# Unit test for constructor of class Router
def test_Router():
    Router = Router()
    assert Router is not None

# Generated at 2022-06-24 04:43:21.113993
# Unit test for constructor of class Router
def test_Router():
    a = Router()

# Generated at 2022-06-24 04:43:29.290866
# Unit test for method finalize of class Router
def test_Router_finalize():
    import sanic
    app = sanic.Sanic("Test")
    router = Router(app)

    router.add("/test/<__file_uri__:uri>", {}, lambda req, uri: None, unquote=True)

    try:
        router.finalize()
    except BaseException:
        assert False

    router.add("/test/<x:uri>", {}, lambda req, uri: None, unquote=True)
    try:
        router.finalize()
    except SanicException as e:
        assert True
        assert e.args[0] == "Invalid route: Route(GET, '/test/<x:uri>', handler=None). Parameter names cannot use '__'."



# Generated at 2022-06-24 04:43:34.184527
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.constants import HTTP_METHODS
    from sanic_routing.route import Route
    from sanic_routing.router import Router

    router = Router()

# Generated at 2022-06-24 04:43:45.808162
# Unit test for method add of class Router
def test_Router_add():
    from sanic.response import json
    from sanic.exceptions import InvalidUsage

    router = Router()
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == []
    assert router.routes_regex == []

    router.add("/", methods=["POST", "GET"], handler=json({}))
    assert len(router.routes_all) == 2
    assert len(router.routes_static) == 2
    assert len(router.routes_dynamic) == 0
    assert len(router.routes_regex) == 0
    router.add("/", methods=["POST", "GET"], handler=json({}), unquote=True)

# Generated at 2022-06-24 04:43:50.165389
# Unit test for method finalize of class Router
def test_Router_finalize():
    app = Flask(__name__)
    r = Router()

    r.add("/test/")
    assert r.finalize(app) == None

    try:
        r.add("/test/<__test>")
        assert False, "Should have raised exception."
    except SanicException:
        assert True

    try:
        r.add("/test/<__test_uri__>")
        assert False, "Should have raised exception."
    except SanicException:
        assert True

if __name__ == "__main__":
    test_Router_finalize()

# Generated at 2022-06-24 04:43:56.689345
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.ctx is None
    assert router.routes == []
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == []
    assert router.named_routes == {}
    assert router.name_index == {}

## Test for method get() of class Router
# Test case 1: no route match

# Generated at 2022-06-24 04:43:58.101054
# Unit test for constructor of class Router
def test_Router():
    test = Router()
    assert type(test) == Router


# Generated at 2022-06-24 04:44:05.976934
# Unit test for method finalize of class Router
def test_Router_finalize():
    class RouterMock(Router):  # type: ignore
        def __init__(self):
            self.routes = [Route(RouteHandler, "get", "/homepage"),
                           Route(RouteHandler, "get", "/page/<page_name>")]


    mock_router = RouterMock()
    mock_router.finalize()

# Generated at 2022-06-24 04:44:08.960391
# Unit test for constructor of class Router
def test_Router():
    from sanic.app import Sanic
    from sanic.router import Router
    app = Sanic("test_Sanic_basic")
    Router(app)

# Generated at 2022-06-24 04:44:12.381002
# Unit test for method add of class Router
def test_Router_add():
    def handler():
        pass
    r = Router()
    r.add(uri = "/", methods = ["GET"], handler = handler, host=None, strict_slashes = False, stream = False, ignore_body = False, version = None, name = None, unquote = False, static = False)


# Generated at 2022-06-24 04:44:17.720061
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic import Sanic

    app = Sanic('test_Router_finalize')
    router = Router()

    @app.route('/')
    def handler(request: Request) -> HTTPResponse:
        return HTTPResponse(text=request.url)

    with pytest.raises(SanicException):
        router.finalize()

# Generated at 2022-06-24 04:44:28.577508
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.ctx.app is None
    assert router.routes == []
    assert router._routes == {}
    assert router.name_index == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == []
    assert router.catchall_route is None
    assert router.route_for_stream is None
    assert router.route_for_host is None
    assert router.route_for_http_methods is None
    assert router.route_for_path is None
    assert router.route_for_name is None


# Generated at 2022-06-24 04:44:29.834882
# Unit test for constructor of class Router
def test_Router():
    tests_router = Router()
    assert isinstance(tests_router, Router)

# Generated at 2022-06-24 04:44:36.611759
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)
    assert len(router.routes_all) == 0
    assert len(router.routes_static) == 0
    assert len(router.routes_dynamic) == 0
    assert len(router.routes_regex) == 0
    assert callable(router.get)
    assert callable(router.add)


# Generated at 2022-06-24 04:44:40.123939
# Unit test for constructor of class Router
def test_Router():
    from sanic.exceptions import InvalidUsage

    router = Router()
    assert router != None

# Generated at 2022-06-24 04:44:40.671374
# Unit test for constructor of class Router
def test_Router():
    pass

# Generated at 2022-06-24 04:44:52.289588
# Unit test for method finalize of class Router
def test_Router_finalize():
    # router.py
    def test_add_invalid_route(app):
        app.get("/")

        with pytest.raises(SanicException):
            app.get("/:__param")


    # router.py
    def test_add_invalid_route():
        with pytest.raises(SanicException):
            app = Sanic("test_server")
            app.get("/:__param")

    # router.py
    def test_add_invalid_route_list():
        with pytest.raises(SanicException):
            app = Sanic("test_server")
            app.add_route(
                app.get, "test_add_invalid_route_list", uri="/:__param", strict_slashes=True
            )



# Generated at 2022-06-24 04:45:02.610089
# Unit test for method add of class Router
def test_Router_add():
    from sanic.server import HttpProtocol
    from sanic.request import Request
    import asyncio
    from contextvars import ContextVar
    from sanic.response import HTTPResponse
    from sanic.exceptions import RequestTimeout, ServerError
    from sanic.views import CompositionView

    class Config(object):
        """
        设置静态类属性需要用这个方法
        self._my_attr = Config.my_attr
        """
        keep_alive = True
        keep_alive_timeout = 5
        request_timeout = 60
        protocol = HttpProtocol
        request_class = Request
        url_param_regexp = r"[\w-]+"