

# Generated at 2022-06-24 04:34:57.719694
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)

# Generated at 2022-06-24 04:34:58.562889
# Unit test for method add of class Router
def test_Router_add():
    assert 1 == 1

# Generated at 2022-06-24 04:35:07.469213
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    assert router.routes is None
    assert router.routes_all is None
    assert router.routes_static is None
    assert router.routes_dynamic is None
    assert router.routes_regex is None

    uri = '/<name>'
    methods = [
        'GET', 'POST', 'PUT', 'DELETE', 'OPTIONS', 'HEAD', 'PATCH', 'CONNECT',
        'TRACE', 'COPY', 'LINK', 'UNLINK', 'PURGE', 'LOCK', 'UNLOCK', 'PROPFIND',
        'VIEW'
    ]
    handler = RouteHandler
    host = '127.0.0.1'
    strict_slashes = False
    stream = False
    ignore_body = False
   

# Generated at 2022-06-24 04:35:14.909454
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    route = router.add("/p1/p2", ["GET", "POST"], lambda r: r)
    assert route.methods == ["GET", "POST"]
    assert route.path == "/p1/p2"
    assert route.handler(None) is None
    assert route.name is None
    assert route.ctx.ignore_body == False
    assert route.ctx.stream == False
    assert route.ctx.hosts is None
    
test_Router_add()

# Generated at 2022-06-24 04:35:22.444061
# Unit test for constructor of class Router
def test_Router():
    router = Router(None)
    print(router)
    print(router.DEFAULT_METHOD)
    print(router.ALLOWED_METHODS)
    print(router._get)
    print(router.get)
    print(router.add)
    print(router.find_route_by_view_name)
    print(router.routes_all)
    print(router.routes_static)
    print(router.routes_dynamic)
    print(router.routes_regex)
    print(router.finalize)

if __name__ == '__main__':
    test_Router()

# Generated at 2022-06-24 04:35:30.853201
# Unit test for method add of class Router
def test_Router_add():
    from sanic_routing.route import Route
    from sanic.request import Request

    router = Router()

    @router.add("/", methods=["GET"])
    async def handler_sync(request):
        return f"I am {handler_async.__name__}"

    @router.add("/", methods=["GET"])
    def handler_async(request):
        return f"I am {handler_async.__name__}"

    assert handler_sync == handler_async
    assert isinstance(handler_sync, RouteHandler)
    assert isinstance(handler_async, RouteHandler)

    request = Request(uri="/", method="GET")
    route, handler, args = router.get(request.uri, request.method, request.host)
    assert handler == handler_sync

# Unit

# Generated at 2022-06-24 04:35:33.192767
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router


# Generated at 2022-06-24 04:35:39.615535
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add("/", methods=["GET", "POST"], handler="handler", ignore_body=True, stream=True, version=0.12, name="name")
    assert router.routes_all
    assert router.routes_static
    assert router.routes_dynamic
    assert router.routes_regex


# Generated at 2022-06-24 04:35:43.116568
# Unit test for method finalize of class Router
def test_Router_finalize():
    r1 = Router()
    class TestEx(SanicException):
        pass
    with pytest.raises(TestEx):
        r1.add(uri='/', methods=['GET'], handler=None)
        r1.add(uri='/:__foo__bar', methods=['GET'], handler=None)
        r1.finalize()

# Generated at 2022-06-24 04:35:52.268951
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    router = Router()
    route = Route(
        path="/",
        handler=None,
        methods=HTTP_METHODS,
        name="",
        strict=False,
    )

    route.labels.append("__file_uri__")
    router.dynamic_routes["/"] = route
    router.finalize()


# Generated at 2022-06-24 04:35:59.528762
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Arrange
    r = Router()

    r.dynamic_routes = {
        "test": Route("test", "test", "test", "test", [("__test__", None)])
    }

    # Act
    exception_thrown = False
    try:
        r.finalize("test", {})
    except SanicException:
        exception_thrown = True

    # Assert
    assert exception_thrown == True

# Generated at 2022-06-24 04:36:04.886306
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add("/", ["GET"], "get")
    router.add("/", ["POST"], "post")
    router.add("/", ["PUT"], "put")
    router.add("/", ["PATCH"], "patch")
    router.add("/", ["DELETE"], "delete")
    router.add("/", ["OPTIONS"], "options")
    router.add("/", ["HEAD"], "head")

# Generated at 2022-06-24 04:36:12.736222
# Unit test for method add of class Router
def test_Router_add():
    from sanic import Sanic

    from sanic.request import Request

    app = Sanic("test_Router_add")

    async def handler(request):
        return text("OK")

    # execute method 'add' of class 'Router'
    router = Router(app)
    route = router.add("/get", ["GET"], handler)

    # validate
    assert route.match("/get", method="GET")



# Generated at 2022-06-24 04:36:14.853473
# Unit test for method add of class Router
def test_Router_add():
    r = Router()
    route = r.add('/', ['GET', 'POST'], None, None, unin)
    assert route == None

# Generated at 2022-06-24 04:36:25.601745
# Unit test for method add of class Router
def test_Router_add():
    def handler():
        pass
    uri='/test'
    methods = ['GET','POST']
    host = None
    strict_slashes = False
    stream = False
    ignore_body = False
    version = 1.0
    name = "nametest"
    router = Router()
    routes = router.add(uri=uri, methods=methods, handler=handler, host=host, strict_slashes=strict_slashes, stream=stream, ignore_body=ignore_body, version=version, name=name)
    assert len(router.routes) == 2
    assert router.routes[0].path == uri
    assert isinstance(router.routes[0].methods, frozenset)
    assert isinstance(router.routes[0].handler, RouteHandler)


# Generated at 2022-06-24 04:36:28.959019
# Unit test for method add of class Router
def test_Router_add():
    def ws(request):
        return "Test Route"
    r = Router()
    r.add("/test", ["GET"], ws, host='192.168.1.1', unquote=True)

# Generated at 2022-06-24 04:36:29.991433
# Unit test for method add of class Router
def test_Router_add():
    pass



# Generated at 2022-06-24 04:36:32.760221
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS


# Generated at 2022-06-24 04:36:42.540112
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    def hi(request, name, age): pass
    router.add("/hi/<name>", ["GET"], hi)
    def hi(request, name, age): pass
    router.add("/hi/<name>", ["POST"], hi)
    def hi(request, name, age): pass
    router.add("/hi/<name>", ["PUT"], hi)
    def hi(request, name, age): pass
    router.add("/hi/<name>", ["DELETE"], hi)
    def hi(request, name, age): pass
    router.add("/hi/<name>", ["OPTIONS"], hi)
    def hi(request, name, age): pass
    router.add("/hi/<name>", ["HEAD"], hi)

# Generated at 2022-06-24 04:36:46.708110
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    router.finalize()

# Generated at 2022-06-24 04:36:54.515157
# Unit test for method finalize of class Router

# Generated at 2022-06-24 04:36:59.768821
# Unit test for method add of class Router
def test_Router_add():
    from sanic import Sanic
    from sanic.request import Request

    app = Sanic("test")

    async def handler(req: Request):
        return 'OK'

    try:
        router = Router(app)
        router.add("/test", ["GET"], handler)
        route, *_ = router.get("/test", "GET", "localhost")
    except NotFound:
        pass
    assert route is not None
    assert route.name == "test"
    assert route.uri == "/test"
    assert route.hosts == None
    assert route.ctx.static == False
    assert route.ctx.ignore_body == False
    assert route.ctx.stream == False

# Generated at 2022-06-24 04:37:01.841768
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None
# Test case functions

# Generated at 2022-06-24 04:37:08.312076
# Unit test for method add of class Router
def test_Router_add():
    method_list = ["GET", "POST"]
    uri = "/add"
    handler = None

    router = Router()
    router.add(uri, method_list, handler)

    assert router.routes_dynamic[uri].uri == uri
    assert router.routes_dynamic[uri].methods == method_list
    assert router.routes_dynamic[uri].handler == handler


# Generated at 2022-06-24 04:37:12.620815
# Unit test for method finalize of class Router
def test_Router_finalize():
    # create a new router
    router = Router()
    # add route to the router
    router.add(uri = "/uri/{__param1}", methods = ["GET"], handler = None)
    # test if finalize raises SanicException
    assert raises(SanicException)(lambda: router.finalize())

# Generated at 2022-06-24 04:37:15.988006
# Unit test for constructor of class Router
def test_Router():
    name = "sanic.router.Router"
    r = Router()
    assert name == r.__class__.__name__


# Generated at 2022-06-24 04:37:21.232149
# Unit test for method add of class Router
def test_Router_add():
    uri = "test_uri"
    methods = ["GET"]
    handler = RouteHandler
    host = None
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = None
    unquote = False
    static = False

    router = Router()
    router.add(uri=uri, methods=methods, handler=handler, host=host, strict_slashes=strict_slashes, stream=stream, ignore_body=ignore_body, version=version, name=name, unquote=unquote, static=static)


# Generated at 2022-06-24 04:37:30.012966
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Test with invalid route
    route = Route(
        "/test/<__test:int>", None, None, None
    )

    router = Router()
    router.dynamic_routes['test'] = route

    handler = router.finalize
    with pytest.raises(SanicException):
        handler()

    # Test with valid route
    route = Route(
        "/test/<__file_uri__:int>", None, None, None
    )

    router = Router()
    router.dynamic_routes['test'] = route

    handler = router.finalize
    handler()

# Generated at 2022-06-24 04:37:31.336893
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-24 04:37:39.960384
# Unit test for method add of class Router
def test_Router_add():
    class Mock_App(object):
        def _generate_name(self, view_name):
            return 'name'
    Mock_App = Mock_App()
    router = Router(Mock_App)
    uri = 'users/all'
    methods = ['GET','POST','OPTIONS']
    handler = lambda:None
    router.add(uri,methods,handler,host=None,strict_slashes=False,stream=False,ignore_body=False,version=None,name=None,unquote=False,static=False)
    assert len(router.routes_all) == 1
    assert len(router.routes_static) == 1
    assert len(router.routes_dynamic) == 0
    assert len(router.routes_regex) == 0


# Generated at 2022-06-24 04:37:44.986718
# Unit test for method add of class Router
def test_Router_add():
	r = Router()
	# Test the case where the method simple adds the route to the dictionary
	u = "/route"
	m = "POST"
	h = "host"
	handler = "handler"
	ss = 		True
	s = False
	ib = False
	v = "1"
	n = "routeName"
	uq = False
	st = False
	r.add(
		uri = u,
		methods = m,
		handler = handler,
	);
	assert "route" not in r.name_index
	# Test the name of the route is added to the dictionary
	r.add(
		uri = u,
		methods = m,
		handler = handler,
		name = n,
	);
	assert "route" in r.name

# Generated at 2022-06-24 04:37:52.977183
# Unit test for method add of class Router
def test_Router_add():
    from sanic.views import CompositionView

    router = Router()

    def handler1():
        pass

    def handler2():
        pass

    # 1. test for CompositionView
    class MyView(CompositionView):
        def get(self, handler1):
            pass

        def post(self, handler2):
            pass

    router.add(
        uri='/',
        methods=['GET', 'POST'],
        handler=MyView,
    )

    assert len(router.routes_all) == 2
    assert len(router.routes_dynamic) == 0
    assert len(router.routes_static) == 0
    assert len(router.routes_regex) == 2

    # 2. test for function handler

# Generated at 2022-06-24 04:38:04.853458
# Unit test for method add of class Router
def test_Router_add():
    uri = "/v1/test"
    method = ["GET"]
    handler = "test"
    strict_slashes = False
    stream = False
    ignore_body = False
    version = 1
    name = None
    unquote = False
    static = False
    expected_path = "/v1/test"
    expected_methods = ["GET"]
    expected_handler = "test"
    expected_name = None
    expected_strict_slashes = False
    expected_unquote = False
    expected_hosts = [None]
    expected_ignore_body = False
    expected_stream = False
    expected_version = "/v1"
    expected_static = False

# Generated at 2022-06-24 04:38:14.929817
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic_routing import BaseRouter
    from sanic_routing.route import Route
    base_router = BaseRouter()
    route_obj = Route(
        "POST",
        "/",
        None,
        None,
        None,
        None,
        None
    )
    route_obj.labels = ["__file_uri__", "__file_uri__"]
    base_router.dynamic_routes[0] = route_obj
    base_router.finalize()
    assert base_router.dynamic_routes[0].labels == ["__file_uri__", "__file_uri__"]
    route_obj.labels = ["__file_uri__", "__file_uri__", "__test__"]

# Generated at 2022-06-24 04:38:24.677449
# Unit test for constructor of class Router
def test_Router():
    import pytest
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router._get == Router._get.__get__(router, Router)
    assert router.get == Router.get.__get__(router, Router)
    assert router.add == Router.add.__get__(router, Router)
    assert router.find_route_by_view_name == Router.find_route_by_view_name.__get__(router, Router)
    assert router.routes_all == router.routes
    assert router.routes_static == router.static_routes
    assert router.routes_dynamic == router.dynamic_routes
    assert router.routes_re

# Generated at 2022-06-24 04:38:28.000878
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    route = router.add('/helloworld', ['GET'], print)
    assert route.path == '/helloworld'
    assert route.methods == ['GET']
    assert route.handler == print
    assert route.hosts == [None]


# Generated at 2022-06-24 04:38:33.153989
# Unit test for method add of class Router
def test_Router_add():
    from sanic.response import text

    routes_all = Router.routes_all
    route = Router.add("/", ["GET"], text("test"), host="test")

    assert route not in routes_all

    routes = Router.routes

    assert route in routes

    routes_static = Router.routes_static

    assert route in routes_static

    routes_dynamic = Router.routes_dynamic

    assert route not in routes_dynamic

    routes_regex = Router.routes_regex

    assert route not in routes_regex
    assert route in Router.static_routes
    assert route.handler is text


# Generated at 2022-06-24 04:38:34.736172
# Unit test for constructor of class Router
def test_Router():
    R = Router()
    assert isinstance(R, Router)

# Generated at 2022-06-24 04:38:35.940671
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None


# Generated at 2022-06-24 04:38:42.590928
# Unit test for method add of class Router
def test_Router_add():
    from sanic.app import Sanic
    # Create an instance of Sanic
    app = Sanic()

    # Create an instance of Router
    router = Router()

    # Call method add of class Router to add a path to the router
    route = router.add ("/", "GET", app.handle_request)
    assert True



# Generated at 2022-06-24 04:38:48.228106
# Unit test for method add of class Router
def test_Router_add():
    from sanic import Sanic
    from sanic.response import text
    app = Sanic(__name__)
    @app.route('/')
    async def test_router(request):
        return text('Hello World!')
    assert app.url_for('test_router') == '/'


# Generated at 2022-06-24 04:38:51.782240
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert isinstance(r, Router)

# Generated at 2022-06-24 04:38:53.765860
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS

# Generated at 2022-06-24 04:38:55.367059
# Unit test for constructor of class Router
def test_Router():
    from sanic import Sanic
    a=Router(Sanic(__name__))
    print(a)

# Generated at 2022-06-24 04:38:58.764767
# Unit test for method add of class Router
def test_Router_add():
    pass



# Generated at 2022-06-24 04:39:00.253808
# Unit test for constructor of class Router
def test_Router():
    '''
    >>> test_Router()
    '''
    assert Router

# Generated at 2022-06-24 04:39:09.845638
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router

    router = Router(None)
    routes = [
        ("/user/<uid>", "GET", lambda x: x),
        ("/group/<gid>", "GET", lambda x: x),
        ("/", "GET", lambda x: x),
    ]
    for route in routes:
        router.routes_all[route[0]] = route[2]
        router.routes_dynamic[route[0]] = route[2]
    router.finalize()
    assert len(router.routes_all) == 3
    assert len(router.routes_dynamic) == 3
    assert len(router.routes_regex) == 3

# Generated at 2022-06-24 04:39:16.935170
# Unit test for method add of class Router
def test_Router_add():
    from inspect import Parameter
    from functools import partial
    from sanic.models.handler_types import RouteHandler
    def test_handler(request):
        pass
    test_handler.__parameters__ = {
        "request": Parameter("request", Parameter.POSITIONAL_OR_KEYWORD)
    }
    test_handler.__name__ = "test_handler"

    router = Router()
    router.add("/test", ["GET"], test_handler)
    router.add("/test2", ["GET"], partial(test_handler, None))

    assert router.get("/test", "GET", "")._handler == test_handler
    assert router.get("/test2", "GET", "")._handler == test_handler

if __name__ == "__main__":
    test_Router_add

# Generated at 2022-06-24 04:39:18.629292
# Unit test for constructor of class Router
def test_Router():
    # Create object and test
    assert Router() is not None

# Generated at 2022-06-24 04:39:25.897827
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add('/', ['GET'], lambda x:x)
    router.add('/', ['GET'], lambda x:x, name='index')
    try:
        router.add('/', ['GET'], lambda x:x, name='__test__')
    except Exception as e:
        assert 'Invalid route' in str(e)

# Generated at 2022-06-24 04:39:29.003766
# Unit test for constructor of class Router
def test_Router():
    uri = "/test"
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS


# Generated at 2022-06-24 04:39:33.343485
# Unit test for method finalize of class Router
def test_Router_finalize():
    class MyRouter(Router):
        pass

    router = MyRouter()
    router.add(uri="/uri", methods=["GET"], handler=None, name="test_route")
    router.finalize()

    with pytest.raises(SanicException):
        router.add(
            uri="/uri",
            methods=["GET"],
            handler=None,
            name="test_route__invalid",
        )

# Generated at 2022-06-24 04:39:43.843750
# Unit test for constructor of class Router
def test_Router():
    """
    Unit test for constructor of class Router.
    """
    from ipdb import set_trace
    from sanic.router import Router as Router_UnitTest
    from pprint import pprint

    test_instance = Router_UnitTest(None)

    print('The test instance of class Router is as follows.')
    pprint(test_instance)

    print('The test instance of class Router is as follows.')
    pprint(test_instance.routes_all)

    print('The test instance of class Router is as follows.')
    pprint(test_instance.routes_static)

    print('The test instance of class Router is as follows.')
    pprint(test_instance.routes_dynamic)

    print('The test instance of class Router is as follows.')

# Generated at 2022-06-24 04:39:46.934641
# Unit test for method add of class Router
def test_Router_add():
        router=Router()
        def function(request,a,b):
                print("Hello World")
        router.add("/test/<a>/<b>",["GET"],function)
        return router

# Generated at 2022-06-24 04:39:52.000661
# Unit test for method finalize of class Router
def test_Router_finalize():
    r1 = Router()
    f1 = lambda: None
    r1.add('/user/<name>/profile', ['GET'], f1)
    r1.finalize()

# Generated at 2022-06-24 04:39:59.705125
# Unit test for method finalize of class Router
def test_Router_finalize():
    import unittest
    from unittest.mock import Mock

    class RouterTest(unittest.TestCase):
        def test_valid_route(self):
            router = Router()
            router.dynamic_routes = Mock(
                values=Mock(return_value=[
                    Mock(labels=['message'])
                ])
            )
            router.finalize()
            self.assertEqual(router.dynamic_routes.values.call_count, 1)

        def test_invalid_route(self):
            router = Router()
            router.dynamic_routes = Mock(
                values=Mock(return_value=[
                    Mock(labels=['__message'])
                ])
            )
            with self.assertRaises(SanicException):
                router.finalize

# Generated at 2022-06-24 04:40:01.295585
# Unit test for constructor of class Router
def test_Router():
    r = Router()

# Generated at 2022-06-24 04:40:05.512974
# Unit test for method add of class Router
def test_Router_add():
    def add_route(router, uri, methods, handler):
        return
    from sanic.router import Router
    router = Router()

    router.add("/", "GET", add_route)

    assert len(router.routes_all) == 1



# Generated at 2022-06-24 04:40:14.956312
# Unit test for method add of class Router
def test_Router_add():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse

    app = Sanic('test_Sanic_route')
    router = Router(app)

    async def test_func(request):
        return HTTPResponse(f"Test method {request.method} on test_func")

    async def test_func2(request):
        return HTTPResponse(f"Test method {request.method} on test_func2")

    # all methods
    router.add("/test", ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'], test_func)
    # Not exists
    try:
        router.add("/test2", 'PATCH', test_func)
        assert False
    except MethodNotSupported:
        pass


# Generated at 2022-06-24 04:40:19.559873
# Unit test for method add of class Router
def test_Router_add():
    dummy_handler = lambda x: None
    dummy_host = 'dummy_host'
    dummy_host_list = [dummy_host, ]
    dummy_uri = '/dummy_uri'
    dummy_methods = ['POST', 'PUT', ]
    dummy_strict_slashes = False
    dummy_stream = False
    dummy_ignore_body = False
    dummy_name = 'dummy_name'
    dummy_unquote = False
    dummy_static = False

    dummy_router = Router()

# Generated at 2022-06-24 04:40:30.727329
# Unit test for method add of class Router
def test_Router_add():
    from sanic_routing.route import Route
    from sanic.request import Request
    from sanic import Sanic
    from sanic.response import HTTPResponse
    from sanic_routing.exceptions import NoMethod as RoutingNoMethod
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import NotFound
    
    def test_handler(request):
        """Test handler"""
        return HTTPResponse(body='test_handler')
    #
    # 'test_uri' is not in the list of "available uri"    
    with pytest.raises(NotFound):
        router = Router()
        routers = router.find_route_by_view_name('test_uri')
    #
    # 'test_handler' is not in the list of "available handlers"
   

# Generated at 2022-06-24 04:40:39.907240
# Unit test for method add of class Router
def test_Router_add():
    from sanic.response import json
    from sanic.server import HttpProtocol
    from sanic.app import Sanic
    from sanic import Blueprint

    server_settings = dict()
    router = Router()
    view_func = json({'test':True})
    router.add(
        uri='/test',
        methods=['GET'],
        handler=view_func,
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version=None,
        name=None,
        unquote=False,
        static=False,
    )
    server = HttpProtocol(app=Sanic('sanic_app'), sock=None, loop=None, **server_settings)
    response = server.request_handler(request=None)

    assert response == view_

# Generated at 2022-06-24 04:40:41.012547
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-24 04:40:41.588402
# Unit test for constructor of class Router
def test_Router():
	Router()

# Generated at 2022-06-24 04:40:47.461202
# Unit test for method add of class Router
def test_Router_add():
    import pytest
    from sanic import Sanic
    from sanic.response import json
    from sanic.request import Request
    from sanic.response import HTTPResponse

    app = Sanic('test_Router_add')

    @app.route('/')
    def handle_request(request: Request) -> HTTPResponse:
        return json({'test': True})

    request, response = app.test_client.get('/')

    assert response.json == {'test': True}



# Generated at 2022-06-24 04:40:54.681707
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Unit: test SanicException raise
    import pytest
    from sanic.router import RouteNotFound

    router = Router(None)
    route = Route("", (), {}, {"label": "__file_uri__"}, None)
    labels = ("label",)
    router.dynamic_routes = {("label",): route}
    with pytest.raises(SanicException):
        router.finalize()

# Generated at 2022-06-24 04:41:00.062348
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    with pytest.raises(SanicException, match="Invalid route: "):
        r = Router()
        r.dynamic_routes = {
            'test': Route(path='test_path', methods=['GET'], labels=['__test_label__']),
            'test2': Route(path='test_path2', methods=['GET']),
        }
        r.finalize()

# Generated at 2022-06-24 04:41:08.245065
# Unit test for method finalize of class Router
def test_Router_finalize():
    class UserRouter(Router):
        pass
    router = UserRouter()
    pattern = r"/{name:int}/"
    expected_error = "Invalid route: Route[name:{name:int} --> handler=None]. Parameter names cannot use '__'."
    try:
        router.add(pattern, "GET", None, name="test")
    except SanicException as err:
        assert str(err) == expected_error
    else:
        assert False, f"A SanicException should have been raised: {expected_error}"

if __name__ == "__main__":
    test_Router_finalize()

# Generated at 2022-06-24 04:41:15.494446
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Setup Router()
    router = Router()
    router.dynamic_routes = {'route': ['route']}
    route = 'route'
    labels = ['__file_uri__', '__extra__', '__file__']
    route.labels = labels
    try:
        router.finalize()
    except Exception as e:
        print(e)

    labels = ['__file_uri__', '___extra__', '__file__']
    route.labels = labels
    try:
        router.finalize()
    except Exception as e:
        print(e)



# Generated at 2022-06-24 04:41:23.318417
# Unit test for method finalize of class Router
def test_Router_finalize():
    a = Router()

    a.add(uri='/', methods=['GET'],
          handler=None, host=None, strict_slashes=False,
          stream=False, ignore_body=False, version=None, name=None)
    a.add(uri='/', methods=['POST'],
          handler=None, host=None, strict_slashes=False,
          stream=False, ignore_body=False, version=None, name=None)
    a.add(uri='/', methods=['PUT'],
          handler=None, host=None, strict_slashes=False,
          stream=False, ignore_body=False, version=None, name=None)

# Generated at 2022-06-24 04:41:29.149445
# Unit test for method add of class Router
def test_Router_add():
    from sanic.exceptions import RouteExists
    from sanic.router import Route
    from sanic.views import HTTPMethodView
    from sanic.views import CompositionView

    class View(HTTPMethodView):
        pass

    class BView(HTTPMethodView):
        pass

    router = Router()

    uri = "/"
    name = "view"
    strict_slashes = False

    router.add(
        uri,
        ["GET", "POST", "OPTIONS"],
        View.as_view(name),
        name=name,
        strict_slashes=strict_slashes,
    )

    uri_1 = "/"
    name_1 = "name"
    strict_slashes_1 = False


# Generated at 2022-06-24 04:41:35.988080
# Unit test for method add of class Router
def test_Router_add():  
    uri = '/@'
    methods = ['GET']
    handler = 'sanic.handlers.ErrorHandler'
    host = None
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = None
    unquote = False
    static = False

    router = Router()
    route = router.add(uri, methods, handler, host, strict_slashes, 
            stream, ignore_body, version, name, unquote, static)
    print(route)

if __name__ == '__main__':
    test_Router_add()
    print('Test finished')

# Generated at 2022-06-24 04:41:45.854174
# Unit test for constructor of class Router
def test_Router():
    assert Router.DEFAULT_METHOD == 'GET'
    assert Router.ALLOWED_METHODS == HTTP_METHODS
    tmp_router = Router()
    assert tmp_router.name_index == {}
    assert tmp_router.types_index == {}
    assert tmp_router.routes == []
    assert tmp_router.routes_all == []
    assert tmp_router.routes_static == []
    assert tmp_router.routes_dynamic == []
    assert tmp_router.routes_regex == []
    assert tmp_router.router_cache.__module__ == 'functools'
    assert tmp_router.ROUTER_CACHE_SIZE == 1024
    assert tmp_router.ctx == None
    assert tmp_router.r

# Generated at 2022-06-24 04:41:56.395842
# Unit test for method finalize of class Router
def test_Router_finalize():
    class TestRouter(Router):
        def finalize(self):
            raise NotImplementedError

    route = Route('/', 'GET')
    route.labels.add('__file_uri__')

    for route_type in ('routes', 'static_routes', 'dynamic_routes', 'regex_routes'):
        setattr(TestRouter, route_type, {route.path: route})
        assert {route.path: route} == getattr(TestRouter, route_type)

    try:
        TestRouter().finalize()
    except NotImplementedError:
        pass

    route.labels.clear()
    route.labels.add('__new_label__')

    with pytest.raises(SanicException):
        TestRouter().finalize

# Generated at 2022-06-24 04:42:02.818349
# Unit test for method finalize of class Router
def test_Router_finalize():
    def test():
        router = Router()
        router.add("/", ["GET"], None)
        router.add("/test/<a>/<b>", ["GET"], None)
        router.finalize()
    test()
    return True


# Run the tests
setattr(Router, 'test', test_Router_finalize())

# Generated at 2022-06-24 04:42:11.599997
# Unit test for method add of class Router
def test_Router_add():
    import json
    import sys
    import os
    import inspect
    import builtins

    from unittest.mock import patch

    from sanic import Sanic
    from sanic.server import HttpProtocol

    from sanic.response import json as _json
    import sanic.router

    # Mock objects
    class Mock_request(object):
        method = None  # type: str
        path = None    # type: str
        host = None    # type: str

    class Mock_response(object):
        pass

    class Mock_HttpProtocol(HttpProtocol):
        @staticmethod
        def write(content):
            return "Content"

    # patch objects
    builtin_object = builtins.__dict__["__import__"]

# Generated at 2022-06-24 04:42:21.904318
# Unit test for method add of class Router
def test_Router_add():
    # uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static
    path = '/users/42'
    method = "GET"
    uri = "/users/<id>"
    methods = ["GET"]
    handler = "handler"
    host = "host"
    strict_slashes = False
    stream = False
    ignore_body = False
    version = 1.0
    name = "name"
    unquote = False
    static = False

    result = Router().add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)
    assert result.path == uri
    assert result.handler == handler
    assert result.methods == methods
    assert result.name == name
    assert result.st

# Generated at 2022-06-24 04:42:26.313047
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    try:
        assert isinstance(router, Router)
        print("pass")
    except Exception as e:
        print("fail")
        print(e)
        print(router)
        raise e

if __name__ == '__main__':
    # test_Router()
    pass

# Generated at 2022-06-24 04:42:34.168680
# Unit test for method add of class Router
def test_Router_add():
    from sanic import Sanic
    from sanic.response import text

    app = Sanic(__name__)
    router = Router(app)

    async def handler(request):
        return text('OK')

    # standard example
    router.add('/test/1', ['GET', 'POST'], handler, host='example.com')

    # use list of hosts
    router.add('/test/2', ['GET', 'POST'], handler, host=['example.com', 'example.org'])

    # use versioning
    router.add(
        '/test/3',
        ['GET', 'POST'],
        handler,
        host='example.com',
        version="1.0"
    )

    # use strict slashes

# Generated at 2022-06-24 04:42:42.129588
# Unit test for method add of class Router
def test_Router_add():
    from sanic.response import text
    from sanic.testing import HOST, PORT

    router = Router()
    assert router.add("/test", ["GET"], text("hello world"), host="test.local")
    assert router.add("/test", ["POST"], text("hello world"), host=["test.local", "test.world"])
    assert router.add("/test", ["PATCH"], text("hello world"), host=("test.local", "test.world"))
    assert router.add("/test", ["GET"], text("hello world"), strict_slashes=False)
    assert router.add("/test", ["GET"], text("hello world"), strict_slashes=True)
    assert router.add("/test", ["GET"], text("hello world"), stream=True)

# Generated at 2022-06-24 04:42:47.852003
# Unit test for constructor of class Router
def test_Router():
    # Testing for path_for
    router = Router()
    def handler_test(request):
        return request
    router.add('/test/<name>', ['GET'], handler_test)
    path = router.path_for('handler_test', name='my_name')
    assert path == '/test/my_name'

# Generated at 2022-06-24 04:42:55.570834
# Unit test for method add of class Router
def test_Router_add():
    from sanic.response import text
    from sanic.request import Request
    from sanic import Sanic
    from sanic_routing.router import Router
    import random

    app = Sanic()
    router = Router()

    @app.route("/get/<param>")
    def handler(request, param):
        return text("I love you {}!".format(param))

    # generate request uri
    methods = ["GET"]
    request_uri = "/get/" + str(random.randint(0, 100))
    route = router.add(request_uri, methods, handler)
    request = Request(method="GET", uri=request_uri, app=app)
    print(router.finalize(request))


# Generated at 2022-06-24 04:43:06.072151
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    from sanic.constants import HTTP_METHODS
    from sanic.router import Router

    @Router
    def app():
        pass

    assert app.routes == []
    assert app.static_routes == []

    route = app.add(
        '/',
        HTTP_METHODS,
        lambda: None,
    )

    assert len(app.routes) == 1
    assert app.static_routes == [route]

    # Test error
    route = app.add(
        '/',
        HTTP_METHODS,
        lambda: None,
        unquote=True,
    )
    with pytest.raises(SanicException):
        app.finalize()



# Generated at 2022-06-24 04:43:10.805205
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    from sanic.response import text
    app = Sanic('test_Router_finalize')

    @app.route('/route/<param>')
    def handler(request, param):
        return text('OK')

    with pytest.raises(SanicException):
        app.add_route(handler, '/route/<__error>')

    with pytest.raises(SanicException):
        app.add_route(handler, '/route/<__file_uri__>')

# Generated at 2022-06-24 04:43:15.656517
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r is not None


# Generated at 2022-06-24 04:43:16.824967
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-24 04:43:28.381809
# Unit test for method add of class Router
def test_Router_add():
    # Case 1
    # Define a function handler
    def handler_test():
        return 1
    test_Router = Router()
    test_Router.add('/', ["GET"], handler_test)

    # Case 2
    # Define different uri
    test_Router = Router()
    test_Router.add('/home', ["GET"], handler_test)

    # Case 3
    # Define different HTTP methods
    test_Router = Router()
    test_Router.add('/', ["POST"], handler_test)

    # Case 4
    # Define different host
    test_Router = Router()
    test_Router.add('/', ["GET"], handler_test, host="localhost")

    # Case 5
    # Define different strict_slashes
    test_Router = Router()


# Generated at 2022-06-24 04:43:28.793977
# Unit test for constructor of class Router
def test_Router():
    r = Router()

# Generated at 2022-06-24 04:43:30.304728
# Unit test for constructor of class Router
def test_Router():
    route = Router()
    assert isinstance(route, Router)


# Generated at 2022-06-24 04:43:37.712776
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()

    # define a test function for handler
    def handler_test():
        pass

    try:
        # add a route
        router.add(f"/test/{1}", ["GET"], handler_test)
        
        # finalize this route
        router.finalize()
    except:
        pass
    else:
        assert False, "Method finalize of class Router should raise SanicException"

    # define a test function for handler
    def handler_test():
        pass

    try:
        # add a route
        router.add(f"/test/{{{'__a'}}}", ["GET"], handler_test)
        
        # finalize this route
        router.finalize()
    except:
        pass

# Generated at 2022-06-24 04:43:46.582395
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    from sanic.response import HTTPResponse

    app = Sanic('test_Router_finalize')
    
    @app.route('/')
    def handler(request):
        return response

    try:
        app.router.finalize()
    except Exception as error:
        print(error)

    # Testing invalid route
    @app.route('/test/<__test:int>')
    def handler(request):
        return response
    
    try:
        app.router.finalize()
    except Exception as error:
        print(error)

# Generated at 2022-06-24 04:43:58.192728
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()

    def func(*args, **kwargs):
        return None

    # finalize routine
    # method 'add' of class 'Router'
    router.add(uri='/', methods=['GET'], handler=func)
    router.add(uri='/test', methods=['GET'], handler=func)

    # finalize routine
    # attribute uri routing_dict method 'add' of class 'Router'
    router.add(uri=['/', '/test'], methods=['GET'], handler=func)

    # finalize routine
    # attribute uri routing_dict method 'add' of class 'Router'
    router.add(uri='/test/<label>', methods=['GET'], handler=func)

    # finalize routine
    # attribute uri regex_routing_dict method

# Generated at 2022-06-24 04:44:02.971679
# Unit test for constructor of class Router
def test_Router():
    # router is an instance of class Router, the constructor
    # of class Router is called.
    router = Router()
    assert isinstance(router, Router)



# Generated at 2022-06-24 04:44:08.659519
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.response import text
    
    router = Router()
    router.add(uri=r"/path/", methods=["POST"], handler=text)
    try:
        router.finalize()
    except Exception as exc:
        return str(exc) == "Invalid route: <Route POST /path/>. Parameter names cannot use '__'."
    return False

test_Router_finalize()


# Generated at 2022-06-24 04:44:11.516097
# Unit test for method add of class Router
def test_Router_add():
	router = Router()
	try:
		router.add("", ["GET"], "")
	except Exception as e:
		pass
	else:
		fail("Router.add fails to raise exception when method set is empty")

# Generated at 2022-06-24 04:44:20.583741
# Unit test for method add of class Router
def test_Router_add():

    route_handler = 'Hello world'
    uri = '/helloworld'
    host = 'localhost'
    strict_slashes = True
    stream = True
    ignore_body = True
    version = '1'
    name = 'helloworld'
    unquote = False
    static = False
    methods_to_test = [
        'GET',
        'POST',
        'PATCH',
        'DELETE',
        'HEAD',
        'PUT',
        'OPTIONS'
    ]
    router = Router()

# Generated at 2022-06-24 04:44:29.107932
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.app import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.router import Router

    app = Sanic("test_Router_finalize")
    router = Router()

    @app.route("/")
    def handler(request: Request) -> HTTPResponse:
        pass

    @app.route("/<param:int>")
    def handler2(request: Request, param: int) -> HTTPResponse:
        assert isinstance(param, int)
        return HTTPResponse()

    # No exception is raised
    router.finalize(app)

    # Exception is raised

# Generated at 2022-06-24 04:44:33.249506
# Unit test for method add of class Router
def test_Router_add():
    Router.add(
        uri="",
        methods=[],
        handler="",
        host="",
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version=None,
        name=None,
        unquote=False,
        static=False,
    )


# Generated at 2022-06-24 04:44:38.674368
# Unit test for method add of class Router
def test_Router_add():
    from sanic.response import text
    router = Router()

    # 仅当 routes 中有值时，才会调用 add 方法添加路由
    router.routes = [['GET', '/', text('OK!')]]
    def test():
        router.add('POST', '/', text('OK!'))
    assert router.routes == [['GET', '/', text('OK!')], ['POST', '/', text('OK!')]]


# Generated at 2022-06-24 04:44:46.621008
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    Unit test for method finalize of class Router

    no argument
    """
    from sanic.router import Router
    from sanic import Sanic

    app = Sanic()
    app.config.KEEP_ALIVE = True
    app.config.KEEP_ALIVE_TIMEOUT = 100

    router = Router(app, catch_all_404s=True)
    router._add_route("POST", "/test", lambda: (), host=None, strict_slashes=False,
                      stream=False, unquote=True, name=None, version=None,
                      static=False, host_matching=False)

# Generated at 2022-06-24 04:44:54.031609
# Unit test for constructor of class Router
def test_Router():
    import sanic.exceptions
    import sanic.request
    import sanic.response
    from sanic.exceptions import NotFound as RoutingNotFound
    from sanic.exceptions import NoMethod as RoutingNoMethod

    try:
        r = Router()
        assert isinstance(r, BaseRouter)
    except Exception as e:
        assert False
    finally:
        pass


# Generated at 2022-06-24 04:45:03.272535
# Unit test for method add of class Router
def test_Router_add():
    # Create object of Router class
    router = Router()
    uri = '/foo/bar'
    methods = ['GET', 'POST', 'OPTIONS']
    handler = RouteHandler
    host = '127.0.0.0'
    strict_slashes = False
    stream = False
    ignore_body = False
    version = '1'
    name = 'route'
    unquote = False
    static = False
    route = router.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)
    assert route == None