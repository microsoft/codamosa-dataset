

# Generated at 2022-06-24 04:35:11.795368
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == ('OPTIONS', 'GET', 'HEAD', 'POST', 'PUT', 'DELETE', 'TRACE', 'CONNECT', 'PATCH')
    assert len(router.routes_all) == 0
    assert len(router.routes_static) == 0
    assert len(router.routes_dynamic) == 0
    assert len(router.routes_regex) == 0
    assert router.components == {'int': 1, 'float': 0.1, 'labels': {}}
    assert router.regex_components == {'int': 1, 'float': 0.1, 'labels': {}}
    assert router.name_index == {}
   

# Generated at 2022-06-24 04:35:22.308702
# Unit test for method add of class Router
def test_Router_add():
    def handler_1(request):
        return request

    def handler_2(request):
        return request


    router = Router()
    # Add a handler to the router
    handler_1_route = router.add(
        uri='/',
        methods=['GET'],
        handler=handler_1,
        host=None,
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version=None,
        name=None,
        unquote=False,
        static=False,
    )
    assert handler_1_route.ctx.ignore_body == False
    assert handler_1_route.ctx.stream == False
    assert handler_1_route.ctx.hosts == [None]
    assert handler_1_route.ctx.static == False
    assert handler_

# Generated at 2022-06-24 04:35:26.728545
# Unit test for method add of class Router
def test_Router_add():
    router = BaseRouter()
    handler = RouteHandler()
    methods = HTTP_METHODS
    host = None
    uri = "uri"
    assert(router.add(uri, methods, handler, host) == None)

# Generated at 2022-06-24 04:35:32.021478
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add("/", ["GET", "POST"], lambda: None)
    assert len(router.routes_all) == 1
    assert len(router.routes_static) == 0
    assert len(router.routes_regex) == 1
    assert len(router.routes_dynamic) == 0
    router.add("/", ["GET", "POST"], lambda: None)
    assert len(router.routes_all) == 1
    assert len(router.routes_static) == 0
    assert len(router.routes_regex) == 1
    assert len(router.routes_dynamic) == 0
    router.add("/static", ["GET", "POST"], lambda: None, static=True)

# Generated at 2022-06-24 04:35:44.702696
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic_routing.router import Router
    from sanic_routing.route import Route
    from sanic_routing.route import LabelsDict

# Generated at 2022-06-24 04:35:46.641891
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert type(router) == Router


# Generated at 2022-06-24 04:35:52.948492
# Unit test for method add of class Router
def test_Router_add():
    from sanic.response import json
    
    @app.route("/route_test")
    def index(request):
        return json({"test": True})
    
    req, resp = app.test_client.get("/route_test")
    
    assert resp.status == 200
    assert resp.json == {"test": True}

# Generated at 2022-06-24 04:36:03.715682
# Unit test for method add of class Router
def test_Router_add():
    r = Router()
    path = "path"
    methods = ["GET", "POST", "PUT", "DELETE", "Any"]
    handler = RouteHandler
    route = r.add(path, methods, handler)
    assert route.ctx.ignore_body == False
    assert route.ctx.stream == False
    assert route.ctx.hosts == [None]
    assert route.ctx.static == False
    method = "GET"
    host = None
    uri = "test"
    route = r.get(uri, method, host)
    assert route[0] == None
    with pytest.raises(NotFound):
        uri = "test"
        r.get(uri, method, host)
    methods = ["GET", "POST"]
    route = r.add(path, methods, handler)
   

# Generated at 2022-06-24 04:36:04.975524
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert type(router) is Router

# Generated at 2022-06-24 04:36:16.545253
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.response import text
    from sanic.router import Router as _Router
    from sanic.server import HttpProtocol
    from sanic_routing.route import Route
    from sanic_routing.router import Router as _BaseRouter

    ctx = HttpProtocol()
    ctx.router = _Router(ctx)
    ctx.router.routes = {
        "test": Route(ctx, path="/test", handler=text("test"), methods=["get"])
    }
    ctx.router.routes["test"].labels = ["__test__", "test"]
    ctx.router.finalize()

    assert isinstance(ctx.router, _Router)

# Generated at 2022-06-24 04:36:19.403159
# Unit test for method add of class Router
def test_Router_add():
    @handler(None)
    def test_handler(request, *args, **kwargs):
        return request

    router = Router()
    router.add("/test_route", methods={"GET", "POST"}, handler=test_handler)



# Generated at 2022-06-24 04:36:28.100163
# Unit test for method finalize of class Router
def test_Router_finalize():
    def test_handler():
        pass

    router = Router()
    with pytest.raises(NotFound):
        router.add(r'/test', {'GET'}, test_handler)
        test_request = Request(
            'GET', '/test', None, None, None, None, None, None, None, None, None,
            None, None, None)
        router.get(
            test_request.path, test_request.method,
            test_request.ip)



# Generated at 2022-06-24 04:36:38.739509
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router._get == router.get
    assert router._get2 == router.get2
    assert router.add == router.add_route
    assert router.add_static == router.add_static_route
    assert router.get_static == router.get_static_route
    assert router.finalize == router.finalize_routes
    assert router.get_dynamic == router.get_dynamic_route
    assert router.get_regex == router.get_regex_route
    assert router.add_dynamic == router.add_dynamic_route
    assert router.add_regex == router.add_regex_route



# Generated at 2022-06-24 04:36:40.823723
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        Router().finalize()
    except SanicException as error:
        assert "Invalid route" in error.message



# Generated at 2022-06-24 04:36:42.577535
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS



# Generated at 2022-06-24 04:36:50.661333
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    handler = None
    router.add(
        uri='/',
        methods=['GET'],
        handler=handler,
        host=None,
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version=None,
        name=None,
        unquote=False,
        static=False,
    )


# Generated at 2022-06-24 04:36:53.012593
# Unit test for constructor of class Router
def test_Router():
    assert all(getattr(Router,'DEFAULT_METHOD')=='GET')
    assert all(isinstance(Router.ALLOWED_METHODS, tuple))

test_Router()

# Generated at 2022-06-24 04:36:53.863957
# Unit test for method add of class Router
def test_Router_add():
    rout = Router()
    rout.add()

# Generated at 2022-06-24 04:36:57.073805
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add("/v1/test", ["GET"], None)
    router.add("/v1/test", ["GET"], None)
    assert router.routes_static.__len__() == 1


# Generated at 2022-06-24 04:37:09.153888
# Unit test for method add of class Router
def test_Router_add():
    from sanic import Sanic
    from sanic_routing import Router as _Router
    assert hasattr(Router, 'add')
    assert hasattr(Router, 'routes_all')
    app = Sanic(__name__)
    router = _Router(app)
    router.add('/test', ['GET'], lambda : None)
    assert len(router.routes_all) == 1
    try:
        router.add('/test', ['GET'], lambda : None, hosts=['test1'])
    except:
        assert False
    assert len(router.routes_all) == 2
    assert router.routes_all[1].ctx.hosts == ['test1']
    assert router.routes_all[1].ctx.static is False

# Generated at 2022-06-24 04:37:11.816860
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add(uri="/stc/<param1>/<param2>", methods=["GET"], handler=None)

# Generated at 2022-06-24 04:37:14.822938
# Unit test for method add of class Router
def test_Router_add():
    import pdb; pdb.set_trace()
    router = Router()


# Generated at 2022-06-24 04:37:22.896097
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route(router=router, methods=["GET"], path="/")
    route.labels = {"__one__", "__two__"}
    router.dynamic_routes = {0: route}

    with pytest.raises(Exception) as exception:
        router.finalize()
    assert str(exception.value) == "Invalid route: <Route(/ [GET])>. Parameter names cannot use '__'."


# Generated at 2022-06-24 04:37:25.042434
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None


# Generated at 2022-06-24 04:37:29.033105
# Unit test for method add of class Router
def test_Router_add():
    """
    Test if the add method of class Router is working properly
    """

    router = Router()
    assert router.dynamic_routes == {}

    router.add('/', ['GET'], lambda: None)
    assert router.dynamic_routes != {}

# Generated at 2022-06-24 04:37:31.161950
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    route = router.add("/abc/xyz/")
    assert route.path == "/abc/xyz/"


# Generated at 2022-06-24 04:37:35.663990
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.ROUTER_CACHE_SIZE == 1024
    assert router.ALLOWED_METHODS == [
        'GET',
        'HEAD',
        'POST',
        'PATCH',
        'PUT',
        'DELETE',
        'OPTIONS'
    ]
    assert router.DEFAULT_METHOD == 'GET'

# Generated at 2022-06-24 04:37:40.559222
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router != None
    assert router.ctx != None
    assert router.DEFAULT_METHOD == 'GET'
    assert router.ALLOWED_METHODS == ['GET', 'HEAD', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS']

# Generated at 2022-06-24 04:37:41.442313
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None


# Generated at 2022-06-24 04:37:51.094382
# Unit test for method add of class Router

# Generated at 2022-06-24 04:37:52.831471
# Unit test for method finalize of class Router
def test_Router_finalize():
    def foo():
        pass
    r = Router()
    r.add("/foo/<name>", ["GET"], foo)
    r.finalize()

# Generated at 2022-06-24 04:37:54.203402
# Unit test for constructor of class Router
def test_Router():
    # when:
    router = Router()

    # then:
    assert isinstance(router, Router)

# Generated at 2022-06-24 04:37:58.242785
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    uri = "test"
    methods = ["GET"]
    handler = "test_handler"
    host = None
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = None
    unquote = False
    static = False

    router.add(uri, methods, handler, host, strict_slashes,
               stream, ignore_body, version, name, unquote, static)
    assert router.routes_all["test"].path == "test"

# Generated at 2022-06-24 04:38:03.924510
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Create router
    router = Router()

    # Test exception case
    with pytest.raises(SanicException):
        router.dynamic_routes = {1: "__uri__"}
        router.finalize()

    # Test normal case
    router.dynamic_routes = {1: "__file_uri__"}
    router.finalize()

# Generated at 2022-06-24 04:38:09.112996
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    from sanic.response import text

    app = Sanic('test_Router_finalize')

    @app.route('/')
    async def test(request):
        return text('OK')
  
    Router.finalize(Router(app, {}), app)

# Generated at 2022-06-24 04:38:13.782402
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == []
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.host == None



# Generated at 2022-06-24 04:38:24.573547
# Unit test for method finalize of class Router
def test_Router_finalize():
    import sanic_routing

    # test on odd name
    def handler():
        pass
    router = Router()
    route = router.add(uri="/<param>/<__bad>/<_sub>", methods=['GET'], handler=handler)
    # path with __bad
    try:
        router.finalize()
    except SanicException:
        pass
    else:
        assert False
    # path without bad label
    router = Router()
    route = router.add(uri="/<param>/<sub>/<__good>", methods=['GET'], handler=handler)
    router.finalize()
    assert route.labels == {'sub': '[^/]+', 'param': '[^/]+', '__good': '[^/]+'}
    # path without any label
    router = Router()

# Generated at 2022-06-24 04:38:30.011198
# Unit test for method add of class Router
def test_Router_add():
    def handler_view():
        pass
    uri = '/hello'
    methods = ['GET', 'POST']
    router = Router()
    router.add(uri, methods, handler_view)
    assert router.dynamic_routes == {}

# Generated at 2022-06-24 04:38:32.760203
# Unit test for method add of class Router
def test_Router_add():
    pass



# Generated at 2022-06-24 04:38:38.298703
# Unit test for method add of class Router
def test_Router_add():
    instance = Router()
    uri = "/"
    methods = []
    handler = ""
    host = None
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = None 
    unquote = False
    static = False
    assert instance.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static) != None

# Generated at 2022-06-24 04:38:47.526080
# Unit test for method add of class Router
def test_Router_add():
    expected_route1 = Route('/', get_handler, ['GET'], 'GET', None, None, None, None)
    assert test_router.find_route_by_view_name('get_handler') == expected_route1
    assert test_router.dynamic_routes == {}
    expected_route2 = Route('/<onedim>', get_handler, ['GET'], 'GET', 'onedim', None, None, None)
    assert test_router.find_route_by_view_name('get_handler') == expected_route2
    assert test_router.dynamic_routes == {('/<onedim>', ['GET']): expected_route2}

# Generated at 2022-06-24 04:38:52.607287
# Unit test for method add of class Router
def test_Router_add():
    def handler(request):
        pass

    ret = Router().add('/', ['GET', 'POST'], handler)
    assert ret.path == '/'
    assert ret.methods == ['GET', 'POST']
    assert ret.handler == handler
assert test_Router_add() is None


# Generated at 2022-06-24 04:38:58.190611
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic_routing.ctx import RouteContext
    from sanic import Sanic
    ctx = RouteContext(Sanic("UnitTest"))
    router = Router(ctx=ctx)

    class Route:
        def __init__(self, labels):
            self.labels = labels

    router.dynamic_routes = {
        "TestRoute": Route(["InvalidParam"]),
    }
    try:
        router.finalize()
    except Exception as e:
        assert type(e) is SanicException
        assert str(e) == "Invalid route: <sanic_routing.tests.test_router.Route object at 0x7f8ed845f438>. Parameter names cannot use '__'."

# Unit tests for method find_route_by_view_name of class Router

# Generated at 2022-06-24 04:38:58.660313
# Unit test for constructor of class Router
def test_Router():
    pass

# Generated at 2022-06-24 04:39:00.970447
# Unit test for method add of class Router
def test_Router_add():
    methods = ('GET', 'OPTIONS')
    request_handler = lambda req: 'Hello World!'

    # create a router object
    router_obj = Router()
    
    # check if the method returns a Route object
    assert isinstance(router_obj.add(uri='/home', methods=methods,
        handler=request_handler), Route)

# Generated at 2022-06-24 04:39:11.085698
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add('/', ['GET'], 'print', unquote=True)
    router.add('/user', ['GET'], 'print', unquote=True)
    router.add('/user/<name>', ['GET'], 'print', unquote=True)
    router.add('/user/<name>', ['POST'], 'print', unquote=True)
    router.add('/user/<name>', ['PUT'], 'print', unquote=True)

    assert type(router.routes) == dict
    assert len(router.routes) == 5
    assert len(router.routes['/'].methods) == 1
    assert len(router.routes['/user'].methods) == 1

# Generated at 2022-06-24 04:39:12.813102
# Unit test for method add of class Router
def test_Router_add():
    route = Router().add
    assert isinstance(route, types.MethodType)

# Generated at 2022-06-24 04:39:23.310023
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic_routing import Route
    from sanic.constants import HTTP_METHODS
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler

    def hello(request, *args, **kwargs):
        return 'Hello'

    router = Router(None)
    router.dynamic_routes['route1'] = Route('/test/', hello, HTTP_METHODS, test=True)
    router.dynamic_routes['route2'] = Route('/__file_uri__', hello, HTTP_METHODS, test=True)

    try:
        router.finalize()
    except Exception:
        assert False
    else:
        assert True

# Generated at 2022-06-24 04:39:31.743047
# Unit test for method add of class Router
def test_Router_add():
    router = Router()

    def handler1(request):
        pass

    def handler2(request):
        pass

    router.add("/path1/", ["GET"], handler1)
    router.add("/path2/", ["GET"], handler2)
    router.add("/path3/", ["GET"], handler2, version="v1.0")
    router.add("/path4/", ["GET"], handler2, version="v1.0", strict_slashes=True)
    router.add("/path5/", ["GET"], handler2, version="v1.0", strict_slashes=True, unquote=True)
    router.add("/path6/", ["GET"], handler2, version="v1.0", strict_slashes=True, unquote=True, host="example.com")


# Generated at 2022-06-24 04:39:34.794449
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []

# Generated at 2022-06-24 04:39:42.439755
# Unit test for method finalize of class Router
def test_Router_finalize():
    class APP:
        def __init__(self):
            self.routes = []
        
        def _generate_name(self, name):
            return name

    class R:
        def __init__(self):
            self.app = APP()
            self.static_routes = {}
            self.dynamic_routes = {'labels': 'xxx'}
            self.regex_routes = {}
            self.name_index = {'labels': 'xxx'}
        
        def add(self):
            pass
        
        def resolve(self):
            pass

    r = R()
    r.finalize()


# Generated at 2022-06-24 04:39:48.122684
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router as Traceroute
    import pytest
    router = Traceroute()
    router.dynamic_routes = {'a': 1}
    router.dynamic_routes.values = {'b': 1}
    with pytest.raises(SanicException, match="Invalid route: 1. Parameter names cannot use '__'."):
        router.finalize()


# Generated at 2022-06-24 04:39:58.340793
# Unit test for method add of class Router
def test_Router_add():
    """
    Unit test for method add of class Router
    """
    _router = Router()
    _handlers = [
        lambda r: r,
        lambda r: r,
        lambda r: r,
    ]
    _hosts = [
        'https://api.github.com',
        'https://api.github.com',
        'https://api.github.com',
        'https://api.github.com',
        'https://api.github.com',
        'https://api.github.com',
        'https://api.github.com',
        'https://api.github.com',
    ]

# Generated at 2022-06-24 04:40:00.924389
# Unit test for method finalize of class Router
def test_Router_finalize():

    from sanic import Sanic

    app = Sanic('test_Router_finalize')
    app.router.add(
        uri="/\<username:string>",
        methods=["GET"],
        handler=lambda request: "ok",
    )
    app.router.finalize()



# Generated at 2022-06-24 04:40:10.629895
# Unit test for method add of class Router
def test_Router_add():
    router = Router(ctx = None)

    uri = "/dummy_url"
    methods = ["GET", "POST", "OPTIONS"]
    handler = RouteHandler()
    host = None
    strict_slashes = False
    stream = False
    ignore_body = False
    version = 3
    name = "dummy"
    unquote = True
    static = False

    # We create a route
    route = router.add(uri,methods,handler,host, strict_slashes,stream,ignore_body,version,name,unquote,static)
    route1 = router.add(uri,methods,handler,host, strict_slashes,stream,ignore_body,version,name,unquote,static)

    # We test if the returned values are equals
    assert route.ctx.ignore_body == ignore_body


# Generated at 2022-06-24 04:40:22.001777
# Unit test for method add of class Router
def test_Router_add():
    from sanic.router import Router
    # from sanic.exceptions import MethodNotSupported, NotFound, SanicException
    from sanic.response import text
    from sanic.utils import sanic_endpoint_test
    from sanic import Sanic

    app = Sanic()

    @app.route('/')
    def handler(request):
        return text('OK')

    request, response = sanic_endpoint_test(app)
    assert response.status == 200

    app.router.add(
        "/foo", ["GET"], handler, strict_slashes=False, unquote=True
    )

    request, response = sanic_endpoint_test(app, uri='/foo')
    assert response.status == 200


# Generated at 2022-06-24 04:40:32.779865
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router(ctx=object())

    # Regular route
    route = router.add("/", ["GET"], lambda req: None)
    router.finalize()
    assert isinstance(route, Route)

    # Regular route with multiple labels
    route = router.add("/<label1>/<label2>", ["GET"], lambda req: None)
    router.finalize()
    assert isinstance(route, Route)

    # Route with a parameter starting with "__"
    route = router.add("/<__label>", ["GET"], lambda req: None)
    try:
        router.finalize()  # should raise error
        assert False
    except SanicException:
        pass
        # Route with allowed parameter starting with "__"

# Generated at 2022-06-24 04:40:39.255602
# Unit test for method add of class Router
def test_Router_add():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    import os

    app = Sanic(configure_logging=False)

    def handler(request):
        return {}

    app.add_route(handler, "/", methods=["GET", "POST", "OPTIONS"])

    # get, post, options
    assert all(
        m in app.router.routes_all
        for m in ["GET", "POST", "OPTIONS"]
    )
    # 1 route
    assert len(app.routes) == 1

    # set a name
    app.add_route(handler, "/test", methods=["GET"], name="test_route")

# Generated at 2022-06-24 04:40:44.302771
# Unit test for method add of class Router
def test_Router_add():
    _Router = Router()
    _Router.add(
        uri="/mcsim",
        methods=["GET", "POST", "OPTIONS"],
        handler=None,
        host=None,
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version=None,
        name=None,
        unquote=False,
        static=False
    )

# Generated at 2022-06-24 04:40:53.049334
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add(
        uri='test_uri',
        methods=['method1', 'method2'],
        handler='test_handler',
        host='host1',
        strict_slashes='strict_slashes1',
        stream='stream1',
        ignore_body='ignore_body1',
        version='version1',
        name='name1',
        unquote='unquote1',
        static='static1'
    )

# Generated at 2022-06-24 04:40:59.252977
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    with pytest.raises(Exception) as e_info:
        router = Router()
        route = Route(router, "/test/<__test>")
        # Add __test to dynamic route
        router.dynamic_routes["GET"].add(route)
        router.finalize()
    assert (str(e_info.value)) == "Invalid route: /test/<__test>. Parameter names cannot use '__'."

# Generated at 2022-06-24 04:41:10.026586
# Unit test for method add of class Router
def test_Router_add():
    @lru_cache(maxsize=ROUTER_CACHE_SIZE)
    def find_route_by_view_name(x, y):
        return None
    # add router instance to globals so that it can be found in the function body
    globals()["find_route_by_view_name"] = find_route_by_view_name

    def handler():
        pass

    router = Router(None)
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}

    def noop():
        pass

    # test default arguments

# Generated at 2022-06-24 04:41:20.983667
# Unit test for method finalize of class Router
def test_Router_finalize():
    # test with Router class
    r=Router()
    r.dynamic_routes["abc"] = Route(path="abc", handler=lambda: None, methods=["GET", "POST"], name="abc", strict=True)
    r.dynamic_routes["bcd"] = Route(path="bcd", handler=lambda: None, methods=["GET", "POST"], name="bcd", strict=True)
    r.dynamic_routes["cde"] = Route(path="cde", handler=lambda: None, methods=["GET", "POST"], name="cde", strict=True)
    try:
        r.finalize()
    except Exception as e:
        assert(str(e)=="Invalid route: cde. Parameter names cannot use '__'.")

    # test with Route class

# Generated at 2022-06-24 04:41:32.622687
# Unit test for method add of class Router
def test_Router_add():

    test_uri = 'test_uri'
    test_methods = ['GET', 'POST']
    test_handler = 'test_handler'

    new_router = Router()

    assert new_router.add(test_uri, test_methods, test_handler)
    assert new_router.routes[0].path == test_uri
    assert new_router.routes[0].methods[0] == test_methods[0]
    assert new_router.routes[0].methods[1] == test_methods[1]
    assert new_router.routes[0].handler == test_handler
    assert new_router.routes[0].ctx.hosts == [None]
    assert new_router.routes[0].ctx.ignore_body

# Generated at 2022-06-24 04:41:38.945961
# Unit test for method add of class Router
def test_Router_add():

    router = Router()

    params = dict(
        path="/",
        methods=["GET"],
        handler=print,
        name="a",
        strict=False,
        unquote=False
    )

    route = router.add(**params)
    route.ctx.ignore_body = False
    route.ctx.stream = False
    route.ctx.hosts = "*"

    assert router.name_index == {"a": route}
    assert router.routes_all == [route]
    assert router.routes_dynamic == {}

# Generated at 2022-06-24 04:41:48.976916
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.dynamic_routes = {
            "test": Route(path="/test/<param>",
                          handler=RouteHandler(),
                          methods=["GET"],
                          labels=["param"],
                          name="")}
    try:
        router.finalize()
    except SanicException:
        pass
    else:
        assert False, "Invalid route not raised"

    router.dynamic_routes = {
        "test": Route(path="/test/<__param>",
                      handler=RouteHandler(),
                      methods=["GET"],
                      labels=["__param"],
                      name="")}
    try:
        router.finalize()
    except SanicException:
        assert False, "Invalid route raised"

# Generated at 2022-06-24 04:41:54.345948
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router("")
    new_route = Route("/", None, "get", [], None, None)
    new_route.labels = ["__test"]
    router.static_routes["/"] = new_route

    router.finalize()

    new_route.labels = ["__test", "__test2"]
    with pytest.raises(SanicException):
        router.finalize()

# Generated at 2022-06-24 04:42:02.679442
# Unit test for method add of class Router
def test_Router_add():
    from sanic.response import json
    from sanic.views import CompositionView

    router = Router()
    test_method = [
        "GET",
        "POST",
        "HEAD",
        "OPTIONS",
        "PUT",
        "PATCH",
        "DELETE",
    ]
    test_route = [
        "/",
        "/home",
        "/home/",
        "/home/<name:string>",
    ]


    def test_handler():
        return json({"test": True})


    def add_test_case(test_method):
        for test_route in test_route:
            router.add(test_route, test_method, test_handler)


    for method in test_method:
        add_test_case(method)

# Generated at 2022-06-24 04:42:08.642917
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    from unittest.mock import MagicMock

    router = Router()
    router.dynamic_routes = {"route": MagicMock()}
    router.dynamic_routes["route"].labels = ["__file_uri__", "__file_uri__1"]
    router.finalize()
    with pytest.raises(SanicException, match=r".*__file_uri__1.*"):
        router.finalize()
    

# Generated at 2022-06-24 04:42:13.763072
# Unit test for method finalize of class Router
def test_Router_finalize():
    tmp_router = Router(app=None)
    tmp_dynamic_routes: Dict[str, Route] = {}
    tmp_router.dynamic_routes = tmp_dynamic_routes
    tmp_router.finalize()


# Generated at 2022-06-24 04:42:14.781216
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.finalize()

# Generated at 2022-06-24 04:42:19.352918
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        r = Router()
        r.add_route(Route(RouteHandler, '', '', ''))
        r.finalize()
    except SanicException as e:
        assert e == SanicException(f"Invalid route: {Route(RouteHandler, '', '', '')}. Parameter names cannot use '__'.")

# Generated at 2022-06-24 04:42:24.073657
# Unit test for method add of class Router
def test_Router_add():
    from sanic.sanic import Sanic
    router = Router()
    # add test case
    def test_handler():
        pass
    app = Sanic("Test")
    router.add("/test/view", ["GET"], test_handler)


# Generated at 2022-06-24 04:42:33.999763
# Unit test for constructor of class Router
def test_Router():
    uri = "client"
    methods = ["POST"]
    handler = "handler"
    host = None
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = None
    unquote = False
    static = False
    router = Router()
    assert router.get(uri, methods[0], host) == (None, None, None)
    assert router.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static) == Route(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)
    assert router.find_route_by_view_name(view_name=None) == None
    assert router.routes_all == router.d

# Generated at 2022-06-24 04:42:36.024948
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, BaseRouter)
    assert len(router.routes_all) == 0
    assert len(router.routes_static) == 0
    assert len(router.routes_dynamic) == 0
    assert len(router.routes_regex) == 0



# Generated at 2022-06-24 04:42:36.966640
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    pass

# Generated at 2022-06-24 04:42:47.537757
# Unit test for method add of class Router
def test_Router_add():
    _uri = "/v1/users"
    _methods = ["POST"]
    _handler = RouteHandler
    _host = "127.0.0.1"
    _strict_slashes = False
    _stream = False
    _ignore_body = False
    _version = "1.0"
    _name = "view_name"
    _unquote = False
    _static = False
    __uri = "/v1/users"
    __methods = ["POST"]
    __handler = RouteHandler
    __host = None
    __strict_slashes = False
    __stream = False
    __ignore_body = False
    __version = None
    __name = "view_name"
    __unquote = False
    __static = False
    router = Router()
    _routes = router.add

# Generated at 2022-06-24 04:42:49.194257
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)



# Generated at 2022-06-24 04:42:57.572808
# Unit test for method finalize of class Router
def test_Router_finalize():
    route = Route(
        path="/api/user/<id>/get",
        handler=None,
        methods=["GET"],
        name="GetUserById",
        strict=False,
        unquote=False,
    )

    route.ctx.labels = route.ctx.labels + ("__id_get__",)
    router = Router()
    router.dynamic_routes["/api/user/<id>/get"] = route

    with pytest.raises(SanicException) as e:
        router.finalize()
        assert e.args[0] == f"Invalid route: {route}. Parameter names cannot use '__'."


# Generated at 2022-06-24 04:43:01.349502
# Unit test for constructor of class Router
def test_Router():
    # simple test for constructor
    from sanic.router import Router
    from sanic.request import Request
    router = Router(None)
    assert router.ctx == None
    return None


# Generated at 2022-06-24 04:43:03.257108
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    @router.add("/", ['GET'])
    def hello_world(request):
        return f"Hello world!"
    return hello_world

# Generated at 2022-06-24 04:43:03.634359
# Unit test for method finalize of class Router
def test_Router_finalize():
    route = Router()

# Generated at 2022-06-24 04:43:05.455249
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == []
    assert router.name_index == {}


# Generated at 2022-06-24 04:43:09.263788
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, BaseRouter)

# Generated at 2022-06-24 04:43:14.256216
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    # Test that the function finalize method of the class Router works properly when we pass an invalid label
    prefix = "__"
    new_label = "".join([prefix, "file_uri"])
    assert new_label not in ALLOWED_LABELS
    new_label = "".join([prefix, "file_uri", "__"])
    assert new_label in ALLOWED_LABELS

# Generated at 2022-06-24 04:43:15.150193
# Unit test for constructor of class Router
def test_Router():
    router = Router(app=None)
    assert router.DEFAULT_METHOD == "GET"

# Generated at 2022-06-24 04:43:16.318284
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert type(router) == Router


# Generated at 2022-06-24 04:43:20.351198
# Unit test for method add of class Router
def test_Router_add():
    test_router = Router()
    result = test_router.add(
        "/test_uri",
        ["GET", "POST"],
        "test_handler",
        host="test_host",
        strict_slashes=True,
        stream=True,
        ignore_body=True,
        version=1,
        name="test_name",
        unquote=True,
        static=False,
    )
    print(result)


# Generated at 2022-06-24 04:43:30.074519
# Unit test for method finalize of class Router
def test_Router_finalize():
    route1_string = "/"
    route2_string = "/abc/{some_name__some_file_uri__}"
    route3_string = "/abc/{some_name__some_file_uri__}/{some_other_name__some_other_file_uri__}"
    route1 = Route(route1_string, lambda request: "OK", ("GET", "POST",), [])
    route2 = Route(route2_string, lambda request: "OK", ("GET", "POST",), [])
    route3 = Route(route3_string, lambda request: "OK", ("GET", "POST",), [])
    route1.ctx.set_defaults = {}
    route2.ctx.set_defaults = {}
    route3.ctx.set_defaults = {}
    route1_dict = {}
   

# Generated at 2022-06-24 04:43:37.524867
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    def test_finalize():
        class TestRouter(Router):
            def finalize(self, *args, **kwargs):
                super().finalize(*args, **kwargs)

            @staticmethod
            def add(
                uri: str,
                methods: Iterable[str],
                handler: RouteHandler,
                host: Optional[Union[str, Iterable[str]]] = None,
                strict_slashes: bool = False,
                stream: bool = False,
                ignore_body: bool = False,
                version: Union[str, float, int] = None,
                name: Optional[str] = None,
                unquote: bool = False,
                static: bool = False,
            ):
                return Route(uri, methods, handler, name, host)

        router = TestRouter

# Generated at 2022-06-24 04:43:44.474393
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.app import Sanic
    from sanic.constants import HTTP_METHODS
    from sanic.router import Router

    app = Sanic("Router finalize")
    router = Router(app)
    try:
        router.finalize()
    except SanicException as e:
        assert str(e) == "No routes found."

    for http_method in HTTP_METHODS:
        router.add(  # type: ignore
            uri="/", method=http_method, handler=app.route_middleware(None)
        )

# Generated at 2022-06-24 04:43:55.527530
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    from sanic_routing.trie import Trie

    class MockRoute(object):

        def __init__(self, labels):
            self.labels = labels

    class MockRouter(Router):

        def __init__(self):
            self.trie = Trie()
            self.endpoints = {}
            self.dynamic_routes = {"route": MockRoute(["__file_uri__"])}

    # test the case that "labels contains __"
    router = MockRouter()
    router.finalize()

    # test the case that "label does not contain __"
    router = MockRouter()
    router.dynamic_routes["route"] = MockRoute(["__a__"])
    with pytest.raises(SanicException):
        router.finalize

# Generated at 2022-06-24 04:44:00.795379
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r.get('path') == '<Response [404]>'
    assert r.delete('path') == '<Response [404]>'
    assert r.post('path') == '<Response [404]>'
    assert r.put('path') == '<Response [404]>'
    assert r.patch('path') == '<Response [404]>'
    assert r.update() == '<Response [404]>'

# Generated at 2022-06-24 04:44:09.441499
# Unit test for constructor of class Router
def test_Router():
    url_str = '/index/'
    methods = ['POST']
    handler = 10
    host = None
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = None
    unquote = False
    static = False
    router = Router()
    router.add(url_str, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)
    assert router.routes_all[0].path ==  '/index/'
    assert router.routes_all[0].uri ==  '/index/'
    assert router.routes_all[0].uri_template ==  '/index/'
    assert router.routes_all[0].host is None

# Generated at 2022-06-24 04:44:19.916553
# Unit test for method add of class Router
def test_Router_add():
    from sanic.blueprints import Blueprint
    from sanic.router import Router
    from sanic.views import HTTPMethodView

    blueprint_b = Blueprint("test_bp1", url_prefix="/blue")
    blueprint_b.add_route(HTTPMethodView.as_view(), "/test")

    blueprint_a = Blueprint("test_bp2", url_prefix="/blue")
    blueprint_a.add_route(HTTPMethodView.as_view(), "/test2")

    # Create a router
    router = Router()
    # Create a route to be added to the router
    print(router.routes_all)
    routes = router.add(
        uri="/test/<name:string>", methods=["GET"], handler=HTTPMethodView.as_view()
    )

# Generated at 2022-06-24 04:44:25.822299
# Unit test for method add of class Router
def test_Router_add():
    def handler(*args, **kwargs):
        pass

    def handler1(*args, **kwargs):
        pass

    router = Router()
    router.add("/", methods=['GET'], handler=handler)

    assert isinstance(router.routes[0], Route)
    assert router.routes[0].handler is handler
    assert router.routes[0].path == "/"


# Generated at 2022-06-24 04:44:33.207691
# Unit test for method add of class Router
def test_Router_add():
    router=Router()
    assert True == router.add(
        uri="uri",
        methods=["GET"],
        handler=lambda path:path,
        host=None,
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version=None,
        name=None,
        unquote=False,
        static=False,
    )


# Generated at 2022-06-24 04:44:35.488619
# Unit test for constructor of class Router
def test_Router():
    with pytest.raises(SanicException):
        Router()

# Generated at 2022-06-24 04:44:39.846151
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    class test_class:
        pass
    test_instance = test_class()
    test_instance.test = "test"
    assert isinstance(test_instance,test_class)
    router.add("/test/","GET",test_instance.test)
    assert router.routes["/test/"].ctx.static == False
    assert router.routes["/test/"].ctx.stream == False


# Generated at 2022-06-24 04:44:47.080537
# Unit test for method add of class Router
def test_Router_add():
    test_uri = "test_uri"
    test_methods = ["GET", "POST", "OPTIONS"]
    test_host = "host"
    test_handler = "handler"
    test_strict_slashes = False
    test_stream = False
    test_ignore_body = False
    test_version = None
    test_name = "name"
    test_unquote = False
    test_static = False

    router = Router()

    route = router.add(test_uri,test_methods,test_handler,test_host,test_strict_slashes,test_stream,test_ignore_body,test_version,test_name,test_unquote,test_static)

    assert isinstance(route,Route)


# Generated at 2022-06-24 04:44:52.629481
# Unit test for method add of class Router
def test_Router_add():
    handler = lambda x : x
    uri = "/uri"
    method = "GET"

    router = Router()
    router.add(uri, method, handler)

    assert(router.routes[uri][method][0].handler == handler)

# Generated at 2022-06-24 04:44:59.957239
# Unit test for method add of class Router
def test_Router_add():
    from sanic.request import Request

    from sanic_routing.route import Route

# Tests for method add of class Router
    def setUp(self):
        self.test_router = Router()

    def test_add_raises_error_if_handler_is_not_callable(self):
        self.assertRaises(TypeError, self.test_router.add,
            uri='some/uri', methods=None, handler=None)

    def test_add_works_without_methods_or_host(self):
        @self.test_router.add(uri='some/uri')
        async def handler(request):
            return 'some result'

        self.assertIn('some/uri', self.test_router.routes_all)

        route_obj = self.test_rou

# Generated at 2022-06-24 04:45:07.784841
# Unit test for method add of class Router
def test_Router_add():

    from sanic.router import Router
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import CompositionView

    router = Router(None)
    router.add(path="/", methods=["GET"], view=CompositionView())
    router.add(
        path="/<name>/<id>",
        methods=["GET"],
        handler=lambda request: HTTPResponse(text="text"),
    )

    request, _ = Request.fake_request()

    routes, _, _ = router.get_routes(request)
    assert len(routes) == 2

    assert routes[0].uri == "/"
    assert routes[0].methods == ["GET"]
    assert routes[0].handlers[0].__class__.__name__