

# Generated at 2022-06-24 04:35:09.162111
# Unit test for method finalize of class Router
def test_Router_finalize():
    pass

# Generated at 2022-06-24 04:35:16.822776
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    from sanic.exceptions import SanicException

    rt = Router()
    rt.add("/", ["GET", "POST"], None)

    rt.finalize()

    with pytest.raises(SanicException):
        rt.add("/", ["GET", "POST"], None, __file_uri__="foo/bar")

    rt.add("/", ["GET", "POST"], None, __file_uri__="foo/bar")

    rt.finalize()

# Generated at 2022-06-24 04:35:24.168594
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router() # type: ignore
    try:
        r.add("/", methods=["GET"], handler="handler", name="api")
        r.finalize()
    except SanicException:
        pass
    else:
        raise Exception('AssertionError')
    r.add("/", methods=["GET"], handler="handler", name="__file_uri__")
    r.finalize()

# Generated at 2022-06-24 04:35:29.638710
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    return router


# Generated at 2022-06-24 04:35:41.282485
# Unit test for method add of class Router
def test_Router_add():
    class app:
        def _generate_name(view_name: str) -> str:
            return 'a'
    router = Router()
    router.ctx.app = app()
    # wrong params
    try:
        router.add(1, [1], 1, 1, 1, 1, 1, 1)
    except SanicException:
        pass
    except BaseException:
        assert False
    # wrong methods
    try:
        router.add('a', ['1'], 1)
    except SanicException:
        pass
    except BaseException:
        assert False
    # wrong params with correct params
    try:
        router.add('a', ['GET'], 1, 1, 1, 1, 1, 1, name='a')
    except SanicException:
        pass
    except BaseException:
        assert False

# Generated at 2022-06-24 04:35:41.883218
# Unit test for constructor of class Router
def test_Router():
    router = Router()



# Generated at 2022-06-24 04:35:47.001535
# Unit test for constructor of class Router
def test_Router():
    myRouter = Router()
    assert myRouter.ALLOWED_METHODS == HTTP_METHODS
    assert myRouter.DEFAULT_METHOD == 'GET'
    assert myRouter.ROUTER_CACHE_SIZE == 1024

# Generated at 2022-06-24 04:35:55.482483
# Unit test for method add of class Router
def test_Router_add():
    def f():
        pass

    r = Router()
    route = r.add(
        uri=f.__name__,
        methods=["GET", "POST"],
        handler=f,
        host=None,
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version=None,
        name=None,
        unquote=True,
        static=False,
    )
    assert route.ctx.hosts == [None] and route.ctx.static is False and route.ctx.unquote is True

# Generated at 2022-06-24 04:35:56.292381
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router



# Generated at 2022-06-24 04:36:03.361814
# Unit test for method add of class Router
def test_Router_add():
    uri = '/'
    methods = ['GET']
    handler = lambda x: x
    host = None
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = None
    unquote = False
    static = False

    router = Router()
    router.add(
        uri,
        methods,
        handler,
        host,
        strict_slashes,
        stream,
        ignore_body,
        version,
        name,
        unquote,
        static
    )
    # error: Invalid route: /. Parameter names cannot use '__'.
    # actually, this is a test for method finalize of class Router
    
    uri = '-/'

# Generated at 2022-06-24 04:36:04.021310
# Unit test for constructor of class Router
def test_Router():
    # just pass unit test
    router = Router(None)


# Generated at 2022-06-24 04:36:05.269565
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)

# Generated at 2022-06-24 04:36:16.544924
# Unit test for method add of class Router
def test_Router_add():
    # Initialization
    router = Router()
    uri = r"/some/uri"
    methods = ["GET", "POST"]
    handler = lambda: None
    host = "some_host"
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = "some_name"
    unquote = False
    static = False
    result: Union[Route, List[Route]] = router.add(
        uri=uri,
        methods=methods,
        handler=handler,
        host=host,
        strict_slashes=strict_slashes,
        stream=stream,
        ignore_body=ignore_body,
        version=version,
        name=name,
        unquote=unquote,
        static=static,
    )

    # Check


# Generated at 2022-06-24 04:36:24.894085
# Unit test for method add of class Router
def test_Router_add():
    rt = Router()
    try:
        rt.add('/', "GET", lambda r: r)
    except Exception:
        assert False

    try:
        rt.add(  # type: ignore
        uri='/',
        methods=["GET"],
        handler=lambda r: r,
        host=None,
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version=None,
        name=None,
        unquote=False,
        static=False,
        )
    except Exception:
        assert False

    assert len(rt.routes_all) == 2



# Generated at 2022-06-24 04:36:29.156985
# Unit test for method finalize of class Router
def test_Router_finalize():
    route = Route()
    route.labels=["__file_uri__","__test__"]
    router = Router()
    router.dynamic_routes={0: route}
    finalize = router.finalize()



# Generated at 2022-06-24 04:36:37.313016
# Unit test for method finalize of class Router
def test_Router_finalize():
    class Routes(Router):
        def __init__(self, app=None):
            self.app = app
            super().__init__(app=app)

    def add_route(self, path, methods, handler, host=None, **kwargs):
        return self.add(
            path=path,
            methods=methods,
            handler=handler,
            host=host,
        )
    Routes.add_route = add_route
    r = Routes()
    r.add_route(path="/test/<hr>", methods=["GET"], handler=None)
    r.add_route(
        path="/test/<hr>",
        methods=["GET"],
        handler=None,
        host="testing.example.com"
    )

# Generated at 2022-06-24 04:36:42.576390
# Unit test for method finalize of class Router
def test_Router_finalize():
    app = Mock()
    router = Router(app)
    router.dynamic_routes = {
        "key": "value",
        ("key1", "key2"): "value",
    }
    with pytest.raises(SanicException):
        router.finalize()
    router.dynamic_routes = {
        "key": "value",
        ("__file_uri__",): "value",
    }
    router.finalize()

# Generated at 2022-06-24 04:36:54.036982
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.exceptions import SanicException
    from sanic_routing.exceptions import NoMethod
    from sanic_routing import BaseRouter, Route

    class TestRouter(Router):
        def _get(self, path: str, method: str, host: Optional[str]) -> Tuple[Route, RouteHandler, Dict[str, Any]]:
            return NotImplemented

    router = TestRouter()
    base_router = BaseRouter()
    route = Route(request_handler=None)
    route.labels = ["__route_arg", "__route_arg_arg"]
    base_router.dynamic_routes = [route]
    router

# Generated at 2022-06-24 04:36:55.724599
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, BaseRouter)



# Generated at 2022-06-24 04:37:00.142068
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_dynamic == {}
    assert router.routes_static == {}
    assert router.routes_regex == {}
    assert router.routes_all == []
    assert router.name_index == {}


# Generated at 2022-06-24 04:37:02.652301
# Unit test for constructor of class Router
def test_Router():
    r = Router(Router.ALLOWED_METHODS)
    assert isinstance(r, Router)


# Generated at 2022-06-24 04:37:04.820586
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    with pytest.raises(AssertionError):
        router.add("/", ["GET"], lambda x: None)

# Generated at 2022-06-24 04:37:13.906673
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    from sanic.router import Route

    # Test to check if Route is lowercase
    # Negative test
    def test_route():
        with pytest.raises(SanicException):
            route = Route(None, 'ui/admin', None, None, None, None, None, None, None, None, None, None, None)

    test_route()

    # Test to check if Route is lowercase
    # Positive test
    def test_route():
        route = Route(None, 'ui/admin', None, None, None, None, None, None, None, None, None, None, None)
        assert route.path == 'ui/admin'

    test_route()

# Generated at 2022-06-24 04:37:14.820936
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None

# Generated at 2022-06-24 04:37:23.340571
# Unit test for method add of class Router
def test_Router_add():
    BaseRouter.add = Router.add
    BaseRouter.register = Router.register
    BaseRouter.get = Router.get
    BaseRouter.__init__ = Router.__init__
    obj = Router()

    assert obj.add(uri="",
                   methods=[],
                   handler=None,
                   host=None,
                   strict_slashes=False,
                   stream=False,
                   ignore_body=False,
                   version=None,
                   name=None,
                   unquote=False)


# Generated at 2022-06-24 04:37:34.022344
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    app = None # Mock for sanic.Sanic(__name__, router=Router(app))
    router = Router(app)
    router._routes = {
        'GET': [],
        'HEAD': [],
        'POST': [],
        'PUT': [],
        'DELETE': [],
        'OPTIONS': [],
        'TRACE': [],
        'CONNECT': [],
        'PATCH': []
    }

# Generated at 2022-06-24 04:37:35.945379
# Unit test for method add of class Router
def test_Router_add():
    u = Router()
    u.add("/",["GET"],"handler")
    assert isinstance(u,Router)



# Generated at 2022-06-24 04:37:39.681057
# Unit test for constructor of class Router
def test_Router():
    # Empty routes_all, routes_static and routes_dynamic
    router = Router(None)
    assert isinstance(router, Router)
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}

# Generated at 2022-06-24 04:37:41.304348
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    # none
    assert r


# Generated at 2022-06-24 04:37:43.714722
# Unit test for constructor of class Router
def test_Router():
    import sanic
    
    app = sanic.Sanic()
    router = Router(app)

# Generated at 2022-06-24 04:37:45.119398
# Unit test for constructor of class Router
def test_Router():
    try:
        Router()
        assert True
    except:
        assert False

# Generated at 2022-06-24 04:37:51.632669
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    Test the finalize method of the Router class
    """
    router = Router()
    uri = '/test_uri'
    methods = ['GET']
    handler = lambda x : x
    host = 'test_host'

    result = router.add(uri, methods, handler, host)
    assert isinstance(result, Route), 'The add method must return a Route object'
    assert result.path == uri, 'The path of the route is not correct'

    result = router.finalize()
    assert router.routes_all == {'test_uri': result}, 'The routes_all attribute is not correct'

# Generated at 2022-06-24 04:38:03.197802
# Unit test for method add of class Router
def test_Router_add():
    import tempfile
    from sanic import Sanic
    app = Sanic("TEST")
    router = Router()

# Generated at 2022-06-24 04:38:06.405288
# Unit test for method finalize of class Router
def test_Router_finalize():
    assert True


# Generated at 2022-06-24 04:38:10.439591
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    assert router.dynamic_routes == {}
    assert router.static_routes == {}
    assert router.regex_routes == {}

    def handler():
        pass

    router.add('/test', ['GET'], handler)
    assert router.dynamic_routes != {}
    assert router.static_routes != {}
    assert router.regex_routes == {}


# Generated at 2022-06-24 04:38:16.836675
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route1 = router.add('/<name1>', 'GET', None)
    route2 = router.add('/<name2>', 'GET', None)
    route3 = router.add('/<__file_uri__>', 'GET', None)
    try:
        router.finalize()
    except SanicException as e:
        assert e.args[0] == "Invalid route: " + str(route2) + \
            ". Parameter names cannot use '__'."
    else:
        assert False, "Should have raised SanicException"

# Generated at 2022-06-24 04:38:25.644864
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Test valid kwargs
    try:
        router = Router()
        router.add(uri='/',methods=['GET'],handler=None,host=None,strict_slashes=False,stream=False,ignore_body=False,version=None,name=None,unquote=False,static=False)
        router.finalize()
    except:
        assert False
    # Test invalid kwargs
    try:
        router = Router()
        router.add(uri='/',methods=['GET'],handler=None,host=None,strict_slashes=False,stream=False,ignore_body=False,version=None,name=None,unquote=False,static=False)
        router.finalize(abc='abc')
        assert False
    except:
        pass

# Generated at 2022-06-24 04:38:34.090460
# Unit test for method add of class Router
def test_Router_add():
    r = Router()
    def handler_test(request, args2):
        return True
    r.add("/path", ['GET'], handler_test)
    assert r.get("/path", "GET", None)[0].path == '/path'
    assert r.get("/path", "GET", None)[0].methods == ['GET']
    assert r.get("/path", "GET", None)[0].handler == handler_test


# Generated at 2022-06-24 04:38:37.282656
# Unit test for method add of class Router
def test_Router_add():
    router = Router()

    router.add("/", ["GET"], lambda request: "OK")

    assert router.routes_all
    assert router.routes_static
    assert router.routes_dynamic
    assert router.routes_regex

# Generated at 2022-06-24 04:38:47.437772
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    from sanic.router import Router
    router = Router()
    uri = 'test/{parameter}'
    methods = ['GET']
    handler = None
    host = None
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = None
    unquote = False
    static = False
    route = router.add(
        uri,
        methods,
        handler,
        host,
        strict_slashes,
        stream,
        ignore_body,
        version,
        name,
        unquote,
        static
    )
    router.finalize()
    assert route.labels == set()

    router = Router()
    uri = 'test/{parameter}'
    methods = ['GET']

# Generated at 2022-06-24 04:38:54.036069
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    from sanic import Sanic
    sanic = Sanic("test-sanic")
    uri = '/<a:int:>/<b:int:>'
    router.add(uri,['POST'], lambda request: None, name='test-route',static=True)
    router.finalize(sanic)
    assert router.dynamic_routes['test-route'].dynamic_route_args == {'a': 'int', 'b': 'int'}

# Generated at 2022-06-24 04:38:56.843091
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    def handler(request):
        return request
    router.add(uri="/", methods=['GET'], handler=handler)
    assert router.routes_all == {'GET /': handler}

# Generated at 2022-06-24 04:39:03.601745
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    
    path = "/"
    methods = "GET"
    handler = "test_handler"
    host = None
    strict_slashes = False
    stream = False
    ignore_body = False
    
    assert router.add(
        path,
        methods,
        handler,
        host,
        strict_slashes,
        stream,
        ignore_body
        ) is not None


# Generated at 2022-06-24 04:39:05.709831
# Unit test for constructor of class Router
def test_Router():
    from sanic.server import Sanic
    app = Sanic()
    router = Router(app)

# Generated at 2022-06-24 04:39:11.402993
# Unit test for method finalize of class Router
def test_Router_finalize():
    route1 = Route(path="/test", handler=None, methods=["GET"])
    route2 = Route(path="/test__1234", handler=None, methods=["GET"])

    routes = {None: {None: {None: {route1, route2}}} }

    router = Router(ctx=None, routes=routes)

    router.finalize()

    assert route1.labels == set()
    assert route2.labels == {"__1234"}

# Generated at 2022-06-24 04:39:23.103963
# Unit test for method add of class Router
def test_Router_add():
    test_routes_added=0
    test_methods={"GET"}
    test_handler=None #using default thus can be None
    test_host=None
    test_strict_slashes=False
    test_stream=False
    test_ignore_body=False
    test_version=None
    test_name=None
    test_unquote=False
    test_static=False
    test_uri="uri"
    router=Router()
    route=router.add(test_uri, test_methods, test_handler, test_host, test_strict_slashes, test_stream, test_ignore_body, test_version, test_name, test_unquote, test_static)
    if route.path==test_uri:
        test_routes_added+=1

# Generated at 2022-06-24 04:39:24.073644
# Unit test for constructor of class Router
def test_Router():
    Router()

# Generated at 2022-06-24 04:39:34.475158
# Unit test for method add of class Router
def test_Router_add():
    from sanic.exceptions import InvalidUsage
    from sanic.server import upgrade, serve
    
    # Set the app name
    app = Sanic() 
    methods = ["GET", "POST", "OPTIONS"]

    @app.route('/', methods=methods)
    async def handler(request): 
        return response.text('OK')

    router = Router()
    router.add('/', methods, handler)

    assert len(app.router.add_route.mock_calls) == 1
    # Set the app name
    app = Sanic() 
    methods = ["GET", "POST", "OPTIONS"]

    @app.route('/', methods=methods)
    async def handler(request): 
        return response.text('OK')

    router = Router()

# Generated at 2022-06-24 04:39:45.587838
# Unit test for method add of class Router
def test_Router_add():
    """
    Test add a route to router
    """
    # given
    route = Router()
    path = '/'
    methods = ('GET')
    handler = (lambda request: 'ok')
    host = 'localhost'
    strict_slashes = True
    stream = True
    ignore_body = True
    version = 1
    name = 'root'
    unquote = True
    static = True

    # when
    route.add(
        uri=path,
        methods=methods,
        handler=handler,
        host=host,
        strict_slashes=strict_slashes,
        stream=stream,
        ignore_body=ignore_body,
        version=version,
        name=name,
        unquote=unquote,
        static=static)

    # then

# Generated at 2022-06-24 04:39:53.006698
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()

    uri = "/test"
    route_obj = Route(
        uri,
        None,
        None,
        False,
        {},
        None,
        None,
        (),
        (),
        (),
        (),
        (),
        "",
        (),
        {},
        False,
        (),
        (),
    )

    try:
        router.finalize()
        assert False, "Does not raises SanicException"
    except SanicException as e:
        assert isinstance(e, SanicException)
        assert e.args[0] == "No routes added"

    route_obj.labels = {"__foo__": None, "__bar__": None}
    router.dynamic_routes[uri] = route_obj
    router.finalize()


# Generated at 2022-06-24 04:39:57.839406
# Unit test for method add of class Router
def test_Router_add():
    class TestRouter(Router):
        pass
    router = TestRouter()
    router.add('/', ['GET'], lambda x, y = None : y)

# Generated at 2022-06-24 04:40:09.939758
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.constants import HTTP_METHODS
    from sanic.router import Router
    from sanic.response import json
    from sanic.test import SanicTestClient

    app = Sanic("test_router")
    router = Router(app)
    new_route = router.add("/user/<id>", methods=HTTP_METHODS, handler=lambda r, id: json({"id": id}))
    assert new_route
    assert router.routes_dynamic[("/user/<id>", "ANY")] == new_route
    assert id in new_route.labels
    router.finalize()
    client = SanicTestClient(app, router=router)
    assert client.get("/user/1").json == {"id": "1"}

# Generated at 2022-06-24 04:40:12.083105
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    r.add('/', ['GET'], None, strict_slashes=False)
    r.finalize(None)
    assert isinstance(r.routes, dict)


# Generated at 2022-06-24 04:40:24.694713
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    test_route = router.add(uri='/', methods=['GET'], handler=None, host=None, strict_slashes=False, stream=False, ignore_body=False, version=None, name=None, unquote=False, static=True)
    test_route_2 = router.add(uri='/', methods=['GET'], handler=None, host=None, strict_slashes=False, stream=False, ignore_body=False, version=None, name=None, unquote=False, static=True)
    assert hasattr(test_route, '__iter__')
    assert hasattr(test_route_2, '__iter__')
    assert test_route[0].path == '/'
    assert test_route[0].methods == {'GET'}
    assert test_route

# Generated at 2022-06-24 04:40:32.197848
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Sanic app
    from sanic.app import Sanic
    app = Sanic("test_Router_finalize")

    # For test a custom router
    class CustomRouter(Router):
        pass

    # Unit test: non-dynamic route works well
    # Static route
    @app.route("/")
    async def test(request):
        pass

    # Router
    app.router = CustomRouter(app)

    app.router.add(
        uri="/",
        methods=["GET"],
        handler=test,
        host=None,
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version=None,
        name="test",
        unquote=False,
        static=False,
    )

    # Finalize router
   

# Generated at 2022-06-24 04:40:35.041617
# Unit test for method finalize of class Router
def test_Router_finalize():
    app = Sanic(__name__)
    app.router.add_route("GET", "/", lambda: None, name="test")
    with pytest.raises(SanicException):
        app.router.finalize()



# Generated at 2022-06-24 04:40:42.135799
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    from sanic.exceptions import InvalidUsage as SanicInvalidUsage
    
    def test_finalize_with_right_cases():
        router = Router(app=None) 
        route = Route(
            uri='/example/',
            method='GET',
            handler=None,
            host='example.com',
            strict_slashes=False,
            stream=False,
            name='example.com',
            version=None)
        route_pattern = {"/example/": route}
        router.dynamic_routes = route_pattern
        router.finalize()
        assert len(router.dynamic_routes) == 1
        
    def test_finalize_with_wrong_cases():
        router = Router(app=None) 

# Generated at 2022-06-24 04:40:45.716301
# Unit test for method add of class Router
def test_Router_add():
	"""
	test function
	"""
	def handler(request, *args, **kwargs):
		return request.app.response_class("Test\n", status=200, content_type='text/plain')
	r = Router()
	r.add("/", ["GET"], handler)
	return r

# Generated at 2022-06-24 04:40:58.815603
# Unit test for method add of class Router
def test_Router_add():
    from sanic.router import Router
    from sanic.response import text
    from pprint import pprint
    router = Router()
    assert router._hosts == {}
    assert router.routes == {}
    assert router.static_routes == {}
    assert router.regex_routes == []
    assert router.dynamic_routes == {}
    assert router.get_methods == {}
    assert router.name_index == {}

    router = Router()
    router.add('/', ['GET'], text('ok'))
    assert router._hosts == {None: {'/': [('GET', 'None')]}}

# Generated at 2022-06-24 04:41:04.504221
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add("/", "GET", lambda x: "hello")
    router.add("/", "POST", lambda x: "hello")
    router.add("/", "OPTIONS", lambda x: "hello")

# Generated at 2022-06-24 04:41:10.815048
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes == {}
    assert router.dynamic_routes == {}
    assert router.static_routes == {}
    assert router.name_index == {}

# Generated at 2022-06-24 04:41:13.580063
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None
    assert router.routes == []
    assert router.static_routes == []
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}

# Generated at 2022-06-24 04:41:18.068514
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    app = pytest.placebo_app(__name__)
    router = Router()
    router.ctx = app
    router.add('/{test}', ['GET'], None, name='test')
    router.finalize()
# vim:sw=4:ts=4:et:

# Generated at 2022-06-24 04:41:21.351371
# Unit test for constructor of class Router
def test_Router():
    # Create a router
    router = Router()

    # Create a route in the router
    router.add(
        uri='/test',
        methods=['POST'],
        handler=None,
        host=None,
        strict_slashes=False,
        stream=False,
        ignore_body= False,
        version=None,
        name=None,
        unquote=False,
        static=False
    )
    # Check whether the added route is in the router
    assert type(router.get('/test', 'POST', None)) == tuple

# Generated at 2022-06-24 04:41:33.035949
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add(
        uri= "/test_uri",
        methods=[],
        handler= router.DEFAULT_METHOD,
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version=None,
        name="test_name"
    )


# Generated at 2022-06-24 04:41:33.703241
# Unit test for method add of class Router
def test_Router_add():
    pass # TODO

# Generated at 2022-06-24 04:41:43.079895
# Unit test for method finalize of class Router
def test_Router_finalize():
    uri = 'abc'
    methods = []
    handler = None
    host = 'localhost'
    strict_slashes = False
    stream = False
    ignore_body = False
    version = 0.1
    name = None
    unquote = False
    static = False
    router = Router()
    route = router.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)
    try:
        router.finalize()
    except SanicException:
        assert False
    assert True
    
    

# Generated at 2022-06-24 04:41:43.980141
# Unit test for constructor of class Router
def test_Router():
    assert True

# Generated at 2022-06-24 04:41:49.072694
# Unit test for method finalize of class Router
def test_Router_finalize():
    # args and kwargs are used for testing *args and **kwargs
    router = Router(*args, **kwargs)
    type_expected = SanicException

    with pytest.raises(type_expected):
        router.finalize()

# Generated at 2022-06-24 04:41:55.312135
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Initialization
    test_uri = 'test_uri'
    test_methods = HTTP_METHODS.copy()
    test_handler = (lambda: "Handler")
    test_hosts = None
    route = Route(test_uri, test_methods, test_handler, test_hosts)

    # test
    router = Router()
    router.add(test_uri, test_methods, test_handler)
    router.finalize()

    assert router.dynamic_routes[test_uri] == route

# Generated at 2022-06-24 04:42:04.302675
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add('/test', HTTP_METHODS, RouteHandler, None, False, False,
                                                False, None, None, False, False)
    uri = '/test'
    methods = HTTP_METHODS
    handler = RouteHandler

    from sanic_routing.route import Route
    route = Route(router.ctx, uri, handler, methods, None, False, False,
                                                        None, None, False)
    assert router.routes['/test'] == route
    assert router.dynamic_routes == {}


# Generated at 2022-06-24 04:42:06.511367
# Unit test for constructor of class Router
def test_Router():
    assert isinstance(Router(), Router)


if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-24 04:42:16.837542
# Unit test for constructor of class Router
def test_Router():
    a = Router()
    uri = 'www.baidu.com'
    methods = ["GET", "POST", "OPTIONS"]
    handler = RouteHandler
    host = 'www.baidu.com'
    strict_slashes = True
    stream = True
    ignore_body = True
    version = 'aaa'
    name = 'name'
    unquote = True
    static = True
    a.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)
    # assert a.DEFAULT_METHOD == 'GET'
    # assert a.ALLOWED_METHODS == HTTP_METHODS
    # assert a.routes_all == a.routes
    # assert a.routes_static == a.static_routes

# Generated at 2022-06-24 04:42:20.520342
# Unit test for method finalize of class Router
def test_Router_finalize():
    class Server:
        def __init__(self):
            self.app = Application()

    f = Server()
    f.app.router.add("/test/<id>", ["GET"], lambda request, id: id)
    assert f.app.router.name_index.get("__file_uri__")

# Generated at 2022-06-24 04:42:30.589526
# Unit test for method finalize of class Router
def test_Router_finalize():
    import sanic
    sanic.Router.finalize = Router.finalize
    app = sanic.Sanic()

    @app.route('/', methods=['GET'])
    async def index(request):
        return sanic.response.text(request.method)

    @app.route('/custom/<id:int>', methods=['GET'])
    async def custom(request, id):
        return sanic.response.text(str(id))

    assert app.router.finalize()

    route = app.router.dynamic_routes['/custom/<id:int>']
    route.labels.append('__hello__')

    try:
        app.router.finalize()
    except SanicException:
        pass
    else:
        raise Exception("Something goes wrong")


# Generated at 2022-06-24 04:42:36.271731
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.static_routes == {}
    assert router.regex_routes == {}
    assert router.dynamic_routes == {}
    assert router.name_index == {}
    assert router.ctx.labels == {}
    assert isinstance(router.finalized, bool)
    assert router.finalized == False


# Generated at 2022-06-24 04:42:39.495552
# Unit test for constructor of class Router
def test_Router():
    r = Router()


# Generated at 2022-06-24 04:42:44.541382
# Unit test for method add of class Router
def test_Router_add():
    router = Router()

    @asyncio.coroutine
    def handle(request, *args, **kwargs):
        pass

    router.add(
        uri='/',
        methods=['GET'],
        handler=handle,
    )

# Generated at 2022-06-24 04:42:46.164172
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        router = Router()
        router.add("/users/<id:int>", ['GET'], None, name='id')
        router.finalize()
    except Exception as e:
        return False

    return True


# Generated at 2022-06-24 04:42:47.174288
# Unit test for constructor of class Router
def test_Router():
    """
    Should be 1
    """
    assert True

# Generated at 2022-06-24 04:42:49.193396
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    route = router.add("/", methods=["GET"], handler=None)


# Generated at 2022-06-24 04:42:54.395628
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}

    # assert router.get()
    # assert router.add()

# Generated at 2022-06-24 04:42:58.384905
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)

# Generated at 2022-06-24 04:43:06.141555
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.constants import HTTP_METHODS

    def my_function(request, *args, **kwargs):
        pass

    router = Router()
    for http_method in HTTP_METHODS:
        router.add('/', [http_method.lower()], my_function)

    assert router.finalize(None)

    router = Router()
    for http_method in HTTP_METHODS:
        router.add('/', [http_method.lower()], my_function,
                   name=http_method.lower())
    assert router.finalize(None)



# Generated at 2022-06-24 04:43:09.320946
# Unit test for constructor of class Router
def test_Router():
    assert Router()


# Generated at 2022-06-24 04:43:11.381786
# Unit test for method add of class Router
def test_Router_add():
    router = Router()

    def _handler(request):
        pass

    router.add(uri='/',methods =['GET'],handler = _handler)

    assert _handler == router.routes[0]['handler']


# Generated at 2022-06-24 04:43:17.463149
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.app import Sanic
    from sanic.router import Router

    app = Sanic()

    router = Router(app)
    try:
        router.finalize()
    except:
        assert False
    assert True


# Generated at 2022-06-24 04:43:19.651559
# Unit test for method add of class Router
def test_Router_add():
    Router().add("/", ["GET"], 0)


# Generated at 2022-06-24 04:43:26.424484
# Unit test for constructor of class Router
def test_Router():
    methods = HTTP_METHODS
    route_handler = lambda request: "hello"
    host = "localhost:8000"
    uri = "/"
    strict = False
    stream = False
    ignore_body = False
    version = 1
    name = "index"
    unquote = False
    static = False
    # Test for constructor of class Router
    router = Router()
    assert(router.add(uri, methods, route_handler, host, strict, stream, ignore_body, version, name, unquote, static))

# Generated at 2022-06-24 04:43:33.526298
# Unit test for method finalize of class Router
def test_Router_finalize():
    class Router(BaseRouter):
        ...
    Router.routes_dynamic = {}
    Router.routes_dynamic[0] = Route("/", None, None, None, None, None, None)
    Router.routes_dynamic[0].labels = ["__a"]
    with raises(SanicException):
        Router.finalize()
    print("test_Router_finalize passed!")


# Generated at 2022-06-24 04:43:39.725848
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    from sanic.models.route import Route

    class TestRoute(Route):
        def __init__(self, uri, handler, host=None, **kwargs):
            self.uri = uri
            self.handler = handler
            self.host = host
            self.ctx = {}

    class TestRouter(Router):
        def __init__(self, app, *args, **kwargs):
            self.app = app
            self.routes_all = []
            self.routes_static = []
            self.routes_dynamic = []
            self.routes_regex = []
            self.routes_group = {}
            self.name_index = {}
            self.dynamic_routes = {}
            self.static_routes

# Generated at 2022-06-24 04:43:48.352038
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.exceptions import SanicException

# Generated at 2022-06-24 04:43:59.340049
# Unit test for method add of class Router
def test_Router_add():
    '''
    Test the add method of class Router
    '''
    router = Router()
    assert len(router.routes_all) == 0
    router.add('/', ['GET', 'POST'], lambda *args, **kwargs: "")
    assert len(router.routes_all) == 1
    router.add('/test/', ['GET'], lambda *args, **kwargs: "")
    assert len(router.routes_all) == 2
    router.add('/test/', ['GET'], lambda *args, **kwargs: "")
    assert len(router.routes_all) == 3
    router.add('/te<string:val>/', ['GET'], lambda *args, **kwargs: "")

# Generated at 2022-06-24 04:44:00.953005
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router
    assert isinstance(router, Router)


# Generated at 2022-06-24 04:44:02.386599
# Unit test for constructor of class Router
def test_Router():
    test_router = Router()
    assert isinstance(test_router, Router)



# Generated at 2022-06-24 04:44:06.604269
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Test route with labels which starts with __
    router_instance = Router()
    class Route():
        def __init__(self):
            self.labels = ["__foo"]
    router_instance.dynamic_routes = {"foo":Route()}

    try:
        router_instance.finalize()
        assert False, "The above line should raise SanicException"
    except SanicException:
        pass

# Generated at 2022-06-24 04:44:17.305524
# Unit test for method add of class Router
def test_Router_add():
    import inspect
    import sys
    import unittest
    from sanic.router import Router
    from sanic.exceptions import InvalidUsage

    def func0():
        pass

    def func1(request):
        pass

    def func2(request, a: str):
        pass

    def func3(request, a: str, b: str):
        pass

    def func4(request, a: str = None):
        pass

    def func5(request, a: str = None, b: str = None):
        pass

    def func6(request, a: str = None, b: str = None, c: str = None):
        pass

    def func7(request, a: str = None, b: str = None, c: str = None, d: str = None):
        pass

    router = Router()



# Generated at 2022-06-24 04:44:28.562426
# Unit test for method add of class Router
def test_Router_add():
    # Initialize objects
    router = Router()
    uri = "/test"
    methods = ["GET", "OPTIONS", "POST"]
    def handler(request):
        return request
    host = "sanic.com"
    strict_slashes = False
    stream = False
    ignore_body = True
    version = "v0.1"
    name = "test_add_route"

    # Check if adding a route works as expected
    route = router.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name)
    assert route.ctx.hosts == [host]
    assert route.ctx.ignore_body == ignore_body
    assert route.ctx.name == name
    assert route.ctx.strict_slashes == strict_slashes

# Generated at 2022-06-24 04:44:30.723142
# Unit test for constructor of class Router
def test_Router():
    test_Router = Router(None)
    assert test_Router.DEFAULT_METHOD == "GET"
    assert test_Router.ALLOWED_METHODS == HTTP_METHODS

# Generated at 2022-06-24 04:44:38.786935
# Unit test for constructor of class Router
def test_Router():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.response import json

    app = Sanic("test_Router")

    async def test_handler(request: Request) -> HTTPResponse:
        return json("Hello")

    app.add_route(test_handler, "/test_handler")

    @app.middleware("request")
    async def test_middleware(request: Request) -> None:
        print("request middleware")

    @app.middleware("response")
    async def test_middleware(request: Request, response: HTTPResponse) -> None:
        print("response middleware")


# Generated at 2022-06-24 04:44:46.498089
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.app import Sanic
    routes = [("/", None), ("/", None)]
    # if routes[0][0] == routes[1][0]:
        # raise SanicException("Route already exists '{}'".format(routes[0][0]))

    # create new router(customized)
    router = Router(Sanic("test"))
    # add routes to the router(customized)
    index=0
    while index < len(routes):
        label = {}
        if len(routes[index]) >= 5:
            label['j'] = "2"
        if len(routes[index]) >= 6:
            label["k"] = "3"
        if len(routes[index]) >= 7:
            label["t"] = "4"

# Generated at 2022-06-24 04:44:48.623328
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-24 04:44:49.161183
# Unit test for method add of class Router
def test_Router_add():
    pass

# Generated at 2022-06-24 04:44:55.533889
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        router = Router()
        router.add('/hello', ['GET'], None, static=True)
        router.finalize()

        router.add('/hello/{test}', ['GET'], None, static=True)
        router.finalize()
    except SanicException as e:
        assert e.args[0] == "Invalid route: /hello/{test}. Parameter names cannot use '__'."

# Generated at 2022-06-24 04:45:06.100751
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.constants import HTTP_METHODS
    from sanic.models.handler_types import RouteHandler

    from sanic import Sanic
    from sanic.router import Router
    from sanic.group import Group
    from sanic.constants import HTTP_METHODS
    from typing import Callable, Any
    from unittest.mock import Mock
    from sanic.exceptions import SanicException

    app = Sanic('test_Router_finalize')
    router = Router(app, False)

    method_routes = []
    allowed_methods = HTTP_METHODS

# Generated at 2022-06-24 04:45:15.634372
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    r.dynamic_routes = {
        "": Route(
            "",
            "",
            "GET",
            handler=None,
            host=None,
            strict_slashes=False,
            unquote=False,
            ctx={},
            name=None,
            static=False,
            requirements={},
            labels={},
        )
    }
    try:
        r.finalize()
    except SanicException as e:
        assert str(e) == "Invalid route: {}. Parameter names cannot use '__'."
