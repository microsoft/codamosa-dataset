

# Generated at 2022-06-24 04:35:08.228618
# Unit test for method add of class Router
def test_Router_add():
    from sanic.router import Router
    from sanic.response import json
    from sanic.models.handler_types import RouteHandler

    testRouter = Router(
        host=None,
        strict_slashes=False,
        stream=False,
        unquote=False,
        version=None
    )
    uri = "/"
    methods = ("GET",)
    handler = lambda x: json({"hello": "world"})
    uri2 = "/hello"
    methods2 = ("GET", "POST")
    host2 = "test"

    # Test add parameter
    assert isinstance(testRouter.add(uri, methods, handler), Route)

    # Test add parameter with uri2
    assert isinstance(testRouter.add(uri2, methods, handler), Route)

    # Test add parameter with

# Generated at 2022-06-24 04:35:09.315107
# Unit test for constructor of class Router
def test_Router():
    assert Router()

# Generated at 2022-06-24 04:35:14.284496
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)
    assert router.DEFAULT_METHOD == 'GET'
    assert router.ALLOWED_METHODS == ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS', 'HEAD']
    assert router.DYNAMIC_ROUTE == Route


# Generated at 2022-06-24 04:35:17.601975
# Unit test for method add of class Router
def test_Router_add():
    # Create router
    router = Router()
    # Create endpoint
    test_endpoint = lambda x: x

    # Add route to router
    router.add('<url>', ['GET'], test_endpoint)

    assert len(router.routes_dynamic) == 1

# Generated at 2022-06-24 04:35:28.546195
# Unit test for method add of class Router
def test_Router_add():
    import pytest
    from sanic_routing.route import Route
    from sanic_routing.router import Router
    from sanic.exceptions import RouteExists

    # Valid cases
    router = Router()
    item1 = router.add(uri='/', methods=['GET'], handler='handler', host=None, 
        strict_slashes=False, stream=False, ignore_body=False, version=None, 
        name=None, unquote=False, static=False)
    assert isinstance(item1, Route)

    # item2 = router.add(uri='/', methods=['GET'], handler='handler', host=None, 
    #     strict_slashes=False, stream=False, ignore_body=False, version=None, 
    #     name=None, unquote=False, static

# Generated at 2022-06-24 04:35:30.716076
# Unit test for constructor of class Router
def test_Router():
    my_router = Router()
    assert isinstance(my_router, Router)


# Generated at 2022-06-24 04:35:38.283782
# Unit test for method finalize of class Router
def test_Router_finalize():
    route = Route(name="to_be_continue")
    route.labels.update({"__file_uri__": "route", "__config_path__": "abc"})
    router = Router()
    router.dynamic_routes.update({"name": route})
    router.finalize()


# Generated at 2022-06-24 04:35:45.533796
# Unit test for method add of class Router
def test_Router_add():
    router=Router()
    assert test_paths_to_methods==router.get('/about/', 'GET', '127.0.0.1:8000')
    for i in test_paths_to_methods:
        router.add(uri=i,methods=i, handler=i,host=i,strict_slashes=i,stream=i,ignore_body=i,version=i,name=i,static=i)


# Generated at 2022-06-24 04:35:51.371100
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == []
    assert router.routes_regex == []



# Generated at 2022-06-24 04:35:57.250842
# Unit test for method finalize of class Router
def test_Router_finalize():

    route = Route(path="/foo/<var>", handler=callable)
    route.labels.add("__file_uri__")
    router = Router(ctx=None, routes=[route])

    assert router.finalize() is None

    route2 = Route(path="/foo/<var>/<var2>", handler=callable)
    route2.labels.add("__file_uri__")
    router = Router(ctx=None, routes=[route2])

    with pytest.raises(Exception):
        router.finalize()

# Generated at 2022-06-24 04:36:03.999967
# Unit test for method finalize of class Router
def test_Router_finalize():
    app = Application()

    @app.route('/test')
    def handler(request):
        pass

    # Test of the route is executed without error
    app.router.finalize()
    assert not hasattr(app.router, '_finalized')

# Test for forbidden characters in route label

# Generated at 2022-06-24 04:36:09.778299
# Unit test for constructor of class Router
def test_Router():
    # the constructor is indirectly called via the 'add' method
    # therefore a test of the constructor is not needed
    router = Router()
    router.add(
        uri="/test",
        methods=["GET", "POST"],
        handler=lambda x,y : x + y,
        host="localhost",
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version="1.0",
        name="testRoute",
        unquote=False,
        static=False,
    )
    route = router.routes_all[0]
    assert route.path == "/test"

# Generated at 2022-06-24 04:36:19.680701
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    uri = 'path'
    methods = ['GET']
    handler = 'handler'
    host = 'localhost'
    strict_slashes = False
    stream = True
    ignore_body = True
    version = '2.0'
    name = 'name'
    unquote = True
    static = False
    result = router.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)
    assert result.path == 'path'
    assert result.hosts == ['localhost']
    assert result.ctx.ignore_body == True
    assert result.ctx.stream == True
    assert result.ctx.hosts == ['localhost']
    assert result.ctx.static == False
    assert result.ctx.version == '2.0'
   

# Generated at 2022-06-24 04:36:23.365749
# Unit test for method add of class Router
def test_Router_add():
    route = Router()


if __name__ == "__main__":
    test_Router_add()

# Generated at 2022-06-24 04:36:35.089923
# Unit test for method add of class Router
def test_Router_add():
    router = Router()

    assert len(router.routes_all) == 0
    assert len(router.routes_static) == 0
    assert len(router.routes_dynamic) == 0
    assert len(router.routes_regex) == 0

    def handler():
        pass

    router.add(uri='/test/', methods=[], handler=handler)

    assert len(router.routes_all) == 1
    assert len(router.routes_static) == 1
    assert len(router.routes_dynamic) == 0
    assert len(router.routes_regex) == 0

    router.add(uri='/test/<arg>', methods=[], handler=handler)


# Generated at 2022-06-24 04:36:44.308496
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    route = router.add("/url/<name>", ["GET", "POST"], handler="handler")
    assert isinstance(route, Route)
    assert route.uri_template == "{}/url/<name>".format("v")
    assert route.uri == "/url/<name>"
    assert route.methods == ["GET", "POST"]
    assert route.name == None
    assert route.strict == False
    assert route.unquote == False
    assert route.ctx.ignore_body == False
    assert route.ctx.stream == False
    assert route.ctx.hosts == [None]
    assert route.ctx.static == False


# Generated at 2022-06-24 04:36:48.939930
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    with pytest.raises(SanicException) as exc_info:
        router.finalize()
    assert "Invalid route" in exc_info.value.args[0]

# Generated at 2022-06-24 04:36:54.998623
# Unit test for method add of class Router
def test_Router_add():
    import sanic.route
    @sanic.route.get("/home/<username>")
    def test(request, username):
        return sanic.response.json({"hello": username})
    r = Router()
    r.add("/test/<username>", ["GET"], test)
    r1 = r.routes[0]
    assert r1.name is not None
    assert r1.uri == "/home/<username>"
    assert r1.methods == ["GET"]
    assert r1.handler is test
    assert r.ctx == {"app": None, "router": r}
    assert r1.ctx.get("ignore_body") is False
    assert r1.ctx.get("stream") is False


# Generated at 2022-06-24 04:37:03.880185
# Unit test for method add of class Router
def test_Router_add():
    uri = "uri"
    methods = ["method1","method2","method3"]
    async def handler():
        pass
    host = "host1"
    strict_slashes = False
    stream = False
    ignore_body = False
    version = "1.0"
    name = "name"
    unquote = False

    router = Router(None)
    routes = router.add(uri,methods,handler,host,strict_slashes,stream,ignore_body,version,name,unquote)
    assert routes is not None

# Generated at 2022-06-24 04:37:14.114755
# Unit test for method finalize of class Router
def test_Router_finalize():
    def view_func(*args, **kwargs):
        print(args, kwargs)
    test_router = Router()
    test_route = Route()
    test_route.handler = view_func
    test_route.labels = ['__file_uri__']
    test_router.dynamic_routes[1] = test_route
    test_route.labels = ['__file__']
    test_router.dynamic_routes[2] = test_route
    try:
        test_router.finalize()
    except Exception as err:
        print(err)
        print('Pass finalize test.')
    else:
        print('Fail finalize test.')

if __name__ == '__main__':
    test_Router_finalize()

# Generated at 2022-06-24 04:37:21.677768
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Route, RouteGroup, Router
    import pytest

    ROUTER = Router(default_klass=Route)
    ROUTER.add(path="/", method="GET", handler=print)

    # Test with correct parameters
    ROUTER.finalize(None)

    ROUTER_GROUP = Router(default_klass=RouteGroup)
    ROUTER_GROUP.add(path="/", method="GET", handler=print)

    ROUTER_GROUP.finalize(None)

    # Test with incorrect parameters
    ROUTER_DYNAMIC = Router(default_klass=Route)
    ROUTER_DYNAMIC.add(path="/:test1/:test2", method="GET", handler=print)

    with pytest.raises(SanicException):
        ROUTER

# Generated at 2022-06-24 04:37:23.991990
# Unit test for constructor of class Router
def test_Router():
    '''
    Test the constructor of class Router
    '''
    router = Router()
    assert router != None and router != ''


# Generated at 2022-06-24 04:37:29.868728
# Unit test for method finalize of class Router
def test_Router_finalize():

    from sanic.router import Router

    router=Router()
    for arg in (1,2,'a', 'b'):
        router.add(arg, arg, arg)
    try:
        router.finalize()
    except:
        assert True
    else:
        assert False
if __name__ == '__main__':
    test_Router_finalize()

# Generated at 2022-06-24 04:37:33.005780
# Unit test for method add of class Router
def test_Router_add():
    from sanic import Sanic
    app = Sanic('test')
    r = Router(app)
    route = r.add('/path',['GET'],app)
    assert isinstance(route,Route)


# Generated at 2022-06-24 04:37:36.349963
# Unit test for method add of class Router
def test_Router_add():
    test_router = Router()
    test_handler = object() # Some object
    assert test_router.add(uri = "uri", methods = ["GET"], handler = test_handler) == test_router.get("uri", "GET", None)


# Generated at 2022-06-24 04:37:45.604310
# Unit test for method add of class Router
def test_Router_add():
    import sanic
    app = sanic.Sanic()
    url = 'sanic.co'
    def handler():
        pass
    router = Router()
    res = router.add(uri=url,methods=[],handler=handler,host=None,strict_slashes=False,stream=False,ignore_body=False,version=None,name=None,unquote=False,static=False)
    expected = '<Route GET /sanic.co handler:<function handler at 0x000001EA0F1A7AF8>>'
    assert str(res) == expected


# Generated at 2022-06-24 04:37:53.352487
# Unit test for method add of class Router
def test_Router_add():
    """test method add of class Router"""
    # Test add(self, uri, methods, handler, host=None, strict_slashes=False, stream=False, ignore_body=False, version=None, name=None)
    _router = Router()
    _uri = ''
    _methods = HTTP_METHODS
    _handler = None
    _strict_slashes = False
    _stream = False
    _ignore_body = False
    _version = None
    _name = None
    _name = None
    _ret = None

# Generated at 2022-06-24 04:38:05.217437
# Unit test for method add of class Router
def test_Router_add():
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import CompositionView
    router = Router()
    # noinspection PyMethodMayBeStatic
    async def handler_func(request, *args, **kwargs):
        return await HTTPResponse('OK')
    class HandlerClass:
        async def get(self, request):
            return await HTTPResponse('OK')
    class MyView(CompositionView):
        async def get(self, request):
            return await HTTPResponse('OK')
    class MyOtherView(CompositionView):
        async def get(self, request):
            return await HTTPResponse('OK')
    view = MyView(MyOtherView)

# Generated at 2022-06-24 04:38:14.097756
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    with raises(SanicException) as result:
        router.finalize()
    assert result.value.args[0] == "No routes specified"

    router = Router()
    router.dynamic_routes = {
        ('GET', ('/test/<file_name>',)): Route(
            ('GET', ('/test/<file_name>',)),
            None,
            None,
            None,
            None,
            None,
            None,
            static=False,
            labels={"file_name": "__file_uri__"},
        )
    }
    router.finalize()

# Generated at 2022-06-24 04:38:15.930266
# Unit test for method finalize of class Router
def test_Router_finalize():
    pass

# Generated at 2022-06-24 04:38:24.797894
# Unit test for method finalize of class Router
def test_Router_finalize():
    class MockApp:
        def _generate_name(self, *args):
            return 'test_ViewName'
    mockApp = MockApp()

    class MockCtx:
        app = mockApp
    mockCtx = MockCtx()

    class MockRoute:
        ctx = mockCtx
        labels = ['__foo__', '__bar__']

    mockRoute = MockRoute()
    mockRoutes = {'mockRoute': mockRoute}

    class MockRouter(Router):
        dynamic_routes = mockRoutes
        regex_routes = {}
        static_routes = {}
        routes = mockRoutes
    mockRouter = MockRouter()

    mockRouter.finalize()


# Generated at 2022-06-24 04:38:28.901229
# Unit test for method finalize of class Router
def test_Router_finalize():
    uri = "test_uri"
    method = "test_method"
    handler = "test_handler"
    name = "test_name"
    r = Router()
    r.add(uri=uri, methods=[method], handler=handler, name=name)
    result = r.finalize()
    assert result == (uri, {method: (handler, None)}, name)



# Generated at 2022-06-24 04:38:36.976984
# Unit test for method add of class Router
def test_Router_add():
    """
    unit test for method add of class Router
    """
    app = mock.MagicMock()
    router = Router(app, name='some name')

    uri = "some uri"
    methods = ["GET", "POST", "OPTIONS"]
    handler = mock.MagicMock()
    handler.__name__ = 'handler'
    host = "some host"
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = "some name"
    unquote = False
    static = False

    assert isinstance(router, Router)

    router.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)

    # assert len(app.routes) == 1
    # assert

# Generated at 2022-06-24 04:38:44.554493
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.route_decorator import RouteDecorator

    class TestDecorator(RouteDecorator):
        def __init__(self, *args, **kwargs):
            self._label = "__" + kwargs["label"] + "__"
            super().__init__(*args, **kwargs)

        def __call__(self, *args, **kwargs):
            uri = self._label + kwargs["uri"]
            del kwargs["uri"]
            return super().__call__(uri, *args, **kwargs)

    router = Router()

    @TestDecorator(label="test")
    @router.route("/", methods=["GET"])
    def test(request, *args, **kwargs):
        pass

# Generated at 2022-06-24 04:38:54.609815
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    uri = "/test"
    methods = ["GET","POST","OPTIONS"]
    handler = RouteHandler
    host = None
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = None
    unquote = False
    static = False

    result = router.add(uri,methods,handler,host,strict_slashes,stream,ignore_body,version,name)
    assert result.ctx.ignore_body == ignore_body
    assert result.ctx.stream == stream
    assert result.ctx.hosts == [None]
    assert result.ctx.static == static


# Generated at 2022-06-24 04:39:06.239321
# Unit test for method finalize of class Router
def test_Router_finalize():
    dyn_router = Router()
    dyn_router.add("/<id>", ["GET"], lambda *args: True)
    dyn_router.finalize()
    assert dyn_router.dynamic_routes.values()[0].labels == {'id'}
    dyn_router.add("/<__id>", ["GET"], lambda *args: True)
    try:
        dyn_router.finalize()
        assert False
    except SanicException:
        assert True
    dyn_router.add("/<__file_uri__>", ["GET"], lambda *args: True)
    try:
        dyn_router.finalize()
        assert True
    except SanicException:
        assert False
    assert dyn_router.dynamic_routes.values()[1].lab

# Generated at 2022-06-24 04:39:08.877443
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert(router.DEFAULT_METHOD=="GET")
    assert(router.ALLOWED_METHODS==HTTP_METHODS)


# Generated at 2022-06-24 04:39:11.183245
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add("/", HTTP_METHODS, lambda: "testing", None)
    assert router.routes_all



# Generated at 2022-06-24 04:39:12.932644
# Unit test for constructor of class Router
def test_Router():
    assert issubclass(Router, BaseRouter)


# Generated at 2022-06-24 04:39:21.552990
# Unit test for method add of class Router
def test_Router_add():
    route = Router().add(
        uri="1",
        methods=["GET", "POST", "OPTIONS"],
        handler=lambda x: x,
        host=None,
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version=None,
        name=None,
        unquote=False,
        static=False,
    )

    str_representation = "<sanic.router.Route(uri='1', method=None, handler=<lambda>)"
    assert str(route) == str_representation

# Generated at 2022-06-24 04:39:31.276760
# Unit test for method add of class Router
def test_Router_add():
    @add_route_metadata
    def test_handler(request,**kwargs):
        return {}

    test_router = Router(app=None)
    test_route = test_router.add(uri='/test',methods=['GET'],handler=test_handler)
    assert test_route.ctx.hosts == [None]

    assert test_route.ctx.ignore_body == False
    assert test_route.ctx.stream == False
    assert test_route.ctx.static == False

    test_route_1 = test_router.add(uri='/test',methods=['GET'],handler=test_handler,ignore_body=True)
    assert test_route_1.ctx.ignore_body == True
    assert test_route_1.ctx.stream == False

# Generated at 2022-06-24 04:39:42.850279
# Unit test for method add of class Router
def test_Router_add():

    def handler():
        pass

    testRouter = Router()
    testRouter.add('testUri', ['GET', 'POST'], handler, None)
    assert testRouter.routes_dynamic == {'testUri': 'testUri'}

    testRouter.add('testUri', ['GET', 'POST'], handler, None, True)
    assert testRouter.routes_dynamic == {'testUri': 'testUri'}

    testRouter.add('testUri', ['GET'], handler, None, True, True, True)
    assert testRouter.routes_dynamic == {'testUri': 'testUri'}

    testRouter.add('testUri', ['GET'], handler, None, True, True, True, 1)
    assert test

# Generated at 2022-06-24 04:39:49.716895
# Unit test for method add of class Router
def test_Router_add():
    from sanic.server import Sanic
    from sanic.models.handler_types import RouteHandler, Request

    sanic_app=Sanic()
    sanic_app.config.KEEP_ALIVE=False
    sanic_app.config.REQUEST_MAX_SIZE=104857600
    sanic_app.config.REQUEST_TIMEOUT=7

    uri = "uri"
    methods = ["GET"]
    def handler(request: Request):
        pass
    host = None
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = None
    unquote = False
    static = False
    
    router = Router(sanic_app)

# Generated at 2022-06-24 04:39:53.470241
# Unit test for constructor of class Router
def test_Router():
    # test whether the two attributes of Router will be set correctly
    routes = {}
    name_index = {}
    router = Router(routes, name_index)
    assert router.routes == routes
    assert router.name_index == name_index


# Generated at 2022-06-24 04:39:58.087402
# Unit test for method finalize of class Router
def test_Router_finalize():
    a_router = Router()
    with pytest.raises(SanicException):
        a_router.add("/a")("a")
        a_router.finalize()



# Generated at 2022-06-24 04:40:02.388529
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    from sanic.router import Router
    
    app = Sanic()
    
    @app.route('/')
    def handler(request):
        return text('OK')

    with app.test_request_context(path='/'):
        for route in app.router.routes_all.values():
            route.finalize()

        for r in app.router.routes_all.values():
            assert isinstance(r, Route)    
    

# Generated at 2022-06-24 04:40:09.398669
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        r = Router()
        r.add('/<__file_uri__:path>', ["GET"], RouteHandler())
    except:
        raise AssertionError('Unit test for method finalize of class Router failed')
    


# Generated at 2022-06-24 04:40:16.377969
# Unit test for method add of class Router
def test_Router_add():
    from sanic_routing import Router
    from sanic.response import json
    # Initialization
    router = Router()
    uri = '''/kasim'''
    methods = ['GET']
    host = '''localhost'''
    handler = json('''{"Hello":"World"}''', status=200)
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = None
    unquote = False
    static = False
    # Call the method to test
    route = router.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)
    # Check if the assertion is successful
    print('''Test for add method of class Router is successful.''')


# Generated at 2022-06-24 04:40:22.571838
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add(
        uri='/',
        methods=['GET', 'POST'],
        handler='handler',
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version=None,
        name=None,
        unquote=False,
        static=False,
        host=None
    )


# Generated at 2022-06-24 04:40:31.486398
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router  # noqa
    from sanic.utils import sanic_endpoint_test

    app = sanic_endpoint_test.Sanic("test_router")
    router = Router()

    # No route param uses `__`
    router.add(uri="foo/bar/<name>",methods=["GET"],handler=None)
    router.finalize()

    # One route param uses `__`
    with pytest.raises(SanicException):
        router.add(uri="foo/bar/<__name>",methods=["GET"],handler=None)
        router.finalize()

    # Multiple route params uses `__`

# Generated at 2022-06-24 04:40:32.509017
# Unit test for constructor of class Router
def test_Router():
    print("test_Router")
    assert Router()

# Generated at 2022-06-24 04:40:33.379094
# Unit test for method add of class Router
def test_Router_add():
    pass


# Generated at 2022-06-24 04:40:36.744722
# Unit test for constructor of class Router
def test_Router():
    pass

# Generated at 2022-06-24 04:40:37.631418
# Unit test for constructor of class Router
def test_Router():
    Router()


# Generated at 2022-06-24 04:40:38.104691
# Unit test for method finalize of class Router
def test_Router_finalize():
    pass



# Generated at 2022-06-24 04:40:41.228584
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        Router.finalize(Router)
    except Exception as e:
        assert False, "Router.finalize(Router) raises Exception: %s %s" % (e, type(e))
    assert True, "Router.finalize(Router) does not raise"

# Generated at 2022-06-24 04:40:48.970190
# Unit test for method add of class Router
def test_Router_add():
    # Method add of class Router

    def handler():
        pass


# Generated at 2022-06-24 04:40:50.690788
# Unit test for method finalize of class Router
def test_Router_finalize():
  a = Router()
  assert a.finalize() == ()

# Generated at 2022-06-24 04:41:00.641895
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    router = Router()
    with pytest.raises(SanicException) as exception:
        router.finalize()
    assert str(exception.value) == "Invalid route: /. Parameter names cannot use '__'."
    router = Router()
    router.add(uri='/', methods=("POST",), handler=lambda: None)
    with pytest.raises(SanicException) as exception:
        router.finalize()
    assert str(exception.value) == "Invalid route: /. Parameter names cannot use '__'."
    router = Router()
    router.add(uri='/<__file_uri__>', methods=("POST",), handler=lambda: None)
    router.finalize()

# Generated at 2022-06-24 04:41:01.218478
# Unit test for method finalize of class Router
def test_Router_finalize():
    pass



# Generated at 2022-06-24 04:41:10.407716
# Unit test for constructor of class Router
def test_Router():
    # Mock false methods to prevent fetching data from memory
    # when instantiating
    def set_http_methods(self):
        pass
    def add_http_method(self, method, handler):
        pass
    def add_route(self, route):
        pass
    def add_websocket_route(self, route):
        pass
    def add_error_handler(self, exception, handler):
        pass
    def update_names(self):
        pass

    # Instantiate Router class
    router = Router(None,
                    None,
                    set_http_methods,
                    add_http_method,
                    add_route,
                    add_websocket_route,
                    add_error_handler,
                    update_names)

    assert(router.ctx == None)

# Generated at 2022-06-24 04:41:17.335375
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    from sanic import Blueprint

    app = Sanic()
    bp = Blueprint("test_finalize_blueprint", url_prefix="/test_finalize_blueprint")

    @bp.route("/test_route_a", name="test_route_a")
    async def handler_a(request):
        return

    @bp.route("/test_route_b/<parameter_name_b>", name="test_route_b")
    async def handler_b(request):
        return

    app.blueprint(bp)

    assert app.router.find_route_by_view_name("test_route_a")

# Generated at 2022-06-24 04:41:20.493666
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert(isinstance(router, Router))



# Generated at 2022-06-24 04:41:27.255450
# Unit test for method add of class Router
def test_Router_add():
    import os
    import sys

    file_path = os.path.abspath(__file__)
    test_directory = os.path.dirname(file_path)
    localpath = os.path.dirname(test_directory)
    sys.path.insert(0, localpath)

    from sanic.router import Router
    from sanic.request import Request
    import sanic

    app = sanic.Sanic()
    router = Router(app)

    @app.route("/")
    async def home(request):
        return sanic.response.text("home")

    @app.route("/1/")
    async def home1(request):
        return sanic.response.text("home1")


# Generated at 2022-06-24 04:41:37.082152
# Unit test for method add of class Router
def test_Router_add():
    from sanic.app import Sanic
    remove_one_item_from_list = lambda l: l if len(l) == 0 else l[1:]

    def handler():
        return "handler"

    def test_no_param():
        router = Router()
        assert len(router.routes_all) == 0
        router_old = router
        route = router.add("/", ["GET"], handler)
        assert len(router.routes_all) == 1
        assert len(router.routes_static) == 1
        assert len(router.routes_dynamic) == 0
        assert len(router.routes_regex) == 0
        assert router == router_old
        assert route.ctx.hosts == [None]

    def test_methods():
        router

# Generated at 2022-06-24 04:41:42.569029
# Unit test for method finalize of class Router
def test_Router_finalize():
    class DummyRouter(Router):
        def __init__(self, label_set):
            super().__init__()
            self.label_set = label_set

    router = DummyRouter(label_set={"__a__b__", "__file_uri__"})
    router.finalize()

# Generated at 2022-06-24 04:41:49.281141
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.app import Sanic

    app = Sanic()

    # Generate an invalid route
    def handler():
        pass

    app.route('/path/<__invalid_param:string>', methods=['GET'])(handler)

    router = Router(app)

    # The following line should raise a SanicException
    router.finalize()
    assert False

# Generated at 2022-06-24 04:41:54.267238
# Unit test for method finalize of class Router
def test_Router_finalize():
    instance = Router()
    route = Route(
        instance.ctx,
        path="/",
        methods=["GET"],
        handler=lambda x: None,
        name=None,
        strict=False,
        unquote=False,
    )
    route.labels = ["__foo__"]
    instance.add_route(route)
    with pytest.raises(SanicException):
        instance.finalize()

# Generated at 2022-06-24 04:41:57.209783
# Unit test for constructor of class Router
def test_Router():
    router = Router()

    assert router.routes_all == {}
    assert router.dynamic_routes == defaultdict(dict)
    assert router.static_routes == defaultdict(dict)
    assert router.regex_routes == defaultdict(dict)

# Generated at 2022-06-24 04:41:59.629335
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)

# Generated at 2022-06-24 04:42:05.877184
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()

    # when
    with pytest.raises(SanicException):
        r.add_parser([], "/path/<__file_uri__>", None)
    with pytest.raises(SanicException):
        r.add_parser([], "/path/<__my_uri__>", None)
    r.add_parser([], "/path/<__file_uri__>", None)

# Generated at 2022-06-24 04:42:09.009669
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    assert router.finalize() == None

# Generated at 2022-06-24 04:42:19.989250
# Unit test for method add of class Router
def test_Router_add():
    from sanic.app import Sanic
    from sanic.response import text

    router = Router()
    app = Sanic()
    app.blueprint(router)

    def handler():
        return text('Test Router add')

    route = router.add('/add', 'GET', handler)
    assert isinstance(route, Route)
    assert route.path == '/add'
    assert route.methods == 'GET'
    assert route.handler == handler
    assert route.ctx.ignore_body == False
    assert route.ctx.stream == False
    assert route.ctx.hosts == [None]
    assert route.ctx.static == False

    route = router.add('/add', 'POST', handler, strict_slashes=True,
                       stream=True, ignore_body=True, version="v1", name='add')

# Generated at 2022-06-24 04:42:21.555444
# Unit test for constructor of class Router
def test_Router():
    router = Router()

# Generated at 2022-06-24 04:42:22.991586
# Unit test for constructor of class Router
def test_Router():
    # Check if the class is initialized without errors
    assert Router()

# Generated at 2022-06-24 04:42:32.239439
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    app = Sanic(__name__)
    router = Router()

    # Test for valid input
    def handler1():
        pass
    path = "/test/<__file_uri__>"
    router.add(path, ["GET", "POST"], handler1)
    router.finalize(app, "")
    assert len(router.routes_all) == 1
    assert len(router.routes_static) == 0
    assert len(router.routes_dynamic) == 1
    assert router.routes_all[0].labels == ["__file_uri__"]
    assert router.routes_dynamic[0].labels == ["__file_uri__"]

    # Test for invalid input
    def handler2():
        pass

# Generated at 2022-06-24 04:42:40.657908
# Unit test for constructor of class Router
def test_Router():
    # test for init
    router = Router()

    # test for init
    router = Router(prefix="a")

    # test for init
    router = Router(prefix="a", suffix="b")

    # test for init
    router = Router(
        prefix="a",
        suffix="b",
        host_matching=True,
        host="a",
        default_subdomain="b",
    )

    # test for init
    router = Router(
        prefix="a",
        suffix="b",
        host_matching=True,
        host="a",
        default_subdomain="b",
        strict_slashes=True,
    )

    # test for init

# Generated at 2022-06-24 04:42:41.631420
# Unit test for method add of class Router
def test_Router_add():
    pass


# Generated at 2022-06-24 04:42:50.019243
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic

    from sanic.app import App
    from sanic.server import HttpProtocol
    from sanic.testing import SanicTestClient

    assert Router.finalize.__name__ == 'finalize'

    app = Sanic("sanic-test_Router_finalize")
    test_client = SanicTestClient(app)

    @app.route("/")
    def handler(request):
        return text("OK")

    request, response = test_client.get("/")

    assert request
    assert response
    assert response.text == "OK"

# Generated at 2022-06-24 04:42:51.122859
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)

# Generated at 2022-06-24 04:42:52.547049
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    with pytest.raises(SanicException):
        r.finalize()

# Generated at 2022-06-24 04:42:59.463096
# Unit test for method add of class Router
def test_Router_add():
    '''
    Test add() method with following params
    1. uri: str
    2. method: Iterable[str]
    3. handler: RouteHandler
    4. host: Optional[Union[str, Iterable[str]]] = None
    5. strict_slashes: bool = False
    6. stream: bool = False
    7. ignore_body: bool = False
    8. version: Union[str, float, int] = None
    9. name: Optional[str] = None
    10. unquote: bool = False
    '''
    test_class = Router()
    test_class.add('uri', ['GET', 'POST', 'OPTIONS'], 'handler', 'host', False, False, False, 1, 'name', False)



# Generated at 2022-06-24 04:43:10.393091
# Unit test for method add of class Router
def test_Router_add():
    # test 1
    router = Router()
    uri = 'test'
    methods = ['GET','POST','OPTIONS']
    # def handler(request, *args, **kwargs):
    #   pass
    # handler = test_handler
    handler = 'test'
    host = 'localhost'
    strict_slashes = True
    stream = False
    ignore_body = True
    version = '1.0'
    name = 'test_add'
    unquote = False
    static = False
    result = router.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)
    # test assertions
    assert result is not None
    assert result.__class__.__name__ == 'Route'


# Generated at 2022-06-24 04:43:20.705830
# Unit test for method add of class Router
def test_Router_add():
    from unittest.mock import MagicMock
    from unittest.mock import patch
    class Router():
        def __init__(self):
            self.routes = []
        def _add(self, method, uri, handler,
                host=None,
                strict_slashes=False,
                stream=False,
                ignore_body=False,
                version=None,
                name=None,
                unquote=False,
                static=False):
            self.routes.append((method, uri, handler,
                host,
                strict_slashes,
                stream,
                ignore_body,
                version,
                name,
                unquote,
                static))
        @staticmethod
        def _get_method(method):
            assert isinstance(method, str)
            return method

# Generated at 2022-06-24 04:43:27.853233
# Unit test for constructor of class Router
def test_Router():
    def testViewFunc():
        return 'test'

    testRouter = Router()
    testRouter.add('/test', ['GET', 'POST'], testViewFunc, stream=True)
    assert len(testRouter.all_routes()) > 0
    assert testRouter.has('/test', ['GET', 'POST']) == True
    assert testRouter.has('/test', ['DELETE']) == False
    assert testRouter.has('/test2') == False


# Generated at 2022-06-24 04:43:36.796974
# Unit test for method add of class Router
def test_Router_add():
    from . import app_test, request_test
    from .handler_test import handler_function_test
    from sanic.response import html_response
    from unittest.mock import Mock

    router = app_test.router

    @router.add("/<name>/")
    def handler(request, name):
        return html_response("")

    assert router._get("/John/", "GET", None) == (
        router.routes_dynamic["GET"].get("/John/"),
        handler,
        {"name": "John"},
    )

    assert router._get("/John/", "GET", None) == (
        router.routes_dynamic["GET"].get("/John/"),
        handler,
        {"name": "John"},
    )


# Generated at 2022-06-24 04:43:48.114867
# Unit test for method add of class Router
def test_Router_add():
    from .utils import MockRequest

    def generate_route_handler(response):
        async def handler(request):
            return response

        return handler

    server_name = "localhost"
    base_uri = "/"
    add_method = HTTP_METHODS[0]
    special_route_method = "CONNECT"
    user_route_method = "OPTIONS"
    path = "test"
    special_path = "__test"
    add_uri = f"{base_uri}{path}"
    special_uri = f"{base_uri}{special_path}"
    stream = False
    ignore_body = False
    app = Sanic("test_Router_add")
    app.config.from_object("testconfig")
    router = Router()
    router.init_app(app)

# Generated at 2022-06-24 04:43:49.430729
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None

# Generated at 2022-06-24 04:43:59.719783
# Unit test for method add of class Router
def test_Router_add():
    # Our input:
    url = '/home'
    method = 'GET'
    handler = lambda x: x
    host = 'localhost:8080'
    strict_slashes = False
    stream = True
    ignore_body = True
    version = '1'
    name = 'test'
    unquote = True
    static = True
    router_instance = Router()
    result = router_instance.add(url, method, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)
    assert result.strict_slashes == strict_slashes
    assert result.stream == stream
    assert result.ctx.hosts == [host]
    assert result.ctx.static == static
    assert result.path == url
    assert result.handler == handler
    assert result.method == method


# Generated at 2022-06-24 04:44:04.711804
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    method = "GET"
    uri = "/hello"
    handler = "handler"
    host = "www.apache.org"
    strict_slashes = False
    stream = False
    ignore_body = False
    version = 1
    name = "hello"
    unquote = False
    static = False
    route = router.add(
        uri,
        method,
        handler,
        host,
        strict_slashes,
        stream,
        ignore_body,
        version,
        name,
        unquote,
        static
    )
    assert route.path == "/v1/hello"
    assert route.methods == {method}
    assert route.handler == handler
    assert route.ctx.ignore_body == ignore_body

# Generated at 2022-06-24 04:44:06.733649
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-24 04:44:11.555239
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route(router, "/test", None, None)
    route.labels = ["test", "__test"]
    router.dynamic_routes = {"test1": route}
    try:
        router.finalize()
    except Exception as error:
        assert str(error) == "Invalid route: /test. Parameter names cannot use '__'."

# Generated at 2022-06-24 04:44:12.643016
# Unit test for method add of class Router
def test_Router_add():
    assert True


# Generated at 2022-06-24 04:44:15.171032
# Unit test for method add of class Router
def test_Router_add():
    pass


# Generated at 2022-06-24 04:44:25.170549
# Unit test for constructor of class Router
def test_Router():
    # test for constructor
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert isinstance(router.routes, list)
    assert isinstance(router.routes_all, list)
    assert isinstance(router.routes_static, list)
    assert isinstance(router.routes_dynamic, list)
    assert isinstance(router.routes_regex, list)
    assert isinstance(router.static_routes, list)
    assert isinstance(router.dynamic_routes, list)
    assert isinstance(router.regex_routes, list)
    assert isinstance(router.name_index, dict)
    

# Unit

# Generated at 2022-06-24 04:44:36.937129
# Unit test for method add of class Router
def test_Router_add():
    router = Router("test_Router_add")

    TEST_ROUTE_1 = "/test/<var>"
    TEST_ROUTE_2 = "/test/<var1>/<var2>"
    TEST_HOST = "test.com"
    
    @router.add(TEST_ROUTE_1, "GET", "test")
    async def test1(request, var):
        pass
    
    @router.add(TEST_ROUTE_2, "GET", "test2")
    async def test2(request, var1, var2):
        pass    

    assert router.find_route_by_view_name("test") is not None, "route not found"
    assert router.find_route_by_view_name("test2") is not None, "route not found"

# Generated at 2022-06-24 04:44:39.858941
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r


# Generated at 2022-06-24 04:44:42.555379
# Unit test for method finalize of class Router
def test_Router_finalize():
    # create a router object
    router = Router()

    # create a route
    router.add(uri=r'/', methods=['GET'], handler=handler_dummy)

    # should not raise any exception
    router.finalize()



# Generated at 2022-06-24 04:44:44.356385
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)
    assert isinstance(router, BaseRouter)



# Generated at 2022-06-24 04:44:52.658776
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    assert router.routes_all == []
    def request_handler(request: Request) -> Response:
        return response.text("")
    router.add("/static/<str:name>", methods=["GET"], handler=request_handler)
    assert len(router.routes_all) == 1
    assert len(router.routes_static) == 0
    assert len(router.routes_dynamic) == 1
    assert len(router.routes_regex) == 0
    router.add("/static/path", methods=["GET"], handler=request_handler)
    assert len(router.routes_all) == 2
    assert len(router.routes_static) == 1

# Generated at 2022-06-24 04:45:02.409609
# Unit test for method add of class Router
def test_Router_add():
    router = Router()

    uri = "/test"
    methods = ("GET", "POST")
    handler = None
    strict_slashes = True
    stream = True
    ignore_body = True
    name = "uri_test"

    route = router.add(
        uri,
        methods,
        handler,
        strict_slashes=strict_slashes,
        stream=stream,
        ignore_body=ignore_body,
        name=name,
    )

    assert route.ctx.ignore_body == ignore_body
    assert route.ctx.stream == stream
    assert route.path == uri
    assert route.methods == methods
    assert route.strict == strict_slashes
    assert route.name == name
