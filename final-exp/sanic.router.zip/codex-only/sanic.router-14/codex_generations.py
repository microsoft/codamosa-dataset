

# Generated at 2022-06-24 04:35:10.624390
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    # Test that router has attribute 'routes' (dict)
    assert hasattr(router, 'routes')
    # Test that router has attribute 'static_routes' (dict)
    assert hasattr(router, 'static_routes')
    # Test that router has attribute 'dynamic_routes' (dict)
    assert hasattr(router, 'dynamic_routes')
    # Test that router has attribute 'regex_routes' (dict)
    assert hasattr(router, 'regex_routes')
    # Test that router has attribute 'ctx' (dict)
    assert hasattr(router, 'ctx')


# Generated at 2022-06-24 04:35:22.253562
# Unit test for method add of class Router
def test_Router_add():
    from sanic.router import Router
    from sanic.views import HTTPMethodView
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.exceptions import SanicException

    router = Router()
    assert router is not None

    class MyView(HTTPMethodView):
        def get(self, request):
            return HTTPResponse(status=200, body=u"abc")

    router.add(uri="/aa", methods=["get"], handler=MyView.as_view())
    assert len(router.routes_all) == 1

    router.add(uri="/bb", methods=["post"], handler=MyView.as_view())
    assert len(router.routes_all) == 2


# Generated at 2022-06-24 04:35:26.668863
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.handlers import ErrorHandler

    router = Router()
    router.add(r"/", "GET", ErrorHandler().response)
    try:
        router.finalize()
    except:
        assert False
    assert True

# Generated at 2022-06-24 04:35:30.454232
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    try:
        router.add("/path/<parameter>", ("GET", "POST"))
    except SanicException as e:
        assert str(e) == "Invalid route: Route(/path/<parameter>). Parameter names cannot use '__'."

    try:
        router.add("/path/<__file_uri__>", ("GET", "POST"))
    except:
        assert False, "router.add do not raise excpetion with allowed label"

# Generated at 2022-06-24 04:35:34.812019
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router(None)
    route = Route()
    route.labels.append("__file_uri__")
    router.dynamic_routes[1] = route
    try:
        router.finalize()
    except SanicException:
        pass
    route.labels.append("__file")
    try:
        router.finalize()
    except SanicException:
        pass



# Generated at 2022-06-24 04:35:45.528105
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.exceptions import SanicException

    router = Router()

    class DummyRoute:
        def __init__(self, labels=[]):
            self.labels = labels

    route1 = DummyRoute(labels=["__1__", "__2__", "__3__", "__4__"])
    route2 = DummyRoute(labels=["__1__", "__2__", "__3__", "__5__"])

    router.dynamic_routes["/uri1"] = route1
    router.dynamic_routes["/uri2"] = route2

    with pytest.raises(SanicException):
        router.finalize()

# Generated at 2022-06-24 04:35:53.593856
# Unit test for method add of class Router
def test_Router_add():
    pass
    # TODO: Implement unit tests
    # Example:
    #from sanic.router import Router
    #from sanic.request import Request
    #from sanic.response import HTTPResponse
    #from sanic.app import Sanic

    #app = Sanic(__name__)

    #@app.route('/')
    #async def handler(request):
    #    return HTTPResponse(body='OK')

    #request = Request(app, {}, '')
    #assert request.app == app



# Generated at 2022-06-24 04:35:55.663097
# Unit test for constructor of class Router
def test_Router():
    '''
    >>> router = Router()
    >>> router
    <sanic.router.Router object at 0x000002BECDC7B308>
    '''

# Generated at 2022-06-24 04:35:58.708555
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r.DEFAULT_METHOD == 'GET'
    assert r.ALLOWED_METHODS == ['OPTIONS', 'HEAD', 'GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'TRACE']



# Generated at 2022-06-24 04:36:00.939343
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    assert router.add is not None


# Generated at 2022-06-24 04:36:09.544627
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router

    class route:
        def __init__(self, **kwargs):
            self.labels = kwargs["labels"]

    router = Router()
    router.dynamic_routes = {}
    route1 = route(labels=["__file_uri__", "__invalid_file_uri__"])
    route2 = route(labels=["__invalid_file_uri__"])
    router.dynamic_routes[1] = route1
    router.dynamic_routes[2] = route2
    with pytest.raises(SanicException) as excinfo:
        router.finalize()
    assert "Parameter names cannot use '__'." in str(excinfo.value)

# Generated at 2022-06-24 04:36:14.007364
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add("/uri", ["GET"], None)
    assert len(router.routes) == 1

# Generated at 2022-06-24 04:36:19.253518
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.ctx == None
    assert len(router.routes) == 0
    assert len(router.static_routes) == 0
    assert len(router.dynamic_routes) == 0
    assert len(router.regex_routes) == 0
    assert len(router.name_index) == 0
    assert router.default_handler == None
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS


# Generated at 2022-06-24 04:36:23.804795
# Unit test for method finalize of class Router
def test_Router_finalize():
    from src.router.router_test_helper import RouterTestHelper

    class TestRouter(RouterTestHelper):
        def __init__(self):
            super().__init__()
            self.app = None
            self.add_route = True
            self.add_exception_handler = True
            self.router = Router()

    tr = TestRouter()
    tr.test_Router_finalize()

# Generated at 2022-06-24 04:36:35.129951
# Unit test for method add of class Router
def test_Router_add():
    test_router = Router()
    test_methods = ["GET", "POST","OPTIONS"]
    test_handler = RouteHandler
    test_host = "localhost"
    test_strict_slashes = True
    test_stream = False
    test_ignore_body = False
    test_version = "v1"
    test_name = "name"
    test_unquote = False
    test_static = True

# Generated at 2022-06-24 04:36:37.936355
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    Unit test for method finalize of class Router
    """
    assert test_Router_finalize_default()



# Generated at 2022-06-24 04:36:40.707309
# Unit test for constructor of class Router
def test_Router():
    r = Router(app=None, ctx=None)
    assert r.DEFAULT_METHOD == "GET"
    assert r.ALLOWED_METHODS == HTTP_METHODS



# Generated at 2022-06-24 04:36:47.232108
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add(uri="/test_route", methods=["GET"], handler=None, host=None, strict_slashes=False, stream=False, ignore_body=False, version=None, name=None, unquote=False, static=False)
    router.dynamic_routes["test_route"] = Route(path="test_route", handler=None, methods=["GET"], name=None, strict=False, unquote=False, **{'ctx': {'name': None, 'methods': ['GET'], 'ignore_body': False, 'stream': False, 'hosts': [None], 'static': False}})
    try:
        router.finalize()
    except BaseException:
        assert False
    

# Generated at 2022-06-24 04:36:52.591773
# Unit test for method finalize of class Router
def test_Router_finalize():
    # NOTE: unittest is not fully applied on this test
    router = Router()
    router.dynamic_routes = [Route(uri=1)]
    for label in router.dynamic_routes:
     assert label not in ALLOWED_LABELS

# Generated at 2022-06-24 04:36:54.814029
# Unit test for constructor of class Router
def test_Router():
    # check that the constructor of class Router does not throw an exception i.e. operates without a problem
    def func():
        pass
    router = Router(func, [])
    assert router

# Generated at 2022-06-24 04:37:06.838141
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    route = router.add(
        "uri", ["methods"], "handler", host=None, strict_slashes=False,
        stream=False, ignore_body=False, version=None, name=None, unquote=False, static=False)

    assert route.ctx.hosts == [None]
    assert not route.ctx.ignore_body
    assert not route.ctx.stream
    assert not route.ctx.static

    route = router.add(
        "uri", ["methods"], "handler", host="host", strict_slashes=False,
        stream=False, ignore_body=False, version=None, name=None, unquote=False, static=False)

    assert route.ctx.hosts == ["host"]
    assert not route.ctx.ignore_body

# Generated at 2022-06-24 04:37:15.995256
# Unit test for method finalize of class Router
def test_Router_finalize():
    # create test objects
    dynamic_routes = {
        'test1': {'labels': ['test11', 'test12']},
        'test2': {'labels': ['test21', 'test22']}
    }
    routes = {
        'test1': {'labels': ['test11', 'test12']},
        'test2': {'labels': ['test21', 'test22']}
    }
    regex_routes = {
        'test1': {'labels': ['test11', 'test12']},
        'test2': {'labels': ['test21', 'test22']}
    }

# Generated at 2022-06-24 04:37:25.063245
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic_routing.route import Route
    from pytest import raises
    from collections import defaultdict
    from typing import DefaultDict
    from unittest.mock import Mock, patch

    class MockRoute(Route):
        def __init__(self):
            super().__init__(path=None, handler=None, methods=None, name=None)
            self.labels = ["__foo__", "__bar__", "__file_uri__"]

    # request = Mock()
    router = Router()

    with patch.object(router, "routes_dynamic", new_callable=lambda: defaultdict(Mock)):
        router.routes_dynamic[MockRoute()] = MockRoute()


# Generated at 2022-06-24 04:37:32.067824
# Unit test for constructor of class Router
def test_Router():
    try:
        router = Router()
        assert (router.routes_all is not None)
        assert (router.routes_static is not None)
        assert (router.routes_dynamic is not None)
        assert (router.routes_regex is not None)
    except Exception as e:
        print(e)
        return False
    return True


if __name__ == "__main__":
    try:
        assert test_Router()
    except AssertionError:
        pass

# Generated at 2022-06-24 04:37:40.511074
# Unit test for method add of class Router
def test_Router_add():
    # Test 1
    router = Router()
    router.add(uri='/user/<name>',
               methods=['GET'],
               handler=lambda: 0,
               host=None,
               strict_slashes=False,
               stream=False,
               ignore_body=False,
               version=None,
               name=None,
               unquote=False)
    assert router.routes[0].name == None
    print("Test 1 passed")
    print("")

    # Test 2
    router = Router()

# Generated at 2022-06-24 04:37:41.653136
# Unit test for constructor of class Router
def test_Router():
  assert Router()


# Generated at 2022-06-24 04:37:46.262408
# Unit test for constructor of class Router
def test_Router():
    # Creation of Router object
    test_router = Router()
    assert isinstance(test_router, Router), "test_router is not an instance of class Router"
    assert len(test_router.routes) == 0, "test_router should not have any routes"


# Generated at 2022-06-24 04:37:47.223737
# Unit test for constructor of class Router
def test_Router():
    assert Router().routes == {}


# Generated at 2022-06-24 04:37:48.858937
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    try:
        router.finalize()
    except Exception as ex:
        assert False

# Generated at 2022-06-24 04:37:53.989313
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    uri = "/"
    methods = HTTP_METHODS
    handler = None
    host = None
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = None
    unquote = False
    static = False
    route = router.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)
    assert type(route) == Route
    assert route.path == '/'
    assert route.handler == None
    assert route.methods == HTTP_METHODS


# Generated at 2022-06-24 04:37:56.611959
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert isinstance(r, BaseRouter) == True


# Generated at 2022-06-24 04:38:06.817731
# Unit test for method add of class Router
def test_Router_add(): # method add of class Router
    from sanic.response import json

    router = Router()
    router.add("/test", ["GET"], json, ["test.com"])
    router.add("/test_1", methods=["GET"], handler=json)
    router.add("/test_2", methods=["GET"], handler=json, strict_slashes=True)
    router.add(
        uri="/test_3",
        methods=["GET"],
        handler=json,
        host="test.com",
        strict_slashes=True,
        stream=True,
        ignore_body=True,
        version=1,
        name="test_route",
        unquote=True,
        static=True,
    )


# Generated at 2022-06-24 04:38:16.773237
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Given
    router = Router()

    route1 = Route()
    route1.add_parameter('__file_uri__', '<file_uri>')

    route2 = Route()
    route2.add_parameter('__file_uri__', '<file_uri>')
    route2.add_parameter('another_parameter', '<another_param>')

    route3 = Route()
    route3.add_parameter('__file_uri__', '<file_uri>')
    route3.add_parameter('__another_parameter', '<another_param>')

    route4 = Route()
    route4.add_parameter('__file_uri__', '<file_uri>')
    route4.add_parameter('__', '<another_param>')


# Generated at 2022-06-24 04:38:24.330504
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    from sanic_routing import Router
    from sanic_routing import Route
    import pytest

    app = Sanic("test_Router_finalize")
    router = Router(app)
    router.dynamic_routes ={
        'test': Route(
            path="/test/<param>",
            handler=None,
            methods=(),
            name='test'
        )
    }
    with pytest.raises(SanicException) as excinfo:
        router.finalize()
    excinfo.match(r'Invalid route')

# Generated at 2022-06-24 04:38:28.543613
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route('route', methods=['GET'])
    route.labels = ['__invalid__']
    router.dynamic_routes = {0: route}
    with pytest.raises(SanicException) as exc:
        router.finalize()
    assert "Invalid route: GET /route. Parameter names cannot use '__'." in f"{exc.value}"

# Generated at 2022-06-24 04:38:34.161820
# Unit test for method finalize of class Router
def test_Router_finalize():
    # test Router finalize
    route1 = Route(None, None, None, None, None, labels=('__file_uri__', '__label1__'), name=None)
    route1.is_dynamic = True
    route2 = Route(None, None, None, None, None, labels=('__label1__',), name=None)
    route2.is_dynamic = True
    route3 = Route(None, None, None, None, None, labels=('__label2__',), name=None)
    route3.is_dynamic = True
    router = Router()
    router.dynamic_routes = {'1': route1, '2': route2, '3': route3}
    router.finalize()


# Generated at 2022-06-24 04:38:42.689009
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route_good = Route(
        path="/<name>",
        handler=lambda request, name: None,
        methods=["GET"],
        name=None,
        strict=False,
        unquote=False,
    )
    route_bad = Route(
        path="/<__bad_name>",
        handler=lambda request, name: None,
        methods=["GET"],
        name=None,
        strict=False,
        unquote=False,
    )
    router.dynamic_routes[route_good] = route_good
    router.dynamic_routes[route_bad] = route_bad
    try:
        router.finalize()
    except SanicException:
        pass
    else:
        assert False, "Expected exception SanicException"

# Generated at 2022-06-24 04:38:43.908414
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert isinstance(r, Router)



# Generated at 2022-06-24 04:38:51.653448
# Unit test for method finalize of class Router
def test_Router_finalize():
    app = Sanic("test_add_route")
    app.config.KEEP_ALIVE_TIMEOUT = None

    @app.route("/")
    async def handler(request):
        return response.text("OK")

    route = app.url_for("handler")
    router = Router(app)
    router.finalize([route])

    assert router.finalized
    assert router.ctx.app is app



# Generated at 2022-06-24 04:38:52.283101
# Unit test for method add of class Router
def test_Router_add():
    assert True

# Generated at 2022-06-24 04:38:56.028453
# Unit test for constructor of class Router
def test_Router():
    routes = Router()
    assert routes.routes.keys() == {'/'}
    assert routes.static_routes.keys() == set()
    assert routes.dynamic_routes.keys() == set()
    assert routes.name_index == {}
    assert routes.strict == False
    assert routes.case_insensitive == False


# Generated at 2022-06-24 04:38:59.131306
# Unit test for constructor of class Router
def test_Router():
    assert Router() is not None

if __name__ == '__main__':
    test_Router()

# Generated at 2022-06-24 04:39:06.135521
# Unit test for method add of class Router
def test_Router_add():
    uri = "tests/fixtures/router_test.txt"
    methods = ["GET", "POST"]
    handler = RouteHandler

    route = Route(uri=uri, methods=methods, handler=handler)
    assert route.uri == "tests/fixtures/router_test.txt"
    assert route.methods == ["GET", "POST"]
    assert route.handler == RouteHandler

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 04:39:14.675577
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    # Case 1
    assert isinstance(router.add("/", methods=("GET",), handler=None), Route)
    # Case 2
    assert isinstance(router.add("/", methods=("GET",), handler=None, host="127.0.0.1"), Route)
    # Case 3
    assert isinstance(router.add("/", methods=("GET",), handler=None, strict_slashes=False), Route)
    # Case 4
    assert isinstance(router.add("/", methods=("GET",), handler=None, stream=False), Route)
    # Case 5
    assert isinstance(router.add("/", methods=("GET",), handler=None, ignore_body=False), Route)
    # Case 6

# Generated at 2022-06-24 04:39:17.988364
# Unit test for constructor of class Router
def test_Router():
    import sanic.router as router
    if not isinstance(router.Router(), router.Router):
        raise Exception("Router class test failed")

# Generated at 2022-06-24 04:39:29.617393
# Unit test for method add of class Router
def test_Router_add():
    from sanic.blueprints import Blueprint
    from sanic.views import HTTPMethodView
    from typing import List
    router = Router()
    router.add(uri="", methods=["GET"], handler=None)
    router.add(uri="/", methods=["GET"], handler=None)
    router.add(uri="/a", methods=["GET"], handler=None, strict_slashes=False)
    router.add(uri="/a/b", methods=["GET"], handler=None, strict_slashes=True)
    router.add(uri="/a/b/c", methods=["GET"], handler=None, strict_slashes=True)
    router.add(uri=r"/a/<var>", methods=["GET"], handler=None, strict_slashes=False)

# Generated at 2022-06-24 04:39:34.554295
# Unit test for method add of class Router
def test_Router_add():
    from .test_router import TestRouter

    uri = ""
    method = ""
    handler = ""
    host = ""
    strict_slashes = ""
    stream = ""
    ignore_body = ""
    version = ""
    name = ""
    unquote = ""
    static = ""
    test_router = Router()
    result = test_router.add(uri, method, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)
    assert result is None


# Generated at 2022-06-24 04:39:44.854587
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()

    route = Route(
        "GET",
        "/",
        lambda x: None,
        strict_slashes=False,
        host=None,
        name=None,
        uri_template="",
        status_code=200,
        unquote=True,
        version=None,
        in_view=False,
        stream=False,
        labels=(),
        host_matching=False,
    )
    route.ctx.ignore_body = False
    route.ctx.stream = False
    route.ctx.hosts = [None]
    route.ctx.static = False

    should_raise_exception = False

# Generated at 2022-06-24 04:39:55.978448
# Unit test for method add of class Router
def test_Router_add():

    router = Router()
    uri = "/"
    methods = ["GET", "POST"]
    handler = RouteHandler
    host = "127.0.0.1"
    strict_slashes = False
    stream = True
    ignore_body = True
    version = "v1"
    name = "main"
    unquote = False
    static = False

    route = router.add(
        uri=uri,
        methods=methods,
        handler=handler,
        host=host,
        strict_slashes=strict_slashes,
        stream=stream,
        ignore_body=ignore_body,
        version=version,
        name=name,
        unquote=unquote,
        static=static,
    )
    assert route.path == f"/v1/{uri}"
    assert route

# Generated at 2022-06-24 04:39:56.894413
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router


# Generated at 2022-06-24 04:40:00.701204
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.ctx is None


# Generated at 2022-06-24 04:40:04.678306
# Unit test for method add of class Router
def test_Router_add():
    uri = "index"
    methods = ["GET"]
    handler = print("hello")
    host = "localhost"
    strict_slashes = False
    stream = False
    ignore_body = False
    version = 1.0
    name = "index"
    unquote = False
    static = False
    # test code
    r = Router()
    r.add(uri, methods, handler, host, strict_slashes, stream, ignore_body,
        version, name, unquote, static)
    assert type(r.routes) == dict

# Generated at 2022-06-24 04:40:10.709998
# Unit test for method finalize of class Router
def test_Router_finalize():
    from main import app
    for route in app.router.dynamic_routes.values():
        if any(
                label.startswith("__")
                for label in route.labels
        ):
            raise Exception("Invalid route: {0}. Parameter names cannot use '__'.".format(route))


# test_Router_finalize()

# Generated at 2022-06-24 04:40:22.050085
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    uri = "/foo"
    methods = ["GET","POST"]
    handler = 1 # type: ignore
    host = "127.0.0.1"
    strict_slashes=False
    stream=False
    ignore_body=False
    version=1.0
    name="foo"
    unquote=False
    static=False
    route = router.add(
        uri=uri,
        methods=methods,
        handler=handler,
        host=host,
        strict_slashes=strict_slashes,
        stream=stream,
        ignore_body=ignore_body,
        version=version,
        name=name,
        unquote=unquote,
        static=static,
    )
    assert route.name == name
    assert route.methods == methods
   

# Generated at 2022-06-24 04:40:24.828146
# Unit test for constructor of class Router
def test_Router():
    from sanic.app import Sanic
    app = Sanic()

    router = Router(app)

    assert isinstance(router, Router)

# Generated at 2022-06-24 04:40:26.282905
# Unit test for method finalize of class Router
def test_Router_finalize():
    # TODO: create unit tests
    pass

# Generated at 2022-06-24 04:40:30.036027
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router("sanic router", host=None)
    with pytest.raises(SanicException):
        r.finalize("/test/<__test>", lambda r: None)
    r.finalize("/test/<__test>", lambda r: None, host=None)

# Generated at 2022-06-24 04:40:35.156125
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route("method", "uri", "handler")
    router.routes_dynamic[1] = route
    router.finalize("scope")
    assert router.finalized
    assert router.dynamic_routes == {}
    assert route in router.routes

# Generated at 2022-06-24 04:40:43.868964
# Unit test for method add of class Router
def test_Router_add():
    from sanic import Sanic

    app = Sanic()

    @app.route('/')
    def handler(request):
        return request.app

    assert len(app.router.routes_all) == 1
    assert len(app.router.routes_static) == 0
    assert len(app.router.routes_dynamic) == 1
    assert len(app.router.routes_regex) == 0
    assert not app.router.routes_static.get('/')
    assert app.router.routes_dynamic.get('/')
    assert not app.router.routes_regex.get('/')
    assert app.router.routes_all[0].handler == handler


# Generated at 2022-06-24 04:40:51.348343
# Unit test for method add of class Router
def test_Router_add():
    # test bad input
    r = Router()
    expect(r.add('/', ["GET", "POST"], None)).to(be(not_(None)))
    expect(r.add('', ["GET", "POST"], None)).to(be(not_(None)))
    # test good input
    expect(r.add('/', ["GET", "POST"], None)).to(be(not_(None)))



# Generated at 2022-06-24 04:41:01.573640
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.exceptions import InvalidUsage

    from .utils import TestRoute

    try:
        TestRoute("/user/{__file_uri__}")
    except InvalidUsage as e:
        assert e.args[0] == "Route parameter names cannot start with '__'"
    else:
        assert False

    tr = TestRoute("/user/{file_uri}")
    tr = TestRoute("/user/{__file_uri__}")
    tr = TestRoute("/user/{__file_uri__}", methods=["HEAD", "POST", "GET"])
    tr = TestRoute("/user/{__file_uri__}", methods=["HEAD", "POST", "GET"])

    tr.finalize()


# Generated at 2022-06-24 04:41:02.045350
# Unit test for method finalize of class Router
def test_Router_finalize():
    pass

# Generated at 2022-06-24 04:41:03.502556
# Unit test for constructor of class Router
def test_Router():
    try:
        Router()
        assert True
    except TypeError as e:
        print(e)

# Generated at 2022-06-24 04:41:06.163346
# Unit test for constructor of class Router
def test_Router():
    assert set(Router().ALLOWED_METHODS) == set(HTTP_METHODS)
    assert Router().DEFAULT_METHOD == "GET"


if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-24 04:41:16.037962
# Unit test for method finalize of class Router
def test_Router_finalize():
    route = Route("/", None, "GET", None, None, None)
    route.ctx.labels = ["__file_uri__", "__test__"]
    route.ctx.hosts = None
    route.ctx.ignore_body = False
    route.ctx.stream = False
    route.ctx.static = False
    route.ctx.version = None
    
    router = Router(None)
    router.dynamic_routes = {
        "GET": {
            "/": {
                "GET": route
            }
        }
    }
    # No raises
    router.finalize()

    route.ctx.labels.append("__new__")
    # Raises SanicException
    with pytest.raises(SanicException):
        router.finalize()

# Generated at 2022-06-24 04:41:17.832903
# Unit test for constructor of class Router
def test_Router():
    '''
	Test the constructor of class Router in sanic.router.py
	'''
    assert Router


# Generated at 2022-06-24 04:41:27.775758
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert type(r.ctx) == type({})
    assert type(r.routes) == type(OrderedDict())
    assert type(r.routes_list) == type(list())
    assert type(r.dynamic_routes) == type(OrderedDict())
    assert type(r.static_routes) == type(OrderedDict())
    assert type(r.regex_routes) == type(OrderedDict())
    assert type(r.name_index) == type(dict())
    assert type(r.host_index) == type(dict())
    assert type(r.host_matchers) == type(dict())
    assert r.DEFAULT_METHOD == "GET"

# Generated at 2022-06-24 04:41:36.577712
# Unit test for constructor of class Router
def test_Router():
    router=Router()
    router.finalize()
    router.add('/', ['GET','POST','OPTIONS'], None, static=True)
    allroutes=router.routes_all
    staticroutes=router.routes_static
    dynamicroutes=router.routes_dynamic
    regexroutes=router.routes_regex
    for route in allroutes.values():
        print(route)
    for route in staticroutes.values():
        print(route)
    for route in dynamicroutes.values():
        print(route)
    for route in regexroutes.values():
        print(route)


# Generated at 2022-06-24 04:41:40.409867
# Unit test for method finalize of class Router
def test_Router_finalize():
    _instance_Router = Router()
    _instance_Router.finalize()

# Generated at 2022-06-24 04:41:42.433806
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS



# Generated at 2022-06-24 04:41:50.650331
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes == []
    assert router.static_routes == []
    assert router.dynamic_routes == []
    assert router.regex_routes == []
    assert router.name_index == {}
    assert router.ctx is None
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == []
    assert router.routes_regex == []

# Generated at 2022-06-24 04:42:00.023540
# Unit test for method add of class Router
def test_Router_add():
    r1 = Router(None)

    uri = "/"
    methods = ["GET"]
    handler = lambda: print("handler")
    r2 = r1.add(uri, methods, handler)

    assert r2.path == uri
    assert r2.methods == methods
    assert r2.handler == handler
    assert r2.ctx.hosts == [None]
    assert r2.ctx.ignore_body == False
    assert r2.ctx.stream == False
    assert r2.ctx.static == False


# Generated at 2022-06-24 04:42:08.460579
# Unit test for constructor of class Router
def test_Router():
    """Test for constructor of class Router."""
    router = Router()
    assert router.host is None
    assert router.uri_template is None
    assert router.strict_slashes is False
    assert router.routes == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.ctx.app is None
    assert router.ctx.hosts == [None]
    assert router.ctx.static is False
    assert router.ctx.ignore_body is False
    assert router.ctx.stream is False
    assert router.ctx.extra == {}


# Generated at 2022-06-24 04:42:09.714674
# Unit test for constructor of class Router
def test_Router():
    newObj = Router()
    assert isinstance(newObj, RoutingNotFound)

# Generated at 2022-06-24 04:42:20.289288
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add("/", 'GET', lambda req: None, name="index")
    assert [x.path for x in router.routes_all] == ["/"]
    assert [x.method for x in router.routes_all] == ["GET"]
    assert [x.name for x in router.routes_all] == ["index"]
    assert router.find_route_by_view_name("index")[0] == "/"
    router.add("/", 'GET', lambda req: None, name="index", unquote=True)
    assert router.find_route_by_view_name("index")[0] == "/"
    router.add("/", 'GET', lambda req: None, name="index", unquote=False)
    assert router.find_route_by_view

# Generated at 2022-06-24 04:42:21.155285
# Unit test for constructor of class Router
def test_Router():
  a = Router()
  assert a

# Generated at 2022-06-24 04:42:23.321336
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    r.add("/test/<a>", ["GET"], "test_handler")
    r.finalize()


# Generated at 2022-06-24 04:42:28.876749
# Unit test for method add of class Router
def test_Router_add():
    a = Router()
    a.add('/',['GET'],print)
    a.add(
    uri = '/',
    methods = ['POST'],
    handler = print,
    host = 'example.com',
    strict_slashes = False,
    stream = True,
    ignore_body = False,
    version = '1',
    name ='Get Method',
    unquote = False,
    static = False)
    return True


# Generated at 2022-06-24 04:42:32.708848
# Unit test for constructor of class Router
def test_Router():
    # check if the router is created
    assert isinstance(Router(), Router)

# Generated at 2022-06-24 04:42:33.972570
# Unit test for constructor of class Router
def test_Router():
    router = Router(None)
    assert router.ctx is None


# Generated at 2022-06-24 04:42:35.210356
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes == {}

# Generated at 2022-06-24 04:42:43.273233
# Unit test for method add of class Router
def test_Router_add():
    # Create a Router() object
    router = Router()

    # Add a handler to the router
    methods = ["GET", "POST", "OPTIONS"]
    uri = "/v1/hello"
    handler = "handler"
    host = "sanic.local"
    strict_slashes = False
    stream = False
    ignore_body = False
    name = "hello"
    unquote = False

    route = router.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, name, unquote)
    assert route.ctx.ignore_body == ignore_body
    assert route.ctx.methods == methods
    assert route.ctx.hosts == [host]
    assert route.ctx.name == name
    assert route.ctx.strict == strict_slashes

# Generated at 2022-06-24 04:42:44.119364
# Unit test for constructor of class Router
def test_Router():
    pass

# Generated at 2022-06-24 04:42:49.846413
# Unit test for method finalize of class Router
def test_Router_finalize():
    uri = '/uri'
    route = Route(uri,None,None)
    route.ctx.labels = ['__file_uri__','__dummy__']
    routes = {uri: route}
    router = Router(None,None)
    router.dynamic_routes = routes
    with pytest.raises(SanicException) as excinfo:
        router.finalize()
    assert 'Invalid route' in str(excinfo.value)

# Generated at 2022-06-24 04:42:56.720800
# Unit test for constructor of class Router
def test_Router():
    test_router = Router(app=None)
    assert test_router.DEFAULT_METHOD == "GET"
    assert test_router.ALLOWED_METHODS == HTTP_METHODS
    assert test_router.routes == {}
    assert test_router.name_index == {}
    assert test_router.static_routes == {}
    assert test_router.dynamic_routes == {}
    assert isinstance(test_router.ctx, RouterContext)
    assert test_router.ctx.app is None


# Generated at 2022-06-24 04:43:06.663905
# Unit test for method finalize of class Router
def test_Router_finalize():
    import sanic
    app = sanic.Sanic("test_Router_finalize")

    router = Router(app, {})

    router.dynamic_routes = {
        "route1": "route1",
        "route2": "route2",
        "route3": "route3",
    }

    @router.route("/route1")
    async def handler(request, name):
        pass

    @router.route("/route2")
    async def handler2(request, name):
        _ = name

    @router.route("/route3")
    async def handler3(request, name):
        _ = name


    try:
        router.finalize()
    except SanicException as e:
        print(e)
        assert False

    router.dynamic_routes

# Generated at 2022-06-24 04:43:18.268339
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router.routes, dict)
    assert isinstance(router.routes_all, dict)
    assert isinstance(router.routes_static, dict)
    assert isinstance(router.routes_dynamic, dict)
    assert isinstance(router.routes_regex, dict)
    assert isinstance(router.name_index, dict)
    assert isinstance(router.ctx, dict)
    assert isinstance(router.finalize, type(Router.finalize))
    assert isinstance(router.get, type(Router.get))
    assert isinstance(router.add, type(Router.add))

# Generated at 2022-06-24 04:43:18.787498
# Unit test for constructor of class Router
def test_Router():
    router = Router()

# Generated at 2022-06-24 04:43:22.710158
# Unit test for method add of class Router
def test_Router_add():
    method = "get"
    uri = "test"
    handler = "handler"
    router = Router()
    assert router.add(uri, method, handler)
    assert len(router.routes) == 1



# Generated at 2022-06-24 04:43:23.965561
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)

# Generated at 2022-06-24 04:43:32.551041
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    # To test the add function of the class, we need to mock the different
    # outputs of the function, which modify the router object.

    # To check that the function is called with the right parameters
    @mock.patch.object(router, "add")
    def test_router_add_with_params(mock_department_add):
        # To make sure that the add is called with the right parameters
        router.add('/hello', ['GET'], lambda: 'Hello World!')
        mock_department_add.assert_called_with('/hello', ['GET'], lambda: 'Hello World!')

    # To test that the method is called when the add is called.

# Generated at 2022-06-24 04:43:39.337902
# Unit test for method finalize of class Router
def test_Router_finalize():
  """Test case to check the function finalize in class Router"""
  router = Router()
  route1 = Route(router, '', '', {'__file_uri__': None})
  route2 = Route(router, '', '', {'__file': None})
  router.static_routes['/'] = [route1]
  router.static_routes['/'] = [route2]
  with pytest.raises(SanicException) as excinfo:
      router.finalize()
  assert 'Invalid route: Route: __file_uri__: None' in str(excinfo.value)

# Generated at 2022-06-24 04:43:41.797966
# Unit test for constructor of class Router
def test_Router():
    # Unit test for constructor
    router = Router()
    assert router.ctx.app == None
    assert router.routes == {}



# Generated at 2022-06-24 04:43:50.390167
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    assert router.routes_all is None
    assert router.routes_static is None
    assert router.routes_dynamic is None
    assert router.routes_regex is None

    def _handler():
        pass

    router.add("/", ["GET"], _handler)
    assert len(router.routes_all) == 1
    assert len(router.routes_static) == 1
    assert len(router.routes_dynamic) == 0
    assert len(router.routes_regex) == 0

    router.add("/path/<param>/<name>", ["ANY"], _handler)
    assert len(router.routes_all) == 2
    assert len(router.routes_static) == 1

# Generated at 2022-06-24 04:43:58.338636
# Unit test for method add of class Router
def test_Router_add():
    from sanic import Sanic
    from sanic.response import text

    app = Sanic()
    router = Router()

    @app.route('/view')
    def view(request):
        return text('I am a view.')

    router.add(uri='/static', methods=['GET'], handler=view, static=True)
    routes = router.routes_all

    assert "/static" in (r.uri for r in routes)
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-24 04:44:06.145168
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    Function to test method finalize of class Router
    """
    from sanic.router import Router
    from sanic.constants import HTTP_METHODS
    from sanic.blueprints import Blueprint
    from sanic.exceptions import SanicException

    # Case 1
    my_router = Router()
    my_router.add('/test/')
    my_router.finalize(None)

    # Case 2
    my_router = Router()
    my_router.add('/test/', HTTP_METHODS)
    my_router.finalize(None)

    # Case 3
    my_router = Router()
    my_router.add('/test/', ['GET'], None)
    my_router.finalize(None)

    # Case 4
    my_rou

# Generated at 2022-06-24 04:44:07.185019
# Unit test for constructor of class Router
def test_Router():
    Router()


# Generated at 2022-06-24 04:44:18.062220
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    method finalize of class Router
    """
    router = Router()
    router.dynamic_routes = {
        "/test/1/<name>": "dummy",
        "/test/2/<name>": "dummy",
    }

    with pytest.raises(SanicException, match=r".*parameter names cannot use '__'."):
        router.finalize()

    router.dynamic_routes = {
        "/test/1/<name>": "dummy",
        "/test/2/<__file_uri__>": "dummy",
    }
    router.finalize()
    assert True

# Generated at 2022-06-24 04:44:25.507062
# Unit test for constructor of class Router
def test_Router():
    
    router = Router()

    router.add(uri='/', methods=['GET', 'POST'], handler='handle')

    router.add(host='host.com', uri='/path', methods=['GET', 'POST'],
        handler='handle')

    router.add(host=['host.com', 'host2.com'], uri='/path',
        methods=['GET'], handler='handle')


# Generated at 2022-06-24 04:44:27.903140
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        router = Router()
        router.add(uri='/test/:usr', methods=['GET'], handler=lambda request: 'a')
        router.finalize()
    except:
        assert False
    assert True

# Generated at 2022-06-24 04:44:37.344554
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    from sanic.response import text

    app = Sanic("test_Router_finalize")
    app.router = Router(app, {})

    # Test ok
    @app.route("/test1")
    async def test1(request):
        print("test1")
        return text("test1")

    app.router.finalize()

    # Test error
    @app.route("/test2/<id__name>")
    async def test2(request, id__name):
        print("test2")
        return text("test2")

    with pytest.raises(Exception, match="Invalid route"):
        app.router.finalize()

# Generated at 2022-06-24 04:44:42.912721
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    result_route = router.add("/test_Router_add_path", ["GET"], test_Router_add)
    assert result_route.path == "/test_Router_add_path"
    assert result_route.methods == ["GET"]
    assert result_route.handler == test_Router_add


# Generated at 2022-06-24 04:44:49.253179
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}


# Generated at 2022-06-24 04:44:53.357291
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()

    # Test that an exception is raised when a route has a label that starts
    # with double underscore but is not allowed.
    try:
        router.dynamic_routes["some fake route"] = Route(
            method="GET",
            uri="/",
            handler=None,
            strict_slashes=True,
            name="",
            parameters={"__non_allowed_label__": "str"},
        )
        router.finalize()
    except:
        assert True

    # Test that an exception is not raised when a route has a name that starts
    # with double underscore and is allowed.

# Generated at 2022-06-24 04:44:55.085186
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = 'test'
    # dummy route
    def dummy_route(x, y):
        return x + y
    router.add(route, ['GET'], dummy_route, static=True)
    # call method finalize with params
    router.finalize



# Generated at 2022-06-24 04:44:55.576675
# Unit test for constructor of class Router
def test_Router():
    router = Router()

# Generated at 2022-06-24 04:45:01.958799
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    app = Sanic(__name__)
    router = Router(app)
    router.add("/test", "post", app.add_route)
    try:
        router.finalize()
    except SanicException as se:
        print(se)

if __name__ == "__main__":
    test_Router_finalize()

# Generated at 2022-06-24 04:45:06.885205
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()

    with pytest.raises(SanicException) as exception_info:
        
        r.finalize('__file_uri__','__file_uri__')
        assert exception_info.match(r'Invalid route: __file_uri__. Parameter names cannot use \'__\'.')
        assert exception_info.match('__file_uri__')

