

# Generated at 2022-06-24 04:35:06.347479
# Unit test for method finalize of class Router
def test_Router_finalize():
    newRouter = Router()
    name_route = Route("/")
    newRouter.dynamic_routes["name_route"] = name_route
    name_route.labels.append("__file_uri__")
    assert newRouter.dynamic_routes["name_route"].labels[0] == "__file_uri__"



# Generated at 2022-06-24 04:35:13.356857
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes == {}
    assert router.name_index == {}
    assert router.static_routes == {}
    assert router.static_routes_names == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}



# Generated at 2022-06-24 04:35:21.617386
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.dynamic_routes = {
        "one": Route(
            path="/<one>",
            methods={"GET"},
            handler=None,
            strict=False,
            unquote=False,
        ),
        "two": Route(
            path="/<one>/<two>",
            methods={"GET"},
            handler=None,
            strict=False,
            unquote=False,
        ),
        "three": Route(
            path="/<one>/<two>/<three>",
            methods={"GET"},
            handler=None,
            strict=False,
            unquote=False,
        ),
    }
    router.finalize()

# Generated at 2022-06-24 04:35:24.295397
# Unit test for constructor of class Router
def test_Router():
    # pylint: disable=protected-access
    router = Router()
    assert router._get_router_index() == {} and router._get_regex_index() == {} and router.dynamic_routes == {}
    assert router._get_match_index() == {} and router.name_index == {} and router.ctx.app is None and router.routes == {}
    assert router.dynamic_routes_names == {} and router.static_routes == {} and router.regex_routes == {} and router.__class__ == Router


# Generated at 2022-06-24 04:35:31.077693
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    r.DEFAULT_METHOD, r.ALLOWED_METHODS
    r.get('url', 'method', 'host')
    r.add('uri', ['method'], lambda x: x)
    r.find_route_by_view_name('view_name', 'name')
    r.routes_all, r.routes_static, r.routes_dynamic, r.routes_regex
    r.finalize()

# Generated at 2022-06-24 04:35:34.211850
# Unit test for constructor of class Router
def test_Router():
    assert Router.DEFAULT_METHOD == "GET"
    assert Router.ALLOWED_METHODS == HTTP_METHODS

# Generated at 2022-06-24 04:35:45.894855
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic_routing import BaseRouter
    from sanic_routing.route import Route
    from sanic_routing.router import Router
    import asyncio

    async def handler():
        pass

    router = Router()
    router.routes = {
        "GET": [
            Route(
                "GET",
                "/",
                handler,
                {"host": None},
                None,
                None,
                True,
                {},
                None,
                None,
                True,
            )
        ],
        "POST": [],
        "DELETE": [],
        "PUT": [],
        "PATCH": [],
        "HEAD": [],
        "OPTIONS": [],
    }
    router.ctx = BaseRouter()
    router.iterator = BaseRouter()

# Generated at 2022-06-24 04:35:54.415620
# Unit test for method add of class Router
def test_Router_add():
    from sanic.views import CompositionView
    from sanic.exceptions import SanicException

    handler = CompositionView()
    router = Router()

    router.add("/hello", ["GET"], handler)

    assert len(router.routes_dynamic) == 1
    assert len(router.routes_static) == 0
    assert len(router.routes_regex) == 0

    router.add("/hello", ["GET"], handler, strict_slashes=True)

    assert len(router.routes_dynamic) == 1
    assert len(router.routes_static) == 0
    assert len(router.routes_regex) == 0


# Generated at 2022-06-24 04:36:02.015177
# Unit test for method add of class Router
def test_Router_add():
    import unittest
    from unittest.mock import Mock
    router = Router()
    uri ='/helloworld/<para1>/<para2>'
    methods = ['GET']
    handler = Mock()
    router.add(uri, methods, handler, host=None,
               strict_slashes=False, stream=False, ignore_body=False, version=None, name=None, unquote=False, static=False)
    class TestRouter(unittest.TestCase):
        def test_add(self):
            self.assertEqual(router.routes[0].methods, methods)
            self.assertEqual(router.routes[0].uri, uri)
            self.assertEqual(router.routes[0].handler, handler)
           

# Generated at 2022-06-24 04:36:02.637833
# Unit test for constructor of class Router
def test_Router():
    test_router = Router()
    assert isinstance(test_router, Router)

# Generated at 2022-06-24 04:36:03.952028
# Unit test for constructor of class Router
def test_Router():
    # Create an instance of Router
    router = Router()


# Generated at 2022-06-24 04:36:05.239856
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)

# Generated at 2022-06-24 04:36:11.829371
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route("/", lambda: None) 
    route.labels["__file_uri__"] = "route_1"
    router.routes_dynamic["route_1"] = route
    try:
        router.finalize()
    except SanicException:
        return False
    
    assert True

# Generated at 2022-06-24 04:36:15.853699
# Unit test for method finalize of class Router
def test_Router_finalize():
    with raises(SanicException):
        route = Route(uri='/user/<__user_id:int>',methods=['GET'],handler=lambda request,user_id: 'OK')
        router = Router()
        router.dynamic_routes = {route.name:route}
        router.finalize()


# Generated at 2022-06-24 04:36:19.794734
# Unit test for constructor of class Router
def test_Router():
    # Test: Constructor of class Router
    router = Router()
    assert router != None, "Router object is created"

# Generated at 2022-06-24 04:36:28.041355
# Unit test for method add of class Router
def test_Router_add():
    # Initial test to make sure the function runs without error
    router = Router()
    router.add(
        uri='/',
        methods=['GET'],
        handler=lambda: 'nothing',
        host=None,
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version=None,
        name=None,
        unquote=False,
        static=False,
    )

# Generated at 2022-06-24 04:36:33.981166
# Unit test for method finalize of class Router
def test_Router_finalize():
    #type: (...) -> List[Route]
    """
    When route's label contains ''__'', it will raise an exception.
    """
    uri = 'http://localhost:8080/'
    method = 'GET'
    target = Router()
    with pytest.raises(SanicException) as excinfo:
        target.add(uri, method, 'test_add_get')

    assert "Invalid route: " in str(excinfo.value)

# Generated at 2022-06-24 04:36:42.392808
# Unit test for method add of class Router
def test_Router_add():
    from sanic.app import Sanic
    from sanic_routing.route import Route
    app = Sanic("test_case")
    router = Router(app)
    def test_handler():
        pass
    route = router.add("/", ["GET"], test_handler, name="test_route")
    assert router.get("/", "GET", None) == (route, test_handler, dict())
    assert router.find_route_by_view_name("test_route") == (route.uri, route)

    with pytest.raises(SanicException):
        router.add("/", ["GET"], test_handler,
                   name="test_route__with_double_underscore")

# Generated at 2022-06-24 04:36:54.036634
# Unit test for method add of class Router
def test_Router_add():

    from sanic.exceptions import ServerError
    from sanic.views import CompositionView
    from sanic.views import HTTPMethodView

    router = Router()
    router.add(uri = "/", methods = ["GET", "POST", "OPTIONS"], handler = HTTPMethodView("GET"))
    router.add(uri = "/", methods = ["GET", "POST", "OPTIONS"], handler = HTTPMethodView("POST"))
    router.add(uri = "/", methods = ["GET", "POST", "OPTIONS"], handler = HTTPMethodView("OPTIONS"))
    router.add(
        uri = "/",
        methods = ["GET", "POST", "OPTIONS"],
        handler = CompositionView()
    )

# Generated at 2022-06-24 04:37:05.491574
# Unit test for method finalize of class Router
def test_Router_finalize():
    uri = "foo"
    methods = ["GET", "POST", "OPTIONS"]
    handler = lambda x: x
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = None
    unquote = False
    static = False

    router = Router()
    route = router.add(
        uri=uri,
        methods=methods,
        handler=handler,
        strict_slashes=strict_slashes,
        stream=stream,
        ignore_body=ignore_body,
        version=version,
        name=name,
        unquote=unquote,
        static=static,
    )
    router.finalize()
    if route.ctx.ignore_body is False:
        assert route.ctx.ignore_body is ignore_body
       

# Generated at 2022-06-24 04:37:12.436414
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Arrange
    class TestRouter(Router):
        def __init__(self, ctx):
            super().__init__(ctx)
            self.dynamic_routes['mock_route'] = 'mock_route'

    # Act
    # Assert
    with pytest.raises(SanicException, match=(
        r'Invalid route: mock_route\. Parameter names cannot use \'__\'.')):
        TestRouter(None).finalize()

# Generated at 2022-06-24 04:37:18.640458
# Unit test for method finalize of class Router
def test_Router_finalize():
    def _from_str(st):
        return st

    # create an instance of the class Router
    router = Router()

    class Signal:

        def __init__(self):
            self.called = False

        def __call__(self):
            self.called = True

    signal = Signal()

    uri = '/test_url_'
    # test usning a valid type uri
    methods = ["GET"]
    handler = _from_str
    host = None
    strict_slashes = False
    stream = True
    ignore_body = True
    version = None
    name = None
    unquote = False
    static = False

    # testing the valid parameters
    router.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)
    #

# Generated at 2022-06-24 04:37:29.352193
# Unit test for method add of class Router
def test_Router_add():
    from sanic.router import Router

    r = Router()

    r.add(uri='/todos', methods=['GET'], handler=lambda request: 1, host=None, strict_slashes=False, stream=False, ignore_body=False, version=None, name=None, unquote=False, static=False)

    assert r.routes_dynamic[0].path == '/todos'
    assert r.routes_all[0].path == '/todos'
    assert r.routes_static[0].path == '/todos'
    assert r.routes_regex[0].path == '/todos'


# Generated at 2022-06-24 04:37:33.231025
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.models import Route
    from sanic.router import Router
    router = Router()
    route = Route("", "", "")
    route.labels = ["__file_uri__", "__hello__"]
    router.dynamic_routes[""] = route
    router.finalize()

# Generated at 2022-06-24 04:37:34.904906
# Unit test for constructor of class Router
def test_Router():
    try:
        Router()
    except Exception as e:
        assert False
    else:
        assert True

# Generated at 2022-06-24 04:37:35.739273
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    

# Generated at 2022-06-24 04:37:36.597036
# Unit test for constructor of class Router
def test_Router():
    router = Router()


# Generated at 2022-06-24 04:37:37.200952
# Unit test for method add of class Router
def test_Router_add():
    pass

# Generated at 2022-06-24 04:37:45.745150
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert type(router) == Router
    assert type(router.routes_static) == list
    assert type(router.routes_dynamic) == {}.__class__
    assert type(router.routes_regex) == {}.__class__
    assert type(router.routes_all) == list
    assert type(router.find_route_by_view_name("index")) == type(None)
    assert type(router.allowed_methods) == list

# Generated at 2022-06-24 04:37:49.861858
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        router = Router()
        router.add('/<__invalid>', methods=['GET'], handler=lambda r: None)
        router.finalize()
    except SanicException as exc:
        assert str(exc) == "Invalid route: /<__invalid>."
    else:
        assert False

test_Router_finalize()

# Generated at 2022-06-24 04:37:56.863882
# Unit test for constructor of class Router
def test_Router():
    uri = '/'
    methods = [1, 2, 3]
    handler = 'a'
    host = 'b'
    strict_slashes = False
    stream = False
    ignore_body = False
    version = 1.0
    name = 'c'
    unquote = False
    static = False
    router = Router()
    router.add(uri,methods,handler,host,strict_slashes,stream,ignore_body,version,name,unquote,static)
    assert router.get('/', '1', 'b') == (Route(uri='/', handler=handler, methods=methods, name=name, strict=strict_slashes, unquote=unquote), handler, {'host': 'b'})
    assert router.find_route_by_view_name('a') == None
   

# Generated at 2022-06-24 04:38:07.885067
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_router = Router()

# Generated at 2022-06-24 04:38:17.505289
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest

    with pytest.raises(SanicException):
        class Router:
            routes = [
                Route(
                    path="u",
                    methods=["GET"],
                    handler="c",
                    name="n",
                    host="h",
                    required_methods=["GET"],
                    labels=["__1__"],
                )
            ]
            dynamic_routes = {
                "u": Route(
                    path="u",
                    methods=["GET"],
                    handler="c",
                    name="n",
                    host="h",
                    required_methods=["GET"],
                    labels=["__1__"],
                )
            }

# Generated at 2022-06-24 04:38:21.477310
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.app import Sanic

    def route_handler():
        pass

    app = Sanic()
    app.blueprint(route_handler)
    app.static('/static', './static')
    router = app.router
    router.finalize()



# Generated at 2022-06-24 04:38:27.433787
# Unit test for method add of class Router
def test_Router_add():
    from sanic.exceptions import SanicException
    from sanic.response import text

    r = Router()

    r.add("/foo", ["GET"], text("OK"))
    assert r.lookup("/foo", "GET")
    assert not r.lookup("/foo", "POST")

    try:
        r.add("/foo", ["GET"], text("OK"))
    except SanicException as e:
        assert "View function mapping is overwriting" in str(e)

    r.add("/foo", ["POST"], text("POST"))
    assert r.lookup("/foo", "POST")
    assert r.lookup("/bar", "GET")
    assert not r.lookup("/bar", "POST")

# Generated at 2022-06-24 04:38:30.036947
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r is not None


# Generated at 2022-06-24 04:38:41.576454
# Unit test for method add of class Router
def test_Router_add():
    router = Router()

    methods = ['GET', 'POST', 'PUT', 'OPTIONS']
    host = '127.0.0.1'
    uri = '/admin'
    handler = 'Handler'
    strict_slashes = False
    stream = False
    ignore_body = True
    version = 0.1
    name = 'name'
    unquote = True

    route = router.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote)

    assert route.ctx.ignore_body == ignore_body
    assert route.ctx.stream == stream
    assert route.ctx.hosts == [host]
    assert route.ctx.static == False
    assert route.methods == methods

# Generated at 2022-06-24 04:38:48.325616
# Unit test for constructor of class Router
def test_Router():
    from sanic.app import Sanic
    from sanic.views import HTTPMethodView

    class MyView(HTTPMethodView):
        pass

    app = Sanic()
    app.add_route(MyView.as_view(), '/')

    assert isinstance(app.router, Router)
    assert app.router == app.router.routes

# Generated at 2022-06-24 04:38:57.981885
# Unit test for constructor of class Router
def test_Router():
    print("Test constructor of class Router")
    app = Sanic('test_Router')
    router = Router(app)
    assert app == router._application
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == []
    assert router.ctx.app == app
    assert router.ctx.router == router
    assert router.ctx.routes == {}
    assert router.ctx.static_routes == {}
    assert router.ctx.dynamic_routes == {}
    assert router.ctx.regex_routes == []



# Generated at 2022-06-24 04:39:08.925024
# Unit test for method finalize of class Router
def test_Router_finalize():
    # this test roiute can't be tested by unittest
    from unittest import TestCase
    from unittest.mock import Mock


    class RouterTest(TestCase):
        def setUp(self):
            self.router = Router()
            self.router._add_dynamic = Mock()
            self.router._add_route = Mock()
            self.route = Route(
                uri='/',
                method='GET',
                handler=Mock(),
                static=True,
                labels=[],
                requirements={},
                name=None,
                unquote=False,
                strict=False,
            )
            self.router.routes_all = {'index': self.route}
            self.router.routes_static = {'index': self.route}
           

# Generated at 2022-06-24 04:39:09.882289
# Unit test for constructor of class Router
def test_Router():
    Router()



# Generated at 2022-06-24 04:39:14.405950
# Unit test for constructor of class Router
def test_Router():
	uri = 'b'
	methods = ['GET', 'POST', 'OPTIONS']
	handler = RouteHandler
	#router = Router(uri, methods, handler)
	routes = Route()
	routes.uri = uri
	routes.methods = methods
	routes.handler = handler
	assert router._get(routes.uri, routes.methods, routes.handler) == routes


# Generated at 2022-06-24 04:39:19.357488
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add('/',methods=['get'],handler=None,host=None,strict_slashes=False,stream=False,ignore_body=False,virsion=None,name=None,unquote=False,static=False)

# Generated at 2022-06-24 04:39:21.050263
# Unit test for method add of class Router
def test_Router_add():
    pass

# Generated at 2022-06-24 04:39:21.617820
# Unit test for method finalize of class Router
def test_Router_finalize():
    pass

# Generated at 2022-06-24 04:39:31.337859
# Unit test for method finalize of class Router

# Generated at 2022-06-24 04:39:32.188025
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)

# Generated at 2022-06-24 04:39:41.887266
# Unit test for constructor of class Router
def test_Router():
    assert Router().resolve("/test?test=test", "GET", {"host": "localhost"}) == ((NoMethod('Method GET not allowed for URL /test')), [])
    assert Router().resolve("/test?test=test", "GET") == ((RoutingNotFound('Requested URL /test not found')), [])
    assert Router().resolve("/test?test=test", "POST") == ((RoutingNotFound('Requested URL /test not found')), [])
    assert Router().get("/test?test=test", "GET", "localhost") == ((NoMethod('Method GET not allowed for URL /test')), [])
    assert Router().find_route_by_view_name("/test?test=test") == None

# Generated at 2022-06-24 04:39:50.865890
# Unit test for method add of class Router
def test_Router_add():
    methods = ['GET']
    uri = '/resource/<id>'
    handler = 'handler'
    host = None
    strict_slashes = True
    stream = False
    ignore_body = True
    version = None

    router = Router(
        labels={'__file_uri__': 'file_uri'},
        prefix='/prefix',
        ctx={'app': 'app'})
    result = router.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version)
    assert result.__class__.__name__ == 'Route'
    assert result.ctx.stream == stream
    assert result.ctx.ignore_body == ignore_body
    assert result.ctx.hosts == [host]
    assert result.ctx.static == False
    

# Generated at 2022-06-24 04:39:54.867326
# Unit test for constructor of class Router
def test_Router():
    import unittest
    from .application import Sanic

    class TestRouter(unittest.TestCase):
        def test_Router_init(self):
            app = Sanic()
            router = Router(app, app.exception_handler)
            self.assertTrue(router)

# Generated at 2022-06-24 04:39:57.938836
# Unit test for constructor of class Router
def test_Router():
    try:
        router=Router()
    except Exception as e:
        assert type(e)==TypeError
    assert router is not None


# Generated at 2022-06-24 04:40:10.268387
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route(
        path="",
        handler=None,
        methods=tuple(),
        name=None,
        strict=False,
        unquote=False,
    )

    router.add_route(route)
    router._dynamic_routes_add(route)
    router.add_static_route(route)
    router._regex_routes_add(route)

    with pytest.raises(SanicException):
        router.finalize()

    route = Route(
        path="",
        handler=None,
        methods=tuple(),
        name=None,
        strict=False,
        unquote=False,
        requirements=dict(param=None),
    )
    router.add_route(route)

    router.finalize()

# Generated at 2022-06-24 04:40:11.167797
# Unit test for method add of class Router
def test_Router_add():
    pass


# Generated at 2022-06-24 04:40:17.189874
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    Test the method finalize of class Router.
    """
    router = Router()
    route = Route(
        path="/user",
        name="user",
        methods=["GET"],
        handler=lambda request: None,
        strict=True,
        ctx=router.ctx,
    )
    router.add_route(route)
    assert route.labels == [route.name]

    route = Route(
        path="/user",
        name="user",
        methods=["GET"],
        handler=lambda request: None,
        strict=True,
        ctx=router.ctx,
        labels=["__file_uri__"],
    )
    router.add_route(route)
    assert route.labels == ["__file_uri__"]


# Generated at 2022-06-24 04:40:28.001772
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    uri = '/test'
    methods = ['GET', 'POST']
    handler = None
    host = 'test.com'
    strict_slashes = True
    stream = False
    ignore_body = True
    version = 1.0
    name = 'test'
    routes = router.add(uri,methods,handler,host,strict_slashes,stream,ignore_body,version,name)
    assert routes.ctx.ignore_body == ignore_body
    assert routes.ctx.hosts == [host]
    assert routes.ctx.name == name
    assert routes.ctx.stream == stream
    assert routes.ctx.static == False
    assert routes.ctx.version == version


# Generated at 2022-06-24 04:40:34.708895
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add(
        uri="/<regex('[a-zA-Z0-9]{5}'):code>",
        methods=["GET", "POST"],
        handler=lambda x: x,
        host="localhost",
        strict_slashes=False,
        stream=False,
        ignore_body=True,
        version="1.0",
        name="test_uri",
        unquote=False,
        static=True,
    )
    with pytest.raises(SanicException):
        router.finalize()

# Generated at 2022-06-24 04:40:37.204303
# Unit test for constructor of class Router
def test_Router():
    assert Router is not None


# Generated at 2022-06-24 04:40:42.539734
# Unit test for method add of class Router
def test_Router_add():
    from sanic.router import Router
    from sanic.utils import IS_WINDOWS
    import os
    import shutil
    import tempfile

    name = "new_name"
    host = 'www.test.com'
    with tempfile.TemporaryDirectory() as t:
        path = os.path.join(t, "sanic_router.json")
        router = Router()
        router.add(uri='/', methods=['GET'], handler=None, host=host)
        router.host_index['www.test.com'] = '/'
        router.name_index[name] = '/'
        router.save(path)
        new_router = Router(load=path)
        assert new_router.host_index['www.test.com'] == '/'
        assert new_router.name

# Generated at 2022-06-24 04:40:44.105487
# Unit test for constructor of class Router
def test_Router():
    aRouter = Router()
    assert isinstance(aRouter, Router)


# Generated at 2022-06-24 04:40:57.391798
# Unit test for method finalize of class Router
def test_Router_finalize():
    # test case: check if it raises SanicException
    # when Parameter name starts with "__" and not
    # in ALLOWED_LABELS
    r = Router()
    r.dynamic_routes = {
        "hello": Route(
            r.ctx,
            r.ctx.app,
            "GET",
            "/hello",
            lambda: "world",
            name="hello",
        ),
        "hello_world": Route(
            r.ctx,
            r.ctx.app,
            "GET",
            "/hello/world",
            lambda: "world",
            name="hello_world",
        ),
    }

    with pytest.raises(SanicException):
        r.finalize()

    # test case: check if it does not raise SanicException
    # when Parameter name

# Generated at 2022-06-24 04:41:08.281365
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.dynamic_routes["test"] = Route(path="", handler=None, methods="get", name=None, strict=False, unquote=False)
    router.dynamic_routes["test"].labels = ["__test__", "__file_uri__"]
    try:
        router.finalize()
    except SanicException as e:
        assert str(e) == "Invalid route: <Route>|get|/|[<function test_handler at 0x10ddf1f28>, <function test_handler at 0x10ddf1f28>]|Any|False|False. Parameter names cannot use '__'."

# Generated at 2022-06-24 04:41:11.022480
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    assert r.finalize("x", "y") == "y"


# Generated at 2022-06-24 04:41:15.941967
# Unit test for constructor of class Router
def test_Router():
    assert super().has_method("get")
    assert super().has_method("add")
    assert super().has_method("find_route_by_view_name")
    assert super().has_method("routes_all")
    assert super().has_method("routes_static")
    assert super().has_method("routes_dynamic")
    assert super().has_method("routes_regex")
    assert super().has_method("finalize")


# Generated at 2022-06-24 04:41:23.773065
# Unit test for method add of class Router
def test_Router_add():
    test_uri = "test_uri"
    test_methods = ["test_method"]
    test_handler = "test_handler"
    test_host = "test_host"
    test_strict_slashes = False
    test_stream = False
    test_ignore_body = False
    test_version = "test_version"
    test_name = "test_name"
    test_unquote = False
    test_static = False
    test_route = Router().add(
        test_uri,
        test_methods,
        test_handler,
        test_host,
        test_strict_slashes,
        test_stream,
        test_ignore_body,
        test_version,
        test_name,
        test_unquote,
        test_static
    )

    # Test that

# Generated at 2022-06-24 04:41:25.035956
# Unit test for method finalize of class Router
def test_Router_finalize():
    pass

# Generated at 2022-06-24 04:41:27.781071
# Unit test for constructor of class Router
def test_Router():
    router = Router("sanic_routing")
    assert router.ctx.name == "sanic_routing"


# Generated at 2022-06-24 04:41:32.541910
# Unit test for method add of class Router
def test_Router_add():
    router = Router()

    def test_handler():
        pass

    router.add(uri='/', methods=['GET'], handler=test_handler)

    route, handler, args = router.get('/', 'GET', '')

    assert route is not None and handler is not None and args == {}



# Generated at 2022-06-24 04:41:34.361527
# Unit test for constructor of class Router
def test_Router():
    # test case 1
    router = Router()
    assert isinstance(router, Router)

    # test case 2
    # TODO
    return

# Generated at 2022-06-24 04:41:45.100018
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.constants import HTTP_METHODS
    from sanic.constants import STATIC_ROUTE

    router = Router(None, None)

    route_obj = Route(
        uri='/users',
        name='users',
        methods=HTTP_METHODS,
        host='',
        stream=False,
        handler=None,
        strict_slashes=True,
        host_matching=False,
        unquote=False,
        labels={'foo': 'bar'}
    )

    router.dynamic_routes['/users'] = route_obj
    try:
        router.finalize()
    except:
        assert True
    else:
        assert False


# Generated at 2022-06-24 04:41:49.421407
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add('/hello', ['GET'], None)
    assert len(router.routes) == 1


# Generated at 2022-06-24 04:41:53.753401
# Unit test for method finalize of class Router
def test_Router_finalize():
    for route in Router.dynamic_routes.values():
        if any(
            label.startswith("__") and label not in ALLOWED_LABELS
            for label in route.labels
        ):
            raise SanicException(
                f"Invalid route: {route}. Parameter names cannot use '__'."
            )

# Generated at 2022-06-24 04:42:02.364653
# Unit test for method add of class Router
def test_Router_add():
    @lru_cache(maxsize=ROUTER_CACHE_SIZE)
    def get(path, method, host):
        try:
            return self.resolve(path=path, method=method, extra={'host': host})
        except RoutingNotFound as e:
            raise NotFound('Requested URL {} not found'.format(e.path))
        except NoMethod as e:
            raise MethodNotSupported(
                'Method {} not allowed for URL {}'.format(method, path),
                method=method,
                allowed_methods=e.allowed_methods,
            )


# Generated at 2022-06-24 04:42:04.011399
# Unit test for method add of class Router
def test_Router_add():
    router = Router()

    def handler_method():
        pass

    router.add(uri="/test_uri", methods=["GET", "POST"], handler=handler_method)



# Generated at 2022-06-24 04:42:05.363607
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)

# Generated at 2022-06-24 04:42:09.600110
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add("/", ["GET"], (lambda _: "OK"), name="test")



# Generated at 2022-06-24 04:42:20.029494
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()

# Generated at 2022-06-24 04:42:25.639120
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import NotFound
    from sanic import Sanic
    from sanic.config import Config
    from sanic.constants import HTTP_METHODS
    import json

    app = Sanic(__name__)
    sanic_routes = [
        ('/', 'GET', app.hello),
        ('/objects/<id:int>', 'POST', app.hello)
    ]

    router = app.router
    for route in sanic_routes:
        router.add(*route)

    app.config.from_object(Config)
    app.static('/static_test', '.')

    def test_hello(request): return HTT

# Generated at 2022-06-24 04:42:33.590701
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()

    class Route:
        labels =  set(['__file_uri__'])
    route = Route()
    router.dynamic_routes = {"route" : route}
    router.finalize()

    assert router.dynamic_routes == {"route" : route}

    class Route:
        labels =  set(['__file_uri__', '__invalid__'])
    route = Route()
    router.dynamic_routes = {"route" : route}
    raised = False
    try:
        router.finalize()
    except SanicException:
        raised = True
    assert raised

if __name__ == "__main__":
    test_Router_finalize()

# Generated at 2022-06-24 04:42:41.696559
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.constants import HOST_PARAMETER_NAME
    from sanic.constants import URI_PARAMETER_NAME
    from sanic.constants import METHOD_PARAMETER_NAME
    from sanic.constants import REQUEST_PARAMETER_NAME
    from sanic.constants import PAYLOAD_PARAMETER_NAME
    from sanic.constants import FILE_PARAMETER_NAME
    from unittest.mock import Mock

    mock_index = Mock()
    mock_index.get.return_value = False
    mock_routes = Mock()
    mock_routes.values.return_value = []
    mock_ctx = Mock()
    mock_ctx._generate_name.side_effect = ["name1", "name2"]


# Generated at 2022-06-24 04:42:52.163349
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    r.routes = [
        {'path': 'a/b/c', 'labels': ('a', 'b', 'c')},
        {'path': 'a/b', 'labels': ('a', 'b')}
    ]
    r.finalize()

# Generated at 2022-06-24 04:42:53.310710
# Unit test for constructor of class Router
def test_Router():
    test = Router()
    assert isinstance(test, Router)

# Generated at 2022-06-24 04:42:56.292693
# Unit test for method finalize of class Router
def test_Router_finalize():
    app = Sanic('test_Router_finalize')
    with pytest.raises(SanicException):
        @app.route('/test_Router_finalize')
        def handler(request, __hello):
            return text('OK')


# Generated at 2022-06-24 04:43:02.030147
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == []
    assert len(router.name_index.keys()) == 0

    def handler1():
        pass

    def handler2():
        pass

    route1 = router.add("/test/<id>/", ["GET"], handler1)
    route2 = router.add("/test/<id1>/<id2>/", ["GET"], handler2)

    assert router.routes_all == {
        ("/test/<id>/", "GET"): route1,
        ("/test/<id1>/<id2>/", "GET"): route2
    }
   

# Generated at 2022-06-24 04:43:06.970579
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes == {}
    assert router.routes_all == {}
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}



# Generated at 2022-06-24 04:43:18.442189
# Unit test for method add of class Router
def test_Router_add():
    # Test add a route to method GET
    router = Router()
    @router.route("/")
    def test_handler(request):
        return

    assert len(router.routes) == 1
    assert len(router.routes_all) == 1
    assert len(router.routes_static) == 1
    assert len(router.routes_dynamic) == 0
    assert len(router.routes_regex) == 0

    assert router.routes["GET"][0].uri == "/"

    route = router.find_route_by_view_name('test_handler')
    assert route
    assert route.handler is test_handler
    assert route.uri == '/'

    # Test add a route to method GET, POST
    router = Router()

# Generated at 2022-06-24 04:43:20.123950
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert type(router) == Router


# Generated at 2022-06-24 04:43:29.877085
# Unit test for method finalize of class Router
def test_Router_finalize():
    import sys
    import os
    import tempfile
    from unittest import mock

    temp_dirname = tempfile.mkdtemp()
    sys.modules["sanic.exceptions"] = mock.MagicMock()
    os.environ["UVLOOP_ENABLED"] = "false"
    from sanic import Sanic
    from sanic.exceptions import SanicException

    app = Sanic("sanic-test")
    router = Router(app, "")
    route = router.add("/v1/test/<id>", methods=["GET", "POST", "OPTIONS"], handler=app._handle)
    route.labels = {"__router__": 1, "name": "test", "id": int, "__file_uri__": "abc"}

# Generated at 2022-06-24 04:43:31.008971
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-24 04:43:38.150569
# Unit test for method add of class Router
def test_Router_add():
    from sanic.router import Router
    from sanic.exceptions import InvalidUsage
    from sanic import Sanic

    app = Sanic("sanic-router-test")
    router = Router(app, {})

    try:
        router.add("/test_add/<name>", ["GET"], "Test Add")
    except InvalidUsage:
        pass
    else:
        assert False
    
    try:
        router.add("/test_add/<name>", ["GET"], app.test_add, name = "Test Add")
    except InvalidUsage:
        assert False
    else:
        assert True
    
    assert len(router.routes) == 1
    router.routes[0].ctx.name == "Test Add"
    assert len(router.routes_dynamic)

# Generated at 2022-06-24 04:43:42.425725
# Unit test for method finalize of class Router
def test_Router_finalize(): 
    """
    Test case for finalize method of class Router.
    """
    try:
        router = Router()
        router.finalize()
    except SanicException:
        pass


# Generated at 2022-06-24 04:43:50.196668
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    r.ctx = {}
    r.routes = {}
    r.static_routes = {}
    r.dynamic_routes = {
        "a" : Route(),
        "b" : Route()
    }
    r.regex_routes = {}
    r.dynamic_routes["a"].labels = ["__file_uri__"]
    try:
        r.finalize()
    except SanicException as se:
        assert se.args[0] == "Invalid route: <sanic_routing.route.Route object at 0x000001ADB093A3C8>. Parameter names cannot use '__'."
        
    r.dynamic_routes["a"].labels = [""]

# Generated at 2022-06-24 04:43:51.819898
# Unit test for constructor of class Router
def test_Router():
    router = Router()


# Generated at 2022-06-24 04:43:59.670312
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic_routing import Router
    try:
        class TestRouter(Router):
            def __init__(self):
                super().__init__()

            def create_route(self, path: str, handler: RouteHandler, **kwargs):
                route = super().create_route(path, handler, **kwargs)
                route.labels = []
                return route

        test_router = TestRouter()
        test_router.add("/{foo}", ["GET"], lambda _: _)
        test_router.finalize()
    except SanicException:
        assert True
    else:
        assert False


# Generated at 2022-06-24 04:44:01.544738
# Unit test for method add of class Router
def test_Router_add():
    router = Router(None)

    def handler():
        pass
    
    try:
        router.add('/', ["GET"], handler) # pass
    except SanicException as e:
        print (e)
        assert False # fail


# Generated at 2022-06-24 04:44:02.481149
# Unit test for method add of class Router
def test_Router_add():
    pass # no test case


# Generated at 2022-06-24 04:44:06.887434
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    r.add(uri='/',methods=['GET', 'POST', 'OPTIONS'],handler=None)
    r.add(uri='/a/b/c/<name>',methods=['GET', 'POST', 'OPTIONS'],handler=None)
    r.finalize()
    assert len(r.routes_static) == 1
    assert len(r.routes_dynamic) == 1


# Generated at 2022-06-24 04:44:10.098094
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    r.add(uri='/user/<name:[a-zA-Z]+>/<id:[\\d]+>', methods=['GET'], handler=None)
    r.finalize()

# Generated at 2022-06-24 04:44:14.657762
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    router=Router()
    router.dynamic_routes["1"]=[1]
    router.dynamic_routes["2"]=[2]
    with pytest.raises(SanicException) as exc_info:
        router.finalize()

# Generated at 2022-06-24 04:44:24.830090
# Unit test for method add of class Router
def test_Router_add():
    from sanic.app import Sanic, SanicRequest

    class MockSanic(Sanic):
        pass

    app = MockSanic()
    router = Router()

    # Test different types of paths
    router.add("/", ["GET"], lambda r: "Hello")
    router.add("/dynamic/<param>", ["GET"], lambda r: r.app.args[0])

    assert len(router.dynamic_routes) == 1
    assert len(router.static_routes) == 1

    # Test different types of methods
    router.add("/", ["GET"], lambda r: "Hello")
    router.add("/", ["POST"], lambda r: "Hello")
    router.add("/", ["PUT"], lambda r: "Hello")

# Generated at 2022-06-24 04:44:29.267681
# Unit test for constructor of class Router
def test_Router():
    assert Router().__class__.__name__=='Router'


# Generated at 2022-06-24 04:44:31.078705
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    try:
        router = Router()
        router.finalize()
        assert True
    except Exception:
        assert False


# Generated at 2022-06-24 04:44:38.997802
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert hasattr(r, "DEFAULT_METHOD")
    assert hasattr(r, "ALLOWED_METHODS")
    assert hasattr(r, "_get")
    assert hasattr(r, "get")
    assert hasattr(r, "add")
    assert hasattr(r, "find_route_by_view_name")
    assert hasattr(r, "routes_all")
    assert hasattr(r, "routes_static")
    assert hasattr(r, "routes_dynamic")
    assert hasattr(r, "routes_regex")
    assert hasattr(r, "finalize")

    assert isinstance(r.DEFAULT_METHOD, str) == True
    assert isinstance(r.ALLOWED_METHODS, tuple) == True
   

# Generated at 2022-06-24 04:44:42.289149
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router(BaseRouter)
    r.add('/', ['GET'], lambda *a, **k: None, static=True)
    r.add('/<val>', ['GET'], lambda *a, **k: None)
    r.finalize()


# Generated at 2022-06-24 04:44:52.392530
# Unit test for method finalize of class Router
def test_Router_finalize():
    # ARRANGE
    test_router = Router()
    my_path = "/test"
    my_method = "GET"
    my_handler = lambda x: x
    my_host = "test.com"
    my_stream = False
    my_ignore_body = False
    my_version = "1"
    my_name = "test_route"
    my_unquote = False
    my_static = False

    test_router.add(my_path,
                    my_method,
                    my_handler,
                    my_host,
                    my_stream,
                    my_ignore_body,
                    my_version,
                    my_name,
                    my_unquote,
                    my_static)

    # ACT
    test_router.finalize()

    # ASSERT
    assert True

# Generated at 2022-06-24 04:45:01.426709
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic_routing.route import Route
    from sanic_routing.router import Router

    router = Router()
    route = Route("path", "handler", ["GET"])
    route.hosts = ['host']
    route2 = Route("path2", "handler2", ["GET"])
    route2.hosts = ['host']

    route.labels.append("__file_uri__")
    router.routes_dynamic.append(route)
    router.routes_dynamic.append(route2)

    assert router._get("path", "GET", host='host') == (route, "handler", {})