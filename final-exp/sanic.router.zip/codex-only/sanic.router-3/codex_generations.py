

# Generated at 2022-06-24 04:35:06.346625
# Unit test for method finalize of class Router
def test_Router_finalize():
    routes = Router(label_suffix='')
    routes.add('/users/<id>', methods=['GET', 'POST', 'DELETE'], handler=None)
    routes.add('/users/<user_id>/journals/<journal_id>', methods=['GET', 'POST', 'DELETE'], handler=None)
    routes.finalize()

# Generated at 2022-06-24 04:35:17.317404
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    import pytest

    r = Router()
    r.add(uri='/',methods=['GET'],handler='handler')
    r.add(uri='/test{__param1}/{__param2}',methods=['GET'],handler='handler')
    r.finalize()

    #test case 1
    with pytest.raises(SanicException) as excinfo:
        r.add(uri='/test{___param1}/{___param2}',methods=['GET'],handler='handler')
        r.finalize()
    


# Generated at 2022-06-24 04:35:24.904235
# Unit test for method finalize of class Router
def test_Router_finalize():
    mlabels = {'__file_uri__': 'get-result'}
    b_dynamic_routes = {'get-result': ('get-result', Route(mlabels, "route", 'get-result', "regex-routes"))}
    is_finalized = True
    r = Router(is_finalized, b_dynamic_routes)
    try:
        r.finalize()
    except:
        assert False

# Generated at 2022-06-24 04:35:31.036704
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    route = Route(r, "", (), "", {}, {})
    route.labels.add("__file_uri__")
    r.dynamic_routes = {"": route}
    route.labels.add("__file")
    with pytest.raises(SanicException) as e:
        r.finalize()
    assert str(e.value) == "Invalid route: <GET / >. Parameter names cannot use '__'."

# Generated at 2022-06-24 04:35:36.816803
# Unit test for method add of class Router
def test_Router_add():
    from sanic.exceptions import NotFound
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.router import Router

    router = Router()
    router.add('/', ['GET'], lambda request: HTTPResponse(status=200))
    _, handler, _ = router.get('/', 'GET', '')
    assert handler(Request('GET', '/'))
    try:
        router.get('/', 'POST', '')
    except NotFound:
        pass
    else:
        assert False

    router = Router()
    router.add('/', ['GET'], lambda request: HTTPResponse(status=200))
    _, handler, _ = router.get('/', 'GET', '')

# Generated at 2022-06-24 04:35:46.896102
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    r = Router(None, [])

    assert len(r.routes_all) == 0
    assert len(r.routes_static) == 0
    assert len(r.routes_dynamic) == 0
    assert len(r.routes_regex) == 0

    # The following code is the most straight forward way to mock the
    # ROUTING_TABLE. It is not the most elegant way but it works.
    def add_route(*args, **kwargs):
        return Route(*args, **kwargs)

    #: 1
    r.add_route = add_route

# Generated at 2022-06-24 04:35:47.822609
# Unit test for constructor of class Router
def test_Router():
    R = Router()
    assert R is not None

# Generated at 2022-06-24 04:35:56.184135
# Unit test for method finalize of class Router
def test_Router_finalize():
    host = "foo.com"
    host_dyn = "bar.com"
    router = Router()
    router.add(
        uri='/hello/{name}',
        methods=["GET"],
        handler="test",
        host=host_dyn,
        unquote=False,
    )

    try:
        router.finalize()
    except SanicException as e:
        assert "Invalid route: " in str(e)
        assert " Parameter names cannot use '__'." in str(e)
    else:
        assert False, "sanic_routing.Router.finalize() should raise SanicException when using invalid parameter names."

# Generated at 2022-06-24 04:36:03.290496
# Unit test for method add of class Router
def test_Router_add():
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView

    from sanic.router import Route
    from sanic.exceptions import NotFound
    from sanic.exceptions import MethodNotSupported

    class BaseView(HTTPMethodView):
        def get(self, *args, **kwargs):
            return HTTPResponse(text="OK")

        def post(self, *args, **kwargs):
            return HTTPResponse(text="POST")

    router = Router()

    routes = router.add(
        uri="/test",
        methods=["GET", "POST"],
        handler=BaseView(),
        version=1.0,
        static=True,
    )

    assert isinstance(routes, list)

# Generated at 2022-06-24 04:36:03.810799
# Unit test for constructor of class Router
def test_Router():
    assert Router()


# Generated at 2022-06-24 04:36:04.463869
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    return router


# Generated at 2022-06-24 04:36:10.425110
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add("/test", ["GET", "POST"], lambda x, y, z: None)
    with pytest.raises(SanicException):
        router.finalize()

# Generated at 2022-06-24 04:36:15.951344
# Unit test for method finalize of class Router
def test_Router_finalize():
    with raises(SanicException):
        router = Router()
        route = Route(
            path="/v1/posts/<__file_uri__:int>",
            method="GET",
            handler=None,
            ctx=router.ctx,
        )
        router.add_route_dynamic(route)
        router.finalize()

Router.__test__ = False

# Generated at 2022-06-24 04:36:23.269701
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    assert isinstance(router, Router)
    # test for raise SanicException
    with pytest.raises(SanicException):
        uri = "/<__file_uri__:path>"
        router.add(uri, ["GET"], None)
        router.finalize()
    # test for not raise SanicException
    uri = "/<__file_uri__:path>"
    router.add(uri, ["GET"], None)
    router.finalize()

# Generated at 2022-06-24 04:36:35.020336
# Unit test for method add of class Router
def test_Router_add():
    import types
    # Note that in this testcase, the parameter 'method' should be of type
    #   Iterable[str].
    # The following code tests this.
    def test(method):
        if isinstance(method, Iterable):
            if any(isinstance(i, str) for i in method):
                return True
        return False
    assert test([]) == False
    assert test(1) == False
    assert test(1.1) == False
    assert test('a') == True
    assert test('1') == True
    assert test([1]) == False
    assert test([1.1]) == False
    assert test(['a']) == True
    assert test(['1']) == True
    assert test([1, 2]) == False
    assert test([1.1, 2.2]) == False
   

# Generated at 2022-06-24 04:36:37.814608
# Unit test for constructor of class Router
def test_Router():    
    c = Router()
    assert isinstance(c, Router)
    c = Router(None)
    assert isinstance(c, Router)

# Generated at 2022-06-24 04:36:45.557193
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_var = "str_var"
    sess = {}
    request = Mock(headers={}, session=sess)
    request.match_info = {}
    request.transport = None
    stream_writer_mock = Mock()
    request.transport.get_extra_info.return_value = stream_writer_mock
    request.app = Mock()
    request.app.router = Router(request.app)
    request.app.router.finalize()
    assert request.app.router.dynamic_routes == {}
    assert request.app.router.static_routes == {}
    assert request.app.router.regex_routes == {}
    assert request.app.router.name_index == {}
    assert request.app.router.ctx.app == request

# Generated at 2022-06-24 04:36:54.247064
# Unit test for method add of class Router

# Generated at 2022-06-24 04:36:55.623344
# Unit test for constructor of class Router
def test_Router():
    """
    Unit test for constructor of class Router
    """
    router = Router(None)
    assert router is not None

# Generated at 2022-06-24 04:37:03.194080
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.models.router import Router
    from sanic.models.route import Route
    from sanic.models.param import Param

    class MockRoute(Route):
        def __init__(self):
            super().__init__()
            self.labels = ['__file_uri__']

    mock_route = MockRoute()
    mock_router = Router()
    mock_router.routes.append(mock_route)

    mock_router.finalize()

# Generated at 2022-06-24 04:37:06.408773
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)

# Generated at 2022-06-24 04:37:15.700256
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    def add_route(labels, wrong_start=False):
        route = Mock()
        route.labels = labels
        if wrong_start:
            route.labels = [ '_' + l for l in labels ]
        router.dynamic_routes[labels[0]] = route
    #
    # happy path tests
    #
    # test for empty router
    router.finalize()
    # test for - one entry with no labels
    add_route([])
    router.finalize()
    # test for - one entry with one label
    add_route(['simple_label'])
    router.finalize()
    # test for - one entry with three labels
    add_route(['label', 'label2', 'label3'])
    router.finalize()
    # test

# Generated at 2022-06-24 04:37:20.682686
# Unit test for method add of class Router
def test_Router_add():
    from sanic.app import Sanic
    from sanic.response import json
    app = Sanic('Router_test')
    router = Router(Sanic)
    app.router = router
    async def handler1(request):
        return json({'hello': 'world'})
    router.add('/', methods=['GET'], host='127.0.0.1', handler=handler1)
    assert router.routes_dynamic['127.0.0.1']['GET'][0].name == None
    assert router.routes_dynamic['127.0.0.1']['GET'][0].uri == '/'
    assert router.routes_dynamic['127.0.0.1']['GET'][0].host == '127.0.0.1'

# Generated at 2022-06-24 04:37:31.607027
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    from sanic.router import Router
    from sanic.exceptions import SanicException

    app = Sanic('test_Router_finalize')
    router = Router(app)

    def handler1():
        return

    def handler2():
        return

    app.add_route(handler1, '/test/__{id}')
    router.finalize()

    app.add_route(handler2, '/test/_{id}')
    router.finalize()

    app.add_route(handler2, '/test/__{id}', name='test2')
    try:
        router.finalize()
    except SanicException as e:
        assert 'Invalid route: /test/__{id}' in str(e)
        assert 'Parameter names cannot use' in str(e)

# Generated at 2022-06-24 04:37:33.279884
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    r.add('/<name>')
    r.finalize()



# Generated at 2022-06-24 04:37:41.310227
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router._get == router.get
    assert isinstance(router.get, lru_cache)
    assert router.get.__doc__ is not None

    assert router.add.__doc__ is not None

    assert router.find_route_by_view_name == router._find_route_by_view_name

    assert router.routes_all == router.routes
    assert router.routes_static == router.static_routes
    assert router.routes_dynamic == router.dynamic_routes
    assert router.routes_regex == router.regex_routes
    assert router.finalize == router._finalize

# Generated at 2022-06-24 04:37:43.245607
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)

# Generated at 2022-06-24 04:37:47.312634
# Unit test for method add of class Router
def test_Router_add():
    def handler_func():
        return 'Some string'
    router = Router()
    router.add('/some_path', ['GET'], handler=handler_func, host='some_host')
    assert router.dynamic_routes['/some_path'].handler() == 'Some string'

# Generated at 2022-06-24 04:37:53.842235
# Unit test for constructor of class Router
def test_Router():
    from sanic.sanic import Sanic
    from sanic.response import text

    app = Sanic()

    @app.route('/')
    def handler(request):
        return text('OK')
    
    # Test if the routes are added to the router
    assert len(app.router.routes_all) == 1
    assert len(app.router.routes_static) == 0
    assert len(app.router.routes_dynamic) == 1
    assert len(app.router.routes_regex) == 1
    
    # Test if the dict fields are initialized

# Generated at 2022-06-24 04:37:56.801875
# Unit test for method add of class Router
def test_Router_add():
    route = Router().add("/index", [], None)
    assert isinstance(route, Route)
    assert route.name == None


# Generated at 2022-06-24 04:37:58.743721
# Unit test for constructor of class Router
def test_Router():

    router = Router(debug=True)
    assert router._debug

# Generated at 2022-06-24 04:38:09.960484
# Unit test for method add of class Router
def test_Router_add():
    test_Router = Router()
    test_path = '/'
    test_methods = 'GET'
    test_handler = 'hello world'
    test_host = ['127.0.0.1']
    test_strict_slashes = False
    test_stream = True
    test_ignore_body = False
    test_version = None
    test_name = None
    test_unquote = False
    test_static = False

    test_Router.add(test_path, test_methods, test_handler, test_host, test_strict_slashes, test_stream, test_ignore_body, test_version, test_name, test_unquote, test_static)
    assert test_Router.routes['/'].path == '/'

# Generated at 2022-06-24 04:38:19.005169
# Unit test for method add of class Router
def test_Router_add():
    from sanic import Sanic
    from sanic.request import Request

    app = Sanic()
    router = Router(app=app)

    async def handler_view(req: Request):
        return req

    async def handler_view_2(req: Request):
        return req

    router.add(uri="/", methods=["GET"], handler=handler_view)
    router.add(
        uri="/", methods=["GET"], handler=handler_view_2, strict_slashes=True
    )
    router.add(uri="/", methods=["GET"], handler=handler_view, host="test")
    router.add(
        uri="/", methods=["GET"], handler=handler_view, host=["test", "test2"]
    )

# Generated at 2022-06-24 04:38:20.255689
# Unit test for constructor of class Router
def test_Router():
    Router({"__file_url__",})


# Generated at 2022-06-24 04:38:21.475890
# Unit test for constructor of class Router
def test_Router():
    route = Router()
    assert route.name_index == {}


# Generated at 2022-06-24 04:38:22.512207
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert type(router) == Router

# Generated at 2022-06-24 04:38:23.448784
# Unit test for method finalize of class Router
def test_Router_finalize():
    # This method is covered by test_routes_decorator
    pass

# Generated at 2022-06-24 04:38:30.713552
# Unit test for method add of class Router
def test_Router_add():
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import NotFound
    from sanic.models.handler_types import RouteHandler
    from sanic.request import Request
    from sanic.router import Router

    router = Router()

    async def u(x):
        return

    router.add(
        uri='/test',
        methods=['GET'],
        handler=u,
        host=None,
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version=None,
        name=None,
        unquote=False,
        static=False,
    )

# Generated at 2022-06-24 04:38:33.220775
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        _test_Router_finalize()
    except Exception as e:
        print("Exception in test_Router_finalize")
        print("type(e): ", type(e))
        print("dir(e): ", dir(e))
        print("e: ", e)
        print("e.args: ", e.args)
        raise


# Generated at 2022-06-24 04:38:38.933241
# Unit test for method add of class Router
def test_Router_add():
    from sanic.response import text
    from sanic.server import HttpProtocol
    from sanic.testing import HOST, PORT

    def create_app(loop):
        app = Sanic("test_sanic")
        routes = Router.add(app, uri="/test/<vararg>", methods=["GET", "POST"],
                            handler=text("test"))
        HttpProtocol(app, loop=loop, host=HOST, port=PORT).create_server()
        return app

    @pytest.mark.unit
    @pytest.mark.asyncio
    async def test_routing_static_file(loop):
        app = create_app(loop)

# Generated at 2022-06-24 04:38:41.648164
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    route = None
    methods = []
    handler = None
    print(router.add(route, methods, handler))



# Generated at 2022-06-24 04:38:46.643258
# Unit test for constructor of class Router
def test_Router():

    r = Router(ctx=None)
    
    assert r.dynamic_routes is not None
    assert r.regex_routes is not None
    assert r.static_routes is not None


# Generated at 2022-06-24 04:38:52.804258
# Unit test for method add of class Router
def test_Router_add():
    # Arrange
    router = Router()

    def handler():
        return None

    # Act
    route = router.add("/", methods=["GET"], handler=handler)

    # Assert
    assert route.ctx.default_method == "GET"
    assert route.ctx.ignore_body is False
    assert route.ctx.stream is False
    assert route.ctx.hosts is None
    assert route.ctx.static is False


# Generated at 2022-06-24 04:38:55.129675
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add("/users/<id>", methods=["GET", "POST"], handler=None)
    with pytest.raises(SanicException):
        router.finalize()

# Generated at 2022-06-24 04:39:06.830997
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    uri = "/"
    methods = ["GET"]
    handler = lambda request: "function"
    host = None
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = None
    unquote = False
    static = False
    #Testing for correct parameters
    router.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)
    #Testing for wrong parameters
    wrong_methods = [1, "str"]
    wrong_methods = ["GET", 1]
    try:
        router.add(uri, wrong_methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)
    except TypeError:
        pass


# Generated at 2022-06-24 04:39:07.483312
# Unit test for constructor of class Router
def test_Router():
    pass

# Generated at 2022-06-24 04:39:12.145642
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add(uri="/add", methods=['GET', 'POST'], handler="handler")
    assert router.routes_static["/add"].uri == "/add"
    assert router.routes_static["/add"].methods == ['GET', 'POST']
    assert router.routes_static["/add"].handler == "handler"


# Generated at 2022-06-24 04:39:14.467589
# Unit test for constructor of class Router
def test_Router():

    routes = Router(ctx=None)
    assert routes.routes_all == {}


# Generated at 2022-06-24 04:39:24.875350
# Unit test for method add of class Router
def test_Router_add():
    from typing import Dict
    from sanic.router import Router
    from sanic.response import text
    import pdb
    import sys
    from pprint import pprint
    from inspect import getmembers
    from inspect import getfullargspec
    from inspect import signature
    from inspect import ismethod
    from pprint import pprint
    from typing import List
    from typing import Dict
    from typing import Any
    from typing import Union

    # Make a test environment
    class App:
        _generate_name = lambda self,x:x

    # Make a test object -- this is the class being tested
    router = Router(App())

    # Make a test object
    # repr(x)
    # dir(x)
    # callable(x)
    # instance of (isinstance)
    # inherits from (issub

# Generated at 2022-06-24 04:39:25.388668
# Unit test for constructor of class Router
def test_Router():
    assert Router()

# Generated at 2022-06-24 04:39:34.059944
# Unit test for method add of class Router
def test_Router_add():
    from sanic.app import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView

    app = Sanic()
    router = Router()

    class InvalidRoute(HTTPMethodView):
        def get(self, request):
            return "OK"

        def __repr__(self):
            return "InvalidRoute"

    class InvalidRoutes(HTTPMethodView):
        routes = ["/url/with/initial/slash/and/ending/slash/", "/missing/ending/slash"]

        def get(self, request):
            return "OK"

    @app.route("/url/")
    async def handler_with_json_output(request):
        return {"hello": "world"}



# Generated at 2022-06-24 04:39:38.486855
# Unit test for method add of class Router
def test_Router_add():
    # Arrange
    router = Router()
    uri = 'uri'
    methods = ('methods',)
    handler = 'handler'

    # Act
    actual = router.add(uri, methods, handler)
    # Assert
    assert actual.path == uri
    assert actual.handler == handler
    assert actual.methods == methods


# Generated at 2022-06-24 04:39:48.632501
# Unit test for method finalize of class Router
def test_Router_finalize():
    import unittest

    def m():
        pass


# Generated at 2022-06-24 04:39:50.369598
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert(router.get_last_route() == None)
    assert(router.lookup_route("GET","/test") == None)

# Generated at 2022-06-24 04:39:58.793910
# Unit test for method add of class Router
def test_Router_add():
    from sanic import Sanic
    from sanic.response import text
    app = Sanic()
    router = Router(app, {})
    router.add("/", ("GET", "POST"))
    app = Sanic()
    router = Router(app, {"strict_slashes": True})
    router.add("/b", ("GET", "POST"))
    app = Sanic()
    router = Router(app, {"strict_slashes": False})
    router.add("/c", ("GET", "POST"))
    router.add("/d", ("GET", "POST"), host="d.example.org")
    router.add("/e", ("GET", "POST"), host=["e1.example.org", "e2.example.org"])

# Generated at 2022-06-24 04:40:01.608916
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router


# Generated at 2022-06-24 04:40:06.759773
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic_routing import Router as R
    r = Router()
    r.add('/', {'GET'}, lambda r: None)
    try:
        r.finalize({})
    except SanicException:
        assert False

    r = R()
    r.add('/<__file_uri__>', {'GET'}, lambda r: None)
    r.finalize({})

# Generated at 2022-06-24 04:40:15.727809
# Unit test for method add of class Router
def test_Router_add():
    @asynccontextmanager
    async def asynccontextmanager_mock(*args, **kwargs):
        yield args[0]

    class aiohttp_request_mock:
        class app:
            class websocket_handlers:
                get = (
                    'method',
                    'path',
                    'handler',
                    'unquote',
                    'strict_slashes',
                    'resources',
                    'name',
                )
        match_info = 'match_info'

    class aiohttp_web_response_mock:
        def __init__(self, *args, **kwargs):
            self.status = kwargs.get('status_code', None)
            self.headers = {'content-type': 'application/json'}


# Generated at 2022-06-24 04:40:18.625393
# Unit test for method add of class Router
def test_Router_add():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse

    app = Sanic()

    router = Router(app=app)

    async def test_handler(request):
        return HTTPResponse(status=200)

    router.add('/test', ['GET', 'HEAD'], test_handler)

    request, response = app.test_client.get('/test')

    assert response.status == 200

# Generated at 2022-06-24 04:40:29.560297
# Unit test for method add of class Router
def test_Router_add():
    router = Router()

    def handler(request, foo=None, bar=None):
        return foo, bar

    route = router.add("/foo/<bar>/<foo>", ["GET", "POST"], handler)

    assert route.path == '/foo/<bar>/<foo>'
    assert route.name is None
    assert route.methods == ["GET", "POST"]
    assert route.handler is handler
    assert route.ctx.static is False
    assert route.ctx.hosts == [None]
    assert route.ctx.ignore_body is False
    assert route.ctx.stream is False
    assert route.ctx.version is None
    assert route.ctx.strict_slashes is False
    assert route.ctx.unquote is False


# Generated at 2022-06-24 04:40:34.173854
# Unit test for constructor of class Router
def test_Router():
    route = Route('/test',RouteHandler)
    router = Router()
    router.routes_all.append(route)
    assert router.routes_all == [route]


# Generated at 2022-06-24 04:40:37.166299
# Unit test for method add of class Router
def test_Router_add():
    pass


# Generated at 2022-06-24 04:40:42.522415
# Unit test for method add of class Router
def test_Router_add():
    class DummyRouter(Router):
        def __init__(self):
            super().__init__()
            self.routes = []

        def add(self, **kwargs):
            self.routes.append(kwargs)
            return kwargs

    router = DummyRouter()

    router.add(
        uri="",
        methods=["POST"],
        handler="handler_1",
        host="host_1",
        strict_slashes=False,
        stream=True,
        ignore_body=True,
        version="version_1",
        name="name_1",
        unquote=True,
        static=True,
    )

# Generated at 2022-06-24 04:40:49.489846
# Unit test for method add of class Router
def test_Router_add():

    def test_func(uri,methods,handler,host,strict_slashes,stream,ignore_body,version,name,unquote,static):
        r = Router()
        r.add(uri,methods,handler,host,strict_slashes,stream,ignore_body,version,name,unquote,static)

    #Test 1 (reached=True)
    uri = "hello"
    methods = ["POST"]
    handler = None
    host = "http://127.0.0.1:8000"
    strict_slashes = True
    stream = True
    ignore_body = True
    version = "1.0"
    name = "yo"
    unquote = True
    static = False


# Generated at 2022-06-24 04:40:56.002090
# Unit test for constructor of class Router
def test_Router():
    test_router = Router()
    assert isinstance(test_router, Router)

    assert isinstance(test_router.DEFAULT_METHOD, str)
    assert test_router.DEFAULT_METHOD == 'GET'

    for method in test_router.ALLOWED_METHODS:
        assert isinstance(method, str)
        assert method.isupper()



# Generated at 2022-06-24 04:41:03.743543
# Unit test for method add of class Router
def test_Router_add():
    import sanic

    app= sanic.Sanic()
    app.add_route(lambda request: None, "/route/1",method="POST")
    assert len(app.router.routes_all) == 1
    app.add_route(lambda request: None, "/route/2",method=["POST","GET"])
    assert len(app.router.routes_all) == 2

    # Unit test for method find_route_by_view_name of class Router
    app.add_route(lambda request: None, "route_1",method="POST",name="route_1")
    route = app.router.find_route_by_view_name('route_1')
    assert route.name == 'route_1'


# Generated at 2022-06-24 04:41:06.715371
# Unit test for method finalize of class Router
def test_Router_finalize():
    def func():
        pass
    route = Route('/test/{name}', func)
    route.context = {'name': 'name'}
    route.labels = ['__name__']
    route.handler = {
        'test' : 'test'
    }
    router = Router(None)
    router.dynamic_routes.update({
        'test' : route
    })
    router.finalize()

# Generated at 2022-06-24 04:41:08.096863
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    print(router.routes_all)


# Generated at 2022-06-24 04:41:11.794154
# Unit test for constructor of class Router
def test_Router():
    # Initialization
    router = Router()
    # Checking type of object
    assert type(router) == Router
    # Checking basic property
    assert router.ctx.app == None


# Generated at 2022-06-24 04:41:12.281814
# Unit test for method finalize of class Router
def test_Router_finalize():
    _ = Router()

# Generated at 2022-06-24 04:41:21.054599
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    from sanic_routing.router import Router

    router = Router()
    router.routes_dynamic = {
        0: Route(path="/", handler=None, methods=['GET'], name=None, \
            strict=False, unquote=False, requirements={}, ctx={})
    }
    router.routes_dynamic[0].labels = ['__file_uri__', '__test__']
    with pytest.raises(SanicException):
        router.finalize()

    router.routes_dynamic[0].labels = ['test']
    router.finalize()

# Generated at 2022-06-24 04:41:33.034827
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic, response
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.router import Router
    from sanic.exceptions import SanicException

    app = Sanic("test_sanic")

    @app.get("/")
    async def handler(request):
        return HTTPResponse(status=200, body="OK")

    @app.route("/<name>")
    async def handler_two(request, name):
        return HTTPResponse(status=200, body="OK")

    @app.route("/<__name>")
    async def handler_three(request, __name):
        return HTTPResponse(status=200, body="OK")


# Generated at 2022-06-24 04:41:43.970698
# Unit test for method add of class Router
def test_Router_add():
    from sanic.app import Sanic
    from sanic.response import json
    app = Sanic(name='add')

    # router test 1
    @app.route('/hello/')
    async def hello(request):
        return json({"hello": "world"})

    # router test 2
    @app.route('/hello/<name>')
    async def hello_name(request, name):
        return json({"hello": name})

    # router test 3
    @app.route('/hello/<name:string>')
    async def hello_name_string(request, name):
        return json({"hello": name})

    # router test 4

# Generated at 2022-06-24 04:41:48.668267
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    router.DEFAULT_METHOD = 'GET'
    assert router.DEFAULT_METHOD == 'GET'
    assert router.ALLOWED_METHODS == HTTP_METHODS


# Generated at 2022-06-24 04:41:56.975875
# Unit test for method finalize of class Router
def test_Router_finalize():
    import os
    import shutil
    import sys
    import tempfile
    from nose.tools import assert_raises, assert_true, nottest

    from sanic.router import Router
    
    @nottest
    def create_file(path):
        with open(path, "w") as f:
            f.write("")

    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # Create sample package
    package_dir = os.path.join(tmp_dir, "package")
    os.mkdir(package_dir)
    create_file(os.path.join(package_dir, "__init__.py"))

    # Create sample module
    module_path = os.path.join(package_dir, "module.py")
    create_file(module_path)

    #

# Generated at 2022-06-24 04:42:06.750618
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    router._method_map
    router._method_regex
    router._dynamic_routes
    router._static_routes
    router._regex_routes
    router._name_index
    router.ctx
    router.resolve
    router.add
    router.get
    router.finalize
    router.find_route_by_view_name
    router.routes_all
    router.routes_static
    router.routes_dynamic
    router.routes_regex

if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-24 04:42:16.850095
# Unit test for constructor of class Router
def test_Router():
    # test for validation
    router = Router()
    try:
        router = Router(strict_slashes=True)
    except TypeError:
        assert False
    except:
        assert True
    try:
        router = Router(strict_slashes=True, host_matching=True)
    except TypeError:
        assert False
    except:
        assert True
    # test for initialization
    try:
        router = Router(strict_slashes=True, host_matching=True, versioning=True)
    except TypeError:
        assert False
    except:
        assert True
    try:
        router = Router(strict_slashes=True, host_matching=True, versioning=False)
    except TypeError:
        assert True
    except:
        assert False

# Generated at 2022-06-24 04:42:17.644514
# Unit test for constructor of class Router
def test_Router():
    assert Router()

# Generated at 2022-06-24 04:42:21.270077
# Unit test for constructor of class Router
def test_Router():
    assert issubclass(Router, BaseRouter)
    assert Router.DEFAULT_METHOD == 'GET'
    assert Router.ALLOWED_METHODS == HTTP_METHODS
    router = Router(server_name='', host_name=None)
    assert isinstance(router, BaseRouter)


# Generated at 2022-06-24 04:42:26.436340
# Unit test for method add of class Router
def test_Router_add():
    handler = lambda x: x
    router = Router()
    router.add('/', methods=['GET'], handler=handler, strict_slashes=False, stream=False, ignore_body=False, version=None, name=None, unquote=False, static=False)
    assert isinstance(router, Router)
    assert router.routes_all['/'].handler == handler


# Generated at 2022-06-24 04:42:28.045473
# Unit test for constructor of class Router
def test_Router():
    Router()


# Generated at 2022-06-24 04:42:36.514068
# Unit test for method add of class Router
def test_Router_add():
    from sanic.router import Router
    from sanic.testing import SanicTestClient
    app = Sanic("sanic-router-test")

    def handler_function(request):
        return text("OK")
    app.router.add("/", ["GET","POST"], handler_function)

    @app.route("/abc")
    def handler_function(request):
        return text("OK")

    request, response = SanicTestClient(app).get("/")
    assert response.status == 200
    assert response.text == 'OK'



# Generated at 2022-06-24 04:42:41.842018
# Unit test for method add of class Router
def test_Router_add():
    request_methods = ["GET", "POST", "OPTIONS"]
    def handler():
        return "I am a handler"
    router = Router(True)
    for method in request_methods:
        route = router.add(
            "/api/v1/products",
            [method],
            handler
        )
        assert method in route.methods
    assert len(router.routes) == 3

# Generated at 2022-06-24 04:42:51.380020
# Unit test for method add of class Router
def test_Router_add():
    route = Route(
        path="/hello",
        methods=["GET"],
        name="hello",
        strict=False,
        unquote=False,
        handler=RouteHandler,
    )
    router = Router()
    router.add(
        uri="/hello",
        methods=["GET", "POST", "OPTIONS"],
        handler=RouteHandler,
        host=None,
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version=None,
        name="hello",
        unquote=False,
        static=False,
    )
    assert route.path.get() == router.routes_all["hello"].path.get()

# Generated at 2022-06-24 04:42:55.397032
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.response import HTTPResponse
    router = Router(None)
    class DummyHandler:
        async def __call__(self, request, *args, **kwargs):
            return HTTPResponse(body="Hello")

    router.add("/get", ["GET"], DummyHandler())
    router.finalize()
    assert True


# Generated at 2022-06-24 04:43:06.560465
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    This test tests the method
        - finalize of class Router
    """
    router = Router()

    from sanic.router import Route
    router.add(
        uri='/test1',
        methods=["GET", ],
        handler=lambda: None,
        name='test1',
        strict_slashes=True
    )


# Generated at 2022-06-24 04:43:10.970850
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add(uri='/user/<name>',methods=['GET'],handler='class_name.func_name')
    router.finalize()

# Generated at 2022-06-24 04:43:15.510422
# Unit test for constructor of class Router
def test_Router():
    r = Router()


# Generated at 2022-06-24 04:43:18.745451
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    uri = "/"
    methods = ["GET", "POST"]
    handler = lambda : None
    router.add(uri=uri, methods=methods, handler=handler)


# Generated at 2022-06-24 04:43:21.671422
# Unit test for method finalize of class Router
def test_Router_finalize():
  try:
    Router.finalize({})
    assert False
  except SanicException:
    assert True


# Generated at 2022-06-24 04:43:29.708278
# Unit test for method add of class Router
def test_Router_add():
    from sanic.constants import HTTP_METHODS
    from sanic.exceptions import MethodNotSupported
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.router import Router
    from sanic.views import CompositionView

    from sanic.handlers import ErrorHandler
    from sanic.views import CompositionView

    from sanic.wrappers import RequestParameters

    import _pickle

    r = Router()


# Generated at 2022-06-24 04:43:39.366716
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic_routing.router import Router as T
    from sanic.app import Sanic
    from contextlib import redirect_stdout
    app = Sanic("Sanic")
    x = T(app)
    x.add("/<var>", ["GET"], lambda r,var: 'Hello World')
    x.finalize()
    routes = [r for r in x.routes_dynamic.values() if "var" in str(r)]
    assert len(routes) == 1
    assert routes[0].uri == '/<var>'
    assert routes[0].labels == ("var",)
    assert routes[0].uri_template == '/{var}'
    x.add("/<var>", ["GET"], lambda r,var: 'Hello World')

# Generated at 2022-06-24 04:43:46.412448
# Unit test for method add of class Router
def test_Router_add():
	router = Router()
	uri = '/path'
	methods = ['GET', 'POST', 'OPTIONS']
	handler = 'handler'
	host = None
	strict_slashes = False
	stream = False
	ignore_body = False
	version = '1'
	name = 'name'
	unquote = False
	static = False
	result = router.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)
	assert isinstance(result, list)
	assert len(result) == 1
	assert isinstance(result[0], Route)
	assert isinstance(result[0].ctx.ignore_body, bool)
	assert isinstance(result[0].ctx.stream, bool)

# Generated at 2022-06-24 04:43:47.526395
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-24 04:43:51.657242
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    route = router.add("/test", ["GET"], lambda request: ...)
    assert route.methods == ["GET"]
    assert route.path == "/test"

# Generated at 2022-06-24 04:43:59.519617
# Unit test for method add of class Router
def test_Router_add():
    # Setup
    router = Router()
    class test_handler:
        def __init__(self):
            pass
    handler = test_handler()
    uri = "/test_uri/"
    methods = "GET"
    host = "test_host.com"
    strict_slashes = True
    stream = True
    ignore_body = True
    version = 1
    name = "test_name"
    unquote = True

    # Exercise
    # Assert we are getting a Route route object

# Generated at 2022-06-24 04:44:02.387690
# Unit test for constructor of class Router
def test_Router():
    router = Router(ctx=None)

    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []

# Generated at 2022-06-24 04:44:08.863824
# Unit test for constructor of class Router
def test_Router():
    uri = '/user1'
    methods = 'POST'
    handler = 'handler_user'
    host = '192.168.1.1'
    strict_slashes = False
    stream = False
    ignore_body = False
    version = '1.1'
    name = 'name'
    unquote = True
    static = True
    r = Router()
    t = type(r)
    if t.__name__ == 'Router':
        print('test_Router ok')
    else:
        print('test_Router error')



# Generated at 2022-06-24 04:44:18.361650
# Unit test for method add of class Router
def test_Router_add():
    from sanic.router import Router
    from sanic.response import json
    import json as jsonlib
    async def async_handler(request):
        return json({"result": "ok"})
    def sync_handler(request):
        return json({"result": "ok"})
    router = Router()
    router.add(
        uri="/",
        methods=["POST"],
        handler=async_handler,
        host="sanic.com",
        strict_slashes=True,
        stream=False,
        ignore_body=False,
        version="1.0",
        name="root",
        unquote=False,
        static=False,
    )
    assert isinstance(router.routes_all, dict)
    assert isinstance(router.routes_static, dict)


# Generated at 2022-06-24 04:44:28.606747
# Unit test for method add of class Router
def test_Router_add():
    def hello(*args, **kwargs):
        return (args, kwargs)

    router = Router()
    router.add(uri='/', methods=['GET'], handler=hello)

    # check type of router
    assert isinstance(router, Router)

    # check type of router._router_tree
    assert isinstance(router._router_tree, Router)

    # check type of router.routes_all
    assert isinstance(router.routes_all, dict)

    # check type of router.routes_static
    assert isinstance(router.routes_static, dict)

    # check type of router.routes_dynamic
    assert isinstance(router.routes_dynamic, dict)

    # check type of router.routes_regex


# Generated at 2022-06-24 04:44:31.385433
# Unit test for constructor of class Router
def test_Router():
    assert Router.ALLOWED_METHODS == HTTP_METHODS
    assert Router.DEFAULT_METHOD == "GET"


if __name__ == '__main__':
    print(test_Router.__doc__)
    test_Router()
    print('ok')

# Generated at 2022-06-24 04:44:39.194471
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    from sanic.exceptions import SanicException
    from sanic.utils import sanic_endpoint_test

    def test_dynamic_routes_1():
        r = Router(context=Sanic("test_dynamic_routes_1"))
        r.add(uri="/test/<name>", methods=("GET",), handler="Hello", name="test")
        r.finalize()

    def test_dynamic_routes_2():
        r = Router(context=Sanic("test_dynamic_routes_2"))
        r.add(uri="/test/<name__file_uri__>", methods=("GET",), handler="Hello", name="test")
        r.finalize()


# Generated at 2022-06-24 04:44:40.304407
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert type(router) == Router


# Generated at 2022-06-24 04:44:41.765455
# Unit test for constructor of class Router
def test_Router():
    """
    Test for constructor of class Router
    """
    router = Router()
    assert router is not None

# Generated at 2022-06-24 04:44:44.701424
# Unit test for constructor of class Router
def test_Router():
    assert Router()


# Generated at 2022-06-24 04:44:50.727013
# Unit test for constructor of class Router
def test_Router():
    router = Router(None)
    assert isinstance(router.routes, dict)
    assert isinstance(router.routes_all, dict)
    assert isinstance(router.routes_dynamic, dict)
    assert isinstance(router.routes_static, dict)
    assert isinstance(router.routes_regex, dict)
    assert isinstance(router.name_index, dict)



# Generated at 2022-06-24 04:44:55.742672
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add(uri="123", methods=["GET"], handler="333")


# Generated at 2022-06-24 04:45:00.238322
# Unit test for method add of class Router
def test_Router_add():
    def handler():
        pass

    router = Router()
    router.add('/', ["GET"], handler)
    
    assert len(router.dynamic_routes) == 1
