

# Generated at 2022-06-12 09:26:05.893892
# Unit test for method add of class Router
def test_Router_add():
    uri = "/test/sanic"
    methods = ["GET", "POST", "OPTIONS"]
    handler = RouteHandler
    host = "localhost"
    strict_slashes = False
    stream = False
    ignore_body = False
    version = 8
    name = "test_Router_add"
    unquote = False
    static = True

    class test_Router(Router):
        pass

    router = test_Router()

# Generated at 2022-06-12 09:26:10.909100
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Create a fake file URI
    class FileURI:
        def __init__(self, path, name=None):
            self.path = path
            self.uri = path
            self.name = name
            self.parameters = dict()
            self.labels = dict()

    # Create a fake route object
    class Route:
        def __init__(self, path, name):
            self.path = path
            self.uri = FileURI(path, name)
            self.parameters = dict()
            self.labels = dict()
            self.ctx = dict()

    # Create a fake app object
    class App:
        def _generate_name(self, label):
            return label

    # Create a fake Tree object

# Generated at 2022-06-12 09:26:17.193777
# Unit test for method finalize of class Router
def test_Router_finalize():
    def test_handler():
        pass
    router = Router()
    router.add('/test', ['GET'], test_handler)
    assert router.routes_static
    with pytest.raises(SanicException) as exc_info:
        router.finalize()
    assert str(exc_info.value) == "Invalid route: /test. Parameter names cannot use '__'."
    router.add('/test/<__user_id>/', ['GET'], test_handler)
    assert router.finalize()


# Generated at 2022-06-12 09:26:22.447518
# Unit test for method finalize of class Router
def test_Router_finalize():
    route = Route(path='/', handler=None, methods=['GET'])
    route.labels.update({'__file_uri__': '/'})
    route.labels.update({'invalid_label': '/'})
    router = Router()
    router.dynamic_routes['/'] = route
    try:
        router.finalize()
    except SanicException:
        assert True

# Generated at 2022-06-12 09:26:26.009174
# Unit test for constructor of class Router
def test_Router():
    """
    >>> router = Router()
    >>> router.get("/", "GET", "www.test.com") #doctest: +ELLIPSIS
    Traceback (most recent call last):
    ...
    sanic.exceptions.NotFound: Requested URL None not found
    """


# Generated at 2022-06-12 09:26:29.017947
# Unit test for constructor of class Router
def test_Router():
    router = Router()

    assert router.DEFAULT_METHOD == 'GET'
    assert router.ALLOWED_METHODS == ['HEAD', 'GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS']

# Generated at 2022-06-12 09:26:30.115933
# Unit test for constructor of class Router
def test_Router():
    assert isinstance(Router(), BaseRouter)


# Generated at 2022-06-12 09:26:36.847475
# Unit test for method finalize of class Router
def test_Router_finalize():
    # 1. testing when raising exception 'Invalid route: route. Parameter names cannot use '__'.'
    route = Route("/", None, ["a", "__a"], None, None)
    r = Router()
    r.dynamic_routes = {'/': route}
    with pytest.raises(SanicException):
        r.finalize("")
    # 2. testing when not raising exception
    route = Route("/", None, ["a", "__a"], None, None)
    r = Router()
    r.dynamic_routes = {'/': route}
    r.finalize("")



# Generated at 2022-06-12 09:26:40.488678
# Unit test for constructor of class Router
def test_Router():
    # Test
    router = Router()
    assert router
    assert router.routes == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.ctx is None


# Generated at 2022-06-12 09:26:49.100012
# Unit test for method finalize of class Router
def test_Router_finalize():
    import sanic
    r = Router()
    r.dynamic_routes.update(
        {
            0: Route(
                path="/test/<__file_uri__:path>",
                labels=["__file_uri__"],
                methods={"GET"},
            ),
            1: Route(path="/test/<invalid>", labels=["invalid"], methods={"GET"})
        }
    )
    try:
        r.finalize(app=sanic.Sanic())
    except SanicException as e:
        assert e.args[0] == "Invalid route: Route(/test/<invalid>) (GET). Parameter names cannot use '__'."

# Generated at 2022-06-12 09:26:55.125144
# Unit test for method add of class Router
def test_Router_add():
    pass

# Generated at 2022-06-12 09:26:55.973633
# Unit test for constructor of class Router
def test_Router():
    router = Router()


# Generated at 2022-06-12 09:26:57.962358
# Unit test for constructor of class Router
def test_Router():
    try:
        router = Router()
        assert isinstance(router, BaseRouter)
    except Exception:
        assert False


# Generated at 2022-06-12 09:27:03.339806
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router(None)

    route = Route("/test/<label>", None, None)
    route.labels = ["label", "__route_uri__", "__file_uri__"]
    router.dynamic_routes["/test/<label>"] = route

    with pytest.raises(SanicException, match="Invalid route: .+ Parameter names cannot use '__'."):
        router.finalize()

# Generated at 2022-06-12 09:27:03.870121
# Unit test for constructor of class Router
def test_Router():
    a = Router()

# Generated at 2022-06-12 09:27:05.308110
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)

# Generated at 2022-06-12 09:27:06.355199
# Unit test for constructor of class Router
def test_Router():
    r1 = Router()
    assert isinstance(r1, Router)

# Generated at 2022-06-12 09:27:08.531759
# Unit test for constructor of class Router
def test_Router():
    # Instantiation of a Router object
    test_router = Router()
    # Asserting instantiation
    assert type(test_router) == Router


# Generated at 2022-06-12 09:27:12.622608
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    unit test for method finalize of class Router,
    """
    router = Router()
    router.dynamic_routes = {
        '__file_uri__': Route(
            path="/<__file_uri__>",
            handler=None,
            methods=['GET'],
            strict=False,
            unquote=False,
            requirements={},
        )
    }
    try:
        router.finalize()
    except:
        raise Exception("The method of finalize of class Router is not work well!")

# Generated at 2022-06-12 09:27:14.064910
# Unit test for constructor of class Router
def test_Router():
    pass # To be implemented or nothing to test()

# Unit tests for method Router.get()

# Generated at 2022-06-12 09:27:31.025125
# Unit test for constructor of class Router
def test_Router():
    from sanic import Sanic
    from sanic_routing import RoutingException
    from sanic_routing.route import Route

    app = Sanic("test_Router")

    router = Router(app)

    @app.route("/")
    async def handler(request):
        return response.text("OK")

    assert router.routes_all == {
        ("GET", "/"): Route("GET", "/", handler),
    }

    assert router.routes_dynamic == {
        ("GET", "/"): Route("GET", "/", handler),
    }

    assert router.routes_static == {}

    assert router.routes_regex == {}


# Generated at 2022-06-12 09:27:35.143566
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    try:
        with pytest.raises(SanicException) as e_info:
            r.finalize()
        assert e_info.value.__str__() == "Invalid route: <GET / >. Parameter names cannot use '__'."
    except Exception as e:
        pytest.fail(f"Raised exception {e} while not expecting an exception")


# Generated at 2022-06-12 09:27:36.008660
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r

# Generated at 2022-06-12 09:27:44.444265
# Unit test for constructor of class Router
def test_Router():
    """
    This function is used to test the constructor of class Router
    """
    from sanic.app import Sanic
    from sanic.router import Router
    from sanic_routing import Route

    app = Sanic("test")
    router = Router(app=app)

    # The __init__ method of the class Router should return a router object
    assert isinstance(router, Router)
    assert isinstance(router, BaseRouter)
    assert isinstance(router, Sanic)
    # The router should have default attributes
    assert router.routes_all == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.routes_static == {}
    assert router.name_index == {}
    assert router.ctx.app == app

# Generated at 2022-06-12 09:27:50.913406
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    assert r.routes_dynamic == {}
    assert r.routes_regex == {}
    assert r.routes_all == []
    assert r.routes_static == []
    with pytest.raises(SanicException):
        r.add("/test/<__test>", ["GET"], "handler")
        r.finalize()
    # clean
    r.routes_dynamic.clear()
    r.routes_regex.clear()
    r.routes_all.clear()
    r.routes_static.clear()
    r.add("/test/<__file_uri__:uri>", ["GET"], "handler")
    r.finalize()



# Generated at 2022-06-12 09:27:53.756586
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    app = Sanic()
    try:
        Router.finalize(app=app)
    except Exception as e:
        raise e

# Generated at 2022-06-12 09:28:02.791183
# Unit test for method finalize of class Router
def test_Router_finalize():
    _globals = {}
    _locals = {"__name__": "__name__"}

    def _inject_globals_locals(global_vars, local_vars):
        _globals.update(global_vars)
        _locals.update(local_vars)


# Generated at 2022-06-12 09:28:05.933502
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        router = Router()
        router.add(uri="test", methods=["GET"], handler=None)
        print("Test passed.")
        return True
    except SanicException as e:
        print(str(e))
        return False

if __name__ == "__main__":
    test_Router_finalize()

# Generated at 2022-06-12 09:28:12.029187
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    app = Sanic(__name__)
    router = Router(app)
    try:
        router.add(
            uri="/test",
            methods=["GET"],
            handler=None,
            host=None,
            strict_slashes=False,
            stream=False,
            ignore_body=False,
            version=None,
            name=None,
            unquote=False,
            static=False,
        )
        router.finalize()
    except Exception as e:
        print(e.args)


# Generated at 2022-06-12 09:28:14.761492
# Unit test for method finalize of class Router
def test_Router_finalize():
    route = Route('myserver.com/user/<id:int>/<name:str>', route_class=Router)
    with pytest.raises(SanicException):
        route.finalize()


# Generated at 2022-06-12 09:28:28.369286
# Unit test for constructor of class Router
def test_Router():
    """<class 'sanic.router.Router'>"""
    t = Router()
    assert isinstance(t, Router)
    assert isinstance(t, BaseRouter)
    assert t.DEFAULT_METHOD == "GET"
    assert t.ALLOWED_METHODS == HTTP_METHODS

# Generated at 2022-06-12 09:28:31.474582
# Unit test for constructor of class Router
def test_Router():
    assert Router.DEFAULT_METHOD == "GET"
    assert Router.ALLOWED_METHODS == HTTP_METHODS
    router = Router()
    assert router is not None

# Generated at 2022-06-12 09:28:32.812305
# Unit test for constructor of class Router
def test_Router():
    route=Router()
    assert(isinstance(route,Router))

# Generated at 2022-06-12 09:28:33.648772
# Unit test for constructor of class Router
def test_Router():
    assert True


# Generated at 2022-06-12 09:28:34.890706
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router,Router)

# Generated at 2022-06-12 09:28:36.464420
# Unit test for constructor of class Router
def test_Router():
    router = Router(None)
    assert isinstance(router,Router)


# Generated at 2022-06-12 09:28:44.643099
# Unit test for constructor of class Router
def test_Router():
    from sanic.request import Request

    from sanic.response import HTTPResponse, json

    def test_route(request):
        return HTTPResponse({'status': 200})

    router = Router(Router.DEFAULT_METHOD, Router.ALLOWED_METHODS, {}, [])
    assert isinstance(router, Router)
    assert isinstance(router.routes_all, dict)
    assert isinstance(router.routes_static, dict)
    assert isinstance(router.routes_dynamic, dict)
    assert isinstance(router.routes_regex, dict)
    router.add('/', ('GET', 'POST'), test_route)
    assert isinstance(router.dynamic_routes.get('/'), Route)
    route = router

# Generated at 2022-06-12 09:28:46.414342
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert(router)
    assert(router.DEFAULT_METHOD == "GET")


# Generated at 2022-06-12 09:28:48.472036
# Unit test for constructor of class Router
def test_Router():
    # Teste with no arguments
    router = Router()
    assert router



# Generated at 2022-06-12 09:28:49.357819
# Unit test for constructor of class Router
def test_Router():
    router = Router()

# Generated at 2022-06-12 09:29:11.524309
# Unit test for constructor of class Router
def test_Router():
    from sanic.constants import HTTP_METHODS
    from sanic.router import Router
    from sanic.model.handler_types import RouteHandler
    router = Router()
    assert isinstance(router.dynamic_routes, dict)
    assert isinstance(router.static_routes, dict)
    assert isinstance(router.regex_routes, dict)
    assert isinstance(router.name_index, dict)
    assert isinstance(router.routes, list)
    assert router.DEFAULT_METHOD == "GET"
    assert sorted(router.ALLOWED_METHODS) == sorted(HTTP_METHODS)


# Generated at 2022-06-12 09:29:12.636309
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    print(r)


# Generated at 2022-06-12 09:29:14.736198
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.DEFAULT_METHOD == "GET"



# Generated at 2022-06-12 09:29:16.440702
# Unit test for constructor of class Router
def test_Router():
    a = str(Router())
    b = str(Router(name="home"))
    assert a == b

# Generated at 2022-06-12 09:29:23.328892
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == []
    assert router.routes_regex == []
    assert router.ctx.app == None
    assert router.ctx.static_url == None
    assert router.ctx.static_root == None
    assert router.ctx.static_strict_slashes == None
    assert router.ctx.default_unquote == True
    assert router.ctx.default_strict_slashes == False
    assert router.ctx.default_method == "GET"


# Generated at 2022-06-12 09:29:24.215597
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert type(router) == Router


# Generated at 2022-06-12 09:29:25.109509
# Unit test for constructor of class Router
def test_Router():
    router=Router()
    assert len(router.routes_all)==0

# Generated at 2022-06-12 09:29:25.854597
# Unit test for constructor of class Router
def test_Router():
  r = Router()


# Generated at 2022-06-12 09:29:29.258381
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert len(router.routes) == 0
    assert len(router.static_routes) == 0
    assert len(router.dynamic_routes) == 0
    assert len(router.regex_routes) == 0


# Generated at 2022-06-12 09:29:30.043236
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None

# Generated at 2022-06-12 09:30:01.056810
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.routes_static == {}

# Generated at 2022-06-12 09:30:06.363527
# Unit test for method add of class Router
def test_Router_add():
    class __FakeApp(object):
        def __init__(self):
            self.router = Router(self)
            self.router.static(
                self,
                '/test/route/path',
            )
            self.router.add(
                '/test/route/path',
                ['GET', 'POST'],
                lambda : 'some route_handler',
            )
    app = __FakeApp()
    assert app.router.routes_all
    assert app.router.routes_static
    assert app.router.routes_dynamic
    assert app.router.routes_regex

# Generated at 2022-06-12 09:30:06.762744
# Unit test for constructor of class Router
def test_Router():
  pass

# Generated at 2022-06-12 09:30:11.557979
# Unit test for constructor of class Router
def test_Router():
    uri = '/'
    method = ['GET']
    handler = 'Sanic'
    host = None
    strict_slashes = False
    stream = False
    ignore_body = False
    version = 1.0
    name = "Sanic"
    unquote = False
    static = False

    r = Router()
    route = r.add(uri, method, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)
    assert route

# Generated at 2022-06-12 09:30:14.170248
# Unit test for constructor of class Router
def test_Router():
    # Test case 1: Define a Router object
    router = Router()
    result = router.__class__.__name__
    expected = 'Router'

    assert result == expected


# Generated at 2022-06-12 09:30:20.011897
# Unit test for constructor of class Router
def test_Router():
    router = Router(
        static_root_url=None, static_root=None, static_url_path=None,
        host_matching=False, app=None, constants=None
    )

    assert router.app is None
    assert router.dynamic_routes == {}
    assert router.name_index == {}
    assert router.regex_routes == {}
    assert router.routes == []
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.static_routes == {}



# Generated at 2022-06-12 09:30:21.289199
# Unit test for constructor of class Router
def test_Router():
    rst = Router()
    assert 'sanic_routing.router' in rst.__module__


# Generated at 2022-06-12 09:30:22.249911
# Unit test for constructor of class Router
def test_Router():
    assert isinstance(Router(), Router)

# Generated at 2022-06-12 09:30:24.515155
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert(r.DEFAULT_METHOD == "GET")
    assert(r.ALLOWED_METHODS == HTTP_METHODS)

# Test _get method of class Router

# Generated at 2022-06-12 09:30:25.255491
# Unit test for constructor of class Router
def test_Router():
    router = Router()


# Generated at 2022-06-12 09:31:22.190533
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None

# Generated at 2022-06-12 09:31:23.997831
# Unit test for constructor of class Router
def test_Router():
    r=Router()
    r.get("/test")
    assert 1, "test_Router passed"


# Generated at 2022-06-12 09:31:28.423545
# Unit test for constructor of class Router
def test_Router():
    # Asserts for default values for class Router
    router = Router()
    assert router._allowed_methods == HTTP_METHODS
    assert router._default_method == "GET"

    # Asserts for default values for class Router
    router = Router(allowed_methods=["GET", "POST", "PUT", "DELETE"], default_method="GET")
    assert router.allowed_methods == ["GET", "POST", "PUT", "DELETE"]
    assert router.default_method == "GET"



# Generated at 2022-06-12 09:31:33.655243
# Unit test for constructor of class Router
def test_Router():
    uri = "/relative-uri"
    methods = ["POST", "GET"]
    handler = RouteHandler()
    host = "http://localhost"
    strict_slashes = False
    stream = False
    ignore_body = False
    version = "1.0"
    name = "test-route"
    unquote = False

    # Test with valid value for all parameters
    try:
        test_router = Router()
        test_router.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote)
    except Exception:
        assert False

    # Test with uri = "/"

# Generated at 2022-06-12 09:31:38.613978
# Unit test for constructor of class Router
def test_Router():
    MyRouter = Router()
    assert isinstance(MyRouter, BaseRouter) # Checking if it is a subclass of BaseRouter
    assert MyRouter.DEFAULT_METHOD == "GET" # Checking the default method
    assert len(MyRouter.ALLOWED_METHODS) == 15 # Checking number of allowed methods
    assert len(MyRouter.ALLOWED_METHODS) != 14 # Checking number of allowed methods
    assert len(MyRouter.ALLOWED_METHODS) != 16 # Checking number of allowed methods


# Generated at 2022-06-12 09:31:39.574792
# Unit test for constructor of class Router
def test_Router():
    router = Router(app=None, prefix=None, routes=None, labels=None)

# Generated at 2022-06-12 09:31:42.786789
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.cache_size == ROUTER_CACHE_SIZE
    assert router.routes == {}
    assert router.routes_all == router.routes
    assert router.routes_static == router.static_routes
    assert router.routes_dynamic == router.dynamic_routes
    assert router.routes_regex == router.regex_routes


# Generated at 2022-06-12 09:31:43.348501
# Unit test for constructor of class Router
def test_Router():
    assert isinstance(Router(), Router) is True

# Generated at 2022-06-12 09:31:50.948113
# Unit test for constructor of class Router
def test_Router():
    import unittest
    from unittest.mock import create_autospec

    class test_RouterMethods(unittest.TestCase):
        def test_fail_on_double_add(self):
            with self.assertRaises(ValueError):
                r = Router()
                setattr(r.dynamic_routes, 'test', 'test')

        def test_fail_mismatch_add(self):
            with self.assertRaises(ValueError):
                r = Router()
                setattr(r, 'test', 'test')

    class test_RouterAttributes(unittest.TestCase):
        def test_default_method(self):
            r = Router()
            self.assertEqual(r.DEFAULT_METHOD, 'GET')


# Generated at 2022-06-12 09:31:52.080871
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert isinstance(r, Router)


# Generated at 2022-06-12 09:33:47.273205
# Unit test for constructor of class Router
def test_Router():
    try:
        Router()
    except Exception as err:
        assert False
    else:
        assert True

# Generated at 2022-06-12 09:33:52.924527
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "HEAD"]
    assert router.routes_all == {}
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []
    assert router.ctx == router
    assert router.name_index == {}
    assert router.routes == []


# Generated at 2022-06-12 09:33:53.942049
# Unit test for constructor of class Router
def test_Router():
    assert Router().__class__.__name__ == 'Router'

# Generated at 2022-06-12 09:33:55.069307
# Unit test for constructor of class Router
def test_Router():
    router = Router(None)
    assert isinstance(router, Router)

# Generated at 2022-06-12 09:33:57.288424
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.ctx.app is None
    router = Router(None)
    assert router.ctx.app is None
    assert isinstance(router, Router)


# Generated at 2022-06-12 09:33:59.542579
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)
    assert hasattr(router, "DEFAULT_METHOD")
    assert hasattr(router, "ALLOWED_METHODS")


# Generated at 2022-06-12 09:34:02.088972
# Unit test for constructor of class Router
def test_Router():
    router = Router(None)
    assert router.DEFAULT_METHOD == 'GET'
    assert router.ALLOWED_METHODS == ['HEAD', 'OPTIONS', 'GET', 'PUT', 'PATCH', 'POST', 'DELETE']

# Generated at 2022-06-12 09:34:03.318364
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes == {}
    assert router.routes_all == {}

# Generated at 2022-06-12 09:34:06.494491
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.default_method == "GET"
    assert router.allowed_methods == HTTP_METHODS
    assert router.ctx.app is None


# Unit tests for method _get of class Router

# Generated at 2022-06-12 09:34:07.993885
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
