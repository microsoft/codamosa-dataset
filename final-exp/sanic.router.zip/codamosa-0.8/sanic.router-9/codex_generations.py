

# Generated at 2022-06-12 09:25:52.023265
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.ctx.app == None
    assert router.ctx.router == None



# Generated at 2022-06-12 09:25:56.738993
# Unit test for constructor of class Router
def test_Router():
    test_router = Router()
    assert test_router.DEFAULT_METHOD == "GET"
    assert test_router.ALLOWED_METHODS == ["OPTIONS", "GET", "POST", "PUT", "PATCH", "DELETE", "HEAD"]


# Generated at 2022-06-12 09:25:58.507144
# Unit test for constructor of class Router
def test_Router():

    r = Router()
    assert isinstance(r,Router)

    assert isinstance(r.routes,dict)



# Generated at 2022-06-12 09:26:00.856141
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert type(router) == Router


# Generated at 2022-06-12 09:26:03.243101
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    app = Sanic()
    router = Router()
    with pytest.raises(SanicException):
        router.finalize(app)

# Generated at 2022-06-12 09:26:04.587283
# Unit test for constructor of class Router
def test_Router():
    router = Router(None)
    assert isinstance(router, Router)



# Generated at 2022-06-12 09:26:05.315391
# Unit test for method finalize of class Router
def test_Router_finalize():
    pass

# Generated at 2022-06-12 09:26:06.036264
# Unit test for constructor of class Router
def test_Router():
    assert Router('Router')


# Generated at 2022-06-12 09:26:09.338210
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route(
        "/path/{__param1}/{param2}",
        "GET",
        lambda: None,
        host="example.com",
        name="route",
        strict_slashes=False,
        unquote=True,
    )

    router.dynamic_routes["route"] = route

    try:
        router.finalize()
    except SanicException:
        return True
    else:
        return False

# Generated at 2022-06-12 09:26:18.442653
# Unit test for method finalize of class Router
def test_Router_finalize():
    @pytest.fixture(scope="function")
    def Router_class(mocker):
        from sanic.router import Router
        return Router

    @pytest.fixture(scope="function")
    def route(mocker):
        route_mock = mocker.Mock()
        route_mock.labels = ["__foo__", "__bar__"]
        return route_mock

    @pytest.fixture(scope="function")
    def dynamic_routes(mocker):
        dynamic_routes = mocker.Mock()
        dynamic_routes.values = mocker.Mock(return_value=[route])
        return dynamic_routes

    @pytest.fixture(scope="function")
    def dynamic_routes_dict(mocker):
        dynamic_rout

# Generated at 2022-06-12 09:26:24.185116
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert type(router)==Router


# Generated at 2022-06-12 09:26:26.628256
# Unit test for constructor of class Router
def test_Router():
    assert hasattr(Router, 'DEFAULT_METHOD')
    assert hasattr(Router, 'ALLOWED_METHODS')
    route = Router()
    assert(isinstance(route, Router))

# Generated at 2022-06-12 09:26:28.441170
# Unit test for constructor of class Router
def test_Router():
    t = Router()
    assert type(t) == Router and isinstance(t, Router)


# Generated at 2022-06-12 09:26:34.347218
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic_routing.route import Route

    router = Router()
    route = Route()
    route.labels = ["__file_uri__", "__some_label__"]

    assert router.finalize(route) == None

    route.labels = ["__file_uri__", "__some_label__"]
    try:
        router.finalize(route)
    except SanicException as e:
        assert str(e) == f"Invalid route: {route}. Parameter names cannot use '__'."

if __name__ == "__main__":
    test_Router_finalize()
    print("Everything passed")

# Generated at 2022-06-12 09:26:35.422004
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None


# Generated at 2022-06-12 09:26:42.091512
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router
    assert router.ctx.app is None
    assert router.ctx.router is router
    assert router.ctx.method is None
    assert router.ctx.url is None
    assert router.ctx.path is None
    assert router.ctx.query_string is None
    assert router.ctx.body is None
    assert router.ctx.headers is None
    assert router.ctx.raw_headers is None
    assert router.ctx.components is None
    assert router.ctx.arguments is None
    assert router.ctx.match_info is None
    assert router.ctx.host is None

# Generated at 2022-06-12 09:26:42.776452
# Unit test for constructor of class Router
def test_Router():
    # This should not raise an exception
    router = Router()

# Generated at 2022-06-12 09:26:43.629052
# Unit test for constructor of class Router
def test_Router():
    assert callable(Router)

# Generated at 2022-06-12 09:26:50.172643
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.app import Sanic
    import pytest

    app = Sanic(__name__)
    router = Router(app)

    with pytest.raises(SanicException):
        router.dynamic('/users/<id>', dict(labels={'__fake__': 'hi'}))
        router.finalize()

if __name__ == "__main__":
    test_Router_finalize()

# Generated at 2022-06-12 09:26:52.726385
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.ctx.app is None


# Generated at 2022-06-12 09:27:02.738220
# Unit test for constructor of class Router
def test_Router():
    assert Router().__class__.__name__ == "Router"

# Generated at 2022-06-12 09:27:05.070772
# Unit test for constructor of class Router
def test_Router():
  testR = Router()
  assert testR.DEFAULT_METHOD == 'GET'
  assert testR.ALLOWED_METHODS == HTTP_METHODS


# Generated at 2022-06-12 09:27:06.148464
# Unit test for method add of class Router
def test_Router_add():
    pass
    # TODO: Write this unit test
    # assert False, "Not implemented"

# Generated at 2022-06-12 09:27:10.504851
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route(name="route", path="route", labels=[], handler="handler")
    router.dynamic_routes["route"] = route
    assert isinstance(router.finalize(), None)



# Generated at 2022-06-12 09:27:14.439670
# Unit test for method finalize of class Router
def test_Router_finalize():
    route = Route("/foo/{bar}", None)
    route.labels = ["foo", "bar"]
    routes_dynamic = {route.path:route}
    router = Router()
    router.dynamic_routes = routes_dynamic
    try:
        router.finalize()
        assert False
    except SanicException:
        assert True

# Generated at 2022-06-12 09:27:15.252947
# Unit test for method finalize of class Router
def test_Router_finalize():
    pass

# Generated at 2022-06-12 09:27:19.757600
# Unit test for method finalize of class Router
def test_Router_finalize():
    def handler():
        pass

    router = Router()

    route = router.add(uri='/handler', methods=('POST',), handler=handler)
    with pytest.raises(SanicException):
        router.finalize()
    
    route.labels.add('__file_uri__')
    router.finalize()
    assert True


# Generated at 2022-06-12 09:27:21.899088
# Unit test for method finalize of class Router
def test_Router_finalize():
    app = Mock(name='app')
    router = Router(app)
    with pytest.raises(SanicException):
        router.finalize()


# Generated at 2022-06-12 09:27:23.568649
# Unit test for constructor of class Router
def test_Router():
    # type: () -> None

    Router()

if __name__ == '__main__':
    test_Router()

# Generated at 2022-06-12 09:27:31.752755
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes == {}
    assert router.routes_all == router.routes
    assert router.routes_static == router.static_routes
    assert router.routes_dynamic == router.dynamic_routes
    assert router.routes_regex == router.regex_routes

    def async_get(request):
        return "Asynchronous!"

    def sync_get(request):
        return "Synchronous!"

    router.add("/async", [], async_get)
    router.add("/sync", ["GET"], sync_get)

    assert len(router.dynamic_routes) == 2
    assert router.dynamic_routes["GET"][0].uri == "/async"
    assert router.d

# Generated at 2022-06-12 09:27:50.356170
# Unit test for constructor of class Router
def test_Router():
    pass

# Generated at 2022-06-12 09:27:59.043787
# Unit test for method finalize of class Router
def test_Router_finalize():
    #given
    dynamic_routes = {
        'hello': 'hello',
        '__file_uri__': '__file_uri__',
        '__values__': '__values__',
        '__global__': '__global__',
    }

    with patch('sanic.router.Router.dynamic_routes', dynamic_routes):
        #when
        try:
            Router().finalize()
        #then
        except Exception as error:
            assert type(error).__name__ == 'SanicException'
            assert error.args[0] == 'Invalid route: __global__. Parameter names cannot use \'__\'.'



# Generated at 2022-06-12 09:28:03.751823
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r.default_method == "GET"
    assert r.allowed_methods == HTTP_METHODS
    assert r.trailing_slash == False
    assert r.strict_slashes == False
    assert r.name_index == {}
    assert r.routes_all == []
    assert r.routes_static == []
    assert r.routes_dynamic == {}
    assert r.routes_regex == []

# Generated at 2022-06-12 09:28:04.436905
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router


# Generated at 2022-06-12 09:28:08.834621
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        router = Router()
        router.dynamic_routes["test"] = Route(
            "test", lambda request: "test", ["GET"], "test", {"test": "test"}
        )
        router.finalize()
    except SanicException as e:
        assert str(e) == f"Invalid route: {router.dynamic_routes['test']}. Parameter names cannot use '__'."
    else:
        assert False

# Generated at 2022-06-12 09:28:17.644611
# Unit test for method add of class Router
def test_Router_add():
    import types
    import asyncio
    loop = asyncio.get_event_loop()
    router = Router()
    def handler():
        pass
    async def async_handler():
        pass
    types_handler = types.FunctionType(handler.__code__, {})

    uri = '/r'
    meths = ['GET']
    # test handler is not callable
    handler = 1
    try:
        router.add(uri, meths, handler)
    except ValueError:
        pass
    else:
        raise AssertionError('Failed to raise ValueError if handler is not callable')

    # test handler is callable
    handler = async_handler
    route = router.add(uri, meths, handler)
    assert route.path == uri
    for m in meths:
        assert m in route

# Generated at 2022-06-12 09:28:21.632316
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Setting up the environment for testing
    import sys
    import tempfile
    sys.path.insert(0, tempfile.mkdtemp())
    router = Router()
    # Run method to test
    try:
        router.finalize()
    except:
        # Verify if the method raises no exception
        raise AssertionError()
    else:
        # Verify if the method finishes the execution succesfully
        assert True

# Generated at 2022-06-12 09:28:29.013701
# Unit test for method finalize of class Router
def test_Router_finalize():
    class TestRouter(Router):
        def finalize(self, *args, **kwargs):
            pass

    import pytest
    with pytest.raises(SanicException):
        TestRouter().add(
            uri="/",
            methods=["GET"],
            handler=lambda: "",
            name="__test_name__"
        )

    with pytest.raises(SanicException):
        TestRouter().add(
            uri="/",
            methods=["GET"],
            handler=lambda __test_name__: "",
            name="__test_name__"
        )


# Generated at 2022-06-12 09:28:32.853750
# Unit test for constructor of class Router
def test_Router():
    class app:
        def _generate_name(value):
            return value
        pass

    router = Router('app', 'name_index')
    assert router.ctx == app
    assert router.name_index == 'name_index'

# Generated at 2022-06-12 09:28:35.863529
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.ctx.app is None
    assert router.ctx.router == router


# Generated at 2022-06-12 09:29:12.560510
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r.DEFAULT_METHOD == 'GET'
    assert r.ALLOWED_METHODS == ['CONNECT', 'DELETE', 'GET', 'HEAD', 'OPTIONS', 'PATCH', 'POST', 'PUT', 'TRACE']


# Generated at 2022-06-12 09:29:13.676292
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert isinstance(r, BaseRouter)


# Generated at 2022-06-12 09:29:22.466486
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    from sanic.app import Config
    from sanic.response import json, HTTPResponse
    from sanic.router import Router as unitRouter
    from sanic.router import Route
    from sanic.router import RouteHandler
    from unittest.mock import MagicMock

    sanic_app = Sanic(__name__)
    sanic_app.config = MagicMock(spec=Config, autospec=True)
    sanic_app.config.REQUEST_MAX_SIZE = 10 * 1024 * 1024
    sanic_app.config.REQUEST_TIMEOUT = 60.0
    sanic_app.config.KEEP_ALIVE = True
    sanic_app.config.KEEP_ALIVE_TIMEOUT = 5
    sanic_app.config.RE

# Generated at 2022-06-12 09:29:23.905548
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    with pytest.raises(SanicException):
        router.finalize()

# Generated at 2022-06-12 09:29:27.416265
# Unit test for method finalize of class Router
def test_Router_finalize():
    # if any(label.startswith("__") and label not in ALLOWED_LABELS for label in route.labels)
    # raise SanicException("Invalid route: {route}. Parameter names cannot use '__'.")
    method = Router.finalize(Router)
    try:
        method()
    except Exception:
        return True
    return False


# Generated at 2022-06-12 09:29:30.428852
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert (router.DEFAULT_METHOD=="GET")
    assert (router.ALLOWED_METHODS==['HEAD', 'OPTIONS', 'GET', 'POST', 'DELETE', 'PUT', 'PATCH', 'TRACE'])

# Generated at 2022-06-12 09:29:38.335441
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest

    route = Route(
        path="/test",
        methods=["GET"],
        handler=None,
        name="test",
        strict=False,
        unquote=False,
    )
    router = Router([route])

    with pytest.raises(
        SanicException,
        match="Invalid route: Route({path: '/test', methods: ['GET'], handler: None, name: 'test', strict: False, unquote: False, ctx: RouteContext({'ignore_body': False, 'static': False, 'stream': False, 'hosts': [None]})}). Parameter names cannot use '__'.",
    ):
        router.finalize()



# Generated at 2022-06-12 09:29:38.767587
# Unit test for constructor of class Router
def test_Router():
    pass


# Generated at 2022-06-12 09:29:39.775523
# Unit test for constructor of class Router
def test_Router():
    router = Router()


# Generated at 2022-06-12 09:29:42.595529
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-12 09:30:51.995219
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r.ctx == {"app": None}
    assert r.routes == []

# Generated at 2022-06-12 09:30:55.694909
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    # Test for basic case (no label)
    router.add("/test/<label>", ["GET"], lambda request: "", "localhost")
    # Test for "__" label
    router.add(
        "/<__file_uri__>", ["GET"], lambda request: "", "localhost"
    )
    router.finalize()

    # Test for invalid label
    router.add("/<__label>", ["GET"], lambda request: "", "localhost")
    try:
        router.finalize()
    except SanicException as e:
        assert "Invalid route" in e.__str__()

# Generated at 2022-06-12 09:31:00.995462
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r.ALLOWED_METHODS == HTTP_METHODS
    assert r.DEFAULT_METHOD == "GET"
    assert r.routes == []
    assert r.regex_routes == []
    assert r.static_routes == []
    assert r.dynamic_routes == {}
    assert r.ctx == None


# Generated at 2022-06-12 09:31:02.867044
# Unit test for constructor of class Router
def test_Router():
    new_route = Router()
    assert isinstance(new_route, Router)

if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-12 09:31:03.312451
# Unit test for constructor of class Router
def test_Router():
    router = Router()

# Generated at 2022-06-12 09:31:05.170883
# Unit test for constructor of class Router
def test_Router():
    try:
        Router()
    except Exception as exc:
        # If constructor raises an exception, this unit test has failed
        assert False

# Generated at 2022-06-12 09:31:08.707671
# Unit test for method finalize of class Router
def test_Router_finalize():
    my_router = Router()
    my_router.add("/{{ url }}", None, None, None, False, False, False, None, None)

    with pytest.raises(SanicException) as logger:
        my_router.finalize()

    assert "Invalid route" in str(logger.value)

# Generated at 2022-06-12 09:31:14.864053
# Unit test for method finalize of class Router
def test_Router_finalize():
    router=Router()
    route1=Route("/<test 123>",handler=None,methods=None,name="test_route")
    try:
        router.dynamic_routes["test"] = route1
        router.finalize()
    except:
        assert 1
    route2=Route("/<test>",handler=None,methods=None,name="test_route")
    router.dynamic_routes["test"] = route2
    try:
        router.finalize()
    except:
        assert 0


# Generated at 2022-06-12 09:31:15.358627
# Unit test for constructor of class Router
def test_Router():
    assert Router

# Generated at 2022-06-12 09:31:16.402473
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert type(router) == Router


# Generated at 2022-06-12 09:33:28.494863
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert isinstance(r, BaseRouter)


# Generated at 2022-06-12 09:33:38.079842
# Unit test for method add of class Router
def test_Router_add():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.blueprints import Blueprint

    app = Sanic("test_add_router")
    bp = Blueprint("test_bp")

    # Test when we add a handler
    @app.get("/test1")
    def handler1(request: Request):
        return HTTPResponse()

    # Test when we add a blueprint
    @bp.get("/test2")
    def handler2(request: Request):
        return HTTPResponse()

    app.blueprint(bp)

    # Test when we add a list of methods
    app.add_route(lambda r: HTTPResponse(), "/test3", ["GET", "POST"])

    router = app.router


# Generated at 2022-06-12 09:33:38.742585
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router



# Generated at 2022-06-12 09:33:40.011770
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router
    assert type(router) == Router
    assert type(router.DEFAULT_METHOD) == str


# Generated at 2022-06-12 09:33:40.712873
# Unit test for constructor of class Router
def test_Router():
    assert Router() is None


# Generated at 2022-06-12 09:33:44.210118
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r.allowed_methods == HTTP_METHODS
    assert r.default_method == 'GET'
    assert isinstance(r.DEFAULT_METHOD, str)
    assert isinstance(r.ALLOWED_METHODS, tuple)
    assert isinstance(r.DEFAULT_METHOD, str)

# Generated at 2022-06-12 09:33:49.388010
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.constants import SANIC_VERSION
    from sanic.request import Request
    from sanic.response import HTTPResponse

    from sanic.router import Router
    from sanic.websocket import WebSocketProtocol
    from sanic.views import CompositionView

    async def handler(request, *args, **kwargs):
        return HTTPResponse()

    async def handler_websocket(request, *args, **kwargs):
        raise NotImplementedError()


    @CompositionView.template("index.html")
    async def handler_template(request, *args, **kwargs):
        return {"template_var": "test"}

    router = Router()


# Generated at 2022-06-12 09:33:56.777226
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    This function Unit test for method finalize of class Router
    """
    from sanic.app import Sanic
    from sanic.router import Router
    from sanic.server import HttpProtocol
    from sanic.exceptions import SanicException
    from sanic.response import text
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol

    # This is the decorator used to register a handler
    # in the test function below.
    def route(uri, *args, **kwargs):
        def decorator(f):
            nonlocal app
            app.route(uri, *args, **kwargs)(f)
            return f

        return decorator

    app = Sanic("test_Router_finalize")


# Generated at 2022-06-12 09:33:57.511468
# Unit test for constructor of class Router
def test_Router():
    assert str(Router()) == '<Router>'

# Generated at 2022-06-12 09:34:04.236378
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route("/foo", None, 'bar')
    route.ctx.labels = ['__param1__']
    router._register_dynamic_route(route)
    with pytest.raises(SanicException): router.finalize()
    route.ctx.labels = ['__param1__', '__param2__']
    with pytest.raises(SanicException): router.finalize()
    route.ctx.labels = ['__param1__', '__file_uri__', '__param2__']
    router.finalize()
    route.ctx.labels = ['__param1__', '__param2__', '__file_uri__']
    router.finalize()