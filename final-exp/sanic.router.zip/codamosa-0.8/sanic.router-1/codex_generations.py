

# Generated at 2022-06-12 09:25:42.215679
# Unit test for constructor of class Router
def test_Router():
    new_Router = Router()
    assert new_Router is not None

# Generated at 2022-06-12 09:25:43.246669
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router
    return router


# Generated at 2022-06-12 09:25:46.760126
# Unit test for constructor of class Router
def test_Router():
    assert issubclass(Router, BaseRouter)
    assert Router.__basicsize__ == ctypes.sizeof(ctypes.c_void_p)
    assert Router.__itemsize__ == 1
    assert Router.DEFAULT_METHOD == "GET"
    assert isinstance(Router.ALLOWED_METHODS , list)


# Generated at 2022-06-12 09:25:48.805753
# Unit test for method finalize of class Router
def test_Router_finalize():
    def _():
        router = Router()
        router.add("/test/<test_id>", methods=["GET"], handler=lambda: None)
        router.finalize()
    _()


# Generated at 2022-06-12 09:25:49.813004
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)

# Generated at 2022-06-12 09:25:59.741561
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    from sanic.response import text
    # test with route param invalid name
    app = Sanic()
    router = app.router

    @app.route("/<__invalid_name>")
    async def test(request, __invalid_name):
        return text("OK")

    with pytest.raises(SanicException):
        router.finalize()

    # test with route param valid name
    router = app.router

    @app.route("/<__file_uri__>")
    async def test(request, __file_uri__):
        return text("OK")

    router.finalize()
    request, _ = app.test_client.get("/test")
    assert request.url == "http://localhost/test"

# Generated at 2022-06-12 09:26:04.589360
# Unit test for constructor of class Router
def test_Router():
    router = Router()

    assert router
    assert hasattr(router, 'DEFAULT_METHOD')
    assert hasattr(router, 'ALLOWED_METHODS')
    assert hasattr(router, '_get')
    assert hasattr(router, 'get')
    assert hasattr(router, 'add')
    assert hasattr(router, 'find_route_by_view_name')


# Generated at 2022-06-12 09:26:06.545458
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add(uri='/', methods=["GET"], handler=lambda request: "ok")

    assert len(router.routes_all) == 1


# Generated at 2022-06-12 09:26:15.897604
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    r = Router()

# Generated at 2022-06-12 09:26:19.846758
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []
    assert router.name_index == {}



# Generated at 2022-06-12 09:26:32.081892
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router._get(path="/", method="GET", host="0.0.0.0") == (Route, RouteHandler, {})
    assert router._get(path="/", method="GET", host="0.0.0.0") == (Route, RouteHandler, {})
    assert router._get(path="/", method="GET", host="0.0.0.0") == (Route, RouteHandler, {})
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.routes_all == {}

# Generated at 2022-06-12 09:26:32.464458
# Unit test for method finalize of class Router
def test_Router_finalize():
    assert True

# Generated at 2022-06-12 09:26:34.876305
# Unit test for constructor of class Router
def test_Router():
    # Arrange
    r = Router()

    # Assert
    assert r.DEFAULT_METHOD == 'GET'
    assert r.ALLOWED_METHODS == ['GET', 'HEAD', 'POST', 'PUT', 'DELETE', 'OPTIONS', 'PATCH', 'TRACE']



# Generated at 2022-06-12 09:26:41.657752
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Should raise a SanicException
    try:
        base_router = BaseRouter()
        base_router.dynamic_routes = {'route': {}}
        base_router.finalize()
        raise Exception("No exception raised")
    except SanicException as e:
        assert "Invalid route: " in str(e)
    
    # Should not raise any exception
    base_router = BaseRouter()
    base_router.dynamic_routes = {'route': {'labels': ['__labels__']}}
    base_router.finalize()

# Generated at 2022-06-12 09:26:51.927348
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    from sanic.router import Router
    from sanic.exceptions import SanicException

    @pytest.fixture
    def router():
        return Router()

    @pytest.fixture
    def handler():
        pass


# Generated at 2022-06-12 09:26:56.966208
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        router = Router()
        router.add('/hello/<user>', ['GET', 'POST'])
        router.add('/hello/<firstname>/<lastname>', ['GET', 'POST'])
        router.finalize('http://example.com')
    except SanicException as e:
        assert(e)
    else:
        assert False

# Generated at 2022-06-12 09:26:58.424976
# Unit test for constructor of class Router
def test_Router():
    
    router = Router()
    assert isinstance(router,Router)

# Generated at 2022-06-12 09:27:07.425890
# Unit test for method add of class Router
def test_Router_add():
    from uuid import uuid4
    from sanic import Sanic
    from sanic.response import text

    app = Sanic("test_Router_add")
    app.router = Router(app)
    method = str(uuid4())
    uri = str(uuid4())
    handler = text("test_Router_add")

    app.router.add(uri=uri, methods=[method], handler=handler)
    routes = app.router.routes_all
    len(routes).should.equal(1)
    routes[0].ctx.stream.should.equal(False)
    routes[0].ctx.ignore_body.should.equal(False)
    routes[0].ctx.hosts.should.equal([None])


# Generated at 2022-06-12 09:27:08.766937
# Unit test for constructor of class Router
def test_Router():
    assert issubclass(Router, BaseRouter)
    assert Router.DEFAULT_METHOD == 'GET'
    assert Router.ALLOWED_METHODS == HTTP_METHODS


# Generated at 2022-06-12 09:27:09.793762
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-12 09:27:16.937391
# Unit test for constructor of class Router
def test_Router():
    @Router.route("/test")
    def route():
        return

    assert str(Router.routes[0]) == "Route(path='/test', handler='route', methods=['GET'], strict=False)"


# Generated at 2022-06-12 09:27:17.892304
# Unit test for constructor of class Router
def test_Router():
    assert Router().__doc__ is not None

# Generated at 2022-06-12 09:27:24.710767
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest

    for route in ["__file_uri__", "__file_uri__/z", "z/__file_uri__"]:
        router = Router(app=None)
        route = router.add("/" + route + "/<file:path>", ["GET"], None)
        router.finalize()
        assert route.labels == ('file',)

    with pytest.raises(SanicException):
        router = Router(app=None)
        route = router.add("/__home/url/<file:path>", ["GET"], None)
        router.finalize()

# Generated at 2022-06-12 09:27:25.909446
# Unit test for constructor of class Router
def test_Router():
    a = Router()
    assert isinstance(a, BaseRouter)



# Generated at 2022-06-12 09:27:29.411274
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == []
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == []
    assert router.get_routes_with_requirements() == {}


# Generated at 2022-06-12 09:27:31.134583
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS

# Generated at 2022-06-12 09:27:32.226422
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert isinstance(r, BaseRouter)

# Generated at 2022-06-12 09:27:38.984167
# Unit test for constructor of class Router
def test_Router():
    import pytest
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    import asyncio

    app = Sanic("test_Router")
    router = Router.get_instance(app)
    assert isinstance(router, Router)

    @app.route("/")
    async def handler(request: Request) -> HTTPResponse:
        return HTTPResponse(status=200)

    request = Request.blank("/", method="GET")
    response = router.get_response(request)
    assert response is not None



# Generated at 2022-06-12 09:27:41.332222
# Unit test for constructor of class Router
def test_Router():
    print("Testing Router")
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS


# Generated at 2022-06-12 09:27:49.052957
# Unit test for constructor of class Router
def test_Router():
    # Initialized router
    router = Router()

    # Test add() method
    # Test condition: add one route
    @router.add('/', methods=['GET'])
    def handler_1():
        pass
    
    # Test condition: add multiple routes
    @router.add('/index', methods=['GET'])
    @router.add('/test', methods=['GET'])
    def handler_2():
        pass
    
    # Test get() method
    # Test condition: successful get
    assert router.get('/', 'GET', None) == (router.resolve('/', 'GET', {'host': None}))

    # Test condition: get failure
    try:
        router.get('/', 'POST', None)
    except NotFound as e:
        assert str(e)

# Generated at 2022-06-12 09:27:58.492787
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-12 09:28:04.906081
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.ctx is None
    assert router.default_method is None
    assert router.allowed_methods == HTTP_METHODS
    assert router.ROUTING_EXCEPTIONS == (RoutingNotFound, NoMethod)
    assert router.name_index == {}
    assert router.dynamic_routes == {}
    assert router.static_routes == {}
    assert router.regex_routes == []
    assert router.routes == {}
    assert router.all_routes == {}


# Generated at 2022-06-12 09:28:09.757778
# Unit test for constructor of class Router
def test_Router():
    router = Router()

    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.dynamic_routes == {}
    assert router.regex_routes == []
    assert router.static_routes == {}
    assert router.name_index == {}
    assert router.url_to_endpoint == {}
    assert router.file_route == None
    assert router.ctx == None

# Generated at 2022-06-12 09:28:13.975237
# Unit test for constructor of class Router
def test_Router():
    try:
        router = Router()
    except Exception as err:
        assert False, f"Construction of class Router raised exception: {err}"
    else:
        assert isinstance(router, Router), (
            f"Expected constructor of class Router to return "
            f"instance of class Router, but it returned "
            f"{type(router)}"
        )


# Generated at 2022-06-12 09:28:14.761136
# Unit test for constructor of class Router
def test_Router():
    router = Router()



# Generated at 2022-06-12 09:28:19.712639
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        class TestRouter(Router):
            def finalize(self, *args, **kwargs):
                pass
        TestRouter.finalize()
    except SanicException as err:
        if __name__ == '__main__':
            print(err)
        return
    assert False, "Should not have reached this point"

if __name__ == '__main__':
    test_Router_finalize()

# Generated at 2022-06-12 09:28:20.211546
# Unit test for constructor of class Router
def test_Router():
    router = Router()

# Generated at 2022-06-12 09:28:21.237690
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert type(router) == Router

# Generated at 2022-06-12 09:28:22.131600
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r != None

# Generated at 2022-06-12 09:28:26.750371
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}



# Generated at 2022-06-12 09:28:43.274986
# Unit test for constructor of class Router
def test_Router():
    router = Router()

# Generated at 2022-06-12 09:28:49.189395
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    routes = [
        Route("/", lambda *args: None, ["GET"]),
        Route("/", lambda *args: None, ["GET"]),
        Route("/", lambda *args: None, ["GET"]),
        Route("/", lambda *args: None, ["GET"]),
        Route("/", lambda *args: None, ["GET"]),
        Route("/", lambda *args: None, ["GET"]),
        Route("/", lambda *args: None, ["GET"]),
        Route("/", lambda *args: None, ["GET"]),
        Route("/", lambda *args: None, ["GET"]),
        Route("/", lambda *args: None, ["GET"]),
    ]
    for route in routes:
        router.routes_all.append(route)

    # Unit test

# Generated at 2022-06-12 09:28:51.071360
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    with pytest.raises(SanicException):
        router.finalize()

# Generated at 2022-06-12 09:28:53.525263
# Unit test for constructor of class Router
def test_Router():
    try:
        router = Router()
    except Exception as e:
        print(e)
        assert False

    print(router)
    assert True



# Generated at 2022-06-12 09:29:02.640058
# Unit test for method add of class Router
def test_Router_add():
    from sanic.testing import SanicTestClient

    app = Sanic('test_router')

    @app.route('/', methods=['GET'])
    async def test_1(request):
        return

    @app.route('/', methods=['POST'])
    async def test_2(request):
        return

    @app.route('/1')
    async def test_3(request):
        return

    @app.route('/2', methods=['GET'])
    async def test_4(request):
        return

    request, response = SanicTestClient(app).get('/')
    assert response.status == 200
    request, response = SanicTestClient(app).post('/')
    assert response.status == 200
    request, response = SanicTestClient(app).get('/1')

# Generated at 2022-06-12 09:29:03.861436
# Unit test for constructor of class Router
def test_Router():
    Router()

# Generated at 2022-06-12 09:29:13.181082
# Unit test for constructor of class Router
def test_Router():
    router = Router(
        app=None,
        uri_prefix=None,
        subdomain=None,
        host=None,
        strict_slashes=False,
        merge_slashes=False,
        skip=None,
        converters=None,
        aliases=None,
        converters_name=None,
    )

    router.add(
        uri='/',
        methods=['GET'],
        handler=None,
        host=None,
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version=None,
        name=None,
        unquote=False,
        static=False,
    )

    router.get(
        path='/',
        method='GET',
        host=None,
    )

    router.finalize

# Generated at 2022-06-12 09:29:21.945222
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    view1 = router.add("/api/info", ["GET"], None)
    router.add("/api/info", ["GET"], None, name="A")
    router.add("/api/info", ["GET"], None, name="A") # Duplicate
    router.add("/api/info", ["GET"], None, name="A") # Duplicate
    router.add("/api/info", ["GET"], None, name="__file_uri__")
    router.add("/api/info", ["GET"], None, name="__file_uri__") # Duplicate
    router.add("/api/info", ["GET"], None, name="__file_uri__") # Duplicate
    router.add("/api/info", ["GET"], None, name="__file_uri__") # Duplicate

# Generated at 2022-06-12 09:29:24.674151
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.app import Sanic
    from sanic.request import Request
    from sanic.response import text

    app = Sanic()

    @app.route("/", methods=["GET"])
    def handler(request: Request):
        return text("OK")

    app.router.finalize()  # this should not fail



# Generated at 2022-06-12 09:29:25.568449
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None


# Generated at 2022-06-12 09:30:12.155457
# Unit test for constructor of class Router
def test_Router():
    method = 'GET'
    try:
        router = Router();
    except:
        pass
    else:
        assert False

    try:
        router = Router(method);
    except:
        assert False
    else:
        pass



# Generated at 2022-06-12 09:30:17.825133
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == 'GET'
    assert router.ALLOWED_METHODS == HTTP_METHODS
    params = dict(
        path='/test',
        handler='test',
        methods=['GET'],
        name='test',
        strict=False,
        unquote=False
    )
    route = router.add(**params)
    assert route.__str__() == "<Route [/test] (GET) -> test>"


# Generated at 2022-06-12 09:30:18.472536
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None

# Generated at 2022-06-12 09:30:19.592553
# Unit test for method finalize of class Router
def test_Router_finalize():

    def handler_dummy(request):
        return 1


# Generated at 2022-06-12 09:30:27.309992
# Unit test for method finalize of class Router
def test_Router_finalize():
    Router.DEFAULT_METHOD = "GET"
    Router.ALLOWED_METHODS = HTTP_METHODS

    import json
    import pytest
    @pytest.mark.skip(reason="does not work")
    def app():
        return json.dumps({'url_for': 'sanic.exceptions'})

    def test_Router_finalize_method():
        import pytest
        @pytest.mark.skip(reason="does not work")
        def test_app():
            return json.dumps({'url': 'sanic.exceptions.NotFound'})
        assert test_app() == json.dumps({'url': 'sanic.exceptions.NotFound'})

    test_Router_finalize_method()

# Generated at 2022-06-12 09:30:29.148633
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None
    assert router.DEFAULT_METHOD == "GET"
    print("test_Router passed")


# Generated at 2022-06-12 09:30:31.258395
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}



# Generated at 2022-06-12 09:30:38.616798
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    current_uri = '/'
    current_methods = 'GET'
    current_handler = None
    current_host = 'localhost'
    current_static_slashes = False
    current_stream = False
    current_ignore_body = False
    current_version = None
    current_name = None
    current_unquote = False
    current_static = False
    # If the method returns successfully, this means that the method is working
    assert router.add(current_uri, current_methods, current_handler,
                    current_host, current_static_slashes, current_stream,
                    current_ignore_body, current_version, current_name, 
                    current_unquote, current_static) != None
    # Assert that the router type was defined correctly, then the add method should work correctly
   

# Generated at 2022-06-12 09:30:44.688731
# Unit test for method finalize of class Router
def test_Router_finalize():
    # make a router
    router = Router()

    # make a route
    route = Route(uri='', methods=['GET'], handler=None, name=None, strict=False, unquote=False, requirements={}, defaults={})

    # make method finalize
    with pytest.raises(SanicException):
        router.finalize()

    # make method finalize
    route.labels = ('__file_uri__',)
    router.finalize()


# Generated at 2022-06-12 09:30:51.268088
# Unit test for method finalize of class Router
def test_Router_finalize():

    from sanic.router import Router
    from sanic.app import Sanic
    from sanic.constants import HTTP_METHODS

    app = Sanic()

    router = Router(app)

    for method in HTTP_METHODS:
        router.add(
            "/test/<param>",
            [method],
            app.add_route,
            stream=True
        )

    try:
        router.finalize()
    except:
        assert False, "test_Router_finalize failed"

    assert True, "test_Router_finalize passed"


test_Router_finalize()

# Generated at 2022-06-12 09:31:51.564213
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    assert router.finalize() == None

# Generated at 2022-06-12 09:31:57.244921
# Unit test for constructor of class Router
def test_Router():
    router = Router(prefix="")
    # test prefix
    assert router.prefix == ""
    # test routes
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.routes_static == {}
    # test _comparison_index
    assert router._comparison_index == {}
    assert router.name_index == {}
    # test _cached_resolver
    assert router._cached_resolver is not None
    assert router._cached_resolver.cache_info().currsize == 0
    assert router._cached_resolver.cache_info().maxsize == ROUTER_CACHE_SIZE

# Generated at 2022-06-12 09:31:58.906231
# Unit test for constructor of class Router
def test_Router():
    # try:
    #     Router()
    #     assert False
    # except:
    #     assert True
    assert True

# Generated at 2022-06-12 09:32:07.552568
# Unit test for constructor of class Router
def test_Router():
    path = "path"
    method = "GET"
    host = "host"
    router = Router()
    router._get(path, method, host)
    router.get(path, method, host)
    uri = "/uri"
    method = ["GET", "POST"]
    handler = RouteHandler
    host = "host"
    strict_slashes = False
    stream = False
    ignore_body = False
    version = 1
    name = "name"
    unquote = False
    static = False
    router.add(uri, method, handler, host, strict_slashes, 
        stream, ignore_body, version, name, unquote, static)
    router.find_route_by_view_name("view_name")
    assert router.routes_all
    assert router.routes_static

# Generated at 2022-06-12 09:32:15.833783
# Unit test for constructor of class Router
def test_Router():
    r = Router(app=None)

    assert r.routes_all
    assert r.routes_static
    assert r.routes_dynamic
    assert r.routes_regex

    assert r.DEFAULT_METHOD == "GET"
    assert r.ALLOWED_METHODS == HTTP_METHODS

    name_index, path_index, path_params_index, dynamic_routes, regex_routes  = [{}] * 5

    assert r.name_index == name_index
    assert r.path_index == path_index
    assert r.path_params_index == path_params_index
    assert r.dynamic_routes == dynamic_routes
    assert r.regex_routes == regex_routes

# Generated at 2022-06-12 09:32:16.861523
# Unit test for constructor of class Router
def test_Router():
    assert Router

if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-12 09:32:18.813478
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert (router is not None)
    print("Constructor of class Router OK")



# Generated at 2022-06-12 09:32:26.450726
# Unit test for method finalize of class Router
def test_Router_finalize():
    routes = [
        ("/<param1:param1>/<param2:param2>", "GET", "handler",),
        ("/<param1:param1>/<param2:param2>", "POST", "handler",),
        ("/<param1:param1>/<param2:param2>", "PATCH", "handler",),
    ]

    router = Router(None, None, None)

    for r in routes:
        uri, methods, handler = r
        method = methods.upper()
        router.add(uri, method, handler, host=None, strict_slashes=False, stream=False, ignore_body=False, version=None, name=None, unquote=False, static=False, )

    #assert False
    #assert "methods" in str(cm.exception)


# Generated at 2022-06-12 09:32:27.601099
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    ToDo
    """

    assert True == True


# Generated at 2022-06-12 09:32:28.601846
# Unit test for constructor of class Router
def test_Router():
    router = Router()

# Generated at 2022-06-12 09:34:29.417021
# Unit test for constructor of class Router
def test_Router():
    from sanic.response import text
    assert Router().add('/test',[],text('test'))

# Generated at 2022-06-12 09:34:32.271363
# Unit test for constructor of class Router
def test_Router():
    obj = Router()
    assert obj.DEFAULT_METHOD == 'GET'
    assert obj.ALLOWED_METHODS == ['GET', 'HEAD', 'POST', 'PUT', 'DELETE', 'OPTIONS', 'PATCH', 'TRACE']

# Generated at 2022-06-12 09:34:32.760375
# Unit test for constructor of class Router
def test_Router():
    router = Router()

# Generated at 2022-06-12 09:34:33.413146
# Unit test for constructor of class Router
def test_Router():
    assert Router is Router

# Generated at 2022-06-12 09:34:38.546993
# Unit test for method add of class Router
def test_Router_add():
    """
    Unit test for method add of class Router
    """
    
    my_host = "host"
    uri = "path/to/path"
    methods = ["GET", "POST", "OPTIONS"]
    handler = "handler"
    strict_slashes = False
    stream = False
    ignore_body = False
    version = "version"
    name = "name"
    unquote = False
    static = False
    
    test_router = Router()
    
    test_route = test_router.add(uri, methods, handler, host = my_host,
                                 strict_slashes = strict_slashes, stream = stream,
                                 ignore_body = ignore_body, version = version, name = name, unquote = unquote)
    
    assert isinstance(test_route, Route)

# Generated at 2022-06-12 09:34:40.938770
# Unit test for constructor of class Router
def test_Router():
    assert Router().base_url == ''
    assert Router().ctx.app == None
    assert Router().ctx.router == None


# Generated at 2022-06-12 09:34:42.365330
# Unit test for constructor of class Router
def test_Router():
    Router()


# Generated at 2022-06-12 09:34:43.769142
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS


# Generated at 2022-06-12 09:34:44.749500
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router,Router)

# Generated at 2022-06-12 09:34:49.616710
# Unit test for constructor of class Router
def test_Router():
    """
    sanic_routing.Router

    :return:
    """
    router = Router()
    assert router.routes_all == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.routes_static == {}
    assert router.router_cache == {}
    assert router.name_index == {}

