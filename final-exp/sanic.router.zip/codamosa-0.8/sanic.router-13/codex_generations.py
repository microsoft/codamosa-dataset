

# Generated at 2022-06-12 09:25:44.023085
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == 'GET'
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.allowed_methods == set(HTTP_METHODS)
    assert router.route_cache == {}
    assert router.name_index == {}
    assert router.dynamic_routes == {}
    assert router.static_routes == {}
    assert router.regex_routes == []
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == []
    assert router.routes_regex == []
    assert router.routes == []



# Generated at 2022-06-12 09:25:44.535500
# Unit test for constructor of class Router
def test_Router():
    router = Router()

# Generated at 2022-06-12 09:25:48.276137
# Unit test for constructor of class Router
def test_Router():

    router = Router(None)
    assert router.ctx is None
    assert router.routes == {}
    assert router.static_routes == {}
    assert router.static_files_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}

# Generated at 2022-06-12 09:25:48.838289
# Unit test for constructor of class Router
def test_Router():
    assert Router()

# Generated at 2022-06-12 09:25:58.250583
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    from sanic import Sanic

    from .handler_types import RouteHandler
    from .models import Route

    class MockRoute(Route):
        def __init__(self, labels=None):
            super().__init__(
                label_pattern=None, labels=labels, method=None, name=None, path=None
            )

    with pytest.raises(SanicException) as e:
        routing = Router()
        routing.dynamic_routes = { 'bibliography': MockRoute(labels=['__book', '__author']) }
        routing.finalize()

    assert str(e.value) == "Invalid route: <class 'test_router.MockRoute'>. Parameter names cannot use '__'."



# Generated at 2022-06-12 09:26:06.173433
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic_routing import Route, Router as BaseRouter
    from sanic.constants import HTTP_METHODS
    from sanic.handlers import ErrorHandler
    from sanic.response import BaseHTTPResponse
    from sanic.views import CompositionView

    class Router(BaseRouter):

        def __init__(self, host, method, uri):
            super().__init__()
            self.host = host
            self.method = method
            self.uri = uri

        async def resolve(self, path, method, extra=None):
            return None, None, None


# Generated at 2022-06-12 09:26:07.076830
# Unit test for constructor of class Router
def test_Router():
    assert callable(Router)


# Generated at 2022-06-12 09:26:09.287299
# Unit test for constructor of class Router
def test_Router():
    router = Router(None)
    assert router.routes == {}
    assert router.regex_routes == {}
    assert router.static_routes == {}

# Generated at 2022-06-12 09:26:10.750555
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.router_type == "simple"

# Generated at 2022-06-12 09:26:12.098125
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None


# Generated at 2022-06-12 09:26:25.112729
# Unit test for constructor of class Router
def test_Router():
    class RouterTest:
        def test_get(self):
            path = '/'
            method = 'GET'
            host = 'www.google.com'
            routerTest = Router()
            routerTest._get(path, method, host)
            assert routerTest._get(path, method, host) is None
        def test_get_exception(self):
            path = 'www.google.com'
            method = 'GET'
            host = 'www.google.com'
            routerTest = Router()
            try:
                routerTest.get(path, method, host)
            except Exception as e:
                assert type(e) == NotFound
        def test_add(self):
            uri = 'www.google.com'
            method = 'GET'
            handler = 'www.google.com'

# Generated at 2022-06-12 09:26:29.974409
# Unit test for constructor of class Router
def test_Router():
    # Call constructor of class Router
    Router()
    # Check default value of two params
    assert Router.ALLOWED_METHODS == ['HEAD', 'OPTIONS', 'GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'TRACE', 'CONNECT']
    assert Router.DEFAULT_METHOD == 'GET'
    # Check return value of function __init__()
    assert isinstance(Router, type)


# Generated at 2022-06-12 09:26:32.379693
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add(uri="", methods=HTTP_METHODS, handler=lambda: print("hello"))
    router.add(uri="/", methods=HTTP_METHODS, handler=lambda: print("world"))
    router.finalize()

# Generated at 2022-06-12 09:26:34.595960
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add("/", methods=["GET"], handler=lambda x: x, name="test")
    route = router.find_route_by_view_name("test")
    assert route is not None

# Generated at 2022-06-12 09:26:42.862456
# Unit test for method finalize of class Router
def test_Router_finalize():
    from uuid import uuid4
    from sanic.response import text
    from sanic import Sanic
    app = Sanic()
    uid = uuid4().hex
    def check(route_name, forbidden_chars):
        router = Router(app)
        @app.route(route_name)
        def handler(_):
            return text("OK")
        router.finalize()
        uid = uuid4().hex
        assert app.router.name_index[uid + "." + handler.__name__]
        if forbidden_chars:
            assert app.router.name_index[handler.__name__].__name__ == uid + "." + handler.__name__

# Generated at 2022-06-12 09:26:43.705721
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router


# Generated at 2022-06-12 09:26:51.926779
# Unit test for method finalize of class Router
def test_Router_finalize():
    def handler():
        pass

    with pytest.raises(SanicException):
        router = Router()
        router.add("/users/{user__id}", [], handler)
        router.finalize()

    router = Router()
    router.add("/users/{user_id}", [], handler)
    router.finalize()
    assert router.routes_all == {}
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.routes == []


# Generated at 2022-06-12 09:26:55.680378
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r.routes_all == {}
    assert r.routes_static == {}
    assert r.routes_dynamic == {}
    assert r.routes_regex == {}


# Generated at 2022-06-12 09:26:59.660406
# Unit test for constructor of class Router
def test_Router():
    # test init
    router = Router()

    assert router.routes == {}
    assert router.static_routes == []
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.ctx == None

# Generated at 2022-06-12 09:27:05.307993
# Unit test for constructor of class Router
def test_Router():
    router = Router()

    # Test __init__
    assert isinstance(router, BaseRouter)
    assert router._finalized is False
    assert not router.routes
    assert not router.name_index
    assert not router.path_index
    assert not router.dynamic_routes
    assert not router.dynamic_paths
    assert not router.static_routes
    assert not router.regex_routes
    assert not router.regex_paths

# Generated at 2022-06-12 09:27:20.143426
# Unit test for method finalize of class Router
def test_Router_finalize():
    import sys
    import io

    capturedOutput = io.StringIO()  # Create StringIO object
    sys.stdout = capturedOutput  #  and redirect stdout.
    r = Router()

# Generated at 2022-06-12 09:27:22.564337
# Unit test for method add of class Router
def test_Router_add():
	print('testing add')
	r = Router()
	def test(request):
		return	
	print(r.add('/',['GET','POST'],test))


# Generated at 2022-06-12 09:27:23.940424
# Unit test for constructor of class Router
def test_Router():
    assert isinstance(Router(), Router)


# Generated at 2022-06-12 09:27:32.051124
# Unit test for method finalize of class Router
def test_Router_finalize():
    methods = ["POST", "GET", "OPTIONS"]
    dynamic_routes = []

    r1 = Route(
        path="",
        methods=methods,
        handler="handler1",
        name="view1",
        strict=False,
        unquote=False,
    )
    r1.ctx.ignore_body = False
    r1.ctx.stream = False
    r1.ctx.hosts = ["test1"]
    r1.ctx.static = False
    dynamic_routes.append(r1)

    r2 = Route(
        path="",
        methods=methods,
        handler="handler2",
        name="view2",
        strict=False,
        unquote=False,
    )
    r2.ctx.ignore_body = False

# Generated at 2022-06-12 09:27:33.871168
# Unit test for constructor of class Router
def test_Router():
    from sanic import Sanic

    router = Router()
    assert(isinstance(router, Router))


# Generated at 2022-06-12 09:27:36.603251
# Unit test for constructor of class Router
def test_Router():
    from sanic import Sanic
    from sanic.server import HttpProtocol

    app = Sanic(__name__)

    app.router = Router()
    app.protocol = HttpProtocol


# Generated at 2022-06-12 09:27:38.458340
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS

# Generated at 2022-06-12 09:27:39.815840
# Unit test for constructor of class Router
def test_Router():
    instance = Router()
    assert isinstance(instance, Router)

# Generated at 2022-06-12 09:27:40.362170
# Unit test for method finalize of class Router
def test_Router_finalize():
    assert True

# Generated at 2022-06-12 09:27:41.212511
# Unit test for constructor of class Router
def test_Router():
    testObject = Router()
    assert testObject is not None

# Generated at 2022-06-12 09:28:02.246436
# Unit test for constructor of class Router
def test_Router():
    from sanic import Sanic
    from sanic.response import text
    app = Sanic()
    router = Router(app)
    assert(app == router.ctx.app)
    @app.route('/test')
    def test_function(request):
        return text('test')
    @app.route('/test1')
    def test_function1(request):
        return text('test')
    assert(test_function == router.get('/test', 'GET')[1])
    assert(test_function1 == router.get('/test1', 'GET')[1])

# Generated at 2022-06-12 09:28:02.934162
# Unit test for constructor of class Router
def test_Router():
    assert str(Router) == "<class 'Router'>"

# Generated at 2022-06-12 09:28:05.442456
# Unit test for method finalize of class Router
def test_Router_finalize():
    func = lambda x, y: x + y
    router = Router(func)
    route = router.add("/<x>/<y>")
    router.finalize()
    assert func == router.get("/<x>/<y>")[1]

# Generated at 2022-06-12 09:28:10.745763
# Unit test for method finalize of class Router
def test_Router_finalize():
    import re
    router = Router()
    router.add(
        uri="/", methods=["GET"], handler=lambda x: 1, host=None, strict_slashes=False, stream=False, ignore_body=False, version=None, name=None, unquote=False, static=False
    )
    try:
        router.finalize()
    except:
        return False
    return True

if __name__ == "__main__":
    print(test_Router_finalize())

# Generated at 2022-06-12 09:28:12.680452
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)
    assert isinstance(router, BaseRouter)


# Generated at 2022-06-12 09:28:18.355235
# Unit test for method finalize of class Router
def test_Router_finalize():

    router = Router()
    router.add(
        uri='/test',
        methods={'get'},
        handler=None,
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version=None,
        name=None,
        unquote=False,
        static=False)

    try:
        router.finalize()
    except SanicException as e:
        assert e.__repr__() == "'Invalid route: None. Parameter names cannot use '__'."

# Generated at 2022-06-12 09:28:20.676472
# Unit test for constructor of class Router
def test_Router():
    def test(method):
        return '/'

    router = Router(None, lambda: test)
    assert router.DEFAULT_METHOD == 'GET'
    assert router.ALLOWED_METHODS == HTTP_METHODS

# Generated at 2022-06-12 09:28:28.488713
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    routes = '/{__file_uri__}'
    r.add('/test', ('get',), print, host=None, strict_slashes=False, stream=False,
            ignore_body=False, version=None, name=None, unquote=False, static=False)
    with pytest.raises(SanicException):
        r.finalize
    r.add('/test', ('get',), print, host=None, strict_slashes=False, stream=False,
            ignore_body=False, version=None, name=None, unquote=False, static=False)
    assert r.finalize

# Generated at 2022-06-12 09:28:37.777270
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.name_index == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.static_routes == {}
    assert router.used_namespaces == set()
    assert router.ctx.app == None
    assert router.ctx.hosts == None
    assert router.ctx.ignore_body == False
    assert router.ctx.name == None
    assert router.ctx.route_handler == None
    assert router.ctx.route_uri == None
    assert router.ctx.stream == False
    assert router.ctx.strict == False
    assert router.ctx.unquote == False
    assert router.ctx.static == False
    assert router.ctx.version == None


# Generated at 2022-06-12 09:28:44.110598
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)
    assert router.ctx == router.__class__.ctx
    assert router.DEFAULT_METHOD == router.__class__.DEFAULT_METHOD
    assert router.ALLOWED_METHODS == router.__class__.ALLOWED_METHODS
    assert router.routes == router.__class__.routes
    assert router.routes_all == router.__class__.routes_all
    assert router.routes_static == router.__class__.routes_static
    assert router.routes_dynamic == router.__class__.routes_dynamic
    assert router.routes_regex == router.__class__.routes_regex

# Generated at 2022-06-12 09:29:14.743056
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    r.add("/about/", methods=["GET"], handler=int)
    r.add("/about/", methods=["GET"], handler=int)
    assert r.finalize() == True

# Generated at 2022-06-12 09:29:16.480738
# Unit test for constructor of class Router
def test_Router():
    router = Router(None)
    assert router.ctx is None

## Unit test for finalize()

# Generated at 2022-06-12 09:29:22.465904
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == 'GET'
    assert router.ALLOWED_METHODS == ['GET', 'POST', 'PUT', 'PATCH', 'HEAD', 'OPTIONS', 'DELETE', 'TRACE']
    assert router.routes_all == []
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-12 09:29:27.723906
# Unit test for constructor of class Router
def test_Router():
    router = Router(prefix='/xxx')
    assert router.prefix == '/xxx'
    assert router.routes == {}
    assert router.routes_all == {}
    assert router.name_index == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.ctx.static_prefix is None
    assert router.ctx.static_path is None
    assert router.ctx.static_url is None
    assert router.ctx.static_folder is None
    assert router.ctx.static_host is None
    assert router.ctx.default_method is None


# Generated at 2022-06-12 09:29:31.032941
# Unit test for constructor of class Router
def test_Router():
    test_router = Router()
    assert test_router.DEFAULT_METHOD == "GET"
    assert test_router.ALLOWED_METHODS == ['CONNECT', 'DELETE', 'GET', 'HEAD', 'OPTIONS', 'PATCH', 'POST', 'PUT', 'TRACE']


# Generated at 2022-06-12 09:29:35.956257
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    # Test vaild route
    router.add("/user", ["GET"], lambda a: a, static=True)
    router.finalize()
    assert router.dynamic_routes == {}

    # Test invalid route
    router.add("/user/<__param>", ["GET"], lambda a: a, static=True)
    with pytest.raises(SanicException):
        router.finalize()


# Generated at 2022-06-12 09:29:37.729526
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-12 09:29:46.770961
# Unit test for method finalize of class Router
def test_Router_finalize():
    import os
    import tempfile
    fd, path = tempfile.mkstemp()

# Generated at 2022-06-12 09:29:49.788085
# Unit test for constructor of class Router
def test_Router():
    import unittest
    class TestRouter(unittest.TestCase):
        def test1(self):
            router = Router()

# Generated at 2022-06-12 09:29:50.504587
# Unit test for constructor of class Router
def test_Router():
    # TODO: write unit test
    pass

# Generated at 2022-06-12 09:30:21.487851
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    routes = router.routes_all
    assert len(routes) == 0
    # TODO: add further testing once we can add routes to Router


# Generated at 2022-06-12 09:30:25.256722
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert isinstance(router.ALLOWED_METHODS, tuple)
    assert router.ALLOWED_METHODS == ('TRACE', 'OPTIONS', 'HEAD', 'GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'LINK', 'UNLINK')


# Generated at 2022-06-12 09:30:31.418048
# Unit test for constructor of class Router
def test_Router():
    router = Router(None)
    assert router.DEFAULT_METHOD == 'GET'
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.ctx is None
    assert router.name_index == {}
    assert router.prefix is None
    assert router.routes == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.delimiter == '/' 


# Generated at 2022-06-12 09:30:35.260703
# Unit test for constructor of class Router
def test_Router():
    uri = 'uri'
    path = 'path'
    method = 'method'
    host = 'host'
    e = Exception()

    try:
        raise e
    except Exception as e:
        assert (isinstance(e, NoMethod))


    assert 'Requested URL {} not found'.format(path) == NotFound('Requested URL {} not found'.format(path)).args[0]

# Generated at 2022-06-12 09:30:40.792785
# Unit test for constructor of class Router
def test_Router():
    @lru_cache(maxsize=ROUTER_CACHE_SIZE)
    def get(self, path: str, method: str, host: Optional[str]) -> Tuple[Route, RouteHandler, Dict[str, Any]]: return None

    @lru_cache(maxsize=ROUTER_CACHE_SIZE)
    def find_route_by_view_name(self, view_name, name=None): return None

    Router.get = get
    Router.find_route_by_view_name = find_route_by_view_name

    router = Router(ctx=None)

    assert issubclass(router.__class__, BaseRouter)

# Generated at 2022-06-12 09:30:47.102600
# Unit test for method add of class Router
def test_Router_add():
    from sanic import Sanic

    app = Sanic()
    router = Router(app)

    @app.route('/')
    async def handler(request):
        pass
    
    assert router.add('/', ['GET'], handler) == router.routes[0]
    assert router.add('/', ['GET','POST'], handler) == router.routes[1:3]
    assert router.add('/', ['GET','POST','PUT'], handler) == router.routes[1:4]



# Generated at 2022-06-12 09:30:54.808121
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    app = Sanic("test_Router_finalize")
    router = Router(app)
    try:
        router.finalize()
    except Exception:
        raise Exception("Wrong test case")

    def handler(a):
        return "1"

    router.add("/test_Router_finalize", ["GET"], handler)
    try:
        router.finalize()
    except Exception:
        raise Exception("Wrong test case")

    router.add("/test_Router_finalize/<__a>", ["GET"], handler)
    try:
        router.finalize()
    except SanicException:
        pass
    else:
        raise Exception("Wrong test case")

# Generated at 2022-06-12 09:30:55.549172
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router

# Generated at 2022-06-12 09:31:03.914843
# Unit test for constructor of class Router
def test_Router():
    from unittest import TestCase
    from sanic import Sanic

    class TestRouter(TestCase):
        def test_router_methods(self):
            app = Sanic("test_default")
            router = Router(app)

            methods = ['add', 'finalize', 'get', 'get_all', 'get_http_methods', 'is_stream',
                       'route', 'routes_all', 'routes_dynamic', 'routes_static', 'routes_regex',
                       'set_default_response_headers', 'stream']

            self.assertEqual(sorted(router.__dir__()), sorted(methods))

    obj = TestRouter()
    obj.test_router_methods()

# Generated at 2022-06-12 09:31:11.621539
# Unit test for method finalize of class Router
def test_Router_finalize():
    class _Router(Router):
        def __init__(self, app=None):
            super().__init__()
            self.ctx = self
            self.ctx.app = app
            self.ctx.router = self
        def register_route(self, route):
            self.routes_all[route.name] = route
            if route.ctx.static:
                self.static_routes[route.name] = route
            else:
                self.dynamic_routes[route.name] = route
                self.regex_routes[route.name] = route
            self.name_index[route.name] = route

    r = _Router()

# Generated at 2022-06-12 09:32:17.689946
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert repr(r) == "<Router at 0x1025f8b10>"

# Generated at 2022-06-12 09:32:18.812690
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router


# Generated at 2022-06-12 09:32:26.531690
# Unit test for constructor of class Router
def test_Router():
    from sanic import Sanic, response
    from sanic.router import RouteExists
    from sanic.router import RouteReset, RouteResetError
    from sanic.router import Router

    app = Sanic('test_Router')


    def handler(request, *args, **kwargs):
        pass


    @app.route('/')
    def handler1(request, *args, **kwargs):
        pass

    router = Router(app, handler, host=None,
                    strict_slashes=False,
                    stream=False,
                    ignore_body=False,
                    version=None,
                    name=None,
                    unquote=False,
                    static=False)
    assert router.ctx.app == app
    assert router.ctx.handler == handler
    assert router.ctx.host is None


# Generated at 2022-06-12 09:32:27.675283
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None


# Generated at 2022-06-12 09:32:28.943231
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    return isinstance(r, BaseRouter)


# Generated at 2022-06-12 09:32:37.979450
# Unit test for constructor of class Router
def test_Router():
  router = Router()
  router.DEFAULT_METHOD
  router.ALLOWED_METHODS
  path = '/'
  method = 'POST'
  host = '127.0.0.1'
  router._get(path, method, host)
  router.get(path, method, host)
  uri = path
  methods = ['POST']
  handler = path
  strict_slashes = False
  stream = False
  ignore_body = False
  version = 1.0
  name = "name"
  unquote = False
  static = False
  router.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)
  router.find_route_by_view_name(view_name = "test")
  router.routes_

# Generated at 2022-06-12 09:32:46.865762
# Unit test for method finalize of class Router
def test_Router_finalize():
    label_list = ["__file_uri__", "__id__"]

    # This is the class that will contain the method to be tested
    class TestClass:
        def finalize(self, *args, **kwargs):
            pass

    # Create an instance of TestClass
    x = TestClass()
    
    # Create an instance of Router
    newRouter = Router(x)

    for label in label_list:
        route = newRouter.add(uri='/', methods=['GET'], handler=None, host=None, strict_slashes=False, stream=False, ignore_body=False, version=None, name=None, unquote=False, static=False)
        route.labels = [label]
        assert newRouter.finalize(args, kwargs)

# Generated at 2022-06-12 09:32:52.107853
# Unit test for constructor of class Router
def test_Router():
    # router = Router(
    #     host=None,
    #     version=None,
    #     prefix=None,
    #     router_name=None,
    #     uri_prefix=None,
    #     strict_slashes=None,
    #     name=None,
    #     routes=None,
    #     versioning_strategy=None,
    #     versioning_base_name=None,
    #     versioning_class_name=None,
    # )
    pass

# Generated at 2022-06-12 09:32:53.176657
# Unit test for constructor of class Router
def test_Router():
    instance = Router()
    assert instance is not None


# Generated at 2022-06-12 09:33:00.527503
# Unit test for method add of class Router
def test_Router_add():
    # Framework: sanic.__init__.py
    router = Router(None)

    # test the case where uri == "/test", methods in {'POST', 'GET'}, host == None, strict_slashes == True, stream == True, ignore_body == True, version == '1', name == '1'
    # Given:
    uri = "/test"
    methods = ['POST', 'GET']
    handler = lambda: 0
    host = None
    strict_slashes = True
    stream = True
    ignore_body = True
    version = '1'
    name = '1'

    # When:
    result = router.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name)

    # Then: