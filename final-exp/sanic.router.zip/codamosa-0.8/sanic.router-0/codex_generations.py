

# Generated at 2022-06-12 09:26:00.175148
# Unit test for constructor of class Router
def test_Router():
    router = Router() # type: ignore
    # To do: assert something



# Generated at 2022-06-12 09:26:07.546539
# Unit test for method finalize of class Router
def test_Router_finalize():
    import re
    import sys

    import pytest
    from sanic.router import Router

    # Tests for issue #1823
    # Ensures that routes with labels starting with __ (double underscore)
    # will not cause internal server errors.
    @pytest.fixture()
    def router():
        router = Router()
        global route
        route = router.add("/<param>", methods=["GET"])
        return router

    def test_router_with_valid_label_name(router):
        route.add_route("/<__file_uri__:path>", methods=["GET"])
        try:
            router.finalize()
        except SanicException:
            pytest.fail("Router.finalize() raised SanicException unexpectedly!")
        else:
            assert True


# Generated at 2022-06-12 09:26:08.730526
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-12 09:26:12.022573
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router.DEFAULT_METHOD, str)
    assert isinstance(router.ALLOWED_METHODS, list)
    assert router._cache_handler == router._get
    assert router.ctx == router._ctx

# Generated at 2022-06-12 09:26:13.276935
# Unit test for constructor of class Router
def test_Router():

    router = Router()
    isinstance(router, Router)


# Generated at 2022-06-12 09:26:23.919127
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    from sanic.exceptions import SanicException
    router = Router()
    routes_dynamic = {}
    routes_dynamic["/456/{__file_uri__}"] = Route(
        path="/456/{__file_uri__}", handler=None,
        methods=["GET"], name=None, strict=False
    )
    routes_dynamic["/123/{__file_uri__}"] = Route(
        path="/123/{__file_uri__}", handler=None,
        methods=["GET"], name=None, strict=False
    )

# Generated at 2022-06-12 09:26:25.112264
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None


# Generated at 2022-06-12 09:26:26.547202
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r

# TEST_CASES["test_Router"] = test_Router

# Generated at 2022-06-12 09:26:28.065625
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)

# Generated at 2022-06-12 09:26:30.836723
# Unit test for method finalize of class Router
def test_Router_finalize():
    # create an instance of the new class
    router = Router()
    route = Route("/", None, [], {}, None)
    # add the route to the protected and private members of the class
    router.dynamic_routes["test"] = route
    router.regex_routes["test"] = route
    router.static_routes["test"] = route
    router.routes["test"] = route
    # execute the unit
    router.finalize()

# Generated at 2022-06-12 09:26:43.432985
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    Test finalize method of class Router
    """
    @lru_cache(maxsize=ROUTER_CACHE_SIZE)
    def find_route_by_view_name(view_name, name=None):
        """
        Find a route in the router based on the specified view name.

        :param view_name: string of view name to search by
        :param kwargs: additional params, usually for static files
        :return: tuple containing (uri, Route)
        """
        if not view_name:
            return None

        route = self.name_index.get(view_name)
        if not route:
            full_name = self.ctx.app._generate_name(view_name)
            route = self.name_index.get(full_name)

        if not route:
            return

# Generated at 2022-06-12 09:26:48.658727
# Unit test for method finalize of class Router
def test_Router_finalize():
    class _Test:
        def __init__(self, router=None):
            if router != Router:
                raise Exception
            
    x = Router()
    x.ctx = _Test

    try:
        x.finalize(Router)
    except Exception:
        raise Exception

# Generated at 2022-06-12 09:26:50.345570
# Unit test for constructor of class Router
def test_Router():
    obj = Router()    
    assert obj.DEFAULT_METHOD == "GET"
    assert obj.ALLOWED_METHODS == HTTP_METHODS

# Generated at 2022-06-12 09:26:51.227991
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router

# Generated at 2022-06-12 09:26:59.468588
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route()

    # Case 1: Parameter names that start with '__' are not allowed
    try:
        route.labels = set(["__file_uri__"])
        router.dynamic_routes = {"a route": route}
        router.finalize()
    except SanicException:
        assert 1

    # Case 2: Parameter names that start with '__' are not allowed
    route.labels = set(["__filename__"])
    router.dynamic_routes = {"a route": route}
    with pytest.raises(SanicException):
        router.finalize()

# Generated at 2022-06-12 09:27:04.573742
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router.routes, dict)
    assert isinstance(router.dynamic_routes, dict)
    assert isinstance(router.static_routes, dict)
    assert isinstance(router.regex_routes, dict)
    assert isinstance(router._cache, dict)
    assert isinstance(router.name_index, dict)


# Generated at 2022-06-12 09:27:05.541782
# Unit test for method finalize of class Router
def test_Router_finalize():
    assert False, "Unimplemented"

# Generated at 2022-06-12 09:27:10.026594
# Unit test for method finalize of class Router
def test_Router_finalize():
    ####
    # Test bad cases
    uri = "test_uri"
    handler = RouteHandler
    router = Router()
    with pytest.raises(SanicException):
        router.finalize()

    ####
    # Test good cases
    uri = "test_uri"
    handler = RouteHandler
    router = Router()
    router.add(uri, ["POST"], handler)
    router.finalize()



# Generated at 2022-06-12 09:27:11.542756
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    try:
        r.finalize()
    except Exception as e:
        raise e

# Generated at 2022-06-12 09:27:18.156716
# Unit test for method finalize of class Router
def test_Router_finalize():

    import pytest

    from sanic.router import Router
    from sanic.exceptions import SanicException

    router = Router(None)

    with pytest.raises(SanicException) as exc:
        router.add('/<__some_label>/', ['GET'], lambda backend, request: None)

    assert exc.value.args[0] == "Invalid route: GET - /<__some_label>/ - " \
                                 "<function <lambda> at 0x000001F0E27D1EA0>"
    assert exc.value.__class__.__name__ == 'SanicException'

# Generated at 2022-06-12 09:27:28.952551
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes == []
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.routes_all == router.routes
    assert router.routes_static == router.static_routes
    assert router.routes_dynamic == router.dynamic_routes
    assert router.routes_regex == router.regex_routes


# Generated at 2022-06-12 09:27:29.499598
# Unit test for constructor of class Router
def test_Router():
    pass

# Generated at 2022-06-12 09:27:30.324117
# Unit test for constructor of class Router
def test_Router():
    _ = Router()


# Generated at 2022-06-12 09:27:34.203022
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route(path="/test/{id:int}/{name}", handler=None, strict=False, unquote=False, ctx=router.ctx)
    router.dynamic_routes[route.path] = route
    with pytest.raises(SanicException):
        router.finalize()

# Generated at 2022-06-12 09:27:35.677292
# Unit test for constructor of class Router
def test_Router():
    r = Router()

    assert isinstance(r, BaseRouter)
    assert isinstance(r, Router)

# Generated at 2022-06-12 09:27:36.857377
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert isinstance(r, Router)

# Generated at 2022-06-12 09:27:37.379415
# Unit test for constructor of class Router
def test_Router():
    assert Router

# Generated at 2022-06-12 09:27:45.735975
# Unit test for method finalize of class Router
def test_Router_finalize():

    brouter = Router()
    brouter.add(
        uri='/path/to',
        methods=["GET", "POST", "OPTIONS"],
        handler=None,
        host=None,
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version=None,
        name=None,
        unquote=False,
        static=False
    )
    try:
        brouter.finalize()
    except:
        assert True
    else:
        assert False


# Generated at 2022-06-12 09:27:46.361859
# Unit test for constructor of class Router
def test_Router():
    assert issubclass(Router, BaseRouter)


# Generated at 2022-06-12 09:27:47.509946
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS



# Generated at 2022-06-12 09:28:00.664309
# Unit test for constructor of class Router
def test_Router():
    from sanic import Sanic
    from sanic.app import Sanic as Sanic_app
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.router import Router

    app = Sanic("sanic-server")
    assert isinstance(app, Sanic)

    router = Router(app)
    assert isinstance(router, Router)

    #class testRouter(Router):
    #    def __init__(self, *args, **kwargs):
    #        super().__init__(*args, **kwargs)

    #test_instance = testRouter(app)
    #assert isinstance(test_instance, testRouter)



# Generated at 2022-06-12 09:28:03.484731
# Unit test for method finalize of class Router
def test_Router_finalize():
    def handler():
        pass
    router = Router()
    router.add('/test', 'GET', handler=handler)
    
    try:
        router.finalize()
    except SanicException as e:
        assert 'Invalid route: /test' in str(e)


# Generated at 2022-06-12 09:28:06.444341
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    
    assert router.routes_all == dict()
    assert router.routes_static == dict()
    assert router.routes_dynamic == dict()
    assert router.routes_regex == dict()
    assert router.name_index == dict()


# Generated at 2022-06-12 09:28:07.240793
# Unit test for constructor of class Router
def test_Router():
    # Test with default constructor
    Router()

# Generated at 2022-06-12 09:28:08.311701
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert isinstance(r, Router) 


# Generated at 2022-06-12 09:28:11.358842
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    with pytest.raises(SanicException) as excinfo:
        router.finalize()
    assert str(excinfo.value) == f"Invalid route: {None}. Parameter names cannot use '__'."

# Generated at 2022-06-12 09:28:14.472544
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    my_router = Router()
    my_router.dynamic_routes = {
        'path1': "path1",
        '__file_uri__': "path2",
    }
    my_router.finalize()


# Generated at 2022-06-12 09:28:22.404079
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Create an instance of Router
    router = Router()
    # Create a sample routes
    routes = [
        Route(
            uri="/",
            methods=["GET"],
            handler=None,
            host=None,
            strict_slashes=False,
            name=None,
            stream=False,
            version=None,
            unquote=False,
            static=False,
            ctx=None,
            ctx_store=None,
            ctx_index=0,
            view_name=None,
            labels={"__file_uri__": "index.html"},
        )
    ]
    router.routes_all.update(routes)
    router.finalize()
    assert len(router.routes_dynamic) == 1
    assert router.routes_d

# Generated at 2022-06-12 09:28:24.183774
# Unit test for constructor of class Router
def test_Router():
    try:
        r=Router()
    except:
        assert False
    assert True



# Generated at 2022-06-12 09:28:25.613732
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == set()

# Generated at 2022-06-12 09:28:43.305342
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router(None, None)
    router.dynamic_routes = {'TestRoute':Route('TestRoute', {'path': '/', 'handler': None, 'methods': ['GET', 'POST', 'OPTIONS'], 'name': 'testroute', 'hosts': None, 'strict': False, 'stream': False, 'ignore_body': False})}
    with pytest.raises(SanicException):
        router.finalize()
    router = Router(None, None)

# Generated at 2022-06-12 09:28:45.516318
# Unit test for constructor of class Router
def test_Router():
    assert Router != None

# Run tests
if __name__ == "__main__":
    import doctest

    doctest.testmod(optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-12 09:28:51.774722
# Unit test for constructor of class Router
def test_Router():
    req = request.Request(
        "POST",
        "https://www.miro.com/get/123",
        headers={"Host": "www.miro.com"},
        json={"title": "abc"},
    )
    router = Router()
    handler = router.get(
        req.path, req.method, req.headers.get("Host")
    )[1]
    assert handler == None



# Generated at 2022-06-12 09:28:58.087360
# Unit test for method finalize of class Router
def test_Router_finalize():
    from unittest.mock import MagicMock

    mock_route = MagicMock()
    mock_route.__getitem__.side_effect = lambda label: "__test__"

    route_list = [mock_route]

    router = Router()
    router.dynamic_routes = dict(test=route_list)

    with pytest.raises(SanicException) as exception_context:
        router.finalize()

    assert "Invalid route: " in str(exception_context.value)

# Generated at 2022-06-12 09:29:03.953790
# Unit test for method finalize of class Router
def test_Router_finalize():
    def handler(request):
        pass

    uri = "/test_uri"
    methods = "POST"
    host = "test_host"
    strict_slashes = False
    stream = False
    ignore_body = False
    version = 1
    name = "name"
    unquote = True
    static = False

    router = Router()
    router.add(
        uri,
        methods,
        handler,
        host,
        strict_slashes,
        stream,
        ignore_body,
        version,
        name,
        unquote,
        static
        )
    router.finalize()

# Generated at 2022-06-12 09:29:10.717302
# Unit test for method finalize of class Router
def test_Router_finalize():
    path = "/test"
    method = "GET"
    handler = lambda request: True
    router = Router()
    router.add(path, method, handler)
    router.finalize()
    try:
        assert(router.dynamic_routes.values()[0].labels == ["test"])
    except:
        assert(False)
    print("test_Router_finalize...ok")

if __name__ == "__main__":
    test_Router_finalize()
    print("Test_Router...OK")

# Generated at 2022-06-12 09:29:11.229085
# Unit test for constructor of class Router
def test_Router():
    pass

# Generated at 2022-06-12 09:29:12.057390
# Unit test for method finalize of class Router
def test_Router_finalize():
    assert False, "Not implemented"


# Generated at 2022-06-12 09:29:18.318985
# Unit test for method finalize of class Router
def test_Router_finalize():
    invalid_route = Route('/path/<__invalid_parameter_name>')
    valid_route = Route('path/<__file_uri__>')

    router = Router()
    router.add_route(invalid_route)
    router.add_route(valid_route)

    try:
        router.finalize()
    except SanicException as e:
        assert "Invalid route: <sanic_routing.route.Route object at 0x7f8bde430290>. Parameter names cannot use '__'." in  str(e), 'SanicException is not correct!'

# Generated at 2022-06-12 09:29:23.442718
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    class TestRouter(Router):
        def __init__(self):
            super().__init__()
            self.dynamic_routes = {
                "test": {
                    "path": b"path",
                    "labels": [],
                    "methods": []
                }
            }
    with pytest.raises(SanicException):
        router = TestRouter()
        router.finalize("")


# Generated at 2022-06-12 09:29:48.855342
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic_routing import BaseRouter
    from sanic_routing.router import Router
    from sanic_routing.route import DynamicRoute
    from sanic.exceptions import SanicException
    from sanic.response import text


    def test_handler(request):
        return text("ok")


    router_test = BaseRouter()
    router_test.add(uri='/', methods=['GET'], handler=test_handler)
    try:
        router_test.finalize()
    except SanicException as e:
        print(f"Got exception: {e}")



# Generated at 2022-06-12 09:29:53.009137
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router(None)
    route = Route("/<user>", "GET", None)
    route.labels = ["user"]
    router.dynamic_routes["/<user>"] = route

    with pytest.raises(SanicException) as exc_info:
        router.finalize()

    assert exc_info.value.args[0] == "Invalid route: Route('/<user>', 'GET')." \
                                     " Parameter names cannot use '__'."


# Generated at 2022-06-12 09:30:01.205705
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Create and finalize a router
    router = Router()
    router.finalize()

    # If a route contains a parameter label starting with '__' and not in
    # ALLOWED_LABELS, then SanicException will be raised
    router_dynamic = dict()
    router_dynamic["uri"] = "/uri_test"
    router_dynamic["args"] = []
    router_dynamic["kwargs"] = {}
    router_dynamic["host"] = None
    router_dynamic["host_regex"] = None
    router_dynamic["strict_slashes"] = False
    router_dynamic["methods"] = ["GET"]
    router_dynamic["handler"] = lambda request: None
    router_dynamic["labels"] = ["__label_test__"]

# Generated at 2022-06-12 09:30:01.936361
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None

# Generated at 2022-06-12 09:30:03.869525
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert (r.DEFAULT_METHOD == "GET") and (len(r.ALLOWED_METHODS) == len(HTTP_METHODS))


# Generated at 2022-06-12 09:30:06.238590
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException

    router = Router()
    with pytest.raises(SanicException):
        router.finalize()

# Generated at 2022-06-12 09:30:08.723219
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes
    assert router.routes_static
    assert router.routes_dynamic
    assert router.routes_regex


# Generated at 2022-06-12 09:30:10.841358
# Unit test for constructor of class Router
def test_Router():
    # assert if an instance is created
    assert isinstance(Router(), Router)
    # assert if router is from the defined BaseRouter
    assert issubclass(Router, BaseRouter)

# Generated at 2022-06-12 09:30:12.711772
# Unit test for constructor of class Router
def test_Router():
    assert Router.__name__ == 'Router'
    assert Router.__init__.__name__ == '__init__'
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-12 09:30:14.661937
# Unit test for constructor of class Router
def test_Router():
    assert Router() is not None

if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-12 09:30:51.414032
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert isinstance(r, Router)

# Generated at 2022-06-12 09:30:56.279961
# Unit test for constructor of class Router
def test_Router():
    obj = Router(None)
    assert obj.ctx == None
    assert obj.routes == {}
    assert obj.routes_all == {}
    assert obj.routes_dynamic == {}
    assert obj.routes_static == {}
    assert obj.routes_regex == {}
    assert obj.name_index == {}
    assert obj.regex_routes == {}
    assert obj.static_routes == {}


# Generated at 2022-06-12 09:30:59.505094
# Unit test for constructor of class Router
def test_Router():
    """
    Default route is 'GET'

    >>> r = Router()
    >>> r.DEFAULT_METHOD
    'GET'

    """
    pass  # pragma: no cover

# Generated at 2022-06-12 09:31:00.788587
# Unit test for constructor of class Router
def test_Router():
    router = Router('routes')
    print(router.routes)

# Generated at 2022-06-12 09:31:06.461760
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    from sanic_routing import Router as SR

    app = Sanic("sanic")
    router = SR()
    router.ctx.app = app

    # test case 1
    class Route():
        def __init__(self, labels):
            self.labels = labels

    route = Route(labels=["__file_uri__"])
    assert router.finalize(route) == route

    # test case 2
    route = Route(labels=["__file_uri__", "__file_uri__"])
    assert router.finalize(route) == route

    # test case 3
    route = Route(labels=["__file_uri__", "__file_uri__", "__file_uri__"])
    assert router.finalize(route) == route

    # test case

# Generated at 2022-06-12 09:31:07.824257
# Unit test for constructor of class Router
def test_Router():
    router_object = Router()
    assert isinstance(router_object, Router)


# Generated at 2022-06-12 09:31:13.981258
# Unit test for constructor of class Router
def test_Router():
    assert Router().routes == {}
    assert Router().routes_dynamic == list()
    assert Router().routes_static == list()
    assert Router().routes_regex == list()
    assert Router().name_index == {}
    assert Router().host_index == {
        None: {
            Router.DEFAULT_METHOD: [],
            "GET": [],
            "HEAD": [],
            "POST": [],
            "PUT": [],
            "DELETE": [],
            "OPTIONS": [],
        }
    }


# Generated at 2022-06-12 09:31:21.110025
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.constants import HTTP_METHODS

    @lru_cache(maxsize=ROUTER_CACHE_SIZE)
    def get(self, path: str, method: str, host: Optional[str]):
        try:
            return self.resolve(
                path=path,
                method=method,
                extra={"host": host},
            )
        except RoutingNotFound as e:
            raise NotFound("Requested URL {} not found".format(e.path))
        except NoMethod as e:
            raise MethodNotSupported(
                "Method {} not allowed for URL {}".format(method, path),
                method=method,
                allowed_methods=e.allowed_methods,
            )
    
    router = Router()

# Generated at 2022-06-12 09:31:25.209488
# Unit test for method finalize of class Router
def test_Router_finalize():
    from . import Sanic
    app = Sanic(__name__)

    router = Router(app)
    route = Route(router, uri="/user/<__file_uri__>/<name>")
    router.dynamic_routes["/user/<__file_uri__>/<name>"] = route

    # Assert no exception raised
    router.finalize()



# Generated at 2022-06-12 09:31:30.583504
# Unit test for method finalize of class Router
def test_Router_finalize():
    def test_app(app, ctx, routes):
        router = Router(app, ctx)
        router.routes_dynamic = routes
        router.finalize()

    # Check that without dynamic routes, does nothing
    empty_router = Router(None, None)
    empty_router.finalize()  # Should not raise

    # Check that dynamic routes with allowed double underscore label
    # does not raise
    test_app(None, None, routes={"non_empty": [Route("/")]})

    # Check that dynamic routes with a disallowed double underscore label
    # raises an exception
    with pytest.raises(SanicException):
        test_app(None, None, routes={"__empty": [Route("/")]})

# Generated at 2022-06-12 09:32:46.862745
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.app import Sanic
    from sanic.router import Router
    try:
        app = Sanic("sanic-app")
        router = Router(app)

        router.add("/dynamic/<param>", ["GET"], lambda request , param: None)
        router.finalize()

        assert True
    except SanicException:
        assert False

    try:
        app = Sanic("sanic-app")
        router = Router(app)

        router.add("/dynamic/<__param>", ["GET"], lambda request, __param: None)
        router.finalize()

        assert False
    except SanicException:
        assert True



# Generated at 2022-06-12 09:32:47.869566
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.name_index == {}

# Generated at 2022-06-12 09:32:49.140739
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add("/test/<id>")
    router.finalize()


# Generated at 2022-06-12 09:32:50.327858
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-12 09:32:58.095357
# Unit test for constructor of class Router
def test_Router():
    # Build functions that are used by the object to be constructed
    def add(
        self,
        uri,
        methods,
        handler,
        host=None,
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version=None,
        name=None,
        unquote=False,
        static=False,
    ):
        pass

    def finalize(self, *args, **kwargs):
        pass

    # Instantiate object
    router = Router(add, finalize)

    # Test methods
    router.routes_all
    router.routes_regex
    router.routes_dynamic
    router.routes_static

# Generated at 2022-06-12 09:32:59.705513
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.name_index == {None: None}
    assert router.ctx.app == None


# Generated at 2022-06-12 09:33:02.033348
# Unit test for constructor of class Router
def test_Router():
    assert callable(Router)



# Generated at 2022-06-12 09:33:06.027409
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    count = 0
    for label in ALLOWED_LABELS:
        route = router.add(uri="/", methods=["GET"], handler=None, name=label)
        if label.startswith("__") and label not in ALLOWED_LABELS:
            count += 1
    assert count == 0
    assert router.finalize() is None


# Generated at 2022-06-12 09:33:10.477652
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router

    _router = Router()
    _router.dynamic_routes = {0: Route("get", "/<_id>/", None, 0, [("__id__",)], None, None, False, False)}

    try:
        _router.finalize()
    except SanicException as e:
        assert str(e) == "Invalid route: <Route: GET /<_id>/>. Parameter names cannot use '__'."
    else:
        assert False, "Should have raised an exception"

# Generated at 2022-06-12 09:33:11.336184
# Unit test for constructor of class Router
def test_Router():
    assert callable(Router)

# Generated at 2022-06-12 09:35:34.215530
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    router.add("/", ["GET"], lambda x: x)
    router.find_route_by_view_name("/")
    router.get("/", "GET", None)
    router.finalize()

# Generated at 2022-06-12 09:35:35.846228
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None


# Generated at 2022-06-12 09:35:39.110596
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()  
    router.add('/test', ['GET'], print)
    router.add('/test2/<name>', ['GET'], print)
    router.add('/test3/<name>', ['GET'], print)
    router.finalize()
    assert True

# Generated at 2022-06-12 09:35:42.068688
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes == []
    assert router.static_routes == []
    assert router.dynamic_routes == {}
    assert router.regex_routes == []
    assert router.name_index == {}

# Generated at 2022-06-12 09:35:43.831409
# Unit test for constructor of class Router
def test_Router():
    routes = Router()
    assert isinstance(routes, Router)


if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-12 09:35:44.997745
# Unit test for constructor of class Router
def test_Router():
    test_router = Router(2)
    assert type(test_router) == Router
    assert test_router.ctx == 2


# Generated at 2022-06-12 09:35:48.013910
# Unit test for constructor of class Router
def test_Router():
    """
    GIVEN: A Router class with no argument
    WHEN:  A Router object is created
    THEN:  The router should be created successfully
    """
    router = Router()
    assert router is not None
    assert router.ctx is None


# Generated at 2022-06-12 09:35:55.550763
# Unit test for constructor of class Router
def test_Router():
    uri = 'https://www.baidu.com/'
    methods = ['GET', 'POST']
    handler = None
    host = ['abc.com', 'www.abc.com', 'github.com']
    strict_slashes = True
    stream = False
    ignore_body = True
    version = '1.0'
    name = 'test'
    unquote = False
    static = False

    router = Router()
    router.add(
        uri,
        methods,
        handler,
        host,
        strict_slashes,
        stream,
        ignore_body,
        version,
        name,
        unquote,
        static
    )

    router.find_route_by_view_name('test', name='test')