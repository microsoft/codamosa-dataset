

# Generated at 2022-06-12 09:25:45.673302
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    from sanic.routing import bind_routes

    class RouterTest(Router):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        #----------------------------------------------------------------------
        @property
        def routes_all(self):
            return self.routes

        @property
        def routes_static(self):
            return self.static_routes

        @property
        def routes_dynamic(self):
            return self.dynamic_routes

        @property
        def routes_regex(self):
            return self.regex_routes

    @bind_routes(routes=[("/", "index")])
    def test_index():
        pass


# Generated at 2022-06-12 09:25:46.455056
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router == None

# Generated at 2022-06-12 09:25:53.222533
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    router = Router(None)

    route_1 = Route("GET", "/", "handler", {})
    router.dynamic_routes[route_1.hash] = route_1

    route_2 = Route("GET", "/", "handler", {"__file_uri__":"file"})
    router.dynamic_routes[route_2.hash] = route_2

    assert router.finalize() is None

    route_3 = Route("GET", "/", "handler", {"__test_uri__":"file"})
    router.dynamic_routes[route_3.hash] = route_3

    with pytest.raises(SanicException):
        assert router.finalize()



# Generated at 2022-06-12 09:26:03.317554
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router(None)
    try:
        router.add(uri="/<__bad_label>", methods=["GET"], handler=None)
        assert False
    except SanicException:
        assert True

    router.dynamic_routes = {1: Route(None, None, None)}
    try:
        router.finalize()
        assert False
    except SanicException:
        assert True

    router.dynamic_routes = {1: Route(None, None, None)}
    router.add(uri="/sanic", methods=["GET"], handler=None)
    try:
        router.finalize()
        assert False
    except SanicException:
        assert True

    router.dynamic_routes = {1: Route(None, None, None)}

# Generated at 2022-06-12 09:26:04.382317
# Unit test for constructor of class Router
def test_Router():
    try:
        Router()
        assert True
    except:
        assert False

# Generated at 2022-06-12 09:26:10.309627
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add_route(uri='/', handler=None, methods=['POST'], name='test')
    assert router.routes['POST'][0].name == 'test'
    router.add_route(uri='/', handler=None, methods=['GET'], name='test1')
    assert router.routes['POST'][0].name == 'test'
    assert router.routes['GET'][0].name == 'test1'
    router.finalize()


# Generated at 2022-06-12 09:26:19.933247
# Unit test for method finalize of class Router
def test_Router_finalize():
    # constructor test
    route_ = Route(
        path=None,
        handler=None,
        methods=None,
        name=None,
        strict=False,
        unquote=False,
        host=None,
    )
    # attribute test
    route_.ctx.hosts = None
    route_.ctx.ignore_body = True
    route_.ctx.stream = False
    route_.ctx.static = False
    # function test
    router = Router(
        regex_index={},
        uri_index={},
        name_index={},
        custom_index={},
        ctx_key=None,
        uri_partition_regex=None,
    )
    router.ctx.app = None
    router.ctx.app.router = None
    router.ctx.app._generate_name

# Generated at 2022-06-12 09:26:28.733053
# Unit test for constructor of class Router
def test_Router():
    router = Router( loop = "loop", error_handler = "error_handler",
                     strict_slashes = "strict_slashes", host_matching = "host_matching" )
    assert( router.loop == "loop" )
    assert( router.error_handler == "error_handler" )
    assert( router.strict_slashes == "strict_slashes" )
    assert( router.host_matching == "host_matching" )
    assert( router.routes_all == {} )
    assert( router.routes_static == {} )
    assert( router.routes_dynamic == {} )
    assert( router.routes_regex == {} )
    assert( router.name_index == {} )
    assert( router.prefix == "" )

# Generated at 2022-06-12 09:26:30.999363
# Unit test for method finalize of class Router
def test_Router_finalize():
    route = Route(uri='/test/:name')
    routes = Router()
    routes.dynamic_routes = {None: {route}}
    routes.finalize()



# Generated at 2022-06-12 09:26:32.139870
# Unit test for constructor of class Router
def test_Router():
	router_class = Router()
	assert isinstance(router_class, Router) == True


# Generated at 2022-06-12 09:26:38.894040
# Unit test for constructor of class Router
def test_Router():
    try:
        router = Router()
    except Exception as e:
        pytest.fail(f"Failed to instantiate router: {e}")


# Generated at 2022-06-12 09:26:41.124156
# Unit test for constructor of class Router
def test_Router():
    def foo(*args, **kwargs):
        pass

    router = Router()
    router.add('/foo', ['OPTIONS', 'GET', 'POST'], foo)
    
    assert True


# Generated at 2022-06-12 09:26:45.900875
# Unit test for method finalize of class Router
def test_Router_finalize():
    route_uri = "/foo"
    method = "GET"
    handler = lambda r: None
    router = Router()
    route = router.add(route_uri, method, handler)
    with pytest.raises(SanicException) as ex:
        router.finalize()
    assert "Invalid route" in str(ex)



# Generated at 2022-06-12 09:26:47.654181
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-12 09:26:48.614699
# Unit test for constructor of class Router
def test_Router():
    assert Router(None, None)


# Generated at 2022-06-12 09:26:58.062131
# Unit test for constructor of class Router
def test_Router():
    uri = "https://www.google.com"
    methods = ["GET","POST","OPTIONS"]
    handler = RouteHandler
    host = "Test"
    strict_slashes = False
    stream = True
    ignore_body = True
    version = "1.0"
    name = "Route"
    unquote = True
    static = True
    
    # Check if the class is instantiated
    assert Router()
    router = Router()
    # Check if the function of method get is called
    assert router.get(path = uri, method = methods[0], host = host)
    # Check if the function of method add is called

# Generated at 2022-06-12 09:26:59.057462
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    return router


# Generated at 2022-06-12 09:27:03.264864
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.strict_slashes = False
    router.add('/test', {'GET'}, lambda x: x, host=None, strict_slashes=False, stream=False, ignore_body=False, version=None, name=None, unquote=False, static=False)
    router.finalize()


# Generated at 2022-06-12 09:27:03.795117
# Unit test for constructor of class Router
def test_Router():
    Router()

# Generated at 2022-06-12 09:27:08.713064
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    correct_route = Route("/test", lambda x: x, ["GET"], name="test")
    router.add("/test", ["GET"], lambda x: x, name="test")
    assert router.find_route_by_view_name("test").dynamic_route == correct_route


if __name__ == "__main__":
    test_Router_finalize()
    print("Everything passed")

# Generated at 2022-06-12 09:27:24.339660
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    Unit test for method finalize of class Router

    Note
        When testing validation error, additional try-except block is needed
        for catching exception raised by Router.finalize.
    """
    router = Router("/")
    router.add("/<__filename>/<file_name>", ["GET", "POST"], lambda x: x)

    with pytest.raises(SanicException):
        try:
            router.finalize()
        except Exception as ex:
            assert "__filename" in str(ex) and "__" in str(ex)
            raise ex
    assert False

# Generated at 2022-06-12 09:27:25.551890
# Unit test for constructor of class Router
def test_Router():
    assert Router().__class__.__name__ == "Router"

# Generated at 2022-06-12 09:27:28.087536
# Unit test for constructor of class Router
def test_Router():
    """
    >> router = Router()
    >> router.ctx
    {}
    """
    router = Router()
    assert router.ctx == {}

# Unit tests for property routes_all of class Router

# Generated at 2022-06-12 09:27:34.757360
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router(app=None)
    test_route = Route(
        "/test/<p1>/<p2>",
        None,
        None,
        None,
        strict=False,
        unquote=False,
        host=None,
        requirements={},
        name=None,
        ctx={},
        labels={},
        host_matching=False,
        host_matching_strict=False,
    )
    test_route.labels.update({"__file_uri__": ""})
    router.dynamic_routes.update({('GET', '/test/<p1>/<p2>'): test_route})
    router.finalize()
    
    

# Generated at 2022-06-12 09:27:43.256186
# Unit test for method add of class Router
def test_Router_add():
    # Case 1: add method ,host is str
    router = Router()
    router.add("/test", ["GET"], "test",host="host")
    assert router.hosts["host"] == {"/test": {"GET"}}

    #Case 2: add method,host is list
    router.add("/test", ["POST"], "test", host=["host", "host1"])
    assert router.hosts["host"] == {"/test": {"GET", "POST"}}
    assert router.hosts["host1"] == {"/test": {"GET", "POST"}}

    # Case 3: add method, host is None
    router.add("/test", ["PUT"], "test")
    assert router.hosts[None] == {"/test": {"GET", "POST", "PUT"}}

    # Case 4: version is not None

# Generated at 2022-06-12 09:27:44.686478
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add("/", {})
    router.finalize()



# Generated at 2022-06-12 09:27:45.445511
# Unit test for constructor of class Router
def test_Router():
    router = Router()


# Generated at 2022-06-12 09:27:51.414633
# Unit test for constructor of class Router
def test_Router():
    from sanic.router import Router
    from sanic.router import ROUTER_CACHE_SIZE
    from sanic.router import ALLOWED_METHODS
    from sanic.router import DEFAULT_METHOD
    from functools import lru_cache
    from sanic_routing import BaseRouter
    from sanic_routing.exceptions import NoMethod
    from sanic_routing.exceptions import NotFound as RoutingNotFound
    from sanic_routing.route import Route
    from typing import Any, Dict, Iterable, List, Optional, Tuple, Union
    from sanic.request import Request
    from sanic.constants import HTTP_METHODS

    # 1. testing constructor Router
    assert Router.ROUTER_CACHE_SIZE == ROUTER_CACHE_SIZE


# Generated at 2022-06-12 09:27:53.089481
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    # print(r.routes)


# Generated at 2022-06-12 09:28:02.058270
# Unit test for constructor of class Router
def test_Router():
    import mock
    import unittest
    from sanic.router import Router as RouterClass
    
    
    router = RouterClass()
    assert isinstance(router, Router)
    assert router.routes_all({}) == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.routes_all_by_method == {'OPTIONS': {}, 'HEAD': {}, 'GET': {}, 'POST': {}, 'PUT': {}, 'DELETE': {}, 'PATCH': {}, 'TRACE': {}}
    assert router.name_index == {}
    assert router.ctx == mock.ANY


# Generated at 2022-06-12 09:28:19.639998
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    from sanic.exceptions import SanicException

    # If the value of any key in the labels of the route object starts with '__' and is not in the ALLOWED_LABELS list,
    # raises an exception, else it works normally.
    def test(labels):
        router = Router()
        route = Route(handler=None, path='aaaa', labels=labels)
        router.dynamic_routes['aaaa'] = route
        if any( label.startswith('__') and label not in ALLOWED_LABELS for label in labels):
            with pytest.raises(SanicException):
                router.finalize()
        else:
            router.finalize()
    

# Generated at 2022-06-12 09:28:20.464958
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router


# Generated at 2022-06-12 09:28:22.583819
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    r.add("/hello/<pal>", ["GET"], lambda *args, **kwargs: "hello")
    r.add("/hello/<pal>", ["GET"], lambda *args, **kwargs: "hello")

# Generated at 2022-06-12 09:28:24.380354
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes == {}
    assert router.route_counter == 0



# Generated at 2022-06-12 09:28:34.314316
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == router.get('/api/1.0/services', 'GET', host=None)[0].method
    assert router.DEFAULT_METHOD == router.get('/api/1.0/services', 'POST', host=None)[0].method
    assert router.DEFAULT_METHOD == router.get('/api/1.0/services', 'OPTIONS', host=None)[0].method
    try:
        router.get('/api/1.0/services', 'DELETE', host=None)
        assert False
    except MethodNotSupported as e:
        assert e.method == 'DELETE'
        assert e.allowed_methods == ['GET', 'POST', 'OPTIONS']
    assert router.DEFAULT_METHOD == router.find_route_by_view

# Generated at 2022-06-12 09:28:38.448981
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes == {}
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app is None


# Generated at 2022-06-12 09:28:45.654790
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    from sanic.router import Router
    from sanic.exceptions import SanicException

    def test_route_labels_with_double_underscores():
        router = Router()
        router.add("/hello/<__file_uri__>")

        router.finalize()

    def test_route_labels_with_single_underscores():
        router = Router()
        router.add("/hello/<username>")

        with pytest.raises(SanicException) as exception:
            router.finalize()

    test_route_labels_with_double_underscores()
    test_route_labels_with_single_underscores()

# Generated at 2022-06-12 09:28:46.692582
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-12 09:28:51.584695
# Unit test for constructor of class Router
def test_Router():
    route_1 = Router()
    assert route_1.routes_all == []
    assert route_1.routes_static == []
    assert route_1.routes_dynamic == []
    assert route_1.routes_regex == []


# Generated at 2022-06-12 09:28:52.254378
# Unit test for method finalize of class Router
def test_Router_finalize():
    pass

# Generated at 2022-06-12 09:29:14.504100
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        rtr = Router()
        rtr.add(uri='/', methods=['GET'], handler=None, host=None, strict_slashes=False, stream=False,
                ignore_body=False, version=None, name=None, unquote=False, static=False)
        rtr.finalize()
        assert True
    except AssertionError:
        assert False



# Generated at 2022-06-12 09:29:22.318976
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    # Test error case
    with pytest.raises(SanicException):
        router.add('/test', ['GET', 'POST'], None,
                   host=None, strict_slashes=False, stream=False, ignore_body=False,
                   version=None, name=None, unquote=False, static=False)
        router.finalize()
    # Test normal case
    router = Router()
    router.add('/test', ['GET', 'POST'], None,
               host=None, strict_slashes=False, stream=False, ignore_body=False,
               version=None, name=None, unquote=False, static=False)
    router.finalize()

# Generated at 2022-06-12 09:29:23.442757
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)

# Generated at 2022-06-12 09:29:29.296255
# Unit test for method finalize of class Router
def test_Router_finalize():
    import sanic
    app = sanic.Sanic('sanic')
    router = Router()
    app.router = router

    def test_route():
        pass

    try:
        router.add('/test', [Router.DEFAULT_METHOD], test_route)
        router.add('/test1/<__test>', ['GET'], test_route)
        router.finalize()
    except Exception as error:
        assert str(error) == "Invalid route: /test1/<__test>." \
            " Parameter names cannot use '__'."
    else:
        assert False, "Expected Exception"

# Generated at 2022-06-12 09:29:30.083874
# Unit test for constructor of class Router
def test_Router():
    assert Router()

# Generated at 2022-06-12 09:29:38.830402
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic_routing.route import Route
    from sanic_routing.router import Router
    from sanic.request import Request

    def handler(req): pass
    def handler_static(req): pass

    router = Router()
    route1 = Route(handler=handler, path="/", methods=["GET"])
    route2 = Route(handler=handler, path="/<param>", methods=["GET"])
    route3 = Route(handler=handler_static, path="/static/<param>", methods=["GET"], static=True)

    routes = [route1, route2, route3]

    router.ctx.host = "localhost"
    router.static_routes = routes
    
    request = Request("GET", "/", {}, {}, b"", "localhost")


# Generated at 2022-06-12 09:29:39.775892
# Unit test for constructor of class Router
def test_Router():
  router = Router()
  assert router

# Generated at 2022-06-12 09:29:40.617118
# Unit test for constructor of class Router
def test_Router():
    a = Router(None)

# Generated at 2022-06-12 09:29:44.319303
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    # Check if router.routes is same as BaseRouter.dynamic_routes
    assert router.routes_dynamic == BaseRouter.dynamic_routes
    # Check default values
    assert router.ctx.split_query_params == True

# Generated at 2022-06-12 09:29:47.905411
# Unit test for constructor of class Router
def test_Router():
    method = HTTP_METHODS
    def handler():
        pass
    assert isinstance(Router(), BaseRouter)
    assert isinstance(Router(method,handler), BaseRouter)
    assert isinstance(Router().DEFAULT_METHOD, str)
    assert isinstance(Router().ALLOWED_METHODS, list)


# Generated at 2022-06-12 09:30:27.657800
# Unit test for constructor of class Router
def test_Router():
    method = 'post'
    uri = '/post/<id>'
    handler = 'action'
    router = Router()
    router.add(uri,method,handler)
    assert router.routes_dynamic == {uri: [('post', handler)]}
    assert router.routes_dynamic.keys() == {uri}
    assert router.routes_dynamic.values() == [('post', handler)]
    return router

# Generated at 2022-06-12 09:30:28.784784
# Unit test for constructor of class Router
def test_Router():
  from sanic.router import Router
  assert isinstance(Router(), Router)

# Generated at 2022-06-12 09:30:29.215489
# Unit test for constructor of class Router
def test_Router():
    pass

# Generated at 2022-06-12 09:30:35.308036
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    import unittest
    import pytest

    class Test_Router_finalize(unittest.TestCase):
        # test for case when label have not allowed name
        def test_not_allowed_labels(self):
            router = Router()
            route = router.add(uri='/', methods=['GET'], handler='')
            route.labels = ['abc_abc']
            try:
                router.finalize()
            except SanicException as e:
                assert str(e) == "Invalid route: / -> GET(name=None). Parameter names cannot use '__'."
            else:
                pytest.fail("Test should fail")

        # test for case when label is allowed
        def test_allowed_labels(self):
            router = Router()

# Generated at 2022-06-12 09:30:41.322563
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.dynamic_routes = {'test': 'route'}
    try:
        router.finalize()
    except SanicException:
        pass
    except Exception as e:
        assert False, e
    else:
        assert False, "Router.finalize() dosen't raise SanicException"
    router.dynamic_routes = {'test': '__file_uri__'}
    try:
        router.finalize()
    except SanicException:
        assert False, "Router.finalize() raise SanicException"
    except Exception as e:
        assert False, e



# Generated at 2022-06-12 09:30:47.034163
# Unit test for constructor of class Router
def test_Router():
    from sanic.app import Sanic

    app = Sanic("router_test")

    router = Router(app=app)

    assert router.ctx == app
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.regex_index == {}
    assert router.ctx.router == router

# Generated at 2022-06-12 09:30:51.445046
# Unit test for constructor of class Router
def test_Router():
    class App:
        def __init__(self, *args, **kwargs):
            self.config = {}
            self.error_handler = {}
            self.log = {}
            self.cleanup_ctx = []
            self.before_start = []
            self.after_start = []
            self.before_stop = []
            self.after_stop = []
            self.before_start_server_list = []
            self.after_start_server_list = []
            self.before_stop_server_list = []
            self.after_stop_server_list = []
            self.before_serving = []
            self.after_serving = []

    app = App()
    router = Router(app)
    assert router.ctx == app

# Generated at 2022-06-12 09:30:52.186207
# Unit test for method finalize of class Router
def test_Router_finalize():
    assert True == True

# Generated at 2022-06-12 09:30:52.966945
# Unit test for constructor of class Router
def test_Router():
  r1 = Router()
  print(r1)
  


# Generated at 2022-06-12 09:30:57.114104
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic_routing.route import Route
    from sanic.constants import HTTP_METHODS
    from sanic.exceptions import MethodNotSupported, NotFound, SanicException

    try:
        from sanic.exceptions import ServerError as SanicException
    except ImportError:
        from sanic.exceptions import SanicException

    router = Router()
    app = test_app = object()

    route = Route(path='/', handler=lambda request: 'OK', methods=HTTP_METHODS, app=app)

    router.add(uri='/', methods=['GET', 'POST'], handler=lambda request: 'OK', stream=False)
    router.add(uri='/', methods=['GET', 'POST'], handler=lambda request: 'OK', stream=True)
   

# Generated at 2022-06-12 09:32:11.787468
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route(path='/path', handler=None, methods=['GET'], labels=['a__b'])
    router.dynamic_routes = {'s': [route]}
    # Wrong
    try:
        router.finalize()
    except SanicException:
        pass
    # Right
    router.dynamic_routes = {}
    router.finalize()

# Generated at 2022-06-12 09:32:15.412134
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r.ALLOWED_METHODS == tuple(method.upper() for method in HTTP_METHODS)
    assert r.DEFAULT_METHOD == "GET"
    assert r.ctx == {}
    assert r.dynamic_routes == {}
    assert r.name_index == {}
    assert r.static_routes == {}

# Generated at 2022-06-12 09:32:16.723197
# Unit test for constructor of class Router
def test_Router():
    from sanic.router import Router
    router = Router()
    return router



# Generated at 2022-06-12 09:32:18.269123
# Unit test for constructor of class Router
def test_Router():  # type: ignore
    """
    Constructor of class Router
    """
    assert isinstance(Router(), Router)

# Generated at 2022-06-12 09:32:24.189093
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router as Router_test
    from sanic.request import Request
    from sanic.response import text
    import pytest
    
    
    test_app = Application()
    
    @test_app.get("/")
    async def index(request):
        return text("hoo")
        
    request, response = test_app.test_client.get('/')
    
    with pytest.raises(SanicException):
        request.app.router.finalize()
        
if __name__ == "__main__":
    test_Router_finalize()

# Generated at 2022-06-12 09:32:31.209142
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()

    allowed_route = Route(path="", allowed_methods=set(HTTP_METHODS))
    allowed_route.labels.add("__file_uri__")
    router.add_route(allowed_route)

    invalid_routes = [
        Route(path=""),
        Route(path=""),
        Route(path=""),
    ]

    for route in invalid_routes:
        route.labels.add("__invalid_name__")
        router.add_route(route)

    with pytest.raises(SanicException):
        router.finalize()

# Generated at 2022-06-12 09:32:33.540565
# Unit test for constructor of class Router
def test_Router():
    route = Router()
    assert route.DEFAULT_METHOD == "GET"
    assert route.ALLOWED_METHODS == HTTP_METHODS

# Generated at 2022-06-12 09:32:38.797345
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.app import Sanic
    from sanic.router import Route
    my_app = Sanic("app")
    route = Route("GET", "/url/<name>", None)
    router = Router()
    router.add("/url/<name>", ["GET"], None)
    try:
        router.finalize(my_app)
    except SanicException as e:
        assert str(e) == "Invalid route: Route(GET, //url/<name>, None). Parameter names cannot use '__'."

# Generated at 2022-06-12 09:32:47.503234
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Test for no error
    try:
        route = Route(
            path='/',
            methods=['GET'],
            handler=None,
            name=None,
            strict=True,
            unquote=False
        )
        Router().dynamic_routes['test'] = route
        Router().finalize()
        assert True
    except SanicException:
        assert False

    # Test for error
    try:
        route = Route(
            path='/',
            methods=['GET'],
            handler=None,
            name=None,
            strict=True,
            labels=['__test'],
            unquote=False
        )
        Router().dynamic_routes['test'] = route
        Router().finalize()
        assert False
    except SanicException:
        assert True

# Generated at 2022-06-12 09:32:49.591244
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router('ctx')
    r.dynamic_routes = {'a': 'b'}
    with pytest.raises(SanicException):
        r.finalize()


# Generated at 2022-06-12 09:34:44.171484
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.exceptions import SanicException
    from sanic.router import Router

    try:
        router = Router()
        route = router.add(uri="/test", methods=["GET"], handler=None, strict_slashes=False, stream=False, ignore_body=False, version=None, name=None, unquote=False, static=False)
        route.labels.append("__new_labels")
        router.finalize()
    except Exception as e:
        assert isinstance(e, SanicException)

# Generated at 2022-06-12 09:34:48.194092
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add(uri='/{foo}', methods=['GET'], handler=None, host=None, strict_slashes=False, stream=False, ignore_body=False, version=None, name=None, unquote=False, static=False)

    try:
        router.finalize()
    except:
        raise AssertionError()

# Generated at 2022-06-12 09:34:50.177353
# Unit test for method finalize of class Router
def test_Router_finalize():
    with pytest.raises(SanicException):
        Router()
        Router().finalize()

# Generated at 2022-06-12 09:34:55.744190
# Unit test for method finalize of class Router
def test_Router_finalize():
    '''
    Unit test for method finalize of class Router
    '''
    router = Router()
    router.add("/", "GET", lambda x: x)
    router.add("/<id:int>", "GET", lambda x: x)
    router.add("/<__file_uri__:path>", "GET", lambda x: x)
    try:
        router.finalize()
    except SanicException:
        assert True
    except:
        assert False

# Generated at 2022-06-12 09:35:00.528532
# Unit test for constructor of class Router
def test_Router():
    r1 = Router()
    assert type(r1) == Router
    assert r1.__class__.__name__ == 'Router'
    assert r1.DEFAULT_METHOD == 'GET'
    assert r1.ALLOWED_METHODS == ['GET', 'HEAD', 'POST', 'PUT', 'PATCH', 'OPTIONS', 'DELETE', 'TRACE']



# Generated at 2022-06-12 09:35:05.289970
# Unit test for constructor of class Router
def test_Router():
    assert Router().routes, "Router has no routes."
    assert Router().static_routes, "Router has no static routes."
    assert Router().dynamic_routes, "Router has no dynamic routes."
    assert Router().regex_routes, "Router has no regex routes."
    assert Router().DEFAULT_METHOD == "GET", "Router has no default method."
    assert Router().ALLOWED_METHODS, "Router has no allowed methods."

# Generated at 2022-06-12 09:35:07.069509
# Unit test for method finalize of class Router
def test_Router_finalize():
    with pytest.raises(SanicException):
        Router().finalize({
            "/test/<__test_label>":
            lambda: None
        })



# Generated at 2022-06-12 09:35:08.652758
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = {"labels": ["__file_uri__"]}
    router.dynamic_routes["test"] = route
    router.finalize()

# Generated at 2022-06-12 09:35:10.716544
# Unit test for constructor of class Router
def test_Router():
    assert Router.DEFAULT_METHOD == "GET"
    assert len(Router.ALLOWED_METHODS) == 10


# Generated at 2022-06-12 09:35:18.222717
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    Sanic의 Router 클래스는 Sanic의 응답을 담당하는 Routing 기능을 제공하는 클래스이다.

    :param args:
    :param kwargs:
    :return:
    """
    '''
    Sanic의 Router 클래스는 Sanic의 응답을 담당하는 Routing 기능을 제공하는 클래스이다.
    '''