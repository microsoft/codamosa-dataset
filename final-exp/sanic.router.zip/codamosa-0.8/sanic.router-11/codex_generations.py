

# Generated at 2022-06-12 09:25:52.591758
# Unit test for constructor of class Router
def test_Router():
    try:
        router = Router()
    except Exception as err:
        print('Unable to create router object : {}'.format(err))


# Generated at 2022-06-12 09:26:02.841944
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    ROUTER_CACHE_SIZE = 1024
    ALLOWED_LABELS = ("__file_uri__",)

    class Router(BaseRouter):
        """

# Generated at 2022-06-12 09:26:05.051450
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.ctx.app is None
    assert router.DEFAULT_METHOD is "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS


# Generated at 2022-06-12 09:26:05.444319
# Unit test for method finalize of class Router
def test_Router_finalize():
    pass

# Generated at 2022-06-12 09:26:06.516802
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, BaseRouter)


# Generated at 2022-06-12 09:26:10.531878
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    try:
        router.add(uri='/', methods=['GET'], handler=lambda _, a: a)
    except SanicException as e:
        assert str(e).startswith('Invalid route')
    else:
        assert False, 'SanicException not raised'

# Generated at 2022-06-12 09:26:17.156016
# Unit test for constructor of class Router
def test_Router():
    # assert Router().DEFAULT_METHOD == "GET"
    assert Router().ALLOWED_METHODS == HTTP_METHODS
    from sanic.exceptions import NotFound, MethodNotSupported, SanicException
    from sanic.constants import HTTP_METHODS
    from sanic.models.handler_types import RouteHandler
    from sanic_routing import Route
    from sanic_routing.exceptions import RoutingNotFound
    from sanic.exceptions import MethodNotSupported, NotFound, SanicException
    from functools import lru_cache


# Generated at 2022-06-12 09:26:20.351847
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.routes_static == {}



# Generated at 2022-06-12 09:26:22.063280
# Unit test for constructor of class Router
def test_Router():
    """ Unit test for constructor of class Router. """
    router = Router()
    assert router is not None

# Generated at 2022-06-12 09:26:26.870680
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route('/hello', 'GET', None, None, None)
    route.labels = ["__file_uri__", "__invalid__"]
    router.dynamic_routes = {'hello':route}
    try:
        router.finalize()
    except SanicException as e:
        assert f"Invalid route: {route}. Parameter names cannot use '__'." == str(e)

# Generated at 2022-06-12 09:26:36.686736
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.constants import HTTP_METHODS

    from sanic_routing import BaseRouter
    from sanic_routing.exceptions import LoadError

    from sanic.app import Sanic

    app = Sanic("test_app")

    router = Router(app, base_uri=None)
    r = router.add
    r("/", ["GET", "POST"], {})
    r("/users/<id>", ["GET"], {})
    r("/users/<id:int>", ["GET"], {})
    r(
        "/users/<id:int>",
        ["POST", "GET"],
        {},
        host=["example.com"],
        version=1.0,
    )
    r("/v2/users", ["GET"], {}, version=2.0)
    r

# Generated at 2022-06-12 09:26:39.463723
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    uri = '/test'
    methods = ['GET']
    def handler(*args, **kwargs):
        return "test handler"
    route = router.add(uri, methods, handler)
    assert router.finalize() == None

# Generated at 2022-06-12 09:26:40.693242
# Unit test for constructor of class Router
def test_Router():
    router = Router()  # type: ignore
    assert router


# Generated at 2022-06-12 09:26:50.479623
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    from sanic.router import Route
    from sanic.constants import HTTP_METHODS
    from sanic.exceptions import SanicException
    router = Router(app=None)

    # Test 1
    try:
        route = Route(path='/', handler=None)
        router.dynamic_routes[1] = route
        router.finalize()
    except SanicException:
        assert True
    else:
        assert False

    # Test 2
    try:
        route.labels = ['__', '__aa', '__file_uri__']
        route.path = '/__'
        router.dynamic_routes[2] = route
        router.finalize()
    except SanicException:
        assert True
    else:
        assert False

    # Test 3


# Generated at 2022-06-12 09:26:55.375272
# Unit test for method finalize of class Router
def test_Router_finalize():
    result = Router()
    result.uri_templates = {
        "test": Route(
            path=None,
            methods=None,
            handler=None,
            name=None,
            strict=None,
            unquote=None,
        )
    }
    assert result.finalize() == None


# Generated at 2022-06-12 09:27:01.958994
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == []
    assert router.routes_regex == []
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == ["GET", "HEAD", "POST", "PUT", "DELETE", "PATCH", "OPTIONS", "TRACE"]
    assert router.ctx is None
    assert router.name_index == {}


# Generated at 2022-06-12 09:27:04.421759
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    _router = Router()
    _router.add(uri="/", methods=["get"], handler=None)
    _router.finalize()
    
    

# Generated at 2022-06-12 09:27:09.530635
# Unit test for constructor of class Router
def test_Router():
    """
    This function is used to test the constructor of class Router

    """
    # Unit test for constructor - when request_factory is not None
    r = Router()
    assert r.dynamic_routes == dict()
    assert r.static_routes == dict()
    assert r.regex_routes == dict()
    assert r.name_index == dict()
    assert r.ctx is None
    assert r.resolver_factory is None


# Generated at 2022-06-12 09:27:18.012201
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.ctx import RequestParameters
    from sanic.response import HTTPResponse

    async def index(request):
        return HTTPResponse("index")

    def index1(request):
        return HTTPResponse("index1")

    def index2(request):
        return HTTPResponse("index2")

    router = Router(None)
    router.add("/test/<__test>/<test>/", index)

    with pytest.raises(SanicException):
        router.finalize()

    router.add("/test1/<test>/", index1)
    router.add("/test2/<__test>/", index2)
    router.finalize()

    results = router.routes_dynamic.get("/test1/<test>/")


# Generated at 2022-06-12 09:27:19.356706
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)

# Generated at 2022-06-12 09:27:32.205000
# Unit test for method add of class Router
def test_Router_add():
    from sanic import Sanic
    from sanic.response import json

    app = Sanic("test_Router_add")

    async def handler(request):
        return json({"test": True})

    router = Router()
    router.add("/test", ["GET"], handler)

    assert len(router.routes_all) == 1


# Generated at 2022-06-12 09:27:32.932738
# Unit test for method finalize of class Router
def test_Router_finalize():
    pass

# Generated at 2022-06-12 09:27:41.372379
# Unit test for constructor of class Router
def test_Router():
    from sanic.request import Request

    @lru_cache(maxsize=ROUTER_CACHE_SIZE)
    def get(self, path, method, host):
        try:
            return self.resolve(path=path, method=method, extra={"host": host})
        except RoutingNotFound as e:
            raise NotFound("Requested URL {} not found".format(e.path))
        except NoMethod as e:
            raise MethodNotSupported(
                "Method {} not allowed for URL {}".format(method, path),
                method=method,
                allowed_methods=e.allowed_methods,
            )

    Router.get = get
    router = Router()
    router.register_from_module('./')
    router.finalize()
    # Unit test for resolve of class Router
    ur

# Generated at 2022-06-12 09:27:43.481953
# Unit test for constructor of class Router
def test_Router():
    """
    check the constructor of Router
    :return:
    """
    # check if the base router is inherited
    assert isinstance(Router(), BaseRouter)



# Generated at 2022-06-12 09:27:50.516470
# Unit test for method finalize of class Router
def test_Router_finalize():
    # define a new class which inherits from the Router class
    class NewRouter(Router):
        def finalize(self):
            # call the superclass' finalize method
            super().finalize()

    dynamic_routes = {
        '/user/<id>': Route(
            uri = '/user/<id>',
            method = 'GET',
            handler = 'handler',
            name = 'get_user',
            strict = False,
            unquote = False,
            host = None,
            ctx = None
        )
    }

    # create an instance of the class
    test_instance = NewRouter(ctx={})
    # set routes to the dynamic routes
    test_instance.dynamic_routes = dynamic_routes
    # call finalize() method

# Generated at 2022-06-12 09:27:52.575715
# Unit test for method add of class Router
def test_Router_add():
    pass


if __name__ == "__main__":
    # Run the unit test
    test_Router_add()

# Generated at 2022-06-12 09:27:54.824757
# Unit test for constructor of class Router
def test_Router():
    # simple test cases
    # at the moment, no error reporting
    route = Router()
    assert route is not None
    return

# Generated at 2022-06-12 09:28:00.898685
# Unit test for constructor of class Router
def test_Router():
    r = Router(None)
    assert r.name == "router_routes"
    assert isinstance(r.routes, dict)
    assert isinstance(r.routes_all, dict)
    assert isinstance(r.routes_dynamic, dict)
    assert isinstance(r.routes_static, dict)
    assert isinstance(r.routes_regex, dict)
    assert isinstance(r.name_index, dict)


# Generated at 2022-06-12 09:28:03.447489
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


if __name__ == "__main__":
    import pytest

    pytest.main(["-s", "-q", "--tb=native", __file__])

# Generated at 2022-06-12 09:28:04.907835
# Unit test for constructor of class Router
def test_Router():
    """Constructor of the class was used with the __slots__ attribute."""
    instance = Router()
    assert instance


# Generated at 2022-06-12 09:28:24.502582
# Unit test for constructor of class Router
def test_Router():
    assert isinstance(Router(), Router) is True

# Generated at 2022-06-12 09:28:25.929853
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    print(router)


# Generated at 2022-06-12 09:28:35.785969
# Unit test for constructor of class Router
def test_Router():
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.utils import sanic_endpoint_test
    from sanic.exceptions import MethodNotSupported, NotFound

    # Create a Router instance
    router = Router()

    # Test the adding of a handler to the router
    router.add(uri='/', methods=['GET', 'POST'], handler=sanic_endpoint_test)

    # Test the getting and setting of the request
    request = Request(uri='/', method='GET')
    router.request = request

    # Test the getting and setting of the url_for function
    def url_for(name, **params):
        return '/'
    router.url_for = url_for

    # Test the getting of the method
    router.get_method()

    #

# Generated at 2022-06-12 09:28:37.918091
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert not router.paths
    assert router.name_index == {}
    assert router.routes_regex == []


# Generated at 2022-06-12 09:28:44.583125
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.route import Route
    from sanic.constants import HTTP_METHODS

    from sanic.exceptions import SanicException

    # Test for dynamic route 
    def test_finalize_with_dynamic_route():
        route = Route(
            '/<id:string>',
            'GET',
            handler=None,
            host=None,
            strict_slashes=None,
            stream=None,
            name=None,
            unquote=None,
        )
        router = Router()
        router.dynamic_routes = {
            "/<name:string>": route
        }
        Router.finalize(router)

    # Test for static route with invalid label

# Generated at 2022-06-12 09:28:45.481396
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router

# Generated at 2022-06-12 09:28:46.537574
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic_routing.route import _Route, Route
    

# Generated at 2022-06-12 09:28:57.157965
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.constants import HTTP_METHODS
    
    router = Router(None)
    # OrderedDict()
    route = router.add("/", HTTP_METHODS, None)
    assert len(router.routes) == 1
    assert len(router.routes_all) == 1
    assert len(router.routes_static) == 1
    assert len(router.routes_dynamic) == 1

    with pytest.raises(SanicException) as exc_info:
        router.finalize([route])
    assert (
        str(exc_info.value) ==
        f"Invalid route: {route}. Parameter names cannot use '__'."
    )



# Generated at 2022-06-12 09:28:59.344913
# Unit test for method finalize of class Router
def test_Router_finalize():
    import sanic.router
    router = sanic.router.Router()
    try:
        router.finalize()
    except Exception as e:
        pass

# Generated at 2022-06-12 09:29:01.720332
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    try:
        router.finalize()
    except SanicException as e:
        assert "parameter names cannot use '__'." in str(e)

# Generated at 2022-06-12 09:29:44.560136
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic_routing.route import Route
    from sanic_routing.route import RouteGroup

    # TODO: How to run unit tests (`python -m unittest`)
    router = Router()
    router.dynamic_routes = {
        "x": Route(RouteGroup("/"), "/<param:foo>", None),
        "y": Route(RouteGroup("/"), "/<param:__foo>", None),
        "z": Route(RouteGroup("/"), "/<param:__file_uri__>", None),
    }

    router.finalize()

# Generated at 2022-06-12 09:29:46.953820
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}

# Generated at 2022-06-12 09:29:51.084535
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    with pytest.raises(SanicException) as context:
        router = Router()
        route = router.add("/")
        route.labels = {'__file_uri__': 123,
                        '__ara_uri__': 123}
        router.finalize()

# Generated at 2022-06-12 09:29:51.802229
# Unit test for method finalize of class Router

# Generated at 2022-06-12 09:29:54.207533
# Unit test for constructor of class Router
def test_Router():
    try:
        router = Router()
    except Exception as e:
        print("Router creation error: " + str(e))
        raise e
    assert type(router) == Router


# Generated at 2022-06-12 09:29:54.699248
# Unit test for constructor of class Router
def test_Router():
    r = Router()

# Generated at 2022-06-12 09:30:01.968725
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router(None)
    def validate_error(route):
        error = None
        try:
            router.finalize([route])
        except SanicException as e:
            error = e
        assert error is not None
        assert str(error) == f"Invalid route: {route}. Parameter names cannot use '__'."

    route = Route({}, '/<__file_uri__:path>')
    del router.methods
    router.finalize([route])
    assert router.methods is not None

    route = Route({}, '/<__path:path>')
    validate_error(route)
    route = Route({}, '/<__:path>')
    validate_error(route)

# Generated at 2022-06-12 09:30:03.268924
# Unit test for constructor of class Router
def test_Router():
    app = Sanic("test_Router")
    router = Router(app)
    assert router is not None

# Generated at 2022-06-12 09:30:04.085890
# Unit test for constructor of class Router
def test_Router():
    router = Router
    assert router

# Generated at 2022-06-12 09:30:05.647832
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.ctx.app == None
    assert router.ctx.session == None


# Generated at 2022-06-12 09:31:26.308838
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == set()
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.paths == {}
    assert isinstance(router.paths, dict)
    assert router.name_index == {}
    assert isinstance(router.name_index, dict)
    assert router.ctx == {}
    assert isinstance(router.ctx, dict)
    assert router.static_routes == {}
    assert router.static_file_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}

# Generated at 2022-06-12 09:31:31.916413
# Unit test for constructor of class Router
def test_Router():
    from sanic.constants import HTTP_METHODS
    from sanic_routing import BaseRouter
    from sanic_routing.router import Router
    from sanic_routing.route import Route
    from sanic.exceptions import NotFound, SanicException

    router = Router()
    assert router.routes == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}

    router = Router(routers=["123"])
    assert router.routers == ["123"]

    # test for _get()
    router = Router()
    uri = "/abc"
    methods = HTTP_METHODS
    hostname = "test"
    handler = asyncio.coroutine

# Generated at 2022-06-12 09:31:32.420310
# Unit test for method finalize of class Router
def test_Router_finalize():
    pass

# Generated at 2022-06-12 09:31:35.014568
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    try:
        router.finalize()
    except Exception as e:
        assert 0, "(router.finalize) Method failed"
        print("(router.finalize) Method failed")
        print(e)


# Generated at 2022-06-12 09:31:41.764483
# Unit test for method finalize of class Router
def test_Router_finalize():
    uri = "/test"
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.routing import Router

    app = Sanic(__name__)
    router_ = Router(app)

    @app.route(uri)
    async def handler(request: Request) -> HTTPResponse:
        return HTTPResponse(b"OK")

    router_.finalize()

    try:
        @app.route(uri)
        async def handler(request: Request,__test:int) -> HTTPResponse:
            return HTTPResponse(b"OK")
    except SanicException:
        pass
    else:
        assert False



# Generated at 2022-06-12 09:31:42.667878
# Unit test for constructor of class Router
def test_Router():
    # type: () -> None
    assert isinstance(Router(), Router)

# Generated at 2022-06-12 09:31:47.534679
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest

    def mock_super_finalize(self, *args, **kwargs):
        return None

    def test_one():
        r = Router()
        r.dynamic_routes = {"test key": "test values"}
        r.finalize()

    def test_two():
        r = Router()
        r.dynamic_routes = {"test key": "test values"}
        with pytest.raises(SanicException):
            r.finalize()
            r.dynamic_routes = {"__test_key": "test values"}

    Router.finalize = mock_super_finalize
    test_one()
    Router.finalize = super(Router, Router).finalize
    assert test_two()

# Generated at 2022-06-12 09:31:48.182725
# Unit test for constructor of class Router
def test_Router():
    router = Router()


# Generated at 2022-06-12 09:31:55.780510
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == ["ACL", 'BIND', 'CHECKOUT', 'CONNECT', 'COPY', 'DELETE', 'GET', 'HEAD', 'LINK', 'LOCK', 'M-SEARCH', 'MERGE', 'MKACTIVITY', 'MKCALENDAR', 'MKCOL', 'MOVE', 'NOTIFY', 'OPTIONS', 'PATCH', 'POST', 'PROPFIND', 'PROPPATCH', 'PURGE', 'PUT', 'REBIND', 'REPORT', 'SEARCH', 'SUBSCRIBE', 'TRACE', 'UNBIND', 'UNLINK', 'UNLOCK', 'UNSUBSCRIBE']

# Generated at 2022-06-12 09:31:56.642564
# Unit test for constructor of class Router
def test_Router():
    router = Router(None)
    assert router.ctx



# Generated at 2022-06-12 09:34:33.018755
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from unittest.mock import Mock

    # Success case
    app = Sanic("test_Router_finalize_success")
    router = Router(app, Mock())
    router.add("/", ["GET"], Mock(), name="abc")
    try:
        router.finalize()
    except SanicException:
        assert False

    # Failure case 1
    app = Sanic("test_Router_finalize_failure_1")
    router = Router(app, Mock())
    router.add("/", ["GET"], Mock(), name="__abc")
    try:
        router.finalize()
        assert False
    except SanicException:
        assert True

    # Failure case 2
   

# Generated at 2022-06-12 09:34:38.374106
# Unit test for method finalize of class Router
def test_Router_finalize():
    
    router = Router()
    try:
        router.finalize()
    except:
        pass
    else:
        raise Exception('error')

    router = Router()
    router.dynamic_routes['test'] = Route(
        ctx=None,
        path='/',
        handler=None,
        methods=['GET'],
        name='test',
        strict=False,
        unquote=False
    )
    router.dynamic_routes['test'].labels = ['__test__']
    try:
        router.finalize()
    except:
        pass
    else:
        raise Exception('error')
    
    router = Router()

# Generated at 2022-06-12 09:34:43.181641
# Unit test for method add of class Router
def test_Router_add():
    r = Router()
    r.add(uri='home',methods=['GET'],handler='home')
    assert len(r.routes) == 1
    assert len(r.routes_static) == 1
    assert r.routes['home'].uri == 'home'
    assert r.routes['home'].handler == 'home'



# Generated at 2022-06-12 09:34:48.955581
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    router = Router()
    router.add("/url", 'GET', lambda r: None, "host_1")
    router.add("/url", 'GET', lambda r: None, "host_2")
    router.add("/url", 'GET', lambda r: None)
    try:
        router.finalize()
    except Exception as e:
        assert e is SanicException("Invalid route: <Route at 0x7f7947c3a3a0 | /url -> <lambda>>. Parameter names cannot use '__'.")

# Generated at 2022-06-12 09:34:57.465868
# Unit test for method add of class Router
def test_Router_add():

    router = Router()

# Generated at 2022-06-12 09:34:59.297140
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None


# Generated at 2022-06-12 09:35:01.139043
# Unit test for constructor of class Router
def test_Router():
    assert Router() is not None
    # def __init__(self, app: Optional[Sanic] = None, labels: Optional[Dict] = None):

# Generated at 2022-06-12 09:35:02.696090
# Unit test for constructor of class Router
def test_Router():
  r = Router()
  assert len(r.get("/", "GET", None)) == 0

# Generated at 2022-06-12 09:35:07.309027
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.dynamic_routes = {
        "GET": [
            Route(
                path="/user/<id:int>",
                handler=None,
                methods={"GET"},
                name=None,
                strict=False,
                unquote=False,
            )
        ]
    }

    try:
        router.finalize()
    except SanicException:
        print("Test Passed")
    else:
        print("Test Failed")

test_Router_finalize()

# Generated at 2022-06-12 09:35:14.917926
# Unit test for method finalize of class Router
def test_Router_finalize():
    import sanic
    app = sanic.Sanic("test_Router_finalize")

    @app.route('/path/<param>')
    def handler(request, param):
        assert True

    app._router.add(
        uri='/path/<param>',
        methods=['GET'],
        handler=handler,
        host=None,
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version=None,
        name=None,
        unquote=False,
        static=False,
    )