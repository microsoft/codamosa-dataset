

# Generated at 2022-06-12 09:25:56.700178
# Unit test for constructor of class Router
def test_Router():
	r = Router()
	assert isinstance(r, BaseRouter)

# Generated at 2022-06-12 09:26:04.959487
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == ["HEAD", "OPTIONS", "GET", "POST", "PUT", "DELETE", "TRACE", "CONNECT", "PATCH"]
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router._routes_all_lut == {}
    assert router._routes_static

# Generated at 2022-06-12 09:26:07.710408
# Unit test for constructor of class Router
def test_Router():
    import sanic
    app = sanic.Sanic()
    router = Router(app)
    assert router.dynamic_routes == {}
    assert router.static_routes == {}
    assert router.regex_routes == []
    assert router.all_routes == {}
    assert router.name_index == {}

# Generated at 2022-06-12 09:26:12.338202
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.constants import HTTP_METHODS
    R = Router()
    for method in HTTP_METHODS:
        assert method in R.ALLOWED_METHODS
    assert R.ROUTER_CACHE_SIZE == 1024
    assert R.ALLOWED_LABELS == ("__file_uri__",)
    assert R.DEFAULT_METHOD == "GET"

# Generated at 2022-06-12 09:26:20.074823
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    uri = "/"
    methods = ["POST"]
    handler = lambda: None
    host = "localhost"
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = None
    unquote = False
    static = False
    routes_added = router.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)
    assert(router == routes_added[0].router)
    assert(type(routes_added[0].router) == type(router))

# Generated at 2022-06-12 09:26:28.837687
# Unit test for method finalize of class Router
def test_Router_finalize():
    import unittest
    class SanicException_mock(Exception):
        pass
    class _Router(Router):
        def __init__(self, *args, **kwargs):
            self.dynamic_routes = {
                f"{i}": {
                    "labels": [],
                    "pattern": i,
                    "regex": i,
                    "methods": ["GET"],
                    "handler": lambda: i,
                    "name": None,
                    "ctxs": {},
                    "versions": [],
                }
                for i in range(3)
            }


# Generated at 2022-06-12 09:26:33.230456
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    router = Router()
    router.dynamic_routes = {0: Router()}
    router.dynamic_routes[0].labels = ["Test"]
    with pytest.raises(SanicException) as excinfo:
        router.finalize()
    assert str(excinfo.value) == "Invalid route: <__main__.Router object at 0x0000022C43709C18>. Parameter names cannot use '__'."

# Generated at 2022-06-12 09:26:34.351026
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r.DEFAULT_METHOD=="GET"

# Generated at 2022-06-12 09:26:35.093877
# Unit test for constructor of class Router
def test_Router():
    assert Router()


# Generated at 2022-06-12 09:26:39.696113
# Unit test for constructor of class Router
def test_Router():
    """
    Test setting up params for class Router
    """
    router = Router()
    assert router.DEFAULT_METHOD == 'GET'
    assert router.ALLOWED_METHODS == ['HEAD', 'GET', 'POST', 'PUT', 'DELETE', 'OPTIONS', 'PATCH', 'CONNECT']


# Generated at 2022-06-12 09:26:54.934996
# Unit test for method add of class Router
def test_Router_add():
    uri = "test"
    method = "GET"
    uri2_2 = "test2_2"
    method2_2 = "HEAD"
    host = "0.0.0.0"

    router = Router()
    router.add(uri=uri, methods=[method], handler=True, host=host)
    router.add(uri=uri, methods=[method2_2], handler=True, host=host)

    assert (router.get(uri, method, host) == (
        Route(uri=uri, methods=[method], handler=True, name=None, strict=False, unquote=False,
              requirements={'host': host},
              ctx=Route.Context(ignore_body=False, stream=False, hosts=[host])),
        True,
        {}
    ))


# Generated at 2022-06-12 09:26:58.705333
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []
    assert router.all_routes == {}


# Generated at 2022-06-12 09:27:00.106589
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"

# Generated at 2022-06-12 09:27:02.561436
# Unit test for constructor of class Router
def test_Router():
    # test for Router
    a = Router()
    b = Router()
    assert a == b
    assert id(a) != id(Router())

# Generated at 2022-06-12 09:27:04.384296
# Unit test for constructor of class Router
def test_Router():
    print("test_Router()")
    router = Router()
    print("test_Router() completed " + str(router))

# Generated at 2022-06-12 09:27:06.673648
# Unit test for method finalize of class Router
def test_Router_finalize():
    import sanic
    obj = sanic.router.Router()
    with pytest.raises(sanic.exceptions.SanicException):
        obj.finalize()

# Generated at 2022-06-12 09:27:13.001112
# Unit test for method finalize of class Router
def test_Router_finalize():
    import tempfile
    import os
    from sanic.app import Sanic

    # create temporary file
    _, fname = tempfile.mkstemp()

    # test file
    with open(fname, 'w') as f:
        f.write('from sanic.views import CompositionView\n\n')
        f.write('view = CompositionView()')

    app = Sanic(__name__)
    app.router.add('/', 'GET', lambda: 'OK', host='localhost')
    app.router.add('/', 'GET', lambda: 'OK', host='localhost')

    app_router = app.router

    # this should not raise exception
    app_router.finalize()

    # remove temporary file
    os.remove(fname)

# Generated at 2022-06-12 09:27:21.798945
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic_routing.router import Router  # type: ignore
    from sanic import Sanic  # type: ignore
    from sanic.response import json  # type: ignore
    from sanic_routing.exceptions import DuplicateResource  # type: ignore

    # define the handler
    def some_handler(request, *args, **kwargs):
        return json({"message": "hello world"})

    # create the app
    app = Sanic(__name__)

    # add a resource to the router
    app.add_route(some_handler, "/resource/<id>/")

    # add a duplicate resource to the router
    with pytest.raises(DuplicateResource):
        app.add_route(some_handler, "/resource/<id>/")

    # add a duplicate resource with a different

# Generated at 2022-06-12 09:27:23.351290
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    with pytest.raises(SanicException):
        r.finalize()

# Generated at 2022-06-12 09:27:30.122062
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    print(router.MAX_DEPTH)
    print(router.ALLOWED_METHODS)
    print(router.DEFAULT_METHOD)
    print(router.ctx)
    print(router.routes)
    print(router.static_routes)
    print(router.regex_routes)
    print(router.dynamic_routes)
    print(router.name_index)
    print(router.cache_resolve)
    print(router.cache_match)
    print(router.depth_map)


# Generated at 2022-06-12 09:27:35.323212
# Unit test for constructor of class Router
def test_Router():
    Router()


# Generated at 2022-06-12 09:27:43.791249
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    We should be able to create a Router.finalize
    """
    from sanic.constants import HTTP_METHODS
    from sanic.response import json
    from sanic_routing.route import Route

    router = Router()

    async def handler(request):
        return json({"hello": "world"})

    # Add the route
    route = router.add(
        uri="/test",
        methods=HTTP_METHODS,
        handler=handler,
    )
    assert isinstance(route, Route)

    # Router should not have any dynamic routes
    assert len(router.dynamic_routes) == 0

    # Finalize the routes
    router.finalize()

    # Router should now have one dynamic route
    assert len(router.dynamic_routes) == 1
    assert len

# Generated at 2022-06-12 09:27:44.304060
# Unit test for constructor of class Router
def test_Router():
    router = Router()

# Generated at 2022-06-12 09:27:46.372105
# Unit test for constructor of class Router
def test_Router():
    try:
        router = Router()
    except Exception as e:
        print(f"Failed: {e}")
    print(f"Passed: ")


# Generated at 2022-06-12 09:27:46.867402
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r is not None

# Generated at 2022-06-12 09:27:55.305352
# Unit test for method finalize of class Router
def test_Router_finalize():
    from unittest.mock import Mock
    from .sandbox import SandboxedTestCase

    class Test(SandboxedTestCase):
        def setUp(self):
            self.setUpSandbox()

        def tearDown(self):
            self.tearDownSandbox()

        def test_Router_finalize(self):
            sanic_app = Mock(name="App")
            router = Router(sanic_app)
            route = Mock(name="Route", labels=["__toto__"])
            router.dynamic_routes = {"my_route": route}
            with self.assertRaises(Exception) as cm:
                router.finalize()
            self.assertEqual(cm.exception.args[0], "Invalid route: my_route. Parameter names cannot use '__'.")

# Generated at 2022-06-12 09:28:03.824595
# Unit test for method add of class Router
def test_Router_add():
    import json

    router = Router()
    router.add("/",["GET"],"GET")
    router.add("/1",["GET"],"GET")
    router.add("/2",["GET"],"GET")
    router.add("/1",["POST"],"GET")
    router.add("/2",["POST"],"GET")
    router.add("/3",["POST"],"GET")
    router.add("/3",["DELETE"],"GET")
    router.add("/4",["DELETE"],"GET")
    router.add("/5",["DELETE"],"GET")

    # All routes
    routes_all = router.routes_all
    assert routes_all[0].ctx.methods == ["GET"]
    assert routes_all[0].ctx.handler == "GET"

# Generated at 2022-06-12 09:28:07.166190
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert hasattr(r, 'routes')
    assert hasattr(r, 'routes_all')
    assert hasattr(r, 'routes_static')
    assert hasattr(r, 'routes_dynamic')
    assert hasattr(r, 'routes_regex')

# Generated at 2022-06-12 09:28:07.662573
# Unit test for constructor of class Router
def test_Router():
    Router()

# Generated at 2022-06-12 09:28:16.295260
# Unit test for constructor of class Router
def test_Router():
    test_Router = Router(
        app=None,
        host_matching=False,
        servername=None,
        default_method=None,
        default_subdomain=None,
        default_stream=False,
        default_ignore_body=False,
        default_protocol=None,
        default_prefix=None,
        default_static='',
        default_url_prefix=None,
        default_strict_slashes=False,
        default_version='1.0',
        is_request_stream=False,
        error_handler=None,
    )

    assert test_Router.app == None
    assert test_Router.host_matching == False
    assert test_Router.servername == None
    assert test_Router.default_method == None
    assert test_

# Generated at 2022-06-12 09:28:25.613629
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router


# Generated at 2022-06-12 09:28:35.135267
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    match_route = Router(None)
    match_route.dynamic_routes = {}
    match_route.routes = []
    match_route.routes = [Route('/test_Router_finalize', None, methods=['OPTIONS']), Route('/test_Router_finalize', None, methods=['OPTIONS'])]
    match_route.dynamic_routes['_test_Router_finalize'] = [Route('/test_Router_finalize', None, methods=['OPTIONS'])]
    
    assert match_route.dynamic_routes['_test_Router_finalize'][0].labels == ("_test_Router_finalize",)


# Generated at 2022-06-12 09:28:43.487099
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    from sanic.views import HTTPMethodView
    from sanic_routing import DynamicRouter
    from sanic_routing.errors import SanicRoutingError

    def dynamicRouter_finalize(self, static_routes=None, dynamic_routes=None):
        if static_routes is not None:
            self.static_routes = static_routes or DynamicRouter()
        if dynamic_routes is not None:
            self.dynamic_routes = dynamic_routes or DynamicRouter()
        if self.static_routes is self.dynamic_routes:
            self.dynamic_routes = DynamicRouter()

# Generated at 2022-06-12 09:28:47.571832
# Unit test for constructor of class Router
def test_Router():
    route = Router()
    assert route.allowed_methods == ("GET", "POST", "PUT", "PATCH", "HEAD", "DELETE", "OPTIONS")
    assert route.default_method == "GET"
    assert route.routes == {}
    assert route.routes_static == {}
    assert route.routes_dynamic == {}
    assert route.routes_regex == {}
    assert route.name_index == {}

# Generated at 2022-06-12 09:28:53.659042
# Unit test for constructor of class Router
def test_Router():
    router = Router(app=None)
    assert router
    assert router.allowed_methods == ["GET", "HEAD", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "TRACE"]
    strings = "app, default_method, allowed_methods, uri_prefix, base_context"
    for string in strings.split(", "):
        assert getattr(router, string)

# Generated at 2022-06-12 09:28:58.087107
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.ctx is None
    assert router.current_route is None
    assert router.regex_routes == {}
    assert router.dynamic_routes == {}
    assert router.static_routes == {}
    assert router.name_index == {}
    assert router.routes == []

# Generated at 2022-06-12 09:29:01.187572
# Unit test for method finalize of class Router
def test_Router_finalize():
    def handler(request):
        pass
    router = Router()
    router.add('/test/<__parameter>', ['GET'], handler)
    try:
        router.finalize()
    except:
        pass
    else:
        assert False

# Generated at 2022-06-12 09:29:03.017431
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add(uri="/url/path/{id}", methods=["GET", "POST"], handler=None)
    router.finalize()


# Generated at 2022-06-12 09:29:04.234956
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router != None

# Generated at 2022-06-12 09:29:13.562804
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.app import Sanic

    app = Sanic("test_finalize")
    app.config.REQUEST_MAX_SIZE = 100
    app.config.REQUEST_TIMEOUT = 60
    app.config.KEEP_ALIVE = True
    app.config.KEEP_ALIVE_TIMEOUT = 5
    app.config.GRACEFUL_SHUTDOWN_TIMEOUT = 15
    app.config.ACCESS_LOG = True
    router = Router()

    router.finalize(app)
    logger = logging.getLogger("sanic.access")
    assert isinstance(logger.handlers[0], SanicAccessLogger)
    assert isinstance(router.ctx.connection_class, KeepAliveConnection)
    assert router.ctx.connection_class.keep_alive_timeout == 5

# Generated at 2022-06-12 09:29:28.449759
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route("test_uri", "test_handler", ["test_method"], {}, None, None)
    route.labels = ["__file_uri__"]
    # testing for case where path starts with __, but label is allowed
    assert router.finalize(route) == None
    # testing for case where path starts with __, and label is not allowed
    route.labels = ["__test_label"]
    try:
        router.finalize(route)
        assert False
    except SanicException:
        assert True
    # testing for case where path does not start with __, and label is not allowed
    route.labels = ["test_label"]
    try:
        router.finalize(route)
        assert False
    except SanicException:
        assert True
    # testing for case where path does

# Generated at 2022-06-12 09:29:35.054908
# Unit test for method finalize of class Router
def test_Router_finalize():
    error = None
    try:
        r = Router()
        r.add("/<__file_uri__:uri>", ["GET"], None)
        r.finalize()
    except SanicException as e:
        error = e
    assert error is None

    error = None
    try:
        r = Router()
        r.add("/<__file_uri__:uri>", ["GET"], None)
        r.add("/<__file_uri__:uri>", ["GET"], None)
        r.finalize()
    except SanicException as e:
        error = e
    assert error is SanicException



# Generated at 2022-06-12 09:29:41.653038
# Unit test for method add of class Router
def test_Router_add():
    import unittest

    from sanic_routing.router import Router

    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    
    def func_handler(req, res):
        return res
    
    async def async_handler(req, res):
        return res
    
    class Handler:
        def __call__(self, req, res):
            return res
    
    class HandlerAsync:
        async def __call__(self, req, res):
            return res
    
    router = Router()
    
    # Test with a sync function handler
    route = router.add('/test', ['GET', 'POST'], func_handler)
    assert route.ctx.static == False
    
    # Test with an async function handler

# Generated at 2022-06-12 09:29:44.919845
# Unit test for constructor of class Router
def test_Router():
    """
    Router should perform correctly
    """
    router = Router()
    assert router is not None and router.routes == {}
    assert router.static_routes == {} and router.dynamic_routes == {}

# Generated at 2022-06-12 09:29:51.798181
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route(
        "dummy",
        "dummy",
        "dummy",
        "dummy",
        "dummy",
        "dummy",
        "dummy",
        "dummy",
        "dummy",
        "dummy",
        "dummy",
        "dummy",
        ["__model1__"],
    )
    try:
        router.finalize([route])
    except Exception:
        assert True
    route.labels = ["__file_uri__"]
    try:
        router.finalize([route])
        assert True
    except Exception:
        assert False

# Generated at 2022-06-12 09:29:52.859330
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    assert router.finalize() == True


# Generated at 2022-06-12 09:29:54.858352
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add(uri='/<name>/<address>', methods=['GET'], handler=None)
    router.finalize()

# Generated at 2022-06-12 09:29:55.609356
# Unit test for constructor of class Router
def test_Router():
    assert(Router())


# Generated at 2022-06-12 09:29:56.387301
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    pass

# Generated at 2022-06-12 09:30:02.412998
# Unit test for method finalize of class Router
def test_Router_finalize():
    route1 = Route("/test-1", "GET", None, None, None, None, {'__test__': 2})
    route2 = Route("/test-2", "GET", None, None, None, None, {'test': 'test'})

    router = Router()
    router.dynamic_routes = {
        '/test-1': {
            'GET': route1
        },
        '/test-2': {
            'GET': route2
        }
    }

    with pytest.raises(SanicException):
        router.finalize()

# Generated at 2022-06-12 09:30:11.768385
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD =="GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS

# Generated at 2022-06-12 09:30:12.451703
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router,Router) == True

# Generated at 2022-06-12 09:30:16.796925
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r.DEFAULT_METHOD == "GET"
    assert r.ALLOWED_METHODS == HTTP_METHODS
    assert r.routes == {}
    assert r.static_routes == {}
    assert r.dynamic_routes == {}
    assert r.regex_routes == {}

# Generated at 2022-06-12 09:30:18.627332
# Unit test for constructor of class Router
def test_Router():
    try:
        router = Router()
    except Exception as e:
        assert False, "Unexpected exception {}".format(e)
    else:
        assert True
test_Router()
        

# Generated at 2022-06-12 09:30:26.530356
# Unit test for method finalize of class Router
def test_Router_finalize():
    import unittest
    class TestFinalize(unittest.TestCase):
        def test_raise_when_reserved_labels(self):
            router = Router()
            router.dynamic_routes = {
                "/{__1__}/{__2__}": Router.Route(
                    method="GET",
                    path="/{__1__}/{__2__}",
                    handler=None,
                    name=None,
                    strict=False,
                    name_prefix=None,
                    host=None,
                    unquote=False,
                    status_code=None,
                    ctx=Router.Context(),
                    middlewares=None,
                )
            }
            
            self.assertRaises(SanicException, lambda: router.finalize())


# Generated at 2022-06-12 09:30:28.608904
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        router = Router()
        router.add('/uri', ['GET'], 'handler')
        router.finalize()
    except SanicException:
        assert True
    else:
        assert False

# Generated at 2022-06-12 09:30:34.763828
# Unit test for constructor of class Router
def test_Router():
    # get a dummy app
    from sanic.app import Sanic
    from sanic.constants import HTTP_METHODS

    app = Sanic()

    # create a dummy request well-formed
    # empty uri --> raise error
    request_0 = {}
    request_0["uri"] = None
    request_0["version"] = "1.1"
    request_0["method"] = "GET"
    request_0["headers"] = {}
    request_0["transport"] = None
    request_0["cookies"] = {}
    request_0["parsed_url"] = None
    request_0["args"] = {}
    request_0["raw_args"] = {}
    request_0["form"] = {}
    request_0["files"] = {}
    request_0["body"] = {}

    #

# Generated at 2022-06-12 09:30:37.467033
# Unit test for method finalize of class Router
def test_Router_finalize():
    myRouter = Router()
    with pytest.raises(SanicException):
        myRouter.add("/test/<int:__id>", ["GET"], None)
        myRouter.finalize()



# Generated at 2022-06-12 09:30:40.427728
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r.DEFAULT_METHOD == "GET"
    assert r.ALLOWED_METHODS == HTTP_METHODS
    assert r.routes_all == []
    assert r.routes_static == []
    assert r.routes_dynamic == []
    assert r.routes_regex == []


# Generated at 2022-06-12 09:30:49.903694
# Unit test for constructor of class Router
def test_Router():
    r1 = Router()
    assert r1._allowed_methods == Router.ALLOWED_METHODS
    assert r1._default_method == Router.DEFAULT_METHOD
    assert r1._router == {}
    assert r1.ctx == {}
    assert r1.routes_all == {}
    assert r1.routes_static == {}
    assert r1.routes_dynamic == {}
    assert r1.routes_regex == {}
    assert r1.name_index == {}

    r2 = Router(r1.ctx)
    assert r2._allowed_methods == Router.ALLOWED_METHODS
    assert r2._default_method == Router.DEFAULT_METHOD
    assert r2._router == {}
    assert r2.ctx == {}
    assert r2.rout

# Generated at 2022-06-12 09:30:58.738671
# Unit test for constructor of class Router
def test_Router():
    router = Router()

# Generated at 2022-06-12 09:31:00.072170
# Unit test for constructor of class Router
def test_Router():
    '''Test for Constructor of Class Router'''
    router = Router()
    return router


# Generated at 2022-06-12 09:31:04.096222
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    r.add("/<param>", ["GET"], None, name="uri")
    
    try:
        r.finalize()
    except SanicException as e:
        assert str(e) == "Invalid route: <Route /<param> -> None>. Parameter names cannot use '__'."
    else:
        raise Exception("No SanicException raised")


# Generated at 2022-06-12 09:31:07.711915
# Unit test for constructor of class Router
def test_Router():
  router = Router()

  assert isinstance(router.routes_all, dict)
  assert isinstance(router.routes_static, dict)
  assert isinstance(router.routes_dynamic, dict)
  assert isinstance(router.routes_regex, list)


# Generated at 2022-06-12 09:31:08.740930
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None


# Generated at 2022-06-12 09:31:17.009182
# Unit test for constructor of class Router
def test_Router():
    # test_router_init1() and test_router_init2() are not really needed for
    # the case of no parameter, but left the code here for reference.
    router = Router(ctx=None)
    assert router.DEFAULT_METHOD == "GET"
    assert router.name_prefix == ""
    assert router.ctx is None
    assert router.name_index == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.routes_all == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.routes_static == {}

    # test_router_init3() works the same as init() with keyword

# Generated at 2022-06-12 09:31:18.477402
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    router.DEFAULT_METHOD
    router.ALLOWED_METHODS
    router.get("/")

# Generated at 2022-06-12 09:31:25.777557
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic_routing import Route
    from sanic_routing.router import Router

    # test allowed labels
    router = Router()
    router.add(uri="/", methods=["GET"], handler=None)
    router.dynamic_routes["name"] = Route(
        path="/",
        handler=None,
        methods=["GET"],
        requirements={},
        name="name",
        strict=False,
        unquote=False,
        labels=["__file_uri__"],
    )
    router.finalize()

    # test not allowed labels
    router = Router()
    router.add(uri="/", methods=["GET"], handler=None)

# Generated at 2022-06-12 09:31:32.582966
# Unit test for constructor of class Router
def test_Router():
    #Should initialize variables as defined by default and return
    #True if initialized
    @asyncio.coroutine
    def async_handler(*args, **kwargs):
        return (args, kwargs)

    router = Router(async_handler)
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert isinstance(router, BaseRouter)
    assert router.ctx.app.async_handler == async_handler
    assert len(router.routes_all) == 0
    assert len(router.routes_static) == 0
    assert len(router.routes_dynamic) == 0
    assert len(router.routes_regex) == 0
    assert len(router.name_index) == 0

# Generated at 2022-06-12 09:31:34.221244
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    with pytest.raises(SanicException, match=r"Paramete.+'__'."):
        router.finalize()

# Generated at 2022-06-12 09:31:55.573663
# Unit test for method add of class Router
def test_Router_add():
    uri = "/users/<username>"
    methods = {"GET", "POST"}
    handler = lambda: None
    host = "example.com"
    strict_slashes = True
    stream = True
    ignore_body = False
    version = 1
    name = "get_users"
    unquote = True
    static = True
    router = Router()
    router.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)

# Generated at 2022-06-12 09:31:56.932498
# Unit test for constructor of class Router
def test_Router():
    # if not isinstance(Router, ):
    #     raise Exception("Constructor of class 'Router' should be:")
    pass


# Generated at 2022-06-12 09:31:57.861489
# Unit test for constructor of class Router
def test_Router():
    router = Router()


if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-12 09:32:02.617094
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.app import Sanic

    app = Sanic(__name__.split('.')[0])
    router = Router(app)

# Generated at 2022-06-12 09:32:03.312380
# Unit test for constructor of class Router
def test_Router():
    assert Router


# Generated at 2022-06-12 09:32:11.751201
# Unit test for method finalize of class Router
def test_Router_finalize():
    url = "my_test_url"
    method = "MY_TEST_METHOD"
    handler = "MY_TEST_HANDLER"
    router = Router()
    router.add(url, method, handler)
    #not raise exception
    router.finalize()
    
    with pytest.raises(SanicException):
        url = "my_test_url"
        method = "MY_TEST_METHOD"
        handler = "MY_TEST_HANDLER"
        router = Router()
        router.add(url, method, handler, uri_args={"__test__": None})
        router.finalize()


# Generated at 2022-06-12 09:32:14.510868
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == []
    assert router.routes_regex == []


# Generated at 2022-06-12 09:32:18.747102
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.dynamic_routes == {}
    assert router.static_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-12 09:32:24.505670
# Unit test for method finalize of class Router
def test_Router_finalize():
    class TestRouter(Router):
        def finalize(self, *args, **kwargs):
            super().finalize(*args, **kwargs)

        def add(self, *args, **kwargs):
            return super().add(*args, **kwargs)
    router = TestRouter()

    @router.add("/test/<user>", methods=["GET"])
    def test_handler(request, user):
        return text("pass")

    try:
        router.finalize()
    except Exception as err:
        assert False, f"Router.finalize() raises an exception: {err}"

# Generated at 2022-06-12 09:32:27.260628
# Unit test for method add of class Router
def test_Router_add():

    @app.route("/test_add", methods=["POST"])
    def test_add(request):
        return response.json({"test": True})

    assert "/test_add" in router.routes



# Generated at 2022-06-12 09:33:00.203416
# Unit test for constructor of class Router
def test_Router():
    rt = Router()
    assert isinstance(rt, Router)
    assert isinstance(rt, BaseRouter)


# Generated at 2022-06-12 09:33:08.476824
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router
    #
    # we can only test for the public methods, but to get better test coverage
    # we want to ensure the hidden methods are used
    #
    # router._get('/','GET','')
    # router.get(path='/', method='GET', host='')
    # router.add(uri='/',
    #            methods=['GET'],
    #            handler=lambda x: None,
    #            host=None,
    #            strict_slashes=False,
    #            stream=False,
    #            ignore_body=False,
    #            version=None,
    #            name=None,
    #            unquote=False)
    route = router.find_route_by_view_name('/')
    assert route is None

    assert router

# Generated at 2022-06-12 09:33:11.824017
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    print(router.routes)
    print(router.dynamic_routes)
    print(router.static_routes)
    print(router.regex_routes)
    print(router.name_index)
    print(router.path_index)
    print(router.reverse_index)
    print(router.host_index)


# Generated at 2022-06-12 09:33:19.558739
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.app import Sanic
    from sanic.router import Router
    from sanic.views import HTTPMethodView
    from sanic.exceptions import SanicException
    # Test 1: dynamic_routes is empty
    # Test 2: route with label "__test__" which is not allowed
    # Test 3: OK
    app = Sanic('test_Router_finalize')
    router = Router(app)

    # Test 1: dynamic_routes is empty
    router.dynamic_routes.clear()
    try:
        router.finalize()
    except SanicException:
        assert True
        # Test 2: route with label "__test__" which is not allowed
        class TestView(HTTPMethodView):
            pass

# Generated at 2022-06-12 09:33:20.306398
# Unit test for constructor of class Router
def test_Router():
    router = Router
    assert router

# Generated at 2022-06-12 09:33:28.134859
# Unit test for method finalize of class Router
def test_Router_finalize():
    from .test_case import SanicTestClient

    router = Router()

    async def handler(request):
        return text("OK")

    # Test with dynamic route
    @router.route("/test/<username>")
    def handler1(request, username):
        return text("OK")

    # Test with dynamic route missing parameter name
    @router.route("/test/<>")
    def handler2(request, username):
        return text("OK")

    # Test with dynamic route with parameter name starting with __
    @router.route("/test/<__username>")
    def handler3(request, username):
        return text("OK")

    # Test with dynamic route with parameter name starting with _

# Generated at 2022-06-12 09:33:35.487044
# Unit test for constructor of class Router
def test_Router():
    """
    Unit test for constructor of class Router
    """
    router1 = Router()
    assert isinstance(router1.DEFAULT_METHOD, str), "DEFAULT_METHOD is valid"
    assert isinstance(router1.ALLOWED_METHODS, list), "ALLOWED_METHODS is valid"
    assert isinstance(router1.ROUTER_CACHE_SIZE, int), "ROUTER_CACHE_SIZE is valid"
    assert isinstance(router1.ALLOWED_LABELS, tuple), "ALLOWED_LABELS is valid"
    print("Test for constructor of class Router successfully!")


# Generated at 2022-06-12 09:33:39.151782
# Unit test for constructor of class Router
def test_Router():
    # test constructor
    assert issubclass(Router, BaseRouter)
    assert Router.DEFAULT_METHOD == "GET"
    assert Router.ALLOWED_METHODS == HTTP_METHODS


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-12 09:33:41.408021
# Unit test for method finalize of class Router
def test_Router_finalize():
    def handler():
        return

    router = Router()
    router.add("/", ["GET"], handler)

    with pytest.raises(SanicException) as e:
        assert router.finalize()

    assert str(e.value) == "Invalid route: / . Parameter names cannot use '__'."

# Generated at 2022-06-12 09:33:42.479703
# Unit test for constructor of class Router
def test_Router():
    my_Router = Router()
    assert my_Router.__class__ == Router

# Generated at 2022-06-12 09:34:47.756778
# Unit test for constructor of class Router
def test_Router():
    assert Router()

# Generated at 2022-06-12 09:34:48.230333
# Unit test for method add of class Router
def test_Router_add():
    pass

# Generated at 2022-06-12 09:34:49.139775
# Unit test for constructor of class Router
def test_Router():
    route = Router()
    assert(route) is not None

# Generated at 2022-06-12 09:34:54.404876
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest

    from sanic import Sanic
    from sanic.exceptions import SanicException
    from sanic.router import Router

    app = Sanic("test_sanic_app")
    router = Router(app)

    @router.route("/<foo__bar>")
    def handler(request, foo__bar):
        pass

    with pytest.raises(SanicException):
        router.finalize()



# Generated at 2022-06-12 09:34:57.157766
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    r.add(
        uri='/',
        methods=['GET'],
        handler=None,
        host=None,
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version=None,
        name=None,
        unquote=False,
        static=False,
    )
    r.finalize()

# Generated at 2022-06-12 09:34:59.615067
# Unit test for constructor of class Router
def test_Router():
    router = Router(
        debug=False, hostname=None, host_matching=False, default_method="GET"
    )

# Generated at 2022-06-12 09:35:05.852841
# Unit test for method finalize of class Router
def test_Router_finalize():
    import sys
    import pytest

    try:
        router = Router(routes = {
            'badlabel': {
                'path': '/path/to/object',
                'methods': ['POST'],
                'handler': 'somehandler',
                'labels': {'__badlabel__': 'x'}
            }
        })
        with pytest.raises(SanicException) as err:
            router.finalize()
        assert str(err.value) == "Invalid route: /path/to/object. Parameter names cannot use '__'."
    except:
        pytest.fail('Unexpected exception raised')



# Generated at 2022-06-12 09:35:08.821965
# Unit test for constructor of class Router
def test_Router():
    router = Router()

    assert router.router_cache_size == 1024
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == ["HEAD", "OPTIONS", "GET", "POST", "PUT", "PATCH", "DELETE", "TRACE", "CONNECT"]


# Generated at 2022-06-12 09:35:11.544540
# Unit test for constructor of class Router
def test_Router():
    test_router = Router()
    assert test_router.DEFAULT_METHOD == "GET"
    assert test_router.ALLOWED_METHODS == HTTP_METHODS


# Generated at 2022-06-12 09:35:19.004707
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.server import HttpProtocol
    from sanic.exceptions import SanicException
    from sanic.handlers import ErrorHandler
    from sanic.router import Router
    from sanic.views import CompositionView
    import sys

    # try exception case
    # define a route with lables that start with '__'
    route = Route("/", None, ["__file_uri__", "__test__test__test__"], None,
                   router=None)
    router = Router(HttpProtocol, ErrorHandler(), [route], None)
    # exception raised because of '__test__test__test__'
    try:
        router.finalize()
    except SanicException as e:
        assert '__test__test__test__' in str(e)

    # try nomal case
    # define a route with