

# Generated at 2022-06-12 09:25:54.060940
# Unit test for method finalize of class Router
def test_Router_finalize():
    router1 = Router()
    router1.dynamic_routes[""] = Route("/{}", 0, {})
    assert router1.finalize() == None

    router2 = Router()
    router2.dynamic_routes[""] = Route("/{__x}", 0, {})
    try:
        router2.finalize()
    except SanicException:
        assert True
    else:
        assert False

# Generated at 2022-06-12 09:26:03.994036
# Unit test for constructor of class Router
def test_Router():
    import unittest
    from unittest.mock import Mock, patch

    class TestRouter(unittest.TestCase):
        def test_Router(self):
            with patch("sanic_routing.route.Route") as mock_route:
                with patch("sanic_routing.route.RouteContext") as mock_route_context:

                    mock_route.return_value.ctx = mock_route_context.return_value

                    mock_router = Router()
                    mock_router.add('/', ['GET'], Mock(), name=None, strict_slashes=False, stream=False, ignore_body=False, version=None, unquote=False)

                    self.assertTrue(mock_router.routes_static['/'].ctx.name, "")

                    mock_router.rout

# Generated at 2022-06-12 09:26:09.657862
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router
    assert isinstance(router, (Router))
    assert hasattr(router, "DEFAULT_METHOD")
    assert hasattr(router, "ALLOWED_METHODS")
    assert hasattr(router, "routes")
    assert hasattr(router, "static_routes")
    assert hasattr(router, "dynamic_routes")
    assert hasattr(router, "regex_routes")
    assert hasattr(router, "name_index")
    assert hasattr(router, "attachments")
    assert hasattr(router, "controller_prefix")


# Generated at 2022-06-12 09:26:14.521103
# Unit test for constructor of class Router
def test_Router():
    router = Router()

    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}



# Generated at 2022-06-12 09:26:15.072273
# Unit test for constructor of class Router
def test_Router():
    assert True

# Generated at 2022-06-12 09:26:18.292536
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r.DEFAULT_METHOD == "GET"
    assert r.ALLOWED_METHODS == HTTP_METHODS


r = Router()
r.add("/users/me", methods=['GET', 'POST'], handler=None)


# Generated at 2022-06-12 09:26:27.888718
# Unit test for method finalize of class Router
def test_Router_finalize():
    class App():
        def __init__(self):
            self.routes = []

        def _generate_name(self, view_name):
            return view_name

    router = Router(App())
    router.ctx = App()

    route = Route(
        path="/",
        methods=['GET', 'POST'],
        handler=None,
        name=None,
        strict=False,
        unquote=False,
        re=False
    )
    router.dynamic_routes = {
        (sorted(route.methods), route.uri_template): route
    }
    # test with __file_uri__
    route.labels = ['__file_uri__']
    router.finalize()

# Generated at 2022-06-12 09:26:28.683716
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == 'GET'



# Generated at 2022-06-12 09:26:33.095439
# Unit test for constructor of class Router
def test_Router():
    # create an instance of Router
    router = Router()

    # define required attributes for an instance of Router class
    router.dynamic_routes = {}
    router.static_routes = {}
    router.regex_routes = {}
    router.name_index = {}
    router.ctx = 'some context'

    # create methods of Router class
    router.add = lambda x: x

    test_Router_instance = router
    assert(test_Router_instance)

# Generated at 2022-06-12 09:26:34.160717
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert isinstance(r, Router)


# Generated at 2022-06-12 09:26:39.048396
# Unit test for constructor of class Router
def test_Router():
    router = Router()

# Generated at 2022-06-12 09:26:47.012617
# Unit test for method finalize of class Router
def test_Router_finalize():
    route1 = Route('/', ['GET'], None)
    route2 = Route('/', ['GET'], None)
    router = Router()
    router.dynamic_routes = {'a': route1, 'b': route2}
    try:
        route1.labels = ('__x', '__y')
        router.finalize()
        assert False
    except:
        assert True
        route1.labels = ('__x', '__file_uri__')
    try:
        route2.labels = ('__a', '__b')
        router.finalize()
        assert False
    except:
        assert True

# Generated at 2022-06-12 09:26:52.422613
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    The router implementation responsible for routing a :class:`Request` object
    to the appropriate handler.
    """
    router = Router()
    router.add('/static/<name:path>', 'GET', lambda request: [1,2,3])
    router.add('/static/<name:path>', 'POST', lambda request: [1,2,3])
    try:
        router.finalize(object())
    except SanicException:
        pass
    # assert router.routes_all is not None
    # assert router.routes_static is not None
    # assert router.routes_dynamic is not None
    # assert router.routes_regex is not None


if __name__ == '__main__':
    test_Router_finalize()

# Generated at 2022-06-12 09:26:54.509801
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)

# Generated at 2022-06-12 09:27:03.634026
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.app import Sanic
    from sanic.models import Route
    from sanic.exceptions import SanicException
    # Test: 
    # 1. Test that no exception is raised when there are no routes
    app = Sanic('test_Router_finalize_1')
    app.router = Router(app)
    app.router.finalize()
    # 2. Test that no exception is raised when there is a route
    route = Route('/test', "handler", app=app)
    app = Sanic('test_Router_finalize_2')
    app.router = Router(app)
    app.router.dynamic_routes[route.labels] = route
    app.router.finalize()
    # 3. Test that exception is raised when there is an invalid route
   

# Generated at 2022-06-12 09:27:05.644799
# Unit test for constructor of class Router
def test_Router():
    class Application():
        def __init__(self):
            pass
    app = Application()
    Router(app)
    return True


# Generated at 2022-06-12 09:27:07.118721
# Unit test for constructor of class Router
def test_Router():
    print("\n# Unit test Router")
    test_router = Router()


# Generated at 2022-06-12 09:27:12.555983
# Unit test for method finalize of class Router
def test_Router_finalize():
    from unittest.mock import Mock
    from unittest.mock import MagicMock
    import re
    from sanic.router import Router

    router = Router()
    router.dynamic_routes = {
        'test': Mock(labels=['__file_uri__', '__abs_path__', 'test'])
    }
    router.finalize({})

    router.dynamic_routes = {
        'test': Mock(labels=['__file_uri__', '__abs_path__', '__test__'])
    }
    with pytest.raises(SanicException):
        router.finalize({})

# Generated at 2022-06-12 09:27:17.771660
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        Router().finalize()
    except SanicException :
        pass
    else:
        assert False
    try:
        Router().finalize(dict(a=1))
    except SanicException :
        pass
    else:
        assert False
    try:
        Router().finalize(globals(),dict(a=1))
    except SanicException :
        pass
    else:
        assert False


# Generated at 2022-06-12 09:27:19.356315
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert isinstance(r, BaseRouter)

# Generated at 2022-06-12 09:27:27.597162
# Unit test for method finalize of class Router
def test_Router_finalize():
    assert True

# Generated at 2022-06-12 09:27:29.735234
# Unit test for method finalize of class Router
def test_Router_finalize():
     router = Router()
     with pytest.raises(SanicException) as excinfo:
         router.finalize()
     assert excinfo.type == SanicException
#

# Generated at 2022-06-12 09:27:32.615786
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r
    r.add('/test', 'GET', lambda x: ..., host='127.0.0.1')
    assert r


# Generated at 2022-06-12 09:27:33.721662
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router == Router()
    return True


# Generated at 2022-06-12 09:27:42.169483
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    assert router.dynamic_routes == {}
    router.add('/users/<id>', ['POST'], None)
    router.add('/users/<id>', ['POST'], None, labels=['__file_uri__'])
    router.add('/users/<id>', ['POST'], None, labels=['__file_uri__', 'name'])
    router.finalize()
    assert bool(router.dynamic_routes)
    router.add('/users/<id>', ['POST'], None, labels=['__file_uri__', 'name'])
    with pytest.raises(SanicException) as err:
        router.finalize()
    assert isinstance(err.value, SanicException)

# Generated at 2022-06-12 09:27:49.623826
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Route
    from sanic.app import Sanic
    from sanic_routing import BaseRouter
    from sanic_routing.route import RouteContext
    from sanic.constants import HTTP_METHODS

    from sanic.exceptions import SanicException

    HTTP_METHODS = HTTP_METHODS + ("OPTIONS",)

    class TestRouter(BaseRouter):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)


# Generated at 2022-06-12 09:27:58.835695
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route(router, "/", None, None)
    try:
        router.finalize()
    except SanicException as e:
        assert e.args[0] == "No routes found"

    route.labels.append("__name__")
    route.labels.append("__file_uri__")
    router.dynamic_routes[route.id] = route

    try:
        router.finalize()
    except SanicException as e:
        assert e.args[0] == "Invalid route: /. Parameter names cannot use '__'."

    route.labels = ["valid_name"]
    router.finalize()


# Generated at 2022-06-12 09:27:59.707167
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    r.DEFAULT_METHOD

# Generated at 2022-06-12 09:28:06.177633
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.ctx['DEFAULT_METHOD'] == router.DEFAULT_METHOD
    assert router.base_ctx == router.ctx
    assert router.name_index == {}
    assert router.tree == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.routes_all == router.routes
    assert router.routes_static == router.static_routes
    assert router.routes_dynamic == router.dynamic_routes
    assert router.routes_regex == router.regex_routes

if __name__=="__main__":
    router = Router()

# Generated at 2022-06-12 09:28:14.512277
# Unit test for constructor of class Router
def test_Router():
  def check_route_property_values(router, route, path, handler, methods, name, strict, unquote):
    assert router.routes[route].ctx.path == path
    assert router.routes[route].ctx.handler == handler
    assert router.routes[route].ctx.methods == methods
    assert router.routes[route].ctx.name == name
    assert router.routes[route].ctx.strict == strict
    assert router.routes[route].ctx.unquote == unquote

  def identity(request):
    return request

  router = Router(None)
  router.add("/test", ["GET", "POST"], identity)
  router.add("/test2", ["GET", "POST"], identity)

# Generated at 2022-06-12 09:28:38.144829
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router != None
    assert router.DEFAULT_METHOD == 'GET'
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router._get == router.get
    assert router._add == router.add
    assert router.hosts == {}
    assert router.name_index == {}
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-12 09:28:39.565691
# Unit test for constructor of class Router
def test_Router():
    """
    assert syntax and object model.
    """
    assert Router(None)

# Generated at 2022-06-12 09:28:41.712480
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS


# Generated at 2022-06-12 09:28:48.451573
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.name == "router"
    assert router.parent == None
    assert router.path == ""
    assert isinstance(router.routes, dict)
    assert isinstance(router.routes_all, dict)
    assert isinstance(router.routes_regex, dict)
    assert isinstance(router.routes_static, dict)
    assert isinstance(router.routes_dynamic, dict)
    assert isinstance(router.static_routes, dict)
    assert isinstance(router.regex_routes, dict)
    assert isinstance(router.name_index, dict)
    assert isinstance(router.prefix, str)
    assert isinstance(router.default_prefix, str)

# Generated at 2022-06-12 09:28:53.570047
# Unit test for method finalize of class Router
def test_Router_finalize():
    uri = "/users/<name>"
    method = "POST"
    host = "localhost"

    def handler(request):
        print(request)
        return "ok"

    router = Router()
    router.add(uri, [method], handler)

    try:
        router.finalize()
    except SanicException as e:
        print(e)



# Generated at 2022-06-12 09:29:02.629768
# Unit test for constructor of class Router
def test_Router():
    assert Router._get.cache_info().currsize == 0
    my_router = Router()
    assert my_router.ctx is None
    assert my_router.routes == []
    assert my_router.name_index == {}
    assert my_router.host_index == {}
    assert my_router.method_index == {}
    assert my_router.dynamic_routes == {}
    assert my_router.static_routes == {}
    assert my_router.regex_routes == {}
    assert my_router.DEFAULT_METHOD == "GET"
    assert my_router.ALLOWED_METHODS == ["DELETE", "HEAD", "PATCH", "GET", "POST", "PUT", "OPTIONS"]


# Generated at 2022-06-12 09:29:12.636648
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic_routing.route import Route
    from sanic.constants import HTTP_METHODS

    router = Router()

# Generated at 2022-06-12 09:29:21.404333
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route_labels = {'__file_uri__': None}

    # Valid route (with __file_uri__ in labels)
    route = Route(path='/test/<path:param>', handler=None,
                  methods=None, name=None, strict=False, unquote=False,
                  labels=route_labels)
    router.dynamic_routes['/test/<path:param>'] = route

    # Invalid route (with __test in labels)
    route_labels = {'__test': None}
    route = Route(path='/test/<path:param>', handler=None,
                  methods=None, name=None, strict=False, unquote=False,
                  labels=route_labels)

# Generated at 2022-06-12 09:29:23.952986
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.dynamic_routes = {'{var}': 'route'}
    try:
        router.finalize()
    except:
        print("Exception was raised")
    else:
        print("No exception was raised, that is wrong")


# Generated at 2022-06-12 09:29:31.698075
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()

    @router.route("/path", methods=["get"])
    def handler(request):
        pass

    # Case: no error
    router.finalize()

    @router.route("/path/<__file_uri__:path>", methods=["get"])
    def handler(request):
        pass

    # Case: no error
    router.finalize()

    @router.route("/path/<__file_uri__:path>", methods=["get"])
    def handler(request):
        pass

    # Case: error

# Generated at 2022-06-12 09:30:18.664235
# Unit test for constructor of class Router
def test_Router():
    from sanic import Sanic
    from sanic.request import Request
    app = Sanic("test_app")

    async def async_handler(request):
        return text("OK")

    @app.middleware("request")
    async def handler(request):
        return text("OK")

    @app.get("/", name="test", strict_slashes=True)
    async def handler(request):
        return text("OK")

    router = Router(app)

    assert isinstance(router.add, type(router.get))
    assert router.DEFAULT_METHOD == "GET"
    assert isinstance(router.ALLOWED_METHODS, tuple)
    assert len(router.ALLOWED_METHODS) > 0



# Generated at 2022-06-12 09:30:19.872920
# Unit test for constructor of class Router
def test_Router():
    # Create an instance of class Router
    router = Router()


# Generated at 2022-06-12 09:30:21.851205
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r.DEFAULT_METHOD == "GET"
    assert r.ALLOWED_METHODS == HTTP_METHODS
    assert r.DEFAULT_METHOD == "GET"
    assert r.ALLOWED_METHODS == HTTP_METHODS


# Generated at 2022-06-12 09:30:29.180051
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    from sanic_router_generator.router import Router

    # Case 1: Parameter names can use __
    router = Router(app=None, strict=False)
    router.add(
        uri="test_uri",
        methods=None,
        handler=None,
        host=None,
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version=None,
        name="test_name",
        unquote=False,
        static=False,
    )
    assert router.finalize()
    # Case 2: Parameter names can't use __
    router = Router(app=None, strict=False)

# Generated at 2022-06-12 09:30:36.369491
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    
    app = Sanic(__name__)
    
    class HTTPMethodView(HTTPMethodView):
        def get(self, request: Request) -> HTTPResponse:
            return HTTPResponse(
                status=200,
                headers={},
                body={},
                content_type="application/json",
                charset="utf-8")

    test_route_view = HTTPMethodView.as_view()
    test_route = app.add_route(test_route_view, "/test", \
                               methods=["GET"], name="test_route")

# Generated at 2022-06-12 09:30:38.643734
# Unit test for constructor of class Router
def test_Router():
    router = Router(app=None)
    assert router.DEFAULT_METHOD == 'GET'
    assert router.ALLOWED_METHODS == ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS', 'HEAD']

# Generated at 2022-06-12 09:30:39.404332
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router


# Generated at 2022-06-12 09:30:42.166952
# Unit test for constructor of class Router
def test_Router():
    router = Router()

    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS

# Generated at 2022-06-12 09:30:50.262029
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Arrange
    class MyRouter(Router):
        def __init__(self):
            super().__init__()
            self.regex_routes = {}
            self.dynamic_routes = {'1': {'1': {'path': 'abcd', 'handler': None, 'methods': ['GET'], 'name': None, 'strict': False, 'unquote': False, 'requirements': {'host': None}, 'ctx': {'ignore_body': False, 'stream': False, 'hosts': [None]}}}}

    my_router = MyRouter()

    # Act
    # Assert
    with pytest.raises(SanicException):
        my_router.finalize()

# Generated at 2022-06-12 09:30:59.030844
# Unit test for constructor of class Router
def test_Router():
    uri = "/hello/world"
    methods = ["get"]
    def handler(request, *args, **kwargs):
        return request
    host = "localhost"

    r1 = Router()
    assert isinstance(r1, Router)

    r2 = router = Router()
    assert isinstance(r2, Router)

    assert r1 == r2
    assert id(r1) == id(r2)

    r3 = Router(host = host)
    assert isinstance(r3, Router)

    assert r1 != r3
    assert id(r1) != id(r3)

    # Make sure that r1 == r2 and that id(r1) == id(r2)
    # even after r2 is updated
    r2.add(uri, methods, handler)

    assert r1 == r2

# Generated at 2022-06-12 09:32:19.153302
# Unit test for constructor of class Router
def test_Router():
    # Test 1
    # Purpose: Test the constructor function
    # Parameter:
    # Expectation:
    router = Router()
    print(type(router))



# Generated at 2022-06-12 09:32:25.406604
# Unit test for method finalize of class Router
def test_Router_finalize():
    """Method finalize of class Router"""
    try:
        @route('/r', methods=['GET', ])
        def r_handler(request):
            return text('OK')

        @route('/s', methods=['GET', ])
        def s_handler(request):
            return text('OK')

        @route('/t', methods=['GET', ])
        def t_handler(request):
            return text('OK')

        @route('/u', methods=['GET', ])
        def u_handler(request):
            return text('OK')

    except Exception as e:        # noqa
        raise e
    else:
        Router.finalize()

# Generated at 2022-06-12 09:32:35.013342
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()

    from sanic.handlers import ErrorHandler
    from sanic.response import HTTPResponse

    async def handler(request):
        return HTTPResponse("test")

    async def error_handler(request, exception):
        pass

    router.add("/test_route", ["GET"], handler, strict_slashes=True)
    router.add("/test_route2/{name}", ["GET"], handler, strict_slashes=True)
    router.add("/test_route3/{name}/{age:int}", ["GET"], handler, strict_slashes=True)
    router.add("/test_route4/{name}/{age:int}", ["GET"], handler, strict_slashes=True)

    router.add_error(ErrorHandler, handler=error_handler)

# Generated at 2022-06-12 09:32:42.200735
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    Unit test for method finalize of class Router.
    """
    import sys
    import unittest

    class _TestRouter(Router):
        def __init__(self):
            super().__init__()
            self.ctx = type("app_ctx_obj", (), dict(app=None))
            self.ctx.app = type("app_obj", (), dict(NAME=None))
            self.ctx.app.NAME = "test_app"

    target = _TestRouter()
    target.dynamic_routes = dict(key1="/url1", key2="/url2")
    target.dynamic_routes["key1"].labels = tuple(["__file_uri__", "__abc__"])


# Generated at 2022-06-12 09:32:43.995947
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    routes = router.routes_all
    assert isinstance(routes, dict) and len(routes) == 0

# Generated at 2022-06-12 09:32:44.830013
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.ALLOWED_METHODS == HTTP_METHODS

# Generated at 2022-06-12 09:32:51.732398
# Unit test for method finalize of class Router

# Generated at 2022-06-12 09:32:52.511322
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None

# Generated at 2022-06-12 09:32:53.035589
# Unit test for method finalize of class Router
def test_Router_finalize():
    pass

# Generated at 2022-06-12 09:32:58.493217
# Unit test for method add of class Router
def test_Router_add():
    router = Router()

    def _func():
        pass

    _uri = "/test/uri/0001"
    _methods = ["GET", "POST", "OPTIONS"]
    _handler = _func
    _host = "localhost"
    _strict_slashes = False
    _stream = False
    _ignore_body = False
    _version = 1
    _name = "test_route"
    _unquote = False
    _static = False


# Generated at 2022-06-12 09:35:08.297837
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    from sanic.router import Router
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.exceptions import SanicException
    from sanic_routing.exceptions import NotFound as RoutingNotFound
    from sanic_routing.exceptions import NoMethod
    from sanic_routing.route import Route
    import pytest
    import unittest

    def func_handler(*args, **kwargs):
        return kwargs

    class TestView(HTTPMethodView):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            super().__init__()


# Generated at 2022-06-12 09:35:08.938752
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    return r


# Generated at 2022-06-12 09:35:14.288126
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    # Invalid route
    router.add("/test/<__param>", ["GET"], lambda r: "test")
    try:
        router.finalize()
    except:
        assert True
    else:
        assert False
    # Correct route
    router.add("/test/<param>", ["GET"], lambda r: "test")
    try:
        router.finalize()
    except:
        assert False
    else:
        assert True

test_Router_finalize()

# Generated at 2022-06-12 09:35:15.180951
# Unit test for constructor of class Router
def test_Router():  # type: ignore
    router = Router(app=None)

# Generated at 2022-06-12 09:35:18.483089
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    with raises(SanicException) as exception:
        router.finalize()
    assert "Invalid route: <sanic_routing.route.Route path: //*, methods: GET, HEAD, OPTIONS, PUT, POST, PATCH, DELETE>" in str(exception.value)

# Generated at 2022-06-12 09:35:22.085433
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    route = Route("GET", "/test", None)
    router.attach(route)
    assert router.get("/test", "GET", None)[0] == route

# Generated at 2022-06-12 09:35:23.184154
# Unit test for constructor of class Router
def test_Router():
    assert isinstance(Router(), Router)


# Generated at 2022-06-12 09:35:24.433070
# Unit test for constructor of class Router
def test_Router():
    app = Application()
    assert isinstance(app.router, Router)


# Generated at 2022-06-12 09:35:28.163757
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes == {}
    assert router.routes_all == {}
    assert router.routes_regex == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.name_index == {}
    assert router.ctx.app is None
    assert router.ctx.router is router


# Generated at 2022-06-12 09:35:32.848229
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()

    with pytest.raises(SanicException):
        router.add("/<__file_uri__:path>", "GET", lambda x: x)
        router.finalize()

    with pytest.raises(SanicException):
        router.add("/<__test_uri__:path>", "GET", lambda x: x)
        router.finalize()