

# Generated at 2022-06-12 09:25:42.610144
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert(isinstance(router, Router))


# Generated at 2022-06-12 09:25:49.422537
# Unit test for constructor of class Router
def test_Router():
    from sanic.api_group import APIGroup
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.views import HTTPMethodView

    class MyView(HTTPMethodView):
        pass

    # TODO: more cases
    app = Mock(name='app')
    router = Router(app)
    assert router.app is app
    assert router.host is None
    assert router.ctx.app is app
    assert router.ctx.host is None

    app2 = Mock(name='app2')
    router2 = Router(app2, host='example.com')
    assert router2.app is app2
    assert router2.host == 'example.com'
    assert router2.ctx.app is app2
    assert router2.ctx.host

# Generated at 2022-06-12 09:25:51.816365
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS


# Generated at 2022-06-12 09:25:53.065055
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None


# Generated at 2022-06-12 09:25:55.171141
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router) == True


# Generated at 2022-06-12 09:25:59.269690
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == 'GET'
    assert router.ALLOWED_METHODS == HTTP_METHODS
    from sanic_routing.router import cache_requests # Do not forget this import
    assert router.cache_requests == cache_requests

# Generated at 2022-06-12 09:26:05.766665
# Unit test for method finalize of class Router
def test_Router_finalize():
    import sys

    router = Router(None)
    route = Route("/test", lambda: None, {}, None, None)
    route.labels = ["__bad__"]
    router.dynamic_routes = {1: route}
    if sys.version_info >= (3, 8):
        with pytest.raises(
            SanicException, match="Invalid route: /test. Parameter names cannot use '__'."
        ):
            router.finalize()
    else:
        with pytest.raises(SanicException, match="Invalid route: /test"):
            router.finalize()

# Generated at 2022-06-12 09:26:07.980123
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add("/<id>", methods=["GET"])
    try:
        router.finalize()
    except Exception as e:
        assert str(e) == "Invalid route: /<id> (GET). Parameter names cannot use '__'."

# Generated at 2022-06-12 09:26:15.472312
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    route0 = Route(
        uri='/',
        handler=lambda r: None,
        methods=['GET'],
        labels={'__full_uri__': '//'},
        path='/',
        strict=False,
    )
    # should not raise exception
    r.finalize()
    assert route0 in r.dynamic_routes.values()
    with pytest.raises(SanicException):
        r.dynamic_routes.clear()
        r.dynamic_routes.values().append(route0)
        # should raise exception
        r.finalize()

# Generated at 2022-06-12 09:26:21.829002
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    app = Sanic()
    router = Router()
    router.add(uri='/users/<user_id:int>',
               methods=('GET', 'PUT'),
               host='localhost',
               handler=None,
               name='users_by_id',
               strict_slashes=False,
               stream=False,
               ignore_body=False,
               version=None,
               unquote=False)
    assert router.finalize(app)


# Generated at 2022-06-12 09:26:28.066073
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router

# Generated at 2022-06-12 09:26:35.389598
# Unit test for constructor of class Router
def test_Router():
    '''
    Test case for "__init__" function of class "Router".
    '''
    router = Router()
    assert type(router) == Router
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS

# Generated at 2022-06-12 09:26:37.688536
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router
    assert isinstance(router, Router)


# Generated at 2022-06-12 09:26:44.903936
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    from sanic.request import Request
    from sanic.router import Route, Router
    from sanic.response import json

    request, response = Request.fake_request(), None

    route = Route("/", "get", handler=json({}))

    for labels in [
        ["foo", "bar"], ["foo", "__file_uri__"], ["foo", "__something__"]
    ]:
        router = Router()
        router.dynamic_routes["/<foo>/<bar>"] = route
        route.labels = labels

        if len(labels) == 2 and labels[1] == "__file_uri__":
            assert router.finalize() == True
        else:
            with pytest.raises(SanicException):
                router.finalize()


# Generated at 2022-06-12 09:26:47.321802
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert(isinstance(router, BaseRouter))


# Generated at 2022-06-12 09:26:54.510572
# Unit test for method finalize of class Router
def test_Router_finalize():
    from unittest.mock import Mock
    from sanic.router import Router
    app = Mock(spec=[])
    router = Router(app)
    app.config = {'ROUTER_CACHE_SIZE': 1024}
    routes = Router.dynamic_routes

    try:
        with pytest.raises(SanicException):
            router.add(uri="/", methods=["GET"], handler=None, host=None)
            router.finalize()
    except Exception as e:
        print(e)
        return False

    return True

# Generated at 2022-06-12 09:26:56.925534
# Unit test for method finalize of class Router
def test_Router_finalize():
    # https://github.com/huge-success/sanic/issues/474
    from sanic.router import Router
    router_instance = Router()
    # This should not raise an error
    router_instance.finalize()

# Generated at 2022-06-12 09:27:06.220440
# Unit test for method finalize of class Router
def test_Router_finalize():
    import unittest
    import sys
    import os
    import builtins
    from sanic.app import Sanic

    # Expected to raise exception for invalid route
    app = Sanic("test_Router")

    router = Router(app)
    route = Route("/", "GET", app, lambda x: x)
    route.labels.append("__test_label__")
    router.dynamic_routes["/"] = route
    assert router.finalize()

    # Expected to raise exception for invalid route
    route = Route("/", "GET", app, lambda x: x)
    route.labels.append("__invalid_label__")
    router.dynamic_routes["/"] = route

# Generated at 2022-06-12 09:27:09.323433
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    r.dynamic_routes = {'a': Route(handler=None, path='/<a>')}
    try:
        r.finalize()
    except SanicException:
        assert True
    else:
        assert False

# Generated at 2022-06-12 09:27:11.005424
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    r.dynamic_routes = {}
    r.finalize()
    assert True


# Generated at 2022-06-12 09:27:29.070189
# Unit test for constructor of class Router
def test_Router():
    class myRouter:
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c
    # test that no create myRouter because it do not have any method contains init
    try:
        Router.__init__(1,2,3)
    except TypeError:
        pass
    # test that no create myRouter because it do not have any method contains init
    try:
        Router(1,2,3)
    except TypeError:
        print("Passed TypeError test for Router() without sanic_routing.BaseRouter")
    # test that no create myRouter because it do not have any method contains init

# Generated at 2022-06-12 09:27:35.372472
# Unit test for constructor of class Router
def test_Router():
    def handle(request, *args, **kwargs):
        return request

    router = Router()
    router.add("/users", ["GET"], handle)
    router.add("/users/{id}", ["GET"], handle)
    router.add("/users/{id}", ["POST", "PUT", "DELETE"], handle)
    router.add("/users/{id}", ["GET"], handle, host="example.com")
    router.add("/users/{id}/image", ["GET"], handle, stream=True)
    router.add(
        "/users/{name}/{id}/image", ["POST"], handle, host=["example.com", "foo.com"]
    )

    assert router.get("/users", "GET", None)

# Generated at 2022-06-12 09:27:40.018471
# Unit test for method add of class Router
def test_Router_add():
    from sanic import Sanic
    from sanic.response import json

    app = Sanic("test_Router_add")

    app.router.add("/test_Router_add", "GET", lambda x: json("OK"))

    request, response = app.test_client.get("/test_Router_add")

    assert response.status == 200
    assert response.json == "OK"


# Generated at 2022-06-12 09:27:47.990643
# Unit test for method add of class Router
def test_Router_add():
    from sanic.exceptions import NotFound
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.testing import HOST, PORT, SanicTestClient

    app = SanicTestClient(__name__)

    @app.route("/")
    async def test(request):
        return HTTPResponse(body=b"OK")

    @app.exception(NotFound)
    def ignore_404s(request, exception):
        return HTTPResponse(body=b"Not found", status=404)

    @app.middleware("request")
    async def print_on_request(request):
        print("I print when a request is received by the server")


# Generated at 2022-06-12 09:27:48.558152
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router

# Generated at 2022-06-12 09:27:53.864164
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_regex == {}
    assert router.routes_dynamic == {}


# Generated at 2022-06-12 09:28:01.366445
# Unit test for method finalize of class Router
def test_Router_finalize():
    mock_sanic_context = MagicMock(spec=Sanic)
    router = Router(mock_sanic_context)
    mock_route = MagicMock(spec=Route)
    mock_route.labels = ["__file_uri__", "__test__"]
    router.routes_dynamic = {"route": mock_route}

    with pytest.raises(SanicException) as exception_info:
        router.finalize()

    assert str(exception_info.value) == "Invalid route: <MagicMock name='route' \
id='2642149440'>. Parameter names cannot use '__'."

# Generated at 2022-06-12 09:28:02.171854
# Unit test for constructor of class Router
def test_Router():
    r = Router()

# Generated at 2022-06-12 09:28:05.627546
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert(r.routes_all == [])
    assert(r.routes_dynamic == {})
    assert(r.routes_regex == {})
    assert(r.routes_static == {})
    assert(r.static_routes_prefixes == [])
    assert(r.static_routes_by_prefix == {})


# Generated at 2022-06-12 09:28:13.975223
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add(
        uri="/test",
        methods=["GET"],
        handler=None,
    )
    assert len(router.dynamic_routes) == 1
    assert len(router.static_routes) == 0
    assert len(router.routes) == 1

    router.add(
        uri="/test/static",
        methods=["GET"],
        handler=None,
        static=True
    )
    assert len(router.dynamic_routes) == 1
    assert len(router.static_routes) == 1
    assert len(router.routes) == 2

    assert len(router.get.cache_info().misses) == 0
    router.finalize()

# Generated at 2022-06-12 09:28:37.127315
# Unit test for constructor of class Router
def test_Router():
    urlPath = "/tasks"
    urlMethod = "GET"
    urlHost = "localhost"
    urlHandler = "testHandler"
    route = Router()
    try:
        route.add(
            uri = urlPath,
            methods = [urlMethod],
            handler = urlHandler,
            host = urlHost
        )
    except SanicException as e:
        # we don't want to leak that the exception occurred, but we want to 
        # make sure that a Sanic Exception gets raised because we can't
        # add a route with a url that uses '__'
        assert str(e) == "Invalid route: /tasks. Parameter names cannot use '__'."


# Generated at 2022-06-12 09:28:43.622326
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes == {}
    assert router.routes_all == {}
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []
    assert router.static_routes == []
    assert router.dynamic_routes == {}
    assert router.regex_routes == []
    assert router.ctx is None
    assert router.name_index == {}
    assert router.index == {}
    assert router.index_regex == {}
    assert router._lock == threading.Lock()
    assert router.DEFAULT_METHOD == "GET"

# Generated at 2022-06-12 09:28:47.877300
# Unit test for method finalize of class Router
def test_Router_finalize():
    router1 = Router(app=None)
    for route in router1.dynamic_routes.values():
        assert all(
            label.startswith("__") and label in ALLOWED_LABELS
            for label in route.labels
        )
    router2 = Router(app=None)
    list1 = [1, 2, 3, 4]
    router2.dynamic_routes = list1
    with pytest.raises(SanicException):
        router2.finalize()

# Generated at 2022-06-12 09:28:58.208834
# Unit test for method finalize of class Router
def test_Router_finalize():
    uri = 'admin/'
    methods = ['GET', 'POST']
    handler = 'test'
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = 'test'
    unquote = False
    static = False

    # Class SanicException
    class SanicException(Exception):
        pass
    # Class Router
    class Router(object):
        def __init__(self):
            self.ctx = self
            self.routes = []

        def __len__(self):
            return len(self.routes)

        def add(self, path, handler, methods, **kwargs):
            self.routes.append((path, handler, methods))
            return self

        @property
        def dynamic_routes(self):
            return

# Generated at 2022-06-12 09:29:03.164929
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router(None)
    route = Route(handler=None, path="abc/{name}/{age}", name=None, strict=False)
    route.labels = ["name", "age"]
    router.dynamic_routes["abc/{name}/{age}"] = route
    with pytest.raises(SanicException):
        router.finalize()
    route.labels = ["__file_uri__"]
    router.finalize()

# Generated at 2022-06-12 09:29:12.749859
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    router = Router(Sanic("test_app"))
    router.static_routes = {}
    router.dynamic_routes = {
        "/test_uri/<__file_uri__>": {
            "requirements": {},
            "labels": [],
            "path": "/test_uri/<__file_uri__>",
            "name": "test_dynamic_route",
            "handler": lambda request: request,
            "methods": {},
            "strict": False,
            "unquote": False,
            "ctx": {
                "static": True,
                "hosts": [],
                "ignore_body": False,
                "stream": False,
            },
        }
    }
    router.regex_routes = {}


# Generated at 2022-06-12 09:29:21.562851
# Unit test for method add of class Router
def test_Router_add():
    router = Router(app)

    # test invalid method
    invalid_methods = (1, (1, 2), [1, 2], {'a': 'b'})

    for method in invalid_methods:
        with pytest.raises(TypeError):
            router.add("url_path", method, handler)

    # test invalid handler
    with pytest.raises(TypeError):
        router.add("url_path", "GET", None)

    # test invalid uri
    invalid_uris = (1, (1, 2), [1, 2], {'a': 'b'})

    for uri in invalid_uris:
        with pytest.raises(TypeError):
            router.add(uri, "GET", handler)

    # test invalid host

# Generated at 2022-06-12 09:29:23.864358
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    print(router.routes_all)
    print(router.routes_dynamic)
    print(router.routes_static)
    print(router.routes_regex)



# Generated at 2022-06-12 09:29:29.857579
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        router = Router()

        @router.add('/user/<__id:int>/')
        @router.add('/user/<__id:int:name>/')
        @router.add('/user/<__id:int:name(test)>/')
        # @router.add('/user/<id:int>/<__id:int>/')
        def user_view(request, path_parameters):
            return text(request.url, 200)

        router.finalize()
        assert False
    except SanicException:
        assert True



# Generated at 2022-06-12 09:29:36.071713
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router == router, "Router is not equal to itself"
    assert router.routes_all == {}, "Routes_all is not an empty dictionary"
    assert router.routes_regex == {}, "Routes_regex is not an empty dictionary"
    assert (
        router.routes_dynamic == {}
    ), "Routes_dynamic is not an empty dictionary"
    assert (
        router.routes_static == {}
    ), "Routes_static is not an empty dictionary"



# Generated at 2022-06-12 09:30:08.805783
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == 'GET'
    assert router.ALLOWED_METHODS == {'HEAD', 'OPTIONS', 'GET', 'POST', 'PUT', 'DELETE', 'CONNECT', 'PATCH', 'TRACE'}


# Generated at 2022-06-12 09:30:17.008563
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import text
    router = Router()
    app = Sanic("test_Router_finalize")
    @app.route("/index")
    def index(request):
        return text("index")
    @app.route("/index/<arg1>")
    def index_arg(request, arg1):
        return text("index arg1")
    @app.route("/index/<arg1>/<arg2>")
    def index_arg(request, arg1,arg2):
        return text("index arg")

# Generated at 2022-06-12 09:30:19.363163
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        Router().add('/users/{user__id}')
    except SanicException as e:
        assert e.args[0].startswith('Invalid route')
        assert 'Parameter names cannot use' in e.args[0]
    else:
        raise AssertionError('SanicException not raised')

# Generated at 2022-06-12 09:30:20.672159
# Unit test for constructor of class Router
def test_Router():
    router = Router(None)
    assert router

# Test the method add of class Router

# Generated at 2022-06-12 09:30:24.172609
# Unit test for method finalize of class Router
def test_Router_finalize():
    route = Route(path='', handler=None, methods=('GET', 'POST', 'PUT', 'DELETE'))
    route.labels = [('__', '__')]
    assert Router.finalize(route) == NotFound('Requested URL {} not found'.format(route.path))

# Generated at 2022-06-12 09:30:24.654856
# Unit test for method finalize of class Router
def test_Router_finalize():
    pass

# Generated at 2022-06-12 09:30:26.388567
# Unit test for constructor of class Router
def test_Router():
    test_router = Router()
    assert test_router.router_cache_size == ROUTER_CACHE_SIZE


# Generated at 2022-06-12 09:30:30.904367
# Unit test for method finalize of class Router
def test_Router_finalize():
    dir(Router)
    Router.DEFAULT_METHOD
    Router.ALLOWED_METHODS
    Router.routes_all
    Router.routes_static
    Router.routes_dynamic
    Router.routes_regex
    Router.finalize()
    Router.add()
    Router.get()
    Router.find_route_by_view_name()


# Generated at 2022-06-12 09:30:31.708578
# Unit test for constructor of class Router
def test_Router():
    router = Router()

# Generated at 2022-06-12 09:30:36.672206
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router(
        {
            "dynamic_routes": {
                "route1": Route(path="/user/<name>/<id>"),
                "route2": Route(path="/user/<name>/something"),
                "route3": Route(path="/user/<__file_uri__>/something"),
                "route4": Route(path="/user/<__not_allowed>/something"),
            },
        }
    )
    
    router.finalize()


# Generated at 2022-06-12 09:31:06.467752
# Unit test for constructor of class Router
def test_Router():
    BaseRouter()

# Generated at 2022-06-12 09:31:06.953423
# Unit test for constructor of class Router
def test_Router():
    route = Router()

# Generated at 2022-06-12 09:31:12.074445
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        route = Route('GET', '/test', None, name='test', labels={'__test__': 1})
        Router().dynamic_routes['test'] = route
        Router().finalize()
        assert False
    except SanicException as e:
        assert e.message == "Invalid route: Route(GET, /test, host=None, handler=None, endpoint=test, strict_slashes=False, unquote=False, name=test, labels={'__test__': 1}). Parameter names cannot use '__'."

# Generated at 2022-06-12 09:31:16.909556
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.ctx.app == None
    assert router.ctx.host == None
    assert router.ctx.hosts == [None]
    assert router.ctx.static == False
    assert router.ctx.stream == False
    assert router.ctx.ignore_body == False
    assert router.ctx.strict is False
    assert router.ctx.methods == ['GET']


# Generated at 2022-06-12 09:31:18.177098
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router(None)
    with pytest.raises(SanicException):
        router.add(uri="/")

# Generated at 2022-06-12 09:31:24.946031
# Unit test for method finalize of class Router
def test_Router_finalize():
    route = {"path": "/", "methods": {'GET'}, "handler": None}
    try:
        Router().add(**route)
    except SanicException as e:
        assert(e.__repr__() == "Invalid route: {}. Parameter names cannot use '__'.".format(route))
    else:
        assert(False) # should not get here

    black_list = ['__hello__']
    try:
        Router().add(**route, labels=black_list)
    except SanicException as e:
        assert(e.__repr__() == "Invalid route: {}. Parameter names cannot use '__'.".format(route))
    else:
        assert(False) # should not get here

# Generated at 2022-06-12 09:31:30.740021
# Unit test for method finalize of class Router
def test_Router_finalize():
    view_name = "test"
    class Router_(Router):
        @property
        def routes_regex(self):
            return {
                "label_1": Route(uri="", handler=None, ctx={"labels": ["__label_1__"], "name": view_name})
                }
    with pytest.raises(SanicException) as exc:
        Router_().finalize()
    assert exc.value.args[-1] == f"Invalid route: {Route(uri='', handler=None, ctx={'labels': ['__label_1__'], 'name': 'test'}).__repr__()}. Parameter names cannot use '__'."



# Generated at 2022-06-12 09:31:31.533669
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-12 09:31:35.949485
# Unit test for constructor of class Router
def test_Router():
    router = Router("testRouter", None)
    assert router.ctx.app == None
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.alias_index == {}
    assert router.ctx.debug == False


# Generated at 2022-06-12 09:31:41.871300
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.dynamic_routes = {"key1": Route("", "", None),
                             "key2": Route("", "", None)}
    # Case 1: the label in labels of route has the prefix '__' and it is not in ALLOWED_LABELS
    router.dynamic_routes["key1"].labels = ["__test__"]
    with pytest.raises(SanicException):
        router.finalize()
    # Case 1: the label in labels of route has the prefix '__' and it is in ALLOWED_LABELS
    router.dynamic_routes["key1"].labels = ["__file_uri__"]
    router.finalize()

# Generated at 2022-06-12 09:32:48.789421
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}

    assert router.DEFAULT_METHOD == 'GET'
    assert router.ALLOWED_METHODS == HTTP_METHODS

    route, handler, kwargs = router._get('/', 'GET', None)
    assert route is None
    assert handler is None
    assert kwargs == {}

    router.add('/', ['GET'], handler, strict_slashes=False, stream=False, ignore_body=False, version=None, name=None, unquote=False, static=False)

# Generated at 2022-06-12 09:32:53.736474
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        router = Router()
        route1 = Route(
            handler=None,
            path="/test/for/route1",
            methods=["POST"],
            uri="/test/for/route1",
            name=None,
            strict=False,
            unquote=False
        )
        route2 = Route(
            handler=None,
            path="/test/for/route2",
            methods=["POST"],
            uri="/test/for/route2",
            name=None,
            strict=False,
            unquote=False
        )
        route2.labels = ["__file_uri__"]
        router.dynamic_routes = {"route1": route1, "route2": route2}

        router.finalize()

    except SanicException as e:
        assert "__"

# Generated at 2022-06-12 09:32:55.437142
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS

# Generated at 2022-06-12 09:33:02.200404
# Unit test for constructor of class Router
def test_Router():
    from sanic.router import Router
    from sanic.exceptions import MethodNotSupported
    from pytest import raises
    from sanic.constants import HTTP_METHODS
    from sanic.response import text
    from sanic.request import Request

    router = Router()
    router.get('/foo', methods=['GET', 'POST'], handler=text('success'))

    request = Request.from_http(
        'GET', '/foo', version='HTTP/1.1', headers=[], protocol=('1.1', '')
    )
    result = router.get(request)
    assert result[0] == text
    assert result[1].get('content_type') == 'text/plain; charset=utf-8'
    assert result[1].get('body').decode() == 'success'

    request = Request

# Generated at 2022-06-12 09:33:05.380187
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes == {}
    assert router.dynamic_routes == {}
    assert router.static_routes == {}
    assert router.name_index == {}
    assert router.regex_routes == {}

# Generated at 2022-06-12 09:33:05.936252
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    assert 1 == 1

# Generated at 2022-06-12 09:33:11.997145
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Test result when not breaking any rule
    router = Router()
    route = Route(  # type: ignore
        "path/to/something",
        lambda request: "OK",
        ["GET"],
        url_args=["id", "name"],
        labels=["id", "name"],
        ctx={"hosts": [None]},
        name="view_name",
    )
    route.ctx["hosts"].append("host")
    router.dynamic_routes["path/to/something"] = route
    router.finalize()
    assert router.dynamic_routes["path/to/something"] == route

    # Test breaking rule
    router = Router()

# Generated at 2022-06-12 09:33:13.781516
# Unit test for constructor of class Router
def test_Router():
    try:
      router = Router()
      assert True
    except Exception as e:
      assert False, e

test_Router()

# Generated at 2022-06-12 09:33:14.572861
# Unit test for constructor of class Router
def test_Router():
    router=Router(ctx=None)
    assert router

# Generated at 2022-06-12 09:33:22.200839
# Unit test for constructor of class Router
def test_Router():
    def test_handler():
        return

    path = "/test"
    method = "GET"
    router = Router()
    router.add(path=path, methods=[method], handler=test_handler)
    route, handler, params = router.get(path, method, None)
    assert isinstance(route, Route), "route is not a subclass of Route"
    assert isinstance(handler, RouteHandler), (
        "handler is not a subclass of RouteHandler"
    )
    assert isinstance(params, Dict[str, Any]), (
        "params is not a subclass of Dict[str, Any]"
    )
    assert route.path == path, "route.path != path"
    assert route.uri_template == path, "route.uri_template != path"

# Generated at 2022-06-12 09:35:30.628309
# Unit test for method add of class Router
def test_Router_add():
    from sanic.blueprints import Blueprint
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.views import CompositionView

    from sanic.log import logger

    logger.info("SANIC_DEBUG_ROUTER")
    app = Blueprint(name="test_Router_add")
    app.route("/test")
    router = Router()

    def handler():
        return HTTPResponse()

    def handler_decorator(func):
        return HTTPResponse()

    class HandlerClass:
        def __init__(self):
            pass

        async def handler_async(self, request: Request):
            return HTTPResponse()


# Generated at 2022-06-12 09:35:39.213592
# Unit test for method finalize of class Router
def test_Router_finalize():
    # create_router(app, uris)
    # create a router
    from sanic import Sanic
    from sanic.response import text

    app = Sanic()

    @app.route("/")
    async def hello(request):
        return text("Hello World!")

    router = Router(app, "test")
    router.add(uri='hello', methods=['GET'], handler=hello)

    try:
        router.finalize()
        raise Exception()
    except Exception as e:
        print(repr(e))
        assert(repr(e) == "SanicException('Invalid route: GET /hello. Parameter names cannot use \'__\'.',)")
    
if __name__ == "__main__":
    test_Router_finalize()