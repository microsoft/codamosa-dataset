

# Generated at 2022-06-12 09:26:03.317202
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-12 09:26:06.574787
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Test when a route contains internal label.
    router = Router()
    route = Route(path='/', methods=['GET'], handler=None, name=None, strict=False, unquote=False, ctx={})
    route.labels = {'__here_is_a_label_with_two_underscores': None}
    router.dynamic_routes = {'/': route}
    with pytest.raises(SanicException):
        router.finalize()


# Generated at 2022-06-12 09:26:15.938020
# Unit test for method finalize of class Router
def test_Router_finalize():
    """test if SanicException raised or not when route path contains ``__`` """
    # arrange
    test_router = Router()
    class custom_route(Route):
        def __init__(self, path: str, handler: RouteHandler, **kwargs):
            super().__init__(path, handler, **kwargs)
            self.labels = ["__file_uri__", "__bad_label__"]
    custom_route_instance = custom_route("/foo", None)
    test_router.dynamic_routes["foo"] = custom_route_instance

    # act, assert
    with pytest.raises(SanicException):
        test_router.finalize()

    # arrange

# Generated at 2022-06-12 09:26:19.892860
# Unit test for constructor of class Router
def test_Router():
    from sanic.app import Sanic

    app = Sanic('test')
    router = Router(app)
    assert isinstance(router, BaseRouter) \
        and app is router.ctx.app \
        and isinstance(router, Router)



# Generated at 2022-06-12 09:26:28.404494
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.app import Sanic

    app = Sanic("Unittest Sanic app")
    router = Router(ctx=app)
    route = Route(root=router, path="/uri", handler=None, strict_slashes=False)
    route.labels = {"__file_uri__": "foo"}
    router.dynamic_routes[1] = route

    # Test good route
    try:
        router.finalize()
    except Exception:
        raise AssertionError("Unittest fail!")

    # Test bad route
    route.labels = {"__bad_rule__": "foo"}
    try:
        router.finalize()
        raise AssertionError("Unittest fail!")
    except SanicException:
        pass

# Generated at 2022-06-12 09:26:33.945729
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router._get.cache_info() == lru_cache(maxsize=ROUTER_CACHE_SIZE).cache_info()
    assert router.get.cache_info() == lru_cache(maxsize=ROUTER_CACHE_SIZE).cache_info()
    assert router.find_route_by_view_name.cache_info() == lru_cache(maxsize=ROUTER_CACHE_SIZE).cache_info()

# Generated at 2022-06-12 09:26:42.332520
# Unit test for method finalize of class Router
def test_Router_finalize():
    router1 = Router()
    uri1 = "/users/<user_id:int>"
    router1.add(
        uri1, ["GET"], None, host=None, strict_slashes=True, stream=False, ignore_body=False, 
        version=None, name=None, unquote=True, static=False)
    assert router1.dynamic_routes[uri1].labels == {"user_id"}

    router2 = Router()
    uri2 = "/users/<__file_uri__:path>"
    router2.add(
        uri2, ["GET"], None, host=None, strict_slashes=True, stream=False, ignore_body=False, 
        version=None, name=None, unquote=True, static=False)
    assert router2.dynamic_r

# Generated at 2022-06-12 09:26:47.004556
# Unit test for constructor of class Router
def test_Router():
    # Initialize the Router
    route = Router(app=None)
    # Assert route has a property routes_all
    assert hasattr(route, "routes_all")
    # Assert route has a property routes_static
    assert hasattr(route, "routes_static")
    # Assert route has a property routes_dynamic
    assert hasattr(route, "routes_dynamic")
    # Assert route has a property routes_regex
    assert hasattr(route, "routes_regex")
    # Assert route has a method finalize
    assert hasattr(route, "finalize")

# Generated at 2022-06-12 09:26:52.403192
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add(
        uri='/',
        methods=('GET', 'POST'),
        handler='handler',
        strict_slashes=False
    )

    assert len(router.routes_all) == 1
    assert len(router.routes_static) == 0
    assert len(router.routes_dynamic) == 1
    assert len(router.routes_regex) == 0

    router.add(
        uri='/static_route',
        methods=('GET', 'POST'),
        handler='handler',
        strict_slashes=False
    )
    assert len(router.routes_all) == 2
    assert len(router.routes_static) == 1

# Generated at 2022-06-12 09:26:56.046877
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.ctx.app is None
    assert router.ctx.router == router
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS

# Generated at 2022-06-12 09:27:06.515343
# Unit test for constructor of class Router
def test_Router():
    # Initialize a Router object
    def handler(request):
        return request

    router = Router(handler=handler)

    # Test __init__()
    assert router.handler == handler
    assert router.routes == {}
    assert router.host_routes == {}
    assert router.regex_routes == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.name_index == {}
    assert router.path_index == {}
    assert router.host_index == {}

# Generated at 2022-06-12 09:27:12.931606
# Unit test for method finalize of class Router
def test_Router_finalize():
    # test invalid route (parameter name contains __)
    r = Router()
    r.add(uri="/", methods=["GET"], handler=print)
    r.add(uri="/<arg>", methods=["GET"], handler=print)
    r.add(uri="/__file_uri__", methods=["GET"], handler=print)
    r.add(uri="/__resource_uri__/<arg>", methods=["GET"], handler=print)
    r.add(uri="/__resource_uri__/<arg>/<__arg>", methods=["GET"], handler=print)
    try:
        r.finalize()
    except SanicException as e:
        assert 'Invalid route: <Route POST /__resource_uri__/<arg>/<__arg> [name:None]>' in str(e)

# Generated at 2022-06-12 09:27:21.468387
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert type(router) is Router
    assert router.ctx.app == None
    assert router.ctx.prefix == ""
    assert not router.ctx.strict_slashes
    assert router.ctx.host is None
    assert router.ctx.hosts is None
    assert router.ctx.name is None
    assert router.labels is None
    assert router.routes is None
    assert router.hosts is None
    assert router.name_index is None
    assert router.dynamic_routes is None
    assert router.static_routes is None
    assert router.regex_routes is None
    assert router.methods == {'GET', 'POST', 'PUT', 'DELETE', 'PATCH'}



# Generated at 2022-06-12 09:27:25.835551
# Unit test for method finalize of class Router
def test_Router_finalize():
    def foo():
        pass

    router = Router(None)
    router.add('/path/<name>', ['GET'], foo)
    with pytest.raises(Exception) as info:
        router.finalize()
    assert info.value.args[0] == "Invalid route: /path/<name> Method: GET. Parameter names cannot use '__'."

# Generated at 2022-06-12 09:27:31.484311
# Unit test for constructor of class Router
def test_Router():
    # Arrange
    router = Router()

    # Assert
    assert router.name_index == {}
    assert router.routes == {}
    assert router.routes_all == {}
    assert router.routes_dynamic == {}
    assert router.routes_static == {}
    assert router.routes_regex == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}


# Generated at 2022-06-12 09:27:32.818087
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router,BaseRouter)




# Generated at 2022-06-12 09:27:33.310225
# Unit test for method finalize of class Router
def test_Router_finalize():
    assert True

# Generated at 2022-06-12 09:27:39.855836
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        router = Router()
        router.add_route(
            uri='/ds'
            ,methods=['GET']
            ,handler="/home/dtuyen/Projects/work/open-source/sanic/sanic/views.py"
            ,host=None
            ,strict_slashes=False
            ,stream=False
            ,ignore_body=False
            ,version=None
            ,name=None
            ,unquote=False
            ,static=False
        )
    except SanicException as e:
        print("{}\n".format(e))

# Generated at 2022-06-12 09:27:40.401297
# Unit test for constructor of class Router
def test_Router():
    assert Router()

# Generated at 2022-06-12 09:27:48.304707
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    r.add(uri="/", methods=["GET", "POST"], handler=None)
    r.add(uri="/", methods=["GET", "POST"], handler=None, strict_slashes=False)
    r.add(uri="/", methods=["GET", "POST"], handler=None, strict_slashes=True)
    r.add(uri="/", methods=["GET", "POST"], handler=None, name="")
    r.add(uri="/", methods=["GET", "POST"], handler=None, name=None)
    r.add(uri="/", methods=["GET", "POST"], handler=None, name="uri")

# Generated at 2022-06-12 09:27:54.940850
# Unit test for method finalize of class Router
def test_Router_finalize():
    with pytest.raises(SanicException):
        Router(None).finalize(Route(None, "", "", ""))
# Low coverage: 14%

# Generated at 2022-06-12 09:27:58.665731
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add(uri='/', methods={'GET'}, handler=lambda: None)
    router.add(uri='/hello/{name}', methods={'GET'}, handler=lambda: None)

    assert router.finalize() is None

# Generated at 2022-06-12 09:27:59.216694
# Unit test for method finalize of class Router
def test_Router_finalize():
    pass

# Generated at 2022-06-12 09:28:01.053700
# Unit test for constructor of class Router
def test_Router():
    from    . import request
    Req = request.Request
    Req.__init__()
    assert isinstance(Req, request.Request)

# Generated at 2022-06-12 09:28:04.041191
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Init object
    route = ['A','B','C']
    from sanic.router import Router
    assert len(Router(route).dynamic_routes.values()) == 3
    assert len(Router(route).finalize().dynamic_routes.values()) == 3


# Generated at 2022-06-12 09:28:04.532224
# Unit test for constructor of class Router
def test_Router():
    pass

# Generated at 2022-06-12 09:28:07.127511
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    route_ = Route("/invalid__route/<foo_bar>", r.ctx, lambda x: x)
    r.dynamic_routes[route_.name] = route_
    assert r.finalize() == None

# Generated at 2022-06-12 09:28:10.622070
# Unit test for method finalize of class Router
def test_Router_finalize():
    with pytest.raises(SanicException):
        route = Route(None)
        route.labels = ['__file_uri__', '__file_uri__']
        router = Router()
        router.dynamic_routes = {'key': route}
        router.finalize()



# Generated at 2022-06-12 09:28:13.204540
# Unit test for constructor of class Router
def test_Router():
    from sanic_routing import Tree

    router = Router(prefix="/", tree=Tree())
    assert router.prefix == "/"
    assert router.ctx.app is None
    assert router.tree == Tree()

# Generated at 2022-06-12 09:28:14.359340
# Unit test for constructor of class Router
def test_Router():
    instance = Router()
    assert isinstance(instance, Router)


# Generated at 2022-06-12 09:28:24.501065
# Unit test for method finalize of class Router
def test_Router_finalize():
    pass


# Generated at 2022-06-12 09:28:29.470244
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == ["HEAD", "OPTIONS", "GET", "POST", "DELETE", "PUT", "PATCH", 'TRACE', 'CONNECT']
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.DEFAULT_METHOD in HTTP_METHODS


# Generated at 2022-06-12 09:28:38.014109
# Unit test for constructor of class Router
def test_Router():
    # Create a class
    router_temp = Router()

    # Create a object
    router = Router()

    # Create a object by copy
    router_copy = copy.deepcopy(router)

    # The class should be the same
    assert Router is router.__class__

    # The class of copied object should be the same
    assert Router is router_copy.__class__

    # The class of copied object should be the same
    assert isinstance(router, BaseRouter)

    # The class of copied object should be the same
    assert isinstance(router_copy, BaseRouter)

    # The copy object shouldn't be the same as original
    assert router is not router_copy

    return


# Generated at 2022-06-12 09:28:39.423687
# Unit test for constructor of class Router
def test_Router():
    routes = Router()
    assert routes is not None



# Generated at 2022-06-12 09:28:39.971025
# Unit test for constructor of class Router
def test_Router():
    router = Router()

# Generated at 2022-06-12 09:28:41.484438
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.STOP_ROUTING == 1


# Generated at 2022-06-12 09:28:42.000187
# Unit test for constructor of class Router
def test_Router():
    assert Router

# Generated at 2022-06-12 09:28:48.582398
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    from sanic.response import text
    router = Router(Sanic("test_app"))
    router.add(
        "/<__file_uri__:any_string>",
        methods=["GET"],
        handler=text("ok"),
        name="file_uri"
    )
    router.finalize()

# Generated at 2022-06-12 09:28:57.237254
# Unit test for method finalize of class Router
def test_Router_finalize():
    from . import app
    from . import request
    router = Router()
    route = Route(handler=None, path="/", methods=HTTP_METHODS, strict=False, unquote=False)
    route.labels = ["__file_uri__", "_a_", "b_", "c_d"]
    router.add_route(route)

    try:
        router.finalize(app, request)
    except SanicException as e:
        assert "Invalid route: / [GET, HEAD, POST, DELETE, PUT, PATCH, OPTIONS]" in str(e)
        assert "__" in str(e)
    else:
        raise AssertionError

# Generated at 2022-06-12 09:28:58.407728
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-12 09:29:25.120147
# Unit test for method finalize of class Router
def test_Router_finalize():
    # This method is used in the unit test and is not part of the API
    # pylint: disable=unused-argument
    router = Router()
    mock_app = Mock(name="app")
    mock_app.config.ROUTES_NAMESPACE = None
    router.ctx.app = mock_app
    route1 = Route("/test1", lambda: None)
    route1.labels.add("__test__")
    route1.labels.add("__test2__")
    route2 = Route("/test2", lambda: None)
    route2.labels.add("__test__")
    route2.labels.add("__test3__")
    router.routes_all = {route1, route2}
    router.finalize()

    # This method is used in the unit

# Generated at 2022-06-12 09:29:29.670856
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        router = Router()
        router.dynamic_routes['x'] = Route(
            handler= None,
            labels=['_test_handler'],
            name=None,
            methods=[],
            path='x',
            requirements={},
            methods_with_query_slash=[],
            strict=False,
            unquote=True)
        router.finalize()
    except Exception:
        assert True


# Generated at 2022-06-12 09:29:32.887307
# Unit test for method finalize of class Router
def test_Router_finalize():
    with pytest.raises(AssertionError):
        def a_handler(request, a):
            pass

    a_router = Router()
    a_router.add('/', 'GET', a_handler)
# End Unit test for method finalize of class Router

# Generated at 2022-06-12 09:29:37.696882
# Unit test for constructor of class Router
def test_Router():
    r = Router()

    assert not r.dynamic_routes
    assert not r.routes
    assert not r.static_routes
    assert isinstance(r.dynamic_routes, set)
    assert isinstance(r.routes, set)
    assert isinstance(r.static_routes, set)



# Generated at 2022-06-12 09:29:42.441821
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    router = Router()
    router.dynamic_routes = {('a.py', 1): Route('/test', None)}

    router.finalize()

    with pytest.raises(SanicException):
        router.dynamic_routes = {('a.py', 1): Route('/test/<__file_uri__>', None)}
        router.finalize()

# Generated at 2022-06-12 09:29:46.336398
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-12 09:29:49.661228
# Unit test for constructor of class Router
def test_Router():
    """Test constructor of class Router."""

    # Create a router
    router = Router()

    # Check that router is a subclass of BaseRouter
    assert(isinstance(router, BaseRouter))

# Generated at 2022-06-12 09:29:57.615174
# Unit test for constructor of class Router
def test_Router():
    test_router = Router()
    assert test_router.DEFAULT_METHOD == 'GET', "test_router.DEFAULT_METHOD == 'GET'"
    assert test_router.ALLOWED_METHODS == ['CONNECT', 'DELETE', 'GET', 'HEAD', 'OPTIONS', 'PATCH', 'POST', 'PUT', 'TRACE'], "test_router.ALLOWED_METHODS == ['CONNECT', 'DELETE', 'GET', 'HEAD', 'OPTIONS', 'PATCH', 'POST', 'PUT', 'TRACE']"
    assert test_router._cache.size == ROUTER_CACHE_SIZE, "test_router._cache.size == ROUTER_CACHE_SIZE"

# Generated at 2022-06-12 09:30:02.352627
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.response import json
    from sanic import Sanic

    app = Sanic("test_Router_finalize")
    router = Router()
    router.add("/", ["GET"], json({"OK": True}), "127.0.0.1", name="test_get")
    try:
        router.finalize("127.0.0.1", app)
    except SanicException:
        print("test Router finalize passed")

# Generated at 2022-06-12 09:30:03.109274
# Unit test for constructor of class Router
def test_Router():
    from sanic.router import Router
    Router()

# Generated at 2022-06-12 09:30:48.068608
# Unit test for method finalize of class Router
def test_Router_finalize():
    import sanic
    router = Router()
    uri = '/'
    method = 'GET'
    handler = sanic.views.CompositionView()
    uri2 = '/<name:string>'
    router.add(uri = uri,methods = [method],handler = handler)
    assert router.finalize() == None

    router.add(uri = uri2,methods = [method],handler = handler)
    assert router.find_route_by_view_name('CompositionView') == '/'


# Generated at 2022-06-12 09:30:48.591029
# Unit test for constructor of class Router
def test_Router():
    r1 = Router()

# Generated at 2022-06-12 09:30:50.009622
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.resolve("/", "GET") == None

# Generated at 2022-06-12 09:30:55.652698
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)
    assert isinstance(router.routes, dict)
    assert isinstance(router.static_routes, dict)
    assert isinstance(router.routes_by_endpoint, defaultdict)
    assert isinstance(router.dynamic_routes, dict)
    assert isinstance(router.regex_routes, list)
    assert isinstance(router.name_index, dict)
    assert router.ALLOWED_METHODS == HTTP_METHODS


# Generated at 2022-06-12 09:30:56.969106
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None


# Generated at 2022-06-12 09:30:57.519776
# Unit test for method finalize of class Router
def test_Router_finalize():
    assert True

# Generated at 2022-06-12 09:31:04.019248
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    from sanic.utils import sanic_endpoint_test

    # Arrange
    from sanic_routing.route import Route
    from sanic_routing.router import Router as RouterSanic
    router = RouterSanic()
    route = Route("/a", "GET", None)
    route.labels = ["__a__", "__b__", "c"]
    router.dynamic_routes = {
        "/a": route
    }

    # Act
    result = router.finalize()

    # Assert
    assert result == None


# Generated at 2022-06-12 09:31:07.629216
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes == {}
    assert router.name_index == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == []
    assert router.all_labels == {}
    assert router.static_routes == {}
    assert router.ctx.app is None

# Generated at 2022-06-12 09:31:08.129103
# Unit test for constructor of class Router
def test_Router():
    pass

# Generated at 2022-06-12 09:31:09.919509
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        Router().finalize()
        assert False
    except SanicException as e:
        assert "Invalid route: ." in str(e)

# Generated at 2022-06-12 09:32:36.358065
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.ctx is None
    assert router.name_index == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.static_routes == {}
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == []
    assert router.routes_regex == []
    assert router.DEFAULT_METHOD == 'GET'
    assert router.ALLOWED_METHODS == HTTP_METHODS

# Generated at 2022-06-12 09:32:44.933463
# Unit test for method finalize of class Router
def test_Router_finalize():
    uri = "/asds/<param1>/<param2>/<param3>/<param4>"
    router = Router()
    current_dir = os.path.dirname(os.path.abspath(__file__))
    static_dir = os.path.join(current_dir, "static")
    static_url_prefix = "/static"
    router.add(uri, ["GET"], lambda r: r, static=True, name="static_file")
    router.add(static_url_prefix, ['GET'], lambda r: r, name="static_folder")
    # not raise Exception
    router.finalize()


# Generated at 2022-06-12 09:32:48.662694
# Unit test for constructor of class Router
def test_Router():
    # test init
    router = Router()
    assert router.routes == {}
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-12 09:32:52.059777
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r.DEFAULT_METHOD == "GET"
    assert r.ALLOWED_METHODS == HTTP_METHODS
    assert r.routes_all == []
    assert r.routes_static == []
    assert r.routes_dynamic == {}
    assert r.routes_regex == []
    # assert r.router_cache_size == 1024

# Generated at 2022-06-12 09:32:52.734793
# Unit test for method finalize of class Router
def test_Router_finalize():
     route = Router()
     route.finalize()

# Generated at 2022-06-12 09:32:53.543242
# Unit test for constructor of class Router
def test_Router():
    assert Router() is not None

# Generated at 2022-06-12 09:32:54.384494
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-12 09:33:01.495473
# Unit test for constructor of class Router
def test_Router():
    # Arrange
    router = Router()

    # Assert
    assert getattr(router, 'DEFAULT_METHOD') == 'GET'
    assert getattr(router, 'ALLOWED_METHODS') == HTTP_METHODS
    assert getattr(router, 'DEFAULT_HOST') is None
    assert getattr(router, 'DEFAULT_VERSION') is None
    assert getattr(router, 'DEFAULT_NAMESPACE') == 'default'
    assert getattr(router, 'ctx') is None
    assert getattr(router, 'routes') == []
    assert getattr(router, 'error_handlers') == []
    assert getattr(router, 'name_index') == {}
    assert getattr(router, 'route_index') == {}

# Generated at 2022-06-12 09:33:03.235028
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        Router().finalize(None, None)
    except Exception as e:
        assert type(e) == SanicException
        assert e.args[0] == "Invalid route: /<__file_uri__>. Parameter names cannot use '__'."

# Generated at 2022-06-12 09:33:09.110757
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router

    # Example for invalid route label
    def test_invalid_route_label():
        router = Router()
        router.add(
            uri='/<__file_uri__:path>',
            methods=['POST'],
            handler=None,
            ignore_body=True,
            static=True
        )
        router.finalize()

    # Example for valid route label
    def test_valid_route_label():
        router = Router()
        router.add(
            uri='/<__file_uri__:path>',
            methods=['POST'],
            handler=None,
            ignore_body=True,
            static=True
        )
        router.finalize()