

# Generated at 2022-06-12 09:26:14.529714
# Unit test for method finalize of class Router
def test_Router_finalize():
    class FakeRouter(Router):
        def __init__(self, ctx):
            super().__init__(ctx)

# Generated at 2022-06-12 09:26:18.100463
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route(path='/test/test', method='test', handler=test_handler)
    route.labels = ['test', '__test']
    router.dynamic_routes['test'] = route
    return_value = router.finalize()
    assert return_value == None

# Generated at 2022-06-12 09:26:19.674809
# Unit test for constructor of class Router
def test_Router():
    a = Router()
    pass

# Generated at 2022-06-12 09:26:23.256494
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add('/', ['GET'], 'Handler')
    try:
        router.finalize()
    except SanicException as err:
        assert err.args[0] == "Invalid route: None. Parameter names cannot use '__'."

test_Router_finalize()

# Generated at 2022-06-12 09:26:26.777994
# Unit test for constructor of class Router
def test_Router():
    router = Router(add_regex_routes=True)
    assert router.DEFAULT_METHOD == 'GET'
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.ctx == {'app': None}

# Unit tests for method _get of class Router

# Generated at 2022-06-12 09:26:29.795126
# Unit test for constructor of class Router
def test_Router():
    import sanic.router as r
    from sanic.request import Request

    rreq = Request('GET', '/', host='example.com')
    assert isinstance(r.Router(), r.Router)



# Generated at 2022-06-12 09:26:34.485620
# Unit test for constructor of class Router
def test_Router():
    obj1 = Router()
    assert type(obj1) == Router
    assert not list(obj1.routes)
    assert not list(obj1.dynamic_routes)
    assert not list(obj1.static_routes)
    assert not list(obj1.regex_routes)
    assert obj1.ctx is None
    assert obj1.DEFAULT_METHOD == 'GET'
    assert obj1.ALLOWED_METHODS == HTTP_METHODS



# Generated at 2022-06-12 09:26:42.778172
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    
    app = Sanic()
    router = Router()
    router.ctx = app
    router.dynamic_routes = {
        'x': Route(
            path='/<name:{l0}{l1:__file_uri__}>',
            handler=None,
            methods=('GET',),
            name=None,
            strict=True,
            unquote=False,
            ctx=app,
            labels=('l0', 'l1'),
            defaults={},
            requirements={}
        )
    }

    try:
        router.finalize()
    except Exception as e:
        print(e)
        assert str(e) == "Invalid route: /<name:{l0}{l1:__file_uri__}>. Parameter names cannot use '__'."

# Generated at 2022-06-12 09:26:48.846586
# Unit test for constructor of class Router
def test_Router():
    import asyncio
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.app import Sanic
    import warnings
    warnings.filterwarnings("ignore", category=DeprecationWarning)

    app = Sanic("test_Router")

    async def simple(request):
        return HTTPResponse(b"123")

    @app.route("/simple")
    async def simple2(request):
        return HTTPResponse(b"123")

    @app.route("/simple3/")
    async def simple3(request):
        return HTTPResponse(b"123")


    @app.route("/simple5/")
    async def simple5(request):
        return HTTPResponse(b"123")


# Generated at 2022-06-12 09:27:05.421764
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    This function is testing for method finalize of class Router in
    the file router.py
    This method is used to finalize the router, meaning that it locks the router
    so that it cannot be modified.
    """

    router = Router()
    router.add("/<param>",["GET"],"handler")
    router.finalize()
    routes = router.dynamic_routes.values()
    with pytest.raises(SanicException):
        for route in routes:
            if any(
                label.startswith("__") and label not in ALLOWED_LABELS
                for label in route.labels
            ):
                raise SanicException(
                    f"Invalid route: {route}. Parameter names cannot use '__'."
                )


# Generated at 2022-06-12 09:27:16.128012
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-12 09:27:18.121419
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, BaseRouter)
    assert isinstance(router, Router)



# Generated at 2022-06-12 09:27:22.976608
# Unit test for method add of class Router
def test_Router_add():
    from sanic.request import Request
    from sanic.response import HTTPResponse

    route = Router().add('/path', ["GET"], lambda request: HTTPResponse(b"test", 200))
    req = Request.from_http(b'GET /path HTTP/1.1', None)
    res = route.handler(req)
    assert res.body == b"test"
    assert res.status == 200



# Generated at 2022-06-12 09:27:25.987120
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    print(r)
    print(r.routes_dynamic)
    print(r.routes_static)
    print(r.routes_regex)
    print(r.routes_all)

# Generated at 2022-06-12 09:27:33.495295
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from functools import partial
    from sanic import Sanic
    from sanic.exceptions import SanicException

    app = Sanic()

    router = Router()

    @app.route('/users/<user_id:int>')
    def handler(request, user_id):
        return text('OK')

    handler.__name__ = "handler"
    handler.__module__ = "__main__"

    route = Route(
            uri="/users/<user_id:int>",
            methods=['GET'],
            handler=handler,
            name=None,
            strict=False,
            unquote=False
        )
    route.labels = ["user_id", "__file_uri__"]

# Generated at 2022-06-12 09:27:37.570954
# Unit test for constructor of class Router
def test_Router():
    router = Router(
        host_matching=True,
        name_pattern="<:name:>",
        name_pattern_delimiter="."
    )
    # Test the attributes of class Router
    assert router.host_matching == True
    assert router.name_pattern == "<:name:>"
    assert router.name_pattern_delimiter == "."


# Generated at 2022-06-12 09:27:38.419036
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    routes = router.routes

# Generated at 2022-06-12 09:27:43.332410
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        router1 = Router()
        router2 = Router()
        router3 = Router()
        router1.add('/', ['GET'], lambda x:x)
        router2.add('/', ['GET'], lambda x:x)
        router3.add('/<__file_uri__:path>', ['GET'], lambda x:x)
    except Exception as e:
        print(e)
    return True

# Generated at 2022-06-12 09:27:44.494024
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert (type(router) == Router)


# Generated at 2022-06-12 09:27:45.147040
# Unit test for constructor of class Router
def test_Router():
    a_router = Router()
    assert a_router


# Generated at 2022-06-12 09:28:05.903541
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.dynamic_routes["1"] = Route(uri="/{param1:int}/{param2:int}/",
                                       method="GET",
                                       handler="handler1",
                                       name="route1",
                                       strict_slashes=True,
                                       uri_template="/{param1:int}/{param2:int}/",
                                       labels={"param1": "int", "param2": "int", "handler": "handler1"},
                                       ctx=router.ctx
                                       )

# Generated at 2022-06-12 09:28:14.249302
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router(None)
    route = {"labels": {"__file_uri__": "okay"}, "methods": ["GET"]}
    valid_route = [route]
    invalid_route = [{"labels": {"__invalid__": "invalid"}, "methods": ["GET"]}]
    router.routes = valid_route
    router.routes_dynamic = valid_route
    router.routes_regex = valid_route
    router.routes_static = valid_route
    try:
        router.finalize()
    except Exception as e:
        assert False, "No exception should be thrown."
    router.routes = invalid_route
    router.routes_dynamic = invalid_route
    router.routes_regex = invalid_route
    router.r

# Generated at 2022-06-12 09:28:22.237677
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Verify that the method finalize raises an exception if the
    # dynamic_routes contains a route with a disallowed label
    router = Router()
    router.dynamic_routes = {
        "test": Route(
            path="test",
            methods=["GET"],
            handler=lambda: None,
            labels=["__test__"],
        )
    }
    with pytest.raises(SanicException) as excinfo:
        router.finalize()
    assert "__test__" in str(excinfo.value)
    # Verify that the method finalize does not raise an exception if the
    # dynamic_routes contains a route with an allowed label
    router = Router()

# Generated at 2022-06-12 09:28:32.359981
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add('/user/<id>', ['GET'], None)
    # 0: OK
    router.finalize()

    router = Router()
    router.add('/user/<__id>', ['GET'], None)
    # 1: Invalid route: /user/<__id> (GET). Parameter names cannot use '__'.
    try:
        router.finalize()
    except SanicException as e:
        print(e)
    finally:
        assert True

    method = 'GET'
    path = ''
    host = '127.0.0.1'
    # 2: OK
    try:
        router.get(path, method, host)
    except SanicException as e:
        print(e)
    finally:
        assert True


# Generated at 2022-06-12 09:28:33.222912
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None

# Generated at 2022-06-12 09:28:41.814088
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.app import Sanic
    app = Sanic()
    router = Router(app, **{})
    route = Route(
        router,
        {
            "path": "test",
            "handler": None,
            "methods": None,
            "name": None,
            "hosts": None,
            "requirements": None,
            "request_class": None,
            "version": None,
            "middleware": None,
            "strict_slashes": True,
            "uri": "test",
            "labels": {},
            "unquote": True,
        },
    )
    router.dynamic_routes['test'] = route

# Generated at 2022-06-12 09:28:48.518386
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.server import HttpProtocol
    from types import FrameType
    from urllib.parse import unquote_plus

    GET_request_url = "/test/path"
    host = "127.0.0.1"

    class Router_test(Router):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    def request_handler_test(request):
        return "test"

    my_router = Router_test()
    my_router.add(
        GET_request_url,
        methods=["GET"],
        host=host,
        handler=request_handler_test,
    )
    my_router.finalize()
    request_handler_result = my_rou

# Generated at 2022-06-12 09:28:49.893681
# Unit test for constructor of class Router
def test_Router():
    assert(Router)


# Generated at 2022-06-12 09:28:59.307265
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r.DEFAULT_METHOD == "GET"
    assert r.ALLOWED_METHODS == HTTP_METHODS
    assert r.ALLOWED_METHODS_LIST == HTTP_METHODS
    assert r.ctx.app is None
    assert r.ctx.key == ""
    assert r.ctx.prefix == ""
    assert r.ctx.version is None
    assert r.ctx.routes == []
    assert r.ctx.custom_methods == []
    assert r.ctx.hosts == []
    assert r.ctx.methods == []
    assert r.ctx.strict == False
    assert r.ctx.unquote == True
    assert r.ctx.static == False
    assert r.ctx.name == None
    assert r.ctx.rules == []
    assert r.ctx.requ

# Generated at 2022-06-12 09:29:05.093656
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic

    app = Sanic("test_Router_finalize")
    
    @app.route("/<__a>")
    def handler1(request, *args, __a):
        pass

    @app.route("/")
    def handler2(request, *args):
        pass
    
    @app.route("/")
    def handler3(request, *args):
        pass

    app.add_route(handler2, "/", "GET")
    app.add_route(handler3, "/", "GET")
    with pytest.raises(SanicException):
        app._router.finalize()



# Generated at 2022-06-12 09:29:25.254663
# Unit test for constructor of class Router
def test_Router():
    # 构造函数
    router = Router()
    # 成员函数和属性
    assert router.ctx
    assert router.name_index
    assert router.dynamic_routes
    assert router.regex_routes
    assert router.static_routes
    assert router.add('/test', ['GET'], lambda x: x)
    assert router.routes_all
    assert router.routes_static
    assert router.routes_dynamic
    assert router.routes_regex
    assert router.find_route_by_view_name('test')
    assert router.get('', '', '')
    assert router.finalize()

if __name__ == "__main__":
    test_Router

# Generated at 2022-06-12 09:29:26.682193
# Unit test for constructor of class Router
def test_Router():
    obj = Router()
    assert str(type(obj)) == "<class 'sanic.router.Router'>"

# Generated at 2022-06-12 09:29:28.783499
# Unit test for constructor of class Router
def test_Router():
    router1 = Router()
    assert isinstance(router1, Router)
    router2 = Router([])
    assert isinstance(router2, Router)


# Generated at 2022-06-12 09:29:37.528826
# Unit test for constructor of class Router
def test_Router():
    request = "sanic.request.Request"
    response = "sanic.response.HTTPResponse"
    routes_all = "sanic.router.Router.routes_all"
    routes_static = "sanic.router.Router.routes_static"
    routes_dynamic = "sanic.router.Router.routes_dynamic"
    routes_regex = "sanic.router.Router.routes_regex"
    router = Router(request, response)
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-12 09:29:46.376087
# Unit test for method add of class Router
def test_Router_add():
    def handler(): pass
    router = Router()
    ret = router.add("/test/<param>", ["GET", "POST"], handler)
    assert ret is not None, "Should return a route."
    assert ret.path == "/test/<param>", "Should return the correct route."
    assert ret.handler is handler, "Should return the correct handler."
    assert ret.methods == ["GET", "POST"], "Should return the correct methods."
    assert ret.ctx.hosts == [None], "Should return the correct hosts."
    assert ret.ctx.ignore_body == False, "Should return the correct ignore body."
    assert ret.ctx.stream == False, "Should return the correct stream."
    assert ret.ctx.static == False, "Should return the correct static."

# Generated at 2022-06-12 09:29:53.637282
# Unit test for constructor of class Router
def test_Router():
    from sanic.blueprints import Blueprint
    assert isinstance(Router(),Router)
    assert isinstance(Router.get(Router(),'/','GET'),Tuple)
    # assert isinstance(Router.add(Router(),'/','GET',Router.get),Route)

    assert isinstance(Router.find_route_by_view_name(Router(),None),type(None))
    assert isinstance(Router.routes_all(Router()),dict)
    assert isinstance(Router.routes_static(Router()),dict)
    assert isinstance(Router.routes_dynamic(Router()),dict)
    assert isinstance(Router.routes_regex(Router()),dict)

    # assert isinstance(Router.finalize(Router()),

# Generated at 2022-06-12 09:30:01.747634
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    uri = 'abc'
    method = 'get'
    handler = RouteHandler("func")
    host = "0.0.0.0"
    strict_slashes = False
    stream = False
    ignore_body = False
    version = "3.5"
    name = "aa"
    unquote = True
    static = False
    print("====================")
    print("Test 1:")
    router.add(
        uri,
        method,
        handler,
        host=host,
        strict_slashes=strict_slashes,
        stream=stream,
        ignore_body=ignore_body,
        version=version,
        name=name,
        unquote=unquote,
        static=static
    )


# Generated at 2022-06-12 09:30:02.776225
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-12 09:30:10.750187
# Unit test for constructor of class Router
def test_Router():
    from sanic.exceptions import SanicException
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import NotFound

    from sanic.constants import HTTP_METHODS
    from sanic.models.handler_types import RouteHandler
    from sanic.router import Router
    from sanic.router import Route

    router = Router()
    router.add("/test", ["GET"], lambda: "test")
    try:
        router.add("/test", ["GET"], lambda: "test", version="v1")
    except:
        pass
    router.add_route("/test", lambda: "test", methods=["GET"])
    router.add_route("/test", lambda: "test", methods=["GET"], host="www.test.com")

# Generated at 2022-06-12 09:30:12.906960
# Unit test for constructor of class Router
def test_Router():
    assert isinstance(Router(), Router)
    assert isinstance(Router.ROUTER_CACHE_SIZE, int)
    assert isinstance(Router.ALLOWED_METHODS, tuple)
# Test for methods of class Router

# Generated at 2022-06-12 09:30:36.001173
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)

# Generated at 2022-06-12 09:30:42.897760
# Unit test for constructor of class Router
def test_Router():
    # assert type(Router()) == Router
    assert hasattr(Router,'finalize')
    assert hasattr(Router,'add')
    assert hasattr(Router,'get')
    assert hasattr(Router,'find_route_by_view_name')
    assert hasattr(Router,'routes_all')
    assert hasattr(Router,'routes_static')
    assert hasattr(Router,'routes_dynamic')
    assert hasattr(Router,'routes_regex')
    assert hasattr(Router,'_get')

# For test
if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-12 09:30:47.560114
# Unit test for constructor of class Router
def test_Router():
    router = Router(None)
    assert isinstance(router, BaseRouter)
    assert isinstance(router, Router)
    assert router.DEFAULT_METHOD == 'GET'
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.ROUTER_CACHE_SIZE == 1024
    assert router.ALLOWED_LABELS == ('__file_uri__',)


# Generated at 2022-06-12 09:30:55.683766
# Unit test for method add of class Router
def test_Router_add():
    from sanic import Sanic
    from sanic.request import Request

    from sanic.views import HTTPMethodView

    app = Sanic()

    class View(HTTPMethodView):
        def get(self, request, *args,**kwargs):
            return 'hello'

        def post(self, request, *args,**kwargs):
            return 'world'

    uri_view = View.as_view('view')
    
    app.router.add(uri='/view', methods=['GET', 'POST'], handler=uri_view)
    
    req = Request.from_http_message({
        'method':'GET', 'uri':'/view', 'http_version':'1.1', 'headers':[]})

# Generated at 2022-06-12 09:30:56.762711
# Unit test for constructor of class Router
def test_Router():
	router = Router()
	assert router

# Generated at 2022-06-12 09:31:00.931596
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []
    assert router.strict_slashes
    assert router.ctx is router


# Generated at 2022-06-12 09:31:04.335890
# Unit test for constructor of class Router
def test_Router():
    # Test without any arguments
    router_1 = Router()
    assert isinstance(router_1, Router)
    assert router_1.ctx == {}

    # Test with arguments
    router_2 = Router(app=None, name=None, prefix=None, host=None)
    assert isinstance(router_2, Router)
    assert router_2.ctx == {}

# Generated at 2022-06-12 09:31:06.138883
# Unit test for constructor of class Router
def test_Router():
    from .test_router import RouterTests
    router = Router() # type: ignore
    test = RouterTests()


# Generated at 2022-06-12 09:31:06.949797
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router


# Generated at 2022-06-12 09:31:10.452605
# Unit test for constructor of class Router
def test_Router():
    uri = "/"
    methods = ["GET", "POST"]
    handler = "test"
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = None

    router = Router(uri, methods, handler, strict_slashes, stream, ignore_body, version, name)

    return router

# Generated at 2022-06-12 09:31:45.806897
# Unit test for constructor of class Router
def test_Router():
    assert Router.DEFAULT_METHOD == "GET"
    assert Router.ALLOWED_METHODS == HTTP_METHODS

# Generated at 2022-06-12 09:31:47.006370
# Unit test for constructor of class Router
def test_Router():
    # Given
    router = Router()

    # Then
    assert router

# Generated at 2022-06-12 09:31:49.714630
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    r.get("/path", "POST", None)
    r.get("/path/<param>", "POST", None)
    r.add("/add", ["POST"], lambda x: x)
    assert r.find_route_by_view_name("/add") == None

# Generated at 2022-06-12 09:31:57.297186
# Unit test for method add of class Router
def test_Router_add():
    from sanic.app import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse, text

    app = Sanic("test_Router_add")
    router = Router()

    # noinspection PyProtectedMember
    @app.route("/test1")
    def test1(request: Request) -> HTTPResponse:
        return text("OK")

    route = router.routes_all[0]
    assert router.resolve(path="/test1", method="GET") == (route, test1, {})
    assert router.resolve(path="/test1", method="POST") == (None, None, None)

    # noinspection PyProtectedMember

# Generated at 2022-06-12 09:32:01.289047
# Unit test for constructor of class Router
def test_Router():
    from sanic.request import Request
    from sanic.response import HTTPResponse
    router = Router()
    @router.get("/")
    def handler(request):
        return HTTPResponse("OK")
    request = Request("GET", "/", {}, "", None, None, False)
    response = router.get_request_response(request)
    assert response is not None

# Generated at 2022-06-12 09:32:02.798678
# Unit test for constructor of class Router
def test_Router():
    """
    This function should test constructor of class Router
    """
    pass


# Generated at 2022-06-12 09:32:04.557781
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS


# Generated at 2022-06-12 09:32:14.079093
# Unit test for method add of class Router
def test_Router_add():
    from sanic.response import json
    from sanic.router import Router
    from sanic.server import serve
    from sanic.websocket import WebSocketProtocol
    from sanic.views import CompositionView
    from sanic_router.router import Route
    from unittest import TestCase
    from unittest.mock import MagicMock

    class TestRouter_add(TestCase):
        def test_add_correct_data(self):
            router = Router()
            router.resolve = MagicMock()

# Generated at 2022-06-12 09:32:16.005930
# Unit test for constructor of class Router
def test_Router():
    assert isinstance(Router, type), "The type of Router is not correct!"

    router = Router()
    assert isinstance(router, Router), "Router Object is not created!"

# Generated at 2022-06-12 09:32:18.778951
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == []
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-12 09:33:20.942498
# Unit test for constructor of class Router
def test_Router():
    import pytest

    with pytest.raises(SanicException):
        Router("v1")

# Generated at 2022-06-12 09:33:22.128573
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)

# Generated at 2022-06-12 09:33:23.191079
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert repr(r) == '<Router>'

# Generated at 2022-06-12 09:33:24.336747
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"

# Generated at 2022-06-12 09:33:26.136114
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS

# Generated at 2022-06-12 09:33:28.917042
# Unit test for constructor of class Router
def test_Router():
    """
    Sanity check for constructed object
    """
    router = Router()
    assert router.routes == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}



# Generated at 2022-06-12 09:33:29.762738
# Unit test for constructor of class Router
def test_Router():
    router = Router()

    assert router



# Generated at 2022-06-12 09:33:33.900816
# Unit test for constructor of class Router
def test_Router():
    router = Router()

    # Check exception
    try:
        router.DEFAULT_METHOD = 'POST'
        assert False
    except Exception as e:
        assert True

    try:
        router.ALLOWED_METHODS = ['PUT']
        assert False
    except Exception as e:
        assert True

# Generated at 2022-06-12 09:33:36.461808
# Unit test for constructor of class Router
def test_Router():
    try:
        assert Router().ctx is None  # make sure router was constructed properly
    except AssertionError:
        print("The router was not constructed properly.")
    else:
        print("The router was constructed properly.")

test_Router()

# Generated at 2022-06-12 09:33:39.941082
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes == {}
    assert router.ctx is None
    assert router.dynamic_routes == {}
    assert router.name_index == {}
    assert router.static_routes == {}
    assert router.regex_routes == {}


# Generated at 2022-06-12 09:35:46.975787
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.name_index == dict()

# Generated at 2022-06-12 09:35:48.281672
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)

# Generated at 2022-06-12 09:35:52.067382
# Unit test for constructor of class Router
def test_Router():
    from sanic.constants import HTTP_METHODS
    from sanic.router import Router
    from sanic_routing.router import Router as RoutingRouter

    # check inheritance
    assert issubclass(Router, RoutingRouter)
    # check constructor
    assert Router.DEFAULT_METHOD == "GET"
    assert Router.ALLOWED_METHODS == HTTP_METHODS

# Generated at 2022-06-12 09:35:53.770387
# Unit test for constructor of class Router
def test_Router():
    assert(ROUTER_CACHE_SIZE == 1024)
    assert(ALLOWED_LABELS == ("__file_uri__",))

# Generated at 2022-06-12 09:36:01.894876
# Unit test for constructor of class Router
def test_Router():
    from sanic.constants import HTTP_METHODS
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import NotFound
    from sanic.models.handler_types import RouteHandler

    router = Router()

    @router.add("/url")
    async def handler(request):
        pass
    route = router.routes_all[0]

    request = MagicMock()

    sanic_app = MagicMock()
    sanic_app.common_middleware.return_value = (MagicMock(), MagicMock())

    request.app = sanic_app

    assert router.get("/url", "GET", "")[1] == handler
    assert router.get("/url", "POST", "")[1] == handler