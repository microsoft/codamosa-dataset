

# Generated at 2022-06-12 09:26:05.115443
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Initialization - 1
    router = Router()
    router.add("/", ["GET"], "handler")
    router.add("/uri/<param>", ["GET"], "handler")
    router.add("/uri/<param>/<param2>", ["GET"], "handler")
    router.add("/static/<param>", ["GET"], "handler")

    # Evaluation - 1
    try:
        router.finalize()
    except SanicException:
        print("SanicException")
        assert True
    except:
        assert False

    # Initialization - 2
    router = Router()
    router.add("/", ["GET"], "handler")
    router.add("/__file_uri__/<param>", ["GET"], "handler")

# Generated at 2022-06-12 09:26:07.112918
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == 'GET'
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.ALLOWED_LABELS == ('__file_uri__',)

# Generated at 2022-06-12 09:26:07.986086
# Unit test for constructor of class Router
def test_Router():
    assert Router()



# Generated at 2022-06-12 09:26:12.669320
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    ### This is expected to fail
    router = Router()
    router.add(uri = "__test_Router_finalize", methods = ['GET'], handler = lambda x : print('__test_Router_finalize'))
    router.finalize()


if __name__ == "__main__":
    test_Router_finalize()

# Generated at 2022-06-12 09:26:13.518540
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router

# Generated at 2022-06-12 09:26:16.015801
# Unit test for constructor of class Router
def test_Router():
    x = Router(name = "test")
    assert x.name == "test"


# Generated at 2022-06-12 09:26:16.858282
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None

# Generated at 2022-06-12 09:26:22.487882
# Unit test for constructor of class Router
def test_Router():
    from sanic.request import Request
    from sanic.response import HTTPResponse, text

    handler = lambda request: HTTPResponse(text="hello world")
    router = Router.create(handler)

    request = Request(b"GET", "/", version=1, loop=None)
    returned_route, route_handler, route_args = router.get(request.uri, request.method, request.host)



# Generated at 2022-06-12 09:26:25.430081
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}

# Generated at 2022-06-12 09:26:28.525054
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}

# Generated at 2022-06-12 09:26:37.137812
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.request import Request
    from sanic.response import HTTPResponse
    router = Router()
    async def test(request: Request) -> HTTPResponse:
        return HTTPResponse(text="test")
    @router.route("/testing")
    def test2(request: Request) -> HTTPResponse:
        return HTTPResponse(text="test")
    router.add(uri="/route_test", methods=["GET"], handler=test)

    assert len(router.routes_dynamic) == 1
    try:
        router.finalize()
    except:
        assert False
    assert len(router.routes_dynamic) == 1
    router.get("/testing", "GET", None)
    route, handler, params = router.find_route

# Generated at 2022-06-12 09:26:39.617129
# Unit test for constructor of class Router
def test_Router():
    router=Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == ["GET", "POST", "DELETE", "PUT", "PATCH", "OPTIONS"]

# Generated at 2022-06-12 09:26:40.850261
# Unit test for constructor of class Router
def test_Router():
    test = Router()
    assert test is not None


# Generated at 2022-06-12 09:26:42.483987
# Unit test for constructor of class Router
def test_Router():
    # Setup
    router = Router.from_handlers(["/", lambda x: x])

    # Exercise

    # Verify
    assert True


# Generated at 2022-06-12 09:26:48.172329
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.static_routes = dict()
    router.dynamic_routes = dict()
    router.regex_routes = dict()
    router.routes_all = dict()
    req_path = "/example"
    req_method = "GET"
    host = "localhost"
    ctx = object()

    def get_handler(request):
        pass

    class _Route:
        def __init__(self, path, handler, labels):
            self.path = path
            self.handler = handler
            self.labels = labels

    router.dynamic_routes['/ex'] = _Route(
        path="/example",
        handler=get_handler,
        labels=["__ex_uri__"]
    )

# Generated at 2022-06-12 09:26:49.099898
# Unit test for constructor of class Router
def test_Router():
    assert(Router() is not None)

# Generated at 2022-06-12 09:26:59.565119
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)
    try:
        assert router.get('/', 'GET', '/') == (None, None, None)
    except:
        assert False
    try:
        assert router.add('/', 'GET', None)
    except:
        assert False
    assert router.finalize() == None
    assert router.routes_all == None
    assert router.routes_dynamic == None
    assert router.routes_regex == None
    assert router.routes_static == None
    try:
        assert router.find_route_by_view_name('name') == None
    except:
        assert False
    return router


# Generated at 2022-06-12 09:27:02.407413
# Unit test for constructor of class Router
def test_Router():
    rt = Router()
    assert rt.ROUTER_CACHE_SIZE == 1024
    assert rt.ALLOWED_METHODS == HTTP_METHODS
    assert rt.DEFAULT_METHOD == "GET"

# Generated at 2022-06-12 09:27:10.450236
# Unit test for method add of class Router
def test_Router_add():
    from sanic.views import HTTPMethodView
    from sanic.views import CompositionView

    HTTPMethodView.get = NotImplemented
    HTTPMethodView.post = NotImplemented
    CompositionView.get = NotImplemented
    CompositionView.post = NotImplemented
    Router.DEFAULT_METHOD = 'GET'
    router = Router()

    class Testget(HTTPMethodView):
        pass

    class Testpost(HTTPMethodView):
        pass

    router = Router()

    assert router.add(uri='/uri/add', methods=['GET', 'POST'], handler=Testget)
    assert router.add(uri='/uri/add/t', methods=['GET', 'POST'], handler=Testpost)

    assert router.rout

# Generated at 2022-06-12 09:27:12.848011
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert isinstance(router, BaseRouter)

# Generated at 2022-06-12 09:27:22.485789
# Unit test for constructor of class Router
def test_Router():
    hello_route = Route('/hello', None, ['GET'])
    hello_route.ctx.hosts = [None]
    assert len(hello_route.ctx.hosts) == 1
    # Test for adding a route
    router = Router()
    router.add('/hello', ['GET'], 'Hello')
    assert router.routes_all[0] == hello_route
    assert router.dynamic_routes
    assert router.regex_routes == {}
    assert router.static_routes == {}


# Generated at 2022-06-12 09:27:25.833879
# Unit test for method finalize of class Router
def test_Router_finalize():
    a = Router()
    with pytest.raises(SanicException) as error:
        a.finalize()
    assert str(error.value) == 'Invalid route: sanic_routing.route.Route(path=\'\'). Parameter names cannot use \'__\'.'

# Generated at 2022-06-12 09:27:33.159426
# Unit test for constructor of class Router
def test_Router():
    uri = 'my-uri'
    methods = ('GET')
    handler = 'my-handler'
    host = 'my-host'
    strict_slashes = False
    stream = False
    ignore_body = True
    version = '1'
    name = 'my-name'
    unquote = True
    static = False
    router = Router()
    router.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)
    routes = router.routes
    assert 'my-name' in routes
    assert '/v1/my-uri' in routes
    assert 'my-handler' in routes
    assert 'swaggerui' not in routes
    assert 'index.html' not in routes

# Generated at 2022-06-12 09:27:38.537616
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.ALLOWED_METHODS == ['GET', 'PUT', 'PATCH', 'POST', 'DELETE', 'OPTIONS', 'HEAD']
    assert router.DEFAULT_METHOD == 'GET'
    assert router.routes_all == []
    assert router.routes_dynamic == {}
    assert router.routes_static == []
    assert router.routes_regex == {}

#Unit test for method make_label of class Router

# Generated at 2022-06-12 09:27:39.391051
# Unit test for constructor of class Router
def test_Router():
    router = Router()


# Generated at 2022-06-12 09:27:40.310893
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None

# Generated at 2022-06-12 09:27:42.438481
# Unit test for constructor of class Router
def test_Router():
    # type: () -> None
    assert Router().DEFAULT_METHOD == "GET"
    assert Router().ALLOWED_METHODS == HTTP_METHODS


# Generated at 2022-06-12 09:27:44.481077
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    try:
        router.finalize()
        assert False, "Unexpectedly did not catch an exception"
    except:
        assert True


# Generated at 2022-06-12 09:27:48.269220
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    As expected, any exception should be raised if we use __ as a parameter name
    """
    route = Router(None, prefixed=False)
    route.dynamic_routes = {'test_route':{'labels':['__test__']}}
    with pytest.raises(SanicException):
        route.finalize()


# Generated at 2022-06-12 09:27:49.874906
# Unit test for constructor of class Router
def test_Router():
    from aiohttp.web import FileResponse
    async def async_func(request: FileResponse):
        return FileResponse()

    assert Router().add("/", "GET", async_func)

# Generated at 2022-06-12 09:28:02.756036
# Unit test for method finalize of class Router
def test_Router_finalize():
    class App(object):
        def _generate_name(self, *args, **kwargs):
            pass


    app = App()
    router = Router(app)
    router.add('/')
    router.finalize()

    assert router.routes == {}
    assert router.dynamic_routes == {}
    assert router.static_routes == {}
    assert router.name_index == {}
    assert router.regex_routes == {}
    assert router.ctx == app



# Generated at 2022-06-12 09:28:03.625781
# Unit test for constructor of class Router
def test_Router():
    new_Router = Router()
    assert type(new_Router) == Router

# Generated at 2022-06-12 09:28:08.098522
# Unit test for method finalize of class Router
def test_Router_finalize():
    class TestRouter(Router):
        def __init__(self):
            super().__init__()
            self.routes = {
                Route(uri = "hello", methods = ("GET", "POST"), name = "test"),
                Route(uri = "__test", methods = ("GET", "POST"), name = "test1")
            }
    
    try:
        test_router = TestRouter()
        assert True
    except:
        assert False



# Generated at 2022-06-12 09:28:11.441079
# Unit test for constructor of class Router
def test_Router():
    # assert that the Router class is defined
    assert isinstance(Router, type)

    try:
        router = Router()
        assert isinstance(router, Router)
        assert isinstance(router, BaseRouter)
    except:
        assert False



# Generated at 2022-06-12 09:28:15.911389
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.ALLOWED_METHODS is HTTP_METHODS
    assert router.DEFAULT_METHOD is "GET"
    assert router.routes_all == []
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.ctx is None


# Generated at 2022-06-12 09:28:16.871411
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router

# Generated at 2022-06-12 09:28:20.054892
# Unit test for constructor of class Router
def test_Router():
    router = Router()

    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert hasattr(router, "routes")
    assert hasattr(router, "get_routes")


# Generated at 2022-06-12 09:28:21.078054
# Unit test for constructor of class Router
def test_Router():
    router = Router(None, None)
    assert router is not None


# Generated at 2022-06-12 09:28:22.097782
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router


# Generated at 2022-06-12 09:28:32.063081
# Unit test for constructor of class Router
def test_Router():
    router=Router()
    router.ctx.app=str
    router.DEFAULT_METHOD="GET"
    router.ctx.app=str
    router.DEFAULT_METHOD="GET"
    router.ALLOWED_METHODS=HTTP_METHODS
    router.ctx.app=str
    router.DEFAULT_METHOD="GET"
    router.ALLOWED_METHODS=HTTP_METHODS
    assert router.routes_all=={}
    assert router.routes_static=={}
    assert router.routes_dynamic=={}
    assert router.routes_regex=={}
    assert router.DEFAULT_METHOD=="GET"
    assert router.ALLOWED_METHODS==HTTP_METHODS

# Generated at 2022-06-12 09:28:55.471211
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    try:
        r.finalize()
    except SanicException as e:
        assert "Invalid route: " in str(e)
    route = Route(handler="handler")

    # case 1
    try:
        route.labels = ["a", "b", "c"]
        r.dynamic_routes["test"] = route
        r.finalize()
    except SanicException as e:
        assert "Invalid route: " in str(e)

    # case 2
    try:
        route.labels = ["__a", "__b", "__c"]
        r.dynamic_routes["test"] = route
        r.finalize()
    except SanicException as e:
        assert "Invalid route: " in str(e)
    else:
        assert True

   

# Generated at 2022-06-12 09:28:57.346145
# Unit test for constructor of class Router
def test_Router():
    _test_router: Router = Router(name="test_route")
    return

# Generated at 2022-06-12 09:29:02.782243
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    r.DEFAULT_METHOD
    r.ALLOWED_METHODS
    r._get("", "", "")
    r.get("", "", "")
    r.add("", [""], lambda x: x, host="")
    r.find_route_by_view_name("")
    r.routes_all
    r.routes_static
    r.routes_dynamic
    r.routes_regex
    r.finalize()

# Generated at 2022-06-12 09:29:12.712288
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    router.add(uri="/test", methods=["GET"], handler=None)
    _, _, _ = router.get(path="/test", method="GET", host=None)
    _, _, _ = router.get(path="/test/", method="GET", host=None)
    _, _, _ = router.get(path="/test/1", method="GET", host=None)
    _, _, _ = router.get(path="/test/2", method="GET", host=None)
    _, _, _ = router.get(path="/test/3", method="GET", host=None)
    _, _, _ = router.get(path="/test/4", method="GET", host=None)

# Generated at 2022-06-12 09:29:14.814459
# Unit test for constructor of class Router
def test_Router():
    try:
        router = Router("sanic")
    except:
        print("[Test Fail]")
        return
    print("[Test Success]")


# Generated at 2022-06-12 09:29:18.277210
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes == dict()
    assert router.routes_all == dict()
    assert router.routes_static == dict()
    assert router.routes_dynamic == dict()
    assert router.routes_regex == dict()

# Generated at 2022-06-12 09:29:25.609208
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    def handler(request):
        return response.text("Hello World")
    router.add("/", ["GET"], handler)
    assert len(router.routes_all) == 1
    assert len(router.routes_static) == 1
    assert len(router.routes_dynamic) == 0
    assert len(router.routes_regex) == 0
    route = router.find_route_by_view_name("handler")
    assert route is not None
    route, handler, params = router.get("/", "GET", None)
    assert isinstance(route, Route)
    assert isinstance(handler, RouteHandler)
    assert isinstance(params, dict)


# Generated at 2022-06-12 09:29:26.173993
# Unit test for constructor of class Router
def test_Router():
    Router()

# Generated at 2022-06-12 09:29:26.688874
# Unit test for constructor of class Router
def test_Router():
    router = Router()

# Generated at 2022-06-12 09:29:30.006659
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}

if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-12 09:29:45.217615
# Unit test for constructor of class Router
def test_Router():
    router = Router(None, {"max_age":100})
    assert router.ctx.max_age == 100

# Generated at 2022-06-12 09:29:49.528455
# Unit test for constructor of class Router
def test_Router():
    route = Router(prefix='v1', host='localhost', strict_slashes=True, version=1.0)
    assert route.prefix == 'v1'
    assert route.host == 'localhost'
    assert route.strict_slashes == True
    assert route.version == 1.0
    

# Generated at 2022-06-12 09:29:55.497015
# Unit test for method finalize of class Router
def test_Router_finalize():
    route = Route(path="/", handler="handler", methods=["GET"], strict=True, unquote=True)
    with pytest.raises(SanicException, match="Invalid route: .+ Parameter names cannot use '__'."):
        route.labels = ["__unknown__"]
        router = Router()
        router.dynamic_routes["dummy"] = route
        router.finalize(app=None)

    route.labels = ["__file_uri__"]
    router = Router()
    router.dynamic_routes["dummy"] = route
    router.finalize(app=None)

# Generated at 2022-06-12 09:29:56.243143
# Unit test for constructor of class Router
def test_Router():
    # TODO
    router = Router()

# Generated at 2022-06-12 09:29:58.269814
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    router.__class__ = Router
    router2 = Router()
    router2.__class__ = Router
    assert router != router2


# Generated at 2022-06-12 09:30:00.575678
# Unit test for method finalize of class Router
def test_Router_finalize():
    SanicException("Invalid route: {route}. Parameter names cannot use '__'.")
    class_name = Router
    class_name.finalize()

# Generated at 2022-06-12 09:30:01.414292
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r


# Generated at 2022-06-12 09:30:03.011721
# Unit test for method add of class Router
def test_Router_add():
    uri = "hello"
    handler = None
    st = False
    r = Router()
    r.add(uri, handler, st)

# Generated at 2022-06-12 09:30:04.690835
# Unit test for constructor of class Router
def test_Router():
    # New router object
    router = Router()
    # Check if the instance is router object
    assert isinstance(router, Router)


# Generated at 2022-06-12 09:30:05.890056
# Unit test for constructor of class Router
def test_Router():
    router=Router()
    assert router.ctx.app is None


# Generated at 2022-06-12 09:30:35.736998
# Unit test for constructor of class Router
def test_Router():
    from sanic import Sanic
    from sanic.blueprints import Blueprint

    app = Sanic(__name__)
    test_bp = Blueprint(__name__)

    assert app.router.__class__ == Router
    assert test_bp.router.__class__ == Router

# Generated at 2022-06-12 09:30:36.806280
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router

test_Router()

# Generated at 2022-06-12 09:30:37.811672
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.ctx.router == router

# Generated at 2022-06-12 09:30:38.893210
# Unit test for constructor of class Router
def test_Router():
  r = Router()
  assert isinstance(r, Router)

# Generated at 2022-06-12 09:30:39.943940
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-12 09:30:42.125489
# Unit test for constructor of class Router
def test_Router():
    assert Router().__class__.__name__ == 'Router'

# Generated at 2022-06-12 09:30:48.352473
# Unit test for method add of class Router
def test_Router_add():
    # Setup test
    router = Router(None)

    uri = "/test/uri"
    methods = ["GET", "POST"]
    handler = lambda r: r
    host = "www.google.com"
    strict_slashes = False
    stream = False
    ignore_body = False
    version = "2"
    name = None

    # Test if expected exception raised
    with pytest.raises(NotImplementedError):
        router.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name)


# Generated at 2022-06-12 09:30:56.661115
# Unit test for method finalize of class Router
def test_Router_finalize():
    route = Route(
        router=Router(),
        path="/users/<uid>/photos/<pid>",
        methods=["GET"],
        handler=lambda x: x,
        uri_template="",
        name="",
        labels=None,
    )
    try:
        Router().finalize(route)
    except:
        pass
    route.labels = ["uid", "pid"]
    Router().finalize(route)
    route.labels = ["uid", "pid", "__page__"]
    Router().finalize(route)
    route.labels = ["uid", "pid", "__page__", "__page2__"]
    try:
        Router().finalize(route)
    except:
        pass

if __name__ == "__main__":
    test_Router_final

# Generated at 2022-06-12 09:31:00.042207
# Unit test for constructor of class Router
def test_Router():
    # Given
    class TestRouter(Router):
        def __init__(self):
            super().__init__()

    # When
    test_router = TestRouter()

    # Then
    assert test_router.ctx is None

# Generated at 2022-06-12 09:31:00.795786
# Unit test for constructor of class Router
def test_Router():
    pass

# Generated at 2022-06-12 09:31:28.792540
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router) == True

# Generated at 2022-06-12 09:31:31.001571
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.ctx == None


# Generated at 2022-06-12 09:31:31.584248
# Unit test for constructor of class Router
def test_Router():
    # Sanity test
    router = Router()

# Generated at 2022-06-12 09:31:34.446011
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_regex == {}
    assert router.routes_all == []
    assert router.dynamic_routes == {}
    assert router.static_routes == {}
    assert router.name_index == {}


# Generated at 2022-06-12 09:31:37.828148
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.routes_static == []

# Generated at 2022-06-12 09:31:38.871846
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert isinstance(r, BaseRouter)

# Generated at 2022-06-12 09:31:39.574805
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None

# Generated at 2022-06-12 09:31:40.142337
# Unit test for constructor of class Router
def test_Router():
    test_router = Router('kb')

# Generated at 2022-06-12 09:31:44.917458
# Unit test for method finalize of class Router
def test_Router_finalize():
    for label in ['__file_uri__', '_filename']:
        route = Route(RouteHandler)
        route.labels = [label]
        router = Router()
        router.dynamic_routes = {label : route}
        router.finalize()
    route = Route(RouteHandler)
    route.labels = ['__filename']
    router = Router()
    router.dynamic_routes = {'__filename' : route}
    try:
        router.finalize()
        raise Exception("Should throw an exception")
    except:
        pass
    route = Route(RouteHandler)
    route.labels = ['_filename', '__filename']
    router = Router()
    router.dynamic_routes = {'__filename' : route}

# Generated at 2022-06-12 09:31:45.770387
# Unit test for constructor of class Router
def test_Router():
    assert Router()


# Generated at 2022-06-12 09:32:45.463149
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    from sanic.constants import HTTP_METHODS
    from sanic.router import Router
    class FakeApp:
        def _generate_name(self, name):
            return name
    app = FakeApp()
    router = Router(app)
    uri= '/'
    methods=HTTP_METHODS
    name='name'
    handler_type=lambda x:x
    router.add(uri, methods, handler_type, name=name)
    try:
        router.finalize()
    except Exception as e:
        pytest.fail("failed to execute function, exception: {0}".format(e))

# Generated at 2022-06-12 09:32:50.051932
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router.routes, dict)
    assert isinstance(router.routes_all, dict)
    assert isinstance(router.routes_static, dict)
    assert isinstance(router.routes_dynamic, dict)
    assert isinstance(router.routes_regex, dict)



# Generated at 2022-06-12 09:32:52.675847
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.dynamic_routes = {'/path1/<param1>': 1, '/path2/<param2>': 2}
    try:
        router.finalize()
    except SanicException as e:
        print(e)
    else:
        assert False


# Generated at 2022-06-12 09:32:58.182321
# Unit test for constructor of class Router
def test_Router():
    uri = "/hello/{name}"
    methods = ["GET", "POST"]
    handler = RouteHandler
    host = None
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = "route1"
    unquote = False
    static = False
    r = Router()
    r.add(uri, methods, handler,host, strict_slashes, stream, ignore_body, version, name, unquote, static )
    assert r.name_index == {"route1": [Route(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote)]}

# Generated at 2022-06-12 09:33:04.180359
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes == {}
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.ctx.app == None
    assert router.ctx.url_prefix == None
    assert router.ctx.host == None


# Generated at 2022-06-12 09:33:06.090391
# Unit test for constructor of class Router
def test_Router():
    from sanic.app import Sanic
    from sanic.router import Router

    app = Sanic("test_sanic")
    router = Router(app)

# Generated at 2022-06-12 09:33:08.633914
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router(None)
    route = Route("/", "GET", None, None, None, None, None)
    route.labels = ["__test_label__"]
    router.dynamic_routes[route.path] = route
    router.finalize()

# Generated at 2022-06-12 09:33:09.022323
# Unit test for constructor of class Router
def test_Router():
    route = Router()

# Generated at 2022-06-12 09:33:10.381671
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS

# Generated at 2022-06-12 09:33:11.820853
# Unit test for constructor of class Router
def test_Router():
    # test constructor of class Router
    router = Router()
    assert (router is not None)


# Generated at 2022-06-12 09:35:44.500784
# Unit test for constructor of class Router
def test_Router():
    assert Router().dynamic_routes == {}
    assert Router().name_index == {}
    assert Router().static_routes == {}
    assert Router().static_routes_prefix == {}
    assert Router().ctx.static_routes == {}
    assert Router().ctx.static_routes_prefix == {}


# Generated at 2022-06-12 09:35:45.305967
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r

# Generated at 2022-06-12 09:35:46.449339
# Unit test for constructor of class Router
def test_Router():
    try:
        Router()
        assert True
    except:
        assert False

# Generated at 2022-06-12 09:35:47.177068
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router



# Generated at 2022-06-12 09:35:51.232918
# Unit test for constructor of class Router
def test_Router():
    uri = 'my_uri'
    host = 'my_host'
    methods = ('GET', 'POST')
    handler = 'my_handler'
    strict_slashes = True
    stream = True
    ignore_body = True
    version = 1.0
    name = 'my_name'
    unquote = True
    static = True

    router = Router()
    router.add(
        uri=uri,
        methods=methods,
        handler=handler,
        host=host,
        strict_slashes=strict_slashes,
        stream=stream,
        ignore_body=ignore_body,
        version=version,
        name=name,
        unquote=unquote,
        static=static
    )

    assert router.dynamic_routes

# Generated at 2022-06-12 09:35:52.371520
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router != None

test_Router()
