

# Generated at 2022-06-12 09:26:04.888648
# Unit test for constructor of class Router
def test_Router():
    # TODO: call all the methods such as __repr__,add,get,finalize,find_route_by_view_name and
    # check_route and check if it is working
    router = Router()
    router.routes = {}
    assert router.routes 
    
    uri = 'test'
    methods = ['GET']
    handler = lambda x: 'hello'
    host = None
    route = router.add(uri,methods,handler,host)
    assert len(route.methods) == 1

    from sanic.request import Request
    request = Request('http://localhost:8080/',method='GET')
    
    # Create a response object for the test
    from sanic.response import json
    response = json({'hello': 'world'})

# Generated at 2022-06-12 09:26:13.238369
# Unit test for constructor of class Router
def test_Router():
    class app:
        _route_cache = {}

    router = Router(app)

    assert router.ctx.app is app
    assert router.static_routes == {}
    assert router.regex_routes == {}
    assert router.dynamic_routes == {}
    assert router.name_index == {}
    assert router.routes == {}
    assert router.app_routes == []
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.DEFAULT_METHOD == "GET"

# Generated at 2022-06-12 09:26:20.106217
# Unit test for method finalize of class Router
def test_Router_finalize():
    a = Router(app=None)

    # Test that illegal labels raises SanicException
    try:
        a.dynamic_routes = {0: Route("/")}
        a.dynamic_routes[0].labels = {"__hello__": "asd"}
        a.finalize()
    except SanicException:
        pass
    else:
        raise Exception("Test failed: should have raised SanicException")

# Generated at 2022-06-12 09:26:25.150603
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.hosts_index == {}
    assert router.name_index == {}
    assert router.routes_all == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.routes_static == {}
    assert router.ctx.app.request_class
    assert router.ctx.app.response_class


# Generated at 2022-06-12 09:26:26.277738
# Unit test for constructor of class Router
def test_Router():
    router_ = Router()
    assert router_.routes == {}



# Generated at 2022-06-12 09:26:27.772948
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert(type(router) == Router)

# Generated at 2022-06-12 09:26:30.964429
# Unit test for constructor of class Router
def test_Router():
    import pytest
    router = Router()
    assert router.routes_all == []
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}

# @pytest.mark.unit

# Generated at 2022-06-12 09:26:39.425927
# Unit test for method finalize of class Router
def test_Router_finalize():
    import sanic.router
    import sanic.constants
    route = sanic.router.Route('/test/<param>', None, ['GET'], {})
    route.labels = ['__file_uri__', '_test']
    router = sanic.router.Router()
    router.dynamic_routes['/test/<param>'] = route
    assert router.finalize()
    route.labels = ['__file_uri__', '__test']
    router.dynamic_routes['/test/<param>'] = route

# Generated at 2022-06-12 09:26:42.084073
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes == {}
    assert router.static_routes == []
    assert router.dynamic_routes == {}
    assert router.regex_routes == []
    assert router.name_index == {}


# Generated at 2022-06-12 09:26:43.934001
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    r.add("/", ["GET"], lambda request, a: "", unquote=False)
    r.finalize()


# Generated at 2022-06-12 09:26:57.964421
# Unit test for method finalize of class Router
def test_Router_finalize():
    import unittest.mock

    mocked_self = unittest.mock.Mock()
    mocked_self.dynamic_routes = {
        "route_one": unittest.mock.Mock(labels=["__test_one__", "__test_two__"]),
        "route_two": unittest.mock.Mock(
            labels=["__test_one__", "__test_two__"]
        ),
    }
    mocked_self.static_routes = {
        "route_one": unittest.mock.Mock(labels=["__test_one__"]),
        "route_two": unittest.mock.Mock(labels=["__test_two__"]),
    }

# Generated at 2022-06-12 09:27:05.787714
# Unit test for constructor of class Router
def test_Router():
    # Test 1 - Create an instance of class Router
    router_1 = Router(None)

    # Test 2 - Check all the attributes are initialized properly
    assert len(router_1.routes) == 0
    assert len(router_1.routes_all) == 0
    assert len(router_1.routes_static) == 0
    assert len(router_1.routes_dynamic) == 0
    assert len(router_1.routes_regex) == 0
    assert len(router_1.name_index) == 0
    assert len(router_1.path_index) == 0



# Generated at 2022-06-12 09:27:12.532284
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    test_router = Router()
    assert test_router.dynamic_routes == {}, "dynamic_routes is empty at initial"
    test_route = test_router.add(uri='/test/<param1>', methods=['GET'], handler='/test')
    assert test_route.labels == {'param1': '<param1>'}
    assert test_router.dynamic_routes == {'/test/<param1>': test_route}
    # Pass
    test_router.finalize()
    # Raise exception

# Generated at 2022-06-12 09:27:13.031378
# Unit test for method finalize of class Router
def test_Router_finalize():
    pass

# Generated at 2022-06-12 09:27:15.699533
# Unit test for constructor of class Router
def test_Router():
    # Test good path
    router = Router(1)
    assert isinstance(router, Router)

    # Test bad path
    with pytest.raises(TypeError):
        Router("1")

# Generated at 2022-06-12 09:27:24.498749
# Unit test for method finalize of class Router
def test_Router_finalize():
    import sys
    import os
    import logging
    import json
    import pytest
    from os.path import dirname, abspath, join
    from pathlib import Path
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.errors import add_status_code

    app_folder = abspath(dirname(dirname(__file__)))
    test_folder = join(abspath(dirname(__file__)))

    sys.path.insert(1, app_folder)

    app = Mock()
    app.config = {}
    app.websocket_enabled = False

    router = Router(app)

    def handler():
        pass

    router.add(uri="/", methods=["GET"], handler=handler)

# Generated at 2022-06-12 09:27:26.741646
# Unit test for constructor of class Router
def test_Router():
    import sanic, types
    router = Router()
    assert isinstance(router, Router)
    assert isinstance(router.ctx, sanic.Sanic)


# Generated at 2022-06-12 09:27:27.585737
# Unit test for constructor of class Router
def test_Router():
    pass


# Generated at 2022-06-12 09:27:29.069862
# Unit test for constructor of class Router
def test_Router():
    def handler():
        pass
    router.add(uri='', methods=None,handler=handler)

# Generated at 2022-06-12 09:27:33.778398
# Unit test for method finalize of class Router
def test_Router_finalize():
    """Unit test for finalize method of class Router"""
    router = Router()
    class err(Exception): pass
    try:
        for route in router.dynamic_routes.values():
            if any(
                label.startswith("__") and label not in ALLOWED_LABELS
                for label in route.labels
            ): raise err
    except Exception as e:
        # if e.__class__ == err:
        #     assert True
        # else:
        #     assert False
        assert e.__class__ == err

# Generated at 2022-06-12 09:27:41.331400
# Unit test for constructor of class Router
def test_Router():
    router = Router(app=None)
    assert isinstance(router, Router)
    assert router.routes_all == dict()
    assert router.routes_dynamic == dict()
    assert router.routes_static == dict()
    assert router.routes_regex == dict()


# Generated at 2022-06-12 09:27:44.299192
# Unit test for constructor of class Router
def test_Router():
    from sanic.server import HTTPServer

    app = Sanic("test_router")
    server = HTTPServer(app=app)
    router = Router(server.app)

    assert router.routes == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.ctx == server.app
    assert router.host_index == {}

# Generated at 2022-06-12 09:27:46.664091
# Unit test for constructor of class Router
def test_Router():  # type: ignore
    router = Router()
    assert router.routes_static == []
    assert router.routes_dynamic == []
    assert router.routes_regex == []


# Generated at 2022-06-12 09:27:49.304191
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    # No exception when labels are not numeric
    router = Router()
    router.dynamic_routes = {0: Route(**{"labels": [0, "not_numeric",],})}
    router.finalize()

# Generated at 2022-06-12 09:27:51.799535
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.ctx.app == None
    assert router.ctx.router == router


# Generated at 2022-06-12 09:27:52.582133
# Unit test for constructor of class Router
def test_Router():
    pass

# Generated at 2022-06-12 09:27:58.365031
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r.name_index == {}
    assert r.ctx == {}
    assert r.regex_routes == {}
    assert r.static_routes == {}
    assert r.dynamic_routes == {}
    assert r.regex_routes_template == {}
    assert r.ctx.app == None
    assert r.raw_routes == {}


# Generated at 2022-06-12 09:28:02.990159
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.basepath == ''
    assert router.ctx.app is None
    assert router.ctx.router == router
    assert router.routes == {}
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}


# Generated at 2022-06-12 09:28:03.898449
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r.router_name == ""

# Generated at 2022-06-12 09:28:08.794664
# Unit test for constructor of class Router
def test_Router():
    assert Router.DEFAULT_METHOD == "GET"
    assert isinstance(Router.ALLOWED_METHODS,tuple)
    assert isinstance(Router.ALLOWED_METHODS[0],str)
    assert Router.ALLOWED_METHODS[0] == 'PUT'
    assert isinstance(Router.ALLOWED_METHODS[5],str)
    assert Router.ALLOWED_METHODS[5] == 'OPTIONS'


# Test for _get method of class Router

# Generated at 2022-06-12 09:28:17.434135
# Unit test for constructor of class Router
def test_Router():
    router=Router()
    assert type(router)==Router


# Generated at 2022-06-12 09:28:18.604126
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router
    assert repr(router) == "<Router>"

# Generated at 2022-06-12 09:28:22.322332
# Unit test for method finalize of class Router
def test_Router_finalize():
    r1 = Router()
    r1.add(uri="/path", methods=None, handler=None, host=None, strict_slashes=False, stream=False, ignore_body=False, version=None, name=None, unquote=False, static=False)
    try:
        r1.finalize()
    except:
        assert False, "Failed test case"



# Generated at 2022-06-12 09:28:23.954402
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.__class__.__name__ == 'Router'


# Generated at 2022-06-12 09:28:29.590147
# Unit test for constructor of class Router
def test_Router():
    router = Router(app=None)

    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.name_index == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.static_files == {}
    assert router.regex_routes == []
    assert router.routes == []


# Generated at 2022-06-12 09:28:33.417391
# Unit test for constructor of class Router
def test_Router():
    class App:
        pass

    app = App()
    r = Router(app)
    assert r.DEFAULT_METHOD == "GET"
    assert r.ALLOWED_METHODS == HTTP_METHODS


# Generated at 2022-06-12 09:28:34.646711
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)

# Generated at 2022-06-12 09:28:37.634427
# Unit test for constructor of class Router
def test_Router():
    router = Router(None)    #
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == ["DELETE", "GET", "HEAD", "OPTIONS", "PATCH", "POST", "PUT"]

# Generated at 2022-06-12 09:28:39.298444
# Unit test for method finalize of class Router
def test_Router_finalize():
    def handler_function():
        return True

    router = Router()
    router.add("/uri", ["GET"], handler_function, unquote=True)
    router.finalize([], [])



# Generated at 2022-06-12 09:28:46.658942
# Unit test for constructor of class Router
def test_Router():
    from sanic.constants import HTTP_METHODS
    from sanic.models.handler_types import RouteHandler
    from sanic.exceptions import MethodNotSupported, NotFound, SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.router import Route,Router
    from sanic.router import ROUTER_CACHE_SIZE

    assert ROUTER_CACHE_SIZE==1024
    test = Router()
    assert test.dynamic_routes=={}
    assert test.regex_routes=={}
    assert test.static_routes=={}
    assert test.ALLOWED_METHODS == HTTP_METHODS
    assert test.DEFAULT_METHOD == "GET"



# Generated at 2022-06-12 09:29:20.405120
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.dynamic_routes = {'/test': Route('/test', {'get': lambda *args: None}, None, None, None, [], [], [], [], None, None, None, None, {}, {'__file_uri__': None}, [])}
    router.finalize()

    router = Router()
    router.dynamic_routes = {'/test': Route('/test', {'get': lambda *args: None}, None, None, None, [], [], [], [], None, None, None, None, {}, {'__invalid_label__': None}, [])}
    with pytest.raises(SanicException):
        router.finalize()

if __name__ == "__main__":
    test_Router_finalize()

# Generated at 2022-06-12 09:29:21.714662
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None


# Generated at 2022-06-12 09:29:22.636928
# Unit test for constructor of class Router
def test_Router():
    assert 'sanic_routing.router.Router'

# Generated at 2022-06-12 09:29:28.115134
# Unit test for method finalize of class Router
def test_Router_finalize():
    uri = "http://www.google.com/api"
    def method_handler():
        pass

    # Case1: __file_uri__ is in route parameters
    method_router = Router()
    route = Route(uri, method_handler, [], None, None, None, None,
                 [], None, None, None, None)
    method_router.routes["/api"] = route

    # Case2: __file_uri__ is not in route parameters
    def raise_exception():
        raise SanicException(
            f"Invalid route: {route}. Parameter names cannot use '__'."
        )

    with pytest.raises(SanicException) as err:
        method_router.finalize()
    assert raise_exception() == err

# Generated at 2022-06-12 09:29:33.495444
# Unit test for method finalize of class Router
def test_Router_finalize():
    # create a route
    route = Route(
        path="/{id}",
        handler=None,
        methods=None,
        name=None,
        strict=False,
        unquote=False,
    )
    
    # add a label to the route
    route.labels.append("__file_uri__")
    router = Router()
    router.dynamic_routes["/{id}"] = route

    # check if the finalize method works
    router.finalize()

# Generated at 2022-06-12 09:29:34.322920
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r is not None

# Generated at 2022-06-12 09:29:40.266728
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        class InvalidRouter(Router):
            def __init__(self):
                super().__init__()
                self.dynamic_routes = {
                    1: Route(
                        uri="/<__bad_param>",
                        method="GET",
                        handler=None,
                        name=None,
                        strict_slashes=False,
                    )
                }
        InvalidRouter()
    except SanicException as e:
        assert "Invalid route: /<__bad_param> (GET), Parameter names cannot use '__'." in str(e)



# Generated at 2022-06-12 09:29:44.185807
# Unit test for constructor of class Router
def test_Router():
    try:
        router = Router() # Initialize router
        router.finalize() # Finalize router 
        router.add("/test", ["GET"], lambda x: "hoge") # Add route for test
    except Exception as e:
        print("Error occured : ", e)
        assert False
    assert True

# Generated at 2022-06-12 09:29:51.336164
# Unit test for method finalize of class Router
def test_Router_finalize():
    route = lambda: None
    route.url_rule = '/'
    route.__dict__['__file_uri__'] = '/static/test/'
    route.methods = ['GET']

    r = Router()
    r.dynamic_routes = {'/test/': route}
    r.finalize()

    route.__dict__['__file_uri__'] = '/static/test/'
    r = Router()
    r.dynamic_routes = {'/test/': route}
    r.finalize()
    assert isinstance(r, Router)
    assert isinstance(r.dynamic_routes, dict)

# Generated at 2022-06-12 09:29:54.027458
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router._get.cache_info().maxsize == ROUTER_CACHE_SIZE

# Generated at 2022-06-12 09:30:23.318095
# Unit test for constructor of class Router
def test_Router():
    pass


# Generated at 2022-06-12 09:30:24.376500
# Unit test for constructor of class Router
def test_Router():
    x = Router()
    assert isinstance(x, Router)

# Generated at 2022-06-12 09:30:25.807337
# Unit test for constructor of class Router
def test_Router():
    my_router = Router()
    assert isinstance(my_router, Router)



# Generated at 2022-06-12 09:30:27.549147
# Unit test for constructor of class Router
def test_Router():
    # Check if object is created successfully
    object = Router()
    assert object is not None

# Generated at 2022-06-12 09:30:30.334598
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    from sanic.exceptions import SanicException
    from sanic.router import Router

    router = Router()
    with pytest.raises(SanicException) as exception_info:
        router.finalize()

    assert str(exception_info.value) == "Missing parameters in URI: /"

# Generated at 2022-06-12 09:30:30.823787
# Unit test for constructor of class Router
def test_Router():
    Router()

# Generated at 2022-06-12 09:30:31.943288
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-12 09:30:37.135435
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Check normal case with valid parameters
    testRouter = Router()
    testRouter.dynamic_routes[0] = Route("", "", [], [], "", "")
    testRouter.finalize()
    assert True

    # Check error case with invalid parameters
    testRouter = Router()
    testRouter.dynamic_routes[0] = Route("", "", ["__file_uri__"], [], "", "")
    with pytest.raises(SanicException):
        testRouter.finalize()

# Generated at 2022-06-12 09:30:40.818534
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        r = Router()
        r.add('/:param1', ['GET'], lambda a, b, c: 0, strict_slashes=False, stream=False, ignore_body=False, host=None, unquote=False, static=False)
    except SanicException as e:
        m = (e.args)[0]
        print(m)

if __name__ == "__main__":
    test_Router_finalize()

# Generated at 2022-06-12 09:30:42.669305
# Unit test for constructor of class Router
def test_Router():
    def func():
        pass
    router = Router(func, func)
    router = Router(func)


# Generated at 2022-06-12 09:31:40.618042
# Unit test for constructor of class Router
def test_Router():
    Router()

# Generated at 2022-06-12 09:31:41.446549
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None


# Generated at 2022-06-12 09:31:42.079737
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.get

# Generated at 2022-06-12 09:31:42.525980
# Unit test for constructor of class Router
def test_Router():
    router = Router()

# Generated at 2022-06-12 09:31:46.670753
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert(isinstance(router, BaseRouter))
    assert(router.routes_all == router.routes)
    assert(router.routes_static == router.static_routes)
    assert(router.routes_dynamic == router.dynamic_routes)
    assert(router.routes_regex == router.regex_routes)
    assert(router.DEFAULT_METHOD == "GET")
    assert(router.ALLOWED_METHODS == HTTP_METHODS)


# Generated at 2022-06-12 09:31:50.647797
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    r.add("/<name:person>", ["GET"], lambda x:x)
    r.add("/<person>", ["GET"], lambda x:x)
    r.add("/<__file_uri__:name>", ["GET"], lambda x:x)
    with pytest.raises(SanicException):
        r.finalize()

# Generated at 2022-06-12 09:31:51.461311
# Unit test for constructor of class Router
def test_Router():
    assert bool(Router())

# Generated at 2022-06-12 09:31:54.159769
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r.routes_all == {}
    assert r.routes_dynamic == {}
    assert r.routes_regex == {}
    assert r.routes_static == {}


# Generated at 2022-06-12 09:31:56.932103
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router as Router1
    router = Router1()
    router.add(uri='/user/<id:int>', methods=('GET',), handler=None)
    
    try:
        router.finalize()
    except Exception as e:
        print(e)
        assert False

test_Router_finalize()

# Generated at 2022-06-12 09:31:57.973530
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.base_url == ""
    assert router.ctx == None

# Generated at 2022-06-12 09:34:02.642197
# Unit test for constructor of class Router
def test_Router():
    from unittest import mock
    from sanic.constants import HTTP_METHODS
    from sanic.models.handler_types import RouteHandler

    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS

    router = Router(default_method="POST")
    assert router.DEFAULT_METHOD == "POST"
    assert router.ALLOWED_METHODS == HTTP_METHODS

    router = Router(default_method="POST", allowed_methods=('GET', 'POST'))
    assert router.DEFAULT_METHOD == "POST"
    assert router.ALLOWED_METHODS == ('GET', 'POST')

    router = Router(default_method="POST", allowed_methods=['GET', 'POST'])

# Generated at 2022-06-12 09:34:03.386661
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None

# Generated at 2022-06-12 09:34:05.843249
# Unit test for constructor of class Router
def test_Router():
    app = Sanic("test_Router")
    router = app.get_route(app)
    assert isinstance(router, Router) == True

# Generated at 2022-06-12 09:34:07.112819
# Unit test for method finalize of class Router
def test_Router_finalize():
    # method is not tested directly
    # method relies on sanic.app.Sanic.finalize
    pass

# Generated at 2022-06-12 09:34:09.424724
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r.DEFAULT_METHOD == 'GET'
    assert r.ALLOWED_METHODS == ['GET', 'HEAD', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS']

# Generated at 2022-06-12 09:34:14.905103
# Unit test for method finalize of class Router
def test_Router_finalize():
    route1 = Route(path="a/b/c/d", methods=['GET'], handler=[], strict=True, unquote=False)
    route1.ctx.labels = ['__file_uri__', 'a', 'b', 'c', 'd']
    route2 = Route(path="a/b/c/d", methods=['GET'], handler=[], strict=True, unquote=False)
    route2.ctx.labels = ['__file_uri__', 'a', 'b', '__c', 'd']
    route3 = Route(path="a/b/c/d", methods=['GET'], handler=[], strict=True, unquote=False)
    route3.ctx.labels = ['__file_uri__', 'a', 'b', 'c', '__d']
    router = Router()

# Generated at 2022-06-12 09:34:17.412977
# Unit test for constructor of class Router
def test_Router():
    rt = Router()
    assert rt.routes_all == []
    assert rt.routes_static == []
    assert rt.routes_dynamic == []
    assert rt.routes_regex == []
# # Unit test for constructor of class Router


# Generated at 2022-06-12 09:34:18.197454
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert isinstance(r, BaseRouter)

# Generated at 2022-06-12 09:34:20.969405
# Unit test for constructor of class Router
def test_Router():
    assert Router().DEFAULT_METHOD == 'GET'
    assert Router().ALLOWED_METHODS == ['OPTIONS', 'HEAD', 'GET', 'POST', 'PUT', 'PATCH', 'DELETE']

    # assert Router().DEFAULT_METHOD == 'GET'
    # assert Router().ALLOWED_METHODS == ['OPTIONS', 'HEAD', 'GET', 'POST', 'PUT', 'PATCH', 'DELETE']


# Generated at 2022-06-12 09:34:22.192699
# Unit test for constructor of class Router
def test_Router():
    my_router = Router()
    assert isinstance(my_router, Router)