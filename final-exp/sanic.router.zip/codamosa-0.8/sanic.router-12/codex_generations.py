

# Generated at 2022-06-12 09:26:02.496595
# Unit test for constructor of class Router
def test_Router():
    """
    Test for constructor of class Router
    """
    router = Router(None)
    assert isinstance(router, Router)


# Generated at 2022-06-12 09:26:06.229540
# Unit test for constructor of class Router
def test_Router():
    router = Router(ctx=False)
    router.finalize(app=False)
    assert router is not None # the constructor works

    router = Router(ctx=False)
    router.finalize(app=False)
    with pytest.raises(SanicException):
        router.add("/url/", ["PUT", "POST"], None, None, None, None, None) # handles invalid route

# Generated at 2022-06-12 09:26:15.433017
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Create a dummy instance of class Router
    router = Router()

    # Create routes for testing
    route1 = Route(
        uri='/{name:__file_uri__}',
        methods=["GET"],
        handler=None,
        ctx={'ignore_body': False, 'stream': False, 'hosts': [None], 'static': False},
    )
    route2 = Route(
        uri='/{name:__file_uri__}/{test}',
        methods=["GET"],
        handler=None,
        ctx={'ignore_body': False, 'stream': False, 'hosts': [None], 'static': False},
    )

    # Add test route
    router.dynamic_routes['/{name:__file_uri__}'] = route1
    router.dynamic

# Generated at 2022-06-12 09:26:16.253348
# Unit test for constructor of class Router
def test_Router():
    assert Router is not None


# Generated at 2022-06-12 09:26:21.193510
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    r.dynamic_routes = {
        "a": "__hello__",
        "b": "__file_uri__",
        "c": "__hello",
    }

    try:
        r.finalize()
    except SanicException:
        pass
    else:
        raise Exception("finalize should raise SanicException")

# Generated at 2022-06-12 09:26:22.178308
# Unit test for constructor of class Router
def test_Router():
    assert isinstance(Router(app=None), Router)

# Generated at 2022-06-12 09:26:27.987669
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        router = Router(None)
        router.add('/path/<id:int>', ['GET'], "handler", name='test')
        router.finalize('/path/<id:int>', ['GET'], "handler", name='test')
    except SanicException as err:
        assert(err.args == ("Invalid route: /path/<id:int> GET. Parameter names cannot use '__'.",))
    else:
        assert(False)


# Generated at 2022-06-12 09:26:32.448562
# Unit test for method finalize of class Router
def test_Router_finalize():
    
    from sanic.router import Router
    from pathlib import Path
    from sanic import Sanic

    from sanic.exceptions import SanicException

    router = Router(None)
    route = Router.Route('/test/:var', None, ['var'], False) 
    router.dynamic_routes['var'] = route
    with pytest.raises(SanicException):
        router.finalize()


# Unit Test for method add of class Router

# Generated at 2022-06-12 09:26:37.366276
# Unit test for constructor of class Router
def test_Router():
    from sanic import Sanic
    from sanic.router import Router
    from sanic.request import Request
    from sanic.response import HTTPResponse
    
    app = Sanic()

    @app.get(address='/')
    async def handler(request: Request) -> HTTPResponse: 
        return HTTPResponse(text='OK', status=200)

    @app.get(uri='/a', host='a.example.com')
    async def handler(request: Request) -> HTTPResponse:
        return HTTPResponse(text='OK', status=200)

    router = Router()

    routes = router.routes_all
    assert len(routes) == 2

    routes = router.routes_static
    assert len(routes) == 1



# Generated at 2022-06-12 09:26:40.418617
# Unit test for constructor of class Router
def test_Router():
    path = '/uril'
    method= 'GET'
    host = None
    router_object = Router()
    assert isinstance(router_object, Router)
    assert router_object._get(path, method, host) == (route, handler, Dict[str, Any])

# Generated at 2022-06-12 09:26:49.406938
# Unit test for constructor of class Router
def test_Router():
    from sanic_routing.router import Router
    from sanic.constants import HTTP_METHODS

    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS



# Generated at 2022-06-12 09:26:57.429304
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert isinstance(r, Router)
    assert r.__class__ == Router
    assert isinstance(r.routes_all, Dict)
    assert isinstance(r.routes_dynamic, Dict)
    assert isinstance(r.routes_static, Dict[Tuple[str, ...], Route])
    assert isinstance(r.routes_regex, Dict[Tuple[str, ...], Route])
    assert isinstance(r.name_index, Dict[str, Route])


# Generated at 2022-06-12 09:27:06.748687
# Unit test for method finalize of class Router
def test_Router_finalize():
    import unittest
    class Test_Router_finalize(unittest.TestCase):
        def setUp(self):
            self.app = sanic.Sanic()
            self.app.config['router'].__class__ = Router
            self.app.config['router'].finalize()
        def test_Router_finalize_normal(self):
            complete_call_path = ''
            call_path = '/admin/'
            complete_call_path = complete_call_path + call_path
            self.app.get(complete_call_path, 'home')
            complete_call_path = ''
            call_path = '/admin/family/'
            complete_call_path = complete_call_path + call_path
            self.app.get(complete_call_path, 'Family')


# Generated at 2022-06-12 09:27:12.335633
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    # Check that SanicException raises during initialization
    with pytest.raises(SanicException) as excinfo:
        router.dynamic_routes.clear()
        router.dynamic_routes["a"] = Route(
            path='/',
            handler=None,
            methods={"GET"},
            labels={'__file_uri__': 'C:\\Users\\user\\Desktop\\etc'},
            name=None,
            strict=False,
            unquote=False,
            requirements={},
        )
        router.finalize()
    assert str(excinfo.value) == "Invalid route: / . Parameter names cannot use '__'."

# Generated at 2022-06-12 09:27:13.134461
# Unit test for constructor of class Router
def test_Router():
    router = Router()

test_Router()

# Generated at 2022-06-12 09:27:16.169473
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.exceptions import SanicException
    from sanic.router import Router
    import pytest

    router = Router()
    with pytest.raises(SanicException):
        router.finalize()

test_Router_finalize()

# Generated at 2022-06-12 09:27:25.003425
# Unit test for method add of class Router
def test_Router_add():
    def test_handler_sync(self, request, id):
        return "route handler"

    def test_handler_async(self, request, id):
        return "route handler async"

    router = Router()
    route_sync = router.add(uri="/t", methods=["GET"], handler=test_handler_sync, name="test_add_route_sync")
    route_async = router.add(uri="/t", methods=["GET"], handler=test_handler_async, name="test_add_route_async")
    assert route_sync.name == "test_add_route_sync"
    assert route_async.name == "test_add_route_async"
    assert route_sync.uri == "/t"
    assert route_async.uri == "/t"
    assert route_sync.handler

# Generated at 2022-06-12 09:27:27.544761
# Unit test for constructor of class Router
def test_Router():
    try:
        assert issubclass(Router, BaseRouter)
    except AssertionError as e:
        print(f'Failure in test_Router(): {e}')


# Generated at 2022-06-12 09:27:30.323147
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_ = Router()
    def method_handler_func(req, method):
        pass
    handler = method_handler_func
    router_.add('/<method>', ['GET'], handler)
    assert router_.finalize()

# Generated at 2022-06-12 09:27:31.583107
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router


# Generated at 2022-06-12 09:28:02.755678
# Unit test for method finalize of class Router
def test_Router_finalize():
    
    from sanic.router import Router

    r = Router()
    r.add("/", methods=["GET"], handler=None)
    # There is no exception.
    r.finalize()
    
    r = Router()
    r.add("/", methods=["GET"], handler=None, unquote=False)
    # There is no exception.
    r.finalize()
    
    r = Router()
    r.add("/", methods=["GET"], handler=None, unquote=True)
    # There is no exception.
    r.finalize()
    
    r = Router()
    r.add("/<__file_uri__>", methods=["GET"], handler=None)
    # There is no exception.
    r.finalize()
    
    # There is SanicException exception.


# Generated at 2022-06-12 09:28:10.322604
# Unit test for method add of class Router
def test_Router_add():
    from sanic import Sanic
    from sanic.response import text
    from sanic.testing import SanicTestClient

    app = Sanic("test_Router_add")
    client = SanicTestClient(app, port=8000)

    @app.route("/")
    async def hello(request):
        return text("Hello")

    request, response = client.get("/")
    assert response.text == "Hello"

    @app.route("/test/")
    async def hello(request):
        return text("Hello Test")

    request, response = client.get("/test/")
    assert response.text == "Hello Test"

    @app.route("/user/<name>/")
    async def user(request, name):
        return text("Hello Test " + name)


# Generated at 2022-06-12 09:28:18.053186
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.utils import SanicTestClient
    from response import response
    app = Sanic("test_Router_finalize")
    app.config.KEEP_ALIVE = False
    router = Router(app)

    @app.exception(SanicException)
    @app.exception(RoutingNotFound)
    def handler_SanicException(request, exception):
        return response.text("Internal Error", status=500)

    @router.get("/")
    async def handler(request):
        return response.text("OK")

    client = SanicTestClient(app)
    request, response = client.get("/")

    assert response.status == 200
    assert response.text == "OK"

# Generated at 2022-06-12 09:28:22.580582
# Unit test for method finalize of class Router
def test_Router_finalize():
    """Test for method finalize of class Router"""

    from sanic.router import Router
    from sanic.exceptions import SanicException


    class BaseRouter:
        def finalize(self, *args, **kwargs):
            return None

    r = Router(None)
    r.dynamic_routes["1"] = BaseRouter()
    r.dynamic_routes["2"] = BaseRouter()

    assert r.finalize() is None


# Generated at 2022-06-12 09:28:23.357299
# Unit test for method finalize of class Router
def test_Router_finalize():
    assert False, "Not implemented yet"

# Generated at 2022-06-12 09:28:25.732580
# Unit test for constructor of class Router
def test_Router():
    try:
        router = Router()
        print("Router is initialized")
    except Exception as err:
        print(err)


# Generated at 2022-06-12 09:28:27.008913
# Unit test for constructor of class Router
def test_Router():
    test_Router = Router()
    assert isinstance(test_Router, Router)

# Generated at 2022-06-12 09:28:28.004727
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router


# Generated at 2022-06-12 09:28:32.196518
# Unit test for constructor of class Router
def test_Router():
    router = Router(dict())
    assert router.routes_all == dict()
    assert router.routes_static == dict()
    assert router.routes_dynamic == dict()
    assert router.routes_regex == dict()


# Generated at 2022-06-12 09:28:37.517660
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route(path="", handler=None, methods=["GET"], name=None, strict=False, unquote=False)
    route.labels = ["__user_id__"]
    router.dynamic_routes = {"": route}
    try:
        router.finalize()
    except SanicException as e:
        assert "Invalid route: " in str(e)
        assert "__user_id__" in str(e)

# Generated at 2022-06-12 09:29:04.007731
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.app import Sanic
    from sanic.router import Router as RouterTest
    import functools as _functools
    from sanic.request import Request as RequestTest
    @_functools.wraps(RouterTest.add)
    def add(self, uri, methods, handler, host=None, strict_slashes=False,
            stream=False, ignore_body=False, version=None, name=None,
            unquote=False, static=False):
        
        if version is not None:
            version = str(version).strip("/").lstrip("v")
            uri = "/".join([f"/v{version}", uri.lstrip("/")])


# Generated at 2022-06-12 09:29:13.333407
# Unit test for method finalize of class Router
def test_Router_finalize():
    class _Router(Router):
        routes_all = [
            Route(
                path="/path/{param}",
                method="GET",
                handler="handler",
                name="name",
                strict=False,
                unquote=False,
            )
        ]
        routes_static = [
            Route(
                path="/path/{param}",
                method="GET",
                handler="handler",
                name="name",
                strict=False,
                unquote=False,
            )
        ]
        routes_dynamic = {
            "/path/{param}": Route(
                path="/path/{param}",
                method="GET",
                handler="handler",
                name="name",
                strict=False,
                unquote=False,
            )
        }

# Generated at 2022-06-12 09:29:20.691250
# Unit test for constructor of class Router
def test_Router():
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.response import text
    from sanic.request import Request
    from sanic.server import serve
    from sanic.handlers import ErrorHandler
    from sanic import Sanic

    app = Sanic("test_Router", router=Router())
    app.default_response = text("OK")
    app.error_handler = ErrorHandler()

    @app.route("/")
    async def handler(request):
        return text("OK")

    request, response = app.test_client.get("/")
    print(response.text)
    

# Generated at 2022-06-12 09:29:21.371986
# Unit test for method finalize of class Router
def test_Router_finalize():
    pass

# Generated at 2022-06-12 09:29:23.698895
# Unit test for method finalize of class Router
def test_Router_finalize():
    class RouterTest(Router):
        def finalize(self, *args, **kwargs):
            self.finalized = True

    r = RouterTest()
    r.finalize()
    assert r.finalized == True

test_Router_finalize()

# Generated at 2022-06-12 09:29:24.355729
# Unit test for constructor of class Router
def test_Router():
    Router()


# Generated at 2022-06-12 09:29:31.145325
# Unit test for method finalize of class Router
def test_Router_finalize():
    # raise SanicException("Invalid route: " + route.name + ". Parameter names cannot use '__'.")
    routes = Router(None).dynamic_routes
    del routes['/{__file_uri__}']

    try:
        Router(None).finalize()
    except SanicException as e:
        assert e.safe_message == "Invalid route: . Parameter names cannot use '__'."
    else:
        raise Exception("Invalid route Test failed")

    routes = Router(None).dynamic_routes
    routes['/{__file_uri__}'] = None
    try:
        Router(None).finalize()
    except Exception:
        raise Exception("Invalid route Test failed")

# Generated at 2022-06-12 09:29:39.532362
# Unit test for method finalize of class Router
def test_Router_finalize():
    class Router(BaseRouter):
        def finalize(self, *args, **kwargs):
            super().finalize(*args, **kwargs)

            for route in self.dynamic_routes.values():
                if any(
                    label.startswith("__") and label not in ALLOWED_LABELS
                    for label in route.labels
                ):
                    raise SanicException(
                        f"Invalid route: {route}. Parameter names cannot use '__'."
                    )

    router = Router()
    router.add("/", ["GET"], lambda: None, name="__file_uri__")

    try:
        router.add("/", ["GET"], lambda: None, name="__label__")
    except SanicException:
        pass
    else:
        assert False, "Exception should be raised"

# Generated at 2022-06-12 09:29:44.799952
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    Verify that finalize method raises SanicException in case of incorrect parameter name
    """
    try:
        router = Router()
        def test_handler(request, test_param):
            return Response(text=f"{test_param}")
        router.add("/test/<test_param>", methods=["GET"], handler=test_handler)
        router.finalize()
        assert True
    except SanicException:
        assert False

# Generated at 2022-06-12 09:29:52.689371
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r.DEFAULT_METHOD == 'GET'
    assert r.ALLOWED_METHODS == ('ACL', 'BIND', 'CHECKOUT', 'CONNECT', 'COPY', 'DELETE', 'GET', 'HEAD', 'LINK', 'LOCK', 'M-SEARCH', 'MERGE', 'MKACTIVITY', 'MKCALENDAR', 'MKCOL', 'MOVE', 'NOTIFY', 'OPTIONS', 'PATCH', 'POST', 'PROPFIND', 'PROPPATCH', 'PURGE', 'PUT', 'REBIND', 'REPORT', 'SEARCH', 'SOURCE', 'SUBSCRIBE', 'TRACE', 'UNBIND', 'UNLINK', 'UNLOCK', 'UNSUBSCRIBE')


# Generated at 2022-06-12 09:30:29.326970
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert (type(router) == Router)

# Generated at 2022-06-12 09:30:30.435069
# Unit test for constructor of class Router
def test_Router():
    router=Router()
    print("Constructor of class Router")


# Generated at 2022-06-12 09:30:36.134633
# Unit test for method finalize of class Router
def test_Router_finalize():
    def handler_dummy(*args, **kwargs):
        print(args, kwargs)

    router = Router()
    router.finalize()
    assert len(router.routes.values()) == 0

    router.add("/", ["GET"], handler_dummy)
    router.finalize()
    assert len(router.routes.values()) == 1

    router.add("/user/<user_id>", ["GET"], handler_dummy)
    router.finalize()
    assert len(router.routes.values()) == 2

    try:
        router.add("/category/<user_id>", ["GET"], handler_dummy)
        router.finalize()
    except SanicException:
        assert True
        return
    else:
        assert False

# Generated at 2022-06-12 09:30:40.870624
# Unit test for constructor of class Router
def test_Router():
    from sanic.app import Sanic
    from sanic.router import Router

    app = Sanic('test_sanic')
    router = Router(app)
    assert router.app == app
    assert router.ctx == app
    assert router.routes == {}
    assert router.labels == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.host_routes == {}
    assert router.default_host == None


# Generated at 2022-06-12 09:30:44.174979
# Unit test for constructor of class Router
def test_Router():
    result = Router()
    assert isinstance(result, Router)
    assert result.ROUTER_CACHE_SIZE == 1024
    assert result.ALLOWED_LABELS == ("__file_uri__",)


# Generated at 2022-06-12 09:30:48.261733
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    Assert that an error is raised when route parameters have been configured
    in an invalid way.
    """
    router = Router()
    uri = "/users/{user_id}/photos/{photo_id}"
    def handler(): pass
    router.add(uri, ["GET"], handler)
    with pytest.raises(SanicException):
        router.finalize()

# Generated at 2022-06-12 09:30:53.851879
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    test_route = Route(router, '/test/route/{myparam}', ['GET'], lambda x: x)
    test_route.labels.add('__file_uri__')
    test_route.labels.add('__increment_counter__')
    router.dynamic_routes['/test/route/{myparam}'] = test_route
    router.finalize()
    assert test_route.labels == {'__file_uri__'}

# Generated at 2022-06-12 09:30:55.149272
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert(router.ctx.defaults is None)
    

# Generated at 2022-06-12 09:31:03.807427
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.response import json

    class test_router(Router):
        pass

    router = test_router()

    @router.add('/')
    def handler(request):
        return json({'hello': 'world'})

    @router.add('/')
    def handler2(request):
        return json({'hello': 'world'})

    def handler3(request):
        return json({'hello': 'world'})

    router.add('/', handler3)

    # test
    router.finalize()

    for route in router.dynamic_routes.values():
        assert not any(
            label.startswith("__") and label not in ALLOWED_LABELS
            for label in route.labels
        ), "Parameter names cannot use '__'."


# Unit test

# Generated at 2022-06-12 09:31:08.338691
# Unit test for method finalize of class Router
def test_Router_finalize():
    host = None
    router = Router(host)
    version = None
    route = router.add("/index", ["GET"], "handler", version=version)
    assert isinstance(route, Route) is True and "Route" in str(route)

    with pytest.raises(SanicException) as excinfo:
        router.finalize()
    assert "Invalid route" in str(excinfo.value)


# Generated at 2022-06-12 09:32:21.498411
# Unit test for method add of class Router
def test_Router_add():
    def test(uri='uri',
        methods=['methods'],
        handler='handler',
        host='host',
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version='version',
        name='name',
        unquote=False,
        static=False):
        router_instance = Router()
        return router_instance.add(
            uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)
    assert len(test()) == 1


# Generated at 2022-06-12 09:32:28.672465
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    Unit test for method finalize of class Router
    """
    router = Router()
    router.dynamic_routes = {1: "a"}
    try:
        router.finalize()
    except SanicException as sanic_exception:
        assert sanic_exception.status == 500
    else:
        assert False
    router.dynamic_routes = {1: "__a"}
    try:
        router.finalize()
    except SanicException as sanic_exception:
        assert sanic_exception.status == 500
    else:
        assert False
    router.dynamic_routes = {1: "__file_uri__"}
    router.finalize()
    assert True

# Generated at 2022-06-12 09:32:35.191536
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest

    # Test 1: Invalid route
    with pytest.raises(SanicException):
        r = Router()
        
        Route1 = Route(
                uri='/',
                handler=None,
                methods=['GET'],
                name=None,
                strict=False,
                unquote=False,
                labels={'__file_uri__': 'test'},
            )
        r.dynamic_routes[Route1.path] = Route1
        r.finalize()

# Generated at 2022-06-12 09:32:38.048027
# Unit test for constructor of class Router
def test_Router():
    router = Router()

    # Test class attributes
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == {
        'GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS', 'HEAD'
    }

# Generated at 2022-06-12 09:32:41.512975
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    r.add_route('GET', '/', None)
    try:
        r.finalize()
    except SanicException:
        assert False
        return
    assert True



# Generated at 2022-06-12 09:32:49.201960
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.response import json
    from sanic.views import HTTPMethodView

    router = Router()

    class ExampleView(HTTPMethodView):

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def get(self, request, *args, **kwargs):
            return json({"message": "get"})

        def post(self, request, *args, **kwargs):
            return json({"message": "post"})

    view = ExampleView.as_view()
    router.add(uri="uri", methods=["GET", "POST"], handler=view)
    assert router.find_route_by_view_name("ExampleView")[0] == "uri"


# Generated at 2022-06-12 09:32:49.854581
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router


# Generated at 2022-06-12 09:32:55.151719
# Unit test for method finalize of class Router
def test_Router_finalize():
    app = Sanic('test')
    uri = '/test1/<param1:re:[0-9]{4}>/<param2:re:[0-9]{4}>'
    app.add_route(lambda x: x, uri)
    uri = '/test2/<param1>/<param2>'
    app.add_route(lambda x: x, uri)
    app.router.finalize()

    uri = '/test1/<param1>/<param2>'
    app.add_route(lambda x: x, uri)
    with pytest.raises(SanicException):
        app.router.finalize()



# Generated at 2022-06-12 09:32:56.297541
# Unit test for constructor of class Router
def test_Router():
    assert isinstance(Router(), Router)


# Generated at 2022-06-12 09:33:00.674656
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        router = Router()
        router.add("/test/<var1>", ["GET", "POST"], None)
        router.finalize()
    except SanicException:
        assert True
    else:
        assert False

    router = Router()
    router.add("/test/<__var1>", ["GET", "POST"], None)
    try:
        router.finalize()
    except SanicException:
        assert True
    else:
        assert False

# Generated at 2022-06-12 09:34:12.569918
# Unit test for constructor of class Router
def test_Router():
    assert True

# Generated at 2022-06-12 09:34:13.271561
# Unit test for constructor of class Router
def test_Router():
    assert callable(Router)

# Generated at 2022-06-12 09:34:14.361778
# Unit test for constructor of class Router
def test_Router():
    router = Router(None)
    assert isinstance(router, Router)



# Generated at 2022-06-12 09:34:15.247837
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None


# Generated at 2022-06-12 09:34:16.568389
# Unit test for constructor of class Router
def test_Router():
    app_name = "app_name"
    router = Router(app_name)
    assert router.ctx.app == app_name



# Generated at 2022-06-12 09:34:17.466156
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)

# Generated at 2022-06-12 09:34:18.054168
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None

# Generated at 2022-06-12 09:34:18.619482
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router

# Generated at 2022-06-12 09:34:20.784662
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)
    assert not router.finalized
    assert not router.routes
    assert not router.static_routes
    assert not router.dynamic_routes
    assert not router.regex_routes
    assert not router.name_index


# Generated at 2022-06-12 09:34:24.008029
# Unit test for constructor of class Router
def test_Router():
    """
    Constructor of class Router
    """
    try:
        sanic_router = Router()
        assert sanic_router is not None
    except Exception as err:
        assert False, "Unexpected exception raised during construction of class Router: " + str(err)