

# Generated at 2022-06-12 09:25:59.886755
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None

# Generated at 2022-06-12 09:26:01.819077
# Unit test for constructor of class Router
def test_Router():
    router = Router(None)
    assert isinstance(router, Router)


# Generated at 2022-06-12 09:26:08.367899
# Unit test for method finalize of class Router
def test_Router_finalize():
    from .models import Application
    from .request import Request
    from .response import HTTPResponse
    from .test import none_context_test
    from .websocket import WebSocketProtocol
    from .websocket import WebSocketProtocolV13
    from .websocket import WebSocketProtocolV8

    app = Application(None, none_context_test)
    request = Request.fake_request('/', 'GET')
    request_context = RequestContext(None, request, HTTPResponse())
    route = Route(None, None, None, None, None, None, request_context, None)
    route = route.finalize(None, None, None, None, None, None)

    route = Route('/', None, 'GET', '/', None, None, request_context, None)

# Generated at 2022-06-12 09:26:16.485685
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic_routing.route import Route
    from sanic.response import text
    from inspect import isfunction
    from sanic.app import Sanic

    app = Sanic()
    router = Router()
    uri = "/test/<path>"
    handler = text("Test")
    route = Route(uri, methods=["GET"], handler=handler)
    route.ctx.static = True
    route.ctx.labels = ["__file_uri__"]
    router.routes_dynamic[uri] = route
    router.finalize(app)
    assert isfunction(router.dynamic_routes["/test/<path>"].handler)

# Generated at 2022-06-12 09:26:25.895420
# Unit test for method finalize of class Router
def test_Router_finalize():
    import unittest
    import unittest.mock
    from sanic import Sanic
    from sanic.exceptions import SanicException

    def _setup_sanic_app():
        sanic_app = Sanic(__name__)
        return sanic_app

    def _setup_Router():
        return Router()

    def _setup_route_with_invalid_label():
        route = Route(
            uri='/invalid/route/',
            methods={'GET'},
            handler=None,
            name=None,
            strict=False,
            unquote=False
        )
        route.labels = ['__invalid_label__']

        return route


# Generated at 2022-06-12 09:26:33.671031
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic_routing.route import Route

    uri = 'user/<user_id:string>'
    methods = ['GET', 'POST', 'OPTIONS']
    handler = lambda: 0
    host = None
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = None
    unquote = False
    static = False
    route = Router.add(uri, methods, handler)
    router = Router()
    router.static_routes = {uri: route}
    router.finalize()
    print(router.routes)
    print(router.static_routes)
    print(router.dynamic_routes)
    print(router.regex_routes)

# Generated at 2022-06-12 09:26:35.026498
# Unit test for constructor of class Router
def test_Router():
    """
    Unit test for constructor of class Router
    """
    # TODO: implement me
    assert True

# Generated at 2022-06-12 09:26:42.058780
# Unit test for method add of class Router
def test_Router_add():
    """
    Test case for method add of class Router.
    
    """
    import unittest
    
    class TestStringMethods(unittest.TestCase):
        def setUp(self):
            self.r = Router()
        def test_Router_add(self):
            def handle():
                pass
            self.r.add('/', ['GET'], handle)

# Generated at 2022-06-12 09:26:43.896292
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        import warnings
        warnings.warn("Unit test for method finalize of class Router")
    except Exception as e:
        print(e)


# Generated at 2022-06-12 09:26:45.022898
# Unit test for constructor of class Router
def test_Router():
    router = Router()

# Generated at 2022-06-12 09:26:50.620887
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS

# Generated at 2022-06-12 09:26:52.682321
# Unit test for constructor of class Router
def test_Router():
    route = Router()
    path = "/"
    method = "GET"
    host = None
    assert route.get(path,method,host)

# Generated at 2022-06-12 09:26:54.737897
# Unit test for constructor of class Router
def test_Router():
    router = Router()

    assert isinstance(router, Router)

# Generated at 2022-06-12 09:26:55.565605
# Unit test for constructor of class Router
def test_Router():
    assert Router() is not None


# Generated at 2022-06-12 09:27:01.445686
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest

    route = Route(name="test_route")
    route.ctx.labels = ["__file_uri__", "__name__"]
    router = Router()
    router.dynamic_routes = {"test_route": route}
    router.finalize()

    route.ctx.labels = ["__file_uri__", "__name__", "__test__"]
    with pytest.raises(SanicException):
        router.finalize()

# Generated at 2022-06-12 09:27:05.070165
# Unit test for method finalize of class Router
def test_Router_finalize():
    with pytest.raises(SanicException) as exinfo:
        Router().finalize(None)
    try:
        assert "Invalid route" in str(exinfo.value)
    except Exception as exception:
        raise exinfo.value from exception


# Generated at 2022-06-12 09:27:07.123077
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS


# Generated at 2022-06-12 09:27:07.773637
# Unit test for method add of class Router
def test_Router_add():
    pass

# Generated at 2022-06-12 09:27:08.863712
# Unit test for constructor of class Router
def test_Router():
    instance = Router()
    assert isinstance(instance, BaseRouter)



# Generated at 2022-06-12 09:27:10.361697
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    r.dynamic_routes = {'a': 'a', 'b': 'b'}
    r.finalize()

# Generated at 2022-06-12 09:27:18.526421
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None

# Generated at 2022-06-12 09:27:19.879796
# Unit test for constructor of class Router
def test_Router():
    assert Router().router_cache.cache_info().maxsize == 1024

# Generated at 2022-06-12 09:27:24.420849
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add("<uri>", ["GET"], lambda request: "Hello World")
    with pytest.raises(SanicException):
        router.finalize()
    router.add("<uri>", ["GET"], lambda request: "Hello World", __file_uri__=True)
    router.finalize()
    router.add("/", ["GET"], "Hello World")
    router.finalize()

# Generated at 2022-06-12 09:27:32.410174
# Unit test for constructor of class Router
def test_Router():
    router = Router(
        "/",
        host="localhost",
        methods=None,
        strict_slashes=False,
    )
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS is HTTP_METHODS
    assert router.ctx.app == None
    assert type(router.ctx.app) is None
    assert router._prefix == '/'
    assert router._host == 'localhost'
    assert router._methods == None
    assert router._strict_slashes == False
    assert router._allow_all == True
    assert type(router.routes) is list
    assert router.routes == []
    assert type(router.dynamic_routes) is dict
    assert router.dynamic_routes == {}

# Generated at 2022-06-12 09:27:34.501108
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    r.add(uri = '', methods = ['GET'], handler = None)
    assert not r._finalized
    r.finalize()


# Generated at 2022-06-12 09:27:38.576629
# Unit test for constructor of class Router
def test_Router():
  r = Router()
  assert r.routes_dynamic == {}
  assert r.routes_regex == {}
  assert r.routes_static == {}
  assert r.routes_all == {}
  assert r.DEFAULT_METHOD == 'GET'
  assert r.ALLOWED_METHODS == HTTP_METHODS


# Generated at 2022-06-12 09:27:39.108914
# Unit test for constructor of class Router
def test_Router():
    Router()

# Generated at 2022-06-12 09:27:47.348545
# Unit test for constructor of class Router
def test_Router():
    from sanic.request import Request

    @lru_cache(maxsize=ROUTER_CACHE_SIZE)
    def get(self, path: str, method: str, host: Optional[str]) -> Tuple[Route, RouteHandler, Dict[str, Any]]:
        try:
            return self.resolve(
                path=path,
                method=method,
                extra={"host": host},
            )
        except RoutingNotFound as e:
            raise NotFound("Requested URL {} not found".format(e.path))
        except NoMethod as e:
            raise MethodNotSupported(
                "Method {} not allowed for URL {}".format(method, path),
                method=method,
                allowed_methods=e.allowed_methods,
            )

    def handler(request: Request):
        return

# Generated at 2022-06-12 09:27:56.440679
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    Test case for method finalize of class Router.
    """
    # TODO: test more cases
    from sanic.app import Sanic
    from sanic.constants import HTTP_METHODS
    # [TODO: Setup test case]
    ctx = Sanic(__name__)
    router = Router(ctx)
    # [TODO: Write test case]
    uri = "uri"
    method = HTTP_METHODS
    handler = "handler"
    host = "host"
    strict_slashes = False
    stream = False
    ignore_body = False
    version = 1
    name = "name"
    unquote = False
    static = False

# Generated at 2022-06-12 09:28:04.043229
# Unit test for method finalize of class Router
def test_Router_finalize():

    router = Router()
    router.dynamic_routes = {
        1: Route(path='/1', handler=1, methods=['GET'],
                 name='named_route', strict=False,
                 unquote=False, labels=['__other_label__'])
    }
    # invalid route
    from pytest import raises
    with raises(SanicException):
        router.finalize()

    router.dynamic_routes = {
        1: Route(path='/1', handler=1, methods=['GET'],
                 name='named_route', strict=False,
                 unquote=False, labels=['__file_uri__'])
    }
    # valid route
    assert router.finalize()

# Generated at 2022-06-12 09:28:19.675553
# Unit test for method add of class Router
def test_Router_add():
    r1 = Router()
    r1.add('/test/view', ['GET', 'POST'], _test_handler, 1)
    r1.add('/test/view/{param}', ['GET', 'POST'], _test_handler, 1)

    assert '/test/view/{param}' in r1.dynamic_routes
    assert '/test/view' in r1.static_routes

    assert '/test/view' in r1.routes_all
    assert '/test/view/{param}' in r1.routes_all

    assert '/test/view' in r1.routes_static
    assert '/test/view/{param}' not in r1.routes_static

    assert '/test/view' not in r1.routes_dynamic
   

# Generated at 2022-06-12 09:28:22.428909
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        from sanic.router import Router

        r = Router(context={})
        r.add("/")
        r.finalize()
        assert False, "should have raised an exception"
    except SanicException as e:
        assert "Invalid route:" in str(e)


# Generated at 2022-06-12 09:28:30.975390
# Unit test for constructor of class Router
def test_Router():
    '''
    Test Router(BaseRouter)
    '''
    from sanic.asgi import HttpProtocol

    routes = Router(HttpProtocol, None)
    assert routes
    assert routes.ALLOWED_METHODS == HTTP_METHODS
    assert routes.DEFAULT_METHOD == "GET"

    assert routes.routes_all == {}
    assert routes.routes_static == {}
    assert routes.routes_dynamic == {}
    assert routes.routes_regex == {}

    assert routes.ctx == HttpProtocol
    assert routes.name_index == {}
    assert routes.urls_map == {}


# Generated at 2022-06-12 09:28:34.686042
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.ctx is None


# Generated at 2022-06-12 09:28:43.232610
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.app import Sanic
    from sanic.utils import IS_PYTHON_35
    from sanic_routing.router import Router

    app = Sanic('test_Router_finalize')
    router = Router()

    @app.route('/path/')
    def hello(request):
        return text('Hello world!')

    router.add(uri='/path/', methods=['GET'], handler=hello, unquote=False)

    if IS_PYTHON_35:
        try:
            router.finalize()
        except RuntimeError as e:
            assert str(e) == 'Event loop is closed'
        else:
            raise AssertionError('An exception should be thrown')
    else:
        router.finalize()


# Generated at 2022-06-12 09:28:48.214595
# Unit test for constructor of class Router
def test_Router():
    @lru_cache(maxsize=100)
    def lru_cache_wrapper(*args, **kwargs):
        return Router(*args, **kwargs)

    # test no arguments
    assert isinstance(lru_cache_wrapper(), Router)

    # test wrong positional argument
    try:
        lru_cache_wrapper(1)
    except Exception as e:
        assert isinstance(e, TypeError)

    # test wrong keyword argument
    try:
        lru_cache_wrapper(kwargs=1)
    except Exception as e:
        assert isinstance(e, TypeError)



# Generated at 2022-06-12 09:28:51.809425
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.app import Sanic
    app = Sanic()
    router = Router(app)
    router.add(uri='/test', methods=['GET'], handler=None)


test_Router_finalize()

# Generated at 2022-06-12 09:28:55.233150
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert (router.routes_all == {})
    assert (router.routes_dynamic == {})
    assert (router.routes_regex == {})
    assert (router.routes_static == {})

# Generated at 2022-06-12 09:29:00.438201
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        for route in routes_dynamic.values():
            if any(
                label.startswith("__") and label not in ALLOWED_LABELS
                for label in route.labels
            ):
                raise SanicException(
                    f"Invalid route: {route}. Parameter names cannot use '__'."
                )
    except Exception as e:
        print(e)



# Generated at 2022-06-12 09:29:06.308871
# Unit test for method finalize of class Router

# Generated at 2022-06-12 09:29:27.267409
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route_handler = lambda x: x

    router.add('/uri_1', ['GET'], route_handler=route_handler)
    router.add('/uri_2', ['GET'], route_handler=route_handler, name='custom_name_2')
    router.add('/uri_3', ['GET'], route_handler=route_handler, name='custom_name_3')
    with pytest.raises(SanicException):
        router.add('/uri_4', ['GET'], route_handler=route_handler, name='__custom_name_4')

    router.finalize()
    assert router.find_route_by_view_name('custom_name_2') is not None

# Generated at 2022-06-12 09:29:35.671160
# Unit test for constructor of class Router
def test_Router():
    path = '/api/v1/names'
    # methods = ['GET', 'POST', 'OPTIONS']
    methods = ['GET']
    handler = router.get
    host = 'localhost'
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = None
    unquote = False
    static = False

    # test 'add' function
    router.add(uri=path, methods=methods, handler=handler, host=host, strict_slashes=strict_slashes, stream=stream, ignore_body=ignore_body, version=version, name=name, unquote=unquote, static=static)

    # test 'get' function

# Generated at 2022-06-12 09:29:38.970244
# Unit test for method finalize of class Router
def test_Router_finalize():
    with pytest.raises(SanicException):
        router = Router(None, None)
        route = Route()
        route.labels = ["__file_uri__"]
        router.dynamic_routes[route.path] = route
        router.finalize()

# Generated at 2022-06-12 09:29:43.120586
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router
    assert router.routes == []
    assert router.routes_all == []
    assert router.routes_regex == {}
    assert router.routes_dynamic == {}
    assert router.routes_static == {}
    assert router.name_index == {}

# Generated at 2022-06-12 09:29:46.337360
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        router = Router()
        router.add("/abc", ["GET"], lambda *_, **__: None, name="abc")
        router.finalize()
    except Exception as e:
        pytest.fail(f"Unexpected exception: {e}")

# Generated at 2022-06-12 09:29:46.853705
# Unit test for constructor of class Router
def test_Router():
    r = Router()

# Generated at 2022-06-12 09:29:49.897443
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    r.add(uri="/test", methods=["GET"], handler=None)
    r.finalize()
    assert r.dynamic_routes.values()

# Generated at 2022-06-12 09:29:50.389983
# Unit test for constructor of class Router
def test_Router():
    pass

# Generated at 2022-06-12 09:29:51.476152
# Unit test for method add of class Router
def test_Router_add():
    pass


# Generated at 2022-06-12 09:29:52.257956
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert True

# Generated at 2022-06-12 09:30:25.954521
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert isinstance(r.routes_all, OrderedDict)
    assert isinstance(r.routes_regex, OrderedDict)
    assert isinstance(r.routes_static, OrderedDict)
    assert isinstance(r.routes_dynamic, dict)
    assert isinstance(r.host_map, dict)
    assert isinstance(r.name_index, dict)



# Generated at 2022-06-12 09:30:30.713009
# Unit test for constructor of class Router
def test_Router():
    router = Router(None)

    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}



# Generated at 2022-06-12 09:30:31.234330
# Unit test for constructor of class Router
def test_Router():
    pass

# Generated at 2022-06-12 09:30:38.586680
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r.DEFAULT_METHOD == "GET"                # test route.DEFAULT_METHOD
    assert r.ALLOWED_METHODS == HTTP_METHODS        # test route.ALLOWED_METHODS
    # test route._get
    assert r._get("path", "method", None) == ()
    # test route.get
    assert r.get("/", "method", None) == ()
    assert r.get("/", "method", None) == ()
    # test route.add
    assert r.add("uri",["methods"],str) == ()
    # test route.find_route_by_view_name.
    try:
        assert r.find_route_by_view_name()
    except SanicException:
        assert True
    # test route.finalize

# Generated at 2022-06-12 09:30:40.182802
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    expected_router = Router()
    assert(router == expected_router)

# Unit tests for method add

# Generated at 2022-06-12 09:30:42.288989
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert type(router) == Router


# Generated at 2022-06-12 09:30:43.550904
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r is not None


# Generated at 2022-06-12 09:30:47.359639
# Unit test for constructor of class Router
def test_Router():
    # Test if the constructor of class Router can run successfully
    url_prefix = ""
    router_name = "router_name"
    app = "app"
    router = Router(url_prefix, router_name, app)
    assert router.name == router_name
    assert router.ctx.app == app


# Generated at 2022-06-12 09:30:50.746863
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router(None)
    with pytest.raises(SanicException):
        import re
        router.regex_routes = {re.compile(r"^/files/(.*?\\..+?)$"): "route"}
        router.finalize()



# Generated at 2022-06-12 09:30:53.780912
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r.ALLOWED_METHODS == HTTP_METHODS
    assert r.DEFAULT_METHOD == 'GET'
    assert ROUTER_CACHE_SIZE == 1024
    assert ALLOWED_LABELS == ("__file_uri__",)

# Generated at 2022-06-12 09:31:52.116262
# Unit test for constructor of class Router
def test_Router():
    # case: constructor
    router = Router()
    # test: no error raised
    assert router is not None


# Generated at 2022-06-12 09:31:58.492292
# Unit test for method add of class Router
def test_Router_add():
    from sanic import Sanic, response
    app = Sanic("test")
    router = Router()

    # Add a route
    router.add("/",["GET"],handler=app.async_to_sync(lambda request: response.text("OK")))
    router.add("/1", ["GET"],app.async_to_sync(lambda request: response.text("OK")) )
   
    assert "/" in router.routes
    assert "/1" in router.routes

    # Test arguments version and name
    router.add("/2", ["GET"], app.async_to_sync(lambda request: response.text("OK")), version=1)
    router.add("/2", ["GET"], app.async_to_sync(lambda request: response.text("OK")), name="test")


# Generated at 2022-06-12 09:32:03.808559
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.app import Sanic

    app = Sanic(__name__)

    @app.route("/test/__id__")
    async def test(request, id):
        pass

    try:
        Router(app)
    except SanicException:
        assert True
    else:
        assert False

    @app.route("/test/:id")
    async def test(request, id):
        pass

    try:
        Router(app)
    except SanicException:
        assert False
    else:
        assert True

# Generated at 2022-06-12 09:32:08.017687
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.routes = [
        {"path": "/test", "labels": ["root", "test"]},
        {"path": "/test", "labels": ["root", "__test__"]},
    ]
    assert router.finalize() == None
    assert router.finalize() == None

# Generated at 2022-06-12 09:32:08.503031
# Unit test for constructor of class Router
def test_Router():
    r = Router()

# Generated at 2022-06-12 09:32:17.029351
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.router_cache == {}
    assert router.args_cache == {}
    assert router.kwargs_cache == {}
    assert router.name_index == {}
    assert router.host_index == {}
    assert router.static_routes == []
    assert router.dynamic_routes == {}
    assert router.regex_routes == []
    assert router.ctx == None
    assert router.routes == []


# Unit test of method get of class Router
@pytest.mark.asyncio
async def test_Router_get():
    router = Router()

    path = ""
    method = "GET"
    host = None
    result = router.get(path, method, host)
    assert result == (None, None, {})


# Unit test

# Generated at 2022-06-12 09:32:24.801172
# Unit test for constructor of class Router
def test_Router():
    from sanic.app import Sanic
    from sanic.server import serve
    from sanic.request import Request
    from sanic.response import HTTPResponse

    app = Sanic(__name__)
    a = Router()
    a.SERVER_SOFTWARE = "server_software"
    a.HOST_NAME = "host_name"
    request = Request.factory(
        host="host",
        path="/test_path",
        method="GET",
        headers={},
        app=app,
        protocol=("HTTP", "1.1"),
        transport=None,
        ip="ip",
        port="80",
    )
    a.request = request

    def handler(request):
        return request.path

    @app.route("/")
    def handler(request):
        return request

# Generated at 2022-06-12 09:32:26.330308
# Unit test for constructor of class Router
def test_Router():
    """
    Unit test for constructor of class Router
    """
    assert Router()



# Generated at 2022-06-12 09:32:29.867043
# Unit test for constructor of class Router
def test_Router():
    uri = "/test/uri"
    methods = ["GET"]
    handler = lambda req: "hi"
    router = Router()
    router.add(uri, methods, handler)
    assert uri in router.routes_dynamic


# Generated at 2022-06-12 09:32:34.510699
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Route
    import pytest
    router = Router()
    route = Route("/hello/<name>", "GET", None)
    route.add_labels(name="__name__")
    router.add_route(route)
    with pytest.raises(SanicException):
        router.finalize()

# Generated at 2022-06-12 09:35:09.222015
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    handlers = [lambda x: None]
    router.add(uri='/test/', methods=['GET'], handler=handlers[0])
    router.add(uri='/test/<test2>', methods=['GET'], handler=handlers[0])
    router.add(uri='/test/', methods=['GET'], handler=handlers[0], host='http://localhost')
    assert router.dynamic_routes == {'/test/<test2>': [Route('/test/<test2>', 'GET', handlers[0], requirements={})]}
    assert router.static_routes == {'/test/': [Route('/test/', 'GET', handlers[0], requirements={})]}

# Generated at 2022-06-12 09:35:10.868704
# Unit test for constructor of class Router
def test_Router():
    result = Router()
    assert result is not None


# Generated at 2022-06-12 09:35:12.001451
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert isinstance(r, Router)

# Generated at 2022-06-12 09:35:19.307342
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    from sanic.response import text
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import SanicException
    from sanic.exceptions import ServerError
    from sanic.exceptions import NotFound

    app = Sanic()

    uri_list = ["/", "/post", "/test", "/user", "/user/<name:string>"]

    def my_handler(request):
        return text("OK")

    def my_error_handler(request, exception):
        return text(str(exception), 500)

    router = Router()

    router.add(uri_list, ["GET", "POST"], my_handler, stream=True)
    router.add(uri_list, "GET", my_handler, stream=False)

# Generated at 2022-06-12 09:35:26.663012
# Unit test for constructor of class Router
def test_Router():
    from sanic import Sanic
    from sanic.router import Router
    from sanic import response
    app = Sanic('test_Router')
    @app.route('/')
    def handler(request):
        return response.text('OK')

    router = Router(app)
    assert(router.routes_all)
    assert(isinstance(router.routes_all, dict))
    assert(router.routes_static)
    assert(isinstance(router.routes_static, dict))
    assert(router.routes_dynamic)
    assert(isinstance(router.routes_dynamic, dict))
    assert(router.routes_regex)
    assert(isinstance(router.routes_regex, dict))



# Generated at 2022-06-12 09:35:28.953141
# Unit test for method finalize of class Router
def test_Router_finalize():
    def handler(request):
        pass

    router = Router()
    router.add("/{foo}", ["GET"], handler)

    with pytest.raises(SanicException):
        router.finalize()

# Generated at 2022-06-12 09:35:33.369830
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    r.add('/', ['GET'], None, None, False, False, False, None, None, False)
    with pytest.raises(SanicException):
        # Here, add method raise SanicException
        r.add('/__', ['GET'], None, None, False, False, False, None, None, False)
        r.finalize()

# Generated at 2022-06-12 09:35:39.860177
# Unit test for constructor of class Router
def test_Router():
    from sanic_routing import Route, RouteTableDef
    from sanic.response import HTTPResponse, stream, text
    mw = {}
    middleware = {}
    class _test(RouteTableDef):
        @Route.get('/test/', mw, middleware)
        def t(req):
            return HTTPResponse(text='hello world')
    _router = Router(lambda x: x)
    _router.add(_test)
    r, h, p = _router.get('/test/', 'GET')
    assert(h.__name__ == 't')

# Generated at 2022-06-12 09:35:42.267921
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r.ctx.app is None
    assert r.ctx.current_route is None


# Generated at 2022-06-12 09:35:43.608464
# Unit test for constructor of class Router
def test_Router():
    router = Router("rout", "routing")
    assert router.ctx.app.name == "rout"
    assert router.ctx.app.name == "routing"