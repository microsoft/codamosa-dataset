

# Generated at 2022-06-21 23:40:31.601808
# Unit test for method add of class Router
def test_Router_add():
    uri = 'uri'
    methods = ['methods']
    handler = 'handler'
    host = 'host'
    strict_slashes = 'strict_slashes'
    stream = 'stream'
    ignore_body = 'ignore_body'
    version = 'version'
    name = 'name'
    unquote = 'unquote'
    static = 'static'

    myRouter = Router(None)
    route = myRouter.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static,)

    assert route.ctx.ignore_body == ignore_body
    assert route.ctx.stream == stream
    assert route.ctx.hosts == [host]
    assert route.ctx.static == static

# Generated at 2022-06-21 23:40:36.570365
# Unit test for constructor of class Router
def test_Router():
    myRouter = Router()
    assert (myRouter.routes_all == {})
    assert (myRouter.routes_static == {})
    assert (myRouter.routes_dynamic == {})
    assert (myRouter.routes_regex == {})
    assert (myRouter.DEFAULT_METHOD == "GET")
    assert (myRouter.ALLOWED_METHODS == HTTP_METHODS)


# Generated at 2022-06-21 23:40:45.765573
# Unit test for method add of class Router
def test_Router_add():
    # Complexity - 0
    # 1, 2
    uri = 'abc'
    methods = ['GET']
    handler = 'handler'
    host = 'localhost'
    strict_slashes = False
    stream = False
    ignore_body = False
    version = 1.0
    name = 'name'
    unquote = False
    static = False
    r = Router()
    r.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)
    assert 1 == 1


# Generated at 2022-06-21 23:40:48.104003
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None

# Generated at 2022-06-21 23:40:49.181649
# Unit test for constructor of class Router
def test_Router():
    pass



# Generated at 2022-06-21 23:40:51.720392
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)

# Generated at 2022-06-21 23:40:53.720577
# Unit test for method finalize of class Router
def test_Router_finalize():
    assert True

# Generated at 2022-06-21 23:40:56.592675
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router) == True


# Generated at 2022-06-21 23:41:08.426363
# Unit test for method add of class Router
def test_Router_add():
    from sanic.router import Router
    router = Router()

    assert router.ctx.app is None
    # assert router.ctx.request is None
    assert router.ctx.sanic_endpoint is None
    assert router.ctx.handler is None
    assert router.ctx.route is None

    # assert len(router.routes_all) == 0
    # assert len(router.routes_static) == 0
    # assert len(router.routes_dynamic) == 0
    # assert len(router.routes_regex) == 0

    assert router.get_host == ""
    assert router.get_prefix == ""

    assert router.get_default_method() == "GET"

# Generated at 2022-06-21 23:41:12.448423
# Unit test for constructor of class Router
def test_Router():
    try:
        router = Router()
        assert router is not None
    except Exception as e:
        assert False, "Router constructor test failed. Error: {}".format(e)


# Generated at 2022-06-21 23:41:30.330390
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Arrange
    _router = Router()

    _uri = "/article/<id:int>"
    _methods = ["GET", "POST", "OPTIONS"]
    _handler = RouteHandler
    _host: Optional[Union[str, Iterable[str]]] = "www.example.com"
    _strict_slashes: bool = False
    _stream: bool = False
    _ignore_body: bool = False
    _version: Union[str, float, int] = "1.0"
    _name: Optional[str] = "product"
    _unquote: bool = False
    _static: bool = False
    # Act

# Generated at 2022-06-21 23:41:32.434773
# Unit test for constructor of class Router
def test_Router():
    route = Router()
    assert (route)



# Generated at 2022-06-21 23:41:42.107255
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add('/users/{user_id}', methods=['GET'], handler='user_id_handler', host=None, strict_slashes=False, stream=False, ignore_body=False, version=None, name=None, unquote=False, static=False)
    assert router.routes_regex[0].path == '/users/{user_id}'
    assert router.routes_regex[0].methods == ['GET']
    assert router.routes_regex[0].handler == 'user_id_handler'
    assert router.routes_regex[0].name == None
    assert router.routes_regex[0].strict == False
    assert router.routes_regex[0].unquote == False
    assert router.r

# Generated at 2022-06-21 23:41:49.358581
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    Test Router method: finalize
    """
    try:
        test_router = Router()
        test_router.add(
            uri = "/",
            methods = ["GET"],
            handler = None,
            host = None,
            strict_slashes = False,
            stream = False,
            ignore_body = False,
            version = None,
            name = None,
            unquote = False,
            static = False
        )
        test_router.finalize()
        assert True
    except SanicException:
        assert False

# Generated at 2022-06-21 23:42:00.854139
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    from sanic.router import Router
    from sanic.constants import HTTP_METHODS

    def test_handler(request):
        return ''

    app = Sanic(__name__)


# Generated at 2022-06-21 23:42:08.860949
# Unit test for method add of class Router
def test_Router_add():
    # Test the default case
    router = Router()
    uri = "about"
    methods = ["GET"]
    handler = None
    strict_slashes = False
    stream = False
    ignore_body = False
    name = "about"
    routes = router.add(uri, methods, handler, strict_slashes, stream, ignore_body, name)
    assert isinstance(routes, list)
    for route in routes:
        assert isinstance(route, Route)
        assert route.path == uri
        assert route.methods == methods
        assert route.handler and route.handler.app == None
        assert route.name == name

# Generated at 2022-06-21 23:42:15.619771
# Unit test for method add of class Router
def test_Router_add():
    test = Router()
    def handle(request, s):
        return s
    test.add('/book/<book>', ['GET'], handle)
    route = test.find_route_by_view_name('handle')
    assert route.path == '/book/<book>'



# Generated at 2022-06-21 23:42:18.214325
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r.DEFAULT_METHOD == "GET"
    assert r.ALLOWED_METHODS == HTTP_METHODS



# Generated at 2022-06-21 23:42:22.425882
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_Router = Router()
    with pytest.raises(SanicException):
        test_Router.finalize()

# Generated at 2022-06-21 23:42:26.537097
# Unit test for constructor of class Router
def test_Router():
    from sanic import Sanic
    from sanic.app import Sanic
    app = Sanic(name = 'test_Router')
    router = Router(app)
    assert router.app == app

# Generated at 2022-06-21 23:42:40.308519
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.app import Sanic

    app = Sanic('test_Router_finalize')
    app.blueprint(app)

    app.get('/', 'hello')
    app.get('/<__name__>', 'hello_name')(
        lambda request, __name__: 'hello %s' % __name__
    )

    router = Router(app)

    assert router.finalize is not None



# Generated at 2022-06-21 23:42:51.367372
# Unit test for method add of class Router
def test_Router_add():
    router = Router(ctx=None)

    def f():
        pass

    assert len(router.add(uri="/", methods=["GET"], handler=f).ctx.hosts) == 1
    assert router.add(uri="/", methods=["GET"], handler=f, host=None).ctx.hosts == []
    assert router.add(uri="/", methods=["GET"], handler=f, host="").ctx.hosts == ['']
    assert len(router.add(uri="/", methods=["GET"], handler=f, host="host").ctx.hosts) == 2
    assert len(router.add(uri="/", methods=["GET"], handler=f, host=["host"]).ctx.hosts) == 2

# Generated at 2022-06-21 23:42:57.801780
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.dynamic_routes = {
        "uri1": Route("uri1", "handler", (None,), {}, {"host": ""})
    }
    with pytest.raises(SanicException):
        router.finalize()

# Generated at 2022-06-21 23:43:11.667399
# Unit test for constructor of class Router
def test_Router():
  uri = "/api/v2/users/<user_id>"
  methods = "GET"
  handler = lambda request: "Welcome to the Internet of Turtles"
  version = 2
  stream = True
  name = "user"

  r = Router()
  r.add(uri, methods, handler, version=version, stream=stream, name=name)
  assert r.routes_all == {
    ('GET', '/api/v2/users/{user_id}'): [('GET', '/api/v2/users/{user_id}')],
    ('GET', '/api/v2/users/{user_id}/'): [('GET', '/api/v2/users/{user_id}/')]
  }

# Generated at 2022-06-21 23:43:15.044134
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add(uri='/hello',methods=['GET'],handler='handler')

    assert router.routes

# Generated at 2022-06-21 23:43:23.061353
# Unit test for method add of class Router
def test_Router_add():
    '''
    1) create an object of Router
    2) add a handler to the router
    3) check the return value(route object)
    '''
    uri = "/home/path"
    methods = ["POST"]
    def handler(request):
        return "hello world"
    host = "localhost"
    strict_slashes = False
    stream = False
    ignore_body = True
    version = 1
    name = "name"
    unquote = True
    static = True
    router = Router()
    route = router.add(uri, methods, handler, host, 
    strict_slashes, stream, ignore_body, version, name, unquote, static)

# Generated at 2022-06-21 23:43:34.659362
# Unit test for method add of class Router
def test_Router_add():
    from sanic.router import Router
    from sanic.request import Request
    from sanic.response import HTTPResponse

    router = Router()
    @router.add("/test")
    def test_no_method_or_handler(*_args, **_kwargs):
        return HTTPResponse()

    @router.add("/test2", methods=["GET"])
    def test_handler_only(*_args, **_kwargs):
        return HTTPResponse()

    @router.add("/test3", "GET")
    def test_method_only(*_args, **_kwargs):
        return HTTPResponse()


# Generated at 2022-06-21 23:43:37.924798
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    router = Router()
    with pytest.raises(SanicException):
        router.finalize(None)


# Generated at 2022-06-21 23:43:44.289382
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router(None, {})
    try:
        route = router.route_class(
            "GET",
            "/",
            lambda r: "OK",
            name="__some_name",
        )
        router.dynamic_routes["/"] = route
        router.finalize()
    except SanicException as e:
        assert "Invalid route" in str(e)
    else:
        raise AssertionError("Should raise SanicException")



# Generated at 2022-06-21 23:43:49.646979
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    with pytest.raises(SanicException):
        router.finalize(({'route': '/test/:value', 'endpoint': 'endpoint', 'handler': 'handler', 'parameters': []},))

# Generated at 2022-06-21 23:44:07.293745
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    compiled_route_uri = re.compile('^/v1/test/$')
    def test_func(request):
        return True
    # by default it has only one dynamic route
    assert isinstance(router.finalize(None), Router)
    assert len(router.routes_dynamic) == 1
    route = router.add('/test', ['GET'], test_func)
    assert isinstance(route, Route)
    # route wraps in dynamic routes
    assert isinstance(router.finalize(None), Router)
    assert len(router.routes_dynamic) == 2
    # test adding a versioned route
    route = router.add('/test', ['GET'], test_func, version=1)
    assert isinstance(route, Route)
    # route

# Generated at 2022-06-21 23:44:17.057560
# Unit test for method finalize of class Router
def test_Router_finalize():
    routes_dynamic = {
        '/<param1>/<param2>': {"param1": "foo", "param2": "bar"},
        '/<param3>/<param4>': {"param3": "baz", "param4": "quux"}
    }
    router = Router(None)
    router.dynamic_routes = routes_dynamic
    try:
        router.finalize()
    except SanicException as exc:
        assert exc.message == "Invalid route: /<param3>/<param4>. Parameter names cannot use '__'."


# Generated at 2022-06-21 23:44:26.326111
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    router = Router(ctx=None)

    # test method
    def f():
        pass

    router.add("test1/<test1>", f)
    router.add("test2/<test2>", f)
    router.add("test3/<test3>", f)

    router.finalize()

    result = router.get("test1/aa", "GET", "")
    assert result[0].uri_template == "/test1/<test1>"
    assert result[0].uri_params == ["test1"]

# Generated at 2022-06-21 23:44:32.584718
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    r.add(uri="test", methods=["GET"], handler=lambda : None, name="test")
    r.add(uri="test", methods=["GET"], handler=lambda : None, name="test")
    #These two lines above should not raise any exception
    r.add(uri="test", methods=["GET"], handler=lambda : None, name="__test")
    with pytest.raises(SanicException):
        r.finalize()

# Generated at 2022-06-21 23:44:45.844446
# Unit test for method finalize of class Router
def test_Router_finalize():
    route = Route(
        path='/test/<a>/<b>',
        handler=None,
        methods=None,
        name=None,
        strict=False,
        unquote=False,
    )
    router = Router(
        routes=None,
        name_index=None,
        dynamic_routes={},
        regex_routes={},
        static_routes={},
    )
    router.dynamic_routes[route] = None
    try:
        router.finalize(None)
    except SanicException as e:
        print(e)
    else:
        assert False


if __name__ == "__main__":
    test_Router_finalize()

# Generated at 2022-06-21 23:44:49.790384
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        from .sanic_routing import Router
        from .router_tests import test_Router_finalize
        return test_Router_finalize()
    except:
        pass

# Generated at 2022-06-21 23:44:56.022864
# Unit test for method add of class Router
def test_Router_add():
    from sanic import Sanic
    from sanic.router import Router
    app = Sanic('test_Router_add')
    @app.route('/')
    async def test(request):
        return response.ststus('200')
    router = Router()
    assert router.add(uri='/', methods=["GET", "POST", "OPTIONS"], handler=test)

    # Test wrong types in methods
    try:
        router.add(uri='/', methods="GET", handler=test)
    except TypeError as e:
        assert(e)
    else:
        assert(False)

    # Test wrong types in handler

# Generated at 2022-06-21 23:45:04.186973
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route("", lambda request: "", "GET")
    route.labels = ["__file_uri__"]
    router.dynamic_routes = {1: route}
    try:
        router.finalize()
    except SanicException:
        assert False, "Router finalize failed"
    route.labels = ["__file_uri__", "__invalid__"]
    with pytest.raises(SanicException):
        router.finalize()

# Generated at 2022-06-21 23:45:10.252334
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.router_cache_size == 1024
    assert router.allowed_labels == ("__file_uri__",)
    assert router.default_method == "GET"
    assert router.allowed_methods == [
        'OPTIONS', 'HEAD', 'GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'TRACE'
    ]

# Generated at 2022-06-21 23:45:12.618718
# Unit test for constructor of class Router
def test_Router():
    assert(isinstance(Router(), Router))

# Generated at 2022-06-21 23:45:38.018137
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router as SanicRouter
    from sanic.exceptions import ServerError

    router = SanicRouter()
    router.add('/test/:forbidden_param', 'POST', None)

    try:
        router.finalize()
    except ServerError:
        pass
    else:
        assert False

    router = SanicRouter()
    router.add('/test/:param', 'POST', None)

    try:
        router.finalize()
    except ServerError:
        assert False

# Generated at 2022-06-21 23:45:48.709813
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic_routing.router import Router
    from sanic_routing.route import Route
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.websocket import WebSocketProtocol

    class FakeRequest(Request):
        def __init__(self, uri, *args, **kwargs):
            super().__init__(*args, uri=uri, **kwargs)

    class FakeUri:
        def __init__(self, uri):
            self.uri = uri

    class FakeRoute:
        def __init__(self, path):
            self.path = path

    def handler(request):
        return HTTPResponse(body="OK")

    def test_regex(request):
        return HT

# Generated at 2022-06-21 23:45:55.716378
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route_details = {
        "path": "/",
        "handler": None,
        "methods": (
            "GET",
            "POST",
            "OPTIONS",
        ),
    }
    route = Route(**route_details)
    route.labels = ["__file_uri__", "__test_label__"]
    router.dynamic_routes = {"/": route}

    try:
        router.finalize()
    except SanicException as e:
        print(e)

    route_details_2 = {
        "path": "",
        "handler": None,
        "methods": (
            "GET",
            "POST",
            "OPTIONS",
        ),
    }
    route_2 = Route(**route_details_2)


# Generated at 2022-06-21 23:46:00.210018
# Unit test for method finalize of class Router
def test_Router_finalize():
    expected_result = SanicException('Invalid route: {0}'.format(route))

    router = Router()
    router.dynamic_routes = {'route': '{0}'}
    with pytest.raises(expected_result):
        router.finalize()

# Generated at 2022-06-21 23:46:13.004420
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.constants import HTTP_METHODS
    from sanic_routing import Route
    import sys
    import pytest
    from pytest import raises
    from unittest import mock

    def mock_super_finalize(*args, **kwargs):
        return None


# Generated at 2022-06-21 23:46:24.335441
# Unit test for method finalize of class Router
def test_Router_finalize():
    import os
    import re
    from sanic import Sanic

    app = Sanic("test")
    router = Router()
    router.ctx = app

    # case: no route
    router.dynamic_routes = {
        "tests.test_routing.test_route": Route(path='/', handler=test_route)
    }
    assert router.finalize() == None

    # case: invalid route
    def bad_route(request):
        return "OK"

    @app.get("/get")
    def get_route(request):
        return "OK"

    router.dynamic_routes = {
        "tests.test_routing.__bad_route": Route(path='/get', handler=bad_route)
    }


# Generated at 2022-06-21 23:46:35.883240
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    from sanic.exceptions import SanicException
    router = Router()
    route = Route(
        path="black_swan",
        handler=lambda x: x,
        methods=["POST"],
        name="black_swan",
        strict=False,
        unquote=False,
    )
    route.ctx.ignore_body = False
    route.ctx.stream = False
    route.ctx.hosts = ['localhost']
    route.ctx.static = False
    route.ctx.parameters = {'__file_uri__': {'type': 'string'}}
    route.ctx.documentation = {}
    route.ctx.description = {}
    route.ctx.tags = {}
    router.routes_dynamic = {'black_swan': route}
    router.static_r

# Generated at 2022-06-21 23:46:37.351412
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.ctx == {'app': None}

# Generated at 2022-06-21 23:46:43.748236
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.ctx = Mock(spec=Router.ctx)
    router.dynamic_routes = {"route": MagicMock()}
    router.dynamic_routes["route"].labels = ["__illegal_label__"]
    try:
        router.finalize()
    except SanicException as e:
        assert str(e).__contains__("labels cannot use '__'")
    else:
        raise Exception("Unit test failed. Excpected SanicException")

# Generated at 2022-06-21 23:46:49.463326
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.app import Sanic
    from sanic.request import Request
    from sanic.response import text

    app = Sanic("Test_Router_finalize")
    router = Router()

    @app.route("/")
    def handler(request):
        return text("OK")

    assert not app.debug

    with pytest.raises(SanicException,match='Invalid route: <sanic_routing.route.Route object at 0x'):
        router.finalize(app)

    assert not app.debug

    app = Sanic("Test_Router_finalize")
    router = Router()

    @app.route("/__")
    def handler(request):
        return text("OK")

    assert not app.debug


# Generated at 2022-06-21 23:47:35.517877
# Unit test for method add of class Router
def test_Router_add():
    from sanic.router import Router
    from sanic.response import json
    import json as json_lib

    # Test case: simple route
    router = Router()
    router.add("/items", ["GET", "POST"], json, name="item")

    assert router.get("/items", "GET")[1] == json
    assert router.find_route_by_view_name("item")[0] == "/items"


    # Test case: simple route, with only one http method
    router = Router()
    router.add("/items", ["GET"], json, name="item")

    assert router.get("/items", "GET")[1] == json
    assert router.find_route_by_view_name("item")[0] == "/items"


    # Test case: simple route, parsed by app.add

# Generated at 2022-06-21 23:47:43.716386
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add('/',['GET'],'test_handler')
    router.add('/{test}',['GET'],'test_handler2',strict_slashes=True)
    router.add('/{test}/test2',['GET'],'test_handler',name='test')

    assert len(router.routes_dynamic)==2
    assert len(router.routes_static)==1
    assert len(router.routes_regex)==3
    assert router.routes['get'].handler=='test_handler'
    assert router.routes_dynamic['test'].handler=='test_handler2'
    assert router.routes_regex['test'].handler=='test_handler'


# Generated at 2022-06-21 23:47:44.471374
# Unit test for constructor of class Router
def test_Router():
    assert Router()


# Generated at 2022-06-21 23:47:56.393263
# Unit test for method add of class Router
def test_Router_add():
    import os
    import sys
    import pytest
    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    from sanic.sanic import Sanic

    app = Sanic()

    # Test Case 1
    with pytest.raises(TypeError):
        app.add_route(1, lambda x: x)

    # Test Case 2
    with pytest.raises(TypeError):
        app.add_route("/", 1)

    # Test Case 3
    with pytest.raises(TypeError):
        app.add_route("/", lambda x: x, 1)

    # Test Case 4
    with pytest.raises(AttributeError):
        app.add_route("/", 1, methods="GET")

    # Test Case 5

# Generated at 2022-06-21 23:47:58.282620
# Unit test for method add of class Router
def test_Router_add():
    pass


# Generated at 2022-06-21 23:48:04.400346
# Unit test for method add of class Router
def test_Router_add():
    def handler():
        pass

    router = Router()
    router.add("/", ["GET"], handler)
    [route] = router.routes_all
    assert route.uri == "/"
    assert route.methods == ["GET"]
    assert route.handler == handler


# Generated at 2022-06-21 23:48:06.869372
# Unit test for method add of class Router
def test_Router_add():
    route = Router.add()
    assert route.handler == handler
    assert route.path == path
    assert route.methods == methods

# Generated at 2022-06-21 23:48:07.668248
# Unit test for constructor of class Router
def test_Router():
    pass

# Generated at 2022-06-21 23:48:11.305547
# Unit test for constructor of class Router
def test_Router():
    # Default
    assert isinstance(Router(), Router)

    # Fail case
    try:
        assert isinstance(Router(), Any)
    except:
        pass


# Generated at 2022-06-21 23:48:16.595192
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.ctx is not None
    assert router.name_index is not None
    assert len(router.routes) == 0
    assert len(router.static_routes) == 0
    assert len(router.dynamic_routes) == 0
    assert router.regex_routes == None


# Generated at 2022-06-21 23:49:37.017244
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic, response
    from rtestbench.Routes import Routes
    app = Sanic(__name__)

    rtr = Router(app)
    rtr.add(Routes.Home.uri(), [Routes.Home.method()], lambda r: response.text(''))
    rtr.add(Routes.About.uri(), [Routes.About.method()], lambda r: response.text(''))

    print(Router.finalize.__doc__)

    # This is the only way to trigger the exception in method finalize of class Router
    rtr.add('/__home2', [Routes.Home.method()], lambda r: response.text(''))

# End of unit test

# Generated at 2022-06-21 23:49:42.012604
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route_uri = '/login/:name'
    route_handler = RouteHandler()
    router.add(route_uri, ['POST'], route_handler)
    with pytest.raises(Exception):
        router.finalize()

# Generated at 2022-06-21 23:49:54.081174
# Unit test for method finalize of class Router
def test_Router_finalize():
    from . import MockRouter
    from . import MockRoute
    from . import MockApp

    handler = lambda a: a
    router = MockRouter(handler)

    route = MockRoute(handler)
    route.labels = ["__invalid_label__"]
    router.dynamic_routes["/"] = route

    app = MockApp()

    try:
        router.finalize(app)
    except SanicException as exception:
        assert exception.args[0] == "Invalid route: <class 'tests.unit.test_router.MockRoute'>." \
                                    " Parameter names cannot use '__'."
    else:
        assert False

    route.labels = ["__file_uri__"]
    router.dynamic_routes["/"] = route

    router.finalize(app)

# Generated at 2022-06-21 23:50:02.098565
# Unit test for constructor of class Router
def test_Router():
    url = 'https://github.com/briancaffey/sanic-routing/blob/master/README.md'
    router = Router()

    assert router.DEFAULT_METHOD == 'GET'
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-21 23:50:13.705423
# Unit test for method finalize of class Router
def test_Router_finalize():
    '''
    Test the method finalize of class Router
    '''
    # define test parameters
    uri = '/'
    methods = 'GET'
    handler = 'route handler'
    host = None
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = None
    unquote = False
    static = False
    label = '__file_uri__'

    # get a router
    router = Router()

    # add route
    try:
        router.add(
            uri,
            methods,
            handler,
            host,
            strict_slashes,
            stream,
            ignore_body,
            version,
            name,
            unquote,
            static,
        )
    except:
        pass

    # finalize

# Generated at 2022-06-21 23:50:18.856535
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    @router.route('/', methods = ['GET'])
    def handler(request, *args, **kwargs):
        pass

    route = router.routes[0]

    assert(route.ctx.ignore_body == False)
    assert(route.ctx.stream == False)
    assert(route.ctx.hosts == [None])
    assert(route.ctx.static == False)

