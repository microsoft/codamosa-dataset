

# Generated at 2022-06-21 23:40:15.199551
# Unit test for constructor of class Router
def test_Router():
    # Create a Router
    router = Router()

    # Create a test function
    def testFunc(request):
        return request

    # Add a handler to the router
    router.add(
        uri = "/test/uri",
        methods = [
            "GET",
            "POST"
        ],
        handler = testFunc,
        host = None,
        strict_slashes = False,
        stream = True,
        ignore_body = True,
        version = None,
        name = None,
        unquote = False,
        static = False
    )

    # Tests for get method

# Generated at 2022-06-21 23:40:17.284171
# Unit test for method add of class Router
def test_Router_add():
    # Create a route object
    router = Router()

    # Check whether the router object is initialized correctly
    assert router is not None

# Generated at 2022-06-21 23:40:23.037118
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-21 23:40:24.930468
# Unit test for constructor of class Router
def test_Router():
    assert isinstance(Router(), Router)


# Generated at 2022-06-21 23:40:29.409958
# Unit test for constructor of class Router
def test_Router():
    # Test for :class:`Router` initialization with no arguments
    route = Router()

    # Test for :class:`Router` initialization with arguments
    route = Router(name_index={})



# Generated at 2022-06-21 23:40:32.609605
# Unit test for method add of class Router
def test_Router_add():
    """
    Unit test for method add of class Router
    """
    print("test_Router_add")
    router = Router()
    route = router.add("/test", "POST", lambda arg1: print("this is a test"))
    assert isinstance(route, Route)
    assert route.path == "/test"
    assert route.methods == {'POST'}
    assert route.ctx.stream == False
    assert route.ctx.ignore_body == False
    assert route.ctx.hosts == [None]


# Generated at 2022-06-21 23:40:34.721061
# Unit test for constructor of class Router
def test_Router():
    route = Router()
    assert isinstance(route, Router)

# Generated at 2022-06-21 23:40:40.494883
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.response import text, json
    import ujson

    router = Router()
    @router.route("/rota/<parametro:int>/", methods=["GET"])
    async def index(request, parametro):
        return text("OK")

    @router.route("/rota/<parametro>/", methods=["GET"])
    async def index1(request, parametro):
        return text("OK")

    router.finalize()
    r = router.routes_dynamic
    r = list(r.keys())[0]
    r = ujson.dumps(r)
    r = ujson.loads(r)

    assert r['__file_uri__'] == '/rota/{parametro}/'

# Generated at 2022-06-21 23:40:43.819591
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.app import Sanic
    app = Sanic('test_Router_finalize')
    router = Router(app)
    route = router.add('/a', ['GET'], app, '/')
    route.labels = {'__test__'}
    router.finalize()


# Generated at 2022-06-21 23:40:45.836252
# Unit test for constructor of class Router
def test_Router():
    route_router = Router()
    assert(isinstance(route_router, Router))

# Generated at 2022-06-21 23:41:00.631700
# Unit test for constructor of class Router
def test_Router():
	from sanic import Sanic
	from sanic_routing.router import Router
	from unittest import TestCase
	from unittest.mock import MagicMock
	from sanic.config import Config
	from sanic.exceptions import SanicException

	class Test_Router(TestCase):
		def test_init(self):
			app = Sanic("test_init")
			router = Router(app)

			config = Config(None)
			router = Router(app, config)
			self.assertIs(router.config, config)
			self.assertIs(router.ctx, app)

			config = Config(None)
			router = Router(app, config, "test_prefix")
			self.assertE

# Generated at 2022-06-21 23:41:05.069337
# Unit test for method add of class Router
def test_Router_add():
    class App:
        def create_route(self, **kwargs):
            return "Route"
        def handle_exception(self, request, exception):
            return "exceptionHandle"
    router = Router("App", "Router")
    router.ctx.app = App()
    router.add("/", "GET", "dummy")
    assert router.routes_dynamic == {
    }
    assert router.routes_static == {
        '': 'Route'
    }
    assert router.routes_regex == {
    }


# Generated at 2022-06-21 23:41:16.074251
# Unit test for method add of class Router
def test_Router_add():
    router = Router()  # Initialization of router
    uri = '/users/<user_id>'
    methods = ['GET', 'POST']
    handler = 'routeHandler'
    host = None
    strict_slashes = False
    stream = False
    ignore_body = False
    version = '1'
    name = 'Users'

    route = router.add(
        uri,
        methods,
        handler,
        host=host,
        strict_slashes=strict_slashes,
        stream=stream,
        ignore_body=ignore_body,
        version=version,
        name=name,
    )

    # Assertion for initialized router
    assert router.routes_all.keys() == {'0', '1', '2', '3'}
    assert router.routes_

# Generated at 2022-06-21 23:41:27.636671
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse

    app = Sanic("sanic-application")

    router = Router(app=app)

    @app.route("/test_Router_finalize")
    def test_Router_finalize_handle(request: Request) -> HTTPResponse:
        return HTTPResponse("OK", 200)

    try:
        router.finalize()
    except SanicException as e:
        assert "Invalid route" in str(e)

    app = Sanic("sanic-application")

    router = Router(app=app)


# Generated at 2022-06-21 23:41:31.085913
# Unit test for constructor of class Router
def test_Router():
    # Create a new Router
    try:
        router = Router()
    except:
        assert False
    else:
        assert isinstance(router, Router)
        assert isinstance(router, BaseRouter)


# Generated at 2022-06-21 23:41:36.629366
# Unit test for method add of class Router
def test_Router_add():
    from sanic.router import Router
    router = Router()
    uri = "/"
    methods = ["GET"]
    handler = None
    host = None
    strict_slashes = None
    stream = None
    ignore_body = None
    version = None
    name = None
    unquote = None
    route = router.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote)
    assert isinstance(route, Route)
    
    

# Generated at 2022-06-21 23:41:38.686120
# Unit test for constructor of class Router
def test_Router():
    rout = Router()
    assert isinstance(rout, BaseRouter)


# Generated at 2022-06-21 23:41:49.741438
# Unit test for method add of class Router
def test_Router_add():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.views import HTTPMethodView

    app = Sanic("test_add_router")

    @app.route("/")
    async def handler(request):
        return text("OK")

    class HTV(HTTPMethodView):
        async def get(self, request):
            pass

        async def post(self, request):
            pass

    app.add_route(handler, "/hello")
    app.add_route(handler, "/hello1", methods=["GET", "POST"])
    app.add_route(handler, "/hello2", methods=["GET", "POST", "PUT"])
    app.add_route(handler, "/hello3", methods=["GET", "HEAD", "PUT"])
   

# Generated at 2022-06-21 23:41:59.183206
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    import pytest
    from sanic.response import text
    def method_ut():
        app = Sanic()
        
        # create
        router = Router()
        router2 = Router(hello)
        router3 = Router(app)
        
        # finalize
        # router.finalize()
        router2.finalize()
        router3.finalize(app)
        return
    
    # with pytest.raises(Exception) as excinfo:
    assert method_ut() == None

# Generated at 2022-06-21 23:42:08.874461
# Unit test for method add of class Router
def test_Router_add():
    from sanic.app import Sanic

    app = Sanic("test_Router_add")
    router = Router(app, "app_router")

    @app.route('/test1')
    def handler1(request):
        pass

    @app.route('/test2', methods=['GET'])
    def handler2(request):
        pass

    @app.route('/test3', methods=['GET', 'POST'])
    def handler3(request):
        pass

    @app.route('/test4/<param1>', methods=['GET', 'POST'])
    def handler4(request, param1):
        pass


# Generated at 2022-06-21 23:42:16.782247
# Unit test for method finalize of class Router
def test_Router_finalize():
    assert True

# Generated at 2022-06-21 23:42:18.756532
# Unit test for constructor of class Router
def test_Router():
  router = Router()
  assert isinstance(router, Router)


# Generated at 2022-06-21 23:42:28.102997
# Unit test for method add of class Router
def test_Router_add():
    r = Router()
    r.add(uri='/', methods=['GET'], handler=None)
    assert r.routes_all == {'/' : [Route(path='/', methods=['GET'], handler=None)]}
    assert r.routes_static == {}
    assert r.routes_dynamic == {'/' : [Route(path='/', methods=['GET'], handler=None)]}
    assert r.routes_regex == {}


# Generated at 2022-06-21 23:42:36.066838
# Unit test for constructor of class Router
def test_Router():
    
    # Test case 1
    my_router = Router()
    assert isinstance(my_router, BaseRouter)
    assert my_router.routes_all == dict()
    assert my_router.routes_static == dict()
    assert my_router.routes_dynamic == dict()
    assert my_router.routes_regex == dict()

# Generated at 2022-06-21 23:42:38.967722
# Unit test for method add of class Router
def test_Router_add():
    def handler(request):
        return "ok"
    router = Router()
    router.add("/", methods=["GET"], handler=handler)
    assert isinstance(router.routes, dict)


# Generated at 2022-06-21 23:42:46.529872
# Unit test for method finalize of class Router
def test_Router_finalize():
    a = Router()
    route = Route(a)
    route.labels = ["__file_uri__", "__file_uri__"]
    a.dynamic_routes = {"route": route}
    a.finalize()

    route.labels = []
    with pytest.raises(SanicException):
        a.finalize()

# Generated at 2022-06-21 23:42:58.682036
# Unit test for method add of class Router
def test_Router_add():
    from sanic.request import Request
    from sanic.response import HTTPResponse
    import asyncio
    async def handle(request):
        return HTTPResponse(body="Hello world!")
    router = Router()
    router.add(uri="/", methods=["GET"], handler=handle)
    # Unit test for method get of class Router
    request = Request(uri_template="/", method="GET", headers={}, app=None)
    response = asyncio.run(router.get(request))
    assert response.text == "Hello world!"
    print("Pass test_Router_add")

if __name__ == '__main__':
    test_Router_add()

# Generated at 2022-06-21 23:43:03.920263
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert(isinstance(router, Router))
    assert(isinstance(router.not_found, NotFound))
    assert(isinstance(router.method_not_supported, MethodNotSupported))

# Generated at 2022-06-21 23:43:04.815107
# Unit test for method finalize of class Router
def test_Router_finalize():
    pass

# Generated at 2022-06-21 23:43:08.881783
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert(router.DEFAULT_METHOD == 'GET')
    assert(router.ALLOWED_METHODS == HTTP_METHODS)

# Generated at 2022-06-21 23:43:21.682003
# Unit test for method finalize of class Router
def test_Router_finalize():
    import os

    def test1(request):
        pass

    def test2(request):
        pass

    testdir = os.path.dirname(os.path.abspath(__file__))
    router = Router(testdir)

    router.add("/test1/<param1>/<param2>", ["GET"], test1)
    router.add("/test2/<param1>/<param2>", ["GET"], test2)

    router.finalize()

# Generated at 2022-06-21 23:43:34.127451
# Unit test for method finalize of class Router
def test_Router_finalize():
    from copy import copy
    import pickle

    from sanic.constants import HTTP_METHODS
    from sanic.router import Router
    from sanic.constants import SERVER_SOFTWARE

    from sanic.testing import HOST, PORT
    from sanic.views import CompositionView
    from sanic.exceptions import SanicException

    # init Router
    router = Router(SERVER_SOFTWARE)
    # init CompositionView
    comp = CompositionView()

    # add routes to router
    uri = '/test'
    methods = HTTP_METHODS
    handler = comp
    host = None
    strict_slashes = False
    stream = False
    ignore_body = False
    static = False

# Generated at 2022-06-21 23:43:43.929926
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic import Sanic, response
    app = Sanic("test_router_finalize")

    router = Router()
    router.ctx = app
    route = router.add("/foo/<string:id>", methods=("GET", "POST", "OPTIONS"),
                       handler=lambda request, id: None)
    route.ctx.ignore_body = False
    route.ctx.stream = False
    route.ctx.hosts = None
    route.ctx.static = False
    route.ctx.name = "foo"

    route.labels = {"id"}
    assert router.finalize()

# Generated at 2022-06-21 23:43:54.167465
# Unit test for method add of class Router
def test_Router_add():
    #Variable
    uri = "index/index.html"
    methods = ["GET", "POST"]
    handler = "test_handler"
    host = "127.0.0.1"
    strict_slashes = True
    stream = False
    ignore_body = False
    version = 1
    name = "test_route"
    unquote = True

    #Create instance of class Router
    router = Router()

    #Test method add of class Router with the following parameters
    route = router.add(uri, methods, handler, host, strict_slashes,
        stream, ignore_body, version, name, unquote)
    assert route is not None


# Generated at 2022-06-21 23:43:59.595379
# Unit test for constructor of class Router
def test_Router():
    assert Router.__name__ == "Router"
    assert Router.__module__ == "sanic.router"
    assert Router.DEFAULT_METHOD == "GET"
    assert Router.ALLOWED_METHODS == HTTP_METHODS


# Generated at 2022-06-21 23:44:08.188930
# Unit test for method add of class Router
def test_Router_add():
    uri = '/'
    methods = ['GET', 'POST']
    handler = 'handler'
    host = 'host'
    strict_slash = False
    stream = False
    ignore_body = False
    version = '1'
    name = 'name'
    unquote = False
    static = False

    r = Router()
    result = r.add(uri, methods, handler, host, strict_slash, stream, ignore_body, version, name, unquote, static)

    assert isinstance(result, type(r.routes_dynamic.values())), 'result should be a type of r.routes_dynamic.values()'
    assert len(result) == 1, 'result should be length 1'

# Generated at 2022-06-21 23:44:19.401690
# Unit test for constructor of class Router
def test_Router():
    from sanic.router import Router
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import NotFound
    from sanic.request import Request
    from sanic.response import HTTPResponse

    r = Router()
    def get_handler(request):
        return HTTPResponse({'hello'})
    r.add('/get', ['GET'], get_handler)
    res = r.get('/get', 'GET')

    assert res.handler == get_handler
    assert res.handlers == [get_handler]
    assert res.stream is False

    with pytest.raises(MethodNotSupported):
        r.get('/get', 'POST')

    with pytest.raises(NotFound):
        r.get('/get1', 'GET')

    res = r

# Generated at 2022-06-21 23:44:21.933988
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert isinstance(r, Router)
    assert isinstance(r, BaseRouter)

# Generated at 2022-06-21 23:44:32.307423
# Unit test for method add of class Router
def test_Router_add():
    from sanic.router import Router as router
    from sanic.request import Request
    from sanic.response import HTTPResponse

    async def hello(request):
        return HTTPResponse(body="hello")

    router.add("/foo", "get", hello, host=["example.com"], strict_slashes=True, unquote=True, name="hello")

    routes = router.routes_all

    # parse params
    assert len(routes["get"]) == 1

    route = routes["get"][0]
    assert route.path == "/foo"
    assert callable(route.handler)
    assert route.handler == hello
    assert route.uri == "/foo"
    assert {"host": "example.com"} == route.requirements
    assert route.strict == True
    assert route

# Generated at 2022-06-21 23:44:33.571089
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    pass

# Generated at 2022-06-21 23:44:55.034514
# Unit test for method add of class Router
def test_Router_add():
    def test_handler():
        pass

    router = Router()
    # Call method add with valid parameters, assert it returns True
    result = router.add(uri='/test', methods=('GET', 'POST'), handler=test_handler, host=None,
                        strict_slashes=False, stream=False, ignore_body=False,
                        version=None, name='test_route')
    assert isinstance(result, Route) and result.ctx.name == 'test_route'
    assert router.mini_dict['test_route'].uri == '/test' and router.mini_dict[
        'test_route'].methods == ['GET', 'POST']
    assert isinstance(router.mini_dict['test_route'], Route)

    # Call method add with duplicated route name, assert it raises SanicException

# Generated at 2022-06-21 23:44:56.498102
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r


# Generated at 2022-06-21 23:45:02.945681
# Unit test for method finalize of class Router
def test_Router_finalize():
    uri = "test"
    methods = ["GET", "POST", "OPTIONS"]
    handler = "test"
    router = Router()
    router.add(uri=uri, methods=methods, handler=handler)
    router.add("__file_uri__", methods=methods, handler=handler)
    router.finalize()


# Generated at 2022-06-21 23:45:04.334370
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router,Router)


# Generated at 2022-06-21 23:45:06.681189
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, BaseRouter)

# Generated at 2022-06-21 23:45:17.934380
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    uri = "test_uri"
    methods = ["GET", "POST", "OPTIONS"]
    handler = "test_handler"
    version = "0.0.1"
    name = "test_name"
    route = router.add(uri, methods, handler, version=version, name=name)
    assert route.path == "/v0.0.1/test_uri"
    assert route.name == "test_name"
    assert route.methods == types.MethodType(methods, route)
    assert route.handler == handler


# Generated at 2022-06-21 23:45:30.299919
# Unit test for method add of class Router
def test_Router_add():
    from sanic.response import text
    from sanic.exceptions import MethodNotSupported
    from sanic.request import Request
    from unittest.mock import Mock
    from sanic.response import HTTPResponse


    # Add a handler to the router
    # normal call with all params, expected result: return the route object
    router = Router()
    route = router.add(uri="test", methods=["GET"], handler=text("hello"))
    assert isinstance(route, Route)
    assert route.path == "test"

    # Add a handler to the router
    # call with version param, expected result: return the route object
    router = Router()
    route = router.add(
        uri="test", methods=["GET"], handler=text("hello"), version="1.0"
    )

# Generated at 2022-06-21 23:45:33.969415
# Unit test for constructor of class Router
def test_Router():
    # Perform unit test for constructor of class Router
    test_router = Router()
    assert test_router


# Generated at 2022-06-21 23:45:39.996840
# Unit test for method finalize of class Router
def test_Router_finalize():
    from pathlib import Path
    from sanic import Sanic

    app = Sanic('test')
    app.static('/static', Path(__file__).parent)

    @app.route('/<__file_uri__:path>', static=True)
    def handle_static_path(request, path):
        pass

    router = app.router._router
    router.finalize()

# Generated at 2022-06-21 23:45:44.431249
# Unit test for method add of class Router
def test_Router_add():
    from sanic.app import Sanic
    app = Sanic('sanic-server')
    @app.route('/test', methods=['GET', 'POST'])
    def echo(request):
        return text('OK')
    assert(app.router.add.__doc__ is not None)

# Generated at 2022-06-21 23:46:09.651372
# Unit test for method add of class Router
def test_Router_add():
    uri = "/"
    methods = ["GET"]
    handler = None
    host = None
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = None
    unquote = False
    static = "NotImplemented"
    r = Router()
    out = r.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)
    assert isinstance(out, list) and len(out) == 1 and isinstance(out[0], Route)
    assert out[0].path == uri and out[0].handler == handler and out[0].methods == methods and out[0].name == name and out[0].ctx.static == static
    assert out[0].ctx.ignore_body == ignore_

# Generated at 2022-06-21 23:46:15.166580
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router(ctx=None)
    router.routes = {}
    router.routes[""] = Route(path="", ctx=None)
    router.routes[""].labels = ["__file_uri__"]
    with pytest.raises(SanicException):
        router.finalize()

# Generated at 2022-06-21 23:46:24.187574
# Unit test for method add of class Router
def test_Router_add():
    uri = "/" 
    methods = ["GET"] 
    name = "dummy"
    def do(handler):
        return 0
    handler = do
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    unquote = False
    host = None
    static = False
    r =  Router()
    assert isinstance( r.add(
        uri,
        methods,
        handler,
        host,
        strict_slashes,
        stream,
        ignore_body,
        version,
        name,
        unquote,
        static
    ),Route)


# Generated at 2022-06-21 23:46:35.096726
# Unit test for method add of class Router
def test_Router_add():
    class MySanic(sanic.Sanic):
        pass
    app = MySanic(__name__)
    r = Router(app)
    assert r.routes_all is None
    assert r.routes_static is None
    assert r.routes_dynamic is None
    assert r.routes_regex is None
    assert r.app is app
    assert r.ctx is app

    r.add(uri='/', methods=['GET', 'POST', 'OPTIONS'], handler=None)
    assert r.routes_all is not None
    assert r.routes_static is not None
    assert r.routes_dynamic is not None
    assert r.routes_regex is not None

# Generated at 2022-06-21 23:46:36.280589
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router


# Generated at 2022-06-21 23:46:40.874392
# Unit test for method add of class Router
def test_Router_add():
    @asyncio.coroutine
    def mock_handler():
        pass

    router = Router("test_Router")
    result = router.add("/", ["GET"], mock_handler)
    assert result.path == "/"
    assert result.methods == ["GET"]
    assert result.handler == mock_handler



# Generated at 2022-06-21 23:46:44.023777
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic

    app = Sanic()

    router = Router(app)
    router.add("/path/<__name>", ["POST", "GET"], lambda : 0)
    router.finalize()


# Generated at 2022-06-21 23:46:56.867216
# Unit test for method add of class Router

# Generated at 2022-06-21 23:47:04.586913
# Unit test for method finalize of class Router
def test_Router_finalize():
    import unittest

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.ctx = Router(None, None)

        def tearDown(self):
            self.ctx = None


# Generated at 2022-06-21 23:47:09.607142
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add(
        uri='/',
        methods=['POST'],
        handler=None,
        host=None,
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version=None,
        name=None,
        unquote=False,
        static=False,
    )



# Generated at 2022-06-21 23:47:39.265549
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, BaseRouter)

# Generated at 2022-06-21 23:47:42.574571
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    test1 = router.add("uri", ["methods", "xxx"], "handler", "host")


# Generated at 2022-06-21 23:47:49.696444
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.dynamic_routes == {}
    assert router.static_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.path_index == {}
    assert router.routes == []
    assert isinstance(router._get, lru_cache)


# Generated at 2022-06-21 23:47:58.968991
# Unit test for method add of class Router
def test_Router_add(): 
    route = Router()
    methods = ("GET", "POST", "OPTIONS")
    def test_handler():
        pass
    uri = '/test'
    host = '127.0.0.1'
    strict_slashes = False
    stream = False
    ignore_body = False
    version = '1.0'
    name = 'test'
    unquote = False
    static = False
    route.add(uri, methods, test_handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)
    assert route.dynamic_routes
    assert not route.static_routes
    assert not route.regex_routes


# Generated at 2022-06-21 23:48:05.106259
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r.routes == []
    assert r.routes_all == []
    assert r.routes_static == []
    assert r.routes_dynamic == {}
    assert r.routes_regex == []

# Generated at 2022-06-21 23:48:08.007720
# Unit test for method add of class Router
def test_Router_add():
    router = Router()

    @router.add('/test', ['GET'], None)
    def test(self):
        return None

    assert len(router.routes) == 1


# Generated at 2022-06-21 23:48:16.305216
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Test for invalid route: Two parameter names cannot use '__'
    route = Route(
        "",
        "",
        "",
        {},
        [],
        None,
        strict_slashes=False,
        unquote=False,
        variables=[],
        labels=["__filepath", "__file_id"],
    )

    router = Router()
    router.dynamic_routes[""] = route

    with pytest.raises(SanicException):
        router.finalize()


# Generated at 2022-06-21 23:48:26.943882
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic_routing import Router
    from sanic_routing.route import Route
    from sanic.models.handler_types import RouteHandler
    from sanic.exceptions import SanicException
    from sanic.constants import HTTP_METHODS

    # Create a fake router
    foo_router = Router()

    # Create a fake route
    foo_route = Route("/", RouteHandler, HTTP_METHODS)

    # Create a fake route that contains a forbidden label
    bad_route = Route("/", RouteHandler, HTTP_METHODS, __foo__=None)

    # Add both fake routes to the router
    foo_router.routes_dynamic = {"foo": foo_route, "bar": bad_route}

    # Finalize the router, expecting no exception
    foo_router.finalize()

    #

# Generated at 2022-06-21 23:48:27.743275
# Unit test for constructor of class Router
def test_Router():
    Router()

# Generated at 2022-06-21 23:48:31.120281
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    Test method finalize
    """
    router = Router()
    router.register_path(None)
    router.finalize()


# Generated at 2022-06-21 23:49:54.804187
# Unit test for method add of class Router
def test_Router_add():
    from sanic.exceptions import NotFound
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import SanicException

    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.ctx.app is None
    try:
        router.finalize()
    except SanicException:
        pass
    except Exception as e:
        assert False, f"Expected SanicException but got {e}"
    args_dict = {}
    args_dict["uri"] = "/"
    args_dict["methods"] = ["GET"]
    args_dict["handler"] = 1
    args_dict["host"] = None
    args

# Generated at 2022-06-21 23:50:05.385560
# Unit test for method add of class Router
def test_Router_add():
    from sanic.router import Router
    from sanic.models.handler_types import RouteHandler

    handler = RouteHandler
    host = None
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = None
    unquote = False
    static = False

    # Test cases