

# Generated at 2022-06-21 23:40:10.246736
# Unit test for method add of class Router
def test_Router_add():
    uri = 'uri'
    methods = ['methods']
    handler = 'handler'
    host = 'host'
    strict_slashes = 'strict_slashes'
    stream = 'stream'
    ignore_body = 'ignore_body'
    version = 'version'
    name = 'name'
    unquote = 'unquote'
    static = 'static'
    r = Router()
    r.ctx.app = r
    r.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)
    assert r.dynamic_routes[uri].methods == methods
    assert r.dynamic_routes[uri].ctx.hosts == host
    assert r.dynamic_routes[uri].ctx.strict_slashes

# Generated at 2022-06-21 23:40:21.759244
# Unit test for method add of class Router
def test_Router_add():
    try:
        router = Router()
        # (uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)
        uri = "/"
        methods = ["GET","POST","OPTIONS"]
        handler = handler
        host = "host"
        strict_slashes = False
        stream = False
        ignore_body = False
        version = "version"
        name = "name"
        unquote = False
        static = False
        route = router.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)
        return True
    except Exception as e:
        return False


# Generated at 2022-06-21 23:40:25.723601
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    try:
        router.finalize()
    except:
        raise AssertionError('Could not finalize')

# Generated at 2022-06-21 23:40:30.871779
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    return router



# Generated at 2022-06-21 23:40:33.402281
# Unit test for constructor of class Router
def test_Router():
    ro=Router()
    if ro:
        print("successfully")


# Generated at 2022-06-21 23:40:44.626852
# Unit test for method add of class Router
def test_Router_add():
    uri = "/users"
    methods = ["GET", "POST", "OPTIONS"]
    handler = RouteHandler
    host = None
    strict_slashes = False
    stream = False
    ignore_body = False
    version = 5
    name = "users"
    unquote = False
    static = False
    route = Route(name, uri, methods, unquote, static, None, None, None)

    r = Router()
    r.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)

    assert r.route_by_uid == {1: route}
    assert r.uri_index == {'/users': route}
    assert r.name_index == {'users': route}
    assert r.dynamic_routes == {}

# Generated at 2022-06-21 23:40:47.307275
# Unit test for constructor of class Router
def test_Router():
    assert Router() != None



# Generated at 2022-06-21 23:40:55.568275
# Unit test for constructor of class Router
def test_Router():
    from sanic import Sanic
    from sanic.response import json as res_json
    from sanic.router import Router as SanicRouter
    app = Sanic("testing")
    test_router = Router(app)
    # It's a subclass of SanicRouter
    assert issubclass(Router, SanicRouter)
    # app is set to a Sanic app
    assert hasattr(test_router, 'app')
    # app is set to specified Sanic app
    assert test_router.app == app



# Generated at 2022-06-21 23:41:04.632555
# Unit test for method finalize of class Router
def test_Router_finalize():
    """Test method Router.finalize."""
    # Arrange
    # Act
    router = Router()
    router.add(uri='/test', methods=['GET'], handler=None, host=None, strict_slashes=False, stream=False, ignore_body=False, version=None, name=None, unquote=False, static=False)
    try:
        router.finalize()
    except SanicException as e:
        # Assert
        assert str(e) == "Invalid route: Route('/test', handler=None, methods=['GET'], name=None, strict=False, unquote=False). Parameter names cannot use '__'."


# Generated at 2022-06-21 23:41:06.653542
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-21 23:41:16.713281
# Unit test for constructor of class Router
def test_Router():
    full_path = 'tests/test_route.py'
    @app.options('/{id}', name='test')
    @app.route('/{id}', methods=['HEAD', 'OPTIONS', 'PUT', 'GET', 'POST'])
    def handler(request, id):
        return id
    router = Router(full_path)
    assert type(router) == Router

# Generated at 2022-06-21 23:41:18.526835
# Unit test for constructor of class Router
def test_Router():
    router = Router()


# Generated at 2022-06-21 23:41:19.610787
# Unit test for constructor of class Router
def test_Router():
    Router()

# Generated at 2022-06-21 23:41:23.542889
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add("/", methods=["GET"], handler=lambda: None, name="test", strict_slashes=True)
    assert router.find_route_by_view_name("test")

# Generated at 2022-06-21 23:41:32.030743
# Unit test for method add of class Router
def test_Router_add():
    class MockHandler:
        pass
    
    class MockRouter(Router):
        def __init__(self):
            super().__init__()
            self.resolved_handlers = {}
        
        def resolve(self, path, method, extra):
            return self.resolved_handlers.get((path, method, extra["host"]))
    
    router = MockRouter()
    routes = []
    
    for i in range(5):
        routes.append(
            router.add(
                uri=f"/{i}", 
                methods=["GET"],
                handler=MockHandler(),
                host=f"{i}.example.com"
            )
        )
        assert len(routes) == 1
        assert not router.routes
        assert not router.name_index

# Generated at 2022-06-21 23:41:37.503770
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET" and \
        router.ALLOWED_METHODS == HTTP_METHODS and \
        router.MAX_CACHE_SIZE == ROUTER_CACHE_SIZE and \
        router.routes == {} and \
        router.static_routes == {} and \
        router.dynamic_routes == {} and \
        router.name_index == {} and \
        router.regex_routes == {} and \
        router.ctx is not None


# Generated at 2022-06-21 23:41:44.486880
# Unit test for method finalize of class Router
def test_Router_finalize():
    """ Test the finalize method of class Router"""
    def fn():
        """ Test function """
        pass
    router = Router()
    router.add('/user/{name}/{blog}', ['GET'], fn, strict_slashes=False)
    router.finalize()
    # Nothing should happen (no exceptions should be raised)
    assert True

# Generated at 2022-06-21 23:41:45.114779
# Unit test for constructor of class Router
def test_Router():
    router = Router()

# Generated at 2022-06-21 23:41:58.376020
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic_routing import BaseRouter
    from sanic_routing.route import Route
    from sanic.constants import HTTP_METHODS
    from sanic.exceptions import SanicException
    from sanic.response import html

    from typing import Any, Dict

    class Router(BaseRouter):

        def __init__(self, *args, **kwargs):
            super(Router, self).__init__(*args, **kwargs)

        def get(self, path: str, method: str) -> Tuple[Route, RouteHandler, Dict[str, Any]]:
            return super().get(path, method)

        def add(self, uri: str, methods: Iterable[str], handler: RouteHandler) -> Route:
            return super().add(uri, methods, handler)


# Generated at 2022-06-21 23:42:00.556209
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)

# Generated at 2022-06-21 23:42:05.852034
# Unit test for method add of class Router
def test_Router_add():
    pass

# Generated at 2022-06-21 23:42:08.142258
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-21 23:42:11.268781
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add(uri="/uri", methods=["GET", "POST"], handler=None)

# Generated at 2022-06-21 23:42:13.340756
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-21 23:42:20.858156
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    app = Sanic('test App')
    r = Router(app)
    try:
        r.finalize()
    except SanicException:
        assert False

    class Route:
        def __init__(self, labels=None):
            self.labels = labels

    r2 = Router(app)
    r2.add_route(Route(['test']))
    try:
        r2.finalize()
    except SanicException:
        assert False
    r3 = Router(app)
    r3.add_route(Route(['__test']))
    try:
        r3.finalize()
    except SanicException:
        assert True

# Generated at 2022-06-21 23:42:30.036984
# Unit test for constructor of class Router
def test_Router():
    assert Router.ALLOWED_METHODS == HTTP_METHODS
    assert Router.DEFAULT_METHOD == "GET"
    assert Router.ALLOWED_METHODS
    assert Router.DEFAULT_METHOD
    assert not Router.routes_all
    assert not Router.routes_static
    assert not Router.routes_dynamic
    assert not Router.routes_regex
    assert Router.routes_all is None
    assert Router.routes_static is None
    assert Router.routes_dynamic is None
    assert Router.routes_regex is None


# Generated at 2022-06-21 23:42:39.747751
# Unit test for method finalize of class Router
def test_Router_finalize():
    with pytest.raises(SanicException, match=
            r"Invalid route: Route\(GET, 'http://localhost/<__file_uri__>', "
            "handler=<function _test.*>:<lambda>\). Parameter names cannot "
            "use '__'."):
        # This is a valid route. The problem is that the parameter name starts
        # with '__'.
        route = Route(HTTP_METHODS, "http://localhost/<__file_uri__>",
            lambda x: None)

        router = Router()
        router.dynamic_routes["hello"] = route
        router.finalize()

# Generated at 2022-06-21 23:42:48.763411
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route(
        path="/users/<name>/<id>",
        handler=lambda x: x,
        methods=["GET"],
        name="test_route",
        strict=False,
        unquote=False,
        host="",
        requirements={},
        ctx=router.ctx,
    )
    router.dynamic_routes[route.path] = route
    router.finalize()



# Generated at 2022-06-21 23:42:50.077579
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router


# Generated at 2022-06-21 23:43:02.007215
# Unit test for method finalize of class Router

# Generated at 2022-06-21 23:43:13.096805
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    with pytest.raises(SanicException):
        router.finalize()


# Generated at 2022-06-21 23:43:15.251238
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.finalize([], {}, "")


# Generated at 2022-06-21 23:43:23.562570
# Unit test for method add of class Router
def test_Router_add():
    import os
    import sys
    import types

    import pytest
    from sanic.response import text

    from .path import URI
    from .test_constants import TEST_ROUTER
    from .test_constants import TEST_HANDLER
    from .test_constants import MOCK_RESOLVED_PATH

    test_router = Router()
    test_router_get = test_router.get

    test_router.add(TEST_ROUTER, ["POST"], TEST_HANDLER)

    for index in range(ROUTER_CACHE_SIZE):
        test_router_get(MOCK_RESOLVED_PATH, "POST", "test_host")

    test_router.add(TEST_ROUTER, ["POST"], TEST_HANDLER)


# Generated at 2022-06-21 23:43:31.208219
# Unit test for method add of class Router
def test_Router_add():
    def route_handler(request):
        return request

    r = Router()
    r.add("/", ("GET",), route_handler)
    r.add("/test/", ("GET",), route_handler)
    assert str(r.routes["/"].uri) == r"/"
    assert str(r.routes["/test/"].uri) == r"/test/"
    

# Generated at 2022-06-21 23:43:42.762653
# Unit test for method add of class Router
def test_Router_add():
  from sanic import Sanic
  app = Sanic('test_Router_add')
  router = Router()
  
  @app.route('/')
  async def handler(request):
      return response.text('OK')
  
  assert router.add(uri=app.add_task(handler).uri,
                    methods=['GET'],
                    handler=app.add_task(handler),
                    host=None,
                    strict_slashes=False,
                    stream=False,
                    ignore_body=False,
                    version=None,
                    name=None,
                    unquote=False,
                    static=False) != None


# Generated at 2022-06-21 23:43:54.359925
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.handlers import RequestParameters
    from sanic.models.route import Route
    from sanic.constants import HTTP_METHODS

    routes = Router(prefix="/api/v1")
    for method in HTTP_METHODS:
        routes.add("/{param}", method, RequestParameters, "api_name")
        routes.add("/{param}/", method, RequestParameters, "api_name")

    def finalize():
        routes.finalize()

    Route.app = None
    try:
        finalize()
    except Exception as e:
        assert type(e) == SanicException
    Route.app = "sanic"
    finalize()

# Generated at 2022-06-21 23:43:56.093973
# Unit test for constructor of class Router
def test_Router():
    t = Router()
    

# Generated at 2022-06-21 23:43:57.566385
# Unit test for constructor of class Router
def test_Router():
    router = Router()


# Generated at 2022-06-21 23:43:58.436910
# Unit test for constructor of class Router
def test_Router():
    assert Router()

# Generated at 2022-06-21 23:44:03.490960
# Unit test for constructor of class Router
def test_Router():
    router1 = Router(strict_slashes=False)
    assert router1.ctx.strict_slashes == False
    router2 = Router(strict_slashes=True)
    assert router2.ctx.strict_slashes == True

if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-21 23:44:27.623047
# Unit test for method add of class Router
def test_Router_add():
    uri = "abc"
    handler = object
    host = "abc.com"
    host_list = ["a.com", "b.com"]
    name = "name"
    version = "1.0"

    router = Router()
    route = router.add(uri, ["POST"], handler, host, version=version, name=name)
    assert route.name == name
    assert route.ctx.hosts == [host]

    route = router.add(uri, ["POST"], handler, host_list, version=version, name=name)
    assert route.name == name
    assert route.ctx.hosts == host_list

# Generated at 2022-06-21 23:44:28.982032
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    r


# Generated at 2022-06-21 23:44:31.591176
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add(uri="test_uri",methods=["test_methods"],handler="test_handler",host=None)




# Generated at 2022-06-21 23:44:38.953024
# Unit test for method finalize of class Router
def test_Router_finalize():
    from typing import Callable
    router = Router()
    router.dynamic_routes = {
        'host:host:host:host:host': {
            'path': 'path',
            'handler': None,  # type: ignore
            'methods': {},
            'name': 'name',
            'strict': False,
            'ctx': {},
            'unquote': False,
            'labels': ['label'],
        },
    }
    assert router.finalize() == None

# Generated at 2022-06-21 23:44:43.488593
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    uri = '/uris'
    methods = ['POST', 'PUT']
    handler = lambda request: request
    uri1 = '/uris/:id'
    host = None
    routes = router.add(uri, methods, handler, host)
    routes1 = router.add(uri1, methods, handler, host)
    assert routes == routes1

# Generated at 2022-06-21 23:44:49.277985
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        router = Router()
        router.add('/{__hello}', methods=['GET'], handler='test')
        router.finalize()
    except SanicException as ex:
        assert str(ex) == "Invalid route: /{__hello} -> test. Parameter names cannot use '__'."

# Generated at 2022-06-21 23:44:55.866767
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    uri = "/test"
    methods = "GET"
    handler = RouteHandler
    host = "localhost"
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = None
    unquote = False
    static = False
    result = router.add(
        uri=uri,
        methods=methods,
        handler=handler,
        host=host,
        strict_slashes=strict_slashes,
        stream=stream,
        ignore_body=ignore_body,
        version=version,
        name=name,
        unquote=unquote,
        static=static
    )
    assert isinstance(result, list)
    assert len(result) == 2

# Generated at 2022-06-21 23:45:08.649713
# Unit test for method add of class Router
def test_Router_add():
    import sys
    import unittest

    from types import FunctionType

    # test for function add of class Router
    class Router_add_TestCase(unittest.TestCase):
        def test_Router_add_check_object_type(self):
            # Arrange
            uri = "/"
            methods = ["GET", "POST", "OPTIONS"]
            handler = main
            host = "medium.com"
            strict_slashes = False
            stream = False
            ignore_body = False
            version = 1
            name = "route0"
            unquote = False
            static = False

            # Act

# Generated at 2022-06-21 23:45:17.623322
# Unit test for method add of class Router
def test_Router_add():
    from sanic import Sanic
    app = Sanic("test")
    app.router = Router(app)

    async def handler(request):
        return request.body
    response = app.router.add(uri="/test", methods=["GET"], handler=handler)
    assert response.path is "/test"
    assert response.handler is handler
    assert response.methods == ["GET"]
    assert response.methods == ["GET"]

# Generated at 2022-06-21 23:45:27.034839
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.request import Request
    from sanic.response import HTTPResponse
    
    # Positional arguments
    router = Router()
    router.finalize([])

    # Keyword arguments
    router = Router()
    router.finalize(dynamic_routes=[])
    router = Router()
    router.finalize(regex_routes=[])
    router = Router()
    router.finalize(static_routes=[])

# Generated at 2022-06-21 23:45:53.351195
# Unit test for method add of class Router
def test_Router_add():
    uri = '/test'
    methods = ['GET']
    handler = 'test'
    host = 'test'
    strict_slashes = True
    stream = True
    ignore_body = False
    version = 'test'
    name = 'test'
    unquote = True
    static = False
    router = sanic.Router()

# Generated at 2022-06-21 23:46:04.902484
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.response import HTTPResponse
    def handler(*args, **kwargs):
        return HTTPResponse()
    router = Router(None)
    routes = router.routes
    routes['/test_1'] = {'uri':'/test_1','handler':handler,'labels':{},'methods':['GET']}
    routes['/test_2'] = {'uri':'/test_2','handler':handler,'labels':{'__test_1__':'test'},'methods':['GET']}
    routes['/test_3'] = {'uri':'/test_3','handler':handler,'labels':{'__test_2__':'test'},'methods':['GET']}

# Generated at 2022-06-21 23:46:12.509003
# Unit test for method finalize of class Router
def test_Router_finalize():
    # mock object
    router = Router()
    route = Route("/")

    # mock method of mock object
    setattr(router, "dynamic_routes", {1: route})
    
    # test the method of mock object
    with pytest.raises(SanicException) as e:
        router.finalize()
    assert str(e.value) == f"Invalid route: {route}. Parameter names cannot use '__'."

# Generated at 2022-06-21 23:46:22.153735
# Unit test for method add of class Router
def test_Router_add():
    from unittest.mock import MagicMock
    uri = '/'
    method = 'GET'
    host = 'google.com'
    handler = MagicMock()
    route = Router().add(uri, method, handler, host)
    assert route.path == '/'
    assert route.methods == ['GET']
    assert route.handler == handler
    assert route.name == None
    assert route.strict == False
    assert route.unquote == False
    assert route.ctx.ignore_body == False
    assert route.ctx.stream == False
    assert route.ctx.hosts == ['google.com']
    assert route.ctx.static == False


# Generated at 2022-06-21 23:46:33.594103
# Unit test for method finalize of class Router
def test_Router_finalize():
    '''
    Check that finalize method of class Router raises an error if a parameter
    name uses '__'.
    '''
    router = Router()

    try:
        # Add a route to router
        router.add(uri="/test/<p1>/<p2>", methods=["GET"], handler=None)
        router.finalize()
    except SanicException as e:
        raise e

    try:
        # Add a route to router
        router.add(uri="/test/<__p1>/<p2>", methods=["GET"], handler=None)
        router.finalize()
    except SanicException as e:
        assert str(e) == "Invalid route: /test/<__p1>/<p2>. Parameter names cannot use '__'."
    else:
        raise AssertionError

# Generated at 2022-06-21 23:46:42.404280
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Check the case that method finalize is correct
    router = Router()
    route = Route(router, "", "", "")
    route.labels = ["__file_uri__"]
    router.dynamic_routes = {"test": route}
    router.finalize()
    # Check the case that method finalize is not correct
    router = Router()
    route = Route(router, "", "", "")
    route.labels = ["__file_uri2__"]
    router.dynamic_routes = {"test": route}
    try:
        router.finalize()
    except SanicException:
        assert True


# Generated at 2022-06-21 23:46:52.403780
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    GIVEN
    a Router instance

    WHEN
    it is finalized

    THEN
    the routing table is finalized
    """
    router = Router()
    handler = lambda: True
    router.add(uri='/foo', methods=['GET'], handler=handler)

    router.finalize()

# Generated at 2022-06-21 23:47:01.999573
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        router = Router()
        router.add(
            uri='/<name>/<email>',
            methods=['GET'],
            handler='handler',
            host='host',
            strict_slashes=True,
            stream=False,
            ignore_body=False,
            version=None,
            name='name',
            unquote=True,
            static=False)
        # The test will fail if an exception is not thrown
        router.finalize()
        assert False
    except Exception as e:
        assert True # No error then the test passed
        

# Generated at 2022-06-21 23:47:04.952718
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    try: 
        router=Router()
        router.finalize()
        assert True
    except:
        assert False

# Generated at 2022-06-21 23:47:15.336818
# Unit test for method finalize of class Router
def test_Router_finalize():
    from glob import glob
    from os.path import dirname
    from io import open
    
    from sanic.app import Sanic
    from sanic.response import HTTPResponse
    
    
    def test_pass():
        pass

    def test_fail():
        raise SanicException("Should fail.")

    def test_import_fail():
        import unknown_module
    
    def test_import_success():
        try:
            import ssl
            ssl.OPENSSL_VERSION
        except ImportError:
            pass
    
    # try:
    #     import ssl
    #     ssl.OPENSSL_VERSION
    # except ImportError:
    #     pass
    # except SanicException:
    #     pass
    
    
    def filter_tests(tests, pattern):
        match

# Generated at 2022-06-21 23:47:37.096155
# Unit test for method add of class Router
def test_Router_add():
    r = Router()



# Generated at 2022-06-21 23:47:50.327899
# Unit test for method add of class Router
def test_Router_add():
    def test_uri():
        uri = ""
        router = Router()
        methods = ["GET"]
        def handler(request): 
            assert False
        
        host = ""
        strict_slashes = False
        stream = False
        ignore_body = False
        version = 1
        name = ""
        unquote = False
        static = False

        assert router.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static) != None
        return "test_uri done successfully"
    
    def test_test_uri():
        assert test_uri() == "test_uri done successfully"

    def test_methods():
        router = Router()
        methods = ""
        def handler(request): 
            assert False
        
        uri = ""
       

# Generated at 2022-06-21 23:48:00.076418
# Unit test for method add of class Router
def test_Router_add():
    # 0.
    router = Router()
    host = None
    uri = "/historique"
    methods = ["GET"]
    handler = lambda : None
    assert isinstance(router.add(uri=uri, methods=methods, handler=handler), Route)
    assert router.routes_all.get("/historique")
    assert router.routes_all.get("/historique").ctx.hosts == [host]
    assert router.routes_all.get("/historique").ctx.static == False

    # 1.
    router = Router()
    host = "example.com"
    uri = "historique"
    methods = ["GET"]
    handler = lambda : None

# Generated at 2022-06-21 23:48:02.291008
# Unit test for constructor of class Router
def test_Router():
    # Check if it can be constructed with no args
    router = Router()


# Generated at 2022-06-21 23:48:07.114018
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    import pytest

    r = Router(None, [])
    with pytest.raises(Exception, match="Invalid route"):
        r.finalize([{"uri": "/foo/<__bar>", "handler": None}])


# Generated at 2022-06-21 23:48:18.726709
# Unit test for method add of class Router
def test_Router_add():
    test_router = Router()
    expected = Route(path='/', methods={"GET"}, handler=lambda x: x, name=None)
    actual = test_router.add('', ["GET"], lambda x: x)
    assert actual.path == expected.path
    assert actual.methods == expected.methods
    assert actual.handler == expected.handler
    assert actual.name == expected.name
    assert actual.ctx.ignore_body == expected.ctx.ignore_body
    assert actual.ctx.stream == expected.ctx.stream
    assert actual.ctx.hosts == expected.ctx.hosts

    actual = test_router.add('', ["GET"], lambda x: x, host='localhost')
    assert actual.ctx.requirements == {'host': 'localhost'}

# Generated at 2022-06-21 23:48:21.169165
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r  # Tell flake8 that we are using r


# Generated at 2022-06-21 23:48:30.230212
# Unit test for method add of class Router
def test_Router_add():
    from .test_help import _req
    from sanic.response import HTTPResponse

    @lru_cache(maxsize=ROUTER_CACHE_SIZE)
    def mock_lru_cache(fn):
        def wrapper(*args, **kwargs):
            return fn(*args, **kwargs)
        return wrapper

    class MockRouter(Router):
        def __init__(self):
            super(MockRouter, self).__init__()
            self._get = mock_lru_cache(self._get)

    router = MockRouter()

    @router.add('/test', ['GET'])
    def mock_handler(request):
        return HTTPResponse(status=200)

    _, handler, _ = router.get('/test', 'GET')
    assert handler

# Generated at 2022-06-21 23:48:31.774757
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    return router

# Generated at 2022-06-21 23:48:33.829519
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None


# Generated at 2022-06-21 23:49:25.784195
# Unit test for method finalize of class Router
def test_Router_finalize():
    # function to be executed
    async def handler(request):
        return text("OK")

    # method in class Router with test
    router1 = Router()
    router1.add("/users/{name}/{identifier}", ["GET"], handler, name="test_name_Router")
    try:
        router1.finalize()
    except Exception as e:
        assert str(e) == "Invalid route: GET /users/{name}/{identifier} -> (test_name_Router). Parameter names cannot use '__'."
    else:
        assert False


# Generated at 2022-06-21 23:49:28.067261
# Unit test for constructor of class Router
def test_Router():
    try:
        Router()
        assert True
    except Exception:
        assert False


# Generated at 2022-06-21 23:49:29.660696
# Unit test for constructor of class Router
def test_Router():
  assert Router()


# Generated at 2022-06-21 23:49:34.771868
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        router = Router()

        router.add("/api/<__version:int>/get_a", ["GET"], print)
        router.finalize()
    except SanicException as e:
        return True
    else:
        return False


# Generated at 2022-06-21 23:49:36.559583
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-21 23:49:48.526111
# Unit test for method finalize of class Router
def test_Router_finalize():
    route = Route(router=Router('sanic'),
                  method='GET',
                  path='/test/path',
                  handler=None,
                  host=None,
                  strict_slashes=True,
                  unquote=False,
                  requirements={},
                  ctx={})
    try:
        route.labels = ['__file_uri__', '__another_label__']
        Router('sanic').finalize()
    except SanicException as e:
        if '__' in str(e):
            raise
    route.labels = ['__file_uri__']
    assert Router('sanic').dynamic_routes[route.name_mapping] == route

# Generated at 2022-06-21 23:49:54.673238
# Unit test for constructor of class Router
def test_Router():

    # Constructor with default parameter
    router = Router()
    assert router.ctx is None

    # Constructor with given parameters
    router = Router(ctx=None)
    assert router.ctx == None

    expected_router = Router()

    # test different inputs for add function
    assert expected_router.add("/", ["GET"], object) == router.add("/", ["GET"], object)
    assert expected_router.add("/", ["GET"], object, False) == router.add("/", ["GET"], object, False)
    assert expected_router.add("/", ["GET"], object, False, False) == router.add("/", ["GET"], object, False, False)