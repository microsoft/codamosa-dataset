

# Generated at 2022-06-21 23:40:25.100157
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    Unit test for method finalize of class Router
    """
    # test with label starting with valid prefix
    route = Route(handler=1, uri='/', method='GET', query_string='', host='', strict_slashes=False, unquote=False, labels=['__file_uri__'])
    rt = Router()
    rt.dynamic_routes = {'/': route}
    rt.finalize()

    # test with label starting with invalid prefix
    route = Route(handler=1, uri='/', method='GET', query_string='', host='', strict_slashes=False, unquote=False, labels=['__abc'])
    rt = Router()
    rt.dynamic_routes = {'/': route}

# Generated at 2022-06-21 23:40:35.873816
# Unit test for method finalize of class Router
def test_Router_finalize():
    import sys
    import io
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = io.StringIO(), io.StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        router = Router()
        route = router.add("/", {"GET"})
        route.labels.add("__file_uri__")
        route.labels.add("__uri_static__")
        route.labels.add

# Generated at 2022-06-21 23:40:49.692144
# Unit test for method add of class Router
def test_Router_add():
    import sanic
    from datetime import timedelta
    from sanic.exceptions import SanicException

    app = sanic.Sanic()

    @app.route('/tag/<tag>')
    async def handler(request, tag):
        return sanic.response.text('Tag: {}'.format(tag))

    # add using decorator
    # assert isinstance(app.router.routes_all['/tag/<tag>'][0], sanic.router.Route)
    # add using method add
    route = app.router.add(uri='/tag/<tag>', methods=['GET'], handler=handler)
    assert isinstance(route, sanic.router.Route)

    # test dynamic routes

# Generated at 2022-06-21 23:40:54.850891
# Unit test for method add of class Router
def test_Router_add():
    uri = "/"
    methods = ["GET", "POST", "OPTIONS"]
    handler = object
    host = "host"
    strict_slashes = False
    stream = False
    ignore_body = False
    version = "1.0"
    name = "name"
    unquote = False
    static = False

    router = Router()
    router.add(
        uri=uri,
        methods=methods,
        handler=handler,
        host=host,
        strict_slashes=strict_slashes,
        stream=stream,
        ignore_body=ignore_body,
        version=version,
        name=name,
        unquote=unquote,
        static=static
    )


# Generated at 2022-06-21 23:41:05.269542
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    from pprint import pprint
    from sanic.router import Router
    from sanic.exceptions import SanicException

    # Case 1: valid labels in dynamic_routes
    router = Router()
    route1 = Route(path='/', methods=['GET'], handler=None, name='index', strict=False, unquote=False)
    route1.labels.add('__file_uri__')
    router.dynamic_routes['/'] = route1

    router.finalize()

    # Case 2: invalid labels in dynamic_routes
    router2 = Router()
    route2 = Route(path='/', methods=['GET'], handler=None, name='index', strict=False, unquote=False)
    route2.labels.add('__x')
    router2

# Generated at 2022-06-21 23:41:12.965101
# Unit test for method add of class Router
def test_Router_add():
    """
    Verification method of the Router class add method
    """
    router = Router()
    def handler():
        return "handler"
    # Note: the parameters of the add method should be processed in the decorator
    # method, So the first parameter here is not /
    router.add('/test', ['get'], handler)
    assert router.find_route_by_view_name('test')[1].path == '/test'


# Generated at 2022-06-21 23:41:19.765527
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    r.regex_routes = {1: Route("", RouteHandler(None), params={"param_name": "__something__"})}

    with pytest.raises(SanicException):
        r.finalize()


# Generated at 2022-06-21 23:41:22.847366
# Unit test for method add of class Router
def test_Router_add():
    r = Router()
    assert type(r.add('/',['GET','POST'],'/')) == Route


# Generated at 2022-06-21 23:41:28.544518
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    with pytest.raises(SanicException):
        router.add(uri="/route", methods=("GET", "POST"), handler=None, host="")
        router.finalize()

# Generated at 2022-06-21 23:41:37.482475
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Initialize class Router
    router = Router('127.0.0.1', 6789, 'http')
    
    # Initialize a dynamtic route
    route = Route()
    route.labels = ['__file_uri__', '__file_name__', 'path']
    
    # Assign the dynamic route to attribute 'dynamic_routes'
    router.dynamic_routes['index'] = route
    
    # Method finalize should return without error
    router.finalize()    
    
if __name__ == '__main__':
    test_Router_finalize()

# Generated at 2022-06-21 23:41:50.913203
# Unit test for method add of class Router
def test_Router_add():
    import pytest
    from sanic import Sanic
    from sanic.router import Router
    from sanic.exceptions import InvalidUsage, NotFound, MethodNotSupported
    from sanic.request import Request
    from sanic.views import HTTPMethodView

    app = Sanic('sanic-router')
    router = Router()
    router.add("/one", ["GET"], lambda r: "one")
    router.add("/two", ["GET"], lambda r: "two")
    router.add("/<name>", ["GET"], lambda r, name: name)
    router.add("/three", ["GET", "POST"], lambda r: "three")
    router.add("/four", ["POST"], lambda r: "four")
    router.add("/five", ["HEAD"], lambda r: "five")


# Generated at 2022-06-21 23:41:57.656391
# Unit test for method add of class Router
def test_Router_add():
    """
    Добавление нового обработчика в роутер.
    """

    def handler(request, response: any):
        return

    router = Router()
    uri = "/"
    methods = ("GET", "POST")
    assert type(router.add(uri, methods, handler)) is list



# Generated at 2022-06-21 23:41:58.754636
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    assert r.finalize() is None

# Generated at 2022-06-21 23:42:06.613788
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.ctx = type('', (object,), {})()
    router.ctx.app = type('', (object,), {
      '_generate_name': lambda self, name: f'{name}:full_name',
    })
    router.name_index = {
      'my_view:full_name': object(),
    }

    route = router.find_route_by_view_name('my_view')

    assert isinstance(route, object)

# Generated at 2022-06-21 23:42:11.279829
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        Router().add('/<path:param1>', ['POST']).finalize()
    except Exception:
        assert 1 == 1
    else:
        raise Exception('failure to raise SanicException')

# Generated at 2022-06-21 23:42:16.645677
# Unit test for constructor of class Router
def test_Router():
    from sanic.router import Router

    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == ['GET', 'POST', 'PUT', 'PATCH',
                                      'DELETE', 'OPTIONS', 'HEAD']



# Generated at 2022-06-21 23:42:17.896535
# Unit test for constructor of class Router
def test_Router():
    router = Router()



# Generated at 2022-06-21 23:42:30.757779
# Unit test for method add of class Router
def test_Router_add():
    result = Router()
    test = result.add(uri='/test', methods=('get', 'post'), handler='test', host=None, strict_slashes=False, stream=False, ignore_body=False, version=None, name=None, unquote=False, static=False)
    assert result.routes_all == {}
    assert result.routes_static == {}
    assert result.routes_dynamic == {}
    assert result.routes_regex == {}
    assert result.name_index == {}
    assert result.method_index == {}
    assert test.ctx.ignore_body == False
    assert test.ctx.stream == False
    assert test.ctx.hosts == [None]
    assert test.ctx.static == False
    assert test.ctx.version == None
    assert test.ctx

# Generated at 2022-06-21 23:42:40.584027
# Unit test for method add of class Router
def test_Router_add():
    r1 = Router()
    r1.add('/index', ['GET'], print)
    r2 = Router()
    r2.add('/index/list', ['GET'], print)
    r3 = Router()
    r3.add('/index', ['GET'], print)
    r4 = Router()
    r4.add('/index/list', ['GET'], print)
    r5 = Router()
    r5.add('/index', ['GET'], print)
    r6 = Router()
    r6.add('/index/list', ['GET'], print)
    r7 = Router()
    r7.add('/index', ['GET'], print)
    r8 = Router()
    r8.add('/index/list', ['GET'], print)
    r9 = Router()


# Generated at 2022-06-21 23:42:52.125944
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    uri = "/accounts/{account_id}"
    methods = ["GET", "POST"]
    handler = lambda: True
    host = "example.com"
    strict_slashes = False
    stream = False
    ignore_body = False
    version = 1.0
    name = "accounts"
    unquote = False
    routes = router.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote)
    for route in routes:
        assert route.ctx.hosts == [host]
        assert route.ctx.ignore_body == ignore_body
        assert route.ctx.stream == stream
        assert route.ctx.static == False

test_Router_add()

# Generated at 2022-06-21 23:42:57.031524
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-21 23:43:04.223762
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    r.add('/', ['GET'], lambda x: x+2)
    r.add('/home/<name>', ['GET'], lambda x, name: x+name)
    r.add('/home/<name>/<age:int>', ['POST', 'GET'], lambda x, name, age: x+name+age)

    print(r.routes)
    print(r.routes_all)
    print(r.routes_static)
    print(r.routes_dynamic)
    print(r.routes_regex)

    print(r.get('/', 'GET', None))
    print(r.get('/home/lucy', 'GET', None))

# Generated at 2022-06-21 23:43:12.977828
# Unit test for method add of class Router
def test_Router_add():
    from sanic.app import Sanic

    router = Router(Sanic("sanic"))
    assert len(router.routes) == 0
    router.add(
        uri="/path/to/route",
        methods=["GET", "OPTIONS"],
        handler=lambda: "test",
    )
    assert len(router.routes) == 1
    router.add(
        uri="/path/to/route2",
        methods=["GET", "OPTIONS"],
        handler=lambda: "test",
    )
    assert len(router.routes) == 2


# Generated at 2022-06-21 23:43:16.275590
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add("/test/<name>", ["GET"], "function")
    assert router.routes_dynamic != dict()

# Generated at 2022-06-21 23:43:24.209772
# Unit test for method finalize of class Router
def test_Router_finalize():
    class _MockRouter(BaseRouter):
        def finalize(self, *args, **kwargs):
            return super().finalize(*args, **kwargs)

    mock_router = _MockRouter()
    route = mock_router.add("/", ["GET"], None)
    mock_router.dynamic_routes[""] = route
    mock_router.routes[route.id] = route
    route.labels = {"__file_uri__"}
    mock_router.finalize()

    route.labels = {"__file_uri__", "__file_uri__2"}
    mock_router.finalize()

# Generated at 2022-06-21 23:43:26.409638
# Unit test for constructor of class Router
def test_Router():
    router = Router(app=None)
    assert isinstance(router, BaseRouter)
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.ctx.app is None


# Generated at 2022-06-21 23:43:30.842465
# Unit test for method finalize of class Router
def test_Router_finalize():
    def test_fn(*args):
        pass

    router = Router()
    router.add("/test2/<v1>", methods=["GET"], handler=test_fn)
    with pytest.raises(SanicException) as e_info:
        router.finalize()
    assert e_info.value.args[0] == "Invalid route: Route(GET /test2/<v1>). Parameter names cannot use '__'."

# Generated at 2022-06-21 23:43:36.123040
# Unit test for constructor of class Router
def test_Router():
    from sanic.app import Sanic
    from sanic.router import Router
    app = Sanic('test_Router')
    app.router = Router(app)


# Generated at 2022-06-21 23:43:45.243058
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    
    class A: 
        def __init__(self): 
            self.name = "A"
    a=A()
    uri = "/path/to/something"
    methods = ["POST"]
    handler = a.name
    host = "localhost"
    strict_slashes = False
    stream = False
    ignore_body = False
    
    result = router.add(uri, methods, handler, host, strict_slashes, 
                        stream, ignore_body)
    assert result.__class__ == Route
    assert result._methods == methods
    assert result._path == uri
    assert result._handler == handler


# Generated at 2022-06-21 23:43:48.263321
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r is not None

# test for method add of class Router

# Generated at 2022-06-21 23:43:53.403284
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    pass

# Generated at 2022-06-21 23:43:56.945356
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    assert router == {}
    #router.add('/', GET, 'test')
    #assert router == {'/', GET}

# Generated at 2022-06-21 23:44:07.453262
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    route = Route(
        r,
        "GET",
        "/some/path/to/somewhere",
        handler=None,
        strict_slashes=False,
        unquote=False,
        name=None,
    )
    route_2 = Route(
        r,
        "GET",
        "/some/path/to/somewhere",
        handler=None,
        strict_slashes=False,
        unquote=False,
        name=None,
    )
    route_2.labels.append("__file_uri__")
    r.dynamic_routes[("GET", "/some/path/to/somewhere")] = route
    r.dynamic_routes[("GET", "/some/path/to/somewhere")] = route_

# Generated at 2022-06-21 23:44:18.790625
# Unit test for method finalize of class Router
def test_Router_finalize():
    def test_fin_1():
        r = Router()
        r.add("/<param1>/<param2>", ["GET"], lambda req, resp: None)
        r.finalize()
    def test_fin_2():
        r = Router()
        r.add("/<param1>/<param2>", ["GET"], lambda req, resp: None)
        r.add("/<param1>/<param2>", ["GET"], lambda req, resp: None)
        r.finalize()
    def test_fin_3():
        r = Router()
        r.add("/<__param1>/<param2>", ["GET"], lambda req, resp: None)
        r.finalize()
    def test_fin_4():
        r = Router()

# Generated at 2022-06-21 23:44:24.026884
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    methods=["GET","POST"]
    uri="uri"
    def handler():
        return "Handler"
    route=router.add(uri,methods,handler)
    assert route.uri == uri
    assert route.handler == handler
    assert route.methods == methods

# Generated at 2022-06-21 23:44:28.147276
# Unit test for constructor of class Router
def test_Router():
    # Given
    router_instance = Router()
    assert router_instance.routes_all == []
    assert router_instance.routes_static == []
    assert router_instance.routes_dynamic == {}
    assert router_instance.routes_regex == []


# Generated at 2022-06-21 23:44:33.596737
# Unit test for constructor of class Router
def test_Router():
    '''
    Test case for Router.

    The test case raises exception, if any error occurs.
    '''
    router = Router()
    assert router is not None
    assert router == {}
    assert router == []
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-21 23:44:41.749658
# Unit test for method finalize of class Router
def test_Router_finalize():
    class test_route(Route):
        def __init__(self, *args, **kwargs):
            self.labels = ["label1", "__file_uri__"]
    routes_dynamic = {"uri": test_route()}
    router = Router()
    router.dynamic_routes = routes_dynamic
    router.finalize()

# Generated at 2022-06-21 23:44:44.242915
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r.DEFAULT_METHOD == "GET"
    assert r.ALLOWED_METHODS == HTTP_METHODS

# Generated at 2022-06-21 23:44:54.151274
# Unit test for method add of class Router
def test_Router_add():
    # Test: Router_add_1:
    test_name = "Router_add_1"
    uri = "/api/v1/users"
    methods = ["GET", "POST", "OPTIONS"]
    handler = lambda x: None
    strict_slashes = False
    stream = False
    ignore_body = False
    version = "1"
    name = "get_user"
    unquote = False
    static = False
    test_router = Router()
    test_route = test_router.add(uri, methods, handler, strict_slashes=strict_slashes, stream=stream, ignore_body=ignore_body, version=version, name=name, unquote=unquote, static=static)
    assert test_route.ctx.ignore_body == ignore_body

# Generated at 2022-06-21 23:45:02.334938
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == []
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}

# Generated at 2022-06-21 23:45:09.090556
# Unit test for constructor of class Router
def test_Router():
    try:
        from sanic.app import Sanic
    except ImportError:
        return

    app = Sanic()
    router = Router(app)
    assert type(router) == Router
    # check if Router() raise TypeError, when app parameter is omitted
    try:
        Router()
    except TypeError:
        pass
    else:
        raise AssertionError("Router is not raising TypeError.")



# Generated at 2022-06-21 23:45:21.445777
# Unit test for method add of class Router
def test_Router_add():
    router = Router()

    # Test host
    router.add('/', ['GET'], lambda x: x)
    assert router.get('/', 'GET', 'host')[0].hosts == [None]
    router.add('/', ['GET'], lambda x: x, 'host')
    assert router.get('/', 'GET', 'host')[0].hosts == ['host']
    router.add('/', ['GET'], lambda x: x, ['host1', 'host2'])
    assert router.get('/', 'GET', 'host1')[0].hosts == ['host1', 'host2']
    assert router.get('/', 'GET', 'host2')[0].hosts == ['host1', 'host2']

# Generated at 2022-06-21 23:45:31.909134
# Unit test for method finalize of class Router
def test_Router_finalize():
    class TestRouter(Router):
        def __init__(self, ctx):
            super().__init__(ctx)
            self.routes = {
                "test": Route(
                    "/test", "GET", "<string:a>/<string:b>", None, {}, None, None, [], [], "test"
                )
            }

    # assert
    TestRouter(None).finalize()  # it should be no exception

    # assert
    TestRouter(None).routes["test"].labels = ["__a", "__b"]
    TestRouter(None).finalize()  # it should be no exception
    TestRouter(None).routes["test"].labels = ["a", "b"]
    TestRouter(None).finalize()  # it should be no

# Generated at 2022-06-21 23:45:43.633577
# Unit test for method finalize of class Router
def test_Router_finalize():
    # create a Router object
    router = Router()
    # create a Route object
    class route(Route):
        pass
    # create a mock method's object
    route.dynamic_routes = {
        "a": route()
    }
    route.dynamic_routes["a"].labels = [
        "__file_uri__"
    ]
    # call finalize() with no exception raises
    router.finalize(route)
    # create a Route object
    class route(Route):
        pass
    # create a mock method's object
    route.dynamic_routes = {
        "a": route()
    }
    route.dynamic_routes["a"].labels = [
        "__test__"
    ]
    # call finalize() with exception raises

# Generated at 2022-06-21 23:45:52.202997
# Unit test for method add of class Router
def test_Router_add():
  uri = '/sanic/route'
  methods = [
    "GET",
    "POST",
    "OPTIONS"
  ]
  handler = None
  host = "localhost"
  strict_slashes = False
  stream = False
  ignore_body = False
  version = "1"
  name = "sanic_app"
  unquote = False
  static = False
  router = Router()
  router.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)
  # print(router.get('/sanic/route', 'GET', 'localhost')[0])


# Generated at 2022-06-21 23:46:03.604444
# Unit test for method add of class Router
def test_Router_add():
    # Create an instance of class Router
    router = Router()
    # Create a mock RouteHandler
    # handler = MagicMock()
    # Create a mock uri (str)
    uri = "/"
    # Create a mock methods (list)
    methods = ["GET", "POST"]
    # Create a mock host (str)
    host = "www.example.com"
    # Create a mock strict_slashes (bool)
    strict_slashes = False
    # Create a mock stream (bool)
    stream = False
    # Create a mock ignore_body (bool)
    ignore_body = False
    # Create a mock version (str)
    version = "v"
    # Create a mock name (str)
    name = "hello"
    # Create a mock unquote (bool)
    unquote = False
    #

# Generated at 2022-06-21 23:46:14.882542
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    Unit test for method finalize of class Router
    """

    # Test with no parameters
    router = Router()
    try:
        router.finalize()
    except SanicException as e:
        assert str(e) == "No application context available."
    
    # Test with unknown parameters
    router = Router()
    router.ctx = object()
    try:
        router.finalize()
    except SanicException as e:
        assert str(e) == "No application available."

    # Test with unknown parameters
    router = Router()
    router.ctx = object()
    try:
        router.finalize()
    except SanicException as e:
        assert str(e) == "No application available."

# Generated at 2022-06-21 23:46:26.681587
# Unit test for method add of class Router
def test_Router_add():
    from sanic import Sanic

    app = Sanic("test")

    router = Router(app)
    router.add("/foo/", ["GET", "POST"], lambda: None)
    routes = router.routes[None]
    assert routes[0].uri == "/foo/"
    assert routes[0].endpoint == "<lambda>"

    # adding a duplicate method to the same resource
    router.add("/foo/", ["POST"], lambda: None)
    assert len(router.routes[None]) == 1
    assert len(router.routes[None][0].handlers) == 2

    assert router.routes[None][0].get_method_and_handler(
        "GET"
    ) == (None, None)
    assert router.routes[None][0].get_method_and

# Generated at 2022-06-21 23:46:27.747489
# Unit test for method add of class Router
def test_Router_add():
    assert False



# Generated at 2022-06-21 23:46:34.255985
# Unit test for constructor of class Router
def test_Router():
  r = Router()
  assert r.ctx.app == None
  assert r.ctx.path == []
  assert r.ctx.hosts == []
  assert r.ctx.hosted == False

# Generated at 2022-06-21 23:46:37.551196
# Unit test for constructor of class Router
def test_Router():
    router = Router(
        ctx=None,
        static_root="/home/ubuntu/sanic-recommendation/static",
        static_url_path="/static",
    )
    assert router is not None


# Generated at 2022-06-21 23:46:40.965824
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    uri = "/users/<id>"
    assert router.routes == {}
    router.add(uri, ["GET"], lambda x, y: None)
    assert router.routes == {}


# Generated at 2022-06-21 23:46:44.407143
# Unit test for constructor of class Router
def test_Router():
    router=Router()
    assert router.routes_all =={}
    assert router.routes_static =={}
    assert router.routes_dynamic =={}
    assert router.routes_regex =={}


# Generated at 2022-06-21 23:46:56.959416
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    method = 'GET'
    uri = '/'
    handler = lambda request: text("OK")
    # Check expected exception when path is an int
    with raises(TypeError):
        router.add(1, [method], handler)
    # Check expected exception when methods is an int
    with raises(TypeError):
        router.add(uri, 1, handler)
    # Check expected exception when handler is an int
    with raises(TypeError):
        router.add(uri, [method], 1)
    # Check expected exception when host is an int
    with raises(TypeError):
        router.add(uri, [method], handler, 1)
    # Check expected exception when strict_slashes is a string

# Generated at 2022-06-21 23:47:03.063893
# Unit test for method add of class Router
def test_Router_add():
    r = Router()
    assert r.routes_all == {}
    r.add(uri="/", methods=["GET", "OPTIONS"], handler=None, host=None, strict_slashes=False, stream=False, ignore_body=False, version=None, name=None, unquote=False)
    assert r.routes_all == {}

# Generated at 2022-06-21 23:47:09.288667
# Unit test for method finalize of class Router
def test_Router_finalize():
    func = lambda request, name: 'test'
    route = Router.add(uri="test",methods=['GET'],handler=func,host=None,
        strict_slashes=False,stream=False,ignore_body=False,version=None,
        name=None,unquote=False,static=False)
    route.labels.append('__name__')
    router = Router()
    router.dynamic_routes['test'] = route
    router.finalize()

# Generated at 2022-06-21 23:47:20.121756
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    r.add('/', ['GET'], lambda x: 0)
    r.add('/<name1>', ['GET'], lambda x: 0)
    r.add('/<name1>/<name2>', ['GET'], lambda x: 0)
    r.add('/<__name1>', ['GET'], lambda x: 0)
    r.add('/<name1>/<__name2>', ['GET'], lambda x: 0)
    r.add('/<__file_uri__>', ['GET'], lambda x: 0)
    try:
        r.finalize()
    except SanicException:
        pass


# Generated at 2022-06-21 23:47:29.764094
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest # type: ignore
    from sanic_routing import BaseRouter # type: ignore
    uut = Router()
    uut.add('/path/a/', ['GET', 'PUT'], 'handler_a')
    uut.add('/path/b/$__file_uri__/', ['GET', 'PUT'], 'handler_b')
    uut.add('/path/c/*__file_uri__/', ['GET', 'PUT'], 'handler_c')
    
    uut.finalize()
    
    if len(uut.routes_dynamic) == 3:
        assert uut.routes_dynamic[0].labels == []
        assert uut.routes_dynamic[1].labels == ['__file_uri__']
        assert uut.r

# Generated at 2022-06-21 23:47:40.813859
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add(uri=r'/hello/[<name>]', methods=['GET'], handler=None)
    router.add(uri=r'/hello/[<name>]', methods=['POST'], handler=None)
    router.add(uri=r'/hello/[<name>]', methods=['PUT'], handler=None)
    router.add(uri=r'/hello/[<name>]', methods=['DELETE'], handler=None)
    router.add(uri=r'/hello/[<name>]', methods=['PATCH'], handler=None)
    router.add(uri=r'/hello/[<name>]', methods=['HEAD'], handler=None)
    router.add(uri=r'/hello/[<name>]', methods=['OPTIONS'], handler=None)

# Generated at 2022-06-21 23:47:53.529337
# Unit test for constructor of class Router
def test_Router():
    test_Router1 = Router(None)
    assert test_Router1.ctx == None
    assert test_Router1.dynamic_routes == {}
    assert test_Router1.static_routes == {}
    assert test_Router1.name_index == {}
    assert test_Router1.regex_routes == []


# Generated at 2022-06-21 23:47:56.890845
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add("/users", ["GET"], "my handler")

    assert router.find("/users", []) == ("my handler", {})



# Generated at 2022-06-21 23:47:58.005930
# Unit test for method add of class Router
def test_Router_add():
    pass

# Generated at 2022-06-21 23:47:59.482799
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router


# Generated at 2022-06-21 23:48:07.798697
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    uri = "user/1/2"
    methods = ["GET"]
    handler = None
    host = None
    strict_slashes = False
    stream = False
    ignore_body = False
    version = 1
    name = None
    unquote = False
    route = router.add(uri, methods, handler, host, strict_slashes, stream, ignore_body,
            version, name, unquote)


# Generated at 2022-06-21 23:48:14.695584
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == []
    assert router.routes_regex == []


# Generated at 2022-06-21 23:48:26.395254
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Arrange
    args = tuple()
    kwargs = {}
    dynamic_routes = {
        'dynamic_routes': [
            ['__x__'],
            ['__x__', '__'],
            ['__'],
            ['__xx__']
        ]}

    # Act
    routers = Router()
    routers.dynamic_routes = dynamic_routes
    for route in routers.dynamic_routes.values():
        if any(
                label.startswith("__") and label not in ALLOWED_LABELS
                for label in route):
            raise SanicException(
                f"Invalid route: {route}. Parameter names cannot use '__'.")

    # Assert
    assert True, "route"

# Generated at 2022-06-21 23:48:35.165290
# Unit test for method finalize of class Router
def test_Router_finalize():
    class FakeRoute:
        def __init__(self):
            self.labels=["__file_uri__", "__user_id__"]
            
    assert ALLOWED_LABELS == ["__file_uri__"]
    router = Router()
    try:
        router.dynamic_routes["my_route"] = FakeRoute()
        router.finalize()
    except SanicException:
        assert True
    else:
        assert False

# Generated at 2022-06-21 23:48:48.074149
# Unit test for method add of class Router
def test_Router_add():
    import unittest
    import types
    class Test(unittest.TestCase):
        def test_1(self):
            router: Router = Router()
            handler: RouteHandler = lambda request, *args, **kwargs: "hello world"
            route: Route = router.add('/', ['GET'], handler)
            self.assertEqual(route.path, '/')
            self.assertEqual(route.methods, ['GET'])
            self.assertEqual(route.name, None)
            self.assertEqual(type(route.handler), types.LambdaType)
            self.assertEqual(route.ctx.ignore_body, False)
            self.assertEqual(route.ctx.stream, False)
            self.assertEqual(route.ctx.hosts, [None])

# Generated at 2022-06-21 23:48:50.963957
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    try:
        router.finalize()
    except:
        # TODO: how to test to raise error?
        pass

# Generated at 2022-06-21 23:49:08.231703
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    r.add("/", ["GET"], None, unquote=True)
    r.add("/<x>", ["GET"], None, unquote=True)
    r.add("/<y>", ["GET"], None, unquote=True)
    r.finalize(None)

# Generated at 2022-06-21 23:49:20.044518
# Unit test for method finalize of class Router
def test_Router_finalize():
    allowed_label = "__file_uri__"

    router = Router()
    dynamic_route = Route(path="/user/<name>", handler=None, methods=["GET"])

# Generated at 2022-06-21 23:49:23.767730
# Unit test for method finalize of class Router
def test_Router_finalize():
    route = Route('/', lambda: '', 'GET')
    router = Router()
    router.dynamic_routes = [route]



# Generated at 2022-06-21 23:49:26.986319
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS

# Generated at 2022-06-21 23:49:33.866206
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        router = Router()
        router.add("/<__name>", [], None)
        router.finalize()
    except Exception as ex:
        assert ex.__class__.__name__ == "SanicException"
        assert "Invalid route: " in ex.__str__()
        assert "Parameter names cannot use" in ex.__str__()
        return
    assert False

if __name__ == '__main__':
    test_Router_finalize()

# Generated at 2022-06-21 23:49:36.070813
# Unit test for method add of class Router
def test_Router_add():
    # write your code
    # make sure that the code you wrote is right
    pass


# Generated at 2022-06-21 23:49:42.756217
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    uri = r'/'
    methods = ["GET"]
    handler = object()
    host = '127.0.0.1'
    strict_slashes = False
    stream = False
    ignore_body = False
    version = '0'
    name = 'index'
    unquote = False
    static = False
    route = router.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)
    assert(route == route)



# Generated at 2022-06-21 23:49:46.188830
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    # Make sure the class of r is Router
    assert isinstance(r, Router)

# Generated at 2022-06-21 23:49:57.333043
# Unit test for method add of class Router
def test_Router_add():
    r = Router()
    r.ctx.app = None
    r.add("/hello/world", ["GET"], None)

    # Adding a route that uses an invalid character should throw an
    # exception.
    _ = False
    try:
        r.add("/hello/worl-d", ["GET"], None)
    except SanicException:
        _ = True
    assert _

    # Adding a route with a label that uses two underscores should throw an
    # exception.
    _ = False
    try:
        r.add("/hello/world__", ["GET"], None)
    except SanicException:
        _ = True
    assert _

    # Adding a route with a label that uses one underscore should not throw an
    # exception.
    _ = True

# Generated at 2022-06-21 23:50:03.521814
# Unit test for method add of class Router
def test_Router_add():
    from sanic.router import Router
    from sanic.sanic import Sanic

    @Sanic.listener('before_server_start')
    async def do_something(app, loop):
        pass
    app = Sanic()
    app.register_listener(do_something, 'before_server_start')

    @app.route('/')
    async def test(request):
        return "Hello"
    app.run(debug=True)