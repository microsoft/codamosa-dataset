

# Generated at 2022-06-21 23:40:08.943427
# Unit test for constructor of class Router
def test_Router():
    router = Router()

# Generated at 2022-06-21 23:40:19.110578
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add(uri='/', methods=('GET', ), handler=None, static=False,
               stream=False, ignore_body=False, version=None, name=None,
               unquote=False, strict_slashes=False, host=None)
    try:
        router.finalize()
    except SanicException as e:
        assert str(e) == "Invalid route: /. Parameter names cannot use '__'."



# Generated at 2022-06-21 23:40:27.762653
# Unit test for method add of class Router
def test_Router_add():
    from sanic_routing.sanic_router import Router as SanicRouter
    def view_func(request):
        return request
    router = SanicRouter()
    try:
        router.add(uri='/test', methods=['GET', 'POST'], handler=view_func)
    except:
        raise AssertionError


# Generated at 2022-06-21 23:40:34.218238
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add('/path/to/route', 'GET', 'RequestHandler', strict_slashes=False,
               stream=False, ignore_body=True, version='1.0', name='route1')
    assert router.find_route_by_view_name('route1')
    assert type(router.find_route_by_view_name('route1')) == tuple
    assert len(router.find_route_by_view_name('route1')) == 2



# Generated at 2022-06-21 23:40:44.943116
# Unit test for method add of class Router
def test_Router_add():
    router = Router()

    route = router.add("/", ["GET"], mock.MagicMock())

    router.add("/path/", ["GET"], mock.MagicMock())
    router.add("/path/", ["POST"], mock.MagicMock())
    router.add("/path/", ["PUT", "PATCH"], mock.MagicMock())

    router.add("/path/<name>/", ["GET"], mock.MagicMock())
    router.add("/path/<name>/", ["POST"], mock.MagicMock())
    router.add("/path/<name>/", ["PUT", "PATCH"], mock.MagicMock())

    router.add("/path/<name>/<id>/", ["GET"], mock.MagicMock())

# Generated at 2022-06-21 23:40:51.934701
# Unit test for method add of class Router
def test_Router_add():
    class SanicApp:
        def generate_unique_name(self, name):
            return name + '_unique'
    uri = "/test"
    methods = ["GET"]
    handler = "test_handler"
    router = Router(SanicApp())
    result = router.add(uri,methods,handler)
    print("router:",result)

# Generated at 2022-06-21 23:41:04.697715
# Unit test for method add of class Router
def test_Router_add():
    # TODO: test for multiple routes
    from sanic.views import CompositionView
    from sanic.views import HTTPMethodView
    from sanic.views import StaticFiles
    import random
    import string

    random_string = ''.join(random.choice(string.ascii_lowercase)
                            for _ in range(8))

    router = Router()
    router.add(uri=random_string, methods=['GET'], handler=HTTPMethodView)
    route = router.find_route_by_view_name(random_string)
    assert route.ctx.ignore_body

    router = Router()
    router.add(uri=random_string, methods=['GET'], handler=CompositionView)
    route = router.find_route_by_view_name(random_string)


# Generated at 2022-06-21 23:41:15.939672
# Unit test for method add of class Router
def test_Router_add():
    from sanic.app import Sanic
    app = Sanic(name='test')
    router = Router(app)
    router.add('/test1/<parameter>', 'GET', RouteHandler) #Defaults
    router.add('/test2/<parameter>', ['GET','POST'], RouteHandler, unquote=True)
    router.add('/test3/<parameter>', ['GET','DELETE'], RouteHandler, unquote=True, static=True)
    router.add('/test4/<parameter>', ['GET','OPTIONS'], RouteHandler, host='127.0.0.1')

# Generated at 2022-06-21 23:41:19.282746
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    # Test whether function Router() is callable.
    assert callable(router)

# Generated at 2022-06-21 23:41:20.813411
# Unit test for constructor of class Router
def test_Router():
    assert Sanic().router.__class__ == Router

# Generated at 2022-06-21 23:41:36.797034
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.response import text
    from sanic import Sanic
    app = Sanic('test')
    router = Router(app)
    @app.route('/test')
    def test(request):
        return text('test')

    try:
        # should raise exception
        router.add('/test/<__test>', 'GET', test)
    except SanicException:
        pass
    @app.route('/test/<__file_uri__>')
    def test2(request):
        return text('test')
    router.add('/test/<__test>', 'GET', test2) # should not raise exception

# Generated at 2022-06-21 23:41:38.830285
# Unit test for constructor of class Router
def test_Router():
    # Test the constructor of class Router
    assert Router


# Generated at 2022-06-21 23:41:45.701914
# Unit test for method finalize of class Router
def test_Router_finalize():
    def handler():
        pass
    class TestRouter(Router):
        pass
    router = TestRouter()
    router.add(uri="/test/<name>", methods=["GET"], handler=handler)
    try:
        router.finalize()
    except Exception:
        raise AssertionError("Failed to finalize router")



# Generated at 2022-06-21 23:41:58.756061
# Unit test for method add of class Router
def test_Router_add():
    from sanic.exceptions import NotFound
    from sanic.exceptions import MethodNotSupported
    from .handler_types import RouteHandler

    # Create router
    router = Router()

    # Create route and add to router
    def handler(request):
        pass
    route = router.add(uri='/uri1', methods=['GET', 'POST'], handler=handler)

    assert isinstance(route, Route)
    assert isinstance(route.ctx.handler, RouteHandler)

    # Retrieve route with valid request
    request = {'path': '/uri1', 'method': 'GET'}
    route, handler, params = router.get(**request)

    assert isinstance(route, Route)
    assert isinstance(route.ctx.handler, RouteHandler)

    # Retrieve route with invalid uri

# Generated at 2022-06-21 23:41:59.260674
# Unit test for method finalize of class Router
def test_Router_finalize():
    pass

# Generated at 2022-06-21 23:42:01.584455
# Unit test for method finalize of class Router
def test_Router_finalize():
    def test_handler(request, response):
        pass
    router1 = Router()
    router1.add('/path', ["GET"], test_handler)
    router1.finalize()

# Generated at 2022-06-21 23:42:05.590734
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    methods = ["GET"]
    handler = None
    uri = "/"
    router.add(uri, methods, handler)
    assert True

test_Router_add()


# Generated at 2022-06-21 23:42:18.174327
# Unit test for constructor of class Router
def test_Router():
    # construct a Router, and then call its methods
    routes = Router(app=None)
    routes.add(uri='/', methods=['get'], handler='/hello')
    routes.get('/', 'get', host=None)
    routes.find_route_by_view_name('name')
    routes.routes_all
    routes.routes_static
    routes.routes_static
    routes.routes_dynamic
    routes.routes_regex
    routes.finalize()
    # check if an exception is raised when the wrong function is called
    try:
        routes.a('/', 'get', host=None) # Here, the function is add, not a
        assert False
    except:
        pass

# Generated at 2022-06-21 23:42:24.785089
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.name_index == {}
    assert router.routes == []
    assert router.routes_regex == {}
    assert router.routes_static == []
    assert router.routes_dynamic == {}

# Generated at 2022-06-21 23:42:34.429464
# Unit test for method add of class Router
def test_Router_add():
    def hello_world(request):
        print('Hello, world')
    handler = hello_world

    class test_router:
        def test(): 
            router = Router()
            route = router.add(
                uri='hello/world',
                methods=['get'],
                handler=handler,
                host=None,
                strict_slashes=False,
                stream=False,
                ignore_body=False,
                version=None,
                name=None,
                unquote=False,
                static=False
            ) 
            assert route.path == '/hello/world'
            assert route.methods['get'] == True
            assert route.ctx.strict is False
            assert route.ctx.stream is False
            assert route.ctx.ignore_body is False

# Generated at 2022-06-21 23:42:51.731629
# Unit test for method add of class Router
def test_Router_add():
    from sanic import Sanic
    from sanic.response import text

    app = Sanic()
    router = Router(app)

    @app.route("/")
    async def index(request):
        return text("OK")

    assert router.get("/", "GET", "")[1] == index

    @app.route("/test")
    def test(request):
        return text("OK")

    assert router.get("/test", "GET", "")[1] == test

    @app.route("/test/1")
    def test1(request):
        return text("OK")

    assert router.get("/test/1", "GET", "")[1] == test1

    @app.route("/test/2/")
    def test2(request):
        return text("OK")


# Generated at 2022-06-21 23:43:01.354959
# Unit test for method add of class Router
def test_Router_add():
    new_Router = Router()
    uri: str = '/'
    methods: List[str] = ['GET']
    handler: RouteHandler = None
    strict_slashes: bool = False
    stream: bool = False
    ignore_body: bool = False
    version: int = 2
    name: str = 'test_name'
    unquote: bool = False
    static: bool = False
    result_route = new_Router.add(uri, methods, handler, None, strict_slashes, stream, ignore_body, version, name, unquote, static)
    assert result_route is not None


# Generated at 2022-06-21 23:43:11.923479
# Unit test for method add of class Router
def test_Router_add():
    r = Router()
    class a:
        async def hello(self, request):
            return True

        async def hi(self, request):
            return True
    r.add('/',['GET'],'a.hello')
    assert r.routes_static[0].handler == 'a.hello'
    r.add('/',['GET'],'a.hi')
    assert r.routes_static[0].handler == 'a.hi'
    r.add('/',['GET'],'a.hello')
    assert len(r.routes_static) == 1
    assert r.routes_static[0].handler == 'a.hello'


# Generated at 2022-06-21 23:43:15.839145
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add('/', ['GET'], lambda x: x)
    assert isinstance(router.routes, dict)

# Generated at 2022-06-21 23:43:22.950280
# Unit test for method finalize of class Router
def test_Router_finalize():

    import pytest
    from sanic import Sanic

    app = Sanic("test_Router_finalize")

    @app.route("/")
    def handler(request):
        return text("OK")

    app.router = Router()
    app.router.static_routes = {"/static":[app.static]}
    app.router.dynamic_routes = {"/handler":[handler]}

    with pytest.raises(SanicException) as excinfo:
        app.router.finalize()
    assert "Parameter names cannot use '__'." in str(excinfo.value)


# Generated at 2022-06-21 23:43:32.258594
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route("/some/url/<p1>", lambda x: x, methods=["GET"])
    route.labels.append("__x")
    router.dynamic_routes["/some/url/<p1>"] = route
    route = Route("/some/url/<p1>", lambda x: x, methods=["GET"])
    route.labels.append("__x")
    router.dynamic_routes["/some/url/<p1>"] = route


# Generated at 2022-06-21 23:43:44.719287
# Unit test for method finalize of class Router
def test_Router_finalize():
    route = Route(
        path="/",
        host=None,
        handler=None,
        methods=["GET"],
        ctx=None,
        name=None,
        strict=False,
        unquote=False,
        requirements=None,
        regex=None,
        regex_names=None,
        regex_strings=None,
        regex_result=None,
    )

    route.labels = (
        "__file_uri__",
        "__normal_uri__",
        "__normal_uri_without_version__",
        "__route_uri__",
    )

    routes_static = {}
    routes_dynamic = {'': route}
    routes_regex = {}

    router = Router()
    router.routes_static = routes_static
    router.routes_

# Generated at 2022-06-21 23:43:46.783679
# Unit test for constructor of class Router
def test_Router():
    Router()

if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-21 23:43:57.026328
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router.route_tree import RouteTree

    def check_dynamic_routes_validate_labels(dynamic_routes):
        for route in dynamic_routes.values():
            if any(
                not label.startswith("__") and label not in ALLOWED_LABELS
                for label in route.labels
            ):
                raise SanicException(
                    f"Invalid route: {route}. Parameter names cannot use '__'."
                )
        return True


# Generated at 2022-06-21 23:44:07.654330
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add(uri='/url',methods='GET',handler='def hola (request):')
    router.add(uri='/api/url',methods='GET',handler='def hola (request):')
    router.add(uri='/url',methods='PUT',handler='def hola (request):')
    router.add(uri='/url',methods='POST',handler='def hola (request):')
    router.add(uri='/url/{id}',methods='DELETE',handler='def hola (request):')
    # There aren't handler for a OPTIONS method in the Router
    assert router.get('/url','OPTIONS',None)[1] == None

# Generated at 2022-06-21 23:44:23.267575
# Unit test for method add of class Router
def test_Router_add():
    r = Router()
    rr = r.add('/',['GET', 'POST'], lambda request:\
     request.text())
    assert rr.ctx.ignore_body == False
    assert rr.ctx.stream == False
    assert rr.ctx.hosts == [None]


# Generated at 2022-06-21 23:44:27.079205
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == ['GET', 'HEAD', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS', 'TRACE']


# Generated at 2022-06-21 23:44:33.923809
# Unit test for method add of class Router
def test_Router_add():
    r = Router()
    assert isinstance(r, BaseRouter) == True

    uri = '/'
    methods = ['GET']
    handler = lambda: None
    host = '127.0.0.1'
    strict_slashes = False
    stream = False
    ignore_body = False
    version = '1.0'
    name = 'test'
    unquote = True
    result = r.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote)
    assert isinstance(result, Route) == True

# Generated at 2022-06-21 23:44:44.955077
# Unit test for method finalize of class Router
def test_Router_finalize():
    BaseRouter.DEFAULT_METHOD = "GET"
    BaseRouter.ALLOWED_METHODS = HTTP_METHODS

    def handler(request):
        pass
    
    router = Router()
    router.add(uri="test_Router_finalize", methods = ["GET"], handler=handler, host=None, strict_slashes=False, stream=False, ignore_body=False, version=None, name=None, unquote=False, static=False)
    try:
        router.finalize()
    except Exception as e:
        print(e)



# Generated at 2022-06-21 23:44:54.393130
# Unit test for method finalize of class Router
def test_Router_finalize():
    test = Router()
    test.add_route(
        uri="/test_a/<test_a>",
        methods={"GET", "POST"},
        handler="handler_a",
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version="test_version",
        name="test_name",
        unquote=False,
        static=False,
    )
    test.add_route(
        uri="/test_b/<test_b>",
        methods={"GET", "POST"},
        handler="handler_b",
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version="test_version",
        name="test_name",
        unquote=False,
        static=False,
    )
   

# Generated at 2022-06-21 23:45:05.654742
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add(uri="test_Router_add", methods=["GET"], handler=print)
    assert router._router.trees["GET"] is not None
    assert router._router.trees["GET"][False].children is not None
    assert len(router._router.trees["GET"][False].children) == 1
    assert router._router.trees["GET"][False].children["test_Router_add"] is not None
    assert router._router.dynamic_routes["test_Router_add"] is not None
    assert isinstance(router._router.dynamic_routes["test_Router_add"], Route)


# Generated at 2022-06-21 23:45:14.850484
# Unit test for method finalize of class Router
def test_Router_finalize():
    _routes = {}
    _routes_static = {}
    _routes_dynamic = {}
    _routes_regex = {}

    _method_index = {}
    _name_index = {}

    _host_index = {}

    _request_handler = None
    _default_method = None
    _allowed_methods = None

    class MockRouter(Router):
        def __init__(self):
            super().__init__()
            self.routes = _routes
            self.static_routes = _routes_static
            self.dynamic_routes = _routes_dynamic
            self.regex_routes = _routes_regex

            self.method_index = _method_index

# Generated at 2022-06-21 23:45:15.872425
# Unit test for constructor of class Router
def test_Router():
    Router()

# Generated at 2022-06-21 23:45:16.516870
# Unit test for constructor of class Router
def test_Router():
    assert True

# Generated at 2022-06-21 23:45:17.655778
# Unit test for method add of class Router
def test_Router_add():
    pass


# Generated at 2022-06-21 23:45:45.708810
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.constants import HTTP_METHODS
    from sanic.exceptions import SanicException

    class Handler:
        def __init__(self, name):
            self.name = name

    class Route:
        def __init__(self, labels, path, name=None):
            self.labels = labels
            self.path = path

        def __repr__(self):
            return f"<{self.path}>"

    # Test with invalid route
    dynamic_routes = {
        (("GET", ), "/a/{b}/c"): Route(("a", "__b__", "c"), path="/a/{b}/c")
    }

    router = Router(dynamic_routes=dynamic_routes)

# Generated at 2022-06-21 23:45:46.378160
# Unit test for constructor of class Router
def test_Router():
    assert Router()

# Generated at 2022-06-21 23:45:47.794969
# Unit test for constructor of class Router
def test_Router():
    assert issubclass(Router, BaseRouter)


# Generated at 2022-06-21 23:45:49.310060
# Unit test for constructor of class Router
def test_Router():
    with pytest.raises(SanicException):
        Router()

# Generated at 2022-06-21 23:45:55.939291
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import json
    from sanic.router import Router

    app = Sanic('test_Router_finalize')

    @app.route('/', methods=['GET'])
    async def test_no_param(request: Request) -> json:
        return json({})

    @app.route('/<my_id>', methods=['GET'])
    async def test_with_param(request: Request, my_id: str) -> json:
        return json({"my_id": my_id})


# Generated at 2022-06-21 23:45:59.853739
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r.DEFAULT_METHOD == 'GET'
    assert r.ALLOWED_METHODS == ['OPTIONS', 'HEAD', 'GET', 'POST', 'PUT', 'PATCH', 'DELETE']

# Generated at 2022-06-21 23:46:12.730591
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, BaseRouter)
    assert isinstance(router.DEFAULT_METHOD, str)
    assert isinstance(router.ROUTES_STATIC, str)
    assert isinstance(router.ROUTES_REGEX, str)
    assert isinstance(router.ROUTES_DYNAMIC, str)
    assert isinstance(router.ROUTE_NAMES, str)
    assert isinstance(router.route_path, str)
    assert isinstance(router.dynamic_routes, dict)
    assert isinstance(router.name_index, dict)
    assert isinstance(router.static_routes, dict)
    assert isinstance(router.regex_routes, dict)



# Generated at 2022-06-21 23:46:24.094586
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route(
        path="/",
        handler=None,
        methods=None,
        strict_slashes=False,
        name="",
        unquote=False,
        ctx=router.ctx,
    )
    setattr(route, "labels", {'__file_uri__': 'file.txt'})
    setattr(router.ctx, "app", "app")
    assert router.finalize() == None
    route.labels = {'__file_uri__': 'file.txt', '__user_id__': 'random_id'}
    assert router.finalize() == None
    router.dynamic_routes = {'dynamic': route}
    assert router.finalize() == None
    # TODO: assertSanicException
    # assert router

# Generated at 2022-06-21 23:46:35.626659
# Unit test for method finalize of class Router
def test_Router_finalize():
        """
        Method test_Router_finalize()
        """
        route_list = []
        path = '/'
        method = 'GET'
        host = 'test'
        handler = 'test'
        param_list = [
            {'uri': path, 'methods': [method], 'handler': handler, 'host': host, 'name': 'test'}
        ]
        route = Route(path, method, handler)
        route.ctx.name = 'test'
        route.ctx.hosts = [host]
        route_list.append(route)
        router = Router()
        router.dynamic_routes = dict()
        for p in param_list:
            route = Route(p['uri'], p['methods'], p['handler'])
            route.ctx.name = p['name']

# Generated at 2022-06-21 23:46:45.098653
# Unit test for method add of class Router
def test_Router_add():
    uri = "/test"
    methods = ["GET", "POST", "OPTIONS"]
    handler = RouteHandler
    host = ["localhost:8000"]
    strict_slashes = False
    stream = False
    ignore_body = False
    version = 1.0
    name = "test name"
    unquote = True
    static = False

    _Router = Router()

    _Router.add(
        uri,
        methods,
        handler,
        host,
        strict_slashes,
        stream,
        ignore_body,
        version,
        name,
        unquote,
        static
    )

    assert _Router.routes_all.keys() == ['/test']
    assert _Router.routes_dynamic.keys() == ['/test']
    assert _Router

# Generated at 2022-06-21 23:47:23.366916
# Unit test for method finalize of class Router
def test_Router_finalize():
    class RouterException(Exception):
        pass
    router = Router(context=None)
    router.dynamic_routes = {
        '/s/<__something>/<__something_else>': None
    }
    with pytest.raises(RouterException):
        router.finalize()
# End test

# Generated at 2022-06-21 23:47:25.072112
# Unit test for constructor of class Router
def test_Router():
  router = Router()
  assert isinstance(router, BaseRouter)


# Generated at 2022-06-21 23:47:36.733473
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic_routing.router import Router
    from sanic.exceptions import SanicException
    from sanic.response import text
    router = Router()
    router.add('/test', methods=['GET'], handler=text('test'))
    router.finalize()
    # No exception raised
    assert type(router.find_route_by_view_name('test')) == tuple
    router.add('/test/<id>', methods=['GET'], handler=text('test'))
    try:
        router.finalize()
    except SanicException as e:
        # print(type(e), e)
        assert str(e) == "Invalid route: <Route GET /test/<id>: text()>. Parameter names cannot use '__'."

# Generated at 2022-06-21 23:47:50.092752
# Unit test for method add of class Router
def test_Router_add():
    r = Router()
    def func():
        pass
    # Test passing the wrong type of input
    exception = None
    try:
        r.add("/testing", ["GET", "POST"], func, host='127.0.0.1')
    except Exception as e:
        exception = e
    assert type(exception) == SanicException

    # Test passing the correct type of input
    r.add("/testing", "GET", func, host='127.0.0.1')
    assert r[0].labels == ['__file_uri__']
    assert r[0].ctx.ignore_body == False
    assert r[0].ctx.stream == False
    assert r[0].ctx.hosts == ['127.0.0.1']
    assert r[0].ctx.static == False


# Generated at 2022-06-21 23:47:52.179792
# Unit test for constructor of class Router
def test_Router():
    # Test the Router
    assert Router()
    try:
        assert Router(host="")
        assert False
    except:
        assert True
    assert Router(host=None)

# Generated at 2022-06-21 23:47:53.489473
# Unit test for method add of class Router
def test_Router_add():
    pass



# Generated at 2022-06-21 23:47:54.711196
# Unit test for method add of class Router
def test_Router_add():
    pass


# Generated at 2022-06-21 23:48:02.778568
# Unit test for method add of class Router
def test_Router_add():
    import functools

    # param: test_Router_add, path: '', method: 'GET', host: '', strict_slashes: '', stream: '', ignore_body: '', version: '', name: '', unquote: '', static: ''
    # Start of test code
    # Create a Router object
    router = Router()

    # Create a handler function
    def handler_func():
        pass

    # Create a list of methods
    methods = ['GET', 'POST', 'OPTIONS']

    # Test add method

# Generated at 2022-06-21 23:48:13.143148
# Unit test for method add of class Router
def test_Router_add():
    # test base case
    router = Router("/")
    router.add(
        uri = "/test_uri",
        methods=["GET"],
        handler = None,
        host = None,
        strict_slashes = False,
        stream = False,
        ignore_body = False,
        version = None,
        name = None,
        unquote = False,
        static = False
    )
    assert router.routes_all[0].uri == "/test_uri"
    assert router.routes_all[0].methods == {"GET"}
    assert router.routes_all[0].ctx.hosts == [None]
    assert router.routes_all[0].ctx.stream == False
    assert router.routes_all[0].ctx.ignore_body == False

# Generated at 2022-06-21 23:48:13.589634
# Unit test for method add of class Router
def test_Router_add():
    pass

# Generated at 2022-06-21 23:49:26.863998
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Put your test code here
    print("\nTest case 1\n")
    # Input:
    # Dynamic_routes = {'/a/b/<c>/d/e/<f>': <test1>, '/a/b/<c>/d/e/<g>': <test2>}
    # Output:
    # It should finalize the dynamic_route dictionary
    # AssertionError: Invalid route: Route(path='/a/b/<c>/d/e/<f>', handler=<function test1 at 0x7f7bfa796580>, method='GET', name=None, strict=False, unquote=False). Parameter names cannot use '__'.

    x = Router(ctx=None)

# Generated at 2022-06-21 23:49:32.956060
# Unit test for method add of class Router
def test_Router_add():
    from sanic.handler import ErrorHandler

    # Arrange
    router = Router(ErrorHandler)

    # Act
    route = router.add("/", ["GET", "POST"], lambda r: "response")

    # Assert
    assert route.path == "/"
    assert route.methods == ["GET", "POST"]
    assert route.handler == "<lambda>"
    assert route.name == None



# Generated at 2022-06-21 23:49:35.304273
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    # Method add is tested indirectly in the following tests
    pass


# Generated at 2022-06-21 23:49:42.594627
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.exceptions import SanicException
    from sanic.router import Router

    router1 = Router()

    router1.add("/", "GET", lambda r: print("/"), "__file_uri__")
    router1.add("/", "GET", lambda r: print("/"))

    assert True == router1.finalize()

    router2 = Router()

    try:
        router2.add("/", "GET", lambda r: print("/"), "__file")
        assert False
    except SanicException as e:
        assert "parameter name" in str(e)


# Generated at 2022-06-21 23:49:54.422571
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    router = Router()

    route_info_one = ("/foo/{faa}", [["GET"]], None)
    route_info_two = ("/foo/{__faa}", [["GET"]], None)
    route_info_three = ("/foo/{__file_uri__}", [["GET"]], None)
    router.add(*route_info_one)

    with pytest.raises(SanicException):
        router.add(*route_info_two)

    router.add(*route_info_three)

    def my_function(a, b):
        pass

    router.add("/", ["GET"], my_function, stream=True)

    assert len(router.routes_static) == 1
    assert len(router.routes_dynamic)

# Generated at 2022-06-21 23:50:05.113154
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    uri = "/test/test_add"
    methods = ["GET"]
    handler = "test_handler"
    host = "localhost"
    strict_slashes = True
    stream = False
    ignore_body = True
    version = 1
    name = "test_name"
    unquote = False

    route = router.add(uri=uri,
                       methods=methods,
                       handler=handler,
                       host=host,
                       strict_slashes=strict_slashes,
                       stream=stream,
                       ignore_body=ignore_body,
                       version=version,
                       name=name,
                       unquote=unquote)
    assert isinstance(route, Route)
    assert route.path == uri
    assert route.handler == handler
    #not sure how to check attribute
    #