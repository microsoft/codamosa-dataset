

# Generated at 2022-06-21 23:40:23.830667
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        route = Route(
                path="/bad/route",
                handler=None,
                methods=["GET"],
                labels={"__test__": "foo"},
            )
        router = Router()
        router.dynamic_routes["/bad/route"] = route
        router.finalize()
    except Exception as e:
        assert e.args[0] == "Invalid route: Route(/bad/route, GET). Parameter names cannot use '__'."

# Generated at 2022-06-21 23:40:30.319788
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add('/test/<parameter>', ['GET', 'POST', 'OPTIONS'], "test_handler", host=None, strict_slashes=False, stream=False, ignore_body=False, version=None, name=None, unquote=False)
    test_routes = router.routes_all
    assert test_routes is not None


# Generated at 2022-06-21 23:40:43.561843
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.exceptions import SanicException

    def test_func():
        pass
    # param name __is not allowed
    r = Route(
        "/", [], test_func, [], method="GET", dyna_args=["__is"]
    )
    r.routable = True
    router = Router()
    router.routes_dynamic = {0: r}
    with pytest.raises(SanicException):
        router.finalize()
    # param name __file_uri__ is allowed
    r = Route(
        "/", [], test_func, [], method="GET", dyna_args=["__file_uri__"]
    )
    r.routable = True
    router = Router()
    router.routes_dynamic = {0: r}

# Generated at 2022-06-21 23:40:46.657033
# Unit test for method add of class Router
def test_Router_add():
    router = Router()

    def handler(request):
        return "handler"

    router.add("uri", ["methods"], handler)

# Generated at 2022-06-21 23:40:47.255391
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router


# Generated at 2022-06-21 23:40:58.874105
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    def handler(*args, **kwargs):
        raise NotImplementedError

    uri = "/uri"
    methods = ["GET", "POST", "OPTIONS"]
    host = "www.example.com"
    strict_slashes = False
    stream = False
    ignore_body = False
    version = 1.0
    name = "name"
    unquote = False
    static = False

    # test
    route = router.add(uri, methods, handler, host, strict_slashes, stream,
            ignore_body, version, name, unquote, static)

    # test correct route add
    assert route
    assert route.path == "/v1.0/uri"
    assert route.handler == handler
    assert route.methods == methods
    assert route.name == name

# Generated at 2022-06-21 23:41:00.875858
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert isinstance(r, Router)


# Generated at 2022-06-21 23:41:05.121681
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    @router.add("hello", "GET", None)
    def hello(request):
        return 'hello'
    test_case = [
        {
            "input": "hello",
            "output": ('hello', hello)
        },
    ]
    for case in test_case:
        assert router.find_route_by_view_name(case["input"]) == case["output"]


# Generated at 2022-06-21 23:41:13.202628
# Unit test for method add of class Router
def test_Router_add():
    from sanic.exceptions import MethodNotSupported

    router = Router()
    router.add('/', ['GET'], lambda: "hello")
    router.add('/', ['POST'], lambda: "hi")

    assert router.get('/', 'GET')[1]() == 'hello'
    assert router.get('/', 'POST')[1]() == 'hi'

    with pytest.raises(MethodNotSupported) as e:
        router.get('/', 'PUT')

# Generated at 2022-06-21 23:41:26.566007
# Unit test for constructor of class Router
def test_Router():
    # Create a new instance of class Router
    router = Router()

    # Create some mock variables
    path, method, host = 1, 1, 1
    route, handler, kwargs = 1, 1, 1

    # Check if the all required properties of the class exist and have the
    # correct types
    assert isinstance(router.DEFAULT_METHOD, str)
    assert isinstance(router.ALLOWED_METHODS, tuple)

    # Check if the all functions of the class exist and have the correct types
    assert isinstance(router._get, Callable)
    assert isinstance(router.get, Callable)
    assert isinstance(router.add, Callable)
    assert isinstance(router.find_route_by_view_name, Callable)

# Generated at 2022-06-21 23:41:33.286870
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router) == True


# Generated at 2022-06-21 23:41:35.397607
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)
    assert isinstance(router, BaseRouter)


# Generated at 2022-06-21 23:41:38.831066
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add(uri='', methods='GET', handler='')


# Generated at 2022-06-21 23:41:41.615621
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    assert router.add("/", "GET", lambda a: a)
    assert router.add("/", ["GET"], lambda a: a)


# Generated at 2022-06-21 23:41:47.271532
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.ROUTER_CACHE_SIZE == 1024
    assert router.ALLOWED_LABELS == ("__file_uri__",)

if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-21 23:42:00.326334
# Unit test for method add of class Router
def test_Router_add():
    # Instantiation of class Router
    router = Router()
    # Get add method of class Router
    add = router.add
    # Mock call of method add of class Router
    add("uri", [], lambda: None, version = "version", name = "name", static = False, unquote = True)
    add("uri", [], lambda: None, version = "version", name = "name", static = False, unquote = False)
    add("uri", [], lambda: None, version = "version", name = "name", static = True, unquote = False)
    add("uri", [], lambda: None, version = "version", name = "name", static = True, unquote = True)
    add("uri", [], lambda: None, name = "name", static = False, unquote = True)

# Generated at 2022-06-21 23:42:02.291523
# Unit test for constructor of class Router
def test_Router():
    router = Router(None, None)
    assert router is not None


# Generated at 2022-06-21 23:42:05.935074
# Unit test for constructor of class Router
def test_Router():
    Router()
    try:
        assert True
    except AssertionError:
        print("Test of Router is failed")
    else:
        print("Test of Router is completed successfully")


# Generated at 2022-06-21 23:42:18.813164
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest

    router = Router()
    route = Route(
        uri="/",
        methods=["GET"],
        handler=None,
        host=None,
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version=2,
        name="",
        unquote=False,
        static=False,
        labels=["__file_uri__"],
    )
    route._compile_uri_pattern()
    router.dynamic_routes["/"] = route


# Generated at 2022-06-21 23:42:26.094149
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    try:
        router.get(1, 2, 3) # type: ignore
        router.base_url_for(1, 2) # type: ignore
        router.add(1, 2, 3, 4) # type: ignore
    except Exception:
        raise

# Generated at 2022-06-21 23:42:32.060766
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-21 23:42:42.955270
# Unit test for method finalize of class Router
def test_Router_finalize():
    """ Unit test for method finalize of class Router """
    from sanic.sanic import Sanic

    def dummy_route_handler(_):
        pass

    # This is OK
    router = Router()
    router.add(
        "/", ["GET"], dummy_route_handler, host="host", strict_slashes=True,
        unquote=True,
    )
    router.add(
        "/", ["POST"], dummy_route_handler, host="host", strict_slashes=True,
        unquote=True,
    )

    # This is not OK
    router = Router()
    router.add(
        "/__hello/{any_param}", ["GET"], dummy_route_handler, host="host",
        strict_slashes=True,
        unquote=True,
    )

# Generated at 2022-06-21 23:42:53.750204
# Unit test for method add of class Router
def test_Router_add():
    from sanic.app import Sanic
    app = Sanic('test_Router_add')
    uri = 'test'
    methods = ['GET', 'POST']
    async def async_test():
        return True
    handler = async_test
    host = 'test.com'
    strict_slashes = True
    stream = True
    ignore_body = True
    version = 2
    name = 'test_name'
    unquote = True
    static = True
    router = Router(app)
    routes = router.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)
    assert routes[0].methods == methods
    assert routes[0].handler == handler
    assert routes[0].host == host
    assert routes[0].ctx.ignore

# Generated at 2022-06-21 23:43:01.912140
# Unit test for method finalize of class Router
def test_Router_finalize():

    from sanic.router import Router

    from sanic.constants import HTTP_METHODS

    from sanic.models.handler_types import RouteHandler

    from sanic.server import HttpProtocol

    import sys


# Generated at 2022-06-21 23:43:13.291301
# Unit test for method finalize of class Router

# Generated at 2022-06-21 23:43:14.523032
# Unit test for method add of class Router
def test_Router_add():
    # test function
    async def async_func(request):
        pass



# Generated at 2022-06-21 23:43:23.407838
# Unit test for method add of class Router
def test_Router_add():
    a = Router()
    uri = "/user/<id>"
    methods = ["GET","POST"]
    handler = list
    host = "sanic.com"
    strict_slashes = False
    stream = True
    ignore_body = True
    version = "1.0"
    name = "user_details"
    unquote = True
    static = False

    b = a.add(uri,methods,handler,host,strict_slashes,stream,ignore_body,version,name,unquote,static)
    assert b.path == '/user/<id>'
    assert b.handler == [].__class__.__name__
    # assert b.methods == ['GET','POST']
    assert b.name is None
    assert b.strict is False
    assert b.unquote is True
   

# Generated at 2022-06-21 23:43:34.760753
# Unit test for method finalize of class Router
def test_Router_finalize():
    from .sanic_route import SanicRoute
    from .router_handler import RouterHandler

    def test():
        pass
    
    def test2():
        pass
    
    def test3():
        pass

    test_route = SanicRoute('/test/<param1>/<param2>', test, ["GET"], False, False, False)
    test_route2 = SanicRoute('/test/<param1>/<param2>', test2, ["GET"], False, False, False)
    test_route3 = SanicRoute('/test/<param1>/<param2>', test3, ["GET"], False, False, False)


# Generated at 2022-06-21 23:43:41.433551
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        router = Router()

        router.add(
            uri="/", methods=['GET'], handler=None, strict_slashes=False, unquote=False
        )

    except SanicException:
        print("SanicException: Invalid route: /. Parameter names cannot use '__'.")

# Run the unit test
test_Router_finalize()

# Generated at 2022-06-21 23:43:44.553428
# Unit test for method add of class Router
def test_Router_add():
	router = Router()
	assert router.add("/")

# Generated at 2022-06-21 23:43:55.357707
# Unit test for method add of class Router
def test_Router_add():
    router = Router()

    @router.add("/")
    def handler1(request):
        return text("handler1")

    assert handler1 == router.get("/", "GET")[1]
    router.add("/", handler=handler1, methods=["GET"])
    assert handler1 == router.get("/", "GET")[1]

    def handler2(request):
        return text("handler2")

    router.add("/", handler=handler2, methods=["GET"])
    assert handler2 == router.get("/", "GET")[1]



# Generated at 2022-06-21 23:44:06.579018
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Default
    router = Router()
    router.add(uri="/", methods=["GET"], handler=None, host=None)
    router.add(
        uri="/",
        methods=["GET"],
        handler=None,
        host=None,
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version=None,
        name=None,
        unquote=False,
        static=False,
    )
    router.finalize()

    # User
    router = Router()
    router.add(uri="/", methods=["GET"], handler=None, host=None)

# Generated at 2022-06-21 23:44:13.529797
# Unit test for method add of class Router
def test_Router_add():
    def handler():
        pass

    r = Router()
    r.add('/test', ['GET', 'POST'], handler)
    routes = r.routes
    assert len(routes) == 1
    assert routes[0].path == '/test'
    assert routes[0].methods == ['POST', 'GET']
    
    

# Generated at 2022-06-21 23:44:20.727286
# Unit test for method finalize of class Router
def test_Router_finalize():
    path = "/:name"
    methods = ["GET"]
    handler = lambda : None
    static = False
    r = Route(path, methods, handler, static)
    routes = {
        r: None
    }
    router = Router(routes)
    router.finalize()

# Generated at 2022-06-21 23:44:22.341187
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-21 23:44:23.769610
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}


# Generated at 2022-06-21 23:44:26.413843
# Unit test for method finalize of class Router
def test_Router_finalize():
    from unittest import mock
    from sanic import Sanic

    app = Sanic()
    router = Router(app)

    router.finalize()



# Generated at 2022-06-21 23:44:27.036901
# Unit test for method add of class Router
def test_Router_add():
    pass

# Generated at 2022-06-21 23:44:34.130922
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    Test if `Router.finalize` raises the appropriate exception when an invalid route is used.
    """
    from sanic.router import Route

    route = Route(
        path="path",
        handler="handler",
        methods=["GET"]
        )
    route.labels = ["__invalid__"]

    router = Router('sanic')
    router.method_routes = {'GET':[route]}

    # Check that exception is thrown
    try:
        Router.finalize(router)
    except SanicException:
        pass
    else:
        assert False

# Generated at 2022-06-21 23:44:47.127946
# Unit test for constructor of class Router
def test_Router():
    from sanic_routing.router import Router
    from sanic.parser import parse_url_path
    from sanic.request import Request
    from sanic.response import text
    router = Router()
    async def my_handler(request):
        return text("OK")
    router.add("/path/to/the/thing", ["GET"], my_handler)
    path = "/path/to/the/thing"
    method = "GET"
    parsed_path = parse_url_path(path)

# Generated at 2022-06-21 23:44:57.553425
# Unit test for method add of class Router
def test_Router_add():
    r = Router()
    r.add('/', ['GET'], print)
    r.add('/', ['POST'], print)



# Generated at 2022-06-21 23:45:09.711146
# Unit test for method add of class Router
def test_Router_add():
    # Example 1
    # ------------
    # Instantiate object
    router = Router()

    router.add('/url', ['GET'], None)

    # Example 2
    # ------------
    # Instantiate object
    router = Router()

    router.add('/url', ['GET'], None, strict_slashes=True)

    # Example 3
    # ------------
    # Instantiate object
    router = Router()

    router.add('/users', ['GET', 'HEAD'], None, stream=False)

    # Example 4
    # ------------
    # Instantiate object
    router = Router()

    router.add('/users', ['GET'], None, host='domain.com')

    # Example 5
    # ------------
    # Instantiate object
    router = Router()


# Generated at 2022-06-21 23:45:21.735426
# Unit test for method add of class Router
def test_Router_add():
    from sanic.response import json

    uri = "/uri"
    methods = ["GET"]
    handler = json({"data": "data"})
    host = None
    strict_slashes = False
    stream = False
    ignore_body = False
    version = "v1"
    name = None
    unquote = False
    static = False

    # Test case with required field
    router = Router()
    router.add(uri, methods, handler)

    assert router.get("/uri", "GET", host)

    # Test case with optional field
    router = Router()
    router.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)

    assert router.get("/uri", "GET", host)

# Generated at 2022-06-21 23:45:32.042073
# Unit test for method add of class Router
def test_Router_add():
    from sanic.response import json, text
    from sanic.request import Request
    from sanic.server import serve
    from sanic import Sanic

    app = Sanic('test_Router_add')
    app.router = Router(ctx=app)

    @app.route('/')
    async def handler(request):
        return json({'test': 'test'})

    # app.add_route is a wrapper of app.router.add
    app.router.add(uri='/test', methods=['GET'], handler=text('pong'))

    request, response = serve(app, 'GET', '/')
    assert response.status == 200
    assert response.text == 'pong'

    request, response = serve(app, 'GET', '/test')
    assert response.status == 200

# Generated at 2022-06-21 23:45:42.948463
# Unit test for method finalize of class Router
def test_Router_finalize():
    from .mock_router import MockRouter
    from .mock_request import MockRequest

    # Bad route with double underscore.
    route = MockRouter(
        [
            ("/hello/<__user>", "get", None, None)
        ],
        [
            ("/hello/<user>", "get", None, None)
        ],
    )
    request = MockRequest(method="GET", path="/hello/bob", host=None)

    # This fails badly.
    try:
        route.finalize()
    except SanicException:
        # Okay, this is expected.
        return
    # Otherwise, this is wrong.
    assert False, 'Finalize did not raise an exception, it should have.'

# Generated at 2022-06-21 23:45:45.368064
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS

# Generated at 2022-06-21 23:45:48.168797
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    class MockRoute:
        def __init__(self, labels):
            self.labels = labels

    from unittest.mock import Mock
    mock_router = Mock(spec=Router)
    mock_router._dynamic_routes = {'mock_route': MockRoute(['__file_uri__', '__some_uri__'])}
    mock_router.finalize()

# Generated at 2022-06-21 23:45:55.524320
# Unit test for method add of class Router
def test_Router_add():
    from sanic import Sanic
    from sanic.response import text
    from sanic.debug import DummyObject
    import sys

    def test_output():
        app = Sanic("test_Router_add")
        router = Router()
        try:
            router.add("/question/<question>", "GET", text, name="test_add")
        except Exception as error:
            print("Error: {}".format(error))

    try:
        test_output()
    except Exception:
        print("Exception in user code:")
        print("-" * 60)
        traceback.print_exc(file=sys.stdout)
        print("-" * 60)
    else:
        print("test_Router_add ran successfully.")
        DummyObject("test_Router_add ran successfully.")

# Generated at 2022-06-21 23:46:02.725165
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    # Test for successful run
    router = Router()
    for route in router.dynamic_routes.values():
        if any(
            label.startswith("__") and label not in ALLOWED_LABELS
            for label in route.labels
        ):
            raise SanicException(
                f"Invalid route: {route}. Parameter names cannot use '__'."
            )


# Generated at 2022-06-21 23:46:15.219593
# Unit test for method add of class Router
def test_Router_add():
    import unittest
    from io import StringIO
    from unittest.mock import patch

    from sanic.router import Router
    from sanic.constants import HTTP_METHODS
    from sanic.exceptions import MethodNotSupported, NotFound
    from sanic.models.handler_types import RouteHandler

    from test.constants import TEST_HOST, TEST_PATH, TEST_URI, TEST_VIEW_NAME
    from test.mock_handler import mock_handler

    class TestRouter(unittest.TestCase):
        @patch("sys.stdout", new_callable=StringIO)
        def test_Router_output(self, mock_stdout):
            """
            Unit test for Router class output method
            """
            router = Router()
            router.output()
            assert mock_stdout.get

# Generated at 2022-06-21 23:46:38.227551
# Unit test for constructor of class Router
def test_Router():
    from sanic import Sanic

    router_default = Router()
    assert isinstance(router_default, Router)
    assert router_default.DEFAULT_METHOD == "GET"
    assert router_default.ROUTER_CACHE_SIZE == 1024
    assert router_default.ctx == None

    app = Sanic(__name__)
    router = Router(app)
    assert isinstance(router, Router)
    assert router.DEPRECATED == False
    assert router.DEFAULT_METHOD == "GET"
    assert router.ROUTER_CACHE_SIZE == 1024
    assert router.ctx == app


# Generated at 2022-06-21 23:46:43.461237
# Unit test for method add of class Router
def test_Router_add():
    uri = '/'
    methods = list(map(str.upper, HTTP_METHODS))
    handler = lambda request: 'hello'
    router = Router()
    router.add(uri, methods, handler)
    assert len(router.routes) == len(methods)
    for method in methods:
        assert uri in router.uri_routes[method]


# Generated at 2022-06-21 23:46:44.085593
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router

# Generated at 2022-06-21 23:46:55.739442
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic_routing.router import Router
    from sanic_routing.exceptions import SanicException
    router = Router()
    route = Route(handler=None, strict=True, methods={"GET"},
                  path="/", labels=[], requirements={"host": None})
    route.labels = ["param1", "__a_good_param__", "__a_bad_param__"]
    router.add_route(route)
    # The unit test should test the actual exception type
    # check the issue https://github.com/SynthesisLab/sanic-routing/issues/33
    try:
        router.finalize()
    except SanicException:
        assert True
    else:
        assert False


# Generated at 2022-06-21 23:47:07.234492
# Unit test for method add of class Router
def test_Router_add():
    from sanic.response import json


    router = Router()

    handler = json({"test": 1})
    router.add("/test", ["GET"], handler)
    assert router.routes_dynamic

    router = Router()
    router.add("/test/", ["GET"], handler)
    assert router.routes_dynamic

    router = Router()
    router.add("/test", ["GET", "POST"], handler)
    assert router.routes_dynamic

    router = Router()
    router.add("/test", ["GET", "POST"], handler, host="example.com")
    assert router.routes_dynamic

    router = Router()
    router.add("/test", ["GET", "POST", "OPTIONS"], handler)
    assert router.routes_dynamic

#

# Generated at 2022-06-21 23:47:17.752942
# Unit test for method add of class Router
def test_Router_add():
    from sanic.request import Request
    from sanic import Sanic
    from sanic.response import HTTPResponse

    def handler(request: Request, **kwargs: Dict[str, Any]) -> HTTPResponse:
        return HTTPResponse(body=b"OK!")

    app = Sanic(__name__)

    Router.add(uri='/', methods=['GET'], handler=handler, host=None, strict_slashes=False, stream=False, ignore_body=False, version=None, name=None, unquote=False, static=False)
    assert len(app.router.routes_all) == 1



# Generated at 2022-06-21 23:47:25.154654
# Unit test for constructor of class Router
def test_Router():
    router = Router(str, [])
    assert router.dynamic_routes == {}
    assert router.static_routes == {}
    assert router.regex_routes == []
    assert router.strict_slashes == False
    assert router.routes == {}
    assert router.routes_all == router.routes
    assert router.routes_static == router.static_routes
    assert router.routes_dynamic == router.dynamic_routes
    assert router.routes_regex == router.regex_routes


# Generated at 2022-06-21 23:47:29.435616
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    with pytest.raises(SanicException):
        router.add(uri="/<__user_id>", methods=['GET'], handler=None)
    print('Unit test for method finalize of class Router finished')

if __name__=='__main__':
    test_Router_finalize()

# Generated at 2022-06-21 23:47:31.421339
# Unit test for constructor of class Router
def test_Router():
    # testing
    r = Router()
    assert isinstance(r,Router)


# Generated at 2022-06-21 23:47:34.040805
# Unit test for constructor of class Router
def test_Router():
    router = Router()


# Generated at 2022-06-21 23:48:10.364203
# Unit test for method add of class Router
def test_Router_add():
    from sanic_routing.router import Router
    uri="/"
    methods=("GET",)
    handler=None
    host=None
    strict_slashes=False
    stream=False
    ignore_body=False
    version=None
    name=None
    unquote=False
    static=False
    route=Router().add(uri,methods,handler,host,strict_slashes,stream,ignore_body,version,name,unquote,static)
    assert isinstance(route,Route)
    
    
    
    

# Generated at 2022-06-21 23:48:22.262575
# Unit test for constructor of class Router
def test_Router():
    # test init
    router_init_test = Router(Router.ctx, Router.implementation)

# Generated at 2022-06-21 23:48:30.420462
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic_routing.router import Router
    from sanic_routing.exceptions import SanicException
    self = Router()
    self.routes_dynamic = {
        '1': (Route(path='/users', handler='handler', methods=['GET'], name='users', labels=['__file_uri__']),),
        '2': (Route(path='/users/{user_id}', handler='handler', methods=['GET'], name='user_detail', labels=['__file_uri__']),),
        '3': (Route(path='/users/{user_id}', handler='handler', methods=['POST'], name='user_edit', labels=['__file_uri__']),),
    }
    with pytest.raises(SanicException):
        self.finalize()


# Generated at 2022-06-21 23:48:37.834913
# Unit test for method add of class Router
def test_Router_add():
    class TestObj:
        def __init__(self, val):
            self.val = val

    def testfunc():
        return TestObj("testval")


    TestObj.__name__ = "testfunc"
    routeobj = Router()
    testroute = routeobj.add("/testpath", ["GET"], testfunc)
    assert testroute.methods == ["GET"]
    assert testroute.path == "/testpath"
    assert testroute.handler.__name__ == "testfunc"


# Generated at 2022-06-21 23:48:46.539934
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.dynamic_routes = {
        1: Route(path = '/api/v1/user/<name>',
        handler = 'handler1',
        methods = ['GET'],
        name = 'my_route',
        strict_slashes = False,
        unquote = False)
    }

    with pytest.raises(SanicException):
        router.finalize()


# Generated at 2022-06-21 23:48:56.665845
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    r.add(uri="/test/<__file_uri__>", methods=["GET"], handler=None, strict_slashes=False, stream=False, ignore_body=False, version=None, name=None, unquote=False, static=False)
    try:
        r.finalize()
        assert False
    except SanicException:
        assert True
    except:
        assert False

    r = Router()
    r.add(uri="/test/<__file_uri__>", methods=["GET"], handler=None, strict_slashes=False, stream=False, ignore_body=False, version=None, name=None, unquote=False, static=False)

# Generated at 2022-06-21 23:49:03.136471
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add(
        uri='/test',
        methods={"GET"},
        handler=None,
        host=None,
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version=None,
        name=None,
        unquote=True,
        static=False
    )


# Generated at 2022-06-21 23:49:12.328069
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from unittest import TestCase,main
    router = Router()
    class TestRouter(TestCase):
        def test_raise_exception(self):
            route = router.add("/my/route/<number>/<status>",("GET",),None)
            route.labels.append("__number__")
            route.labels.append("__status__")
            route.labels.append("__nonexistent__")
            self.assertRaises(SanicException,router.finalize)
        def test_Router_finalize(self):
            route = router.add("/my/route/<number>/<status>",("GET",),None)
            route.labels.append("__number__")

# Generated at 2022-06-21 23:49:18.828176
# Unit test for method add of class Router
def test_Router_add():
    uri = '/test'
    uri1 = '/test1'
    uri2 = '/test2'
    methods = ['GET']
    def handler():
        print('test')

    t = Router()
    t.add(uri, methods, handler)
    t.add(uri1, methods, handler)
    t.add(uri2, methods, handler)
    assert t.routes_all[uri].ctx.hosts == [None]
    assert t.static_routes[uri].ctx.hosts == [None]
    assert t.dynamic_routes[uri].ctx.hosts == [None]


# Generated at 2022-06-21 23:49:27.395877
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic import Sanic
    from sanic.views import HTTPMethodView

    app = Sanic()

    class View(HTTPMethodView):
        def get(self, request):
            return 'get'
        def post(self, request):
            return 'post'

    router = Router()
    router.add(View.as_view(), '/')
    router.finalize(app)

# Generated at 2022-06-21 23:50:08.684569
# Unit test for method add of class Router
def test_Router_add():
    # Case 1 and Case 2
    assert 1 == 1


# Generated at 2022-06-21 23:50:13.342740
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route(uri='/'), RouteHandler, {}
    router.dynamic_routes = {"key": route}
    with pytest.raises(SanicException):
        router.finalize()
        raise ValueError("Oops! that was no valid number.  Try again...")