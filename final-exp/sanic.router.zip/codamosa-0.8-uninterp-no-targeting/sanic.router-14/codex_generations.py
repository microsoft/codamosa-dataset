

# Generated at 2022-06-21 23:40:16.450589
# Unit test for method add of class Router
def test_Router_add():
    from sanic import Sanic

    app = Sanic("sanic")

    @app.route("/")
    def handler(request):
        return

    router = app.router
    assert router.get("/", "GET") == (app.default_handler, handler, {})
    assert router.get("/", "GET", host="") == (app.default_handler, handler, {})

    @app.route("/static/path")
    def handler(request):
        return

    router = app.router
    assert router.get("/static/path", "GET") == (app.default_handler, handler,{})
    assert router.get("/static/path", "GET",host="") == (app.default_handler, handler, {})



# Generated at 2022-06-21 23:40:21.500237
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    r.add("/<param1>/<param2>", methods=["GET"], handler=lambda r: r)
    r.add("/<param1>/<param2>/<__file_uri__>", methods=["GET"], handler=lambda r: r, static=True)
    r.finalize()

# Generated at 2022-06-21 23:40:29.773694
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.constants import HTTP_METHODS
    from sanic.models.handler_types import RouteHandler
    def unit_test_RouteHandler(): pass
    try:
        router = Router()
        router.add("/", HTTP_METHODS, unit_test_RouteHandler, name="test")
        router.finalize()
        assert router.routes_all[0].name == "test"
    except Exception as error:
        assert True == False, error


# Generated at 2022-06-21 23:40:34.563712
# Unit test for constructor of class Router
def test_Router():
    r=Router()
    assert r.DEFAULT_METHOD == "GET"
    assert r.ALLOWED_METHODS == HTTP_METHODS


# Generated at 2022-06-21 23:40:44.105910
# Unit test for method add of class Router
def test_Router_add():
    from sanic.request import Request
    from sanic.response import HTTPResponse  # noqa

    router = Router()

    router.add("/test", None, "handler1")
    router.add("/test", None, "handler2")

    # Verify router's behavior
    for _, rule in router.routes_all.items():
        assert isinstance(rule, Route)
        assert isinstance(rule.ctx.handler, str)



# Generated at 2022-06-21 23:40:51.028040
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert isinstance(r, Router)
    assert r.dynamic_routes == {}
    assert r.name_index == {}
    assert r.regex_routes == {}
    assert r.routes == OrderedDict()
    assert r.static_routes == OrderedDict()

if __name__ == '__main__':
    test_Router()

# Generated at 2022-06-21 23:40:51.748471
# Unit test for method add of class Router
def test_Router_add():
    pass

# Generated at 2022-06-21 23:41:04.644585
# Unit test for method add of class Router
def test_Router_add():
    from sanic import Sanic
    from sanic.response import text
    from sanic.exceptions import NotFound
    from sanic_routing.exceptions import NoMethod
    app = Sanic(__name__)

    @app.route("/", methods=["PUT"])
    def put_request(request):
        return text("hello")

    @app.route("/", methods=["GET"])
    async def get_request(request):
        return text("world")

    @app.route("/")
    async def request(request):
        return text("yay")

    @app.route("/")
    async def request1(request):
        return text("yay")

    @app.route("/rq3")
    def request3(request):
        return text("yay")


# Generated at 2022-06-21 23:41:15.909225
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    r.add('/path1', ['GET'], 'hanler1')
    if len(r.get_routes()) != 1:
        raise Exception('(1)')

    r.add('/path2/<name>', ['GET'], 'hanler2')
    if len(r.get_routes()) != 2:
        raise Exception('(2)')

    r.add('/path3/<name>', ['POST'], 'hanler3')
    if len(r.get_routes()) != 3:
        raise Exception('(3)')

    r.add('/path4/<name>', ['POST', 'GET'], 'hanler4')
    if len(r.get_routes()) != 4:
        raise Exception('(4)')

    r

# Generated at 2022-06-21 23:41:16.800341
# Unit test for method finalize of class Router
def test_Router_finalize():
    assert True

# Generated at 2022-06-21 23:41:37.026367
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    assert router.dynamic_routes == {}
    assert router.static_routes == {}
    assert router.regex_routes == []
    assert router.named_routes == {}
    assert router.name_index == {}

    def handler(request):
        return request

    router.add(uri='/', methods=['GET'], handler=handler)

    assert router.dynamic_routes != {}
    assert router.static_routes != {}
    assert router.regex_routes != []
    assert router.named_routes != {}
    assert router.name_index != {}
    assert getattr(router, 'routes') == getattr(router, 'routes_all')


# Generated at 2022-06-21 23:41:48.923949
# Unit test for method finalize of class Router
def test_Router_finalize():
    import json
    import pathlib
    from io import IOBase
    from typing import Any

    from sanic.router import Router

    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler

    router = Router({"app": None})
    DEFAULT_METHOD = "GET"
    ALLOWED_LABELS = ("__file_uri__",)

    async def test():
        return "hello"
    method = DEFAULT_METHOD
    method_handler = RouteHandler(test, DEFAULT_METHOD, None)
    host = None
    routes = router.add(
        "/", [method], method_handler, host, strict_slashes=False, stream=False, ignore_body=False, version=None, name=None, unquote=False, static=False
    )

# Generated at 2022-06-21 23:41:49.441429
# Unit test for constructor of class Router
def test_Router():
    pass

# Generated at 2022-06-21 23:41:50.975471
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    print(router)

if __name__ == '__main__':
    test_Router()

# Generated at 2022-06-21 23:41:51.413386
# Unit test for constructor of class Router
def test_Router():
    router = Router()

# Generated at 2022-06-21 23:41:59.905905
# Unit test for constructor of class Router
def test_Router():
    r1 = Router()
    r2 = Router(ROUTER_CACHE_SIZE)
    assert r1 != r2
    assert r1.routes != r2.routes
    assert r1.routes_all != r2.routes_all
    assert r1.routes_static != r2.routes_static
    assert r1.routes_dynamic != r2.routes_dynamic
    assert r1.routes_regex != r2.routes_regex


# Generated at 2022-06-21 23:42:07.021469
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()

    # test for SanicException
    route = Route("/path/to/<invalid_param>")
    r.dynamic_routes["/path/to/<invalid_param>"] = route
    with pytest.raises(SanicException):
        r.finalize()

    # test for working
    route = Route("/path/to/<valid_param>")
    r.dynamic_routes["/path/to/<valid_param>"] = route
    r.finalize()

# Generated at 2022-06-21 23:42:14.146201
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    with pytest.raises(SanicException):
        r.add("/hello/<var1>", methods=["POST"], handler=None, static=True)
        r.finalize(None)
    r.add("/hello/<var1>", methods=["POST"], handler=None)
    r.finalize(None)

# Generated at 2022-06-21 23:42:20.224277
# Unit test for method finalize of class Router
def test_Router_finalize():
    import doctest
    from .server import Sanic
    doctest.run_docstring_examples(Router.finalize, globals(),
                                   optionflags=doctest.ELLIPSIS)
    app = Sanic("test_Router_finalize")
    router = Router("example_routes", app=app)
    router.add("/invalid/route/<__invalid_parameter_name>", None, None)
    try:
        router.finalize()
    except Exception as e:
        pass
    assert "Invalid route: " in str(e)

# Generated at 2022-06-21 23:42:24.412869
# Unit test for constructor of class Router
def test_Router():
    # Test if the object created by this constructor is an instance of class Router
    assert isinstance(Router(),Router)


# Generated at 2022-06-21 23:42:31.579997
# Unit test for method add of class Router
def test_Router_add():
    # TODO: Test for this function
    pass


# Generated at 2022-06-21 23:42:33.147322
# Unit test for constructor of class Router
def test_Router():
    rooter = Router()
    assert rooter

# Generated at 2022-06-21 23:42:35.604730
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == 'GET'

# Generated at 2022-06-21 23:42:39.788855
# Unit test for method finalize of class Router
def test_Router_finalize():
    class Sanic:
        def _generate_name(self, view_name):
            return "sanic.test"

    ctx = {"app": Sanic()}

    router = Router(ctx)
    try:
        router.add("/", ["GET"], {})
    except SanicException:
        router.finalize()

# Generated at 2022-06-21 23:42:47.540660
# Unit test for method finalize of class Router
def test_Router_finalize():
    class MockApp:
        def _generate_name(self, *args, **kwargs):
            return ''

    # Case 1: a route with correct labels should not raise any error
    route_correct = Route(
        path='/users/{name}', methods=['GET'], handler=None
    )
    router = Router(MockApp())
    router.add(route=route_correct)
    router.finalize()

    # Case 2: a route with label "__file_uri__" should not raise any error
    route_file_uri = Route(
        path='/users/{__file_uri__}', methods=['GET'], handler=None
    )
    router = Router(MockApp())
    router.add(route=route_file_uri)
    router.finalize()

    # Case 3:

# Generated at 2022-06-21 23:42:50.788100
# Unit test for constructor of class Router
def test_Router():
    """
    Unit test for constructor of class Router
    """
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-21 23:43:02.341416
# Unit test for constructor of class Router
def test_Router():
    test = Router()
    assert test.ctx.app == None # default value is None
    assert test.hosts == None # default value is None
    assert test.DEFAULT_METHOD == "GET" # Test the value of DEFAULT_METHOD
    assert test.ALLOWED_METHODS == HTTP_METHODS # Test the value of ALLOWED_METHODS
    assert test.uri_tpl == "{}{}{}{}{}{}{}{}{}" # Test the value of uri_tpl
    assert test.dynamic_routes == {} # default value is {}
    assert test.regex_routes == {} # default value is {}
    assert test.dynamic_hosts == {} # default value is {}
    assert test.regex_hosts == {} # default value is {}
    assert test.static_routes == {} # default value is

# Generated at 2022-06-21 23:43:03.844618
# Unit test for method add of class Router
def test_Router_add():
    assert True


# Generated at 2022-06-21 23:43:05.423612
# Unit test for constructor of class Router
def test_Router():
    router = Router()


# Generated at 2022-06-21 23:43:11.478778
# Unit test for method add of class Router
def test_Router_add():
    def fn(a):
        return a

    r = Router()

    r.add("/", ["GET"], fn)

    try:
        r.add("/", ["GET"], "abc")
    except Exception as ex:
        print(ex)

    try:
        r.add("/", ["GET"], fn, host="example.com")
    except Exception as ex:
        print(ex)



# Generated at 2022-06-21 23:43:34.813487
# Unit test for constructor of class Router
def test_Router():
    assert Router.__name__ == "Router"


# Generated at 2022-06-21 23:43:40.729892
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Setup
    router = Router()

    # Exercise
    route = router.add(uri="/", methods=["GET"], handler=None)

    try:
        router.finalize()
    except SanicException as ex:
        assert str(ex) == "Invalid route: /. Parameter names cannot use '__'."

# Generated at 2022-06-21 23:43:45.608391
# Unit test for method add of class Router
def test_Router_add():
    r = Router()
    r.add("/a/b/c", ["GET"], lambda a, b: None)
    assert len(r.routes_dynamic) == 1

# Generated at 2022-06-21 23:43:56.556570
# Unit test for method add of class Router
def test_Router_add():
    from sanic.exceptions import SanicException
    from sanic import Sanic

    app = Sanic("sanic")
    router = Router(app)

    @app.route("/test", methods=["GET"])
    def test(request):
        return "OK"

    assert router.find_route_by_view_name("test") == ("/test", router.routes_static["/test"][0])

    @app.route("/test2", methods=["GET"], host="example.com")
    def test2(request):
        return "OK"

    assert router.find_route_by_view_name("test2") == ("/test2", router.routes_static["/test2"][0])


# Generated at 2022-06-21 23:43:57.493415
# Unit test for method finalize of class Router
def test_Router_finalize():
    assert True

# Generated at 2022-06-21 23:43:58.862110
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add(uri='/user', methods = ['GET'], handler = None)



# Generated at 2022-06-21 23:43:59.946969
# Unit test for constructor of class Router
def test_Router():
    router = Router(default_method=Router.DEFAULT_METHOD)
    assert router.DEFAULT_METHOD == "GET"

# Generated at 2022-06-21 23:44:04.021536
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes == {}
    assert router.name_index == {}
    assert router.regex_routes == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}


# Generated at 2022-06-21 23:44:11.318003
# Unit test for constructor of class Router
def test_Router():
    router = Router(None)
    assert router.ctx == None
    assert router.routes == {}
    assert router.tree == {}
    assert router.init_path == None
    assert router.endpoints == []
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}

# Generated at 2022-06-21 23:44:14.034318
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.register(path="/test")
    with pytest.raises(SanicException):
        router.finalize()

# Generated at 2022-06-21 23:44:25.900991
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Route as RouteType
    from sanic import Sanic
    app = Sanic()
    router = Router()
    route = RouteType(
        "/test",
        {})
    router.dynamic_routes["test"] = route
    router.finalize(app)

# Generated at 2022-06-21 23:44:34.731165
# Unit test for method add of class Router
def test_Router_add():
    @coroutine
    def _(request):
        pass

    for m in ("get", "post", "delete", "put", "patch"):
        setattr(Router, m, Router.add)

    r = Router()
    r.get("/test", ["GET"], _)
    r.post("/test", ["POST"], _)

    r.add("/test", ["GET"], _)
    r.add("/test", ["POST"], _)
    r.add("/test", ["GET", "PUT"], _)

    # Exception, invalid host
    try:
        r.get("/test", ["GET"], _, host=["test", "test"])
    except TypeError:
        assert True
    else:
        assert False

    # Exception, invalid unquote

# Generated at 2022-06-21 23:44:44.706111
# Unit test for method finalize of class Router
def test_Router_finalize():
    # arrange
    import sanic.router as model

    test_model = model.Router()
    test_model.dynamic_routes = {
        '/user/id': model.Route(
            '',
            '/user/id',
            {'/user/id'},
            {'__file_uri__': ('/user', 'id')},
            None,
            None,
            {}
        )
    }

    # act
    test_model.finalize(None)

    # assert
    assert True


# Generated at 2022-06-21 23:44:47.044550
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, BaseRouter)


# Generated at 2022-06-21 23:44:55.146784
# Unit test for method add of class Router
def test_Router_add():
    uri = "test/uri"
    methods = ["GET", "POST", "OPTIONS"]
    handler = RouteHandler()
    host = "test.com"
    strict_slashes = True
    stream = True
    ignore_body = True
    version = "1.0"
    name = "test_name"
    unquote = True
    static = True

    test_object = Router()

    # Positive test
    test_route = test_object.add(uri, methods, handler, host, strict_slashes,
                                stream, ignore_body, version, name, unquote, static)
    assert type(test_route) == Route

    # Negative test - changing object values to fail
    methods = ["GET", "POST", "PUT"]
    strict_slashes = False
    stream = False

# Generated at 2022-06-21 23:45:08.154202
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import serve
    from sanic.websocket import WebSocketProtocol

    def test_error():
        #! test case for error

        uri = "/uri"
        app = Sanic(__name__)
        app.router.add(uri, ['GET'], lambda _: HTTPResponse())

        return app

    def test_ok():
        #! test case for ok

        uri = "/uri"
        app = Sanic(__name__)
        app.router.add(uri, ['GET'], lambda _: HTTPResponse())

        return app

    assert test_error().router.routes[0] is None
    assert test_

# Generated at 2022-06-21 23:45:20.625325
# Unit test for constructor of class Router
def test_Router():
    # Create a route list
    example_route_list = [{
        'path': '/route1',
        'methods': ['GET', 'POST', 'PATCH'],
        'handler': 'handler1',
        'stream': False,
        'ignore_body': False,
        'version': None,
        'name': 'name1',
        'unquote': False,
        'static': False,
        'strict_slashes': False,
        'websocket': False,
        'host': None
    }]

    # Create a new router
    new_router = Router(example_route_list)

    # Assert that the router is not an empty list
    assert (len(new_router) > 0) == True



# Generated at 2022-06-21 23:45:23.186218
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert isinstance(r, Router)


# Generated at 2022-06-21 23:45:30.411770
# Unit test for method add of class Router
def test_Router_add():
    uri = "api"
    methods = HTTP_METHODS
    handler = None
    host = "localhost"
    strict_slashes = False
    stream = False
    ignore_body = False
    version = 1
    name = "test_name"
    unquote = False
    static = False
    test_router = Router()
    assert(test_router.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static) == [])


# Generated at 2022-06-21 23:45:36.664529
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic_routing.router import Router
    from sanic.exceptions import SanicException
    from sanic.router import Route
    router = Router()
    router.dynamic_routes["invalid_route"] = Route
    with pytest.raises(SanicException):
        router.finalize()

# Generated at 2022-06-21 23:45:54.163888
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add("/user/<name>", ["GET"], handler=None)
    router.add("/app/<name>", ["GET"], handler=None)
    router.finalize()

# Generated at 2022-06-21 23:45:55.589875
# Unit test for constructor of class Router
def test_Router():
  r = Router()
  assert isinstance(r, BaseRouter)


# Generated at 2022-06-21 23:46:05.715219
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    uri = "uri"
    methods = ("GET", "POST")
    handler = lambda: "test"
    strict_slashes = False
    stream = False
    ignore_body = False
    version = '1.0'
    name = 'test'
    unquote = False

    router.add(
        uri=uri,
        methods=methods,
        handler=handler,
        strict_slashes=strict_slashes,
        stream=stream,
        ignore_body=ignore_body,
        version=version,
        name=name,
        unquote=unquote
    )

    assert router.method_list == methods

# Generated at 2022-06-21 23:46:18.423068
# Unit test for method add of class Router
def test_Router_add():
    from sanic import Sanic

    def handler():
        pass

    uri = "/test"
    methods = ["GET", "POST", "OPTIONS"]
    host = "test.com"
    strict_slashes = False
    stream = False
    ignore_body = False

    expected_route = Route(
        uri=uri,
        handler=handler,
        methods=methods,
        host=None,
        strict=strict_slashes,
        unquote=False,
    )
    actual_route = Router().add(
        uri,
        methods,
        handler,
        host=host,
        strict_slashes=strict_slashes,
        stream=stream,
        ignore_body=ignore_body,
    )
    assert actual_route == expected_route

test_Router_

# Generated at 2022-06-21 23:46:19.109111
# Unit test for method add of class Router
def test_Router_add():
    pass

# Generated at 2022-06-21 23:46:30.723502
# Unit test for method add of class Router

# Generated at 2022-06-21 23:46:41.218245
# Unit test for method add of class Router
def test_Router_add():
    router = Router(None)
    uri = "/home/:id"
    methods = ["GET"]
    handler = "handler"
    host = "localhost"
    strict_slashes = False
    stream = False
    ignore_body = True
    version = 2
    name = "name"
    unquote = False
    static = True
    
    # Test parameters uri, methods, handler
    assert(router.add(uri, methods, handler) == [])
    # Test parameters uri, methods, handler, host
    assert(router.add(uri, methods, handler, host) == [])
    # Test parameters uri, methods, handler, host, strict_slashes
    assert(router.add(uri, methods, handler, host, strict_slashes) == [])
    # Test parameters uri, methods,

# Generated at 2022-06-21 23:46:46.373163
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router = Router()
    route = Route(
        path = '/stat'
    )
    router.add(
        uri='/stat',
        methods=['GET'],
        handler=route,
        static=False,
    )
    route = Route(
        path = '/stat'
    )
    router.add(
        uri='/stat',
        methods=['GET'],
        handler=route,
        static=True,
    )


# Generated at 2022-06-21 23:46:48.518334
# Unit test for method add of class Router
def test_Router_add():
    check = Router()
    check.add("/uri", "methods", "handler")


# Generated at 2022-06-21 23:46:49.973127
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert isinstance(r, Router)

# Generated at 2022-06-21 23:47:39.332786
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    keys = list(router.__dict__.keys())
    assert len(keys) == 2
    assert keys[0] == "ctx"
    assert keys[1] == "name_index"
    assert router.ctx is None
    assert router.name_index == {}
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-21 23:47:50.826777
# Unit test for method finalize of class Router
def test_Router_finalize():
    import string
    import random
    import tempfile

    with tempfile.TemporaryDirectory() as tmpdirname:
        tmpdirname = tmpdirname.replace("\\", "/")
        print(f'created temporary directory: {tmpdirname}')

        random_folder_name = "".join(random.choice(string.ascii_lowercase + string.digits) for i in range(6))
        tmpdirname = f"{tmpdirname}/{random_folder_name}"
        os.makedirs(tmpdirname)
        print(f'created temporary directory: {tmpdirname}')

        template_module_file_name = f"{tmpdirname}/template_module_file.py"
        with open(template_module_file_name, "w") as template_module_file:
            template_module

# Generated at 2022-06-21 23:47:56.634772
# Unit test for method finalize of class Router
def test_Router_finalize():
    import sanic.router

    try:
        sanic.router.Router(app=None)
    except Exception as ex:
        print(str(ex))
        assert type(ex) == SanicException
        assert "Parameter names cannot use '__'." in str(ex)
    else:
        assert False, "Should have raised exception in test_Router_finalize"

# Generated at 2022-06-21 23:48:03.135974
# Unit test for method finalize of class Router
def test_Router_finalize(): 
    from sanic.app import Sanic
    app = Sanic("test_Router_finalize")
    router = Router(app)
    router.add("/test", methods=["GET"], handler=app.request)
    router.finalize()
#

# Generated at 2022-06-21 23:48:09.569597
# Unit test for constructor of class Router
def test_Router():
    router = Router(True)
    assert(router.ctx.app)
    assert(router._built)
    assert(router._finalized)
    assert(router.routes)
    assert(router.static_routes)
    assert(router.dynamic_routes)
    assert(router.regex_routes)
    assert(router.name_index)
    assert(router.hosts)


# Generated at 2022-06-21 23:48:20.538594
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic_routing.route import Route

    class DummyRoute(Route):
        def __init__(self, labels):
            self.labels = labels

    test_cases = [
        {
            "input": [DummyRoute(["abc", "__file_uri__", "def"])],
            "expect": None,
        },
        {
            "input": [DummyRoute(["__abc", "def"])],
            "expect": SanicException("Invalid route: %r. Parameter names cannot use '__'."),
        }
    ]
    for test_case in test_cases:
        router = Router()
        router.dynamic_routes = {
            "dummy": test_case["input"][0]
        }

# Generated at 2022-06-21 23:48:23.507118
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS

# Generated at 2022-06-21 23:48:26.465297
# Unit test for method add of class Router
def test_Router_add():
    router = Router(None)
    assert isinstance(router.add('/',['GET'], print, name='hello'), Route)
    assert isinstance(router.add('/',['GET'], print, name='hello'), Route)


# Generated at 2022-06-21 23:48:28.776413
# Unit test for constructor of class Router
def test_Router():
    router= Router()
    assert isinstance(router, Router)


# Generated at 2022-06-21 23:48:37.274859
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        router = Router(app=None)
        router.ctx = MagicMock()
        router.dynamic_routes = {
            "d1": MagicMock(labels={"__a","__b"})
        }
        router.finalize(None)
    except Exception as e:
        assert isinstance(e, SanicException) and \
            str(e) == "Invalid route: <MagicMock name='mock.d1' id='4585388136'>. Parameter names cannot use '__'."