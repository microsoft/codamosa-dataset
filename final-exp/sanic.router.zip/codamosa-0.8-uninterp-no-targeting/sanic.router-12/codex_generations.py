

# Generated at 2022-06-21 23:40:15.317769
# Unit test for constructor of class Router
def test_Router():
    pass

# Generated at 2022-06-21 23:40:16.208205
# Unit test for constructor of class Router
def test_Router():
    r = Router()

# Generated at 2022-06-21 23:40:20.411966
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router(None)
    route = Route(r, '/', None, None)

    with pytest.raises(SanicException) as e:
        r.finalize([route])
        assert "Invalid route: " in str(e.value)

# Generated at 2022-06-21 23:40:31.852177
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}

    routes = router.add(
        uri="/test",
        methods=["GET"],
        host="localhost",
        handler="handler",
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version="0.0.1",
        name="name",
        unquote=False,
    )
    assert isinstance(routes, list)
    assert len(router.routes_all) == 1
    assert len(router.routes_dynamic) == 1

# Generated at 2022-06-21 23:40:41.467496
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    routers = {"test": router}
    routes = [
        Route(
            "test",
            "/resources/<id>",
            None,
            {},
            None,
            host=None,
            name=None,
            methods={},
            strict_slashes=False,
            requirements={},
            dynamic=True,
        )
    ]
    for route in routes:
        router.add(route.path, route.methods, None, host=route.host)

    router.finalize(routers)

# Generated at 2022-06-21 23:40:52.857351
# Unit test for method finalize of class Router
def test_Router_finalize():
    route = Route.from_string('/<param1>/<param2>/<param3>', 'GET')
    routes = {'foo': route}
    # the key 'foo' in the dict routes is not allowed
    router = Router(None, routes)
    with pytest.raises(SanicException):
        router.finalize()

    route = Route.from_string('/<param1>/<param2>/<param3>', 'GET',
                              host='192.168.1.1')
    routes = {'foo': route}
    # the key 'foo' in the dict routes is not allowed
    router = Router(None, routes)
    with pytest.raises(SanicException):
        router.finalize()


# Generated at 2022-06-21 23:40:54.171116
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.name == "Router"



# Generated at 2022-06-21 23:40:55.628230
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router


# Generated at 2022-06-21 23:40:56.198418
# Unit test for method finalize of class Router
def test_Router_finalize():
    pass

# Generated at 2022-06-21 23:41:02.074420
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Same as above test, but with leading __
    test_Router = Router()
    test_Router.dynamic_routes["__test"] = Route(
        uri="/test",
        methods={"GET"},
        handler=lambda request: None,
    )
    test_Router.finalize()



# Generated at 2022-06-21 23:41:16.738007
# Unit test for method add of class Router
def test_Router_add():
    print ("\n test_Router_add running..")
    from sanic import Sanic
    app = Sanic('sanic')
    router = Router()

    @app.route('/test')
    async def handler(request):
        return request

    uri = 'test'
    methods = ['GET', 'POST']
    handler = handler
    host = None
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = None
    unquote = False
    static = False
    router.add(uri, methods, handler, host, strict_slashes, stream,
              ignore_body, version, name, unquote, static)

    assert router.routes[0].path == '/test'
    assert router.routes[0].handler == handler
    assert router

# Generated at 2022-06-21 23:41:25.310013
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, BaseRouter)
    assert router.router_cache_size == ROUTER_CACHE_SIZE

# Unit tests for get of class Router

# Generated at 2022-06-21 23:41:28.219711
# Unit test for method finalize of class Router
def test_Router_finalize():
    """Test finalize method of class Router"""
    router = Router()
    method = router.finalize


# Generated at 2022-06-21 23:41:32.991288
# Unit test for constructor of class Router
def test_Router():
    assert Router().routes == {}
    assert Router().routes_static == {}
    assert Router().routes_dynamic == {}
    assert Router().routes_regex == {}


# Generated at 2022-06-21 23:41:42.079775
# Unit test for method add of class Router
def test_Router_add():
    def test_handler(r):
        pass
    # Build the test case
    r = Router()
    r.add(uri='/<name>',
          methods=['GET'],
          handler=test_handler,
          host=None,
          strict_slashes=False,
          stream=False,
          ignore_body=False,
          version=None,
          name=None,
          unquote=False,
          static=False)
    # Unpack arguments for the method call
    route, handler, params = r.get('/Lee', 'GET', None)
    # Compare the result to the expected value
    assert((route.path, handler, params) == ('/<name>', test_handler, {'name': 'Lee'}))


# Generated at 2022-06-21 23:41:50.420914
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    from sanic.app import Sanic
    from sanic.router import Router

    with pytest.raises(Exception, match="Invalid route:.*Parameternames cannot use '__'."):
        def test_func(request):
            pass
        
        app = Sanic("test_Router_finalize_app")
        router = Router()

        router.add("/", "GET", test_func, host="test1")
        router.add("/", "GET", test_func, __host="test2")
        router.add("/", "GET", test_func, __file_uri__="test3")
        router.finalize(app)


# Generated at 2022-06-21 23:41:56.224930
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r.DEFAULT_METHOD == 'GET'
    assert r.ALLOWED_METHODS == ['GET', 'HEAD', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS']
    assert r.routes_all == []
    assert r.routes_static == []
    assert r.routes_dynamic == {} # Type: Dict
    assert r.routes_regex == []
    assert r.name_index == {}



# Generated at 2022-06-21 23:42:06.539709
# Unit test for method finalize of class Router
def test_Router_finalize():
    #
    # Create a Route object
    #
    route = Route(
        path="/:user/:action",
        handler=None,
        methods=["GET"],
        ctx=None,
        name="route_1",
        strict=False,
        unquote=False,
    )
    #
    # Add this route to the Router object
    #
    router = Router()
    router.dynamic_routes[route.name] = route
    #
    # Now check that finalize raises an exception
    #
    with raises(SanicException):
        router.finalize()

# Generated at 2022-06-21 23:42:08.334982
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    r.finalize()


# Generated at 2022-06-21 23:42:18.135889
# Unit test for method finalize of class Router
def test_Router_finalize():
    route_handler = lambda: None

    with pytest.raises(SanicException) as exc_info:
        Router().add(
            uri='/test',
            methods=["GET"],
            handler=route_handler,
            host=None,
            strict_slashes=False,
            stream=False,
            ignore_body=False,
            version=None,
            name=None,
            unquote=False,
            static=False,
        ).finalize()

    assert 'Invalid route' in str(exc_info.value)
    assert 'Parameter names cannot use' in str(exc_info.value)

# Generated at 2022-06-21 23:42:27.248792
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    try:
        router.add('/', ['GET', 'POST'], 'handler')
        router.finalize()
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-21 23:42:30.958748
# Unit test for constructor of class Router
def test_Router():
    class FakeApp:
        def _generate_name(self, view_name):
            return view_name
    app = FakeApp()
    router = Router(app)


# Generated at 2022-06-21 23:42:36.666430
# Unit test for method finalize of class Router
def test_Router_finalize():
    route = "test"
    _ = test.get_router()
    try:
        test.add(route, ["GET"], lambda x: x)
    except Exception as e:
        raise e
    test.finalize()
    assert test.routes[route] == "test"

# Generated at 2022-06-21 23:42:38.562355
# Unit test for constructor of class Router
def test_Router():
    pass


# Generated at 2022-06-21 23:42:48.406353
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.ctx == {}
    assert router.routes == []
    assert router.name_index == {}
    assert router.regex_routes == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.routes_all == []
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-21 23:42:57.753193
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    print(router.ctx)
    print(router.DEFAULT_METHOD)
    print(router.ALLOWED_METHODS)
    print(router.routes)
    print(router.routes_all)
    print(router.routes_static)
    print(router.routes_dynamic)
    print(router.routes_regex)


# Generated at 2022-06-21 23:43:00.759739
# Unit test for method add of class Router
def test_Router_add():
    router = Router("")
    def handler():
        pass
    router.add("/", ["GET"], handler)
    assert router.routes[0] == Route("/", ["GET"], handler, "", False, "", False)

# Generated at 2022-06-21 23:43:02.097032
# Unit test for constructor of class Router
def test_Router():
    print("test router")
    router = Router()

# Generated at 2022-06-21 23:43:03.002967
# Unit test for constructor of class Router
def test_Router():
    router = Router()

# Generated at 2022-06-21 23:43:03.849157
# Unit test for method finalize of class Router
def test_Router_finalize():
    pass

# Generated at 2022-06-21 23:43:20.356121
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_router = Router([], {})
    test_router.dynamic_routes = {
        'test_uri': {'labels': ['__file_uri__']},
        'test_uri2': {'labels': ['__file_uri__', 'file_uri2']},
        'test_uri3': {'labels': ['file_uri3']}
    }
    test_router.finalize()


# Generated at 2022-06-21 23:43:33.805988
# Unit test for method add of class Router
def test_Router_add():
    from sanic.exceptions import MethodNotSupported
    from sanic.request import Request

    app = Sanic('test_get')
    router = Router(app)

    @app.route('/test')
    async def handler(request):
        return text('OK')

    # simulating Sanic.add_route
    router.add('/test', ['GET', 'POST'], handler)

    # testing Sanic.get_route
    request, response = app.test_client.get('/test')
    assert response.text == 'OK'
    request, response = app.test_client.post('/test')
    assert response.text == 'OK'

    # testing Sanic.get_route
    # with method not allowed
    request, response = app.test_client.delete('/test')
    assert response.status == 405

# Generated at 2022-06-21 23:43:45.357444
# Unit test for method finalize of class Router
def test_Router_finalize():
        r=Router()
        uri_1="/index"
        uri_2="/index/__index"
        methods=["GET","POST"]
        handler=lambda x:x+""
        handler_2=lambda x:x+""
        host=None
        strict_slashes=False
        stream=False
        ignore_body=False
        version="1.0"
        name="home"
        unquote=False
        static=False
        try:
            r.finalize()
        except Exception:
            pass
        else:
            print("fail,should raise exception here")
            exit()

        r.add(uri_1,methods,handler,host,strict_slashes,stream,ignore_body,version,name,unquote,static)


# Generated at 2022-06-21 23:43:55.010894
# Unit test for method add of class Router
def test_Router_add():
    uri = "test"
    methods = ["GET", "POST", "OPTIONS"]
    handler = RouteHandler(None, None)
    host = "url"
    strict_slashes = False
    stream = False
    ignore_body = False
    version = "0.1"
    name = "route_name"
    unquote = False
    static = False
    router = Router()
    route = router.add(
        uri,
        methods,
        handler,
        host,
        strict_slashes,
        stream,
        ignore_body,
        version,
        name,
        unquote,
        static,
    )
    assert route is not None


# Generated at 2022-06-21 23:44:06.469530
# Unit test for method add of class Router
def test_Router_add():
    
    class Router:
        @add(
            uri='/',
            methods=['GET'],
            handler=None,
            host=None,
            strict_slashes=False,
            stream=False,
            ignore_body=False,
            version=None,
            name=None,
            unquote=False
        )
        def _Router_add(self, **kwargs):
            return kwargs

    class RouterTest:
        def __init__(self):
            self.router = Router()


# Generated at 2022-06-21 23:44:10.661638
# Unit test for method add of class Router
def test_Router_add():
    a = Router()
    b = a.add('/test', ['GET'], lambda : None)
    assert a.lookup('GET', '/test') is not None
    assert type(b) == Route

# Generated at 2022-06-21 23:44:19.979924
# Unit test for constructor of class Router
def test_Router():
    def lru_cache(maxsize: int):
        def test_decorator(func):
            def wrapper(*args, **kwargs):
                return (func(*args, **kwargs))
            return wrapper
        return test_decorator

    class Sanic(object):
        def __call__(self, *args, **kwargs): # pragma: no cover
            return self
        def __init__(self, *args, **kwargs): # pragma: no cover
            pass
        def add_route(self, *args, **kwargs): # pragma: no cover
            pass
        def add_websocket_route(self, *args, **kwargs): # pragma: no cover
            pass
        def __repr__(self): # pragma: no cover
            return "Sanic"


# Generated at 2022-06-21 23:44:28.588554
# Unit test for method add of class Router
def test_Router_add():
    class Mock:
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
    class MockRouter(Router):
        def _add(self, *args, **kwargs):
            return Mock(*args, **kwargs)
    router = MockRouter()
    uri = "www.google.com"
    methods = ["GET"]
    handler = lambda x: x
    host = "https://www.google.com"
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = "google"
    unquote = True
    static = True


# Generated at 2022-06-21 23:44:36.541679
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.app import Sanic
    from sanic.router import Router
    from sanic.exceptions import SanicException

    class TestRouter(Router):
        def __init__(self, app, *args, **kwargs):
            self.log = []
            super().__init__(app, *args, **kwargs)

    app = Sanic('test_Router_finalize')

    # Test invalid labels
    router = TestRouter(app, [], dynamic_labels=['__foo__'])
    try:
        router.finalize()
    except SanicException as err:
        assert 'Invalid route' in err.args[0]
        assert "'__foo__'" in err.args[0]

    # Test valid labels

# Generated at 2022-06-21 23:44:37.905072
# Unit test for constructor of class Router
def test_Router():
    # Can not be unit tested
    assert False

# Generated at 2022-06-21 23:45:01.090350
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r.DEFAULT_METHOD == Router.DEFAULT_METHOD == "GET"
    assert r.ALLOWED_METHODS == Router.ALLOWED_METHODS == HTTP_METHODS


# Generated at 2022-06-21 23:45:09.471038
# Unit test for method add of class Router
def test_Router_add():
    obj = Router()
    uri = '/'
    methods = ["GET", "POST", "OPTIONS"]
    handler = "handler1"
    host = "WEB_HOST"
    strict_slashes = False
    stream = False
    ignore_body = False
    version = "v1"
    name = "name_test"
    unquote = False
    static = False
    route = obj.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)
    assert route != None


# Generated at 2022-06-21 23:45:21.614303
# Unit test for method add of class Router
def test_Router_add():
    from sanic_routing import Router as sanic_Router
    from sanic.app import Sanic
    from sanic.handler import ErrorHandler
    from sanic.response import json as Json
    from sanic.response import text as Text
    from sanic.request import Request
    import unittest

    def test_backward_compatibility():
        app = Sanic('test_backward_compatibility')
        router = Router(app)
        app.router = router

        @app.route('/')
        async def handler(request: Request) -> Json:
            return Json({'test': True}, status=200)

        routes = router.routes_all
        assert routes[0].handler == handler  # type: ignore
        assert len(routes) == 1



# Generated at 2022-06-21 23:45:26.851484
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        r = Router()
        r.add(uri="/abc/<id>", methods="GET", handler=lambda *a, **k: None, version=1)
        r.finalize()
    except Exception:
        assert False
    else:
        assert True

# Generated at 2022-06-21 23:45:39.998642
# Unit test for method finalize of class Router
def test_Router_finalize():
    print("test_Router_finalize():")
    router = Router(None, None, None)
    
    # test case 1 - OK
    route = Route('/', None, None, None, None, None)
    route.labels = set()
    router.dynamic_routes = dict({'route': route})
    router.finalize()

    # test case 2 - OK, because label is allowed
    route = Route('/', None, None, None, None, None)
    route.labels = set(['__file_uri__'])
    router.dynamic_routes = dict({'route': route})
    router.finalize()
    
    # test case 3 - Exception
    route = Route('/', None, None, None, None, None)

# Generated at 2022-06-21 23:45:50.610713
# Unit test for method add of class Router
def test_Router_add():
    def handler(request, handler_arg1, handler_kws=None):
        return 'success'

    Router.DEFAULT_METHOD = 'GET'
    router = Router()
    host = "example.com"
    uri = "/"
    methods = ["GET", "POST", "OPTIONS"]
    strict_slashes = False
    stream = False
    ignore_body = False
    version = 0.1
    name = None
    unquote = False
    static = False


# Generated at 2022-06-21 23:45:57.114190
# Unit test for method finalize of class Router
def test_Router_finalize():
    from pathlib import Path
    from sanic import Sanic
    from sanic.blueprints import Blueprint

    app = Sanic(__name__)
    router = app.router
    blueprint = Blueprint('test_Router_finalize')
    
    blueprint.add_route(app.get, '/test')
    router.add_blueprint(blueprint, '/')
    app.router.finalize()
    assert router.routes_dynamic


# Generated at 2022-06-21 23:45:57.781952
# Unit test for constructor of class Router
def test_Router():
    routes = Router()

# Generated at 2022-06-21 23:46:09.707446
# Unit test for method add of class Router
def test_Router_add():
    from unittest import TestCase
    from unittest.mock import MagicMock

    class TC(TestCase):
        def test(self):
            r = Router()
            route = MagicMock()
            r.dynamic_routes = {
                "foo1": [route],
                "bar1": [route],
                "bar2": [route],
            }
            r.add("/foo", ["GET"], None)
            r.add("/foo", ["POST"], None)
            r.add("/bar", ["PUT"], None)

            self.assertEqual(len(r.dynamic_routes), 4)
            self.assertIn("foo", r.dynamic_routes)
            self.assertIn("foo1", r.dynamic_routes)

# Generated at 2022-06-21 23:46:14.754663
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    r.add("/")
    r.add("/<name:string>")
    with raises(SanicException) as e:
        r.add("/<__path__:path>")
    assert "Invalid route" in str(e.value)

# Generated at 2022-06-21 23:47:00.732584
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.websocket import WebSocketProtocol
    from sanic.views import CompositionView, HTTPMethodView, HTTPMethodViewType
    from sanic.response import HTTPResponse, text

    app = Sanic('test_Router_finalize')

    class Test1View(HTTPMethodView):
        def get(self, request):
            return text("OK")

    class Test2View(HTTPMethodViewType):
        def get(self, request):
            return text("OK")

    class Test3View(HTTPMethodViewType):
        async def get(self, request):
            return text("OK")

    class Test4View(CompositionView):
        class Meta:
            views = [Test1View, Test2View, Test3View]


# Generated at 2022-06-21 23:47:06.221897
# Unit test for method add of class Router
def test_Router_add():
    route = Router().add(uri='/testing', methods=['GET'], handler=None, host=None, strict_slashes=False, stream=False, ignore_body=False, version=None, name=None, unquote=False, static=False)
    assert(route == None)


# Generated at 2022-06-21 23:47:10.406553
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    r.add("/test/{a}/{b}", ["GET"], lambda request, a, b: "test")
    r.add("/test/{__a}/{b}", ["GET"], lambda request, __a, b: "test")
    r.finalize()

# Generated at 2022-06-21 23:47:13.516401
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add('/', methods=['GET'], handler=None, host=None, strict_slashes=False, stream=False, ignore_body=False, version=None, name=None, unquote=False)

# Generated at 2022-06-21 23:47:24.987759
# Unit test for method add of class Router
def test_Router_add():
    fn = lambda request: None
    from sanic.router import Router
    r = Router()
    r.add("/uri", ("GET",), fn)

# Generated at 2022-06-21 23:47:27.995435
# Unit test for method add of class Router
def test_Router_add():
    from sanic.models.route import Route

    router = Router()
    router.add("/", ["GET"], None)

    assert isinstance(router.routes_all[""]["GET"], Route)


# Generated at 2022-06-21 23:47:34.907841
# Unit test for constructor of class Router
def test_Router():
    # test constructor
    router = Router()
    # check if routes are empty
    assert len(router.routes_all) == 0
    assert len(router.routes_static) == 0
    assert len(router.routes_dynamic) == 0
    assert len(router.routes_regex) == 0


# Generated at 2022-06-21 23:47:42.539717
# Unit test for method add of class Router
def test_Router_add():
    # Set up
    methods = ["GET", "POST"]
    uri = "/"
    handler = RouteHandler("hello")
    host = "www.google.com"
    strict_slashes = False
    stream = False
    ignore_body = False
    version = 1
    name = "me"
    unquote = False
    static = True
    route = Route("/", handler, methods, None, strict_slashes, unquote,
    True, None, name, True, ())
    router = Router()
    
    # Test
    router.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)

    # Assert
    assert router.static_routes.__len__() == 1


# Generated at 2022-06-21 23:47:50.331792
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router._get == router.get
    assert router.find_route_by_view_name == router.find_route_by_view_name
    assert router.finalize == router.finalize

# Generated at 2022-06-21 23:47:57.545476
# Unit test for method finalize of class Router
def test_Router_finalize():
    routes = [
        {'endpoint': 'test1', 'uri': '/test1/<param1>', 'methods': [
            'GET'], 'handler': 'test1'},
        {'endpoint': 'test2', 'uri': '/test2', 'methods': ['GET'],
         'handler': 'test2'},
    ]
    router = Router()
    for route in routes:
        router.add(**route)
    router.finalize()



# Generated at 2022-06-21 23:49:10.332994
# Unit test for method finalize of class Router
def test_Router_finalize():
    # test value not in ALLOWED_LABELS
    with pytest.raises(SanicException):
        Router().finalize()

# Generated at 2022-06-21 23:49:11.882590
# Unit test for method add of class Router
def test_Router_add():
    pass


# Generated at 2022-06-21 23:49:23.656570
# Unit test for method add of class Router
def test_Router_add():
    r = Router()
    R1 = Route()
    R2 = Route()

    r.add(uri='/home', methods=['GET'], handler=None)
    R1.path = '/home'
    R1.ctx.methods = ('GET',)

    r.add(uri='/home', methods=['GET', 'POST'], handler=None)
    R2.path = '/home'
    R2.ctx.methods = ('GET', 'POST')

    fun = r.add(uri='/home', methods=['GET'], handler=None)
    R3 = Route()
    R3.path = '/home'
    R3.ctx.methods = ('GET',)

    assert r.get('/home', 'POST') == (R1, None, {})

# Generated at 2022-06-21 23:49:25.710058
# Unit test for constructor of class Router
def test_Router():
  a=Router()
  assert isinstance(a,Router)


# Generated at 2022-06-21 23:49:37.128644
# Unit test for method finalize of class Router
def test_Router_finalize():
    import sys
    import os
    import unittest
    import json
    import inspect
    from pathlib import Path

    currentdir = Path(os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe()))))
    parentdir = currentdir.parent
    sys.path.insert(0, str(parentdir))
    from server import app

    client = app.test_client()

    # If the returned HTTP code is 500, it means the method fails.
    resp = client.get("/__check-routes")
    assert resp.status_code == 500
    assert resp.json['message'].startswith("Invalid route: /users/<user_id>/uploads/<upload_id>/files/<path:file_path>")

# Generated at 2022-06-21 23:49:46.854336
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)
    assert router.DEFAULT_METHOD == 'GET'
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.ctx == None
    assert router.path_index == {}
    assert router.name_index == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == []


# Generated at 2022-06-21 23:49:48.441261
# Unit test for constructor of class Router
def test_Router():
    try:
        router = Router()
    except Exception as error:
        print(error)


# Generated at 2022-06-21 23:49:58.182570
# Unit test for method add of class Router
def test_Router_add():
    from sanic.response import html

    from controller.html import get_sample_html

    router = Router()
    router.add('/sample-html', ['GET'], get_sample_html, host=None, strict_slashes=False, stream=False, ignore_body=False, version=None, name='get_sample_html', unquote=False, static=False)

    result = router.get('/sample-html', 'GET', 'localhost:8000')
    assert isinstance(result, tuple)
    assert isinstance(result[0], Route)
    assert isinstance(result[1], get_sample_html)
    assert isinstance(result[2], dict)


# Generated at 2022-06-21 23:50:03.949891
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.version is None
    assert router.name_index == {}
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []
    assert router.ctx.app is None
    assert router.ctx.root_path is None


# Generated at 2022-06-21 23:50:11.707895
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    method = 'GET'
    host = 'localhost'
    path = '127.0.0.1'
    handler = {"a"}
    uri = "/"
    strict_slashes = False
    stream = False
    ignore_body = False
    version = 'a'
    name = None
    unquote = False
    static = False
    print(router.add(uri, method, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static))