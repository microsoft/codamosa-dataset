

# Generated at 2022-06-21 23:40:10.246554
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    # the variable is not a collection, raises exception
    try:
        router.finalize('toto')
    except SanicException as e:
        assert str(e) == "the variable is not a collection"

    # the variable contains params starting with '__', raises exception
    try:
        router.finalize([('hello', ['__toto'])])
    except SanicException as e:
        assert str(e) == "Invalid route: (hello, ['__toto']). " \
                "Parameter names cannot use '__'"

    # the variable doesn't contains params starting with '__', raises exception
    router.finalize([('hello', ['toto'])])

# Generated at 2022-06-21 23:40:18.490332
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException

    route = '''sanic.route("/<__something>", uri="/<__something>")'''

    router = Router()
    exec(route) in {"router": router, "sanic": {"route": router.add}}

    with pytest.raises(SanicException):
        router.finalize()

# Generated at 2022-06-21 23:40:21.175312
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        assert True == False
    except AssertionError:
        print("test_Router_finalize test failure")
    else:
        print("test_Router_finalize test success")

# Generated at 2022-06-21 23:40:32.273427
# Unit test for method add of class Router
def test_Router_add():
    """
    Test that the method add of class Router creates a new Route object
    with the given attributes as stated in the :func:add method.
    """
    # Create a new Router object
    r = Router()
    # Create a function that is the handler for the route
    # This function returns the string "Handler"
    def _handler():
        return "Handler"

    # Add the route to the router
    route = r.add(uri="test_path", methods=["GET"], handler=_handler, host=None,
                  strict_slashes=False, stream=False, ignore_body=False,
                  version=0.0, name=None, unquote=False)

    # Assert that the proper Route object was created
    assert(route.path == "test_path")
    assert(route.methods == {"GET"})
   

# Generated at 2022-06-21 23:40:36.697655
# Unit test for method add of class Router
def test_Router_add():
    x = Router()
    x.add(uri="", methods="", handler="", host="", strict_slashes="",
          stream="", ignore_body="", version="", name="", unquote="", static="")

# Generated at 2022-06-21 23:40:39.843510
# Unit test for constructor of class Router
def test_Router():
    app = Sanic('test_get_route')
    app.static('/static', './static')
    router = Router(app, {})
    assert router.ctx.app is app


# Generated at 2022-06-21 23:40:41.943156
# Unit test for method add of class Router
def test_Router_add():
    assert 1==1

# Generated at 2022-06-21 23:40:53.031362
# Unit test for method add of class Router
def test_Router_add():
    from sanic.response import json as json_response
    from sanic.testing import SanicTestClient
    from sanic.views import HTTPMethodView

    router = Router()

    class SimpleView(HTTPMethodView):
        def get(self, request):
            return json_response({"a": "b"})

    @router.add("/test")
    async def example(request):
        return json_response({"c": "d"})

    router.add(
        uri="/test/<id>",
        methods=["GET"],
        handler=HTTPMethodView().get,
        name="name",
    )
    router.add(
        uri="/no_name",
        methods=["GET"],
        handler=SimpleView().get,
    )

# Generated at 2022-06-21 23:40:56.075084
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router(autocorrect=False)

    with pytest.raises(SanicException) as excinfo:
        router.finalize()

    assert "parameter names cannot use" in str(excinfo.value).lower()


# Generated at 2022-06-21 23:41:02.353636
# Unit test for method add of class Router
def test_Router_add():
    router = Router()

    @router.add('/')
    # Define decorator with params
    def add_handler():
        pass

    assert len(router.routes_dynamic) == 1
    assert len(router.routes_regex) == 0
    assert len(router.routes_static) == 0


# Generated at 2022-06-21 23:41:12.965349
# Unit test for method finalize of class Router
def test_Router_finalize():
    route = Route(name='hello', path='/', methods=['GET'], handler=None, strict=False, unquote=False)
    router = Router(app_ctx=None)
    router.dynamic_routes['/'] = route
    try:
        router.finalize()
    except SanicException:
        return True
    else:
        return False

# Generated at 2022-06-21 23:41:26.403372
# Unit test for method add of class Router
def test_Router_add():
    # 测试methods为空
    router = Router()
    uri = 'uri'
    methods = []
    handler = 'handler'
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = 'name'
    unquote = False
    static = False
    assert router.add(uri, methods, handler, strict_slashes=strict_slashes,
                      stream=stream, ignore_body=ignore_body, version=version,
                      name=name, unquote=unquote, static=static) == []

    # 测试methods不为空
    router = Router()
    uri = 'uri'
    methods = ['GET']
    handler = 'handler'
    strict_slashes = False

# Generated at 2022-06-21 23:41:35.604829
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.function import Sanic
    class test_Router(Router):
        def finalize(self, *args, **kwargs):
            super().finalize(*args, **kwargs)
            self.finalized = True
    # This is the test case.
    # Sanic application is needed to create the class Router.
    sanic_app = Sanic()
    # This is the router object which is a subclass of Router.
    router = test_Router(sanic_app)
    assert router.finalized

# Generated at 2022-06-21 23:41:37.755842
# Unit test for constructor of class Router
def test_Router():
    router = Router()



# Generated at 2022-06-21 23:41:43.545931
# Unit test for constructor of class Router
def test_Router():
    from sanic.app import Sanic

    app = Sanic("test")
    router = Router(app)
    assert router.ctx.app == app

if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-21 23:41:51.784273
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        # test case 1: route is not valid
        router_obj = Router()
        router_obj.dynamic_routes = {
            "route1": Route(path="path1", labels=["__file_uri__", "label"])
        }
        router_obj.finalize()
    except SanicException as e:
        assert str(e) == "Invalid route: path1. Parameter names cannot use '__'."
    else:
        assert False


# Generated at 2022-06-21 23:42:04.805283
# Unit test for method add of class Router
def test_Router_add():
    test_uri = "/test-uri"
    test_handlers = ["GET", "PUT", "POST", "DELETE", "OPTIONS", "HEAD", "PATCH"]
    test_handler = RouteHandler()
    test_host = "test.host"
    test_strict_slashes = False
    test_stream = False
    test_ignore_body = False
    test_version = "1"
    test_name = "test_name"
    test_unquote = False

    # Create a router object
    router = Router(*[], **{})

    # Add a route with all options

# Generated at 2022-06-21 23:42:14.190415
# Unit test for method add of class Router
def test_Router_add():
    """
    test sanic.Router.add
    """
    path = "/example"
    methods = ["POST"]
    handler = "hello world"
    host = "192.168.1.1"
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = "test"

    router = Router(None)
    return_value = router.add(
        uri=path,
        methods=methods,
        handler=handler,
        host=host,
        strict_slashes=strict_slashes,
        stream=stream,
        ignore_body=ignore_body,
        version=version,
        name=name
    )
    assert return_value.ctx.hosts == [host]
    assert return_value.ctx.static == False

# Generated at 2022-06-21 23:42:17.491973
# Unit test for method add of class Router
def test_Router_add():
    from unittest.mock import Mock
    
    router = Router()
    router.add('/', ['something'], Mock())
    pass



# Generated at 2022-06-21 23:42:22.971240
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_test = Router()
    try:
        router_test.finalize()
    except SanicException as e:
        assert "Invalid route: {}. Parameter names cannot use '__'." in str(e)

# Generated at 2022-06-21 23:42:28.756379
# Unit test for method add of class Router
def test_Router_add():
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 23:42:30.683358
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert type(router) == Router

# Generated at 2022-06-21 23:42:41.662086
# Unit test for method finalize of class Router
def test_Router_finalize():

    import pytest

    # Allowed parameters
    # Dynamic routes

# Generated at 2022-06-21 23:42:52.977663
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes == {}
    assert router.ctx.app is None
    assert router.ctx.router == router
    assert router.ctx.hosts == [None]
    assert router.ctx.size == 0
    assert router._regex == []
    assert router._unknown_methods == []
    assert router._matches == []
    assert router._labels == set()
    assert router.name_index == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == []
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == []

#

# Generated at 2022-06-21 23:42:56.002581
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    @router.route("/")
    async def handler(request):
        pass

    with pytest.raises(SanicException):
        router.finalize()



# Generated at 2022-06-21 23:42:56.444684
# Unit test for method add of class Router
def test_Router_add():
    assert True

# Generated at 2022-06-21 23:42:59.765143
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == ("GET", "POST", "PUT", "PATCH", "DELETE",
                                      "HEAD", "OPTIONS", "TRACE")



# Generated at 2022-06-21 23:43:00.280654
# Unit test for method finalize of class Router
def test_Router_finalize():
    pass

# Generated at 2022-06-21 23:43:05.422583
# Unit test for method add of class Router
def test_Router_add():
    @lru_cache(maxsize=ROUTER_CACHE_SIZE)
    def _get(path, method, host=None):
        return Router().add(path=path, methods=method, handler="called", host=host)


# Generated at 2022-06-21 23:43:16.038358
# Unit test for method add of class Router
def test_Router_add():
    from sanic.app import Sanic

    from sanic_routing.route import Route

    app = Sanic("test_Router_add")
    app.config.KEEP_ALIVE_TIMEOUT = 30
    app.config.REQUEST_TIMEOUT = 40
    app.config.RESPONSE_TIMEOUT = 50
    router = Router()
    router.ctx = app
    ret = router.add(
        uri="/users/<username>",
        methods=["GET"],
        handler=lambda r, username: username,
        host="www.example.ru",
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version=None,
        name=None,
        unquote=False,
        static=False,
    )

# Generated at 2022-06-21 23:43:26.347281
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None


# Generated at 2022-06-21 23:43:31.610383
# Unit test for method finalize of class Router
def test_Router_finalize():
    with pytest.raises(SanicException):
        router = Router()
        route = Route("uri", "handler")
        route.labels.add("__Not_Allowed__")
        router.dynamic_routes["uri"] = route
        router.finalize()



# Generated at 2022-06-21 23:43:42.981727
# Unit test for constructor of class Router
def test_Router():
    uri='/test'
    methods=['GET', 'PUT', 'POST']
    host='http://localhost'
    handler=None
    strict_slashes=True
    stream=True
    unquote=False
    version='v:1000'
    name=None
    static=False

    routers = Router()
    router= routers.add(
        uri,
        methods,
        handler,
        host,
        strict_slashes,
        stream,
        unquote,
        version,
        name,
        static
        )
    assert router!=None

# Unit tests for function get() of class Router

# Generated at 2022-06-21 23:43:49.730296
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.router import ROUTER_CACHE_SIZE
    from sanic.router import Router as _Router



# Generated at 2022-06-21 23:43:52.710297
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    r.add(uri="/", methods=["GET"], handler=None)
    r.finalize()
    assert r.get("/", "GET", None) == (None, None, {})

# Generated at 2022-06-21 23:44:00.449543
# Unit test for method finalize of class Router
def test_Router_finalize():
    with pytest.raises(SanicException) as excinfo:
        router = Router(None)
        router.dynamic_routes = {}
        router.finalize()

    assert (
        str(excinfo.value)
        == "Invalid route: <Route: (GET, HEAD, OPTIONS) static_test>."
        " Parameter names cannot use '__'."
    )

# Generated at 2022-06-21 23:44:08.618568
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    Unit test for method finalize of class Router
    """
    router = Router()

    def method(request, text):
        """
        Handler for testing
        """
        print(text)

    router.add(
        uri='/path/to/method/{text}',
        methods=['GET'],
        handler=method,
        host=None,
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version=None,
        name=None,
        unquote=False,
        static=False,
    )

    try:
        router.finalize(None)
    except Exception as e:
        assert False, "The method should not raise any exception."


# Generated at 2022-06-21 23:44:19.777719
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    # Test basic add
    def some_handle():
        return None

    router.add('/some_url', ['GET', 'POST'], some_handle)
    assert router.get('/some_url', 'GET') != (None, None, None)
    assert router.get('/some_url', 'POST') != (None, None, None)
    assert router.get('/some_url_2', 'POST') == (None, None, None)

    # Test uri with version
    def some_handle_with_uri():
        return None

    router.add('/some_url', ['PUT'], some_handle_with_uri, version='2')
    assert router.get('/v2/some_url', 'PUT') != (None, None, None)

    # Test uri with version

# Generated at 2022-06-21 23:44:27.769148
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.router import Route
    router = Router()
    route = Route(
                    path="/test",
                    methods=HTTP_METHODS,
                    handler=lambda x: x,
                    name="test_route")
    router.dynamic_routes["/test"] = route
    try:
        router.finalize()
    except Exception as e:
        assert str(e) == "Invalid route: /test -> function_test. Parameter names cannot use '__'."
    else:
        assert False

# Generated at 2022-06-21 23:44:34.410768
# Unit test for method add of class Router
def test_Router_add():
    def handler(request): pass
    router = Router()
    routes = router.add("/uri", ["GET", "POST"], handler)
    assert isinstance(routes, list)
    assert routes[0].ctx.ignore_body is False
    assert routes[0].ctx.stream is False
    assert routes[0].ctx.hosts == [None]
    assert routes[0].ctx.static is False
    routes = router.add("/uri1", ["GET", "POST"], handler, static=True)
    assert isinstance(routes, list)
    assert routes[0].ctx.static is True

# Generated at 2022-06-21 23:44:55.635962
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    uri = "uri"
    methods = ["methods"]
    handler = "handler"

    route = router.add(uri, methods, handler)

    assert route.path == uri
    assert route.handler == handler
    assert route.methods == methods

# Generated at 2022-06-21 23:45:07.701596
# Unit test for method add of class Router
def test_Router_add():
    # A dummy class to test the method add, which is a member function of class Router.
    class FakeRouter(Router):
        def __init__(self):
            super().__init__()

    fake_router = FakeRouter()
    fake_methods = ["GET", "POST"]
    try:
        fake_router.add(
            uri = "fake_uri",
            methods = fake_methods,
            handler = "fake_handler",
            host = "fake_host",
            strict_slashes = False,
            stream = False,
            ignore_body = False,
            version = None,
            name = None,
            unquote = False,
            static = False
        )
    except:
        pass

# Generated at 2022-06-21 23:45:20.663284
# Unit test for method add of class Router
def test_Router_add():
    from sanic.exceptions import ServerError
    from sanic.response import text
    uri = '/'
    methods = ("GET")
    def handler(request,*arg,**kwargs):
        return text('hello')
    host = "localhost"
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = None
    unquote = False
    static = False
    router = Router()
    router.add(uri,methods,handler,host,strict_slashes,stream,ignore_body,version,name,unquote,static)
    assert isinstance(router,Router)
    router2 = Router()

# Generated at 2022-06-21 23:45:25.252038
# Unit test for method add of class Router

# Generated at 2022-06-21 23:45:26.793916
# Unit test for constructor of class Router
def test_Router():
    Router()


if __name__ == '__main__':
    test_Router()

# Generated at 2022-06-21 23:45:39.947247
# Unit test for method add of class Router
def test_Router_add():
    from sanic_routing.route import Route
    from sanic.constants import SERVER_DOCS
    from sanic import Sanic
    from sanic.views import HTTPMethodView
    app = Sanic('test_Sanic_config')
    app.config.REQUEST_MAX_SIZE = 100
    app.config.REQUEST_TIMEOUT = 60
    app.config.RESPONSE_TIMEOUT = 60
    app.config.KEEP_ALIVE = False
    app.config.KEEP_ALIVE_TIMEOUT = 5
    app.config.SERVER_NAME = 'sanic'
    app.config.RETURN_AS_COROUTINE = False
    app.config.ACCESS_LOG = True
    app.config.LOGO = None
    app.config.ERROR_LOGGER = True
   

# Generated at 2022-06-21 23:45:41.010890
# Unit test for method add of class Router
def test_Router_add():
    pass


# Generated at 2022-06-21 23:45:42.420601
# Unit test for constructor of class Router
def test_Router():
    assert 'Router' == Router().__class__.__name__

# Generated at 2022-06-21 23:45:44.052679
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert isinstance(r, Router)

# Generated at 2022-06-21 23:45:48.949028
# Unit test for method finalize of class Router
def test_Router_finalize():
    app = None
    router = Router(app)
    for route in router.dynamic_routes.values():
        if any(
            label.startswith("__") and label not in ALLOWED_LABELS
            for label in route.labels
        ):
            assert False
        else:
            assert True



# Generated at 2022-06-21 23:46:20.074114
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add("/uri", ("GET", "POST"), handler=None)
    assert len(router.routes) == 2

# Generated at 2022-06-21 23:46:21.448188
# Unit test for constructor of class Router
def test_Router():
    test_router = Router()
    assert isinstance(test_router, Router)

# Generated at 2022-06-21 23:46:30.286918
# Unit test for method finalize of class Router
def test_Router_finalize():
    final_router = Router()
    for meth in ["get", "post", "put", "patch", "delete", "head", "options"]:
        final_router.add("/", {"host": "example.com"}, "handler", [meth])
        final_router.add("/", {"host": "example.com"}, "handler", [meth], name="hello")
        final_router.add("/", {"host": "example.com"}, "handler", [meth], strict_slashes=True)
    final_router.finalize()
    assert True

# Generated at 2022-06-21 23:46:32.940704
# Unit test for constructor of class Router
def test_Router():
    router_test = Router()
    assert isinstance(router_test, Router)
    assert router_test.DEFAULT_METHOD == "GET"
    

# Generated at 2022-06-21 23:46:34.000493
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    return router

# Generated at 2022-06-21 23:46:44.140845
# Unit test for method add of class Router
def test_Router_add():
    from sanic.handlers import ErrorHandler  # type: ignore

    # Declare variables
    uri = ""
    methods = ("GET", "POST")
    handler = ErrorHandler()
    host = Optional[str]
    strict_slashes = False
    stream = False
    ignore_body = False
    version = 1
    name = None
    unquote = False
    static = False

    # Create object
    router = Router(None)

    # Test add

# Generated at 2022-06-21 23:46:46.684767
# Unit test for constructor of class Router
def test_Router():
    assert Router

# Generated at 2022-06-21 23:46:49.537482
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add('/', 'GET', test_Router_add, False)

    assert len(router.dynamic_routes) == 1

# Generated at 2022-06-21 23:46:53.784206
# Unit test for method add of class Router
def test_Router_add():
    from sanic.app import Sanic

    app = Sanic('test_Router_add')
    router = Router(app)
    async def index(request, view_args):
        return text('OK')
    router.add('/wiki/<page>', ['GET'], index)



# Generated at 2022-06-21 23:46:55.593384
# Unit test for constructor of class Router
def test_Router():
    instance = Router()
    assert isinstance(instance, Router)
    assert isinstance(instance, BaseRouter)


# Generated at 2022-06-21 23:47:46.797629
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    
    assert router.DEFAULT_METHOD == 'GET'
    assert router.ALLOWED_METHODS == ('OPTIONS', 'HEAD', 'GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'TRACE')

# Generated at 2022-06-21 23:47:47.679713
# Unit test for constructor of class Router
def test_Router():
    assert isinstance(Router(), Router)

# Generated at 2022-06-21 23:47:48.871027
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)



# Generated at 2022-06-21 23:47:54.244727
# Unit test for method add of class Router
def test_Router_add():
    async def async_handler(request):
        return "OK"

    def handler(request):
        return "OK"

    router = Router()

    router.add("/test", "GET", handler)
    router.add("/test_async", "GET", async_handler)

    # can't add same path with different handler
    with pytest.raises(SanicException) as exc:
        router.add("/test", "POST", async_handler)
    assert "Route already exists" in str(exc.value)

    # can add same path with same handler
    router.add("/test", "POST", handler)
    assert (router.get("/test", "POST"))[1] == handler

    # can add same path with different handler
    router.add("/test", "OPTIONS", async_handler)
   

# Generated at 2022-06-21 23:47:55.389147
# Unit test for method finalize of class Router
def test_Router_finalize():
    pass #TODO

# Generated at 2022-06-21 23:47:56.522168
# Unit test for method add of class Router
def test_Router_add():
    Router.add()

# Generated at 2022-06-21 23:48:09.716089
# Unit test for method add of class Router
def test_Router_add():
    from sanic import Sanic
    from sanic.response import json
    app = Sanic('sanic')

    # Case 1:
    @app.route('/url/001', methods=['GET'])
    async def handler001(request):
        return json({"key": "value"})

    # Case 2:
    @app.route('/url/002', methods=['GET', 'POST'], host='localhost')
    async def handler002(request):
        return json({"key": "value"})

    # Case 3:
    @app.route('/url/003', methods=['GET'], strict_slashes=True)
    async def handler003(request):
        return json({"key": "value"})

    # Case 4:

# Generated at 2022-06-21 23:48:11.732956
# Unit test for constructor of class Router
def test_Router():
    router = Router()  
    assert isinstance(router, Router)


# Generated at 2022-06-21 23:48:22.786926
# Unit test for method add of class Router
def test_Router_add():
    from sanic.response import html
    from sanic.views import HTTPMethodView
    from sanic.server import HttpProtocol
    import re

    app = sanic.Sanic()
    router = Router()
    router.ctx.app = app
    router.finalize()
    url = "http://localhost:5000/"
    path = url


# Generated at 2022-06-21 23:48:28.108149
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    super(Router, router).finalize([])
    assert router.routes_all == {}
    assert router.routes_dynamic == {}
    assert router.dynamic_routes == {}
    assert router.routes_static == {}
    assert router.static_routes == {}
    assert router.routes_regex != {}
    assert router.regex_routes != {}
