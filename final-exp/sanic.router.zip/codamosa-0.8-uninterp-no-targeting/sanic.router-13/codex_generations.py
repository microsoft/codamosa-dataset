

# Generated at 2022-06-21 23:40:25.771706
# Unit test for method finalize of class Router
def test_Router_finalize():
    import sanic
    app = sanic.Sanic("Test Sanic")
    router = sanic.Router(app)
    host = '127.0.0.1'
    path = '/'
    handler = app.handler
    method = 'GET'
    kwargs = dict()

    try:
        router.add(path,host=host,methods=method,handler=handler)
    except Exception as e:
        pass
    else:
        assert False, "EXCEPTION NOT RAISED"

    try:
        router.add(path,methods=method,handler=handler,**kwargs)
    except Exception as e:
        assert False, f"EXCEPTION RAISED: {e}"
    else:
        pass

if __name__ == '__main__':
    test_Router_

# Generated at 2022-06-21 23:40:29.365895
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS

# Generated at 2022-06-21 23:40:37.826164
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Initializing arguments
    args = ()
    # Initializing keyword arguments
    kwargs = {}
    args_ = []
    kwargs_ = {}

    # Call to finalize
    # Raises:
    #     SanicException:
    #         [Invalid route: <sanic_routing.route.Route object at 0x1042a3550>. Parameter names cannot use '__'.]
    # 
    # multiple parameters with double underscores are invalid

    for route in self.dynamic_routes.values():
        if any(
            label.startswith("__") and label not in ALLOWED_LABELS
            for label in route.labels
        ):
            raise SanicException(
                f"Invalid route: {route}. Parameter names cannot use '__'."
            )


# Generated at 2022-06-21 23:40:48.327568
# Unit test for method add of class Router
def test_Router_add():
    class TestServer:
        pass

    @asyncio.coroutine
    def handler(request):
        return None

    router = Router(TestServer(), [])
    routes = router.add("/test", "GET", handler)
    assert len(router.routes_static) == 1
    assert len(router.static_routes) == 1
    assert len(router.static_routes["/test"].method_routes["GET"]) == 1
    assert len(router.path_index["/test"]) == 1
    assert next(iter(router.path_index["/test"])).path == "/test"
    assert next(iter(router.path_index["/test"])).methods == {"GET"}

# Generated at 2022-06-21 23:40:48.989361
# Unit test for method finalize of class Router
def test_Router_finalize():
    assert True

# Generated at 2022-06-21 23:40:51.173660
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert(r)

# Generated at 2022-06-21 23:40:56.893973
# Unit test for constructor of class Router
def test_Router():
    # Test case 1
    router = Router()
    assert isinstance(router, Router)
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS

# Generated at 2022-06-21 23:41:08.531723
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    # Test without error
    r = Router()
    r.append('/{name}/{surname}').with_ctx('route.parameters', {'name': 'John', 'surname': 'Smith'})
    r.finalize()

    # Test with error
    r = Router()
    r.append('/{__asd}/{asd}/{}').with_ctx('route.parameters', {'__asd': 'asd', 'asd': 'asd', '': 'asd'})
    with pytest.raises(SanicException) as exc:
        r.finalize()


# Generated at 2022-06-21 23:41:17.246050
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest

    # Create an instance of class Router
    router = Router()

    # Add routes to router
    @router.route('/')
    async def handle_request(_):
        pass

    @router.route('/<param>')
    async def handle_request(_):
        pass

    # The method finalize of class Router will be called
    with pytest.raises(SanicException) as exc:
        router.finalize()

    assert str(exc.value) == \
           "Invalid route: Route(GET, /<param>, handler=handle_request, host=None). Parameter names cannot use '__'."

test_Router_finalize()

# Generated at 2022-06-21 23:41:25.468303
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    # Create object with bad labels
    route = Router()
    route.dynamic_routes = {1: {'labels': ['__file_uri__', '__not_allowed__']}}
    with pytest.raises(SanicException):
        route.finalize()

    # Create object with bad labels
    route = Router()
    route.dynamic_routes = {1: {'labels': ['__file_uri__']}}
    route.finalize()

# Generated at 2022-06-21 23:41:41.254471
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    router = Router()

# Generated at 2022-06-21 23:41:46.751708
# Unit test for constructor of class Router
def test_Router():
    try:
        # pass
        router = Router()
    except Exception as e:
        error_msg = 'Test `{0}` fail\n  Raise error "{1.__class__.__name__}: {1}"'
        print(error_msg.format("test_Router", e))

# Unit tests for method add of class Router

# Generated at 2022-06-21 23:41:59.326044
# Unit test for method add of class Router
def test_Router_add():
    # Test: Add a route to router
    r = Router()
    r.add("/path/<file>", methods=["GET", "POST", "OPTIONS"], handler=test_handler)
    assert r.routes_dynamic
    assert r.routes_regex
    assert r.routes_static
    assert r.routes_all
    assert r.nodes
    assert r.name_index

    # Test: Use an invalid label
    r = Router()
    try:
        r.add("/path/<__file>", methods=["GET", "POST", "OPTIONS"], handler=test_handler)
    except SanicException:
        assert True
    # Test: Add a route to router with version
    r = Router()

# Generated at 2022-06-21 23:42:08.445431
# Unit test for method add of class Router
def test_Router_add():
    import inspect
    import sys
    from sanic.response import json

    def hello():
        return json({"hello": "world"})

    router = Router(app=None)
    router.add("/hi", ["GET"], hello)
    assert router.find_route_by_view_name("hello")[0] == '/hi'
    assert inspect.iscoroutinefunction(router.find_route_by_view_name("hello")[1].handler) == False
    assertrouter.find_route_by_view_name("hello")[1].methods == ["GET"]
    assertrouter.find_route_by_view_name("hello")[1].ctx.hosts == [None]
    assertrouter.find_route_by_view_name("hello")[1].ctx.static == False
    assertrou

# Generated at 2022-06-21 23:42:19.857937
# Unit test for method add of class Router
def test_Router_add():
    from sanic.request import Request
    from sanic.response import HTTPResponse, text
    from sanic.server import create_server  
    from sanic.app import Sanic

    server = create_server(app=Sanic(), host=None, port=None, run_async=False)
    request = Request(b'GET', b'/', headers={})
    response = HTTPResponse(text='OK', headers={})

    @server.app.route('/', methods=['GET'])
    def handler(request):
        return response

    assert server.app.router.routes[0].uri == '/'
    assert server.app.router.routes[0].handler == handler


# Generated at 2022-06-21 23:42:29.542372
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router(None)
    
    def _test_function():
        route = Route(path='/hello', handler=None, methods=None, name=None, strict=False, unquote=False)
        route.labels = ['__label1__', '__label2__']
        route.handler = _test_function
        router.dynamic_routes['/hello'] = route
        with pytest.raises(SanicException):
            router.finalize()
    
    _test_function()        
    
test_Router_finalize()

# Generated at 2022-06-21 23:42:31.441379
# Unit test for constructor of class Router
def test_Router():
    assert isinstance(Router(ctx={}), Router)
    return


# Generated at 2022-06-21 23:42:41.942834
# Unit test for method add of class Router
def test_Router_add():
    # create a router
    router1 = Router()
    router1.add("/test", "GET", lambda req: None)
    router2 = Router()
    router2.add("/test/<test>", "GET", lambda req: None)
    router3 = Router()
    router3.add("/test/<test>", "PUT", lambda req: None)
    router4 = Router()
    router4.add("/test/<test>", "POST", lambda req: None)
    router5 = Router()
    router5.add("/test/<test>", ("GET","POST"), lambda req: None)
    router6 = Router()
    router6.add("/test/<test>", ("GET","POST","PUT"), lambda req: None)

    # test the type of attributes

# Generated at 2022-06-21 23:42:44.746956
# Unit test for constructor of class Router
def test_Router():
  router = Router(None)
  assert isinstance(router, Router)

# Generated at 2022-06-21 23:42:49.874308
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    from sanic import Sanic

    app = Sanic("sanic-router")
    router = Router()

    with pytest.raises(SanicException):
        @router.route("/test")
        def test_handler(request, name__from__uri):
            pass
        
        router.finalize(app)

# Generated at 2022-06-21 23:43:05.580959
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}

# Generated at 2022-06-21 23:43:16.069013
# Unit test for method add of class Router
def test_Router_add():
    uri = "a/uri"
    methods = ["GET", "POST", "OPTIONS"]
    handler = ""
    host = "www.example.com"
    strict_slashes = True
    stream = True
    ignore_body = True
    version = "1"
    name = "a_route"
    unquote = True
    static = True
    route = Router().add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)
    assert route.ctx.ignore_body == ignore_body
    assert route.ctx.path == uri
    assert route.ctx.methods == methods
    assert route.ctx.hosts == [host]
    assert route.ctx.stream == stream
    assert route.ctx.static == static



# Generated at 2022-06-21 23:43:19.827428
# Unit test for method add of class Router
def test_Router_add():
    def handler():
        pass

    router = Router()
    router.add("/test", "GET", handler)
    assert "/test" in router.static_routes
    assert len(router.static_routes) > 0


# Generated at 2022-06-21 23:43:22.453053
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    print(r.ctx)


# Generated at 2022-06-21 23:43:34.447394
# Unit test for method add of class Router
def test_Router_add():
    from sanic_routing.route import Route
    from sanic.router import Router
    from sanic import Sanic
    from sanic.response import json
    app = Sanic('test_Router_add')
    router = Router(app)
    routes = router.routes_all
    uri = '/test'
    methods = ['GET','POST','PUT','PATCH','DELETE','OPTIONS','HEAD']
    handler = json({'name': 'test'}, status=200)
    host = None
    strict_slashes = False
    stream = False
    ignore_body = False
    name = 'test'
    static = False
    route = router.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, name, static)

# Generated at 2022-06-21 23:43:37.772750
# Unit test for constructor of class Router
def test_Router():
    import sanic
    app = sanic.Sanic(__name__)
    routes = Router(app)
    assert routes.ctx == app

# Generated at 2022-06-21 23:43:40.917574
# Unit test for method add of class Router
def test_Router_add(): # pragma: no cover
    try:
        router = Router()
        router.add(
            uri="/",
            methods=["GET"],
            handler="handler",
            version=2,
        )
    except SanicException:
        assert True
        return
    assert False


# Generated at 2022-06-21 23:43:54.385703
# Unit test for method finalize of class Router
def test_Router_finalize():
    methods = ("DELETE", "GET", "HEAD",
               "OPTIONS", "PATCH", "POST", "PUT")
    router = Router()
    route = router.add("/", methods, ...)
    assert route.methods == methods
    assert route.ctx.ignore_body is False
    assert route.ctx.stream is False
    assert route.ctx.hosts == [None]
    assert route.ctx.static is False
    route = router.add("/", methods, ..., stream=True)
    assert route.methods == methods
    assert route.ctx.ignore_body is False
    assert route.ctx.stream is True
    assert route.ctx.hosts == [None]
    assert route.ctx.static is False
    route = router.add("/", methods, ..., ignore_body=True)
   

# Generated at 2022-06-21 23:44:06.269040
# Unit test for method add of class Router
def test_Router_add():
    import pytest
    from sanic.constants import HTTP_METHODS
    from sanic.exceptions import MethodNotSupported, NotFound
    from sanic.models.handler_types import RouteHandler
    router = Router()
    test_uri = 'www.google.com'
    test_methods = ['GET', 'POST', 'OPTIONS']
    test_handler = None
    test_host = 'www.google.com'
    test_name = 'test'
    test_unquote = True
    test_static = True
    result = router.add(test_uri, test_methods, test_handler, host=test_host, 
    name=test_name, unquote=test_unquote, static=test_static)
    for i in result:
        assert i.path == test_uri

# Generated at 2022-06-21 23:44:13.528208
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    uri = '/'
    methods = ['GET']
    handler = None
    host = None
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = None
    unquote = False
    static = False
    test = router.add(uri,methods,handler,host,strict_slashes,stream,ignore_body,version,name,unquote,static)
    assert test is not None, "test should return a Route but return None"
    assert isinstance(test,Route)


# Generated at 2022-06-21 23:44:47.227303
# Unit test for method add of class Router
def test_Router_add():
    import sys
    import io
    from sanic.app import Sanic
    from sanic.response import json
    from contextlib import contextmanager


    app = Sanic('test_Router_add')
    router = Router()
    router.add('/test_Router_add/', ['GET'] , test_Router_add_handler,
               host='sanic-test-host.com')

    captured = io.StringIO()
    @contextmanager
    def stdout_redirector(stream):
        old_stdout = sys.stdout
        sys.stdout = stream
        try:
            yield
        finally:
            sys.stdout = old_stdout

    with stdout_redirector(captured):
        router.finalize(app)

    assert router.ctx.app == app
    assert router

# Generated at 2022-06-21 23:44:52.405688
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest

    router = Router()
    route = Route("/<bla:blub>")
    route.ctx.labels = {"__file_uri__", "__bla__"}
    with pytest.raises(SanicException):
        router.finalize([route])


__all__ = ["Router"]

# Generated at 2022-06-21 23:44:57.421216
# Unit test for method add of class Router
def test_Router_add():
    route = Router._get(  # type: ignore
        path="Router_add",
        method="GET",
        host=None,
    )
    assert route == ()


# Generated at 2022-06-21 23:45:01.091284
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert 'Router' == router.__class__.__name__
    assert id(router) == id(router.routes_all)

# Generated at 2022-06-21 23:45:05.373737
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Default test
    try:
        r = Router()
        assert not r.finalize()
    except Exception as e:
        print(e)

    # Test for invalid route
    try:
        r = Router()
        r.add("/invalid", "GET", lambda r: "")
        assert not r.finalize()
    except Exception as e:
        print(e)

# Generated at 2022-06-21 23:45:14.724292
# Unit test for method add of class Router
def test_Router_add():
    print("Start test_Router_add")
    #
    # def print_hello():
    #     return "Hello"
    #
    # def print_world():
    #     return "world"
    #
    # router = Router()
    # router.add('/<name>/<id>', ["GET"], print_hello)
    # routes = router.routes_dynamic
    # for (key, value) in routes.items():
    #     print(key, value)
    #
    # print(Router.get(router, "/hello/3", "GET"))
    #
    # for key in router.__dict__.keys():
    #     print(key, router.__dict__[key])
    #
    # print(router.find_route_by_view_name('hello'

# Generated at 2022-06-21 23:45:22.687263
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Set up objects
    # TODO: use mock libraries
    args = ()
    kwargs = {}
    router = Router(args, kwargs)

    label = {'__file_uri__', 'yolo'}
    label_not_allowed = {'__file_uri__', '__yolo__'}

    class test_route():
        labels = label

    class test_route_not_allowed():
        labels = label_not_allowed

    route = test_route()
    route_not_allowed = test_route_not_allowed()

    router.dynamic_routes.update({'a': route, 'b': route_not_allowed})

    with pytest.raises(SanicException):
        router.finalize()

# Generated at 2022-06-21 23:45:24.807565
# Unit test for constructor of class Router
def test_Router():
    assert issubclass(Router, BaseRouter)


# Generated at 2022-06-21 23:45:26.892396
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    with pytest.raises(SanicException):
        router.finalize(None, None)

# Generated at 2022-06-21 23:45:33.658827
# Unit test for constructor of class Router
def test_Router():
    
    router = Router()

    assert router.routes_all == {}
    assert router.routes_static == set()
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.routes_all == router.routes_all




# Generated at 2022-06-21 23:45:59.390842
# Unit test for constructor of class Router
def test_Router():
    router=Router()
    assert router.router_type=='sanic_routing.router'
    assert router.ctx.app==None
    assert router.ctx.paths==set()
    assert router.ctx.paths==set()


        

# Generated at 2022-06-21 23:46:12.229430
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic_routing.router import Router
    from sanic.response import json
    import time
    import pytest

    @lru_cache(maxsize=ROUTER_CACHE_SIZE)
    def _get(*args, **kwargs):
        url, method, host = args[0], args[1], args[2]
        return url, method, host

    @lru_cache(maxsize=ROUTER_CACHE_SIZE)
    def get(*args, **kwargs):
        url, method, host = args[0], args[1], args[2]
        return url, method, host

    @property
    def routes_all(self):
        return self.routes

    @property
    def routes_static(self):
        return self.static_routes


# Generated at 2022-06-21 23:46:23.672562
# Unit test for method add of class Router
def test_Router_add():
    import sanic_routing
    router = Router()
    # TODO: set these params to exact values
    uri = "str"
    methods = "Iterable[str]"
    handler = "sanic.models.handler_types.RouteHandler"
    host = "Optional[Union[str, Iterable[str]]]"
    strict_slashes = "bool"
    stream = "bool"
    ignore_body = "bool"
    version = "Union[str, float, int]"
    name = "Optional[str]"
    unquote = "bool"
    static = "bool"
    

# Generated at 2022-06-21 23:46:32.929736
# Unit test for constructor of class Router
def test_Router():
    from sanic import Sanic
    from sanic.router import Router
    app = Sanic(__name__)
    router = Router(os.path.join(os.path.dirname(__file__), "config"), app)
    assert router.router_cache_size == 1024
    assert router.router_cache_size == 1024
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}

if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-21 23:46:34.406660
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    print(router)


# Generated at 2022-06-21 23:46:44.448887
# Unit test for method finalize of class Router
def test_Router_finalize():
    def f(request, *args, **kwargs):
        pass
    route1 = Route(
        path="/",
        methods=["GET"],
        handler=f,
        name="index",
        strict=False,
        unquote=True,
    )
    route1.labels = {"__file_uri__": "some/path", "invalid": "invalid"}
    route2 = Route(
        path="/",
        methods=["GET"],
        handler=f,
        name="index",
        strict=False,
        unquote=True,
    )
    route2.labels = {"invalid": "invalid"}
    router = Router()
    router.dynamic_routes = {"": [route1, route2]}
    with pytest.raises(SanicException) as exception:
        router

# Generated at 2022-06-21 23:46:50.610862
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    for label in ALLOWED_LABELS:
        router.add("/test/label/{}".format(label))
    try:
        router.add("/test/label/{__invalid}")
        assert False, 'Exception did not raised'
    except SanicException:
        pass

# Generated at 2022-06-21 23:46:53.636717
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router(None)
    route_handler = None
    router.finalize(route_handler)

    try:
        router.finalize()
        assert False
    except Exception:
        assert True

# Generated at 2022-06-21 23:46:59.544100
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    assert router.routes_dynamic == {}
    router.add("/static", ["GET"], "handler", static=True)
    assert router.routes_dynamic == {}
    router.add("/dynamic/<label>", ["GET"], "handler", static=False)
    assert len(router.routes_dynamic) != 0


# Generated at 2022-06-21 23:47:11.910108
# Unit test for method add of class Router
def test_Router_add():
    route_uri = "/"
    methods = ["GET","POST","OPTIONS"]
    handler = asyncio.coroutine
    host = None
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = None
    unquote = False
    static = False
    route = Router().add(  # type: ignore
        uri=route_uri,
        methods=methods,
        handler=handler,
        host=host,
        strict_slashes=strict_slashes,
        stream=stream,
        ignore_body=ignore_body,
        version=version,
        name=name,
        unquote=unquote,
        static=static,
    )
    assert isinstance(route,Route)

# Generated at 2022-06-21 23:48:02.630402
# Unit test for method finalize of class Router

# Generated at 2022-06-21 23:48:04.793267
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-21 23:48:09.149641
# Unit test for method finalize of class Router
def test_Router_finalize():
    # create a Router obj
    r = Router()

    # add a route to r
    route = r.add(uri='/path/<param>', methods=["GET"], handler=None)
    route.labels.update({'__label1__': None, 'label2': None})

    # call on r.finalize
    r.finalize()

# Generated at 2022-06-21 23:48:15.154191
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    methods = ['GET', 'POST']
    handler = RouteHandler()
    host = 'localhost'
    uri = '/'
    router.add(
        uri, methods, handler, host, strict_slashes=True, stream=True,
        ignore_body=True, version=1, name='foo')

# Generated at 2022-06-21 23:48:24.979174
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route(path='/test', handler=lambda request: None, methods=["GET"])
    route.label_params.add('__file_uri__')
    router.dynamic_routes['test'] = [route]

    # Check for if exist route with label name that startswith "__" and not in allowed labels
    try:
        router.finalize()
    except SanicException as e:
        print(f'Expected: {e}')
    else:
        assert False

test_Router_finalize()

# Generated at 2022-06-21 23:48:35.621957
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route(None, None, None, {"a": "b", "__file_uri__": "something"})
    router.dynamic_routes["some_route"] = route
    # no exception cause it has label "__file_uri__"
    router.finalize()
    # exception cause it has label "__file_uri__"
    route.labels = {"__file_uri__": "something"}
    try:
        router.finalize()
    except Exception:
        return
    assert False

# Generated at 2022-06-21 23:48:39.998765
# Unit test for constructor of class Router
def test_Router():
    # Definir e iniciar o Router
    my_router = Router()
    assert my_router

test_Router()

# Generated at 2022-06-21 23:48:44.034876
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException

    with pytest.raises(SanicException):
        Router().finalize()


# Generated at 2022-06-21 23:48:51.375678
# Unit test for method finalize of class Router
def test_Router_finalize():
    from _pytest.monkeypatch import MonkeyPatch
    from sanic import Sanic

    app = Sanic("foo")
    monkeypatch = MonkeyPatch()

    monkeypatch.setattr(
        Route,
        "get_labels",
        lambda x: ["hello", "__world__", "__file_uri__", "name"],
    )

    monkeypatch.setattr(
        Route,
        "__repr__",
        lambda x: "Route('/route/__world__')",
    )

    try:
        router = Router(app)
        exception = router.finalize()
    except Exception as e:
        exception = e

    assert "Route('/route/__world__')" in str(exception)



# Generated at 2022-06-21 23:48:52.028433
# Unit test for constructor of class Router
def test_Router():
    a = Router()

# Generated at 2022-06-21 23:49:24.753160
# Unit test for constructor of class Router
def test_Router():
    routes = Router()
    assert issubclass(type(routes), BaseRouter) == True  # base class check
    assert isinstance(routes, Router) == True  # type check

# Generated at 2022-06-21 23:49:36.626910
# Unit test for constructor of class Router
def test_Router():
    class MockRouter(Router):
        def _get(
            self, path: str, method: str, host: Optional[str]
        ) -> Tuple[Route, RouteHandler, Dict[str, Any]]:
            return self.resolve(
                path=path,
                method=method,
                extra={"host": host},
            )

    router = MockRouter()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.finalized == False
    assert isinstance(router.routes, dict) == True
    assert isinstance(router.routes_all, dict) == True
    assert isinstance(router.routes_regex, dict) == True

# Generated at 2022-06-21 23:49:47.202836
# Unit test for constructor of class Router
def test_Router():
    # create an instance of Router
    router = Router()
    router.add("/", HTTP_METHODS, "handler")
    router.finalize()
    assert router.routes == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.static_lookup == {}
    assert router.reverse_lookup == {}
    assert router.name_index == {}
    assert router.not_found_handler == None

# Generated at 2022-06-21 23:49:58.309539
# Unit test for constructor of class Router
def test_Router():
    methods = ['GET']
    host = 'localhost:8000'

    router = Router()
    # method '_get'
    path = '/'
    method = 'GET'
    # expected_route, expected_route_handler, expected_dict = router._get(path, method, host)
    expected_route = '/'
    expected_route_handler = None
    expected_dict = dict()
    actual_route, actual_route_handler, actual_dict = router._get(path, method, host)
    assert actual_route == expected_route
    assert actual_route_handler == expected_route_handler
    assert actual_dict == expected_dict
    
    # method 'get'
    path = '/'
    method = 'GET'
    expected_route = '/'
    expected_route_handler = None

# Generated at 2022-06-21 23:50:05.953511
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes == {}
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}

    @router.get('/')
    def handler(request):
        pass

    assert 'GET' in router.routes['/']
    assert 'GET' in router.routes_all['/']
    assert 'GET' in router.routes_static['/']
    assert 'GET' not in router.routes_dynamic
    assert 'GET' not in router.routes_regex


# Generated at 2022-06-21 23:50:14.090048
# Unit test for constructor of class Router
def test_Router():
    uri = "/test/<id>"
    methods = ['GET']
    host = 'localhost'
    handler = "test"
    strict_slashes = False
    stream = True
    ignore_body = True
    version = "1.0.0"
    name = "test_name"
    unquote = False
    static = False

    r = Router()
    r.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)