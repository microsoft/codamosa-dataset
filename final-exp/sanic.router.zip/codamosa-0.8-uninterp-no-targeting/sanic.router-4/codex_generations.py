

# Generated at 2022-06-21 23:40:26.606065
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    r1 = Route(
        "/abc/{__a}/{__file_uri__}",
        methods={"GET", "POST", "DELETE"},
    )
    r2 = Route(
        "/def/{__b}/",
        methods={"GET", "POST", "DELETE"},
    )
    router.routes_dynamic[r1.ctx.id] = r1
    router.routes_dynamic[r2.ctx.id] = r2

    router.finalize()



# Generated at 2022-06-21 23:40:28.452899
# Unit test for constructor of class Router
def test_Router():
    assert Router(root=None)

# Generated at 2022-06-21 23:40:35.498086
# Unit test for method add of class Router
def test_Router_add():
    from sanic import Sanic
    from sanic.response import html

    def simple_html(request, name):
        return html("<h1>Hello {0}. It works!</h1>".format(name))

    app = Sanic("simple_html_app")

    # Use function add
    app.add_route(simple_html, '/', 'GET')
    assert app.router.routes_all == {'GET': ['/']}

    # Use decorator
    @app.route("/hello/<name>")
    async def say_hello(request, name):
        return html("<h1>Hello {0}</h1>".format(name))

    assert app.router.routes_all == {'GET': ['/', '/hello/<name>']}


# Generated at 2022-06-21 23:40:38.680176
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"



# Generated at 2022-06-21 23:40:40.609340
# Unit test for constructor of class Router
def test_Router():
    a = Router()
    assert isinstance(a, Router)


# Generated at 2022-06-21 23:40:45.063827
# Unit test for method add of class Router
def test_Router_add():
    """
    Unit test for method add of class Router
    """
    router = Router()
    assert router.routes == {}
    router.add('/', ['GET'], None)
    assert len(router.routes) == 1
    router.add('/', ['POST'], None)
    assert len(router.routes) == 1
    router.add('/test', ['POST'], None)
    assert len(router.routes) == 2
    router.add('/test', ['GET'], None)
    assert len(router.routes) == 2


# Generated at 2022-06-21 23:40:48.690234
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    def test_handler():
        pass
    router.add('/test', ['GET'], test_handler)
    assert router.routes_all['GET'][0].path == '/test'
    assert router.routes_all['GET'][0].handler == test_handler


# Generated at 2022-06-21 23:40:51.630266
# Unit test for constructor of class Router
def test_Router():
    # TODO: Remove this method when we have tests with pytest
    router = Router()
    assert router

# Generated at 2022-06-21 23:40:53.260515
# Unit test for method add of class Router
def test_Router_add():
    1 == 1

# Generated at 2022-06-21 23:41:03.853281
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    app = Sanic('test')
    router = Router()
    app.add_route(lambda x, *args, **kwargs: None, '/__cannot_use_the_prefix',
                  methods=['GET'])
    with pytest.raises(SanicException):
        router.finalize(app, None, method_override=None, strict_slashes=None)
    app.add_route(lambda x, *args, **kwargs: None, '/__file_uri__',
                  methods=['GET'])
    router.finalize(app, None, method_override=None, strict_slashes=None)

# Generated at 2022-06-21 23:41:21.505209
# Unit test for method finalize of class Router
def test_Router_finalize():
    from urllib.parse import unquote

    class MockApp(object):
        def _generate_name(*_):
            return "full_name"

        def on_startup(*_):
            pass

    class MockRoute(object):
        def __init__(self):
            self.labels = ["__f_u__", "__file_u_r_i__"]

    mock_routes = {unquote("x/x"): [MockRoute()]}

    class MockRouter(Router):
        def __init__(self):
            self.dynamic_routes = mock_routes
            self.ctx = MockApp()

    test = MockRouter()
    test.finalize()

    # Testing if not raise any SanicException
    assert True

# Generated at 2022-06-21 23:41:27.539986
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    r.dynamic_routes['a'] = Route('/a/:b')
    r.dynamic_routes['b'] = Route('/b/:b', labels={'__b'})

    assert r.finalize() == None
    try:
        r.dynamic_routes['a'].labels = {'__b'}
        r.finalize()
        assert False
    except Exception as e:
        assert 'invalid' in e.args[0].lower()

# Generated at 2022-06-21 23:41:31.317285
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    r.add_dynamic_route = lambda *x: None

    assert r.finalize() == r

# Generated at 2022-06-21 23:41:35.375376
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.models.handler_types import RouteHandler

    r = Router()
    r.add("/", ["GET"], RouteHandler)
    r.add("/<string>/", ["GET"], RouteHandler)
    r.finalize()
    pass

# Generated at 2022-06-21 23:41:44.887420
# Unit test for method finalize of class Router
def test_Router_finalize():
  r = Router()
  r.add('/foo/{bar}/baz', ('GET', 'POST'), 'foo_handler')
  r.add('/', 'GET', 'foo_handler')
  with pytest.raises(SanicException):
      r.finalize()
  r.add('/foo/{bar}/baz2', ('GET', 'POST'), 'foo_handler')
  r.finalize()


# Generated at 2022-06-21 23:41:47.083777
# Unit test for constructor of class Router
def test_Router():
    router = Router("first_arg", "second_arg", "third_arg")
    assert router


# Generated at 2022-06-21 23:42:00.217877
# Unit test for method add of class Router
def test_Router_add():
    from sanic.response import json
    from sanic.router import Router
    from sanic.models.handler_types import RouteHandler
    handler: RouteHandler
    handler = None
    router: Router
    router = Router()
    uri: str
    uri = ' '
    methods: Iterable[str]
    methods = [ ]
    host: Optional[Union[str, Iterable[str]]]
    host = None
    strict_slashes: bool
    strict_slashes = False
    stream: bool
    stream = False
    ignore_body: bool
    ignore_body = False
    version: Union[str, float, int]
    version = None
    name: Optional[str]
    name = None
    unquote: bool
    unquote = False
    static: bool
    static = False
    static_

# Generated at 2022-06-21 23:42:09.702030
# Unit test for method add of class Router
def test_Router_add():
    import pytest
    from sanic.router import Router
    from sanic.constants import HTTP_METHODS
    from sanic.handlers import ErrorHandler

    router = Router()
    test_handler = ErrorHandler(lambda: 1)


    def test_add(uri, methods, expected):
        router.add(uri, methods, test_handler)
        for method in methods:
            assert router.routes[method].pop() == expected

    test_add("/", HTTP_METHODS, Route("/", test_handler, methods=HTTP_METHODS))
    test_add("/", ["GET"], Route("/", test_handler, methods=["GET"]))
    test_add("/test", ["GET"], Route("/test", test_handler))

# Generated at 2022-06-21 23:42:20.169767
# Unit test for method add of class Router
def test_Router_add():
    from sanic.response import json
    from sanic import Sanic
    from sanic.request import Request

    sanic_app = Sanic()
    request = Request('POST', '/')
    router = Router(sanic_app, {})
    router.add('/', ['GET', 'POST'], json, name='name_1', unquote=True)
    assert router.find_route_by_view_name('name_1')[1].name == 'name_1'
    assert router.routes_all[0].name == 'name_1'
    assert router.routes_dynamic[('GET', '/')].name == 'name_1'
    assert router.routes_dynamic[('POST', '/')].name == 'name_1'

# Generated at 2022-06-21 23:42:26.831096
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert isinstance(r.ROUTER_CACHE_SIZE, int)
    assert isinstance(r.DEFAULT_METHOD, str)
    assert isinstance(r.ALLOWED_METHODS, list)
    assert len(r.ALLOWED_METHODS) == 9


# Generated at 2022-06-21 23:42:35.680814
# Unit test for constructor of class Router
def test_Router():
    router = Router(None)
    assert isinstance(router, Router)

# Generated at 2022-06-21 23:42:40.468173
# Unit test for method add of class Router
def test_Router_add():
    class TestClass:
        pass
    router = Router()
    router.add(
        uri='/',
        methods=['GET', 'POST'],
        handler=TestClass(),
        host=['localhost'],
        strict_slashes=False,
        stream=True,
        ignore_body=False,
        version=None,
        name='name'
    )
    assert True

# Generated at 2022-06-21 23:42:49.200017
# Unit test for method add of class Router
def test_Router_add():
    # Create an application
    app = Sanic("test_sanic")

    # Create a router
    rt = Router()

    # Create a callback for the handler
    async def foo(request, *args, **kwargs):
        return text("OK")

    # Add a route
    rt.add("/", ["GET"], foo)

    # Add an application
    app.add_route(rt.get, "/")

    # Return the application
    return app


# Generated at 2022-06-21 23:42:53.582313
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    r.add("/test/<__test:int>", ["GET"], lambda x: x)
    r.finalize()

test_Router_finalize()

# Generated at 2022-06-21 23:42:55.719730
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)

# Generated at 2022-06-21 23:42:57.801089
# Unit test for constructor of class Router
def test_Router():
    assert isinstance(Router(), Router)



# Generated at 2022-06-21 23:43:00.539696
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert hasattr(router, "get")



# Generated at 2022-06-21 23:43:05.658563
# Unit test for constructor of class Router
def test_Router():
    assert Router.ALLOWED_METHODS == HTTP_METHODS
    assert Router.DEFAULT_METHOD == "GET"
    assert len(Router.__doc__) > 0
    assert len(Router.get.__doc__) > 0

# Generated at 2022-06-21 23:43:12.776464
# Unit test for method finalize of class Router
def test_Router_finalize():
    '''Unit test for method finalize of class Router'''
    # Test for private method _get of class Router
    # Initialize parameters for test
    router = Router()
    uri = 'route_uri'
    method = 'method'
    handler = 'route_handler'

    router.add(uri, method, handler)
    # Test for method finalize of class Router:
    msg = 'Test method finalize of class Router fail'
    assert router.dynamic_routes[uri].labels[0] == '__file_uri__'

# Generated at 2022-06-21 23:43:16.708923
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add("/test/<param1>", ["GET", "POST"], None, name="test4")
    router.finalize()

# Generated at 2022-06-21 23:43:34.559849
# Unit test for method add of class Router
def test_Router_add():
    uri = '/user/<name>'
    methods = ['GET', 'POST', 'OPTIONS']
    handler = 'user_handler'
    name = 'my-route'
    stream = False
    ignore_body = False
    version = '1'
    unquote = False
    static = False
    route = Route('/user/<name>', methods=methods, handler=handler, name=name, strict=True, unquote=unquote)
    router = Router()
    assert router.add(uri, methods, handler, strict_slashes=True, stream=stream, ignore_body=ignore_body, version=version, name=name, unquote=unquote, static=static) == route


# Generated at 2022-06-21 23:43:43.151581
# Unit test for method add of class Router
def test_Router_add():
    uri = "uri"
    methods = []
    handler = "handler"
    host = None
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = None
    unquote = False
    static = False
    # create an object of class Router
    obj = Router()
    # Call method add with parameters
    obj.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)
    assert obj == obj


# Generated at 2022-06-21 23:43:48.572186
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert (Router.DEFAULT_METHOD) == "GET"
    assert(Router.ALLOWED_METHODS == HTTP_METHODS)

test_Router()

# Generated at 2022-06-21 23:43:52.391626
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    handler = lambda x: x

    r.add("/{a}", ["GET"], handler, stream=False, static=False, name=None, unquote=False)

    r.finalize()


# Generated at 2022-06-21 23:44:05.291033
# Unit test for constructor of class Router
def test_Router():
    uri = "/"
    methods = "GET"
    handler = "async def handler(): return response"
    strict_slashes = False
    stream = False
    ignore_body = False
    version = 3
    name = "home"
    unquote = False
    static = False
    host = "localhost"

    router = Router()
    router.add(uri = "/", methods = "GET", handler = "async def handler(): return response")
    router.add(uri = "/", methods = "POST", handler = "async def handler(): return response")
    router.add(uri = "/", methods = "PUT", handler = "async def handler(): return response")
    router.add(uri = "/", methods = "PATCH", handler = "async def handler(): return response")

# Generated at 2022-06-21 23:44:14.706242
# Unit test for method add of class Router
def test_Router_add():
    from sanic.response import text
    from sanic.views import CompositionView

    router = Router()
    uri = "test"
    methods = ["GET"]
    handler = CompositionView()
    host = "www.google.com"
    strict_slashes = False
    stream = False
    ignore_body = False
    version = 1.0
    name = "test"
    unquote = False
    static = False
    # the input parameter is legal

# Generated at 2022-06-21 23:44:24.369334
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    from sanic.response import text
    router.add(uri='/',methods=['GET'],handler=text("hello"))
    assert router.routes[0].path == '/'
    assert router.routes[0].methods[0] == 'GET'
    from sanic.request import Request
    request = Request("/",method="GET")
    result = router.get("/",request.method,None)
    assert result

# Generated at 2022-06-21 23:44:33.892998
# Unit test for method add of class Router
def test_Router_add():
    # Setup test
    router = Router()
    method = "GET"
    uri = "/Router/add"
    handler = "Handler"
    host = "host"
    strict_slashes = False
    stream = False
    ignore_body = False
    version = 3.6
    name = "add_test"
    unquote = False
    static = False

    # Test
    route = router.add(uri, methods=[method], handler=handler, host=host,
                       strict_slashes=strict_slashes, stream=stream,
                       ignore_body=ignore_body, version=version, name=name,
                       unquote=unquote, static=static)
    assert route.path == uri
    assert route.handler == handler
    assert route.methods == methods
    assert route.host == host

# Generated at 2022-06-21 23:44:36.823339
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert(isinstance(r, BaseRouter))

# Generated at 2022-06-21 23:44:47.871303
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    # assert router.__class__.__name__ == "Router"
    Router.get(router, path = "/", method = "GET", host = None)
    Router.add(router, uri = "test", methods = ("GET",), handler = RouteHandler, host = None, strict_slashes = False, stream = False, ignore_body = False, version = None, name = None, unquote = False, static = False)
    Router.find_route_by_view_name(router, view_name = "test", name = None)
    assert isinstance(Router.routes_all, property)
    assert isinstance(Router.routes_static, property)
    assert isinstance(Router.routes_dynamic, property)

# Generated at 2022-06-21 23:45:00.048008
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD=="GET"

# Generated at 2022-06-21 23:45:01.850719
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router
    r.finalize("/test/<abc>")

# Generated at 2022-06-21 23:45:11.894359
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    TestRouter finalize
    """

    router = Router()
    route_handler = RouteHandler()
    uri = "/"
    methods = ["GET"]
    host = None
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = None
    unquote = False
    static = False

    assert router.finalize() is None
    assert router.add(
        uri,
        methods,
        route_handler,
        host,
        strict_slashes,
        stream,
        ignore_body,
        version,
        name,
        unquote,
        static
    ) is None


# Generated at 2022-06-21 23:45:22.016327
# Unit test for method finalize of class Router
def test_Router_finalize():
    # First, create a Router object
    router = Router()

    # Second, add a route that has a '__file_uri__' label, it will not raise SanicException exception
    router.add(
        uri='/{__file_uri__}',
        methods=['GET'],
        handler=None,
    )

    # Third, add a route that has a '__bad_label__' label, it will raise SanicException exception
    with pytest.raises(SanicException) as e:
        router.add(
            uri='/{__bad_label__}',
            methods=['GET'],
            handler=None,
        )

    assert str(e.value) == "Invalid route: /{__bad_label__}. Parameter names cannot use '__'."

# Generated at 2022-06-21 23:45:26.692302
# Unit test for constructor of class Router
def test_Router():
    """
    Define 'test_Router' function that does unit test for constructor of
    class Router
    """
    router = Router("test")
    assert router.ctx.name == "test"
    assert router.ctx.app is None



# Generated at 2022-06-21 23:45:38.302019
# Unit test for constructor of class Router
def test_Router():
    router = Router(auto_domain=False)
    assert len(router.ALLOWED_METHODS) == len(HTTP_METHODS)
    assert router.DEFAULT_METHOD == "GET"

    assert 'GET' in router.ALLOWED_METHODS
    assert 'POST' in router.ALLOWED_METHODS
    assert 'PUT' in router.ALLOWED_METHODS
    assert 'DELETE' in router.ALLOWED_METHODS
    assert 'OPTIONS' in router.ALLOWED_METHODS
    assert 'HEAD' in router.ALLOWED_METHODS
    assert 'PATCH' in router.ALLOWED_METHODS


# Generated at 2022-06-21 23:45:42.470328
# Unit test for constructor of class Router
def test_Router():
    import unittest.mock
    uri = unittest.mock.MagicMock()
    methods = unittest.mock.MagicMock()
    handler = unittest.mock.MagicMock()

    # We don't have to test everything all the time
    router = Router()
    router.add(uri, methods, handler)
    route = router.get(uri, 'GET', 'localhost')
    assert len(route) == 3, 'Unexpected return size'
    assert len(route[0].parameters) == 0, 'Should be an empty list when not defined'
    assert len(route[2]) == len(route[0].parameters)
    assert route[0].methods is methods, 'Should be the same methods'
    assert route[0].path is uri, 'Should be the same URI'

# Generated at 2022-06-21 23:45:45.855221
# Unit test for constructor of class Router
def test_Router():
    router=Router()
    assert router.DEFAULT_METHOD == 'GET'
    assert router.ALLOWED_METHODS == HTTP_METHODS
#test_Router()

#test for get method

# Generated at 2022-06-21 23:45:54.585436
# Unit test for method add of class Router
def test_Router_add():
    from sanic.response import json

    async def handler():
        return json({"hello": "world"})

    router = Router()
    router.add("/test", ["GET"], handler)

    # Test basic add
    assert len(router.routes_all) == 1
    assert len(router.routes_dynamic) == 1
    assert len(router.routes_regex) == 0
    assert len(router.routes_static) == 0

    # Test host with add
    router = Router()
    router.add("/test", ["GET"], handler, host="example.org")

    assert len(router.routes_all) == 1
    assert len(router.routes_dynamic) == 1
    assert len(router.routes_regex)

# Generated at 2022-06-21 23:46:04.317264
# Unit test for method add of class Router
def test_Router_add():
    """
    Test case for add method of class Router.
    
    """
    uri = '/user/<id>'
    methods = ['GET']
    handler = 'handler'
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = None
    unquote = False
    static = False
    host=None
    router = Router()
    router.add(uri, methods, handler,host,strict_slashes,stream,ignore_body,version,name,unquote,static)

#if __name__ == "__main__":
#    test_Router_add()

# Generated at 2022-06-21 23:46:14.586627
# Unit test for constructor of class Router
def test_Router():
    router = Router(None)
    assert router is not None

# Generated at 2022-06-21 23:46:15.480510
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS

# Generated at 2022-06-21 23:46:24.481428
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    # Add route
    try:
        router.add(
            uri="/user/<name>",
            methods=['GET'],
            handler=lambda request: "",
        )
    except SanicException:
        print('1. Test failed.')
    # Add invalid route
    try:
        router.add(
            uri="/user/<__name>",
            methods=['GET'],
            handler=lambda request: "",
        )
    except SanicException:
        print('2. Test passed.')

if __name__ == "__main__":
    test_Router_finalize()

# Generated at 2022-06-21 23:46:35.983709
# Unit test for constructor of class Router
def test_Router():
    router = Router()

    # Add route
    # Group of routes

    # route_group = RouteGroup("/v1/user")
    # router.add_route("GET", "/v1/user", "index.show_index")
    # router.add_route("POST", "/v1/user", "index.show_index")


    router.add(
        uri="/v1/user",
        methods=["GET", "POST"],
        handler="index.show_index",
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version="v1",
        name="show_user",
        unquote=False,
        static=False
    )


# Generated at 2022-06-21 23:46:44.260846
# Unit test for method add of class Router
def test_Router_add():
    host = "localhost"
    uri = "/"
    methods = ("GET",)
    handler = lambda request: request
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = None
    unquote = False

    r = Router()
    r.add(
        uri=uri,
        methods=methods,
        handler=handler,
        host=host,
        strict_slashes=strict_slashes,
        stream=stream,
        ignore_body=ignore_body,
        version=version,
        name=name,
        unquote=unquote,
    )
    

# Generated at 2022-06-21 23:46:50.562433
# Unit test for method add of class Router
def test_Router_add():

    router = Router()
    method_created = router.add(
        uri="/aditya", methods=["GET", "POST", "OPTIONS"], handler=RouteHandler
    )
    assert method_created.ctx.ignore_body == False
    assert method_created.ctx.stream == False


# Generated at 2022-06-21 23:46:52.846645
# Unit test for constructor of class Router
def test_Router():
    print("Testing Router Class")
    print("Testing constructor")
    x = Router()
    print("Learned Object")
    print(x)

# Generated at 2022-06-21 23:46:58.712405
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        r1 = Router()
        r1.add("/<__file_uri__:file_uri>", methods=["GET"], handler=None)
        r1.finalize()
    except SanicException:
        assert False, "Test of method finalize of class Router failed"
    else:
        assert True, "Test of method finalize of class Router passed"


# Generated at 2022-06-21 23:47:07.043508
# Unit test for method finalize of class Router
def test_Router_finalize():
    def _route_func():
        pass
    router = Router()
    route = router.add(uri='/', methods=['POST'], handler=_route_func, version=None)
    # check function call and raise error
    with pytest.raises(Exception) as e:
        router.dynamic_routes = {route : route}
        router.finalize()
    assert "Invalid route: {}".format(route) in str(e)


# Generated at 2022-06-21 23:47:07.795867
# Unit test for method add of class Router
def test_Router_add():
    pass

# Generated at 2022-06-21 23:47:26.884945
# Unit test for method add of class Router
def test_Router_add():
    from sanic.blueprints import Blueprint
    from sanic.request import Request

    bp = Blueprint("test_bp")

    async def async_handler(request: Request):
        return request.app.name

    def handler(request: Request):
        return request.app.name

    bp.add_route(handler, "/", name="asdf")
    bp.add_route(async_handler, "/asdf")
    bp.add_route(handler, "/test", "GET")
    bp.add_route(async_handler, "/test", "POST")
    bp.add_route(async_handler, "/test", ["PUT", "DELETE"])
    bp.add_route(handler, "/test_strict_true", strict_slashes=True)
    bp.add_route

# Generated at 2022-06-21 23:47:27.793692
# Unit test for method add of class Router
def test_Router_add():
    pass


# Generated at 2022-06-21 23:47:39.540596
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.response import html, json

    def test_handler(*args, **kwargs):  # type: ignore
        return json("foo")

    router = Router()

    # No raised exception
    r = router.add("/test1", ["GET"], test_handler)
    r.ctx.static = True
    r = router.add("/test2", ["GET"], test_handler)
    r.ctx.static = True
    r = router.add("/test3", ["GET"], test_handler)
    r.ctx.static = True

    router.finalize(None)

    # Raised exception
    r = router.add("/test1", ["GET"], test_handler)
    r.ctx.static = True
    r = router.add("/test2", ["GET"], test_handler)

# Generated at 2022-06-21 23:47:50.925035
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route_uri_1 = "/test"
    route_uri_2 = "/test/:uid"
    route_uri_3 = "/test/:id/:uid"
    assert router.finalize()

    route_1 = Route(
        route_uri_1, "GET", lambda request: None, name="name_only"
    )
    router.routes.append(route_1)
    router.dynamic_routes[route_1] = route_1
    assert router.finalize()

    route_2 = Route(
        route_uri_2,
        "GET",
        lambda request: None,
        name="name_with_param",
        labels=['req_id_only'],
    )
    router.routes.append(route_2)
    router

# Generated at 2022-06-21 23:48:01.205528
# Unit test for method add of class Router
def test_Router_add():
    class FakeRouter(Router):
        def add(self, *args, **kwargs):
            return super().add(*args, **kwargs)

    fake_router = FakeRouter()

    fake_router.add('/path/in/url/', ['GET', 'POST'], None)
    fake_router.add('/path/in/url/', ['GET', 'POST'], None, host='http://www.haha.com')
    fake_router.add('/path/in/url/', ['GET', 'POST'], None, host='http://www.haha.com', strict_slashes=True)
    fake_router.add('/path/in/url/', ['GET', 'POST'], None, host='http://www.haha.com', stream=True)
    fake_

# Generated at 2022-06-21 23:48:12.446774
# Unit test for method finalize of class Router
def test_Router_finalize():
    from pathlib import Path
    from os.path import dirname
    import sys

    sys.path.append(dirname(dirname(Path(__file__).resolve())))

    from sanic import Sanic
    from sanic import Blueprint
    from sanic_routing.route import Route

    # Create a sanic app
    app = Sanic("sanic-routing-test-finalize")

    # Create a router
    router = Router()

    # Create a blueprint
    bp = Blueprint(app, name="test-finalize", url_prefix="/test-finalize")

    # Add a route to the blueprint
    @bp.route("/", methods=["GET"])
    def handler(request):
        return request.json

    # Register the blueprint to the router
    router.register_blueprint(bp)

    #

# Generated at 2022-06-21 23:48:16.083824
# Unit test for method add of class Router
def test_Router_add():
    uri = "/test"
    methods = ["GET"]
    handler = "sfaihnfas"
    args = uri, methods, handler
    router = Router()
    routes = router.add(*args)
    assert routes.path == uri



# Generated at 2022-06-21 23:48:23.045081
# Unit test for constructor of class Router
def test_Router():
    uri = "/hello"
    methods = "GET"
    handler = "app.route"
    strict_slashes = True

    test = Router(uri, methods, handler, strict_slashes)
    assert test.uri == uri
    assert test.methods == methods
    assert test.handler == handler
    assert test.strict_slashes == strict_slashes


# Generated at 2022-06-21 23:48:24.815793
# Unit test for constructor of class Router
def test_Router():
    # Create a new Router
    router = Router()
    # Unique type
    assert isinstance(router, Router)

# Generated at 2022-06-21 23:48:36.146770
# Unit test for method add of class Router
def test_Router_add():
    # Case 1: host is list
    # Case 2: host is str
    # Case 3: host is None
    # Case 4: invalid type of host
    # Case 5: param version is None
    # Case 6: param version is a string
    # Case 7: param version is a float
    # Case 8: param version is a int
    # Case 9: param version is a int, version is start with "v"
    # Case 10: param version is a int, uri is start with "/"
    # Case 11: param version is a int, uri is just a "/"
    pass


# Generated at 2022-06-21 23:48:54.958890
# Unit test for method finalize of class Router
def test_Router_finalize():
    pass

# Generated at 2022-06-21 23:48:59.716252
# Unit test for method add of class Router
def test_Router_add():
    def route_handler():
        return True
    # Check router add method with all parameters
    uri = "/hello"
    methods = ["GET"]
    router = Router()
    router.add(uri,methods,route_handler())
    assert router.routes_all


# Generated at 2022-06-21 23:49:05.606722
# Unit test for method add of class Router
def test_Router_add():
    """
    Simple test of method add of class Router
    """
    route = Router()
    res_value = route.add(uri='/index', methods=['GET'], handler=None, host=None, strict_slashes=False, stream=False, ignore_body=False, version=None, name=None, unquote=False, static=False)
    assert res_value is not None

# Generated at 2022-06-21 23:49:13.981884
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add(uri = "/",
            methods = ["GET"],
            handler = None,
            host = None,
            strict_slashes = False,
            stream = False,
            ignore_body = False,
            version = None,
            name = None,
            unquote = False,
            static = False
        )
    

# Generated at 2022-06-21 23:49:22.467006
# Unit test for method add of class Router
def test_Router_add():
    from sanic.core import Sanic
    from sanic.router import Router

    router = Router(Sanic("test app"))

    @router.add("/test")
    def test(request):
        return "test"

    routes = router.routes_all

    assert len(routes) > 0
    assert routes[0].uri == "/test"
    assert routes[0].handler == test
    assert routes[0].methods == ["GET"]
    assert routes[0].strict == False


# Generated at 2022-06-21 23:49:26.890947
# Unit test for constructor of class Router
def test_Router():
    from sanic.app import Sanic
    router = Router(Sanic("test_app"))
    if not isinstance(router, Router):
        raise AssertionError("Router is not an instance of class Router.")

# Generated at 2022-06-21 23:49:35.840239
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router._get

    with pytest.raises(NotFound):
        router._get('/aaa', 'GET', 'bbb')
    with pytest.raises(MethodNotSupported):
        router._get('/aaa', 'POST', 'bbb')

    # TODO: add more unit test cases for _get

    # TODO: add unit test cases for other functions


if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-21 23:49:44.320283
# Unit test for method finalize of class Router
def test_Router_finalize():
    from unittest.mock import Mock
    from unittest.mock import patch
    from sanic.exceptions import SanicException

    # Mock class 'Router' for RouteHandler
    class MockClassRouter:
        # Mock method 'dynamic_routes' of class 'Router'
        @property
        def dynamic_routes(self):
            return {}

    # Mock class 'Route' for RouteHandler
    class MockClassRoute:
        # Mock method 'labels' of class 'Route'
        @property
        def labels(self):
            return ["label_1", "label_2"]

        # Mock method '__repr__' of class 'Route'
        def __repr__(self):
            return "Route(label_1, label_2)"

    # Mock class 'App' for RouteHandler


# Generated at 2022-06-21 23:49:46.969212
# Unit test for constructor of class Router
def test_Router():
    router = Router(None)
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.ctx is None
    assert router.routes_dynamic == {}
    assert router.routes_static == {}
    assert router.name_index == {}
    assert router.regex_routes == {}
    assert router.routes_all == []


# Generated at 2022-06-21 23:49:49.849705
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    for route in router.dynamic_routes.values():
        assert True == any(
            label.startswith("__") and label not in ALLOWED_LABELS
            for label in route.labels
        )