

# Generated at 2022-06-21 23:40:01.025103
# Unit test for method add of class Router
def test_Router_add():
    def f(req, res):
        pass
    router = Router()
    router.add("/", ["GET"], f)


# Generated at 2022-06-21 23:40:11.936004
# Unit test for constructor of class Router
def test_Router():
    from sanic.server import HttpProtocol
    from sanic.app import Sanic
    from sanic.response import json
    from sanic.request import Request
    router = Router()
    sanic = Sanic('test', router=router)
    assert sanic.router == router
    assert router.ctx == sanic
    assert isinstance(router.ctx, Sanic)
    assert router.ctx.name == 'test'
    assert isinstance(router.default_route, Route)
    assert not router.routes
    assert not router.dynamic_routes
    assert not router.static_routes
    assert not router.name_index
    assert not router.regex_routes

    request = Request('/', 'GET', '/')

# Generated at 2022-06-21 23:40:15.609137
# Unit test for method add of class Router
def test_Router_add():
    pass


# Generated at 2022-06-21 23:40:17.115779
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add()

# Generated at 2022-06-21 23:40:26.069221
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router._get is not None
    assert router.get is not None
    assert router.add is not None
    assert router.find_route_by_view_name is not None
    assert router.routes_all is not None
    assert router.routes_static is not None
    assert router.routes_dynamic is not None
    assert router.routes_regex is not None
    assert router.finalize is not None
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}

# Generated at 2022-06-21 23:40:31.143968
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    def handler():
        pass
    try:
        router.add("/foo/<__file_uri__:path>", ["GET"], handler) # pylint: disable=unsubscriptable-object
    except SanicException as e:
        print(e)

# Generated at 2022-06-21 23:40:43.880091
# Unit test for constructor of class Router
def test_Router():
    x = Router(['a', 'b', 'c'])
    assert  x.ROUTER_CACHE_SIZE == 1024
    assert  x.ALLOWED_LABELS[0] == '__file_uri__'
    assert  x.DEFAULT_METHOD == 'GET'
    assert  x.ALLOWED_METHODS[0] == 'GET'
    assert  x.routes == {'a': ['2', 3], 'b': ['2', 3], 'c': ['2', 3]}

    assert x._get('a', 'b', 'c') == (x.routes['a'], x.routes['b'], x.routes['c'])

# Generated at 2022-06-21 23:40:55.188142
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_router = Router()
    # Testing route without __file_uri__ in labels
    router_path = "/test1/{test_label1}/test2/{test_label2}"
    test_route = Route(uri=router_path, methods=["GET", "POST", "OPTIONS"], handler=None)
    test_route.labels.add("test_label1")
    test_route.labels.add("test_label2")
    test_route.regex = re.compile("^/test1/([^/]+)/test2/([^/]+)$")
    test_router.dynamic_routes[router_path] = test_route
    try:
        test_router.finalize()
    except SanicException:
        pass
    else:
        raise

# Generated at 2022-06-21 23:40:57.873783
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert len(router.get_routes()) == 0


# Generated at 2022-06-21 23:41:04.118600
# Unit test for method add of class Router
def test_Router_add():
    uri = "/api/v1/users"
    methods = ["GET", "POST", "OPTIONS"]
    host = "localhost"
    strict_slashes = False
    stream = False
    ignore_body = False
    name = None
    version = 1
    static = False
    unquote = True

    def handler():
        pass

    router = Router()
    route = router.add(uri, methods, handler, host, strict_slashes,
    stream, ignore_body, version, name, unquote, static)
    assert isinstance(route, Route)


# Generated at 2022-06-21 23:41:15.942313
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    from sanic.router import Router
    from sanic.sanic import Sanic
    
    def view(request):
        return 'OK'
    with pytest.raises(SanicException):
        app = Sanic(name='test')
        router = Router(app)
        router.add('/test', ['GET', 'POST'], view, __name__)
        router.add('/test2', ['GET', 'POST'], view, __name__)
        router.finalize()

# Test finalize function when sending a route with a __name__
test_Router_finalize()

# Generated at 2022-06-21 23:41:26.777347
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    from sanic.router import Router, Route

    class FakeRequest:
        """
        Fake class that mimics a sanic.request.Request
        """

        method = "GET"
        path = "/"
        scheme = "http"
        host = "localhost"

    router = Router()
    route = Route(path="", handler=None, methods=['GET'])
    router.dynamic_routes[id(route)] = route

    for label in ALLOWED_LABELS:
        with pytest.raises(SanicException):
            router.finalize()

    route.labels = ['__file_uri__']
    router.finalize()



# Generated at 2022-06-21 23:41:27.670164
# Unit test for constructor of class Router
def test_Router():
    router = Router()

# Generated at 2022-06-21 23:41:35.885318
# Unit test for method add of class Router
def test_Router_add():
    # Add handler to the router
    # Parameters: the path of the route
    #             the types of HTTP methods that should be attached, example:
    #             ["GET", "POST", "OPTIONS"]
    #             the sync or async function to be executed
    #             host that the route should be on, defaults to None
    #             whether to apply strict slashes, defaults to False
    #             whether to stream the response, defaults to False
    #             whether the incoming request body should be read, defaults to
    #             False
    #             a version modifier for the uri, defaults to None
    #             an identifying name of the route, defaults to Nones
    # return the route object
    pass


# Generated at 2022-06-21 23:41:45.662073
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    import sanic
    router = Router()
    app = sanic.Sanic("test_Sanic_add_route")

    # Error
    with pytest.raises(
        SanicException
    ) as excinfo:
        router.add("/<bad_label:custom>", ["GET"], lambda request: request)
        router.finalize(app.add_route)

    assert str(excinfo.value) == "Invalid route: /<bad_label:custom>. Parameter names cannot use '__'."

# Generated at 2022-06-21 23:41:58.690785
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router as PyRouter

    host = "127.0.0.1"
    port = 8350
    ws_host = "127.0.0.1"
    ws_port = 8351
    path = "/"
    async def handler(request, a, b, c):
        pass
    route = Route(handler, ["POST", "PUT"], path,
        strict_slashes=False, unquote=False,
    )
    route.ctx.hosts = [f"http://{host}:{port}"]
    route.ctx.static = False
    route.ctx.ws_hosts = [f"ws://{ws_host}:{ws_port}"]
    route.ctx.ws_path = path
    router = PyRouter()
    # the method "add()" with

# Generated at 2022-06-21 23:42:06.869505
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    for i in range(ROUTER_CACHE_SIZE):
        router.add("/", ["GET"], lambda: None, name=f"name{i}")
    router.finalize()
    assert len(router.routes) == ROUTER_CACHE_SIZE
    assert len(router._get.cache_info().hits) == 0
    assert router._get.cache_info().currsize == 0
    assert router.get.cache_info().currsize == 0

# Generated at 2022-06-21 23:42:19.084290
# Unit test for method finalize of class Router
def test_Router_finalize():
    import inspect
    import os
    import sys
    import types
    import unittest
_test_Router_finalize = True

if _test_Router_finalize:
    import os
    import sys

    _test_exception = SanicException
    _test_route = Route
    _test_route.labels = ('foo',)
    _test_router = Router()
    _test_router.dynamic_routes = {_test_route: _test_route}
    with unittest.mock.patch('builtins.print') as mock_print:
        with unittest.mock.patch('sys.exit') as mock_exit:
            mock_exit.side_effect = SystemExit
            with self.assertRaises(SystemExit):
                _test_router.finalize()

# Generated at 2022-06-21 23:42:26.580915
# Unit test for method add of class Router
def test_Router_add():
    from sanic.app import Sanic
    from sanic.response import text

    app = Sanic("test_Router_add")

    @app.route("/")
    async def handler(request):
        return text("OK")

    assert len(app.router.routes_all) == 1



# Generated at 2022-06-21 23:42:34.084246
# Unit test for method finalize of class Router
def test_Router_finalize():
    #create an instance of class Router
    router = Router()
    #create a route with label that is not allowed
    route = Route(
        path="/some/{param_with_two_under_score}/",
        methods=["GET", "POST", "OPTIONS"],
        handler=None,
        name="some_route",
        strict=True,
    )
    #add route to list of routes
    router.dynamic_routes["/some/{param_with_two_under_score}/"] = route
    #call method finalize
    with pytest.raises(SanicException):
        router.finalize()

# Generated at 2022-06-21 23:42:45.749053
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD in HTTP_METHODS
    assert router.ALLOWED_METHODS == HTTP_METHODS

# Generated at 2022-06-21 23:42:53.814033
# Unit test for constructor of class Router
def test_Router():
   router = Router()
   assert router.ctx == None
   assert router.dynamic_routes == {}
   assert router.dynamic_routes_parent == {}
   assert router.name_index == {}
   assert router.static_routes == {}
   assert router.static_routes_parent == {}
   assert router.regex_routes == {}
   assert router.routes == {}
   assert router.routes_all == {}
   assert router.routes_dynamic == {}
   assert router.routes_regex == {}
   assert router.routes_static == {}
   assert router.route_groups == {}
   assert router.tree == None


# Generated at 2022-06-21 23:42:55.324726
# Unit test for method add of class Router
def test_Router_add():
    pass



# Generated at 2022-06-21 23:42:58.874329
# Unit test for method add of class Router
def test_Router_add():
    from sanic.response import text
    router = Router()
    router.add(
        uri='/',
        methods=["GET"],
        handler=text('OK!')
    )


# Generated at 2022-06-21 23:43:12.284444
# Unit test for method finalize of class Router
def test_Router_finalize():
    def test_routes(routes):
        '''
        разделяет uri на части обрабатываемые sanic
        '''
        uri_list = [(i.split('/')[1:], i) for i in routes]
        uri_list.sort(key=lambda uri: len(uri[0]), reverse=True)
        return uri_list

    def test_route(router, routes):
        for i in routes:
            uri, r_uri = i
            assert router.resolve(uri, 'get', extra={'host': None})[0].path == r_uri


# Generated at 2022-06-21 23:43:17.901909
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add("/", ["GET"], lambda: "OK")
    assert router.routes["(GET) /"].ctx.stream == False
    assert router.routes["(GET) /"].ctx.ignore_body == False

# Generated at 2022-06-21 23:43:19.626034
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    with pytest.raises(SanicException):
        router.finalize()

# Generated at 2022-06-21 23:43:23.429682
# Unit test for constructor of class Router
def test_Router():
    # create a new Router object
    router = Router()
    # test the type of object
    assert isinstance(router, Router)

# Generated at 2022-06-21 23:43:29.474981
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.constants import HTTP_METHODS
    uri = "/test_Router_finalize"
    methods = HTTP_METHODS
    def handler():
        pass
    router = Router()
    router.add(uri, methods, handler)
    router.finalize()


# Generated at 2022-06-21 23:43:30.917766
# Unit test for constructor of class Router
def test_Router():
    assert isinstance(Router(), Router)


# Generated at 2022-06-21 23:43:52.829945
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router.routes_all, dict)
    assert isinstance(router.routes_regex, dict)
    assert isinstance(router.routes_dynamic, dict)
    assert isinstance(router.routes_static, dict)
    assert isinstance(router.ctx, dict)

# Generated at 2022-06-21 23:43:58.747447
# Unit test for method add of class Router
def test_Router_add():
    # Init
    r = Router()

    # Test
    route = r.add(uri="/test", methods=["GET"], handler=None)
    assert isinstance(route, Route)
    assert route.path == "/test"
    assert route.ctx.methods == "GET"

# Generated at 2022-06-21 23:44:04.022640
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert(router.routes == {})
    assert(router.static_routes == {})
    assert(router.dynamic_routes == {})
    assert(router.regex_routes == {})
    assert(router.name_index == {})


# Generated at 2022-06-21 23:44:06.895830
# Unit test for constructor of class Router
def test_Router():
    assert Router.ALLOWED_METHODS == HTTP_METHODS
    assert Router.DEFAULT_METHOD == "GET"

# Generated at 2022-06-21 23:44:07.593346
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.finalize()

# Generated at 2022-06-21 23:44:12.052582
# Unit test for constructor of class Router
def test_Router():
    router = Router(None)
    assert router.ctx == None
    assert router.DEFAULT_METHOD == 'GET'
    assert router.ALLOWED_METHODS == ['DELETE', 'GET', 'HEAD', 'OPTIONS', 'PATCH', 'POST', 'PUT', 'TRACE']


# Generated at 2022-06-21 23:44:14.371491
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert(isinstance(router, BaseRouter))


# Generated at 2022-06-21 23:44:16.976905
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert type(router) == Router

# Generated at 2022-06-21 23:44:25.045649
# Unit test for constructor of class Router
def test_Router():
    assert BaseRouter
    assert Route
    assert RouteHandler
    assert RoutingNotFound
    assert NoMethod
    assert isinstance(ROUTER_CACHE_SIZE, int)
    assert isinstance(ALLOWED_LABELS, tuple)
    assert isinstance(Router.DEFAULT_METHOD, str)
    assert isinstance(Router.ALLOWED_METHODS, tuple)
    assert Router()


# Generated at 2022-06-21 23:44:25.697875
# Unit test for constructor of class Router
def test_Router():
    Router()

# Generated at 2022-06-21 23:44:41.990507
# Unit test for method finalize of class Router
def test_Router_finalize():
    start_app(Router())


# Generated at 2022-06-21 23:44:44.389957
# Unit test for method add of class Router
def test_Router_add():
    a = Router()
    a.add('/',['GET'],print)
    assert(len(a.routes) == 1)

# Generated at 2022-06-21 23:44:45.648609
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router != None

# Generated at 2022-06-21 23:44:52.433752
# Unit test for method add of class Router
def test_Router_add():
    from sanic.app import Sanic
    app = Sanic("test_Router_add")

    # test whether Router.add method can add routes to app
    router = Router(app)
    app.router = router
    router.add("/test/<name:string>", ["GET", "POST"], "handler", None, False, False, False, None, None, False, False)
    assert len(router.routes) == 1

# Generated at 2022-06-21 23:45:00.333627
# Unit test for method add of class Router
def test_Router_add():
    from sanic.router import Router
    router = Router()
    router.add(uri="/foo", methods=['GET'], handler=hello_world)
    assert router.routes[0].path == '/foo'
    assert router.routes[0].methods == {'GET'}
    assert router.routes[0].handler == hello_world


# Generated at 2022-06-21 23:45:01.649386
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router


# Generated at 2022-06-21 23:45:02.742378
# Unit test for constructor of class Router
def test_Router():
    assert Router() is not None

# Generated at 2022-06-21 23:45:12.377656
# Unit test for method add of class Router
def test_Router_add():
    uri = ''
    methods = []
    handler = None
    host = None
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = None
    unquote = False
    static = False
    router = Router()
    routes_all_expected = {}
    routes_static_expected = {}
    routes_dynamic_expected = {}
    routes_regex_expected = {}
    router.routes_all = routes_all_expected
    router.routes_static = routes_static_expected
    router.routes_dynamic = routes_dynamic_expected
    router.routes_regex = routes_regex_expected


# Generated at 2022-06-21 23:45:22.364473
# Unit test for constructor of class Router
def test_Router():
    uri = "/"
    methods = ["GET", "POST", "OPTIONS"]
    handler = lambda x, y: None

    host = "www.google.com"
    strict_slashes = False
    stream = False
    ignore_body = False
    version = "1"
    name = None
    unquote = False
    static = False

    router = Router()

    route = router.add(
        uri=uri,
        methods=methods,
        handler=handler,
        host=host,
        strict_slashes=strict_slashes,
        stream=stream,
        ignore_body=ignore_body,
        version=version,
        name=name,
        unquote=unquote,
        static=static,
    )

# Generated at 2022-06-21 23:45:32.299296
# Unit test for method add of class Router
def test_Router_add():
    from sanic.app import Sanic
    app = Sanic("sanic-server")
    my_router = Router()

    uri = "/"
    methods = ['GET']
    host = 'localhost:8000'
    handler = None
    strict_slashes = False
    stream = True
    ignore_body = False
    version = 1.0
    name = "homepage"
    unquote = False
    static = True

    route = my_router.add(uri, methods,
                          handler, host, strict_slashes,
                          stream, ignore_body,
                          version, name, unquote, static)
    assert route.ctx.hosts == [host]
    assert route.ctx.stream == True
    assert route.ctx.ignore_body == False
    assert route.ctx.static == True



# Generated at 2022-06-21 23:46:02.415871
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Arrange
    router = Router()

    # Act
    router.finalize()

    assert 1 == 1

# Generated at 2022-06-21 23:46:03.800613
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)

# Generated at 2022-06-21 23:46:04.954987
# Unit test for method add of class Router
def test_Router_add():
    pass


# Generated at 2022-06-21 23:46:17.012528
# Unit test for constructor of class Router
def test_Router():
    uri = "/test/<param1>/<param2>"
    
    def handler(request, *args, **kwargs):
        pass
    
    method = ["GET", "POST"]
    host = "localhost"
    strict_slashes = False
    stream = False
    ignore_body = False
    version = "1.0"
    name = "test"

    router = Router()
    router.add(uri, method, handler, host, strict_slashes, stream, ignore_body, version, name)
    
    assert router.dynamic_routes == {}
    assert router.static_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.routes == []



# Generated at 2022-06-21 23:46:24.728483
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.testing import create_route_table, create_app

    app = create_app()
    router = Router(app, create_route_table())

    @app.route("/")
    def handler(request):
        return "Success"

    try:
        router.finalize()
    except SanicException:
        assert True
    
    @app.route("/")
    def handler(request):
        return "Success"
    
    try:
        router.finalize()
    except SanicException:
        assert False

# Generated at 2022-06-21 23:46:29.254624
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    with pytest.raises(SanicException):
        router.dynamic_routes = {'/': [1, 2, 3]}
        router.finalize()

test_Router_finalize()

# Generated at 2022-06-21 23:46:39.777353
# Unit test for method add of class Router
def test_Router_add():
    from sanic.router import Router
    from sanic.response import text
    from sanic import Sanic
    from sanic.constants import HTTP_METHODS
    from sanic.request import Request
    import sys
    import os


    @text("HELLO")
    async def handler(request: Request):
        return text("HELLO")


    @text("HELLO")
    def handler1(request: Request):
        return text("HELLO")


    @text("HELLO")
    def handler2(request):
        return text("HELLO")


    @text("HELLO")
    def handler3(request: Request = None):
        return text("HELLO")



# Generated at 2022-06-21 23:46:41.966074
# Unit test for constructor of class Router
def test_Router():
    # create an object for Router
    router = Router()
    # check instance of Router
    assert isinstance(router, Router)


# Generated at 2022-06-21 23:46:48.082376
# Unit test for method add of class Router
def test_Router_add():
    def test_func():
        pass
    uri = '/test'
    host = 'www.example.com'
    methods = ('GET', 'POST')
    strict_slashes = False
    stream = False
    ignore_body = False
    version = '1.0'
    name = 'function_name'
    unquote = False
    static = False
    test_router = Router()
    result = test_router.add(uri, methods, test_func, host, strict_slashes, stream, ignore_body, version, name, unquote, static)
    test_router.finalize()

# Tests for class Router and method find_route_by_view_name

# Generated at 2022-06-21 23:46:48.730174
# Unit test for constructor of class Router
def test_Router():
    pass

# Generated at 2022-06-21 23:47:49.105273
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    Test case for method finalize of class Router

    :return:
    """
    pass



# Generated at 2022-06-21 23:47:58.117047
# Unit test for method add of class Router
def test_Router_add():
    '''
    Class Router:
        1. method add(uri: str,
        methods: Iterable[str],
        handler: RouteHandler,
        host: Optional[Union[str, Iterable[str]]] = None,
        strict_slashes: bool = False,
        stream: bool = False,
        ignore_body: bool = False,
        version: Union[str, float, int] = None,
        name: Optional[str] = None,
        unquote: bool = False,
        static: bool = False,) -> Union[Route, List[Route]]:
    '''
    router = Router()
    uri = "/"
    methods = ["GET", "POST", "OPTIONS"]
    handler = "handler"
    host = "host"
    strict_slashes = False
    stream = False
    ignore_

# Generated at 2022-06-21 23:48:04.795212
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert repr(router) == "Router()"
    assert router._middleware == []
    assert router._middleware_stack == []
    assert router.routes == {}
    assert router.regex_routes == []
    assert router.name_index == {}


# Generated at 2022-06-21 23:48:15.266520
# Unit test for method finalize of class Router
def test_Router_finalize():
    # test for route with '__file_uri__' in labels
    path = '__file_uri__'
    methods = ['GET']
    handler = 'handler'
    host = None
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = None
    unquote = False
    static = False
    router = Router()
    route = router.add(path,methods,handler,host,strict_slashes,stream,ignore_body,version,name,unquote,static)
    assert router.finalize()


# Generated at 2022-06-21 23:48:26.667510
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    assert router.routes == set()
    assert router.routes_dynamic == dict()
    assert router.routes_regex == dict()
    assert router.routes_static == dict()
    router.add(uri = '', methods = [], handler = None)
    assert router.routes == set()
    assert router.routes_dynamic == dict()
    assert router.routes_regex == dict()
    assert router.routes_static == dict()
    router.add(uri = '', methods = [], handler = None, host = None, strict_slashes = False, stream = False, ignore_body = False, version = None, name = None, unquote = False, static = False)
    assert router.routes == set()

# Generated at 2022-06-21 23:48:38.636758
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic_routing.route import Route
    from sanic.response import json
    from sanic import Sanic

    app = Sanic()
    app.router.add('/', 'GET', lambda request: json({'hello': 'world'}))
    assert len(app.router.dynamic_routes) == 1
    assert len(app.router.regex_routes) == 0
    assert len(app.router.static_routes) == 0

    app.router.add('/<name>', 'GET', lambda request, name: json({'hello': 'world'}))
    assert len(app.router.dynamic_routes) == 1
    assert len(app.router.regex_routes) == 1

# Generated at 2022-06-21 23:48:39.103467
# Unit test for method add of class Router
def test_Router_add():
    pass

# Generated at 2022-06-21 23:48:47.896921
# Unit test for method finalize of class Router
def test_Router_finalize():
    _routes = [
        Route(
            "/",
            [],
            None,
            False,
            False,
            False,
            [],
            [],
            {},
            True,
            [],
            {},
            {},
            "",
            "",
            False,
            False,
            False,
        ),
        Route(
            "/",
            [],
            None,
            False,
            False,
            False,
            [],
            [],
            {},
            True,
            [],
            {},
            {"foo": "__unicorn__"},
            "",
            "",
            False,
            False,
            False,
        ),
    ]

    routes = {None: _routes}


# Generated at 2022-06-21 23:48:52.783175
# Unit test for constructor of class Router
def test_Router():
    # GIVEN
    test_router = Router()
    # THEN
    assert test_router.DEFAULT_METHOD == "GET"
    assert test_router.ALLOWED_METHODS == HTTP_METHODS
    assert test_router.ctx.current_route is None


# Generated at 2022-06-21 23:48:59.519301
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    """
    create a valid Route object
    """
    route = Route(
        path="test/<name>",
        handler=None,
        methods=None,
        name=None,
        strict=None,
        unquote=None,
        requirements=None,
    )
    router.dynamic_routes["test/<name>"] = route
    """
    test for invalid route
    """
    route = Route(
        path="test/<__name>",
        handler=None,
        methods=None,
        name=None,
        strict=None,
        unquote=None,
        requirements=None,
    )
    router.dynamic_routes["test/<__name>"] = route