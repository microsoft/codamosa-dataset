

# Generated at 2022-06-21 23:40:14.102275
# Unit test for constructor of class Router
def test_Router():
    router = Router ()
    assert isinstance(router, BaseRouter)

# Generated at 2022-06-21 23:40:16.915834
# Unit test for constructor of class Router
def test_Router():
    router = Router()

    assert isinstance(router, Router)


# Generated at 2022-06-21 23:40:19.564462
# Unit test for method finalize of class Router
def test_Router_finalize():
    pass

# Generated at 2022-06-21 23:40:30.298370
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert hasattr(router, "ctx")
    assert hasattr(router, "name_index")
    assert hasattr(router, "dynamic_routes")
    assert hasattr(router, "static_routes")
    assert hasattr(router, "regex_routes")
    assert hasattr(router, "routes")
    assert hasattr(router, "normalized_routes")
    assert hasattr(router, "normalized_static_routes")


# Generated at 2022-06-21 23:40:35.396155
# Unit test for constructor of class Router
def test_Router():
    routing = Router()
    assert not routing.static_routes
    assert not routing.dynamic_routes
    assert not routing.regex_routes
    assert not routing.name_index

# Generated at 2022-06-21 23:40:37.912770
# Unit test for constructor of class Router
def test_Router():
    try:
        router = Router()
        assert True
    except:
        assert False


# Generated at 2022-06-21 23:40:42.039930
# Unit test for method add of class Router
def test_Router_add():
    uri = "/item/<item_id:int>"
    router = Router()
    methods = HTTP_METHODS
    handler = RouteHandler
    try:
        # router.add(uri, methods, handler)
        pass
    except:
        assert False
    assert True

# Generated at 2022-06-21 23:40:44.925481
# Unit test for constructor of class Router
def test_Router():
    args = ([], [])
    test = Router(args)
    assert test


# Generated at 2022-06-21 23:40:48.364151
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router

# Generated at 2022-06-21 23:40:50.557172
# Unit test for constructor of class Router
def test_Router():
  router = Router()
  assert isinstance(router, Router)

# Generated at 2022-06-21 23:40:58.325965
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)
    assert isinstance(router, BaseRouter)
    

# Generated at 2022-06-21 23:41:09.029426
# Unit test for constructor of class Router
def test_Router():
    router = Router()

    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []

    assert router.ctx.name == "Router(BaseRouter)"
    assert router.ctx.app == None
    assert router.ctx.uri_prefix == None
    assert router.ctx.host == None
    assert router.ctx.hosts == []
    assert router.ctx.host_regex == None
    assert router.ctx.host_match == None
    assert router.ctx.host_requirements == {}
    assert router.ctx.host_uri == None
    assert router.ctx.host_static == False
    assert router.ctx.name_prefix == None
    assert router.ctx.strict_

# Generated at 2022-06-21 23:41:17.140114
# Unit test for method add of class Router
def test_Router_add():
    from sanic.router import Router
    # def __init__(self, app=None, host=None):
    router = Router()
    # def add(self, uri, method, handler, host=None,
    #         strict_slashes=False):
    uri = "/"
    method = "GET"
    handler = None
    host = "127.0.0.1"
    strict_slashes = False
    router = Router()
    ret = router.add(uri, method, handler, host, strict_slashes)
    assert isinstance(ret, Route)

# Generated at 2022-06-21 23:41:18.038455
# Unit test for constructor of class Router
def test_Router():
    assert Router()

# Generated at 2022-06-21 23:41:26.133964
# Unit test for method add of class Router
def test_Router_add():
    def app():
        pass

    uri = '/method'
    methods=['POST', 'GET']
    handler=app
    host = None
    strict_slashes = False
    stream = False
    ignore_body = False
    args1 = (uri, methods, handler, host, strict_slashes, stream, ignore_body)
    args2 = (uri, methods, handler)
    add = Router.add
    assert (add(*args1)).ctx.hosts == [None]
    assert (add(*args2)).ctx.hosts == [None]

# Generated at 2022-06-21 23:41:38.280056
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.app import Sanic

    app = Sanic("test_Router_finalize")

    @app.route("/")
    async def test(request):
        return "OK"

    @app.route("/__file_uri__")
    async def test1(request):
        return "OK"

    @app.route("/__invalid__")
    async def test1(request):
        return "OK"

    test_Router_finalize.__doc__ = Router.finalize.__doc__

    app.add_task(app.router.finalize)
    app.add_task(app.start)

    client = app.test_client

    assert client.get("/").status == 200
    assert client.get("/__file_uri__").status == 200


# Generated at 2022-06-21 23:41:49.534266
# Unit test for constructor of class Router
def test_Router():
    # _get
    router = Router()
    assert router._get(path="/hello_world", method="GET", host=None) == (
        NotFound,
        "Requested URL /hello_world not found",
    )
    assert router._get(path="/hello_world", method="GET", host="localhost") == (
        NotFound,
        "Requested URL /hello_world not found",
    )

    # get
    assert router.get(path="/hello_world", method="GET", host="localhost") == (
        NotFound,
        "Requested URL /hello_world not found",
    )

    # add
    def func(): pass

# Generated at 2022-06-21 23:42:00.413449
# Unit test for method add of class Router
def test_Router_add():
    r = Router()
    methods = ["GET","POST"]
    handler = "100"
    host = None
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = None
    unquote = False
    static = False
    uri = "100"
    route = r.add(
        uri=uri,
        methods=methods,
        handler=handler,
        host=host,
        strict_slashes=strict_slashes,
        stream=stream,
        ignore_body=ignore_body,
        version=version,
        name=name,
        unquote=unquote,
        static=static
    )
    assert route.path == "100"



# Generated at 2022-06-21 23:42:02.080976
# Unit test for constructor of class Router
def test_Router():
    from sanic_routing import Router
    router = Router()



# Generated at 2022-06-21 23:42:05.761238
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.response import text
    router = Router()

    router.add('/test', ['GET'], text('test'))

    assert router.finalize() == None



# Generated at 2022-06-21 23:42:12.124506
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None


# Generated at 2022-06-21 23:42:21.075822
# Unit test for method finalize of class Router
def test_Router_finalize():
    uri = "uri"
    methods = ["GET", "POST", "OPTIONS"]
    handler = RouteHandler
    version = 1
    name = "name"

    from sanic.constants import HTTP_METHODS
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.router import Router

    router = Router()
    router.add(
        uri,
        methods,
        handler,
        host="host",
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version=version,
        name=name,
        unquote=False,
        static=False,
    )

# Generated at 2022-06-21 23:42:24.712999
# Unit test for constructor of class Router
def test_Router():
    try:
        Router("a", "b", "c", "d")
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-21 23:42:27.812678
# Unit test for constructor of class Router
def test_Router():
    from sanic.router import Router
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS


# Generated at 2022-06-21 23:42:34.496548
# Unit test for method add of class Router
def test_Router_add():
    r = Router()
    handler = lambda: None
    r.add(uri='/', methods=['GET', 'POST'], handler=handler)
    assert len(r.routes) == 2
    assert r.routes['GET:/'].handler == handler
    assert r.routes['POST:/'].handler == handler


# Generated at 2022-06-21 23:42:38.531072
# Unit test for method add of class Router
def test_Router_add():
    from sanic.response import text
    router = Router()
    route = router.add('/',["GET"],"text")
    assert route.methods == ['GET']
    assert route.handler == text
    assert router.name_index == {None: route}



# Generated at 2022-06-21 23:42:40.016410
# Unit test for method finalize of class Router
def test_Router_finalize():
    x = Router()
    #x.finalize()

# Generated at 2022-06-21 23:42:47.952753
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    # Test case 1: route.labels is empty
    r.dynamic_routes[0] = Route(
        "/",
        "GET",
        None,
        labels={},
        uri_template="uri_template",
        host=None,
    )
    r.static_routes[0] = Route(
        "/",
        "GET",
        None,
        labels={},
        uri_template="uri_template",
        host=None,
    )
    r.regex_routes[0] = Route(
        "/",
        "GET",
        None,
        labels={},
        uri_template="uri_template",
        host=None,
    )
    r.finalize()
    # Test case 2: route.labels has allowed

# Generated at 2022-06-21 23:42:59.744646
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    uri = "/"
    methods = ["GET", "POST", "OPTIONS"]
    handler = "handler"
    host = None
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = "name"
    unquote = False
    static = False
    router.add(uri, methods, handler, host, strict_slashes, stream, \
        ignore_body, version, name, unquote, static)
    try:
        router.finalize()
    except SanicException as e:
        assert (f"Invalid route: {uri}. Parameter names cannot use '__'." in e.__str__())

# Generated at 2022-06-21 23:43:12.430028
# Unit test for method add of class Router
def test_Router_add():
    from sanic.handlers import RequestParameters

    rt = Router()
    rt.add(uri='/hello/<something>/else',
           methods=["GET", "POST", "OPTIONS"],
           handler=RequestParameters,
           host=None,
           strict_slashes=False,
           stream=False,
           ignore_body=False,
           version=None,
           name=None,
           unquote=False,
           static=False)

# Generated at 2022-06-21 23:43:33.994550
# Unit test for method add of class Router
def test_Router_add():
    from sanic.response import text

    router = Router(None, {})
    router.add("/test", ["GET"], lambda r: text("hello"))

    assert len(router.routes) == 1
    assert router.routes_all[0].path == "/test"
    assert router.routes_all[0].methods[0] == "GET"
    assert router.routes_all[0].handler("") == text("hello")("")

    router.add("/test", ["GET"], lambda r: text("hello again"))

    assert len(router.routes) == 2
    assert router.routes_all[1].path == "/test"
    assert router.routes_all[1].methods[0] == "GET"

# Generated at 2022-06-21 23:43:40.175940
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    uri = "/test"
    methods = ["GET", "POST", "OPTIONS"]  # type: Iterable[str]
    handler = asyncio.get_event_loop().create_task(print("hello world!"))
    router.add(uri, methods, handler)



# Generated at 2022-06-21 23:43:51.906689
# Unit test for method add of class Router
def test_Router_add():
    route = Route(["GET"], "test_uri", "test_handler", "test_name")
    router = Router(["GET"], "test_uri", "test_handler", "test_name")
    assert router.routes == {route: {None}}
    assert route.ctx.hosts == [None]
    assert len(router.routes_all) == 1
    assert len(router.routes_static) == 1
    assert len(router.routes_dynamic) == 0
    assert len(router.routes_regex) == 0

# Generated at 2022-06-21 23:44:04.970494
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.request import Request

    def test_error():
        router = Router()
        router.add(uri="/", methods=["GET"], handler=lambda request: None)
        router.finalize(None)
        
    # assertRaises is for tests to check for expected exceptions
    # If a test does not assertRaises an exception and a bug in a test
    # leads to an exception, the test will seemingly pass without actually
    # running the code it was meant to test.
    assertRaises(SanicException, test_error)

    def test_ok():
        router = Router()
        router.add(uri="/", methods=["GET"], handler=lambda request: None)
        router.finalize(None)

    assertRaises(SanicException, test_ok)



# if __name__ == "__main__":


# Generated at 2022-06-21 23:44:13.432433
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route(
        path = '/',
        handler = 'handler'
    )

    with pytest.raises(SanicException):
        router.dynamic_routes = {1: route}
        router.finalize()
    with pytest.raises(SanicException):
        route.labels = ['__test_label1', '__test_label2', '__test_label3']
        router.dynamic_routes = {1: route}
        router.finalize()
    router.dynamic_routes = {1: route}
    router.finalize()


# Generated at 2022-06-21 23:44:19.915980
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == []


# Generated at 2022-06-21 23:44:27.417724
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router
    assert router.DEFAULT_METHOD
    assert router.ALLOWED_METHODS
    assert router.get
    assert router.add
    assert router.find_route_by_view_name
    assert router.routes_all
    assert router.routes_static
    assert router.routes_dynamic
    assert router.routes_regex
    assert router.finalize
    assert router.dynamic_routes


if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-21 23:44:34.583388
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Arrange
    url = "http://exmaple.com/api/v1/_/user/<int:user_id>.json"
    methods = ["GET", "POST", "OPTIONS"]
    host = "exmaple.com"
    router = Router()
    router.add(url, methods, handler=None, host=host)
    # Act
    with pytest.raises(SanicException) as e:
        router.finalize()

    # Assert
    assert "Invalid route: /api/v1/_/user/<int:user_id>.json. Parameter names cannot use '__'." == str(e.value)

# Generated at 2022-06-21 23:44:37.613075
# Unit test for constructor of class Router
def test_Router():
    try:
        router = Router()
    except TypeError:
        pass



# Generated at 2022-06-21 23:44:48.084914
# Unit test for method add of class Router

# Generated at 2022-06-21 23:45:00.814718
# Unit test for constructor of class Router
def test_Router():
    try:
        Router()
        assert True
    except Exception as e:
        assert False, e.args

# Generated at 2022-06-21 23:45:02.437752
# Unit test for constructor of class Router
def test_Router():
    router = Router("")
    assert isinstance(router, Router)


# Generated at 2022-06-21 23:45:12.208246
# Unit test for method add of class Router
def test_Router_add():
    from sanic.views import HTTPMethodView
    from sanic.blueprints import Blueprint

    class Dummy(HTTPMethodView):
        pass

    routes = dict()
    bp = Blueprint("test", "/", strict_slashes=True)

    router = Router(None)
    routes["/test/1"] = router.add("/test/1", ["GET", "POST"], Dummy.dispatch)
    assert isinstance(routes["/test/1"], Route)
    routes["/test/2"] = router.add("/test/2", "GET", Dummy.dispatch)
    assert isinstance(routes["/test/2"], Route)
    routes["/test/3"] = router.add("/test/3", ["OPTIONS", "GET"], Dummy.dispatch)
   

# Generated at 2022-06-21 23:45:17.521058
# Unit test for constructor of class Router
def test_Router():
    router = Router()  
    print(router.routes_all)
    print(router.routes_static)
    print(router.routes_dynamic)
    print(router.routes_regex)


# Generated at 2022-06-21 23:45:19.289013
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-21 23:45:31.045652
# Unit test for method add of class Router
def test_Router_add():
    BASE_PARAMS = {
        "uri": "/{id}",
        "methods": ["GET", "POST"],
        "handler": "handler",
        "host": "host",
        "strict_slashes": True,
        "stream": True,
        "ignore_body": True,
        "version": 1,
        "name": "name",
        "unquote": True,
        "static": True,
    }

    # Test with base params
    router = Router()
    route = router.add(**BASE_PARAMS)
    assert isinstance(route, Route)
    assert route.ctx.ignore_body == True
    assert route.ctx.stream == True
    assert route.ctx.hosts == ["host"]
    assert route.ctx.static == True

    # Test dynamic parameters
    router = Router

# Generated at 2022-06-21 23:45:43.347945
# Unit test for method add of class Router
def test_Router_add():
    # set up
    uri = "some/path"
    methods = ["GET"]
    handler = lambda req: print("this is a handler")
    host = "hello"
    strict_slashes = False
    stream = False
    ignore_body = True
    version = 1.0
    name = "A handler"
    unquote = False
    static = True
    params = {
        "path": "some/path",
        "handler": handler,
        "methods": methods,
        "name": name,
        "strict": strict_slashes,
        "unquote": unquote,
        }
    router = Router()

    # run test
    result = router.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)
# Unit test

# Generated at 2022-06-21 23:45:46.214461
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    try:
        router.finalize()
    except SanicException:
        pass
    # TODO: this test is a dummy, make it more relevant
    assert True

# Generated at 2022-06-21 23:45:50.477704
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router
    assert router.routes_all == []
    assert router.routes_static == OrderedDict()
    assert router.routes_dynamic == OrderedDict()
    assert router.routes_regex == OrderedDict()


# Generated at 2022-06-21 23:45:57.338057
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    r.ctx.app = 'app'
    r.dynamic_routes = {'1': 'A', '2': 'B', '3': 'C'}
    with pytest.raises(SanicException):
        r.finalize()
    r.dynamic_routes = {'1': 'A', '2': 'B', '__file_uri__': 'C'}
    r.finalize()
    r.ctx.app = None
    r.finalize()

# Generated at 2022-06-21 23:46:18.378567
# Unit test for method add of class Router
def test_Router_add():
    ROUTER_CACHE_SIZE = 1
    ALLOWED_LABELS = ["__test__"]
    class Router(BaseRouter):
        """
        The router implementation responsible for routing a :class:`Request` object
        to the appropriate handler.
        """

        DEFAULT_METHOD = "GET"
        ALLOWED_METHODS = HTTP_METHODS

        def _get(
            self, path: str, method: str, host: Optional[str]
        ) -> Tuple[Route, RouteHandler, Dict[str, Any]]:
            try:
                return self.resolve(
                    path=path,
                    method=method,
                    extra={"host": host},
                )
            except RoutingNotFound as e:
                raise NotFound("Requested URL {} not found".format(e.path))

# Generated at 2022-06-21 23:46:28.266493
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    uri = "/"
    methods = ["GET", "POST", "OPTIONS"]
    handler = "dummy_handler"
    host = None
    strict_slashes = False
    stream = False
    ignore_body = False
    version = 0
    name = "dummy_name"
    unquote = False
    static = False

# Generated at 2022-06-21 23:46:32.779193
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_router = Router()
    route = Route("/", "GET", lambda: None, None)
    test_router.dynamic_routes = {"/": route}

    with pytest.raises(SanicException):
        test_router.finalize()


# Generated at 2022-06-21 23:46:36.855685
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.constants import HTTP_METHODS
    from sanic.models.handler_types import RouteHandler
    r = Router()
    r.add('/', HTTP_METHODS, RouteHandler())
    assert r.finalize() == None

# Generated at 2022-06-21 23:46:42.140980
# Unit test for method add of class Router
def test_Router_add():
    # Initialize the Router class
    r = Router()
    # If request has same uri and method then that route handler called
    r.add(uri = '/', method = ['GET'], handler = 'Function')
    # If request has same uri and method then that route handler called
    r.add(uri = '/About', method = ['GET'], handler = 'Function')
    # If request has same uri and method then that route handler called
    r.add(uri = '/Contact', method = ['GET'], handler = 'Function')
    # If request has same uri and method then that route handler called
    r.add(uri = '/Product', method = ['GET'], handler = 'Function')
    # If request has same uri and method then that route handler called

# Generated at 2022-06-21 23:46:45.714735
# Unit test for method finalize of class Router
def test_Router_finalize():
    route = Route('some', RouteHandler, 'test', [], {})
    route.labels = ['__test__']
    router = Router()
    router.dynamic_routes = {'test': route}
    try:
        router.finalize()
    except SanicException:
        assert True
        return
    assert False


# Generated at 2022-06-21 23:46:57.126971
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic_routing.route import Route
    from sanic.views import HTTPMethodView
    from sanic.response import text

    class TestView(HTTPMethodView):
        def get(self, request):
            return text("I am get method")

        def post(self, request):
            return text("I am post method")

    router = Router()

    # Test case: Route is executed successfully and finalize method is executed without error
    try:
        router.add(uri="/add", endpoint=TestView.as_view(), methods=["GET", "POST", "OPTIONS"])
    except:
        assert False

    # Test case: Parameter names cannot use '__'

# Generated at 2022-06-21 23:46:58.285653
# Unit test for method finalize of class Router
def test_Router_finalize():
    #TODO: Write test
    pass

# Generated at 2022-06-21 23:47:11.230636
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    route = router.add("/", ["GET", "POST"], lambda request: text("OK"))
    assert isinstance(route, Route)
    assert route.ctx.hosts == [None]
    assert route.ctx.ignore_body is False
    assert route.ctx.stream is False
    assert route.ctx.static is False
    assert route.ctx.version == None
    assert route.methods == ["GET", "POST"]
    assert route.name is None
    assert route.path == "/"
    assert route.strict is False
    assert route.unquote is False
    assert router.routes_all[route.key] == route
    assert router.routes_dynamic[route.key] == route
    assert router.routes_dynamic[route.key] == route
    assert router

# Generated at 2022-06-21 23:47:15.204878
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r.DEFAULT_METHOD == 'GET'
    assert r.allowed_methods == ('GET', 'HEAD', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS')


if __name__ == '__main__':
    test_Router()

# Generated at 2022-06-21 23:47:34.858076
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    try:
        router.finalize()
    except Exception:
        assert False
    assert True

# Generated at 2022-06-21 23:47:42.721085
# Unit test for method add of class Router
def test_Router_add():
    from types import FunctionType,LambdaType
    rt = Router()
    assert isinstance(rt, Router)

    assert rt.allowed_methods == Router.ALLOWED_METHODS
    assert rt.default_method == Router.DEFAULT_METHOD

    assert not rt.routes_all.keys()
    assert not rt.routes_static.keys()
    assert not rt.routes_dynamic.keys()
    assert not rt.routes_regex.keys()

    assert not rt.routes.keys()
    assert not rt.name_index.keys()

    assert not rt.static_routes.keys()
    assert not rt.dynamic_routes.keys()
    assert not rt.regex_routes.keys()



# Generated at 2022-06-21 23:47:48.139467
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic

    app = Sanic("PathParameterEscape")

    app.blueprint(lambda _: None, url_prefix="/users/<user_id__>")

    with pytest.raises(SanicException) as exc:
        app.router.finalize()

    assert "Invalid route" in str(exc)

# Generated at 2022-06-21 23:47:57.013120
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        class test_router(Router):
            def finalize(self, *args, **kwargs):
                super().finalize(*args, **kwargs)

                for route in self.dynamic_routes.values():
                    if any(
                        label.startswith("__") and label not in ALLOWED_LABELS
                        for label in route.labels
                    ):
                        raise SanicException(
                            f"Invalid route: {route}. Parameter names cannot use '__'."
                        )

    except Exception as error:
        print("Error: " + repr(error))
    else:
        print("Finalize method works correctly")


# Generated at 2022-06-21 23:48:09.751172
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.request import Request
    from typing import Any
    from sanic_routing.route import Route
    ro = Router()
    ro._get_dynamic_routes = lambda: {
        'path_without_slash': Route(
            'path_without_slash',
            lambda request: request.path,
            methods=['POST'],
            ctx=dict(
                host=None,
                hosts=None,
                ignore_body=False,
                stream=False,
                static=False
            ),
            middlewares=[],
            name=None,
            strict_slashes=False,
            unquote=False,
            uri='path_without_slash',
            version=0)
    }
    with pytest.raises(SanicException) as ex:
        ro.final

# Generated at 2022-06-21 23:48:10.241840
# Unit test for method finalize of class Router
def test_Router_finalize():
    assert True

# Generated at 2022-06-21 23:48:17.720779
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route(uri="/uri", methods=["GET"], handler=lambda: None)
    route.labels.append("__everything_goes__")
    router.dynamic_routes[route.uri] = route
    try:
        router.finalize()
    except SanicException as e:
        assert "__everything_goes__" in e.args[0]
    else:
        raise SanicException("No SanicException was thrown")

# Generated at 2022-06-21 23:48:27.393830
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router._get == router.get
    assert router._get.cache_info().hits == 0
    assert router._get.cache_info().misses == 0
    assert router._get.cache_info().maxsize == ROUTER_CACHE_SIZE
    assert router.finalize == router.finalize
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []
    assert router.find_route_by_view_name == router.find_route_by_view_name
    assert router.DEFAULT_METHOD == "GET"


# Generated at 2022-06-21 23:48:38.971401
# Unit test for method add of class Router
def test_Router_add():
    from sanic.app import Sanic
    from sanic.response import json

    app = Sanic("test_Router_add")

    def handler(request):
        return json({"test": True})

    def bad_handler(request):
        raise Exception("Oh no")

    # Normal call
    route = app.router.add("/test", methods=["GET"], handler=handler)
    assert isinstance(route, Route)

    # Testing if the exception is raised when the methods are invalid
    with pytest.raises(AssertionError):
        app.router.add("/test", methods=["get"], handler=handler)

    # Testing if all the decorators are working
    route = app.router.add(
        "/test_decorators", methods=["GET"], handler=bad_handler
    )
   

# Generated at 2022-06-21 23:48:40.897122
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None

# Generated at 2022-06-21 23:49:19.643874
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    try:
        r.finalize()
    except:
        assert False
    r.add('/test1/<label1:string>', ['GET'], None)
    r.add('/test2', ['GET'], None)
    try:
        r.finalize()
    except:
        assert False
    assert r.find_route_by_view_name('test1_GET') is not None
    assert r.find_route_by_view_name('test2_GET') is not None
    assert r.find_route_by_view_name('test3_GET') is None

# Generated at 2022-06-21 23:49:32.880296
# Unit test for method add of class Router
def test_Router_add():
    # 1. Test with valid parameters
    router = Router()
    def handler():
        pass
    methods = ["GET", "POST", "OPTIONS"]
    path = "/"
    host = "localhost"
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = "test"
    unquote = False
    static = False
    route = router.add(uri = path, methods = methods, handler = handler, host = host, 
                        strict_slashes = strict_slashes, stream = stream, ignore_body = ignore_body,
                        version = version, name = name, unquote = unquote, static = static)
    assert type(route) == Route

    # 2. Test with invalid parameters:
    # 2.1 Version = 1.2
    router = Router()


# Generated at 2022-06-21 23:49:43.038882
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.app import Sanic
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.request import Request
    from sanic.response import HTTPResponse
    import pytest

    # Unit test: type system
    class TestClass():
        def __init__(self):
            self.routes = {}
            self.static_routes = {}
            self.dynamic_routes = {}
            self.regex_routes = {}

    # Unit test: route object
    class TestRoute():
        def __init__(self):
            self.labels = ['__file_uri__']

        def get_name(self):
            return self.labels


    app = Sanic("test")

    # Unit test: SanicException 1


# Generated at 2022-06-21 23:49:54.677761
# Unit test for constructor of class Router
def test_Router():
    from sanic.log import logger_setup as _logger_setup

    _logger_setup()

    router = Router(ctx=None, prefix=None, filters=None, async_mode=None)

    assert router.routes == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.prefix == None
    assert router.filters == None
    assert router.async_mode == None
    assert router.finalized is False
    assert router.methods == ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD', 'OPTIONS', 'CONNECT', 'TRACE']


# Generated at 2022-06-21 23:50:01.573361
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic_routing.router import Router

    router = Router()
    router.add(uri='/user', methods=['GET', 'POST'], handler='None')
    try:
        router.add(uri='/user/__id__', methods=['GET', 'POST'], handler='None')
        assert False
    except SanicException:
        assert True
    assert True

# Generated at 2022-06-21 23:50:11.759252
# Unit test for method add of class Router
def test_Router_add():
    router=Router()
    uri="/listUser"
    methods=["GET","POST","OPTIONS"]
    handler="testHandler"
    strict_slashes=False
    stream=False
    ignore_body=False
    version=None
    name=None
    unquote=False
    static=False
    router.add(uri,methods,handler,strict_slashes=strict_slashes,
    stream=stream,ignore_body=ignore_body,version=version,name=name,unquote=unquote,static=static)

    assert router.routes_dynamic["/listUser"]._methods==methods
