

# Generated at 2022-06-21 23:40:15.312429
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    uri = r"/{number:\d+}"
    methods = ["GET"]
    handler = RouteHandler()

    router.add(uri, methods, handler)

    with pytest.raises(SanicException):
        router.finalize()


# Generated at 2022-06-21 23:40:24.973542
# Unit test for method add of class Router
def test_Router_add():
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.constants import HTTP_METHODS as methods
    from sanic.router import Router

    class MockView(HTTPMethodView):

        def get(self, request):
            return HTTPResponse()

        def post(self, request):
            return HTTPResponse()

    router = Router()

    mock_view = MockView.as_view()

    # Simple
    router.add("/")(mock_view)

    # Host
    router.add("/", host="example.com")(mock_view)

    # Methods
    router.add("/", methods=("GET", "POST"))(mock_view)

    #

# Generated at 2022-06-21 23:40:35.810637
# Unit test for method add of class Router
def test_Router_add():
    from sanic.app import Sanic
    from sanic.response import text
    app = Sanic(__name__)
    router = Router(app)
    router.add("/", ["POST"], text, host = ['127.0.0.1', 'localhost'], version = '0.0.0', name = "text", unquote = False, static = False)
    assert router.routes_all['/'].ctx.hosts == ['127.0.0.1', 'localhost']
    assert router.routes_all['/'].ctx.static == False
    assert router.routes_all['/'].ctx.version == '0.0'
    assert router.routes_all['/'].ctx.name == 'text'
    assert router.routes_all['/'].ctx.un

# Generated at 2022-06-21 23:40:49.199311
# Unit test for method add of class Router
def test_Router_add():
    from sanic.app import Sanic
    uri = '/'
    methods = ['']
    handler = lambda x, y: 3
    host = None
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = None
    app = Sanic('Sanic')
    # First, route does not exist
    check = app.router.find_route_by_view_name('test')
    assert check is None
    # Second, route exist
    app.router.add(uri,methods,handler,host,strict_slashes,stream,ignore_body, version, name)
    check = app.router.find_route_by_view_name('test')
    assert check is not None

# Generated at 2022-06-21 23:40:51.360183
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    router.compile()

# Generated at 2022-06-21 23:41:02.467520
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    print(type(router))
    assert isinstance(router, BaseRouter)

    def handler(request):
        pass

    router.add("/", ["GET", "POST"], handler, host="test")
    route, handler, params = router._get("/", "GET", "test")

    # The route, handler and params should be expected
    assert isinstance(route, Route)
    assert handler is not None
    assert isinstance(handler, type(handler))
    assert isinstance(params, dict)
    assert len(params) == 0


# Generated at 2022-06-21 23:41:07.610748
# Unit test for method finalize of class Router
def test_Router_finalize():
    def route_handler():  # type: ignore
        pass
    router = Router()
    router.add("/test/<param>", ["GET"], route_handler)
    router.finalize()

# Generated at 2022-06-21 23:41:16.528893
# Unit test for constructor of class Router
def test_Router():
    from unittest.mock import Mock
    from sanic.app import Sanic

    app = Sanic("test_Router")

    # Initialize router
    router = Router(app)

    # Test methods
    assert isinstance(router.routes_all, list)
    assert router.routes_all == []
    assert isinstance(router.routes_static, dict)
    assert router.routes_static == {}
    assert isinstance(router.routes_dynamic, dict)
    assert router.routes_dynamic == {}
    assert isinstance(router.routes_regex, dict)
    assert router.routes_regex == {}



# Generated at 2022-06-21 23:41:19.845366
# Unit test for constructor of class Router
def test_Router():
    # Test construction of the Router instance
    assert(isinstance(Router(), Router))


# Generated at 2022-06-21 23:41:30.270622
# Unit test for method add of class Router
def test_Router_add():
    """
    Test description
    """
    # initialise a dict to test against
    data = {}

    # set up a test route
    route_test = Route(app=None, rule="/test", methods=["GET"], handler=None)

    # make a test instance of Router and add the route to the instance
    r_test = Router()
    assert r_test.ctx is None
    assert r_test.dynamic_routes is None
    assert r_test.static_routes is None
    assert r_test.regex_routes is None
    assert r_test.url_for_static is None
    assert r_test.routes_all is None
    assert r_test.routes_static is None
    assert r_test.routes_dynamic is None

# Generated at 2022-06-21 23:41:48.573573
# Unit test for method add of class Router
def test_Router_add():
    from sanic.request import Request
    from sanic.views import HTTPMethodView
    from typing import Dict, Any

    class TestRouter(Router):
        def resolve(self, path: str, method: str, extra: Dict[str, Any]) -> Tuple[Route, RouteHandler, Dict[str, Any]]:
            return (Route(), None, {})
        
        @lru_cache(maxsize=ROUTER_CACHE_SIZE)
        def get(self, path: str, method: str, host: Optional[str]) -> Tuple[Route, RouteHandler, Dict[str, Any]]:
            return (Route(), None, {})
    
    test = TestRouter()
    test.add("/", ["GET"], None)

# Generated at 2022-06-21 23:41:58.953465
# Unit test for method add of class Router
def test_Router_add():
    import sys
    import os

    sys.path.insert(0,os.path.abspath(__file__+"/../../.."))

    from sanic.router import Router


    # Test extracted from this line in sanic_api.py
    #    app.add_route(handler.dispatch, '/', 'GET')
    def test_Router_add():
        router = Router()

        # Create mock object
        class Test:
            async def dispatch(self, request):
                return request

        test = Test()

        router.add("/", ["GET"], test.dispatch)

if __name__ == "__main__":
    test_Router_add()

# Generated at 2022-06-21 23:42:07.711138
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    uri = "test"
    methods = ["GET"]
    handler = RouteHandler()
    host = "www.google.com"
    strict_slashes = "false"
    stream = "false"
    ignore_body = "false"
    version = 2
    name = "mama"
    unquote = "false"
    static = "false"
    route = router.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)
    assert isinstance(route, Route)


# Generated at 2022-06-21 23:42:09.047053
# Unit test for method add of class Router
def test_Router_add():
    # TODO: Implement this
    pass

# Generated at 2022-06-21 23:42:18.813225
# Unit test for method finalize of class Router
def test_Router_finalize():
    from unittest.mock import patch

    from sanic import Sanic

    app = Sanic("__main__")

    test_router = Router(app, host="example.com")
    test_router.dynamic_routes = {
        "GET example.com/dyn/<param:path>"
    }

    with patch("sanic.router.Router.dynamic_routes", new={
        "GET example.com/dyn/<param:path>"
    }):
        with pytest.raises(SanicException):
            test_router.finalize()



# Generated at 2022-06-21 23:42:20.300612
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router

# Generated at 2022-06-21 23:42:21.877982
# Unit test for constructor of class Router
def test_Router():
    # Add a handler to the router
    router = Router()
    router.add(uri = "/", methods = ["GET"], handler = print("Hello World"))


# Generated at 2022-06-21 23:42:33.361250
# Unit test for method add of class Router
def test_Router_add():
    # Declaration of function
    def test_func(request):
        return 'hi'
    
    router = Router()
    
    # Call add method
    result = router.add(uri='/test', methods=['POST'], handler=test_func)
    
    # Get tuple of method test_func
    tuple_of_method = test_func.__code__.co_varnames
    # Check handler has variable names
    assert tuple_of_method == ('request',)
    
    assert result.reqs == {'host': None}
    
    assert result.methods == {'POST'}
    assert result.strict == False
    assert result.hosts == [None]
    assert result.ctx.ignore_body == False
    assert result.ctx.stream == False

# Generated at 2022-06-21 23:42:43.482600
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()

    # Test a route without a label
    route = Route(uri='', handler=None, methods=[])
    router.dynamic_routes[('', 'GET')] = route

    # Test a route with an allowed label
    route = Route(
        uri='',
        handler=None,
        methods=[],
        labels=['__file_uri__']
    )
    router.dynamic_routes[('/__file_uri__', 'GET')] = route

    # Test a route with a label starting with an underscore
    route = Route(
        uri='',
        handler=None,
        methods=[],
        labels=['__file']
    )
    router.dynamic_routes[('/__file', 'GET')] = route

    # Test a route with a label

# Generated at 2022-06-21 23:42:53.814602
# Unit test for method finalize of class Router
def test_Router_finalize():
    # create a demo app, with router
    app = Sanic('test')
    router = Router()

    # create a test route without name
    route = Route(None, None, None, None, None, None)
    # add route to router
    router.dynamic_routes[route] = route

    # test case 0, default function
    class_Router_finalize = Router()
    class_Router_finalize.dynamic_routes[route] = route
    # expect to raise exception
    with pytest.raises(SanicException) as e_info:
        class_Router_finalize.finalize()
    assert e_info.value.args[0] ==  "Invalid route: " + str(route) + ". Parameter names cannot use '__'."


# Generated at 2022-06-21 23:43:01.405288
# Unit test for constructor of class Router
def test_Router():
    router = Router()


# Generated at 2022-06-21 23:43:08.120877
# Unit test for method add of class Router
def test_Router_add():
    import pytest

    router = Router()

# Generated at 2022-06-21 23:43:09.559945
# Unit test for constructor of class Router
def test_Router():
    assert Router().routes_all == {}


# Generated at 2022-06-21 23:43:22.054945
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    r.add("/user/<name>/<id>", ["GET", "POST"], lambda x: x)
    try:
        r.finalize()
    except SanicException as e:
        assert str(e) == "Invalid route: <Route: GET /user/<name>/<id> -> lambda x: x>. Parameter names cannot use '__'."
    else:
        assert True == False
    r.add("/user/<id>/<__file_uri__>", ["GET", "POST"], lambda x: x)
    try:
        r.finalize()
    except SanicException as e:
        assert str(e) == "Invalid route: <Route: GET /user/<id>/<__file_uri__> -> lambda x: x>. Parameter names cannot use '__'."

# Generated at 2022-06-21 23:43:34.264954
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Check exception is not raised
    router = Router()
    route = Route(
        uri='/',
        methods=['get'],
        handler='handler',
        name='name',
        strict=False,
        unquote=False,
    )
    router.dynamic_routes[''] = route
    router.finalize()
    # Check exception is raised
    router = Router()
    route = Route(
        uri='/',
        methods=['get'],
        handler='handler',
        name='name',
        strict=False,
        unquote=False,
    )
    route.labels.add('__illegal__')
    router.dynamic_routes[''] = route
    with pytest.raises(SanicException) as excinfo:
        router.finalize()


# Generated at 2022-06-21 23:43:36.921144
# Unit test for constructor of class Router
def test_Router():
    from sanic import Sanic
    router = Router(Sanic())
    assert isinstance(router, Router)

# Generated at 2022-06-21 23:43:41.292955
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == []
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == []

# Generated at 2022-06-21 23:43:51.118299
# Unit test for constructor of class Router
def test_Router():
    router = Router()

    assert isinstance(router, Router)
    assert isinstance(router.routes, dict)
    assert isinstance(router.dynamic_routes, dict)
    assert isinstance(router.static_routes, dict)
    assert isinstance(router.regex_routes, dict)
    assert isinstance(router.name_index, dict)



# Generated at 2022-06-21 23:43:57.400878
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        router = Router()
        router.add("/users/", ["GET"], lambda: "foo", name="users_get_")
    except SanicException as e:
        assert "Invalid route: /usersttt/ -> <lambda>" in e.message
        return 

    assert False

# Generated at 2022-06-21 23:44:05.290110
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.app import Sanic
    from sanic.router import Router

    app = Sanic('test_Router_finalize')  # type: ignore
    router = Router(app, False)

    with pytest.raises(SanicException):
        router.add('/', ('GET',), lambda : 'OK', ['__test__'])

    with pytest.raises(SanicException):
        router.add('/<test>', ('GET',), lambda : 'OK', ['__test__'])


# Generated at 2022-06-21 23:44:24.763515
# Unit test for method finalize of class Router
def test_Router_finalize():
    uri = "/api/v1/test"
    methods = ["GET", "POST", "OPTIONS"]
    test_router = Router()
    try:
        test_router.add(uri, methods, route_handler, host="localhost")
    except SanicException as e:
        assert(isinstance(e, SanicException))
        assert(str(e) == "Invalid route: Route(GET,POST,OPTIONS,/api/v1/test). Parameter names cannot use '__.'")
    else:
        assert(False)

async def route_handler():
    pass

# Generated at 2022-06-21 23:44:31.389576
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.exceptions import SanicException
    from tests.test_utils import create_route_obj
    from tests.test_utils import create_router_obj

    route_obj = create_route_obj('/foo/<bar>', None, None, None, None)
    router_obj = create_router_obj(route_obj)

    try:
        router_obj.finalize()
    except SanicException:
        assert True
    else:
        assert False

# Generated at 2022-06-21 23:44:38.951242
# Unit test for method add of class Router
def test_Router_add():
    # Fixture 1
    router = Router()
    # Fixture 2
    uri = '/foo'
    # Fixture 3
    methods = ["GET"]
    # Fixture 4
    handler = lambda request: 'foo handler'
    # Fixture 5
    host = None
    # Fixture 6
    strict_slashes = False

    # Test no. 1
    route = router.add(
        uri=uri,
        methods=methods,
        handler=handler,
        host=host,
        strict_slashes=strict_slashes
    )

    assert isinstance(route, Route)
    assert isinstance(route.ctx, dict)
    assert isinstance(route.ctx['kwargs'], dict)
    assert isinstance(route.ctx['args'], list)

# Generated at 2022-06-21 23:44:50.459048
# Unit test for method add of class Router
def test_Router_add():
    Handler = RouteHandler
    Router = Router
    router = Router()

    def handler(*args, **kwargs):
        pass

    uri = 'uri'
    methods = ['GET']
    handler = handler
    host = None
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = None
    unquote = False
    static = False

    # Test case 1.
    # Input: uri = 'uri', method = ['GET']
    # Expected: Route object
    route = router.add(uri, methods, handler, host)
    assert isinstance(route, Route)

    # Test case 2.
    # Input: uri = 'uri', method = ['GET']
    # Expected: Route object

# Generated at 2022-06-21 23:44:59.458229
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    from sanic.router import Router
    from sanic.models.handler_types import RouteHandler
   
    def func():
        return "test"

    routing = Router()
    routing.add("/path", methods=["GET"], handler=func)
    routing.add("/<p1>", methods=["GET"], handler=func)
    routing.add("/<p1>/<p2>", methods=["GET"], handler=func)
    routing.add("/<p1>/<p2>/<p3>", methods=["GET"], handler=func)

    # test the parameter names cannot use '__'
    with pytest.raises(SanicException) as err:
        routing.finalize()

# Generated at 2022-06-21 23:45:05.161848
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route('/', None, None, [])
    with pytest.raises(SanicException) as exc_info:
        router.dynamic_routes = {'a': route}
        router.finalize()
    assert str(exc_info.value) == "Invalid route: Route('/', None, None, [])."

# Generated at 2022-06-21 23:45:13.064978
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    uri = "test"
    methods = ["GET", "POST", "OPTIONS"]
    handler = asyncio.coroutine(lambda : None)
    host = "127.0.0.1"
    strict_slashes = True
    stream = False
    ignore_body = False
    version = None
    name = "route"
    unquote = False
    static = True
    routes = router.add(uri,methods,handler,host,strict_slashes,stream,ignore_body,version,name,unquote,static)
    assert(isinstance(routes, list))
    assert(isinstance(routes[0], Route))


# Generated at 2022-06-21 23:45:22.573591
# Unit test for method finalize of class Router
def test_Router_finalize():
    assert getattr(Router, 'finalize', None) is not None
    
    from mock import patch
    
    from sanic.router import Router
    from sanic.exceptions import SanicException
    
    path = 'sanic.router.Router.finalize()'
    
    with patch('sanic.router.Router.dynamic_routes', {}):
        with patch('sanic.router.Router.routes', {}):
            router = Router()
            
            with patch('sanic.router.ALLOWED_LABELS', ['__file_uri__']):
                route = {'labels': ['__file_uri__']}
                with patch.object(Router, 'dynamic_routes', {'route':route}):
                    router.finalize()
               

# Generated at 2022-06-21 23:45:25.892498
# Unit test for constructor of class Router
def test_Router():
    assert(Router()._Router__allowed_methods == HTTP_METHODS)

# Unit tests for method add of class Router


# Generated at 2022-06-21 23:45:39.207450
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    routes = [Route(path=None, handler=None, strict=False, methods=None,
         name=None, param_types=None, unquote=False, ctx=r.ctx,
         labels={'__file_uri__': ''}, defaults={}),
         Route(path=None, handler=None, strict=False, methods=None,
         name=None, param_types=None, unquote=False, ctx=r.ctx,
         labels={'__file_uri__': ''}, defaults={}),
         Route(path=None, handler=None, strict=False, methods=None,
         name=None, param_types=None, unquote=False, ctx=r.ctx,
         labels={'__file_uri__': ''}, defaults={})]
    r.dynamic_r

# Generated at 2022-06-21 23:45:53.495538
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    router = Router()
    route = Route("test", uri="/test/<test1>", handler=None)
    router.dynamic_routes["test"] = route
    with pytest.raises(SanicException) as excinfo:
        router.finalize(None)

    expected = "Invalid route: test: /test/<test1>. Parameter names cannot " + \
    "use '__'."
    assert str(excinfo.value) == expected

# Generated at 2022-06-21 23:46:03.329707
# Unit test for method add of class Router
def test_Router_add():
    uri = "/test/add"
    methods = ["GET"]
    handler = "Test Handler"
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = None
    unquote = False

    r = Router()
    route = r.add(uri, methods, handler, strict_slashes=strict_slashes, stream=stream)
    assert uri == route.path
    assert ignore_body == route.ctx.ignore_body
    assert stream == route.ctx.stream
    assert version is route.ctx.version
    assert name is route.ctx.name
    assert unquote is route.ctx.unquote



# Generated at 2022-06-21 23:46:07.359043
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.registry == ['HEAD', 'GET', 'POST', 'PUT', 'DELETE', 'OPTIONS', 'PATCH', 'TRACE', 'CONNECT', 'ANY']
    assert router.routes_all == {}

# Generated at 2022-06-21 23:46:17.607551
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.app import Sanic
    app = Sanic("test_Router_finalize")
    router = Router(app)
    router.add(
        uri='/',
        methods=['GET'],
        handler=None,
        host=None,
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version=None,
        name=None,
        unquote=False,
        static=False,
    )
    try:
        router.finalize()
    except:
        traceback.print_exc()
        assert False
    else:
        assert True

# Generated at 2022-06-21 23:46:29.302739
# Unit test for method add of class Router
def test_Router_add():
    # Create mock objects for Router, Route, route_handler, host
    router = mock.MagicMock()
    route = mock.MagicMock()
    route_handler = mock.MagicMock()
    host = mock.MagicMock()

    # Define return values of methods of mock objects
    router.hosts = [host]
    route.ctx.hosts = [host]
    route.ctx.ignore_body = False
    route.ctx.stream = False
    route.ctx.static = False

    # Define return values of methods of mock objects
    router.routes_dynamic = {route}
    router.dynamic_routes = {route}
    router.regex_routes = {route}

    # Call method and check return value

# Generated at 2022-06-21 23:46:32.725504
# Unit test for constructor of class Router
def test_Router():
    """Testing the constructor of class Router"""
    a = Router()
    assert a.static_routes == {}
    assert a.dynamic_routes == {}
    assert a.regex_routes == {}


# Generated at 2022-06-21 23:46:39.678949
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route("/maybe/<name>", lambda: None, host=None,
                  requirements={'host': None},
                  methods=['GET', 'HEAD'], labels=("__file_uri__", "__name"))
    router.dynamic_routes[route.get_hash()] = route
    router.finalize()
    assert router.finalized == True
    assert router.dynamic_routes[route.get_hash()] == route


# Generated at 2022-06-21 23:46:47.502323
# Unit test for method add of class Router
def test_Router_add():
    from sanic_routing.resolve import Resolver  # type: ignore
    from sanic.router import Router  # type: ignore
    from sanic.request import Request  # type: ignore
    from sanic.response import HTTPResponse  # type: ignore
    async def handler(request):
        return HTTPResponse('Hello world!')
    router = Router(Resolver())
    router.add('/', ['GET'], handler)
    req = Request('GET', '/')
    req.app = router.ctx.app
    req.app.register_listener(router.ctx.app.before_server_start, 'before_server_start')
    assert router.get(req.path, req.method, req and req.host) == (router.routes[0], handler, {})

# Generated at 2022-06-21 23:46:58.173378
# Unit test for method add of class Router
def test_Router_add():
    def handler():
        return "handler"

    # test all true
    uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static = (
        "/",
        ("GET", "POST", "OPTIONS"),
        handler,
        "localhost",
        True,
        True,
        True,
        "v1",
        "test",
        True,
        True
    )
    router = Router()
    routes = router.add(
        uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static
    )
    assert len(router.dynamic_routes) == 1
    assert len(router.routes) == 1
    assert len(router.static_routes)

# Generated at 2022-06-21 23:47:07.585151
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    def handler():
        pass
    router.add("/", ["GET"], handler, host="localhost")
    router.add("/test/<uuid:label>", ["GET"], handler, host="localhost")
    router.add("/test/<uuid:label>", ["GET"], handler, host="localhost")
    router.add("/test2/<label>", ["GET"], handler, host="localhost")
    router.add("/test2/<__label>", ["GET"], handler, host="localhost")
    router.finalize()

# Generated at 2022-06-21 23:47:23.512248
# Unit test for constructor of class Router
def test_Router():
    assert True

# Generated at 2022-06-21 23:47:34.648344
# Unit test for method finalize of class Router
def test_Router_finalize():
    # First finalize without any error
    router = Router()
    router.dynamic_routes = {
        "user": Route(
            "GET", "/{name}", "view_function", None, None, None, None, {"name"}
        )
    }
    router.finalize()

    # Finalize with error
    router = Router()
    router.dynamic_routes = {
        "user": Route(
            "GET", "/{__name}", "view_function", None, None, None, None, {"__name"}
        )
    }
    with pytest.raises(SanicException) as excinfo:
        router.finalize()
    
    assert "Invalid route: GET /{__name}" in str(excinfo.value)

# Generated at 2022-06-21 23:47:39.365611
# Unit test for method finalize of class Router
def test_Router_finalize():
    r = Router()
    r.add("/test")

    # test invalid route
    with pytest.raises(SanicException):
        r.dynamic_routes[0].labels = ["__foo__"]
        r.finalize()

    # exists
    r.dynamic_routes[0].labels = ALLOWED_LABELS
    r.finalize()

# Generated at 2022-06-21 23:47:41.367756
# Unit test for constructor of class Router
def test_Router():
    assert (Router.ALLOWED_METHODS == HTTP_METHODS)

# Generated at 2022-06-21 23:47:47.096187
# Unit test for method add of class Router
def test_Router_add():
    # Check the required parameters of method add of class Router
    router = Router()
    uri = "PLACEHOLDER"
    methods = ["PLACEHOLDER"]
    handler = "PLACEHOLDER"
    router.add(uri=uri, methods=methods, handler=handler)



# Generated at 2022-06-21 23:47:51.597387
# Unit test for method add of class Router
def test_Router_add():
    from sanic import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse

    app = Sanic()

    @app.route("/")
    async def test(request: Request) -> HTTPResponse:
        return HTTPResponse(body="OK SANIC")

    request, response = app.test_client.get("/")
    assert response.text == "OK SANIC"

# Generated at 2022-06-21 23:47:56.471731
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router == {}
    assert router.dynamic_routes == {}
    assert router.static_routes == {}
    assert router.name_to_regex == {}
    assert router.regex_routes == {}
    assert router.name_index_all == {}
    assert router.name_index == {}


# Generated at 2022-06-21 23:48:02.905994
# Unit test for constructor of class Router
def test_Router():
    # test that router object created successfully
    router = Router()
    assert router.router_cache_size == ROUTER_CACHE_SIZE
    assert router.allowed_labels == ALLOWED_LABELS
    assert isinstance(router.router_cache, dict)

# Generated at 2022-06-21 23:48:06.688206
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router(app = None)
    router.dynamic_routes['toto'] = None
    router.dynamic_routes['titi'] = None
    router.finalize()



# Generated at 2022-06-21 23:48:08.594410
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)

# Generated at 2022-06-21 23:48:40.760485
# Unit test for method finalize of class Router
def test_Router_finalize():
    assert 1+1 == 2

# Generated at 2022-06-21 23:48:47.250519
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert (router.routes) == {}
    assert (router.dynamic_routes) == {}
    assert (router.static_routes) == {}
    assert (router.regex_routes) == {}
    assert (router.name_index) == {}
    assert (router.ctx) == {}
    assert (router.cache) == {}


# Generated at 2022-06-21 23:48:52.562625
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        route = Route()
        route.labels = {'__file_uri__': 'sanic_routing/route.py'}
        router = Router()
        router.dynamic_routes = {'route': route}
        router.finalize()
    except SanicException:
        raise
    else:
        return True

# Generated at 2022-06-21 23:48:58.103490
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest

    with pytest.raises(SanicException):
        route = Route(
            path="/",
            methods=None,
            handler=None,
            name=None,
            version=None,
            host=None,
            strict_slashes=False,
            unquote=False,
            is_static=False,
        )
        route.labels = ["__re0__", "p", "__re1__"]

        router = Router()
        router.dynamic_routes = {0: route}
        router.finalize()

# Generated at 2022-06-21 23:49:07.686475
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.constants import HTTP_METHODS

    router = Router()
    for method in HTTP_METHODS:
        router.add(
            uri="/test", methods=[method], handler=lambda x: x, host="example.com"
        )

    router.add(uri="/test2/{param}", methods=["GET"], handler=lambda x: x)

    for route in router.routes:
        router.routes_all[route.uri] = route

    router.finalize()
    assert router.routes_all != router.routes

# Generated at 2022-06-21 23:49:21.021994
# Unit test for method add of class Router
def test_Router_add():
    # Class to be used in unit tests
    class MockClass:
        async def get_method(self, request, *args, **kwargs):
            return 'ok'
        def get_method_sync(self, request, *args, **kwargs):
            return 'ok'

    # Initialize router object
    router = Router()
    # Test adding a sync view
    route = router.add(uri='/test/<id>', methods=['GET'], handler=MockClass.get_method_sync)
    assert isinstance(route, Route) == True
    assert route.ctx.ignore_body == False
    assert route.ctx.stream == False
    assert route.ctx.hosts == [None]
    assert route.ctx.static == False
    # Test adding an async view

# Generated at 2022-06-21 23:49:21.806852
# Unit test for method finalize of class Router
def test_Router_finalize():
    import inspect
    assert inspect.getsource(Router.finalize)



# Generated at 2022-06-21 23:49:34.299139
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    from sanic import Blueprint
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.response import text
    from sanic_routing.route import Route
    from sanic_routing.route import RouteHandler

    app = Sanic("test_Router_finalize")
    app.config.KEEP_ALIVE_TIMEOUT = 5

    @app.route("/")
    def handler(request):
        return text("OK")

    def fetch_route_by_view_name(view_name, *args, **kwargs):
        return view_name
    app.router.find_route_by_view_name = fetch_route_by_view_name

    app.blueprint(Blueprint("bp"))


# Generated at 2022-06-21 23:49:37.954840
# Unit test for constructor of class Router
def test_Router():
    # Test with no argument
    test1 = Router()

    # Test with arguments
    test2 = Router("A", "2")

    assert test1 is not None
    assert test2 is not None


# Generated at 2022-06-21 23:49:45.650823
# Unit test for method add of class Router
def test_Router_add():
    routes = Router(ctx=None)
    routes.add(uri='/', methods=['GET'], handler=None)
    assert routes.dynamic_routes == {'/': {'GET': Route(ctx=None, path='/', methods=['GET'], handler=None, name=None, strict=False, alias=False)}}
