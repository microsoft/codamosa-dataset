

# Generated at 2022-06-26 04:05:51.240489
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

# Generated at 2022-06-26 04:05:59.401629
# Unit test for constructor of class Router
def test_Router():
    router_0 = None
    bool_0 = False
    router_0 = Router(router_0, bool_0)
    router_0.get()



# Generated at 2022-06-26 04:06:03.430962
# Unit test for constructor of class Router
def test_Router():
    type_0 = None
    bool_0 = True
    test_case_0(type_0, bool_0)


# Generated at 2022-06-26 04:06:08.249434
# Unit test for method finalize of class Router
def test_Router_finalize():
    type_0 = None
    bool_0 = False
    router_0 = Router(type_0, bool_0)
    try:
        router_0.finalize()
    except SanicException as exception_0:
        pass



# Generated at 2022-06-26 04:06:23.619218
# Unit test for constructor of class Router
def test_Router():
    # Invalid arguments:
    try:
        # None ctx and False safe_mode
        type_0 = None
        bool_0 = False
        router_0 = Router(type_0, bool_0)
        assert False
    except Exception:
        pass
    try:
        # None ctx and True safe_mode
        type_1 = None
        bool_1 = True
        router_1 = Router(type_1, bool_1)
        assert False
    except Exception:
        pass

    # Valid arguments:
    # None ctx and None safe_mode
    type_2 = None
    bool_2 = None
    router_2 = Router(type_2, bool_2)



# Generated at 2022-06-26 04:06:26.379946
# Unit test for method finalize of class Router
def test_Router_finalize():
    type_2 = None
    bool_2 = True
    router_0 = Router(type_2, bool_2)
    # test function here
    with pytest.raises(SanicException):
        router_0.finalize()


# Generated at 2022-06-26 04:06:28.977669
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = None
    router_1 = Router(router_0)
    router_1.finalize()


# Generated at 2022-06-26 04:06:30.347630
# Unit test for constructor of class Router
def test_Router():
    _test_case = test_case_0()

if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-26 04:06:38.931835
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        type_0 = None
        bool_0 = True
        router_0 = Router(type_0, bool_0)
        router_0.finalize()
    except Exception as inst:
        print('Exception thrown in test_Router_finalize:')
        print('    ', inst)
        traceback.print_exc()
        sys.exit(1)
    #
    # should not reach here:
    #
    assert False


# Generated at 2022-06-26 04:06:42.672622
# Unit test for method finalize of class Router
def test_Router_finalize():
    type_0 = None
    bool_0 = True
    router_0 = Router(type_0, bool_0)
    try:
        router_0.finalize()
    except SanicException:
        pass


# Generated at 2022-06-26 04:06:51.329750
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.finalize()


# Generated at 2022-06-26 04:06:55.320562
# Unit test for constructor of class Router
def test_Router():
    try:
        Router()
    except Exception as e:
        print(e)
        assert False
    else:
        assert True



# Generated at 2022-06-26 04:07:04.522478
# Unit test for method finalize of class Router
def test_Router_finalize():
    app = Sanic('test')
    router = Router(app)
    router.add('/test/0/', methods=['GET'], handler=router.finalize)
    router.add('/test/1', methods=['GET'], handler=test_case_0, unquote=True)
    router.add('/test/2', methods=['GET'], handler=test_case_0, unquote=True)
    router.add('/test/3', methods=['GET'], handler=test_case_0, unquote=True)
    router.add('/test/4', methods=['GET'], handler=test_case_0, unquote=True)
    router.add('/test/5', methods=['GET'], handler=test_case_0, unquote=True)

# Generated at 2022-06-26 04:07:07.282702
# Unit test for constructor of class Router
def test_Router():
    # Unit test for the constructor of Router
    router = Router()
    assert router


# Generated at 2022-06-26 04:07:08.690757
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    test_case_0()

# Generated at 2022-06-26 04:07:13.833743
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        var_0 = None
        bool_0 = True
        if bool_0:
            print("Could not test %s::%s due to Error: %s" % (
                "Router", "finalize", 
                "Could not create type due to Error: Invalid test_case"
            ))
    except:
        print("Error raised when testing method finalize of class Router")
        raise


# Generated at 2022-06-26 04:07:15.497648
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_case_0()

# Generated at 2022-06-26 04:07:16.307593
# Unit test for method finalize of class Router
def test_Router_finalize():
    var_0 = Router()
    # var_0.finalize()

# Generated at 2022-06-26 04:07:17.099027
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.finalize()


# Generated at 2022-06-26 04:07:25.235032
# Unit test for method finalize of class Router
def test_Router_finalize():
    import unittest
    import unittest.mock

    try:
        from unittest.mock import call
    except ImportError:
        from mock import call

    router = Router()
    mock_sorted = unittest.mock.Mock()
    mock_is_coroutinefunction = unittest.mock.Mock()
    mock_add_route = unittest.mock.Mock()
    mock_finalize = unittest.mock.Mock()

# Generated at 2022-06-26 04:07:34.059439
# Unit test for constructor of class Router
def test_Router():
    try:
        router_0 = Router()
        if not isinstance(router_0,Router):
            return False
    except Exception:
        return False
    return True


# Generated at 2022-06-26 04:07:38.800483
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    try:
        router_0.finalize()
    except Exception:
        raise AssertionError("finalize method of router raised exception unexpectedly!")


# Generated at 2022-06-26 04:07:39.863082
# Unit test for method finalize of class Router
def test_Router_finalize():
    # create default arguments
    router_0 = Router()
    router_0.finalize()

# Generated at 2022-06-26 04:07:42.644011
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    if (router_0 is None):
        raise Exception("router_0 is None")
    else:
        try:
            router_0.finalize(None)
        except TypeError:
            pass


# Generated at 2022-06-26 04:07:47.388446
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert not r.routes_regex
    assert not r.routes_dynamic
    assert not r.routes_static
    assert not r.routes_all



# Generated at 2022-06-26 04:07:58.215402
# Unit test for method add of class Router
def test_Router_add():
    router_0 = Router()
    route_0 = Route('/static/<path:filename>', 'GET', None, {}, {'host': None}, False, False)
    paths = ['hello', 'test', 'goodbye', 'todo']
    for i in paths:
        router_0.add('/static/<path:filename>', 'GET', None, None, False)
        router_0.add('/static/<path:filename>', 'GET', None, None, False)
        router_0.add('/static/<path:filename>', 'GET', None, None, False)
        router_0.add('/todo/<todo_id>', 'GET', None, None, False)

# Generated at 2022-06-26 04:08:09.417763
# Unit test for constructor of class Router

# Generated at 2022-06-26 04:08:11.059475
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()



# Generated at 2022-06-26 04:08:18.727271
# Unit test for constructor of class Router
def test_Router():
    assert isinstance(Router(), Router)
    assert isinstance(Router(add_slash=True), Router)
    assert isinstance(Router(add_slash=False), Router)

# The Sanic.add_route(uri, handler, methods=None, host=None, strict_slashes=None, version=None, name=None, stream=False)
# method takes a URI path, a handler function, and optional keyword arguments
# and associates them with each other.

# Generated at 2022-06-26 04:08:23.047902
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    router_1 = Router()
    assert isinstance(router_1, Router)
    assert router_0 == router_1


# Generated at 2022-06-26 04:08:29.741540
# Unit test for constructor of class Router
def test_Router():

    assert isinstance(router_0, Router)

# Generated at 2022-06-26 04:08:34.946844
# Unit test for constructor of class Router
def test_Router():
    try:
        router_0 = Router()
    except Exception as ex:
        print("Constructor of class Router has errors: " + ex.message)
        return False
    return True



# Generated at 2022-06-26 04:08:40.675817
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    router_1 = Router()
    router_0.add('/', ['GET'], 'DUMMY_ROUTE_HANDLER')
    assert router_0._get('/', 'GET', None) == ('/', 'DUMMY_ROUTE_HANDLER', {})
    assert router_1.get('/', 'GET', None) == ('/', 'DUMMY_ROUTE_HANDLER', {})

# Generated at 2022-06-26 04:08:42.138121
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router



# Generated at 2022-06-26 04:08:44.431110
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-26 04:08:45.340213
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-26 04:08:48.258991
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    assert isinstance(router_0, Router)


# Generated at 2022-06-26 04:09:00.807630
# Unit test for constructor of class Router
def test_Router():
    from sanic.router import Router
    from sanic.response import text
    app = Sanic('test_Router')
    router_0 = Router(app)
    router_1 = Router(app, exception_handler=text)
    router_2 = Router(app, pop_last_slash=True)
    router_3 = Router(app, pop_last_slash=True, exception_handler=text)
    router_4 = Router(app, strict_slashes=False)
    router_5 = Router(app, strict_slashes=False, exception_handler=text)
    router_6 = Router(app, pop_last_slash=True, strict_slashes=False)
    router_7 = Router(app, pop_last_slash=True, strict_slashes=False, exception_handler=text)


# Generated at 2022-06-26 04:09:02.885326
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-26 04:09:05.010722
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    exception = None
    try:
        router_0.finalize()
    except Exception as exception_0:
        exception = exception_0
    assert(
        isinstance(
            exception,
            TypeError
        )
    )

# Generated at 2022-06-26 04:09:16.595922
# Unit test for constructor of class Router
def test_Router():
    assert router_0 is not None


# Generated at 2022-06-26 04:09:18.672348
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    assert router_0


# Generated at 2022-06-26 04:09:23.159595
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    router_0.finalize()

    assert len(router_0.routes_static) == 0
    assert len(router_0.routes_dynamic) == 0
    assert len(router_0.routes_regex) == 0
    assert len(router_0.routes_all) == 0
    assert len(router_0.routes) == 0
    assert len(router_0.name_index) == 0



# Generated at 2022-06-26 04:09:29.384374
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)
    assert isinstance(router, BaseRouter)
    assert isinstance(router.DEFAULT_METHOD, str)
    assert isinstance(router.ALLOWED_METHODS, tuple)


# Generated at 2022-06-26 04:09:30.471843
# Unit test for constructor of class Router
def test_Router():
    assert isinstance(Router(), Router)



# Generated at 2022-06-26 04:09:42.382942
# Unit test for method add of class Router
def test_Router_add():
    path1 = '/path1'
    method1 = 'POST'
    handler1 = 'handler1'
    host1 = 'host1'
    strict2 = False
    stream2 = False
    ignore2 = False
    version2 = 1
    name2 = 'name2'
    unquote2 = True
    static2 = False
    router_1 = Router()
    router_1.add(uri=path1,methods=method1,handler=handler1,host=host1,strict_slashes=strict2,stream=stream2,ignore_body=ignore2,version=version2,name=name2,static=static2)


# Generated at 2022-06-26 04:09:54.966847
# Unit test for method finalize of class Router
def test_Router_finalize():
    # check function finalize in class Router
    import sys
    import inspect
    import re
    member = inspect.getframeinfo(
        inspect.currentframe()).function
    member = re.sub(
        r"test_",
        "",
        member
    )
    member = re.sub(
        r"_0",
        "",
        member
    )
    name = inspect.getframeinfo(inspect.currentframe()).filename
    name = re.sub(
        r"^.*/",
        "",
        name
    )
    name = re.sub(
        r"\.py$",
        "",
        name
    )
    m = re.search(r"test_", name)
    if m:
        pytest.xfail("need to modify test to current method")
    name

# Generated at 2022-06-26 04:09:58.191875
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    router_0.add(uri='/', methods=['GET'], handler=__file__)
    router_0.finalize()


# Generated at 2022-06-26 04:09:59.274870
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()


# Generated at 2022-06-26 04:10:00.849803
# Unit test for constructor of class Router
def test_Router():
    Router()
    assert True

# Unit test to check if the routes have been added successfully

# Generated at 2022-06-26 04:10:23.370316
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    str_0 = 'YovjvIHwMBV'
    tuple_0 = None
    list_0 = [str_0]
    bool_0 = None
    var_0 = router_0.add(str_0, tuple_0, list_0, bool_0, bool_0)
    path_0 = '/GBE2uV7DnX'
    method_0 = 'kKCzIY5Y5J'
    host_0 = 'fOMtbROaX9'
    var_1 = router_0.add(path_0, tuple_0, list_0, host_0, bool_0)
    var_2 = router_0.get(path_0, method_0, host_0)
    router_0.finalize()
    method

# Generated at 2022-06-26 04:10:32.100340
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    str_0 = 'Response was bigger than content-length'
    tuple_0 = None
    list_0 = [str_0]
    bool_0 = None
    var_0 = router_0.add(str_0, tuple_0, list_0, bool_0, bool_0)


# Generated at 2022-06-26 04:10:40.442442
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    str_0 = 'Response was bigger than content-length'
    tuple_0 = None
    list_0 = [str_0]
    bool_0 = None
    var_0 = router_0.add(str_0, tuple_0, list_0, bool_0, bool_0)
    print("result:")
    print(var_0)
    # print(router_0.routes_all)
    # print(router_0.routes_static)
    # print(router_0.routes_dynamic)
    # print(router_0.routes_regex)
    # print(router_0.get("/test2", "GET"))
    # print(router_0.find_route_by_view_name("

# Generated at 2022-06-26 04:10:45.001831
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    str_0 = None
    var_0 = router_0.add(str_0, router_0, router_0, router_0, router_0)
    bytes_0 = None
    router_0.add(bytes_0, router_0, router_0, router_0, router_0)

# Generated at 2022-06-26 04:10:55.364484
# Unit test for method finalize of class Router
def test_Router_finalize():
    print('\n' + '\033[4;35m' + 'test_Router_finalize' + '\033[0;m')
    router_0 = Router()
    str_0 = 'Response was bigger than content-length'
    tuple_0 = None
    list_0 = [str_0]
    router_0.add(str_0, tuple_0, list_0)
    router_0.finalize()
    # TODO: Consider if this is a test
    # if not self.static_routes:
    #     raise SanicException("App does not have any routes")



# Generated at 2022-06-26 04:10:56.872836
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

# Generated at 2022-06-26 04:11:01.550272
# Unit test for method add of class Router
def test_Router_add():
    router_0 = Router()
    router_0._add(None, None, None)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 04:11:06.076286
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    str_0 = 'Response was bigger than content-length'
    tuple_0 = None
    list_0 = [str_0]
    bool_0 = None
    var_0 = router_0.add(str_0, tuple_0, list_0, bool_0, bool_0)


# Generated at 2022-06-26 04:11:16.363675
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    assert router_0._static is False
    assert router_0.middleware == ()
    assert router_0.exception_handler == None
    assert router_0.registry_name == 'routes'
    assert router_0.ctx == None
    assert router_0.routes_all == {}
    assert router_0.routes_static == {}
    assert router_0.routes_dynamic == {}
    assert router_0.routes_regex == []


# Generated at 2022-06-26 04:11:29.044270
# Unit test for constructor of class Router
def test_Router():

    # Check if constructor with no params is working
    router_0 = Router()

    # Check if constructor with params is working
    str_0 = 'Response was bigger than content-length'
    tuple_0 = None
    list_0 = [str_0]
    bool_0 = None
    var_0 = router_0.add(str_0, tuple_0, list_0, bool_0, bool_0)

    # Check if constructor with params is working
    str_0 = 'Response was bigger than content-length'
    tuple_0 = None
    list_0 = [str_0]
    bool_0 = None
    var_0 = router_0.add(str_0, tuple_0, list_0, bool_0, bool_0)

    # Check if constructor with params is working

# Generated at 2022-06-26 04:11:44.232774
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    str_0 = None
    tuple_0 = [str_0]
    str_1 = None
    var_0 = router_0.finalize(str_0, tuple_0, str_1)


# Generated at 2022-06-26 04:11:46.973914
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    tuple_0 = None
    router_0.finalize(tuple_0)

# Generated at 2022-06-26 04:11:56.011150
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    assert router_0
    # Test for Router.add()
    test_case_0()
    
    

# class BaseHTTPMessage:
#     def __init__(self, *args, **kwargs):
#         pass

#     def read(self, *args, **kwargs):
#         pass

#     def add_header(self, *args, **kwargs):
#         pass

#     def del_param(self, *args, **kwargs):
#         pass

#     def get_param(self, *args, **kwargs):
#         pass

#     def header_items(self, *args, **kwargs):
#         pass

#     def is_multipart(self, *args, **kwargs):
#         pass



# Generated at 2022-06-26 04:11:57.586923
# Unit test for constructor of class Router
def test_Router():
	pass


# Generated at 2022-06-26 04:12:00.359100
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    router_0.finalize(router_0, tuple(), dict())


# Generated at 2022-06-26 04:12:05.628672
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    str_0 = 'Response was bigger than content-length'
    tuple_0 = None
    list_0 = [str_0]
    bool_0 = None
    var_0 = router_0.add(str_0, tuple_0, list_0, bool_0, bool_0)



# Generated at 2022-06-26 04:12:07.344414
# Unit test for constructor of class Router
def test_Router():
    test_case_0()


# Generated at 2022-06-26 04:12:17.092794
# Unit test for constructor of class Router
def test_Router():
    # Create an instance of the class
    router_0 = Router()
    str_0 = 'Response was bigger than content-length'
    tuple_0 = None
    list_0 = [str_0]
    bool_0 = None
    var_0 = router_0.add(str_0, tuple_0, list_0, bool_0, bool_0)
    assert var_0
    str_1 = 'Content-Length'
    var_1 = router_0.add(str_0, tuple_0, list_0, bool_0, bool_0)
    assert var_1

# Generated at 2022-06-26 04:12:28.502380
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    str_0 = 'Response was bigger than content-length'
    tuple_0 = None
    list_0 = [str_0]
    bool_0 = None
    var_0 = router_0.add(str_0, tuple_0, list_0, bool_0, bool_0)
    var_0.finalize()


# Generated at 2022-06-26 04:12:37.342347
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    str_0 = 'test_Router'
    tuple_0 = None
    list_0 = [str_0]
    bool_0 = None
    var_0 = router_0.add(str_0, tuple_0, list_0, bool_0, bool_0)
    str_1 = 'test_Router'
    tuple_1 = None
    list_1 = [str_1]
    bool_1 = None
    var_1 = router_0.add(str_1, tuple_1, list_1, bool_1, bool_1)
    test_Router_0 = router_0.dynamic_routes
    test_Router_1 = router_0.routes_all
    test_Router_2 = router_0.routes_

# Generated at 2022-06-26 04:12:47.186662
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    assert isinstance(router_0, Router)

# Generated at 2022-06-26 04:12:48.120722
# Unit test for constructor of class Router
def test_Router():
    test_case_0()
    router_0 = Router()

test_Router()

# Generated at 2022-06-26 04:12:56.731330
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    var_0 = None
    str_0 = 'kKz-Y5J'
    var_1 = router_0.add(str_0, var_0, str_0, str_0, var_0)
    var_2 = router_0.finalize()


# Generated at 2022-06-26 04:13:05.193087
# Unit test for constructor of class Router
def test_Router():
    pass

    # def _get(
    #     self, path: str, method: str, host: Optional[str]
    # ) -> Tuple[Route, RouteHandler, Dict[str, Any]]:
    #     try:
    #         return self.resolve(
    #             path=path,
    #             method=method,
    #             extra={"host": host},
    #         )
    #     except RoutingNotFound as e:
    #         raise NotFound("Requested URL {} not found".format(e.path))
    #     except NoMethod as e:
    #         raise MethodNotSupported(
    #             "Method {} not allowed for URL {}".format(method, path),
    #             method=method,
    #             allowed_methods=e.allowed_methods,
    #         )


# Generated at 2022-06-26 04:13:12.998249
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router(name_index=dict())
    assert not router_0.name_index
    assert not router_0.host_index
    assert not router_0.routes
    assert not router_0.static_routes
    assert not router_0.dynamic_routes
    assert not router_0.regex_routes
    assert not router_0.routes_all
    assert not router_0.routes_static
    assert not router_0.routes_dynamic
    assert not router_0.routes_regex


# Generated at 2022-06-26 04:13:15.211934
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

# Tests for method add of class Router

# Generated at 2022-06-26 04:13:19.213735
# Unit test for constructor of class Router
def test_Router():
    try:
        test_case_0()
    except:
        return False
    else:
        return True


# Generated at 2022-06-26 04:13:26.802854
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    str_0 = '1Ie-1fM'
    str_1 = 'http://localhost'
    str_2 = 'OKFN'
    tuple_1 = router._get(str_0, str_1, str_2)
    assert tuple_1[0].ctx.ignore_body == False
    assert tuple_1[0].ctx.hosts == [None]
    assert tuple_1[0].ctx.stream == False
    assert tuple_1[0].ctx.unquote == False
    assert tuple_1[0].ctx.static == False
    assert tuple_1[0].path == '1Ie-1fM'
    assert tuple_1[0].methods == ['GET', 'HEAD']
    assert tuple_1[0].permissions is None

# Generated at 2022-06-26 04:13:30.942332
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        router_0 = Router(None)
        router_0.finalize()
        assert False
    except:
        assert True


# Generated at 2022-06-26 04:13:34.368187
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Setup mock
    router_0 = Router()
    var_0 = None
    str_0 = 'kKz-Y5J'
    var_1 = router_0.add(str_0, var_0, str_0, str_0, var_0)

    # Test
    router_0.finalize()

# Generated at 2022-06-26 04:13:54.470594
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

# Generated at 2022-06-26 04:14:01.347342
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    str_0 = '1hDfR76'
    str_1 = 'pBhq-dP'

# Generated at 2022-06-26 04:14:06.700652
# Unit test for method finalize of class Router
def test_Router_finalize():
    var_0 = None
    str_0 = 'kKz-Y5J'
    router_0 = Router()
    router_0.add(str_0, var_0, str_0, str_0, var_0)


# Generated at 2022-06-26 04:14:09.617601
# Unit test for constructor of class Router
def test_Router():
    test_case_0()


if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-26 04:14:21.897491
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    assert router_0.ctx == {}
    assert router_0.default_host == None
    assert router_0.hosts == []
    assert router_0.host_regex == '^$'
    assert router_0.host_names == {}
    assert router_0.default_method == 'GET'
    assert router_0.allowed_methods == ['GET', 'HEAD', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS']
    assert router_0.router_cache_size == 1024
    assert router_0.routes == []
    assert router_0.routes_all == router_0.routes
    assert router_0.routes_static == []
    assert router_0.routes_dynamic == {}

# Generated at 2022-06-26 04:14:23.567297
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

# Generated at 2022-06-26 04:14:32.105315
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    str_0 = 'Mk1-8Kc'
    str_1 = 'kKz-Y5J'
    var_0 = None
    router_0.add(str_0, var_0, str_0, str_0, var_0)
    router_0.add(str_1, var_0, str_0, str_0, var_0)
    try:
        router_0.finalize('', '')
    except:
        pass


# Generated at 2022-06-26 04:14:36.448410
# Unit test for constructor of class Router
def test_Router():
    # Constructor without parameter
    router_0 = Router()
    # Basic constructor
    router_0 = Router(method='GET', uri='/', handler=test_case_0)
    try:
        assert router_0.size == 0
        assert router_0.ctx is None
    except AssertionError:
        raise AssertionError("Router might not initialized correctly")


if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-26 04:14:40.806836
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    var_0 = None
    str_0 = 'kKz-Y5J'
    var_1 = None
    var_2 = router_0.add(str_0, var_0, str_0, str_0, var_0)
    router_0.finalize(var_1)


# Generated at 2022-06-26 04:14:41.744175
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()


# Generated at 2022-06-26 04:15:11.461201
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    var_0 = None
    str_0 = 'kKz-Y5J'
    var_1 = router_0.add(str_0, var_0, str_0, str_0, var_0)
    var_2 = router_0.routes_dynamic
    var_3 = router_0.routes_all
    var_4 = router_0.routes_static
    var_5 = router_0.routes_regex

# Generated at 2022-06-26 04:15:24.118636
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    var_0 = router_0.ctx
    str_0 = '_U=D*'
    var_1 = router_0.add(str_0, var_0, str_0, str_0, var_0)
    var_2 = router_0.traverse(str_0)
    var_3 = router_0.get(str_0, str_0, str_0)
    var_4 = router_0.find_route_by_view_name(str_0)
    var_5 = router_0.finalize()
    var_6 = router_0.routes_all
    var_7 = router_0.routes_static
    var_8 = router_0.routes_dynamic
    var_9 = router_0.rout

# Generated at 2022-06-26 04:15:26.882581
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()

    assert router_0

# Generated at 2022-06-26 04:15:28.456405
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Test case 0
    test_case_0()

# Generated at 2022-06-26 04:15:30.085757
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_case_0()


# Generated at 2022-06-26 04:15:31.637187
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()


# Generated at 2022-06-26 04:15:33.824126
# Unit test for constructor of class Router
def test_Router():
    print("======TEST CONSTRUCTOR======")
    router = Router()
    assert True # TODO: implement your test here


# Generated at 2022-06-26 04:15:39.971320
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    str_0 = 'S0a'
    router_1 = router_0.add(str_0, str_0, str_0, str_0, str_0)
    router_0.finalize()

# Generated at 2022-06-26 04:15:45.769986
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    var_0 = None
    str_0 = 'kKz-Y5J'
    tuple_0 = (var_0, str_0, str_0)
    str_1 = 'kKz-Y5J'
    var_1 = router_0.add(str_1, tuple_0, var_0, str_0, var_0)
    router_0.finalize((str_0, var_0))
