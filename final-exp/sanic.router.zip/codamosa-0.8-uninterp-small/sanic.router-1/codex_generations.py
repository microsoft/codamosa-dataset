

# Generated at 2022-06-26 04:05:41.432317
# Unit test for constructor of class Router
def test_Router():
    from sanic.app import Sanic
    from sanic.router import Router
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic_routing.exceptions import NotFound as RoutingNotFound

    # Test with Sanic()
    app = Sanic('test_Router')
    router = Router(app)
    router.add('/', 'GET', lambda *args, **kwargs: None)
    router.add('/view', 'GET', lambda *args, **kwargs: None)
    router.add('/view_func', 'GET', lambda *args, **kwargs: None)
    assert router.get('/')[1](Request('GET', '/')) == None
   

# Generated at 2022-06-26 04:05:44.203398
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_case_0()


# Generated at 2022-06-26 04:05:45.465530
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_case_0()

# Generated at 2022-06-26 04:05:47.352621
# Unit test for constructor of class Router
def test_Router():
    assert Router(True)


# Generated at 2022-06-26 04:05:54.727311
# Unit test for constructor of class Router
def test_Router():
    bool_0 = True
    router_0 = Router(bool_0)
    router_0.finalize()
    assert router_0.ctx.cache_lock is False
    router_0 = Router()
    router_0.finalize()
    assert router_0.ctx.cache_lock is True


# Generated at 2022-06-26 04:06:08.211864
# Unit test for method add of class Router
def test_Router_add():
    uri = 'str_0'
    methods = None

    handler = 'handler'
    host = None
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = None
    unquote = False
    static = False

    router_0 = Router(True)
    router_0.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)

    assert router_0.routes_all[0].path == '/'


# Generated at 2022-06-26 04:06:19.231039
# Unit test for constructor of class Router
def test_Router():
    router = Router(bool_0)

    router.add(
        uri="homey",
        methods=["GET"],
        handler="bran",
        host=None,
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version=None,
        name="paul",
        unquote=False,
        static=False,
    )

    router.find_route_by_view_name(
        view_name="view", name="name"
    )

    router.get(path="paul", method="GET", host="homey")

    router.finalize()

# Generated at 2022-06-26 04:06:20.451671
# Unit test for constructor of class Router
def test_Router():
    pass


# Generated at 2022-06-26 04:06:21.406453
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

# Generated at 2022-06-26 04:06:23.794391
# Unit test for constructor of class Router
def test_Router():

    bool_0 = False
    router_0 = Router(bool_0)
    try:
        var_0 = router_0.finalize()
    except SanicException as err:
        pass



# Generated at 2022-06-26 04:06:30.418877
# Unit test for constructor of class Router
def test_Router():
    teset_case_0()

    test_case_1()
    test_case_2()


# Generated at 2022-06-26 04:06:35.310337
# Unit test for method finalize of class Router
def test_Router_finalize():
    bool_0 = False
    router_0 = Router(bool_0)
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:06:46.229943
# Unit test for constructor of class Router
def test_Router():
    # Test cases:
    #   - Test the constructor of Router
    #   - Test the get method of Router
    #   - Test the find_route_by_view_name of Router
    #   - Test the finalize method of Router
    #   - Test the property routes_all of Router
    #   - Test the property routes_static of Router
    #   - Test the property routes_dynamic of Router
    #   - Test the property routes_regex of Router
    #   - Test the add method of Router
    #   - Test the add method of Router

    # Test the constructor of Router
    bool_0 = False
    router_0 = Router(bool_0)
    assert(
        router_0
        == Router(False, base_prefix="", router_cache_size=1024))

    # Test the get method of Router
   

# Generated at 2022-06-26 04:06:57.010085
# Unit test for constructor of class Router
def test_Router():
    bool_0 = True
    router_0 = Router(bool_0)
    str_0 = "This_is_a_test_string"
    list_0 = ["GET", "POST", "OPTIONS"]
    dict_0 = dict()
    dict_0["1"] = router_0
    def function_0(str_0 , list_0 ):
        return "This_is_a_test_string"
    int_0 = 1
    int_1 = 2
    router_0.add(str_0, list_0, function_0, int_0)
    handler_0 = router_0.find_route_by_view_name(int_1)
    router_0.finalize()

    test_case_0()

# Generated at 2022-06-26 04:06:59.494716
# Unit test for constructor of class Router
def test_Router():

    tests.append(test_case_0)

    for test in tests:
        test()


tests = []

# Generated at 2022-06-26 04:07:05.845000
# Unit test for constructor of class Router
def test_Router():
    bool_0 = False
    router_0 = Router(bool_0)
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:07:13.427110
# Unit test for constructor of class Router
def test_Router():
    bool_1 = False
    router_1 = Router(bool_1)
    router_1.routes_all
    router_1.routes_static
    router_1.routes_dynamic
    router_1.routes_regex
    router_1.__dict__
    router_1._get('/', 'GET', 'host')
    router_1.get('/', 'GET', 'host')
    router_1.find_route_by_view_name('view_name', 'name')
    router_1.add('uri', ['method'], 'handler', 'host', True, True, True, 'version', 'name', True, True)
    router_1.finalize()
    res = inspect.getmembers(router_1.__class__)

# Generated at 2022-06-26 04:07:15.028357
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_case_0()

# Generated at 2022-06-26 04:07:24.562153
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == []
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == []
    assert router.dynamic_routes_cache == {}
    assert router.static_route_cache == {}
    assert router.static_route_cache_sorted == []
    assert router.reverse_cache == {}
    assert router.reverse_cache_sorted == []
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-26 04:07:28.389802
# Unit test for constructor of class Router
def test_Router():
    result = test_case_0()
    print("Testcase 0:")
    print("Expected:")
    print()
    print("Received:")

# Generated at 2022-06-26 04:07:43.745553
# Unit test for method add of class Router
def test_Router_add():
    bool_0 = False
    router_0 = Router(bool_0)
    var_0 = router_0.ctx
    var_0 = router_0.finalize()
    test_Router_add.counter += 1
    if test_Router_add.counter == 10:
        router_0.add("/", ["GET"], lambda x: None)
    else:
        router_0.add("/", ["None"], lambda x: None)

test_Router_add.counter = 0

# Generated at 2022-06-26 04:07:47.316132
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router(False)
    assert isinstance(router_0,Router)



# Generated at 2022-06-26 04:07:50.617253
# Unit test for constructor of class Router
def test_Router():
    bool_1 = False
    router_1 = Router(bool_1)
    var_1 = router_1.finalize()



# Generated at 2022-06-26 04:07:54.585091
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router(False)
    assert not router_0.strict_slashes
    assert not router_0.keep_trailing_slash


# Generated at 2022-06-26 04:08:08.060588
# Unit test for method add of class Router
def test_Router_add():
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint
    from sanic.request import Request
    
    app = Sanic()
    test_Router_add_0()
    test_Router_add_1()
    test_Router_add_2()
    test_Router_add_3()

    @app.route("/", methods=["GET", "HEAD", "POST", "PUT", "PATCH", "DELETE"])
    async def handler(request: Request) -> None:
        return

    name = "view"
    uri = "/view"
    router_0 = app.router.add(uri=uri, methods=[], handler=handler, name=name)

    uri = "/"
    request_0 = Request("GET", uri, [], b"")


# Generated at 2022-06-26 04:08:11.688938
# Unit test for constructor of class Router
def test_Router():
    bool_0 = False
    router_0 = Router(bool_0)
    var_0 = router_0.finalize()



# Generated at 2022-06-26 04:08:13.167606
# Unit test for constructor of class Router
def test_Router():
    assert (Router(False))



# Generated at 2022-06-26 04:08:15.292210
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Test 0
    test_case_0()


test_Router_finalize()

# Generated at 2022-06-26 04:08:16.861695
# Unit test for constructor of class Router
def test_Router():
    try:
        test_case_0()
        assert True
    except AssertionError as e:
        assert False

# Generated at 2022-06-26 04:08:20.118366
# Unit test for method finalize of class Router
def test_Router_finalize():
    bool_0 = False
    router_0 = Router(bool_0)
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:08:30.327421
# Unit test for method finalize of class Router
def test_Router_finalize():
    """Only one test."""
    router = Router(False)
    router.finalize()

# Generated at 2022-06-26 04:08:39.184306
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Test for finalize
    bool_0 = True
    router_0 = Router(bool_0)
    var_0 = router_0.finalize(None, None)
    # AssertionError * AssertionError: None != <sanic.router.Router object at 0x7f7d98beb6a0>
    # Test for finalize
    bool_0 = True
    router_0 = Router(bool_0)
    var_0 = router_0.finalize()



# Generated at 2022-06-26 04:08:44.249119
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    Test for method  Router.finalize
    """
    var_0 = True
    router_0 = Router(var_0)
    var_1 = router_0.finalize()


# Generated at 2022-06-26 04:08:51.517777
# Unit test for constructor of class Router
def test_Router():
    bool_0 = False
    router_0 = Router(bool_0)
    assert router_0.ctx == bool_0
    assert router_0.dynamic_routes == {}
    assert router_0.name_index == {}
    assert router_0.params == {}
    assert router_0.regex_routes == []
    assert router_0.routes == {}
    assert router_0.static_routes == []
    assert router_0.static_prefixes == []



# Generated at 2022-06-26 04:09:02.047427
# Unit test for constructor of class Router
def test_Router():
    var_0 = Router(False)
    assert var_0.ctx.app == None
    assert len(var_0.dynamic_routes) == 0
    assert len(var_0.static_routes) == 0
    assert len(var_0.regex_routes) == 0
    assert len(var_0.name_index) == 0
    assert len(var_0.url_map) == 0
    assert len(var_0.methods_map) == 0
    assert len(var_0.hosts_map) == 0
    assert len(var_0.regex_hosts_map) == 0
    assert var_0._routes == None
    assert var_0.routes == {}
    assert var_0.routes_all == {}
    assert var_0

# Generated at 2022-06-26 04:09:03.509032
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

# Generated at 2022-06-26 04:09:06.208913
# Unit test for constructor of class Router
def test_Router():
    router = Router(True)
    assert isinstance(router, Router)


# Generated at 2022-06-26 04:09:09.607107
# Unit test for constructor of class Router
def test_Router():
    bool_0 = False
    router_0 = Router(bool_0)
    var_0 = router_0.finalize()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 04:09:14.088622
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        test_case_0()
    except SanicException as e:
        assert True
    else:
        assert False, "No exception thrown"


# Generated at 2022-06-26 04:09:16.882425
# Unit test for constructor of class Router
def test_Router():
    bool_0 = False
    router_0 = Router(bool_0)
    var_0 = router_0.finalize()
    if router_0 is None:
        raise Exception("router is None")


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 04:09:37.529201
# Unit test for constructor of class Router
def test_Router():
    bool_0 = False
    router_0 = Router(bool_0)
    int_0 = router_0.ROUTE_CACHE_SIZE


# Generated at 2022-06-26 04:09:44.098324
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    router_1 = Router(False)
    assert router_0.routes_regex == {} # Make sure the default value is {}
    assert router_0.routes_dynamic == {} # Make sure the default value is {}
    assert router_0.routes_static == {}
    assert router_1.routes_regex == {}
    assert router_1.routes_dynamic == {}
    assert router_1.routes_static == {}

# Generated at 2022-06-26 04:09:44.736572
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_case_0()



# Generated at 2022-06-26 04:09:46.154717
# Unit test for method finalize of class Router
def test_Router_finalize():
    bool_0 = False
    router_0 = Router(bool_0)
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:09:50.035908
# Unit test for method finalize of class Router
def test_Router_finalize():
    bool_0 = False
    router_0 = Router(bool_0)
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:09:51.696189
# Unit test for method finalize of class Router
def test_Router_finalize():
    assert test_case_0() == None


# Generated at 2022-06-26 04:09:54.448480
# Unit test for constructor of class Router
def test_Router():
    bool_1 = False
    router_1 = Router(bool_1)
    var_1 = router_1.finalize()


# Generated at 2022-06-26 04:10:00.901071
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router(False)
    assert router_0.ctx is None
    assert router_0.routes is None
    assert router_0.name_index is None
    assert router_0.regex_routes is None
    assert router_0.dynamic_routes is None
    assert router_0.static_routes is None
    assert router_0.route_cache is dict()


# Generated at 2022-06-26 04:10:02.749558
# Unit test for method finalize of class Router
def test_Router_finalize():
    pass


# Generated at 2022-06-26 04:10:06.626391
# Unit test for method finalize of class Router
def test_Router_finalize():
    bool_0 = False
    router_0 = Router(bool_0)
    router_0.finalize()


# Generated at 2022-06-26 04:10:41.919794
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router(False)
    router_0.finalize()


# Generated at 2022-06-26 04:10:43.958343
# Unit test for constructor of class Router
def test_Router():
    bool_1 = False
    router_1 = Router(bool_1)
    assert router_1 is not None


# Generated at 2022-06-26 04:10:48.147000
# Unit test for method finalize of class Router
def test_Router_finalize():
    # set-up
    bool_0 = False
    router_0 = Router(bool_0)
    # test
    test_case_0()


# Generated at 2022-06-26 04:10:50.226618
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Case 0
    test_case_0()


# Generated at 2022-06-26 04:10:54.032499
# Unit test for constructor of class Router
def test_Router():
    try:
        test_case_0()
    except (AssertionError, TypeError, ValueError):
        return False
    return True


if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-26 04:10:59.205147
# Unit test for method finalize of class Router
def test_Router_finalize():
    bool_0 = False
    router_0 = Router(bool_0)
    var_0 = router_0.finalize()
    assert isinstance(var_0, bool) == True



# Generated at 2022-06-26 04:11:03.272518
# Unit test for constructor of class Router
def test_Router():
    bool_1 = False
    router_1 = Router(bool_1)
    bool_2 = True
    router_2 = Router(bool_2)


# Generated at 2022-06-26 04:11:09.349837
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    router_0.get("https://github.com/huge-success/sanic")
    router_0.add("https://github.com/huge-success/sanic")
    router_0.add_route("https://github.com/huge-success/sanic")
    router_0.find_route_by_view_name("https://github.com/huge-success/sanic")
    router_0.routes_all
    router_0.routes_static
    router_0.routes_dynamic
    router_0.routes_regex
    router_0._get("https://github.com/huge-success/sanic", "https://github.com/huge-success/sanic", "https://github.com/huge-success/sanic")
    router

# Generated at 2022-06-26 04:11:10.878648
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_case_0()



# Generated at 2022-06-26 04:11:19.006510
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router(False)
    router.add("/test", ["GET"], lambda x: x, name="test")
    router.finalize()
    assert router.get("/test", "GET")[0].handler
    assert router.get("/test", "GET")[0].name == "test"

    router = Router(False)
    router.add("/test", ["GET"], lambda x: x, name="test")
    router.add("/test", ["GET"], lambda x: x, name="test_2")
    router.finalize()
    assert router.get("/test", "GET")[0].handler
    try:
        router.get("/test", "GET")[0].name
        raise AssertionError()
    except SanicException:
        pass

    router = Router(False)

# Generated at 2022-06-26 04:12:24.152015
# Unit test for constructor of class Router
def test_Router():
    bool_0 = True
    router_0 = Router(bool_0)
    bool_1 = False
    router_1 = Router(bool_1)



# Generated at 2022-06-26 04:12:26.099241
# Unit test for method finalize of class Router
def test_Router_finalize():
    bool_0 = False
    router_0 = Router(bool_0)
    var_0 = router_0.finalize()
    assert True


# Generated at 2022-06-26 04:12:34.225967
# Unit test for constructor of class Router
def test_Router():
    # Default constructor for class
    router_obj = Router(True)
    assert router_obj is not None
    assert (router_obj.trace_handler is None)

    router_obj = Router(False)
    assert router_obj is not None
    assert (router_obj.trace_handler is not None)

    bool_0 = True
    router_0 = Router(bool_0)
    assert bool_0 is True
    assert router_0 is not None

    bool_0 = False
    router_0 = Router(bool_0)
    assert bool_0 is False
    assert router_0 is not None


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 04:12:37.410230
# Unit test for method finalize of class Router
def test_Router_finalize():
    bool_0 = False
    router_0 = Router(bool_0)
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:12:45.809178
# Unit test for constructor of class Router
def test_Router():
    bool_0 = False
    router_0 = Router(bool_0)
    router_0.finalize()
    bool_1 = (router_0.dynamic_routes == {})
    assert bool_1
    bool_1 = (router_0.static_routes == {})
    assert bool_1
    bool_1 = (router_0.regex_routes == [])
    assert bool_1
test_case_0()
test_Router()
print('+--------+')
print('|  Done  |')
print('+--------+')

# Generated at 2022-06-26 04:12:49.030137
# Unit test for constructor of class Router
def test_Router():
    my_app = Sanic()
    router_1 = Router(my_app)
    route_1 = router_1.add('/post/<id:int>', methods=['GET'])


# Generated at 2022-06-26 04:12:53.212595
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router(False)
    var_0 = router_0.finalize()



# Generated at 2022-06-26 04:12:54.442517
# Unit test for constructor of class Router
def test_Router():
    bool_0 = False
    router_0 = Router(bool_0)
    assert type(router_0) == Router


# Generated at 2022-06-26 04:13:04.548596
# Unit test for constructor of class Router

# Generated at 2022-06-26 04:13:07.604595
# Unit test for constructor of class Router
def test_Router():
    bool_0 = True
    router_0 = Router(bool_0)
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:15:11.885161
# Unit test for constructor of class Router
def test_Router():
    assert Router(False) != None


# Generated at 2022-06-26 04:15:15.799620
# Unit test for method finalize of class Router
def test_Router_finalize():
    bool_0 = False
    router_0 = Router(bool_0)
    var_0 = router_0.finalize()
    assert var_0 is True


# Generated at 2022-06-26 04:15:19.366727
# Unit test for method finalize of class Router
def test_Router_finalize():
    bool_0 = False
    router_0 = Router(bool_0)
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:15:24.810065
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()

    with pytest.raises(SanicException) as error:
        router.add("/", "GET", lambda request: None, name="foobar")
        router.add("/<var_0>", "GET", lambda request: None, name="baz__quux")
        router.finalize()

    assert str(error.value) == repr("Invalid route: /<var_0> (baz__quux). Parameter names cannot use '__'.")

# Generated at 2022-06-26 04:15:28.313856
# Unit test for method finalize of class Router
def test_Router_finalize():
    bool_0 = True
    router_0 = Router(bool_0)
    var_0 = router_0.finalize()
