

# Generated at 2022-06-26 04:05:53.122295
# Unit test for method finalize of class Router
def test_Router_finalize():
    int_0 = -1393817378
    router_0 = Router(int_0)


# Generated at 2022-06-26 04:05:59.144774
# Unit test for constructor of class Router
def test_Router():
    # test 0
    try:
        test_case_0()
    except SanicException:
        # print("test 0 failed!")
        pass
    else:
        print("test 0 failed!")
    # test 1
    try:
        test_case_1()
    except NotFound:
        # print("test 1 failed!")
        pass
    else:
        print("test 1 failed!")
    # test 2
    try:
        test_case_2()
    except MethodNotSupported:
        # print("test 2 failed!")
        pass
    else:
        print("test 2 failed!")
    # test 3
    try:
        test_case_3()
    except NotFound:
        # print("test 3 failed!")
        pass
    else:
        print("test 3 failed!")
   

# Generated at 2022-06-26 04:06:03.101606
# Unit test for constructor of class Router
def test_Router():
    int_0 = 1710
    router_0 = Router(int_0)
    test_case_0()

test_Router()

# Generated at 2022-06-26 04:06:06.492204
# Unit test for method finalize of class Router
def test_Router_finalize():
    int_0 = 2
    router_0 = Router(int_0)
    router_0.finalize(1, 2, 3)


# Generated at 2022-06-26 04:06:07.898877
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

# Generated at 2022-06-26 04:06:10.908058
# Unit test for constructor of class Router
def test_Router():
    # Test with two arguments.
    router_0 = Router(0, False)


# Generated at 2022-06-26 04:06:21.128392
# Unit test for method finalize of class Router
def test_Router_finalize():
    int_0 = -682
    router_0 = Router(int_0)

    # Test with known exception
    try:
        router_0.finalize(router_0)
        assert False
    except SanicException:
        assert True

    # Test with normal operation
    try:
        router_0.finalize(router_0)
        assert True
    except SanicException:
        assert False


# Generated at 2022-06-26 04:06:28.718753
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Test for the condition where route.labels does not have any elements
    # with label.startswith("__")
    # and label not in ALLOWED_LABELS
    router_1 = Router(5)
    router_1.dynamic_routes = {'a': Route('b', 'c', 'd'), 'e': Route('f', 'g', 'h')}
    Route.labels = {'a': ['i'], 'e': ['j']}
    Route.__str__ = lambda self: ''
    router_1.finalize()
    assert len(router_1.routes) == 0

    # Test for the condition where route.labels has an element
    # with label.startswith("__")
    # and label not in ALLOWED_LABELS

# Generated at 2022-06-26 04:06:31.079061
# Unit test for constructor of class Router
def test_Router():
    try:
        test_case_0()
        print("Test case 0 successful!")
    except Exception as e:
        print("Test case 0 failed!")



# Generated at 2022-06-26 04:06:42.477266
# Unit test for method finalize of class Router
def test_Router_finalize():
    int_0 = -1798
    dict_0 = dict()
    dict_1 = dict()
    dict_1['str_0'] = 7329
    dict_0[696146] = dict_1
    dict_1 = dict()
    dict_1['str_0'] = 8069
    dict_0[561142] = dict_1
    dict_1 = dict()
    dict_1['str_0'] = -4824
    dict_0[128628] = dict_1
    int_1 = -2513
    dict_1 = dict()
    dict_1['str_0'] = -925
    dict_0[-671826] = dict_1
    dict_1 = dict()
    dict_1['str_0'] = -2376
    dict_0[842551]

# Generated at 2022-06-26 04:06:56.003830
# Unit test for constructor of class Router
def test_Router():
    int_1 = -1500
    assert isinstance(router_0, Router), "Error: cannot create instance of class Router"
    try:
        router_0.get
    except NotFound as e:
        # We want to catch NotFound, not AttributeError
        assert True
    assert router_0.DEFAULT_METHOD == "GET"
    assert router_0.ALLOWED_METHODS == HTTP_METHODS
    assert router_0.ctx.app_route_id == int_1
    assert router_0.ctx.app is None
    assert router_0.ctx.router == router_0
    assert router_0.ctx.id == 1


# Generated at 2022-06-26 04:06:57.391745
# Unit test for constructor of class Router
def test_Router():
    test_case_0()


# Generated at 2022-06-26 04:07:03.685754
# Unit test for method add of class Router
def test_Router_add():

    # Create a router object
    router = Router()

    # Create a route and add to router
    router.add(uri='test', methods=['GET', 'POST'], handler='handler')
    assert len(router.routes) == 2

    # Create a route with a host
    router.add(uri='test', methods=['GET', 'POST'], handler='handler', host='host')
    assert len(router.routes) == 4

    # Create a route with a host and version
    router.add(uri='test', methods=['GET', 'POST'], handler='handler', host='host', version='1.0.0')
    assert len(router.routes) == 6


# Generated at 2022-06-26 04:07:06.266475
# Unit test for constructor of class Router
def test_Router():
    router = Router(1)
    if(router.max_cache_size == 1):
        print("Router Constructor test: passed")



# Generated at 2022-06-26 04:07:12.462453
# Unit test for constructor of class Router
def test_Router():
    router = Router(ROUTER_CACHE_SIZE)
    assert isinstance(router, Router)
    assert router.dynamic_routes == {}
    assert router.name_index == {}
    assert router.routes == []
    assert router.regex_routes == []
    assert router.static_routes == {}


# Generated at 2022-06-26 04:07:17.534710
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router != None

if __name__ == "__main__":
    args = list(sys.argv)
    sys.exit(pytest.main(args))

# Generated at 2022-06-26 04:07:19.146539
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

# Generated at 2022-06-26 04:07:22.150121
# Unit test for method finalize of class Router
def test_Router_finalize():
    for i in range(10):
        router_4 = Router(i)
        router_4.finalize()


# Generated at 2022-06-26 04:07:28.464643
# Unit test for constructor of class Router
def test_Router():
    int_0 = -1875
    bool_0 = False
    str_0 = ""
    assert Router(int_0)
    assert Router(int_0, bool_0)
    assert Router(int_0, bool_0, str_0)


# Generated at 2022-06-26 04:07:37.293657
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    print('Router(): ')
    assert router.default_method == "GET"
    assert router.allowed_methods == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_regex == {}
    assert router.routes_dynamic == {}
    assert router.host_routes_regex == {}
    assert router.host_routes_static == {}
    assert router.host_routes_dynamic == {}
    assert router.name_index == {}
    assert router.ctx == -1
    print('Router is OK\n')


# Generated at 2022-06-26 04:07:43.520700
# Unit test for method finalize of class Router
def test_Router_finalize():

    router_0 = Router()
    router_0.finalize()


# Generated at 2022-06-26 04:07:49.566984
# Unit test for method add of class Router
def test_Router_add():
    router_0 = Router()
    for method in HTTP_METHODS:
        assert router_0.add("/",method,lambda request: 'Sanic') == router_0.dynamic_routes[0]



# Generated at 2022-06-26 04:07:51.761594
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)



# Generated at 2022-06-26 04:07:59.387116
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    Method finalize of class Router.
    """
    router_0 = Router()
    try:
        router_0.finalize()
        assert False
    except SanicException:
        assert True

    route_0 = Route(
        uri = '/test_Router_finalize/test_Router_finalize',
        host = '1.1.1.1',
        strict_slashes = True,
        unquote = False,
        name = 'test_Router_finalize/test_Router_finalize',
        handler = staticmethod(lambda request: HTTPResponse()),
        methods = set(),
        )

    router_0.register(route_0)


# Generated at 2022-06-26 04:08:06.492678
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.finalize("test_sanic.app.app", "test_sanic.app", "app")
    # assert router.ctx.app == "test_sanic.app"
    # assert router.ctx.name == "app"
    # assert router.ctx.uri_prefix == "test_sanic.app.app"


# Generated at 2022-06-26 04:08:15.553818
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router.routes, dict)
    assert isinstance(router.static_routes, list)
    assert isinstance(router.dynamic_routes, dict)
    assert isinstance(router.regex_routes, list)
    assert isinstance(router.name_index, dict)
    assert isinstance(router.host_index, dict)



# Generated at 2022-06-26 04:08:18.365099
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Create an instance of class Router
    router_0 = Router()

    # Call method finalize on the instance of class Router
    router_0.finalize()

    # Assert that finalize returns None as expected
    assert router_0.finalize() is None



# Generated at 2022-06-26 04:08:20.429309
# Unit test for method finalize of class Router
def test_Router_finalize():
    my_router = Router()
    assert test_Router_finalize

# Generated at 2022-06-26 04:08:25.960241
# Unit test for constructor of class Router
def test_Router():
    try:
        router_0 = Router()
        assert(type(router_0) == Router)
        print("Constructor test passed successfully")
    except AssertionError as e:
        print("Constructor test failed")


# Generated at 2022-06-26 04:08:27.028715
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()


# Generated at 2022-06-26 04:08:35.277106
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    assert router_0.finalize() is None


# Generated at 2022-06-26 04:08:40.831903
# Unit test for method finalize of class Router
def test_Router_finalize():
    context = {}
    logger = Mock()
    router = Router(context, logger)
    route = Mock()
    routes = [route]
    router.routes_all = routes
    router.routes_regex = {}
    router.routes_dynamic = {}
    router.routes_static = {}
    router.name_index = {}
    router.finalize()
    route.finalize.assert_called_with(router)


# Generated at 2022-06-26 04:08:44.249405
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    with pytest.raises(SanicException):
        router_0.finalize()



# Generated at 2022-06-26 04:08:46.076904
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert id(router) == id(router)
    assert isinstance(router, Router)
    # assert repr(router) == repr(router)


# Generated at 2022-06-26 04:08:49.182538
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    router_0.add("/test/{testOne}/{testTwo}", ["GET"], lambda x: x)

    router_0.finalize()

# Generated at 2022-06-26 04:09:00.981694
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    assert type(router_0) is Router
    assert router_0.routes == {}
    assert router_0.routes_all == {}
    assert router_0.routes_static == {}
    assert router_0.routes_dynamic == {}
    assert router_0.routes_regex == {}
    assert router_0.static_routes_base == {}
    assert router_0.static_routes_sorted == {}
    assert router_0.dynamic_routes_sorted == {}
    assert router_0.regex_routes_sorted == {}
    assert router_0.name_index == {}
    assert router_0.name_cache == {}


# Generated at 2022-06-26 04:09:04.003100
# Unit test for constructor of class Router
def test_Router():
    try:
        test_case_0()
        print("\033[1;32;40m[PASS]\033[0m test case 0 of class Router.")
    except:
        print("\033[1;31;40m[FAIL]\033[0m test case 0 of class Router.")
        raise

if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-26 04:09:13.752365
# Unit test for constructor of class Router
def test_Router():
    # Test for lines 13-15
    router_0 = Router()

    # Test for lines 18-20
    assert router_0.get_all_routes() == []

    # Test for lines 23-25
    assert router_0.get_all_routes() == router_0.routes_all
    # Test for lines 28-30
    assert router_0.get_all_routes() == router_0.routes

    # Test for lines 33-35
    assert router_0.get_all_routes() == router_0.routes_all
    # Test for lines 38-40
    assert router_0.get_all_routes() == router_0.routes

    # Test for lines 43-45

# Generated at 2022-06-26 04:09:22.186669
# Unit test for constructor of class Router
def test_Router():
    router_1 = Router()
    assert isinstance(router_1, Router)
    assert len(router_1.routes) == 0
    assert len(router_1.routes_all) == 0
    assert len(router_1.routes_static) == 0
    assert len(router_1.routes_dynamic) == 0
    assert len(router_1.routes_regex) == 0
    assert isinstance(router_1.name_index, dict)
    with pytest.raises(AssertionError):
        router_1.add('/', 'GET', None)


# Generated at 2022-06-26 04:09:28.091868
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == []
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.auto_endpoint == {}



# Generated at 2022-06-26 04:09:43.314545
# Unit test for constructor of class Router
def test_Router():
    router = Router()

    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == []

    assert router.dynamic_routes is not None
    assert router.static_routes is not None
    assert router.regex_routes is not None
    assert router.name_index is not None
    assert router.regex_index is not None



# Generated at 2022-06-26 04:09:44.690918
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_case_0()


# Generated at 2022-06-26 04:09:46.174446
# Unit test for constructor of class Router
def test_Router():
  return True


# Generated at 2022-06-26 04:09:46.978832
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    router_0.finalize()


# Generated at 2022-06-26 04:09:50.399929
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    try:
        router_0.finalize()
    except:
        assert False
    assert True


# Generated at 2022-06-26 04:09:53.148888
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    name = "test_case"
    res = router.finalize(name)
    assert router.ctx.name == name



# Generated at 2022-06-26 04:09:55.868576
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    assert isinstance(router_0, Router)


# Generated at 2022-06-26 04:09:57.532362
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    assert(isinstance(router_0, Router))

# Generated at 2022-06-26 04:09:58.623094
# Unit test for constructor of class Router
def test_Router():
    router_0 = test_case_0()

# Generated at 2022-06-26 04:10:00.689761
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_1 = Router()
    router_1.finalize()
    assert isinstance(router_1, Router)



# Generated at 2022-06-26 04:10:13.430130
# Unit test for constructor of class Router
def test_Router():
    assert type(Router()) == Router, "Cannot create a Router object!"



# Generated at 2022-06-26 04:10:18.259818
# Unit test for constructor of class Router
def test_Router():
    router_1 = Router()
    assert router_1
    try:
        router_1.finalize()
    except AttributeError:
        assert False


# Generated at 2022-06-26 04:10:23.204062
# Unit test for method add of class Router
def test_Router_add():
    router_1 = Router()
    router_1.add('/foo', ['GET'], lambda x: x)
    assert router_1.routes_all['/foo'].path == '/foo'
    assert router_1.routes_all['/foo'].methods == {'GET'}


# Generated at 2022-06-26 04:10:25.736416
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.finalize


# Generated at 2022-06-26 04:10:35.886624
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    assert router_0.routes == {}
    assert router_0.dynamic_routes == {}
    assert router_0.static_routes == {}
    assert router_0.regex_routes == {}
    assert router_0.ctx == {}
    assert router_0.name_index == {}
    assert router_0.dynamic_routes_keys == {}
    assert router_0.dynamic_routes_keys_map == {}
    assert router_0.route_index == {}
    assert router_0.cancel_last_rule_value == False
    assert router_0.cancel_next_rule_value == False
    assert router_0.static_routes_keys == {}
    assert router_0.static_routes_keys_map

# Generated at 2022-06-26 04:10:37.999790
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_Router_finalize_0()
    return 0


# Generated at 2022-06-26 04:10:39.508948
# Unit test for constructor of class Router
def test_Router():
    router_1 = Router()


# Generated at 2022-06-26 04:10:46.336851
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()

    assert router_0
    assert router_0.get_info() == ("Router", {})
    assert router_0.ctx.static_server is None
    assert router_0.ctx.app
    assert router_0.ctx.app == router_0.ctx.static_server
    assert not router_0.routes
    assert router_0.routes_regex
    assert router_0.routes_all
    assert router_0.routes_static
    assert router_0.routes_dynamic


# Generated at 2022-06-26 04:10:48.523588
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Generate an instance of class Router
    router_0 = Router()


# Generated at 2022-06-26 04:10:57.762131
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    try:
        router.add("/", ["GET"], "lambda x:x")
        router.add("/", ["GET"], "lambda x:x", name="post")
    except Exception as e:
        print(e)
        assert False, "Should not throw exception"

    try:
        router.add("/", ["GET"], "lambda x:x", name="__test__")
        router.add("/", ["GET"], "lambda x:x", name="__file_uri__")
        assert False, "Should throw exception as parameter name cannot use '__'."
    except Exception as e:
        print(e)
        assert True


# Generated at 2022-06-26 04:11:06.502310
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

# Generated at 2022-06-26 04:11:17.757214
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Test 0
    test_case_0()
    # Test 1
    router_1 = Router()
    router_1.add("/user/<name>", [], lambda a: a)
    assert router_1.finalize()
    # Test 2
    router_2 = Router()
    router_2.add("/user/<name>", [], lambda a: a, name="test")
    assert router_2.finalize()
    # Test 3
    router_3 = Router()
    router_3.add("/user/<name>", [], lambda a: a, name="test")
    assert router_3.finalize()


# Generated at 2022-06-26 04:11:19.348712
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()

# Generated at 2022-06-26 04:11:22.124042
# Unit test for constructor of class Router
def test_Router():
    router = Router()

    assert router.routes == {}
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.static_index == {}
    assert router.name_index == {}
    assert router.ctx == {}

    router.finalize()
    assert router.ctx == {}



# Generated at 2022-06-26 04:11:31.034226
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.app import Sanic

    router_0 = Router()
    app_0 = Sanic("sanic_0")
    app_0.router.ctx.app = app_0

    # call method
    router_0.finalize(app_0)

    assert isinstance(router_0.routes, dict)
    assert len(router_0.routes) == 0

    assert isinstance(router_0.static_routes, dict)
    assert len(router_0.static_routes) == 0

    assert isinstance(router_0.dynamic_routes, dict)
    assert len(router_0.dynamic_routes) == 0

    assert isinstance(router_0.regex_routes, dict)

# Generated at 2022-06-26 04:11:31.574923
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

# Generated at 2022-06-26 04:11:41.953830
# Unit test for method add of class Router
def test_Router_add():
    router_0 = Router()
    method_0 = None
    uri_0 = "test"
    methods_0 = []
    handler_0 = ""
    strict_slashes_0 = None
    stream_0 = None
    ignore_body_0 = None
    version_0 = None
    name_0 = None
    unquote_0 = None
    static_0 = None
    host_0 = None
    route_0 = router_0.add(uri_0, methods_0, handler_0, host_0, strict_slashes_0, stream_0, ignore_body_0, version_0, name_0, unquote_0, static_0)
    assert isinstance(route_0, List)
    method_1 = "GET"
    uri_1 = "test"

# Generated at 2022-06-26 04:11:48.777799
# Unit test for constructor of class Router
def test_Router():
    assert issubclass(Router, BaseRouter)
    router = Router()
    assert router.routes == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.ctx == router


# Generated at 2022-06-26 04:11:51.107687
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()

    # call method finalize
    router_0.finalize()



# Generated at 2022-06-26 04:11:52.456508
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

# Generated at 2022-06-26 04:12:05.472039
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.routes_static == {}

# Generated at 2022-06-26 04:12:09.667345
# Unit test for constructor of class Router
def test_Router():
    print('Test constructor of class Router')
    router_0 = Router()
    assert isinstance(router_0, Router)


# Generated at 2022-06-26 04:12:18.560214
# Unit test for method add of class Router
def test_Router_add():
    import unittest
    class TestRouterAdd(unittest.TestCase):
        @classmethod
        def setUpClass(cls):
            cls.router_0 = Router()
            cls.uri_0 = "test_add"
            cls.methods_0 = ["GET", "POST"]
            cls.handler_0 = None
            cls.host_0 = None
            cls.strict_slashes_0 = False
            cls.stream_0 = False
            cls.ignore_body_0 = False
            cls.version_0 = None
            cls.name_0 = None
            cls.unquote_0 = False
            cls.static_0 = False
        def test_Router_add_0(self):
            ret_0 = self.router_

# Generated at 2022-06-26 04:12:27.712363
# Unit test for method finalize of class Router
def test_Router_finalize():
    import os
    import sys
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from test_app import app

    router = Router()
    for route in app.router.routes_all:
        route.ctx.stream = False
        router.add(
            route.uri,
            route.methods,
            route.handler,
            route.ctx.hosts,
            route.ctx.strict,
            route.ctx.stream,
            route.ctx.ignore_body,
            route.ctx.version,
            route.ctx.name,
            route.ctx.unquote,
            route.ctx.static,
        )
    router.finalize(app)



# Generated at 2022-06-26 04:12:39.954586
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_1 = Router()
    router_1.add("/", ["GET"], asyncio.coroutine(lambda request: "OK"))
    router_1.add("/user", ["GET"], asyncio.coroutine(lambda request: "OK"))
    router_1.add("/user", ["POST"], asyncio.coroutine(lambda request: "OK"))
    router_1.add("/user/<name>", ["GET"], asyncio.coroutine(lambda request: "OK"))
    router_1.add("/rest/db/<mytable>", ["GET"], asyncio.coroutine(lambda request: "OK"))
    router_1.finalize()
    router_1.find_route_by_view_name("test")
    router_1.find_route_by_view_name("test", name=None)
    router

# Generated at 2022-06-26 04:12:48.413483
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    assert isinstance(router_0.routes, dict)
    assert isinstance(router_0.static_routes, dict)
    assert isinstance(router_0.name_index, dict)
    assert isinstance(router_0.regex_routes, list)
    assert isinstance(router_0.dynamic_routes, dict)
    assert isinstance(router_0.routes_all, dict)
    assert isinstance(router_0.routes_static, dict)
    assert isinstance(router_0.routes_dynamic, dict)
    assert isinstance(router_0.routes_regex, list)



# Generated at 2022-06-26 04:12:53.375454
# Unit test for constructor of class Router
def test_Router():
    assert issubclass(Router, BaseRouter)
    try:
        router_0 = Router()
    except Exception as e:
        assert False, e

# Generated at 2022-06-26 04:12:55.813082
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    assert router_0


# Generated at 2022-06-26 04:12:59.070294
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    try:
        router_0.finalize()
    except Exception as exception:
        print(exception)


# Generated at 2022-06-26 04:13:00.993319
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    router_0.finalize()
    # Default assert
    assert True


# Generated at 2022-06-26 04:13:21.314282
# Unit test for constructor of class Router
def test_Router():
    router_1 = Router()
    assert router_1 is not None


# Generated at 2022-06-26 04:13:22.045178
# Unit test for constructor of class Router
def test_Router():
    router_1 = Router()

# Generated at 2022-06-26 04:13:25.053823
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None
    assert isinstance(router, Router)


# Generated at 2022-06-26 04:13:27.663158
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    assert router_0


# Generated at 2022-06-26 04:13:29.863215
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert(type(router) == Router)



# Generated at 2022-06-26 04:13:33.765234
# Unit test for method finalize of class Router
def test_Router_finalize():

    # Test 0
    router = Router()
    try:
        router.finalize()
    except NotImplementedError:
        pass  # Test successful
    else:
        assert False  # Test failed



# Generated at 2022-06-26 04:13:44.513506
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    routes_0_all = router_0.routes_all
    routes_0_static = router_0.routes_static
    routes_0_dynamic = router_0.routes_dynamic
    routes_0_regex = router_0.routes_regex
    if router_0 and routes_0_all and routes_0_static and routes_0_dynamic and routes_0_regex:
        pass
    else:
        assert True


# Generated at 2022-06-26 04:13:51.552890
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.ctx == None
    assert router.dynamic_routes == {}
    assert router.name_index == {}
    assert router.regex_routes == {}
    assert router.routes == {}
    assert router.static_routes == {}


# Generated at 2022-06-26 04:13:53.009941
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()  # type: ignore

# Generated at 2022-06-26 04:13:54.792625
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None
    assert isinstance(router, Router)


# Generated at 2022-06-26 04:14:32.151718
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    assert router_0.__class__.__name__ == "Router"


# Generated at 2022-06-26 04:14:34.049869
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    with pytest.raises(SanicException):
        router_0.finalize()

# Generated at 2022-06-26 04:14:37.637685
# Unit test for constructor of class Router
def test_Router():
    # construct an instance of class Router
    router = Router()
    # assert object type
    assert isinstance(router, Router)


# Generated at 2022-06-26 04:14:43.705474
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()

    assert router.dynamic_routes == {}
    # TODO: add some routes and run the method

    router.finalize()

    # TODO: assert something here


# Generated at 2022-06-26 04:14:49.317552
# Unit test for constructor of class Router
def test_Router():
    try:
        test_case_0()
    except Exception as e:
        print("Error in test case 0")
        print(e)

if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-26 04:14:51.448018
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

if __name__ == '__main__':
    test_Router()

# Generated at 2022-06-26 04:14:54.709483
# Unit test for constructor of class Router
def test_Router():
    print("Testing Router constructor ...")
    router_1 = Router()


# Generated at 2022-06-26 04:15:02.580184
# Unit test for constructor of class Router
def test_Router():
    router_object = Router()
    assert router_object.routes_all == None
    assert router_object.routes_static == None
    assert router_object.routes_dynamic == None
    assert router_object.routes_regex == None
    assert router_object.static_file_cache == None
    assert router_object.host_index == {}
    assert router_object.name_index == {}
    assert router_object.status_code_index == {}

# Generated at 2022-06-26 04:15:05.716860
# Unit test for constructor of class Router
def test_Router():

    # Variables used when constructing an instance of class Router
    router_0 = Router()
    assert router_0 != None



# Generated at 2022-06-26 04:15:15.506680
# Unit test for method add of class Router
def test_Router_add():
    router_1 = Router()
    router_1.add(
        uri='/endpoint-1', methods=['OPTIONS', 'GET'], handler=None, host=None, strict_slashes=False, stream=False, ignore_body=False, version=None, name=None, unquote=False, static=False
    )
    assert router_1.routes_all == [{'path': '/endpoint-1', 'requirements': {}, 'methods': ['OPTIONS', 'GET'], 'handler': None, 'name': None, 'strict': False, 'unquote': False, 'ctx': {'ignore_body': False, 'stream': False, 'hosts': [None], 'static': False}}]