

# Generated at 2022-06-26 04:05:51.186901
# Unit test for constructor of class Router
def test_Router():
    str_0 = ':Mq^m?g+Mw{>'
    router_0 = Router(str_0)
    assert isinstance(router_0, Router) == True

    router_1 = Router()
    assert isinstance(router_1, Router) == True


# Generated at 2022-06-26 04:06:06.772912
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router('str_0')
    assert router_0.ctx.app == 'str_0'
    assert isinstance(router_0.ctx.schema, dict)
    assert router_0.ctx.schema == {}
    assert isinstance(router_0.name_index, dict)
    assert router_0.name_index == {}
    assert isinstance(router_0.routes, dict)
    assert router_0.routes == {}
    assert isinstance(router_0.dynamic_routes, dict)
    assert router_0.dynamic_routes == {}
    assert isinstance(router_0.static_routes, dict)
    assert router_0.static_routes == {}

# Generated at 2022-06-26 04:06:18.557301
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_0 = '+cA|[a2Z^wj`]a=J'
    router_0 = Router(str_0)
    routing_exceptions_NoMethod_0 = NoMethod('N.2T!oN=F^y"Cn>', '|j9&{`q"ZU+wBh^', 'bQ(%T~FIy,Rj!E"*', '9|%x,Z(2[wYKUCd=', 'M$+}y:^&]u%OmCX7', 'mK!mV7Y?z(dDdp7K', 'Re:Cv&4}1dI4;2@J')

# Generated at 2022-06-26 04:06:21.129230
# Unit test for constructor of class Router
def test_Router():
    str_0 = ':Mq^m?g+Mw{>'
    router_0 = Router(str_0)


# Generated at 2022-06-26 04:06:26.062011
# Unit test for method add of class Router
def test_Router_add():
    uri_0: str = '/nkiemdrwzkt/'
    methods_0: Iterable[str] = iter(['POST', 'DELETE', 'PUT'])
    handler_0: RouteHandler = {'#x@l&7<~9Rg': ['i', 'H', 'uQP'], 'TmTvse': {}}
    host_0: Optional[Union[str, Iterable[str]]] = 'c_l{=i&'
    strict_slashes_0: bool = True
    stream_0: bool = False
    ignore_body_0: bool = False
    version_0: Union[str, float, int] = float()
    name_0: Optional[str] = 'JaaI?H!Wx'
    unquote_0: bool = True
    static

# Generated at 2022-06-26 04:06:31.134065
# Unit test for constructor of class Router
def test_Router():
    # Initialize test data
    str_0 = ':Mq^m?g+Mw{>'

    # Create an instance of Router
    router_0 = Router(str_0)

    # Check the result of constructor
    assert router_0.ctx == str_0

    # Clear test data
    del str_0, router_0


# Generated at 2022-06-26 04:06:42.477320
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_0 = '*k`r<;c}N{#'
    # Test case 0
    # ---
    # Expected output:
    # SanicException("Invalid route: {}. Parameter names cannot use '__'.".format(route))
    # ---
    # Raise:
    # SanicException("Invalid route: {}. Parameter names cannot use '__'.".format(route))
    # ---
    router_0 = Router(str_0)
    for route in router_0.dynamic_routes.values():
        if any(label.startswith('__') and label not in ALLOWED_LABELS for label in route.labels):
            raise SanicException('Invalid route: {}. Parameter names cannot use {}.'.format(route, '__'))
    router_0.finalize()
    pass

# Generated at 2022-06-26 04:06:47.550351
# Unit test for method add of class Router
def test_Router_add():
    try:
        raise ValueError()
    except ValueError:
        try:
            test_case_0()
        except Exception as ex_0:
            print(ex_0)
        else:
            pass
    else:
        pass


# Generated at 2022-06-26 04:06:59.611428
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router('')
    router_1 = Router('')
    input_0 = 'rRkt*mj{!pz'
    input_1 = {'XVxO==\x05\x0e\x18': True, '#\x0f!\x01\x1a\x05': -60.6, '\x1e\x13\n\x05\x06\x0b': set()}
    input_2 = '<s*$$(h'

# Generated at 2022-06-26 04:07:02.770361
# Unit test for constructor of class Router
def test_Router():
    str_0 = ':Mq^m?g+Mw{>'
    router_0 = Router(str_0)
    str_0 = ':Mq^m?g+Mw{>'
    router_1 = Router(str_0)


# Generated at 2022-06-26 04:07:14.009287
# Unit test for constructor of class Router
def test_Router():
    router = Router(routes=None)

    try:
        router.add(uri='string', methods=['GET'], handler=test_case_0)
    except TypeError:
        assert True
    except SanicException:
        assert True
    else:
        assert False

    try:
        router.add(uri='string', methods=['GET'], handler=None)
    except TypeError:
        assert True
    except SanicException:
        assert True
    else:
        assert False

# Generated at 2022-06-26 04:07:19.933807
# Unit test for method finalize of class Router
def test_Router_finalize():
    var_0 = ValueError
    var_1 = Router()
    try:
        test_case_0()
    except Exception as e:
        var_0 = type(e)

    assert var_0 == ValueError


# Generated at 2022-06-26 04:07:21.470035
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_case_0()


# Generated at 2022-06-26 04:07:22.421552
# Unit test for constructor of class Router
def test_Router():
    var_0 = Router()


# Generated at 2022-06-26 04:07:26.929871
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        var_0 = ValueError()
    except ValueError:
        var_1 = ValueError("Attempt to catch ValueError()")
        raise var_1


# Generated at 2022-06-26 04:07:29.738072
# Unit test for constructor of class Router
def test_Router():
    var_0 = Router()
    if not isinstance(var_0, Router):
        raise ValueError


# Generated at 2022-06-26 04:07:35.182692
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.testing import open_mock_http_response
    import sanic
    # Extra args
    # Extra kwargs
    # Create the router instance
    var_1 = Router()
    # Call the method finalize of router instance
    var_1.finalize()
    # Get the results
    pass



# Generated at 2022-06-26 04:07:39.248633
# Unit test for constructor of class Router
def test_Router():
    #  constructor(self) -> None
    try:
        obj_0 = Router()
    except ValueError:
        var_0 = ValueError()



# Generated at 2022-06-26 04:07:40.764966
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router


# Generated at 2022-06-26 04:07:42.955395
# Unit test for constructor of class Router
def test_Router():
    # type: () -> None
    test_case_0()



# Generated at 2022-06-26 04:07:53.429556
# Unit test for method finalize of class Router
def test_Router_finalize():
    var_0 = Router()
    var_1 = var_0.finalize()
    try:
        var_0.finalize()
    except Exception:
        var_2 = False
    else:
        var_2 = True
    assert var_2


# Generated at 2022-06-26 04:07:57.957688
# Unit test for method finalize of class Router
def test_Router_finalize():
    var_0 = Router(
        host=None,
        name="test_Router_finalize",
        strict_slashes=False,
        streams=None,
        host_matching=False,
    )
    var_0.finalize()
    assert (
        repr(var_0)
        == "test_Router_finalize (8/8 dynamic routes, 0/0 static routes)"
    )


# Generated at 2022-06-26 04:08:09.342605
# Unit test for method finalize of class Router
def test_Router_finalize():
    var_0 = ValueError()

    # Testing if TypeError was raised
    with pytest.raises(TypeError):
        # Testing if an exception was raised
        with pytest.raises(var_0): pass # Exception

    var_1 = [('var_0', 'var_1')]

    # Testing if TypeError was raised
    with pytest.raises(TypeError):
        # Testing if an exception was raised
        with pytest.raises(var_0): pass # Exception
        # Testing if an exception was raised
        with pytest.raises(var_0): pass # Exception
        # Testing if an exception was raised
        with pytest.raises(var_0): pass # Exception
        # Testing if an exception was raised
        with pytest.raises(var_0): pass # Exception


# Generated at 2022-06-26 04:08:14.651255
# Unit test for method finalize of class Router
def test_Router_finalize():
    var_2 = Router()
    var_3 = None
    var_4 = None
    # Call method finalize of class Router
    var_0 = var_2.finalize(var_3, var_4)


# Generated at 2022-06-26 04:08:16.198665
# Unit test for method finalize of class Router
def test_Router_finalize():
    var_0 = Router()
    var_0.finalize()


# Generated at 2022-06-26 04:08:18.291378
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert type(router) == Router


# Generated at 2022-06-26 04:08:23.200790
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_Router = Router()
    assert test_Router is not None
    try:
        test_Router.finalize()
    except:
        test_case_0()


# Generated at 2022-06-26 04:08:24.735173
# Unit test for constructor of class Router
def test_Router():
    var_0 = Router()


# Generated at 2022-06-26 04:08:26.655377
# Unit test for constructor of class Router
def test_Router():
    var_0 = Router()
    assert var_0 is not None


# Generated at 2022-06-26 04:08:34.711958
# Unit test for constructor of class Router
def test_Router():
    try:
        __args__ = ()
        __kwargs__ = ()
        var_0 = Router(*__args__, **__kwargs__)
    except:
        var_1 = sys.exc_info()
        var_2 , var_3, var_4 = var_1
        test_case_0()
    else:
        pass


# Generated at 2022-06-26 04:08:53.897603
# Unit test for method finalize of class Router
def test_Router_finalize():
    from unittest import mock
    from sanic.router import Router

    try:
        mock_args = mock.Mock()
        mock_kwargs = mock.Mock()

        mock.patch('sanic.router.Router.dynamic_routes', new_callable=mock.PropertyMock(return_value={})).start()

        var_1 = Router().finalize(mock_args, mock_kwargs)
        var_2 = True
        try:
            assert var_1 == var_2
        except AssertionError as e:
            var_3 = ValueError()
            raise e

    finally:
        # Mock objects cleanup
        pass


# Generated at 2022-06-26 04:08:55.311526
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_case_0()

# Generated at 2022-06-26 04:08:57.028128
# Unit test for method finalize of class Router
def test_Router_finalize():
    var_1 = Router()
    var_1.finalize()
    


# Generated at 2022-06-26 04:09:00.140364
# Unit test for constructor of class Router
def test_Router():
    # Instantiate a router object
    router_0 = Router()

    # Constructor of class Router should not raise any exception
    try:
        test_case_0()
    except Exception as e:
        assert False
    else:
        assert True

# Generated at 2022-06-26 04:09:05.829422
# Unit test for method finalize of class Router
def test_Router_finalize():
    for i in range(10):
        var_1 = i
        try:
            test_case_0()
        except ValueError as var_2:
            var_1 = var_2
        del var_1, var_2

    return var_1


# Generated at 2022-06-26 04:09:08.482462
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-26 04:09:15.928362
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router

    var_0 = Router()
    try:
        var_0.finalize()
    except BaseException as var_1:
        var_3 = type(var_1) is ValueError
        var_2 = var_3
    else:
        var_2 = False
    assert var_2


# Generated at 2022-06-26 04:09:19.121388
# Unit test for method finalize of class Router
def test_Router_finalize():
    var_0 = ValueError()
    var_1 = {}
    var_1 = {}
    try:
        var_0 = Router()
        var_1.update({
            "a": var_0.finalize("a")
        })
    except Exception as var_2:
        print(var_2)
    assert var_1 == {}


# Generated at 2022-06-26 04:09:32.809224
# Unit test for constructor of class Router
def test_Router():
    from sanic import Sanic
    from sanic.log import loggers
    from sanic.request import Request
    app = Sanic('sanic_server')
    router = Router(app, loggers.access_log, loggers.error_log)
    assert router.app == app
    assert router.ctx.app == app
    assert router.ctx.routes
    assert router.ctx.access_log
    assert router.ctx.error_log
    assert router.ctx.unresolved_info_stack
    assert router.ctx.unresolved_info_stack.top == (None, None, -1)
    assert router.routes
    assert router.name_index
    assert router.host_index
    assert router.static_routes
    assert router.dynamic_routes
    assert router.regex

# Generated at 2022-06-26 04:09:36.793802
# Unit test for constructor of class Router
def test_Router():
    try:
        test_case_0()
    except ValueError:
        pass


if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-26 04:09:47.102730
# Unit test for method finalize of class Router
def test_Router_finalize():
    var_0 = Router()
    try:
        test_case_0()
    except BaseException as e:
        var_0.finalize(e)


# Generated at 2022-06-26 04:09:49.881228
# Unit test for constructor of class Router
def test_Router():
    var_0 = Router()
    assert var_0 != None and type(var_0) == Router


# Generated at 2022-06-26 04:09:53.442663
# Unit test for method finalize of class Router
def test_Router_finalize():
    var_1 = Router()
    try:
        var_1.finalize()
    except ValueError:
        print("ValueError")
    except Exception:
        print("Exception")
    else:
        print("No exception")


# Generated at 2022-06-26 04:09:54.766305
# Unit test for constructor of class Router
def test_Router():
    var_0 = Router()


# Generated at 2022-06-26 04:09:56.761643
# Unit test for constructor of class Router
def test_Router():
    _Router = Router(var_0, var_1)


# Generated at 2022-06-26 04:10:03.257709
# Unit test for method finalize of class Router
def test_Router_finalize():
    var_1 = Router()
    try:
        var_1.finalize()
    except ValueError:
        var_0 = sys.exc_info()[1]
    else:
        var_0 = None
    assert var_0 == None
    var_1 = Router()
    try:
        var_1.finalize(0)
    except ValueError:
        var_0 = sys.exc_info()[1]
    else:
        var_0 = None
    assert var_0 == None


# Generated at 2022-06-26 04:10:11.573883
# Unit test for constructor of class Router
def test_Router():
    """Test case for constructor of class Router"""
    print("Constructor of class Router")
    # Test with value error
    print("Test with value error")
    try:
        test_case_0()
    except ValueError as e:
        # Assert that type of e is type(var_0)
        assert type(e) == type(var_0), "var_0 type is ValueError"


# Generated at 2022-06-26 04:10:16.510814
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Create instance of class Router
    var_0 = ValueError()

    # Invoke method finalize of var_3
    test_case_0()

# Global variable __version__
__version__ = '1.0.0'

# Global variable __author__
__author__ = 'Jonathan Neal'

# Global variable __licence__
__licence__ = 'MIT'

# Global variable __email__
__email__ = 'jonathantneal@gmail.com'

# Generated at 2022-06-26 04:10:20.419625
# Unit test for method add of class Router
def test_Router_add():
    _0 = Router()
    _1 = _0.add('/')
    assert _1 == None, "_1"
    pass


# Generated at 2022-06-26 04:10:31.159735
# Unit test for method finalize of class Router
def test_Router_finalize():
    uri = "" # type: str
    methods = [] # type: Iterable[str]
    handler = test_case_0
    host = None # type: Optional[Union[str, Iterable[str]]]
    strict_slashes = False # type: bool
    stream = False # type: bool
    ignore_body = False # type: bool
    version = None # type: Union[str, float, int]
    name = None # type: Optional[str]
    unquote = False # type: bool
    static = False # type: bool

    obj = Router()
    obj.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)
    obj.finalize()

if __name__ == '__main__':
    test_Router_finalize()

# Generated at 2022-06-26 04:10:53.877460
# Unit test for constructor of class Router
def test_Router():

    var_0 = NotFound("", Exception())

    var_1 = RoutingNotFound("", Exception())

    var_2 = NoMethod("", Exception(), [])

    var_3 = MethodNotSupported("", "", [])

    var_4 = SanicException("", Exception())


# Generated at 2022-06-26 04:10:55.285325
# Unit test for constructor of class Router
def test_Router():
    router = Router() # type: Router


# Generated at 2022-06-26 04:11:05.443226
# Unit test for method finalize of class Router
def test_Router_finalize():
    var_0 = Route('/test', ['GET', 'POST'], RouteHandler)
    var_1 = OrderedDict()
    var_1[var_0.variables] = var_0
    var_2 = Router(OrderedDict(), OrderedDict(), OrderedDict(), var_1, \
        OrderedDict(), OrderedDict(), OrderedDict())
    var_0._ctx.ignore_body = True
    var_0._ctx.hosts = [None]
    var_2.finalize()

# Generated at 2022-06-26 04:11:10.878605
# Unit test for method finalize of class Router
def test_Router_finalize():
    var_1 = ValueError()
    var_2 = str()
    var_3 = tuple()
    var_4 = tuple()
    var_5 = tuple()
    var_6 = tuple()
    var_7 = tuple()


# Generated at 2022-06-26 04:11:12.859576
# Unit test for method finalize of class Router
def test_Router_finalize():
    var_0 = Router()
    var_1 = test_case_0()
    var_2 = Router.finalize(var_0)
    assert var_2 is None


# Generated at 2022-06-26 04:11:15.735569
# Unit test for method finalize of class Router
def test_Router_finalize():
    var_0 = Router()
    try:
        var_0.finalize()
    except:
        pass


# Generated at 2022-06-26 04:11:24.223027
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add("/foo/{bar}/baz", ["GET"], test_finalize)
    try:
        router.finalize()
    except:
        pass
    router.add("/foo/{bar}/baz", ["GET"], test_finalize)
    try:
        router.finalize()
    except:
        pass
    return None



# Generated at 2022-06-26 04:11:31.556141
# Unit test for constructor of class Router
def test_Router():
    # Var_0 is a instance of class Router
    var_0 = Router()
    # Var_1 is a instance of class Router
    var_1 = Router()
    # Var_2 is a instance of class Router
    var_2 = Router()
    # Var_3 is a instance of class Router
    var_3 = Router()
    # Var_4 is a instance of class Router
    var_4 = Router()
    # Var_5 is a instance of class Router
    var_5 = Router()
    # Var_6 is a instance of class Router
    var_6 = Router()
    # Var_7 is a instance of class Router
    var_7 = Router()
    # Var_8 is a instance of class Router
    var_8 = Router()
    # Var_9 is a instance of class Router
    var_9 = Router()

# Generated at 2022-06-26 04:11:37.256663
# Unit test for method finalize of class Router
def test_Router_finalize():
    var_0 = Router()
    try:
        var_0.finalize()
    except ValueError as var_1:
        var_2 = var_1
    else:
        var_2 = None
    test_case_0()


# Generated at 2022-06-26 04:11:49.633409
# Unit test for method add of class Router
def test_Router_add():
    var_0 = Router()
    var_1 = "/search"
    var_2 = ["GET", "POST", "OPTIONS"]
    def var_3(var_4):
        return var_4
    var_5 = None
    var_6 = False
    var_7 = False
    var_8 = False
    var_9 = None
    var_10 = None
    var_11 = False
    var_12 = False
    var_13 = var_0.add(var_1, var_2, var_3, var_5, var_6, var_7, var_8, var_9, var_10, var_11, var_12)


# Generated at 2022-06-26 04:12:12.982374
# Unit test for constructor of class Router
def test_Router():
    try:
        var_0 = Router()
    except Exception as inst:
        assert isinstance(inst, Exception)
        assert inst.args[0] == "first argument must be callable"
    else:
        raise RuntimeError("No exception thrown")


# Generated at 2022-06-26 04:12:16.615764
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    test_case_0()


# Generated at 2022-06-26 04:12:32.565201
# Unit test for method finalize of class Router
def test_Router_finalize():
    var_0 = Router()
    var_1 = ValueError()
    var_2 = {var_3 for var_3 in range(0, 10)}
    var_4 = {var_5 for var_5 in range(0, 10)}
    var_6 = {var_7 for var_7 in range(0, 10)}
    var_8 = {var_9 for var_9 in range(0, 10)}
    var_10 = ValueError()
    try:
        var_0.finalize(var_1, var_2, var_3, var_4, var_5, var_6)
        assert False
    except ValueError:
        var_11 = BaseException()
        var_12 = ValueError()

# Generated at 2022-06-26 04:12:34.539276
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    test_case_0()


# Generated at 2022-06-26 04:12:37.673621
# Unit test for constructor of class Router
def test_Router():
    try:
        var_Router = Router()
    except Exception as exc:
        print(exc)
        assert False
    assert True



# Generated at 2022-06-26 04:12:40.295865
# Unit test for constructor of class Router
def test_Router():
    with pytest.raises(ValueError) as exception_info:
        test_case_0()
    print(exception_info.value)

test_Router()

# Generated at 2022-06-26 04:12:43.195495
# Unit test for constructor of class Router
def test_Router():
    router = Router()

    test_case_0()

if __name__ == "__main__":
    test_Router()
    print("[+] All unit tests are passed for 'Router'.")

# Generated at 2022-06-26 04:12:45.895315
# Unit test for constructor of class Router
def test_Router():
    # Test case #0 of constructor of class Router
    try:
        test_case_0()
    except ValueError:
        pass


# Generated at 2022-06-26 04:12:47.213377
# Unit test for method finalize of class Router
def test_Router_finalize():
    #assert False
    pass


# Generated at 2022-06-26 04:12:47.923355
# Unit test for constructor of class Router
def test_Router():
    router = Router()


# Generated at 2022-06-26 04:13:14.088000
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_0 = 'o'
    iterable_0 = None
    bytes_0 = b"\xd8P'\xa9\xd0f0\x8d=qL\x93g\x9b\xd7\xd2\x8e\x89"
    router_0 = Router()
    router_0.add(str_0, iterable_0, bytes_0)
    str_1 = 'o'
    iterable_1 = None
    router_0.get(str_1, str_0, str_1)
    router_0._get(str_1, str_0, str_1)
    router_0.find_route_by_view_name(str_0, str_1)
    router_0.find_route_by_view_name(str_0)

# Generated at 2022-06-26 04:13:19.569957
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Instantiate class Router
    router_0 = Router()
    # Get the value of property 'finalize'
    var_0 = router_0.finalize()
    # assert var_0 == None



# Generated at 2022-06-26 04:13:25.064095
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_0 = 'o'
    iterable_0 = None
    bytes_0 = b"\xd8P'\xa9\xd0f0\x8d=qL\x93g\x9b\xd7\xd2\x8e\x89"
    router_0 = Router()
    var_0 = router_0.add(str_0, iterable_0, bytes_0)
    router_0.finalize()


# Generated at 2022-06-26 04:13:36.972659
# Unit test for constructor of class Router
def test_Router():
    str_2 = 'm'
    set_0 = {'CqG'}
    router_0 = Router()
    assert (router_0.routes == {})
    assert (router_0.static_routes == {})
    assert (router_0.dynamic_routes == {})
    assert (router_0.regex_routes == [])
    assert (router_0.name_index == {})
    assert (router_0.ctx.namespace == '')
    assert (router_0.ctx.path_prefix == '')
    assert (router_0.ctx.strict_slashes == True)
    assert (router_0.ctx.host == None)

# Generated at 2022-06-26 04:13:39.688722
# Unit test for constructor of class Router
def test_Router():
    # Initialise a Router object
    router = Router()
    assert isinstance(router, Router)



# Generated at 2022-06-26 04:13:46.081793
# Unit test for constructor of class Router
def test_Router():
    str_0 = 'o'
    iterable_0 = None
    bytes_0 = b"\xd8P'\xa9\xd0f0\x8d=qL\x93g\x9b\xd7\xd2\x8e\x89"
    router_0 = Router()
    var_0 = router_0.add(str_0, iterable_0, bytes_0)


# Generated at 2022-06-26 04:13:51.476117
# Unit test for method finalize of class Router
def test_Router_finalize():
    type_0 = 'foo'
    flags_0 = 0
    router_0 = Router()
    var_0 = router_0.finalize(type_0, flags_0)


# Generated at 2022-06-26 04:13:57.858440
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_0 = 'o'
    iterable_0 = None
    bytes_0 = b"\xd8P'\xa9\xd0f0\x8d=qL\x93g\x9b\xd7\xd2\x8e\x89"
    router_0 = Router()
    var_0 = router_0.add(str_0, iterable_0, bytes_0)
    router_0.finalize()


# Generated at 2022-06-26 04:14:10.832190
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Variable declaration
    router_0 = Router()

# Generated at 2022-06-26 04:14:13.378996
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    assert isinstance(router_0, Router)


# Generated at 2022-06-26 04:14:33.849866
# Unit test for constructor of class Router
def test_Router():
    test_case_0()


# CommandLine: python -m unittest router_test
if __name__ == "__main__":
    import unittest
    unittest.main()

# Generated at 2022-06-26 04:14:35.537197
# Unit test for method finalize of class Router
def test_Router_finalize():
    return None

# Generated at 2022-06-26 04:14:41.219729
# Unit test for constructor of class Router
def test_Router():
    str_0 = 'o'
    iterable_0 = None
    bytes_0 = b"\xd8P'\xa9\xd0f0\x8d=qL\x93g\x9b\xd7\xd2\x8e\x89"
    router_0 = Router()
    var_0 = router_0.add(str_0, iterable_0, bytes_0)


# Generated at 2022-06-26 04:14:42.176980
# Unit test for constructor of class Router
def test_Router():
    test_case_0()


test_Router()

# Generated at 2022-06-26 04:14:48.135278
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_0 = 'o'
    iterable_0 = None
    bytes_0 = b"\xd8P'\xa9\xd0f0\x8d=qL\x93g\x9b\xd7\xd2\x8e\x89"
    router_0 = Router()
    router_0.add(str_0, iterable_0, bytes_0)
    str_1 = '_'
    router_0.finalize(str_1)


# Generated at 2022-06-26 04:14:55.807231
# Unit test for constructor of class Router
def test_Router():
    str_0 = 'o'
    iterable_0 = None
    bytes_0 = b"\xd8P'\xa9\xd0f0\x8d=qL\x93g\x9b\xd7\xd2\x8e\x89"
    router_0 = Router()
    var_0 = router_0.add(str_0, iterable_0, bytes_0)
    # get method
    str_1 = 'J\xc3\xd7+\x0f\x84'

# Generated at 2022-06-26 04:14:57.579312
# Unit test for constructor of class Router
def test_Router():
    assert True == True



# Generated at 2022-06-26 04:15:00.761647
# Unit test for constructor of class Router
def test_Router():
    try:
        Router()
    except Exception as ex:
        print(ex)
    else:
        assert True



# Generated at 2022-06-26 04:15:05.090057
# Unit test for method finalize of class Router
def test_Router_finalize():
    # test case 0
    str_0 = 'o'
    iterable_0 = None
    bytes_0 = b"\xd8P'\xa9\xd0f0\x8d=qL\x93g\x9b\xd7\xd2\x8e\x89"
    router_0 = Router()
    var_0 = router_0.add(str_0, iterable_0, bytes_0)
    router_0.finalize()


# Generated at 2022-06-26 04:15:07.241048
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    assert router_0 != None


# Generated at 2022-06-26 04:15:33.451546
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_0 = 'o'
    iterable_0 = None
    bytes_0 = b"\xd8P'\xa9\xd0f0\x8d=qL\x93g\x9b\xd7\xd2\x8e\x89"
    router_0 = Router()
    router_0.add(str_0, iterable_0, bytes_0)
    router_0.finalize()


# Generated at 2022-06-26 04:15:44.839296
# Unit test for method add of class Router
def test_Router_add():
    router_0 = Router()
    uri_0 = str()
    methods_0 = (list(), dict())
    handler_0 = str()
    host_0 = bool()
    strict_slashes_0 = float()
    stream_0 = bytes()
    ignore_body_0 = complex()
    version_0 = set()
    name_0 = None
    unquote_0 = None
    var_0 = router_0.add(uri_0, methods_0, handler_0, host_0, strict_slashes_0, stream_0, ignore_body_0, version_0, name_0, unquote_0)
