

# Generated at 2022-06-26 04:05:46.437771
# Unit test for method finalize of class Router
def test_Router_finalize():
    float_0 = 667.9263532398
    router_0 = Router(float_0)
    try:
        router_0.finalize()
    except:
        assert False


# Generated at 2022-06-26 04:05:47.353008
# Unit test for constructor of class Router
def test_Router():
    test_case_0()


# Generated at 2022-06-26 04:05:50.770628
# Unit test for method finalize of class Router
def test_Router_finalize():
    float_0 = 438.4849
    router_0 = Router(float_0)
    router_0.finalize()


# Generated at 2022-06-26 04:06:06.765315
# Unit test for constructor of class Router
def test_Router():

    @router_0.middleware('request')
    async def handler_0(request):
        pass

    request_0 = await request
    route_0, handler_1, params_0 = router_0.get(request_0.path, request_0.method, request_0.host)
    str_0 = route_0.uri()
    route_1 = router_0.find_route_by_view_name(str_0)
    int_0 = route_0.ctx.stream
    route_1.ctx.stream = int_0
    int_1 = route_0.ctx.ignore_body
    route_2 = route_0.ctx.hosts
    list_0 = [str_1 for str_1 in route_2]
    int_2 = route_0.ctx.static
    route_0

# Generated at 2022-06-26 04:06:12.288376
# Unit test for method finalize of class Router
def test_Router_finalize():
    float_0 = 438.4849
    router_0 = Router(float_0)

    try:
        router_0.finalize(float_0)
    except SanicException as e:
        assert "Invalid route: {route}. Parameter names cannot use '__'." in str(e)
    else:
        assert False


# Generated at 2022-06-26 04:06:13.921756
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router(None)


# Generated at 2022-06-26 04:06:26.702300
# Unit test for method finalize of class Router
def test_Router_finalize():
    float_0 = 200.11
    str_0 = "/"
    router_0 = Router(float_0)
    route_0 = router_0.add(str_0, (), lambda request, response: response)
    route_0.ctx.ignore_body = True
    route_0.ctx.stream = True
    route_1 = router_0.add(str_0, ("GET", "POST", "OPTIONS"), lambda request, response: response)
    route_1.ctx.ignore_body = True
    route_1.ctx.stream = True
    # AssertionError: Expected False but received True
    try:
        assert False == router_0.finalize()
    except AssertionError:
        print("AssertionError: Expected False but received True")

# Generated at 2022-06-26 04:06:29.874036
# Unit test for method finalize of class Router
def test_Router_finalize():
    float_0 = 438.4849
    router_0 = Router(float_0)

    # TypeError case
    # Test passed: Success: Test failed: Test raised TypeError
    # Test passed: Success: Test failed: Test raised TypeError
    # Test passed: Success: Test failed: Test raised TypeError
    # Test passed: Success: Test failed: Test raised TypeError


# Generated at 2022-06-26 04:06:34.054795
# Unit test for constructor of class Router
def test_Router():
    pass



# Generated at 2022-06-26 04:06:41.595798
# Unit test for method finalize of class Router
def test_Router_finalize():
    float_0 = 438.4849
    router_0 = Router(float_0)
    str_0 = ""
    float_1 = float_0
    # Line Coverage: 0.1%
    # Mutation Coverage: 0.0%
    # assert False
    try:
        router_0.finalize(str_0, float_1)
    # Line Coverage: 0.0%
    # Mutation Coverage: 0.0%
    except Exception as exception_0:
        print(str(type(exception_0)) + " thrown from Router.finalize")
        print(str(exception_0) + " thrown from Router.finalize")


# Generated at 2022-06-26 04:06:48.141785
# Unit test for method finalize of class Router
def test_Router_finalize():
    bool_0 = True
    router_0 = Router(bool_0)
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:06:49.232221
# Unit test for method finalize of class Router
def test_Router_finalize():
    assert test_case_0() == None



# Generated at 2022-06-26 04:06:53.378304
# Unit test for constructor of class Router
def test_Router():
    try:
        router_1 = Router(True)
    except Exception as inst:
        print(inst)
    else:
        print("Instantiation of Router object does not result in exception")
        print(router_1)
        

# Generated at 2022-06-26 04:06:54.951771
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

test_Router()

# Generated at 2022-06-26 04:06:59.693299
# Unit test for method finalize of class Router
def test_Router_finalize():
    dt_0 = None
    router_0 = Router(dt_0)
    var_0 = router_0.finalize()
    var_1 = isinstance(var_0, None)
    assert var_1 == True



# Generated at 2022-06-26 04:07:02.588451
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router(None)
    router_0.name_index = {'test':None,'test2':None}
    try:
        router_0.finalize()
    except SanicException:
        pass


# Generated at 2022-06-26 04:07:05.174902
# Unit test for method finalize of class Router
def test_Router_finalize():
    arg_0 = True
    test_case_0(arg_0)

# Generated at 2022-06-26 04:07:07.870796
# Unit test for method finalize of class Router
def test_Router_finalize():
    bool_0 = True
    router_0 = Router(bool_0)
    try:
        router_0.finalize()
    except:
        assert False


# Generated at 2022-06-26 04:07:12.065017
# Unit test for constructor of class Router
def test_Router():
    # Set up the test
    bool_0 = True
    router_0 = Router(bool_0)
    # Test the method
    var_0 = router_0.finalize()
    # Check the assertion
    # Pass the test
    pass


# Generated at 2022-06-26 04:07:24.273659
# Unit test for constructor of class Router
def test_Router():
    bool_0 = True
    router_0 = Router(bool_0)
    assert router_0.ALLOWED_METHODS == HTTP_METHODS
    assert router_0.DEFAULT_METHOD == 'GET'
    assert router_0.ctx == True
    assert router_0.finalized
    assert type(router_0.routes) == dict
    assert type(router_0.dynamic_routes) == dict
    assert type(router_0.static_routes) == dict
    assert type(router_0.regex_routes) == dict
    assert type(router_0.name_index) == dict
    assert type(router_0.host_index) == dict


# Generated at 2022-06-26 04:07:36.367726
# Unit test for constructor of class Router
def test_Router():
    bool_0 = True
    try:
        if bool_0:
            router_0 = Router(bool_0)
            var_0 = router_0.finalize()
        if bool_0:
            router_1 = Router(bool_0)
            var_0 = router_1.finalize()
    except Exception as e:
        print(e)
        return 0
    else:
        return 1



# Generated at 2022-06-26 04:07:37.810088
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Test code:
    test_case_0()

# Generated at 2022-06-26 04:07:41.221297
# Unit test for constructor of class Router
def test_Router():
    try:
        test_case_0()
        print('%c' % 0x2714, "Test case 0 passed")
    except AssertionError:
        print('%c' % 0x2718, "Test case 0 failed")


if __name__ == '__main__':
    test_Router()

# Generated at 2022-06-26 04:07:42.813477
# Unit test for method finalize of class Router
def test_Router_finalize():
    """Tests: test_Router_finalize"""

    try:
        test_case_0()
    except Exception as e:
        assert False, str(e)



# Generated at 2022-06-26 04:07:45.945418
# Unit test for constructor of class Router
def test_Router():
    bool_0 = True
    router_0 = Router(bool_0)
    var_0 = router_0.finalize()

# Generated at 2022-06-26 04:07:51.350425
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    assert isinstance(router_0, BaseRouter)
    router_1 = Router(True)
    assert isinstance(router_1, BaseRouter)
    router_2 = Router(False)
    assert isinstance(router_2, BaseRouter)
    router_3 = Router(True, True)
    assert isinstance(router_3, BaseRouter)
    router_4 = Router(False, True)
    assert isinstance(router_4, BaseRouter)
    router_5 = Router(True, False)
    assert isinstance(router_5, BaseRouter)
    router_6 = Router(False, False)
    assert isinstance(router_6, BaseRouter)

# Generated at 2022-06-26 04:07:52.912575
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_case_0()

# ----------------------------------------------------------------------

# Generated at 2022-06-26 04:07:55.964165
# Unit test for method finalize of class Router
def test_Router_finalize():
    bool_0 = True
    router_0 = Router(bool_0)
    var_0 = router_0.finalize()


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 04:08:08.720376
# Unit test for constructor of class Router
def test_Router():
    bool_0 = True
    router_0 = Router(bool_0)
    router_0.add("/users/<name>/<id>", ["POST"], RouteHandler)
    router_0.add("/users/<name>/<id>/<age>", ["GET"], RouteHandler)
    router_0.add("/users/<name>/<id>/<age>/<location>", ["PUT"], RouteHandler)
    router_0.finalize()
    uri_0 = "/users/ahmad/15"
    method_0 = "POST"
    host_0 = "127.0.0.1"
    tuple_0 = router_0.get(uri_0, method_0, host_0)
    route_0, handler_0, _ = tuple_0
    var_0 = route

# Generated at 2022-06-26 04:08:14.723349
# Unit test for constructor of class Router
def test_Router():
    bool_0 = False
    router_0 = Router(bool_0)
    var_0 = router_0.finalize()
    bool_1 = False
    router_1 = Router(bool_1)
    var_1 = router_1.finalize()

# Generated at 2022-06-26 04:08:34.223891
# Unit test for method finalize of class Router
def test_Router_finalize():
    assert callable(Router.finalize)
    router_0 = Router(True)
    var_0 = router_0.finalize()
    try:
        assert True
    except:
        raise AssertionError()


# Generated at 2022-06-26 04:08:37.018700
# Unit test for constructor of class Router
def test_Router():
    bool_0 = True
    router_0 = Router(bool_0)

    router_0.finalize()



# Generated at 2022-06-26 04:08:38.207179
# Unit test for constructor of class Router
def test_Router():
    router = Router(False)
    assert type(router) is Router

# Generated at 2022-06-26 04:08:51.529587
# Unit test for method add of class Router
def test_Router_add():
    bool_0 = True
    router_0 = Router(bool_0)
    str_0 = "host"
    str_1 = "host"
    str_2 = "strict_slashes"
    str_3 = "stream"
    str_4 = "ignore_body"
    str_5 = "version"
    str_6 = "name"
    str_7 = "unquote"
    str_8 = "static"
    str_9 = "methods"

    def fun_0(*args, **kwargs):
        var_1 = args[3]
        str_10 = "request"
        var_2 = var_1[str_10]
        return var_2
    int_0 = bind(fun_0, *[], **{})

# Generated at 2022-06-26 04:08:54.059370
# Unit test for constructor of class Router
def test_Router():
    bool_0 = True
    router_0 = Router(bool_0)
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:08:59.282780
# Unit test for constructor of class Router
def test_Router():
    assert Router.ALLOWED_METHODS == ('DELETE', 'GET', 'HEAD', 'OPTIONS', 'POST',
    'PUT', 'PATCH')
    router = Router(False)
    assert router.ctx == None
    router.finalize()
    assert router.ctx != None


# Generated at 2022-06-26 04:09:02.657176
# Unit test for constructor of class Router
def test_Router():
    bool_0 = True
    router_0 = Router(bool_0)
    assert router_0 is not None


# Generated at 2022-06-26 04:09:10.462442
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    var_0 = router_0.finalize()
    bool_1 = True
    router_1 = Router(bool_1)
    var_1 = router_1.finalize()
    bool_2 = True
    bool_3 = False
    router_2 = Router(bool_2, bool_3)
    var_2 = router_2.finalize()
if __name__ == '__main__':
    test_case_0()
    test_Router()

# Generated at 2022-06-26 04:09:21.876995
# Unit test for constructor of class Router
def test_Router():
    router = Router(True)
    assert router.ctx.app is not None
    assert len(router.routes) == 0
    assert router.routes_all == router.routes
    assert router.routes_static == router.static_routes
    assert router.routes_dynamic == router.dynamic_routes
    assert router.routes_regex == router.regex_routes

    # Exception raises if called twice
    try:
        router.finalize()
    except SanicException as e:
        assert 'Router.finalize() should not be called more than once.' in str(e)

    # Sanity check methods
    assert router.add is not None
    assert router.get is not None
    assert router.resolve is not None
    assert router.find_

# Generated at 2022-06-26 04:09:26.509363
# Unit test for method finalize of class Router
def test_Router_finalize():
    bool_0 = True
    router_0 = Router(bool_0)
    var_0 = router_0.finalize()
    del (bool_0, router_0, var_0)


# Generated at 2022-06-26 04:09:56.426315
# Unit test for constructor of class Router
def test_Router():
    run = testRunnerAdmin.TestRunner()
    run.AddTest(test_case_0)
    run.RunTests()

if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-26 04:10:05.373396
# Unit test for constructor of class Router
def test_Router():
    bool_0 = True
    router_0 = Router(bool_0)
    route_0 = router_0.find_route_by_view_name(None)
    var_0 = route_0
    routes_list_0 = router_0.routes_all
    routes_list_0 = router_0.routes_static
    routes_list_0 = router_0.routes_dynamic
    routes_list_0 = router_0.routes_regex
    var_1 = router_0.finalize()
    route_1, route_handler_0, dict_0 = router_0.get('/test/:name', 'get', 'localhost')

# Generated at 2022-06-26 04:10:12.488904
# Unit test for method add of class Router
def test_Router_add():
    bool_0 = True
    router_0 = Router(bool_0)
    list_0 = ["Test", "Test"]
    var_0 = router_0.add(
        "str_0",
        list_0,
        "handler_0",
        None,
        bool_0,
        True,
        True,
        None,
        "name_0",
        True,
        True
    )


# Generated at 2022-06-26 04:10:15.315896
# Unit test for method finalize of class Router
def test_Router_finalize():
    bool_0 = False
    router_0 = Router(bool_0)
    try:
        router_0.finalize()
    except SanicException:
        pass
    else:
        raise RuntimeError


# Generated at 2022-06-26 04:10:21.692160
# Unit test for method add of class Router
def test_Router_add():
    bool_0 = True
    router_0 = Router(bool_0)
    var_0 = router_0.finalize()
    var_1 = router_0.find_route_by_view_name('/', 'get')
    # assert var_1 == var_0


# Generated at 2022-06-26 04:10:34.444444
# Unit test for constructor of class Router
def test_Router():
    bool_0 = True
    router_0 = Router(bool_0)
    var_0 = router_0.finalize()

# Check Router.add method for request of path /
# Check for the response header Content-Type = application/json; charset=utf-8
# Check for the response header Server = gunicorn/19.9.0
# Check for the response header Connection = close
# Check for the response header Date = Sun, 14 Oct 2018 14:32:47 GMT
# Check for the response header Access-Control-Allow-Origin = *
# Check for the response header Content-Length = 44
# Check for the response header Access-Control-Allow-Methods = PUT, GET, POST, DELETE
# Check for the response header Access-Control-Allow-Headers = Content-Type, Authorization



# Generated at 2022-06-26 04:10:41.326803
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router(False)
    handler_0 = lambda: None
    var_0 = router_0.add("/foo", ["GET"], handler_0, name=None)
    var_1 = router_0.finalize()
    var_2 = router_0.ctx != None
    var_3 = var_2



# Generated at 2022-06-26 04:10:46.727193
# Unit test for method finalize of class Router
def test_Router_finalize():
    bool_2 = True
    router_4 = Router(bool_2)
    bool_0 = False
    str_0 = None
    int_0 = None
    int_1 = None
    bool_3 = None
    router_3 = None
    router_2 = Router(bool_0)
    router_4 = router_4.add(str_0, int_0, int_1, bool_3, router_3)
    var_0 = router_4.get(str_0, int_0, router_2)


# Generated at 2022-06-26 04:10:49.520293
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router(True)
    assert isinstance(router_0, Router)


# Generated at 2022-06-26 04:10:54.551853
# Unit test for constructor of class Router
def test_Router():
    bool_0 = True
    router_0 = Router(bool_0)
    assert router_0 is not None
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()


# Generated at 2022-06-26 04:11:25.877914
# Unit test for method finalize of class Router
def test_Router_finalize():
    print("test_Router_finalize")

    # Reset the cache in case it has been used in other tests
    Router.get.cache_clear()
    Router.find_route_by_view_name.cache_clear()

    router = Router(True)
    result = router.finalize()

    assert result == router



# Generated at 2022-06-26 04:11:39.653775
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    router_0.static_routes
    router_0.add()
    router_0.add()
    bool_0 = bool()
    router_1 = Router(bool_0)
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()
    bool_10 = bool()
    bool_11 = bool()
    bool_12 = bool()
    bool_13 = bool()
    bool_14 = bool()
    bool_15 = bool()
    bool_16 = bool()
    bool_17 = bool()
    bool_18 = bool()


# Generated at 2022-06-26 04:11:47.422623
# Unit test for constructor of class Router
def test_Router():
    router = Router(True)
    assert router.is_finalized
    assert router.ctx.app == None
    assert router.dynamic_routes == {}
    assert router.name_index == {}
    assert router.regex_routes == []
    assert router.routes == {}
    assert router.static_routes == []

# Generated at 2022-06-26 04:11:48.816306
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router(False)
    var_0 = router_0.finalize()

# Generated at 2022-06-26 04:11:50.610137
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Router.finalize() raises SanicException
    with pytest.raises(SanicException):
        test_case_0()

# Generated at 2022-06-26 04:11:52.649996
# Unit test for constructor of class Router
def test_Router():
    print("Unit test for constructor of class Router")
    # Test: with params
    test_case_0()
    print("Test passed\n")


# Generated at 2022-06-26 04:11:53.557817
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_case_0()



# Generated at 2022-06-26 04:11:55.909932
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router(True)
    router_0.finalize()
    print(router_0.uri_template_index)


# Generated at 2022-06-26 04:11:57.426149
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_case_0()

# Generated at 2022-06-26 04:12:01.675362
# Unit test for constructor of class Router
def test_Router():
    for i in range(5):
        bool_0 = i % 2 == 0
        router_0 = Router(bool_0)
        var_0 = router_0.finalize()


# Generated at 2022-06-26 04:12:54.703155
# Unit test for method finalize of class Router
def test_Router_finalize():
    bool_0 = True
    router_0 = Router(bool_0)
    var_0 = router_0.finalize()

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 04:12:56.901473
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_1 = Router(True)
    router_1.finalize()


# Generated at 2022-06-26 04:12:58.338459
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_case_0()


# Generated at 2022-06-26 04:13:01.442336
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router(True)
    bool_0 = bool(router_0)
    assert bool_0
    assert bool_0 == True
    assert bool_0 == bool_0

# Generated at 2022-06-26 04:13:04.778867
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router(False) # should pass without assertation error


# Generated at 2022-06-26 04:13:07.855639
# Unit test for constructor of class Router
def test_Router():
    bool_0 = True
    router_0 = Router(bool_0)
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:13:15.176398
# Unit test for constructor of class Router
def test_Router():
    try:
        Router(None)
    except TypeError:
        pass
    else:
        assert False

    # Test branch coverage
    try:
        router_0 = Router(True)
        router_0.add("path", list(HTTP_METHODS), None)
        router_0.add("path", list(HTTP_METHODS), None)
        router_0.finalize()
        router_0.dynamic_routes.clear()
        router_0.static_routes.clear()
        router_0.get("path", "GET", None)
    except Exception:
        pass


# Generated at 2022-06-26 04:13:22.118563
# Unit test for method finalize of class Router
def test_Router_finalize():
    bool_0 = True
    router_0 = Router(bool_0)
    var_1 = router_0.finalize()
    print("Test 0: " + str(var_1))

if __name__ == '__main__':
    test_Router_finalize()

# Generated at 2022-06-26 04:13:25.211410
# Unit test for method finalize of class Router
def test_Router_finalize():
    if __name__ == '__main__':
        test_case_0()

# Generated at 2022-06-26 04:13:35.088631
# Unit test for constructor of class Router
def test_Router():
    bool_0 = False
    router_0 = Router(bool_0)
    bool_1 = router_0.ctx.app
    bool_2 = router_0.ctx.router
    router_1 = Router(bool_0)
    router_2 = Router(bool_0)
    router_3 = Router(bool_0)
    router_0 = Router(bool_0)
    router_4 = Router(bool_0)
    router_5 = Router(bool_0)
    # test case: finalize()
    test_case_0()


# Generated at 2022-06-26 04:15:32.092413
# Unit test for method finalize of class Router
def test_Router_finalize():
    bool_0 = True
    router_0 = Router(bool_0)
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:15:36.300784
# Unit test for method add of class Router
def test_Router_add():
    router_0 = Router(True)
    router_0.finalize()

    uri = "/any_uri"
    methods = ["GET", "POST", "OPTIONS"]
    handler = lambda request: None

    route = router_0.add(uri, methods, handler, strict_slashes=True)

    assert route.path == uri
    assert route.methods == methods
    assert route.handler == handler
    assert route.strict_slashes == True


# Generated at 2022-06-26 04:15:38.463790
# Unit test for constructor of class Router
def test_Router():
    bool_0 = True
    test_case_0()
    test_case_0()