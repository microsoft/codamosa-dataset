

# Generated at 2022-06-26 04:06:02.958396
# Unit test for method finalize of class Router
def test_Router_finalize():
    float_0 = 0.001
    router_0 = Router(float_0)
    router_0.add("/test1/<test>", router_0.ALLOWED_METHODS, test_case_0)
    router_0.add("/test2/<test>", router_0.ALLOWED_METHODS, test_case_0, static=True)
    router_0.add("/test3/<test>", router_0.ALLOWED_METHODS, test_case_0)

    routes_all = router_0.routes_all
    if len(routes_all) == 3:
        routes_static = router_0.routes_static
        if len(routes_static) == 1:
            routes_dynamic = router_0.routes_dynamic


# Generated at 2022-06-26 04:06:07.122402
# Unit test for constructor of class Router
def test_Router():
    float_0 = 0.001
    router_0 = Router(float_0)
    int_0 = 0
    int_1 = 1
    str_0 = "__file_uri__"
    for i in range(int_0, int_1):
        router_0.add(str_0, List[str], RouteHandler, str, bool, bool, bool, Union[str, float, int])

# Generated at 2022-06-26 04:06:18.997740
# Unit test for constructor of class Router
def test_Router():
    # If a float is given to the constructor of class Router, throws exception SanicException
    float_0 = 0.001
    router_0 = Router(float_0)
    assert isinstance(router_0, Exception) == True

    # If an integer is given to the constructor of class Router, throws exception SanicException
    int_0 = 1
    router_1 = Router(int_0)
    assert isinstance(router_1, Exception) == True

    # If a boolean value is given to the constructor of class Router, throws exception SanicException
    bool_0 = False
    router_2 = Router(bool_0)
    assert isinstance(router_2, Exception) == True

    # If a string value is given to the constructor of class Router, throws exception SanicException
    str_0 = "router"
    router_

# Generated at 2022-06-26 04:06:25.129621
# Unit test for method finalize of class Router
def test_Router_finalize():
    float_0 = 0.001
    router_0 = Router(float_0)
    try:
        router_0.finalize()
    except Exception as inst:
        import sys
        import traceback
        tb = sys.exc_info()[2]
        tbinfo = traceback.format_tb(tb)[0]
        pymsg = "PYTHON ERRORS:\nTraceback info:\n" + tbinfo + "\nError Info:\n" + str(
            inst)
        print(pymsg)

# Generated at 2022-06-26 04:06:26.942932
# Unit test for constructor of class Router
def test_Router():
    test_case_0()
    #print("All test are passed for Router")


if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-26 04:06:35.867238
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router[str](0)
    assert router_0.base_url == 0
    assert router_0.static_routes == {}
    assert router_0.dynamic_routes == {}
    assert router_0.regex_routes == {}
    assert router_0.name_index == {}
    assert router_0.ctx.app == 0
    assert router_0.routes == {}
    assert router_0.static_routes == {}
    assert router_0.dynamic_routes == {}
    assert router_0.regex_routes == {}


# Generated at 2022-06-26 04:06:37.171983
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None


# Generated at 2022-06-26 04:06:39.850516
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router(0.0)

    # Test for line router.resolve
    test_case_0()

# Generated at 2022-06-26 04:06:50.092728
# Unit test for constructor of class Router
def test_Router():
    float_0 = 0.001
    # Test for constructor of class Router
    router_0 = Router(float_0)
    path_0 = "Router__resolve__0.01"
    assert router_0._resolve(path_0) == None
    router_0.add("add_0", ["add_1"], "add_2")
    router_0.get("get_0", "get_1", "get_2")
    router_0.find_route_by_view_name("find_route_by_view_name_0", "find_route_by_view_name_1")
    assert router_0.routes_all == router_0.routes
    assert router_0.routes_static == router_0.static_routes
    assert router_0.routes

# Generated at 2022-06-26 04:07:01.443883
# Unit test for constructor of class Router
def test_Router():
    float_0 = 0.0001
    router_0 = Router(float_0)
    routes_all = router_0.routes_all
    if not isinstance(router_0, Router):
        raise ValueError
    if len(router_0.routes_static) != 0:
        raise ValueError
    if len(router_0.routes_dynamic) != 0:
        raise ValueError
    if len(router_0.routes_regex) != 0:
        raise ValueError
    if len(routes_all) != 0:
        raise ValueError
    uri_0 = ""
    methods_0 = ["GET", "POST", "OPTIONS"]
    handler_0 = test_case_0
    host_0 = ""

# Generated at 2022-06-26 04:07:07.750043
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None


# Generated at 2022-06-26 04:07:13.686984
# Unit test for constructor of class Router
def test_Router():
    my_test_router = Router()
    print(my_test_router)
    assert(type(my_test_router) == Router)

# API: https://docs.aiohttp.org/en/stable/web_reference.html#aiohttp.web.BaseRequest
# API: https://docs.aiohttp.org/en/stable/web_reference.html#aiohttp.web.BaseRequest

# Generated at 2022-06-26 04:07:17.606902
# Unit test for constructor of class Router
def test_Router():
    # Arrange
    router = Router()

    # Action
    result: Router = router

    # Assert
    assert router == result


# Generated at 2022-06-26 04:07:21.064411
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None
    assert len(router.name_index) == 0


# Generated at 2022-06-26 04:07:22.192401
# Unit test for constructor of class Router
def test_Router():
    routes = Router()
    assert type(routes) == Router


# Generated at 2022-06-26 04:07:24.309870
# Unit test for constructor of class Router
def test_Router():
    test_case_0() #TODO: test case


# Generated at 2022-06-26 04:07:36.601502
# Unit test for method finalize of class Router
def test_Router_finalize():

    # Arguments to be passed to the function
    args = ()

    # Keyword arguments (if any) to be passed to the function
    kwargs = {}

    # Attempt to call the function, check for assertion errors
    try:
        # Call the function
        result = finalize(*args, **kwargs)

        # Check that the result is what we expect
        assert result == None

    # Check for TypeError
    except TypeError as e:
        if "unexpected keyword argument" in str(e):
            print(e)
            raise Exception("Argument name mismatch. Check arguments and kwargs.")
        else:
            raise e

    # Check for assertion errors
    except AssertionError as e:
        print(e)
        raise Exception("Unexpected result. Check function definition.")

    # Return the result
    return result




# Generated at 2022-06-26 04:07:43.265314
# Unit test for constructor of class Router
def test_Router():
    try:
        test_case_0()
    except NameError as e:
        print("Name Error:", e)
    except TypeError as e:
        print("Type Error:", e)
    except AttributeError as e:
        print("Attribute Error:", e)



# Generated at 2022-06-26 04:07:51.019361
# Unit test for method finalize of class Router
def test_Router_finalize():
    int_0 = 0
    int_1 = 1
    int_0 = 0
    str_0 = str(int_0)
    int_2 = 2
    int_3 = 3
    int_1 = 1
    str_1 = str(int_1)

    # Test 0: Call the function
    test_case_0()

# Generated at 2022-06-26 04:07:53.084835
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    class_0 = router.__class__
    assert class_0 == Router
    test_case_0()

Router.finalize = finalize


# Generated at 2022-06-26 04:08:03.972246
# Unit test for method finalize of class Router
def test_Router_finalize():
    # setup test
    int_0 = 0
    int_1 = 1
    str_0 = "string 0"
    test_case_0()

# Generated at 2022-06-26 04:08:11.209886
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    from sanic import Sanic
    from sanic.router import Router
    from sanic.exceptions import SanicException

    app = Sanic("test_Router_finalize")
    router = Router(app)

    @app.route("/", methods=["get"])
    async def test_route(request):
        return await response.text("I am a get request")

    @app.route("/user/<name>", methods=["get"])
    async def test_route_name(request, name):
        return await response.text("I am a get request for {}".format(name))

    # Test for user-defined __test_case_0()

# Generated at 2022-06-26 04:08:13.929056
# Unit test for constructor of class Router
def test_Router():
    # Create a new Router instance
    router = Router()
    test_case_0()


# Generated at 2022-06-26 04:08:16.073935
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    print(router.routes_all)


# Generated at 2022-06-26 04:08:18.216111
# Unit test for method finalize of class Router
def test_Router_finalize():
    int_0 = 0
    # Test case 0
    try:
        test_case_0()
    except Exception as e:
        assert (True == False)
    else:
        assert (True == True)

# Generated at 2022-06-26 04:08:20.260718
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None


# Generated at 2022-06-26 04:08:28.132707
# Unit test for method finalize of class Router
def test_Router_finalize():
    int_0 = 0
    int_1 = 1
    int_2 = 2
    router = Router()
    router.dynamic_routes = {int_1: int_1, int_1: int_1, int_0: int_0}
    # CALLING METHOD finalize [1/2] OF Router
    router.finalize(int_0, int_1, int_1)



# Generated at 2022-06-26 04:08:40.645326
# Unit test for constructor of class Router
def test_Router():

    # Test type of attribute routes_all
    assert isinstance(Router.routes_all, property)
    
    # Test type of attribute routes_static
    assert isinstance(Router.routes_static, property)
    
    # Test type of attribute routes_dynamic
    assert isinstance(Router.routes_dynamic, property)
    
    # Test type of attribute routes_regex
    assert isinstance(Router.routes_regex, property)
    
    # Test type of attribute find_route_by_view_name
    assert callable(Router.find_route_by_view_name)

    # Test type of attribute add
    assert callable(Router.add)
    
    # Test type of attribute finalize
    assert callable(Router.finalize)

    #

# Generated at 2022-06-26 04:08:51.621314
# Unit test for method finalize of class Router
def test_Router_finalize():
    int_0 = 0
    router = Router()
    route_0 = Route(
        router,
        "route_0",
        "/",
        "GET",
        test_case_0,
        int_0,
        int_0,
        int_0,
        int_0,
        int_0,
        int_0,
        int_0,
        int_0,
        int_0,
        int_0,
        int_0,
        int_0,
        int_0,
    )
    router.dynamic_routes = { int_0: route_0 }
    try:
        router.finalize()
    except SanicException:
        pass


# Generated at 2022-06-26 04:08:54.514734
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-26 04:09:14.311656
# Unit test for constructor of class Router
def test_Router():
    try:
        router_instance = Router()
    except:
        print("AssertionError")
        assert False
    print("Pass")


# Generated at 2022-06-26 04:09:16.387233
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    int_0 = 0


# Generated at 2022-06-26 04:09:17.853553
# Unit test for constructor of class Router
def test_Router():
    assert Router()



# Generated at 2022-06-26 04:09:23.042223
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()

    name_index = {'test_case_0': 1}
    setattr(router, 'name_index', name_index)

    dynamic_routes = {'test_case_0': 1}
    setattr(router, 'dynamic_routes', dynamic_routes)

    try:
        router.finalize()
    except SanicException as e:
        assert(e.args == ('Invalid route: 1. Parameter names cannot use \'__\'.',))
        assert(isinstance(e, SanicException))


# Generated at 2022-06-26 04:09:25.744060
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert not isinstance(router, BaseRouter)


# Generated at 2022-06-26 04:09:27.081604
# Unit test for constructor of class Router
def test_Router():
    # Initializing a new Router Object
    router = Router()
    assert type(router) is Router
    # router = Router(ctx = Router)
    # assert type(router) is Router

# Generated at 2022-06-26 04:09:36.999129
# Unit test for method finalize of class Router
def test_Router_finalize():
    int_0 = 0
    router = Router()
    app = Sanic('sanic-server')
    app.static('/favicon.ico', '../Favorites/favicon.ico')
    app.static('/static/js', './static/js')
    app.static('/static/css', './static/css')
    app.static('/static/assets', './static/assets')
    router.add_static("/static", "../static")
    if router.routes_static:
        route = router.routes_static[0]
        if route.methods and route.methods[0] == 'HEAD':
            raise AssertionError('Failed to add route')
        router.add_static("/admin/static", "../static")
        route = router.routes

# Generated at 2022-06-26 04:09:39.853203
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Declare test object
    router = Router()
    # Call method
    router.finalize()
    

# Generated at 2022-06-26 04:09:41.608924
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None
test_Router()



# Generated at 2022-06-26 04:09:43.774827
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-26 04:10:22.458299
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)
    assert router.ctx == {}
    assert router.dynamic_routes == {}
    assert router.static_routes == {}
    assert router.name_index == {}
    assert router.regex_routes == {}
    assert router.host_index == {}
    assert router.routes == []


# Generated at 2022-06-26 04:10:24.662428
# Unit test for constructor of class Router
def test_Router():
    try:
        test_case_0()
    except:
        pass

# Generated at 2022-06-26 04:10:35.644917
# Unit test for constructor of class Router
def test_Router():
    route = Route()
    router = Router()
    router._get_route_by_view_name('a')
    if router.base_path != '':
        raise NotImplementedError()
    test_case_0()
    if router.routes != {}:
        raise NotImplementedError()
    if router.regex_routes != []:
        raise NotImplementedError()
    if router.dynamic_routes != {}:
        raise NotImplementedError()
    if router.static_routes != {}:
        raise NotImplementedError()
    if router.name_index != {}:
        raise NotImplementedError()
    if router.ctx != None:
        raise NotImplementedError()
    router.add(uri='a', methods=[], handler=None)


# Generated at 2022-06-26 04:10:37.680914
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    assert router_0 is not None


# Generated at 2022-06-26 04:10:39.183358
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None

# Generated at 2022-06-26 04:10:41.326295
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router != None


# Generated at 2022-06-26 04:10:41.885991
# Unit test for constructor of class Router
def test_Router():
    Router()


# Generated at 2022-06-26 04:10:46.294434
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    try:
        method_0 = router_0.finalize
        try:
            method_0()
        except TypeError:
            return
    except AttributeError:
        test_case_0()


# Generated at 2022-06-26 04:10:54.224218
# Unit test for method add of class Router
def test_Router_add():
    with pytest.raises(TypeError):
        print("Test case 0")
        print(test_case_0)
        test_case_0()
"""
    with pytest.raises(TypeError):
        print("Test case 1")
        print(test_case_1)
        test_case_1()
    print("Test case 2")
    print(test_case_2)
    test_case_2()
"""

# Generated at 2022-06-26 04:10:58.824412
# Unit test for constructor of class Router
def test_Router():
    # Create an instance of Router
    obj_Router = Router()
    # Tests getattr
    test_case_0()
    assert obj_Router


# Generated at 2022-06-26 04:12:06.553456
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router

    return

if __name__ == "__main__":
    test_case_0()
    test_Router()

# Generated at 2022-06-26 04:12:15.539150
# Unit test for constructor of class Router
def test_Router():
    router = Router()

    assert (router.ctx == {})
    assert (router.dynamic_routes == {})
    assert (router.static_routes == {})
    assert (router.regex_routes == {})
    assert (router.name_index == {})
    assert (router.path_index == {})
    assert (router.default_route == {})


# Generated at 2022-06-26 04:12:17.917339
# Unit test for constructor of class Router
def test_Router():
    inst_Router = Router()
    assert inst_Router is not None


# Generated at 2022-06-26 04:12:32.909773
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Parameter initializations
    self = Router()
    args = ()
    kwargs = {}

    # Code to test
    result = self.finalize(*args, **kwargs)

    # Return value check
    try:
        assert result is None
    except AssertionError:
        print(f"Expected: None\nActual:   {result}")
        raise

    # Return value check for find_route_by_view_name
    view_name = None
    try:
        assert self.find_route_by_view_name(view_name) is None
    except AssertionError:
        print(f"Expected: None\nActual:   {self.find_route_by_view_name(view_name)}")
        raise

# Generated at 2022-06-26 04:12:41.505830
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        route = Route(
            prefix=None,
            path='/',
            methods=('POST', 'GET'),
            handler=test_case_0,
            name=None,
            strict=False,
            host=None,
            requirements=None,
            unquote=False
        )
    except:
        route = Route(
            prefix=None,
            path='/',
            methods=('POST', 'GET'),
            handler=test_case_0,
            name=None,
            strict=False,
            host=None,
            unquote=False
        )

    router = Router()
    router.routes_dynamic[0] = route
    router.routes_all[0] = route
    router.finalize()



# Generated at 2022-06-26 04:12:42.826386
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.finalize()



# Generated at 2022-06-26 04:12:46.693322
# Unit test for constructor of class Router
def test_Router():
    int_0 = 0
    router = Router()
    if router is None:
        raise Exception("expected router to not be None but was None")
    return

test_Router()
test_case_0()

# Generated at 2022-06-26 04:13:00.893120
# Unit test for constructor of class Router
def test_Router():
    ctx_0 = Router.RouterContext(Router)
    ctx_0.ctx = None
    ro_0 = Router(ctx_0)
    ro_0.routes = dict()
    ro_0.name_index = dict()
    ro_0.dynamic_routes = dict()
    ro_0.regex_routes = dict()
    ro_0.static_routes = dict()
    assert ro_0.routes == dict()
    assert ro_0.name_index == dict()
    assert ro_0.dynamic_routes == dict()
    assert ro_0.regex_routes == dict()
    assert ro_0.static_routes == dict()
    test_case_0()



# Generated at 2022-06-26 04:13:07.250046
# Unit test for method finalize of class Router
def test_Router_finalize():
    print("Unit test for method finalize of class Router")
    router = Router()
    try:
        router.finalize()
    except Exception as e:
        print("Exception occurred:\n")
        print(e)

    return


# Generated at 2022-06-26 04:13:14.031148
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    assert isinstance(router_0, Router)
    assert isinstance(router_0, BaseRouter)
    assert len(router_0.routes_all) == 0
    assert len(router_0.routes_static) == 0
    assert len(router_0.routes_dynamic) == 0
    assert len(router_0.routes_regex) == 0


# Generated at 2022-06-26 04:15:11.923698
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    assert isinstance(router_0, Router)


# Generated at 2022-06-26 04:15:16.375076
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    int_0 = 0
    try:
        router_0.finalize()
        assert False
    except Exception as e:
        assert True


# Generated at 2022-06-26 04:15:21.316900
# Unit test for constructor of class Router
def test_Router():
    # test for simple case
    router = Router()
    assert isinstance(router, Router)

    # test for exception case
    try:
        router = Router()
    except Exception:
        assert False


# Generated at 2022-06-26 04:15:24.350520
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.name_index == {}
    assert router.routes == {}
    assert router.host_index == {}
    assert router.dynamic_routes == {}
    assert router.static_routes == {}
    assert router.regex_routes == {}


# Generated at 2022-06-26 04:15:28.242707
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router != None, 'Router object successfully created'
    print("Passed test_Router")


# Generated at 2022-06-26 04:15:33.750297
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    try:
        assert isinstance(router, Router)
    except Exception as info:
        print(info)
        print("FAIL: test_Router")
        test_case_0()
    else:
        print("OK: test_Router")


# Generated at 2022-06-26 04:15:37.393763
# Unit test for constructor of class Router
def test_Router():
    try:
        Router()
    except Exception as e:
        test_case_0()


# Generated at 2022-06-26 04:15:46.114767
# Unit test for constructor of class Router
def test_Router():
    router = Router(None)
    assert router

    # Test router.allowed_methods 
    allowed_methods = router.allowed_methods
    assert type(allowed_methods) == tuple

    # Test router.allowed_methods = allowed_methods
    router.allowed_methods = allowed_methods
    assert router.allowed_methods == allowed_methods

    # Test router.default_method
    default_method = router.default_method
    assert type(default_method) == str

    # Test router.default_method = default_method
    router.default_method = default_method
    assert router.default_method == default_method

