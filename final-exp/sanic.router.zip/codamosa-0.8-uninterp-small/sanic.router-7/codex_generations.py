

# Generated at 2022-06-26 04:05:39.687251
# Unit test for constructor of class Router
def test_Router():

    try:
        test_case_0()

    except Exception as e:
        print(e)

    else:
        print("OK")

if __name__ == '__main__':
    test_Router()

# Generated at 2022-06-26 04:05:42.057037
# Unit test for constructor of class Router
def test_Router():
    bool_0 = None
    router_0 = Router(bool_0)



# Generated at 2022-06-26 04:05:50.667895
# Unit test for constructor of class Router
def test_Router():
    bool_0 = None
    router_0 = Router(bool_0)
    assert not router_0.get_routes()
    assert not router_0.get_dynamic_routes()
    assert not router_0.get_static_routes()
    str_0 = "qvq6Ud"
    str_1 = "fHclvq"
    str_2 = "8WEnNs"
    str_3 = "KlRm8V"
    str_4 = "BdZfVE"
    str_5 = "2yV7Dy"
    str_6 = "GViV7Z"
    str_7 = "8iVRpd"
    str_8 = "PV7lc8"
    str_9 = "sYd1C7"
    str

# Generated at 2022-06-26 04:05:51.828653
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router(False)


# Generated at 2022-06-26 04:06:03.991908
# Unit test for method add of class Router
def test_Router_add():
  bool_0 = None
  router_0 = Router(bool_0)
  str_0 = "2T7E"
  str_1 = "Uo"
  route_0 = router_0.add(str_0, str_1)
  route_1 = router_0.add(str_0, str_1)
  if (route_0 is not None):
    route_0.run()
  if (route_1 is not None):
    route_1.run()


# Generated at 2022-06-26 04:06:08.789101
# Unit test for constructor of class Router
def test_Router():
    bool_0 = None
    router_0 = Router(bool_0)

if __name__ == "__main__":
    bool_0 = None
    router_0 = Router(bool_0)

    test_Router()
    test_case_0()

# Generated at 2022-06-26 04:06:11.864961
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_obj_0 = Router(None)
    test_obj_0.finalize()


# Generated at 2022-06-26 04:06:18.994872
# Unit test for constructor of class Router
def test_Router():
    bool_0 = None
    router_0 = Router(bool_0)

    assert isinstance(router_0, Router), "router_0 created with right type"
    print("Router test passed!")



# Generated at 2022-06-26 04:06:26.418633
# Unit test for method finalize of class Router
def test_Router_finalize():
    bool_0 = None
    # Testing of exceptions
    # if the type of the error is sanic.exceptions.SanicException
    try:
        router_0 = Router(bool_0)
        method_0 = router_0.finalize()
        assert False
    except SanicException as error:
        assert error.__cause__ == None
        assert str(error) == "Invalid route: <Route: /v1/<name> -> " \
            "<function health at 0x7f91d58b41e0>, methods: ['GET']>. " \
            "Parameter names cannot use '__'."
    except Exception as error:
        assert False


# Generated at 2022-06-26 04:06:36.687459
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    router_0._Router__router_0(router_0)
    router_0 = Router('<script>alert(1)</script>')
    router_0._Router__router_0(router_0)
    router_0 = Router('<script>alert(1)</script>')
    router_0._Router__router_0(router_0)
    router_0 = Router('<script>alert(1)</script>')
    router_0._Router__router_0(router_0)
    router_0 = Router(False)
    router_0._Router__router_0(router_0)
    router_0 = Router(None)
    router_0._Router__router_0(router_0)
    router_

# Generated at 2022-06-26 04:06:43.750662
# Unit test for constructor of class Router
def test_Router():
    bool_0 = None
    router_0 = Router(bool_0)

test_Router()
test_case_0()

# Generated at 2022-06-26 04:06:46.480919
# Unit test for constructor of class Router
def test_Router():
    bool_0 = None
    router_0 = Router(bool_0)


# Generated at 2022-06-26 04:06:48.191097
# Unit test for constructor of class Router
def test_Router():
    router = Router(app=None)
    assert router is not None

# Generated at 2022-06-26 04:06:50.455859
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-26 04:06:56.170001
# Unit test for method finalize of class Router
def test_Router_finalize():
    bool_0 = None
    router_0 = Router(bool_0) # Type-inference error
    try:
        router_0.finalize()
    except:
        pass


# Generated at 2022-06-26 04:07:01.561408
# Unit test for method finalize of class Router
def test_Router_finalize():
    bool_0 = None
    # Creation of the class instance
    router_0 = Router(bool_0)
    # Force exception on the next line
    # router_0.finalize(*(Exception())(), **{Exception(): []})
    with pytest.raises(Exception):
        router_0.finalize(*(Exception())(), **{Exception(): []})


# Generated at 2022-06-26 04:07:08.759093
# Unit test for method add of class Router
def test_Router_add():
    bool_0 = None
    router_0 = Router(bool_0)

    str_0 = "test_sanic_exceptions.test_case_0"
    str_1 = ""
    router_0.add(str_0, ["test_sanic_exceptions.test_case_0"], str_1)

# Generated at 2022-06-26 04:07:11.642884
# Unit test for method finalize of class Router
def test_Router_finalize():
    bool_0 = None
    router_0 = Router(bool_0)
    router_0.finalize()


# Generated at 2022-06-26 04:07:25.452369
# Unit test for constructor of class Router
def test_Router():
    bool_0 = None
    router_0 = Router(bool_0)
    uri_0 = "/"
    methods_0 = ["GET", "POST", "DELETE", "PUT", "OPTIONS", "HEAD", "PATCH"]
    handler_0 = lambda request, name: None
    host_0 = None
    strict_slashes_0 = True
    stream_0 = False
    ignore_body_0 = False
    version_0 = None
    name_0 = None
    unquote_0 = False
    static_0 = False
    route_0 = router_0.add(uri_0, methods_0, handler_0, host_0, strict_slashes_0, stream_0, ignore_body_0, version_0, name_0, unquote_0, static_0)
    view_

# Generated at 2022-06-26 04:07:30.426186
# Unit test for method finalize of class Router

# Generated at 2022-06-26 04:07:46.774875
# Unit test for constructor of class Router
def test_Router():
    bool_0 = None
    router_0 = Router(bool_0)
    router_0.ctx.opener = None
    router_0.ctx.app.websocket_max_size = 4096
    str_0 = "Host cannot be an IP address"
    router_0.ctx.app.error_handler.default_handler(NotImplementedError(str_0), router_0.ctx.app.error_handler.handlers)
    list_0 = list()
    router_0.ctx.app.exception(Exception, list_0)
    router_0.ctx.app.listeners = dict()
    dict_0 = dict()
    router_0.ctx.app.blueprints = dict_0
    router_0.ctx.app.config = dict()
    router_0.ctx.app.blueprint_

# Generated at 2022-06-26 04:07:58.013606
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    Unit test for method finalize of class Router

    """
    router_0 = Router(True)
    try:
        router_0.finalize()
    except Exception as exc:
        print(exc)


if __name__ == '__main__':

    # Unit test for method finalize of class Router
    test_Router_finalize()

    # Unit test for method add of class Router
    test_Router_add()

    # Unit test for method get of class Router
    test_Router_get()

    # Unit test for method get_routes of class Router
    test_Router_get_routes()

    # Unit test for method routes_all of class Router
    test_Router_routes_all()

    # Unit test for method routes_dynamic of class Router
    test_R

# Generated at 2022-06-26 04:08:01.983134
# Unit test for constructor of class Router
def test_Router():
    try:
        # test case to call Router with static parameters
        test_case_0()
    except Exception as e:
        print(e)


test_Router()

# Generated at 2022-06-26 04:08:04.270811
# Unit test for constructor of class Router
def test_Router():
    # Test cases

    # Test case 0
    test_case_0()

# Generated at 2022-06-26 04:08:10.667464
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router(None)
    assert attr.asdict(router_0) == attr.asdict(Router.__dict__['__init__'].__defaults__[0])

    router_1 = Router(1)
    assert attr.asdict(router_1) != attr.asdict(router_0)



# Generated at 2022-06-26 04:08:19.104112
# Unit test for method finalize of class Router
def test_Router_finalize():

    import tempfile

    with tempfile.TemporaryDirectory() as d:
        path_0 = os.path.join(d, "sanic-router0")
        print("path_0: %s" % (path_0))
        path_1 = os.path.join(d, "sanic-router1")
        path_2 = os.path.join(d, "sanic-router2")
        print("path_2: %s" % (path_2))
        path_3 = os.path.join(d, "sanic-router3")


# Generated at 2022-06-26 04:08:30.612920
# Unit test for constructor of class Router
def test_Router():
    # Test args
    bool_0 = None

    # Instantiation with arguments
    try:
        router_0 = Router(bool_0)
    except Exception as e:
        stderr_0 = str(e)

    # Instantiation without arguments
    router_0 = Router()

    # Instance attributes
    route_0 = router_0.route_0
    routes_all = router_0.routes_all
    routes_dynamic = router_0.routes_dynamic
    routes_regex = router_0.routes_regex
    routes_static = router_0.routes_static
    dynamic_routes = router_0.dynamic_routes
    name_index = router_0.name_index
    regex_routes = router_0.regex_rout

# Generated at 2022-06-26 04:08:36.596802
# Unit test for method finalize of class Router
def test_Router_finalize():
    bool_0 = None
    router_0 = Router(bool_0)
    bool_0 = False
    try:
        router_0.finalize(bool_0)
    except SanicException as e:
        print(e)


# Generated at 2022-06-26 04:08:37.283355
# Unit test for method finalize of class Router
def test_Router_finalize():
    pass

# Generated at 2022-06-26 04:08:39.209466
# Unit test for constructor of class Router
def test_Router():
    pass
    # TODO: write your test code here


# Generated at 2022-06-26 04:08:46.969580
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert type(router) != None

# Generated at 2022-06-26 04:08:51.654622
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    route_0 = Route()

    router_0.dynamic_routes = {str_0: route_0 for str_0 in [str_1, str_2]}
    router_0.static_routes = {str_0: route_0 for str_0 in reverse(str_0, str_1)}

    router_0.finalize()



# Generated at 2022-06-26 04:08:58.803833
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_1 = 'K`&n'
    callable_0 = None
    bool_0 = None
    router_1 = Router()
    var_0 = router_1.add(str_1, bool_0, callable_0, bool_0, bool_0, bool_0, bool_0)
    router_1.finalize()


# Generated at 2022-06-26 04:09:01.009600
# Unit test for method finalize of class Router
def test_Router_finalize():
    assert issubclass(Router, BaseRouter)


# Generated at 2022-06-26 04:09:06.549797
# Unit test for method finalize of class Router
def test_Router_finalize():
    # ---------------------------------------------------------------
    class Sanic:
        def _generate_name(self, view_name):
            '''
            Generate a full name for a view function.

            :param view_name: name of view.
            :return: full name of view
            '''
            return view_name

    # ---------------------------------------------------------------
    class MyRouter(Router):
        def finalize(self, app: Sanic):
            super().finalize(app)

        @property
        def dynamic_routes(self):
            return {'test': Route('', None, 'test', [])}

        @property
        def routes(self):
            return {'/': Route('', None, '', [])}

    # ---------------------------------------------------------------
    jordan_router = MyRouter()
    jordan_router.finalize

# Generated at 2022-06-26 04:09:08.845747
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    assert isinstance(router_0, BaseRouter)


# Generated at 2022-06-26 04:09:11.531774
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    # test for add method
    test_case_0()

# Generated at 2022-06-26 04:09:13.639183
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()

    test_case_0()

# Generated at 2022-06-26 04:09:23.380825
# Unit test for method finalize of class Router
def test_Router_finalize():
    int_0 = None
    int_1 = None
    str_0 = 'FL'
    callable_0 = None
    str_1 = 'qv2'
    router_0 = Router()
    router_0.finalize(int_0, str_0, str_1, int_1)
    router_0.finalize(int_0, str_0, str_1, int_1)
    router_0.finalize(int_0, str_0, str_1, int_1)
    router_0.finalize(int_0, str_0, str_1, int_1)
    router_0.finalize(int_0, str_0, str_1, int_1)
    router_0.finalize(int_0, str_0, str_1, int_1)


# Generated at 2022-06-26 04:09:24.709811
# Unit test for constructor of class Router
def test_Router():
    try:
        test_case_0()
    except Exception as e:
        print("Error in test_Router(): {}".format(e))
        assert False


# Generated at 2022-06-26 04:09:41.129555
# Unit test for method finalize of class Router
def test_Router_finalize():
    routes = router.routes_all
    router.finalize()
    assert len(routes) == len(router.routes_all)
    assert (
        router.find_route_by_view_name("test_finalize") == ("/test/finalize", None)
    )



# Generated at 2022-06-26 04:09:42.630460
# Unit test for constructor of class Router
def test_Router():
    router_1 = Router()


# Generated at 2022-06-26 04:09:45.893731
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    try:
        router_0.finalize(router_0)
    except Exception as e:
        print(e)

# Generated at 2022-06-26 04:09:52.689197
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_0 = '/'
    callable_0 = None
    router_0 = Router()
    dict_0 = dict()
    router_0.add(str_0, dict_0, callable_0, str_0, str_0, str_0, str_0, str_0)
    router_0.finalize()


# Generated at 2022-06-26 04:09:54.185135
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()


# Generated at 2022-06-26 04:10:04.486440
# Unit test for method add of class Router
def test_Router_add():
    int_0 = 1
    str_0 = '^ 2cXp8[buX'
    callable_0 = None
    bool_0 = None
    router_0 = Router()
    var_0 = router_0.add(str_0, bool_0, callable_0, str_0, bool_0, str_0, bool_0,
                         float_0=float(int_0), long_0=long(int_0), str_1=str_0, float_1=float(int_0),
                         float_2=float(int_0), char_0='a', short_0=int_0, str_2=str_0,
                         long_1=long(int_0),
                         long_2=long(int_0), byte_0=int_0)



# Generated at 2022-06-26 04:10:14.544400
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_0 = '1'
    str_1 = '0'
    str_2 = '3'
    str_3 = '6'
    str_4 = '4'
    str_5 = '2'
    str_6 = '8'
    str_7 = '7'
    str_8 = '5'
    str_9 = '9'
    str_10 = 'a'
    str_11 = 'b'
    str_12 = 'c'
    str_13 = 'd'
    str_14 = 'e'
    str_15 = 'f'
    str_16 = 'g'
    str_17 = 'h'
    str_18 = 'i'
    str_19 = 'j'
    str_20 = 'k'
    str_21 = 'l'
   

# Generated at 2022-06-26 04:10:24.781898
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    router_1 = Router()
    router_2 = Router()
    router_3 = Router()
    router_4 = Router()
    router_5 = Router()
    router_6 = Router()
    router_7 = Router()
    router_8 = Router()
    router_9 = Router()
    router_10 = Router()
    router_11 = Router()
    router_12 = Router()
    router_13 = Router()
    router_14 = Router()
    router_15 = Router()
    router_16 = Router()
    router_17 = Router()
    router_18 = Router()
    router_19 = Router()
    router_20 = Router()
    router_21 = Router()
    router_22 = Router()
    router_23 = Router()
    router_24 = Router()

# Generated at 2022-06-26 04:10:28.041638
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    return router_0


# Generated at 2022-06-26 04:10:29.442624
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

# Generated at 2022-06-26 04:10:45.859279
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_0 = '/'
    dict_0 = dict()
    router_0 = Router()
    var_0 = dict()
    router_0.add(str_0, var_0, var_0, str_0, str_0, str_0, str_0, str_0)
    var_1 = dict()
    router_0.add(str_0, var_0, var_0, str_0, str_0, str_0, str_0, str_0)
    router_0.finalize()


# Generated at 2022-06-26 04:10:47.458063
# Unit test for method finalize of class Router
def test_Router_finalize():
    var_0 = Router()


# Generated at 2022-06-26 04:10:53.522780
# Unit test for constructor of class Router
def test_Router():
    str_0 = '/'
    router_0 = Router()
    var_0 = dict()
    var_1 = router_0.add(str_0, var_0, var_0, str_0, str_0, str_0, str_0, str_0)



# Generated at 2022-06-26 04:11:00.855109
# Unit test for constructor of class Router
def test_Router():
    str_0 = '/'
    router_0 = Router()
    var_0 = dict()
    var_1 = router_0.add(var_0, var_0, var_0, str_0, str_0, str_0, str_0, str_0)


# Generated at 2022-06-26 04:11:04.196561
# Unit test for constructor of class Router
def test_Router():
    try:
        router_2 = Router()
        assert router_2 != None
    except Exception:
        assert False


# Generated at 2022-06-26 04:11:05.973932
# Unit test for constructor of class Router
def test_Router():
    pass


# Generated at 2022-06-26 04:11:12.469736
# Unit test for constructor of class Router
def test_Router():
    str_0 = '/'
    router_1 = Router()
    var_0 = dict()
    var_1 = router_1.add(str_0, var_0, var_0, str_0, str_0, str_0, str_0, str_0)



# Generated at 2022-06-26 04:11:14.678976
# Unit test for method finalize of class Router
def test_Router_finalize():
    unittest.main(exit=False)


# Generated at 2022-06-26 04:11:16.326096
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)
    assert isinstance(router, BaseRouter)

# Generated at 2022-06-26 04:11:17.603207
# Unit test for constructor of class Router
def test_Router():
    test_case_0()


# Generated at 2022-06-26 04:11:26.729868
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    router.add('/', {}, None)


# Generated at 2022-06-26 04:11:40.074390
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_0 = '/'
    router_0 = Router()
    var_0 = dict()
    var_1 = router_0.add(str_0, var_0, var_0, str_0, str_0, str_0, str_0, str_0)
    router_0.finalize()
    # Verify property routes_all set
    assert len(router_0.routes_all.keys()) == 1
    # Verify property routes_static set
    assert len(router_0.routes_static.keys()) == 0
    # Verify property routes_dynamic set
    assert len(router_0.routes_dynamic.keys()) == 1
    # Verify property routes_regex set
    assert len(router_0.routes_regex.keys()) == 0

# Generated at 2022-06-26 04:11:43.461677
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
        Sanity check for the Router class
        Sanity check for the finalize method
    """
    test_case_0()

# Generated at 2022-06-26 04:11:47.379983
# Unit test for constructor of class Router
def test_Router():
    # None
    var_0 = Router()

if __name__ == "__main__":
    print(test_Router())
    print(test_case_0())

# Generated at 2022-06-26 04:11:51.860148
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    router_0.finalize()
    assert router_0 != None
    # validate callbacks for the finalize method of class Router
    # TODO: validate all callbacks for the finalize method



# Generated at 2022-06-26 04:11:53.869937
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    assert isinstance(router_0, BaseRouter)
    # Check if ret is not none
    assert router_0 is not None

# Generated at 2022-06-26 04:12:00.222968
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_0 = '/'
    router_0 = Router()
    var_0 = dict()
    var_1 = router_0.add(str_0, var_0, var_0, str_0, str_0, str_0, str_0, str_0)
    var_2 = router_0.finalize()

# Generated at 2022-06-26 04:12:02.494955
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

if __name__ == '__main__':
    test_Router()

# Generated at 2022-06-26 04:12:07.442683
# Unit test for constructor of class Router
def test_Router():
    str_2 = '/'
    router_1 = Router()
    var_2 = dict()
    str_1 = 'get'
    print(router_1._get(str_2, str_1, str_2))
    var_3 = router_1.add(str_2, var_2, var_2, str_2, str_2, str_2, str_2, str_2)
    print(var_3)


# Generated at 2022-06-26 04:12:17.534523
# Unit test for constructor of class Router
def test_Router():
    str_0 = '/'
    router_0 = Router()
    var_0 = dict()
    var_1 = router_0.add(str_0, var_0, var_0, str_0, str_0, str_0, str_0, str_0)
    var_2 = router_0.get(str_0, str_0, str_0)
    var_3 = router_0.find_route_by_view_name(str_0, str_0)
    var_4 = router_0.finalize(var_3, var_1, var_0, var_0, str_0, str_0, str_0, str_0, str_0, str_0)

# Generated at 2022-06-26 04:12:31.682086
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        str_0 = '/'
        router_0 = Router()
        var_0 = dict()
        var_1 = router_0.add(str_0, var_0, var_0, str_0, str_0, str_0, str_0, str_0)
        router_0.finalize()
    except Exception as exception_0:
        var_2 = exception_0

# Generated at 2022-06-26 04:12:38.069740
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_0 = '/'
    router_0 = Router()
    var_0 = dict()
    var_1 = router_0.add(str_0, var_0, var_0, str_0, str_0, str_0, str_0, str_0)
    if random.random() > 0.5:
        var_2 = router_0.finalize(str_0)
    else:
        var_3 = router_0.finalize()
    router_0.finalize(str_0)


# Generated at 2022-06-26 04:12:47.550501
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Keys: ['', 'route_0', 'route_3', 'route_2', 'route_1']
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_4 = dict()
    dict_5 = dict()
    dict_6 = dict()
    dict_7 = dict()
    dict_8 = dict()

    dict_0['__label_1'] = 'method'
    dict_0['__label_0'] = 'path'

    dict_1['__label_1'] = 'route_2'
    dict_1['__label_0'] = '__file_uri__'

    dict_2['__label_1'] = 'route_1'

# Generated at 2022-06-26 04:12:56.424917
# Unit test for constructor of class Router
def test_Router():
    # Initialization
    router_0 = Router()
    # Operation
    router_0.finalize()
    # Verification
    str_0 = '/'
    var_0 = dict()
    var_1 = router_0.add(str_0, var_0, var_0, str_0, str_0, str_0, str_0, str_0)



# Generated at 2022-06-26 04:13:00.787819
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.name_index == dict()
    assert router.routes_all == dict()
    assert router.routes_static == dict()
    assert router.routes_dynamic == dict()
    assert router.routes_regex == dict()
    assert router.ctx == dict()
    assert router.base_path == ''
    assert router.error_handler == dict()
    assert router.error_handler_type == dict()


# Generated at 2022-06-26 04:13:11.498606
# Unit test for constructor of class Router
def test_Router():
    assert issubclass(Router, BaseRouter)
    assert Router._get.__code__.co_argcount == 4
    assert Router.get.__code__.co_argcount == 4
    assert Router.get.__code__.co_varnames == ('self', 'path', 'method', 'host')
    assert Router.get.__code__.co_argcount == 4
    assert Router.get.__code__.co_varnames == ('self', 'path', 'method', 'host')


# Generated at 2022-06-26 04:13:12.782999
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_case_0()

# Generated at 2022-06-26 04:13:15.605850
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    Test method finalize of class Router
    """
    # Setup phase
    test_case_0()

# Generated at 2022-06-26 04:13:22.611260
# Unit test for constructor of class Router
def test_Router():
    str_0 = '/'
    router_0 = Router()
    var_0 = dict()
    var_1 = router_0.add(str_0, var_0, var_0, str_0, str_0, str_0, str_0, str_0)
    var_2 = router_0.get_host(str_0)

# Generated at 2022-06-26 04:13:34.747213
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Setup
    args = (1, 2)
    kwargs = {"key1": 1, "key2": 2}
    router = Router()
    static_route = router.add(path="/", handler=lambda r: [], static=True)
    dynamic_route = router.add(path="/", handler=lambda r: [], static=False)

    # Unit under test
    router.finalize(*args, **kwargs)

    # Asserts
    assert static_route.ctx.args == args
    assert static_route.ctx.kwargs == kwargs
    assert dynamic_route.ctx.args == args
    assert dynamic_route.ctx.kwargs == kwargs



# Generated at 2022-06-26 04:13:45.044584
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

if __name__ == '__main__':
    test_Router()

# Generated at 2022-06-26 04:13:46.750980
# Unit test for constructor of class Router
def test_Router():
    router = Router()


# Generated at 2022-06-26 04:13:58.688925
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_0 = '/'
    router_0 = Router()
    var_0 = dict()
    var_1 = router_0.add(str_0, var_0, var_0, str_0, str_0, str_0, str_0, str_0)
    router_1 = Router()
    var_2 = dict()
    var_3 = router_1.add(str_0, var_0, var_0, str_0, str_0, str_0, str_0, str_0)
    str_1 = '__file_uri__'
    str_2 = '__something__'
    str_3 = '__something_else__'
    str_4 = f"/<{str_1}>"
    def func_0():
        return str_0

# Generated at 2022-06-26 04:14:08.900767
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_0 = '/user/<string>'
    # Variables initialization
    router_0 = Router()
    var_0 = dict()
    var_1 = router_0.add(str_0, var_0, var_0, str_0, str_0, str_0, str_0, str_0)
    try:
        # Test method finalize of class Router
        router_0.finalize()

    except SanicException as e_0:
        var_2 = e_0.args
        print(*var_2)



# Generated at 2022-06-26 04:14:12.052215
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    var_0 = router_0.finalize()
    assert var_0 == None

# Generated at 2022-06-26 04:14:14.586514
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    var_0 = None
    router_0.finalize(var_0)

# Generated at 2022-06-26 04:14:18.190746
# Unit test for constructor of class Router
def test_Router():
    str_0 = Cache_maxsize_set
    str_1 = dict()
    str_2 = dict()
    var_2 = Router(str_0, str_1, str_2)


# Generated at 2022-06-26 04:14:26.475715
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_0 = '/'
    router_0 = Router()
    var_0 = dict()
    var_1 = router_0.add(str_0, var_0, var_0, str_0, str_0, str_0, str_0, str_0)
    router_0.finalize()

# Generated at 2022-06-26 04:14:31.389096
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_0 = '/'
    router_0 = Router()
    var_0 = dict()
    router_0.add(str_0, var_0, var_0, str_0, str_0, str_0, str_0, str_0)
    router_0.finalize()



# Generated at 2022-06-26 04:14:32.457915
# Unit test for constructor of class Router
def test_Router():
    # This test is not implemented yet
    assert False


# Generated at 2022-06-26 04:14:47.161216
# Unit test for constructor of class Router
def test_Router():
    obj_0 = Router()
    assert obj_0.allowed_methods == ['GET', 'POST', 'OPTIONS', 'HEAD', 'PUT', 'PATCH', 'DELETE', 'TRACE']
    assert obj_0.ctx.app is None
    assert obj_0.routes == dict()
    assert obj_0.static_routes == dict()
    assert obj_0.dynamic_routes == dict()
    assert obj_0.regex_routes == dict()


# Generated at 2022-06-26 04:14:52.213635
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_0 = '/'
    router_0 = Router()
    var_0 = dict()
    var_1 = router_0.add(str_0, var_0, var_0, str_0, str_0, str_0, str_0, str_0)
    router_0.finalize()

# Generated at 2022-06-26 04:14:59.862683
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_0 = '/'
    router_0 = Router()
    var_0 = dict()
    var_1 = router_0.add(str_0, var_0, var_0, str_0, str_0, str_0, str_0, str_0)

    router_0.finalize()

# Generated at 2022-06-26 04:15:02.072435
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        test_case_0()
    except:
        print("OK")

# Run test cases
test_Router_finalize()

# Generated at 2022-06-26 04:15:04.226724
# Unit test for constructor of class Router
def test_Router():
    x = Router()
    assert type(x) == Router


# Generated at 2022-06-26 04:15:12.434401
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    assert router_0.ctx is None
    assert router_0.options is None
    assert router_0.requirements is None
    assert router_0.regex_routes == dict()
    assert router_0.routes == dict()
    assert router_0.static_routes == dict()
    assert router_0.dynamic_routes == dict()
    assert router_0.name_index == dict()



# Generated at 2022-06-26 04:15:24.468026
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_0 = '/'
    router_0 = Router()
    var_0 = dict()
    var_1 = router_0.add(str_0, var_0, var_0, str_0, str_0, str_0, str_0, str_0)
    router_0 = Router()
    var_0 = dict()
    var_1 = router_0.add(str_0, var_0, var_0, str_0, str_0, str_0, str_0, str_0)
    router_0 = Router()
    var_0 = dict()
    var_1 = router_0.add(str_0, var_0, var_0, str_0, str_0, str_0, str_0, str_0)
    router_0 = Router()
    var_

# Generated at 2022-06-26 04:15:29.810619
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_0 = '/'
    router_0 = Router()
    var_0 = dict()
    var_1 = router_0.add(str_0, var_0, var_0, str_0, str_0, str_0, str_0, str_0)
    x_0 = router_0.routes
    x_1 = router_0.routes_static
    x_2 = router_0.routes_dynamic
    x_3 = router_0.routes_regex
    x_4 = router_0.dynamic_routes
    x_5 = router_0.regex_routes
    x_6 = router_0.static_routes
    x_7 = not router_0.is_finalized
    router_0.finalize()
