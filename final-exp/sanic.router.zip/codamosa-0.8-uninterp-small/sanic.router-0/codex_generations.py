

# Generated at 2022-06-26 04:05:51.186941
# Unit test for constructor of class Router
def test_Router():
    router_1 = Router(None)
    router_1.add(uri='', methods=None, handler=None, strict_slashes=False, version=None, stream=False, ignore_body=False, unquote=False, name=None)
    router_1.add(uri='', methods=[], handler=None, strict_slashes=False, version=None, stream=False, ignore_body=False, unquote=False, name=None)
    router_1.add(uri='', methods=[], handler=None, strict_slashes=True, version=None, stream=False, ignore_body=False, unquote=False, name=None)
    router_1.get(path='', method='', host='')
    router_1.get(path='', method='', host=None)
    router_1.find_route

# Generated at 2022-06-26 04:05:58.934092
# Unit test for method finalize of class Router
def test_Router_finalize():
    type_0 = None
    router_0 = Router(type_0)
    router_0.finalize()


# Generated at 2022-06-26 04:06:03.638199
# Unit test for method finalize of class Router
def test_Router_finalize():
    type_0 = None
    router_0 = Router(type_0)
    str_0 = ''
    router_0.finalize('', str_0)


# Generated at 2022-06-26 04:06:07.473830
# Unit test for method finalize of class Router
def test_Router_finalize():
    type_0 = None
    router_0 = Router(type_0)
    # Finalize the router
    router_0.finalize()


# Generated at 2022-06-26 04:06:11.387587
# Unit test for method finalize of class Router
def test_Router_finalize():
    type_0 = None
    router_0 = Router(type_0)
    assert_raises(SanicException, router_0.finalize)


# Generated at 2022-06-26 04:06:16.997346
# Unit test for constructor of class Router
def test_Router():
    # Check if we can create a Router object
    router_0 = Router()

    type_0 = None
    router_1 = Router(type_0)


# Generated at 2022-06-26 04:06:26.191611
# Unit test for method finalize of class Router
def test_Router_finalize():
    type_0 = None
    router_0 = Router(type_0)

    # check case 1
    type_0 = None
    router_0 = Router(type_0)
    result_0 = router_0.finalize()
    assert not result_0, "Expected true"

    # check case 2
    type_0 = None
    router_0 = Router(type_0)
    result_0 = router_0.finalize()
    assert not result_0, "Expected true"

    # check case 3
    type_0 = None
    router_0 = Router(type_0)
    result_0 = router_0.finalize()
    assert not result_0, "Expected true"


# Generated at 2022-06-26 04:06:30.380110
# Unit test for method finalize of class Router
def test_Router_finalize():
    type_0 = None
    router_0 = Router(type_0)
    try:
        router_0.finalize()
    except Exception as e:
        instance_0 = None
        assert type(instance_0) is type(e)
    else:
        assert True



# Generated at 2022-06-26 04:06:35.994862
# Unit test for method finalize of class Router
def test_Router_finalize():
    type_0 = None
    router_0 = Router(type_0)
    try:
        router_0.finalize()
    except Exception as e:
        print(e)


# Generated at 2022-06-26 04:06:37.595158
# Unit test for constructor of class Router
def test_Router():
    type_0 = None
    router_0 = Router(type_0)


# Generated at 2022-06-26 04:06:50.067453
# Unit test for constructor of class Router
def test_Router():
    assert (Router.__dict__.keys()) == {'DEFAULT_METHOD', 'ALLOWED_METHODS', '__init__', '_get', 'get', 'add', 'find_route_by_view_name', 'routes_all', 'routes_static', 'routes_dynamic', 'routes_regex', 'finalize'}
    assert isinstance(Router(Router).__dict__, dict)
    assert isinstance(Router.__init__(Router), None)
    assert isinstance(Router.__init__(Router, Router), None)

# Generated at 2022-06-26 04:07:01.444467
# Unit test for constructor of class Router
def test_Router():
    type_0: Optional[Type[BaseRouter]] = None
    router_0 = Router(type_0)
    uri_0: str = ""
    methods_0: Iterable[str] = []
    handler_0: Union[coroutine, types.FunctionType] = lambda: None
    host_0: Optional[Union[str, Iterable[str]]] = None
    strict_slashes_0: bool = False
    stream_0: bool = False
    ignore_body_0: bool = False
    version_0: Union[str, float, int] = ""
    name_0: Optional[str] = ""
    unquote_0: bool = False
    static_0: bool = False

# Generated at 2022-06-26 04:07:06.822898
# Unit test for method finalize of class Router
def test_Router_finalize():
    type_0 = None
    router_0 = Router(type_0)
    try:
        router_0.finalize()
        assert True
    except:
        assert False


# Generated at 2022-06-26 04:07:15.412697
# Unit test for method add of class Router
def test_Router_add():
    type_0 = None
    router_0 = Router(type_0)
    uri_0 = ''
    methods_0 = [
        '',
        ''
    ]
    handler_0 = (lambda a: None)
    host_0 = None
    strict_slashes_0 = False
    stream_0 = False
    ignore_body_0 = False
    version_0 = None
    name_0 = None
    unquote_0 = False
    static_0 = False
    route_0 = router_0.add(uri_0, methods_0, handler_0, host_0, strict_slashes_0, stream_0, ignore_body_0, version_0, name_0, unquote_0, static_0)


# Generated at 2022-06-26 04:07:16.802959
# Unit test for constructor of class Router
def test_Router():
    try:
        test_case_0()
    except SanicException as e:
        print(e)


if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-26 04:07:24.310148
# Unit test for constructor of class Router
def test_Router():
    type_0 = None
    router_0 = Router(type_0)
    route_handler_0 = {}
    uri_0 = "zU6"
    methods_0 = set()
    host_0 = ""
    strict_slashes_0 = True
    stream_0 = True
    ignore_body_0 = False
    version_0 = -5
    name_0 = "|x"
    unquote_0 = True
    static_0 = True
    router_0.add(uri_0, methods_0, route_handler_0, host_0, strict_slashes_0, stream_0, ignore_body_0, version_0, name_0, unquote_0, static_0)
    path_0 = "n"
    method_0 = "-"
    host_1 = "e"

# Generated at 2022-06-26 04:07:28.159911
# Unit test for constructor of class Router
def test_Router():
    type_0 = None
    router_0 = Router(type_0)
    assert router_0 is not None


# Generated at 2022-06-26 04:07:30.918939
# Unit test for constructor of class Router
def test_Router():
    type_0 = None
    router_0 = Router(type_0)


# Generated at 2022-06-26 04:07:33.252788
# Unit test for method finalize of class Router
def test_Router_finalize():
    type_0 = None
    router_0 = Router(type_0)
    router_0.finalize()

# Generated at 2022-06-26 04:07:38.489731
# Unit test for method finalize of class Router
def test_Router_finalize():
    type_0 = None
    router_0 = Router(type_0)
    try:
        router_1 = router_0.finalize()
    except:
        pass


# Generated at 2022-06-26 04:07:46.130734
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_case_0()

# Generated at 2022-06-26 04:07:50.615673
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Assigning variable
    var_0 = Router()

    # Invoking method finalize
    test_case_0()

    # Assigning variable
    var_0 = None


# Generated at 2022-06-26 04:07:51.629500
# Unit test for constructor of class Router
def test_Router():
    obj = Router(var_0)
    assert isinstance(obj, Router)


# Generated at 2022-06-26 04:07:53.381098
# Unit test for constructor of class Router
def test_Router():
    print("\n\n")
    print("test_Router")
    print("-----------")
    var_0 = Router()



test_case_0()
test_Router()

# Generated at 2022-06-26 04:07:54.602454
# Unit test for constructor of class Router
def test_Router():
    obj = Router(app=var_0)
    assert isinstance(obj, Router)

test_case_0()

# Generated at 2022-06-26 04:08:08.095239
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic

    class TestCase0(unittest.TestCase):
        def test_0(self):
            var_0 = Sanic("sanic-app")

            # Class 'Router' supports static method 'finalize'
            # Type check: 'method'
            assert hasattr(Router, "finalize")
            # Type check: 'function' -> 'Callable'
            assert isinstance(Router.finalize, Callable)
            # Type check: 'instance'
            assert isinstance(var_0.router, Router)
            # Type check: 'method'
            assert hasattr(var_0.router, "finalize")
            # Type check: 'function' -> 'Callable'
            assert isinstance(var_0.router.finalize, Callable)


# Generated at 2022-06-26 04:08:18.491155
# Unit test for method finalize of class Router
def test_Router_finalize():
    var_0 = Router()

# Generated at 2022-06-26 04:08:27.152628
# Unit test for constructor of class Router
def test_Router():
    router: Router = Router()
    assert router.name_index == {}
    assert router._path_index == {}
    assert router._method_index == {}
    assert router._host_index == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.static_routes == {}
    assert router.routes == {}
    assert router.ctx is None


# Generated at 2022-06-26 04:08:29.175252
# Unit test for constructor of class Router
def test_Router():
    router = Router(None)
    assert router



# Generated at 2022-06-26 04:08:34.954490
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Setup test.
    var_0 = None

    # Assertion setup
    assert var_0 is None

    # Execute code under test.
    test_case_0()

    # Verify postconditions.


# Generated at 2022-06-26 04:08:43.532274
# Unit test for method finalize of class Router
def test_Router_finalize():
    var_0 = Router()
    try:
        var_0.finalize()
    except Exception as e:
        print(e)


# Generated at 2022-06-26 04:08:51.790144
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    finalize_type = None
    finalize_type_1 = type(finalize_type)
    router.add('/user/<id>', ['GET'], finalize_type_1()) # issue 1
    router.add('/user/<id>', ['GET'], finalize_type_1()) # issue 3
    router.add('/user/<id>', ['GET'], finalize_type_1()) # issue 4


if __name__ == '__main__':
    test_case_0()
    test_Router_finalize()

# Generated at 2022-06-26 04:08:54.671636
# Unit test for method finalize of class Router
def test_Router_finalize():
    var_0 = Router(None)
    try:
        var_0.finalize()
    except Exception:
        pass

# Generated at 2022-06-26 04:08:56.720740
# Unit test for constructor of class Router
def test_Router():
    var_0 = Router()
    assert var_0 is not None


# Generated at 2022-06-26 04:08:59.742133
# Unit test for method finalize of class Router
def test_Router_finalize():
    var_0 = Router()
    try:
        var_0.finalize()
    except Exception:
        var_1 = None
    else:
        var_1 = False
    assert var_1


# Generated at 2022-06-26 04:09:04.247521
# Unit test for method finalize of class Router
def test_Router_finalize():
    var_0 = Router()
    try:
        var_0.finalize()
    except Exception:
        var_1 = 1
    else:
        var_1 = 0
    assert var_1


# Generated at 2022-06-26 04:09:07.582773
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()

    try:
        router.finalize()
        assert True
    except:
        assert False


# Generated at 2022-06-26 04:09:12.556877
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    try:
        router.get("/users/me/<id>/foo", "GET", "example.com")
    except NotFound as e:
        assert str(e) == "Requested URL /users/me/<id>/foo not found"

    try:
        router.get("/users/me", "GET", "example.com")
    except MethodNotSupported as e:
        assert str(e) == "Method GET not allowed for URL /users/me"

    # parameters to function Router.__init__
    # unquote: bool = False
    # case_insensitive: bool = False
    # default_method: Optional[str] = 'GET'
    # allowed_methods: Optional[Iterable[str]] = None
    # host_matching: bool = False
    # label_separ

# Generated at 2022-06-26 04:09:13.574573
# Unit test for constructor of class Router
def test_Router():
    var_0 = Router()
    print(var_0)


# Generated at 2022-06-26 04:09:15.711835
# Unit test for constructor of class Router
def test_Router():
    obj = Router()
    var_0 = obj.ctx


# Generated at 2022-06-26 04:09:27.945445
# Unit test for method finalize of class Router
def test_Router_finalize():
    # TODO: Implement test
    return True



# Generated at 2022-06-26 04:09:29.752983
# Unit test for constructor of class Router
def test_Router():
    router = Router()


# Generated at 2022-06-26 04:09:30.970855
# Unit test for constructor of class Router
def test_Router():
    var_1 = Router()
    var_2 = Router(None)


# Generated at 2022-06-26 04:09:43.906408
# Unit test for method finalize of class Router
def test_Router_finalize():
    code0 = inspect.getsource(test_case_0)
    AST0 = ast.parse(code0)
    # print(astunparse.unparse(AST0))
    node0 = AST0.body[0]
    assign_targets0 = node0.targets
    vartable0 = {}
    for assign_target0 in assign_targets0:
        vartable0[assign_target0.id] = node0
    # print(vartable0)
    node1 = AST0.body[1]
    assign_targets1 = node1.targets
    vartable1 = {}
    for assign_target1 in assign_targets1:
        vartable1[assign_target1.id] = node1
    # print(vartable1)



# Generated at 2022-06-26 04:09:50.761908
# Unit test for method finalize of class Router
def test_Router_finalize():
    var_1 = None

    # Application code
    class Sanic:
        pass

    class Route:
        pass

    var_1 =  Router()
    var_2 =  Sanic()
    var_3 =  Route()
    var_1.finalize(var_2)


# Generated at 2022-06-26 04:09:52.108696
# Unit test for constructor of class Router
def test_Router():
    var_0 = Router()


# Generated at 2022-06-26 04:09:54.126945
# Unit test for constructor of class Router
def test_Router():
    r = Router()


# Generated at 2022-06-26 04:10:04.452936
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    from sanic.router_helpers import _default_router_factory

    # Creating app
    app = Sanic(__name__)

    # Assigning var_0 to "test_case_0"
    # Creating variable var_1 with value of 0
    var_1 = 0
    try:
        # Testing if call of method test_case_0 throws an exception
        test_case_0()
    except:
        # Increment var_1 by 1
        var_1 += 1

    # If var_1 is not equal to 0, var_0 will be assigned to "test_case_0"
    if var_1 != 0:
        var_0 = "test_case_0"

# Generated at 2022-06-26 04:10:05.997894
# Unit test for constructor of class Router
def test_Router():
    try:
        test_case_0()
    except Exception as e:
        print(e)

if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-26 04:10:09.544279
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add("/",["GET"],"test_case_0()")
    router.finalize()

# Generated at 2022-06-26 04:10:22.382516
# Unit test for constructor of class Router
def test_Router():
    # Test simple case
    var_0 = Router(prefix="__prefix__")
    assert var_0 is not None


# Generated at 2022-06-26 04:10:29.372234
# Unit test for constructor of class Router
def test_Router():
    c = Router()
    assert isinstance(c, BaseRouter) == True
    assert isinstance(c, Router) == True
    assert c.DEFAULT_METHOD == "GET"
    assert c.ALLOWED_METHODS == HTTP_METHODS


# Generated at 2022-06-26 04:10:32.200759
# Unit test for constructor of class Router
def test_Router():
    var_0 = Router()
    return None


# Generated at 2022-06-26 04:10:37.236873
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router as RouterClass

    var_1 = RouterClass()

    var_2 = None
    try:
        var_1.finalize()
    except:
        var_2 = "Exception was raised"

    if var_2 == "Exception was raised":
        print("Test for method finalize of class Router failed!")
    else:
        print("Test for method finalize of class Router succeeded!")

    return var_2


# Generated at 2022-06-26 04:10:41.848177
# Unit test for method add of class Router
def test_Router_add():
    try:
        router = Router()
        router.add('/test1', ['GET'], test_case_0)
        status = True
    except:
        status = False
    assert status

# Generated at 2022-06-26 04:10:47.467510
# Unit test for constructor of class Router
def test_Router():
    a = Router()
    assert isinstance(a, BaseRouter) == True
    assert isinstance(a, Router) == True
    assert isinstance(a.routes, dict) == True
    assert isinstance(a.routes_regex, dict) == True
    assert isinstance(a.routes_static, dict) == True
    assert isinstance(a.routes_dynamic, dict) == True
    assert isinstance(a.ipv6_hosts, list) == True
    assert isinstance(a.ctx, dict) == True
    assert isinstance(a.name_index, dict) == True


# Generated at 2022-06-26 04:10:53.877899
# Unit test for constructor of class Router
def test_Router():
    try:
        var_1 = Router(None)
    except Exception as e:
        print(e)

    try:
        var_2 = Router([])
    except Exception as e:
        print(e)

    try:
        var_3 = Router({})
    except Exception as e:
        print(e)


# Generated at 2022-06-26 04:10:56.432862
# Unit test for constructor of class Router
def test_Router():
    # Verify that the constructor of Router is working correctly
    router = Router()
    assert router is not None


# Generated at 2022-06-26 04:10:58.744913
# Unit test for constructor of class Router
def test_Router():
    test_case_0()


# Generated at 2022-06-26 04:11:02.079863
# Unit test for constructor of class Router
def test_Router():
    try:
        var_1 = Router()
    except Exception:
        var_1 = None
    assert var_1 is not None


# Generated at 2022-06-26 04:11:20.164003
# Unit test for constructor of class Router
def test_Router():
    from sanic_routing import Router as Router0
    Router()
    var_0 = Router0()
    var_0.validate_rules()
    var_2 = []
    var_0.add(var_2, 'test_case_0', test_case_0)
    var_0.get('test_case_0', 'test_case_0')
    var_0.get('test_case_0', 'test_case_0')
    var_0.get('test_case_0', 'test_case_0')
    var_0.get('test_case_0', 'test_case_0')
    var_0.get('test_case_0', 'test_case_0')
    var_0.get('test_case_0', 'test_case_0')
    var_0

# Generated at 2022-06-26 04:11:26.221459
# Unit test for constructor of class Router
def test_Router():
    from sanic.exceptions import SanicException
    try:
        var_0 = test_case_0()
    except SanicException:
        var_1 = None
    else:
        var_1 = "big enough"
    return


# Generated at 2022-06-26 04:11:32.692959
# Unit test for constructor of class Router
def test_Router():
    # Empty constructor
    router = Router(None)

    # Check if the object is constructed successfully
    if router is not None:
        print("Router object was constructed successfully")
    else:
        print("Router object was constructed unsuccessfully")

test_case_0()

# Generated at 2022-06-26 04:11:34.878682
# Unit test for method finalize of class Router
def test_Router_finalize():
    route_table = Router()
    test_case_0()


# Generated at 2022-06-26 04:11:37.023604
# Unit test for constructor of class Router
def test_Router():
    assert(isinstance(Router(), Router))


# Generated at 2022-06-26 04:11:38.631710
# Unit test for constructor of class Router
def test_Router():
    var_0 = Router()


# Generated at 2022-06-26 04:11:42.867322
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    r.ctx.app = None
    assert isinstance(r.ctx, Router)
    assert isinstance(r.ctx.app, None)



# Generated at 2022-06-26 04:11:48.007701
# Unit test for method finalize of class Router
def test_Router_finalize():
    var_1 = Router(
        app=None,
        prefix=None,
        host=None,
        strict_slashes=None,
        version=None,
        name_index=None
    )
    var_1.finalize()


# Generated at 2022-06-26 04:11:48.958447
# Unit test for method finalize of class Router
def test_Router_finalize():
    var_0 = None


# Generated at 2022-06-26 04:11:50.197904
# Unit test for method finalize of class Router
def test_Router_finalize():
    var_0 = Router()
    var_0.finalize()


# Generated at 2022-06-26 04:12:12.108441
# Unit test for method finalize of class Router
def test_Router_finalize():
    for arg_0 in [None]:
        try:
            test_case_0()
        except:
            print("Exception: test_case_0")


# Generated at 2022-06-26 04:12:24.083709
# Unit test for method finalize of class Router
def test_Router_finalize():

    # no duplicated routes
    r = Router(finalize=False)
    r.add("/test/<param>", ["GET", "POST"], lambda x: x)
    r.add("/test/<param>", ["GET", "POST"], lambda x: x)
    r.finalize()

    # duplicated routes
    r = Router(finalize=False)
    r.add("/test/<param>", ["GET", "POST"], lambda x: x)
    r.add("/test/<param>", ["GET", "POST"], lambda x: x)
    r.finalize()

# This is for searching for the test_Router_finalize
# error_index = [[0, 0]]

# Generated at 2022-06-26 04:12:25.011128
# Unit test for method finalize of class Router
def test_Router_finalize():
    param_0 = None

    test_case_0()


# Generated at 2022-06-26 04:12:26.346589
# Unit test for method finalize of class Router
def test_Router_finalize():
    var_0 = None
    test_case_0()



# Generated at 2022-06-26 04:12:28.099130
# Unit test for constructor of class Router
def test_Router():
    router = Router()


# Generated at 2022-06-26 04:12:29.849809
# Unit test for constructor of class Router
def test_Router():
    # init
    var_1 = Router(
        prefix="/",
        name="",
        handler=None,
        host="",
        middleware=None,
        strict_slashes=False,
        unquote=False,
    )


# Generated at 2022-06-26 04:12:33.094566
# Unit test for method finalize of class Router
def test_Router_finalize():
    var_0 = Router()
    var_0.finalize(None)


# Generated at 2022-06-26 04:12:35.155394
# Unit test for constructor of class Router
def test_Router():

    # Test the constructor
    r1 = Router()

    return r1


# Generated at 2022-06-26 04:12:38.210547
# Unit test for constructor of class Router
def test_Router():
    test_case_0()
    Router()

if __name__ == '__main__':
    test_Router()

# Generated at 2022-06-26 04:12:40.077894
# Unit test for constructor of class Router
def test_Router():
    var_0 = Router()
    return var_0 == None

# Test case entry function

# Generated at 2022-06-26 04:13:17.844690
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.finalize()


# Generated at 2022-06-26 04:13:19.920180
# Unit test for method finalize of class Router
def test_Router_finalize():
    class_0 = Router()
    var_0 = None



# Generated at 2022-06-26 04:13:21.803457
# Unit test for method add of class Router
def test_Router_add():
    test_router = Router()
    test_router.add("/hello", ["GET"], None, None, False, False, False, None, None, False, True)


# Generated at 2022-06-26 04:13:22.461298
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

# Generated at 2022-06-26 04:13:23.902294
# Unit test for constructor of class Router
def test_Router():
    r_obj = Router()


# Generated at 2022-06-26 04:13:36.592924
# Unit test for method finalize of class Router
def test_Router_finalize():
    var_0 = None
    var_0 = Router()
    var_1 = None
    var_1 = var_0.finalize()
    var_2 = None
    var_3 = []
    var_3.append("dynamic_routes")
    var_3.append("routes")
    var_3.append("routes_dynamic")
    var_3.append("routes_regex")
    var_3.append("routes_regex_dict")
    var_3.append("routes_static")
    var_3.append("static_routes")
    var_2 = any(var_1.__contains__(var_4) for var_4 in var_3)
    return var_2


# Generated at 2022-06-26 04:13:47.460344
# Unit test for constructor of class Router
def test_Router():
    from sanic.router import Route
    from sanic.router import RouteResult
    from sanic.router import Router
    from sanic.router import VersionedRouter
    from sanic.router import RouterError
    from sanic.router import RouterDict
    from sanic.router import RouterDict_set

    # --------------------------- Initialization ---------------------------
    # Create an instance of class Router
    # Test case #0
    try:
        obj_0 = Router()
        assert obj_0 is not None
    except TypeError as e:
        print("TypeError: Router(): {}".format(e))


    # --------------------------- Methods ---------------------------
    # Test add method of class Router
    # Test case #0

# Generated at 2022-06-26 04:13:57.079600
# Unit test for method finalize of class Router
def test_Router_finalize():
    var_0 = Router()
    var_0.finalize()
    assert var_0.routes_dynamic == {}
    assert var_0.routes_regex == []
    assert var_0.routes_all == []
    assert var_0.routes_static == []
    assert var_0.routes_dynamic == {}
    assert var_0.routes_regex == []
    assert var_0.routes_all == []
    assert var_0.routes_static == []


# Generated at 2022-06-26 04:13:58.676453
# Unit test for constructor of class Router
def test_Router():
    assert type(Router()) == Router


# Generated at 2022-06-26 04:14:03.808378
# Unit test for method finalize of class Router
def test_Router_finalize():
    var_5 = Router()
    with pytest.raises(SanicException, match="Parameter names cannot use '__'."):
        var_5.finalize()


# Generated at 2022-06-26 04:14:42.429021
# Unit test for constructor of class Router
def test_Router():
    try:
        test_case_0()
        ans = True
    except:
        ans = False
    finally:
        assert ans

if __name__ == '__main__':
    test_Router()

    # Test whether the unit test is useful
    assert Router().routes_all == Router().routes

# Generated at 2022-06-26 04:14:45.718458
# Unit test for constructor of class Router
def test_Router():
    var_0 = Router()
    assert isinstance(var_0, Router)


# Generated at 2022-06-26 04:14:50.351488
# Unit test for method finalize of class Router
def test_Router_finalize():
    if True:
        var_0 = Router()
        test_case_0()


if __name__ == "__main__":
    test_Router_finalize()

# Generated at 2022-06-26 04:14:51.509436
# Unit test for constructor of class Router
def test_Router():
    var_0 = Router()


# Generated at 2022-06-26 04:14:55.393277
# Unit test for constructor of class Router
def test_Router():
    var_0 = Router('/home')
    var_1 = Router()


# Generated at 2022-06-26 04:14:58.409408
# Unit test for method finalize of class Router
def test_Router_finalize():
    var_0 = None
    var_0 = Router()
    var_0.finalize()


# Generated at 2022-06-26 04:15:05.957841
# Unit test for constructor of class Router
def test_Router():
    # Test case for function _get
    # var_0
    path = '/post/'
    method = 'GET'
    host = None
    test_case_0()
    test_var_1 = None
    assert test_var_1 == None
    # Test case for function add
    # var_0
    uri = '/v2/users'
    # var_1
    methods = http_methods_0
    # var_2
    handler = function_0
    # var_3
    host = None
    # var_4
    strict_slashes = False
    # var_5
    stream = False
    # var_6
    ignore_body = False
    # var_7
    version = 'v2'
    # var_8
    name = 'get_user'
    # var_9

# Generated at 2022-06-26 04:15:11.063520
# Unit test for constructor of class Router
def test_Router():
    # The assignment of value to some_var_name is necessary to ensure that
    # stmt_0 is an expression statement and not an assignment statement.
    (var_0,) = (None,)
    assert var_0 is None


# Generated at 2022-06-26 04:15:21.096242
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()

    # Call test_case_0
    try:
        router.finalize(var_0)
    except SanicException as exception:
        assert exception.message == 'Invalid route: Route(path="/{__label_0}", method="GET", handler=None, ctx=Context(hosts=[], static=False, stream=False, ignore_body=False), name=None, requirements=None, name_prefix=None, host=None, strict=False, unquote=False). Parameter names cannot use "__".'


# Generated at 2022-06-26 04:15:22.082980
# Unit test for method finalize of class Router
def test_Router_finalize():
    assert Router()
    var = None

