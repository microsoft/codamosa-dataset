

# Generated at 2022-06-26 04:05:46.437774
# Unit test for constructor of class Router
def test_Router():
    router_1 = Router()
    router_2 = Router()
    assert router_1 is not router_2


# Generated at 2022-06-26 04:05:51.074593
# Unit test for method add of class Router
def test_Router_add():
    # Create a router object
    router_1 = Router()

    # Create a URL route
    @router_1.add("/route/url/")
    async def route_function(request, *args, **kwargs):
        print("This is my route function")

    # call the route_function in the context of the router
    route_function(router_1, *[])

# Generated at 2022-06-26 04:05:59.461204
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.response import HTTPResponse

    app = Sanic('test_Router_finalize')

    @app.route('/')
    async def f(request):
        return HTTPResponse(body='OK')

    with pytest.raises(SanicException) as excinfo:
        router_0 = app._router
        router_0.finalize()

    excinfo.match(r"Invalid route: <Route GET / () >. Parameter names cannot use '__\.'")


# Generated at 2022-06-26 04:06:01.555705
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_case_0()

# Generated at 2022-06-26 04:06:04.603061
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    try:
        router_0.finalize()
    except Exception:
        assert False

    router_0 = Router()
    try:
        router_0.finalize(None)
    except Exception:
        assert False


# Generated at 2022-06-26 04:06:06.037742
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

# Generated at 2022-06-26 04:06:07.474462
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()



# Generated at 2022-06-26 04:06:08.787200
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

# Generated at 2022-06-26 04:06:18.667242
# Unit test for method finalize of class Router
def test_Router_finalize():
    from functools import partial
    from sanic import Sanic

    @partial
    def _partial_0(*args, **kwargs):
        pass

    app = Sanic(_partial_0)

    router_0 = Router()
    router_0.finalize(app)

# Generated at 2022-06-26 04:06:20.451679
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    assert (True)



# Generated at 2022-06-26 04:06:29.644728
# Unit test for constructor of class Router
def test_Router():
    assert Router().__class__.__name__ == 'Router'


# Generated at 2022-06-26 04:06:32.546504
# Unit test for constructor of class Router
def test_Router():
    assert Router()
    assert Router(ctx=None)
    assert Router(ctx=None, finalize=True)


# Generated at 2022-06-26 04:06:34.686457
# Unit test for constructor of class Router
def test_Router():
    router_1 = Router()
    assert type(router_1) == Router


# Generated at 2022-06-26 04:06:36.046325
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    assert router_0 is not None

# Generated at 2022-06-26 04:06:37.934897
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    if isinstance(router_0, Router):
        assert True
    else:
        assert False

# Generated at 2022-06-26 04:06:39.141962
# Unit test for constructor of class Router
def test_Router():
    assert router_0 == None

# Generated at 2022-06-26 04:06:47.709007
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_1 = Router()
    router_1.add('/test_path', 'GET', '')
    router_1.finalize()
    assert router_1.routes == {}
    assert router_1.static_routes == {}
    assert router_1.dynamic_routes == {}
    assert router_1.regex_routes == {}
    # assert router_1.name_index == {}

if __name__ == '__main__':
    test_case_0()
    test_Router_finalize()

# Generated at 2022-06-26 04:06:49.053992
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    assert type(router_0) == Router
    return True

# Generated at 2022-06-26 04:06:50.920954
# Unit test for method finalize of class Router
def test_Router_finalize():
  router = Router()
  router.finalize()


# Generated at 2022-06-26 04:06:57.482499
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == []
    assert router.routes_dynamic == {}
    assert router.routes_static == []
    assert router.routes_regex == []
    assert router.name_index == {}


# Generated at 2022-06-26 04:07:06.523936
# Unit test for method finalize of class Router
def test_Router_finalize():
    ent_0 = test_case_0()


# Generated at 2022-06-26 04:07:15.506372
# Unit test for method finalize of class Router
def test_Router_finalize():
    # basic ir (from examples):
    router_0 = Router()
    var_0 = router_0.finalize()
    # basic cg (from examples):
    router_0 = Router()
    var_0 = router_0.finalize()
    print('var_0 = ', var_0)
    # examples w/ more complex ir:
    router_0 = Router()
    var_0 = router_0.finalize()
    router_0 = Router()
    var_0 = router_0.finalize()
    # examples w/ more complex cg:
    router_0 = Router()
    var_0 = router_0.finalize()
    router_0 = Router()
    var_0 = router_0.finalize()
    # examples w/ duplicate ir:
    router_0 = Router()
    var_

# Generated at 2022-06-26 04:07:16.322434
# Unit test for method finalize of class Router
def test_Router_finalize():
    pass # TODO: Implement your test here



# Generated at 2022-06-26 04:07:22.838827
# Unit test for constructor of class Router

# Generated at 2022-06-26 04:07:31.147561
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    assert router_0
    assert isinstance(router_0,Router)
    assert router_0.routes
    assert router_0.static_routes
    assert router_0.dynamic_routes
    assert router_0.regex_routes
    assert router_0.prefixes



# Generated at 2022-06-26 04:07:38.284891
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_1 = Router()
    router_1.routes = [None]
    router_1.routes_all = [None]
    router_1.routes_static = [None]
    router_1.routes_regex = [None]
    router_1.routes_dynamic = [None]
    router_1.static_routes = [None]
    router_1.trie_index = None
    router_1.name_index = None
    router_1.dynamic_routes = {'key': None}
    router_1.regex_routes = [None]
    var_1 = router_1.finalize()
    assert var_1 == None


# Generated at 2022-06-26 04:07:39.575901
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:07:43.092754
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    var_0 = router_0.finalize()
    assert (
        str(var_0)
        == "Router(name_index={}, routes=[], dynamic_routes={}, regex_routes=[], static_routes=[], app=None, ctx=None)"
    )


# Generated at 2022-06-26 04:07:48.607115
# Unit test for method finalize of class Router
def test_Router_finalize():
  
    # Constructor test case 0
    router_0 = Router()
    var_0 = router_0.finalize()
    assert isinstance(router_0, Router)
    assert isinstance(var_0, None)


# Generated at 2022-06-26 04:07:57.344375
# Unit test for constructor of class Router
def test_Router():
    var_0 = Router()
    assert type(var_0) == Router
    assert var_0.DEFAULT_METHOD == "GET"
    assert var_0.ALLOWED_METHODS == HTTP_METHODS
    assert var_0.routes_all == dict()
    assert var_0.routes_static == dict()
    assert var_0.routes_dynamic == dict()
    assert var_0.routes_regex == dict()
    assert var_0.name_index == dict()
    assert type(var_0.ctx) == dict


# Generated at 2022-06-26 04:08:15.035206
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_1 = Router()
    var_1 = router_1.finalize()


# Generated at 2022-06-26 04:08:16.711780
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:08:19.362265
# Unit test for constructor of class Router
def test_Router():
    router_1 = Router()
    var_1 = router_1.finalize()
    assert (var_1 == None)

# Generated at 2022-06-26 04:08:23.646879
# Unit test for constructor of class Router
def test_Router():
    # Finish all the tests in a separate file called RouterTest.py
    pass

if __name__ == "__main__":
    import pytest

    pytest.main()

# Generated at 2022-06-26 04:08:26.340222
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:08:28.493670
# Unit test for method finalize of class Router
def test_Router_finalize():
    arg_0 = None
    arg_1 = None
    arg_2 = None
    arg_3 = None


# Generated at 2022-06-26 04:08:31.066296
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Test case with single argument
    router = Router()
    var = router.finalize()


# Generated at 2022-06-26 04:08:39.557831
# Unit test for constructor of class Router
def test_Router():
    for_testing_0 = Router()
    var_1 = for_testing_0.finalize()
    var_2 = for_testing_0.routes_regex
    var_3 = for_testing_0.routes_all
    var_4 = for_testing_0.routes_static
    var_5 = for_testing_0.routes_dynamic
    var_6 = for_testing_0.get(uri = "/", method = "GET", host = None)


# Generated at 2022-06-26 04:08:43.784485
# Unit test for constructor of class Router
def test_Router():
    import inspect

    # Make sure that the constructor does not take any arguments
    assert not inspect.getfullargspec(Router.__init__).args


# Generated at 2022-06-26 04:08:45.573129
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_case_0()


# Generated at 2022-06-26 04:09:23.313312
# Unit test for method add of class Router
def test_Router_add():
    var_0: str = "test_case_0"
    var_1: str = "test_case_0"
    var_2: str = "test_case_0"
    var_3: str = "test_case_0"
    var_4: str = "test_case_0"
    var_5: str = "test_case_0"
    var_6: str = "test_case_0"
    router_0 = Router()
    var_7 = router_0.add(uri = var_1, methods = var_2, handler = var_3, host = var_4, strict_slashes = var_5, stream = var_6)



# Generated at 2022-06-26 04:09:25.445978
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    assert router_0

# Generated at 2022-06-26 04:09:29.302643
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        test_case_0()
    except Exception as inst:
        assert isinstance(inst, Exception)


# Generated at 2022-06-26 04:09:37.714166
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Create mock object for class Sanic
    ctx_0 = mock.Mock()
    # Create mock object for class Router
    var_0 = mock.Mock(spec = Router)
    # Create mock object for class SanicApp
    app_0 = mock.Mock()
    # Create mock object for class _Context
    class_0 = mock.Mock()
    # Configure mock object for class Sanic
    ctx_0.app = app_0
    ctx_0.finalized = False
    # Configure mock object for class _Context
    class_0.app = app_0
    # Configure mock object for class Router
    var_0.ctx = class_0
    var_0.dynamic_routes = {}
    var_0.static_routes = {}
    var_0.re

# Generated at 2022-06-26 04:09:44.426155
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    var_0 = router_0.routes_all
    var_0 = router_0.routes_dynamic
    var_0 = router_0.routes_regex
    var_0 = router_0.routes_static
    router_0.finalize()
    var_0 = router_0.DEFAULT_METHOD
    var_0 = router_0.ALLOWED_METHODS
    var_0 = router_0._create_route(arg_0=1)


# Generated at 2022-06-26 04:09:55.720588
# Unit test for constructor of class Router
def test_Router():
    from sanic.exceptions import NotFound, MethodNotSupported
    from sanic.models.handler_types import RouteHandler
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    try:
        router._get("/", "OPTIONS")
    except RoutingNotFound as e:
        assert e.__class__.__name__ == "NotFound"
        assert str(e) == "Requested URL / not found"
    except NoMethod as e:
        assert e.__class__.__name__ == "MethodNotSupported"
    try:
        router._get("/", "GET")
    except:
        assert False
    try:
        router._get("/", "POST")
    except:
        assert False

# Generated at 2022-06-26 04:09:57.856182
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    var_0 = router_0.finalize()
    pass



# Generated at 2022-06-26 04:09:59.361092
# Unit test for constructor of class Router
def test_Router():

    router = Router()
    assert router._cache == {}


# Generated at 2022-06-26 04:10:00.926686
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:10:13.588692
# Unit test for constructor of class Router
def test_Router():
    # Test case 1
    router_1 = Router()
    var_1 = router_1.ALLOWED_METHODS
    assert var_1 == HTTP_METHODS
    var_2 = router_1.static_routes
    assert var_2 == {}
    var_3 = router_1.dynamic_routes
    assert var_3 == {}
    var_4 = router_1.regex_routes
    assert var_4 == {}
    var_5 = router_1.router_cache
    assert var_5 == {}
    var_6 = router_1.name_index
    assert var_6 == {}
    var_7 = router_1.file_uri_cache
    assert var_7 == {}

# Generated at 2022-06-26 04:10:42.464844
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    var_0 = router_0.finalize()



# Generated at 2022-06-26 04:10:43.919824
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:10:47.458078
# Unit test for constructor of class Router
def test_Router():
    assert (isinstance(Router, type))
    assert (issubclass(Router, BaseRouter))


# Generated at 2022-06-26 04:10:48.635474
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:10:54.442709
# Unit test for method add of class Router
def test_Router_add():
    router_0 = Router()
    var_0 = router_0.add(uri="/downloads/<path:filename>", methods={}, handler=None, host=None, strict_slashes=False, stream=False, ignore_body=False, version=None, name=None, unquote=False, static=False)


# Generated at 2022-06-26 04:11:02.910394
# Unit test for method add of class Router
def test_Router_add():
    router_1 = Router()
    var_1 = router_1.add(uri="test_Router_add", methods=["GET", "POST", "OPTIONS"], handler=test_case_0, host=None, strict_slashes=False, stream=False, ignore_body=False, version=None, name=None, unquote=False)


# Generated at 2022-06-26 04:11:09.253834
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    var_0 = router_0
    for route_1 in var_0.routes_all.values():
        var_2 = route_1
        var_3 = var_2.labels
        if var_3 is not None:
            for label_4 in var_3:
                var_5 = label_4
                var_6 = var_5.startswith("__")
                var_7 = var_5 not in ALLOWED_LABELS
                if var_6 and var_7:
                    var_8 = SanicException(
                        f"Invalid route: {route_1}. Parameter names cannot use '__'."
                    )

                    raise var_8
    var_0 = router_0
    var_9 = router_0.dynamic_routes
    var_10

# Generated at 2022-06-26 04:11:11.823226
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    var_0 = router_0.finalize()

# Generated at 2022-06-26 04:11:20.085912
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    check_routes_all = router_0.routes_all
    check_routes_dynamic = router_0.routes_dynamic
    check_routes_regex = router_0.routes_regex
    check_routes_static = router_0.routes_static
    check_routes_all_item_1 = check_routes_all.items()
    check_routes_dynamic_item_1 = check_routes_dynamic.items()
    check_routes_regex_item_1 = check_routes_regex.items()
    check_routes_static_item_1 = check_routes_static.items()

# Generated at 2022-06-26 04:11:22.955020
# Unit test for constructor of class Router
def test_Router():
    t_0 = Router()
    assert isinstance(t_0, Router)


# Generated at 2022-06-26 04:11:52.803571
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:11:53.728643
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    var = router.finalize()

# Generated at 2022-06-26 04:11:55.752588
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:11:56.965641
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_case_0()

# Generated at 2022-06-26 04:12:08.624085
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    var_0: str = router_0.name
    var_1: str = router_0.index_name
    var_2: str = router_0.ctx.name
    var_3: str = router_0.ctx.index_name
    var_4: str = router_0.ctx.app.name
    var_5: str = router_0.ctx.app.index_name
    var_6: Dict = router_0.named_routes
    var_7: Dict = router_0.name_index
    var_8: Dict = router_0.dynamic_routes
    var_9: Dict = router_0.static_routes
    var_10: Dict = router_0.regex_routes

# Generated at 2022-06-26 04:12:11.374399
# Unit test for constructor of class Router
def test_Router():
    a = Router()
    assert isinstance(a, BaseRouter)
    a.finalize()


# Generated at 2022-06-26 04:12:16.565672
# Unit test for constructor of class Router
def test_Router():
    # Basic test: Constructor
    router_test = Router()
    assert router_test is not None, 'Error: Cannot create an instance of Router class'


# Generated at 2022-06-26 04:12:21.935227
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:12:28.901101
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    print(router_0.routes)
    print(router_0.dynamic_routes)
    print(router_0.name_index)
    print(router_0.static_routes)
    print(router_0.regex_routes)
    assert len(router_0.routes) == 0
    assert len(router_0.dynamic_routes) == 0
    assert len(router_0.name_index) == 0
    assert len(router_0.static_routes) == 0
    assert len(router_0.regex_routes) == 0
    router_0.add("path_0", ["GET", "POST", "OPTIONS"], "handler_0")

# Generated at 2022-06-26 04:12:40.740554
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.ctx.app == None
    assert router.ctx.errors == {}
    assert router.ctx.host == None
    assert router.ctx.hosts == []
    assert router.ctx.ignore_body == None
    assert router.ctx.name == None
    assert router.ctx.regex == None
    assert router.ctx.stream == None
    assert router.ctx.static == None
    assert router.ctx.version == None
    assert router.dynamic_routes == {}
    assert router.name_index == {}
    assert router.name_registry == {}
    assert router.regex_routes == {}
    assert router.static_files == {}
    assert router

# Generated at 2022-06-26 04:13:42.744588
# Unit test for method add of class Router
def test_Router_add():
    router_0 = Router()
    var_0 = router_0.add("/plaintext", ["GET"], "test", strict_slashes=False)
    del router_0


# Generated at 2022-06-26 04:13:43.453842
# Unit test for constructor of class Router
def test_Router():
    Router()


# Generated at 2022-06-26 04:13:45.406057
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    var_0 = router_0.finalize()
    assert var_0 == None


# Generated at 2022-06-26 04:13:50.078970
# Unit test for constructor of class Router
def test_Router():
    router_1 = Router()
    assert router_1 is not None

if __name__ == "__main__":
    test_case_0()
    test_Router()

# Generated at 2022-06-26 04:13:59.994225
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()

# Generated at 2022-06-26 04:14:02.489825
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}


# Generated at 2022-06-26 04:14:12.086481
# Unit test for constructor of class Router
def test_Router():
    router_1 = Router()
    router_1.add("/path/to/resource/<param>", "GET", lambda x: x, static = False)
    router_1.add("/path/to/resource2/<param>", "GET", lambda x: x, static = False)
    router_1.add("/path/to/resource3/<param>", "GET", lambda x: x, static = False)
    var_1 = router_1.finalize()
    assert var_1.routes_dynamic[0].path == "/path/to/resource2/<param>"
    assert var_1.routes_dynamic[0].ctx.unquote == False
    assert var_1.routes_dynamic[0].ctx.ignore_body == False
    assert var_1.routes

# Generated at 2022-06-26 04:14:16.067722
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    var_0 = router_0.routes_all
    var_1 = router_0.routes_static
    var_2 = router_0.routes_dynamic
    var_3 = router_0.routes_regex
    var_4 = router_0.finalize()


# Generated at 2022-06-26 04:14:18.088622
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:14:25.774338
# Unit test for constructor of class Router
def test_Router():
    assert (Router().routes_all == [])
    assert (Router().routes_static == [])
    assert (Router().routes_dynamic == [])
    assert (Router().routes_regex == [])
