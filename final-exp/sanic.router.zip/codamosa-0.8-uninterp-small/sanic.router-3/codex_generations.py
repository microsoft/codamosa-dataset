

# Generated at 2022-06-26 04:05:44.492572
# Unit test for method add of class Router
def test_Router_add():
    pass


# Generated at 2022-06-26 04:05:47.045280
# Unit test for method finalize of class Router
def test_Router_finalize():
    float_0 = -3281.51
    router_0 = Router(float_0)
    router_0.finalize()


# Generated at 2022-06-26 04:05:48.562862
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Setup

    # Exercise

    # Verify
    pass

# Generated at 2022-06-26 04:06:00.295529
# Unit test for constructor of class Router
def test_Router():
    # Setup test parameters
    float_1: float = 3.5
    float_0: float = 0.0
    float_2: float = 3.5
    float_3: float = 0.0
    int_0: int = 0
    int_1: int = 1
    int_2: int = 2
    str_0: str = "test_string"
    str_1: str = "test_string"
    str_2: str = "test_string"
    str_3: str = "test_string"
    str_4: str = "test_string"
    str_5: str = "test_string"
    str_6: str = "test_string"
    str_7: str = "test_string"
    str_8: str = "test_string"

# Generated at 2022-06-26 04:06:11.229228
# Unit test for constructor of class Router
def test_Router():
    float_0 = -3281.51
    router_0 = Router(float_0)
    assert router_0.base_url == -3281.51
    assert router_0.ctx.app == -3281.51
    assert router_0.name_index == {}
    assert router_0.routes == {}
    assert router_0.dynamic_routes == {}
    assert router_0.static_routes == {}
    assert router_0.regex_routes == {}
    assert not router_0.resolver.cache
    assert router_0.resolver.routes == []
    assert router_0.resolver.routemap == {}
    assert router_0.resolver.routemap_rev == {}

    router_1 = Router(float_0)
    assert router

# Generated at 2022-06-26 04:06:24.722663
# Unit test for constructor of class Router
def test_Router():
    float_0 = -6.477
    float_1 = -0.0
    float_2 = 5.557
    float_3 = -2.836
    float_4 = -0.0
    float_5 = 0.0
    float_6 = 5.325
    float_7 = -9.971
    float_8 = -8.867
    float_9 = 7.172
    float_10 = -0.0
    float_11 = -0.0
    float_12 = 0.39
    float_13 = -0.0
    float_14 = -2.5
    float_15 = -5.174
    float_16 = 6.843
    float_17 = -7.304
    float_18 = 2.357
    float_19 = -6.221
    float

# Generated at 2022-06-26 04:06:26.266277
# Unit test for constructor of class Router
def test_Router():
    float_0 = -3281.51
    router_0 = Router(float_0)


# Generated at 2022-06-26 04:06:28.222228
# Unit test for constructor of class Router
def test_Router():
    float_0 = -3281.51
    router_0 = Router(float_0)


# Generated at 2022-06-26 04:06:30.891894
# Unit test for method finalize of class Router
def test_Router_finalize():
    int_0 = 7911
    dict_0 = dict()
    router_0 = Router(int_0)
    router_0.finalize(dict_0)


# Generated at 2022-06-26 04:06:42.477141
# Unit test for method finalize of class Router
def test_Router_finalize():
    float_0 = 7590.06
    bool_0 = True
    str_0 = "y"
    bool_1 = False
    float_1 = -0.73
    float_2 = -0.76
    int_0 = -41
    list_0 = [float_2, bool_1, bool_0, 1, str_0]
    list_1 = [float_2, int_0, "V@` mN^G", 497, int_0]
    router_0 = Router(list_0)
    try:
        router_0.finalize(float_0)
    except SanicException:
        pass
    list_2 = ["0", "1", "2", "3", "4"]

# Generated at 2022-06-26 04:06:49.715060
# Unit test for method finalize of class Router
def test_Router_finalize():
    float_0 = -3281.51
    router_0 = Router(float_0)
    var_0 = router_0.finalize()
# Test output
test_case_0()

# Generated at 2022-06-26 04:06:52.790006
# Unit test for method finalize of class Router
def test_Router_finalize():
    float_0 = -3281.51
    router_0 = Router(float_0)
    var_0 = router_0.finalize()

# Generated at 2022-06-26 04:06:56.530803
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    router_0.finalize()

# Unit tests for constructor of class Router that checks preconditions

# Generated at 2022-06-26 04:06:57.894750
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

# Generated at 2022-06-26 04:06:59.754103
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    router.finalize()


# Generated at 2022-06-26 04:07:03.095494
# Unit test for constructor of class Router
def test_Router():
    base_1 = 0.72
    router_0 = Router(base_1)
    bool_0 = False
    try:
        var_0 = router_0.finalize(bool_0)
    except SanicException:
        bool_0 = True
    assert bool_0


# Generated at 2022-06-26 04:07:05.116860
# Unit test for constructor of class Router
def test_Router():
    try:
        assert test_case_0() == True
        print("test_case_0: PASS")
    except:
        print("test_case_0: FAIL")

if __name__ == '__main__':
    test_Router()

# Generated at 2022-06-26 04:07:09.050953
# Unit test for method finalize of class Router
def test_Router_finalize():
    float_1 = -1151.0
    router_1 = Router(float_1)
    var_1 = router_1.finalize()


# Generated at 2022-06-26 04:07:11.162427
# Unit test for constructor of class Router
def test_Router():
    # test case 0
    test_case_0()


# Generated at 2022-06-26 04:07:12.789880
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()


# Generated at 2022-06-26 04:07:23.125846
# Unit test for method finalize of class Router
def test_Router_finalize():
    float_0 = -3281.51
    router_0 = Router(float_0)
    router_0.finalize()


# Generated at 2022-06-26 04:07:25.379889
# Unit test for constructor of class Router
def test_Router():
    if __name__ == '__main__':
        test_case_0()



# Generated at 2022-06-26 04:07:29.811338
# Unit test for constructor of class Router
def test_Router():
    float_0 = -3281.51
    router_0 = Router(float_0)
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:07:31.330629
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_case_0()

# Generated at 2022-06-26 04:07:33.124687
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

# Generate inputs

# Generated at 2022-06-26 04:07:35.309524
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_case_0()



# Generated at 2022-06-26 04:07:41.198220
# Unit test for constructor of class Router
def test_Router():
    float_0 = -3281.51
    router_0 = Router(float_0)
    var_0 = router_0.finalize()
    return

if __name__ == "__main__":
    test_case_0()
    test_Router()

# Generated at 2022-06-26 04:07:45.249894
# Unit test for method finalize of class Router
def test_Router_finalize():
    float_0 = 8.9
    router_0 = Router(float_0)
    var_0 = router_0.finalize()
    try:
        assert var_0 is None
    except AssertionError:
        raise AssertionError()


# Generated at 2022-06-26 04:07:48.028502
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-26 04:07:57.344456
# Unit test for method finalize of class Router
def test_Router_finalize():
    float_1 = -9.6
    router_1 = Router(float_1)
    var_1 = router_1.finalize()
    assert var_1 == None
    router_2 = Router(float_0)
    try:
        router_2.finalize()
    except Exception as e:
        var_2 = e
    else:
        var_2 = None
    assert type(var_2) == SanicException
    # Check that error message contains '__'
    assert '__' in var_2.args[0]

if __name__ == '__main__':
    test_Router_finalize()

# Generated at 2022-06-26 04:08:17.244313
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    Unit test for method finalize of class Router

    """
    float_0 = -3281.51
    router_0 = Router(float_0)
    var_0 = router_0.finalize()



# Generated at 2022-06-26 04:08:21.321859
# Unit test for method finalize of class Router
def test_Router_finalize():
    float_0 = -1.83
    router_0 = Router(float_0)
    var_0 = router_0.finalize()

test_case_0()

# Generated at 2022-06-26 04:08:24.896287
# Unit test for method finalize of class Router
def test_Router_finalize():
    float_0 = -3281.51
    router_0 = Router(float_0)
    var_0 = router_0.finalize()

# Generated at 2022-06-26 04:08:26.338988
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_case_0()


# Generated at 2022-06-26 04:08:39.685960
# Unit test for method add of class Router
def test_Router_add():
    float_0 = -3281.51
    router_0 = Router(float_0)
    uri_0 = ''
    methods_0 = dict()
    def handler_0():
        pass
    host_0 = handler_0
    strict_slashes_0 = True
    stream_0 = float_0
    ignore_body_0 = True
    version_0 = dict()
    name_0 = 'http://localhost:8080/test'
    unquote_0 = True
    static_0 = float_0
    route_0 = router_0.add(uri_0, methods_0, handler_0, host_0, strict_slashes_0, stream_0, ignore_body_0, version_0, name_0, unquote_0, static_0)
    assert route_0 is not None



# Generated at 2022-06-26 04:08:40.682693
# Unit test for constructor of class Router
def test_Router():
    router = Router()

# Generated at 2022-06-26 04:08:44.093186
# Unit test for method finalize of class Router
def test_Router_finalize():
    float_0 = -3281.51
    router_0 = Router(float_0)
    var_0 = router_0.finalize()

# Generated at 2022-06-26 04:08:45.621389
# Unit test for method finalize of class Router
def test_Router_finalize():
    float_0 = float(99.86)
    router_0 = Router(float_0)
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:08:46.327839
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

# Generated at 2022-06-26 04:08:49.929010
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    float_0 = -3281.51
    router_0 = Router(float_0)
    var_0 = router_0.finalize()
    assert var_0 is None


# Generated at 2022-06-26 04:09:22.743930
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_case_0()



# Generated at 2022-06-26 04:09:26.834755
# Unit test for constructor of class Router
def test_Router():
    float_0 = -3732.32
    router_0 = Router(float_0)

    assert router_0.ctx.app == float_0


# Generated at 2022-06-26 04:09:30.629857
# Unit test for method finalize of class Router
def test_Router_finalize():
    float_0 = -3281.51
    router_0 = Router(float_0)
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:09:37.002922
# Unit test for constructor of class Router
def test_Router():
    float_0 = float.fromhex('0x1.8p+3')
    router_0 = Router(float_0)
    try:
        router_0.finalize()
    except SanicException:
        pass
    assert True


# Generated at 2022-06-26 04:09:42.656988
# Unit test for method add of class Router
def test_Router_add():
    float_0 = -8120.73
    router_0 = Router(float_0)
    router_2 = router_0.add(u"", [], lambda event, context: None, False)
    # Only one assert can be tested due to error "RuntimeError: generator 'add' raised StopIteration"
    assert router_2.ctx.unquote


# Generated at 2022-06-26 04:09:52.217615
# Unit test for constructor of class Router
def test_Router():
    assert issubclass(Router, BaseRouter) == True
    assert isinstance(Router(0), BaseRouter) == True
    assert Router(0).__init__ == BaseRouter.__init__
    # Ensure initialization for Router with constructor
    # def __init__(self, strict_slashes = False):

    # test for re-assigning with finalize at end
    test_case_0()
    assert True
    # ensure negative strict_slashes flag



# Generated at 2022-06-26 04:09:54.126377
# Unit test for constructor of class Router
def test_Router():
    # test_case_0()
    pass


# Generated at 2022-06-26 04:09:58.126244
# Unit test for method finalize of class Router
def test_Router_finalize():
    float_0 = -1276.96848
    router_0 = Router(float_0)
    with pytest.raises(SanicException):
        router_0.finalize()


# Generated at 2022-06-26 04:09:59.226659
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_case_0()



# Generated at 2022-06-26 04:10:01.114188
# Unit test for constructor of class Router
def test_Router():
    assert isinstance(Router(None), Router)

if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-26 04:11:04.234574
# Unit test for constructor of class Router
def test_Router():
    float_0 = -2341.248
    router_0 = Router(float_0)
    url_0 = "k"
    int_0 = 6
    var_0 = router_0.resolve(path=url_0, method=int_0)



# Generated at 2022-06-26 04:11:06.580364
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    router_0.finalize()

# Generated at 2022-06-26 04:11:07.620605
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    assert isinstance(router_0, Router)


# Generated at 2022-06-26 04:11:13.415939
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Test a basic method
    float_0 = -3281.51
    router_0 = Router(float_0)
    var_0 = router_0.finalize()

    # A simple test, but a test nonetheless.



# Generated at 2022-06-26 04:11:16.909646
# Unit test for constructor of class Router
def test_Router():
    # Setup
    float_0 = -3281.51
    router_0 = Router(float_0)
    # Verify
    assert isinstance(router_0, Router)

# Unit tests for method Router.finalize()

# Generated at 2022-06-26 04:11:18.348896
# Unit test for constructor of class Router
def test_Router():
    test_case_0()


# Generated at 2022-06-26 04:11:29.870085
# Unit test for method add of class Router
def test_Router_add():
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    str_0 = str()
    str_1 = str()
    str_2 = str()
    str_3 = str()
    str_4 = str()
    list_0 = list()
    tuple_0 = tuple()
    tuple_1 = tuple()
    tuple_2 = tuple()
    tuple_3 = tuple()
    tuple_4 = tuple()
    tuple_5 = tuple()
    tuple_6 = tuple()
    tuple_7 = tuple()
    tuple_8 = tuple()
    tuple_9 = tuple()

# Generated at 2022-06-26 04:11:31.753605
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()

# Generated at 2022-06-26 04:11:35.099135
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router(0)
    method_0 = router_0.finalize()

    assert(method_0 == None)


# Generated at 2022-06-26 04:11:43.146610
# Unit test for constructor of class Router
def test_Router():
    float_0 = -3281.51
    router_0 = Router(float_0)
    var_0 = router_0.finalize()
    float_1 = float_0 + float_0
    assert float_1 == float_0
    var_1 = router_0.routes_regex
    var_2 = router_0.routes_all
    router_1 = Router(float_1)
    var_3 = router_1.routes_all
    router_1.add(
        '/user',
        {'POST'},
        None,
        None,
        False,
        False,
        False,
        None,
        None,
        False,
        False,
    )
    var_4 = router_1.routes_regex
    var_5 = router_

# Generated at 2022-06-26 04:13:35.841600
# Unit test for constructor of class Router
def test_Router():
    pass

# Generated at 2022-06-26 04:13:37.342115
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_case_0()

# Generated at 2022-06-26 04:13:37.901263
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_case_0()

# Generated at 2022-06-26 04:13:39.300879
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

# Generated at 2022-06-26 04:13:40.878392
# Unit test for constructor of class Router
def test_Router():
    float_0 = -3281.51
    router_0 = Router(float_0)
    var_0 = router_0.finalize()




# Generated at 2022-06-26 04:13:43.133017
# Unit test for constructor of class Router
def test_Router():
    logger.info("***** Testing Constructor of Router class *****")
    # case 0
    test_case_0()
    logger.info("***** Finished testing Constructor of Router class *****")
    logger.info("\n\n")


# Generated at 2022-06-26 04:13:44.677296
# Unit test for method finalize of class Router
def test_Router_finalize():
    float_0 = -3281.51
    router_0 = Router(float_0)
    var_0 = router_0.finalize()



# Generated at 2022-06-26 04:13:47.604282
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:13:52.016463
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router(3)


if __name__ == "__main__":
    test_case_0()
    test_Router()
    pass

# Generated at 2022-06-26 04:14:00.692033
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    router_0.finalize()
    router_0 = Router()
    router_0.finalize()
    router_0 = Router()
    router_0.finalize()
    router_0 = Router()
    router_0.finalize()
    router_0 = Router()
    router_0.finalize()
    router_0 = Router()
    router_0.finalize()
    router_0 = Router()
    router_0.finalize()
    router_0 = Router()
    router_0.finalize()
    router_0 = Router()
    router_0.finalize()
    router_0 = Router()
    router_0.finalize()
    router_0 = Router()
    router_0.finalize()
    router_0 = Router()
    router_0