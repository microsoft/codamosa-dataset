

# Generated at 2022-06-26 04:05:47.679058
# Unit test for method finalize of class Router
def test_Router_finalize():
    # int_0 = -699
    # router_0 = Router(int_0)
    raise NotImplementedError()

# Generated at 2022-06-26 04:05:57.140943
# Unit test for constructor of class Router
def test_Router():
    int_0 = -699
    router_0 = Router(int_0)
    assert router_0.ctx.app == int_0
    assert router_0.routes_all != None
    assert router_0.routes_dynamic != None
    assert router_0.routes_regex != None
    assert router_0.routes_static != None


# Generated at 2022-06-26 04:06:03.101088
# Unit test for method finalize of class Router
def test_Router_finalize():
    int_0 = -6318
    assert type(int_0) is int
    assert isinstance(int_0, int)
    router_0 = Router(int_0)
    router_0.finalize()


# Generated at 2022-06-26 04:06:04.461976
# Unit test for constructor of class Router
def test_Router():
    int_0 = -699
    router_0 = Router(int_0)


# Generated at 2022-06-26 04:06:09.028294
# Unit test for method add of class Router
def test_Router_add():
    int_0 = -11
    router_0 = Router(int_0)
    # TypeError: add() missing 1 required positional argument: 'handler'
    router_0.add()
    # ValueError: No routes have been registered
    router_0.get()



# Generated at 2022-06-26 04:06:13.836128
# Unit test for method finalize of class Router
def test_Router_finalize():
    int_0 = -699
    router_0 = Router(int_0)


# Generated at 2022-06-26 04:06:23.505043
# Unit test for method add of class Router
def test_Router_add():
    int_0 = 489
    router_0 = Router((int_0 * -1328633909))
    str_0 = ":6UoX_Uynq}ZF?5Cxr'e5hP-R>dtW@"
    list_0 = [
        "v",
        "OPTIONS",
        "POST",
        "DELETE",
        "PUT",
        "GET",
    ]
    bool_0 = None is int_0
    route_0 = router_0.add(
        str_0,
        list_0,
        bool_0,
        "aV7(u_y1e-g4h;{Y%R#$8",
        False,
        False,
        False,
    )

# Generated at 2022-06-26 04:06:24.939496
# Unit test for constructor of class Router
def test_Router():
    int_0 = -2
    router_0 = Router(int_0)


# Generated at 2022-06-26 04:06:28.317320
# Unit test for method finalize of class Router
def test_Router_finalize():
    int_0 = -1
    router_0 = Router(int_0)
    router_0.finalize()
    assert router_0.routes_all
    assert router_0.routes_static
    assert router_0.routes_dynamic
    assert router_0.routes_regex


# Generated at 2022-06-26 04:06:30.676707
# Unit test for constructor of class Router
def test_Router():
    assert(test_case_0());

routes_all_test_case_0 = Router(42).routes


# Generated at 2022-06-26 04:06:35.841376
# Unit test for method finalize of class Router
def test_Router_finalize():
    var_0 = NotImplementedError()


# Generated at 2022-06-26 04:06:37.113661
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Construction statement 1
    var_1 = Router()


# Generated at 2022-06-26 04:06:38.895401
# Unit test for method finalize of class Router
def test_Router_finalize():
    var = None  # type: Any
    var = Router()
    test_case_0()
    return


# Generated at 2022-06-26 04:06:40.920298
# Unit test for method finalize of class Router
def test_Router_finalize():
    # NotImplementedError: raise NotImplementedError
    # var_0 = NotImplementedError()
    pass


# Generated at 2022-06-26 04:06:45.818518
# Unit test for method finalize of class Router
def test_Router_finalize():
    # var_0 = NotImplementedError()
    # var_1 = NotImplementedError()
    # var_2 = NotImplementedError()
    # var_3 = NotImplementedError()
    pass


# Generated at 2022-06-26 04:06:57.876681
# Unit test for constructor of class Router
def test_Router():
    m_get = Mock()
    m_add = Mock()
    m_find_route_by_view_name = Mock()
    m_routes_all = Mock()
    m_routes_static = Mock()
    m_routes_dynamic = Mock()
    m_routes_regex = Mock()
    m_finalize = Mock()


# Generated at 2022-06-26 04:07:04.227614
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        var_0 = NotImplementedError()
        try:
            for (var_1, var_2) in var_0.items():
                var_3 = var_2.labels
                for var_4 in var_3:
                    if var_4.startswith(NotImplemented):
                        raise var_1
        except TypeError:
            var_5 = var_0[NotImplemented]
        else:
            var_5 = var_0.__getitem__(NotImplemented)
    except Exception as var_6:
        var_7 = getattr(var_6, NotImplemented(), None)
        if var_7 is None:
            var_7 = getattr(var_6, NotImplemented, None)
            if var_7 is None:
                var_

# Generated at 2022-06-26 04:07:05.756136
# Unit test for constructor of class Router
def test_Router():
    var_0 = NotImplementedError()


# Generated at 2022-06-26 04:07:15.296591
# Unit test for constructor of class Router
def test_Router():
    
    # Test case 1
    test_Route_1 = Router.Route("test_case_1", None, None, None)
    if test_Route_1.path != "test_case_1":
        print("Failed")
    if test_Route_1.handler != None:
        print("Failed")
    if test_Route_1.methods != None:
        print("Failed")
    if test_Route_1.name != None:
        print("Failed")
    if test_Route_1.strict != False:
        print("Failed")
    if test_Route_1.requirements != {}:
        print("Failed")
    if test_Route_1.unquote != False:
        print("Failed")

    # Test case 2

# Generated at 2022-06-26 04:07:26.716686
# Unit test for constructor of class Router
def test_Router():
    def test_case_1():
        var_0 = Router()
        var_0.DEFAULT_METHOD = "GET"
        var_0.ALLOWED_METHODS = ('GET', 'HEAD', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS')

# Generated at 2022-06-26 04:07:37.075340
# Unit test for constructor of class Router
def test_Router():
    int_0 = -699
    router_0 = Router(int_0)

    assert isinstance(router_0, Router)

    # Test the method 'add'

    # Test the method 'finalize'
    test_case_0()

    # Test the method 'find_route_by_view_name'

    # Test the method 'get'

    # Test the property 'routes_all'

    # Test the property 'routes_dynamic'

    # Test the property 'routes_regex'

    # Test the property 'routes_static'

# Generated at 2022-06-26 04:07:40.007108
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-26 04:07:43.324937
# Unit test for constructor of class Router
def test_Router():
    print('test_Router')

    test_case_0()

if __name__ == '__main__':
    test_Router()

# Generated at 2022-06-26 04:07:45.473857
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_case_0()


# Generated at 2022-06-26 04:07:50.534679
# Unit test for constructor of class Router
def test_Router():
    int_0 = -650
    router_0 = Router(int_0)
    assert router_0.ctx == int_0
    assert int_0 == -650
    var_0 = router_0.finalize()



# Generated at 2022-06-26 04:07:53.286875
# Unit test for method finalize of class Router
def test_Router_finalize():
    """Method finalize, test as follows"""
    # Create a Router object
    test_case_0()


# Generated at 2022-06-26 04:07:55.570766
# Unit test for method finalize of class Router
def test_Router_finalize():
    int_0 = -699
    router_0 = Router(int_0)
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:08:08.336642
# Unit test for method add of class Router
def test_Router_add():
    uri_0 = '\xef\xbf\xbd\xef'
    methods_0 = {'\xef\xbf\xbd\xef\xbf\xbd\xef\xbf\xbd\xef' : '\xef\xbf\xbd\xef\xbf\xbd\xef\xbf\xbd\xef\xbf\xbd', }
    handler_0 = None
    host_0 = '\xef\xbf\xbd\xef'
    var_0 = Router(handler_0)
    var_1 = var_0.add(uri_0, methods_0, host_0)
    print(var_1)
    print(var_1)
    print(var_1)

# Generated at 2022-06-26 04:08:10.010117
# Unit test for constructor of class Router
def test_Router():
    test_case_0()


# Generated at 2022-06-26 04:08:11.528413
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_case_0()

# Generated at 2022-06-26 04:08:26.338545
# Unit test for constructor of class Router
def test_Router():
    int_0 = 5
    router_0 = Router(int_0)

    router_0.add("/users/<id>", ["GET"], lambda: 0)

    int_1 = router_0.routes_all[0].methods[0]
    assert int_1 == "GET", "Method does not match"


# Generated at 2022-06-26 04:08:27.234799
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_case_0()


# Generated at 2022-06-26 04:08:29.245565
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Case 0
    test_case_0()


# Generated at 2022-06-26 04:08:33.580820
# Unit test for constructor of class Router
def test_Router():
    int_0 = 816
    # Initialize a router
    router_0 = Router(int_0)
    # Finalize the router
    var_0 = router_0.finalize()

# Generated at 2022-06-26 04:08:35.950834
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    router_0.finalize()


# Generated at 2022-06-26 04:08:38.245865
# Unit test for constructor of class Router
def test_Router():
    print("Testing constructor of class Router")
    router_0 = Router(837)
    router_0.finalize()


# Generated at 2022-06-26 04:08:45.423354
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router(int_0)
    print(router_0)

if __name__ == "__main__":
    int_0 = -699
    router_0 = Router(int_0)
    print(router_0)
    var_0 = router_0.finalize()

# Generated at 2022-06-26 04:08:55.332274
# Unit test for constructor of class Router
def test_Router():
    int_0 = -699
    router_0 = Router(int_0)
    router_0.ctx.uris_all.clear()
    router_0.static_routes.clear()
    uri_0 = 'g`q&'
    method_0 = 'json'
    handler_0 = 'DE'
    var_0 = router_0.add(uri_0, method_0, handler_0)
    host_0 = 'zB{k>'
    path_0 = 'h|'
    method_1 = 'GET'
    var_1 = router_0.get(path_0, method_1, host_0)
    # AssertionError: False is not true : Could not match a route for ['GET', 'h|'] with host zB{k>

# Generated at 2022-06-26 04:08:56.789289
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_case_0()


# Generated at 2022-06-26 04:09:09.789964
# Unit test for method add of class Router

# Generated at 2022-06-26 04:09:30.896871
# Unit test for constructor of class Router
def test_Router():
    int_0 = -118
    router_0 = Router(int_0)
    # Method: void finalize( void)
    router_0.finalize()
    router_0.ALLOWED_METHODS
    # Method: void finalize( void)
    router_0.finalize()
    router_0.DEFAULT_METHOD



# Generated at 2022-06-26 04:09:34.196253
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, BaseRouter) == True


# Generated at 2022-06-26 04:09:37.437221
# Unit test for constructor of class Router
def test_Router():
    int_0 = -1169
    router_0 = Router(int_0)
    var_0 = router_0.finalize()



# Generated at 2022-06-26 04:09:41.051964
# Unit test for method finalize of class Router
def test_Router_finalize():
    int_0 = -50
    router_0 = Router(int_0)
    var_0 = router_0.finalize()
test_Router_finalize()

# Generated at 2022-06-26 04:09:46.240538
# Unit test for method finalize of class Router
def test_Router_finalize():
    # test case 0
    try:
        test_case_0()
    except Exception as e:
        print("Error raised: " + str(e))

if __name__ == "__main__":
    test_Router_finalize()

# Generated at 2022-06-26 04:09:56.269621
# Unit test for constructor of class Router
def test_Router():
    # noinspection PyUnusedLocal
    route_0 = Route(None, None, None)
    route_0.ctx.static = -1
    router_0 = Router(None)
    # noinspection PyCallingNonCallable
    router_0.get(None, None, None)
    # noinspection PyCallingNonCallable
    router_0.add(None, None, None, None, None, None, None, None, None, None)

    # noinspection PyCallingNonCallable,PyProtectedMember
    router_0.find_route_by_view_name(None)

    var_0 = router_0.routes_all
    var_1 = router_0.routes_static
    var_2 = router_0.routes_dynamic

# Generated at 2022-06-26 04:09:58.328410
# Unit test for constructor of class Router
def test_Router():
    int_0 = 810
    router_0 = Router(int_0)


# Generated at 2022-06-26 04:10:06.238592
# Unit test for constructor of class Router

# Generated at 2022-06-26 04:10:12.608074
# Unit test for constructor of class Router
def test_Router():
    router_1 = Router()
    assert len(router_1.routes) == 0
    assert len(router_1.static_routes) == 0
    assert len(router_1.regex_routes) == 0
    assert len(router_1.dynamic_routes) == 0
    assert len(router_1.name_index) == 0


# Generated at 2022-06-26 04:10:13.661805
# Unit test for constructor of class Router
def test_Router():
    assert(router)


# Generated at 2022-06-26 04:10:43.767850
# Unit test for method finalize of class Router
def test_Router_finalize():
    int_0 = -498
    router_0 = Router(int_0)
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:10:47.312586
# Unit test for constructor of class Router
def test_Router():
    # Case 0
    test_case_0()


if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-26 04:10:48.827759
# Unit test for constructor of class Router
def test_Router():
    assert True, "Unit test code goes here"

# Generated at 2022-06-26 04:10:52.331474
# Unit test for constructor of class Router
def test_Router():
    var_0 = Router(int())
    var_1 = Router(int())
    assert var_0 == var_1


# Generated at 2022-06-26 04:10:54.368376
# Unit test for method finalize of class Router
def test_Router_finalize():
    int_0 = -699
    router_0 = Router(int_0)
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:10:56.302150
# Unit test for constructor of class Router
def test_Router():
    # test_case_0()
    test_case_1()



# Generated at 2022-06-26 04:11:00.559067
# Unit test for method finalize of class Router
def test_Router_finalize():
    int_0 = -699
    router_0 = Router(int_0)
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:11:05.930172
# Unit test for constructor of class Router
def test_Router():
    def _test_Router_1():
        var_0 = Router(0)
        assert var_0.__class__ == Router

    def _test_Router_2():
        var_0 = Router()
        assert var_0.__class__ == Router

    _test_Router_2()
    _test_Router_1()


# Generated at 2022-06-26 04:11:08.740336
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-26 04:11:10.312420
# Unit test for method finalize of class Router
def test_Router_finalize():
    pass


# Generated at 2022-06-26 04:12:17.392868
# Unit test for constructor of class Router
def test_Router():
    int_0 = -699
    router_0 = Router(int_0)
    var_0 = router_0.finalize()

# Generated at 2022-06-26 04:12:23.640420
# Unit test for method finalize of class Router
def test_Router_finalize():
    int_0 = -8819
    router_0 = Router(int_0)
    router_0.finalize()


# Generated at 2022-06-26 04:12:34.283782
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    Unit test for method finalize of class Router

    """

    # Create an instance of the Router class
    router_0 = Router()

    # Call the finalize method on this instance
    try:
        router_0.finalize()
    except:
        fail("TestCase 0: Router.finalize")

    # Create an instance of the Router class
    router_1 = Router()

    # Call the finalize method on this instance
    router_1.finalize()

    # Create an instance of the Router class
    router_2 = Router()

    # Call the finalize method on this instance
    try:
        router_2.finalize()
    except:
        fail("TestCase 3: Router.finalize")

    # Create an instance of the Router class
    router_3 = Router()

    # Call the finalize method on

# Generated at 2022-06-26 04:12:37.476294
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        test_case_0()
    except SanicException as e:
        assert(e != None)


test_Router_finalize()

# Generated at 2022-06-26 04:12:40.872329
# Unit test for constructor of class Router
def test_Router():
    int_0 = -699
    router_0 = Router(int_0)
    var_0 = router_0.finalize()

if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-26 04:12:42.088844
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

# Function call to test Router class
test_Router()

# Generated at 2022-06-26 04:12:43.849736
# Unit test for constructor of class Router
def test_Router():
    assert Router

if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-26 04:12:46.692404
# Unit test for method finalize of class Router
def test_Router_finalize():
    # The following tests were found in test_Router_finalize
    # They wont be checked by our script
    return


# Generated at 2022-06-26 04:12:48.691435
# Unit test for method finalize of class Router
def test_Router_finalize():

    router_0 = Router()
    var_0 = router_0.finalize()



# Generated at 2022-06-26 04:13:03.110441
# Unit test for constructor of class Router
def test_Router():
    int_0 = int()
    assert isinstance(int_0, int)
    int_1 = int(1)
    assert isinstance(int_1, int)
    assert int_1 == 1
    int_2 = int(2.0)
    assert isinstance(int_2, int)
    assert int_2 == 2
    int_3 = int(3.5)
    assert isinstance(int_3, int)
    assert int_3 == 3
    int_4 = int(4.9)
    assert isinstance(int_4, int)
    assert int_4 == 4
    int_5 = int(5.01)
    assert isinstance(int_5, int)
    assert int_5 == 5
    int_6 = int(6.99)

# Generated at 2022-06-26 04:15:50.207129
# Unit test for constructor of class Router
def test_Router():
    int_0 = -699
    router_0 = Router(int_0)
    var_0 = router_0.finalize()
    route_0 = router_0.find_route_by_view_name("/test")
    route_1 = router_0.find_route_by_view_name("/test")

    arg_0 = 0
    arg_1 = 0
    arg_2 = 0
    route_2, handler_0, d_0 = router_1.get("/test", arg_0, arg_1, arg_2)
