

# Generated at 2022-06-26 04:06:04.170799
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

# Unit tests for add method of class Router
# def test_add():
#     test_case_0()


# Unit tests for find_route_by_view_name method of class Router
# def test_find_route_by_view_name():
#     test_case_0()

# Unit tests for finalize method of class Router
# def test_finalize():
#     test_case_0()

# Unit tests for get method of class Router
# def test_get():
#     test_case_0()

# Generated at 2022-06-26 04:06:09.397024
# Unit test for constructor of class Router
def test_Router():
    str_0 = '1>&7YUC{]`=Z>Q;*kE+o'
    tuple_0 = None
    router_0 = Router(str_0, tuple_0)
    router_0.ctx.app = '1>&7YUC{]`=Z>Q;*kE+o'

# Generated at 2022-06-26 04:06:13.734042
# Unit test for constructor of class Router
def test_Router():
    str_0 = "8=kQ"
    tuple_0 = (True, )
    router_0 = Router(str_0, tuple_0)
    router_0.finalize(tuple_0, str_0)
    RouteHandler_0 = router_0.find_route_by_view_name("a")
    route_0 = router_0.add("", (), RouteHandler_0)
    return str_0


# Generated at 2022-06-26 04:06:20.233543
# Unit test for constructor of class Router
def test_Router():
    # Initialize a Router object
    str_0 = '{]`=Z>Q;*kE+o'
    router_0 = Router(str_0, None)
    # Act on object
    # Use method find_route_by_view_name
    str_1 = '{]`=Z>Q;*kE+o'
    route_0 = router_0.find_route_by_view_name(str_1, None)
    # Use method get
    str_2 = '{]`=Z>Q;*kE+o'
    method_0 = '{]`=Z>Q;*kE+o'
    str_3 = '{]`=Z>Q;*kE+o'

# Generated at 2022-06-26 04:06:23.119074
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_0 = '1>&7YUC{]`=Z>Q;*kE+o'
    tuple_0 = None
    router_0 = Router(str_0, tuple_0)
    tuple_1 = router_0.finalize()

# Generated at 2022-06-26 04:06:28.976682
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_0 = '1>&7YUC{]`=Z>Q;*kE+o'
    tuple_0 = None
    router_0 = Router(str_0, tuple_0)


# Generated at 2022-06-26 04:06:39.196145
# Unit test for method add of class Router
def test_Router_add():

    str_0 = '1>&7YUC{]`=Z>Q;*kE+o'
    tuple_0 = None
    router_0 = Router(str_0, tuple_0)

    def handler_0():
        return None

    str_1 = '1>&7YUC{]`=Z>Q;*kE+o'
    args_0 = {
        str_1: True
    }
    str_1 = '1>&7YUC{]`=Z>Q;*kE+o'
    args_1 = {
        str_1: handler_0
    }
    route_0 = router_0.add(**args_0, **args_1)


# Generated at 2022-06-26 04:06:47.434051
# Unit test for method add of class Router
def test_Router_add():
    str_0 = '1>&7YUC{]`=Z>Q;*kE+o'
    tuple_0 = None
    router_0 = Router(str_0, tuple_0)
    str_1 = '~>!'
    list_0 = []
    str_2 = '#'
    list_1 = [str_2]
    str_3 = 'U6'
    router_0.add(str_1, list_0, str_2, str_3)


# Generated at 2022-06-26 04:06:49.289893
# Unit test for constructor of class Router
def test_Router():
    str_0 = 'E(co<0h>Z'
    tuple_0 = None
    router_0 = Router(str_0, tuple_0)


# Generated at 2022-06-26 04:06:52.831592
# Unit test for constructor of class Router
def test_Router():
    str_0 = '3qrZ7VuQ]^U5.N=22Jq4'
    router_0 = Router(str_0)


# Generated at 2022-06-26 04:07:04.995692
# Unit test for constructor of class Router
def test_Router():
    client = Client()
    print('Unit test for Router')
    print('Test for default constructor')
    str_0 = '1>&7YUC{]`=Z>Q;*kE+o'
    router_0 = Router(str_0)
    result = [router_0.routes_all, router_0.routes_static, router_0.routes_dynamic, router_0.routes_regex, router_0.tree]
    correct = [{}, {}, {}, {}, {}]
    assert (result == correct), "result != correct"
    print('Test for constructor with arguments')
    router_1 = Router(str_0, str_0, str_0)

# Generated at 2022-06-26 04:07:10.699367
# Unit test for constructor of class Router
def test_Router():
    str_0 = '1>&7YUC{]`=Z>Q;*kE+o'
    router_0 = Router(str_0)
    assert router_0.ctx == '1>&7YUC{]`=Z>Q;*kE+o'
    assert router_0.routes == {}
    assert router_0.dynamic_routes == {}
    assert router_0.static_routes == {}
    assert router_0.regex_routes == {}
    assert router_0.name_index == {}

# Generated at 2022-06-26 04:07:12.803357
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_0 = 'E%/*xnTx^B7V2]Y6#_:Vq'
    router_0 = Router(str_0)
    router_0.finalize()


# Generated at 2022-06-26 04:07:22.382692
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_0 = '1>&7YUC{]`=Z>Q;*kE+o'
    router_0 = Router(str_0)
    try:
        router_0.finalize()
    except Exception as e:
        assert str(e) == 'Invalid route: Route(GET, path="/", handler=<function test_Router_finalize at 0x7f3e932d6e18>). Parameter names cannot use \'__\'.'


# Generated at 2022-06-26 04:07:29.347161
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_0 = 'OQ-3qE16:'

    # Invoke method finalize of class Router with argument str_0
    try:
        router_0 = Router(str_0)
        router_0.finalize()
    except Exception as exception_0:
        assert type(exception_0) == SanicException

# Generated at 2022-06-26 04:07:31.539211
# Unit test for constructor of class Router
def test_Router():
    test_case_0()
    print('test_Router successful !')


# Generated at 2022-06-26 04:07:34.220623
# Unit test for constructor of class Router
def test_Router():
    str_0 = '1>&7YUC{]`=Z>Q;*kE+o'
    router_0 = Router(str_0)


# Generated at 2022-06-26 04:07:46.391447
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_0 = 'K,[b<@lbI;&]pW#l8{v["'

# Generated at 2022-06-26 04:07:50.883366
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_0 = '1>&7YUC{]`=Z>Q;*kE+o'
    router_0 = Router(str_0)
    test_Router_finalize_0()


# Generated at 2022-06-26 04:07:53.355474
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_0 = '1>&7YUC{]`=Z>Q;*kE+o'
    router_0 = Router(str_0)
    try:
        router_0.finalize()
    except SanicException:
        pass


# Generated at 2022-06-26 04:07:59.071100
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router != None


# Generated at 2022-06-26 04:08:09.704303
# Unit test for constructor of class Router
def test_Router():
    try:
        # todo: use 'str' instead of 'str_0'
        test_case_0()

        return
    except Exception as err:
        print(err)
        pass

    try:
        # todo: use 'str_1' instead of 'str_0'
        test_case_0()

        return
    except Exception as err:
        print(err)
        pass

    try:
        # todo: use 'str' instead of 'str_0'
        test_case_0()

        return
    except Exception as err:
        print(err)
        pass

    try:
        # todo: use 'str_0' instead of 'str_0'
        test_case_0()

        return
    except Exception as err:
        print(err)
        pass


# Generated at 2022-06-26 04:08:10.308165
# Unit test for method finalize of class Router
def test_Router_finalize():
    pass


# Generated at 2022-06-26 04:08:17.754484
# Unit test for method finalize of class Router
def test_Router_finalize():
    r_0 = Router(lru_size=1024)
    r_0.routes_dynamic = dict()
    r_0.routes_regex = dict()
    r_0.routes_static = dict()
    assert not r_0.routes_all

    r_0.finalize()

    assert r_0.routes_all
    assert r_0.routes_dynamic
    assert r_0.routes_regex
    assert r_0.routes_static


# Generated at 2022-06-26 04:08:26.339729
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    dynamic_routes = {}
    dynamic_routes['0'] = 'K,[b<@lbI;&]pW#l8{v["'
    router.dynamic_routes = dynamic_routes
    router.finalize()
    return 'K,[b<@lbI;&]pW#l8{v["'


# Generated at 2022-06-26 04:08:39.686693
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_0 = 'C;-k@\x15\x04E\x00\x19'
    str_1 = '[V\x16r\x16"T[\x01\x1dv\x1cW\x0f\x16\x15\x15X\\"\x1c\x10'
    int_0 = 166
    str_2 = '{Q\x0eX,\x16'
    int_1 = 0
    array = ['z', 'P&o\x0f', 'x,kg\x0f/\x01&/\x07\x1fW', 'Vh}c%']
    int_2 = 17
    str_3 = '\x03K\x00'

# Generated at 2022-06-26 04:08:43.134304
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Case 0
    str_0 = 'K,[b<@lbI;&]pW#l8{v["'


# Generated at 2022-06-26 04:08:45.966318
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    assert router.finalize() is None


# Generated at 2022-06-26 04:08:55.680534
# Unit test for constructor of class Router
def test_Router():
    str_0 = 'K,[b<@lbI;&]pW#l8{v["'
    str_1 = ",K,[b<@lbI;&]pW#l8{v["
    int_0 = 2
    str_2 = ".K,[b<@lbI;&]pW#l8{v["
    str_3 = "C,K,[b<@lbI;&]pW#l8{v["
    str_4 = "CK,[b<@lbI;&]pW#l8{v["
    str_5 = "2,K,[b<@lbI;&]pW#l8{v["
    str_6 = "2K,[b<@lbI;&]pW#l8{v["

# Generated at 2022-06-26 04:08:57.099907
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()


# Generated at 2022-06-26 04:09:04.643494
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        test_case_0()
    except Exception as e:
        print('Unhandled exception: ', sys.exc_info()[0])
        raise


# Generated at 2022-06-26 04:09:06.113390
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_case_0()

# Generated at 2022-06-26 04:09:07.583546
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

# Generated at 2022-06-26 04:09:09.965172
# Unit test for constructor of class Router
def test_Router():
    try:
        test_case_0()
    except Exception as e:
        print('Exception: ', e)
        print('Arguments: ', e.args)


# Generated at 2022-06-26 04:09:16.157491
# Unit test for constructor of class Router
def test_Router():
    # Test 1
    str_0 = '4nJY$'
    list_0 = [str_0, str_0]
    bool_0 = False
    router_0 = Router(str_0, list_0, bool_0)


# Generated at 2022-06-26 04:09:17.586348
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

# Generated at 2022-06-26 04:09:18.882459
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_case_0()


# Generated at 2022-06-26 04:09:26.228466
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_0 = '4nJY$'
    list_0 = [str_0, str_0, str_0]
    bool_0 = True
    router_0 = Router(str_0, list_0, bool_0)
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:09:29.301837
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:09:30.198180
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

if __name__ == '__main__':
    test_Router()

# Generated at 2022-06-26 04:09:41.681485
# Unit test for constructor of class Router
def test_Router():
    list_0 = []
    str_0 = '7\x0bs'
    router_0 = Router(str_0)
    assert router_0


# Generated at 2022-06-26 04:09:54.683978
# Unit test for constructor of class Router
def test_Router():
    list_0 = []
    int_0 = -56
    router_0 = Router(int_0)
    # Verify that add instance of Route is returned by method Router.add
    var_0 = router_0.add(int_0, list_0, int_0)
    print(var_0.handler)
    print(var_0.path)
    # Verify that add instance of Route is returned by method Router.add
    var_1 = router_0.add(int_0, list_0, int_0)
    print(var_1.methods)
    print(var_1.path)
    # Verify that get instance of Route is returned by method Router.get
    var_2 = router_0.get(int_0, int_0, bool())
    print(var_2.methods)
    print

# Generated at 2022-06-26 04:09:59.721136
# Unit test for method add of class Router
def test_Router_add():
    list_0 = []
    bool_0 = False
    str_0 = '7\x0bs'
    router_0 = Router(str_0)
    var_0 = router_0.add(str_0, list_0, bool_0, bool_0)


# Generated at 2022-06-26 04:10:04.634130
# Unit test for method finalize of class Router
def test_Router_finalize():
    list_0 = []
    bool_0 = False
    str_0 = '7\x0bs'
    router_0 = Router(str_0)
    router_0.finalize()


# Generated at 2022-06-26 04:10:06.424364
# Unit test for constructor of class Router
def test_Router():
    myrouter = Router("7\x0bs")

# Generated at 2022-06-26 04:10:08.708366
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    router_0.finalize()


# Generated at 2022-06-26 04:10:13.800829
# Unit test for method finalize of class Router
def test_Router_finalize():
    print("[+] Starting test Router_finalize")
    test_case_0()
    print("[-] Test passed successfully")

# Generated at 2022-06-26 04:10:20.487479
# Unit test for method finalize of class Router
def test_Router_finalize():
    list_0 = []
    bool_0 = False
    str_0 = '7\x0bs'
    router_0 = Router(str_0)
    router_0.finalize(list_0, bool_0, bool_0, bool_0)


# Generated at 2022-06-26 04:10:24.035753
# Unit test for constructor of class Router
def test_Router():
    list_0 = []
    bool_0 = False
    str_0 = '7\x0bs'
    router_0 = Router(str_0)
    var_0 = router_0.add(str_0, list_0, bool_0, bool_0)


# Generated at 2022-06-26 04:10:33.080090
# Unit test for method finalize of class Router
def test_Router_finalize():
    # router_0 = Router()
    # var_0 = router_0.finalize()
    list_0 = []
    bool_0 = False
    str_0 = '7\x0bs'
    router_0 = Router(str_0)
    var_0 = router_0.add(str_0, list_0, bool_0, bool_0)
    var_1 = router_0.finalize()


# Generated at 2022-06-26 04:10:45.137201
# Unit test for constructor of class Router
def test_Router():
    list_1 = []
    bool_1 = False
    str_1 = '7\x0bs'
    router_1 = Router(str_1)
    assert(router_1.ctx == '7\x0bs')
    return


# Generated at 2022-06-26 04:10:51.122273
# Unit test for constructor of class Router
def test_Router():
    list_0 = []
    bool_0 = False
    str_0 = '7\x0bs'
    router_0 = Router(str_0)
    var_0 = router_0.add(str_0, list_0, bool_0, bool_0)

# Generated at 2022-06-26 04:10:53.122824
# Unit test for constructor of class Router
def test_Router():
    str_0 = '7\x0bs'
    router_0 = Router(str_0)

# Generated at 2022-06-26 04:11:06.546210
# Unit test for method add of class Router
def test_Router_add():

    list_0 = ["GET", "POST", "OPTIONS"]
    bool_0 = False
    bool_1 = True
    str_0 = "hi1"
    str_1 = '0'
    router_0 = Router(str_0)
    var_0 = router_0.add(str_1, list_0, bool_0, bool_0)
    str_2 = '1'
    var_1 = router_0.add(str_2, list_0, bool_0)
    assert type(var_0) == list
    assert len(var_0) == 1
    assert type(var_1) == list
    assert len(var_1) == 1
    str_3 = '2'

# Generated at 2022-06-26 04:11:18.728345
# Unit test for constructor of class Router
def test_Router():
    list_0 = []
    bool_0 = False
    str_0 = '7\x0bs'
    router_0 = Router(str_0)
    router_0.add(str_0, list_0, bool_0, bool_0)
    list_0.append(bool_0)
    list_1 = []
    list_2 = []
    str_1 = '\x14\x07\t'
    router_1 = Router(str_1)
    router_1.add(str_1, list_2, list_0, list_1)
    list_1.clear()
    list_1.append(list_0)
    list_2.append(bool_0)
    list_2.append(list_1)
    list_3 = []

# Generated at 2022-06-26 04:11:23.111002
# Unit test for constructor of class Router
def test_Router():
    try:
        router_0 = Router('ZQ')
    except Exception as e:
        print("Exception when calling the constructor of Router")
        print(e)


# Generated at 2022-06-26 04:11:31.323276
# Unit test for constructor of class Router

# Generated at 2022-06-26 04:11:38.776812
# Unit test for method finalize of class Router
def test_Router_finalize():
    list_0 = []
    bool_0 = False
    str_0 = '7\x0bs'
    router_0 = Router(str_0)
    var_0 = router_0.add(str_0, list_0, bool_0, bool_0)
    router_0.finalize()

if __name__ == "__main__":
    test_case_0()
    test_Router_finalize()

# Generated at 2022-06-26 04:11:41.785961
# Unit test for constructor of class Router
def test_Router():
    str_0 = 'peacock'
    obj_0 = Router(str_0)

# Generated at 2022-06-26 04:11:46.368648
# Unit test for method finalize of class Router
def test_Router_finalize():
    list_0 = []
    bool_0 = False
    str_0 = '7\x0bs'
    router_0 = Router(str_0)
    router_0.finalize()


# Generated at 2022-06-26 04:12:00.025930
# Unit test for method finalize of class Router
def test_Router_finalize():
    list_0 = []
    bool_0 = False
    str_0 = '7\x0bs'
    router_0 = Router(str_0)
    router_0.finalize()


# Generated at 2022-06-26 04:12:07.577281
# Unit test for constructor of class Router
def test_Router():
    list_0 = []
    bool_0 = False
    str_0 = '7\x0bs'
    router_0 = Router(str_0)
    if router_0 is not None:
        print ("Router created")
    else:
        print ("Router creation failed")


# Generated at 2022-06-26 04:12:13.161201
# Unit test for constructor of class Router
def test_Router():
    assert Router('foo')

    # Prepare mocks
    list_0 = []
    bool_0 = False
    str_0 = '7\x0bs'
    router_0 = Router(str_0)

    # Unit test for add method
    var_0 = router_0.add(str_0, list_0, bool_0, bool_0)
    assert (router_0.ctx.unquote)
    assert (router_0.ctx.unquote_all)

    # Unit test for _get method
    try:
        router_0._get(str_0, str_0, str_0)
    except NotFound:
        assert True

    def my_handler():
        pass

    # Unit test for get method

# Generated at 2022-06-26 04:12:20.475565
# Unit test for method finalize of class Router
def test_Router_finalize():
    # case 0: all test conditions pass, code is valid
    list_0 = []
    bool_0 = False
    str_0 = '7\x0bs'
    router_0 = Router(str_0)
    router_0.finalize()
    assert not router_0.finalized


# Generated at 2022-06-26 04:12:23.981143
# Unit test for method finalize of class Router
def test_Router_finalize():
    list_0 = []
    bool_0 = False
    str_0 = '7\x0bs'
    router_0 = Router(str_0)
    var_0 = router_0.finalize(list_0, str_0)
    assert var_0 == None


# Generated at 2022-06-26 04:12:29.493036
# Unit test for method finalize of class Router
def test_Router_finalize():
    bool_0 = bool()
    list_0 = []
    str_0 = '8'
    router_0 = Router(str_0)
    router_0.finalize(list_0, bool_0)


# Generated at 2022-06-26 04:12:35.901695
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router('W8\x0b')
    list_0 = {}
    list_1 = {}
    assert router_0.routes_all == list_0
    assert router_0.routes_regex == list_1


# Generated at 2022-06-26 04:12:36.736804
# Unit test for constructor of class Router
def test_Router():
    test_case_0()


# Generated at 2022-06-26 04:12:39.002582
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router(str_0)
    router_0.finalize(str_0, str_0)

# Generated at 2022-06-26 04:12:52.091169
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router('\x164\r\xa1z\xd6\x91\xa1\x0e\x11\x04\xe3\x11\xa3\x05\xc1\x90\x02\x01')
    assert(router_0)
    try:
        router_1 = Router('\x1b\x1b \x06\x9b\x8d\xf2\xa6\x1a\xcb\xdc\xde\xdd\x84\x18\x03\x13\x12\xe7\xc5\xcf\xdd\x08\xf5\x9f\x03\xe7')
    except Exception as err:
        assert(type(err) == SanicException)
    else:
        assert(False)

#

# Generated at 2022-06-26 04:13:15.416664
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    str_0 = '3jDNL>V\x0b"HGe='
    iterable_0 = None
    var_0 = router_0.add(str_0, iterable_0, router_0, str_0)
    var_1 = router_0.find_route_by_view_name(str_0)
    tuple_0 = ()
    var_2 = router_0.routes_regex
    var_3 = router_0.routes_static
    var_4 = router_0.routes_dynamic
    var_5 = router_0.routes_all
    dict_0 = {}
    var_6 = router_0.get(str_0, str_0, str_0)


# Generated at 2022-06-26 04:13:24.412338
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    str_0 = '3jDNL>V\x0b"HGe='
    iterable_0 = None
    var_0 = router_0.add(str_0, iterable_0, router_0, str_0)
    # finalize
    try:
        router_0.finalize()
    except SanicException as e:
        assert str(e) == f"Invalid route: {var_0}. Parameter names cannot use '__'."

if __name__ == "__main__":
    test_Router_finalize()

# Generated at 2022-06-26 04:13:29.865211
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    try:
        router_0.finalize()
    except Exception as exception_0:
        print((type(exception_0)))
        raise
    return None

# Generated at 2022-06-26 04:13:31.815412
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    str_0 = '3jDNL>V\x0b"HGe='
    iterable_0 = None
    var_0 = router_0.add(str_0, iterable_0, router_0, str_0)


# Generated at 2022-06-26 04:13:33.227551
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

# Generated at 2022-06-26 04:13:41.787788
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    tuple_0 = (router_0, None)
    str_0 = '3jDNL>V\x0b"HGe='
    iterable_0 = None
    var_0 = router_0.add(str_0, iterable_0, router_0, str_0)
    router_0.finalize()


# Generated at 2022-06-26 04:13:47.431320
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    print("\033[92m{}\033[00m".format("test Router"))
    test_case_0()
    print("\033[1;32m{}\033[00m\n".format("Test success"))


# Entry point for program
if __name__ == '__main__':
    # Unit test for Router class
    test_Router()
    print("\033[1;32m{}\033[00m\n".format("Unit test"))

# Generated at 2022-06-26 04:13:58.210739
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    str_0 = '3jDNL>V\x0b"HGe='
    iterable_0 = None
    var_0 = router_0.add(str_0, iterable_0, router_0, str_0)
    string_0 = "x9N\x16e_\x05n\n~\x00\x1f"
    str_1 = "1"
    dict_0 = {}
    print(router_0.get(string_0, str_1, None))
    print(router_0.add(string_0, iterable_0, router_0, string_0).ctx.hosts)



# Generated at 2022-06-26 04:14:05.982096
# Unit test for constructor of class Router
def test_Router():
    # Test case 0
    router = Router()
    router.all_routes = {}
    router.static_routes = {}
    router.regex_routes = {}
    router.dynamic_routes = {}
    router.name_index = {}


# Generated at 2022-06-26 04:14:09.397780
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    str_0 = 'LJ\x0bT>\x0c\x1e;?3\r&J'
    iterable_0 = None
    var_0 = router_0.add(str_0, iterable_0, router_0, str_0)

# Generated at 2022-06-26 04:14:31.999165
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_1 = Router()
    str_1 = '3jDNL>V\x0b"HGe='
    iterable_1 = None
    router_1.add(str_1, iterable_1, router_1, str_1)
    router_1.finalize()


# Generated at 2022-06-26 04:14:38.348326
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_0 = '/:a/:b/:c'
    obj_0 = Router()
    str_1 = '1'
    str_2 = '2'
    str_3 = '3'
    var_0 = obj_0.resolve(str_0, str_0, {'a': str_1, 'b': str_2, 'c': str_3})
    assert (var_0.ctx.custom_var == str_0)
    assert (var_0.uri_template == str_0)
    #
    # unit test for find_route_by_view_name method of class Router
    #
    def test_Router_find_route_by_view_name():
        str_0 = 'static'
        str_1 = 'static'
        obj_0 = Router()
        var

# Generated at 2022-06-26 04:14:46.783742
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Setting up objects
    router_0 = Router()
    object_0 = ()
    object_1 = ()
    # None
    # Calling method
    try:
        router_0.finalize(object_0, object_1)
    except SanicException as e:
        pass


# Generated at 2022-06-26 04:14:52.069448
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    str_0 = "d$\"@"
    iterable_0 = None
    var_0 = router_0.add(str_0, iterable_0, router_0, str_0)
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:15:04.428778
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    str_0 = '3jDNL>V\x0b"HGe='
    iterable_0 = None
    var_0 = router_0.add(str_0, iterable_0, router_0, str_0)
    str_1 = '3jDNL>V\x0b"HGe='
    str_2 = '3jDNL>V\x0b"HGe='
    var_1 = router_0.get(str_1, str_2, str_1)
    str_3 = '3jDNL>V\x0b"HGe='
    var_2 = router_0.find_route_by_view_name(str_3)
    return router_0, str_0, iterable_0, var_0, str_1

# Generated at 2022-06-26 04:15:15.017250
# Unit test for constructor of class Router
def test_Router():
    #test case 0
    test_case_0()
    #test case 1
    router_0 = Router()
    str_0 = 'TQD:r\x7f'
    str_1 = '\\xdc\\u0007\\x10\\xcc\\x00\\xf9\\xa5\\xa6\\x1d'
    route_0 = router_0.add(str_0, [str_1], router_0, str_0, True)
    iterable_0 = None
    route_0.add(str_0, iterable_0, router_0, str_0, True)
    #test case 2
    router_0 = Router()
    str_0 = '\x1a\\u0003\\x1aB'
    iterable_0 = None
    var_0 = router_0

# Generated at 2022-06-26 04:15:17.876298
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    try:
        router_0.finalize()
    except:
        pass


# Generated at 2022-06-26 04:15:20.796520
# Unit test for constructor of class Router
def test_Router():
    try:
        test_case_0()
        assert True
    except AssertionError:
        assert False



# Generated at 2022-06-26 04:15:27.089448
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    str_0 = 'Nv+!dU4\x1d\x1e8G[A'
    str_1 = '=aFmf@}(@X]0-\x01`'
    list_0 = [str_0, str_1]
    # Parameter1: Router
    # Parameter2: None
    # Parameter3: list
    # Parameter4: str
    # Parameter5: list
    # Parameter6: str
    # Parameter7: str
    # Parameter8: int
    # Parameter9: str
    # Parameter10: bool
    # Parameter11: bool
    # Parameter12: bool
    # Parameter13: bool
    # Parameter14: None
    # Parameter15: str
    var_0

# Generated at 2022-06-26 04:15:30.497363
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()


if __name__ == "__main__":
    test_case_0()
    test_Router()