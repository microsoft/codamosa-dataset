

# Generated at 2022-06-26 04:05:38.531319
# Unit test for method finalize of class Router
def test_Router_finalize():
    pass



# Generated at 2022-06-26 04:05:44.770257
# Unit test for method finalize of class Router
def test_Router_finalize():
    type_0 = None
    bool_0 = None
    router_0 = Router(type_0, bool_0)

    try:
        router_1 = router_0.finalize()
    except Exception as e:
        print(e)


# Generated at 2022-06-26 04:05:45.976953
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

# Generated at 2022-06-26 04:05:53.935966
# Unit test for constructor of class Router
def test_Router():
    type_0 = None
    bool_0 = None
    router_0 = Router(type_0, bool_0)

    str_0 = "yV7X^Ky<4:Vn5?E|'2!7x>x<"
    str_1 = "dNh~X9faN_o07&0/pU6h,8!e"
    tuple_0 = (str_0, str_1)
    route_handler_0 = None
    route_0 = router_0.add(*tuple_0, route_handler_0)
    route_handler_1 = None
    dict_0 = {'host': None}
    tuple_1 = router_0.get(route_handler_1, *tuple_0, **dict_0)
    route_1 = tuple_1[0]

# Generated at 2022-06-26 04:05:57.650830
# Unit test for method finalize of class Router
def test_Router_finalize():
    type_2 = None
    bool_2 = None
    router_2 = Router(type_2, bool_2)
    assert router_2.finalize() == None


# Generated at 2022-06-26 04:06:01.555900
# Unit test for constructor of class Router
def test_Router():
    type_0 = None
    bool_0 = None
    # router_0 = Router(type_0, bool_0)



# Generated at 2022-06-26 04:06:08.681239
# Unit test for constructor of class Router
def test_Router():
    class_0 = Router
    type_0 = None
    bool_0 = None
    obj = class_0(type_0, bool_0)
    assert isinstance(obj, class_0)


if __name__ == "__main__":
    test_case_0()
    test_Router()

# Generated at 2022-06-26 04:06:15.497330
# Unit test for constructor of class Router

# Generated at 2022-06-26 04:06:17.024929
# Unit test for constructor of class Router
def test_Router():
    type_0 = None
    bool_0 = None
    router_0 = Router(type_0, bool_0)


# Generated at 2022-06-26 04:06:19.846293
# Unit test for constructor of class Router
def test_Router():
    try:
        type_0 = None
        bool_0 = None
        router_0 = Router(type_0, bool_0)
    except TypeError as e:
        print("Exception expected: ", e)
    except Exception as e:
        raise e


# Generated at 2022-06-26 04:06:30.650112
# Unit test for constructor of class Router
def test_Router():
    str_0 = 'oSg8'
    list_0 = []
    dict_0 = {str_0: str_0}
    router_0 = Router(str_0, list_0, dict_0)
    var_0 = router_0.finalize()

    if isinstance(router_0, Router):
        print("It is an instance of Router")
    else:
        print("It is not an instance of Router")

    if isinstance(router_0, BaseRouter):
        print("It is an instance of BaseRouter")
    else:
        print("It is not an instance of BaseRouter")


# Generated at 2022-06-26 04:06:42.476838
# Unit test for constructor of class Router
def test_Router():
    str_0 = 'PbUz'
    list_0 = [str_0]
    dict_0 = {str_0: list_0}
    router_0 = Router(str_0, list_0, dict_0)
    var_0 = router_0.static_routes
    var_1 = router_0.regex_routes
    var_2 = router_0.dynamic_routes
    var_3 = router_0.routes
    var_4 = router_0.routes_all
    var_5 = router_0.routes_static
    var_6 = router_0.routes_dynamic
    var_7 = router_0.routes_regex
    var_8 = router_0.finalize()
    #Test Case #0

# Generated at 2022-06-26 04:06:55.312017
# Unit test for method add of class Router
def test_Router_add():
    assert Router.add.__module__ == 'sanic.router.router'
    assert Router.add.__name__ == 'add'
    # default case
    # test only with args
    # TODO: add uri
    # TODO: add methods
    # TODO: add handler
    # TODO: add host
    # TODO: add strict_slashes
    # TODO: add stream
    # TODO: add ignore_body
    # TODO: add version
    # TODO: add name
    # TODO: add unquote
    # TODO: add static
    # default case with only args, default value
    # TODO: add uri
    # TODO: add methods
    # TODO: add handler
    # TODO: add host
    # TODO: add strict_slashes
    #

# Generated at 2022-06-26 04:07:01.669327
# Unit test for constructor of class Router
def test_Router():
    str_0 = 'oSg8'
    list_0 = []
    dict_0 = {str_0: str_0}
    router_0 = Router(str_0, list_0, dict_0)
    assert(str_0 == router_0.ctx.prefix)
    assert(dict(oSg8='oSg8') == router_0.ctx.requirements)
    assert(list() == router_0.ctx.hosts)

# Generated at 2022-06-26 04:07:03.823533
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

# Generated at 2022-06-26 04:07:05.130219
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_case_0()


# Generated at 2022-06-26 04:07:08.708992
# Unit test for constructor of class Router
def test_Router():
    str_0 = 'oSg8'
    list_0 = []
    dict_0 = {str_0: str_0}
    router_0 = Router(str_0, list_0, dict_0)
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:07:11.285150
# Unit test for constructor of class Router
def test_Router():
    from test_bench_0 import test_case_0
    test_case_0()

test_Router()

# Generated at 2022-06-26 04:07:14.131849
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-26 04:07:26.411587
# Unit test for constructor of class Router
def test_Router():
    str_0 = 'oSg8'
    list_0 = []
    dict_0 = {str_0: str_0}
    router_0 = Router(str_0, list_0, dict_0)
    str_1 = 'finalize'
    var_0 = hasattr(router_0, str_1)
    str_2 = 'routes_all'
    var_1 = hasattr(router_0, str_2)
    str_3 = 'routes_static'
    var_2 = hasattr(router_0, str_3)
    str_4 = 'routes_dynamic'
    var_3 = hasattr(router_0, str_4)
    str_5 = 'routes_regex'

# Generated at 2022-06-26 04:07:32.949340
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

test_Router()

# Generated at 2022-06-26 04:07:39.629524
# Unit test for constructor of class Router
def test_Router():
    str_0 = 'oSg8'
    list_0 = []
    dict_0 = {str_0: str_0}
    router_0 = Router(str_0, list_0, dict_0)

# END OF TEST

# Test generator for test case 0



# Generated at 2022-06-26 04:07:41.307948
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_case_0()

# Run tests for class Router

# Generated at 2022-06-26 04:07:42.382334
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_case_0()

if __name__ == "__main__":
    test_Router_finalize()

# Generated at 2022-06-26 04:07:47.387830
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_0 = 'oSg8'
    list_0 = []
    dict_0 = {str_0: str_0}
    router_0 = Router(str_0, list_0, dict_0)
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:07:48.128410
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_case_0()

# Generated at 2022-06-26 04:07:50.237450
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_case_0()

# Unit tests for class Router

# Generated at 2022-06-26 04:07:50.824967
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_case_0()

# Generated at 2022-06-26 04:07:54.968856
# Unit test for constructor of class Router
def test_Router():
    str_0 = 'oSg8'
    list_0 = []
    dict_0 = {str_0: str_0}
    Router(str_0, list_0, dict_0)

# Generated at 2022-06-26 04:08:03.620646
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_0 = 'oSg8'
    list_0 = []
    dict_0 = {str_0: str_0}
    router_0 = Router(str_0, list_0, dict_0)
    str_1 = 'tOgs'
    router_0.finalize(*[str_1, str_1], **{str_0: str_0})


# Generated at 2022-06-26 04:08:18.217014
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_0 = 'oSg8'
    list_0 = []
    dict_0 = {str_0: str_0}
    router_0 = Router(str_0, list_0, dict_0)
    method_object_0 = router_0.finalize
    var_0 = callable(method_object_0)
    assert var_0


# Generated at 2022-06-26 04:08:26.173451
# Unit test for constructor of class Router
def test_Router():
    str_0 = 'oSg8'
    list_0 = []
    dict_0 = {str_0: str_0}
    router_0 = Router(str_0, list_0, dict_0)
    var_0 = router_0.DEFAULT_METHOD
    var_1 = router_0.ALLOWED_METHODS


# Generated at 2022-06-26 04:08:28.387525
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router('oSg8', [], {'oSg8': 'oSg8'})
    router.finalize()



# Generated at 2022-06-26 04:08:37.534364
# Unit test for constructor of class Router
def test_Router():
    str_0 = 'oSg8'
    list_0 = []
    dict_0 = {str_0: str_0}
    router_0 = Router(str_0, list_0, dict_0)
    var_0 = router_0.finalize()
    print(var_0)
    #print(router_0.routes_dynamic)

if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-26 04:08:49.462380
# Unit test for method add of class Router
def test_Router_add():
    str_0 = 'oSg8'
    list_0 = []
    dict_0 = {str_0: str_0}
    router_0 = Router(str_0, list_0, dict_0)
    str_1 = 'uRiR'
    list_1 = []
    dict_1 = {str_1: str_1}
    route_0 = router_0.add(str_0, list_1, dict_1)
    def f0():
        pass
    var_0 = router_0.add(str_0, list_1, f0)


# Generated at 2022-06-26 04:08:55.399577
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_0 = 'oSg8'
    list_0 = []
    dict_0 = {str_0: str_0}
    router_0 = Router(str_0, list_0, dict_0)
    var_0 = router_0.finalize()



# Generated at 2022-06-26 04:08:56.861859
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_case_0()


# Generated at 2022-06-26 04:09:01.549649
# Unit test for constructor of class Router
def test_Router():
    str_0 = 'oSg8'
    list_0 = []
    dict_0 = {str_0: str_0}
    router_0 = Router(str_0, list_0, dict_0)
    var_0 = router_0.finalize()

# Generated at 2022-06-26 04:09:02.451076
# Unit test for constructor of class Router
def test_Router():
    test_case_0()
    print('Pass test case 0')

# Generated at 2022-06-26 04:09:04.106509
# Unit test for constructor of class Router
def test_Router():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-26 04:09:30.550973
# Unit test for constructor of class Router
def test_Router():
    str_1 = 'oSg8'
    list_1 = []
    dict_1 = {str_1: str_1}
    router_1 = Router(str_1, list_1, dict_1)
    for key in dict_1:
        print(key, dict_1[key])


# Generated at 2022-06-26 04:09:33.977704
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router('', [], {})
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:09:40.852794
# Unit test for constructor of class Router
def test_Router():
    # Check initialize constructor
    str_0 = 'oSg8'
    list_0 = []
    dict_0 = {str_0: str_0}
    router_0 = Router(str_0, list_0, dict_0)
    # Check method finalize
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:09:42.474808
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

test_Router()

# Generated at 2022-06-26 04:09:54.998176
# Unit test for method add of class Router
def test_Router_add():
    router_0 = Router("", [], {})
    route = router_0.add("", ["", ""], lambda request: None)
    assert isinstance(route, Route)
    uri = ""
    methods = ["", ""]
    handler = lambda request: None
    assert route == router_0.add(uri, methods, handler)
    str_0 = ''
    list_0 = []
    route = router_0.add('', list_0, lambda request: None, '')
    assert isinstance(route, Route)
    uri = ''
    methods = []
    handler = lambda request: None
    assert route == router_0.add(uri, methods, handler, '')
    route = router_0.add('', ['', ''], lambda request: None, '')
    assert isinstance(route, Route)
   

# Generated at 2022-06-26 04:10:04.243325
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        test_case_0()
    except Exception as e:
        print("Error in testcase 0")
        print(e)
    try:
        str_0 = 'VjG'
        str_1 = 'ZYn'
        dict_0 = {str_0: str_1}
        list_0 = [str_1, str_1]
        router_0 = Router(str_0, list_0, dict_0)
        var_0 = router_0.finalize(str_0, list_0)
    except Exception as e:
        print("Error in testcase 1")
        print(e)

if __name__ == '__main__':
    test_Router_finalize()

# Generated at 2022-06-26 04:10:09.308569
# Unit test for constructor of class Router
def test_Router():
    str_0 = 'oSg8'
    dict_0 = {}
    list_0 = [str_0]
    Router(str_0, list_0, dict_0)


# Generated at 2022-06-26 04:10:12.506257
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_0 = 'oSg8'
    list_0 = []
    dict_0 = {str_0: str_0}
    router_0 = Router(str_0, list_0, dict_0)
    var_0 = router_0.finalize()

# Generated at 2022-06-26 04:10:20.219848
# Unit test for constructor of class Router
def test_Router():
    str_0 = 'oSg8'
    list_0 = []
    dict_0 = {str_0: str_0}
    router_0 = Router(str_0, list_0, dict_0)
    str_1 = 'G5%c'
    str_2 = 'U1~l'
    str_3 = 'WkK8'
    list_1 = [str_3]
    route_0 = router_0.add(str_1, list_1, str_2)
    list_2 = ['Eywy', str_2, str_2, str_2, str_2, str_2, str_1, str_2, str_2, route_0]

# Generated at 2022-06-26 04:10:22.717577
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Test method of class Router without args
    try:
        test_case_0()
    except Exception as ex:
        print(ex)


# Generated at 2022-06-26 04:11:05.301441
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_0 = 'oSg8'
    list_0 = []
    dict_0 = {str_0: str_0}
    router_0 = Router(str_0, list_0, dict_0)
    var_0 = router_0.finalize()

# Generated at 2022-06-26 04:11:09.454805
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_case_0()

ROUTER_CACHE_SIZE = 1024
ALLOWED_LABELS = ("__file_uri__",)



# Generated at 2022-06-26 04:11:12.697971
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:11:16.910031
# Unit test for constructor of class Router
def test_Router():
    str_0 = 'oSg8'
    list_0 = []
    dict_0 = {str_0: str_0}
    router_0 = Router(str_0, list_0, dict_0)
    assert router_0.finalize() == None


# Generated at 2022-06-26 04:11:19.314741
# Unit test for constructor of class Router
def test_Router():
    str_0 = 'oSg8'
    list_0 = []
    dict_0 = {str_0: str_0}
    router_0 = Router(str_0, list_0, dict_0)
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:11:27.437206
# Unit test for constructor of class Router
def test_Router():
    str_0 = 'oSg8'
    list_0 = []
    dict_0 = {str_0: str_0}

    try:
        router_0 = Router(str_0, list_0, dict_0)
    except Exception as e:
        print('Exception:', e)
        assert False

    assert isinstance(router_0, BaseRouter)

# Stress test for constructor of class Router

# Generated at 2022-06-26 04:11:40.424470
# Unit test for method finalize of class Router
def test_Router_finalize():
    # test for multiple type of uri and multiple types of handler
    router = Router('oSg8', [], {})
    # dynamic route
    uri = '/test_dynamic_route/<param>'
    handler = lambda request, response, param: None
    router.add(uri, ['GET'], handler)
    # static route
    uri = '/test_static_route'
    router.add(uri, ['GET'], handler)
    # regex route
    uri = '/test_regex_route/[a-zA-Z]+'
    router.add(uri, ['GET'], handler)
    try:
        router.finalize()
    except:
        print('ERROR: Failed to finalize.')
        return -1

# Generated at 2022-06-26 04:11:48.591430
# Unit test for method add of class Router
def test_Router_add():
    str_0 = 'dxvH'
    list_0 = []
    dict_0 = {str_0: str_0}
    router_0 = Router(str_0, list_0, dict_0)
    str_1 = 'yRKy'
    list_1 = []
    handler_0 = RouteHandler()
    var_0 = router_0.add(str_1, list_1, handler_0)
    return


# Generated at 2022-06-26 04:11:58.231588
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_0 = 'oSg8'
    list_0 = []
    dict_0 = {str_0: str_0}
    router_0 = Router(str_0, list_0, dict_0)
    var_0 = router_0.finalize()
    assert isinstance(var_0, Router)
    assert hasattr(var_0, 'DEFAULT_METHOD')
    assert hasattr(var_0, 'ALLOWED_METHODS')
    assert hasattr(var_0, '_get')
    assert hasattr(var_0, 'get')
    assert hasattr(var_0, 'add')
    assert hasattr(var_0, 'find_route_by_view_name')
    assert hasattr(var_0, 'routes_all')

# Generated at 2022-06-26 04:12:06.122723
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_0 = 'oSg8'
    list_0 = []
    dict_0 = {str_0: str_0}
    router_0 = Router(str_0, list_0, dict_0)
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:13:21.401123
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_case_0()


# Generated at 2022-06-26 04:13:22.327533
# Unit test for constructor of class Router
def test_Router():
    # test case: 0
    test_case_0()


# Generated at 2022-06-26 04:13:25.210691
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    Test for method finalize of class Router
    """
    test_case_0()

# Generated at 2022-06-26 04:13:27.289022
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

# Generated at 2022-06-26 04:13:29.499138
# Unit test for method finalize of class Router
def test_Router_finalize():
    assert test_case_0() is None


# Generated at 2022-06-26 04:13:34.208766
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_0 = 'H'
    list_0 = []
    dict_0 = {str_0: str_0}
    router_0 = Router(str_0, list_0, dict_0)
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:13:38.886284
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        test_case_0()
        assert False
    except SanicException:
        assert True
    else:
        assert False



# Generated at 2022-06-26 04:13:40.348455
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

# Generated at 2022-06-26 04:13:45.297178
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_0 = 'oSg8'
    list_0 = []
    dict_0 = {str_0: str_0}
    router_0 = Router(str_0, list_0, dict_0)
    var_0 = router_0.finalize()
    assert var_0 is None


# Generated at 2022-06-26 04:13:47.117400
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_case_0()
