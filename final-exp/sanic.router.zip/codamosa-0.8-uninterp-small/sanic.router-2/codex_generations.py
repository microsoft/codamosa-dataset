

# Generated at 2022-06-26 04:05:56.668032
# Unit test for method finalize of class Router
def test_Router_finalize():
    bool_0 = False
    router_0 = Router()
    try:
        router_0.finalize()
    except:
        bool_0 = True
    assert bool_0


# Generated at 2022-06-26 04:05:58.015854
# Unit test for constructor of class Router
def test_Router():
    test_case_0()


# Generated at 2022-06-26 04:05:59.431023
# Unit test for constructor of class Router
def test_Router():
    test_case_0()



# Generated at 2022-06-26 04:06:09.251146
# Unit test for method finalize of class Router
def test_Router_finalize():
    bool_0 = False
    router_0 = Router()
    class_0 = SanicException()
    exception_0 = SanicException()
    router_0.dynamic_routes = {
        'int_0': Route(
            'str_0',
            'str_0',
            requirements=dict(),
            name=None,
            defaults=dict(),
            host=None,
            strict=bool_0
        )
    }
    router_0.finalize()


test_Router_finalize()

# Generated at 2022-06-26 04:06:15.385462
# Unit test for method add of class Router
def test_Router_add():
    test_Router_add_path_0 = str()
    test_Router_add_methods_0 = list()
    test_Router_add_handler_0 = RouteHandler()
    test_Router_add_host_0 = None
    test_Router_add_strict_slashes_0 = False
    test_Router_add_stream_0 = False
    test_Router_add_ignore_body_0 = False
    test_Router_add_version_0 = None
    test_Router_add_name_0 = None
    test_Router_add_unquote_0 = False
    test_Router_add_static_0 = False

    # Replace the following line with your implementation
    raise NotImplementedError()


# Generated at 2022-06-26 04:06:17.038288
# Unit test for constructor of class Router
def test_Router():
    bool_0 = False
    router_0 = Router()

    assert type(router_0) == Router



# Generated at 2022-06-26 04:06:23.804971
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    # Test case 0 should raise SanicException
    try:
        router.finalize()
    except SanicException:
        pass
    # Test case 1 should pass
    router_0 = Router()

# Generated at 2022-06-26 04:06:25.540477
# Unit test for constructor of class Router
def test_Router():
    # Test constructor of Router
    test_case_0()


if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-26 04:06:30.552620
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    assert router_0.ctx.router == router_0
    assert isinstance(router_0, Router)
    assert router_0.dynamic_routes == {}
    assert router_0.ctx.app == None
    assert router_0.name_index == {}
    assert router_0.ctx.allowed_methods == {'HEAD', 'OPTIONS', 'GET', 'POST', 'PUT', 'PATCH', 'DELETE'}
    assert router_0.routes == {}
    assert router_0.static_routes == {}


# Generated at 2022-06-26 04:06:36.454373
# Unit test for constructor of class Router
def test_Router():
    try:
        router_0 = Router()
    except:
        print('Error: Constructor of class Router raises an exception.')
        raise
    else:
        print('Constructor of class Router does not raise an exception.')

# Generated at 2022-06-26 04:06:44.228319
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    router_0.finalize()
    assert router_0.dynamic_routes is not None
    assert router_0.regex_routes is not None
    assert router_0.static_routes is not None



# Generated at 2022-06-26 04:06:50.964542
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == []
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == {}
    assert router.ctx == router.ctx

# Generated at 2022-06-26 04:06:53.555765
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    try:
        router_0.finalize()
    except Exception:
        assert False


# Generated at 2022-06-26 04:06:55.404304
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    assert router_0.finalize() is None


# Generated at 2022-06-26 04:07:01.696283
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.dynamic_routes['/user/<name>/<id>'] = Route('/user/<name>/<id>', None, None, None, None, False)
    router.dynamic_routes['/user/<names>/<id>'] = Route('/user/<names>/<id>', None, None, None, None, False)
    router.finalize()


# Generated at 2022-06-26 04:07:05.991509
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)
    assert isinstance(router, BaseRouter)


# Generated at 2022-06-26 04:07:08.702224
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()  # type: ignore
    assert isinstance(router_0, Router)


# Generated at 2022-06-26 04:07:09.654430
# Unit test for method finalize of class Router
def test_Router_finalize():
    assert Router().finalize(None, None) == None


# Generated at 2022-06-26 04:07:15.367367
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()

    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}

    router.add("/", ["GET"], finalize)

    assert router.routes_all == {
        "GET ": Route(None, "/", finalize, ["GET"], None, False, False, False, False)
    }
    assert router.routes_static == {"GET /": Route(None, "/", finalize, ["GET"], None, False, False, False, False)}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-26 04:07:17.981101
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_obj = Router()
    router_obj.finalize()


# Generated at 2022-06-26 04:07:31.689217
# Unit test for constructor of class Router
def test_Router():
    try:
        router_0 = Router()
        assert True
    except:
        assert False


# Generated at 2022-06-26 04:07:33.607562
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    assert isinstance(router_0, Router) == True


# Generated at 2022-06-26 04:07:35.378621
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router


# Generated at 2022-06-26 04:07:38.251500
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_1 = Router()
    router_1.finalize()
    assert router_1



# Generated at 2022-06-26 04:07:40.388518
# Unit test for constructor of class Router
def test_Router():
    assert isinstance(Router(), Router)



# Generated at 2022-06-26 04:07:43.707208
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    router_0.add('/users', ['POST'], test_case_0)



# Generated at 2022-06-26 04:07:47.820959
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    with pytest.raises(SanicException):
        router_0.finalize()


# Generated at 2022-06-26 04:07:49.947616
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    assert router_0 == router_0


# Generated at 2022-06-26 04:07:55.749204
# Unit test for constructor of class Router
def test_Router():
    router_1 = Router()
    assert router_1.ctx.app is None
    assert router_1.dynamic_routes == {}
    assert router_1.static_routes == {}
    assert router_1.regex_routes == {}


if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-26 04:08:05.149868
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router.ctx, type)
    assert hasattr(router.ctx, 'app')
    assert router.ctx.app != None
    assert hasattr(router, 'routes')
    assert isinstance(router.routes, dict)
    assert hasattr(router, 'name_index')
    assert isinstance(router.name_index, dict)


# Generated at 2022-06-26 04:08:36.828314
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)
    assert isinstance(router, BaseRouter)
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == []


# Generated at 2022-06-26 04:08:39.822836
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic import Sanic
    from sanic_routing import Router, RoutedMethods
    app_0 = Sanic()
    router_0 = Router(app_0)
    with pytest.raises(SanicException):
        router_0.finalize()

# Generated at 2022-06-26 04:08:44.340181
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import InvalidUsage
    router = Router()
    r = router.add("/", ["GET"], lambda request: "hello")
    r.uri_template
    router.finalize()
    r.uri_template
    # test add duplicate name
    r = router.add("/", ["GET"], lambda request: "hello", name="test")
    router.finalize()
    r = router.add("/", ["GET"], lambda request: "hello", name="test")
    try:
        router.finalize()
    except (InvalidUsage) as e:
        assert e.status_code == 500
        assert e.args[0] == "Route 'test' already exists"


# Generated at 2022-06-26 04:08:47.722731
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    assert router_0.finalize(1, 2) == 2

# Generated at 2022-06-26 04:08:48.677518
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.finalize()

# Generated at 2022-06-26 04:09:00.980151
# Unit test for constructor of class Router
def test_Router():
    """
    Test cases for the constructor of class Router
    """
    router_0 = Router()
    router_1 = Router()

    """
    Test case for default constructor of class Router
    """
    assert router_0.routes_all.keys() == set()
    assert router_1.routes_all.keys() == set()
    assert router_0.routes_static.keys() == set()
    assert router_1.routes_static.keys() == set()
    assert router_0.routes_dynamic.keys() == set()
    assert router_1.routes_dynamic.keys() == set()
    assert router_0.routes_regex.keys() == set()
    assert router_1.routes_regex.keys() == set()
    assert router

# Generated at 2022-06-26 04:09:03.041276
# Unit test for constructor of class Router
def test_Router():
    # Test for constructor of class Router
    test_case_0()

# Generated at 2022-06-26 04:09:05.761517
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, BaseRouter)


# Generated at 2022-06-26 04:09:07.875680
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    router_0.finalize()

# Generated at 2022-06-26 04:09:15.622156
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Create a router
    router = Router()

    # Create a route
    def my_route():
        pass
    route = router.add(uri = "", methods = ['GET'], handler = my_route)

    # Finalize the router
    router.finalize()
    routes_all = router.routes_all
    routes_dynamic = router.routes_dynamic
    routes_static = router.routes_static

    # Validate
    assert routes_all == [route]
    assert routes_dynamic == {"": route}
    assert routes_static == {"": route}
    assert not hasattr(router, 'routes_regex')

if __name__ == "__main__":
    test_Router_finalize()

# Generated at 2022-06-26 04:10:05.868696
# Unit test for constructor of class Router
def test_Router():
    print("Test for constructor of class Router")
    router_0 = Router()
    assert router_0.__class__ == Router
    assert router_0.DEFAULT_METHOD == "GET"
    assert router_0.ALLOWED_METHODS == HTTP_METHODS
    assert router_0.get.__class__ == lru_cache
    assert router_0.add.__class__ == lru_cache
    assert router_0.find_route_by_view_name.__class__ == lru_cache
    assert router_0.routes_all == []
    assert router_0.routes_static == []
    assert router_0.routes_dynamic == {}
    assert router_0.routes_regex == []
    print("Test passed")


# Generated at 2022-06-26 04:10:09.382668
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    assert router_0 is not None
    assert isinstance(router_0, Router)


# Generated at 2022-06-26 04:10:12.779675
# Unit test for method add of class Router
def test_Router_add():
    router_0 = Router()
    int_0 = router_0.add('path_0', ('GET', ), None)
    if isinstance(router_0.routes_all[int_0], Route) is False:
        raise AssertionError()


# Generated at 2022-06-26 04:10:13.800887
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()


# Generated at 2022-06-26 04:10:15.263002
# Unit test for method finalize of class Router
def test_Router_finalize():
    assert True


# Generated at 2022-06-26 04:10:24.752970
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route("1", "2", "3", "4", "5")
    router.add(route)

    # Test the case that when adding an invalid route, the function `finalize` will throw an exception
    try:
        router.add(Route("1", "2", "3", "4", "5"))
    except SanicException:
        assert True
    else:
        assert False

    # Test the case that when adding a normal route, the function will not throw an exception
    router.add(Route("1", "2", "3", "4", "5", "6"))
    router.finalize()
    assert True

if __name__ == "__main__":
    test_case_0()
    test_Router_finalize()

# Generated at 2022-06-26 04:10:35.666451
# Unit test for method finalize of class Router
def test_Router_finalize():

    path = "/map"
    method = "GET"
    host = "localhost"
    uri = "map"
    methods = [method]
    handler = "handler"
    strict_slashes = False
    stream = False
    ignore_body = False
    version = 2.0
    name = "name"
    unquote = False
    static = False

    assert path == "/map"
    assert method == "GET"
    assert host == "localhost"
    assert uri == "map"
    assert methods == [method]
    assert handler == "handler"
    assert strict_slashes == False
    assert stream == False
    assert ignore_body == False
    assert version == 2.0
    assert name == "name"
    assert unquote == False
    assert static == False

    router_1 = Router()
    router

# Generated at 2022-06-26 04:10:36.509840
# Unit test for method finalize of class Router
def test_Router_finalize():

    router = Router()
    router.finalize()

# Generated at 2022-06-26 04:10:39.788982
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)
    assert isinstance(router, BaseRouter)


# Generated at 2022-06-26 04:10:42.598895
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert len(router.routes_all) == 0


# Generated at 2022-06-26 04:11:26.085992
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    assert router_0.routes_all == []

# Generated at 2022-06-26 04:11:28.960697
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    assert router_0.routes_all == {}


# Generated at 2022-06-26 04:11:37.116604
# Unit test for constructor of class Router
def test_Router():
    var_0 = Router()
    var_1 = type(var_0)
    var_2 = str(var_1)
    var_3 = var_2 == "<class 'sanic.router.Router'>"
    var_4 = var_0.routes_all
    var_5 = len(var_4)
    

# Generated at 2022-06-26 04:11:38.757297
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

# Generated at 2022-06-26 04:11:41.165995
# Unit test for constructor of class Router
def test_Router():
    print("Testing constructor of class Router")
    test_case_0()


# Generated at 2022-06-26 04:11:51.151825
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    var_0 = router_0.routes_all
    var_1 = len(var_0)
    router_1 = Router()
    var_2 = router_0.routes_all
    var_3 = len(var_2)
    var_4 = var_3 == 0

    # self.assertIsInstance(var_0, dict)
    # self.assertEqual(var_1, 0)
    # self.assertIsInstance(var_2, dict)
    # self.assertEqual(var_3, 0)
    # self.assertEqual(var_4, True)



# Generated at 2022-06-26 04:11:55.340011
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    Test for method finalize of class Router
    """
    router_0 = Router()
    var_0 = router_0.routes_all
    var_1 = len(var_0)
    router_0.finalize()
    var_0 = router_0.routes_all
    var_1 = len(var_0)


# Generated at 2022-06-26 04:11:57.500742
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    router_0.finalize()



# Generated at 2022-06-26 04:12:07.628700
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router.create_router(None)
    var_0 = router_0.routes_all
    var_1 = len(var_0)
    var_2 = router_0.ctx
    var_3 = router_0.ctx.app
    var_4 = router_0.ctx.router
    var_5 = router_0.routes_static
    var_6 = len(var_5)
    var_7 = router_0.routes_dynamic
    var_8 = len(var_7)
    var_9 = router_0.routes_regex
    var_10 = len(var_9)
    var_11 = router_0.name_index
    var_12 = len(var_11)
    var_13 = router_0.host_

# Generated at 2022-06-26 04:12:09.833859
# Unit test for method finalize of class Router
def test_Router_finalize():

    # params: ()
    # return: None
    # exception: SanicException(f"Invalid route: {route}. Parameter names cannot use '__'."),
    # SanicException(f"Invalid route: {route}. Parameter names cannot use '__'."),
    # Line (71)
    test_case_0()

# Generated at 2022-06-26 04:13:34.575876
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    try:
        router_0.finalize(0)
    except NotImplementedError:
        pass
    except SanicException:
        pass


# Generated at 2022-06-26 04:13:41.578748
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.ctx.app is None
    assert router.routes_all is None
    assert router.routes_static is None
    assert router.routes_dynamic is None
    assert router.routes_regex is None
# unit test for path of class Router

# Generated at 2022-06-26 04:13:42.796965
# Unit test for method add of class Router
def test_Router_add():
    router_0 = Router()
    router_0.add('/' , [], lambda x : '')


# Generated at 2022-06-26 04:13:43.814884
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    print(router_0.routes_all)


# Generated at 2022-06-26 04:13:49.499424
# Unit test for constructor of class Router
def test_Router():
    router_1 = Router()
    len(router_1.routes_all)
    len(router_1.routes_static)
    len(router_1.routes_dynamic)
    len(router_1.routes_regex)
    router_1.routes_all
    router_1.routes_static
    router_1.routes_dynamic
    router_1.routes_regex
    router_1.DEFAULT_METHOD
    router_1.ALLOWED_METHODS
    router_2 = Router()
    var_2 = router_2.routes_all
    var_3 = len(var_2)
    class_1 = object()
    router_3 = Router()

# Generated at 2022-06-26 04:13:54.185894
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    var_0 = router_0._get('path', 'method', 'host')
    var_1 = router_0.get('path', 'method', 'host')

# Generated at 2022-06-26 04:13:55.876395
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    assert len(router_0.routes_all) == 0



# Generated at 2022-06-26 04:14:09.081248
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    var_0 = router_0.routes_all
    var_1 = len(var_0)
    var_2 = var_0[0].ctx.hosts
    var_3 = var_0[0].ctx.ignore_body
    var_4 = var_0[0].ctx.stream
    var_5 = var_0[0].ctx.static
    var_6 = router_0.routes_static
    var_7 = len(var_6)
    var_8 = router_0.routes_dynamic
    var_9 = len(var_8)
    var_10 = router_0.routes_regex
    var_11 = len(var_10)

# Generated at 2022-06-26 04:14:14.377647
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        router_0 = Router()
        router_0.finalize()
    except SanicException as e:
        assert str(e) == "Invalid route: None. Parameter names cannot use '__'."


# Generated at 2022-06-26 04:14:21.451356
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    var_0 = router_0.routes_all
    var_1 = len(var_0)
    var_0 = router_0.routes_static
    var_1 = len(var_0)
    var_0 = router_0.routes_dynamic
    var_1 = len(var_0)
    var_0 = router_0.routes_regex
    var_1 = len(var_0)


# Generated at 2022-06-26 04:15:36.487854
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    var_0 = router_0.routes_all
    router_0.finalize()
    router_0._finalized = True
    try:
        var_1 = router_0.routes_all
    except Exception as inst:
        var_2 = inst
    else:
        var_2 = None
    var_3 = hasattr(var_2, "__module__")


if __name__ == "__main__":
    import __main__

    testing_function = getattr(__main__, sys.argv[1])
    testing_function()

# Generated at 2022-06-26 04:15:46.601058
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()