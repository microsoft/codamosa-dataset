

# Generated at 2022-06-26 04:05:38.674985
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_0 = 'y{^GJ7'
    bool_0 = True
    router_0 = Router(str_0, bool_0)
    router_0.finalize()

# Generated at 2022-06-26 04:05:44.915198
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        str_0 = '*suseB~pu^x'
        bool_0 = None
        router_0 = Router(str_0, bool_0)
        router_0.finalize()
    except Exception:
        assert False


# Generated at 2022-06-26 04:05:47.622046
# Unit test for constructor of class Router
def test_Router():
    # Constructor
    str_0 = '*suseB~pu^x'
    bool_0 = None
    router_0 = Router(str_0, bool_0)

# Generated at 2022-06-26 04:05:52.135715
# Unit test for constructor of class Router
def test_Router():
    str_0 = '*suseB~pu^x'
    bool_0 = None
    router_0 = Router(str_0, bool_0)


# Generated at 2022-06-26 04:05:54.973176
# Unit test for method finalize of class Router
def test_Router_finalize():
    str_0 = 'KKb%c=p3qj'
    bool_0 = False
    router = Router(str_0, bool_0)
    args = []
    kwargs = {'c%j': 'zU_wF0', '6hjb': None, '[': None, '+X9': '^'}
    router.finalize(args, kwargs)



# Generated at 2022-06-26 04:06:09.062142
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Input
    str_0 = '*suseB~pu^x'
    bool_0 = None
    router_0 = Router(str_0, bool_0)

    fields_0 = dict()
    fields_0['str_0'] = str_0
    fields_0['bool_0'] = bool_0
    fields_0['router_0'] = router_0

    for key in fields_0:
        router_0.ctx.app.__dict__[key] = fields_0[key]

    try:
        router_0.finalize()
        raise Exception('Test failed')
    except SanicException:
        pass

# Generated at 2022-06-26 04:06:14.736300
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Asserts that finalize raises an error when a parameter starts with __.
    str_0 = '*suseB~pu^x'
    bool_0 = None
    router_0 = Router(str_0, bool_0)
    router_0.add('/clients/<resource_id>/', ['GET'], lambda request: None, strict_slashes=False, static=False, host=None, version=None, name=None, unquote=False)
    try:
        router_0.finalize()
    except SanicException:
        pass
    else:
        raise AssertionError("finalize did not raise expected error")

# Generated at 2022-06-26 04:06:17.068528
# Unit test for constructor of class Router
def test_Router():
    path = '*suseB~pu^x'
    strict_slashes = None
    router = Router(path, strict_slashes)
    assert router

# Generated at 2022-06-26 04:06:17.974747
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

if __name__ == '__main__':
    test_Router()

# Generated at 2022-06-26 04:06:19.589909
# Unit test for constructor of class Router
def test_Router():
    test_case_0()
    print('\nAttention: ' + 'All cases passed.')
    print('\n')

# Generated at 2022-06-26 04:06:29.399035
# Unit test for constructor of class Router
def test_Router():

    type_1 = None
    router_1 = Router(type_1)
    
    assert router_1.routes == {}
    assert router_1.dynamic_routes == {}
    assert router_1.static_routes == {}


# Generated at 2022-06-26 04:06:31.235198
# Unit test for method finalize of class Router
def test_Router_finalize():
    with raises(SanicException):
        type_0 = None
        router_0 = Router(type_0)
        test_case_0()

# Generated at 2022-06-26 04:06:35.724965
# Unit test for constructor of class Router
def test_Router():
    # constructor
    try:
        type_0 = None
        router_0 = Router(type_0)
    except:
        assert False



# Generated at 2022-06-26 04:06:37.950841
# Unit test for method finalize of class Router
def test_Router_finalize():
    try:
        type_0 = None
        router_0 = Router(type_0)
        router_0.finalize()
    except SanicException:
        pass


# Generated at 2022-06-26 04:06:39.739592
# Unit test for constructor of class Router
def test_Router():
    type_0 = None
    router_0 = Router(type_0)



# Generated at 2022-06-26 04:06:42.253778
# Unit test for constructor of class Router
def test_Router():
    try:
        test_case_0()
    except TypeError as e:
        print(e)

test_Router()

# Generated at 2022-06-26 04:06:50.979820
# Unit test for constructor of class Router
def test_Router():
    type_0 = None
    router_0 = Router(type_0)
    path_0 = "/index/index"
    method_0 = "GET"
    host_0 = None
    route, handler, args = router_0._get(path_0, method_0, host_0)
    assert route is None
    assert handler is None
    assert args is None
    uri_0 = "/index/index"
    methods_0 = "GET"
    handler_0 = None
    host_0 = None
    strict_slashes_0 = False
    stream_0 = False
    ignore_body_0 = False
    version_0 = None
    name_0 = None
    unquote_0 = False
    static_0 = False

# Generated at 2022-06-26 04:06:54.688292
# Unit test for method finalize of class Router
def test_Router_finalize():
    type_0 = None
    router_0 = Router(type_0)

    # TODO: A lambda is required to improve the test coverage.
    try:
        router_0.finalize()
    except:
        pass



# Generated at 2022-06-26 04:06:56.802123
# Unit test for constructor of class Router
def test_Router():
    type_0 = None
    router_0 = Router(type_0)


# Generated at 2022-06-26 04:07:01.121355
# Unit test for method finalize of class Router
def test_Router_finalize():
    # -> None :
    # The file path of the test agent
    type_0 = None
    # Sanic application router.
    router_0 = Router(type_0)
    # None
    assert router_0.finalize() is None


# Generated at 2022-06-26 04:07:05.437995
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.finalize()

# Generated at 2022-06-26 04:07:07.308485
# Unit test for constructor of class Router
def test_Router():
    # test_case_0()
    test = Router()



# Generated at 2022-06-26 04:07:11.203130
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add(
        uri='/test', methods=['GET', 'POST'], handler=None, host=None, strict_slashes=False,
        stream=False, ignore_body=False, version=None, name=None, unquote=False, static=False)
    try:
        router.finalize()
    except SanicException as error:
        print(error)


# Generated at 2022-06-26 04:07:12.852600
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()


# Generated at 2022-06-26 04:07:19.307808
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    Test case for method finalize of class Router
    """
    router_0 = Router()
    try:
        router_0.finalize()
    except NotImplementedError:
        pass
    except Exception:
        assert False


# Generated at 2022-06-26 04:07:20.781646
# Unit test for method finalize of class Router
def test_Router_finalize():
    assert True


# Generated at 2022-06-26 04:07:26.324091
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_1 = Router()
    router_1.dynamic_routes={}
    router_1.path_index={}
    router_1.regex_routes={}
    router_1.reversed_index={}
    router_1.static_routes={}
    #test case 1
    try:
        router_1.finalize()
    except Exception as e:
        print ("Error: " + str(e))



# Generated at 2022-06-26 04:07:29.202763
# Unit test for constructor of class Router
def test_Router():
    router_const = Router()
    assert(router_const != None)


# Generated at 2022-06-26 04:07:34.652810
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    # check that the routes are initialized correctly
    assert router.routes_regex == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.name_index == {}
    assert router.default_host == None
    assert router.ctx == {}


# Generated at 2022-06-26 04:07:36.690557
# Unit test for method finalize of class Router
def test_Router_finalize():
    print("Inside test_Router_finalize")


# Generated at 2022-06-26 04:07:41.807230
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    var_0 = router_0.finalize()
    router_0.ctx = None

# Generated at 2022-06-26 04:07:45.711919
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    assert router_0.DEFAULT_METHOD == 'GET'
    assert router_0.ALLOWED_METHODS == ['GET', 'PUT', 'POST', 'DELETE', 'PATCH', 'OPTIONS']



# Generated at 2022-06-26 04:07:47.159309
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()

# Generated at 2022-06-26 04:07:49.867172
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:07:58.938910
# Unit test for constructor of class Router
def test_Router():
    from sanic.constants import HTTP_METHODS
    from sanic.exceptions import MethodNotSupported, NotFound, SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.exceptions import MethodNotSupported as MethodNotSupported0
    from sanic.exceptions import NotFound as NotFound0
    from sanic_routing import BaseRouter
    from sanic_routing.exceptions import NoMethod
    from sanic_routing.exceptions import NotFound as NotFound1
    from sanic_routing.route import Route

    assert isinstance(Router, type)
    assert hasattr(Router, 'DEFAULT_METHOD')
    assert isinstance(Router.DEFAULT_METHOD, str)
    assert hasattr(Router, 'ALLOWED_METHODS')

# Generated at 2022-06-26 04:08:08.095244
# Unit test for constructor of class Router
def test_Router():

    router_0 = Router()

    var_0 = router_0.finalize()

    # router_0.add('/greet', 'POST', test_case_0, host=None, strict_slashes=False, stream=False, ignore_body=False, version=None, name=None, unquote=False, static=False)

    # Add a handler to the router

    router_0.get('/greet', 'POST', host=None)

    # Retrieve a `Route` object containg the details about how to handle
    # a response for a given request


# Generated at 2022-06-26 04:08:14.723203
# Unit test for constructor of class Router
def test_Router():
    assert issubclass(Router, BaseRouter)
    assert issubclass(Router, _RouterContext)
    assert Router.__module__ == "sanic.routing"

    # Testing constructor
    router = Router()
    assert isinstance(router, Router)


# Unit tests:
# Finalize

# Generated at 2022-06-26 04:08:21.089333
# Unit test for constructor of class Router
def test_Router():
    router_1 = Router()
    class_name_1 = router_1.__class__.__name__
    assert class_name_1 == "Router"

    # Test for add
    router_1.add("/users", ["POST"], lambda request: "")
    router_1.add("/user/<user_id>", ["PUT"], lambda request: "")
    router_1.add("/user/<user_id>", ["DELETE"], lambda request: "")
    router_1.add("/user/<user_id>", ["GET"], lambda request: "")
    router_1.add("/user/<user_id>/profile", ["GET"], lambda request: "")
    router_1.add("/user/<user_id>/profile", ["PUT"], lambda request: "")
    router_

# Generated at 2022-06-26 04:08:24.036418
# Unit test for method finalize of class Router
def test_Router_finalize():

    router_0 = Router()
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:08:29.603540
# Unit test for method finalize of class Router
def test_Router_finalize():
    sanic_0 = Sanic("sanic_0")
    router_0 = Router()
    # This does not raise an exception
    try:
        var_0 = router_0.finalize()
    except Exception as e:
        raise AssertionError("Router_finalize raised an exception: {}".format(e))

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 04:08:38.402442
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_case_0()

# Generated at 2022-06-26 04:08:40.921116
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    var_0 = router_0.finalize()

# Generated at 2022-06-26 04:08:49.098254
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    assert len(router_0.routes_all) == 0
    assert len(router_0.routes_static) == 0
    assert len(router_0.routes_dynamic) == 0
    assert len(router_0.routes_regex) == 0
    assert router_0.ctx is None



# Generated at 2022-06-26 04:09:01.154477
# Unit test for method add of class Router
def test_Router_add():
    # Initialize
    router_0 = Router()
    uri_0 = "route"
    methods_0 = ["GET", "POST", "OPTIONS"]
    handler_0 = lambda *args, **kwargs: None
    host_0 = "y.ext"
    strict_slashes_0 = False
    stream_0 = False
    ignore_body_0 = True
    version_0 = "v0"
    name_0 = "name_0"
    unquote_0 = True
    static_0 = False

    # Execute
    out_0 = router_0.add(uri_0, methods_0, handler_0, host_0, strict_slashes_0, stream_0, ignore_body_0, version_0, name_0, unquote_0, static_0)

    # Evaluate

# Generated at 2022-06-26 04:09:09.754683
# Unit test for constructor of class Router
def test_Router():
    # Calling function test_case_0
    test_case_0()

    router_0 = Router()
    assert router_0.routes_dynamic == {}
    assert router_0.routes_regex == {}
    assert router_0.routes_static == {}
    assert router_0.allowed_methods == ['GET', 'HEAD', 'POST', 'DELETE', 'PUT', 'OPTIONS', 'PATCH']
    assert router_0.default_method == 'GET'


# Generated at 2022-06-26 04:09:13.638925
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    var_0 = router_0.finalize()
    # assert var_0 == ...


# Generated at 2022-06-26 04:09:14.995123
# Unit test for constructor of class Router
def test_Router():
    assert test_case_0() is None


# Generated at 2022-06-26 04:09:16.713155
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    # Error: TypeError: finalize() takes 0 positional arguments but 1 was given
    var_0 = router_0.finalize()

# Generated at 2022-06-26 04:09:19.313938
# Unit test for constructor of class Router
def test_Router():
    with pytest.raises(Exception):
        router_0 = Router()
        var_0 = router_0.finalize()


# Generated at 2022-06-26 04:09:21.928018
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    router_0.finalize()


# Generated at 2022-06-26 04:09:37.769636
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    router.add(uri="", methods=["GET"], handler=None, unquote=False, static=False)
    router.add(uri="/", methods=["GET"], handler=None, unquote=False, static=False)
    router.add(uri="//", methods=["GET"], handler=None, unquote=False, static=False)
    router.add(uri="/<name>", methods=["GET"], handler=None, unquote=False, static=False)
    router.add(uri="/static/<filename:path>", methods=["GET"], handler=None, unquote=False, static=False)
    router.add(uri="/user/<name>", methods=["GET"], handler=None, unquote=False, static=False)

# Generated at 2022-06-26 04:09:40.426388
# Unit test for constructor of class Router
def test_Router():
    # Test 0
    router_0 = Router()
    # Test 1
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:09:42.177346
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    var_0 = router_0.finalize()
    assert var_0 == None


# Generated at 2022-06-26 04:09:54.913086
# Unit test for constructor of class Router
def test_Router():
    router_1 = Router()
    # Testing method router_1.get()
    # Testing exception NotFound
    try:
        router_1.get(
            path="test_case_3_1",
            method="test_case_3_2",
            host=None,
        )
    except NotFound as ex_1:
        print(ex_1)

    # Testing exception MethodNotSupported
    try:
        router_1.get(
            path="test_case_4_1",
            method="test_case_4_2",
            host=None,
        )
    except MethodNotSupported as ex_2:
        print(ex_2)

    # Testing method router_1.get()
    # Testing exception NotFound

# Generated at 2022-06-26 04:09:56.277633
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None

# Generated at 2022-06-26 04:09:57.484018
# Unit test for constructor of class Router
def test_Router():
    pass


# Generated at 2022-06-26 04:10:00.407680
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_1 = Router()
    var_1 = router_1.finalize()

    assert router_1.finalize() is None and router_1.del_route(router_1) is None


# Generated at 2022-06-26 04:10:13.382134
# Unit test for constructor of class Router
def test_Router():
    import os
    import sys
    import inspect
    import json
    import hashlib
    import tempfile
    import logging
    import importlib
    import shutil
    import subprocess
    import traceback
    import asyncio

    if sys.version_info < (3, 7):
        try:
            from functools import lru_cache
        except ImportError:
            from backports.functools_lru_cache import lru_cache

        sys.modules["functools"].lru_cache = lru_cache

    from sanic import Sanic
    from sanic.exceptions import NotFound
    from sanic.response import json as json_response
    from sanic_routing.route import Route
    from sanic.routing import Router
    from sanic_routing import Route, RouteExpect

    TEST

# Generated at 2022-06-26 04:10:16.232959
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    var_0 = router_0.finalize()
    return None


# Generated at 2022-06-26 04:10:19.106177
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == []


# Generated at 2022-06-26 04:10:36.912230
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:10:39.026252
# Unit test for method finalize of class Router
def test_Router_finalize():
    var_0 = Router()
    var_0.finalize()


# Generated at 2022-06-26 04:10:40.182137
# Unit test for constructor of class Router
def test_Router():
    test_case_0()


# Generated at 2022-06-26 04:10:43.424772
# Unit test for method finalize of class Router
def test_Router_finalize():
    # finalize(self)
    #
    #

    router_0 = Router()
    var_0 = router_0.finalize()



# Generated at 2022-06-26 04:10:44.808056
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert True


# Generated at 2022-06-26 04:10:48.981626
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    res_0 = router_0.finalize(example = 'abc' )
    res_1 = router_0.finalize()

# Generated at 2022-06-26 04:10:51.196417
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    assert router_0 != None


# Generated at 2022-06-26 04:10:55.294974
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)
    assert isinstance(router.ALLOWED_METHODS, list)
    assert set(router.ALLOWED_METHODS) == set(HTTP_METHODS)
    assert router.DEFAULT_METHOD == "GET"


# Generated at 2022-06-26 04:10:58.823324
# Unit test for method finalize of class Router
def test_Router_finalize():
    """
    Method finalize of class Router
    """
    # No code to test
    pass


# Generated at 2022-06-26 04:11:05.512036
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    router.finalize()

    var_0 = router.routes_all
    var_1 = router.routes_dynamic
    var_2 = router.routes_regex
    var_3 = router.routes_static
    var_4 = router.DEFAULT_METHOD
    var_5 = router.ALLOWED_METHODS


# Generated at 2022-06-26 04:11:55.232978
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()

    assert router_0
    assert isinstance(router_0, Router)


# Generated at 2022-06-26 04:12:06.957124
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()

# Generated at 2022-06-26 04:12:17.994554
# Unit test for constructor of class Router
def test_Router():
    from sanic.router import Router
    from sanic.constants import HTTP_METHODS
    from sanic.models.handler_types import RouteHandler
    from sanic.exceptions import SanicException

    router = Router()

    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.DEFAULT_METHOD == "GET"

    # with pytest.raises(SanicException):
    #     uri = '/path/to/path'
    #     methods = ["GET", "POST", "OPTIONS"]
    #     handler = RouteHandler
    #     host = None
    #     strict_slashes = False
    #     stream = True
    #     ignore_body = False
    #     version = None
    #     name = "testName"
    #     unquote = False
    #     static

# Generated at 2022-06-26 04:12:23.712184
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    assert isinstance(router_0, Router)


# Generated at 2022-06-26 04:12:27.409955
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:12:29.490945
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    var_1 = router_0.finalize()
    assert var_1 is True

# Generated at 2022-06-26 04:12:32.289819
# Unit test for constructor of class Router
def test_Router():
    router_1 = Router()
    assert router_1 == router_1


# Generated at 2022-06-26 04:12:35.450293
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Test case #0
    router_0 = Router()
    var_0 = router_0.finalize()

# Generated at 2022-06-26 04:12:44.294037
# Unit test for constructor of class Router
def test_Router():
    
    # Test with default constructor
    router_0 = Router()
    assert router_0.__class__.__name__ == 'Router'
    assert router_0.routes_all == {}
    assert router_0.routes_static == {}
    assert router_0.routes_dynamic == {}
    assert router_0.routes_regex == {}
    assert router_0.name_index == {}
    assert router_0.ALLOWED_METHODS == HTTP_METHODS
    assert router_0.DEFAULT_METHOD == 'GET'
    assert router_0.ctx.app is None

# Generated at 2022-06-26 04:12:45.528068
# Unit test for method finalize of class Router
def test_Router_finalize():
    test_case_0()

# Generated at 2022-06-26 04:13:58.978360
# Unit test for constructor of class Router
def test_Router():
    try:
        if (test_case_0()):
            return True
    except Exception:
        return False


# Generated at 2022-06-26 04:14:02.266045
# Unit test for constructor of class Router
def test_Router():
    assert Router.__name__ == 'Router'



# Generated at 2022-06-26 04:14:05.828504
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    var_0 = router_0.finalize()
    var_1 = router_0.finalize()


# Generated at 2022-06-26 04:14:13.656504
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Create an instance of the Router
    router = Router()

    # Invoke the target function
    try:
        router.finalize()
    except Exception as e:
        # Removes the context from the stack
        router.ctx.pop()
        # Removes the context from the stack
        router.ctx.pop()
        # Removes the context from the stack
        router.ctx.pop()
        # Removes the context from the stack
        router.ctx.pop()
        # Collects all the variables having the same name
        gc.collect()

        # Re-raise the caught exception
        raise e

    # Removes the context from the stack
    router.ctx.pop()
    # Removes the context from the stack
    router.ctx.pop()
    # Removes the context from the stack
    router.ctx.pop()


# Generated at 2022-06-26 04:14:16.219550
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    var_0 = router_0.finalize()


# Generated at 2022-06-26 04:14:21.545223
# Unit test for constructor of class Router
def test_Router():
    # Arrange
    router = Router()

    # Act
    router.finalize()

    # Assert
    assert router.dynamic_routes == {}
    assert router.static_routes == {}
    assert router.name_index == {}
    assert router.regex_routes == []
    assert router.routes == {}


# Generated at 2022-06-26 04:14:26.397689
# Unit test for constructor of class Router
def test_Router():
    with pytest.raises(TypeError) as e_info:
        Router(2)
    assert str(e_info.value) == "__init__() takes 1 positional argument but 2 were given"

# Generated at 2022-06-26 04:14:30.483523
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    var_0 = router_0.finalize()
    assert isinstance(var_0, Router) and var_0 is router_0, var_0


# Generated at 2022-06-26 04:14:31.579470
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    assert router_0.finalize() == None

# Generated at 2022-06-26 04:14:32.645217
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    var_0 = router_0.finalize()
