

# Generated at 2022-06-26 04:05:54.049985
# Unit test for constructor of class Router
def test_Router():
    list_0 = []
    router_0 = Router(list_0)
    assert not router_0.routes_all
    assert not router_0.routes_static
    assert not router_0.routes_dynamic
    assert not router_0.routes_regex


# Generated at 2022-06-26 04:06:01.562188
# Unit test for constructor of class Router
def test_Router():
    list_0 = []
    router_0 = Router(list_0)
    assert not router_0.dynamic_routes
    assert not router_0.static_routes
    assert not router_0.regex_routes
    assert not router_0.name_index
    assert not router_0.lookup

    list_1 = [Route(handler=None, uri=None, method=None, name=None, strict_slashes=None, unquote=None)]
    router_1 = Router(list_1)
    assert router_1.dynamic_routes
    assert router_1.static_routes
    assert router_1.regex_routes
    assert router_1.name_index
    assert router_1.lookup


# Generated at 2022-06-26 04:06:04.925833
# Unit test for constructor of class Router
def test_Router():
    list_0 = []
    router_0 = Router(list_0)

if __name__ == "__main__":
    test_case_0()
    test_Router()

# Generated at 2022-06-26 04:06:12.529711
# Unit test for constructor of class Router
def test_Router():
    list_0 = [
        {
            "handler": "<handler>",
            "methods": ["GET"],
            "path": "^/wildcard/(?P<name>[^/]+)$"
        }
    ]
    router_0 = Router(list_0)

    assert router_0.routes_dynamic == {
        '^/wildcard/(?P<name>[^/]+)$': {
            'GET': [{'handler': '<handler>', 'path': '^/wildcard/(?P<name>[^/]+)$'}]
        }
    }

# Generated at 2022-06-26 04:06:15.941654
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

# vim:ts=4:sw=4:et:syn=python:

# Generated at 2022-06-26 04:06:26.703200
# Unit test for constructor of class Router
def test_Router():
    list_0 = []
    router_0 = Router(list_0)
    assert router_0.ctx == list_0
    assert router_0.routes == {}
    assert router_0.static_routes == {}
    assert router_0.dynamic_routes == {}
    assert router_0.regex_routes == {}
    assert router_0.name_index == {}
    assert router_0.path_index == {}
    assert router_0.path_index_reverse == {}
    assert router_0.host_index == {}
    assert router_0.method_index == {}
    assert router_0.allowed_methods == ('DELETE', 'GET', 'HEAD', 'OPTIONS', 'PATCH', 'POST', 'PUT', 'TRACE', 'CONNECT')
    assert router_

# Generated at 2022-06-26 04:06:29.259739
# Unit test for method finalize of class Router
def test_Router_finalize():
    list_0 = []
    router_0 = Router(list_0)
    extra_0 = router_0.finalize()



# Generated at 2022-06-26 04:06:40.212699
# Unit test for constructor of class Router
def test_Router():
    list_1 = []
    router_1 = Router(list_1)
    uri_1 = 'test_uri'
    methods_1 = [1,2]
    handler_1 = 1
    host_1 = 'test_host'
    strict_slashes_1 = False
    stream_1 = False
    ignore_body_1 = False
    version_1 = 'test_version'
    name_1 = 'test_name'
    unquote_1 = False
    static_1 = False
    route = router_1.add(uri_1,methods_1,handler_1,host_1,strict_slashes_1,stream_1,ignore_body_1,version_1,name_1,unquote_1,static_1)
    assert route.ctx.hosts == [host_1]

# Generated at 2022-06-26 04:06:43.216455
# Unit test for constructor of class Router
def test_Router():
    try:
        list_0 = []
        router_0 = Router(list_0)
    except:
        print("test case 0 failed")


# Generated at 2022-06-26 04:06:47.510166
# Unit test for constructor of class Router
def test_Router():
    list_0 = []
    router_0 = Router(list_0)
    assert router_0.routes_all == list_0


# ------------------------ Case 1 --------------------------


# Generated at 2022-06-26 04:06:55.175289
# Unit test for constructor of class Router
def test_Router():
    list_0 = []
    router_0 = Router(list_0)


# Generated at 2022-06-26 04:06:58.301862
# Unit test for method finalize of class Router
def test_Router_finalize():
    list_0 = []
    router_0 = Router(list_0)
    router_0.finalize()


# Generated at 2022-06-26 04:07:00.608710
# Unit test for constructor of class Router
def test_Router():

    list_0 = []
    router_0 = Router(list_0)


# Generated at 2022-06-26 04:07:07.135604
# Unit test for constructor of class Router
def test_Router():
    import random
    list_0 = []
    for i in range(100):
        path = ""
        for j in range(10):
            path += str(random.randint(0,9))
        route = Route(path, "GET")
        route.ctx.hosts = [None]
        list_0.append(route)

    router_0 = Router(list_0)
    route, handler, param = router_0.get("1111", "GET", None)

    assert router_0.DEFAULT_METHOD == "GET"
    assert all(router_0.ALLOWED_METHODS)
    assert isinstance(router_0, BaseRouter)


# Generated at 2022-06-26 04:07:14.765663
# Unit test for constructor of class Router
def test_Router():
    list_0 = []
    # The Router object
    router_0 = Router(list_0)
    # The list object
    assert router_0.ctx == list_0
    # The dict object
    assert router_0.name_index == dict()
    # The dict object
    assert router_0.routes_all == dict()
    # The dict object
    assert router_0.dynamic_routes == dict()
    # The dict object
    assert router_0.regex_routes == dict()
    # The dict object
    assert router_0.static_routes == dict()
    
    

# Generated at 2022-06-26 04:07:16.721620
# Unit test for constructor of class Router
def test_Router():
    list_0 = []
    Router(list_0)

# Generated at 2022-06-26 04:07:26.996642
# Unit test for constructor of class Router
def test_Router():
    list_0 = [1, 2, 3]
    router_0 = Router(list_0)
    router_0.uri = "test"
    routes_0 = router_0.routes_all
    assert(routes_0 == list_0)
    assert(router_0.uri == "test")
    assert(router_0.routes_static == {})
    assert(router_0.routes_dynamic == {})
    assert(router_0.routes_regex == {})
    assert(router_0._route_cache == {})
    router_1 = Router(routes_0, "test")
    assert(router_1.routes_all == list_0)
    assert(router_1.uri == "test")

# Generated at 2022-06-26 04:07:28.073317
# Unit test for constructor of class Router
def test_Router():
    list_0 = []
    router_0 = Router(list_0)
    assert isinstance(router_0, Router)


# Generated at 2022-06-26 04:07:37.342441
# Unit test for constructor of class Router
def test_Router():
    assert issubclass(Router, BaseRouter)
    
    # If routes is not a list
    try:
        router = Router(1)
    except AssertionError:
        err_msg = "Routes must be a list of Route objects"
        assert str(sys.exc_info()[1]) == err_msg
    
    routes_list = []
    router = Router(routes_list)
    assert router.ctx.app == None
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.aliases == {}

# Generated at 2022-06-26 04:07:41.988551
# Unit test for method finalize of class Router
def test_Router_finalize():
    list_0 = []
    router_0 = Router(list_0)
    router_0.finalize()
    int_0 = 1
    router_0.finalize(int_0)



# Generated at 2022-06-26 04:07:58.090437
# Unit test for method finalize of class Router
def test_Router_finalize():
    list_0 = []
    router_0 = Router(list_0)

    # Try to finalize with no routes, should raise an exception
    # since the router is not properly prepared
    try:
        router_0.finalize(None)
        assert False
    except:
        assert True

    # Create a route and add it to the router
    route_0 = Route('r0', '/r0', 'GET', lambda : None)
    router_0.dynamic_routes['r0'] = route_0

    try:
        router_0.finalize(None)
        assert True
    except:
        assert False
    assert router_0.static_routes == {}
    assert router_0.regex_routes == {}

    # Create a route and add it to the router
    route_1 = Route

# Generated at 2022-06-26 04:08:05.445502
# Unit test for constructor of class Router
def test_Router():
    list_0 = []
    router_0 = Router(list_0)
    # Test if the variable list_0 is changed after the invoking of the method "constructor of class Router"
    if list_0 != []:
        raise Exception("Test #0 failed")
    else:
        print("Test for constructor of class Router is completed")


# Generated at 2022-06-26 04:08:14.363127
# Unit test for constructor of class Router
def test_Router():
    # Initialize path_params to []
    path_params = []
    # Initialize list_0 to []
    list_0 = []
    # Initialize router_0 to router made with list_0 as parameter
    router_0 = Router(list_0)
    # Initialize router_1 to router made with list_0 and path_params as parameters
    router_1 = Router(list_0, path_params)


# Generated at 2022-06-26 04:08:16.030758
# Unit test for constructor of class Router
def test_Router():
    list_0 = []
    router_0 = Router(list_0)

# Generated at 2022-06-26 04:08:18.642089
# Unit test for method finalize of class Router
def test_Router_finalize():
    list_0 = []
    router_0 = Router(list_0)
    # Tests if an exception has been raised or not
    try:
        router_0.finalize()
        return True
    except Exception as e:
        return False


# Generated at 2022-06-26 04:08:22.973231
# Unit test for constructor of class Router
def test_Router():
    print("Router.py")
    test_case_0()
    print("Test complete")

if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-26 04:08:26.338935
# Unit test for method finalize of class Router
def test_Router_finalize():
    list_0 = []
    router_0 = Router(list_0)
    router_0.finalize()


# Generated at 2022-06-26 04:08:28.760748
# Unit test for constructor of class Router
def test_Router():
    list_0 = []
    router_0 = Router(list_0)


# Generated at 2022-06-26 04:08:31.452678
# Unit test for method finalize of class Router
def test_Router_finalize():
    list_0 = []
    router_0 = Router(list_0)


# Generated at 2022-06-26 04:08:33.183564
# Unit test for constructor of class Router
def test_Router():
    test_case_0()


# Generated at 2022-06-26 04:08:42.986256
# Unit test for constructor of class Router
def test_Router():
    list_0 = []
    router_0 = Router(list_0)

    list_1 = []
    router_1 = Router(list_1)

    assert router_0 is not router_1

# Generated at 2022-06-26 04:08:54.347788
# Unit test for constructor of class Router
def test_Router():
    list_0 = []
    router_0 = Router(list_0)
    list_1 = []
    router_1 = Router(list_1)
    list_2 = []
    router_2 = Router(list_2)
    list_3 = []
    router_3 = Router(list_3)
    list_4 = []
    router_4 = Router(list_4)
    list_5 = []
    router_5 = Router(list_5)
    list_6 = []
    router_6 = Router(list_6)
    list_7 = []
    router_7 = Router(list_7)
    list_8 = []
    router_8 = Router(list_8)
    list_9 = []
    router_9 = Router(list_9)
    list_10 = []
    router

# Generated at 2022-06-26 04:08:57.131872
# Unit test for method finalize of class Router
def test_Router_finalize():
    list_0 = []
    router_0 = Router(list_0)
    args = ()
    kwargs = {}
    router_0.finalize(*args, **kwargs)


# Generated at 2022-06-26 04:08:59.063273
# Unit test for constructor of class Router
def test_Router():
    test_case_0()


if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-26 04:09:04.248204
# Unit test for method finalize of class Router
def test_Router_finalize():
    list_0 = []
    router_0 = Router(list_0)
    try:
        router_0.finalize()
    except Exception as exception_0:
        print(str(exception_0))


# Generated at 2022-06-26 04:09:05.686184
# Unit test for constructor of class Router
def test_Router():
    test_case_0()

# Generated at 2022-06-26 04:09:09.343244
# Unit test for method finalize of class Router
def test_Router_finalize():
    list_0 = []
    router_0 = Router(list_0)
    try:
        router_0.finalize()
    except:
        print("Exception: ", sys.exc_info())


# Generated at 2022-06-26 04:09:16.804822
# Unit test for constructor of class Router
def test_Router():
    list_0 = []
    assert_equal([[], None, {}], [list_0, None, {}])
    router_0 = Router(list_0)
    assert_equal([[], None, {}], [list_0, None, {}])
    assert_equal(router_0, list_0)


# Generated at 2022-06-26 04:09:19.948044
# Unit test for constructor of class Router
def test_Router():
    print("start")
    # Test cases for constructor of class Router

    test_case_0()
    print("end")


if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-26 04:09:22.746687
# Unit test for constructor of class Router
def test_Router():
    list_0 = []
    router_0 = Router(list_0)



# Generated at 2022-06-26 04:09:33.936157
# Unit test for constructor of class Router
def test_Router():
    try:
        test_case_0()
    except Exception:
        print("Test failed")

test_Router()

# Generated at 2022-06-26 04:09:39.749582
# Unit test for method finalize of class Router
def test_Router_finalize():
    sanic_0 = Sanic("sanic_app_for_test")
    list_0 = []
    router_0 = Router(list_0)

    # Test for simple finalize
    assert router_0.finalize(sanic_0) == None


# Generated at 2022-06-26 04:09:41.383336
# Unit test for constructor of class Router
def test_Router():
    list_0 = []
    router_0 = Router(list_0)


# Generated at 2022-06-26 04:09:47.697300
# Unit test for constructor of class Router
def test_Router():
    list_0 = []
    router_0 = Router(list_0)
    assert router_0.dynamic_routes == None
    assert router_0.name_index == None


test_case_0()
test_Router()
print('Passed.')

# Generated at 2022-06-26 04:09:51.269854
# Unit test for method finalize of class Router
def test_Router_finalize():
    list_0 = []
    router_0 = Router(list_0)
    router_0.finalize()


# Generated at 2022-06-26 04:09:54.283111
# Unit test for method finalize of class Router
def test_Router_finalize():
    list_0 = []
    router_0 = Router(list_0)
    wrapper_0 = sanic.router.RouteWrapper(router_0)
    router_0.finalize(wrapper_0._ROUTE_MATCHES)


# Generated at 2022-06-26 04:10:00.810618
# Unit test for method finalize of class Router
def test_Router_finalize():
    list_0 = []
    router_0 = Router(list_0)
    assert not router_0.finalized, "Router.finalized returned True with expected False"
    assert router_0.is_finalized == False, "Router.is_finalized returned True with expected False"
    assert router_0.is_not_finalized == True, "Router.is_not_finalized returned True with expected False"


# Generated at 2022-06-26 04:10:04.020687
# Unit test for constructor of class Router
def test_Router():
    list_0 = []
    router_0 = Router(list_0)


# Generated at 2022-06-26 04:10:07.154171
# Unit test for method finalize of class Router
def test_Router_finalize():
    list_0 = []
    router_0 = Router(list_0)
    router_0.finalize()

# Generated at 2022-06-26 04:10:15.151975
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Case 1
    list_0 = []
    router_0 = Router(list_0)

    # Case 2
    list_0 = []
    router_0 = Router(list_0)

    # Case 3
    list_0 = []
    router_0 = Router(list_0)

    # Case 4
    list_0 = []
    router_0 = Router(list_0)

    # Case 5
    list_0 = []
    router_0 = Router(list_0)

    # Case 6
    list_0 = []
    router_0 = Router(list_0)

    # Case 7
    list_0 = []
    router_0 = Router(list_0)

    # Case 8
    list_0 = []
    router_0 = Router(list_0)

    # Case 9
    list

# Generated at 2022-06-26 04:10:32.262148
# Unit test for constructor of class Router
def test_Router():
    print("Test Router")

    try:
        test_case_0()
    except Exception as e:
        print("Fail, " + str(e))
    else:
        print("Pass")

# main entry of test
if __name__ == "__main__":
    test_Router()

# Generated at 2022-06-26 04:10:35.811109
# Unit test for constructor of class Router
def test_Router():
    list_0 = []
    router_0 = Router(list_0)
    assert isinstance(router_0, BaseRouter)


# Generated at 2022-06-26 04:10:39.719042
# Unit test for method finalize of class Router
def test_Router_finalize():
    list_ = []
    router = Router(list_)
    try:
        router.finalize()
    except Exception as e:
        raise e
    else:
        pass

# Generated at 2022-06-26 04:10:47.894638
# Unit test for method finalize of class Router
def test_Router_finalize():
    list_0 = []
    router_0 = Router(list_0)

# Generated at 2022-06-26 04:10:57.549798
# Unit test for constructor of class Router
def test_Router():
    # Case 0
    list_0 = [{'host': 'sanic.com'}, {'host': 'sanic.com'}, {'host': 'sanic.com'}]
    router_0 = Router(list_0)
    
    # Case 1
    list_0 = [{'host': 'sanic.com'}, {'host': 'sanic.com'}, {'host': 'sanic.com'}]
    router_0 = Router(list_0)
    
    # Case 2
    list_0 = [{'host': 'sanic.com'}, {'host': 'sanic.com'}, {'host': 'sanic.com'}]
    router_0 = Router(list_0)
    
    # Case 3

# Generated at 2022-06-26 04:11:03.531192
# Unit test for method finalize of class Router
def test_Router_finalize():
    list_0 = []
    router_0 = Router(list_0)

    try:
        router_0.finalize()
        assert False
    except SanicException as exc_0:
        assert "Invalid route" in exc_0.args[0]

# Generated at 2022-06-26 04:11:06.963094
# Unit test for method finalize of class Router
def test_Router_finalize():
    list_0 = []
    router_0 = Router(list_0)
    exception_0 = None
    try:
        router_0.finalize(list_0)
    except Exception as exception_1:
        exception_0 = exception_1
    assert exception_0
    assert isinstance(exception_0, TypeError)
    
    

# Generated at 2022-06-26 04:11:09.205546
# Unit test for constructor of class Router
def test_Router():
    list_0 = []
    router_0 = Router(list_0)

# Generated at 2022-06-26 04:11:17.792269
# Unit test for method finalize of class Router
def test_Router_finalize():
    list_0 = []
    router_0 = Router(list_0)

    router_0.ctx.app = None
    try:
        router_0.finalize()
    except Exception:
        assert True
    else:
        assert False
    router_0.ctx.app = None

    router_0.ctx.app = router_0
    try:
        router_0.finalize()
    except Exception:
        assert False
    else:
        assert True
    router_0.ctx.app = None
# End of unit test

# Generated at 2022-06-26 04:11:24.821161
# Unit test for constructor of class Router
def test_Router():
    try:
        list_1 = []
        router_1 = Router(list_1)
    except Exception as e:
        assert False

    try:
        list_2 = [1]
        router_2 = Router(list_2)
        assert False
    except Exception as e:
        assert True

# Generated at 2022-06-26 04:11:37.561668
# Unit test for method finalize of class Router
def test_Router_finalize():
    list_0 = []
    router_0 = Router(list_0)
    router_0.finalize()

test_case_0()

# Generated at 2022-06-26 04:11:39.081861
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router


# Generated at 2022-06-26 04:11:42.076288
# Unit test for constructor of class Router
def test_Router():
    list_0 = []
    router_0 = Router(list_0)


# Generated at 2022-06-26 04:11:50.163439
# Unit test for constructor of class Router
def test_Router():
    list_1 = []
    router_1 = Router(list_1)
    if (router_1.routes == list_1):
        print("Passed test 0")
    else:
        print("Failed test 0")

    list_2 = []
    router_2 = Router(list_2)
    if (router_2.routes == list_2):
        print("Passed test 1")
    else:
        print("Failed test 1")



# Generated at 2022-06-26 04:11:53.063041
# Unit test for constructor of class Router
def test_Router():
    list_0 = []
    router_0 = Router(list_0)
    router_0.routes_all
    router_0.routes_static
    router_0.routes_dynamic
    router_0.routes_regex



# Generated at 2022-06-26 04:12:05.540106
# Unit test for method finalize of class Router
def test_Router_finalize():
    list_0 = []
    router_0 = Router(list_0)
    list_1 = []
    route_0 = Route(list_1, handler=None)
    list_2 = []
    route_0.ctx.app = list_2
    router_0.routes_regex.append(route_0)
    try:
        router_0.finalize()
    except SanicException as e_1:
        assert repr(e_1) == repr(SanicException("Invalid route: <Route>."))
    except Exception as e_2:
        print('Expected:', SanicException("Invalid route: <Route>."), '\nActual:  ', repr(e_2))

if __name__ == '__main__':
    import sys
    import pytest

# Generated at 2022-06-26 04:12:09.827377
# Unit test for constructor of class Router
def test_Router():
    list_0 = []
    router_0 = Router(list_0)
    router_0.resolve('b', 'GET', 'a')

# Generated at 2022-06-26 04:12:12.475939
# Unit test for constructor of class Router
def test_Router():
    assert_raises(TypeError, Router)
    test_case_0()


# Generated at 2022-06-26 04:12:24.015628
# Unit test for constructor of class Router
def test_Router():
    list_0 = []
    router_0 = Router(list_0)
    assert router_0.dynamic_routes == {}
    assert router_0.name_index == {}
    assert router_0.regex_routes == []
    assert router_0.routes == []
    assert router_0.routes_all == []
    assert router_0.routes_dynamic == {}
    assert router_0.routes_regex == []
    assert router_0.routes_static == []
    assert router_0.static_routes == {}
    assert router_0.method_routes == {}


# Generated at 2022-06-26 04:12:28.331433
# Unit test for method finalize of class Router
def test_Router_finalize():
    list_0 = []
    router_0 = Router(list_0)
    router_0.finalize()


# Generated at 2022-06-26 04:12:45.980583
# Unit test for constructor of class Router
def test_Router():
    router_1 = Router()
    assert router_1.routes_all is []
    assert router_1.routes_static is []
    assert router_1.routes_dynamic is {}
    assert router_1.routes_regex is []

    router_2 = Router(allow_all_methods=False)
    assert router_2.routes_all is []
    assert router_2.routes_static is []
    assert router_2.routes_dynamic is {}
    assert router_2.routes_regex is []


# Generated at 2022-06-26 04:12:55.207055
# Unit test for constructor of class Router

# Generated at 2022-06-26 04:13:00.206561
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    router_0.add('/users/<name>/<id>', ['GET', 'POST'], lambda x, y, z: (x, y, z))

test_case_0()

# Generated at 2022-06-26 04:13:12.945552
# Unit test for method finalize of class Router
def test_Router_finalize():
    router_0 = Router()
    router_1 = Router()

    # assert that duplicate routes cannot be added
    assert router_0.add('/users', ['GET'], print).name == 'print'
    assert router_0.add('/users', ['GET'], print).name == 'print-1'
    assert router_0.add('/users', ['GET'], print).name == 'print-2'
    assert router_0.add('/users', ['GET'], print).name == 'print-3'

    # assert that finalize exception is taken care of
    router_1.add('/users', ['GET'], print)
    router_1.add('/users', ['GET'], print)
    assert router_1.routes
    router_1.finalize()
    

# Generated at 2022-06-26 04:13:14.309665
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router



# Generated at 2022-06-26 04:13:15.970427
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()


# Generated at 2022-06-26 04:13:18.833422
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    assert router_0 is not None


# Generated at 2022-06-26 04:13:26.536273
# Unit test for constructor of class Router
def test_Router():
    """
    @return:
    """
    router_0 = Router()
    # assert router_0.routes_regex == {}, f"Expected {dict()}, but your code returns {router_0.routes_regex}"
    # assert router_0.routes_static == {}, f"Expected {dict()}, but your code returns {router_0.routes_static}"
    # assert router_0.routes_dynamic == {}, f"Expected {dict()}, but your code returns {router_0.routes_dynamic}"
    # assert router_0.name_index == {}, f"Expected {dict()}, but your code returns {router_0.name_index}"



# Generated at 2022-06-26 04:13:35.267635
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance( router, BaseRouter)
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.ctx == {}
    assert router.name_index == {}
    assert router.routes == []
    assert router.routes_all == router.routes
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.routes_static == {}

# Generated at 2022-06-26 04:13:46.662447
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    assert router_0.ctx.app == None
    assert router_0.ctx.router == router_0
    assert router_0.ctx.strict_slashes == False
    assert router_0.ctx.unquote == True
    assert router_0.routes == {}
    assert router_0.static_routes == {}
    assert router_0.dynamic_routes == {}
    assert router_0.regex_routes == {}
    assert router_0.name_index == {}
    assert router_0.strict_slashes == False
    assert router_0.unquote == True
    assert router_0.parent == None
    assert router_0.index == 0

# Generated at 2022-06-26 04:14:06.908748
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.finalize()


# Generated at 2022-06-26 04:14:09.616294
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router is not None


# Generated at 2022-06-26 04:14:13.178963
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    router_1 = Router()

    assert router_0
    assert router_1



# Generated at 2022-06-26 04:14:15.156402
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    assert router_0


# Generated at 2022-06-26 04:14:23.485528
# Unit test for constructor of class Router
def test_Router():
    router_0 = Router()
    assert isinstance(router_0._routes, list)
    assert isinstance(router_0._static_routes, dict)
    assert isinstance(router_0._dynamic_routes, dict)
    assert isinstance(router_0._regex_routes, dict)
    assert isinstance(router_0._routes_ordered, bool)
    assert isinstance(router_0._named_routes, dict)
    assert isinstance(router_0._id_index, dict)
    assert isinstance(router_0._name_index, dict)
    assert isinstance(router_0._ctx, object)
    assert isinstance(router_0.get_routes_all, property)

# Generated at 2022-06-26 04:14:34.896184
# Unit test for method add of class Router
def test_Router_add():
    router_0 = Router()
    method_0 = ["GET"]
    def handler_0():
        pass
    uri_0 = "/"
    routes_0 = router_0.add(uri_0, method_0, handler_0)
    assert type(routes_0) is list and len(routes_0) == 1
    route_0 = routes_0[0]
    assert route_0.path == "/"
    assert route_0.methods == ["GET"]
    assert route_0.name is None
    assert route_0.strict is False
    assert route_0.unquote is False
    assert router_0.routes_all == {'GET': {'/': [route_0]}}

# Generated at 2022-06-26 04:14:36.148053
# Unit test for constructor of class Router
def test_Router():
    assert test_case_0() == None

# Generated at 2022-06-26 04:14:39.125192
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.methods == ["HEAD", "OPTIONS", "GET", "POST", "PUT", "PATCH", "DELETE"]
    assert router.allocated == 7
    

# Generated at 2022-06-26 04:14:40.769053
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_regex == []
    assert router.routes_dynamic == {}
    assert router.routes_static == {}
    assert router.routes_all == {}
    assert router.ctx.app is None


# Generated at 2022-06-26 04:14:42.096362
# Unit test for constructor of class Router
def test_Router():
    assert callable(Router)
    router_0 = Router()


# Generated at 2022-06-26 04:15:26.257339
# Unit test for constructor of class Router
def test_Router():
    router = Router(default_method='GET')
    assert router.DEFAULT_METHOD == 'GET'
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert hasattr(router, 'get')
    assert hasattr(router, 'add')
    assert hasattr(router, '_get')
    assert hasattr(router, 'find_route_by_view_name')
    assert hasattr(router, 'routes_all')
    assert hasattr(router, 'routes_static')
    assert hasattr(router, 'routes_dynamic')
    assert hasattr(router, 'routes_regex')
    assert hasattr(router, 'finalize')


# Generated at 2022-06-26 04:15:36.418440
# Unit test for method add of class Router
def test_Router_add():
    router_1 = Router()
    assert router_1.routes_all == {}
    assert router_1.routes_static == {}
    assert router_1.routes_dynamic == {}
    assert router_1.routes_regex == {}
    router_1.add("/test/<name>", ["GET"], lambda  r, name: (r, name))
    assert len(router_1.routes_all) == 1
    assert router_1.routes_all["get:/test/<name>"]
    assert len(router_1.routes_dynamic) == 1
    assert router_1.routes_dynamic["get:/test/<name>"]
    assert len(router_1.routes_regex) == 1
