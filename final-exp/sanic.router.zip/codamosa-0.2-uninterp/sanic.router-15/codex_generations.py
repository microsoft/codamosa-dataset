

# Generated at 2022-06-18 05:57:46.784201
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS
    from sanic.response import text
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.exceptions import NotFound
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import ServerError
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import Unauthorized
    from sanic.exceptions import Forbidden
    from sanic.exceptions import NotAllowed

# Generated at 2022-06-18 05:57:48.513903
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-18 05:58:00.308107
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.app_ctx == None
    assert router.ctx.router_ctx == None
    assert router.ctx.host == None
    assert router.ctx.hosts == None
    assert router.ctx.ignore_body == False
    assert router.ctx.stream == False
    assert router.ctx.static == False
    assert router.ctx.version == None
    assert router.ctx.name == None
    assert router.ctx.unquote == False
    assert router.ctx.strict == False
    assert router.ctx.methods == None
    assert router.ctx.handler == None

# Generated at 2022-06-18 05:58:09.573003
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == 'GET'
    assert router.ALLOWED_METHODS == ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS', 'HEAD', 'TRACE']
    assert router.routes == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 05:58:13.724546
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == []
    assert router.routes_regex == []


# Generated at 2022-06-18 05:58:19.313104
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.ctx.app == None


# Generated at 2022-06-18 05:58:29.945974
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler

    def handler(request):
        return request

    router = Router()
    router.add("/test/<__file_uri__>", ["GET"], handler)
    router.add("/test/<__file_uri__>", ["GET"], handler)
    router.add("/test/<__file_uri__>", ["GET"], handler)
    router.add("/test/<__file_uri__>", ["GET"], handler)
    router.add("/test/<__file_uri__>", ["GET"], handler)
    router.add("/test/<__file_uri__>", ["GET"], handler)

# Generated at 2022-06-18 05:58:31.380529
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-18 05:58:42.136758
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.models.route import RouteContext
    from sanic.models.route import RouteMethods
    from sanic.models.route import RouteMethods
    from sanic.models.route import RouteMethods
    from sanic.models.route import RouteMethods
    from sanic.models.route import RouteMethods
    from sanic.models.route import RouteMethods
    from sanic.models.route import RouteMethods
    from sanic.models.route import RouteMethods
    from sanic.models.route import RouteMethods
    from sanic.models.route import RouteMethods
    from sanic.models.route import RouteMethods

# Generated at 2022-06-18 05:58:47.377775
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.ctx.app == None


# Generated at 2022-06-18 05:58:59.964923
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.dynamic_routes = {
        "test": Route(
            path="/test/<param>",
            handler=None,
            methods=["GET"],
            name=None,
            strict=False,
            unquote=False,
            ctx=None,
        )
    }
    try:
        router.finalize()
    except SanicException as e:
        assert str(e) == "Invalid route: /test/<param>. Parameter names cannot use '__'."
    else:
        assert False

# Generated at 2022-06-18 05:59:05.615159
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 05:59:16.406746
# Unit test for method add of class Router
def test_Router_add():
    from sanic.app import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.response import json
    from sanic.response import text

    app = Sanic("test_Router_add")

    @app.route("/")
    async def handler(request):
        return text("OK")

    @app.route("/json")
    async def handler_json(request):
        return json({"test": True})

    @app.route("/post", methods=["POST"])
    async def handler_post(request):
        return text("OK")

    @app.route("/get", methods=["GET"])
    async def handler_get(request):
        return text("OK")


# Generated at 2022-06-18 05:59:23.159258
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler

    def test_handler(request):
        pass

    router = Router()
    router.add("/test", ["GET"], test_handler)
    router.add("/test/<__test>", ["GET"], test_handler)
    try:
        router.finalize()
    except SanicException as e:
        assert str(e) == "Invalid route: /test/<__test>. Parameter names cannot use '__'."
    else:
        assert False

# Generated at 2022-06-18 05:59:34.777715
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.static_routes == []
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router

# Generated at 2022-06-18 05:59:39.170322
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 05:59:46.836869
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add(uri='/', methods=['GET'], handler=None)
    assert router.routes_all[0].path == '/'
    assert router.routes_all[0].methods == ['GET']
    assert router.routes_all[0].handler == None
    assert router.routes_all[0].ctx.ignore_body == False
    assert router.routes_all[0].ctx.stream == False
    assert router.routes_all[0].ctx.hosts == [None]
    assert router.routes_all[0].ctx.static == False


# Generated at 2022-06-18 05:59:57.941122
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []
    assert router.name_index == {}
    assert router.ctx == {}
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []
    assert router.name_index == {}
    assert router.ctx == {}
    assert router.routes_all == []
    assert router.routes_static == []

# Generated at 2022-06-18 06:00:07.002517
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router._get.cache_info().maxsize == ROUTER_CACHE_SIZE
    assert router.get.cache_info().maxsize == ROUTER_CACHE_SIZE
    assert router.find_route_by_view_name.cache_info().maxsize == ROUTER_CACHE_SIZE
    assert router.routes_all == router.routes
    assert router.routes_static == router.static_routes
    assert router.routes_dynamic == router.dynamic_routes
    assert router.routes_regex == router.regex_routes


# Generated at 2022-06-18 06:00:17.018156
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:00:34.628914
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS
    from sanic.response import HTTPResponse
    from sanic.request import Request
    from sanic.app import Sanic
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import HTTP_METHODS
    from sanic.response import HTTPResponse
    from sanic.request import Request
    from sanic.app import Sanic
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import HTTP_METHODS
    from sanic.response import HT

# Generated at 2022-06-18 06:00:41.100784
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:00:51.515422
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.constants import HTTP_METHODS
    from sanic.response import text
    from sanic.views import HTTPMethodView
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.exceptions import NotFound
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import ServerError
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import UnsupportedMediaType


# Generated at 2022-06-18 06:00:59.964898
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.blueprints import Blueprint
    from sanic.constants import HTTP_METHODS
    from sanic.exceptions import SanicException
    from sanic.router import Router
    from sanic.views import HTTPMethodView
    from sanic.response import HTTPResponse
    from sanic.request import Request
    from sanic.blueprints import Blueprint
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP

# Generated at 2022-06-18 06:01:09.891284
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.models.handler_types import RouteHandler
    from sanic.exceptions import SanicException
    from sanic.constants import HTTP_METHODS
    from sanic.response import text
    from sanic.request import Request
    from sanic.server import HttpProtocol
    from sanic.app import Sanic
    from sanic.websocket import WebSocketProtocol
    from sanic.constants import HTTP_METHODS
    from sanic.exceptions import NotFound, MethodNotSupported
    from sanic.models.handler_types import RouteHandler
    from sanic.router import Router
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.app import Sanic
    from sanic.response import text

# Generated at 2022-06-18 06:01:19.961194
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:01:28.204372
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route

    def handler():
        pass

    router = Router()
    router.add("/", ["GET"], handler, name="test")
    router.add("/", ["GET"], handler, name="__test")
    router.add("/", ["GET"], handler, name="__test__")
    router.add("/", ["GET"], handler, name="__test__")
    router.add("/", ["GET"], handler, name="__test__")
    router.add("/", ["GET"], handler, name="__test__")
    router.add("/", ["GET"], handler, name="__test__")

# Generated at 2022-06-18 06:01:36.394809
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.app import Sanic
    from sanic.router import Router
    from sanic.exceptions import SanicException

    app = Sanic("test_Router_finalize")
    router = Router(app)
    router.add("/test/<__file_uri__>", ["GET"], lambda r: "OK")
    router.finalize()

    try:
        router.add("/test/<__file_uri__>", ["GET"], lambda r: "OK")
        router.finalize()
    except SanicException:
        assert True
    else:
        assert False

# Generated at 2022-06-18 06:01:40.678830
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:01:46.647906
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:02:07.287509
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.static_routes == {}
    assert router.ctx.dynamic_routes == {}
    assert router.ctx.regex_routes == {}
    assert router.ctx.name_index == {}
    assert router.ctx.host_index == {}
    assert router.ctx.host_regex_index == {}


# Generated at 2022-06-18 06:02:15.654249
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.constants import HTTP_METHODS
    from sanic.models.handler_types import RouteHandler

    router = Router()
    router.add("/", HTTP_METHODS, RouteHandler, name="test")
    router.add("/", HTTP_METHODS, RouteHandler, name="__test")
    with pytest.raises(SanicException):
        router.finalize()

# Generated at 2022-06-18 06:02:25.622329
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app is None
    assert router.ctx.router is router
    assert router.ctx.hosts == [None]
    assert router.ctx.ignore_body is False
    assert router.ctx.stream is False
    assert router.ctx.static is False


# Generated at 2022-06-18 06:02:32.563472
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.constants import HTTP_METHODS
    from sanic.models.handler_types import RouteHandler

    router = Router()
    router.add("/", HTTP_METHODS, RouteHandler, name="__file_uri__")
    router.add("/", HTTP_METHODS, RouteHandler, name="__file_uri__")
    router.add("/", HTTP_METHODS, RouteHandler, name="__file_uri__")
    router.add("/", HTTP_METHODS, RouteHandler, name="__file_uri__")
    router.add("/", HTTP_METHODS, RouteHandler, name="__file_uri__")
    router.add("/", HTTP_METHODS, RouteHandler, name="__file_uri__")


# Generated at 2022-06-18 06:02:45.356978
# Unit test for method add of class Router
def test_Router_add():
    from sanic.router import Router
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import NotFound

    router = Router()
    router.add("/", ["GET"], lambda request: HTTPResponse("OK"))
    router.add("/", ["POST"], lambda request: HTTPResponse("OK"))
    router.add("/", ["PUT"], lambda request: HTTPResponse("OK"))
    router.add("/", ["DELETE"], lambda request: HTTPResponse("OK"))
    router.add("/", ["PATCH"], lambda request: HTTPResponse("OK"))
    router.add("/", ["OPTIONS"], lambda request: HTTPResponse("OK"))
   

# Generated at 2022-06-18 06:02:55.627414
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.ctx == None
    assert router.name_index == {}
    assert router.static_index == {}
    assert router.regex_index == {}
    assert router.dynamic_index == {}
    assert router.dynamic_routes == {}
    assert router.static_routes == {}
    assert router.regex_routes == {}
    assert router.routes == {}
    assert router.routes_all == {}

# Generated at 2022-06-18 06:02:58.383144
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:03:01.063829
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add(uri='/', methods=['GET'], handler=None)
    router.finalize()

# Generated at 2022-06-18 06:03:04.324364
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []


# Generated at 2022-06-18 06:03:12.301219
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router


# Generated at 2022-06-18 06:03:44.595637
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.route import Route
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.blueprints import Blueprint
    from sanic.app import Sanic
    from sanic.websocket import WebSocketProtocol
    from sanic.server import HttpProtocol
    from sanic.constants import HTTP_METHODS
    from sanic.constants import HTTP_STATUS_CODES
    from sanic.constants import SERVER_SOFTWARE
    from sanic.constants import LOGO

# Generated at 2022-06-18 06:03:46.772793
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)

# Generated at 2022-06-18 06:03:50.669089
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:03:54.462659
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:03:57.282287
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []


# Generated at 2022-06-18 06:04:09.981091
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS
    from sanic.response import text
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.app import Sanic
    from sanic.constants import HTTP_METHODS

    def handler(request):
        return text("OK")

    router = Router()
    router.add("/", HTTP_METHODS, handler)
    router.add("/<param>", HTTP_METHODS, handler)

# Generated at 2022-06-18 06:04:15.585026
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router


# Generated at 2022-06-18 06:04:23.822210
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app is None
    assert router.ctx.router is router
    assert router.ctx.name_index is router.name_index
    assert router.ctx.routes_all is router.routes_all
    assert router.ctx.routes_static is router.routes_static
    assert router.ctx.routes_dynamic is router.routes_dynamic
    assert router.ctx

# Generated at 2022-06-18 06:04:35.309898
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add("/", ["GET"], lambda: None)
    router.add("/<param>", ["GET"], lambda param: None)
    router.add("/<param>/<param2>", ["GET"], lambda param, param2: None)
    router.add("/<param>/<param2>/<param3>", ["GET"], lambda param, param2, param3: None)
    router.add("/<param>/<param2>/<param3>/<param4>", ["GET"], lambda param, param2, param3, param4: None)
    router.add("/<param>/<param2>/<param3>/<param4>/<param5>", ["GET"], lambda param, param2, param3, param4, param5: None)

# Generated at 2022-06-18 06:04:40.411948
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:05:30.366759
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.response import text
    router = Router()
    router.add("/", ["GET"], text("OK"))
    router.add("/<name>", ["GET"], text("OK"))
    router.finalize()
    assert router.routes_dynamic["/<name>"]
    assert router.routes_dynamic["/<name>"].labels == ["name"]
    router.add("/<__name>", ["GET"], text("OK"))
    try:
        router.finalize()
    except SanicException as e:
        assert str(e) == "Invalid route: /<__name> -> <function text at 0x7f8b8d9c3d08> (GET). Parameter names cannot use '__'."

# Generated at 2022-06-18 06:05:35.851002
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add("/", ["GET"], None, name="test")
    router.finalize()
    assert router.routes_all
    assert router.routes_static
    assert router.routes_dynamic
    assert router.routes_regex
    assert router.find_route_by_view_name("test")


# Generated at 2022-06-18 06:05:44.504861
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:05:51.514404
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.models.route_parameter import RouteParameter
    from sanic.models.route_parameter_type import RouteParameterType
    from sanic.models.route_parameter_type_converter import RouteParameterTypeConverter
    from sanic.models.route_parameter_type_converter_regex import RouteParameterTypeConverterRegex
    from sanic.models.route_parameter_type_converter_string import RouteParameterTypeConverterString
    from sanic.models.route_parameter_type_converter_uuid import RouteParameterTypeConverterUUID

# Generated at 2022-06-18 06:05:58.394012
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route(
        path="/",
        handler=None,
        methods=["GET"],
        name=None,
        strict=False,
        unquote=False,
    )
    route.labels = ["__file_uri__", "__file_uri__"]
    router.dynamic_routes = {
        "/": route
    }
    router.finalize()

# Generated at 2022-06-18 06:06:06.018690
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.response import text
    from sanic.exceptions import SanicException

    router = Router()

    @router.get("/")
    async def handler(request):
        return text("OK")

    router.finalize()

    assert router.routes_all
    assert router.routes_static
    assert router.routes_dynamic
    assert router.routes_regex


# Generated at 2022-06-18 06:06:16.899253
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.constants import HTTP_METHODS
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler

    router = Router()
    router.add(
        uri="/test",
        methods=HTTP_METHODS,
        handler=RouteHandler(),
        host=None,
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version=None,
        name=None,
        unquote=False,
        static=False,
    )
    try:
        router.finalize()
    except SanicException as e:
        assert e.args[0] == "Invalid route: /test. Parameter names cannot use '__'."

# Generated at 2022-06-18 06:06:22.949231
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == {}


# Generated at 2022-06-18 06:06:29.977403
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.hosts == [None]
    assert router.ctx.ignore_body == False
    assert router.ctx.stream == False
    assert router.ctx.static == False


# Generated at 2022-06-18 06:06:38.931045
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.constants import HTTP_METHODS
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.models.route import RouteContext
    from sanic.models.route import RouteMethods
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethods