

# Generated at 2022-06-18 05:57:46.784265
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []
    assert router.name_index == {}
    assert router.ctx == None
    assert router.static_routes == []
    assert router.dynamic_routes == {}
    assert router.regex_routes == []
    assert router.routes == []
    assert router.name_index == {}
    assert router.ctx == None
    assert router.static_routes == []
    assert router.dynamic_routes == {}
    assert router.re

# Generated at 2022-06-18 05:57:58.593217
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.views import CompositionView
    from sanic.views import CompositionViewError
    from sanic.views import Stream
    from sanic.views import stream_with_context
    from sanic.views import HTTPMethodView
    from sanic.views import HTTPMethodViewType
    from sanic.views import CompositionViewType
    from sanic.views import StreamType
    from sanic.views import stream_with_context

# Generated at 2022-06-18 05:58:05.330042
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add(uri='/', methods=['GET'], handler=None)
    router.add(uri='/', methods=['GET'], handler=None, name='test')
    router.add(uri='/', methods=['GET'], handler=None, name='__file_uri__')
    router.add(uri='/', methods=['GET'], handler=None, name='__file_uri__')
    router.finalize()

# Generated at 2022-06-18 05:58:20.647350
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.blueprints import Blueprint

    class TestView(HTTPMethodView):
        def get(self, request):
            return HTTPResponse()

    router = Router()

# Generated at 2022-06-18 05:58:31.079835
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add("/", ["GET"], lambda: None)
    router.add("/<name>", ["GET"], lambda: None)
    router.add("/<name>/<id>", ["GET"], lambda: None)
    router.add("/<name>/<id>/<name2>", ["GET"], lambda: None)
    router.add("/<name>/<id>/<name2>/<id2>", ["GET"], lambda: None)
    router.add("/<name>/<id>/<name2>/<id2>/<name3>", ["GET"], lambda: None)
    router.add("/<name>/<id>/<name2>/<id2>/<name3>/<id3>", ["GET"], lambda: None)


# Generated at 2022-06-18 05:58:36.193955
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 05:58:48.216845
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.static_routes == {}
    assert router.ctx.dynamic_routes == {}
    assert router.ctx.regex_routes == {}
    assert router.ctx.name_index == {}
    assert router.ctx.host_index == {}
    assert router.ctx.host_routes == {}
   

# Generated at 2022-06-18 05:58:57.771353
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add("/", ["GET"], lambda x: x)
    router.add("/<name>", ["GET"], lambda x: x)
    router.finalize()

# Generated at 2022-06-18 05:59:08.712649
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 05:59:17.263896
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.static_routes == []
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 05:59:24.762851
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 05:59:27.814129
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)
    assert isinstance(router, BaseRouter)


# Generated at 2022-06-18 05:59:38.589510
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 05:59:47.487565
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.routes == []
    assert router.ctx.static_routes == []
    assert router.ctx.dynamic_routes == []
    assert router.ctx.regex_routes == []
    assert router.ctx.name_index == {}
    assert router.ctx.host_index == {}
    assert router.ctx.host_routes == {}
    assert router.ctx.host_regex_routes == {}
    assert router

# Generated at 2022-06-18 05:59:54.199703
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    router = Router()
    router.add(uri='/test/<param1>/<param2>', methods=['GET'], handler=None)
    try:
        router.finalize()
    except SanicException as e:
        assert str(e) == "Invalid route: /test/<param1>/<param2>. Parameter names cannot use '__'."

# Generated at 2022-06-18 06:00:03.116727
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.constants import HTTP_METHODS
    from sanic.exceptions import SanicException

    router = Router()
    router.add("/", HTTP_METHODS, lambda x: x)
    router.add("/<__file_uri__>", HTTP_METHODS, lambda x: x)
    router.add("/<__file_uri__>/<__file_uri__>", HTTP_METHODS, lambda x: x)
    router.add("/<__file_uri__>/<__file_uri__>/<__file_uri__>", HTTP_METHODS, lambda x: x)

# Generated at 2022-06-18 06:00:06.908193
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:00:10.794716
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:00:20.769445
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.host == None
    assert router.ctx.hosts == None
    assert router.ctx.ignore_body == False
    assert router.ctx.stream == False
    assert router.ctx.static == False
    assert router.ctx.version == None
    assert router.ctx.name == None
    assert router.ctx.strict == False

# Generated at 2022-06-18 06:00:27.440146
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == []
    assert router.routes_regex == []
    assert router.ctx == None
    assert router.name_index == {}
    assert router.path_index == {}
    assert router.regex_index == {}
    assert router.static_index == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.routes == []
    assert router.host_index == {}


# Generated at 2022-06-18 06:00:35.429856
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add("/test", ["GET"], lambda x: x)
    assert router.routes_all[0].path == "/test"
    assert router.routes_all[0].methods == ["GET"]

# Generated at 2022-06-18 06:00:47.533222
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.models.handler_types import RouteHandler
    from sanic.exceptions import SanicException
    from sanic.constants import HTTP_METHODS
    from sanic.response import text
    from sanic.request import Request
    from sanic.server import HttpProtocol
    from sanic.app import Sanic
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocket
    from sanic.websocket import WebSocketProtocol13
    from sanic.websocket import WebSocketProtocol

# Generated at 2022-06-18 06:00:52.305837
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    router = Router()
    router.add(uri='/test/<param1>/<param2>', methods=['GET'], handler=None)
    try:
        router.finalize()
    except SanicException:
        assert True
    else:
        assert False


# Generated at 2022-06-18 06:01:01.478591
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.route import Route
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS

    router = Router()
    router.add(uri='/', methods=HTTP_METHODS, handler=RouteHandler(None))
    try:
        router.finalize()
    except SanicException as e:
        assert str(e) == "Invalid route: Route(/). Parameter names cannot use '__'."
    else:
        assert False


# Generated at 2022-06-18 06:01:07.265826
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS
    from sanic.response import text
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.exceptions import NotFound
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import ServerError
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import ContentTypeError
    from sanic.exceptions import HeaderNotFound
    from sanic.exceptions import HeaderValueError

# Generated at 2022-06-18 06:01:12.924861
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:01:20.400982
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.ctx.app is None
    assert router.ctx.router is router
    assert router.ctx.router_cache_size == ROUTER_CACHE_SIZE
    assert router.ctx.router_allowed_labels == ALLOWED_LABELS
    assert router.ctx.router_default_method == "GET"
    assert router.ctx.router_allowed_methods == HTTP_METHODS


# Generated at 2022-06-18 06:01:24.870855
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:01:28.868644
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    router = Router()
    try:
        router.finalize()
    except SanicException as e:
        assert str(e) == "Invalid route: /<__file_uri__>. Parameter names cannot use '__'."

# Generated at 2022-06-18 06:01:32.794859
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == 'GET'
    assert router.ALLOWED_METHODS == ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS', 'HEAD']
    assert router.ctx == None
    assert router.routes == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.path_index == {}
    assert router.host_index == {}
    assert router.method_index == {}
    assert router.host_method_index == {}
    assert router.host_path_index == {}
    assert router.host_method_path_index == {}
    assert router.host_method_

# Generated at 2022-06-18 06:01:48.054201
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.static_routes == router.routes_static
    assert router.ctx.dynamic_routes == router.routes_dynamic
    assert router.ctx.regex_routes == router.routes_regex
    assert router.ctx.name_index == router.name_index

# Unit

# Generated at 2022-06-18 06:01:51.386208
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:02:02.988556
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add(uri='/', methods=['GET'], handler=None)
    router.add(uri='/', methods=['GET'], handler=None, host=None)
    router.add(uri='/', methods=['GET'], handler=None, host=None, strict_slashes=False)
    router.add(uri='/', methods=['GET'], handler=None, host=None, strict_slashes=False, stream=False)
    router.add(uri='/', methods=['GET'], handler=None, host=None, strict_slashes=False, stream=False, ignore_body=False)

# Generated at 2022-06-18 06:02:10.755106
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS

    router = Router()
    router.add(uri='/', methods=HTTP_METHODS, handler=RouteHandler)
    router.add(uri='/', methods=HTTP_METHODS, handler=RouteHandler, name='test')
    router.add(uri='/', methods=HTTP_METHODS, handler=RouteHandler, name='test__')
    router.add(uri='/', methods=HTTP_METHODS, handler=RouteHandler, name='__test')
    router.add(uri='/', methods=HTTP_METHODS, handler=RouteHandler, name='__test__')

# Generated at 2022-06-18 06:02:16.738649
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:02:27.452059
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:02:37.262944
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.constants import HTTP_METHODS
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.models.route import RouteContext
    from sanic.models.route import RouteMethods
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethods

# Generated at 2022-06-18 06:02:41.689229
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:02:47.299321
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.ctx == {}


# Generated at 2022-06-18 06:02:53.970604
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler

    router = Router()

    def handler():
        pass

    router.add("/", ["GET"], handler, name="test")
    router.add("/", ["GET"], handler, name="__test")
    router.add("/", ["GET"], handler, name="__test__")

    try:
        router.finalize()
    except SanicException:
        assert True
    else:
        assert False

# Generated at 2022-06-18 06:03:05.494287
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:03:16.012786
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.models.handler_types import RouteHandler
    from sanic.exceptions import SanicException
    from sanic.constants import HTTP_METHODS
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.websocket import WebSocketProtocol
    from sanic.blueprints import Blueprint
    from sanic.app import Sanic
    from sanic.constants import HTTP_METHODS
    from sanic.exceptions import SanicException
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.websocket import WebSocketProtocol

# Generated at 2022-06-18 06:03:22.394218
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []


# Generated at 2022-06-18 06:03:31.596533
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.host == None
    assert router.ctx.hosts == [None]
    assert router.ctx.ignore_body == False
    assert router.ctx.stream == False
    assert router.ctx.static == False
    assert router.ctx.version == None
    assert router.ctx.name == None
    assert router.ctx.unquote == False
    assert router.ctx.strict == False
    assert router.ctx.requirements == {}
    assert router.ctx.labels == {}
    assert router.ctx.parameters == {}
    assert router.ctx.defaults == {}

# Generated at 2022-06-18 06:03:38.220333
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route(
        path="/",
        handler=None,
        methods=["GET"],
        name=None,
        strict=False,
        unquote=False,
    )
    route.labels = ["__file_uri__", "__test__"]
    router.dynamic_routes["/"] = route
    try:
        router.finalize()
    except SanicException:
        assert True
    else:
        assert False

# Generated at 2022-06-18 06:03:45.607390
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route(
        path="/",
        handler=None,
        methods=["GET"],
        name=None,
        strict=False,
        unquote=False,
    )
    route.labels = ["__file_uri__", "__test__"]
    router.dynamic_routes = {"/": route}
    with pytest.raises(SanicException):
        router.finalize()

# Generated at 2022-06-18 06:03:47.376741
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-18 06:03:57.647847
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.ctx == None
    assert router.routes == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.path_index == {}
    assert router.host_index == {}
    assert router.method_index == {}
    assert router.host_method_index == {}
    assert router.host_path_index == {}
    assert router.host_method_path_index == {}
    assert router.host_method_path_index == {}
    assert router.host_method_path_index == {}

# Generated at 2022-06-18 06:04:05.825283
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router


# Generated at 2022-06-18 06:04:11.793040
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:04:34.403296
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:04:40.944780
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router


# Generated at 2022-06-18 06:04:47.608831
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.host == None
    assert router.ctx.hosts == [None]
    assert router.ctx.ignore_body == False
    assert router.ctx.stream == False
    assert router.ctx.static == False
    assert router.ctx.version == None
    assert router.ctx.name == None


# Generated at 2022-06-18 06:04:53.593554
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:05:01.510272
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.router_cache_size == ROUTER_CACHE_SIZE
    assert router.ctx.router_allowed_labels == ALLOWED_LABELS
    assert router.ctx.router_default_method == "GET"
    assert router.ctx.router_allowed_methods == HTTP_METHODS
    assert router.ctx.router_default_method == "GET"
    assert router.ctx.router_allowed_methods == HTTP_METHODS
    assert router.ctx.router_default_method == "GET"
    assert router.ctx.router_allowed

# Generated at 2022-06-18 06:05:11.349397
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:05:22.538183
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.host == None
    assert router.ctx.hosts == [None]
    assert router.ctx.ignore_body == False
    assert router.ctx.stream == False
    assert router.ctx.static == False
    assert router.ctx.version == None
    assert router.ctx.name == None
    assert router.ctx.unquote

# Generated at 2022-06-18 06:05:29.239360
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == {}
    assert router.ctx.app == None
    assert router.ctx.router == router


# Generated at 2022-06-18 06:05:30.812415
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add("/test/<param>", ["GET"], lambda x: x)
    router.finalize()

# Generated at 2022-06-18 06:05:39.710709
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.static_routes == []
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:06:22.742080
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    router = Router()
    route = router.add("/test", ["GET"], lambda x: x)
    route.labels = ["__test__"]
    try:
        router.finalize()
    except SanicException as e:
        assert str(e) == "Invalid route: /test. Parameter names cannot use '__'."

# Generated at 2022-06-18 06:06:23.999717
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-18 06:06:31.960522
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == 'GET'
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.router_name == 'router'
    assert router.ctx.app_name == 'app'
    assert router.ctx.host == None
    assert router.ctx.host_name == 'host'
    assert router.ctx.host_regex == None
    assert router.ctx.host_regex_name == 'host_regex'
    assert router.ctx.host_regex_pattern == None
    assert router.ctx.host_regex_pattern_name == 'host_regex_pattern'
    assert router.ctx.host_regex_match == None

# Generated at 2022-06-18 06:06:35.320105
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:06:40.320416
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:06:44.826479
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:06:55.667453
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.route import Route
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS

    router = Router()
    uri = "/"
    methods = HTTP_METHODS
    handler = RouteHandler()
    host = None
    strict_slashes = False
    stream = False
    ignore_body = False
    version = None
    name = None
    unquote = False
    static = False

    route = router.add(uri, methods, handler, host, strict_slashes, stream, ignore_body, version, name, unquote, static)
    route.labels = ["__file_uri__", "__test__"]

# Generated at 2022-06-18 06:07:00.661002
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:07:07.760944
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}

# Generated at 2022-06-18 06:07:13.249184
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
