

# Generated at 2022-06-18 05:57:33.257381
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.constants import HTTP_METHODS
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.models.route_param import RouteParam
    from sanic.models.route_param_type import RouteParamType
    from sanic.models.route_param_type_converter import RouteParamTypeConverter
    from sanic.models.route_param_type_regex import RouteParamTypeRegex
    from sanic.models.route_param_type_string import RouteParamTypeString
    from sanic.models.route_param_type_uuid import RouteParamTypeUUID
    from sanic.models.route_param_type_int import RouteParamTypeInt


# Generated at 2022-06-18 05:57:43.015457
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []
    assert router.name_index == {}
    assert router.ctx == None
    assert router.static_routes == []
    assert router.dynamic_routes == {}
    assert router.regex_routes == []
    assert router.routes == []
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}

# Generated at 2022-06-18 05:57:48.673260
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 05:57:57.596067
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.dynamic_routes = {
        "test": Route(
            path="/test/<param1>/<param2>",
            handler=None,
            methods=["GET"],
            name=None,
            strict=False,
            unquote=False,
        )
    }
    try:
        router.finalize()
    except SanicException as e:
        assert str(e) == "Invalid route: /test/<param1>/<param2>. Parameter names cannot use '__'."
    else:
        assert False


# Generated at 2022-06-18 05:58:04.238353
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []
    assert router.name_index == {}
    assert router.ctx == {}


# Generated at 2022-06-18 05:58:11.349938
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.constants import HTTP_METHODS
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.models.route_parameter import RouteParameter
    from sanic.models.route_parameter_type import RouteParameterType
    from sanic.models.route_parameter_type_converter import RouteParameterTypeConverter
    from sanic.models.route_parameter_type_validator import RouteParameterTypeValidator
    from sanic.models.route_parameter_type_validator_regex import RouteParameterTypeValidatorRegex
    from sanic.models.route_parameter_type_validator_type import RouteParameterTypeValidatorType

# Generated at 2022-06-18 05:58:24.753054
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.constants import HTTP_METHODS
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler

    router = Router()
    router.add("/", HTTP_METHODS, RouteHandler, name="test")
    router.add("/", HTTP_METHODS, RouteHandler, name="__test")
    router.add("/", HTTP_METHODS, RouteHandler, name="__test__")
    router.add("/", HTTP_METHODS, RouteHandler, name="__test_")
    router.add("/", HTTP_METHODS, RouteHandler, name="_test__")
    router.add("/", HTTP_METHODS, RouteHandler, name="_test_")

# Generated at 2022-06-18 05:58:30.192531
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 05:58:40.949726
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == []
    assert router.routes_static == []

# Generated at 2022-06-18 05:58:53.064650
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.routes == []
    assert router.ctx.static_routes == []
    assert router.ctx.dynamic_routes == []
    assert router.ctx.regex_routes == []
    assert router.ctx.name_index == {}
    assert router.ctx.host_index == {}
    assert router

# Generated at 2022-06-18 05:59:00.016368
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add("/test/<param>", ["GET"], lambda x: x)
    router.finalize()

# Generated at 2022-06-18 05:59:11.224517
# Unit test for method finalize of class Router

# Generated at 2022-06-18 05:59:21.098316
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.static_routes == []
    assert router.ctx.dynamic_routes == []
    assert router.ctx.regex_routes == []
    assert router.ctx.name_index == {}
    assert router.ctx.path_index == {}
    assert router.ctx.host_index == {}
    assert router.ctx.method_index == {}
   

# Generated at 2022-06-18 05:59:32.541342
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.constants import HTTP_METHODS
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.models.route_info import RouteInfo
    from sanic.models.route_param import RouteParam
    from sanic.models.route_param_info import RouteParamInfo
    from sanic.models.route_param_type import RouteParamType
    from sanic.models.route_param_value import RouteParamValue
    from sanic.models.route_param_value_info import RouteParamValueInfo
    from sanic.models.route_param_value_type import RouteParamValueType
    from sanic.models.route_param_value_type_info import RouteParamValue

# Generated at 2022-06-18 05:59:40.664412
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == {}
    assert router.ctx.app == None
    assert router.ctx.router == router


# Generated at 2022-06-18 05:59:45.382603
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []


# Generated at 2022-06-18 05:59:56.812033
# Unit test for method add of class Router
def test_Router_add():
    from sanic.app import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.router import Router
    from sanic.views import HTTPMethodView

    app = Sanic("test_Router_add")
    router = Router(app)

    class SimpleView(HTTPMethodView):
        def get(self, request: Request) -> HTTPResponse:
            return HTTPResponse(b"OK")


# Generated at 2022-06-18 06:00:04.915961
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.route import Route
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS
    from sanic.models.route import Route
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS
    from sanic.models.route import Route
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS
    from sanic.models.route import Route
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS
    from sanic.models.route import Route
    from sanic.models.handler_types import RouteHandler


# Generated at 2022-06-18 06:00:11.630823
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:00:21.446405
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.hosts == []
    assert router.ctx.host == None
    assert router.ctx.static == False
    assert router.ctx.stream == False
    assert router.ctx.ignore_body == False
    assert router.ctx.version == None
    assert router.ctx.name == None
    assert router.ctx.strict == False

# Generated at 2022-06-18 06:00:30.965846
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add("/test/<name>", ["GET"], lambda request: "")
    router.finalize()
    assert router.routes_dynamic
    assert router.routes_regex
    assert router.routes_static
    assert router.routes_all


# Generated at 2022-06-18 06:00:32.445094
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-18 06:00:39.296306
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add(uri='/', methods=['GET'], handler=None)
    router.add(uri='/', methods=['GET'], handler=None, name='test')
    router.add(uri='/', methods=['GET'], handler=None, name='__test__')
    router.add(uri='/', methods=['GET'], handler=None, name='__file_uri__')
    try:
        router.add(uri='/', methods=['GET'], handler=None, name='__test')
    except SanicException as e:
        assert str(e) == "Invalid route: / GET. Parameter names cannot use '__'."
    else:
        assert False, "Should raise SanicException"

# Generated at 2022-06-18 06:00:41.969975
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS

# Generated at 2022-06-18 06:00:52.356549
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.hosts == None
    assert router.ctx.stream == False
    assert router.ctx.ignore_body == False
    assert router.ctx.static == False
    assert router.ctx.name == None
    assert router.ctx.unquote == False
    assert router.ctx.strict == False
    assert router.ctx.requirements == {}
    assert router.ctx.defaults == {}
    assert router.ctx.labels == {}
    assert router.ctx.host == None
    assert router.ctx.version == None
    assert router.ctx.path == None
    assert router.ctx

# Generated at 2022-06-18 06:01:03.172926
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.ctx == None
    assert router.routes == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.path_index == {}
    assert router.host_index == {}
    assert router.method_index == {}
    assert router.version_index == {}
    assert router.host_method_index == {}
    assert router.host_path_index == {}
    assert router.host_method_path_index == {}
    assert router.host_method_path_index == {}
    assert router.host_method_path_index == {}
    assert router.host_method_path_index == {}
    assert router.host_method

# Generated at 2022-06-18 06:01:04.589109
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-18 06:01:09.006088
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.routing import Route
    from sanic.constants import HTTP_METHODS
    from sanic.models.handler_types import RouteHandler
    from sanic.response import text

    router = Router()
    router.add(uri='/', methods=HTTP_METHODS, handler=text('OK'), name='test')
    router.add(uri='/', methods=HTTP_METHODS, handler=text('OK'), name='test__')
    router.add(uri='/', methods=HTTP_METHODS, handler=text('OK'), name='__test')
    router.add(uri='/', methods=HTTP_METHODS, handler=text('OK'), name='__test__')

# Generated at 2022-06-18 06:01:19.810963
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add(uri='/', methods=['GET'], handler=None)
    router.finalize()

# Generated at 2022-06-18 06:01:26.821556
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.router_cache_size == ROUTER_CACHE_SIZE
    assert router.ctx.router_allowed_labels == ALLOWED_LABELS


# Generated at 2022-06-18 06:01:36.452151
# Unit test for constructor of class Router
def test_Router():
    r = Router()
    assert r.DEFAULT_METHOD == "GET"
    assert r.ALLOWED_METHODS == HTTP_METHODS


# Generated at 2022-06-18 06:01:47.502293
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.constants import HTTP_METHODS
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.models.route_parameter import RouteParameter
    from sanic.models.route_parameter_type import RouteParameterType
    from sanic.models.route_parameter_type import RouteParameterType
    from sanic.models.route_parameter_type import RouteParameterType
    from sanic.models.route_parameter_type import RouteParameterType
    from sanic.models.route_parameter_type import RouteParameterType
    from sanic.models.route_parameter_type import RouteParameterType
    from sanic.models.route_parameter_type import RouteParameter

# Generated at 2022-06-18 06:01:52.574366
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:01:58.902403
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:02:05.206258
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == {}


# Generated at 2022-06-18 06:02:16.532912
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app is None
    assert router.ctx.router is router
    assert router.ctx.static_routes == {}
    assert router.ctx.dynamic_routes == {}
    assert router.ctx.regex_routes == {}
    assert router.ctx.name_index == {}
    assert router.ctx.host_index == {}
    assert router.ctx.host_routes == {}
   

# Generated at 2022-06-18 06:02:20.600332
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:02:26.351931
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:02:31.535594
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add("/", ["GET"], lambda: None)
    router.add("/<param>", ["GET"], lambda param: None)
    router.add("/<param>", ["GET"], lambda __param: None)
    router.add("/<param>", ["GET"], lambda __file_uri__: None)
    router.add("/<param>", ["GET"], lambda __file_uri__param: None)
    router.add("/<param>", ["GET"], lambda __file_uri__param__: None)
    router.finalize()
    assert True

# Generated at 2022-06-18 06:02:39.116558
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:02:59.315251
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    router = Router()
    router.dynamic_routes = {'a': {'labels': ['__file_uri__', '__file_uri__']}}
    router.finalize()
    router.dynamic_routes = {'a': {'labels': ['__file_uri__', '__file_uri__1']}}
    try:
        router.finalize()
    except SanicException as e:
        assert str(e) == "Invalid route: {'labels': ['__file_uri__', '__file_uri__1']}. Parameter names cannot use '__'."


# Generated at 2022-06-18 06:03:05.913330
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:03:15.653378
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:03:23.076341
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:03:26.486796
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:03:29.998396
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.app import Sanic
    app = Sanic("test_Router_finalize")
    router = Router(app)
    router.add("/test/<param>", ["GET"], lambda r, p: None)
    router.finalize()


# Generated at 2022-06-18 06:03:34.404842
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:03:47.133532
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.models.handler_types import RouteHandler
    from sanic.exceptions import SanicException

    def handler():
        pass

    router = Router()
    router.add("/", ["GET"], handler)
    router.add("/<__file_uri__:path>", ["GET"], handler)
    router.add("/<__file_uri__:path>", ["GET"], handler)
    router.add("/<__file_uri__:path>", ["GET"], handler)
    router.add("/<__file_uri__:path>", ["GET"], handler)
    router.add("/<__file_uri__:path>", ["GET"], handler)
    router.add("/<__file_uri__:path>", ["GET"], handler)
    router.add

# Generated at 2022-06-18 06:03:56.944754
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:04:09.059760
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == {}
    assert router.routes_static == {}

# Generated at 2022-06-18 06:04:42.680126
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.models.handler_types import RouteHandler
    from sanic.exceptions import SanicException

    router = Router()
    router.add("/test/<__file_uri__>", ["GET"], RouteHandler)
    router.finalize()

    with pytest.raises(SanicException):
        router.add("/test/<__file_uri__>", ["GET"], RouteHandler)
        router.finalize()

# Generated at 2022-06-18 06:04:53.725499
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.static_routes == {}
    assert router.ctx.dynamic_routes == {}
    assert router.ctx.regex_routes == {}
    assert router.ctx.name_index == {}
    assert router.ctx.host_index == {}
    assert router.ctx.host_routes == {}
   

# Generated at 2022-06-18 06:05:01.598915
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.ctx.app is None
    assert router.ctx.router is router
    assert router.ctx.router_class is Router
    assert router.ctx.router_args == ()
    assert router.ctx.router_kwargs == {}
    assert router.ctx.router_cache_size == ROUTER_CACHE_SIZE
    assert router.ctx.router_cache_clear is False
    assert router.ctx.router_cache_clear_all is False
    assert router.ctx.router_cache_clear_all_except is False
    assert router.ctx.router_cache_clear_all_except_list == []
    assert router.ctx.router_cache_clear_all_except_regex == []
    assert router.ctx.router_cache_clear_all_

# Generated at 2022-06-18 06:05:07.201094
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:05:14.330128
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router


# Generated at 2022-06-18 06:05:21.357584
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:05:26.545109
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:05:33.480945
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.routing import Route
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS
    from sanic.response import text
    from sanic.views import HTTPMethodView
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import NotFound, MethodNotSupported
    from sanic.constants import HTTP_METHODS
    from sanic.models.handler_types import RouteHandler
    from sanic.models.handler_types import RequestHandler
    from sanic.models.handler_types import RequestHandler

# Generated at 2022-06-18 06:05:39.886935
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:05:44.310539
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:06:55.164750
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-18 06:07:00.252120
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:07:07.350929
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    router = Router()
    route = router.add('/test/<param>', ['GET'], None)
    route.labels = ['__file_uri__', '__test__']
    try:
        router.finalize()
    except SanicException as e:
        assert str(e) == "Invalid route: /test/<param>. Parameter names cannot use '__'."
    else:
        assert False, "SanicException not raised"
    route.labels = ['__file_uri__', 'test']
    try:
        router.finalize()
    except SanicException as e:
        assert False, "SanicException raised"
    else:
        assert True


# Generated at 2022-06-18 06:07:17.813456
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.static_routes == {}
    assert router.ctx.dynamic_routes == {}
    assert router.ctx.regex_routes == {}
    assert router.ctx.name_index == {}
    assert router.ctx.host_index == {}
    assert router.ctx.host_index_static == {}
   

# Generated at 2022-06-18 06:07:26.846678
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.ctx == None
    assert router.name_index == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.routes == {}
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}