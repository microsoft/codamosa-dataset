

# Generated at 2022-06-18 05:57:53.511289
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add("/", ["GET"], None, name="index")
    router.add("/", ["GET"], None, name="__index")
    router.add("/", ["GET"], None, name="__file_uri__")
    router.add("/", ["GET"], None, name="__file_uri__")
    router.add("/", ["GET"], None, name="__file_uri__")
    router.add("/", ["GET"], None, name="__file_uri__")
    router.finalize()
    assert router.routes_all[0].name == "index"
    assert router.routes_all[1].name == "__index"
    assert router.routes_all[2].name == "__file_uri__"
    assert router.routes_

# Generated at 2022-06-18 05:58:04.922673
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route(
        path="/",
        handler=None,
        methods=["GET"],
        name=None,
        strict=False,
        unquote=False,
    )
    route.labels = ["__file_uri__", "__file_uri__"]
    router.dynamic_routes = {
        "/": route,
    }
    router.finalize()
    assert router.dynamic_routes == {
        "/": route,
    }

    route.labels = ["__file_uri__", "__file_uri__", "__file_uri__"]
    router.dynamic_routes = {
        "/": route,
    }
    with pytest.raises(SanicException):
        router.finalize()


# Generated at 2022-06-18 05:58:20.648708
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.ctx == None
    assert router.name_index == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.routes == {}
    assert router.name_index == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}


# Generated at 2022-06-18 05:58:29.446377
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}


# Generated at 2022-06-18 05:58:39.824888
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler

    router = Router()
    router.add("/", ["GET"], RouteHandler)
    router.add("/<name>", ["GET"], RouteHandler)
    router.add("/<__file_uri__>", ["GET"], RouteHandler)
    router.add("/<__file_uri__>/<name>", ["GET"], RouteHandler)
    router.add("/<__file_uri__>/<__file_uri__>", ["GET"], RouteHandler)
    router.add("/<__file_uri__>/<__file_uri__>/<name>", ["GET"], RouteHandler)


# Generated at 2022-06-18 05:58:45.983725
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 05:58:51.746546
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 05:58:59.699504
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.constants import HTTP_METHODS
    from sanic.app import Sanic
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.websocket import WebSocketProtocol
    from sanic.views import HTTPMethodView
    from sanic.blueprints import Blueprint
    from sanic.constants import HTTP_METHODS
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.router import Router
    from sanic.server import Http

# Generated at 2022-06-18 05:59:09.438248
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add(uri='/', methods=['GET'], handler=None)
    assert router.routes_all[0].path == '/'
    assert router.routes_all[0].methods == ['GET']
    assert router.routes_all[0].handler == None
    assert router.routes_all[0].ctx.ignore_body == False
    assert router.routes_all[0].ctx.stream == False
    assert router.routes_all[0].ctx.hosts == [None]
    assert router.routes_all[0].ctx.static == False


# Generated at 2022-06-18 05:59:19.391091
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.constants import HTTP_METHODS
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.views import CompositionView
    from sanic.views import CompositionViewError
    from sanic.views import HTTPMethodViewError
    from sanic.views import HTTPMethodViewType
    from sanic.views import HTTPMethodViewTypeError
    from sanic.views import HTTPMethodViewTypeError
    from sanic.views import HTTPMethodViewTypeError
    from sanic.views import HTTPMet

# Generated at 2022-06-18 05:59:34.188982
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.app import Sanic
    from sanic.router import Router
    from sanic.exceptions import SanicException

    app = Sanic('test_Router_finalize')
    router = Router(app)

    # Test for invalid route
    try:
        router.add(uri='/test', methods=['GET'], handler=None, name='test')
        router.finalize()
    except SanicException as e:
        assert str(e) == "Invalid route: /test. Parameter names cannot use '__'."

    # Test for valid route
    router.add(uri='/test', methods=['GET'], handler=None, name='test')
    router.finalize()

# Generated at 2022-06-18 05:59:38.487175
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 05:59:47.465186
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS
    from sanic.response import text
    from sanic.request import Request

    router = Router()
    router.add("/", HTTP_METHODS, text("OK"))
    router.add("/<__file_uri__:path>", HTTP_METHODS, text("OK"))
    router.add("/<__file_uri__:path>/<__file_uri__:path>", HTTP_METHODS, text("OK"))
    router.add("/<__file_uri__:path>/<__file_uri__:path>/<__file_uri__:path>", HTTP_METHODS, text("OK"))
   

# Generated at 2022-06-18 05:59:58.489767
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add(uri='/', methods=['GET'], handler=None)
    assert router.routes_all[0].path == '/'
    assert router.routes_all[0].methods == ['GET']
    assert router.routes_all[0].handler == None
    assert router.routes_all[0].ctx.ignore_body == False
    assert router.routes_all[0].ctx.stream == False
    assert router.routes_all[0].ctx.hosts == [None]
    assert router.routes_all[0].ctx.static == False
    assert router.routes_all[0].ctx.requirements == {}
    assert router.routes_all[0].ctx.name == None
    assert router.routes

# Generated at 2022-06-18 06:00:02.542176
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.ctx.app is None
    assert router.ctx.router is router


# Generated at 2022-06-18 06:00:09.561655
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.constants import HTTP_METHODS

    router = Router()
    router.add("/test/<__test>", HTTP_METHODS, lambda x: x)
    try:
        router.finalize()
    except SanicException as e:
        assert str(e) == "Invalid route: /test/<__test>. Parameter names cannot use '__'."
    else:
        assert False

# Generated at 2022-06-18 06:00:19.870043
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.routes == []
    assert router.ctx.static_routes == []
    assert router.ctx.dynamic_routes == []
    assert router.ctx.regex_routes == []
    assert router.ctx.name_index == {}
    assert router.ctx.host_index == {}
    assert router

# Generated at 2022-06-18 06:00:26.872941
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.prefix == ""
    assert router.ctx.host == None
    assert router.ctx.hosts == []
    assert router.ctx.version == None
    assert router.ctx.static == False
    assert router.ctx.stream == False
    assert router.ctx.ignore_body == False
    assert router.ctx.labels == []
    assert router.ctx.name == None
    assert router.ctx.strict == False
    assert router.ctx.unquote == False
    assert router.ctx.requirements == {}
    assert router.ctx.defaults == {}
    assert router.ctx

# Generated at 2022-06-18 06:00:32.802195
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:00:45.385262
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add("/", ["GET"], lambda x: x)
    router.add("/<param>", ["GET"], lambda x: x)
    router.add("/<param>", ["GET"], lambda x: x, unquote=True)
    router.add("/<param>", ["GET"], lambda x: x, unquote=False)
    router.add("/<param>", ["GET"], lambda x: x, unquote=False)
    router.add("/<param>", ["GET"], lambda x: x, unquote=False)
    router.add("/<param>", ["GET"], lambda x: x, unquote=False)
    router.add("/<param>", ["GET"], lambda x: x, unquote=False)

# Generated at 2022-06-18 06:01:03.402987
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.models.route import Route
    from sanic.models.route import Route
    from sanic.models.route import Route
    from sanic.models.route import Route
    from sanic.models.route import Route
    from sanic.models.route import Route
    from sanic.models.route import Route
    from sanic.models.route import Route
    from sanic.models.route import Route
    from sanic.models.route import Route
    from sanic.models.route import Route
    from sanic.models.route import Route
    from sanic.models.route import Route

# Generated at 2022-06-18 06:01:09.496796
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:01:18.013190
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router._get.cache_info().currsize == 0
    assert router.get.cache_info().currsize == 0
    assert router.find_route_by_view_name.cache_info().currsize == 0
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:01:22.809566
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:01:32.103323
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route(
        path="/",
        handler=None,
        methods=["GET"],
        name=None,
        strict=False,
        unquote=False,
    )
    route.labels = ["__file_uri__", "__file_uri__"]
    router.dynamic_routes = {
        "": route
    }
    router.finalize()
    assert router.dynamic_routes == {
        "": route
    }

    route.labels = ["__file_uri__", "__file_uri__", "__file_uri__"]
    router.dynamic_routes = {
        "": route
    }
    with pytest.raises(SanicException):
        router.finalize()

# Generated at 2022-06-18 06:01:40.626116
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    router = Router()
    router.add("/", ["GET"], None, name="__file_uri__")
    router.add("/", ["GET"], None, name="__file_uri__")
    router.add("/", ["GET"], None, name="__file_uri__")
    router.add("/", ["GET"], None, name="__file_uri__")
    router.add("/", ["GET"], None, name="__file_uri__")
    router.add("/", ["GET"], None, name="__file_uri__")
    router.add("/", ["GET"], None, name="__file_uri__")
    router.add("/", ["GET"], None, name="__file_uri__")

# Generated at 2022-06-18 06:01:51.355975
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:01:57.395841
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route(
        path="/",
        handler=None,
        methods=["GET"],
        name=None,
        strict=False,
        unquote=False,
    )
    route.labels = ["__file_uri__", "__file_uri__"]
    router.dynamic_routes = {"/": route}
    router.finalize()

# Generated at 2022-06-18 06:02:01.543425
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:02:09.433541
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:02:35.028080
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.app import Sanic
    app = Sanic()
    router = Router(app)
    router.add("/", ["GET"], lambda x: x)
    router.add("/<param>", ["GET"], lambda x: x)
    router.add("/<param:int>", ["GET"], lambda x: x)
    router.add("/<param:float>", ["GET"], lambda x: x)
    router.add("/<param:re:[a-z]+>", ["GET"], lambda x: x)
    router.add("/<param:re:[a-z]+>/<param2:re:[a-z]+>", ["GET"], lambda x: x)

# Generated at 2022-06-18 06:02:43.597319
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.response import text
    from sanic.exceptions import SanicException
    router = Router()
    router.add('/', ['GET'], text('OK'))
    router.add('/<__file_uri__:path>', ['GET'], text('OK'))
    try:
        router.add('/<__file_uri__:path>', ['GET'], text('OK'))
    except SanicException:
        pass
    else:
        assert False

# Generated at 2022-06-18 06:02:54.335161
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler

    def test_handler(request):
        return request

    router = Router()
    router.add("/test/<__file_uri__>", ["GET"], test_handler)
    router.finalize()

    router = Router()
    router.add("/test/<__file_uri__>", ["GET"], test_handler)
    router.add("/test/<__file_uri__>", ["GET"], test_handler)
    router.finalize()

    router = Router()
    router.add("/test/<__file_uri__>", ["GET"], test_handler)

# Generated at 2022-06-18 06:03:01.797250
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router._get.cache_info().currsize == 0
    assert router.get.cache_info().currsize == 0
    assert router.find_route_by_view_name.cache_info().currsize == 0
    assert router.routes_all == {}
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []


# Generated at 2022-06-18 06:03:12.945876
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.constants import HTTP_METHODS
    from sanic.exceptions import MethodNotSupported
    from sanic_routing.exceptions import NoMethod
    from sanic_routing.exceptions import NotFound as RoutingNotFound
    from sanic_routing.route import Route as RoutingRoute
    from sanic_routing import BaseRouter
    from sanic.constants import HTTP_METHODS
    from sanic.exceptions import MethodNotSupported, NotFound, SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.router import Router

# Generated at 2022-06-18 06:03:16.801977
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException

    router = Router()
    router.add("/test/<__test>", ["GET"], lambda x: x)
    try:
        router.finalize()
    except SanicException:
        assert True
    else:
        assert False

# Generated at 2022-06-18 06:03:22.184793
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route(path='/', handler=None, methods=['GET'], name=None, strict=False, unquote=False)
    route.labels = ['__file_uri__', '__file_uri__']
    router.dynamic_routes[route.path] = route
    router.finalize()

# Generated at 2022-06-18 06:03:31.429365
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.router_stack == []
    assert router.ctx.router_stack_size == 0
    assert router.ctx.router_stack_size_max == 0
    assert router.ctx.router_stack_size_min == 0
    assert router.ctx.router_stack_size_avg == 0
    assert router.ctx.router_stack_size_median == 0
    assert router.ctx.router_stack_size_mode == 0
    assert router.ctx.router_stack_size_variance == 0
    assert router.ctx.router_stack

# Generated at 2022-06-18 06:03:43.005578
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.constants import HTTP_METHODS

    router = Router()
    router.add(
        uri="/",
        methods=HTTP_METHODS,
        handler=RouteHandler(),
        host=None,
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version=None,
        name=None,
        unquote=False,
        static=False,
    )

# Generated at 2022-06-18 06:03:51.996667
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS

    router = Router()

    def handler_func():
        pass

    router.add("/test/<__test>", HTTP_METHODS, handler_func)
    try:
        router.finalize()
    except SanicException as e:
        assert str(e) == "Invalid route: /test/<__test>. Parameter names cannot use '__'."
    else:
        assert False

# Generated at 2022-06-18 06:04:15.173450
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:04:23.621800
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.ctx == None
    assert router.name_index == {}
    assert router.static_index == {}
    assert router.regex_index == {}
    assert router.dynamic_index == {}
    assert router.dynamic_routes == {}
    assert router.static_routes == []
    assert router.regex_routes == []
    assert router.routes == []
    assert router.routes_all == []

# Generated at 2022-06-18 06:04:24.970292
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-18 06:04:29.814926
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:04:39.585299
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:04:40.382765
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-18 06:04:43.220561
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == []
    assert router.routes_regex == []


# Generated at 2022-06-18 06:04:48.594770
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:04:54.185907
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:04:56.210058
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:05:31.947415
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == []
    assert router.routes_regex == []


# Generated at 2022-06-18 06:05:38.166766
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:05:42.986886
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:05:49.671986
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []
    assert router.name_index == {}
    assert router.ctx == None
    assert router.static_routes == []
    assert router.dynamic_routes == {}
    assert router.regex_routes == []
    assert router.routes == []
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:05:55.147141
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:06:03.986185
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router._get.cache_info().maxsize == ROUTER_CACHE_SIZE
    assert router.get.cache_info().maxsize == ROUTER_CACHE_SIZE
    assert router.find_route_by_view_name.cache_info().maxsize == ROUTER_CACHE_SIZE
    assert router.routes_all == router.routes
    assert router.routes_static == router.static_routes
    assert router.routes_dynamic == router.dynamic_routes
    assert router.routes_regex == router.regex_routes
    assert router.finalize() == None

# Unit

# Generated at 2022-06-18 06:06:07.433117
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:06:15.154646
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.ctx.app == None
    assert router.ctx.router == router


# Generated at 2022-06-18 06:06:21.279526
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:06:25.794937
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:07:29.544627
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:07:37.524863
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.routes == []
    assert router.ctx.static_routes == []
    assert router.ctx.dynamic_routes == []
    assert router.ctx.regex_routes == []
    assert router.ctx.name_index == {}
    assert router.ctx.host_index == {}