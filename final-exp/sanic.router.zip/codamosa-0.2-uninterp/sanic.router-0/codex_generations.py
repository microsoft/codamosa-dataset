

# Generated at 2022-06-18 05:57:46.784316
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app is None
    assert router.ctx.router is router
    assert router.ctx.static_routes == {}
    assert router.ctx.dynamic_routes == {}
    assert router.ctx.regex_routes == {}
    assert router.ctx.name_index == {}
    assert router.ctx.host_index == {}
    assert router.ctx.host_regex_index == {}


# Generated at 2022-06-18 05:57:48.513976
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-18 05:57:55.885680
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == 'GET'
    assert router.ALLOWED_METHODS == ['OPTIONS', 'HEAD', 'GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'TRACE', 'CONNECT']
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 05:58:06.867487
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add("/", ["GET"], lambda x: x, name="index")
    router.add("/", ["GET"], lambda x: x, name="index2")
    router.add("/", ["GET"], lambda x: x, name="__file_uri__")
    router.add("/", ["GET"], lambda x: x, name="__file_uri__2")
    router.add("/", ["GET"], lambda x: x, name="__file_uri__3")
    router.add("/", ["GET"], lambda x: x, name="__file_uri__4")
    router.add("/", ["GET"], lambda x: x, name="__file_uri__5")
    router.add("/", ["GET"], lambda x: x, name="__file_uri__6")

# Generated at 2022-06-18 05:58:14.309878
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route(
        path="/",
        handler=None,
        methods=["GET"],
        name=None,
        strict=False,
        unquote=False,
    )
    route.labels = ["__file_uri__", "__file_uri__"]
    router.dynamic_routes = {"/": route}
    router.finalize()

# Generated at 2022-06-18 05:58:19.870134
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 05:58:30.395963
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.models.handler_types import RouteHandler
    from sanic.exceptions import SanicException
    from sanic.constants import HTTP_METHODS
    from sanic.models.route import Route
    from sanic.models.route import RouteContext
    from sanic.models.route import RouteType
    from sanic.models.route import RouteTypeEnum
    from sanic.models.route import RouteTypeStatic
    from sanic.models.route import RouteTypeDynamic
    from sanic.models.route import RouteTypeRegex
    from sanic.models.route import RouteTypeStar
    from sanic.models.route import RouteTypeStarRegex
    from sanic.models.route import RouteTypeStarDynamic
    from sanic.models.route import RouteTypeStarRegexDynamic

# Generated at 2022-06-18 05:58:34.286372
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []


# Generated at 2022-06-18 05:58:38.824170
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    router = Router()
    try:
        router.finalize()
    except SanicException as e:
        assert str(e) == "Invalid route: /<__file_uri__>. Parameter names cannot use '__'."

# Generated at 2022-06-18 05:58:44.084460
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add('/', ['GET'], lambda x: x)
    assert router.routes_all[0].path == '/'
    assert router.routes_all[0].methods == ['GET']

# Generated at 2022-06-18 05:58:57.916544
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.constants import HTTP_METHODS

    class TestView(HTTPMethodView):
        def get(self, request):
            return HTTPResponse(text="OK")

    router = Router()
    router.add(
        uri="/test/",
        methods=HTTP_METHODS,
        handler=TestView.as_view(),
    )
    router.add(
        uri="/test/<__test_id>/",
        methods=HTTP_METHODS,
        handler=TestView.as_view(),
    )
   

# Generated at 2022-06-18 05:59:09.478779
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add(uri="/", methods=["GET"], handler=None)
    router.add(uri="/", methods=["GET"], handler=None)
    router.add(uri="/", methods=["GET"], handler=None)
    router.add(uri="/", methods=["GET"], handler=None)
    router.add(uri="/", methods=["GET"], handler=None)
    router.add(uri="/", methods=["GET"], handler=None)
    router.add(uri="/", methods=["GET"], handler=None)
    router.add(uri="/", methods=["GET"], handler=None)
    router.add(uri="/", methods=["GET"], handler=None)
    router.add(uri="/", methods=["GET"], handler=None)

# Generated at 2022-06-18 05:59:19.435462
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add(uri='/', methods=['GET'], handler=None)
    assert router.routes_all[0].path == '/'
    assert router.routes_all[0].methods == ['GET']
    assert router.routes_all[0].handler == None
    assert router.routes_all[0].ctx.ignore_body == False
    assert router.routes_all[0].ctx.stream == False
    assert router.routes_all[0].ctx.hosts == [None]
    assert router.routes_all[0].ctx.static == False
    assert router.routes_all[0].ctx.unquote == False
    assert router.routes_all[0].ctx.name == None
    assert router.routes

# Generated at 2022-06-18 05:59:26.128131
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.response import text
    from sanic.exceptions import SanicException
    from sanic.constants import HTTP_METHODS

    router = Router()
    router.add(
        uri="/test",
        methods=HTTP_METHODS,
        handler=text("OK"),
    )
    router.add(
        uri="/test/<__file_uri__:path>",
        methods=HTTP_METHODS,
        handler=text("OK"),
    )
    router.add(
        uri="/test/<__test__:path>",
        methods=HTTP_METHODS,
        handler=text("OK"),
    )

# Generated at 2022-06-18 05:59:37.440632
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.models.route import Route
    from sanic.models.handler_types import RouteHandler
    from sanic.exceptions import SanicException
    from sanic.constants import HTTP_METHODS
    from sanic.response import text
    from sanic.request import Request
    from sanic.views import HTTPMethodView
    from sanic.app import Sanic
    from sanic.websocket import WebSocketProtocol

    class TestView(HTTPMethodView):
        def get(self, request):
            return text("OK")

    class TestView2(HTTPMethodView):
        def get(self, request):
            return text("OK")


# Generated at 2022-06-18 05:59:43.538851
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 05:59:54.808767
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes == []
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.static_routes == []
    assert router.ctx.dynamic_routes == {}
    assert router.ctx.regex_routes == []
    assert router.ctx.name_index == {}
    assert router.ctx.host_index == {}
    assert router.ctx.host_regex_index == {}
    assert router.ctx.host_regex_index == {}

# Generated at 2022-06-18 06:00:03.013580
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == router.routes
    assert router.routes_static == router.static_routes
    assert router.routes_dynamic == router.dynamic_routes
    assert router.routes_regex == router.regex_routes


# Generated at 2022-06-18 06:00:14.179227
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.blueprints import Blueprint
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketDisconnect
    from sanic.websocket import WebSocket

# Generated at 2022-06-18 06:00:19.028911
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:00:29.999980
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:00:38.142955
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.response import text
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS

    router = Router()
    router.add(
        uri='/',
        methods=HTTP_METHODS,
        handler=text('OK'),
        host=None,
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version=None,
        name=None,
        unquote=False,
        static=False,
    )

# Generated at 2022-06-18 06:00:49.704785
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == {}
    assert router.ctx.app == {}
    assert router.ctx.router == router
    assert router.ctx.router.ctx == router.ctx
    assert router.ctx.router.ctx.router == router
    assert router.ctx.router.ctx.router.ctx == router.ctx
    assert router.ctx.router.ctx.router.ctx.router == router
    assert router

# Generated at 2022-06-18 06:00:53.323875
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.router import Router

    app = Sanic()
    router = Router(app)
    router.add("/", ["GET"], text, name="test")
    router.finalize()

# Generated at 2022-06-18 06:01:03.198196
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.static_routes == []
    assert router.ctx.static_routes_names == []
    assert router.ctx.static_routes_paths == []
    assert router.ctx.static_routes_hosts == []
    assert router.ctx.static_routes_versions == []
    assert router

# Generated at 2022-06-18 06:01:14.301904
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add(uri='/', methods=['GET'], handler=None)
    router.add(uri='/', methods=['GET'], handler=None, name='__file_uri__')
    router.add(uri='/', methods=['GET'], handler=None, name='__file_uri__')
    router.add(uri='/', methods=['GET'], handler=None, name='__file_uri__')
    router.add(uri='/', methods=['GET'], handler=None, name='__file_uri__')
    router.add(uri='/', methods=['GET'], handler=None, name='__file_uri__')
    router.add(uri='/', methods=['GET'], handler=None, name='__file_uri__')

# Generated at 2022-06-18 06:01:24.078127
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app is None
    assert router.ctx.router is router
    assert router.ctx.routes == []
    assert router.ctx.static_routes == []
    assert router.ctx.dynamic_routes == []
    assert router.ctx.regex_routes == []
    assert router.ctx.name_index == {}
    assert router.ctx.host_index == {}
    assert router

# Generated at 2022-06-18 06:01:33.477237
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:01:38.086690
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:01:41.522192
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:01:56.407402
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route(
        path="/",
        handler=None,
        methods=["GET"],
        name=None,
        strict=False,
        unquote=False,
    )
    route.labels = ["__file_uri__", "__file_uri__"]
    router.dynamic_routes = {"/": route}
    router.finalize()
    assert router.dynamic_routes == {"/": route}

    route.labels = ["__file_uri__", "__file_uri__", "__file_uri__"]
    router.dynamic_routes = {"/": route}
    with pytest.raises(SanicException):
        router.finalize()

# Generated at 2022-06-18 06:02:02.264934
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:02:10.342172
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == []
    assert router.routes_static == []

# Generated at 2022-06-18 06:02:17.763006
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS

    router = Router()
    router.add(uri='/', methods=HTTP_METHODS, handler=RouteHandler)
    try:
        router.finalize()
    except SanicException as e:
        assert str(e) == "Invalid route: /. Parameter names cannot use '__'."

# Generated at 2022-06-18 06:02:25.621205
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route(
        path='/',
        handler=None,
        methods=['GET'],
        name=None,
        strict=False,
        unquote=False,
        requirements=None,
        ctx=None,
        host=None,
        uri=None,
    )
    route.labels = ['__file_uri__', '__test__']
    router.dynamic_routes = {'/': route}
    router.finalize()

# Generated at 2022-06-18 06:02:28.888707
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:02:35.436452
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.models.route import RouteContext
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType

# Generated at 2022-06-18 06:02:48.105432
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == []
    assert router.routes_static == []

# Generated at 2022-06-18 06:02:52.993171
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:02:59.738364
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.routes == []
    assert router.ctx.static_routes == []
    assert router.ctx.dynamic_routes == []
    assert router.ctx.regex_routes == []
    assert router.ctx.name_index == {}
    assert router.ctx.host_index == {}
    assert router

# Generated at 2022-06-18 06:03:20.644184
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:03:24.378143
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:03:32.672050
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS
    from sanic.models.route import Route
    from sanic.models.route import RouteContext
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType

# Generated at 2022-06-18 06:03:38.221659
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:03:44.442589
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:03:48.735490
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:03:55.209244
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add(uri='/', methods=['GET'], handler=None)
    router.add(uri='/', methods=['GET'], handler=None, name='test')
    router.add(uri='/', methods=['GET'], handler=None, name='__test__')
    router.add(uri='/', methods=['GET'], handler=None, name='__file_uri__')
    router.finalize()

# Generated at 2022-06-18 06:03:58.425228
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.ctx.app == None


# Generated at 2022-06-18 06:04:04.822857
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == []
    assert router.routes_regex == []
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS


# Generated at 2022-06-18 06:04:16.092434
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.app import Sanic
    from sanic.router import Router
    app = Sanic('test_Router_finalize')
    router = Router(app)
    router.add(uri='/test', methods=['GET'], handler=None)
    router.finalize()

# Generated at 2022-06-18 06:04:56.642417
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.dynamic_routes == {}
    assert router.static_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:05:05.378699
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app is None
    assert router.ctx.router is router
    assert router.ctx.static_routes == []
    assert router.ctx.dynamic_routes == []
    assert router.ctx.regex_routes == []
    assert router.ctx.name_index == {}
    assert router.ctx.host_index == {}
    assert router.ctx.host_routes == {}
   

# Generated at 2022-06-18 06:05:09.159694
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:05:18.295219
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add("/test/<param>", ["GET"], lambda request: "OK")
    router.finalize()
    assert router.dynamic_routes["/test/<param>"].labels == ["param"]
    router.add("/test/<param>", ["GET"], lambda request: "OK")
    try:
        router.finalize()
    except SanicException as e:
        assert str(e) == "Invalid route: /test/<param>. Parameter names cannot use '__'."
    else:
        assert False, "SanicException not raised"

# Generated at 2022-06-18 06:05:23.529512
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route(path="/", handler=None, methods=["GET"])
    route.labels = ["__file_uri__", "__invalid_label__"]
    router.dynamic_routes = {"/": route}
    with pytest.raises(SanicException):
        router.finalize()

# Generated at 2022-06-18 06:05:28.871122
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == 'GET'
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:05:32.629131
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:05:36.725335
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:05:37.965456
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-18 06:05:42.094249
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.constants import HTTP_METHODS

    router = Router()
    router.add("/", HTTP_METHODS, lambda x: x)
    router.add("/", HTTP_METHODS, lambda x: x, name="name")
    router.add("/", HTTP_METHODS, lambda x: x, name="__name__")
    router.add("/", HTTP_METHODS, lambda x: x, name="__file_uri__")
    router.add("/", HTTP_METHODS, lambda x: x, name="__file_uri__")
    router.add("/", HTTP_METHODS, lambda x: x, name="__file_uri__")

# Generated at 2022-06-18 06:06:30.932635
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS
    from sanic.response import text
    from sanic.request import Request
    from sanic.exceptions import NotFound, MethodNotSupported
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS
    from sanic.response import text
    from sanic.request import Request
    from sanic.exceptions import NotFound, MethodNotSupported
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS

# Generated at 2022-06-18 06:06:36.714836
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router


# Generated at 2022-06-18 06:06:41.599966
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == {}


# Generated at 2022-06-18 06:06:48.214351
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.models.handler_types import RouteHandler
    from sanic.exceptions import SanicException
    from sanic.constants import HTTP_METHODS
    from sanic.models.route import Route
    router = Router()
    router.add("/", HTTP_METHODS, RouteHandler, name="test")
    try:
        router.finalize()
    except SanicException:
        assert True
    else:
        assert False


# Generated at 2022-06-18 06:06:51.349737
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == []
    assert router.routes_regex == []


# Generated at 2022-06-18 06:06:59.878873
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.static_routes == {}


# Generated at 2022-06-18 06:07:05.239747
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router


# Generated at 2022-06-18 06:07:14.484153
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.ctx == None
    assert router.name_index == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:07:25.322907
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.route import Route
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS
    from sanic.response import HTTPResponse
    from sanic.request import Request
    from sanic.app import Sanic
    from sanic.constants import HTTP_METHODS
    from sanic.exceptions import SanicException
    from sanic.models.route import Route
    from sanic.models.handler_types import RouteHandler
    from sanic.response import HTTPResponse
    from sanic.request import Request
    from sanic.app import Sanic
    from sanic.constants import HTTP_METHODS
    from sanic.exceptions import SanicException


# Generated at 2022-06-18 06:07:32.891346
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.host == None
    assert router.ctx.hosts == None
    assert router.ctx.ignore_body == False
    assert router.ctx.stream == False
    assert router.ctx.static == False
    assert router.ctx.version == None
    assert router.ctx.name == None
    assert router.ctx.strict == False