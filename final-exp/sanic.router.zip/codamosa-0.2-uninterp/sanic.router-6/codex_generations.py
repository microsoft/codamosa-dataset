

# Generated at 2022-06-18 05:57:46.784396
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add(uri='/', methods=['GET'], handler=None)
    router.add(uri='/test', methods=['GET'], handler=None)
    router.add(uri='/test/<name>', methods=['GET'], handler=None)
    router.add(uri='/test/<name>/<id>', methods=['GET'], handler=None)
    router.add(uri='/test/<name>/<id>/<__file_uri__>', methods=['GET'], handler=None)
    router.add(uri='/test/<name>/<id>/<__file_uri__>/<__file_uri__>', methods=['GET'], handler=None)
    router.finalize()
    assert router.routes_all

# Generated at 2022-06-18 05:57:58.592862
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.response import text
    from sanic.constants import HTTP_METHODS

    router = Router()
    router.add(uri='/', methods=HTTP_METHODS, handler=text('OK'))
    router.add(uri='/<__file_uri__>', methods=HTTP_METHODS, handler=text('OK'))
    router.add(uri='/<__file_uri__>/<__file_uri__>', methods=HTTP_METHODS, handler=text('OK'))

# Generated at 2022-06-18 05:58:02.688207
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == []
    assert router.routes_regex == []


# Generated at 2022-06-18 05:58:10.636585
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.route import Route
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.exceptions import NotFound
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import ContentTypeError
    from sanic.exceptions import ServerError
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import InvalidURL
    from sanic.exceptions import InvalidUsage

# Generated at 2022-06-18 05:58:23.716756
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.constants import HTTP_METHODS
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import NotFound
    from sanic_routing.exceptions import NoMethod
    from sanic_routing.exceptions import NotFound as RoutingNotFound
    from sanic_routing.route import Route as RoutingRoute
    from sanic_routing import BaseRouter
    from functools import lru_cache
    from typing import Any, Dict, Iterable, List, Optional, Tuple, Union
    from sanic_routing import BaseRouter  # type: ignore

# Generated at 2022-06-18 05:58:33.057529
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.response import text
    from sanic.exceptions import SanicException

    router = Router()
    router.add(uri='/', methods=['GET'], handler=text('OK'))
    router.add(uri='/<__file_uri__>', methods=['GET'], handler=text('OK'))
    router.add(uri='/<__file_uri__>', methods=['GET'], handler=text('OK'))
    router.add(uri='/<__file_uri__>', methods=['GET'], handler=text('OK'))
    router.add(uri='/<__file_uri__>', methods=['GET'], handler=text('OK'))

# Generated at 2022-06-18 05:58:44.623226
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add("/", ["GET"], lambda x: x)
    router.add("/<param>", ["GET"], lambda x: x)
    router.add("/<param1>/<param2>", ["GET"], lambda x: x)
    router.add("/<param1>/<param2>/<param3>", ["GET"], lambda x: x)
    router.add("/<param1>/<param2>/<param3>/<param4>", ["GET"], lambda x: x)
    router.add("/<param1>/<param2>/<param3>/<param4>/<param5>", ["GET"], lambda x: x)

# Generated at 2022-06-18 05:58:55.450309
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.ctx.app is None
    assert router.ctx.router is router
    assert router.ctx.handlers == {}
    assert router.ctx.hosts == {}
    assert router.ctx.host_routes == {}
    assert router.ctx.host_routes_regex == {}
    assert router.ctx.host_routes_static == {}
    assert router.ctx.host_routes_dynamic == {}

# Generated at 2022-06-18 05:59:06.765986
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.route import Route
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS
    from sanic.exceptions import MethodNotSupported
    from sanic_routing.exceptions import NoMethod
    from sanic_routing.exceptions import NotFound
    from sanic_routing.route import Route as RoutingRoute
    from sanic_routing.exceptions import NotFound as RoutingNotFound
    from sanic_routing.exceptions import NoMethod as RoutingNoMethod
    from sanic_routing import BaseRouter
    from sanic.constants import HTTP_METHODS
    from sanic.exceptions import MethodNotSupported, NotFound, SanicException
   

# Generated at 2022-06-18 05:59:08.979017
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-18 05:59:18.736864
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 05:59:22.962588
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 05:59:34.565014
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.route import Route
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS

    router = Router()
    router.add(uri="/", methods=HTTP_METHODS, handler=RouteHandler)
    router.add(uri="/__test__", methods=HTTP_METHODS, handler=RouteHandler)
    router.add(uri="/__test__/", methods=HTTP_METHODS, handler=RouteHandler)
    router.add(uri="/__test__/<name>", methods=HTTP_METHODS, handler=RouteHandler)
    router.add(uri="/__test__/<name>/", methods=HTTP_METHODS, handler=RouteHandler)

# Generated at 2022-06-18 05:59:45.501053
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.route import Route
    from sanic.models.handler_types import RouteHandler

    router = Router()
    router.add("/", ["GET"], RouteHandler(), name="index")
    router.add("/", ["GET"], RouteHandler(), name="index")
    router.add("/", ["GET"], RouteHandler(), name="index")
    router.add("/", ["GET"], RouteHandler(), name="index")
    router.add("/", ["GET"], RouteHandler(), name="index")
    router.add("/", ["GET"], RouteHandler(), name="index")
    router.add("/", ["GET"], RouteHandler(), name="index")
    router.add("/", ["GET"], RouteHandler(), name="index")
    router

# Generated at 2022-06-18 05:59:55.391008
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.app import Sanic
    from sanic.router import Router
    from sanic.exceptions import SanicException
    app = Sanic("test_Router_finalize")
    router = Router(app)
    router.add("/", ["GET"], lambda: None)
    router.add("/<__file_uri__>", ["GET"], lambda: None)
    try:
        router.add("/<__file_uri__>", ["GET"], lambda: None)
    except SanicException:
        pass
    else:
        assert False, "Should raise SanicException"
    router.add("/<__file_uri__>", ["GET"], lambda: None)

# Generated at 2022-06-18 06:00:03.902287
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router

# Generated at 2022-06-18 06:00:09.604570
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:00:19.915053
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.models.route import RouteContext
    from sanic.models.route import RouteMethods
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethods

# Generated at 2022-06-18 06:00:22.171842
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS


# Generated at 2022-06-18 06:00:33.732220
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:00:49.267461
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:00:57.183832
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:01:04.773400
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.response import text
    from sanic.exceptions import SanicException
    from sanic.constants import HTTP_METHODS
    from sanic.models.handler_types import RouteHandler

    router = Router()
    router.add("/", HTTP_METHODS, text("OK"))
    router.add("/<__file_uri__>", HTTP_METHODS, text("OK"))
    router.add("/<__file_uri__>/<__file_uri__>", HTTP_METHODS, text("OK"))
    router.add("/<__file_uri__>/<__file_uri__>/<__file_uri__>", HTTP_METHODS, text("OK"))

# Generated at 2022-06-18 06:01:10.750914
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route(
        path="/",
        handler=None,
        methods=["GET"],
        name=None,
        strict=False,
        unquote=False,
    )
    route.labels = ["__file_uri__", "__invalid__"]
    router.dynamic_routes = {"/": route}
    with pytest.raises(SanicException):
        router.finalize()

# Generated at 2022-06-18 06:01:21.616738
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == 'GET'
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.routes == []
    assert router.ctx.static_routes == []
    assert router.ctx.dynamic_routes == []
    assert router.ctx.regex_routes == []
    assert router.ctx.name_index == {}
    assert router.ctx.host_index == {}
    assert router

# Generated at 2022-06-18 06:01:28.998316
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add('/', ['GET'], 'handler')
    assert router.routes_all[0].path == '/'
    assert router.routes_all[0].methods == ['GET']
    assert router.routes_all[0].handler == 'handler'
    assert router.routes_all[0].ctx.ignore_body == False
    assert router.routes_all[0].ctx.stream == False
    assert router.routes_all[0].ctx.hosts == [None]
    assert router.routes_all[0].ctx.static == False
    assert router.routes_all[0].ctx.version == None
    assert router.routes_all[0].ctx.name == None

# Generated at 2022-06-18 06:01:38.991185
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.constants import HTTP_METHODS
    from sanic.exceptions import MethodNotSupported
    from sanic_routing.exceptions import NoMethod
    from sanic_routing.exceptions import NotFound as RoutingNotFound
    from sanic_routing.route import Route as RoutingRoute
    from sanic_routing import BaseRouter
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.constants import HTTP_METHODS
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import NotFound

# Generated at 2022-06-18 06:01:49.153868
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.hosts == None
    assert router.ctx.ignore_body == False
    assert router.ctx.stream == False
    assert router.ctx.static == False


# Generated at 2022-06-18 06:02:00.118595
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add("/", ["GET"], lambda x: x)
    router.add("/<param>", ["GET"], lambda x: x)
    router.add("/<param>", ["GET"], lambda x: x, name="test")
    router.add("/<param>", ["GET"], lambda x: x, name="__file_uri__")
    router.finalize()
    assert router.routes_all
    assert router.routes_static
    assert router.routes_dynamic
    assert router.routes_regex
    assert router.find_route_by_view_name("test")
    assert router.find_route_by_view_name("__file_uri__")
    assert router.find_route_by_view_name("test", name="test")


# Generated at 2022-06-18 06:02:04.023509
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:02:20.262376
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    router = Router()
    route = router.add("/", ["GET"], None)
    route.labels = ["__file_uri__", "__file_uri__"]
    try:
        router.finalize()
    except SanicException:
        assert True
    else:
        assert False

# Generated at 2022-06-18 06:02:25.171464
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.host == None
    assert router.ctx.hosts == None
    assert router.ctx.ignore_body == False
    assert router.ctx.stream == False
    assert router.ctx.static == False
    assert router.ctx.version == None
    assert router.ctx.name == None

# Generated at 2022-06-18 06:02:33.718643
# Unit test for method add of class Router
def test_Router_add():
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.views import CompositionView

    class MyView(HTTPMethodView):
        def get(self, request):
            return HTTPResponse(text="Hello, World!")

    class MyView2(HTTPMethodView):
        def get(self, request):
            return HTTPResponse(text="Hello, World!")

    class MyView3(HTTPMethodView):
        def get(self, request):
            return HTTPResponse(text="Hello, World!")


# Generated at 2022-06-18 06:02:42.862683
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route(
        path="/",
        handler=None,
        methods=["GET"],
        name=None,
        strict=False,
        unquote=False,
    )
    route.labels = ["__file_uri__", "__file_uri__"]
    router.dynamic_routes["/"] = route
    try:
        router.finalize()
    except SanicException as e:
        assert e.args[0] == "Invalid route: /. Parameter names cannot use '__'."
    else:
        assert False

# Generated at 2022-06-18 06:02:53.764199
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add(uri='/', methods=['GET'], handler=None)
    assert len(router.routes) == 1
    assert len(router.routes_all) == 1
    assert len(router.routes_static) == 1
    assert len(router.routes_dynamic) == 0
    assert len(router.routes_regex) == 0
    assert len(router.name_index) == 0
    assert len(router.path_index) == 1
    assert len(router.method_index) == 1
    assert len(router.method_index['GET']) == 1
    assert len(router.method_index['GET']['/']) == 1

# Generated at 2022-06-18 06:02:54.685963
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-18 06:02:57.667373
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:03:06.688805
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:03:16.919366
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router

# Generated at 2022-06-18 06:03:22.603856
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:03:38.070254
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:03:50.806035
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add(uri="/", methods=["GET"], handler=None)
    router.add(uri="/", methods=["GET"], handler=None, name="test")
    router.add(uri="/", methods=["GET"], handler=None, name="__test__")
    router.add(uri="/", methods=["GET"], handler=None, name="__file_uri__")
    router.add(uri="/", methods=["GET"], handler=None, name="__file_uri__")
    router.add(uri="/", methods=["GET"], handler=None, name="__file_uri__")
    router.add(uri="/", methods=["GET"], handler=None, name="__file_uri__")
    router.add(uri="/", methods=["GET"], handler=None, name="__file_uri__")

# Generated at 2022-06-18 06:03:55.920529
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:04:08.308345
# Unit test for method add of class Router
def test_Router_add():
    from sanic.response import text
    from sanic.router import Router
    router = Router()
    router.add("/", ["GET"], text("OK"))
    assert router.routes_all[0].uri == "/"
    assert router.routes_all[0].methods == ["GET"]
    assert router.routes_all[0].handler == text
    assert router.routes_all[0].ctx.ignore_body == False
    assert router.routes_all[0].ctx.stream == False
    assert router.routes_all[0].ctx.hosts == [None]
    assert router.routes_all[0].ctx.static == False
    assert router.routes_all[0].ctx.version == None

# Generated at 2022-06-18 06:04:14.581538
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:04:23.210389
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException

    router = Router()
    router.add("/test/<__file_uri__>", ["GET"], lambda r: r)
    router.add("/test/<__file_uri__>/<__file_uri__>", ["GET"], lambda r: r)
    router.add("/test/<__file_uri__>/<__file_uri__>/<__file_uri__>", ["GET"], lambda r: r)
    router.add("/test/<__file_uri__>/<__file_uri__>/<__file_uri__>/<__file_uri__>", ["GET"], lambda r: r)

# Generated at 2022-06-18 06:04:31.811843
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router


# Generated at 2022-06-18 06:04:35.086389
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == []
    assert router.routes_regex == []


# Generated at 2022-06-18 06:04:44.366385
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add("/", ["GET"], lambda: None)
    router.add("/", ["GET"], lambda: None, name="test")
    router.add("/", ["GET"], lambda: None, name="__file_uri__")
    router.finalize()
    assert router.routes_all
    assert router.routes_static
    assert router.routes_dynamic
    assert router.routes_regex
    assert router.find_route_by_view_name("test")
    assert router.find_route_by_view_name("__file_uri__")
    assert not router.find_route_by_view_name("__file_uri")
    assert not router.find_route_by_view_name("__file_uri__test")

# Generated at 2022-06-18 06:04:51.960772
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router


# Generated at 2022-06-18 06:05:07.910141
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:05:17.093265
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route(
        path="/",
        handler=None,
        methods=["GET"],
        name=None,
        strict=False,
        unquote=False,
    )
    route.labels = ["__file_uri__", "__file_uri__"]
    router.dynamic_routes["/"] = route
    try:
        router.finalize()
    except SanicException as e:
        assert str(e) == "Invalid route: /. Parameter names cannot use '__'."
    else:
        assert False, "Should raise SanicException"

# Generated at 2022-06-18 06:05:19.573448
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS


# Generated at 2022-06-18 06:05:29.789326
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.ctx == None
    assert router.name_index == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.routes == {}
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}

# Generated at 2022-06-18 06:05:35.751845
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:05:45.223112
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.models.handler_types import RouteHandler
    from sanic.exceptions import SanicException
    from sanic.constants import HTTP_METHODS
    from sanic.response import text

    router = Router()
    router.add("/", HTTP_METHODS, text("OK"))
    router.add("/<__file_uri__>", HTTP_METHODS, text("OK"))
    router.add("/<__file_uri__>/<__file_uri__>", HTTP_METHODS, text("OK"))
    router.add("/<__file_uri__>/<__file_uri__>/<__file_uri__>", HTTP_METHODS, text("OK"))

# Generated at 2022-06-18 06:05:52.776713
# Unit test for method add of class Router

# Generated at 2022-06-18 06:05:58.804926
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:06:01.666053
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == []
    assert router.routes_regex == []


# Generated at 2022-06-18 06:06:08.501459
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.models.route import RouteContext
    from sanic.models.route import RouteMethods
    from sanic.models.route import RouteMethods
    from sanic.models.route import RouteMethods
    from sanic.models.route import RouteMethods
    from sanic.models.route import RouteMethods
    from sanic.models.route import RouteMethods
    from sanic.models.route import RouteMethods
    from sanic.models.route import RouteMethods
    from sanic.models.route import RouteMethods
    from sanic.models.route import RouteMethods
    from sanic.models.route import RouteMethods

# Generated at 2022-06-18 06:06:40.699418
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.app import Sanic
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.constants import HTTP_METHODS
    from sanic.request import Request
    from sanic.response import HTTPResponse

    app = Sanic("test_Router_finalize")

    @app.route("/")
    async def handler(request):
        return HTTPResponse()

    router = Router(app)
    router.add(
        uri="/",
        methods=HTTP_METHODS,
        handler=handler,
        host=None,
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version=None,
        name=None,
        unquote=False,
        static=False,
    )

# Generated at 2022-06-18 06:06:46.038420
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route(
        "GET",
        "/",
        lambda: None,
        name="index",
        strict_slashes=False,
        unquote=False,
    )
    route.ctx.labels = ["__file_uri__", "__file_uri__"]
    router.dynamic_routes["/"] = route
    router.finalize()

# Generated at 2022-06-18 06:06:51.558001
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None


# Generated at 2022-06-18 06:07:02.056442
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app is None
    assert router.ctx.router is router
    assert router.ctx.hosts == []
    assert router.ctx.ignore_body is False
    assert router.ctx.stream is False
    assert router.ctx.static is False
    assert router.ctx.version is None
    assert router.ctx.name is None
    assert router.ctx.unquote is False

# Generated at 2022-06-18 06:07:06.198659
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route(
        path="/",
        handler=None,
        methods=["GET"],
        name=None,
        strict=False,
        unquote=False,
    )
    route.labels = ["__file_uri__", "__test__"]
    router.dynamic_routes = {
        "/": route
    }
    router.finalize()

# Generated at 2022-06-18 06:07:12.498019
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.models.handler_types import RouteHandler
    from sanic.exceptions import SanicException
    from sanic.constants import HTTP_METHODS

    router = Router()
    router.add("/", HTTP_METHODS, RouteHandler, None, False, False, False, None, None, False, False)
    try:
        router.finalize()
    except SanicException:
        assert True
    else:
        assert False

# Generated at 2022-06-18 06:07:18.098954
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add(uri='/', methods=['GET'], handler=None)
    assert router.routes_all
    assert router.routes_static
    assert router.routes_dynamic
    assert router.routes_regex
    assert router.find_route_by_view_name(view_name='/')


# Generated at 2022-06-18 06:07:26.568004
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []
    assert router.name_index == {}
    assert router.ctx == {}
    assert router.finalized == False
    assert router.static_routes == []
    assert router.dynamic_routes == {}
    assert router.regex_routes == []
    assert router.name_index == {}
    assert router.ctx == {}
    assert router.finalized == False
