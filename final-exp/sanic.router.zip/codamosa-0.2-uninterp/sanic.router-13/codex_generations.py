

# Generated at 2022-06-18 05:57:29.905356
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.constants import HTTP_METHODS
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.models.route_parameter import RouteParameter
    from sanic.models.route_parameter_type import RouteParameterType
    from sanic.models.route_parameter_type_converter import RouteParameterTypeConverter
    from sanic.models.route_parameter_type_validator import RouteParameterTypeValidator
    from sanic.models.route_parameter_type_validator_regex import RouteParameterTypeValidatorRegex
    from sanic.models.route_parameter_type_validator_type import RouteParameterTypeValidatorType

# Generated at 2022-06-18 05:57:30.997643
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-18 05:57:33.465861
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    with pytest.raises(SanicException):
        router.finalize()

# Generated at 2022-06-18 05:57:40.362469
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == {}
    assert router.ctx.app == None
    assert router.ctx.router == router


# Generated at 2022-06-18 05:57:48.214550
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.constants import HTTP_METHODS
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.models.route import RouteContext
    from sanic.models.route import RouteMeta
    from sanic.models.route import RouteRegistry
    from sanic.models.route import RouteRegistryContext
    from sanic.models.route import RouteRegistryMeta
    from sanic.models.route import RouteRegistryRegistry
    from sanic.models.route import RouteRegistryRegistryMeta
    from sanic.models.route import RouteRegistryRegistryRegistry
    from sanic.models.route import RouteRegistryRegistryRegistryMeta

# Generated at 2022-06-18 05:57:59.969659
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.router_args == ()
    assert router.ctx.router_kwargs == {}
    assert router.ctx.host == None
    assert router.ctx.hosts == [None]
    assert router.ctx.ignore_body == False
    assert router.ctx.stream == False
    assert router.ctx.static == False
    assert router.ctx.version == None
    assert router.ctx.name == None
    assert router.ctx.uri == None
    assert router.ctx.methods == None
    assert router.ctx.handler == None
    assert router.ctx.strict == False

# Generated at 2022-06-18 05:58:04.705969
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add(uri='/', methods=['GET'], handler=lambda: None)
    router.finalize()
    assert router.routes_all
    assert router.routes_static
    assert router.routes_dynamic
    assert router.routes_regex


# Generated at 2022-06-18 05:58:20.647193
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.static_routes == {}
    assert router.ctx.dynamic_routes == {}
    assert router.ctx.regex_routes == {}
    assert router.ctx.name_index == {}
    assert router.ctx.host_index == {}
    assert router.ctx.host_regex_index == {}


# Generated at 2022-06-18 05:58:31.082584
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []
    assert router.name_index == {}
    assert router.ctx == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.host == None
    assert router.ctx.hosts == [None]
    assert router.ctx.ignore_body == False
    assert router.ctx.stream == False
    assert router.ctx.static == False
    assert router.ctx.version == None
    assert router.ctx.name == None


# Generated at 2022-06-18 05:58:41.707306
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add("/", ["GET"], lambda: None)
    router.add("/<param>", ["GET"], lambda param: None)
    router.add("/<param:int>", ["GET"], lambda param: None)
    router.add("/<param:float>", ["GET"], lambda param: None)
    router.add("/<param:path>", ["GET"], lambda param: None)
    router.add("/<param:re:\\d+>", ["GET"], lambda param: None)
    router.add("/<param:re:[a-z]+>", ["GET"], lambda param: None)
    router.add("/<param:re:\\d+>/<param2:re:[a-z]+>", ["GET"], lambda param, param2: None)

# Generated at 2022-06-18 05:58:54.028566
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.routing import Route

    class MockRoute(Route):
        def __init__(self, labels):
            self.labels = labels

    router = Router()
    router.dynamic_routes = {
        "test": MockRoute(labels=["__file_uri__", "__test__"])
    }
    with pytest.raises(SanicException):
        router.finalize()

# Generated at 2022-06-18 05:58:57.685292
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add("/<name>", ["GET"], None)
    router.finalize()
    assert router.routes_dynamic
    assert router.routes_regex
    assert router.routes_static
    assert router.routes_all


# Generated at 2022-06-18 05:59:01.670531
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []


# Generated at 2022-06-18 05:59:06.166357
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add("/", ["GET"], lambda x: x)
    router.finalize()
    assert router.routes_all
    assert router.routes_static
    assert router.routes_dynamic
    assert router.routes_regex


# Generated at 2022-06-18 05:59:17.043141
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.constants import HTTP_METHODS
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.models.route_parameter import RouteParameter
    from sanic.models.route_parameter_type import RouteParameterType

    router = Router()
    router.add(uri='/', methods=HTTP_METHODS, handler=RouteHandler, host=None, strict_slashes=False, stream=False, ignore_body=False, version=None, name=None, unquote=False, static=False)
    router.finalize()

# Generated at 2022-06-18 05:59:25.009596
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.ctx == None
    assert router.name_index == {}
    assert router.host_index == {}
    assert router.host_regex_index == {}
    assert router.host_regex_index == {}
    assert router.host_regex_index == {}
    assert router.host_regex_index == {}
    assert router.host_regex_index == {}
    assert router.host_regex_index == {}
    assert router.host_regex

# Generated at 2022-06-18 05:59:36.529314
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS
    from sanic.response import text
    from sanic.request import Request
    from sanic.views import HTTPMethodView
    from sanic.blueprints import Blueprint
    from sanic.app import Sanic
    from sanic.exceptions import NotFound
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import ServerError
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import Unauthorized

# Generated at 2022-06-18 05:59:40.990115
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 05:59:46.197597
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 05:59:57.630764
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    router = Router()
    router.add("/", ["GET"], lambda: None)
    router.add("/<name>", ["GET"], lambda: None)
    router.add("/<__file_uri__>", ["GET"], lambda: None)
    router.add("/<__name>", ["GET"], lambda: None)
    router.finalize()
    assert router.routes_all == router.routes_dynamic
    assert router.routes_all == router.routes_regex
    assert router.routes_all != router.routes_static
    assert len(router.routes_all) == 3
    assert len(router.routes_static) == 0

# Generated at 2022-06-18 06:00:05.161529
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:00:16.404527
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.ctx.app is None
    assert router.ctx.router is router
    assert router.ctx.router_stack == []
    assert router.ctx.router_stack_size == 0
    assert router.ctx.router_stack_size_max == 0
    assert router.ctx.router_stack_size_max_default == 0
    assert router.ctx.router_stack_size_max_default == 0
    assert router.ctx.router_stack_size_max_default == 0
    assert router.ctx.router_stack_size_max_default == 0
    assert router.ctx.router_stack_size_max_default == 0
    assert router

# Generated at 2022-06-18 06:00:21.659905
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []
    assert router.name_index == {}
    assert router.ctx == {}


# Generated at 2022-06-18 06:00:33.778185
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.models.route import RouteContext
    from sanic.models.route import RouteDict
    from sanic.models.route import RouteDictRegex
    from sanic.models.route import RouteDictStatic
    from sanic.models.route import RouteDictTree
    from sanic.models.route import RouteDictTreeRegex
    from sanic.models.route import RouteDictTreeStatic
    from sanic.models.route import RouteDictTreeTree
    from sanic.models.route import RouteDictTreeTreeRegex
    from sanic.models.route import RouteDictTreeTreeStatic

# Generated at 2022-06-18 06:00:46.237290
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.ctx.app is None
    assert router.ctx.router is router
    assert router.ctx.host is None
    assert router.ctx.hosts is None
    assert router.ctx.ignore_body is False
    assert router.ctx.stream is False
    assert router.ctx.static is False
    assert router.ctx.version is None
    assert router.ctx.name is None
    assert router.ctx.strict_slashes is False
    assert router.ctx.unquote is False
    assert router.ctx.methods == ["GET"]
    assert router.ctx.requirements == {}
    assert router.ctx.defaults == {}

# Generated at 2022-06-18 06:00:55.513871
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.routes == []
    assert router.ctx.static_routes == []
    assert router.ctx.dynamic_routes == []
    assert router.ctx.regex_routes == []
    assert router.ctx.name_index == {}
    assert router.ctx.host_index == {}
    assert router

# Generated at 2022-06-18 06:01:03.944374
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.constants import HTTP_METHODS
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.models.route import RouteTable
    from sanic.models.route import RouteTableDynamic
    from sanic.models.route import RouteTableRegex
    from sanic.models.route import RouteTableStatic
    from sanic.models.route import RouteTableTree
    from sanic.models.route import RouteTableTreeNode
    from sanic.models.route import RouteTableTreeNodeDynamic
    from sanic.models.route import RouteTableTreeNodeRegex
    from sanic.models.route import RouteTableTreeNodeStatic
    from sanic.models.route import RouteTableTreeNodeStatic

# Generated at 2022-06-18 06:01:15.155139
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.static_routes == {}
    assert router.ctx.dynamic_routes == {}
    assert router.ctx.regex_routes == {}
    assert router.ctx.name_index == {}
    assert router.ctx.host_index == {}
    assert router.ctx.host_regex_index == {}


# Generated at 2022-06-18 06:01:24.698309
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.ctx.app is None
    assert router.ctx.router is router
    assert router.ctx.router_cache_size == ROUTER_CACHE_SIZE
    assert router.ctx.router_cache_size == router.get.cache_info().currsize
    assert router.ctx.router_cache_size == router.find_route_by_view_name.cache_info().currsize
    assert router.ctx.router_cache_size == router.get.cache_info().maxsize
    assert router.ctx.router_cache_size == router.find_route_by_view_name.cache_info().maxsize

# Generated at 2022-06-18 06:01:30.741730
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []
    assert router.name_index == {}
    assert router.ctx == {}


# Generated at 2022-06-18 06:01:44.688350
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:01:50.650461
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:01:58.698261
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.hosts == []


# Generated at 2022-06-18 06:02:07.896027
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.static_routes == []
    assert router.ctx.dynamic_routes == {}
    assert router.ctx.regex_routes == {}
    assert router.ctx.name_index == {}


# Generated at 2022-06-18 06:02:20.261170
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app is None
    assert router.ctx.router is router
    assert router.ctx.handlers == []
    assert router.ctx.middleware == []
    assert router.ctx.error_handlers == {}
    assert router.ctx.exception_handlers == {}
    assert router.ctx.websocket_handlers == {}
    assert router.ctx.middleware_stack == []

# Generated at 2022-06-18 06:02:23.513497
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:02:33.205273
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.static_routes == {}
    assert router.ctx.dynamic_routes == {}
    assert router.ctx.regex_routes == {}
    assert router.ctx.name_index == {}
    assert router.ctx.host_index == {}
    assert router.ctx.host

# Generated at 2022-06-18 06:02:45.806361
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.constants import HTTP_METHODS
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.models.route import RouteContext
    from sanic.models.route import RouteMethods
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethods

# Generated at 2022-06-18 06:02:55.923442
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.route import Route
    from sanic.models.handler_types import RouteHandler

    def handler():
        pass

    router = Router()
    route = Route(
        path="/",
        handler=handler,
        methods=["GET"],
        name="test",
        strict=False,
        unquote=False,
    )
    route.ctx.ignore_body = False
    route.ctx.stream = False
    route.ctx.hosts = [None]
    route.ctx.static = False
    route.labels = ["__test__"]
    router.dynamic_routes["/"] = route


# Generated at 2022-06-18 06:02:58.496960
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add("/test/<name>", ["GET"], lambda x: x)
    router.finalize()
    assert router.routes_dynamic["/test/<name>"]


# Generated at 2022-06-18 06:03:27.228798
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.static_routes == []
    assert router.ctx.static_routes_names == []
    assert router.ctx.static_routes_paths == []
    assert router.ctx.static_routes_hosts == []
    assert router.ctx.static_routes_versions == []
    assert router

# Generated at 2022-06-18 06:03:31.881136
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:03:37.295374
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add("/", ["GET"], lambda: None)
    router.add("/<name>", ["GET"], lambda: None)
    router.add("/<name>/<age>", ["GET"], lambda: None)
    router.add("/<name>/<age>/<sex>", ["GET"], lambda: None)
    router.finalize()

# Generated at 2022-06-18 06:03:48.883097
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []
    assert router.name_index == {}
    assert router.ctx == {}
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []
    assert router.name_index == {}
    assert router.ctx == {}


# Generated at 2022-06-18 06:03:54.681607
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:03:59.053711
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx is None


# Generated at 2022-06-18 06:04:11.465230
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.models.route_parameters import RouteParameters
    from sanic.models.route_parameters import RouteParameter
    from sanic.models.route_parameters import RouteParameterType
    from sanic.models.route_parameters import RouteParameterTypeInt
    from sanic.models.route_parameters import RouteParameterTypeString
    from sanic.models.route_parameters import RouteParameterTypeFloat
    from sanic.models.route_parameters import RouteParameterTypePath
    from sanic.models.route_parameters import RouteParameterTypeUUID
    from sanic.models.route_parameters import RouteParameterTypeBool

# Generated at 2022-06-18 06:04:21.229422
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.route_types import Route
    from sanic.models.handler_types import RouteHandler

    def handler():
        pass

    router = Router()
    router.add("/", ["GET"], handler, name="test")
    router.add("/<__file_uri__>", ["GET"], handler, name="test")
    router.add("/<__file_uri__>", ["GET"], handler, name="test")
    router.add("/<__file_uri__>", ["GET"], handler, name="test")
    router.add("/<__file_uri__>", ["GET"], handler, name="test")
    router.add("/<__file_uri__>", ["GET"], handler, name="test")

# Generated at 2022-06-18 06:04:31.171438
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route(
        path="/",
        methods=["GET"],
        handler=None,
        name=None,
        strict=False,
        unquote=False,
    )
    route.labels = ["__file_uri__", "__file_uri__"]
    router.dynamic_routes = {"/": route}
    router.finalize()

    route.labels = ["__file_uri__", "__file_uri__", "__file_uri__"]
    router.dynamic_routes = {"/": route}
    with pytest.raises(SanicException):
        router.finalize()

# Generated at 2022-06-18 06:04:40.592033
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:05:18.206294
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []


# Generated at 2022-06-18 06:05:22.050957
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []


# Generated at 2022-06-18 06:05:31.060509
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.models.route import RouteContext
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType

# Generated at 2022-06-18 06:05:33.452947
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS


# Generated at 2022-06-18 06:05:37.466659
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:05:46.616587
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app is None
    assert router.ctx.router is router
    assert router.ctx.static_routes == {}
    assert router.ctx.dynamic_routes == {}
    assert router.ctx.regex_routes == {}
    assert router.ctx.name_index == {}
    assert router.ctx.host_index == {}
    assert router.ctx.host_routes == {}
   

# Generated at 2022-06-18 06:05:50.013046
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:05:55.387994
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.ctx == {}
    assert router.ctx.app == None


# Generated at 2022-06-18 06:05:58.719001
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add("/test/<param>", ["GET"], lambda r: r)
    router.finalize()
    assert router.routes_dynamic["/test/<param>"].labels == ["param"]

# Generated at 2022-06-18 06:06:05.740979
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    from sanic.router import Router
    from sanic.exceptions import SanicException

    router = Router()
    route = router.add("/<__file_uri__>", ["GET"], lambda: None)
    router.finalize()
    assert route.labels == ("__file_uri__",)

    router = Router()
    route = router.add("/<__file_uri__>", ["GET"], lambda: None)
    with pytest.raises(SanicException) as excinfo:
        router.finalize()
    assert "Invalid route: /<__file_uri__> (GET). Parameter names cannot use '__'." in str(excinfo.value)

# Generated at 2022-06-18 06:06:51.876356
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.routes == []
    assert router.ctx.static_routes == []
    assert router.ctx.dynamic_routes == []
    assert router.ctx.regex_routes == []
    assert router.ctx.name_index == {}


# Generated at 2022-06-18 06:07:02.259461
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.static_routes == {}
    assert router.ctx.dynamic_routes == {}
    assert router.ctx.regex_routes == {}
    assert router.ctx.name_index == {}
    assert router.ctx.host_index == {}
    assert router.ctx.host

# Generated at 2022-06-18 06:07:06.504953
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == {}


# Generated at 2022-06-18 06:07:12.925499
# Unit test for method add of class Router
def test_Router_add():
    from sanic.app import Sanic
    app = Sanic("test_Router_add")
    router = Router(app)
    def handler(request):
        return "OK"
    router.add("/test", ["GET"], handler)
    assert router.routes_all[0].path == "/test"
    assert router.routes_all[0].methods == ["GET"]
    assert router.routes_all[0].handler == handler
