

# Generated at 2022-06-18 05:57:42.777531
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app is None
    assert router.ctx.router is router
    assert router.ctx.router_cache_size == ROUTER_CACHE_SIZE
    assert router.ctx.router_cache_size == router.get.cache_info().currsize


# Generated at 2022-06-18 05:57:48.515156
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 05:58:00.309846
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes == {}
    assert router.dynamic_routes == {}
    assert router.static_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.ctx.app is None
    assert router.ctx.router is router
    assert router.ctx.request is None
    assert router.ctx.response is None
    assert router.ctx.exception is None
    assert router.ctx.traceback is None
    assert router.ctx.host is None
    assert router.ctx.port is None
    assert router.ctx.protocol is None
    assert router.ctx.secure is None
    assert router.ctx.root_path is None
    assert router.ctx.prefix is None
    assert router.ctx.url_prefix

# Generated at 2022-06-18 05:58:10.631612
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.constants import HTTP_METHODS
    from sanic.response import text
    from sanic.exceptions import SanicException

    router = Router()
    router.add(
        uri="/", methods=HTTP_METHODS, handler=text("hello world"), strict_slashes=False
    )
    router.add(
        uri="/__file_uri__", methods=HTTP_METHODS, handler=text("hello world"), strict_slashes=False
    )
    try:
        router.add(
            uri="/__file_uri__", methods=HTTP_METHODS, handler=text("hello world"), strict_slashes=False
        )
    except SanicException:
        pass
    else:
        assert False, "Should raise SanicException"

# Generated at 2022-06-18 05:58:23.324792
# Unit test for method finalize of class Router
def test_Router_finalize():
    import pytest
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    router = Router()
    router.add("/", ["GET"], RouteHandler, name="test")
    router.finalize()
    assert router.find_route_by_view_name("test")
    router = Router()
    router.add("/", ["GET"], RouteHandler, name="__test")
    with pytest.raises(SanicException):
        router.finalize()
    router = Router()
    router.add("/", ["GET"], RouteHandler, name="__file_uri__")
    router.finalize()
    assert router.find_route_by_view_name("__file_uri__")

# Generated at 2022-06-18 05:58:31.889778
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.hosts == None
    assert router.ctx.ignore_body == False
    assert router.ctx.stream == False
    assert router.ctx.static == False
    assert router.ctx.version == None


# Generated at 2022-06-18 05:58:43.238175
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.models.handler_types import RouteHandler
    from sanic.exceptions import SanicException
    from sanic.constants import HTTP_METHODS
    from sanic.response import json
    from sanic.request import Request

    router = Router()
    router.add(
        uri='/',
        methods=HTTP_METHODS,
        handler=lambda request: json({})
    )
    router.finalize()
    assert router.routes_all
    assert router.routes_static
    assert router.routes_dynamic
    assert router.routes_regex
    assert router.get('/', 'GET', None)
    assert router.find_route_by_view_name('/')
    assert router.find_route_by_view

# Generated at 2022-06-18 05:58:50.413150
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []
    assert router.name_index == {}
    assert router.ctx == {}


# Generated at 2022-06-18 05:58:57.954737
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.ctx == {}
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.finalize() == None


# Generated at 2022-06-18 05:59:06.515490
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    router = Router()
    route = Route(uri='/', methods=['GET'], handler=None, name=None, strict=False, unquote=False, ctx=None)
    route.labels = ['__file_uri__', '__test__']
    router.dynamic_routes = {'/': route}
    try:
        router.finalize()
    except SanicException as e:
        assert str(e) == "Invalid route: /. Parameter names cannot use '__'."
    else:
        assert False

# Generated at 2022-06-18 05:59:14.235699
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add("/test/<param>", ["GET"], lambda x: x)
    router.finalize()


# Generated at 2022-06-18 05:59:23.158952
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.static_routes == {}
    assert router.ctx.dynamic_routes == {}
    assert router.ctx.regex_routes == {}
    assert router.ctx.name_index == {}
    assert router.ctx.host_index == {}
    assert router.ctx.host_regex_index == {}


# Generated at 2022-06-18 05:59:33.942931
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 05:59:39.993413
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 05:59:48.060084
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.constants import HTTP_METHODS
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import NotFound
    from sanic_routing.exceptions import NoMethod
    from sanic_routing.exceptions import NotFound as RoutingNotFound
    from sanic_routing.route import Route as RoutingRoute
    from sanic_routing import BaseRouter

    def handler(request):
        pass

    router = Router()
    router.add("/", HTTP_METHODS, handler)

# Generated at 2022-06-18 05:59:59.009123
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.routes == []
    assert router.ctx.static_routes == []
    assert router.ctx.dynamic_routes == []
    assert router.ctx.regex_routes == []
    assert router.ctx.name_index == {}
    assert router.ctx.host_index == {}
    assert router

# Generated at 2022-06-18 06:00:01.787373
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:00:12.678936
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.constants import HTTP_METHODS
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.models.route_param import RouteParam
    from sanic.models.route_param_type import RouteParamType
    from sanic.models.route_param_type_converter import RouteParamTypeConverter
    from sanic.models.route_param_type_regex import RouteParamTypeRegex
    from sanic.models.route_param_type_string import RouteParamTypeString
    from sanic.models.route_param_type_uuid import RouteParamTypeUUID
    from sanic.models.route_param_type_int import RouteParamTypeInt


# Generated at 2022-06-18 06:00:15.315681
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS


# Generated at 2022-06-18 06:00:24.078531
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.models.route import Route
    from sanic.exceptions import SanicException
    from sanic.constants import HTTP_METHODS
    from sanic.response import text
    from sanic.request import Request
    from sanic.server import HttpProtocol
    from sanic.app import Sanic
    from sanic.websocket import WebSocketProtocol
    from sanic.blueprints import Blueprint
    from sanic.exceptions import NotFound
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import ServerError
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import FileNotFound

# Generated at 2022-06-18 06:00:32.030121
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add("/test/<param>", ["GET"], lambda x: x)
    router.finalize()
    assert router.routes_dynamic["/test/<param>"].labels == ["param"]

# Generated at 2022-06-18 06:00:39.123293
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.host_index == {}
    assert router.ctx.host_regex_index == {}
    assert router.ctx.host_regex_index_reversed == {}
    assert router.ctx.host_regex_index_reversed == {}
    assert router.ctx.host_regex_index_reversed == {}
    assert router.ctx.host_regex_index_reversed == {}
    assert router.ctx.host_re

# Generated at 2022-06-18 06:00:45.100985
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:00:49.930548
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:00:58.844164
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.constants import HTTP_METHODS
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.models.route import RouteContext
    from sanic.models.route import RouteMethods
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethods

# Generated at 2022-06-18 06:01:01.510745
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:01:06.839165
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:01:13.408429
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:01:18.552336
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:01:27.411614
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.static_routes == {}
    assert router.ctx.dynamic_routes == {}
    assert router.ctx.regex_routes == {}
    assert router.ctx.name_index == {}
    assert router.ctx.host_index == {}
    assert router.ctx.host_regex_index == {}


# Generated at 2022-06-18 06:01:45.024080
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.hosts == []
    assert router.ctx.ignore_body == False
    assert router.ctx.stream == False
    assert router.ctx.static == False
    assert router.ctx.version == None
    assert router.ctx.name == None
    assert router.ctx.strict == False
    assert router.ctx.unquote == False
    assert router.ctx.requirements == {}
    assert router.ctx.defaults == {}
    assert router.ctx.host == None
    assert router.ctx.methods == []
    assert router.ctx.path == None
    assert router.ctx.handler == None
    assert router.ctx.labels == []
    assert router.ctx.parameters == {}

# Generated at 2022-06-18 06:01:56.667786
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.routes == []
    assert router.ctx.static_routes == []
    assert router.ctx.dynamic_routes == {}
    assert router.ctx.regex_routes == {}
    assert router.ctx.name_index == {}
    assert router.ctx.host

# Generated at 2022-06-18 06:02:02.474171
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app is None
    assert router.ctx.router is router


# Generated at 2022-06-18 06:02:03.882354
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-18 06:02:08.670085
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:02:21.042999
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.ctx == {}
    assert router.name_index == {}
    assert router.prefix == ""
    assert router.host == ""
    assert router.host_regex == ""
    assert router.host_regex_index == {}
    assert router.host_regex_index_reversed == {}
    assert router.host_regex_index_reversed_list == []
    assert router.host_regex_index_reversed_list_reversed == []
    assert router.host_regex_index_reversed_list_reversed_reversed == []

# Generated at 2022-06-18 06:02:31.478580
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.ctx == {}
    assert router.name_index == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.routes == {}
    assert router.name_index == {}
    assert router.ctx == {}
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.rout

# Generated at 2022-06-18 06:02:44.071212
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add("/", ["GET"], lambda x: x)
    assert len(router.routes_all) == 1
    assert len(router.routes_static) == 1
    assert len(router.routes_dynamic) == 0
    assert len(router.routes_regex) == 0
    assert router.routes_all[0].path == "/"
    assert router.routes_all[0].methods == ["GET"]

# Generated at 2022-06-18 06:02:54.699894
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS
    from sanic_routing.route import Route
    from sanic_routing.exceptions import NoMethod
    from sanic_routing.exceptions import NotFound as RoutingNotFound
    from sanic_routing import BaseRouter
    from functools import lru_cache
    from typing import Any, Dict, Iterable, List, Optional, Tuple, Union
    from sanic_routing import BaseRouter  # type: ignore
    from sanic_routing.exceptions import NoMethod  # type: ignore

# Generated at 2022-06-18 06:03:03.534929
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler

    def handler(request):
        pass

    router = Router()
    router.add(uri='/', methods=['GET'], handler=handler)
    router.add(uri='/<name>', methods=['GET'], handler=handler)
    router.add(uri='/<__name>', methods=['GET'], handler=handler)

    try:
        router.finalize()
    except SanicException as e:
        assert str(e) == "Invalid route: /<__name> (GET). Parameter names cannot use '__'."
    else:
        assert False

# Generated at 2022-06-18 06:03:15.367911
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:03:20.459070
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:03:30.231062
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.ctx.app is None
    assert router.ctx.router is router
    assert router.ctx.router_cache_size == ROUTER_CACHE_SIZE
    assert router.ctx.router_cache_size == router.get.cache_info().currsize
    assert router.ctx.router_cache_size == router.find_route_by_view_name.cache_info().currsize
    assert router.ctx.router_cache_size == router.get.cache_info().maxsize
    assert router.ctx.router_cache_size == router.find_route_by_view_name.cache_info().maxsize

# Generated at 2022-06-18 06:03:41.294295
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == {}
    assert router.routes_static == {}

# Generated at 2022-06-18 06:03:53.679412
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.routes == []
    assert router.ctx.static_routes == []
    assert router.ctx.dynamic_routes == []
    assert router.ctx.regex_routes == []
    assert router.ctx.name_index == {}
    assert router.ctx.host_index == {}
    assert router

# Generated at 2022-06-18 06:03:54.951492
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-18 06:04:00.213523
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    router = Router()
    route = router.add("/test/<__file_uri__>", ["GET"], None)
    try:
        router.finalize()
    except SanicException:
        assert True
    else:
        assert False
    route = router.add("/test/<__file_uri__>", ["GET"], None)
    try:
        router.finalize()
    except SanicException:
        assert False
    else:
        assert True

# Generated at 2022-06-18 06:04:04.428005
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:04:16.048364
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.static_routes == []
    assert router.ctx.static_routes_names == []
    assert router.ctx.static_routes_prefixes == []
    assert router.ctx.static_routes_regex == []
    assert router.ctx.static_routes_regex_names == []


# Generated at 2022-06-18 06:04:24.095356
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException

    router = Router()
    router.add(
        uri="/",
        methods=["GET"],
        handler=lambda request: "OK",
        name="index",
    )
    router.add(
        uri="/",
        methods=["GET"],
        handler=lambda request: "OK",
        name="__index__",
    )
    router.add(
        uri="/",
        methods=["GET"],
        handler=lambda request: "OK",
        name="__file_uri__",
    )
    router.add(
        uri="/",
        methods=["GET"],
        handler=lambda request: "OK",
        name="__file_uri__",
    )

# Generated at 2022-06-18 06:04:44.440469
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:04:48.563846
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:04:58.585887
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.static_routes == {}
    assert router.ctx.dynamic_routes == {}
    assert router.ctx.regex_routes == {}
    assert router.ctx.name_index == {}
    assert router.ctx.host_index == {}
    assert router.ctx.host_regex_index == {}


# Generated at 2022-06-18 06:05:02.918551
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []


# Generated at 2022-06-18 06:05:09.161330
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:05:14.726497
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:05:18.890295
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []


# Generated at 2022-06-18 06:05:29.239584
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == {}
    assert router.routes_static == {}

# Generated at 2022-06-18 06:05:40.540692
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.static_routes == {}
    assert router.ctx.dynamic_routes == {}
    assert router.ctx.regex_routes == {}
    assert router.ctx.name_index == {}
    assert router.ctx.host_index == {}
    assert router.ctx.host

# Generated at 2022-06-18 06:05:48.562661
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.name_index == {}
    assert router.ctx.path_index == {}
    assert router.ctx.path_regex_index == {}
    assert router.ctx.static_index == {}
    assert router.ctx.static_regex_index == {}
    assert router.ctx.static_routes == {}

# Generated at 2022-06-18 06:06:13.490974
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == []
    assert router.routes_regex == []


# Generated at 2022-06-18 06:06:24.506329
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.routes == []
    assert router.ctx.static_routes == []
    assert router.ctx.dynamic_routes == []
    assert router.ctx.regex_routes == []
    assert router.ctx.name_index == {}
    assert router.ctx.host

# Generated at 2022-06-18 06:06:32.312167
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == 'GET'
    assert router.ALLOWED_METHODS == ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS', 'HEAD']
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:06:37.098932
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:06:40.066684
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []


# Generated at 2022-06-18 06:06:49.839729
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app is None
    assert router.ctx.router is router
    assert router.ctx.routes == []
    assert router.ctx.static_routes == []
    assert router.ctx.dynamic_routes == []
    assert router.ctx.regex_routes == []
    assert router.ctx.name_index == {}
    assert router.ctx.host_index == {}
    assert router

# Generated at 2022-06-18 06:06:55.280947
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:07:04.591945
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.routes == []
    assert router.ctx.static_routes == []
    assert router.ctx.dynamic_routes == {}
    assert router.ctx.regex_routes == {}
    assert router.ctx.name_index == {}
    assert router.ctx.host

# Generated at 2022-06-18 06:07:08.724356
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:07:13.568305
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
