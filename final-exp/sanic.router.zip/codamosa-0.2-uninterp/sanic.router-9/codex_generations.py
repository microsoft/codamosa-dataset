

# Generated at 2022-06-18 05:57:54.945274
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.models.route_parameter import RouteParameter
    from sanic.models.route_parameter_type import RouteParameterType
    from sanic.models.route_parameter_type_converter import RouteParameterTypeConverter

    # test case 1
    router = Router()

# Generated at 2022-06-18 05:58:02.180708
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add("/test/<param>", ["GET"], lambda x: x)
    router.finalize()
    assert router.dynamic_routes["/test/<param>"].labels == ["param"]
    router.add("/test/<param>", ["GET"], lambda x: x)
    with pytest.raises(SanicException):
        router.finalize()


# Generated at 2022-06-18 05:58:05.449334
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 05:58:16.754494
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException

    router = Router()
    router.add("/test/<test>", ["GET"], None)
    router.add("/test/<__test>", ["GET"], None)
    try:
        router.finalize()
    except SanicException as e:
        assert str(e) == "Invalid route: /test/<__test> Parameter names cannot use '__'."
    else:
        assert False, "SanicException not raised"

# Generated at 2022-06-18 05:58:23.666138
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == {}


# Generated at 2022-06-18 05:58:25.472298
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-18 05:58:33.933127
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.route_types import Route
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS
    from sanic.exceptions import MethodNotSupported, NotFound, SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route_types import Route
    from sanic.router import Router
    from sanic.utils import sanic_endpoint_test
    from sanic.views import CompositionView
    from sanic.views import HTTPMethodView
    from sanic.views import StreamBuffer
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketState

# Generated at 2022-06-18 05:58:45.324963
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.constants import HTTP_METHODS
    from sanic.models.route import Route
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route

# Generated at 2022-06-18 05:58:55.282274
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 05:59:01.051186
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 05:59:16.146924
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app is None
    assert router.ctx.router is router
    assert router.ctx.static_routes == {}
    assert router.ctx.dynamic_routes == {}
    assert router.ctx.regex_routes == {}
    assert router.ctx.name_index == {}
    assert router.ctx.host_routes == {}
    assert router.ctx.host_regex_rout

# Generated at 2022-06-18 05:59:24.538185
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.static_routes == []
    assert router.ctx.static_routes_names == []
    assert router.ctx.static_routes_paths == []
    assert router.ctx.static_routes_hosts == []
    assert router.ctx.static_routes_versions == []
    assert router

# Generated at 2022-06-18 05:59:36.156522
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.static_dirs == []
    assert router.ctx.static_files == {}
    assert router.ctx.static_routes == []
    assert router.ctx.static_routes_names == []
    assert router.ctx.static_routes_paths == []
    assert router.ctx.static_routes

# Generated at 2022-06-18 05:59:44.824317
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.ctx == None
    assert router.name_index == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}


# Generated at 2022-06-18 05:59:56.271903
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.ctx.app is None
    assert router.ctx.router is router
    assert router.ctx.handlers == []
    assert router.ctx.middleware == []
    assert router.ctx.error_handlers == {}
    assert router.ctx.exception_handlers == {}
    assert router.ctx.websocket_handlers == {}
    assert router.ctx.middleware_stack == []
    assert router.ctx.middleware

# Generated at 2022-06-18 06:00:04.471793
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.ctx == None
    assert router.name_index == {}
    assert router.path_index == {}
    assert router.host_index == {}
    assert router.method_index == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.routes_all == {}
    assert router.routes_static == {}

# Generated at 2022-06-18 06:00:12.724586
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == {}
    assert router.finalized == False
    assert router.finalize == router._finalize


# Generated at 2022-06-18 06:00:17.696658
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:00:25.462232
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == []
    assert router.routes_static == []

# Generated at 2022-06-18 06:00:29.032846
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:00:46.852486
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:00:56.009557
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []
    assert router.name_index == {}
    assert router.ctx == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.routes == []
    assert router.ctx.static_routes == []
    assert router.ctx.dynamic_routes == {}
    assert router.ctx.regex_routes == []
    assert router.ctx.name_index == {}
    assert router.ctx.host

# Generated at 2022-06-18 06:00:58.695107
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS


# Generated at 2022-06-18 06:01:01.719568
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add("/", ["GET"], lambda x: x)
    assert router.routes_all
    assert router.routes_static
    assert not router.routes_dynamic
    assert not router.routes_regex


# Generated at 2022-06-18 06:01:08.284646
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:01:11.803811
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:01:18.014326
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:01:26.373228
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:01:36.756895
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.router_cache_size == ROUTER_CACHE_SIZE
    assert router.ctx.router_cache_size == ROUTER_CACHE_SIZE
    assert router.ctx.router_cache_size == ROUTER_CACHE_SIZE
    assert router.ctx.router_cache_size == ROUTER_CACHE_SIZE
    assert router.ctx.router_cache_size == ROUTER_CACHE_SIZE
    assert router.ctx.router_cache_size == ROUTER_CACHE_SIZE
    assert router.ctx

# Generated at 2022-06-18 06:01:47.827163
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.ctx.app is None
    assert router.ctx.router is router
    assert router.ctx.handlers == []
    assert router.ctx.hosts == []
    assert router.ctx.static == False
    assert router.ctx.stream == False
    assert router.ctx.ignore_body == False
    assert router.ctx.name is None
    assert router.ctx.version is None
    assert router.ctx.strict_slashes == False
    assert router.ctx.unquote == False
    assert router.ctx.requirements == {}
    assert router.ctx.labels == {}
    assert router.ctx.host_matching == False
    assert router.ctx.host_match

# Generated at 2022-06-18 06:02:15.435683
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:02:19.503724
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:02:22.658219
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:02:31.278631
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.router_cache_size == ROUTER_CACHE_SIZE
    assert router.ctx.router_cache == {}


# Generated at 2022-06-18 06:02:38.714716
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == {}


# Generated at 2022-06-18 06:02:50.562403
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.static_routes == {}
    assert router.ctx.dynamic_routes == {}
    assert router.ctx.regex_routes == {}
    assert router.ctx.name_index == {}
    assert router.ctx.host_index == {}
    assert router.ctx.host_regex_index == {}


# Generated at 2022-06-18 06:02:53.721132
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:03:00.127916
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.static_routes == {}
    assert router.ctx.dynamic_routes == {}
    assert router.ctx.regex_routes == {}
    assert router.ctx.name_index == {}
    assert router.ctx.host_index == {}
    assert router.ctx.host_regex_index == {}


# Generated at 2022-06-18 06:03:11.359050
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:03:18.842571
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:04:00.619156
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.ctx.app is None
    assert router.ctx.router is router
    assert router.ctx.router_name == "router"
    assert router.ctx.router_prefix == ""
    assert router.ctx.router_version is None
    assert router.ctx.router_hosts == [None]
    assert router.ctx.router_static is False
    assert router.ctx.router_strict_slashes is False
    assert router.ctx.router_stream is False
    assert router.ctx.router_ignore_body is False
    assert router.ctx.router_unquote is False
    assert router.ctx.router_name is None
    assert router.ctx.router_host is None
    assert router.ctx.router_methods == ["GET"]


# Generated at 2022-06-18 06:04:04.774278
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:04:16.408507
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.prefix == ""
    assert router.ctx.host == None
    assert router.ctx.hosts == None
    assert router.ctx.static == False
    assert router.ctx.stream == False
    assert router.ctx.ignore_body == False
    assert router.ctx.version == None

# Generated at 2022-06-18 06:04:24.299431
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.host == None
    assert router.ctx.hosts == [None]
    assert router.ctx.ignore_body == False
    assert router.ctx.stream == False
    assert router.ctx.static == False
    assert router.ctx.version == None
    assert router.ctx.name == None
    assert router.ctx.strict

# Generated at 2022-06-18 06:04:35.843298
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.handlers == []
    assert router.ctx.hosts == []
    assert router.ctx.static == False
    assert router.ctx.stream == False
    assert router.ctx.ignore_body == False
    assert router.ctx.version == None
    assert router.ctx.name == None
    assert router.ctx.strict == False
    assert router.ctx.unquote

# Generated at 2022-06-18 06:04:40.945124
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:04:45.373013
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:04:51.672615
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router


# Generated at 2022-06-18 06:05:00.549091
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app is None
    assert router.ctx.router is router
    assert router.ctx.handlers == []
    assert router.ctx.middleware == []
    assert router.ctx.error_handlers == {}
    assert router.ctx.exception_handlers == {}
    assert router.ctx.host_middleware == {}
    assert router.ctx.host_error_handlers == {}

# Generated at 2022-06-18 06:05:07.911023
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == 'GET'
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router


# Generated at 2022-06-18 06:06:30.432875
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-18 06:06:32.702991
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:06:41.025294
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:06:49.221910
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.ctx == {}
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:06:55.368412
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:07:04.628929
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.routes == []
    assert router.ctx.static_routes == []
    assert router.ctx.dynamic_routes == {}
    assert router.ctx.regex_routes == {}
    assert router.ctx.name_index == {}
    assert router.ctx.host

# Generated at 2022-06-18 06:07:09.403093
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:07:10.571224
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-18 06:07:21.265792
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router

# Generated at 2022-06-18 06:07:26.128107
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
