

# Generated at 2022-06-18 05:57:43.015861
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.models.handler_types import RouteHandler
    from sanic.exceptions import SanicException

    def handler(request):
        pass

    router = Router()
    router.add("/test/<__file_uri__>", ["GET"], handler)
    router.add("/test/<__file_uri__>", ["GET"], handler)
    router.add("/test/<__file_uri__>", ["GET"], handler)
    router.add("/test/<__file_uri__>", ["GET"], handler)
    router.add("/test/<__file_uri__>", ["GET"], handler)
    router.add("/test/<__file_uri__>", ["GET"], handler)

# Generated at 2022-06-18 05:57:49.057017
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route(
        path="/",
        handler=None,
        methods=["GET"],
        name=None,
        strict=False,
        unquote=False,
    )
    route.labels = ["__file_uri__", "__invalid_label__"]
    router.dynamic_routes = {
        "": route
    }
    with pytest.raises(SanicException):
        router.finalize()

# Generated at 2022-06-18 05:57:59.861069
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 05:58:10.728564
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.route import Route
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS

    router = Router()
    router.add(uri='/', methods=HTTP_METHODS, handler=lambda: None, host=None, strict_slashes=False, stream=False, ignore_body=False, version=None, name=None, unquote=False, static=False)
    router.add(uri='/', methods=HTTP_METHODS, handler=lambda: None, host=None, strict_slashes=False, stream=False, ignore_body=False, version=None, name=None, unquote=False, static=False)

# Generated at 2022-06-18 05:58:23.821185
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.models.route import RouteContext
    from sanic.models.route import RouteRegistry
    from sanic.models.route import RouteRegistryEntry
    from sanic.models.route import RouteRegistryEntryType
    from sanic.models.route import RouteRegistryType
    from sanic.models.route import RouteType
    from sanic.models.route import StaticRoute
    from sanic.models.route import StaticRouteType
    from sanic.models.route import DynamicRoute
    from sanic.models.route import DynamicRouteType
    from sanic.models.route import RegexRoute

# Generated at 2022-06-18 05:58:33.124006
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.routes == []
    assert router.ctx.static_routes == []
    assert router.ctx.dynamic_routes == {}
    assert router.ctx.regex_routes == {}
    assert router.ctx.name_index == {}
    assert router.ctx.host

# Generated at 2022-06-18 05:58:44.611391
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.app import Sanic
    from sanic.constants import HTTP_METHODS
    from sanic.exceptions import MethodNotSupported, NotFound
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.response import HTTPResponse
    from sanic.server import HttpProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.app import Sanic

# Generated at 2022-06-18 05:58:55.449553
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.ctx == None
    assert router.name_index == {}
    assert router.path_index == {}
    assert router.host_index == {}
    assert router.method_index == {}
    assert router.static_index == {}
    assert router.regex_index == {}
    assert router.dynamic_index == {}
    assert router.dynamic_routes == {}
    assert router.static_routes == {}
    assert router.regex_rout

# Generated at 2022-06-18 05:59:01.444793
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.models.route import RouteContext
    from sanic.models.route import RouteMethods
    from sanic.models.route import RouteParams
    from sanic.models.route import RouteRequirements
    from sanic.models.route import RouteRegex
    from sanic.models.route import RouteStatic
    from sanic.models.route import RouteUri
    from sanic.models.route import RouteUriTemplate
    from sanic.models.route import RouteUriTemplateRegex
    from sanic.models.route import RouteUriTemplateStatic
    from sanic.models.route import RouteUriTemplateVariable

# Generated at 2022-06-18 05:59:05.305200
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add("/test/<param>", ["GET"], lambda x: x)
    router.add("/test/<param>", ["GET"], lambda x: x)
    router.finalize()


# Generated at 2022-06-18 05:59:19.859274
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.host == None
    assert router.ctx.hosts == [None]
    assert router.ctx.static == False
    assert router.ctx.stream == False
    assert router.ctx.ignore_body == False
    assert router.ctx.version == None


# Generated at 2022-06-18 05:59:24.190099
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.app import Sanic
    from sanic.router import Router
    from sanic.exceptions import SanicException
    app = Sanic('test_Router_finalize')
    router = Router(app)
    route = router.add(uri='/', methods=['GET'], handler=None)
    route.labels.add('__test__')
    router.finalize()
    assert True


# Generated at 2022-06-18 05:59:35.824230
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.routes == []
    assert router.ctx.static_routes == []
    assert router.ctx.dynamic_routes == []
    assert router.ctx.regex_routes == []
    assert router.ctx.name_index == {}
    assert router.ctx.host_index == {}

# Generated at 2022-06-18 05:59:45.811871
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    router = Router()
    route = router.add("/", ["GET"], lambda: None)
    route.labels = ["__file_uri__"]
    router.finalize()
    assert router.routes_all == {route.name: route}
    assert router.routes_static == {route.name: route}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    route.labels = ["__file_uri__", "__test__"]
    try:
        router.finalize()
    except SanicException:
        assert True
    else:
        assert False


# Generated at 2022-06-18 05:59:53.794358
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add("/", ["GET"], lambda request: "OK")
    router.add("/<name>", ["GET"], lambda request, name: "OK")
    router.add("/<name>/<age>", ["GET"], lambda request, name, age: "OK")
    router.finalize()
    assert router.routes_all
    assert router.routes_static
    assert router.routes_dynamic
    assert router.routes_regex


# Generated at 2022-06-18 05:59:57.113435
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:00:04.872429
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.models.route import RouteContext
    from sanic.models.route import RouteMethods
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RoutePath
    from sanic.models.route import RoutePathContext
    from sanic.models.route import RoutePathRegex
    from sanic.models.route import RoutePathRegexContext
    from sanic.models.route import RoutePathRegexMatch
    from sanic.models.route import RoutePathRegexMatchContext
    from sanic.models.route import RoutePathRegexMatchGroup
    from sanic.models.route import RoutePathRegexMatch

# Generated at 2022-06-18 06:00:10.742856
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []


# Generated at 2022-06-18 06:00:12.331349
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-18 06:00:17.240890
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:00:33.281399
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.dynamic_routes == {}
    assert router.static_routes == []
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router

# Generated at 2022-06-18 06:00:39.684538
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS


# Generated at 2022-06-18 06:00:48.678532
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == []
    assert router.routes_regex == []
    assert router.name_index == {}
    assert router.ctx == {}
    assert router.static_routes == []
    assert router.dynamic_routes == {}
    assert router.regex_routes == []
    assert router.routes == []


# Generated at 2022-06-18 06:00:57.339738
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.routes == []
    assert router.ctx.static_routes == []
    assert router.ctx.dynamic_routes == []
    assert router.ctx.regex_routes == []
    assert router.ctx.name_index == {}
    assert router.ctx.host_index == {}
    assert router.ctx.host_method_index == {}

# Generated at 2022-06-18 06:01:04.854435
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView

    router = Router()
    router.add(
        uri="/",
        methods=HTTP_METHODS,
        handler=HTTPMethodView.as_view("test"),
    )
    router.add(
        uri="/test",
        methods=HTTP_METHODS,
        handler=HTTPMethodView.as_view("test"),
    )

# Generated at 2022-06-18 06:01:08.606022
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add(uri="/", methods=["GET"], handler=None)
    router.add(uri="/", methods=["GET"], handler=None, name="__file_uri__")
    router.finalize()

# Generated at 2022-06-18 06:01:14.255323
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:01:22.329924
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.ctx == {}
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:01:26.897423
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.dynamic_routes = {
        "test": Route(
            path="/test/<param>",
            handler=None,
            methods=["GET"],
            name="test",
            strict=False,
            unquote=False,
        )
    }
    try:
        router.finalize()
    except SanicException:
        assert True
    else:
        assert False

# Generated at 2022-06-18 06:01:32.138066
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:01:46.548736
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:01:57.666370
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.host == None
    assert router.ctx.host_regex == None
    assert router.ctx.host_regex_str == None
    assert router.ctx.host_regex_str_static == None
    assert router.ctx.host_regex_str_dynamic == None
    assert router.ctx.host_regex_str_regex == None

# Generated at 2022-06-18 06:02:04.211795
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:02:09.142331
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route(
        path="/",
        handler=None,
        methods=["GET"],
        name=None,
        strict=False,
        unquote=False,
    )
    route.labels = ["__file_uri__", "__file_uri__"]
    router.dynamic_routes["/"] = route
    try:
        router.finalize()
    except SanicException:
        assert True
    else:
        assert False

# Generated at 2022-06-18 06:02:15.792369
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:02:17.294009
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-18 06:02:28.619883
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.route import Route
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS
    from sanic.models.route import Route
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS
    from sanic.models.route import Route
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS
    from sanic.models.route import Route
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS
    from sanic.models.route import Route
    from sanic.models.handler_types import RouteHandler


# Generated at 2022-06-18 06:02:32.513786
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:02:36.995036
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []


# Generated at 2022-06-18 06:02:43.748204
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route(
        path="/",
        handler=None,
        methods=["GET"],
        name=None,
        strict=False,
        unquote=False,
    )
    route.labels = ["__file_uri__", "__test__"]
    router.dynamic_routes = {
        "/": route
    }
    router.finalize()

# Generated at 2022-06-18 06:03:11.452073
# Unit test for method add of class Router
def test_Router_add():
    from sanic.response import json
    from sanic.request import Request
    from sanic.app import Sanic
    from sanic.exceptions import MethodNotSupported, NotFound
    from sanic.constants import HTTP_METHODS
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.constants import HTTP_METHODS
    from sanic.models.route import Route
    from sanic.models.handler_types import RouteHandler
    from sanic.models.request import Request
    from sanic.models.response import HTTPResponse
    from sanic.models.response import HTTPResponse
    from sanic.models.response import HTTPResponse

# Generated at 2022-06-18 06:03:16.366569
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == {}


# Generated at 2022-06-18 06:03:22.499884
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:03:31.629427
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.routes == []
    assert router.ctx.static_routes == []
    assert router.ctx.dynamic_routes == []
    assert router.ctx.regex_routes == []
    assert router.ctx.name_index == {}
    assert router.ctx.host_index == {}
    assert router.ctx.method_index == {}
   

# Generated at 2022-06-18 06:03:43.276050
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.hosts == []
    assert router.ctx.host_index == {}
    assert router.ctx.host_regex_index == {}
    assert router.ctx.host_regex_index_sorted == []
    assert router.ctx.host_regex_index_sorted_reversed == []
    assert router.ctx

# Generated at 2022-06-18 06:03:55.252671
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException

    router = Router()
    router.dynamic_routes = {
        "test": Route(
            path="/test/<__file_uri__>",
            methods=["GET"],
            handler=None,
            name="test",
            strict=False,
            unquote=False,
        )
    }

    router.finalize()


# Generated at 2022-06-18 06:04:01.084019
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []
    assert router.name_index == {}
    assert router.ctx == None
    assert router.static_routes == []
    assert router.dynamic_routes == {}
    assert router.regex_routes == []
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:04:08.209308
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS

    router = Router()
    router.add(uri='/', methods=HTTP_METHODS, handler=RouteHandler)
    try:
        router.finalize()
    except SanicException as e:
        assert str(e) == "Invalid route: /. Parameter names cannot use '__'."

# Generated at 2022-06-18 06:04:14.537014
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.response import text
    router = Router()
    router.add("/", ["GET"], text("OK"))
    router.finalize()
    assert router.routes_all
    assert router.routes_static
    assert router.routes_dynamic
    assert router.routes_regex

# Generated at 2022-06-18 06:04:23.177500
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS
    from sanic.response import text
    from sanic.views import HTTPMethodView
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.exceptions import NotFound
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import ServerError
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import URLTimeout
    from sanic.exceptions import UnsupportedMediaType
    from sanic.exceptions import RequestEntityTooLarge

# Generated at 2022-06-18 06:05:00.769783
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app is None
    assert router.ctx.router is router
    assert router.ctx.hosts == [None]
    assert router.ctx.ignore_body is False
    assert router.ctx.stream is False
    assert router.ctx.static is False


# Generated at 2022-06-18 06:05:06.696600
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:05:18.118815
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.regex_routes == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.routes == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.regex_routes == {}
    assert router.static_routes == {}
    assert router.d

# Generated at 2022-06-18 06:05:28.509224
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.constants import HTTP_METHODS
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView
    from sanic.app import Sanic
    from sanic.blueprints import Blueprint
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketProtocol

# Generated at 2022-06-18 06:05:33.884041
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:05:38.344168
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}


# Generated at 2022-06-18 06:05:43.141380
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router


# Generated at 2022-06-18 06:05:50.509673
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.ctx.app == None
    assert router.ctx.router == None
    assert router.ctx.static_routes == {}
    assert router.ctx.dynamic_routes == {}
    assert router.ctx.regex_routes == {}
    assert router.ctx.name_index == {}
    assert router.ctx.static_routes_all == {}
    assert router

# Generated at 2022-06-18 06:06:01.143569
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add("/test", ["GET"], lambda: None)
    router.add("/test/<param>", ["GET"], lambda: None)
    router.add("/test/<param>/<param2>", ["GET"], lambda: None)
    router.add("/test/<param>/<param2>/<param3>", ["GET"], lambda: None)
    router.add("/test/<param>/<param2>/<param3>/<param4>", ["GET"], lambda: None)
    router.add("/test/<param>/<param2>/<param3>/<param4>/<param5>", ["GET"], lambda: None)

# Generated at 2022-06-18 06:06:09.268590
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:07:24.532615
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router


# Generated at 2022-06-18 06:07:32.157781
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app is None
    assert router.ctx.router is router
    assert router.ctx.router_stack == []
    assert router.ctx.route is None
    assert router.ctx.route_stack == []
    assert router.ctx.request is None
    assert router.ctx.request_stack == []
    assert router.ctx.response is None
    assert router.ctx.response_stack == []