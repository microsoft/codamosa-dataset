

# Generated at 2022-06-18 05:57:29.905491
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.routes == []
    assert router.ctx.static_routes == []
    assert router.ctx.dynamic_routes == []
    assert router.ctx.regex_routes == []
    assert router.ctx.name_index == {}
    assert router.ctx.host_index == {}
    assert router

# Generated at 2022-06-18 05:57:39.840894
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.static_dirs == []
    assert router.ctx.static_routes == []
    assert router.ctx.static_files == []
    assert router.ctx.static_routes_names == []
    assert router.ctx.static_files_names == []


# Generated at 2022-06-18 05:57:45.843858
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.ctx == None
    assert router.name_index == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}


# Generated at 2022-06-18 05:57:58.592858
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.response import text
    from sanic.exceptions import SanicException

    router = Router()
    router.add("/", ["GET"], text("OK"))
    router.add("/<__file_uri__>", ["GET"], text("OK"))
    router.add("/<__file_uri__>/<__file_uri__>", ["GET"], text("OK"))
    router.add("/<__file_uri__>/<__file_uri__>/<__file_uri__>", ["GET"], text("OK"))
    router.add("/<__file_uri__>/<__file_uri__>/<__file_uri__>/<__file_uri__>", ["GET"], text("OK"))

# Generated at 2022-06-18 05:58:08.463116
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.routes == []
    assert router.ctx.static_routes == []
    assert router.ctx.dynamic_routes == []
    assert router.ctx.regex_routes == []
    assert router.ctx.name_index == {}
    assert router.ctx.host

# Generated at 2022-06-18 05:58:21.563355
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.exceptions import SanicException
    from sanic.constants import HTTP_METHODS
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.models.route import RouteContext
    from sanic.models.route import RouteMeta
    from sanic.models.route import RouteMetaContext
    from sanic.models.route import RouteMetaContext
    from sanic.models.route import RouteMetaContext
    from sanic.models.route import RouteMetaContext
    from sanic.models.route import RouteMetaContext
    from sanic.models.route import RouteMetaContext
    from sanic.models.route import RouteMetaContext

# Generated at 2022-06-18 05:58:30.877978
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler

    def handler(request):
        pass

    # Test for invalid route
    try:
        router = Router()
        router.add('/test/<__file_uri__:path>', ['GET'], handler)
        router.finalize()
    except SanicException as e:
        assert str(e) == "Invalid route: /test/<__file_uri__:path>."

    # Test for valid route
    router = Router()
    router.add('/test/<__file_uri__:path>', ['GET'], handler)
    router.finalize()

# Generated at 2022-06-18 05:58:40.804619
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 05:58:50.176400
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    router = Router()
    route = router.add("/test/<param1>/<param2>", ["GET"], lambda x: x)
    route.labels = ["param1", "param2"]
    router.finalize()
    assert router.dynamic_routes.values() == [route]
    route.labels = ["param1", "__param2"]
    try:
        router.finalize()
        assert False
    except SanicException:
        assert True

# Generated at 2022-06-18 05:58:58.780517
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.constants import HTTP_METHODS
    from sanic.response import text
    from sanic.request import Request
    from sanic.websocket import WebSocketProtocol
    from sanic.server import HttpProtocol
    from sanic.app import Sanic
    from sanic.constants import HTTP_METHODS
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import NotFound
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.router import Router

# Generated at 2022-06-18 05:59:10.927473
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException

    router = Router()
    route = router.add("/", ["GET"], lambda x: x, name="test")
    route.labels.add("__file_uri__")
    router.finalize()

    route = router.add("/", ["GET"], lambda x: x, name="test")
    route.labels.add("__test__")
    try:
        router.finalize()
    except SanicException:
        pass
    else:
        assert False

# Generated at 2022-06-18 05:59:12.176962
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-18 05:59:17.497186
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []


# Generated at 2022-06-18 05:59:18.399479
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-18 05:59:25.692662
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS
    from sanic.response import text
    from sanic.request import Request
    from sanic.views import HTTPMethodView
    from sanic.websocket import WebSocketProtocol
    from sanic.blueprints import Blueprint
    from sanic.app import Sanic
    from sanic.response import HTTPResponse
    from sanic.constants import HTTP_METHODS
    from sanic.exceptions import NotFound, MethodNotSupported
    from sanic.request import RequestParameters
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView

# Generated at 2022-06-18 05:59:32.222648
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route(
        path="/test/<param>",
        handler=None,
        methods=["GET"],
        name=None,
        strict=False,
        unquote=False,
    )
    router.dynamic_routes["/test/<param>"] = route
    with pytest.raises(SanicException):
        router.finalize()

# Generated at 2022-06-18 05:59:38.546789
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}


# Generated at 2022-06-18 05:59:45.698085
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.constants import HTTP_METHODS
    from sanic.models.handler_types import RouteHandler

    router = Router()
    router.add(uri="/", methods=HTTP_METHODS, handler=RouteHandler)
    router.add(uri="/", methods=HTTP_METHODS, handler=RouteHandler, name="test")
    router.add(uri="/", methods=HTTP_METHODS, handler=RouteHandler, name="__test")
    router.add(uri="/", methods=HTTP_METHODS, handler=RouteHandler, name="__test__")
    router.add(uri="/", methods=HTTP_METHODS, handler=RouteHandler, name="__test__test")

# Generated at 2022-06-18 05:59:47.888936
# Unit test for method finalize of class Router
def test_Router_finalize():
    # Test for method finalize of class Router
    # This method is tested in test_router.py
    pass

# Generated at 2022-06-18 05:59:58.131839
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:00:17.937232
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.router_cache_size == ROUTER_CACHE_SIZE
    assert router.ctx.router_cache_size == ROUTER_CACHE_SIZE
    assert router.ctx.router_cache_size == ROUTER_CACHE_SIZE
    assert router.ctx.router_cache_size == ROUTER_CACHE_SIZE
   

# Generated at 2022-06-18 06:00:25.587440
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.route_model import Route

    class MockRoute(Route):
        def __init__(self, labels):
            self.labels = labels

    router = Router()

# Generated at 2022-06-18 06:00:35.990435
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.ctx == None
    assert router.name_index == {}
    assert router.regex_index == {}
    assert router.static_index == {}
    assert router.dynamic_index == {}
    assert router.dynamic_routes == {}
    assert router.static_routes == {}
    assert router.regex_routes == {}
    assert router.routes == {}
    assert router.routes_all == {}

# Generated at 2022-06-18 06:00:48.051950
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.route import Route
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS
    from sanic.response import text
    from sanic.request import Request
    from sanic.server import HttpProtocol
    from sanic.app import Sanic
    from sanic.websocket import WebSocketProtocol
    from sanic.exceptions import NotFound, MethodNotSupported
    from sanic.constants import HTTP_METHODS
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.models.route import Route
    from sanic.router import Router
    from sanic.exceptions import SanicException

# Generated at 2022-06-18 06:00:56.895985
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.route import Route
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS
    from sanic.models.route import Route
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS
    from sanic.models.route import Route
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS
    from sanic.models.route import Route
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS
    from sanic.models.route import Route
    from sanic.models.handler_types import RouteHandler


# Generated at 2022-06-18 06:01:01.803238
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.constants import HTTP_METHODS
    from sanic.models.handler_types import RouteHandler

    router = Router()
    router.add(uri='/', methods=HTTP_METHODS, handler=RouteHandler)
    try:
        router.finalize()
    except SanicException as e:
        print(e)


# Generated at 2022-06-18 06:01:13.213270
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.host == None
    assert router.ctx.hosts == [None]
    assert router.ctx.ignore_body == False
    assert router.ctx.stream == False
    assert router.ctx.static == False
    assert router.ctx.version == None
    assert router.ctx.name == None
    assert router.ctx.requirements == {}
    assert router.ctx.unquote == False
    assert router.ctx.strict == False
    assert router.ctx.methods == []
    assert router.ctx.path == ""
    assert router.ctx.handler == None

# Generated at 2022-06-18 06:01:18.375294
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:01:27.256946
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.routes == []
    assert router.ctx.static_routes == []
    assert router.ctx.dynamic_routes == []
    assert router.ctx.regex_routes == []
    assert router.ctx.name_index == {}
    assert router.ctx.host

# Generated at 2022-06-18 06:01:34.192038
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    router = Router()
    route = router.add("/", ["GET"], None)
    route.labels = ["__file_uri__", "__test__"]
    try:
        router.finalize()
    except SanicException as e:
        assert e.args[0] == "Invalid route: /. Parameter names cannot use '__'."
    else:
        assert False, "Should raise SanicException"

# Generated at 2022-06-18 06:02:03.079351
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS
    from sanic.response import text
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.exceptions import NotFound
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import RequestTimeout
    from sanic.exceptions import PayloadTooLarge
    from sanic.exceptions import InvalidUsage
    from sanic.exceptions import ServerError
    from sanic.exceptions import FileNotFound
    from sanic.exceptions import Unauthorized
    from sanic.exceptions import Forbidden
    from sanic.exceptions import NotAllowed

# Generated at 2022-06-18 06:02:10.577390
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.constants import HTTP_METHODS

    router = Router()
    router.add(uri='/', methods=HTTP_METHODS, handler=RouteHandler, strict_slashes=False, stream=False, ignore_body=False, version=None, name=None, unquote=False, static=False)
    try:
        router.finalize()
    except SanicException as e:
        assert str(e) == "Invalid route: <Route: / [GET, HEAD, POST, PUT, PATCH, DELETE, OPTIONS]>."


# Generated at 2022-06-18 06:02:17.456868
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:02:24.113903
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:02:29.946326
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == {}


# Generated at 2022-06-18 06:02:31.830473
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add("/<name>", ["GET"], lambda x: x)
    router.finalize()


# Generated at 2022-06-18 06:02:44.423025
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == {}
    assert router.routes_static == {}

# Generated at 2022-06-18 06:02:54.975257
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.ctx.app is None
    assert router.ctx.router is router
    assert router.ctx.handlers == []
    assert router.ctx.middlewares == []
    assert router.ctx.exception_handlers == {}
    assert router.ctx.error_handler is None
    assert router.ctx.request_middlewares == []
    assert router.ctx.response_middlewares == []
    assert router.ctx.default_exception_handler is None
    assert router.ctx.default_error_handler is None
    assert router.ctx.default_request_middleware is None
    assert router.ctx.default_response_middleware is None
    assert router.ctx.default

# Generated at 2022-06-18 06:02:59.320075
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == 'GET'
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:03:05.145509
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:03:52.047482
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.router_cache_size == ROUTER_CACHE_SIZE
    assert router.ctx.router_cache == {}
    assert router.ctx.router_cache_keys == []
    assert router.ctx.router_cache_index == 0
    assert router.ctx.router_

# Generated at 2022-06-18 06:04:00.303861
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.models.route import RouteContext
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType

# Generated at 2022-06-18 06:04:06.179227
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:04:15.305209
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add(
        uri='/',
        methods=['GET'],
        handler=None,
        host=None,
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version=None,
        name=None,
        unquote=False,
        static=False,
    )
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:04:23.682190
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import CompositionView
    from sanic.views import HTTPMethodView
    from sanic.views import Stream
    from sanic.views import Template
    from sanic.views import file

    router = Router()
    router.add(uri='/', methods=['GET'], handler=lambda x: x, host=None, strict_slashes=False, stream=False, ignore_body=False, version=None, name=None, unquote=False, static=False)

# Generated at 2022-06-18 06:04:27.015492
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []


# Generated at 2022-06-18 06:04:33.635137
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:04:38.866006
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:04:41.109515
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS


# Generated at 2022-06-18 06:04:45.259715
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add(uri="/", methods=["GET"], handler=None)
    router.add(uri="/", methods=["GET"], handler=None, name="test")
    router.add(uri="/", methods=["GET"], handler=None, name="__file_uri__")
    try:
        router.finalize()
    except SanicException:
        assert False
    else:
        assert True

# Generated at 2022-06-18 06:06:00.313471
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:06:07.648423
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.app import Sanic
    from sanic.router import Router
    from sanic.exceptions import SanicException

    app = Sanic("test_Router_finalize")
    router = Router(app)
    router.add("/test/<__file_uri__>", ["GET"], None)
    router.add("/test/<__file_uri__>", ["GET"], None)
    router.add("/test/<__file_uri__>", ["GET"], None)
    router.add("/test/<__file_uri__>", ["GET"], None)
    router.add("/test/<__file_uri__>", ["GET"], None)
    router.add("/test/<__file_uri__>", ["GET"], None)

# Generated at 2022-06-18 06:06:19.815488
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.static_routes == []
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router

# Generated at 2022-06-18 06:06:28.666918
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.routing import Route
    from sanic.routing import RouteContext
    from sanic.routing import RouteHandler
    from sanic.routing import RouteRegistry
    from sanic.routing import RouteTable
    from sanic.routing import RouteTableRegistry
    from sanic.routing import RouteTableTree
    from sanic.routing import RouteTree
    from sanic.routing import RouteTreeNode
    from sanic.routing import RouteTreeRegistry
    from sanic.routing import RouteTreeRoot
    from sanic.routing import RouteTreeRootNode
    from sanic.routing import RouteTreeRootRegistry
    from sanic.routing import RouteTreeRootRegistryNode

# Generated at 2022-06-18 06:06:36.715331
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.static_routes == {}
    assert router.ctx.dynamic_routes == {}
    assert router.ctx.regex_routes == {}
    assert router.ctx.name_index == {}
    assert router.ctx.host_index == {}
    assert router.ctx.host_regex_index == {}


# Generated at 2022-06-18 06:06:46.085565
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.models.route import RouteContext
    from sanic.models.route import RouteResult
    from sanic.models.route import RouteResultMatchInfo
    from sanic.models.route import RouteResultMatchInfoParameters
    from sanic.models.route import RouteResultMatchInfoParametersParameters
    from sanic.models.route import RouteResultMatchInfoParametersParametersParameters
    from sanic.models.route import RouteResultMatchInfoParametersParametersParametersParameters
    from sanic.models.route import RouteResultMatchInfoParametersParametersParametersParametersParameters
    from sanic.models.route import RouteResultMatchInfoParametersParametersParametersParametersParametersParameters

# Generated at 2022-06-18 06:06:50.923209
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []


# Generated at 2022-06-18 06:06:56.702445
# Unit test for method add of class Router
def test_Router_add():
    from sanic.app import Sanic
    app = Sanic("test_Router_add")
    router = Router(app)
    router.add("/", ["GET"], lambda request: "OK")
    assert router.routes_all
    assert router.routes_static
    assert not router.routes_dynamic
    assert not router.routes_regex


# Generated at 2022-06-18 06:07:05.696955
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route

    def handler():
        pass

    def handler_with_param(param):
        pass

    def handler_with_param_and_default(param=None):
        pass

    def handler_with_param_and_default_and_annotation(param: str = None):
        pass

    def handler_with_param_and_annotation(param: str):
        pass

    def handler_with_param_and_default_and_annotation_and_kwargs(
        param: str = None, **kwargs
    ):
        pass


# Generated at 2022-06-18 06:07:10.215476
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
