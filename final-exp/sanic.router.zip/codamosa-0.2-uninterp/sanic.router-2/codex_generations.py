

# Generated at 2022-06-18 05:57:26.777415
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add("/test/<param>", ["GET"], lambda x: x)
    router.finalize()
    assert router.dynamic_routes["/test/<param>"].labels == ["param"]


# Generated at 2022-06-18 05:57:31.239368
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 05:57:42.023467
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.route import Route
    from sanic.models.handler_types import RouteHandler

    router = Router()
    router.add("/", ["GET"], RouteHandler)
    router.add("/<name>", ["GET"], RouteHandler)
    router.add("/<__file_uri__>", ["GET"], RouteHandler)
    router.add("/<__file_uri__>/<name>", ["GET"], RouteHandler)
    router.add("/<__file_uri__>/<__file_uri__>", ["GET"], RouteHandler)
    router.add("/<__file_uri__>/<__file_uri__>/<name>", ["GET"], RouteHandler)

# Generated at 2022-06-18 05:57:47.544618
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 05:57:58.913376
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.models.route import RouteContext
    from sanic.models.route import RouteMethods
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethodsContext
    from sanic.models.route import RouteMethods

# Generated at 2022-06-18 05:58:08.106139
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.host == None
    assert router.ctx.hosts == [None]
    assert router.ctx.ignore_body == False
    assert router.ctx.stream == False
    assert router.ctx.static == False


# Generated at 2022-06-18 05:58:10.020171
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-18 05:58:22.794986
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.models.route_parameters import RouteParameters
    from sanic.models.route_parameters import RouteParameter
    from sanic.models.route_parameters import RouteParameterType
    from sanic.models.route_parameters import RouteParameterTypeEnum
    from sanic.models.route_parameters import RouteParameterTypeInt
    from sanic.models.route_parameters import RouteParameterTypeString
    from sanic.models.route_parameters import RouteParameterTypeUUID
    from sanic.models.route_parameters import RouteParameterTypeFloat
    from sanic.models.route_parameters import RouteParameterTypeBool
   

# Generated at 2022-06-18 05:58:32.641650
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.static_routes == router.routes_static
    assert router.ctx.dynamic_routes == router.routes_dynamic
    assert router.ctx.regex_routes == router.routes_regex
    assert router.ctx.name_index == {}
    assert router.ctx.path_index == {}
    assert router.ctx.path_regex_index == {}
    assert router.ctx.host_index == {}
    assert router.ctx.host

# Generated at 2022-06-18 05:58:36.342523
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 05:58:48.726146
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.app import Sanic
    from sanic.router import Router

    app = Sanic("test_Router_finalize")
    router = Router(app)
    router.add("/", ["GET"], lambda r: r)
    router.add("/<param>", ["GET"], lambda r, param: r)
    router.add("/<__file_uri__>", ["GET"], lambda r, __file_uri__: r)
    router.finalize()
    assert True

# Generated at 2022-06-18 05:58:58.153091
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add("/", ["GET"], lambda x: x)
    assert router.routes_all[0].path == "/"
    assert router.routes_all[0].methods == ["GET"]

# Generated at 2022-06-18 05:59:09.747494
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.handlers == []
    assert router.ctx.middleware == []
    assert router.ctx.error_handlers == {}
    assert router.ctx.exception_handlers == {}
    assert router.ctx.websocket_handlers == []
    assert router.ctx.websocket_error_handlers == {}

# Generated at 2022-06-18 05:59:19.703071
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.ctx.app is None
    assert router.ctx.router is router
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes

# Generated at 2022-06-18 05:59:23.823143
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 05:59:35.532385
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.views import HTTPMethodView

    class MyView(HTTPMethodView):
        def get(self, request: Request) -> HTTPResponse:
            return HTTPResponse(b"OK")

    router = Router()
    router.add(uri="/", methods=["GET"], handler=MyView.as_view())
    router.add(uri="/", methods=["GET"], handler=MyView.as_view(), name="test")

# Generated at 2022-06-18 05:59:44.944937
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.router_cache_size == ROUTER_CACHE_SIZE
    assert router.ctx.allowed_labels == ALLOWED_LABELS


# Generated at 2022-06-18 05:59:51.030015
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add("/", ["GET"], lambda x: x)
    router.add("/<name>", ["GET"], lambda x: x)
    router.add("/<name>/<id>", ["GET"], lambda x: x)
    router.add("/<name>/<id>/<__file_uri__>", ["GET"], lambda x: x)
    router.finalize()

# Generated at 2022-06-18 06:00:01.243748
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.router_cache_size == ROUTER_CACHE_SIZE
    assert router.ctx.router_cache_size == ROUTER_CACHE_SIZE
    assert router.ctx.router_cache_size == ROUTER_CACHE_SIZE
    assert router.ctx.router_cache_size == ROUTER_CACHE_SIZE
    assert router.ctx.router_cache_size == ROUTER_CACHE_SIZE
    assert router.ctx.router_cache_size == ROUTER_CACHE_SIZE
    assert router.ctx

# Generated at 2022-06-18 06:00:12.484901
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS
    from sanic.models.route import Route
    from sanic.models.route import RouteContext
    from sanic.models.route import RouteRegistry
    from sanic.models.route import RouteRegistryContext
    from sanic.models.route import RouteRegistryIndex
    from sanic.models.route import RouteRegistryIndexContext
    from sanic.models.route import RouteRegistryIndexItem
    from sanic.models.route import RouteRegistryIndexItemContext
    from sanic.models.route import RouteRegistryIndexItemContext
    from sanic.models.route import RouteRegistryIndexItemContext

# Generated at 2022-06-18 06:00:23.544976
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.models.route import RouteContext
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType
    from sanic.models.route import RouteType

# Generated at 2022-06-18 06:00:28.278038
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:00:33.731466
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:00:41.299557
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:00:47.620823
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    route = Route(
        path="/",
        methods=["GET"],
        handler=None,
        name=None,
        strict=False,
        unquote=False,
        requirements=None,
    )
    route.labels = ["__file_uri__", "__file_uri__"]
    router.dynamic_routes = {
        "": route
    }
    router.finalize()

# Generated at 2022-06-18 06:00:56.600118
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app is None
    assert router.ctx.router is router
    assert router.ctx.routes == []
    assert router.ctx.static_routes == []
    assert router.ctx.dynamic_routes == []
    assert router.ctx.regex_routes == []
    assert router.ctx.name_index == {}
    assert router.ctx.host_index == {}
    assert router

# Generated at 2022-06-18 06:01:04.479343
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.models.route import Route
    from sanic.exceptions import SanicException
    from sanic.constants import HTTP_METHODS
    from sanic.models.handler_types import RouteHandler

    router = Router()
    router.add(
        uri="/test",
        methods=HTTP_METHODS,
        handler=RouteHandler(),
        host=None,
        strict_slashes=False,
        stream=False,
        ignore_body=False,
        version=None,
        name=None,
        unquote=False,
        static=False,
    )
    router.finalize()

# Generated at 2022-06-18 06:01:15.676838
# Unit test for method finalize of class Router
def test_Router_finalize():
    router = Router()
    router.add(uri='/', methods=['GET'], handler=None)
    router.add(uri='/', methods=['POST'], handler=None)
    router.add(uri='/', methods=['PUT'], handler=None)
    router.add(uri='/', methods=['DELETE'], handler=None)
    router.add(uri='/', methods=['OPTIONS'], handler=None)
    router.add(uri='/', methods=['HEAD'], handler=None)
    router.add(uri='/', methods=['PATCH'], handler=None)
    router.add(uri='/', methods=['TRACE'], handler=None)
    router.add(uri='/', methods=['CONNECT'], handler=None)

# Generated at 2022-06-18 06:01:20.587269
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:01:23.029103
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS


# Generated at 2022-06-18 06:01:36.620343
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.constants import HTTP_METHODS
    from sanic.models.handler_types import RouteHandler

    router = Router()
    router.add(uri='/', methods=HTTP_METHODS, handler=RouteHandler)
    try:
        router.finalize()
    except SanicException:
        assert True
    else:
        assert False

# Generated at 2022-06-18 06:01:47.733467
# Unit test for constructor of class Router
def test_Router():
    assert Router.__name__ == 'Router'
    assert Router.__doc__ == '\n    The router implementation responsible for routing a :class:`Request` object\n    to the appropriate handler.\n    '
    assert Router.DEFAULT_METHOD == 'GET'
    assert Router.ALLOWED_METHODS == ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS', 'HEAD']
    assert Router.__module__ == 'sanic.router'
    assert Router.__qualname__ == 'Router'
    assert Router.__init__.__qualname__ == 'Router.__init__'
    assert Router.__init__.__module__ == 'sanic.router'

# Generated at 2022-06-18 06:01:58.497836
# Unit test for method add of class Router
def test_Router_add():
    from sanic.response import json
    from sanic.views import HTTPMethodView
    from sanic.request import Request
    from sanic.response import HTTPResponse
    from sanic.exceptions import NotFound
    from sanic.exceptions import MethodNotSupported
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.models.route import Route
    from sanic.models.route import Route
    from sanic.models.route import Route
    from sanic.models.route import Route
    from sanic.models.route import Route
    from sanic.models.route import Route
    from sanic.models.route import Route
    from sanic.models.route import Route
    from sanic.models.route import Route

# Generated at 2022-06-18 06:02:07.166412
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:02:13.466133
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == []


# Generated at 2022-06-18 06:02:19.503066
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:02:30.076735
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.ctx.app is None
    assert router.ctx.router is router
    assert router.ctx.static_routes is router.static_routes
    assert router.ctx.dynamic_routes is router.dynamic_routes
    assert router.ctx.regex_routes is router.regex_routes
    assert router.ctx.routes is router.routes
    assert router.ctx.name_index is router.name

# Generated at 2022-06-18 06:02:33.013912
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:02:41.676973
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router


# Generated at 2022-06-18 06:02:51.981327
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == None
    assert router.routes == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.ctx == None


# Generated at 2022-06-18 06:03:17.708469
# Unit test for method add of class Router
def test_Router_add():
    from sanic.app import Sanic
    from sanic.response import text
    from sanic.router import Router
    from sanic.server import HttpProtocol

    app = Sanic("test_Router_add")
    router = Router(app, HttpProtocol)

    @app.route("/")
    async def handler(request):
        return text("OK")

    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}

    router.add("/", ["GET"], handler)


# Generated at 2022-06-18 06:03:23.082027
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:03:26.965623
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == {}


# Generated at 2022-06-18 06:03:34.278461
# Unit test for method add of class Router
def test_Router_add():
    router = Router()
    router.add(uri="/test", methods=["GET"], handler=None)
    assert router.routes_all[0].path == "/test"
    assert router.routes_all[0].methods == ["GET"]
    assert router.routes_all[0].handler == None
    assert router.routes_all[0].ctx.hosts == [None]
    assert router.routes_all[0].ctx.ignore_body == False
    assert router.routes_all[0].ctx.stream == False
    assert router.routes_all[0].ctx.static == False
    assert router.routes_all[0].ctx.version == None
    assert router.routes_all[0].ctx.name == None
    assert router.routes_

# Generated at 2022-06-18 06:03:47.030338
# Unit test for method finalize of class Router
def test_Router_finalize():
    from sanic.router import Router
    from sanic.exceptions import SanicException
    from sanic.models.handler_types import RouteHandler
    from sanic.constants import HTTP_METHODS
    from sanic.response import text
    from sanic.request import Request
    from sanic.server import HttpProtocol
    from sanic.app import Sanic
    from sanic.websocket import WebSocketProtocol
    from sanic.websocket import WebSocketCommonProtocol
    from sanic.websocket import WebSocketConnectionClosed
    from sanic.websocket import WebSocketError
    from sanic.websocket import WebSocketProtocolError
    from sanic.websocket import WebSocketState
    from sanic.websocket import WebSocketStream
    from sanic.websocket import WebSocketWriter

# Generated at 2022-06-18 06:03:52.553218
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:04:00.590020
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.routes == []
    assert router.ctx.static_routes == []
    assert router.ctx.dynamic_routes == []
    assert router.ctx.regex_routes == []
    assert router.ctx.name_index == {}
    assert router.ctx.host

# Generated at 2022-06-18 06:04:10.440842
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes == {}
    assert router.static_routes == {}
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.name_index == {}
    assert router.ctx == {}
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:04:20.417552
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == 'GET'
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.hosts == None
    assert router.ctx.ignore_body == False
    assert router.ctx.stream == False
    assert router.ctx.static == False
    assert router.ctx.version == None
    assert router.ctx.name == None
    assert router.ctx.strict == False
    assert router.ctx.unquote == False
    assert router.ctx.requirements

# Generated at 2022-06-18 06:04:26.345061
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.handlers == []
    assert router.ctx.hosts == []
    assert router.ctx.static == False
    assert router.ctx.stream == False
    assert router.ctx.ignore_body == False
    assert router.ctx.version == None
    assert router.ctx.name == None

# Generated at 2022-06-18 06:05:09.425045
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:05:21.406261
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app == None
    assert router.ctx.router == router
    assert router.ctx.routes == []
    assert router.ctx.static_routes == []
    assert router.ctx.dynamic_routes == []
    assert router.ctx.regex_routes == []
    assert router.ctx.name_index == {}
    assert router.ctx.host_index == {}
    assert router

# Generated at 2022-06-18 06:05:27.247435
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == {}


# Generated at 2022-06-18 06:05:30.037641
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:05:39.104871
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == []
    assert router.routes_static == []
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.ctx == None
    assert router.name_index == {}
    assert router.routes == []
    assert router.static_routes == []
    assert router.dynamic_routes == {}
    assert router.regex_routes == {}
    assert router.resolver == None


# Generated at 2022-06-18 06:05:42.550737
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}


# Generated at 2022-06-18 06:05:46.035261
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.ctx == {}
    assert router.name_index == {}


# Generated at 2022-06-18 06:05:51.791795
# Unit test for method add of class Router
def test_Router_add():
    from sanic.response import text
    from sanic.router import Router
    router = Router()
    router.add("/", ["GET"], text("Hello World"))
    assert router.routes_all[0].uri == "/"
    assert router.routes_all[0].methods == ["GET"]
    assert router.routes_all[0].handler == text
    assert router.routes_all[0].ctx.hosts == [None]
    assert router.routes_all[0].ctx.ignore_body == False
    assert router.routes_all[0].ctx.stream == False
    assert router.routes_all[0].ctx.static == False


# Generated at 2022-06-18 06:06:02.582590
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx.app is None
    assert router.ctx.router is router
    assert router.ctx.router_cache_size == ROUTER_CACHE_SIZE
    assert router.ctx.router_cache_size == ROUTER_CACHE_SIZE
    assert router.ctx.router_cache_size == ROUTER_CACHE_SIZE
    assert router.ctx.router_cache_size == R

# Generated at 2022-06-18 06:06:09.062988
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.ctx.app is None
    assert router.ctx.router is router
    assert router.ctx.hosts == [None]
    assert router.ctx.ignore_body is False
    assert router.ctx.stream is False
    assert router.ctx.static is False
    assert router.ctx.version is None
    assert router.ctx.name is None
    assert router.ctx.strict_slashes is False
    assert router.ctx.unquote is False
    assert router.ctx.requirements == {}
    assert router.ctx.defaults == {}
    assert router.ctx.labels == {}
    assert router.ctx.host == None
    assert router.ctx.methods == []

# Generated at 2022-06-18 06:07:14.101636
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert isinstance(router, Router)


# Generated at 2022-06-18 06:07:20.400300
# Unit test for constructor of class Router
def test_Router():
    router = Router()
    assert router.DEFAULT_METHOD == "GET"
    assert router.ALLOWED_METHODS == HTTP_METHODS
    assert router.routes_all == {}
    assert router.routes_static == {}
    assert router.routes_dynamic == {}
    assert router.routes_regex == {}
    assert router.name_index == {}
    assert router.ctx == {}
