

# Generated at 2022-06-21 20:01:35.984284
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    entry = LedgerEntry(Ledger(Account("444444"), Balance("2018-12-31", Quantity(Decimal("100")))),
                        Posting("2018-12-31", Account("444444"), Amount(Decimal("100")), +1,
                                Journal("2018-12-31", "Description")),
                        Quantity(200))

# Generated at 2022-06-21 20:01:47.317397
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    aapl = Account('AAPL')
    jnl = JournalEntry('journal-1')
    jnl.post(aapl, 100, 'debit')
    jnl.post(aapl, 100, 'credit')
    led = Ledger(aapl, Balance(datetime.date(2019, 1, 1), Quantity(100)))
    entry = LedgerEntry(led, jnl.postings[0], Quantity(100))

# Generated at 2022-06-21 20:01:59.088455
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    from .accounts import AccountSystem
    from .journaling import Accountant, Cash

    ## Accounting system
    accounts = AccountSystem()

    ## Build ledger by accounting for all cash transfers and entries
    accountant = Accountant(accounts)

    ## Build ledger by accounting for all cash transfers and entries
    entry_1 = LedgerEntry(
        accounts.assets.cash, Posting(accounts.assets.cash, Quantity(Decimal(1000)), Cash(datetime.date(2020, 5, 30)))
    )
    entry_2 = LedgerEntry(
        accounts.assets.cash, Posting(accounts.assets.cash, Quantity(Decimal(1000)), Cash(datetime.date(2020, 5, 30)))
    )

# Generated at 2022-06-21 20:02:06.195890
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    ledger1 = Ledger(Account(1, 'A', 'Account A', '001'), Balance(1, 2))
    ledger2 = Ledger(Account(1, 'A', 'Account A', '001'), Balance(1, 2))
    assert ledger1 == ledger2
    assert not Ledger(Account(2, 'A', 'Account A', '001'), Balance(1, 2)) == ledger1
    assert not Ledger(Account(1, 'B', 'Account B', '002'), Balance(1, 2)) == ledger1
    assert not Ledger(Account(1, 'A', 'Account A', '001'), Balance(2, 2)) == ledger1
    assert not Ledger(Account(1, 'A', 'Account A', '001'), Balance(1, 3)) == ledger1



# Generated at 2022-06-21 20:02:13.241071
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    assert repr(Ledger(
        account=Account(
            code=1,
            name="name",
            type="type",
            nature="nature"
        ),
        initial=Balance(
            date=datetime.date.today(),
            value=Quantity(Decimal(1))
        ),
        entries=[]
    )) == "Ledger(account=Account(code=1, name='name', type='type', nature='nature'), initial=Balance(date=datetime.date(2020, 10, 27), value=Decimal('1')), entries=[])"


# Generated at 2022-06-21 20:02:23.909103
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    """
    Tests the constructor of class GeneralLedger.
    """
    print("test_GeneralLedger")

    ## Create a test period:
    test_period1 = DateRange(datetime.date(2020,1,1),datetime.date(2020, 1, 5))

    ## Create a test journal entry:
    posting1 = Posting(datetime.date(2020, 1, 1), "Test Description", "Test Account", "Test Account2", amount = Amount(100))
    posting2 = Posting(datetime.date(2020, 1, 2), "Test Description", "Test Account2", "Test Account3", amount = Amount(50))
    posting3 = Posting(datetime.date(2020, 1, 3), "Test Description", "Test Account4", "Test Account5", amount = Amount(200))

# Generated at 2022-06-21 20:02:27.850668
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    ledger_entry1 = LedgerEntry('ledger', 'posting', 'balance')
    ledger_entry2 = LedgerEntry('ledger', 'posting', 'balance')
    assert ledger_entry1 == ledger_entry2


# Generated at 2022-06-21 20:02:29.831444
# Unit test for constructor of class Ledger
def test_Ledger():
    a = Account(account_id=1, account_name="Cash", parent_account=None)
    b = Balance(date=None, value=None)
    c = Ledger(account=a, initial=b)
    assert c
    assert c.account == a
    assert c.initial == b

# Generated at 2022-06-21 20:02:40.924377
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    # create ledger1
    data1 = {
        'account':Account('1000','Cash','10','ASSET'),
        'initial':Balance(datetime.date(2020,1,1),100),
        }
    ledger1 = Ledger(**data1)
    
    # create ledger2 with the same data as ledger1
    ledger2 = Ledger(**data1)

    # compare the ledgers with method __eq__
    assert (ledger1==ledger2)

    # create ledger3 with different data from ledger1
    data3 = {
        'account':Account('2000','MyAccount','20','LIABILITY'),
        'initial':Balance(datetime.date(2020,1,4),200),
        }
    ledger3 = Ledger(**data3)
    
    # compare the ledgers with method __eq__


# Generated at 2022-06-21 20:02:49.162279
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    
    array = []
    array.append(Posting(None, None, None, None, None))
    array.append(Posting(None, None, None, None, None))
    array.append(Posting(None, None, None, None, None))
    x = Ledger(None, None, array)
    
    
    assert repr(x) == "Ledger(account=None, initial=None, entries=[LedgerEntry(ledger=Ledger(account=None, initial=None, entries=[]), posting=None, balance=0), LedgerEntry(ledger=Ledger(account=None, initial=None, entries=[]), posting=None, balance=0), LedgerEntry(ledger=Ledger(account=None, initial=None, entries=[]), posting=None, balance=0)])"

# Generated at 2022-06-21 20:03:06.664802
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    # Set the period
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 2, 1))
    # Should be raise an error if no general ledger created
    try:
        # Run the function build_general_ledger
        general_ledger = build_general_ledger(period, [], [])
    except Exception as e:
        # If error
        # Show the error message
        print(e.args)
    # Should be raise an error if balance is negative

# Generated at 2022-06-21 20:03:12.693799
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    """
    Tests the method __repr__ of the class Ledger
    """

    ## Create a ledger
    l = Ledger(0,0)

    ## Check the output of the method is correct
    assert str(l) == "Ledger(account=0, initial=0, entries=[])"


# Generated at 2022-06-21 20:03:14.527758
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    
    #Testing constructor of class GeneralLedgerProgram
    assert GeneralLedgerProgram

# Generated at 2022-06-21 20:03:26.964802
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    from .asset import Asset, AssetAccount
    from .commodity import Commodity
    from .accounts import AccountKind, AccountTree
    from typing import NamedTuple
    import datetime
    USD = Commodity(name='USD', numeric_code=840, default_fraction_digits=5,
                    display_precision=3, alternate_symbols=('US$',))
    account_tree = AccountTree(
        Account(kind=AccountKind.ASSET, commodity=USD, code=1000, name='Cash'),
        Account(kind=AccountKind.REVENUE, commodity=USD, code=4000, name='Revenue'),
    )

# Generated at 2022-06-21 20:03:27.604004
# Unit test for function build_general_ledger
def test_build_general_ledger():
    assert True

# Generated at 2022-06-21 20:03:34.651865
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    @dataclass
    class ReadInitialBalancesMock:
        def __call__(self, period: DateRange) -> dict:
            return dict()

    @dataclass
    class ReadJournalEntriesMock:
        def __call__(self, period: DateRange) -> Iterable[JournalEntry]:
            return list()

    assert compile_general_ledger_program(ReadInitialBalancesMock(), ReadJournalEntriesMock())

# Generated at 2022-06-21 20:03:35.550679
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    assert LedgerEntry.__eq__ is not None


# Generated at 2022-06-21 20:03:40.932128
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    assert repr(Ledger(account=Account('account1'), initial=Balance(datetime.datetime(2020, 6, 30), Quantity(Decimal(0))))) == \
           "Ledger(account=Account(name='account1', type=AccountType.ASSET), initial=Balance(date=datetime.date(2020, 6, 30), value=Quantity(0)))"


# Generated at 2022-06-21 20:03:48.305171
# Unit test for method add of class Ledger
def test_Ledger_add():
    account = Account(0, 'account')
    balance = Balance(datetime.date(1900, 1, 1), Quantity(0))
    posting = Posting(datetime.date(1900, 1, 1), True, Amount(5), account)
    posting.journal.postings.append(posting)
    ledger = Ledger(account, balance)
    ledger.add(posting)
    assert ledger.entries == [LedgerEntry(ledger, posting, 5)]


# Generated at 2022-06-21 20:03:57.314397
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    from .accounts import AccountType
    from .currency import Currency
    from .journaling import JournalEntry, Posting, PostingDirection, PostingType

    ## Initialize ledgers buffer as per available initial balances:

# Generated at 2022-06-21 20:04:10.608791
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    a=LedgerEntry(Ledger(Account(1),Balance(datetime.date.today(), Quantity(Decimal(0)))), Posting(JournalEntry(datetime.date.today(),'test',[]), datetime.date.today(), Account(1), Wallet(1), 1), Quantity(Decimal(10)))
    print(a.__repr__())
    print(a.__str__())
    

# Generated at 2022-06-21 20:04:19.755304
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    GL1 = GeneralLedger(DateRange(since=datetime.date(2019, 1, 1), until=datetime.date(2019, 12, 31)),
        {Account("000001"): Ledger(Account("000001"), Balance(datetime.date(2019, 1, 1), Quantity(0))),
        Account("000002"): Ledger(Account("000002"), Balance(datetime.date(2019, 1, 1), Quantity(0)))})


# Generated at 2022-06-21 20:04:31.307293
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .journaling import Journal, Direction, Transaction
    from .accounts import Account

    account = Account(name="account")
    date = datetime.date(2019, 5, 1)
    amount = Amount(Decimal(12.34))
    balance = Balance(end=date, value=Quantity(Decimal(5.67)))
    direction = Direction.DEBIT
    description = "test description"
    entry = LedgerEntry(ledger=None, posting=None, balance=balance)
    journal = Journal(date=date, description=description, postings=[])
    transaction = Transaction(date=date, description=description)
    transaction.postings.append(Posting(direction=direction, account=account, amount=amount))
    journal.postings.append(transaction.postings[0])

    assert entry.ledger == None

# Generated at 2022-06-21 20:04:42.580411
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    from .accounts import Account, AccountType
    from .ledgers import GeneralLedger, build_general_ledger
    from .journaling import AccountJournal, JournalEntry, Posting
    from datetime import date

    ## Test data
    account_type = AccountType.ASSET
    account = Account(number=1234, name="Test", type=account_type, subtype=None)
    period = DateRange(since=date.today(), until=date.today())
    initial_balance = None
    entries = []
    general_ledger = GeneralLedger(period=period, ledgers={account: GeneralLedger(period=period, ledgers={account: entries})})
    posting = Posting(account=account, quantity=None, amount=None, direction=None)

# Generated at 2022-06-21 20:04:48.379085
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Unit test for method __call__ of class GeneralLedgerProgram
    """
    ## Create a ledger program:
    ledger_program = compile_general_ledger_program(
        lambda period: dict(),
        lambda period: list(),
    )

    ## Execute the program and receive the general ledger:
    general_ledger = ledger_program(DateRange(datetime.date(2016, 1, 1), datetime.date(2016, 1, 31)))

    ## Ensure the general ledger is as expected:
    assert isinstance(general_ledger, GeneralLedger) is True

# Generated at 2022-06-21 20:04:49.673819
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    print("GeneralLedger.__init__()")

# Generated at 2022-06-21 20:04:54.592587
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    @dataclass
    class IB:
        def __call__(self, period: DateRange) -> InitialBalances:
            pass

    ib = IB()
    assert isinstance(ib, (Protocol, ReadInitialBalances)), "IB should be an instance of ReadInitialBalances"


# Generated at 2022-06-21 20:05:02.974016
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    period = DateRange(datetime.date(2017, 1, 1), datetime.date(2017, 1, 1))
    journal = [JournalEntry([], datetime.date(2017, 1, 1), "test")]
    initial = {"test": Balance(datetime.date(2017, 1, 1), Quantity(Decimal(0)))}
    return GeneralLedger(period, build_general_ledger(period, journal, initial)) == GeneralLedger(period, build_general_ledger(period, journal, initial))

# Generated at 2022-06-21 20:05:04.082605
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    assert ReadInitialBalances.__doc__ is not None

# Generated at 2022-06-21 20:05:04.799104
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    pass

# Generated at 2022-06-21 20:05:23.876465
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from .accounts import AccountType
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from .commons.numbers import Amount, Quantity


# Generated at 2022-06-21 20:05:31.734363
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    @dataclass
    class ReadJournalEntriesMock:
        def __call__(self):
            return None

    @dataclass
    class ReadInitialBalancesMock:
        def __call__(self):
            return None

    read_initial_balances: ReadInitialBalances = ReadInitialBalancesMock()
    read_journal_entries: ReadJournalEntries[int] = ReadJournalEntriesMock()

    compiled_program = compile_general_ledger_program(read_initial_balances, read_journal_entries)
    assert compiled_program(DateRange(None, None)) is not None

# Generated at 2022-06-21 20:05:42.907774
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():

    from dataclasses import dataclass, field, asdict
    from datetime import date, timedelta
    from decimal import Decimal
    from typing import Dict
    from ..commons.zeitgeist import DateRange
    from ..core.accounts import AccountType
    from ..core.general_ledger import GeneralLedger
    from ..core.journaling import ReadJournalEntries, JournalEntry, Posting, Direction, JournalType
    from ..core.journaling.journal_entries import JournalEntries
    from ..core.general_ledger.initial_balances import InitialBalances

    # Define an implementation of the algebra.
    class ReadInitialBalancesImpl:

        def __call__(self, period: DateRange) -> InitialBalances:
            rc = dict()
            rc[Account(AccountType.ASSET, "1000")] = Balance

# Generated at 2022-06-21 20:05:52.804023
# Unit test for constructor of class Ledger
def test_Ledger():
    import datetime
    from decimal import Decimal
    from ..commons.numbers import Amount, Currency, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journaling import Journal, JournalEntry, Posting
    from .generic import Balance
    from .business import Business
    from .sample_data import sample_business
    from .accounting import Period
    from .ledgers import Ledger, LedgerEntry

    # Instantiate a business for testing purposes:
    business: Business = sample_business()
    
    # Prepare a ledger:
    account: Account = Account(name='Cash', account_type=AccountType.ASSET)
    initial: Balance = Balance(period.since, Quantity(Decimal(10000)))
    ledger: Ledger = Ledger(account, initial)

    # Prepare

# Generated at 2022-06-21 20:06:05.306244
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..journaling.model import Posting, ReadJournalEntries, JournalEntry
    from ..ledgers.model import Ledger, GeneralLedger, build_general_ledger
    from ..commons.zeitgeist import DateRange
    from ..commons.numbers import Quantity, Amount


# Generated at 2022-06-21 20:06:15.742578
# Unit test for function build_general_ledger
def test_build_general_ledger():
    """
    Test the function "build_general_ledger" in module "ledgerize.journaling.ledgers"
    """

    # Define a date range
    from datetime import date
    from ..commons.zeitgeist import DateRange
    period = DateRange(since=date(2019, 1, 1), until=date(2019, 1, 2))

    # Import the class JournalEntry from module "ledgerize.journaling.journal"
    from ledgerize.journaling.journal import JournalEntry
    # Import the class Account from module "ledgerize.journaling.accounts"
    from ledgerize.journaling.accounts import Account
    # Import the class Amount from module "ledgerize.commons.numbers"
    from ledgerize.commons.numbers import Amount
    # Import the class Balance from module "ledgerize.

# Generated at 2022-06-21 20:06:25.771949
# Unit test for constructor of class Ledger

# Generated at 2022-06-21 20:06:30.700903
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    
    # Define a dictionary containing accounts and balances
    initial_balances = {'1': 100, '2': 200}
    # Assume the period is from 1 Jan 2018 to 31 Dec 2018
    period = DateRange.from_str('2018-01-01', '2018-12-31')
    
    # Create a ReadInitialBalances object
    r = ReadInitialBalances()
    # A function call of the ReadInitialBalances object
    r(period)


# Generated at 2022-06-21 20:06:34.320261
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    l1_1 = LedgerEntry(None, None, "")
    l1_2 = LedgerEntry(None, None, "")

    assert l1_1 == l1_2

# Generated at 2022-06-21 20:06:38.364454
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    """
    Unit test for constructor of class GeneralLedgerProgram
    """
    ReadInitialBalances = compile_general_ledger_program(
        read_initial_balances=ReadInitialBalances,
        read_journal_entries=ReadJournalEntries,
    )

# Generated at 2022-06-21 20:07:09.892806
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    from ..commons.util import same

    assert (
        GeneralLedger(
            DateRange("2019-01-01", "2019-12-31"),
            {
                Account("101", "Cash"): Ledger(
                    Account("101", "Cash"), Balance("2019-01-01", Quantity("100.00")),
                ),
            },
        )
        ==
        GeneralLedger(
            DateRange("2019-01-01", "2019-12-31"),
            {
                Account("101", "Cash"): Ledger(
                    Account("101", "Cash"), Balance("2019-01-01", Quantity("100.00")),
                ),
            },
        )
    )


# Generated at 2022-06-21 20:07:20.546556
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    """
    Equals test
    """
    generalLedger1 = GeneralLedger(DateRange(datetime.date(2019, 9, 1), datetime.date(2019, 12, 1)), {
        Account("100", "Cash"): Ledger(Account("100", "Cash"), Balance(datetime.date(2019, 9, 1), Quantity(Decimal(0)))),
        Account("200", "Receivables"): Ledger(Account("200", "Receivables"), Balance(datetime.date(2019, 9, 1), Quantity(Decimal(0))))
    })


# Generated at 2022-06-21 20:07:31.238309
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    a1 = Account(name='aa', number=1, terminal=True)
    a2 = Account(name='aa', number=2, terminal=True)
    a3 = Account(name='aa', number=3, terminal=True)
    a4 = Account(name='aa', number=4, terminal=True)
    a5 = Account(name='aa', number=5, terminal=True)
    a6 = Account(name='aa', number=6, terminal=True)
    a7 = Account(name='aa', number=7, terminal=True)
    a8 = Account(name='aa', number=8, terminal=True)

    le1 = LedgerEntry(a1, a2, Decimal(1))
    le2 = LedgerEntry(a1, a3, Decimal(2))
    le3 = LedgerEntry

# Generated at 2022-06-21 20:07:40.082166
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    """
    This function tests the __eq__ method of class GeneralLedger
    """
    generalLedger1 = GeneralLedger(DateRange(datetime.date(2020,1,1), datetime.date(2020,4,4)),{})
    generalLedger2 = GeneralLedger(DateRange(datetime.date(2020,1,1), datetime.date(2020,4,4)),{})

    if (generalLedger1 == generalLedger2):
        print("OK")
    else:
        print("ERROR")

#Unit test for method __ne__ of class GeneralLedger

# Generated at 2022-06-21 20:07:52.805001
# Unit test for method add of class Ledger
def test_Ledger_add():
    account_ls = [Account('000001',  'Cash',True),
                  Account('000002', 'Accounts Payable',True),
                  Account('000003', 'Accounts Receivable',True),
                  Account('000004', 'Inventory',True),
                  Account('000005', 'Prepaid Expenses',True),
                  Account('000006', 'Dividends',False),
                  Account('000007', 'Equipment',False),
                  Account('000008', 'Interest Payable',False),
                  Account('000009', 'Mortgage Payable',False),
                  Account('000010', 'Interest Revenue',False),
                  ]
    account_ls = {k:v for k,v in enumerate(account_ls)}
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

# Generated at 2022-06-21 20:07:57.069616
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    class ReadInitialBalances(Protocol):
        """
        Type of functions which reads and returns initial balances.
        """

        def __call__(self, period: DateRange) -> InitialBalances:
            pass

    def f(p:DateRange):
        pass

    f:ReadInitialBalances

# Generated at 2022-06-21 20:07:57.892261
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    assert "TODO"

# Generated at 2022-06-21 20:08:04.001273
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    from ..commons.zeitgeist import DateRange
    from ..journaling.algebra import ReadJournalEntries, build_read_journal_entries, read_journal_entries_from_csv
    from ..structural import ReadStructuralUnits
    from .accounts import Account, AccountNumber

    from .algebra import read_initial_balances_from_csv
    from .generic import Balance
    from .journaling import Posting, BalanceSheet, GeneralLedger
    from .structural import StructuralUnit

    ## This is the hard-coded data from the tutorial.
    ## Loads it from csv, but could come from any other domain model.

# Generated at 2022-06-21 20:08:05.618952
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    l1 = Ledger(a1, b1).add(p1)
    l2 = Ledger(a2, b2).add(p2)

    assert l1 == l1
    assert l1 != l2


# Generated at 2022-06-21 20:08:10.373948
# Unit test for method add of class Ledger
def test_Ledger_add():
    post = Posting(Account(0), Amount(1), True, datetime.date.today())
    led = Ledger(Account(0), Balance(datetime.date.today(), Quantity(Decimal(0))))
    led.add(post)
    assert led.entries[0].balance == Quantity(Decimal(1))

# Generated at 2022-06-21 20:09:04.900409
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    acc1 = Account("acc1", "acc1")
    acc2 = Account("acc2", "acc2")
    acc3 = Account("acc3", "acc3")
    acc4 = Account("acc4", "acc4")
    acc5 = Account("acc5", "acc5")


# Generated at 2022-06-21 20:09:07.029827
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    assert compile_general_ledger_program.__name__ == "compile_general_ledger_program"


# Generated at 2022-06-21 20:09:14.084174
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import AccountNames, AccountType, build_account_hierarchy
    from .journaling import Journal, PostingDirection


# Generated at 2022-06-21 20:09:23.873899
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    @dataclass
    class Mock:
        pass
    a = Account("a")
    account = Account("account")
    entries_1 = [LedgerEntry(Ledger(a,Balance(datetime.date(2020,5,5),5)),"abc",2)]
    entries_2 = [LedgerEntry(Ledger(a,Balance(datetime.date(2020,5,5),5)),"def",3)]

    ledger_1 = Ledger(account,Balance(datetime.date(2020,5,5),5),entries_1)
    ledger_2 = Ledger(account,Balance(datetime.date(2020,5,5),5),entries_1)
    ledger_3 = Ledger(account,Balance(datetime.date(2020,5,5),5),entries_2)
    ledger_4

# Generated at 2022-06-21 20:09:25.214100
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    pass


# Generated at 2022-06-21 20:09:34.035418
# Unit test for constructor of class Ledger
def test_Ledger():
    test_entries = [
    LedgerEntry(Ledger(Account('Test_account_1'), Balance(datetime.date(2019, 11, 1), Quantity(Decimal(100)))),
    Posting(datetime.date(2019, 11, 1), Account('Test_account_2'), Quantity(Decimal(50)), Direction.Debit),
    Quantity(Decimal(150))),

    LedgerEntry(Ledger(Account('Test_account_1'), Balance(datetime.date(2019, 11, 1), Quantity(Decimal(100)))),
    Posting(datetime.date(2019, 11, 1), Account('Test_account_2'), Quantity(Decimal(50)), Direction.Credit),
    Quantity(Decimal(-50)))]

    assert test_entries[0].date == datetime.date(2019, 11, 1)
   

# Generated at 2022-06-21 20:09:46.846422
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from . import (
        compilations,
        periods,
        read_debit_credit_journal_entries,
        read_initial_balances,
        transactions,
        transactions_with_initial_balances
    )

    ## Compile the program:
    general_ledger_program = compile_general_ledger_program(read_initial_balances, read_debit_credit_journal_entries)

    ## Define accounting period:
    period = periods.sample()

    ## Compile journal entries:
    journal_entries = compilations.compile_journal_entries(period, *transactions_with_initial_balances.sample())

    ## Manually build the general ledger:
    general_ledger = build_general_ledger(period, journal_entries, read_initial_balances(period))



# Generated at 2022-06-21 20:09:54.494471
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    ## Setup test data:
    period = DateRange(since=datetime.date(2020, 6, 1), until=datetime.date(2020, 6, 30))
    initial_balances = {
        Account(code="1110", name="Cash", is_terminal=True): Balance(period.since, Quantity(Decimal(100_000))),
        Account(code="1210", name="Accounts Receivable", is_terminal=True): Balance(period.since, Quantity(Decimal(45_000))),
        Account(code="2110", name="Accounts Payable", is_terminal=True): Balance(period.since, Quantity(Decimal(10_000))),
        Account(code="2190", name="Provisions", is_terminal=True): Balance(period.since, Quantity(Decimal(0)))
    }


# Generated at 2022-06-21 20:10:07.381827
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    # Arrange
    # Act
    # Assert
    assert Ledger(Account("1010", "Cash"), Balance(datetime.date(2020,1,1), Quantity(Decimal(0))), []).__eq__(Ledger(Account("1010", "Cash"), Balance(datetime.date(2020,1,1), Quantity(Decimal(0))), []))
    assert not Ledger(Account("1010", "Cash"), Balance(datetime.date(2020,1,1), Quantity(Decimal(0))), []).__eq__(Ledger(Account("1011", "Cash"), Balance(datetime.date(2020,1,1), Quantity(Decimal(0))), []))

# Generated at 2022-06-21 20:10:17.499911
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    from ..tests.algebras.bookkeeping_test import DR, CR
    from ..tests.algebras.bookkeeping_test import A, B, C, D
    from ..tests.algebras.bookkeeping_test import J01, J02, J03, J04, J05
    from ..tests.algebras.bookkeeping_test import IB_A, IB_B, IB_C, IB_D
    period = DateRange(
        datetime.date(2020, 1, 1),
        datetime.date(2020, 1, 31),
    )
    journal = (J01, J02, J03, J04, J05)
    initial = {A: IB_A, B: IB_B, C: IB_C, D: IB_D}