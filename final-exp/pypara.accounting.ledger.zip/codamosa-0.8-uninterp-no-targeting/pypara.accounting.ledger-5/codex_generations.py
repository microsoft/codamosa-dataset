

# Generated at 2022-06-21 20:01:20.744976
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    account = Account('101', 'Interest income', True)
    initial = Balance(datetime.date(2020,1,1), Quantity(1000))
    entries = []
    ledger1 = Ledger(account, initial)
    ledger1.entries = entries
    ledger2 = Ledger(account, initial)
    ledger2.entries = entries
    assert ledger1.__eq__(ledger2)

    # Unit test for method __eq__ of class LedgerEntry

# Generated at 2022-06-21 20:01:30.802167
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting, Transaction
    from ..commons.zeitgeist import Date, Months

    ## Define accounts:
    asset_account = Account("asset_account", AccountType.Asset)
    expense_account = Account("expense_account", AccountType.Expense)
    income_account = Account("income_account", AccountType.Income)

    ## Prepare journal entries to post:
    journal_entry1 = JournalEntry("journal_entry1", Date.today(), Transaction("transaction1", [
        Posting(asset_account, 10, True),
        Posting(expense_account, -10, False),
    ]))

# Generated at 2022-06-21 20:01:41.335699
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    import datetime
    from dataclasses import dataclass
    from decimal import Decimal
    from typing import Dict
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting


    ## Build test context.
    @dataclass
    class TestContext:
        #: Buffer of journal entries.
        buffer: Dict[DateRange, List[JournalEntry[None]]]

        #: Buffer of initial balances.
        initial: Dict[DateRange, Dict[Account, Balance]]


# Generated at 2022-06-21 20:01:42.280394
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # TODO: Implement
    pass


# Generated at 2022-06-21 20:01:54.347048
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():

    from ..commons.zeitgeist import end_of_month, today, today_as_date

    today = today()

    def read_initial_balances(period):

        assert period.until == end_of_month(today)

        return {
            Account("2-1000"): Balance(end_of_month(today), Quantity(Decimal("1234.45"))),
            Account("3-2000"): Balance(end_of_month(today), Quantity(Decimal("-234.56"))),
        }

    def read_journal_entries(period):

        assert period.since == today_as_date(today)
        assert period.until == today_as_date(today)

        from ..journaling.algebra import JournalEntryLike

        import dataclasses

        # noinspection PyTypeChecker

# Generated at 2022-06-21 20:02:04.005411
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from dataclasses import replace
    from decimal import Decimal

    from ..commons.zeitgeist import DateRange, parse_yyyymm

    from .accounts import Account, AccountType

    from .journaling import JournalEntry, Posting

    ## Initialize a journal entry:
    journal = JournalEntry(
        date=parse_yyyymm("2019.12"),
        description="Test journal entry",
        postings=[
            Posting(
                account=Account(type=AccountType.ASSET, code=1000),
                amount=Decimal(100),
                direction=Decimal(1),
            ),
            Posting(
                account=Account(type=AccountType.ASSET, code=2000),
                amount=Decimal(100),
                direction=Decimal(-1),
            ),
        ],
    )

    ## Initialize the accounting

# Generated at 2022-06-21 20:02:06.552944
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    ledger_entry = LedgerEntry(None, None, None)
    result = ledger_entry.__eq__(ledger_entry)
    assert result == True

# Generated at 2022-06-21 20:02:07.564886
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    #TODO
    pass



# Generated at 2022-06-21 20:02:16.117231
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    # Test for two ledger with same account name and same entries
    ledger1 = Ledger("Expenses:Utilities:Electricity", Balance("2019-10-01", Decimal(0) ),[
                    LedgerEntry("Expenses:Utilities:Electricity", Posting("2019-10-01", "Payment to the Utilities Company", "Expenses:Utilities:Electricity",Amount(Decimal(300) ) ), Decimal(300) ),
                    LedgerEntry("Expenses:Utilities:Electricity", Posting("2019-10-05", "Payment to the Utilities Company", "Expenses:Utilities:Electricity",Amount(Decimal(200) ) ), Decimal(500) )
                    ])

# Generated at 2022-06-21 20:02:19.453240
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    result = eval(repr(LedgerEntry(None,None,None)))
    assert result.ledger == None and result.posting == None and result.balance == None


# Generated at 2022-06-21 20:02:37.414993
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    """
    Test for method __eq__ of class LedgerEntry
    """
    from ..commons.zeitgeist import date_range
    from .accounts import Account, AccountGroup

    assert LedgerEntry(None, None, None) == LedgerEntry(None, None, None)


# Generated at 2022-06-21 20:02:44.961963
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    """
    Compile the General Ledger Program
    """
    account_ledger_program = compile_general_ledger_program(
        "read_initial_balances", "read_journal_entries"
    )
    assert (
        account_ledger_program ==
        '''def _program(period: DateRange) -> GeneralLedger[_T]:
                    initial_balances=read_initial_balances(period)
                    journal_entries=read_journal_entries(period)
                    return build_general_ledger(period,journal_entries,initial_balances)'''
    )



# Generated at 2022-06-21 20:02:58.026489
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    from ..commons.zeitgeist import now
    from .accounts import Account
    from .journaling import Journal, Posting, PostingDirection
    from .transactions import Transaction

    # Prepare data for test:
    journal = Journal("Test Journal", now(), [
        Posting(Transaction("Test Transaction", now(), "", None, Quantity(10), None, None, []), Account("liabilities:clearing"), PostingDirection.CREDIT),
        Posting(Transaction("Test Transaction", now(), "", None, Quantity(10), None, None, []), Account("assets:clearing"), PostingDirection.DEBIT)
    ])

    post1 = journal.postings[0]
    post2 = journal.postings[1]

    ledger1 = Ledger(post1.account, Balance("2018-09-01", Quantity(0)))


# Generated at 2022-06-21 20:03:09.338964
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    # First Ledger
    one_account = Account("one_account")
    one_initial = Balance(datetime.date(2019, 1, 1), Quantity(Decimal(0)))
    one_ledger = Ledger(one_account, one_initial)

    # Second Ledger
    one_ledger_1 = Ledger(one_account, one_initial)

    # Third Ledger
    one_initial_1 = Balance(datetime.date(2019, 1, 1), Quantity(Decimal(5)))
    one_ledger_2 = Ledger(one_account, one_initial_1)

    assert one_ledger == one_ledger_1
    assert one_ledger != one_ledger_2
    # test default field
    assert one_ledger.entries == []
    assert one_ledger.entries

# Generated at 2022-06-21 20:03:18.963324
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    period=DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 10))
    ledgers={
        0 : Ledger(0, balance=Balance(0,0)),
        1 : Ledger(1, balance=Balance(1,1)),
        2 : Ledger(2, balance=Balance(2,2)),
        3 : Ledger(3, balance=Balance(3,3))
    }
    gl=GeneralLedger(period=period,ledgers=ledgers)
    assert gl.period==period
    assert gl.ledgers==ledgers


# Generated at 2022-06-21 20:03:32.170200
# Unit test for function build_general_ledger
def test_build_general_ledger():
    """
    Unit test for function build_general_ledger.
    """
    ## Import:
    from datetime import date
    from decimal import Decimal
    from ..journaling.ledgers import Book

    ## Helper function:
    def add_journal(book: Book, date: datetime.date, descr: str, dr_acc: str, cr_acc: str, qty: Decimal):
        """
        Adds a journal entry.
        """

        ## Create a new journal:
        journal = book.create_journal(date, descr)

        ## Add debit and credit postings.
        journal.add_posting(dr_acc, qty)
        journal.add_posting(cr_acc, qty)

        return journal

    ## Create a book:
    book = Book.create()

    ## Add initial balance for

# Generated at 2022-06-21 20:03:40.409769
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    a = Account(account_number='0000', name='account_a')
    b = Account(account_number='0000', name='account_b')
    c = Account(account_number='0001', name='account_a')
    d = Account(account_number='0001', name='account_b')
    e = Account(account_number='0002', name='account_c')
    f = Account(account_number='0003', name='account_c')

    aa = Ledger(a, Quantity(Decimal(0)))
    bb = Ledger(b, Quantity(Decimal(0)))
    cc = Ledger(c, Quantity(Decimal(0)))
    dd = Ledger(d, Quantity(Decimal(0)))
    ee = Ledger(e, Quantity(Decimal(0)))

# Generated at 2022-06-21 20:03:47.166242
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    account = Account("12345678")
    initial = Balance(datetime.date(2017, 1, 1), Quantity(Decimal("-10.00")))
    l = Ledger(account, initial)
    assert repr(l) == "Ledger(account=Account('12345678'), initial=Balance(date=datetime.date(2017, 1, 1), value=-10))"


# Generated at 2022-06-21 20:03:53.915409
# Unit test for constructor of class Ledger
def test_Ledger():
    test1 = Ledger(Account(111), Balance(datetime.date(2020, 1, 1), 100))
    assert test1.account == Account(111)
    assert test1.initial == Balance(datetime.date(2020, 1, 1), 100)
    assert test1.entries == []
    assert test1._last_balance == 100
    assert not test1.add(Posting(datetime.date(2020, 1, 1), Account(111), Account(222), 100, True))


# Generated at 2022-06-21 20:04:05.257695
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    import unittest
    import datetime
    from typing import Any
    from decimal import Decimal
    from ..commons.galleries import EmptyIterator
    from ..commons.zeitgeist import DateRange
    from .commons import AccountType
    from .accounts import Account
    from .journaling import ReadJournalEntries, Posting, JournalEntryBalanced, Journal, JournalEntryDebit, JournalEntryCredit
    from .generic import Balance

    class MockReadInitialBalances:
        def __call__(self, period: DateRange) -> Dict[Account, Balance]:
            return {
                Account(AccountType.Assets, "CASH"): Balance(period.since, Decimal(1000)),
                Account(AccountType.Liabilities, "AP"): Balance(period.since, Decimal(500)),
            }


# Generated at 2022-06-21 20:04:21.127511
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    from .journaling import Journal, Posting
    from .accounts import Account
    from datetime import date
    from dataclasses import _MISSING_TYPE
    from .generic import Transaction

    # Define a sample transaction
    Transaction
    Transaction(date(2018, 1, 1), "Buy Stuff", [
        Posting(Account("Expenses/Stuff/Soda"), Amount(50), Transaction),
        Posting(Account("Assets/Cash"), -Amount(50), Transaction)
    ])

    # Define a sample ledger
    ledger = LedgerEntry(Ledger(Account("Expenses/Stuff/Soda"), Balance(date(2018, 1, 1), Amount(50))),
                         Posting(Account("Expenses/Stuff/Soda"), Amount(50), Transaction),
                         Amount(50))

# Generated at 2022-06-21 20:04:27.799314
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    @dataclass
    class Campaign:
        name: str

    @dataclass
    class Donation:
        amount: Amount
        campaign: Campaign

    @dataclass
    class Donor:
        name: str

    @dataclass
    class DonorDonation:
        donor: Donor
        donation: Donation


# Generated at 2022-06-21 20:04:39.492048
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ...commons.zeitgeist import now
    from ...journaling import build_journal_entry
    from ...accounting import (
        Account,
        AccountType,
        InMemoryChartOfAccounts,
        build_chart_of_accounts,
        prepopulate_chart_of_accounts,
    )

    chart = prepopulate_chart_of_accounts(InMemoryChartOfAccounts())
    chart.add(Account(AccountType.TERMINAL, "100100", "Cash"))
    chart.add(Account(AccountType.TERMINAL, "100200", "Accounts Receivable"))
    chart.add(Account(AccountType.TERMINAL, "100300", "Merchandise Inventory"))
    chart.add(Account(AccountType.TERMINAL, "100400", "Prepaid Expenses"))

# Generated at 2022-06-21 20:04:50.498823
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    """
    Unit test for method __eq__ of class GeneralLedger
    """
    
    from .transactors import UnitTestTransactor
    from .algebra import unit_test_transactor_algebra
    from ..services import ServiceProvider, UnitTestServiceProvider

    def _compile_general_ledger_program(business_day: datetime.date):
        """
        Returns a function which consumes opening and closing dates and produces a general ledger
        """
        ## Define a 'use case':
        def _use_case(read_journal_entries: ReadJournalEntries[_T]) -> GeneralLedgerProgram[_T]:
            """
            Consumes an implementation of the algebra and returns a program which consumes opening and closing dates
            and produces a general ledger.
            """

# Generated at 2022-06-21 20:05:03.117197
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from iso4217 import Alfa2
    from datetime import date
    from decimal import Decimal
    from typing import Dict

    test_currency, test_date_since, test_date_until = Alfa2('HRK'), date(2020,1,1), date(2020,1,2)
    test_initial_balances: InitialBalances = {'6501': Balance(test_date_since, Quantity(Decimal(100), test_currency))}

    ## Define the protocol:
    ReadInitialBalances.register('test', Dict)

    class ReadInitialBalancesTest:
        def __call__(self, period: DateRange) -> InitialBalances:
            assert period.since == test_date_since
            assert period.until == test_date_until
            return test_initial_balances

    ## Test the protocol:

# Generated at 2022-06-21 20:05:14.354350
# Unit test for method add of class Ledger
def test_Ledger_add():

    # Define initial balance
    initial_balance = Balance(datetime.date(2019, 1, 1), int(0))

    # Define account linked to the ledger
    Account_1 = Account(AccountName="Assets", AccountNumber="1", AccountType="Assets")

    # Create the ledger
    ledger_test = Ledger(Account_1, initial_balance)

    # Define journal entry
    Journal_1 = JournalEntry('2019-01-01', 'Journal 1')

    # Define posting and add it to the journal entry
    posting = Posting(Account_1, (Account_1), Journal_1, 'Debit', Amount(int(10)))
    Journal_1.add_posting(posting)

    # Add the posting to the ledger
    entry = ledger_test.add(Journal_1.postings[0])



# Generated at 2022-06-21 20:05:19.798430
# Unit test for constructor of class Ledger
def test_Ledger():
    account = Account(code='01',name='Assets')
    initial = Balance(datetime.date(2020, 1, 1),Quantity(Decimal(15000)))
    entries = List[LedgerEntry]
    ledger = Ledger(account = account,initial = initial)

    assert ledger.account.code == '01'
    assert ledger.initial == initial
    assert ledger.entries == entries


# Generated at 2022-06-21 20:05:26.549013
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..cybernetics import Closure
    from ..finance.accounts import Account
    from ..finance.banking import BankAccount
    from ..finance.payments import CashAccount
    from ..finance.taxes import PayableAccount, ReceivableAccount
    from ..finance.transactions import Transaction


# Generated at 2022-06-21 20:05:33.727889
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    """
    Tests __eq__ method of class GeneralLedger
    """
    a = Account(1, Account.Type.ASSET, "A")
    b = Account(2, Account.Type.EXPENSE, "B")
    date1 = datetime.date(2020, 1, 1)
    date2 = datetime.date(2020, 1, 2)
    date3 = datetime.date(2020, 2, 1)
    date4 = datetime.date(2020, 2, 2)
    date5 = datetime.date(2020, 2, 3)

    period1 = DateRange(date1, date4)
    period2 = DateRange(date2, date5)

    balance1 = Balance(date1, Quantity(0))
    balance2 = Balance(date1, Quantity(1))

# Generated at 2022-06-21 20:05:41.716670
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    class ReadInitialBalancesImpl:
        def __init__(self, data: InitialBalances):
            self.data = data

        def __call__(self, period: DateRange) -> InitialBalances:
            return self.data

    # Test code goes here
    robust = ReadInitialBalancesImpl({Account("100", "test"): Balance(datetime.date(2019, 8, 1), Quantity(Decimal(100))), Account("200", "test"): Balance(datetime.date(2019, 8, 1), Quantity(Decimal(200)))})


# Generated at 2022-06-21 20:05:49.129416
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    pass

# Generated at 2022-06-21 20:05:56.890230
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .journaling import compile_journal_entries_program
    from .accounts import compile_initial_balances_program

    ## Define a program which computes the general ledger:
    gl_program: GeneralLedgerProgram[str] = compile_general_ledger_program(
        compile_initial_balances_program(), compile_journal_entries_program()
    )

    ## Define a period:
    period = DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31))

    ## Compute the general ledger and print it:
    for acc, ledger in gl_program(period).ledgers.items():
        print(f"{acc.number}-{acc.name} {ledger.initial.value:>10}\n")
        for e in ledger.entries:
            print

# Generated at 2022-06-21 20:05:58.009586
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    ...


# Generated at 2022-06-21 20:06:05.677652
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    account = Account("test_account")
    account_test = Account("test_account_test")
    balance = Balance(datetime.date(2020, 1, 1), Quantity(Decimal(1)))
    balance_test = Balance(datetime.date(2020, 1, 2), Quantity(Decimal(2)))
    ledger = Ledger(account, balance)
    ledger_test = Ledger(account_test, balance_test)
    assert ledger != ledger_test
    assert ledger != account
    assert ledger != balance


# Generated at 2022-06-21 20:06:15.974260
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from unittest import TestCase
    from unittest.mock import MagicMock

    from .accounts import Account

    ## Setup:
    period = DateRange.of(0, 0)
    initial_balances = {Account.of(1, 1, 10): Balance(0, 0)}
    read_initial_balances = MagicMock(return_value=initial_balances)
    journal_entries = [
        JournalEntry.of(1, 0, "Test", [Posting.of(Account.of(1, 1, 10), 1, 1, 1)])
    ]
    read_journal_entries = MagicMock(return_value=journal_entries)
    program = compile_general_ledger_program(
        read_initial_balances,
        read_journal_entries,
    )

   

# Generated at 2022-06-21 20:06:28.065767
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    general_ledger1 = GeneralLedger(period = DateRange(since = datetime.date(2015, 1, 1), until = datetime.date(2015, 12, 31)), ledgers = {'a': Ledger('a', Balance(dt=datetime.date(2018, 1, 1), value=Decimal(0))), 'b': Ledger('b', Balance(dt=datetime.date(2018, 1, 1), value=Decimal(0)))})

# Generated at 2022-06-21 20:06:33.708920
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from unittest.mock import Mock
    from datetime import date
    from ..commons.numbers import Quantity
    mock = Mock(spec=ReadInitialBalances)
    mock.__call__(date(2020, 1, 1))
    mock.assert_called_once_with(date(2020, 1, 1))


# Generated at 2022-06-21 20:06:42.331970
# Unit test for method add of class Ledger
def test_Ledger_add():
    ledger = Ledger(Account(0), Balance(datetime.date(2020,5,5), Quantity(Decimal(0))))
    posting = Posting(datetime.date(2020,5,5), JournalEntry(datetime.date(2020,5,5), 'Test'),
                         Account(0), Amount(Decimal('100.00')), PostingDirections.Debit)
    ledger.add(posting)
    assert ledger.entries[0].posting == posting
    assert ledger.entries[0].balance == Quantity(Decimal('100.00'))
    assert ledger.entries[0].description == "Test"
    assert ledger.entries[0].amount == Amount(Decimal('100.00'))
    
    

# Generated at 2022-06-21 20:06:54.885333
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Unit test for method __call__ of class GeneralLedgerProgram
    """
    from datetime import date
    from datetime import datetime; from finance.algebra.bank import Bank
    from finance.algebra.properties import HasInitialBalances, HasJournalEntries
    from finance.domain.cash import CashPosting

    ## Define the class that implements the protocol ReadInitialBalances
    class ReadInitialBalancesImpl(HasInitialBalances):
        "Implementation of the interface ReadInitialBalances"
        ## The implementation clal method:
        def __call__(self, period: DateRange) -> InitialBalances:
            return InitialBalances

    ## Define the class that implements the protocol ReadJournalEntries
    class ReadJournalEntriesImpl(HasJournalEntries[CashPosting]):
        "Implementation of the interface ReadJournalEntries"

# Generated at 2022-06-21 20:07:03.779380
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    from dataclasses import is_dataclass_instance
    from .journaling import Journal, JournalEntry, Posting
    from .accounts import Account, AssetAccount, LiabilityAccount

    # Set up the instance of asset account and liability account
    asset_account = AssetAccount('Account 1')
    liability_account = LiabilityAccount('Account 2')

    # Set up the instance of Journal
    journal = Journal(datetime.date(2020, 1, 1), 'Debit to Asset Account')

    # Set up the instance of posting
    posting1 = Posting(asset_account, journal, Quantity(20), 'debit')
    posting2 = Posting(liability_account, journal, Quantity(10), 'credit')

    # Set up the instance of journal entry
    journal_entry = JournalEntry([posting1, posting2], journal)

    # Set

# Generated at 2022-06-21 20:07:40.146767
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    """
    Unit test for method __repr__ of class GeneralLedger.
    """
    #import pytest  # type: ignore
    from .accounts import Account  # type: ignore
    from .currency import Currency  # type: ignore
    from .journaling import CreateJournalEntry, CreatePosting  # type: ignore
    from datetime import date  # type: ignore
    #from ..commons import Numbers  # type: ignore
    #import math # type: ignore
    #from typing import FrozenSet # type: ignore

    # Test sample data, where
    # - Account(100) = Test account 1
    # - Account(200) = Test account 2
    # - Account(300) = Test account 3
    # - Account(400) = Test account 4
    # - Account(500) = Test account 5
    # - Account(600)

# Generated at 2022-06-21 20:07:52.854969
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    @dataclass
    class TestJournalEntry(Generic[_T]):
        pass

    @dataclass
    class TestPosting(Generic[_T]):
        pass

    TestJournalEntry = TestJournalEntry(_T)
    TestPosting = TestPosting(_T)

    TestJournalEntry.postings = [TestPosting("Test Posting")]

    test_general_ledger = GeneralLedger(
        DateRange("2020-01-01", "2020-02-01"),
        {Account("Test Account"): Ledger(Account("Test Account"), Balance("2020-01-01", 0))},
    )

    assert test_general_ledger.period == DateRange("2020-01-01", "2020-02-01")

# Generated at 2022-06-21 20:07:53.984924
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass

# Generated at 2022-06-21 20:08:01.764028
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    from ..books.books import Book
    from ..books.chart import ChartOfAccounts

    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {}


    book = Book("Test Book", ChartOfAccounts([]))

    read_initial_balances = _read_initial_balances
    read_journal_entries = book.read_journal_entries

    glp = compile_general_ledger_program(read_initial_balances, read_journal_entries)

    # Unit test for method __call__() of class GeneralLedgerProgram

# Generated at 2022-06-21 20:08:14.172097
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    t0 = datetime.date(2018, 1, 1)
    t1 = datetime.date(2018, 1, 3)
    t2 = datetime.date(2018, 1, 5)
    period = DateRange(t0, t2)
    journal = [
        JournalEntry(
            t0,
            "entry1",
            [Posting(Account("1150", "Cash"), Decimal("1000"), True), Posting(Account("1700", "Sales"), Decimal("1000"), False)],
        )
    ]

    # Initial balances
    initial = {
        Account("1150", "Cash"): Balance(None, Decimal("1000")),
        Account("1700", "Sales"): Balance(None, Decimal("0")),
    }

    # Create the general ledger
    ledgers = build_general_led

# Generated at 2022-06-21 20:08:17.139723
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    pass


# Generated at 2022-06-21 20:08:18.200595
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    pass


# Generated at 2022-06-21 20:08:28.853782
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import AccountClass
    from .journaling import Journal, Posting
    from .ledgering import LedgerRegistry, PostableLedger

    # define a toy account structure
    ledger_registry = LedgerRegistry()

    ledger_registry.add("1", Account("1", AccountClass.ASSET, "Cash in bank"))

    ledger_registry.add("11", Account("11", AccountClass.INCOME, "Sales"))
    ledger_registry.add("12", Account("12", AccountClass.INCOME, "Interest income"))

    ledger_registry.add("21", Account("21", AccountClass.EXPENSE, "COGS"))
    ledger_registry.add("22", Account("22", AccountClass.EXPENSE, "Wages"))


# Generated at 2022-06-21 20:08:35.289963
# Unit test for constructor of class Ledger
def test_Ledger():
    # Declare a ledger
    ledger = Ledger(Account('123'), Balance(datetime.date(2000, 1, 1), Quantity(Decimal(100))))
    assert ledger.account.code == '123'
    assert ledger.initial.value == Quantity(Decimal(100))
    assert ledger.initial.date == datetime.date(2000, 1, 1)
    assert ledger.entries == []



# Generated at 2022-06-21 20:08:42.373472
# Unit test for constructor of class Ledger
def test_Ledger():
    from .accounts import Account, Option
    from .commons.numbers import Quantity
    from .journaling import Journal, JournalEntry, Posting, ReadJournalEntries

    a = Account(1, Option.ASSET, "Cash")
    b = Account(2, Option.LIABILITY, "Bank Loan")
    c = Account(3, Option.EXPENSE, "Advertising")
    d = Account(4, Option.CURRENT_LIABILITY, "Accounts Payable")
    e = Account(5, Option.REVENUE, "Sales")
    f = Account(6, Option.CURRENT_ASSET, "Inventory")
    g = Account(7, Option.EQUITY, "Legal Capital")
    h = Account(8, Option.RETAINED_EARNING, "Retained Earning")

# Generated at 2022-06-21 20:09:06.286812
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    assert repr(LedgerEntry(None, None, None)) == 'LedgerEntry(None, None, None)'


# Generated at 2022-06-21 20:09:13.693733
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    ##testing ledgerEntry constructor
    from Coding_Challenges.src.accounting.journaling import Posting, Journal, Direction
    from Coding_Challenges.src.accounting.accounts import Account, AccountType
    #setting up
    test_account = Account("test", AccountType.ASSET)
    test_balance = Balance(datetime.date(2020,1,1), Quantity(Decimal(100)))
    test_ledger = Ledger(test_account, test_balance)
    test_journal = Journal(datetime.date(2020,1,1),"test journal")
    test_posting = Posting(test_journal,Direction.CREDIT,test_account,Quantity(Decimal(100)))
    test_amount = Amount(Decimal(100))

# Generated at 2022-06-21 20:09:16.370301
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    assert repr(GeneralLedger(None, None)) == "GeneralLedger(None, None)"

# Generated at 2022-06-21 20:09:24.479992
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting, Source
    from .transaction import Transaction
    from .utils import AccountLookup

    accounts = AccountLookup()

    period = DateRange(since=datetime.date(2019, 1, 1), until=datetime.date(2019, 12, 31))
    initial = {
        accounts.find(1040): Balance(datetime.date(2018, 12, 31), Quantity(Decimal("100.00"))),
        accounts.find(1200): Balance(datetime.date(2018, 12, 31), Quantity(Decimal("200.00"))),
    }

# Generated at 2022-06-21 20:09:33.543913
# Unit test for method __eq__ of class LedgerEntry

# Generated at 2022-06-21 20:09:46.506891
# Unit test for function build_general_ledger
def test_build_general_ledger():
    ## Which account is to be used?
    account: Account = Account("Assets:Bank:Checking")
    assert account.code == "1"

    ## Build an entry:
    entry: JournalEntry[None] = JournalEntry(
        date=datetime.date(2015, 1, 12),
        description="First Entry",
        postings=[
            Posting(account, Amount(100), None),
            Posting(Account("Revenues:Service"), Amount(100), None),
        ],
    )

    ## Build another entry:

# Generated at 2022-06-21 20:09:47.530133
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-21 20:09:52.935020
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    @dataclass
    class InitialBalances(Protocol):
        def __call__(self, period: DateRange) -> Dict:
            return {}

    @dataclass
    class JournalEntries(Protocol):
        def __call__(self, period: DateRange) -> List:
            return []

    read_initial_balances = compile_general_ledger_program(InitialBalances, JournalEntries)

    assert isinstance(read_initial_balances, GeneralLedgerProgram)


# Generated at 2022-06-21 20:09:56.049139
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    read_initial_balances: ReadInitialBalances
    """
    Test case for the constructor of class ReadInitBalances.
    """


# Generated at 2022-06-21 20:09:59.336600
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    read_initial_balances = ReadInitialBalances()
    read_journal_entries = ReadJournalEntries()
    compile_general_ledger_program(read_initial_balances, read_journal_entries)

# Generated at 2022-06-21 20:11:05.606972
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    account = Account("10001-100")
    # posting = Posting("1", datetime.date(1995, 1, 1), "Monthly shipping fee", Decimal("100"))
    # posting.account = account
    posting = Posting("1", datetime.date(1995, 1, 1), "Monthly shipping fee", Decimal("100"), account)
    initial = Balance(datetime.date(1995, 1, 1), Decimal("1000"))
    ledger = Ledger(account, initial)
    entry = LedgerEntry(ledger, posting, Decimal("900"))
    assert entry.date == datetime.date(1995, 1, 1)
    assert entry.description == "Monthly shipping fee"
    assert entry.amount == Decimal("100")
    assert entry.is_debit == True
    assert entry.is_credit == False
