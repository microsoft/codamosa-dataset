

# Generated at 2022-06-21 20:01:14.060502
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    ## Define an instance of the class
    ReadInitialBalances()

# Generated at 2022-06-21 20:01:24.150383
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    class MockReadJournalEntries:
        def __init__(self, period):
            self.period = period

        def __call__(self, period):
            from ..commons.sql.select_builder import SelectBuilder
            from ..core.sql.client import SQLClient
            import pandas as pd
            import numpy as np
            
            assert(period == self.period)
            client = SQLClient()
            select = SelectBuilder()
            select.columns = ['posting_id', 'journal_id', 'date', 'account_id', 'direction', 'amount']
            select.tables = ['company.journal_entries']
            select.add_conditions(['company.journal_entries.date between ? and ?'], [period.since, period.until])

# Generated at 2022-06-21 20:01:36.082722
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from .journaling import Journal, LedgerEntry
    from .accounts import Account
    from .generic import Balance
    from .commons.zeitgeist import today

    journal1 = Journal(
        date=today(),
        description='description',
        entries=[],
    )
    posting1 = Posting(
        journal=journal1,
        account=Account('account'),
        amount=100,
        direction='incoming',
    )
    initial = Balance(date = today(), value = Quantity(Decimal(0)))
    entry = LedgerEntry(
        ledger=Ledger(
            account=Account('account'),
            initial=initial,
            entries=[],
        ),
        posting=posting1,
        balance=Quantity(50),
    )
    assert entry.posting == posting1

# Generated at 2022-06-21 20:01:40.563910
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    acc = Account("0000", "description")
    bal = Balance(datetime.date(2000,1,1),Quantity(Decimal(10)))
    le1 = Ledger(acc, bal)
    le2 = Ledger(acc, bal)
    assert le1 == le2
    assert le2 == le1

# Generated at 2022-06-21 20:01:52.196985
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    ## Import modules under test:
    from .accounts import Account, AccountType
    from .commons import Direction
    from .journaling import JournalEntry, Posting

    ## Define some account type:
    account_type = AccountType(id="TEST", is_terminal=True)

    ## Get some account:
    account = Account(account_type, "YYY", "TEST ACCOUNT")

    ## Define initial balance:
    initial_balance = Balance(datetime.date(2018, 11, 30), Quantity(Decimal(1000)))

    ## Define a read_initial_balances function:
    def read_initial_balances(period: DateRange) -> Dict[Account, Balance]:
        return {account: initial_balance}

    ## Define a read_journal_entries function:

# Generated at 2022-06-21 20:02:01.423064
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    def test():
        period = DateRange(datetime.date(2019, 10, 1), datetime.date(2019, 12, 31))

        def read_initial_balances(period: DateRange) -> InitialBalances:
            return {"a": Balance(period.since, Quantity(Decimal(100))), "b": Balance(period.since, Quantity(Decimal(200)))}

        def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
            pass

        l = compile_general_ledger_program(read_initial_balances, read_journal_entries)
        return l(period)

    return test



# Generated at 2022-06-21 20:02:07.614302
# Unit test for constructor of class Ledger
def test_Ledger():
    account = Account("Cash", "A")
    initial = Balance(datetime.date(2018, 1, 1), Quantity(Decimal(10)))
    entries = []
    l = Ledger(account, initial, entries)
    assert l.account == account
    assert l.initial == initial
    assert l.entries == entries
    assert l._last_balance == initial.value


# Generated at 2022-06-21 20:02:16.172571
# Unit test for function build_general_ledger
def test_build_general_ledger():
    import datetime
    from decimal import Decimal
    from pytz import UTC

    from ..commons.numbers import Amount, Quantity

    period = DateRange(since=datetime.date(2016, 1, 1), until=datetime.date(2016, 1, 7))

    journal1 = [
        (datetime.date(2016, 1, 1), "INCR", "100"),  # Initial balance for account 100.
    ]

    result1 = build_general_ledger(period, journal1, {100: Amount(100)})

    assert result1.period == period
    assert result1.ledgers[100].initial == Amount(100)
    assert result1.ledgers[100].entries[0].posting.journal.description == "INCR"
    assert result1.ledgers[100].entries[0].date == dat

# Generated at 2022-06-21 20:02:26.038825
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    def _read_initial_balances(period: DateRange):
        return {a: Balance(period.since, Quantity(Decimal(0))) for a in [Account(1), Account(2)]}

    def _read_journal_entries(period: DateRange):
        return [
            JournalEntry(datetime.date(2020, 9, 22), "", [Posting(Account(1), Amount(100), True)]),
            JournalEntry(datetime.date(2020, 9, 23), "", [Posting(Account(2), Amount(200), False)]),
        ]

    program = compile_general_ledger_program(_read_initial_balances, _read_journal_entries)

    period = DateRange(datetime.date(2020, 9, 21), datetime.date(2020, 9, 30))

# Generated at 2022-06-21 20:02:32.607667
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    # Initialize a LedgerEntry object
    entry = LedgerEntry("1", "2", "3")
    # Assert equality of the object with a LedgerEntry object of the same attributes
    assert entry == LedgerEntry("1", "2", "3")
    # Assert inequity of the object with a LedgerEntry object with a different attribute
    assert not entry == LedgerEntry("4", "2", "3")
    # Assert inequity of the object with another object type
    assert not entry == "other"

# Generated at 2022-06-21 20:02:41.283681
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    # TODO
    pass

# Generated at 2022-06-21 20:02:49.387507
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    from .accounts import Account, Accounts
    from .journaling import JournalEntry, Journal, Posting
    from .generic import Balance

    # Test without initial balances:
    acct = Account('Units Sold', Accounts.Income)
    acct2 = Account('Taxes', Accounts.Income)
    acct3 = Account('Phone', Accounts.Expense)
    acct4 = Account('Revenue', Accounts.Income)

    je = JournalEntry(Journal('apples', 'apples'), [acct], [acct])
    je2 = JournalEntry(Journal('apples', 'apples'), [acct2], [acct2])
    je3 = JournalEntry(Journal('apples', 'apples'), [acct3], [acct3])

# Generated at 2022-06-21 20:03:01.768107
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    """
    This is a test case to check whether General Ledger is constructed correctly.
    """
    # To store all the initial balances
    initial_balances = {Account(9000): Balance(datetime.date(2019, 11, 1), Quantity(100)), Account(9100): Balance(datetime.date(2019, 11, 1), Quantity(0))}

    # To store all the journal entries
    journal_entry = JournalEntry(datetime.date(2019, 11, 1), "Test")
    journal_entry.post(Account(9100), Amount(100))
    journal_entry.post(Account(9000), Amount(-100))

    # To store all the journal entries
    journal_entry1 = JournalEntry(datetime.date(2019, 11, 2), "Test1")

# Generated at 2022-06-21 20:03:11.834337
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    print('\n\n TEST: GeneralLedgerProgram  __call__  method\n')
    from datetime import date
    from accounting_core.commons.models import Amount
    from accounting_core.journaling.models import JournalEntry
    
    from .models import Account, Balance

    from accounting_core.journaling import build_journal_entry
    from . import build_general_ledger

    ## Initialize account instances.
    checking = Account("Cash at bank", True)
    supplies = Account("Supplies", True)
    revenue = Account("Revenue", True)
    profit = Account("Total profit", False)

    ## Define initial balances.

# Generated at 2022-06-21 20:03:14.874993
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    id = 'abc'
    test_document = GeneralLedger(id)
    repr(test_document)
    return True

# Generated at 2022-06-21 20:03:27.287218
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from datetime import date
    from ..journaling import Journal, Posting, ReadJournalEntries
    from .accounts import Account, AccountType
    p = Posting(Journal(date(2020, 5, 12), Account(60, AccountType.liability, 'How I met your mother', 'Rent'), 'Rent'),
                Account(63, AccountType.asset, 'Eroski', 'Cash'), Amount(125))
    l = LedgerEntry(Ledger(Account(63, AccountType.asset, 'Eroski', 'Cash'),
                           Balance(date(2020, 5, 12), Quantity(325))), p, Quantity(325))
    assert l.balance == Quantity(325)
    assert l.posting == p

# Generated at 2022-06-21 20:03:38.294678
# Unit test for method add of class Ledger
def test_Ledger_add():
    ledger = Ledger(Account(
        'Assets:Cash:Checking',
        description='Checking Account',
        type='ASSET',
        parent=Account('Assets:Cash', description='Cash', type='ASSET', parent=Account('Assets', description='Assets', type='ASSET')),
        active=True,
        initial=Balance(date=datetime.date(2000, 1, 1), value=Quantity())
    ), Balance(date=datetime.date(2000, 1, 1), value=Quantity(Decimal(0))))


# Generated at 2022-06-21 20:03:50.404271
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    from ..commons.journaling import Journal
    from ..commons.types import  Direction

    _account = Account.of(1000)
    _date = datetime.date.today()
    _journal = Journal(_date, "Test Transaction")
    _posting = Posting(_account, _journal, _amount, _direction)
    _balance = Quantity(Decimal(0))
    _ledger_entry = LedgerEntry(_ledger, _posting, _balance)

    assert _ledger_entry.__repr__() == "{ledger_entry.__class__.__name__}(ledger={ledger_entry.ledger!r}, posting={ledger_entry.posting!r}, balance={ledger_entry.balance!r})".format(ledger_entry=_ledger_entry)

# Generated at 2022-06-21 20:03:54.682498
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    a = Ledger(1,1)
    b = Ledger(1,1)
    c = Ledger(1,None)
    d = Ledger(None,1)
    assert(a == b)
    assert(not (a == c))
    assert(not (a == d))
    assert(not (c == d))


# Generated at 2022-06-21 20:03:59.279532
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    """
    for value1 in valuelist:
        for value2 in valuelist:
            actual = value1 == value2
            expected = (value1 == value2)
            assert actual == expected
    """

# Generated at 2022-06-21 20:04:16.464688
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    @dataclass
    class JournalEntry_T:
        date: datetime.date
        description: str
        postings: List[Posting]

    @dataclass
    class Posting_T:
        date: datetime.date
        direction: Quantity.QuantityDirection
        account: Account
        amount: Decimal

    @dataclass
    class Account_JournalEntries(Generic[T]):
        account: Account
        entries: List[T] = field(default_factory=list)
    @dataclass
    class Account_InitialBalance(Generic[T]):
        account: Account
        entry: T



# Generated at 2022-06-21 20:04:24.185664
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    ## Test data:
    ref_period: DateRange = DateRange("2019-01-01", "2019-12-31")

# Generated at 2022-06-21 20:04:28.270508
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    ledgent = LedgerEntry(None,None,None)
    ledgent2 = LedgerEntry(None,None,None)
    assert(ledgent == ledgent2)

# Unit tests for method __eq__ of class Ledger

# Generated at 2022-06-21 20:04:32.167879
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    t = Ledger(Account("1"), Balance(datetime.date(2020, 1,1), Quantity(Decimal(0))))
    assert repr(t) == "Ledger(account=Account('1'), entries=[])"

# Generated at 2022-06-21 20:04:43.277133
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():

    # Test method __call__ of class GeneralLedgerProgram._program, Positive (Functional)

    # Test data
    class ReadInitialBalancesMock:

        def __init__(self):
            self.entries = None

        def __call__(self, period: DateRange):
            pass
    read_initial_balances = ReadInitialBalancesMock()

    class ReadJournalEntriesMock:

        def __init__(self):
            self.entries = None

        def __call__(self, period: DateRange):
            pass
    read_journal_entries = ReadJournalEntriesMock()

    period = DateRange(datetime.datetime(2018, 1, 1), datetime.datetime(2018, 12, 31))

    # Expected result
    expectedResult = None

    # Perform the test

# Generated at 2022-06-21 20:04:55.748210
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .accounts import Assets, IncomeStatement, Liabilities, Equity
    from .journaling import JournalEntry, Posting, read_journal_entries
    import datetime
    from decimal import Decimal

    ## Function to read initial balances as per Accounting Principals
    ## https://accountingprinciples.com/accounting-principles/how-to-analyze-ledger-accounts/
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Assets: Balance(period.since, Quantity(Decimal("100"))),
            Liabilities: Balance(period.since, Quantity(Decimal("20"))),
            Equity: Balance(period.since, Quantity(Decimal("80"))),
        }

    ## Standard read journal entries:
    read_journal_entries = read_journal_entries

# Generated at 2022-06-21 20:05:06.670007
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    from .accounts import Account
    from .journaling import Posting

    acct = Account()
    bal = Balance(datetime.date(2020, 1, 1), Quantity(0))
    ledger = Ledger(acct, bal)

    acct1 = Account()
    bal1 = Balance(datetime.date(2020, 2, 1), Quantity(0))
    ledger1 = Ledger(acct1, bal1)

    acct2 = Account()
    bal2 = Balance(datetime.date(2020, 1, 1), Quantity(0))
    ledger2 = Ledger(acct2, bal2)

    assert ledger != ledger1
    assert ledger != ledger2

    posting = Posting(acct, bal, Quantity(1))
    entry = LedgerEntry(ledger, posting, Quantity(1))

# Generated at 2022-06-21 20:05:17.407434
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    from .algebra import AccountingAlgebra
    from .backends import memory
    from .journaling import (
        ReadJournalEntries,
        ReadJournalEntriesR,
        ReadJournalEntriesS,
        ReadJournalEntriesRS,
    )
    from .generic import ReadInitialBalancesR
    from .types import _T
    from ..commons.zeitgeist import DateRange
    from .models import JournalEntry

    period: DateRange = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))


# Generated at 2022-06-21 20:05:25.649753
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    """
    Test for constructor of class GeneralLedgerProgram
    """
    # This method will test the constructor of class GeneralLedger
    def test_GeneralLedger(self, period: DateRange, read_initial_balances: ReadInitialBalances,
            read_journal_entries: ReadJournalEntries[_T]) -> GeneralLedger[_T]:
            """
            Consumes the opening and closing dates and produces a general ledger.
            """
            # Get initial balances as of the end of previous financial period:
            initial_balances = read_initial_balances(period)
            # Read journal entries and post each of them:
            journal_entries = read_journal_entries(period)
            # Build the general ledger and return:
            return build_general_ledger(period, journal_entries, initial_balances)



# Generated at 2022-06-21 20:05:33.070926
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account

    account = Account("", "", "", "")
    initial = Balance(datetime.date(2017, 12, 31), Quantity(0.00))
    ledger = Ledger(account, initial)
    entry = ledger.add(Posting(decimal.Decimal(-1.00), 1.0, "", "", "", datetime.date(2018, 1, 1)))
    assert entry.balance == decimal.Decimal(1.00)
    entry = ledger.add(Posting(decimal.Decimal(-2.00), 1.0, "", "", "", datetime.date(2018, 1, 1)))
    assert entry.balance == decimal.Decimal(3.00)

# Generated at 2022-06-21 20:05:55.449509
# Unit test for constructor of class Ledger
def test_Ledger():
    acc = Account(
        name="abc",
        type=AccountType(
            class_name="Service",
            sub_class_name="Revenue",
            type_name="Sales",
        )
    )
    bal = Balance(datetime(2020, 1, 1), 123)
    ledger = Ledger(acc, bal)
    assert ledger.account == acc
    assert ledger.initial == bal


# Generated at 2022-06-21 20:05:59.173782
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    assert compile_general_ledger_program([], []) != None
    assert callable(compile_general_ledger_program([], []))


# Generated at 2022-06-21 20:06:11.242960
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    import src.commons.zeitgeist as zeitgeist

    def _read_initial_balances(period):
        return {Account('A', 'B', 'C'): zeitgeist.initial_balance(2000, 7, 1, 1)}

    def _read_journal_entries(period):
        return None

    _general_ledger_program = compile_general_ledger_program(_read_initial_balances, _read_journal_entries)
    _general_ledger_program(zeitgeist.period())

    _read_initial_balances = None
    _read_journal_entries = None
    _general_ledger_program = compile_general_ledger_program(_read_initial_balances, _read_journal_entries)
    _general_ledger_program(zeitgeist.period())

   

# Generated at 2022-06-21 20:06:17.896531
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    # Preparation
    from .payables import Payables
    from .receivables import Receivables
    from .products import Products
    from .products import Product
    from .products import ProductType
    from .accounts import AccountType
    from .journaling import Journal
    from .journaling import JournalEntry
    from .journaling import Posting
    from .journaling import Direction
    from .sales import Sales
    from .sales import SalesRevenue
    from .sales import SalesDiscounts
    from .sales import SalesTax
    from .sales import SalesReturnsAndAllowances
    from ..commons.zeitgeist import DateRange
    from ..commons.numbers import Amount
    from ..commons.numbers import Quantity
    from datetime import date
    from dataclasses import dataclass, field

# Generated at 2022-06-21 20:06:29.007105
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    from .journaling import JournalEntry, Posting, read_journal_entries

    @dataclass
    class Mock:
        def __init__(self) -> None:
            self.balances = {
                Account("Assets:Cash"): Balance(datetime.date(2019, 12, 31), Quantity(1118.62)),
                Account("Assets:Bank"): Balance(datetime.date(2019, 12, 31), Quantity(1327.61)),
            }

        def __call__(self, period: DateRange) -> InitialBalances:
            return self.balances

    mock = Mock()


# Generated at 2022-06-21 20:06:30.734098
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    """
    No unit test available.
    """
    pass


# Generated at 2022-06-21 20:06:36.877601
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    # Setup
    ledger = Ledger(Account("1001"),Balance(datetime.date(2020, 1, 1), Quantity(100)))
    # Exercise and Verify
    assert repr(ledger) == "Ledger(account=Account(name='1001',category=<AccountCategory.Asset: 'Asset'>), initial=Balance(date=datetime.date(2020, 1, 1), value=Quantity(100)))"


# Generated at 2022-06-21 20:06:38.012299
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass



# Generated at 2022-06-21 20:06:45.886156
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():

    # Define test data
    dates = [
        datetime.date(year=2017, month=1, day=1),
        datetime.date(year=2017, month=1, day=5),
        datetime.date(year=2017, month=2, day=1),
        datetime.date(year=2017, month=2, day=5),
    ]
    keys = ["xxx", "yyy", "zzz"]
    accounts = [Account(k) for k in keys]
    account_map = {a: i for i, a in enumerate(accounts)}
    amounts = [Amount(1000 * i) for i in range(len(accounts))]
    balances = [Balance(dates[0], a) for a in amounts]

# Generated at 2022-06-21 20:06:53.433111
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    assert repr(LedgerEntry(Account("G000"), Posting(Account("G000"), Amount(Decimal(1)), "purchase", "purchase"), Quantity(Decimal(0)))) == "LedgerEntry(ledger=Account(code='G000'), posting=Posting(account=Account(code='G000'), amount=Amount(value=Decimal('1')), description='purchase', journal='purchase'), balance=Quantity(value=Decimal('0')))"


# Generated at 2022-06-21 20:07:30.492889
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    ## Define the read_initial_balances
    from ..accounts.config import terminal_accounts
    from ..accounts.parsing import parse_accounts
    from ..commons.codecs import read_lines
    from ..journaling.parsing import parse_journal_entry

    ## Load the account registry
    registry = parse_accounts(read_lines("data/accounts.csv", encoding="utf8"))

    ## Get the terminal accounts from the registry
    terminal = terminal_accounts(registry)

    ## Define the read_initial_balances
    @dataclass()
    class ReadInitialBalances():
        initial_balances: Dict[Account, Balance]

        def __call__(self, period: DateRange) -> InitialBalances:
            return self.initial_balances

    ## Get the initial balances

# Generated at 2022-06-21 20:07:41.099795
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    period = DateRange('2019-01-01', '2019-12-31')
    account_100 = Account('100')
    account_200 = Account('200')
    account_300 = Account('300')
    initial_balance_at_20190101_100 = Balance(date='2019-01-01', value=Quantity(Decimal('6000')))
    initial_balance_at_20190101_200 = Balance(date='2019-01-01', value=Quantity(Decimal('4000')))
    initial_balance_at_20190101_300 = Balance(date='2019-01-01', value=Quantity(Decimal('2000')))

# Generated at 2022-06-21 20:07:47.310713
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    """ Tests method __repr__ of class GeneralLedger

    """
    # Test case 1
    # Execute method __repr__
    _result = GeneralLedger._repr_(None)

    # Verify
    assert _result == '<GeneralLedger>'
# end def test_GeneralLedger___repr__


# Generated at 2022-06-21 20:07:56.768434
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    from . import build_account_structure_from_query
    from .accounts import AccountSource
    from .queries import build_query_model
    from .sinks import GeneralLedgerSink
    from .sources import JsonSource, JsonSourceConfig
    
    ## Define the general ledger sink:
    glsink = GeneralLedgerSink()

    ## Get the account structure:
    query_model = build_query_model(glsink.query)
    accounts = build_account_structure_from_query(query_model)

    ## Get the GL's account:
    GL = accounts[1200000000]
    
    ## The type modeling the data to be read by the JSON source:

# Generated at 2022-06-21 20:07:57.605935
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
  pass


# Generated at 2022-06-21 20:08:03.911593
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Unit test for method GeneralLedgerProgram.__call__.
    """

    ## Test data:
    period = DateRange(datetime.date(2020, 2, 1), datetime.date(2020, 2, 29))
    initial_balances = {Account("100"): Balance(datetime.date(2020, 1, 1), Quantity(1000))}

# Generated at 2022-06-21 20:08:06.238068
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    assert LedgerEntry(None, None, None) == LedgerEntry(None, None, None)

# Generated at 2022-06-21 20:08:16.206610
# Unit test for method add of class Ledger
def test_Ledger_add():

    # Ledger test case
    class TestLedger(Ledger):
        def __init__(self, account, initial):
            super().__init__(account, initial)
            self.__init__ = 0

    # Create test ledger
    test_ledger = TestLedger(Account.of("TestAccount"), Balance.at(datetime.date.today(), Quantity(Decimal(0))))

    # Journal test case
    class TestJournal(JournalEntry):
        def __init__(self, date, description):
            super().__init__(date, description)
            self.__init__ = 0

    # Posting test case
    class TestPosting(Posting):
        def __init__(self, amount, direction, account, journal):
            super().__init__(amount, direction, account, journal)

# Generated at 2022-06-21 20:08:27.334940
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    from .journaling import Journal
    from .persistence.persistence import ReadJournalEntries

    from .commons.zeitgeist import datetime_from, datetime_now

    from .persistence import in_memory, memory_journaling

    from .professional import compile_business_logic

    ## Compile business logic:
    business_logic = compile_business_logic()

    ## Prepare time now:
    time_now = datetime_now()

    ## Create accounting object:
    accounting = in_memory.make_accounting(business_logic, memory_journaling.make_journaling(business_logic))

    ## Create new asset account:

# Generated at 2022-06-21 20:08:38.037570
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import Assets, Expenses, Revenue, chart_of_accounts
    from .builders import create_journal_entry

    ## Define sample instances:
    journal_entries_buffer: List[JournalEntry] = []

    ## Define sample implementations:
    read_initial_balances = lambda _: {a: Balance(datetime.date(1970, 1, 1), Quantity(Decimal(0))) for a in chart_of_accounts}

# Generated at 2022-06-21 20:09:31.850227
# Unit test for function build_general_ledger
def test_build_general_ledger():

    # set of accounts
    a1 = Account(1, 'a1', 'a1')
    a2 = Account(2, 'a2', 'a2')
    a3 = Account(3, 'a3', 'a3')
    a4 = Account(4, 'a4', 'a4')

    # set of journal entries
    j1 = JournalEntry(1, 'j1', 'j1',
                      [Posting(a2, Quantity(10), True), Posting(a3, Quantity(10), False)])
    j2 = JournalEntry(2, 'j2', 'j2',
                      [Posting(a4, Quantity(10), True), Posting(a1, Quantity(10), False)])

# Generated at 2022-06-21 20:09:35.910394
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    from ..commons.zeitgeist import today, withdays, withmonths
    generalLedger = GeneralLedger(withmonths(0), {})
    assert repr(generalLedger) == '<GeneralLedger(period:time.DateRange(since:time.Date(2020, 5, 12), until:time.Date(2020, 6, 11)), ledgers:(<Account:A1>, <Account:A2>))>'

# Generated at 2022-06-21 20:09:48.190506
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    from .common import bob_green, tues_jan1_2019_15
    from copy import copy

    le = LedgerEntry(
        Ledger(bob_green, Balance(tues_jan1_2019_15, Quantity(Decimal(0)))),
        Posting(
            copy(tues_jan1_2019_15),
            bob_green,
            Amount(Decimal(15)),
        ),
        Quantity(Decimal(5)),
    )

    # NOTE: repr(le) called in line below is only for visual comparison,
    #       it should not be used directly in unit tests as it might change

# Generated at 2022-06-21 20:09:59.387038
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .journaling import ReadJournalEntries, Journal
    from .accounts import ReadAccounts, Account

    class MockJournal(ReadJournalEntries):
        def __call__(self, period: DateRange) -> Iterable[Journal]:
            return [Journal.from_amount(period.since, "Test", Account("1010"), Account("1020"), 1)]

    class MockAccount(ReadAccounts):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {Account("1010"):Balance(period.since, Quantity(0))}

    ledger = Ledger(Account("1010"), Balance(datetime.date(2020, 1, 1), Quantity(0)))
    account = ledger.account
    balance = ledger.initial
    entries = ledger.entries

# Generated at 2022-06-21 20:10:12.022463
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    from ..journaling import Journal, Posting
    from ..parsing.accounts import AccountParser
    from ..parsing.journal import JournalParser

    ## Build a journal entry.
    journal_parser = JournalParser(AccountParser())
    journal = JournalParser.from_str("foo", journal_parser("2019-01-01,Expenses,Commuter fare,-7.00,Assets:Eftpos,Expenses:Commuter fare"))
    posting = journal.postings[1]

    ## Build a ledger:
    ledger = Ledger(posting.account, Balance(datetime.date(2019, 1, 1), Quantity(Decimal(0))))

    ## Create the ledger entry.
    entry = LedgerEntry(ledger, posting, Quantity(posting.amount))

    ## Test.

# Generated at 2022-06-21 20:10:19.869813
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry
    from .posting import Posting

    def _read_initial_balances(period):
        return {
            Account("1100", "Current Assets", Account.T_BALANCE_SHEET): Balance(period.since, 1000),
            Account("2100", "Capital & Reserves", Account.T_BALANCE_SHEET): Balance(period.since, 10000),
            Account("2200", "Treasury Shares", Account.T_BALANCE_SHEET): Balance(period.since, 1000),
        }


# Generated at 2022-06-21 20:10:21.498970
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # This language is a joke.
    assert True, "TODO"


# Generated at 2022-06-21 20:10:30.837797
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """Unit test for method __call__ of class GeneralLedgerProgram"""
    import datetime
    from dataclasses import dataclass
    from typing import List, cast
    from functools import partial
    from hamcrest import assert_that, all_of, contains_string, empty, has_item, has_length, is_, none, only_contains
    from hamcrest.core.core.isequal import equal_to
    from hamcrest.core.core.isequal import is_not
    from hamcrest.library.collection.ismap_containing import has_key, has_value
    from hamcrest.library.object.is_ import is_
    from hamcrest.library.text.stringendswith import ends_with


    from .accounts import Account, Category, GeneralLedger, Terminal


# Generated at 2022-06-21 20:10:42.500660
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    from .accounts import Account
    from .commons.zeitgeist import Date

    account = Account.create_asset("BANK")

    today = Date.today()
    yesterday = today - 1

    l = Ledger(account, Balance(yesterday, Quantity(50)))
    le = l.add(Posting(Date(today), "posting description", Direction.DEBIT, Amount(5), account, []))


# Generated at 2022-06-21 20:10:49.456158
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from ..commons.zeitgeist import today
    from .accounts import Account
    from .commons import Balance

    #: Initial balances
    initial_balances = {
        Account("100", "Cash"): Balance(today(1), Quantity(Decimal(100_000))),
        Account("200", "Accounts receivable"): Balance(today(1), Quantity(Decimal(500_000))),
    }

    def __call__(period: DateRange) -> InitialBalances:
        return initial_balances

    #: Read initial balances algebra
    read_initial_balances = __call__

    #: Read journal entries function
    read_journal_entries = lambda period: []

    #: Build the general ledger program