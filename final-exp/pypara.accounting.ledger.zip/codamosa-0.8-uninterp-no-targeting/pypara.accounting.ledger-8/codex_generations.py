

# Generated at 2022-06-21 20:01:17.715032
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    @dataclass
    class _Foo(Generic[_T]):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {
                Account('101101', '101101'): Balance(period.since, Quantity(Decimal(10))),
                Account('101501', '101501'): Balance(period.since, Quantity(Decimal(2)))
            }
    assert _Foo().__call__(DateRange(datetime.date.today(), datetime.date.today())) == \
           {Account('101101', '101101'): Balance(datetime.date.today(), Quantity(Decimal(10))),
            Account('101501', '101501'): Balance(datetime.date.today(), Quantity(Decimal(2)))}


# Generated at 2022-06-21 20:01:26.483528
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    """
    Unit test for method __repr__ of class GeneralLedger:
    """
    # pylint: disable=unused-argument
    @dataclass
    class GeneralLedgers(Generic[_T]):
        """
        Unit test class.
        """

        #: Accounting period.
        period: DateRange

        #: Individual account ledgers of the general ledger.
        ledgers: Dict[Account, Ledger[_T]]

        def __repr__(self) -> str:
            """
            Returns a string representation of an object.
            """
            return "GeneralLedgers(period={}, ledgers=[<Ledger>,...])".format(self.period)

    # pylint: enable=unused-argument
    # assert __repr__(<instance>) == <expected value>

# Generated at 2022-06-21 20:01:37.394597
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    # Mock dependencies:
    ivbs = dict()
    jentries = dict()

    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return ivbs[period]

    def _read_journal_entries(period: DateRange) -> List[JournalEntry[_T]]:
        return jentries[period]

    # Compile the general ledger program:
    glp = compile_general_ledger_program(_read_initial_balances, _read_journal_entries)

    # Test it:
    ivbs[DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31))] = dict()
    ivbs[DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))] = dict()
    j

# Generated at 2022-06-21 20:01:48.545739
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Unit test for method __call__ of class GeneralLedgerProgram
    """
    from . import Journal, Posting, ReadJournalEntries
    from dataclasses import dataclass
    from datetime import date
    from .accounts import Account, Asset, Equity, Liability
    from ..commons.zeitgeist import DateRange
    from decimal import Decimal
    @dataclass(frozen=True)
    class JournalEntry_initial_balances(Journal):
        """
        A journal entry used specifically in the context of unit tests.
        """
        @dataclass(frozen=True)
        class Posting_initial_balance(Posting):
            """
            A posting used specifically in the context of unit tests.
            """
            amount: Decimal


# Generated at 2022-06-21 20:01:52.835878
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    # arrange
    entry1 = LedgerEntry(None, None, None)
    entry2 = LedgerEntry(None, None, None)

    # act
    entry1.__eq__(entry2)

    # assert (nothing to assert)
    pass


# Generated at 2022-06-21 20:01:56.923151
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    """
    Compares 2 identical Ledger objects
    """
    ledg1 = Ledger('Account', 'Balance')
    ledg2 = Ledger('Account', 'Balance')
    return ledg1 == ledg2

# Generated at 2022-06-21 20:02:05.213632
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    from .genledger.algebras import read_initial_balances, read_journal_entries
    from .genledger.models import InitialBalances, JournalEntry
    from .journaling import Journal

    @dataclass
    class JournalEntry1(JournalEntry):
        pass

    @dataclass
    class Journal1(Journal):

        a: int

        def __init__(self, a: int, *args):
            super().__init__(*args)
            self.a = a

    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            "A": Balance(datetime.date(2000, 1, 1), Quantity(Decimal(10)))
        }


# Generated at 2022-06-21 20:02:14.021763
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    # arrange
    account = Account(
        "Output",
        "Output",
        "Net product as obtained after all deductions, including any increases, deductions, or other transfers to net product.",
        True,
        False,
    )
    balance = Balance(datetime.date(2019, 12, 31), Quantity(Decimal(400)))
    ledger = Ledger(account, balance)
    # act
    result = ledger.__repr__()
    # assert
    assert result == "Ledger(account=Output, initial=Balance(date=2019-12-31, value=400))"


# Generated at 2022-06-21 20:02:18.454413
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from mydata.commons.zeitgeist import date_range
    from mydata.datasets.accounts import sample_accounts
    from mydata.datasets.ledgers import sample_initial_balances

    date_range_ = date_range(2020,1,1, 2020,1)

    data = sample_initial_balances(date_range_, sample_accounts())

    assert data is not None


# Generated at 2022-06-21 20:02:27.190171
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    posting1 = Posting(debit(Account(1), 100, "description"), datetime.date(2020, 1, 1), "description")
    posting2 = Posting(debit(Account(1), 100, "description"), datetime.date(2020, 1, 2), "description")
    balance1 = Quantity(100)
    balance2 = Quantity(200)
    ledger1 = Ledger(Account(1), Balance(datetime.date(2020, 1, 1), Quantity(0)))
    ledger_entry1 = LedgerEntry(ledger1, posting1, balance1)
    ledger_entry2 = LedgerEntry(ledger1, posting2, balance2)

# Generated at 2022-06-21 20:02:47.036779
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    class Journal:
        def __init__(self, description, postings):
            self.description = description
            self.postings = postings

    class Posting:
        def __init__(self, account, amount, direction):
            self.account = account
            self.amount = amount
            self.direction = direction

    class Account:
        def __init__(self, name):
            self.name = name

    class Direction:
        def __init__(self, value):
            self.value = value

    class Ledger:
        def __init__(self):
            self.name = "ledger"

    class Quantity:
        def __init__(self, value):
            self.value = value

    p000001 = Account("p000001")
    p000002 = Account("p000002")
    p000003 = Account

# Generated at 2022-06-21 20:02:55.327229
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    ## Mock dependencies.
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {}

    def read_journal_entries(period: DateRange) -> List[JournalEntry[_T]]:
        return []

    ## Compile the program and call it:
    compile = compile_general_ledger_program(read_initial_balances, read_journal_entries)
    compile(DateRange(datetime.date.today(), datetime.date.today()))

# Generated at 2022-06-21 20:03:02.664217
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    @dataclass
    class TrialBalance:
        account: Account
        balance: Quantity
    
    general_ledger=GeneralLedger(DateRange(datetime.date(2020, 10, 7), datetime.date(2020, 10, 31)), {TrialBalance('5400', Quantity(Decimal('0')))}, None)
    
    print(general_ledger.period)
    print(len(general_ledger.ledgers))
    
    
#test_GeneralLedger()


# Generated at 2022-06-21 20:03:12.230368
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    assert GeneralLedger(DateRange(datetime.date(2016, 1, 1), datetime.date(2016, 2, 1)), {}) == GeneralLedger(DateRange(datetime.date(2016, 1, 1), datetime.date(2016, 2, 1)), {})
    assert GeneralLedger(DateRange(datetime.date(2016, 1, 1), datetime.date(2016, 2, 1)), {}) != GeneralLedger(DateRange(datetime.date(2016, 1, 1), datetime.date(2016, 3, 1)), {})

# Generated at 2022-06-21 20:03:17.394491
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    """
    Unit test for `Ledger.__repr__` method.
    """
    ledger = Ledger('1000', Balance('2019-09-18', 0))

    assert repr(ledger) == "Ledger('1000', Balance('2019-09-18', 0))"


# Generated at 2022-06-21 20:03:29.740904
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .import apis as apis
    from . import impls as impls
    from .commons import read_journal_entries_from_file
    import datetime

    ## Define the opening and closing dates of period.
    period = apis.DateRange(
        datetime.date(day=1, month=1, year=2018), datetime.date(day=31, month=12, year=2018)
    )

    ## Define the path to the journal.
    journal = '.journal.csv'

    ## Read the journal entries from file and post each of them.
    journal_entries = read_journal_entries_from_file(journal)

    ## Get initial balances.
    initial_balances = impls.read_initial_balances(period)

    ## Compile the general ledger program.
    general_led

# Generated at 2022-06-21 20:03:39.672618
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():

    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting, Transaction

    # We create an account.
    account = Account(id='1000', name='Asset:Cash', type=AccountType.ASSET, debit='D', credit='C')

    # We create some transactions.

    # 123:
    t1 = Transaction(description='t1',
                     postings=[Posting('C', account, Amount(1200)),  Posting('D', Account('2000', 'Liability:Income Tax Payable'), Amount(1200))])

    # 456:
    t2 = Transaction(description='t2',
                     postings=[Posting('D', account, Amount(3456)),  Posting('C', Account('3000', 'Equity:Retained Earnings'), Amount(3456))])

    # 789:

# Generated at 2022-06-21 20:03:52.006650
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Account for which the ledger will be created
    account = Account("1001", "Assets", "Cash", 1)

    # Entries are not added to the ledger yet
    assert account.ledger.entries == []

    # Adding an in debt posting of 500
    posting = Posting("Payment received", "Paid 500", datetime.date(year=2019, month=1, day=1), 500, 1, account)
    posting.journal.postings.append(posting)
    account.add_posting(posting)

    # A ledger entry is created and added to the entries list
    assert account.ledger.entries[-1].ledger == account.ledger
    assert account.ledger.entries[-1].posting == posting
    assert account.ledger.entries[-1].date == posting.date


# Generated at 2022-06-21 20:04:03.630452
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    """
    Unit test for method __eq__ of class Ledger
    """
    ledger1=Ledger(Account("1"),Balance(datetime.date(2016, 10, 10),Decimal(500)))
    ledger2=Ledger(Account("1"),Balance(datetime.date(2016, 10, 10),Decimal(500)))
    ledger3=Ledger(Account("2"),Balance(datetime.date(2016, 10, 10),Decimal(500)))
    ledger_entries=[]
    ledger_entries.append(LedgerEntry(ledger1, Posting(datetime.date(2016, 10, 10), Amount(Decimal(100)), 'debit', Account("1"), Account("2")), Quantity(Decimal(200))))
    ledger1.entries= ledger_entries
    ledger2.entries= ledger_entries


# Generated at 2022-06-21 20:04:11.379897
# Unit test for constructor of class Ledger
def test_Ledger():
    "Test for constructor of class Ledger"
    account_1 = Account("a1", None, True)
    initial_1 = Balance(datetime.date.today(), Quantity(1))
    ledger_1 = Ledger(account_1, initial_1)
    assert ledger_1.account == account_1
    assert ledger_1.initial == initial_1
    assert ledger_1.entries == []
    assert ledger_1._last_balance == 1


# Generated at 2022-06-21 20:04:20.901033
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    assert ReadInitialBalances

# Generated at 2022-06-21 20:04:21.573249
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__(): ...


# Generated at 2022-06-21 20:04:33.148878
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting

    date = datetime.date(2016, 1, 1)
    journal_entry = JournalEntry(
        date=date,
        description="Example journal entry 01.",
        postings=[
            Posting(
                account=Account.get_account(10100), amount=Amount(10), direction=Posting.Direction.DR
            ),
            Posting(
                account=Account.get_account(10200), amount=Amount(10), direction=Posting.Direction.CR
            ),
        ],
    )
    journal_entry.post()

    initial_balance = {Account.get_account(10100): Balance(date, Quantity(Decimal(100)))}


# Generated at 2022-06-21 20:04:36.951364
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    ledger = Ledger(Account(31002,'Cash - USD'),Balance(datetime.date(2019,1,1),Quantity(0)))
    assert "<Ledger for account 31002 Cash - USD>" == ledger.__repr__()

# Generated at 2022-06-21 20:04:46.670356
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    @dataclass
    class _AccountingPeriod:
        since: datetime.date
        until: datetime.date

    @dataclass
    class _Debit:
        amount: Decimal
        description: str

    @dataclass
    class _Credit:
        amount: Decimal
        description: str

    @dataclass
    class _AccountMovement:
        debit: _Debit
        credit: _Credit

    @dataclass
    class _GeneralAccount:
        account: Account
        balance: Balance

    @dataclass
    class _JournalEntry:
        date: datetime.date
        description: str
        movements: List[_AccountMovement]

    @dataclass
    class _OpeningBalanceEntry:
        date: datetime.date
        account: Account
        balance: Decimal


# Generated at 2022-06-21 20:04:53.145523
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    """
    Tests that the representation of an instance is returned properly.
    """
    assert (
        repr(GeneralLedger(DateRange(datetime.date(2020, 8, 15), datetime.date(2020, 8, 30)), {}))
        == "GeneralLedger(period=DateRange(since=datetime.date(2020, 8, 15), until=datetime.date(2020, 8, 30)), ledgers={})"
    )
    pass



# Generated at 2022-06-21 20:05:02.253283
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    '''
    This is a test function to test the __repr__ method of class Ledger
    '''
    pass
    '''
    # Test case 1
    print('Test case 1: Positive case')
    ledger = Ledger(1,2)
    assert ledger.__repr__ == <__main__.ledger object at 0x107ef6ba8>
    print('Pass')
    '''
    # Test case 2
    print('Test case 2: Negative case')
    assert 1 == 2
    print('Pass')

# Generated at 2022-06-21 20:05:03.251063
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-21 20:05:14.509369
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import AccountTree
    from .journaling import Journal, Posting

    #: Journal:
    journal = Journal(
        date=datetime.date(year=2017, month=12, day=31),
        description="Test journal",
        postings=(
            Posting(AccountTree.FICA_Expense.with_type("payroll-taxable"), Quantity(1000)),
            Posting(AccountTree.Accounts_Payable.with_type("vendor"), Quantity(1000)),
        ),
    )

    #: Initial balances:

# Generated at 2022-06-21 20:05:23.311398
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    ledger = Ledger(Account("A", "B"), Balance(datetime.date(2020, 8, 31), Quantity(5)))
    posting = Posting(
        Journal("DEBIT_JOURNAL", "Debit journal", datetime.date(2020, 8, 31)), Account("A", "B"), Quantity(10), -1
    )
    entry_1 = LedgerEntry(ledger, posting, Quantity(5))
    entry_2 = LedgerEntry(ledger, posting, Quantity(5))
    entry_3 = LedgerEntry(ledger, posting, Quantity(10))
    entry_4 = LedgerEntry(ledger, posting, Quantity(5))
    assert entry_1 == entry_2
    assert entry_1 != entry_3
    assert entry_1 == entry_4

# Generated at 2022-06-21 20:05:52.035495
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():

    # Set up the test fixture.
    def mock_initial_balances() -> InitialBalances:
        return {}

    # Execute the system under test.
    i = mock_initial_balances()

    # Check the results.
    assert isinstance(i, dict)


# Generated at 2022-06-21 20:05:57.961012
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    @dataclass
    class ReadInitialBalancesImpl(Generic[_T]):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {}

    assert ReadInitialBalancesImpl()(DateRange(datetime.date(2019, 12, 31), datetime.date(2020, 1, 31))) == {}



# Generated at 2022-06-21 20:06:08.204973
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    a = GeneralLedger(DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31)), {
        "Assets:Cash": Ledger(Account("Assets", "Cash"), Balance(datetime.date(2020, 1, 1), Quantity(Decimal(100)))),
        "Assets:Food": Ledger(Account("Assets","Food"), Balance(datetime.date(2020, 1, 1), Quantity(Decimal(100))))
    })

# Generated at 2022-06-21 20:06:16.714270
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    account = Account(
        short_name="Saving",
        long_name="Saving Account",
        account_type="Asset",
        extras={"exchange": "USD"},
    )

    initial = Balance(datetime.date(2015, 10, 10), Quantity(Decimal(0)))


    obj = Ledger(account, initial)
    assert repr(obj) == (
        "Ledger(account: Account(short_name: 'Saving', long_name: 'Saving Account',"
        " account_type: 'Asset', extras: {'exchange': 'USD'}), initial: Balance(date:"
        " datetime.date(2015, 10, 10), value: Decimal('0')))"
    )

# Generated at 2022-06-21 20:06:24.670131
# Unit test for method add of class Ledger
def test_Ledger_add():
    t = Posting(Account(12345678, 'Dutch'), datetime.date(2019, 1, 1), Quantity(12.34), Direction.Debit)
    a = Ledger(Account(12345678, 'Dutch'), Balance(datetime.date(2019, 1, 1), Quantity(0)))
    a.add(t)
    assert a.entries[0].balance == 12.34
    assert a.entries[0].amount == 12.34
    assert a.entries[0].credit == None

# Generated at 2022-06-21 20:06:25.866393
# Unit test for constructor of class Ledger
def test_Ledger():
    # Todo: Implement
    pass



# Generated at 2022-06-21 20:06:30.009962
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    acc = Account('DUMMY')
    posting = Posting(acc, AccType.Liability, AccType.Asset, Decimal(100), datetime.date(2020, 1, 1))
    le1 = LedgerEntry(None, posting, Decimal(100))
    le2 = LedgerEntry(None, posting, Decimal(200))
    assert le1 == le2


# Generated at 2022-06-21 20:06:41.847046
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    account = Account(number="0123", name="foo")
    date = datetime.date(2020, 1, 1)
    amount = Amount(10)
    
    test_ledger_entries = []
    test_ledger_entries.append(LedgerEntry(Ledger(account, Balance(date, amount)), Posting(Amount(5), date, ""), Quantity(5)))
    test_ledger_entries.append(LedgerEntry(Ledger(account, Balance(date, amount)), Posting(Amount(10), date, ""), Quantity(15)))
    
    test_ledger = Ledger(account, Balance(date, amount))
    test_ledger.entries.extend(test_ledger_entries)
    assert str(test_ledger) == "Ledger[foo, entries=2]"

#

# Generated at 2022-06-21 20:06:54.310309
# Unit test for constructor of class Ledger
def test_Ledger():
    from .journaling import Journal
    from .accounts import Account, AccountType
    from .generic import Balance
    from .commons.numbers import Quantity
    from .commons.zeitgeist import CurrentDate

    # Create an account for ledger
    account = Account(1, AccountType.ASSET, 'Cash')

    # Setup opening balance for account
    opening_balance = Balance(CurrentDate, Quantity(1000))

    # Create journal entries
    j1 = Journal(1, CurrentDate, 'Debit Test', Posting(CurrentDate, account, Quantity(1000), True))
    j2 = Journal(1, CurrentDate, 'Credit Test', Posting(CurrentDate, account, Quantity(300), False))

    # Create an instance of Ledger
    ledger = Ledger(account, opening_balance)
    # Assert that initial balance is set correctly
   

# Generated at 2022-06-21 20:07:02.702413
# Unit test for method __eq__ of class GeneralLedger

# Generated at 2022-06-21 20:07:53.123199
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    test_period = DateRange(datetime.date.today(), datetime.date.today())
    test_account = "TestAccount"
    test_journal_entries = [JournalEntry(datetime.date.today()), JournalEntry(datetime.date.today())]
    test_initial_balance = {"TestAccount":2}
    test_initial_balances = {"TestAccount":Balance(1,1)}
    build_general_ledger_result = build_general_ledger(test_period, test_journal_entries, test_initial_balances)
    assert isinstance(build_general_ledger_result, GeneralLedger)
    assert build_general_ledger_result.period == test_period
    assert build_general_ledger_result.ledgers == test_initial_balances


# Generated at 2022-06-21 20:07:56.488897
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    period = DateRange()
    journal = iter([JournalEntry()])
    initial = dict([Account(), Balance(datetime.date(2020, 4, 3), Quantity(Decimal(1)))])
    general_ledger = build_general_ledger(period, journal, initial)
    assert general_ledger is not None


# Generated at 2022-06-21 20:07:57.381872
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-21 20:08:03.651779
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 2, 29))
    posting = Posting(
        datetime.date(2020, 2, 29), True, datetime.date(2020, 2, 29), "test", Account("test"), Amount(10)
    )
    l = Ledger(Account("test"), Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0))))
    le = LedgerEntry(l, posting, Quantity(10))
    l.add(posting)
    l2 = Ledger(Account("test"), Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0))))
    le2 = LedgerEntry(l2, posting, Quantity(30))
    l2.entries.append(le2)

# Generated at 2022-06-21 20:08:14.792668
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import datetime
    from decimal import Decimal

    from ..commons.logging import configure_test_logging
    from ..commons.zeitgeist import DateRange

    from ..data.ledgers.accounts import Account
    from ..data.ledgers.generic import Balance

    # Initial balances

# Generated at 2022-06-21 20:08:27.148224
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    # Initialize ledgers
    a = Ledger(Account('Account'), Balance(datetime.date(2020, 1, 1), Quantity(50)))
    b = Ledger(Account('Account'), Balance(datetime.date(2020, 1, 1), Quantity(50)))
    a.entries.append(LedgerEntry(a, Posting(Account('Account'), Quantity(50), datetime.date(2020, 1, 1),), Quantity(50)))
    a.entries.append(LedgerEntry(a, Posting(Account('Account'), Quantity(50), datetime.date(2020, 1, 2),), Quantity(0)))
    b.entries.append(LedgerEntry(b, Posting(Account('Account'), Quantity(50), datetime.date(2020, 1, 1),), Quantity(50)))

# Generated at 2022-06-21 20:08:38.037987
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from contextlib import contextmanager
    import os
    import random

    import pytest
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker

    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange

    from .accounts import Account, Terminal, Type
    from .journaling import build_journal_entry, JournalEntry, Posting, ReadJournalEntries
    from .persistence import Base, Repository

    ##
    ## Setup environment and test data.
    ##

    ## Setup test folder.
    TEST_DIR = "./tests/GeneralLedgerProgram"
    os.makedirs(TEST_DIR, exist_ok=True)

# Generated at 2022-06-21 20:08:48.554383
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from typing import Callable

    from .accounts import Account, AccountingEntity
    from .journaling import Journal

    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {}

    def _read_journal_entries(period: DateRange) -> Iterable[Journal]:
        return []

    program: Callable[[DateRange], GeneralLedger[AccountingEntity]] = compile_general_ledger_program(
        _read_initial_balances, _read_journal_entries
    )
    assert program(DateRange(datetime.date(2020, 4, 1), datetime.date(2020, 4, 30))) == GeneralLedger(
        DateRange(datetime.date(2020, 4, 1), datetime.date(2020, 4, 30)), {}
    )

# Generated at 2022-06-21 20:09:01.697105
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    """
    Tests equality comparison of LedgerEntry instances.
    """
    # Test case 1: LedgerEntry instances with different ledgers are not equal.
    ledger1 = Ledger(1, 2)
    ledger2 = Ledger(2, 2)
    posting1 = Posting(1, 2)
    balance1 = 1
    assert LedgerEntry(ledger1, posting1, balance1) != LedgerEntry(ledger2, posting1, balance1)

    # Test case 2: LedgerEntry instances with different postings are not equal.
    ledger3 = Ledger(2, 3)
    posting2 = Posting(1, 5)
    assert LedgerEntry(ledger3, posting1, balance1) != LedgerEntry(ledger3, posting2, balance1)

    # Test case 3: LedgerEntry instances with different balances are not

# Generated at 2022-06-21 20:09:11.144067
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    # Data for test:
    p = datetime.date(2020, 7, 15)
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))
    account = Account(
        number=101,
        alias='Cash',
        full_name='Cash',
        nature=None,
        category=None,
        definition=None,
    )
    initial = Balance(period.since, Quantity(Decimal(0)))
    posting1 = Posting(
        account=account,
        jv_number=1,
        date=p,
        description='Payment for services rendered',
        amount=Amount(Decimal(1000)),
        direction=Posting.Direction.DEBITED,
    )

# Generated at 2022-06-21 20:10:35.524136
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    pass # TODO

# Generated at 2022-06-21 20:10:44.978096
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..business_objects.journaling import Journal, JournalEntry, Posting, PostingDirection

    ## Build a journal:
    journal = Journal(
        description="Salary",
        postings=[Posting(PostingDirection.Debit, Account.SalariesAndWages, Amount(42))],
    )

    ## Build a journal entry:
    journal_entry = JournalEntry(date=datetime.date(2020, 1, 1), journal=journal)

    ## Build a ledger:
    ledger = Ledger(
        account=Account.SalariesAndWages,
        initial=Balance(
            date=datetime.date(2020, 1, 1),
            value=Quantity(42),
        ),
    )

    ## Add the posting to the ledger:
    ledger_entry = ledger.add(journal_entry.postings[0])
   

# Generated at 2022-06-21 20:10:55.541930
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
  period = DateRange(1,1,1,1,1,1)
  journal = JournalEntry(1, "a", "a", 1, [
                    Posting(1, 1, 1, 1),
                    Posting(1, 1, 1, 1)
                    ]
                  )
  journal_iter = iter(journal)
  initial = {
      "a": Balance(1,1)
  }
  g = build_general_ledger(period, journal_iter, initial)
  assert g.period == period
  assert g.ledgers == {
      "a": Ledger(1, Balance(1,1))
  }

# Generated at 2022-06-21 20:11:05.073348
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    """
    Unit test for method __repr__ of class GeneralLedger
    """
    # Declaring a ledger list
    ledger_list = []
    # Declaring a key list
    key_list = []
    # Initializing ledger
    ledger = Ledger(Account(1,'Asset Account'), Balance(datetime.date(2020, 1, 1), Decimal(0)))
    # Adding the ledger in the ledger list
    ledger_list.append(ledger)
    # Adding the account in the key list
    key_list.append(ledger.account)
    # Initializing ledger
    ledger = Ledger(Account(2,'Asset Account'), Balance(datetime.date(2020, 1, 1), Decimal(0)))
    # Adding the ledger in the ledger list
    ledger_list.append(ledger)
    # Adding the account in the