

# Generated at 2022-06-21 20:01:26.620257
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    posting = Posting(DateRange(datetime.date(2020, 3, 20), datetime.date(2020, 3, 30)),
                            'Payment for March',
                            10000,
                            datetime.date(2020, 3, 30),
                            datetime.date(2020, 3, 30))
    ledger = Ledger(Account('2501', 'Cash'),
                        Balance(datetime.date(2020, 3, 1), Decimal(10000)))
    entry = LedgerEntry(ledger, posting,
                        Quantity(Decimal(10000 + 10000 * 1)))
    assert entry.date == datetime.date(2020, 3, 30)
    assert entry.description == 'Payment for March'
    assert entry.amount == Amount(Decimal(10000))
    assert entry.cntraccts == []
    assert entry.is_deb

# Generated at 2022-06-21 20:01:29.532698
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    assert GeneralLedger(None, None) == GeneralLedger(None, None)
    assert not GeneralLedger(None, None) != GeneralLedger(None, None)


# Generated at 2022-06-21 20:01:37.918947
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests method __call__ of class GeneralLedgerProgram.
    """
    ## Create a dummy implementation of ReadInitialBalances:
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {}

    ## Create a dummy implementation of ReadJournalEntries:
    def _read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        return []

    ## Compile the program:
    program = compile_general_ledger_program(_read_initial_balances, _read_journal_entries)

    ## Invoke the program:
    program(datetime.date.today())

# Generated at 2022-06-21 20:01:40.615101
# Unit test for constructor of class Ledger
def test_Ledger():
    assert Ledger(1,2).account == 1
    assert Ledger(1,2).initial == 2
    assert Ledger(1,2).entries == []


# Generated at 2022-06-21 20:01:52.240151
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # Test data
    class JournalEntryA:
        def __init__(self, date, description, postings):
            self.date = date
            self.description = description
            self.postings = postings
    class PostingA:
        def __init__(self, account, direction, amount):
            self.account = account
            self.direction = direction
            self.amount = amount

# Generated at 2022-06-21 20:02:02.706630
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    """
    Unit test for method __repr__ of class LedgerEntry
    """
    from .accounts import Account
    from .journaling import Journal, PostingDirection

    # Set up a fake ledger
    ledger = Ledger(Account(1), Balance(datetime.date(2016, 1, 1), 0))
    # Set up a Journal
    journal = Journal(
        datetime.date(2016, 12, 1),
        "Test Journal Entry",
        [
            Posting(Account(1), PostingDirection.DEBIT, 10),
            Posting(Account(2), PostingDirection.CREDIT, 10),
        ],
    )
    # Set up LedgerEntry
    ledger_entry = LedgerEntry(ledger, journal.postings[0], 0)
    # Compare the __repr__() with the expected result

# Generated at 2022-06-21 20:02:14.728632
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    """
    :Test Title: test_Ledger___repr__

    :Test Description: Unit test for method __repr__ of class Ledger

    :Test Steps:
        - Create new Ledger(account=Account(description='Test Account', number=12345),
          initial=Balance(date=datetime.date(year=2019, month=12, day=31), value=Decimal(45678)))
        - Call method __repr__

    :Test Expected Result:
        - Method __repr__ returns a string
    """
    # Create new Ledger(account=Account(description 'Test Account', number=12345),
    #                   initial=Balance(date=datetime.date(year=2019, month=12, day=31), value=Decimal(45678)))

# Generated at 2022-06-21 20:02:24.996746
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    def read_initial_balances(period: DateRange):
        return {Account("A1"): Balance(period.since, Quantity(Decimal(10000)))}

    def read_journal_entries(period: DateRange):
        return [
            JournalEntry(
                Description("J1"),
                Date(period.since),
                [
                    Posting(Credit, Account("C1"), Amount(Decimal(100))),
                    Posting(Debit, Account("A1"), Amount(Decimal(100))),
                ],
            )
        ]

    program = compile_general_ledger_program(read_initial_balances, read_journal_entries)
    assert program(DateRange(since=Date(datetime.date.today()), until=Date(datetime.date.today())))



# Generated at 2022-06-21 20:02:31.659689
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..journaling import Journal, Posting, create_journal
    from ..accounts import Asset, Liability, Equity, Revenue, Expense, create_chart_of_accounts
    from ..commons.zeitgeist import DateRange
    from ..commons.numbers import Amount, Quantity
    from datetime import date
    from decimal import Decimal
    import io
    import unittest

    # Define test case class
    class BuildGeneralLedgerTest(unittest.TestCase):

        # Setup.
        def setUp(self):
            # Create a chart of accounts.
            self.coa = create_chart_of_accounts(io.StringIO(COA_TEXT))

            # Create the initial balances dictionary.

# Generated at 2022-06-21 20:02:33.335145
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Unit test for method __call__ of class GeneralLedgerProgram
    """
    pass

# Generated at 2022-06-21 20:02:37.484086
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-21 20:02:38.289791
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass



# Generated at 2022-06-21 20:02:48.813480
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    import dateutil.parser
    from datetime import date
    from ledger.accounts import Account

    @dataclass
    class ReadInitialBalancesStub:
        """
        Stub
        """

        def __call__(self, period: DateRange) -> InitialBalances:
            """
            Stub
            """
            return {Account("123"): Balance(dateutil.parser.parse("2020-04-01").date(), Decimal("1000"))}

    from ledger.general_ledger import ReadInitialBalances as target

    subject: target = ReadInitialBalancesStub()
    expected: InitialBalances = {Account("123"): Balance(dateutil.parser.parse("2020-04-01").date(), Decimal("1000"))}

# Generated at 2022-06-21 20:03:01.258719
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    from ..commons import Money, Quantity
    from ..domain.journaling import Posting

    heading = "LedgerEntry(ledger=Ledger(account=1, initial=Balance(date=datetime.date(2000, 12, 31), value=5.5), entries=[]), posting=Posting(direction=1, account=1, amount=Money(amount=6.6, currency='ZAR')), balance=6.6)"
    
    result = LedgerEntry(ledger=Ledger(account=1, initial=Balance(date=datetime.date(2000, 12, 31), value=Quantity(Decimal(5.5))), entries=[]), posting=Posting(direction=1, account=1, amount=Money(amount=Decimal(6.6), currency='ZAR')), balance=Quantity(Decimal(6.6))).__

# Generated at 2022-06-21 20:03:06.667294
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    # Default constructor
    entry = LedgerEntry(0,'KCP', 'C0001', ['C0002', 'C0003'], Decimal(10), "description 1", "2019-12-01", Decimal(0))
    assert entry != None    
    

# Generated at 2022-06-21 20:03:07.918538
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-21 20:03:21.168253
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import Date
    from ..service.accounts import Account, AccountType
    from ..service.journaling import Journal, JournalEntry, Posting, Transaction
    period = DateRange(Date(2020, 1, 1), Date(2020, 12, 31))

# Generated at 2022-06-21 20:03:33.965870
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    period = DateRange(datetime.date(2019, 10, 3), datetime.date(2019, 10, 21))
    journal = [
        JournalEntry('Purchased 6,000 kg of wheat at $1 per 100 kg', [Posting('Bank', 1000, True), Posting('Cash', 1000, False)]),
        JournalEntry('Purchased 7,000 kg of oats at $0.50 per 100 kg', [Posting('Bank', 500, True), Posting('Cash', 500, False)]),
        JournalEntry('Sold 600 kg of wheat and 800 kg of oats', [Posting('Bank', 1200, False), Posting('Cash', 1200, True)])
    ]
    initial = {'Cash': Quantity(10), 'Bank': Quantity(100)}
    test_gl = build_general_ledger(period, journal, initial)

    assert test_

# Generated at 2022-06-21 20:03:35.213896
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    """
    Test method __eq__ of class LedgerEntry
    """
    pass



# Generated at 2022-06-21 20:03:37.938500
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    L=LedgerEntry("a","b","c","d")
    L1=LedgerEntry("a","b","c","d")
    assert(L.__eq__(L1)==True)

# Generated at 2022-06-21 20:03:53.789980
# Unit test for constructor of class Ledger
def test_Ledger():
    account1 = Account("100100")
    initial_balances = {account1: Balance(datetime.date(2019, 11, 1), Quantity(Decimal(1000))),}
    journal_entries_iterable = [JournalEntry(
        datetime.date(2019, 11, 1), "Test for constructor of class Ledger",
        [Posting(account1, Quantity(Decimal(500)), True)])]
    period = DateRange(since=datetime.date(2019, 10, 1), until=datetime.date(2019, 12, 1))
    desired_output = GeneralLedger(period, {account1: Ledger(account1, Balance(datetime.date(2019, 11, 1), Quantity(Decimal(1000))))})

# Generated at 2022-06-21 20:03:59.372380
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    assert str(Ledger(account = Account(name = "Bank"), initial = Balance(date = datetime.date(2020, 1, 1), value = 0))) == "Ledger(account=Account(name='Bank'), initial=Balance(date=datetime.date(2020, 1, 1), value=0))"


# Generated at 2022-06-21 20:04:10.994254
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    '''
    Demonstrates the repr of class GeneralLedger
    '''
    print('>>> test_GeneralLedger___repr__:')
    period = DateRange.of(datetime.date(2020, 1, 1), datetime.date(2020, 2, 29))
    print(repr(period))
    
    account1 = Account.objects.create(number='1012', name='Bank Kamis')
    account2 = Account.objects.create(number='1022', name='Bank LB')
    post1 = Posting(account1, Decimal('300'), datetime.date(2020, 1, 10), True, False)
    post2 = Posting(account2, Decimal('500'), datetime.date(2020, 1, 20), False, False)

# Generated at 2022-06-21 20:04:19.924832
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    from .periods import Period
    from .accounts import Account, TermAccount, AssetAccount
    from .journaling import Journal, Posting, JournalEntry
    from .warehouse import Item, Unit
    from .generic import Balance

    p = Period(datetime.date(2020, 1, 1), datetime.date(2020, 2, 28))
    a1 = TermAccount("A1", "A1")
    a2 = AssetAccount("A2", "A2")
    a3 = AssetAccount("A3", "A3")
    b1 = Balance(a1, datetime.date(2020, 2, 1), Quantity(0))
    b2 = Balance(a2, datetime.date(2020, 2, 1), Quantity(0))

# Generated at 2022-06-21 20:04:26.210727
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    print("Unit testing constructor of LedgerEntry:")
    print("Testing a sample case:")
    posting1 = Posting(datetime.date(2012, 1, 1), Quantity(Decimal(0.0)), Account("Cash"), Account("Revenue"))
    posting2 = Posting(datetime.date(2012, 2, 1), Quantity(Decimal(0.0)), Account("Revenue"), Account("Cash"))
    posting3 = Posting(datetime.date(2012, 3, 1), Quantity(Decimal(0.0)), Account("Cash"), Account("Revenue"))
    journal1 = JournalEntry(datetime.date(2012, 1, 1), "Purchase", [posting1])
    journal2 = JournalEntry(datetime.date(2012, 2, 1), "Purchase", [posting2])

# Generated at 2022-06-21 20:04:37.840867
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():

    # Arrange
    from ..fixtures import accounting
    from ..cypher.queries import compiled_open_balances_query, compiled_journal_entries_query

    # Act
    program = compile_general_ledger_program(compiled_open_balances_query, compiled_journal_entries_query)
    ledger = program(DateRange(datetime.date(2015, 1, 1), datetime.date(2015, 12, 31)))

    # Assert
    assert ledger.period == DateRange(datetime.date(2015, 1, 1), datetime.date(2015, 12, 31))
    assert "Assets:Cash:Checking" in ledger.ledgers
    assert "Assets:Cash:Savings" in ledger.ledgers
    assert "Assets:Equipment:PretendCo" in ledger.ledgers
   

# Generated at 2022-06-21 20:04:47.225624
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    entry = LedgerEntry(Ledger(Account('1'), Balance(datetime.datetime(2019, 1, 1), Quantity(Decimal(1)))), Posting(datetime.datetime(2019, 1, 1, 0, 0), Account('1'), Account('2'), Quantity(Decimal(42))), Quantity(Decimal(43)))
    entry_equal = LedgerEntry(Ledger(Account('1'), Balance(datetime.datetime(2019, 1, 1), Quantity(Decimal(1)))), Posting(datetime.datetime(2019, 1, 1, 0, 0), Account('1'), Account('2'), Quantity(Decimal(42))), Quantity(Decimal(43)))

# Generated at 2022-06-21 20:04:57.966372
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():

    dates = DateRange(since=datetime.date(year=2018, week=1), until=datetime.date(year=2019, week=4))
    accounts = {
        "Sales": Account("Sales", "Income"),
        "Cash": Account("Cash", "Assets"),
        "Debtors": Account("Debtors", "Assets"),
    }
    balances = {accounts["Sales"]: Balance(dates.since, Quantity(Decimal(0))),
                accounts["Cash"]: Balance(dates.since, Quantity(Decimal(0))),
                accounts["Debtors"]: Balance(dates.since, Quantity(Decimal(0))),
                }
    GeneralLedger(dates, balances)

# Generated at 2022-06-21 20:04:59.637422
# Unit test for constructor of class Ledger
def test_Ledger():
    account1 = Account('DE2019', 'DE', 2019, 'monthly')
    balance1 = Balance(12, 12)
    ledger1 = Ledger(account1, balance1)


# Generated at 2022-06-21 20:05:08.895487
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # Test method __call__ of class GeneralLedgerProgram
    # We will use in-memory implementations of algebras as inputs.
    import privacyidea.contrib.interledger
    from privacyidea.contrib.interledger.algebras.accounts.memory import (
        ReadAccounts,
        WriteAccounts,
    )
    from privacyidea.contrib.interledger.algebras.journaling.memory import (
        ReadJournalEntries,
        WriteJournalEntries,
        append_journal_entry,
    )
    import privacyidea.contrib.interledger.models.accounts

    accounts: Dict[Account, privacyidea.contrib.interledger.models.accounts.Account] = {}

# Generated at 2022-06-21 20:05:27.089387
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import Journal

    # Define initial balances:
    initial_balances = {
        Account("1001", "Cash"),
        Account("2001", "Inventory"),
        Account("4001", "Sales"),
        Account("5001", "Cost of Sales"),
    }

    # Define journal entries:
    journal_entries = [
        # Initial balances:
        Journal("1001", "Inventory", [Account("1001", "Cash"), Account("2001", "Inventory")]),
    ]

    # Define the period:
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

    # Build the general ledger:
    gl = build_general_ledger(period, journal_entries, initial_balances)

    assert gl.period == period
    assert gl

# Generated at 2022-06-21 20:05:33.774345
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    """
    Test function for class GeneralLedgerProgram
    """
    period = DateRange(datetime.date(1,1,1), datetime.date(1,1,1))
    initial_balances = {Account(0): Balance(datetime.date(1,1,1), 0)}
    journal_entries = [JournalEntry(datetime.date(1,1,1), "", [])]

    assert build_general_ledger(period, journal_entries, initial_balances) == compile_general_ledger_program(
        lambda p: initial_balances, lambda p: journal_entries)(period)

# Generated at 2022-06-21 20:05:38.013121
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import AccountId, AccountType

    from ..commons.algebras import (
        mock_algebra,
        mock_instance,
    )
    from ..commons.zeitgeist import MockDateRange

    account_type: AccountType = mock_instance("account_type")
    account_id: AccountId = mock_instance("account_id")
    account: Account = mock_instance("account", account_type=account_type, account_id=account_id)
    balance: Balance = mock_instance("balance", value=Decimal("1"))

    read_initial_balances = mock_algebra("read_initial_balances", returns={account: balance})
    read_journal_entries = mock_algebra("read_journal_entries", returns=[])


# Generated at 2022-06-21 20:05:40.157102
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass


# Generated at 2022-06-21 20:05:50.703162
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    a1 = Account(1, 'a1')
    a2 = Account(2, 'a2')
    a3 = Account(3, 'a3')
    a4 = Account(4, 'a4')
    a5 = Account(5, 'a5')
    b1 = Balance(datetime.date(2019,1,1), 100)
    b2 = Balance(datetime.date(2019,1,1), 10)
    b3 = Balance(datetime.date(2019,1,1), 20)
    b4 = Balance(datetime.date(2019,1,1), 30)
    b5 = Balance(datetime.date(2019,1,1), 40)
    d1 = datetime.date(2019,1,2)
    d2 = datetime.date(2019,1,3)
    d

# Generated at 2022-06-21 20:05:57.223093
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    l = GeneralLedger(DateRange(datetime.date(2019, 6, 1), datetime.date(2019, 6, 30)), {})
    assert str(l) == 'GeneralLedger(period=DateRange(since=datetime.date(2019, 6, 1), until=datetime.date(2019, 6, 30)), ledgers={})'


# Generated at 2022-06-21 20:06:07.805148
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    import datetime
    from accounting.commons.numbers import Amount, Quantity
    from accounting.commons.zeitgeist import DateRange
    from accounting.entries.accounts import Account
    from accounting.entries.generic import Balance
    from accounting.entries.journaling import JournalEntry, Posting
    from accounting.entries.ledgers.generic import GeneralLedger, Ledger, LedgerEntry
    from decimal import Decimal
    period = DateRange(datetime.date(2019, 4, 1), datetime.date(2019, 4, 30))
    initial_balances = {Account('200'): Balance(datetime.date(2019, 4, 1), Quantity(Decimal(0)))}

# Generated at 2022-06-21 20:06:09.150768
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    pass

# Generated at 2022-06-21 20:06:13.577849
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    # Test list
    accounts = [Account(1), Account(2)]
    ledgers = [Ledger(accounts[0]), Ledger(accounts[1])]
    assert (ledgers[0] == ledgers[1]) == False
    assert ledgers[0] == ledgers[0]


# Generated at 2022-06-21 20:06:14.470096
# Unit test for method add of class Ledger
def test_Ledger_add():
    # FIXME:
    pass

# Generated at 2022-06-21 20:06:58.014168
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    # Set up
    class InitialBalancesReader:
        def __init__(self, initial_balances: InitialBalances):
            self.initial_balances = initial_balances

        def __call__(self, period: DateRange) -> InitialBalances:
            return self.initial_balances

    initial_balances = Dict[Account, Balance]()
    class_inst = InitialBalancesReader(initial_balances)

    # Exercise and Verify
    assert isinstance(class_inst, ReadInitialBalances)

    return


# Generated at 2022-06-21 20:07:09.651998
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from .ledger import LedgerEntry
    from .journaling import JournalEntry, Posting
    from .accounts import Account
    from .generic import Balance
    from datetime import datetime, timedelta
    from decimal import Decimal
    
    ledger = LedgerEntry(Ledger('account', Balance(datetime(2020,4,4), Decimal(100))),
                Posting(JournalEntry('description',datetime(2020,4,4)), 
                Account('account'), Decimal(50)))
    assert ledger.ledger.account == 'account'
    assert ledger.posting.journal.description == 'description'
    assert ledger.balance.value == Decimal(150)
    assert ledger.posting.amount == Decimal(50)
    assert ledger.date == datetime(2020, 4, 4)

# Generated at 2022-06-21 20:07:18.424216
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    from .accounts import AccountPseudo

    account = AccountPseudo("1234", "Cash")
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 31))
    initial = Balance(datetime.date(2020, 1, 1), Quantity(Decimal("1000")))
    general_ledger : GeneralLedger = GeneralLedger(period, {account: Ledger(account, initial)})

# Generated at 2022-06-21 20:07:29.141424
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    ## Create a test LedgerEntry
    our_LedgerEntry = LedgerEntry(1)
    ## Check that the test LedgerEntry has the right type
    assert isinstance(our_LedgerEntry, LedgerEntry)
    ## Check that our LedgerEntry has the right properties
    assert hasattr(our_LedgerEntry, 'ledger')
    assert hasattr(our_LedgerEntry, 'posting')
    assert hasattr(our_LedgerEntry, 'balance')
    assert hasattr(our_LedgerEntry, 'date')
    assert hasattr(our_LedgerEntry, 'description')
    assert hasattr(our_LedgerEntry, 'amount')
    assert hasattr(our_LedgerEntry, 'cntraccts')
    assert hasattr(our_LedgerEntry, 'is_debit')
    assert hasattr

# Generated at 2022-06-21 20:07:34.804488
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    from .accounting.read_journal_entries import read_journal_entries
    from .accounting.read_initial_balances import read_initial_balances
    program = compile_general_ledger_program(read_initial_balances, read_journal_entries)
    assert program


# Unit test of build_general_ledger

# Generated at 2022-06-21 20:07:35.842470
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    pass

# Generated at 2022-06-21 20:07:36.778165
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert(False)


# Generated at 2022-06-21 20:07:50.740654
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    ## Setup journal data:
    account_cash_at_bank = Account("Cash At Bank")
    account_cash_in_hand = Account("Cash In Hand")
    account_retained_earnings = Account("Retained Earnings")

    journal_a = JournalEntry(datetime.date(2018, 6, 30), "Closing Entry")
    journal_a.add_credit(account_retained_earnings, 20)
    journal_a.add_debit(account_cash_in_hand, 10)
    journal_a.add_debit(account_cash_at_bank, 10)

    journal_b = JournalEntry(datetime.date(2018, 6, 30), "Cash at Bank")
    journal_b.add_debit(account_cash_at_bank, 2)

# Generated at 2022-06-21 20:07:56.804586
# Unit test for constructor of class Ledger
def test_Ledger():
    account = Account("101", "Account Name")
    balance = Balance(datetime.date(2020,1,1), Quantity(Decimal(100000)))
    ledger = Ledger(account, balance)
    assert ledger.account.number == "101"
    assert ledger.account.name == "Account Name"
    assert ledger.initial.value == Quantity(Decimal(100000))
    assert ledger.initial.date == datetime.date(2020,1,1)
    assert len(ledger.entries) == 0


# Generated at 2022-06-21 20:08:03.231574
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():

    from .journaling import Posting, Journal

    journal_entry1 = Journal(
        date=datetime.date(2020, 1, 1),
        description="Sample journal entry 1",
        postings=[
            Posting(account=Account("123", "Sample account 1"), amount=Decimal("13.37"), direction="CREDIT")
        ],
    )

    journal_entry2 = Journal(
        date=datetime.date(2020, 1, 1),
        description="Sample journal entry 2",
        postings=[
            Posting(account=Account("234", "Sample account 2"), amount=Decimal("1234.56"), direction="DEBIT")
        ],
    )

    initial_balances = {Account("123", "Sample account 1"): Balance(datetime.date(2020, 1, 1), Decimal("10"))}

    general_led

# Generated at 2022-06-21 20:08:53.044710
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    pass


# Generated at 2022-06-21 20:08:55.320657
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    assert GeneralLedger(DateRange(datetime.date(2020, 1, 1), datetime.date(2021, 1, 1)), {})

# Generated at 2022-06-21 20:08:58.772650
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    assert repr(LedgerEntry(None, None, Quantity(Decimal(0)))) == 'LedgerEntry(ledger=None, posting=None, balance=Quantity(Decimal(\'0\')))'


# Generated at 2022-06-21 20:08:59.843727
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass


# Generated at 2022-06-21 20:09:00.846461
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    assert ReadInitialBalances


# Generated at 2022-06-21 20:09:10.140808
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    account = Account(11000, "Cash")
    entry1 = LedgerEntry(account, Posting(10000, "1/1/1999", 1000), Balance(1000))
    entry2 = LedgerEntry(account, Posting(10000, "1/1/1999", 1000), Balance(1000))
    ledger = Ledger(account, Balance(1000))
    ledger.entries = [entry1, entry2]
    lhs = Ledger(account, Balance(1000))
    lhs.entries = [entry1]
    rhs = Ledger(account, Balance(1000))
    rhs.entries = [entry2]
    assert lhs != rhs
    lhs.entries.append(entry2)
    assert lhs == rhs

# Generated at 2022-06-21 20:09:21.492888
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    """
    Tests method __repr__ of class GeneralLedger
    """
    from .journaling import Journal, PostingDirection, Posting, JournalEntry
    from .accounts import Account, AccountType
    from datetime import date
    period = DateRange(date(2020, 1, 1), date(2020, 12, 31))

    account1 = Account("1100", AccountType.ASSET, None, None)
    account2 = Account("1110", AccountType.ASSET, None, None)

    balance1 = Balance(period.until, Quantity(100))
    balance2 = Balance(period.until, Quantity(50))

    journal1 = Journal(date(2020, 5, 1), "Test Journal 1")
    journal2 = Journal(date(2020, 6, 1), "Test Journal 2")


# Generated at 2022-06-21 20:09:30.575977
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from .journaling import ReadJournalEntries, JournalEntry

    # Test ledger entry
    test_le = LedgerEntry(None, None, None)

    assert test_le.ledger == None
    assert test_le.posting == None
    assert test_le.balance == None
    assert test_le.date == None
    assert test_le.description == None
    assert test_le.amount == None
    assert test_le.cntraccts == []
    assert test_le.is_debit == False
    assert test_le.is_credit == False
    assert test_le.debit == None
    assert test_le.credit == None

    # Test Ledger entry additional
    test_le_additional = LedgerEntry(1, 2, 3)

    assert test_le_additional.ledger == 1


# Generated at 2022-06-21 20:09:37.076748
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    a = LedgerEntry(Ledger(Account("A"), Balance(datetime.date(2020, 1, 1), Quantity(Decimal(10)))), Posting(Decimal(1), datetime.date(2020, 1, 1), JournalEntry("Test", None, [Account("A"), Account("B")]), 1), Quantity(Decimal(10)))
    b = LedgerEntry(Ledger(Account("A"), Balance(datetime.date(2020, 1, 1), Quantity(Decimal(10)))), Posting(Decimal(1), datetime.date(2020, 1, 1), JournalEntry("Test", None, [Account("A"), Account("B")]), 1), Quantity(Decimal(10)))
    assert a == b


# Generated at 2022-06-21 20:09:48.681391
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    a1 = Account("a1", "1st account")
    a2 = Account("a2", "2nd account")

    a1_balance = Balance(datetime.date(2020, 9, 30), Quantity(Decimal(100)))

    a1_ledger = Ledger(a1, a1_balance)

    a_ledger = GeneralLedger(DateRange(datetime.date(2020, 9, 30), datetime.date(2020, 10, 7)), {"a1": a1_ledger, "a2": a2})

    assert a_ledger.period == DateRange(datetime.date(2020, 9, 30), datetime.date(2020, 10, 7))
    assert a_ledger.ledgers["a1"] == a1_ledger
