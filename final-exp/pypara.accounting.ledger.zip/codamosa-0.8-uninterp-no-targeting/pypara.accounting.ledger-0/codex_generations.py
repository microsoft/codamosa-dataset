

# Generated at 2022-06-21 20:01:23.994295
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    ## Mock read initial balances:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        from ..commons.numbers import Amount

        return {
            1: Balance(period.since, Amount(1000)),
            2: Balance(period.since, Amount(2000)),
            3: Balance(period.since, Amount(3000)),
        }

    ## Mock read journal entries:
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry]:
        from .journaling import Journal, Posting, PostingDirection, PostingType


# Generated at 2022-06-21 20:01:36.077639
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    # Given some initial balances as of the end of previous financial period
    initial_balances = {}
    
    # And some journal entries concerning current financial period
    journal_entries = []
    
    # When I compile a program that consumes opening and closing dates and produces a general ledger
    general_ledger_program = compile_general_ledger_program(
        lambda _period: initial_balances, lambda _period: journal_entries)
    
    # Then I can execute the program with current financial period to get a general ledger
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))
    general_ledger = general_ledger_program(period)
    
    # And the general ledger has current accounting period
    assert general_ledger.period == period

# Generated at 2022-06-21 20:01:38.119675
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    """
    Tests constructor of class ReadInitialBalances.
    """
    print(help(ReadInitialBalances))

# Generated at 2022-06-21 20:01:42.910575
# Unit test for constructor of class Ledger
def test_Ledger():
    account = Account(str(4546546), str(myac))

# Generated at 2022-06-21 20:01:47.066073
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    assert repr(LedgerEntry(None, Posting(None, None, None, "name", datetime.date.today(), None, False), Quantity(0))) == "<LedgerEntry: 'name'>"

# Generated at 2022-06-21 20:01:58.864041
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    @dataclass
    class InitialBalancesAlgebraStub:
        def __call__(self, period: DateRange) -> InitialBalances:
            return {
                Account.ASSETS: Balance(period.since, Quantity(Decimal(2000))),
                Account.LIABILITIES: Balance(period.since, Quantity(Decimal(1000))),
                Account.EQUITY: Balance(period.since, Quantity(Decimal(1000))),
            }


# Generated at 2022-06-21 20:01:59.450203
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    pass

# Generated at 2022-06-21 20:02:06.578856
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    from .accounts import Account, AccountType
    from .journaling import Journal, NewJournal
    j = Journal(NewJournal(
        date=datetime.date(2020, 5, 15),
        desc='Test Test',
        postings=[
            Posting(debit=Account(name='Account1', type=AccountType.ASSETS), credit=Account(name='Account2', type=AccountType.EXPENSE), amount=1000, ccy='EUR'),
            Posting(debit=Account(name='Account1', type=AccountType.ASSETS), credit=Account(name='Account2', type=AccountType.EXPENSE), amount=1000, ccy='EUR')
        ]
    ))

# Generated at 2022-06-21 20:02:14.488762
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    account = Account('1000', 'Cash')
    posting = Posting(Decimal(100), 'D', account, journal_entries=[])
    posting.journal_entries.append(JournalEntry(datetime.date(2020, 1, 1), posting, 'Test Journal Entry'))
    e1 = LedgerEntry(Ledger(account, Balance(datetime.date(2020, 1, 1), Decimal(100))), posting, Decimal(200))
    e2 = LedgerEntry(Ledger(account, Balance(datetime.date(2020, 1, 1), Decimal(100))), posting, Decimal(200))
    assert e1 == e2


# Generated at 2022-06-21 20:02:18.866416
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    """
    Tests the method __repr__ of class Ledger.
    """
    # Initialize a ledger
    ledger = Ledger(Account("1234", "Sales"), Balance(datetime.date(2018, 1, 4), Quantity(Decimal(35000))))

    # Test __repr__ method
    assert repr(ledger) == "<Ledger 1234 Sales: Balance(date=2018-01-04, value=Decimal('35000'))>"

# Generated at 2022-06-21 20:02:28.876048
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    assert GeneralLedger([], [])

# Generated at 2022-06-21 20:02:35.550874
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    # Given
    _account = Account("560360")
    initial = Balance(datetime.date(2020, 1, 1), Quantity(Decimal(100)))
    _ledger = Ledger(_account, initial)

    # When
    actual = _ledger.__repr__()

    # Then
    assert actual == "Ledger(Account(name='560360'), Balance(date=datetime.date(2020, 1, 1), value=100))"


# Generated at 2022-06-21 20:02:45.306313
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.test import Payee, account_code
    from ..commons.zeitgeist import Today

    # Account
    code=account_code("1.01")
    account = Account(code, "Smoke Shop", "Income")

    # Ledger
    balance = Balance(Today.prev(days=60), Quantity(Decimal(1000.00)))
    ledger = Ledger(account, balance)

    # Posting
    date = Today.prev(days=5)
    Payee("Wizard Weed")
    credit = Account("1.02", "Smoke Shop", "Assets")
    debit = Account("2.01", "Cash", "Assets")
    posting = Posting(date, debit, credit, Quantity(Decimal(10.00)))

# Generated at 2022-06-21 20:02:58.565005
# Unit test for method add of class Ledger
def test_Ledger_add():
    new_posting = Posting(date=datetime.date(2018,1,1), account=Account("1"), amount=Decimal(5), direction=0)
    new_posting1 = Posting(date=datetime.date(2018,1,2), account=Account("1"), amount=Decimal(5), direction=0)
    new_posting2 = Posting(date=datetime.date(2018,1,3), account=Account("1"), amount=Decimal(5), direction=1)

    new_ledger = Ledger(account=Account("1"), initial=Balance(date=datetime.date(2017,12,31), value=Decimal(0)))
    new_ledger.add(new_posting)
    new_ledger.add(new_posting1)

# Generated at 2022-06-21 20:03:03.433339
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    # create a class to test
    class Test:
        period = DateRange(datetime.date(2019, 9, 1), datetime.date(2019, 9, 30))

        test_GeneralLedger = GeneralLedger(period, {})


    # test GeneralLedger
    test = Test()



# Generated at 2022-06-21 20:03:04.851963
# Unit test for function build_general_ledger
def test_build_general_ledger():
    pass

# Generated at 2022-06-21 20:03:12.694777
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import Journal, Posting, JournalEntry

    from ..commons.zeitgeist import Date, DateRange
    from .accounts import Account, AccountGroup, TerminalAccount

    assets = AccountGroup(
        name='Assets',
        direct=Account.Direction.DEBIT,
        accounts=[
            TerminalAccount(
                name='Cash',
                group=Account.Group.CURRENT,
                code='1000',
            ),
            TerminalAccount(
                name='Bank',
                group=Account.Group.CURRENT,
                code='1100',
            ),
        ]
    )


# Generated at 2022-06-21 20:03:24.825387
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    from ..commons.journaling import buy
    from .accounts import AccountId

    A1 = Account("A1", AccountId("A1"))
    A2 = Account("A2", AccountId("A2"))
    A3 = Account("A3", AccountId("A3"))

    L = Ledger(A1, Balance(None, Quantity(Decimal(0))))

    E = L.add(Posting(buy("", [A1], [A2, A3], Amount(Decimal(123.45))), 1))

# Generated at 2022-06-21 20:03:27.854653
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():

    # Imports;
    import doctest

    ## Test method __repr__ of class GeneralLedger
    doctest.testmod(verbose=True)

# Generated at 2022-06-21 20:03:38.639219
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    """
    Tests _repr__ method of GeneralLedger
    """
    # Setup test data
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 1, 31))
    entries = []
    accounts = []
    ledgers = []
    data = {}
    i = 0
    while i < 1000:
        i = i + 1
        acc_id = "Acc" + str(i)
        acc_name = "Account" + str(i)
        acc_type = "Asset"
        acc_subtype = "Current Asset"

        # Creating Account Instance
        acc = Account(acc_id, acc_name, acc_type, acc_subtype)

        # Creating Ledger Instance
        ledger_id = "1001"

# Generated at 2022-06-21 20:03:48.766160
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    pass



# Generated at 2022-06-21 20:03:55.382418
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    entry=LedgerEntry(None, Posting(None, None, Amount(1), True, None), Quantity(1))
    assert entry.posting.amount==Amount(1)
    assert entry.balance==Quantity(1)
    assert entry.date==None
    assert entry.description==None
    assert entry.amount==Amount(1)
    assert entry.cntraccts==[]
    assert entry.is_debit==True
    assert entry.is_credit==False
    assert entry.debit==Amount(1)
    assert entry.credit==None

# Generated at 2022-06-21 20:04:01.717639
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    l = Ledger(Account('400', 'account'), Balance(datetime.datetime(2000, 1, 1), Quantity(100)))
    l.add(Posting(Account('50', 'account'), Quantity(10), datetime.datetime(2000, 1, 1), 'journal entry'))
    assert isinstance(l, Ledger)
    assert isinstance(repr(l), str)
    print(repr(l))

# Generated at 2022-06-21 20:04:13.630284
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from .ids import JournalId
    from .journaling import Journal, PostingDirection
    from .accounts import AccountId

    account = AccountId("1")
    journal_id = JournalId("hola")
    journal = Journal(journal_id, None, None, None, None, None)
    posting = Posting(journal, None, PostingDirection.Credit, None)

    ledger = Ledger(account, None)

    entry = LedgerEntry(ledger, posting, Quantity(1))

    assert entry.amount.value == 1
    assert entry.balance.value == Quantity(1)
    assert entry.description.value == "hola"
    assert entry.is_debit == False
    assert entry.is_credit == True
    assert entry.ledger.account.raw == "1"
    assert entry.posting.amount

# Generated at 2022-06-21 20:04:17.343135
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    # Since it is dataclass, constructor test is sufficient
    # Created a ledger:
    a = LedgerEntry(1, 2, 3)
    assert a.ledger == 1
    assert a.posting == 2
    assert a.balance == 3
    assert a.balance.value == 3.0


# Generated at 2022-06-21 20:04:28.821997
# Unit test for constructor of class Ledger
def test_Ledger():
    from ..commons.numbers import Amount
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import ReadJournalEntries
    from .generic import ReadInitialBalances

    account = Account(1, 'LedgerAccount01')
    initial = Balance(DateRange(datetime.date.fromisoformat('2020-01-01'), datetime.date.fromisoformat('2020-12-31')),
                      Amount(10))

# Generated at 2022-06-21 20:04:32.099386
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # TODO: Figure out how to approach unit testing of implementations of this protocol.
    #       - It may be fine for this protocol to be abstract, and its implementations only tested by integration tests.
    pass

# Generated at 2022-06-21 20:04:37.625616
# Unit test for constructor of class Ledger
def test_Ledger():
    ledger = Ledger(Account('1'), Balance(datetime.date(2019, 1, 1), Quantity(Decimal(0)) ))
    assert ledger.account == Account('1')
    assert ledger.initial.value == Quantity(Decimal(0))
    assert ledger.initial.date == datetime.date(2019, 1, 1)
    assert ledger.entries == []


# Generated at 2022-06-21 20:04:38.540816
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    pass

# Generated at 2022-06-21 20:04:39.204065
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    return read_initial_balances


# Generated at 2022-06-21 20:05:03.469850
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Tests function compile_general_ledger_program.
    """
    from datetime import date
    from enum import Enum
    from typing import List

    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting

    class Direction(Enum):
        """
        Transaction direction.
        """

        Debit = 1
        Credit = -1

    class Balance(Decimal):
        """
        Decimal with a custom __repr__() method.
        """

        def __repr__(self):
            return f"{self:,.2f}"

    class Quantity(Decimal):
        """
        Decimal with a custom __repr__() method.
        """


# Generated at 2022-06-21 20:05:14.706731
# Unit test for function build_general_ledger
def test_build_general_ledger():
    """
    Unit test for function :py:func:`build_general_ledger`.
    """
    from ..commons.zeitgeist import Date
    from .accounts import Account, AccountType, IncomeType
    from .journaling import Journal

    ## Inputs:
    period = DateRange(since=Date(year=2017, month=1, day=1), until=Date(year=2017, month=2, day=28))

# Generated at 2022-06-21 20:05:23.168137
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.numbers import Decimal
    from ..commons.zeitgeist import Date
    from .accounts import AccountType
    from .journaling import Journal
    from .posting import Direction

    # Given:
    ledger = Ledger(
        Account(AccountType.BalanceSheet, "110000", "Cash"),
        Balance(Date(1, 1, 2014), Quantity(Decimal(0))),
    )

    posting = Posting(Direction.Debit, Journal(Date(1, 1, 2014), "Cash from customer"), Quantity(Decimal(100)))

    # When:
    result = ledger.add(posting)

    # Then:
    assert result.posting == posting
    assert result.balance == Quantity(Decimal(100))

# Generated at 2022-06-21 20:05:33.155025
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    from mitra.commons.testing import load_test_accounts
    from mitra.journaling import Journal, JournalEntry, Posting
    from mitra.ledgering import GeneralLedger, Ledger, build_general_ledger, compile_general_ledger_program

    test_accounts = load_test_accounts()
    ## Define the period:
    period = DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31))

    ## Define the journal entries:

# Generated at 2022-06-21 20:05:43.762883
# Unit test for method __eq__ of class GeneralLedger

# Generated at 2022-06-21 20:05:53.083301
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    # build an Ledger
    ledger = Ledger(Account("LK0","Kasse","Cash"),Balance(datetime.date(2019, 1, 1),Quantity(Decimal(0))))
    # prepare an LedgerEntry
    url = "http://127.0.0.1:5000/api/journal_entry/1"
    posting = Posting(1, datetime.date(2019, 12, 1), True, Amount(Quantity(Decimal(100)), "EUR"), Account("RA1","Reisekosten","Travel"))
    posting.journal.url = url
    posting.journal.id = 1
    posting.journal.code = "JE1"
    posting.journal.description = "Journal Entry 1"
    posting.journal.source_id = "JE-000001"

# Generated at 2022-06-21 20:05:57.713756
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Create objects to be used in the test
    acc = Account('Asset', 'BANK', '1000')
    bal = Balance(datetime.datetime.now().date(), Quantity(Decimal(1000)))
    ledger = Ledger(acc, bal)
    j = JournalEntry(datetime.datetime.now().date(), 'Test')
    p = Posting(j, acc, Quantity(Decimal(100)))
    # Call the method to be tested
    entry = ledger.add(p)
    # Check the result
    assert entry == LedgerEntry(ledger, p, Quantity(1100))

# Generated at 2022-06-21 20:06:08.083853
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    """
    Unit test for method __eq__ of class GeneralLedger
    """
    import accounting.algebras.tests.journaling.algebra as journaling_algebra
    import accounting.algebras.tests.journaling.doubles as journaling_doubles
    import accounting.commons.zeitgeist as zeitgeist
    from accounting.domain.accounts import Account
    from accounting.domain.accounts import AccountType as AT
    from accounting.domain.charcoal import Charcoal
    from accounting.domain.journaling import Journal, Posting
    from accounting.domain.journaling import PostingDirection as PD
    from accounting.domain.journaling import ReadJournalEntries as ReadJournalEntries
    from accounting.domain.ledgers import GeneralLedger as GeneralLedger

# Generated at 2022-06-21 20:06:17.074187
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    from freezegun import freeze_time
    from datetime import datetime
    from decimal import Decimal
    from ..commons.numbers import Quantity
    from ..commons.zeitgeist import DateRange
    from ..journaling.domain.journaling_protocols import Journal
    from ..journaling.domain import JournalEntry, Posting
    from ..accounts.domain.accounting_protocols import Account
    from ..accounts.domain import AccountBalance
    from ..accounts.domain import AccountBalanceEntry
    from general_ledger.domain.general_ledger_protocols import Balance

    @dataclass
    class AccountBalance_Mock(AccountBalance):
        balance_entries: List[AccountBalanceEntry]

        def __init__(self, account: Account, balance_entries: List[AccountBalanceEntry]):
            super

# Generated at 2022-06-21 20:06:26.310882
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    from .accounts import Account, AccountType, Category

    # Given:
    account = Account(code='1112', name='Bank and Cash', type=AccountType.TERMINAL, category=Category.ASSET)
    period = DateRange(since='2019/01/01', until='2019/12/31')
    initial = Balance(period.since, Quantity(Decimal(0)))
    ledger = Ledger(account = account, initial = initial)

    # When:
    l = ledger.__repr__()

    # Then:
    assert l == f'Ledger(account={account}, initial={initial}, entries=[])'

# Generated at 2022-06-21 20:06:46.447262
# Unit test for method __eq__ of class Ledger

# Generated at 2022-06-21 20:06:47.749394
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # TODO
    pass

# Generated at 2022-06-21 20:06:56.566769
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    account = Account(code='0000', name='Account Name')
    initial = Balance(datetime.date(2020, 5, 2), Quantity(Decimal(1)))
    ledger1 = Ledger(account, initial)
    posting = Posting(datetime.date(2020, 5, 2), account, Quantity(Decimal(2)), Quantity(Decimal(3)), Journal(
            entries=[],
            date=datetime.date(2020, 5, 2),
            id='1588608900.000000',
            description='Accounting journal entry'))
    balance = Quantity(Decimal(2))
    ledger_entry1 = LedgerEntry(ledger1, posting, balance)
    ledger1.entries = [ledger_entry1]

    assert ledger1.__eq__(ledger1)

    ledger2 = Ledger(account, initial)

# Generated at 2022-06-21 20:07:04.655247
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    """
    Unit test for method __eq__ of class LedgerEntry
    """
    from .accounts import Header, Quadrature, SubAccount, TerminalAccount

    account = TerminalAccount("1110", "Kontonamn")
    posting = Posting(account, Quantity(100), datetime.date(2020, 1, 1))
    ledger = Ledger(account, Balance(datetime.date(1990, 12, 31), Quantity(0)))
    entry = LedgerEntry(ledger, posting, Quantity(100))
    assert entry == entry
    assert entry != None
    assert entry != 1
    assert entry != posting
    assert entry != ledger
    assert entry != LedgerEntry(ledger, posting, Quantity(99))
    assert entry != LedgerEntry(ledger, posting, Quantity(100))

# Generated at 2022-06-21 20:07:15.322897
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    # Test with the following inputs:
    #     period = DateRange(date(2019, 12, 24), date(2019, 12, 31))
    #     journal = []
    #     initial = {}
    # Expected output:
    #     GeneralLedger(
    #         period=DateRange(2019-12-24, 2019-12-31),
    #         ledgers={},
    #     )
    period = DateRange(datetime.date(2019, 12, 24), datetime.date(2019, 12, 31))
    journal = []
    initial = {}
    expected_object = GeneralLedger(
        period=DateRange(datetime.date(2019, 12, 24), datetime.date(2019, 12, 31)),
        ledgers={},
    )
    assert build_general_ledger(period, journal, initial)

# Generated at 2022-06-21 20:07:26.037808
# Unit test for method add of class Ledger
def test_Ledger_add():
    ## Create a new balance
    from ..trips.trips import Trip
    from .journaling import Journal, Posting
    from .accounts import Account, AccountKind, DEBIT, CREDIT
    from .commons.types import Type
    from .commons.prices import Price, PriceType
    from .commons.numbers import Amount, Quantity


    AR_ACCOUNT = Account(name="AR", kind=AccountKind.ASSET)
    AP_ACCOUNT = Account(name="AP", kind=AccountKind.ASSET)
    REVENUE_ACCOUNT = Account(name="REV", kind=AccountKind.REVENUE)
    EXPENSE_ACCOUNT = Account(name="EXP", kind=AccountKind.EXPENSE)
    price = Price(PriceType.CURRENCY, Amount(Decimal(1)))

# Generated at 2022-06-21 20:07:29.910637
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from unittest.mock import MagicMock

    mock_return_value = {"test account 1": Balance(datetime.date(2020, 1, 1), Quantity(Decimal(100))),
                         "test account 2": Balance(datetime.date(2020, 1, 1), Quantity(Decimal(300)))}

    mock_read_initial_balances = MagicMock()
    mock_read_initial_balances.__call__.return_value = mock_return_value

    assert mock_read_initial_balances() == mock_return_value


# Generated at 2022-06-21 20:07:40.807537
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    from .journaling import Journal, Direction
    from .accounts import Account
    from decimal import Decimal as D
    # Set up the LedgerEntry object
    journal = Journal(date=datetime.date(2018, 11, 1), description="String description",
                      postings=[Posting(account=Account(account='1000', name='Asset'), amount=D(100),
                                        direction=Direction.debit)])
    posting = Posting(account=Account(account='1000', name='Asset'), amount=D(100), direction=Direction.debit)
    entry = LedgerEntry(ledger=1, posting=posting, balance=D(100))
    # Set up the expected output
    output = "LedgerEntry(ledger=1, posting=Posting(account=Account(account='1000', name='Asset'), amount=Decimal('"

# Generated at 2022-06-21 20:07:46.650842
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    entry1 = LedgerEntry(None, Posting(None, None, None), Quantity(Decimal(10.0)))
    entry2 = LedgerEntry(None, Posting(None, None, None), Quantity(Decimal(10.0)))
    assert (entry1 == entry2) is True


# Generated at 2022-06-21 20:07:48.208977
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    assert LedgerEntry(1, 2, 3)

# Generated at 2022-06-21 20:08:20.129615
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
  print("test_ReadInitialBalances___call__()")
  class ReadInitialBalancesMock:
    def __call__(self, period: DateRange) -> InitialBalances:
      return {'Test Account Name': Balance(datetime.date(period.since.year,1,1), Quantity(Decimal(0)))}
  read_initial_balances = ReadInitialBalancesMock()
  read_journal_entries = ReadJournalEntriesMock()
  gl = compile_general_ledger_program(read_initial_balances, read_journal_entries)(DateRange(datetime.date(2020,1,1), datetime.date(2020,12,31)))
  print(gl)



# Generated at 2022-06-21 20:08:29.944531
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    from .journaling import PostingDirection, Journal

    account1 = Account.create('account1', "Account 1", True)
    account2 = Account.create('account2', "Account 2", True)
    account3 = Account.create('account3', "Account 3", True)
    account4 = Account.create('account4', "Account 4", True)
    account5 = Account.create('account5', "Account 5", True)
    account6 = Account.create('account6', "Account 6", True)
    account7 = Account.create('account7', "Account 7", True)
    account8 = Account.create('account8', "Account 8", True)
    account9 = Account.create('account9', "Account 9", True)


# Generated at 2022-06-21 20:08:40.113946
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Test GeneralLedgerProgram.__call__().
    """
    from .read import read_journal_entries

    ## compile_general_ledger_program takes two parameters:
    ## a function for reading initial balances, and
    ## a function for reading journal entries.

# Generated at 2022-06-21 20:08:50.167099
# Unit test for method add of class Ledger
def test_Ledger_add():
    journal = JournalEntry(datetime.date(2019, 12, 31), "", [
                Posting(Account("1.1"), "", Amount(Decimal("123")), ""),
                Posting(Account("9.9"), "", Amount(Decimal("-123")), "")
            ], "")

    initial_balances = {
        Account("1.1"): Balance(datetime.date(2019, 12, 31), Quantity(Decimal("-23"))),
        Account("9.9"): Balance(datetime.date(2019, 12, 31), Quantity(Decimal("-23")))
    }

    period = DateRange(datetime.date(2019, 12, 31))
    ledger = Ledger(Account("1.1"), initial_balances[Account("1.1")])

# Generated at 2022-06-21 20:08:55.513978
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    ledger1 = Ledger(Account('A'), Balance(datetime.date(2019, 6, 1), Quantity(Decimal(10))))
    ledger2 = Ledger(Account('A'), Balance(datetime.date(2019, 6, 1), Quantity(Decimal(10))))
    assert ledger1 == ledger2


# Generated at 2022-06-21 20:09:05.011709
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..accounts.algebra import ReadInitialBalances
    from ..journaling.algebra import ReadJournalEntries
    from ..adapters.memory import read_balances, read_journal
    import datetime
    # Create a general ledger program:
    read_initial_balances = ReadInitialBalances(
        base=read_balances, account=lambda _: True, since=lambda _: datetime.date(2020, 1, 1), until=lambda _: datetime.date(2020, 6, 30)    
    )
    read_journal_entries = ReadJournalEntries(base=read_journal)
    general_ledger_program = compile_general_ledger_program(read_initial_balances, read_journal_entries)
    # Execute the program:

# Generated at 2022-06-21 20:09:11.017538
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    # AAA test pattern
    # Arrange - Set up the objects
    ledger = Ledger(Account('23'), Balance(datetime.date.today(), Quantity(Decimal(0))))
    posting = Posting()
    balance = Quantity(Decimal(0))
    a = LedgerEntry(ledger, posting, balance)
    b = LedgerEntry(ledger, posting, balance)

    # Act - Execute the test
    actual = a.__eq__(b)

    # Assert - Verify the test result
    expected = True
    assert actual == expected


# Generated at 2022-06-21 20:09:22.100162
# Unit test for function build_general_ledger
def test_build_general_ledger():
    ## Define accounting period:
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

    ## Define pre-defined account ledgers:
    ledgers = {
        Account(100, "Cash"): Ledger(Account(100, "Cash"), Balance(
            datetime.date(2018, 12, 31), Quantity(100)
        )),
        Account(200, "Revenues"): Ledger(Account(200, "Revenues"), Balance(
            datetime.date(2018, 12, 31), Quantity(0)
        )),
    }

    ## Initialize ledgers for journal entries:

# Generated at 2022-06-21 20:09:31.200584
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    """
    test_LedgerEntry___repr__
    """

    # given
    from datetime import date
    from .journaling import JournalEntry, Posting

    account = "ACCOUNT"
    balance = 42.42

    journal_entry = JournalEntry(
        date(2020, 1, 2),
        description="BANANA",
        postings=[Posting(account, 1.00), Posting(account, -1.00)]
    )

    posting = journal_entry.postings[0]

    ledger = Ledger(account, Balance(date(2020, 1, 1), balance))
    entry = LedgerEntry(ledger, posting, balance + 1.00)

    # when
    result = entry.__repr__()

    # then

# Generated at 2022-06-21 20:09:32.206292
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    pass



# Generated at 2022-06-21 20:10:32.925609
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    pass

# Generated at 2022-06-21 20:10:43.348192
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import JournalEntry, Posting
    from .accounts import Account
    from .generic import ReadJournalEntries, Balance
    from .ledgering import GeneralLedger, Ledger

    from ..commons.zeitgeist import DateRange

    from datetime import date
    from typing import Dict

    from decimal import Decimal, ROUND_HALF_UP

    def _round(amount):
        return amount.quantize(Decimal("0.01"), ROUND_HALF_UP)

    A = Account("A")
    B = Account("B")
    C = Account("C")
    D = Account("D")
    E = Account("E")


# Generated at 2022-06-21 20:10:49.859066
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    # Get the module:
    from ledgers import algebras, general_ledger

    # Build the program:
    build_general_ledger = general_ledger.compile_general_ledger_program(
        read_initial_balances=algebras.get_balance_at,
        read_journal_entries=algebras.read_journal_entries,
    )

    # Build the initial balances to be used in tests:
    initial_balances = {
        algebras.accounts.BALANCE_SHEET.current_liabilities.accounts_payable.trade: algebras.Balance(
            datetime.date(2019, 1, 1), 100
        )
    }

    # Build the general ledger:

# Generated at 2022-06-21 20:10:51.077424
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    pass


# Generated at 2022-06-21 20:10:59.830632
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    assert repr(LedgerEntry(Ledger(Account("1000"), Balance("2020-01-01", Quantity(Decimal("100.00")))),
                            Posting("2020-01-01", "Description", Quantity(Decimal("10.00")), 1, Account("2000")),
                            Quantity(Decimal("100.00")))) == "LedgerEntry(ledger=Ledger(account=Account('1000'), initial=Balance(date=datetime.date(2020, 1, 1), value=Decimal('100.00'))), posting=Posting(date=datetime.date(2020, 1, 1), description='Description', amount=Decimal('10.00'), direction=1, account=Account('2000')), balance=Decimal('100.00'))"


# Generated at 2022-06-21 20:11:06.839414
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    input_value = LedgerEntry(None, Posting(Journal(datetime.date(2019, 1, 1), "Test"), None, Amount(10)), None)
    expected_value = "LedgerEntry(ledger=None, posting=Posting(journal=Journal(date=datetime.date(2019, 1, 1), description='Test'), account=None, amount=Amount(value=10)), balance=None)"
    actual_value = repr(input_value)
    assert expected_value == actual_value
