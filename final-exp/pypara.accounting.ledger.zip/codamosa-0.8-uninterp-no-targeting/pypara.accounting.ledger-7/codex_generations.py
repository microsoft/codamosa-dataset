

# Generated at 2022-06-21 20:01:26.509914
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    gl = GeneralLedger(
    period = DateRange(1,1,1,12,31,9999),
    ledgers = {"account1": Ledger(account = "account1", initial = Balance(date = datetime.datetime.today(), value = Quantity(10000))),
               "account2": Ledger(account = "account2", initial = Balance(date = datetime.datetime.today(), value = Quantity(20))),
               "account3": Ledger(account = "account3", initial = Balance(date = datetime.datetime.today(), value = Quantity(-10)))})
    assert gl.period == DateRange(1,1,1,12,31,9999)
    assert gl.ledgers["account1"].account == "account1"
    assert gl.ledgers["account1"].initial.value == Quantity(10000)
   

# Generated at 2022-06-21 20:01:27.261635
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    pass

# Generated at 2022-06-21 20:01:37.870881
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    import datetime
    from .accounts import Account, AccountKind
    from .journaling import JournalEntry, Posting
    GENERALLEDGER_INSTANCE = None

# Generated at 2022-06-21 20:01:39.355703
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():

    entry = LedgerEntry("a", "b", "c")


# Generated at 2022-06-21 20:01:43.886176
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    """
    Unit test for method __repr__ of class LedgerEntry
    """
    ledger_entry = LedgerEntry(ledger="ledger", posting="posting", balance="balance")
    result = "LedgerEntry(ledger=ledger, posting=posting, balance=balance)"
    assert result == ledger_entry.__repr__()

# Generated at 2022-06-21 20:01:46.222968
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    # TODO: implement this test
    assert True == False


# Generated at 2022-06-21 20:01:58.040229
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    #: Sample initial balances:
    mock_initial_balances = InitialBalances({Account("ASSETS", "CASH"): Balance(None, Quantity(Decimal(100)))})

    #: Sample accounting period:
    mock_period = DateRange(datetime.date(2020, 12, 1), datetime.date(2020, 12, 31))

    #: A mock implementation of the algebra.
    mock_initial_balances_algebra = lambda period: mock_initial_balances

    #: A mock protocol instance.
    r_initial_balances: ReadInitialBalances = mock_initial_balances_algebra

    # Compile program:
    program = compile_general_ledger_program(r_initial_balances, lambda _: [])

    # Execute program:
    general_ledger = program(mock_period)



# Generated at 2022-06-21 20:02:05.842258
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    from ..functools import hash
    from .accounts import AccountInfo
    from .journaling import Journal

    account = Account(AccountInfo("Account", "Desc.", "1"), 0)

    posting = Posting(Journal(
        datetime.date(2020, 1, 1),
        "Description",
        [
            Posting(None, datetime.date(2020, 1, 1), account, Amount(1)),
            Posting(None, datetime.date(2020, 1, 1), account, Amount(-1))
        ]
    ),
        datetime.date(2020, 1, 1), account, Amount(1)
    )

    ledger = Ledger(account, None)
    ledger2 = Ledger(account, None)
    ledger.add(posting)
    ledger2.add(posting)

    # ledger_entry and

# Generated at 2022-06-21 20:02:06.468361
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    assert True

# Generated at 2022-06-21 20:02:18.387402
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    @dataclass
    class MockReadInitialBalances(Protocol):
        """
        Type of functions which reads and returns initial balances.
        """

        def __call__(self, period: DateRange) -> InitialBalances:
            pass

    def mock_read_initial_balances(self, period: DateRange) -> InitialBalances:
        pass

    mock_read_initial_balances.__name__ = "mock_read_initial_balances"
    mock_read_initial_balances.__qualname__ = "mock_read_initial_balances"
    mock_read_initial_balances.__doc__ = "mock_read_initial_balances"
    mock_read_initial_balances.__module__ = "mock_read_initial_balances"
    mock_read_initial_balances

# Generated at 2022-06-21 20:02:34.091498
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .journaling import Posting, Journal, JournalEntry
    from .accounts import Account
    from datetime import date
    from .generic import Balance
    
    #: Defines a generic type variable.
    _T = TypeVar("_T")

    #: Initial balances:
    InitialBalances: Dict[Account, Balance[_T]]

    #: Accounting period.
    period: DateRange[_T]

    #: Individual account ledgers of the general ledger.
    ledgers: Dict[Account, Ledger[_T]]

    account = Account('Assets', 'Bank')
    amount = 1000

    entry = Posting('code','description', amount, account, True,  '2020-05-09' )

    journal = Journal('description','description', [entry])

    entry = JournalEntry([journal], 'description','description')

    #ent

# Generated at 2022-06-21 20:02:35.593115
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    pass


# Generated at 2022-06-21 20:02:45.543722
# Unit test for method __eq__ of class Ledger

# Generated at 2022-06-21 20:02:58.826054
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    """
    This test includes the functionality of the constructor of GeneralLedgerProgram.
    """
    # construct a program
    def read_initial_balances(period):
        initial_balances = {
            Account("Test1"): Balance(datetime.date(2016, 2, 1), Quantity(Decimal(100))),
            Account("Test2"): Balance(datetime.date(2016, 2, 1), Quantity(Decimal(100))),
        }
        return initial_balances

    journal1 = JournalEntry(
        datetime.date(2016, 2, 1),
        "Test",
        [
            Posting(Account("Test1"), Decimal(100), Direction.DEBIT),
            Posting(Account("Test2"), Decimal(100), Direction.CREDIT),
        ],
    )


# Generated at 2022-06-21 20:03:04.902378
# Unit test for constructor of class Ledger
def test_Ledger():
    account = Account("1110", "Cash", None)
    initial = Balance(datetime.date(2019, 3, 31), Quantity(50))

    ledger = Ledger(account, initial)

    assert ledger.account == account
    assert ledger.initial == initial
    assert len(ledger.entries) == 0


# Generated at 2022-06-21 20:03:06.022363
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    pass


# Generated at 2022-06-21 20:03:10.891876
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    @dataclass
    class FakeReadInitialBalances(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances: ...

    assert isinstance(FakeReadInitialBalances(), ReadInitialBalances)


# Generated at 2022-06-21 20:03:16.390127
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    assert compile_general_ledger_program(lambda period: {}, lambda period: [])(DateRange(datetime.date(2000, 1, 1), datetime.date(2000, 1, 31))) == GeneralLedger(DateRange(datetime.date(2000, 1, 1), datetime.date(2000, 1, 31)), {})

# Generated at 2022-06-21 20:03:21.380613
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    assert LedgerEntry(1, 2) != 3
    assert LedgerEntry(1, 2) == LedgerEntry(1, 2)
    assert LedgerEntry(1, 2) != LedgerEntry(1, 3)
    assert LedgerEntry(1, 2) != LedgerEntry(3, 2)



# Generated at 2022-06-21 20:03:26.755854
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    @dataclass
    class _MockReadInitialBalances:
        def __call__(self, period: DateRange) -> InitialBalances:
            pass

    assert ReadInitialBalances.__args__ == (_MockReadInitialBalances.__call__.__args__,)



# Generated at 2022-06-21 20:03:34.644571
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    # Create a LedgerEntry
    ledger = Ledger("doesnt matter", Balance("dont", "need"))
    posting = Posting("it", Amount("1.00"), Account("isn't"), "going", "to", "work", "anyway")
    balance = Quantity("1.00")
    entry1 = LedgerEntry(ledger, posting, balance)
    entry2 = LedgerEntry(ledger, posting, balance)
    assert entry1.__eq__(entry2)

# Generated at 2022-06-21 20:03:41.671392
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .accounts import Account, AccountFactory
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    ## Defines accounts factory:
    factory = AccountFactory()

    ## Setup accounts of the ledger:
    gl_account = factory.get(1201, "GL Account")
    bank_account = factory.get(1101, "Bank Account")

    ## Setup account of the initial balance:
    cash_account = factory.get(1111, "Cash Account")

    ## Setup initial balance:
    initial_balance = Balance(datetime.date(2019, 1, 1), Quantity(1000))

    ## Setup journal entries:
    journal_entry1 = JournalEntry(datetime.date(2019, 1, 2), "GL Account Debit", [Posting(gl_account, -1000)])

# Generated at 2022-06-21 20:03:42.996693
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    assert LedgerEntry
    return

# Generated at 2022-06-21 20:03:44.825215
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    assert LedgerEntry(None, None, None) == LedgerEntry(None, None, None)


# Generated at 2022-06-21 20:03:47.070646
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    """
    Test for method __call__ of class ReadInitialBalances
    """
    pass


# Generated at 2022-06-21 20:03:56.545864
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    from .generic import Balance, Quantity
    from .journaling import Posting, JournalEntry

    # Create a class with a required method like Posting
    class MockPosting:
        def __init__(self, account, amount, direction, is_credit, is_debit):
            self.account = account
            self.amount = amount
            self.direction = direction
            self.is_debit = is_debit
            self.is_credit = is_credit
        def __repr__(self):
            return "MockPosting(account={}, amount={}, direction={}, is_credit={}, is_debit={})".format(self.account, self.amount, self.direction, self.is_credit, self.is_debit)

    # Create a class with a required method like JournalEntry

# Generated at 2022-06-21 20:04:04.829264
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    l1 = Ledger('a', Balance(datetime.date('2020-01-01'), 100))
    l2 = Ledger('a', Balance(datetime.date('2020-01-01'), 100))
    l3 = Ledger('a', Balance(datetime.date('2020-01-01'), 101))
    l4 = Ledger('b', Balance(datetime.date('2020-01-01'), 100))

    assert l1 == l2
    assert l2 != l3
    assert l3 != l4
    assert l4 != l1


# Generated at 2022-06-21 20:04:08.871401
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    from ..books.base import LedgerEntry

    assert LedgerEntry.__repr__(LedgerEntry(1,2,3)) == "<LedgerEntry.__repr__ of ('1', '2', '3')>"


# Generated at 2022-06-21 20:04:10.544559
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-21 20:04:19.726735
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    @dataclass
    class TestJournalEntry:
        date: datetime.date
        description: str

    def _read_journal_entries(period: DateRange):
        journal = [
            TestJournalEntry(datetime.date(2019, 1, 3), "Opening balances"),
            TestJournalEntry(datetime.date(2019, 1, 6), "Cash purchase"),
            TestJournalEntry(datetime.date(2019, 1, 15), "Cash sale"),
        ]
        return (je for je in journal if period.since <= je.date <= period.until)

    def _read_initial_balances(period: DateRange):
        return {"Cash": Balance(datetime.date(2018, 12, 31), Quantity(Decimal(100)))}


# Generated at 2022-06-21 20:04:47.036127
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry
    from .accounts import Account, AccountType
    from ..commons.zeitgeist import DateRange
    from .reading import ReadJournalEntries, build_read_journal_entries
    from .writing import InitialBalances
    # Setup an example ledger
    account = Account(account_no=1, name='Account Example', type=AccountType.Asset)
    initial_balances = InitialBalances({account: Balance(date=datetime.date(year=2019, month=12, day=31), value=Quantity(0))})
    read_journal_entries = build_read_journal_entries(initial_balances=initial_balances)
    journal_entry = JournalEntry(date=datetime.date(year=2020, month=1, day=1), description='Journal Example', postings=[])
   

# Generated at 2022-06-21 20:04:59.064398
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    # Test with ledgers with the same data (ie same account and initial balance)
    # Test should return true
    from .accounts import Account
    from .generic import Balance
    from .journaling import Posting, JournalEntry

    account = Account(code="EXPENSES:SALARIES", name="Salaries", is_terminal=True)
    initial = Balance(date=datetime.date(2020, 6, 1), value=0)
    def make_ledgers():
        ledgers = [Ledger(account, initial)]
        ledgers.append(Ledger(account, initial))
        return ledgers
    ledgers = make_ledgers()
    assert ledgers[0] == ledgers[1]

    # Test with ledgers with different data (ie different initial balance)
    # Test should return false

# Generated at 2022-06-21 20:05:02.253816
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    assert repr(Ledger(None, None)) == "Ledger(account=None, initial=None, entries=[]"


# Generated at 2022-06-21 20:05:10.107360
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    print("GeneralLedgerProgram")
    from .algebra import ReadInitialBalances, ReadJournalEntries
    from .journaling import from_simple_postings, JournalEntry, Posting, PostingDirection
    from .accounts import AccountType
    from .generic import Balance
    from .commons.numbers import Amount
    initial = {
        Account(AccountType.Revenue, 'Sales'): Balance(1, Amount(100)),
        Account(AccountType.Expense, 'Wages'): Balance(1, Amount(20)),
    }

# Generated at 2022-06-21 20:05:15.848899
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from dataclasses import asdict
    from typing import Any
    from datetime import date

    # Define an algebra
    @dataclass
    class Algebra:
        def __call__(self, period: DateRange) -> Iterable[Any]:
            pass

    # Define initial balance factory
    read_initial_balances: ReadInitialBalances = Algebra()
    # Define journal entry factory
    read_journal_entries: ReadJournalEntries = Algebra()

    # Compile GeneralLedgerProgram
    func = compile_general_ledger_program(read_initial_balances, read_journal_entries)

    # Compile GeneralLedgerProgram with TypeAlias
    func: GeneralLedgerProgram = compile_general_ledger_program(read_initial_balances, read_journal_entries)

    # Assert func

# Generated at 2022-06-21 20:05:28.205129
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    """
    Test the method __eq__ of class GeneralLedger
    """

    from .accounts import Account, Asset, Liability, Equity, Income, Cost, Expense, Revenue

    ## Define account categories:
    CASH = Asset("CASH")
    BANK = Asset("BANK")
    VENDOR = Liability("VENDOR")
    CUSTOMER = Liability("CUSTOMER")
    CAPITAL = Equity("CAPITAL")
    MISC_INCOME = Income("MISC_INCOME")
    MISC_EXPENSE = Expense("MISC_EXPENSE")
    GROSS_PROFIT = Income("GROSS_PROFIT")
    SERVICE_REVENUE = Revenue("SERVICE_REVENUE")
    MAINTENANCE_EXPENSE = Cost("MAINTENANCE_EXPENSE")


# Generated at 2022-06-21 20:05:35.518666
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from ..accounts import Account
    from ..accounting.journaling import JournalEntry, Posting
    
    a_journal_entry = JournalEntry()
    a_posting = a_journal_entry.post(Account(), 1)
    a_balance = Balance(datetime.date.today(), 1)
    a_ledger = Ledger(Account(), a_balance, [])
    
    a_ledger_entry = LedgerEntry(a_ledger, a_posting, 1)
    
    assert(a_ledger_entry.ledger == a_ledger)
    assert(a_ledger_entry.posting == a_posting)
    assert(a_ledger_entry.balance == 1)
    assert(a_ledger_entry.date == datetime.date.today())

# Generated at 2022-06-21 20:05:44.801062
# Unit test for function compile_general_ledger_program

# Generated at 2022-06-21 20:05:54.136607
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    @dataclass
    class _Ledger:
        entries: List = field(default_factory=list)

    date = datetime.date.today()
    journal = JournalEntry(date, "Entry")
    posting = Posting(journal, Direction.CREDIT, Account("2"), Amount(Decimal(4)))
    ledger = _Ledger()
    balance = Balance(date, Quantity(Decimal(4)))
    entry = LedgerEntry(ledger, posting, balance)
    assert entry.ledger == ledger
    assert entry.posting == posting
    assert entry.balance == balance
    assert entry.date == date
    assert entry.description == "Entry"
    assert entry.amount == Amount(Decimal(4))
    assert entry.cntraccts[0] == Account("1")

# Generated at 2022-06-21 20:06:06.058553
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    from ..journals.generic import Journal, Posting
    from ..commons.zeitgeist import date_range
    from .accounts import Account


    # For creating test-data
    def ledger_object_creation_support(postings, period, initial = {}):
        journal = Journal(postings, "", period.since)
        entry = journal.postings[0]
        balance = Balance(period.since, Quantity(Decimal(0)))
        ledgerEntry = LedgerEntry(Ledger(entry.account, initial[entry.account] if entry.account in initial else balance), entry, Quantity(initial[entry.account].value) + entry.amount * entry.direction.value)
        posting = journal.postings[1]
        balance = Balance(period.since, Quantity(Decimal(0)))

# Generated at 2022-06-21 20:06:27.171857
# Unit test for constructor of class Ledger
def test_Ledger():
    account = Account(1,1,"A1", "First Account")
    balance = Balance(20, Quantity(0))
    L = Ledger(account, balance)
    assert L.account.account_no == 1
    assert L.initial.value == 0



# Generated at 2022-06-21 20:06:40.226742
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    account1 = Account("101.01")
    account2 = Account("101.02")
    account3 = Account("101.03")
    debit1 = Amount(Decimal("100.00"))
    debit2 = Amount(Decimal("200.00"))
    date1 = datetime.date(2019, 12, 25)
    date2 = datetime.date(2019, 12, 26)
    balance1 = Quantity(Decimal("100.00"))
    balance2 = Quantity(Decimal("200.00"))
    description1 = "Description 1"
    description2 = "Description 2"
    description3 = "Description 3"
    description4 = "Description 4"
    description5 = "Description 5"
    description6 = "Description 6"
    direction1 = Decimal("1")
    direction2 = Decimal("-1")
    entry1

# Generated at 2022-06-21 20:06:46.564207
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from .ledgers import JournalEntry
    from .accounts import Account

    journal_entry = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Depreciation expense for the year 2020",
        postings=[
            Posting(
                journal=journal_entry,
                account=Account.parse("60000.0000.0000"),
                direction="DR",
                amount=Amount(Decimal(120)),
            )
        ],
    )
    ledger_entry = LedgerEntry(ledger="0", posting=journal_entry.postings[0], balance=Decimal(10))
    assert ledger_entry.date == datetime.date(2020, 1, 1)
    assert ledger_entry.description == "Depreciation expense for the year 2020"
    assert ledger_entry.amount == Amount(Decimal(120))
   

# Generated at 2022-06-21 20:06:57.630879
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    from .accounts import Account
    from .commons import Date
    from .journaling import Journal, JournalEntry
    from .business import Product, Business
    from .accounting import Transaction, Budget, Record

    date_today = Date.today()
    product_red_shoes = Product.v('Red Shoes')
    account_income_others = Account(100, '100', 'Income - Others')
    account_income_credits = Account(101, '101', 'Income - Credits')
    account_income_sales = Account(102, '102', 'Income - Sales')
    account_income = Account(10, '10', 'Income')
    account_expenses = Account(20, '20', 'Expenses')
    account_expenses_depreciation = Account(201, '201', 'Expenses - Depreciation')


# Generated at 2022-06-21 20:07:09.202193
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    from .accounts import Account
    from .generic import Balance
    from .journaling import Posting
    from .parties import Party
    from .types import TypedData, TypedDataValue
    from datetime import date
    from decimal import Decimal
    from .commons.numbers import Amount


    account1 = Account("1", "Account1")
    account2 = Account("2", "Account2")
    data = TypedData([TypedDataValue(100)])
    party1 = Party("1", "Party1")
    party2 = Party("2", "Party2")
    posting1 = Posting(account1, Amount(Decimal(1)), party1, data)
    posting2 = Posting(account2, Amount(Decimal(1)), party2, data)


# Generated at 2022-06-21 20:07:11.452989
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    g = GeneralLedger("T", "A")
    assert g.period == "T"
    assert g.ledgers == "A"


# Generated at 2022-06-21 20:07:19.307410
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    @dataclass
    class MyReadInitialBalances(ReadInitialBalances): # noqa: F401
        """
        Reads initial balances.
        """

        def __call__(self, period: DateRange) -> InitialBalances:
            """
            Consumes the accounting period and returns all opening balances between the opening and closing dates in
            the period.

            :param period: Accounting period.
            :return: Opening balances.
            """
            # since the argument period is the same type as DateRange, the return value must be InitialBalances

    test = MyReadInitialBalances()
    example_period = DateRange(datetime.date(2000, 1, 1), datetime.date(2001, 1, 1))
    test(example_period)
    # No return value, so it must be None

# Generated at 2022-06-21 20:07:20.393203
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    assert ReadInitialBalances()


# Generated at 2022-06-21 20:07:27.792348
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    ledger = Ledger(Account('M1'), None)
    posting = Posting('D', Amount(10), 'Dummy journal')
    entry = LedgerEntry(ledger, posting, '10')
    assert repr(entry) == 'LedgerEntry(ledger=Ledger(account=Account(name=\'M1\'), initial=None, entries=[]), posting=Posting(direction=Direction[+], amount=Amount(value=Decimal(\'10\')), journal=JournalEntry(date=datetime.date(2020, 6, 1), description=\'Dummy journal\', postings=None)), balance=10)'


# Generated at 2022-06-21 20:07:37.023273
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():

    # Test the method __call__ of class ReadInitialBalances

    # Define a constant
    period = DateRange(datetime.date(2020, 10, 31), datetime.date(2020, 10, 31), False)

    # Set up
    obj = None

    # Invoke the method
    MethodResult = obj.__call__(period)

    # Check the result
    assert MethodResult is None

    # Define a constant
    expected = None

    # The results should be the same
    assert MethodResult == expected



# Generated at 2022-06-21 20:08:18.910222
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    ## Declare a ledger.
    ledger = Ledger(None, None)

    ## Declare a posting.
    posting = Posting(None, None, None, None)

    ## Declare a balance.
    balance = Quantity()

    ## Declare a ledger entry.
    ledger_entry = LedgerEntry(ledger, posting, balance)

    ## Assert ledger_entry is instance of LedgerEntry.
    assert isinstance(ledger_entry, LedgerEntry)

    ## Assert ledger_entry is instance of object.
    assert isinstance(ledger_entry, object)

# Generated at 2022-06-21 20:08:19.486186
# Unit test for function build_general_ledger
def test_build_general_ledger():
    pass

# Generated at 2022-06-21 20:08:22.700420
# Unit test for constructor of class Ledger
def test_Ledger():
    instance = Ledger(Account('Test Account'), Balance(datetime.date(2016, 10, 10), Quantity(Decimal(1))))
    assert instance.account == Account('Test Account')
    assert instance.initial == Balance(datetime.date(2016, 10, 10), Quantity(Decimal(1)))
    assert instance.entries == []
    

# Generated at 2022-06-21 20:08:30.894577
# Unit test for method add of class Ledger
def test_Ledger_add():
    # assume
    result = []
    Posting = dataclasses.make_dataclass('Posting', ['date', 'journal', 'account', 'direction', 'amount'])
    JournalEntry = dataclasses.make_dataclass('JournalEntry', ['postings', 'date', 'description'])
    Account = dataclasses.make_dataclass('Account', ['code', 'name'])
    Balance = dataclasses.make_dataclass('Balance', ['date', 'value'])
    DateRange = dataclasses.make_dataclass('DateRange', ['since', 'until'])
    LedgerEntry = dataclasses.make_dataclass('LedgerEntry', ['ledger', 'posting', 'balance'])

    """
    return the account type of a posting
    """

# Generated at 2022-06-21 20:08:40.731772
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import Account, AccountKind
    from .commons.types import Symbol
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .ledgers import (
        Balance,
        DateRange,
        GeneralLedger,
        InitialBalances,
        Quantity,
        ReadInitialBalances,
        build_general_ledger,
        compile_general_ledger_program,
    )

    account1 = Account(Symbol("A"), AccountKind.Asset, "A")
    account2 = Account(Symbol("B"), AccountKind.Asset, "B")
    account3 = Account(Symbol("C"), AccountKind.Liability, "C")


# Generated at 2022-06-21 20:08:50.644797
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    from .commons.money import Money
    from .journaling import Journal, Posting, PostingDirection

    a = Account(name="A", kind=None)
    b = Account(name="B", kind=None)
    p = Money(Decimal(0), "T")
    j = Journal(date=datetime.date(2018, 1, 1), description="", postings=[
        Posting(direction=PostingDirection.DEBIT, account=a, amount=p),
        Posting(direction=PostingDirection.CREDIT, account=b, amount=p),
    ])

    la = Ledger(a, Balance(datetime.date(2018, 1, 1), Quantity(Decimal(0))))
    la_entries = []

# Generated at 2022-06-21 20:09:02.073109
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    from ..persistence.memory import journal_entries
    from ..persistence.memory import initial_balances
    from . import accounts
    from . import companies
    from . import currencies
    from . import booking
    from . import journaling

    ## Define accounting period:
    period = DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31))

    ## Get the account registry:
    registry = accounts.Registry(companies.Company("test", "TST"), currencies.Currency("EUR"))

    ## Create a book for general ledger:
    book = booking.Book(registry, journaling.journal())

    ## Read general ledger from memory:

# Generated at 2022-06-21 20:09:11.496922
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from ..books.accounts import Account
    from ..books.journaling import Debit, Credit
    from ..books.generic import Money, Balance
    from ..books.journaling import JournalEntry, Posting
    from ..books.numbers import Quantity
    from ..books.commons.zeitgeist import DateRange
    from ..books.commons.numbers import Amount
    from ..books.entities import Party, BusinessEntity, Individual
    from ..books.accounts import GeneralLedgerProgram
    from ..books.general_ledger import Ledger, GeneralLedger
    from ..books.initial_balances import InitialBalancesProgram, ReadInitialBalances, ReadJournalEntries, build_initial_balances
    from .commons.zeitgeist import DateRange
    from datetime import date, datetime

# Generated at 2022-06-21 20:09:18.026953
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    entry1 = LedgerEntry(2, 3, 4)
    entry2 = LedgerEntry(3, 4, 5)
    entry3 = LedgerEntry(2, 3, 4)
    assert entry1 == entry3
    assert entry1 != entry2
    assert entry2 != entry3
    assert entry1 != 5
    assert entry2 != 5
    assert entry3 != 5


# Generated at 2022-06-21 20:09:25.554871
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    import pytest
    from dataclasses import dataclass
    from decimal import Decimal
    from datetime import date
    from ..commons.zeitgeist import DateRange
    from ..commons.numbers import Quantity
    from ..commons.algebra import MapGet
    from ..data.accounts import Account
    from ..data.journaling import JournalEntry, Posting, partition_journal_entries
    class InitialBalance:
        def __init__(self, period_end: date, balance: Quantity):
            self.period_end = period_end
            self.balance = balance
    @dataclass
    class LedgerEntryEntry(_T):
        def __init__(self, posting: Posting):
            self.posting = posting

# Generated at 2022-06-21 20:10:59.295686
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    from datetime import date
    from decimal import Decimal
    from lib.model.journaling import JournalEntry, Posting
    from lib.model.accounts import Account, AccountType
    

# Generated at 2022-06-21 20:11:09.463978
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    # Create a test account.
    test_account = Account(101, "Test Account")

    # Create a test posting.
    test_posting = Posting(
        date=datetime.date(2000, 1, 1), account=test_account, amount=Decimal(1.0), direction=Direction.DEBIT
    )

    # Create a test ledger.
    test_ledger = Ledger(test_account, Balance(datetime.date(1999, 12, 31), Quantity(Decimal(99.0))))

    # Create a test ledger entry:
    test_ledger_entry = LedgerEntry(test_ledger, test_posting, Quantity(100.0))

    # Expect a proper, human-readable string representation to be returned.