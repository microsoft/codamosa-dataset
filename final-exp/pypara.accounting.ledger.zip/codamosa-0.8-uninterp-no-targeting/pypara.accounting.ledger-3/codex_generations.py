

# Generated at 2022-06-21 20:01:23.534220
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    print(Ledger.__repr__)
    ledger = Ledger(Account(1, 2, 3), Balance(datetime.date(2020, 1, 1), Quantity(10)))
    assert repr(ledger) == "Ledger(account=Account(entity_id=1, group_id=2, id=3), initial=Balance(date=datetime.date(2020, 1, 1), value=Quantity(10, '', '')), entries=[])"


# Generated at 2022-06-21 20:01:27.194397
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    general=GeneralLedger(1,2)
    assert type(general.period)==int
    assert type(general.ledgers)==dict


# Generated at 2022-06-21 20:01:37.838318
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from .accounts import Account
    from .journaling import Posting

    @dataclass
    class Test:
        pass

    # Test-1
    a = Account.get("Assets", "Bank", "Savings")
    p = Posting(None, a, Quantity(1), "")
    l = Ledger(a, Balance(datetime.datetime.now(), Quantity(0)))
    le = LedgerEntry(l, p, Quantity(1))

    assert le.date == datetime.datetime.now()
    assert le.description == ""
    assert le.amount == Quantity(1)
    assert le.cntraccts == []
    assert le.is_debit == True
    assert le.is_credit == False
    assert le.debit == Quantity(1)
    assert le.credit == None

   

# Generated at 2022-06-21 20:01:49.006905
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    #constructor without type variable:
    post = Posting(Account(1), 1, "TEST", "TEST", Decimal(1))
    l = LedgerEntry(Ledger(Account(1), Balance(datetime.date.today(), Decimal(1))), post, Decimal(1))

# Generated at 2022-06-21 20:02:00.526075
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    a = Account('100', 'Cash')
    b = Balance(Quantity(0), '1-1-2020')
    c = Balance(Quantity(0), '1-1-2020')
    d = DateRange('1-1-2020', '1-1-2020')
    d1 = JournalEntry('1-1-2020', 'Transfer', '', [])
    p1 = Posting(d1, a, Amount(0), 0)
    lg = Ledger(a, b, [LedgerEntry(d1, p1, c)])
    ledgers = {a: lg}
    gl = GeneralLedger(d, ledgers)

# Generated at 2022-06-21 20:02:02.311131
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
	g = build_general_ledger(1,2,3)
	assert "g.__repr__() == +GeneralLedger()" == +g

# Generated at 2022-06-21 20:02:14.321859
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import Account
    from .journaling import AccountEntry, JournalEntry, Posting, build_journal_entry

    #: Number of days per month.
    MONTH_SIZE = 30

    #: Definition of the accounting period.
    PERIOD = DateRange(fromdate=datetime.date(2018, 9, 1), untildate=datetime.date(2018, 9, MONTH_SIZE))

    #: Initial balances of terminal accounts.

    INITIAL_BALANCES = {
        Account("0000"): Balance(PERIOD.since, Quantity(Decimal(0))),
        Account("1000"): Balance(PERIOD.since, Quantity(Decimal(100))),
        Account("2000"): Balance(PERIOD.since, Quantity(Decimal(-100))),
    }

    #: Definition of accounts for

# Generated at 2022-06-21 20:02:18.443270
# Unit test for constructor of class Ledger
def test_Ledger():
    """
    Test the constructor of class Ledger.
    """
    account = Account("Cash")
    initial = Balance(datetime.date(2020, 1, 1), Quantity(Decimal("10")))
    entries = []
    ledger = Ledger(account, initial,entries)
    assert ledger.account == account
    assert ledger.initial == initial
    assert ledger.entries == entries


# Generated at 2022-06-21 20:02:18.941732
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    assert True == True

# Generated at 2022-06-21 20:02:29.044082
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    """
    Unit test for method __eq__ of class LedgerEntry.
    """
    from .accounts import Accounts

    #
    # SET UP
    #

    # Jane’s checking account, US$.
    account = Accounts.jane_checking_usd

    # Jane’s paycheck for $10.00.

# Generated at 2022-06-21 20:02:44.808887
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    from ..serialization.interfaces import ReadAccountBalances, ReadAccounts
    from ..serialization.load import load_account_balances, load_accounts
    from ..serialization.serializers import csv_to_account_balances, csv_to_accounts
    from .accounts import AccountType, AccountCategory
    from .commons import Money
    from .journaling import Transaction

    for test in range(1, 2):
        ### Load risks data.
        balances = load_account_balances(
            "../sample/balances.csv",
            csv_to_account_balances,
        )

        accounts = load_accounts(
            "../sample/accounts.csv",
            csv_to_accounts,
        )
    
        ## Implicitly defines a protocol and a single implementation in an ad-

# Generated at 2022-06-21 20:02:56.980848
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    # Setup
    _input_account = Account(code="ABC", name="Test Account")
    _input_balance = Balance(date=datetime.date(year=2017, month=2, day=1), value=Quantity(Decimal(100)))
    _input_entries = []
    _expected_output = "Ledger(account=Account(code='ABC', name='Test Account'), initial=Balance(date=datetime.date(2017, 2, 1), value=Quantity(Decimal('100'))), entries=[])"

    # Exercise
    _actual_output = str(Ledger(_input_account, _input_balance, _input_entries))

    # Verify
    assert _expected_output == _actual_output



# Generated at 2022-06-21 20:03:03.547194
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    # Arrange
    ledger_entry_1 = LedgerEntry(object(), object(), object())
    ledger_entry_2 = LedgerEntry(object(), object(), object())
    # Act
    result_1 = ledger_entry_1.__eq__(ledger_entry_2)
    result_2 = ledger_entry_1.__eq__(ledger_entry_1)
    # Assert
    assert not result_1 and not result_2

# Generated at 2022-06-21 20:03:12.458103
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    def test_read_initial_balances(period: DateRange) -> InitialBalances:
        return {Account.from_string("ASSETS/CASH"): Balance(datetime.date.today(), Quantity(Decimal("100.00")))}

    def test_read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        return [
            JournalEntry(
                datetime.date.today(), "INVOICE #1", [
                    Posting(datetime.date.today(), Account.from_string("ASSETS/CASH"), Amount(Decimal("0.00")), 1),
                    Posting(datetime.date.today(), Account.from_string("REVENUE"), Amount(Decimal("100.00")), -1),
                ],
            ),
        ]

    program = compile_general_

# Generated at 2022-06-21 20:03:24.601728
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    from dataclasses import dataclass
    from decimal import Decimal
    
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account
    from .journaling import Posting
    from .generic import Balance
    from .ledgers import LedgerEntry

    ## A Posting model.
    @dataclass
    class MyPosting(Posting[None]):
        """
        A postiing model just for this unit test.
        """

    ## A MyPosting based ledger entry model.
    @dataclass
    class MyLedgerEntry(LedgerEntry[None]):
        """
        A ledger entry model just for this unit test.
        """

    ## A ledger model.

# Generated at 2022-06-21 20:03:32.527470
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():

    def read_journal_entries(period: DateRange):
        pass

    def read_initial_balances(period: DateRange):
        pass

    general_ledger_program = compile_general_ledger_program(read_initial_balances, read_journal_entries)

    assert(general_ledger_program(DateRange(datetime.date(2017, 12, 31), datetime.date(2018, 12, 31))) == None)

# Generated at 2022-06-21 20:03:40.931740
# Unit test for constructor of class Ledger
def test_Ledger():
    from .accounts import Account
    from .generic import Balance
    from .journaling import Direction, JournalEntry, Posting
    from ..commons.date import Date
    from ..commons.zeitgeist import DateRange

    # Initialize some accounts.
    a = Account("A")
    b = Account("B")
    c = Account("C")
    d = Account("D")

    # Initialize some balances.
    balance_a_0 = Balance(Date(2019, 1, 1), Quantity(0))
    balance_b_0 = Balance(Date(2019, 1, 1), Quantity(0))
    balance_c_0 = Balance(Date(2019, 1, 1), Quantity(0))
    balance_d_0 = Balance(Date(2019, 1, 1), Quantity(0))

    # Initialize some postings.
    posting_

# Generated at 2022-06-21 20:03:44.296065
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    e1 = LedgerEntry({}, {}, {})
    e2 = LedgerEntry({}, {}, {})
    assert e1 == e2


# Generated at 2022-06-21 20:03:54.837353
# Unit test for constructor of class Ledger
def test_Ledger():
    # test for an entry with a debit and a credit
    account = Account("Account 1")
    initial_balance = Balance(datetime.date.today(), Quantity(Decimal(0)))
    posting = Posting(datetime.date.today(), account, Amount(Decimal(0)), Quantity(Decimal(1)))

    journal = JournalEntry(datetime.date.today(),"test journal entry",[posting])
    class MockJournalEntries:
        def __init__(self, journal):
            self.journal = journal
        
        def __iter__(self):
            return iter([self.journal])
    
    ledgers = {}
    ledgers[account] = Ledger(account, initial_balance)
    journal_entries = MockJournalEntries(journal)

# Generated at 2022-06-21 20:04:01.298772
# Unit test for constructor of class Ledger
def test_Ledger():
    """
    Test of constructor of class Ledger
    :return:
    """
    led = Ledger(Account("A1"), Balance(datetime.date.today(), Decimal(1.23)))
    assert led.account == Account("A1")
    assert led.initial == Balance(datetime.date.today(), Decimal(1.23))
    assert led.entries == []


# Generated at 2022-06-21 20:04:31.097727
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    assert repr(
        LedgerEntry(
            Ledger(Account("100", None), Balance(None, Quantity(0))),
            Posting(Account("100", None), Amount(1), 1),
            Quantity(1),
        )
    ) == "LedgerEntry(Ledger(Account('100', None), Balance(None, Quantity(0))), Posting(Account('100', None), Amount(1), 1), Quantity(1))"

# Generated at 2022-06-21 20:04:42.312906
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    period_1 = DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 1, 31))
    period_2 = DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 2, 28))
    period_3 = DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 3, 31))
    period_4 = DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 1, 31))
    period_5 = DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 2, 28))
    period_6 = DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 3, 31))
    account_1 = Account(1)
    account_

# Generated at 2022-06-21 20:04:49.873682
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    from .accounts import Account
    from .generic import Balance
    from .journaling import Posting, JournalEntry

    acct = Account("A", "B", "C")
    opbal = Balance("2018-01-01", 1000)
    je1 = JournalEntry("A", "", "", "2018-01-02")
    p1 = Posting(je1, acct, 100, True)
    p2 = Posting(je1, acct, -100, True)
    je1.postings = [p1, p2]

    je2 = JournalEntry("B", "", "", "2018-01-03")
    p3 = Posting(je2, acct, -200, False)
    p4 = Posting(je2, acct, 200, False)

# Generated at 2022-06-21 20:05:02.567574
# Unit test for method add of class Ledger
def test_Ledger_add():
    class Journal:
        def __init__(self, date, description, postings):
            self.date = date
            self.description = description
            self.postings = postings

    def translate(x):
        if isinstance(x, str):
            return Account(x)
        elif isinstance(x, int):
            return Quantity(x)
        else:
            return x

    def build_posting(p):
        return Posting(translate(p[0]), translate(p[1]), translate(p[2]))


# Generated at 2022-06-21 20:05:09.002906
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    a = Account("1", "Test Account", "Account 1")
    b = Balance(datetime.date.today(), Quantity(Decimal(0)))
    c = DateRange(datetime.date.today(), datetime.date.today())
    d = GeneralLedger(c, {a: Ledger(a, b)})
    assert d.period == c
    assert d.ledgers == {a: Ledger(a, b)}

# Generated at 2022-06-21 20:05:19.524023
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from ..commons.numbers import Amount, Quantity
    from ..accounting.journaling import JournalEntry, Posting, PostingDirection
    from ..accounting.accounts import (
        Account,
        AccountType,
    )


# Generated at 2022-06-21 20:05:21.708539
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    assert (
        LedgerEntry.__repr__.__qualname__
        == "LedgerEntry.__repr__"
    )


# Generated at 2022-06-21 20:05:32.023873
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    ## Define a type of general ledger entry:
    @dataclass
    class GLJournalEntry:
        """
        General ledger journal entry.
        """

        #: Date of the journal entry.
        date: datetime.date

        #: Description of the journal entry.
        description: str

        #: Postings of the journal entry.
        postings: List[Posting[str]]

    def _test_initial(period: DateRange) -> InitialBalances:
        return {
            "A": Balance(period.since, Quantity(Decimal(100))),
            "B": Balance(period.since, Quantity(Decimal(0))),
        }


# Generated at 2022-06-21 20:05:43.161244
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    g = GeneralLedger(DateRange(datetime.date(1,1,1), datetime.date(2,2,2)),
                      dict({Account('A', '01'): Ledger(Account('A', '01'), Balance(datetime.date(1,1,1), Quantity(1))),
                            Account('B', '02'): Ledger(Account('B', '02'), Balance(datetime.date(1,1,1), Quantity(2)))}))
    assert str(g.period) == '0001-01-01/0002-02-02'
    assert str(g.ledgers[Account('A', '01')].account) == 'A 01'
    assert str(g.ledgers[Account('A', '01')].initial) == '1.00'

# Generated at 2022-06-21 20:05:52.843981
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    @dataclass
    class DummyBalance(Balance):
        pass

    @dataclass
    class DummyJournalEntry(JournalEntry):
        pass

    @dataclass
    class DummyPosting(Posting):
        pass

    @dataclass
    class DummyAccount(Account):
        pass

    @dataclass
    class DummyLedger(Ledger):
        pass

    @dataclass
    class DummyLedgerEntry(LedgerEntry):
        pass

    @dataclass
    class DummyGeneralLeger(LedgerEntry):
        pass

    def _read_initial_balances(period: DateRange) -> InitialBalances:
        initial_balances = {}
        return initial_balances


# Generated at 2022-06-21 20:06:17.008312
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..storage.ram import Ram
    from . import data

    # Initialize ledger store:
    storage = Ram()

    # Provision data:
    storage.provision(data.Accounts)
    storage.provision(data.InitialBalances)
    storage.provision(data.JournalEntries)

    # Read initial balances:
    read_initial_balances = storage.read_initial_balances

    # Read journal entries:
    read_journal_entries = storage.read_journal_entries

    # Build general ledger program:
    program = compile_general_ledger_program(read_initial_balances, read_journal_entries)

    # Generate general ledger:
    ledger: GeneralLedger[data.JournalEntry] = program(data.Period)

    # Assertions:
    assert ledger.period == data

# Generated at 2022-06-21 20:06:17.605764
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    pass

# Generated at 2022-06-21 20:06:23.274138
# Unit test for constructor of class Ledger
def test_Ledger():
    # Test 1: Create a instance of class Ledger without fail
    print("\nTest 1: Create a instance of class Ledger without fail")
    account = Account("Main", "Main Account")
    ledger = Ledger(account, Balance(datetime.date(2020, 1, 1), 100))
    assert isinstance(ledger, Ledger)


# Generated at 2022-06-21 20:06:28.184237
# Unit test for constructor of class Ledger
def test_Ledger():
    a = Account(123, 'Account', 'Account', True, True)
    b = Balance(datetime.date(2000, 4, 17), Quantity(Decimal(5)))
    lgr = Ledger(a,b)
    assert lgr._last_balance == 5
    assert lgr.entries == []
    assert lgr.initial == b

# Generated at 2022-06-21 20:06:36.799388
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.test.test_zeitgeist import today
    from .journaling import build_journal
    from .accounts import (
        Cash,
        OfficeEquipments,
        Purchases,
        RetainedEarnings,
        SalesRevenue,
        SalesReturnsAndAllowances,
        Supplies,
        WagesExpense,
    )

    ## Journal:

# Generated at 2022-06-21 20:06:45.333552
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    from .commons.money import Currency
    from .journaling import Posting
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))


# Generated at 2022-06-21 20:06:57.259785
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    test_LedgerEntry = LedgerEntry(Ledger("0000", Balance(datetime.date(2018,1,1), Quantity(0))),
                                   Posting("", datetime.date(2018,1,1), Account(""), "", "","","", 1, Amount(1)),
                                   Quantity(0))
    assert repr(test_LedgerEntry) == "LedgerEntry(" \
                                     "ledger=Ledger(" \
                                                 "account=Account(" \
                                                 "number='0000'" \
                                                 "), " \
                                                 "initial=Balance(" \
                                                        "date=datetime.date(2018, 1, 1)," \
                                                        "value=Quantity(" \
                                                                "value=Decimal('0')" \
                                                                ")" \
                                                        ")"

# Generated at 2022-06-21 20:07:09.105154
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    test_DateRange = DateRange(datetime.date(2016, 1, 1), datetime.date(2016, 1, 10))
    test_initial_balances = dict()
    test_posting1 = Posting(datetime.date(2016, 1, 1), 5, 1, 'test01')
    test_posting2 = Posting(datetime.date(2016, 1, 1), 10, 2, 'test02')
    test_posting3 = Posting(datetime.date(2016, 1, 1), 15, 3, 'test03')
    test_postings = [test_posting1, test_posting2, test_posting3]
    test_journal = JournalEntry(datetime.date(2016, 1, 1), test_postings, 'testjournal')

# Generated at 2022-06-21 20:07:18.103308
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import now

    account = Account(code="TEST", name="Test Account")
    ledger = Ledger(account, Balance(now(), "0"))

    posting = Posting(account, now(), "Test Posting", "0")

    entry = ledger.add(posting)

    assert(ledger.entries == [entry])

    assert(entry.ledger == ledger)
    assert(entry.posting == posting)
    assert(entry.balance == "0")
    assert(entry.date == now())
    assert(entry.description == "Test Posting")
    assert(entry.amount == "0")
    assert(entry.cntraccts == [])
    assert(entry.is_debit == False)
    assert(entry.is_credit == False)

# Generated at 2022-06-21 20:07:25.404202
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    # == Arrange ==
    account = Account("Assets", "Cash")
    L = Ledger(account, Balance("2018-01-01", Quantity(100)))
    entry = LedgerEntry(L, Posting("2018-01-01", Account("Assets", "Cash"), Account("Income", "Salary"), Amount(100), True), Quantity(200))
    L.add(entry)
    # == Act ==
    x = L.__repr__()
    # == Assert ==
    print(x)


# Generated at 2022-06-21 20:07:54.247764
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    pass

# Generated at 2022-06-21 20:07:55.666818
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    Call = GeneralLedgerProgram[1]
    assert isinstance(GeneralLedger,type)

# Generated at 2022-06-21 20:07:59.203323
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    account = Account(code="code", type="type", name="name")
    balance = Balance(date=Decimal(0).date(), value=Quantity(Decimal(0)))
    ledger1 = Ledger(account, balance)
    ledger2 = Ledger(account, balance)
    assert ledger1.__eq__(ledger2) == True


# Generated at 2022-06-21 20:08:11.569613
# Unit test for function build_general_ledger
def test_build_general_ledger():
    account = Account("CASH")
    initial = {account: Balance("2017-01-01", Quantity(100))}
    journal = [
        JournalEntry("2017-01-02", "Payment from client A", [Posting("2017-01-02", account, Quantity(-50), "Debit")]),
        JournalEntry("2017-01-03", "Payment from client B", [Posting("2017-01-03", account, Quantity(-100), "Debit")]),
        JournalEntry("2017-01-04", "Payment from client C", [Posting("2017-01-04", account, Quantity(-150), "Debit")]),
        JournalEntry("2017-01-05", "Withdrawal", [Posting("2017-01-05", account, Quantity(-300), "Debit")]),
    ]

# Generated at 2022-06-21 20:08:18.213834
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    """
    Unit test for constructor of class GeneralLedgerProgram
    """
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {period.since : Balance(period.since, Quantity(Decimal(0)))}

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        return [period.since]
    # test for the compile_general_ledger_program
    # Should return a function
    assert callable(compile_general_ledger_program(read_initial_balances, read_journal_entries))



# Generated at 2022-06-21 20:08:22.778371
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    def read_initial_balances(period):
        return {a: Balance(period.since, Quantity(Decimal(0))) for a in range(20)}
    assert isinstance(read_initial_balances, ReadInitialBalances)

## Unit test for constructor of class GeneralLedgerProgram

# Generated at 2022-06-21 20:08:29.042960
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    # Arrange
    period = DateRange(datetime.date(2017, 12, 1), datetime.date(2017, 12, 31))
    journal: Iterable[JournalEntry[str]] = []
    initial: InitialBalances = {}
    generalLedger1 = GeneralLedger(period, initial)
    generalLedger2 = GeneralLedger(period, initial)

    # Act
    result = generalLedger1 == generalLedger2
    # Assert
    assert result == True


# Generated at 2022-06-21 20:08:32.016783
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    ledger1 = Ledger(None, None)
    ledger2 = Ledger(None, None)
    assert ledger1 == ledger2


# Generated at 2022-06-21 20:08:40.914380
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from pyledger.commons.zeitgeist import DateRange
    from pyledger.journaling.journal import JournalEntry
    from pyledger.journaling.posting import Posting
    from pyledger.accounting.accounting import Account, Balance
    initial_balances: Dict[Account, Balance] = {Account("A101"): Balance(datetime.date(2018, 1, 1), Quantity(1))}
    entries = [JournalEntry("A101", "debit", "credit", datetime.date(2018, 1, 1), Quantity(1))]
    period = DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 1, 2))
    ledgers = build_general_ledger(period, entries, initial_balances)

# Generated at 2022-06-21 20:08:50.789718
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from ..domains.accounting.accounts import Account
    from ..domains.accounting.journaling import ReadJournalEntries
    from ..domains.accounting.ledgers import Balance
    from ..commons import DebitCredit, Quantity
    from ..commons.numbers import Amount
    from .journaling import journal_entry_from_postings
    from .ledgers import InitialBalances, OpeningBalance


# Generated at 2022-06-21 20:09:54.417332
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    # Set up a dummy Posting
    posting = Posting('debit', 'account1', 'account2', 'account3', 'some_journal', '01/01/2019', Amount(10, 'US'))
    # Create a dummy Ledger
    ledger = Ledger('account1', Balance('01/01/2019', Quantity(10, 'US')))
    # Set up a dummy LedgerEntry
    ledger_entry = LedgerEntry(ledger, posting, Quantity(10, 'US'))
    assert ledger_entry.ledger == ledger
    assert ledger_entry.posting == posting
    assert ledger_entry.balance == Quantity(10, 'US')


# Generated at 2022-06-21 20:10:07.381723
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    from .accounts import AccountType
    from .commons.zeitgeist import DateRange
    from .journaling import JournalEntry, Posting
    from .ledgers import Ledger, build_general_ledger
    from typing import Iterable

    # Define test input
    account_type = AccountType.BalanceSheet
    account_code = "1.1"
    account_name = "Cash and cash equivalent"
    subtype = ""
    account = Account(account_type, account_code, subtype, account_name)

    journal_entry_date = "2020-01-01"
    journal_entry_description = "Test Journal Entry"
    journal_entry_amount = Decimal("100")
    journal_entry_account_code = "1.1"
    journal_entry_direction = 0
    journal_entry1 = JournalEntry

# Generated at 2022-06-21 20:10:16.307247
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    from .journaling import Journal, Posting
    from .accounts import Cash
    ledger = Ledger(Cash,Balance(30))
    other = Ledger(Cash,Balance(30))
    journal = Journal(date=datetime.date.today(),description="test",postings=[Posting(Cash,40,True)])
    posting = Posting(Cash,40,True)
    entry = LedgerEntry(ledger, posting, Quantity(self._last_balance + posting.amount * posting.direction.value))
    otherEntry = LedgerEntry(ledger, posting, Quantity(self._last_balance + posting.amount * posting.direction.value))
    assert entry == otherEntry

# Generated at 2022-06-21 20:10:28.871485
# Unit test for function build_general_ledger
def test_build_general_ledger():
    ## Define expected model:
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))
    AccountCash = Account("cash")
    AccountAssets = Account("assets")
    AccountExpenses = Account("expenses")
    AccountLiabilities = Account("liabilities")
    initial_balances = {AccountCash: Balance(period.since, Quantity(1000)), AccountAssets: Balance(period.since, Quantity(0)), AccountExpenses: Balance(period.since, Quantity(0))}

# Generated at 2022-06-21 20:10:35.418747
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    GL1 = GeneralLedger(DateRange(since=datetime.date(2019, 1, 1), until=datetime.date(2019, 1, 31)), {})
    GL2 = GeneralLedger(DateRange(since=datetime.date(2019, 1, 1), until=datetime.date(2019, 1, 31)), {})

    assert GL1 == GL2


# Generated at 2022-06-21 20:10:38.005381
# Unit test for constructor of class Ledger
def test_Ledger():
    x = Ledger(1,2)
    assert x.account == 1
    assert x.initial == 2
    assert x.entries == []

# Unit Test for add

# Generated at 2022-06-21 20:10:43.793565
# Unit test for method add of class Ledger
def test_Ledger_add():
    account = Account("3000")
    initial_balance = Balance(datetime.date(2018, 11, 1), Quantity(Decimal(100)))
    ledger = Ledger(account, initial_balance)
    posting = Posting(datetime.date(2018, 11, 1), 1, Quantity(Decimal(50)), account)
    posting.journal.description = "test"
    current_balance = ledger.add(posting)
    assert(current_balance == 150)



# Generated at 2022-06-21 20:10:56.550803
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    A = Account
    D = datetime
    AD = Amount
    I = InitialBalances
    J = JournalEntry
    Q = Quantity
    P = Posting
    L = Ledger
    LE = LedgerEntry
    G = GeneralLedger
    GProg = GeneralLedgerProgram

    
    # read_initial_balances: ReadInitialBalances = lambda period: I({A('a'): Balance(D.date(2020,1,1), Q(Decimal(1)))})
    # read_journal_entries: ReadJournalEntries[_T] = lambda period: [J(D.date(2020,1,1), '', [P(A('a'), AD(1))])]

    # read_initial_balances: ReadInitialBalances = lambda period: I({A('a'): Balance(D.date(2020,1

# Generated at 2022-06-21 20:11:00.343254
# Unit test for constructor of class Ledger
def test_Ledger():
    ledger = Ledger(Account("3000"), Balance(datetime.date(2017, 1, 1), Quantity(10)))
    assert ledger.account == Account("3000")
    assert ledger.initial == Balance(datetime.date(2017, 1, 1), Quantity(10))



# Generated at 2022-06-21 20:11:02.203243
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert "_program" == "compile_general_ledger_program"