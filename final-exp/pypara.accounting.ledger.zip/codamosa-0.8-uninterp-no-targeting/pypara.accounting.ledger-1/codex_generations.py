

# Generated at 2022-06-21 20:01:17.898473
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    from .accounts import AccountType, Account
    from .generic import Balance
    from .journaling import Direction, Posting
    account: Account = Account(1, 'Test Account', AccountType.ASSET, None)
    initial: Balance = Balance(None, Quantity(Decimal(0)))
    entry: LedgerEntry = LedgerEntry(None, Posting(None, Direction.CREDIT, Quantity(Decimal(10))), Quantity(Decimal(10)))
    ledger: Ledger = Ledger(account, initial)
    ledger.entries = [entry]


# Generated at 2022-06-21 20:01:21.706487
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    """
           Description
    Scope: Unit test for method __eq__ of class LedgerEntry

    Passed in:  -nothing-
    Expected: True

    Remarks:
    - Nothing to do

    """
    a=LedgerEntry
    b=LedgerEntry
    assert a == b


# Generated at 2022-06-21 20:01:32.342723
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from .accounts import Account
    from .journaling import JournalEntry
    from .generic import Balance
    from .postings import Posting
    from .accounts import Debit
    from .accounts import Credit

    #define accounts
    cash = Account("00001", "CASH")
    accounts_receivable = Account("00002", "ACCOUNTS RECEIVABLE")
    inventory = Account("00003", "INVENTORY")
    accounts_payable = Account("00004", "ACCOUNTS PAYABLE")
    profit_loss = Account("00005", "PROFIT AND LOSS")
    common_stock = Account("00006", "COMMON STOCK")

    #create initial balances dictionary

# Generated at 2022-06-21 20:01:34.833441
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    assert GeneralLedger("12345","321456").period == "12345"
    assert GeneralLedger("12345","321456").ledgers == "321456"

# Generated at 2022-06-21 20:01:39.553719
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    @dataclass
    class ReadInitialBalancesImp(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {}

    assert ReadInitialBalancesImp()(DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))) == {}


# Generated at 2022-06-21 20:01:51.137784
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    from datetime import date
    from ..commons.types import DateRange
    from ..finance.accounts import Account
    from ..finance.journaling import JournalEntry, Posting
    from ..finance.ledgering import build_general_ledger, Ledger, GeneralLedger
    
    period = DateRange(date(2019, 1, 1), date(2019, 6, 30))
    account1 = Account("Account1", "Account1")
    account2 = Account("Account2", "Account2")
    account3 = Account("Account3", "Account3")
    journal1 = JournalEntry(date(2019, 1, 1), "Journal1")
    posting11 = Posting(journal1, account1, 100)
    posting12 = Posting(journal1, account2, -100)

# Generated at 2022-06-21 20:02:01.858663
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # Assign
    from .accounts import Account, CONSOLIDATED_ACCOUNTS, TRIAL_BALANCES
    from ..commons.testing import assert_is_instance, assert_is_not_none, assert_length
    from ..commons.zeitgeist import DateRange
    from .journaling import JournalEntry, Posting, Transaction

    # Act
    def read_initial_balances(period: DateRange) -> InitialBalances:
        balances = {}
        for tb in TRIAL_BALANCES:
            if tb.account in CONSOLIDATED_ACCOUNTS:
                continue
            balances[tb.account] = Balance(tb.date, Quantity(Decimal(0)))

# Generated at 2022-06-21 20:02:07.513662
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    lg1 = Ledger("A", Balance(datetime.date(2019, 12, 31), 50))
    lg2 = Ledger("A", Balance(datetime.date(2019, 12, 31), 50))
    assert lg1 == lg2
    lg1.initial.value = 100
    assert lg1 != lg2

# Generated at 2022-06-21 20:02:10.160274
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    GeneralLedger(DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31)), {})


# Generated at 2022-06-21 20:02:21.352644
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from ..journaling.entries import JournalEntry, Posting
    from ..journaling.domain import Sales
    from ..journaling.narrative import Narrative
    from ..journaling.vouchers import Invoice
    from ..accounting.accounts import Account, Asset, Liability, Equity, Expense
    from ..accounting.domain import OpeningBalances, Cash, Borrowings, Capital, SundryDebtors
    from ..accounting.generic import Balance
    from ..accounting import books
    import datetime


# Generated at 2022-06-21 20:02:40.578641
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from .accounts import read_terminal_accounts


# Generated at 2022-06-21 20:02:46.406361
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    # Setup
    ledger = Ledger(
        account=Account(code="1000", name="Cash and cash equivalents"),
        initial=Balance(date=datetime.date(2019, 5, 25), value=Quantity(Decimal(10000.00))),
    )
    # Exercise
    actual = ledger.__repr__()
    # Verify
    expected = '1000: Cash and cash equivalents, 2019-05-25, 10000.00'
    assert actual == expected
    # Cleanup - none necessary



# Generated at 2022-06-21 20:02:59.365388
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    import pytest
    from textwrap import dedent
    from ..commons.journaling import JournalEntry, Posting, ReadJournalEntries
    from ..commons.zeitgeist import DateRange

    # 1. Test fixtures:
    class ReadJournalEntryAlg:
        def __call__(self, period: DateRange) -> Iterable[JournalEntry]:
            yield JournalEntry(
                "John Doe, credit card payment", "400.00", ["Cr. Card Repayment", "Li. John Doe"], [
                    Posting("Dr. Loan", "400.00"),
                    Posting("Dr. Personal", "400.00"),
                ],
            )

# Generated at 2022-06-21 20:03:10.260401
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .journaling import JournalEntry, Posting

    # mock account
    account = Account(1, "assets", "cash")
    # mock Posting
    posting = Posting(Account(1, "assets", "cash"), Direction.Debit, Quantity(Decimal(100.00)))
    # mock JournalEntry
    journal_entry = JournalEntry(datetime.date(2019, 8, 7), "test", [posting])

    # start ledger with a initial balance of 0
    ledger = Ledger(account, Balance(datetime.date(2019, 8, 7), Decimal(0.00)))

    # add mock Posting to ledger
    ledger.add(posting)

    assert ledger.entries[0].balance.value == 100

    # mock Posting2

# Generated at 2022-06-21 20:03:22.716467
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    '''
    Test GeneralLedger
    '''
    
    from .accounts import Account
    from .journaling import Journal
    from .posting import Posting
    from ..commons.collections import SortedSet

    # Define a set of accounts
    income = Account(number=1000, name="Income", category="Revenue")
    taxes = Account(number=2200, name="Taxes", category="Expense")
    cash = Account(number=1110, name="Cash", category="Asset")
    equity = Account(number=3000, name="Equity")
    expenses = Account(number=5100, name="Expenses", category="Expense")
    sales = Account(number=4000, name="Sales", category="Revenue")

# Generated at 2022-06-21 20:03:24.926043
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    assert LedgerEntry(None, None, None) == LedgerEntry(None, None, None)

# Generated at 2022-06-21 20:03:37.129188
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .accounts import get_account
    from .journaling import build_journal_entry
    from .transactions import build_transaction
    from .transactions.payables import create_payables_transaction
    from .transactions.receivables import create_receivables_transaction
    from datetime import date
    from decimal import Decimal
    from typing import cast

    ## Build a receivables transaction:
    receivables_transaction = create_receivables_transaction(build_transaction(1, date(2020, 1, 1)))
    receivables_transaction.record_invoice(Decimal(1000))
    receivables_transaction.record_payment(Decimal(700))

    ## Build a payables transaction:

# Generated at 2022-06-21 20:03:42.710274
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    from .journaling import JournalEntry, Posting
    from .accounts import Account

    class AccountA(Account):
        pass

    class AccountB(Account):
        pass

    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            AccountA: Balance(period.since, Quantity(Decimal(0))),
            AccountB: Balance(period.since, Quantity(Decimal(0))),
        }


# Generated at 2022-06-21 20:03:52.202644
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    period = DateRange(since= datetime.date(2020, 1, 1), until=datetime.date(2020, 12, 31))
    asset = Account('Assets')
    liabilities = Account('Liabilities')
    ledgers = {asset: Ledger(asset, Balance(datetime.date(2020, 12, 31), Quantity(Decimal(10))), ),
               liabilities: Ledger(liabilities, Balance(datetime.date(2020, 12, 31), Quantity(Decimal(0))), )}
    general_ledger = GeneralLedger(period, ledgers)
    assert general_ledger.period == period
    assert general_ledger.ledgers == ledgers

# Generated at 2022-06-21 20:03:59.134320
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    @dataclass
    class Test:
        pass
    Test_value = Test()
    Test.add = lambda self, *args, **kwargs: None
    general_ledger = GeneralLedger(DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 6, 30)), {})
    assert general_ledger.__repr__() is not None


# Generated at 2022-06-21 20:04:19.181942
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    from ..commons.zeitgeist import date_range
    from .accounts import Account, AccountKind, PostingRule
    from .journaling import JournalEntry, Posting
    from datetime import date
    from decimal import Decimal

    # set up mocks
    period = date_range(date(2019, 1, 1), date(2019, 12, 31))
    journal = JournalEntry.from_postings(
        postings=[
            Posting(
                account=Account(kind=AccountKind.ASSET, number=Decimal(10), posting_rule=PostingRule.WITH_DEBIT),
                amount=Decimal(1),
                date=date(2019, 1, 1),
            )
        ],
        description="test",
    )


# Generated at 2022-06-21 20:04:30.632285
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    # Declare variable for test
    account1 = Account(code=1, name='first', group='active', terminal=True)
    account2 = Account(code=2, name='second', group='non-active', terminal=True)
    balance1 = Balance(date=datetime.date.today(), value=Quantity(Decimal(10)))
    balance2 = Balance(date=datetime.date.today(), value=Quantity(Decimal(1)))

    # Test with correct entries and correct balance
    test_posting = Posting(account=account1, amount=Amount(Decimal(10)), direction=1)
    test_ledger = Ledger(account=account1, initial=balance1)
    test_LedgerEntry = LedgerEntry(ledger=test_ledger, posting=test_posting, balance=Quantity(Decimal(10)))

# Generated at 2022-06-21 20:04:41.948149
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():

    from .journaling import JournalEntry
    import dataclasses
    import pytest
    from dataclasses import dataclass
    from typing import List
    import collections

    @dataclass
    class MockInitialBalances:
        """
        Mocking ReadInitialBalances algebra.
        """
        initial_balances: collections.OrderedDict

        def __call__(self, period):
            return self.initial_balances

    @dataclass
    class MockJournalEntries:
        """
        Mocking ReadJournalEntries algebra.
        """
        journal_entries: List[JournalEntry]

        def __call__(self, period):
            return self.journal_entries

    @dataclass
    class MockSetupData:
        """
        Mocking the setup data.
        """
        # Accounting period
        period

# Generated at 2022-06-21 20:04:43.717040
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    # setup
    pass
    #assert
    print("LedgerEntry not tested")

# Generated at 2022-06-21 20:04:45.004902
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    pass


# Generated at 2022-06-21 20:04:51.393575
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Given
    Posting = Posting()
    Posting.date = datetime.date(2019, 1, 1)
    Posting.direction = "debit"
    Posting.amount = 100
    Posting.account = "Revenue"
    Posting.journal = JournalEntry()
    Posting.journal.description = "something"
    Posting.journal.postings = [Posting]

    # When
    Entry = Ledger.add(Posting)

    # Then
    assert Entry.date == datetime.date(2019, 1, 1)
    assert Entry.description == "something"
    assert Entry.amount == 100
    assert Entry.cntraccts == ["Revenue"]
    assert Entry.is_debit == True
    assert Entry.is_credit == False
    assert Entry.debit == 100

# Generated at 2022-06-21 20:05:03.763674
# Unit test for function build_general_ledger
def test_build_general_ledger():

    def given_journal_entries(period: DateRange):

        # type: (DateRange) -> Iterable[JournalEntry[_T]]

        from .journaling import JournalEntry
        from .common_accounts import CommonAccounts
        from .accounts import accounts
        from ..commons.zeitgeist import DateTime
        from ..commons.numbers import Amount, Quantity

        date = period.since + datetime.timedelta(days=period.days // 2)


# Generated at 2022-06-21 20:05:04.461402
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__(): ...

# Generated at 2022-06-21 20:05:15.486744
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account

    from .journaling import ReadJournalEntries

    from .generic import Balance
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .accounts import Account

    from ..commons.testutils import assert_namedtuples


# Generated at 2022-06-21 20:05:21.121257
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    # test that constructor creates expected instance of GeneralLedger
    since=datetime.date(period.since)
    until=datetime.date(period.until)
    genledger=GeneralLedger(since,until,ledgers)
    assert isinstance(genledger, GeneralLedger)


# Generated at 2022-06-21 20:05:58.763372
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    """
    Test method __repr__ of class Ledger
    """

    class TestClass:
        pass

    test_obj = Ledger(
        TestClass,
        TestClass,
    )

    assert repr(test_obj) == "<Ledger(account=<TestClass object at {0:#x}>, initial=<TestClass object at {1:#x}>)>".format(
        id(TestClass()),
        id(TestClass()),
    )

# Generated at 2022-06-21 20:05:59.514493
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    pass


# Generated at 2022-06-21 20:06:00.350484
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    pass

# Generated at 2022-06-21 20:06:02.869538
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    assert GeneralLedger.__name__ in repr(GeneralLedger(DateRange("2016-01-02", "2016-01-05"),{}))

# Generated at 2022-06-21 20:06:14.742334
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    from .journaling import Posting, Journal

    date = datetime.date(2011, 11, 11)
    description = "Transactions Description"

    #: Build a program which consumes initial balances and returns a general ledger.
    ledger_entry_1 = LedgerEntry(Ledger(Account("a"), Balance(date, Quantity(Decimal(0)))),
                                 Posting(date, "1.1", Account("a"), Journal(date, description)), Quantity(1))
    ledger_entry_2 = LedgerEntry(Ledger(Account("a"), Balance(date, Quantity(Decimal(0)))),
                                 Posting(date, "1.2", Account("a"), Journal(date, description)), Quantity(1))

# Generated at 2022-06-21 20:06:27.816611
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from typing import Any

    from .accounts import Account
    from .commons.test_commons import test_value_of, test_equals_with, test_equals
    from .typing import Balance

    balance_1_0 = Balance(test_value_of(datetime.date, "2018-01-01"), test_value_of(Decimal, "1000.00"))
    balance_2_0 = Balance(test_value_of(datetime.date, "2018-01-01"), test_value_of(Decimal, "2000.00"))
    balances = {test_value_of(Account, "1"): balance_1_0, test_value_of(Account, "2"): balance_2_0}

# Generated at 2022-06-21 20:06:29.303631
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    pass


# Generated at 2022-06-21 20:06:41.334707
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from tests.budgets.examples import example_journal, example_initial_balances
    from tests.budgets.examples import example_general_ledger

    # Test journal postings.
    assert example_journal is not None

    # Test initial balances.
    assert example_initial_balances is not None

    # Test the general ledger.
    assert example_general_ledger is not None

    # Build the actual general ledger.
    actual_general_ledger = build_general_ledger(
        DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31)),
        example_journal,
        example_initial_balances,
    )

    # Compare results.
    assert example_general_ledger == actual_general_ledger



# Generated at 2022-06-21 20:06:49.407962
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    from decimal import Decimal
    from datetime import date

    from .accounts import (
        Account,
        AccountCode,
        AccountType,
        AssetAccount,
        EquityAccount,
        ExpenseAccount,
        LiabilityAccount,
        RevenueAccount,
    )
    from .generic import Balance

    read_initial_balances = ReadInitialBalances()

    hist_date = date(2019, 12, 31)
    initial_balances = read_initial_balances(hist_date)
    assert initial_balances

# Generated at 2022-06-21 20:06:56.136749
# Unit test for method add of class Ledger
def test_Ledger_add():
    account = Account(0, "Account")
    balance = Balance(datetime.date(2019, 3, 31), Quantity(Decimal(10)))
    amount = Amount(12, "USD")
    direction = Posting.Direction.DEBIT
    posting = Posting(datetime.date(2019, 4, 1), amount, direction, account)
    ledger = Ledger(account, balance)
    entry = ledger.add(posting)
    assert entry.balance == Quantity(Decimal(22))

# Generated at 2022-06-21 20:07:22.021976
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    assert compile_general_ledger_program

# Generated at 2022-06-21 20:07:25.489783
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    """
    Test for method __repr__ of class Ledger
    """
    assert(Ledger(Account('C'), Balance('2020-01-01', '0')).__repr__() == 'Ledger(account=Account(name=C))')

# Generated at 2022-06-21 20:07:27.031565
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    assert repr(LedgerEntry(None, None, 0)) == "LedgerEntry(None, None, 0)"

# Generated at 2022-06-21 20:07:37.489610
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from ..stubs.general_ledgers import a_journal_entry

    ledger = Ledger(Account("TestAccount"), Balance(datetime.date(2015, 1, 1), Quantity(7)))
    entry = LedgerEntry(ledger, a_journal_entry.postings[0], Quantity(7))

    assert entry.ledger == ledger
    assert entry.posting == a_journal_entry.postings[0]
    assert entry.balance == Quantity(7)
    assert entry.amount == a_journal_entry.postings[0].amount
    assert entry.cntraccts == []
    assert entry.debit is not None
    assert entry.credit is None


# Generated at 2022-06-21 20:07:50.741839
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    test_class = LedgerEntry
    # Test 1:

# Generated at 2022-06-21 20:07:59.202580
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from pytest import raises

    from ..commons.numbers import Amount
    from ..commons.zeitgeist import date_range
    from .accounts import Account
    from .journaling import JournalEntry, Posting, PostingDirection

    ##
    ## Test case 1:
    ##
    ##              1/2/3
    ##             /      \
    ##            /        \
    ##   Assets 50          \
    ##    1/1       1/1     50
    ##   /   \     /   \   /   \
    ##  E    L  Equity  L E    Equity
    ##

# Generated at 2022-06-21 20:08:11.568265
# Unit test for method add of class Ledger
def test_Ledger_add():
    t = datetime.datetime.utcnow()
    acc = Account.of('Money')
    jr1 = JournalEntry('January', datetime.date(2018, 1, 1))
    pst1 = Posting(None, jr1, acc, Quantity(100))
    amt1 = Amount.of(100)

    jr2 = JournalEntry('February', datetime.date(2018, 2, 1))
    pst2 = Posting(None, jr2, acc, Quantity(100))
    amt2 = Amount.of(100)

    lgr1 = Ledger(acc, Balance(datetime.date(2018, 1, 1), Quantity(0)))
    lgr2 = Ledger(acc, Balance(datetime.date(2018, 1, 1), Quantity(100)))

    lgrentry1 = Ledger

# Generated at 2022-06-21 20:08:19.988712
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from datetime import date 
    from app.domain.journaling import JournalEntry, Posting
    from app.domain.ledgering import Ledger, LedgerEntry
    from app.domain.commons.types import AccountingDate, Description

    class LedgerTest(Ledger):
        def __init__(self, account: Account, initial: Balance):
            super().__init__(account, initial)

        def add(self, posting: Posting[_T]) -> LedgerEntry[_T]:
            return super().add(posting)

    ##To test LedgerEntry

    a = Account(1)
    b = Account(2)
    j = JournalEntry(AccountingDate(date(2017, 11, 5)), Description("Hello"), [Posting(a, Quantity(2), True), Posting(b, Quantity(2), False)])
    k

# Generated at 2022-06-21 20:08:24.603256
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    from .utilities import new_account

    account = new_account("my_account")
    ledger = Ledger(account)

    assert ledger.__repr__() == "Ledger(account=Account(code='my_account'), initial=None, entries=[])"


# Generated at 2022-06-21 20:08:31.611446
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    # define the algebra
    @dataclass
    class ReadInitialBalancesData:
        """
        Provides a data class to read initial balances.
        """

        #: Initial balances.
        initial_balances: InitialBalances

        def __call__(self, period: DateRange) -> InitialBalances:
            return self.initial_balances

    @dataclass
    class ReadJournalEntriesData:
        """
        Provides a data class to read journal entries.
        """

        #: Journal entries.
        journal_entries: List[JournalEntry]

        def __call__(self, period: DateRange) -> List[JournalEntry]:
            return self.journal_entries

    # define the business logic

# Generated at 2022-06-21 20:09:21.227819
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .accounts import AccountIdentifier, AccountType
    from .accounts.common import AccountTree
    from .journaling import Journal

    ## Prepare the period and journal entries:
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 3))

# Generated at 2022-06-21 20:09:24.264425
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    """
    Unit test for constructor of class GeneralLedgerProgram
    """

    ## Try to use the constructor of class GeneralLedgerProgram
    try:
        compile_general_ledger_program()
    except:
        raise AssertionError('Cannot use constructor of class GeneralLedgerProgram')

    ## Raise an assertion error if the constructor works
    assert True

# Generated at 2022-06-21 20:09:25.416008
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    assert ReadInitialBalances



# Generated at 2022-06-21 20:09:27.620400
# Unit test for constructor of class Ledger
def test_Ledger():
    account_ledger = Ledger(Account("0000", "", ""), Balance(datetime.date(2018, 1, 1), Quantity(12345)))
    assert account_ledger.entries == []


# Generated at 2022-06-21 20:09:35.802648
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from .journaling import Journal, Posting, PostingDirection

    ## Create the journal:
    journal = Journal("First test journal")

    ## Create the postings:
    posting1 = Posting(journal, datetime.date(2020, 4, 1), PostingDirection.DEBIT, Amount(1))
    posting2 = Posting(journal, datetime.date(2020, 4, 1), PostingDirection.CREDIT, Amount(1))

    ## Give the postings some counter accounts:
    posting1.add_counter_account("Assets:Cash")
    posting2.add_counter_account("Income:Sales")

    ## Create the ledger:
    ledger = Ledger("Income", Balance(datetime.date(2020, 4, 1), Quantity(2)))

    ## Add the postings to the ledger:

# Generated at 2022-06-21 20:09:48.126861
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    from .journaling import JournalEntry, Posting

    p1 = Posting("a", "b", datetime.date(2011, 1, 1), Amount(42), "one", "two")
    p2 = Posting("a", "b", datetime.date(2011, 1, 1), Amount(42), "one", "two")
    p3 = Posting("a", "b", datetime.date(2011, 1, 1), Amount(42), "one", "three")

    e1 = JournalEntry([p1], datetime.date(2011, 1, 1), "one")
    e2 = JournalEntry([p2], datetime.date(2011, 1, 1), "one")
    e3 = JournalEntry([p1], datetime.date(2011, 1, 1), "two")

# Generated at 2022-06-21 20:09:59.286911
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from typing import Any, Callable, TypeVar

    from .accounts import Account, AccountsTree
    from .journaling import Journal, JournalItem, Posting, ReadJournalEntries, ReadInitialBalances

    TT = TypeVar("TT")

    class MockReadInitialBalances(ReadInitialBalances):
        """
        Mock implementation of the ReadInitialBalances type.
        """

        def __init__(self, balances: InitialBalances):
            """
            Initializes the mock.
            """
            self._balances = balances

        def __call__(self, period: DateRange) -> InitialBalances:
            """
            Consumes a period and returns opening balances of terminal accounts as of the end of previous financial
            period.

            :param period: Accounting period.
            :return: Opening balances.
            """
            return self._balances

    #

# Generated at 2022-06-21 20:10:11.940403
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Unit test for function :py:func:`compile_general_ledger_program`.

    :return: None
    """
    import pytest
    from .accounts import Accounts
    from .journaling import JournalEntries
    from .journaling import PostingDate
    from .journaling import ReadAccounts, ReadJournalEntries

    ## This one is key, really:
    import mock
    import decimal

    # Accounts:

# Generated at 2022-06-21 20:10:12.813128
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    # arrange
    GeneralLedger.__repr__()

# Generated at 2022-06-21 20:10:20.310392
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from datetime import date
    from decimal import Decimal

    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType

    from .ledgers import ReadInitialBalances, build_general_ledger, compile_general_ledger_program
    from .journaling import JournalEntry, Posting, account_name_to_object, build_journal_entry_from_dict
    from .commons.accounts import account_name_to_object

    # pylint: disable=unused-argument