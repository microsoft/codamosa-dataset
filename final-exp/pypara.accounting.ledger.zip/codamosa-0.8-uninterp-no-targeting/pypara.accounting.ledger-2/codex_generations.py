

# Generated at 2022-06-21 20:01:25.405719
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    a1 = Account("a")
    a2 = Account("b")
    b1 = Balance(datetime.date(2018, 3, 1), Quantity(1))
    b2 = Balance(datetime.date(2018, 3, 1), Quantity(2))
    l1 = Ledger(a1, b1)
    l2 = Ledger(a1, b1)
    l3 = Ledger(a1, b2)
    l4 = Ledger(a2, b1)

    assert l1 == l2
    assert l1 != l3
    assert l1 != l4

# Generated at 2022-06-21 20:01:31.664974
# Unit test for method add of class Ledger
def test_Ledger_add():
    a = Account(1, 'account1', 'assets')
    b = Balance(datetime.date(2018, 3, 1), Quantity(1))
    c = a.post(datetime.date(2018, 3, 2), Quantity(1), 'journal1')
    d = Ledger(a, b)
    e = d.add(c)
    f = LedgerEntry(d, c, Quantity(2))
    assert e == f

# Generated at 2022-06-21 20:01:37.438562
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    assert repr(Ledger(account=Account("1-000"), initial=Balance(datetime.date.today(), Quantity(Decimal(0.0))))) == "Ledger(account=Account(code='1-000', name='', nature='debit', segment=None), initial=Balance(date=datetime.date(2020, 5, 24), value=Quantity(0.0, currency='EUR')))";

# Generated at 2022-06-21 20:01:39.705096
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    assert [Ledger(None, None), Ledger(None, None)] == [Ledger(None, None), Ledger(None, None)]


# Generated at 2022-06-21 20:01:44.749050
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .generic import Balance

    # initial account
    account = Account("1000", "Cash", AccountType.Asset)

    # initial balance
    balance = Balance(datetime.date(2020, 8, 1), 10)

    # new ledger
    ledger = Ledger(account, balance)

    # new journal entry
    journal_entry = JournalEntry("2020-08-17", "Debt re-payment", [
        Posting(datetime.date.today(), "1000", 1),
        Posting(datetime.date.today(), "2000", -1)
    ])

    # new ledger entry
    ledger_entry = LedgerEntry(ledger, journal_entry.postings[0], quantity=2.1)

    assert ledger_entry.__

# Generated at 2022-06-21 20:01:47.315722
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    #TODO: Implement unit test for method __eq__ of class GeneralLedger
    pass


# Generated at 2022-06-21 20:01:59.049042
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    _T = TypeVar("_T")
    def read_initial_balances(period: DateRange) -> InitialBalances:
        initial_balances = {}
        return initial_balances
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        journal_entries = []
        return journal_entries
    @dataclass
    class GeneralLedger(Generic[_T]):
        period: DateRange
        ledgers: Dict[Account, Ledger[_T]]
    def compile_general_ledger_program(
        read_initial_balances: ReadInitialBalances,
        read_journal_entries: ReadJournalEntries[_T],
    ) -> GeneralLedgerProgram[_T]:
        def _program(period: DateRange) -> GeneralLedger[_T]:
            initial_

# Generated at 2022-06-21 20:02:04.779808
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    # create a mock ledger
    class MockLedger(object):
        def __init__(self):
            self.entries = []
    # create mock postion
    class MockPosting(object):
        def __init__(self, amount):
            self.amount = amount
            self.is_debit = True
    # create mock account
    class MockAccount(object):
        def __init__(self):
            self.is_terminal = True
    
    # create ledger entry
    mock_account = MockAccount()
    mock_ledger = MockLedger()
    mock_posting = MockPosting(Decimal(10))
    test_entry = LedgerEntry(mock_ledger, mock_posting, Quantity(Decimal(10)))

    # assert
    assert test_entry.posting == mock_posting

# Generated at 2022-06-21 20:02:13.657280
# Unit test for constructor of class Ledger
def test_Ledger():
    assert Ledger(Account("100"), Balance(datetime.date.today(), Quantity(Decimal(0)))).balance == Quantity(Decimal(0))
    assert Ledger(Account("100"), Balance(datetime.date.today(), Quantity(Decimal(0)))).entries == []
    assert Ledger(Account("100"), Balance(datetime.date.today(), Quantity(Decimal(0)))).account == Account("100")
    assert Ledger(Account("100"), Balance(datetime.date.today(), Quantity(Decimal(0)))).initial == Balance(datetime.date.today(), Quantity(Decimal(0)))


# Generated at 2022-06-21 20:02:24.270052
# Unit test for method __eq__ of class LedgerEntry

# Generated at 2022-06-21 20:02:43.922430
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import DateRange
    from .journaling import Journal, JournalEntry, Posting
    from .money import Account, Balance, Money, MoneyPosting
    from . import accounts

    ##
    ## Test data:
    ##

    ## Test journal contents:

# Generated at 2022-06-21 20:02:50.877973
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    GeLe = GeneralLedger(_T = int)

# Generated at 2022-06-21 20:02:58.824913
# Unit test for constructor of class Ledger
def test_Ledger():
   a1 = Ledger(Account("1","1", False),Balance(datetime.date(2000,1,1), Quantity(Decimal(100))))
   assert a1.account.number == "1"
   assert a1.account.name == "1"
   assert a1.account.is_control == False
   assert a1.initial.date == datetime.date(2000,1,1)
   assert a1.initial.value == Quantity(Decimal(100))


# Generated at 2022-06-21 20:03:02.245695
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    @dataclass
    class StubReadInitialBalances(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {Account("1010"): Balance(period.since, Quantity(Decimal(0)))}

    assert StubReadInitialBalances()({'since': datetime.date(2018, 1, 1), 'until': datetime.date(2018, 12, 31)}) == {
        Account('1010'): Balance(datetime.date(2018, 1, 1), Quantity(Decimal(0)))
    }


# Generated at 2022-06-21 20:03:12.038222
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    from journaling import _JournalEntry, _Posting
    from ledger import _Account

    from dataclasses import dataclass
    from decimal import Decimal
    from typing import List
    from datetime import date
    from uuid import UUID

    from ..commons.numbers import Amount
    
    @dataclass(init=True, frozen=True)
    class Posting(Generic[_T]):

        #: Account the posting is attributed to.
        account: _Account = None

        #: Amount of the posting.
        amount: Amount = None

        #: Date of the posting.
        date: date = None

        #: Entry the posting belongs to.
        journal: "JournalEntry" = None

        @property
        def direction(self):
            """
            Indicates the direction of the posting.
            """

# Generated at 2022-06-21 20:03:24.336089
# Unit test for constructor of class Ledger
def test_Ledger():
    account = Account.create(
    '711',
    'Accounts Receivable',
    Account.Category.asset,
    Account.Type.current,
    Account.NormalBalance.debit,
    '4',
    1,
    'This account is used to track customer balances.',
    datetime.datetime.now(),
    '1'
    )
    
    balance = Balance(
        date = datetime.date(2020,2,13),
        closingDate = datetime.date(2020,2,13),
        value = Quantity(Decimal(20.00)),
        currency = "CAD",
        origin = "1"
    )
    ledger = Ledger(
        account = account ,
        initial = balance
    )
    

# Generated at 2022-06-21 20:03:36.679474
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Tests the compile_general_ledger_program function.
    """

    import datetime as dt
    from unittest.mock import Mock

    ## Create an example period:
    period = DateRange(dt.date(2020, 1, 1), dt.date(2020, 12, 31))

    ## Define mocked algebra implementation:
    read_initial_balances = Mock()
    read_journal_entries = Mock()

    ## Compile the program:
    program = compile_general_ledger_program(read_initial_balances, read_journal_entries)

    ## Call the compiled program:
    program(period)

    ## Assert that the mocked algebraic implementations have been called:
    read_initial_balances.assert_called_once_with(period)
    read_journal_entries.assert_

# Generated at 2022-06-21 20:03:49.082791
# Unit test for function build_general_ledger
def test_build_general_ledger():
    """
    This function unit tests function build_general_ledger.
    """
    ## Create two accounts.
    a0: Account = Account(
        "a0", "A0", False
    )  # type: Account
    a1: Account = Account(
        "a1", "A1", False
    )  # type: Account

    ## Create two journals.
    j0: JournalEntry = JournalEntry(
        datetime.date(2020, 1, 1),
        "J0",
        [
            Posting(
                a0, Decimal(10), True
            ),  # type: Posting
            Posting(
                a1, Decimal(10), False
            ),  # type: Posting
        ],
    )  # type: JournalEntry

# Generated at 2022-06-21 20:03:57.690330
# Unit test for method add of class Ledger
def test_Ledger_add():
    ## Get the accounts:
    assets = Account("assets", Account.Nature.ASSETS)
    equity = Account("equity", Account.Nature.EQUITY)

    ## Create a ledger:
    ledger = Ledger(assets, Balance(datetime.date(2016, 1, 1), Quantity(Decimal(0))))

    ## Create a journal entry and its associated postings:
    journal_entry = JournalEntry("First entry", datetime.date(2016, 1, 5))
    posting1 = Posting(journal_entry, assets, Quantity(Decimal(5)), Account.Direction.DEBIT)
    posting2 = Posting(journal_entry, equity, Quantity(Decimal(-5)), Account.Direction.CREDIT)

    ## Add the postings to the ledger
    ## CHECK: ledger entries' balance is 5

# Generated at 2022-06-21 20:04:00.195005
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    try:
        assert(ReadInitialBalances)
        return 0
    except (RuntimeError, TypeError, NameError):
        return 1


# Generated at 2022-06-21 20:04:21.170670
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from .accounts import Account
    from .commons import Money
    from .journaling import Posting, JournalEntry
    from .journaling.algebras import read_journal_entries
    from .journaling.models import Journal

    # sub-test 1:
    def _program(period: DateRange) -> GeneralLedger[Money]:
        """
        Consumes the opening and closing dates and produces a general ledger.

        :param period: Accounting period.
        :return: A general ledger.
        """
        ## Get initial balances as of the end of previous financial period:
        initial_balances = read_initial_balances(period)

        ## Read journal entries and post each of them:
        journal_entries = read_journal_entries(period)

        ## Build the general ledger and return:

# Generated at 2022-06-21 20:04:21.840091
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass

# Generated at 2022-06-21 20:04:22.477860
# Unit test for constructor of class Ledger
def test_Ledger():
    pass

# Generated at 2022-06-21 20:04:34.034359
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import AccountingPeriod
    from .accounts import DEBIT, NormalAccount
    from .journaling import Journal, Posting
    from .testing import JournalEntryFixtures

    period = AccountingPeriod(datetime.date.today())
    journal = JournalEntryFixtures.create(
        Journal(
            datetime.date.today(),
            "Test transaction.",
            [
                Posting(NormalAccount("101", "Cash in hand", DEBIT), Quantity(-3)),
                Posting(NormalAccount("201", "Accounts Receivable", DEBIT), Quantity(-5)),
            ],
        )
    )

    general_ledger = build_general_ledger(period, journal, {NormalAccount("101", "Cash in hand", DEBIT): Balance(period.since, Quantity(Decimal(0)))})
    assert general_

# Generated at 2022-06-21 20:04:44.708592
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():

    class FakePeriod:
        since = datetime.date(2019, 1, 1)
        until = datetime.date(2019, 1, 2)
    period = FakePeriod()

    class FakeInitialBalance:
        date = datetime.date(2019, 1, 1)
        value = Quantity(Decimal('1.23'))
    initial_balance = FakeInitialBalance()

    class FakeAccount:
        name = 'Fake Account'

    account = FakeAccount()

    class FakePosting:
        journal = JournalEntry('abc', datetime.date(2019, 1, 1), 'Fake Journal')
        account = FakeAccount()
        date = datetime.date(2019, 1, 1)
        amount = Amount(Decimal('1.23'))
        is_debit = True
        direction = 1

    posting = FakePosting()

# Generated at 2022-06-21 20:04:56.983742
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    assert type(GeneralLedger) == dataclass
    assert GeneralLedger(period=15, ledgers={"Balance sheet":30}) == GeneralLedger(period=15, ledgers={"Balance sheet":30})
    assert GeneralLedger(period=30, ledgers={"Balance sheet":30}) != GeneralLedger(period=15, ledgers={"Balance sheet":30})
    assert GeneralLedger(period=15, ledgers={"Balance sheet":15}) != GeneralLedger(period=15, ledgers={"Balance sheet":30})
    assert GeneralLedger(period=15, ledgers={"Balance sheet":15}) != GeneralLedger(period=15, ledgers={"Balance sheet":30, "Income statement":50})

# Generated at 2022-06-21 20:04:58.361934
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    pass


# Generated at 2022-06-21 20:05:08.051532
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from datetime import date
    from datetime import timedelta
    from ..commons.zeitgeist import DateRange
    from .journaling import JournalEntry, Posting, build_journal_entry
    from .accounts import Account

    # Define a function which reads opening balances as of the end of previous financial period.
    def read_initial_balances(period: DateRange) -> InitialBalances:
        # Starting balances.
        return {
            Account(1): Balance(period.since, Quantity(100)),
            Account(2): Balance(period.since, Quantity(-100)),
            Account(3): Balance(period.since, Quantity(0)),
        }

    # Define a function which reads journal entries.

# Generated at 2022-06-21 20:05:18.485216
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    import random
    import unittest.mock
    from datetime import date
    from decimal import Decimal
    from typing import Tuple
    from ..commons.types import QuantityStr
    from ..commons.zeitgeist import DateRange, DateRangeStr
    from ..accounting.accounts import Account, AccountTree
    from ..accounting.journaling import JournalEntry, Posting, stringify_journal_entry
    from .accounts import account_with_name, account_with_code
    from .generic import Balance
    from .journaling import stringify_journal_entries

    # Helper function for test
    def random_date(start: date=date(2019,1,1), end: date=date(2019,12,31)) -> date:
        """
        Helper function for generating a random date in a range
        """
       

# Generated at 2022-06-21 20:05:26.472188
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from dataclasses import astuple
    from decimal import Decimal
    from typing import Tuple
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account, AccountType
    from .currencies import Currency
    from .journaling import JournalEntry, Posting, Direction
    from .types import Coding

    # Define a use case:
    # The company has opened an account with a bank.
    # It has received 100 USD at the account.
    # The company has made a loan application and received the loan.
    # It has received 1,000 USD at the account.
    # The company has paid back the loan.
    # It has made a 1,000 USD payment, at the account.

    # Create a mock currency object:

# Generated at 2022-06-21 20:05:56.723296
# Unit test for constructor of class Ledger
def test_Ledger():
    a = Account(1, "Cash", True)
    b = Balance(datetime.date(2019, 1, 1), Decimal(100))
    l = Ledger(a, b)
    assert l.account == a
    assert l.initial == b
    assert l.entries == []


# Generated at 2022-06-21 20:06:07.548290
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..algebra.accounting import read_journal_entries
    from ..algebra.bookkeeping import read_journal_entry

    ## Initialize a general ledger period.
    period = DateRange("2019-01-01", "2019-01-31")

    ## Initialize some journal entries:

# Generated at 2022-06-21 20:06:09.227506
# Unit test for function build_general_ledger
def test_build_general_ledger():
    
    assert True == True

# Generated at 2022-06-21 20:06:17.908729
# Unit test for method add of class Ledger
def test_Ledger_add():
    """
    Unit test for method add of class Ledger
    """
    from dateutil import parser
    from decimal import Decimal
    from .accounts import Account
    from .numbers import Quantity
    from .journaling import Journal, Posting
    from .directions import Direction
    from .journaled import Journaled

    # define the quantity:
    quantity = Quantity(Decimal(10))

    # define the direction:
    direction = Direction.DEBIT

    # define the account:
    account = Account("::0")

    # define the journaled:
    journaled = Journaled()

    # define the posting:
    posting = Posting(journaled, direction, account, quantity)

    # define the initial balance:

# Generated at 2022-06-21 20:06:25.863561
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    from .ledgers import Ledger
    from .accounts import Account
    from .commons.baldate import BalanceDate
    from .commons.numbers import Quantity
    from datetime import datetime
    account = Account('Bank',1)
    bdate = BalanceDate(datetime.now())
    bal = Balance(bdate,Quantity(Decimal(10)))
    ledger = Ledger(account,bal)
    assert ledger.__repr__() == f"<Ledger {account} {bal}>"


# Generated at 2022-06-21 20:06:39.002849
# Unit test for method add of class Ledger
def test_Ledger_add():
    account = Account(
        code="5000",
        name="Cash",
        is_terminal=False,
        is_asset=True,
        is_liability=False,
        is_equity=False,
        is_revenue=False,
        is_expense=False,
    )
    balance = Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0)))
    ledger = Ledger(account, balance)

    description = "I paid for strawberries"
    journal_entry1 = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description=description,
        postings=[
            Posting(
                account=account,
                amount=Amount(Decimal(100)),
                direction=Posting.DrCr.CREDIT,
            )
        ],
    )


# Generated at 2022-06-21 20:06:46.357863
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    journal = [
        JournalEntry(datetime.datetime(2019, 10, 1), "Sales", [
            Posting(datetime.datetime(2019, 10, 1), Account("1010"), Quantity(+100), Direction.Debit),
            Posting(datetime.datetime(2019, 10, 1), Account("2020"), Quantity(-100), Direction.Credit)
        ])
    ]
    period = DateRange(datetime.datetime(2019, 10, 1), datetime.datetime(2019, 10, 31))
    initial = {Account("1010"): Balance(datetime.datetime(2019, 9, 30), Quantity(0))}
    general = build_general_ledger(period, journal, initial)
    assert general.period == period

# Generated at 2022-06-21 20:06:55.704910
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    @dataclass
    class _Impl(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {}

    _ = ReadInitialBalances
    assert isinstance(_Impl(), _)

    with pytest.raises(TypeError):
        _Impl.__bases__ = ()
        # noinspection PyArgumentList
        isinstance(_Impl(), _)

    with pytest.raises(TypeError):
        _Impl.__bases__ = (object,)
        # noinspection PyArgumentList
        isinstance(_Impl(), _)


# unit test for constructor of class GeneralLedgerProgram

# Generated at 2022-06-21 20:07:04.240342
# Unit test for method __call__ of class GeneralLedgerProgram

# Generated at 2022-06-21 20:07:05.358969
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass



# Generated at 2022-06-21 20:07:30.329770
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    assert hasattr(ReadInitialBalances, "__call__")


# Generated at 2022-06-21 20:07:39.010362
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    account1 = Account('Akaraka')
    ledger1 = Ledger(account1, Balance(datetime.date(2019, 9, 1), Quantity(Decimal('100.00'))))
    ledger2 = Ledger(account1, Balance(datetime.date(2019, 9, 1), Quantity(Decimal('100.00'))))
    ledger3 = Ledger(account1, Balance(datetime.date(2019, 9, 1), Quantity(Decimal('200.00'))))

    assert ledger1 == ledger2
    assert ledger1 != ledger3


# Generated at 2022-06-21 20:07:51.914216
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    l1 = Ledger(Account("A001"), Balance(datetime.date(2019, 1, 1), Quantity(Decimal("0.00"))))
    l1.entries.extend(
        [
            LedgerEntry(l1, Posting(JournalEntry(datetime.date(2019, 1, 1), "Test", [Account("A001")]), Account("A001"), Decimal("1.00")), Decimal("1.00")),
            LedgerEntry(l1, Posting(JournalEntry(datetime.date(2019, 1, 1), "Test", [Account("A001")]), Account("A001"), Decimal("1.00")), Decimal("2.00")),
        ]
    )


# Generated at 2022-06-21 20:07:56.963928
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    '''
    function test_LedgerEntry
    unit test for constructor of class LedgerEntry
    '''
    a = LedgerEntry(1,2,3)
    assert a.ledger == 1
    assert a.posting == 2
    assert a.balance == 3


# Generated at 2022-06-21 20:08:00.495947
# Unit test for method add of class Ledger
def test_Ledger_add():
    ledger = Ledger(Account('Assets', 'Cash'), Balance(datetime.date(2020, 1, 31), Quantity(Decimal(100))))
    ledger.add(Posting(Account('Assets', 'Cash'), datetime.date(2020, 2, 1), Quantity(Decimal(100)), 1))
    assert ledger.entries[0].balance == Quantity(Decimal(200))

# Generated at 2022-06-21 20:08:12.875571
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from datetime import date
    from ledger.accounting.core import Account, Journal, Posting

    def read_initial_balances(period: DateRange):
        return {
            Account(code='10', label='Bank Account'): Balance(date(year=2020, month=1, day=1), Quantity(Decimal(1000))),
            Account(code='20', label='Cash'): Balance(date(year=2020, month=1, day=1), Quantity(Decimal(500)))
        }


# Generated at 2022-06-21 20:08:15.781650
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    period = DateRange(datetime.date(2019, 5, 2), datetime.date(2019, 7, 4))
    assert not period.is_open
    ReadInitialBalances.__call__(period)


# Generated at 2022-06-21 20:08:26.091937
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    """
    Method __repr__ should return a string of format 'LedgerEntry(ledger, posting, balance)'
    """
    entry = LedgerEntry(Ledger(Account(0), Balance(datetime.date.today(), Quantity(0))), Posting(JournalEntry(datetime.date.today(), ''), Account(1), Direction.DEBIT, Amount(0)), Quantity(0))
    assert repr(entry) == "LedgerEntry(Ledger(Account(0), Balance(datetime.date(2020, 3, 3), Quantity(0))), Posting(JournalEntry(datetime.date(2020, 3, 3), ''), Account(1), Direction.DEBIT, Amount(0)), Quantity(0))"


# Generated at 2022-06-21 20:08:32.135243
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Given a journal entry
    class DummyObject:
        def __init__():
            self = self

    dummy_object = DummyObject()
    journal_entry = JournalEntry[DummyObject](0, datetime.date(2020, 1, 1), "something", [])

    # And a posting
    posting = Posting[DummyObject](journal_entry, 0, 'debit', Decimal('10.00'), dummy_object)

    # And a ledger
    ledger = Ledger[DummyObject](0, Balance(datetime.date(2020, 1, 1), Decimal('0.00')))

    # When a new ledger entry is added to the ledger
    result = ledger.add(posting)

    # Then the result is a ledger entry
    ledger_entry = LedgerEntry[DummyObject]
    assert type(result)

# Generated at 2022-06-21 20:08:39.427474
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account
    from .journaling import Posting

    class Journal(Generic[_T]):
        def __init__(self, date: datetime.date, amount: Amount, description: str, postings: List[Posting[_T]]):
            self.date = date
            self.amount = amount
            self.description = description
            self.postings = postings

    # Journal entries:
    J1 = Journal(datetime.date(2001, 1, 1), Amount(Decimal("0.50")), "", [Posting(Account("1"), Decimal("0.50"))])
    J2 = Journal(datetime.date(2001, 1, 2), Amount(Decimal("0.50")), "", [Posting(Account("1"), Decimal("0.50"))])

# Generated at 2022-06-21 20:09:24.962275
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    pass


# Generated at 2022-06-21 20:09:27.453373
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    class ReadInitialBalances:
        def __call__(self, period: DateRange) -> InitialBalances:
            pass

    assert ReadInitialBalances is not None


# Generated at 2022-06-21 20:09:28.281641
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    compile_general_ledger_program(None, None)

# Generated at 2022-06-21 20:09:30.105923
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    RIB0 = ReadInitialBalances()
    RIB1 = ReadInitialBalances()
    assert RIB0 is not RIB1


# Generated at 2022-06-21 20:09:37.341951
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    import datetime as dt
    from typing import List
    from businessdate import BusinessDate
    from businessdate.businessdate import BusinessDateType as bd
    from businessdate.holiday import load_holidays
    from src.commons.numbers import Quantity
    from src.commons.zeitgeist import DateRange
    from src.ledger.accounts import Account
    from src.ledger.ledger import Ledger, LedgerEntry
    from src.ledger.journaling import JournalEntry, Posting, BusinessTransaction


    def mock_journal(
            date: bd,
            description: str,
            postings: List[Posting]
    ) -> JournalEntry:
        from src.ledger.accounts import Account, AccountType
        from src.ledger.journaling import JournalEntry, Posting


# Generated at 2022-06-21 20:09:48.989246
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import AccountGroup
    from .journaling import Journal, JournalEntry
    from .commons.numbers import Amount

    # Create accounts
    root = AccountGroup("root")
    r1 = root.create_child("r1")
    r2 = root.create_child("r2")
    a1 = r1.create_account("1")
    a2 = r2.create_account("2")
    a3 = r2.create_account("3")

    # Create journals
    j1 = Journal("j1")
    j1.post(a1, Amount(12.34), a2, Amount(12.34))

    j2 = Journal("j2")
    j2.post(a3, Amount(56.78), a3, Amount(56.78))

    # Create journal entries
    e1

# Generated at 2022-06-21 20:09:55.657789
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    # Create account objects
    account1 = Account(id="111", name="Bank", currency="BRL", num_account=1, account_class="active",
                       account_group="bank accounts")
    account2 = Account(id="112", name="Cash", currency="BRL", num_account=1, account_class="active",
                       account_group="cash accounts")

    # Create Balance objects
    balance1 = Balance(datetime.datetime(2020, 1, 1), Quantity(100))
    balance2 = Balance(datetime.datetime(2020, 1, 1), Quantity(100))

    # Create Ledger objects
    ledger1 = Ledger(account1, balance1)
    ledger2 = Ledger(account1, balance1)
    ledger3 = Ledger(account1, balance2)

# Generated at 2022-06-21 20:10:08.035699
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    dt1 = datetime.datetime(year=2019, month=7, day=23)
    dt2 = datetime.datetime(year=2019, month=7, day=24)
    dt3 = datetime.datetime(year=2019, month=7, day=25)
    db_initial_balances = {'X': Balance(dt2, Quantity(Decimal(10)))}
    db_general_ledger = build_general_ledger(DateRange(dt1, dt3), [], db_initial_balances)

# Generated at 2022-06-21 20:10:09.737047
# Unit test for constructor of class Ledger
def test_Ledger():
    assert(True)



# Generated at 2022-06-21 20:10:18.421494
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # arrange
    @dataclass
    class _ReadInitialBalances:
        def __call__(self, period : DateRange) -> InitialBalances:
            return {
                Account("1000"): Balance(period.since, Quantity(Decimal("200.00"))),
                Account("2000"): Balance(period.since, Quantity(Decimal("-100.00")))
            }

    # act
    act = _ReadInitialBalances()(DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31)))

    # assert