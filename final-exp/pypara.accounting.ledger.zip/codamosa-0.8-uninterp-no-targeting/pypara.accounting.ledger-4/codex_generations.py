

# Generated at 2022-06-21 20:01:25.211353
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from .journaling import (
        Journal,
        JournalEntry,
        JournalEntryType,
        Posting,
        PostingDirection,
        PostingType,
    )
    from .accounts import Account, AccountType
    from .generic import Balance
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .ledgers import Ledger, GeneralLedger, build_general_ledger

    # Define some data
    today = datetime.date.today()
    period = DateRange(since=today - datetime.timedelta(days=7), until=today)
    initial_balances = {Account(name="A", type=AccountType.ASSET): Balance(since=period.since, value=Quantity(decimal=0))}


# Generated at 2022-06-21 20:01:36.201526
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():

    def read_initial_balances(period):
        return {Account("101"): Balance(period.since, Quantity(5)),
                Account("102"): Balance(period.since, Quantity(7))}

    def read_journal_entries(period):
        return [JournalEntry(datetime.date(year=2018, month=12, day=31), "Some journal entry",
                             [Posting(Account("101"), Quantity(5), 1),
                              Posting(Account("102"), Quantity(5), -1)])]

    general_ledger_program = compile_general_ledger_program(read_initial_balances, read_journal_entries)


# Generated at 2022-06-21 20:01:42.447239
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from .journaling import DebitPosting
    from .accounts import Account

    test_ledger = Ledger(Account("1111"), Balance(datetime.date(2018, 1, 1), Quantity(Decimal(0))))
    test_posting = DebitPosting(datetime.date(2019, 1, 1), Account("1111"), Amount(Decimal(1)))
    test_entry = LedgerEntry(test_ledger, test_posting, Quantity(Decimal(1)))

    assert test_entry.ledger == test_ledger
    assert test_entry.posting == test_posting
    
    assert test_entry.date == datetime.date(2019, 1, 1)
    assert test_entry.amount == Amount(Decimal(1))
    assert test_entry.cntraccts == list()
    assert test_

# Generated at 2022-06-21 20:01:44.407526
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    assert 8 == 5+3
    assert '__main__' == __name__
    assert 200 == 200


# Generated at 2022-06-21 20:01:57.181320
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    import datetime
    from decimal import Decimal
    from typing import Dict, Generic, Iterable, List, Optional, TypeVar
    import unittest

    from ..commons.numbers import Amount
    from ..commons.zeitgeist import DateRange
    from ..journaling.algebra import ReadJournalEntries
    from .accounting import Account, Balance, DatePoint, InitialBalances, ReadInitialBalances
    from .journaling import JournalEntry, Posting
    from .ledgering import GeneralLedger, GeneralLedgerProgram, Ledger, build_general_ledger, compile_general_ledger_program

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    class TestCase(unittest.TestCase):
        """
        Test case for the class GeneralLedger.
        """


# Generated at 2022-06-21 20:02:05.360602
# Unit test for method __repr__ of class GeneralLedger

# Generated at 2022-06-21 20:02:17.373844
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
	accountA = Account('1', "First Account", "This is the first account", True, None)
	balanceA = Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0)))
	ledgerA = Ledger(accountA, balanceA)
	
	journalentryA = JournalEntry(datetime.date(2020, 1, 1), "This is the first journal entry", "")
	postingA1 = Posting(accountA, journalentryA, Amount(Decimal("1000")), 1)
	postingA2 = Posting(accountA, journalentryA, Amount(Decimal("-1000")), -1)
	
	## Create the first ledger entry.
	entryA1 = LedgerEntry(ledgerA, postingA1, Quantity(1000))

# Generated at 2022-06-21 20:02:26.960477
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    import datetime
    from decimal import Decimal
    from ..accounts import Account
    from ..commons.numbers import Amount
    from ..journaling import Posting
    from .accounts import AccountType

    acc_assets = Account("Assets", AccountType.ASSET)
    acc_cash = Account("Cash", AccountType.ASSET)
    acc_accounts_receivable = Account("Accounts Receivable", AccountType.ASSET)
    acc_share_capital = Account("Share Capital", AccountType.CAPITAL)
    acc_revenues = Account("Revenues", AccountType.REVENUE)
    acc_expenses = Account("Expenses", AccountType.EXPENSE)
    acc_accounts_payable = Account("Accounts Payable", AccountType.LIABILITY)

# Generated at 2022-06-21 20:02:38.423271
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():

    import pytest

    from ..commons.zeitgeist import DateRange

    from .accounts import Account

    from .journaling import JournalEntry, Posting, ReadJournalEntries

    @dataclass
    class InitialBalances:
        """
        Initial balances.
        """

        #: Accounting period.
        period: DateRange

        #: Mapping of accounts to their opening balances.
        initial: Dict[Account, Balance]

    @dataclass
    class JournalEntries:
        """
        Journal entries.
        """

        #: Accounting period.
        period: DateRange

        #: Journal entries.
        journal: List[JournalEntry]

    """
    Read initial balances.
    """


# Generated at 2022-06-21 20:02:48.976206
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    # Mock instances
    import types
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .commons.numbers import Amount, Quantity

    from .accounts import Account
    from .generic import Balance
    from .journaling import Journal, JournalEntry, Posting
    from .ledgering import Ledger
    initial_balances = {"1": Balance(1, Quantity(Decimal(100))), "2": Balance(1, Quantity(Decimal(200)))}
    def read_journal_entries(period):
        # Mock journal entries (created with an external source)
        journal1 = JournalEntry(5, "Transfusion", Journal([Posting(5, "1", Amount(Decimal(100)), False), Posting(5, "2", Amount(Decimal(100)), True)]))

# Generated at 2022-06-21 20:03:06.102821
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    ledger_one = Ledger(Account(3), Balance(datetime.date(2019, 1, 1), Quantity(Decimal(1000.0))))
    ledger_two = Ledger(Account(3), Balance(datetime.date(2019, 1, 1), Quantity(Decimal(1000.0))))
    ledger_three = Ledger(Account(4), Balance(datetime.date(2019, 1, 1), Quantity(Decimal(1000.0))))
    assert ledger_one == ledger_one
    assert ledger_one == ledger_two
    assert ledger_two == ledger_one
    assert ledger_one != ledger_three
    assert ledger_two != ledger_three
    assert ledger_three != ledger_one
    assert ledger_three != ledger_two
    assert ledger_one != None
    assert ledger_two != None
    assert ledger_three != None



# Generated at 2022-06-21 20:03:17.557694
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from dataclasses import dataclass
    from types import SimpleNamespace
    from .accounts import Account

    from ..commons.zeitgeist import DateRange

    from .general_ledger import ReadInitialBalances

    @dataclass
    class MockInst(object):
        def __call__(self, period: DateRange) -> Dict[Account, SimpleNamespace]:
            pass

    obj = MockInst()
    obj.__call__(DateRange(since=date(2016, 1, 1), until=date(2016, 12, 31)))
    assert isinstance(obj, ReadInitialBalances)
    assert isinstance(obj, MockInst)

# Generated at 2022-06-21 20:03:29.894129
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    period = DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 2, 28))
    account1 = Account("1000", "Cash at Bank")
    account2 = Account("2000", "Cash on Hand")
    account3 = Account("3000", "Accounts Receivable")
    account4 = Account("4000", "Office Supply")
    account5 = Account("5000", "Accounts Payable")
    account6 = Account("6000", "Office Rent")
    account7 = Account("7000", "Business Tax")


# Generated at 2022-06-21 20:03:34.325059
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    assert eval(repr(Ledger(Account(1), Balance(datetime.date(2020, 9, 13), Quantity(1))))) == Ledger(Account(1), Balance(datetime.date(2020, 9, 13), Quantity(1)))


# Generated at 2022-06-21 20:03:41.508419
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    from ..books.journal import Journal
    from ..books.posting import Posting
    from ..books.accounts import Account, Accounts
    from ..books.journaling import JournalEntry, ReadJournalEntries
    from ..books.journaling.algebras import read_journal_entries_from_scratch_book
    from ..books.books import get_book

    general_ledger_program = compile_general_ledger_program(lambda period: {}, read_journal_entries_from_scratch_book)
    ledger = general_ledger_program(DateRange.since(datetime.date(2020, 1, 1)).until(datetime.date(2020, 1, 31)))

    book = get_book("Test")

# Generated at 2022-06-21 20:03:43.388640
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    print(Ledger(1000, Balance(Decimal(0))))

# Generated at 2022-06-21 20:03:50.346157
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    ## Create the program which builds general ledge for a given period:
    program = compile_general_ledger_program(lambda period: InitialBalances({Account("0001"): Balance(period.since, Quantity(Decimal(0)))}), lambda period: [])

    ## Program must consume the period and return a general ledger:
    assert isinstance(program(DateRange(datetime.date(2018, 11, 1), datetime.date(2018, 11, 30))), GeneralLedger)

# Generated at 2022-06-21 20:03:58.298440
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    account1 = Account(1)
    account2 = Account(2)
    account3 = Account(3)
    initialBalances = {
        account1: Balance(datetime.date(2000, 1, 1), Quantity(Decimal(100))),
        account2: Balance(datetime.date(2000, 1, 1), Quantity(Decimal(200))),
        account3: Balance(datetime.date(2000, 1, 1), Quantity(Decimal(300))),
    }
    period = DateRange(datetime.date(2000, 1, 1), datetime.date(2000, 2, 28))
    firstLedger = Ledger(account1, initialBalances[account1])
    firstLedger.add(Posting(firstLedger, datetime.date(2000, 2, 15), Quantity(Decimal(20)), True, None))

# Generated at 2022-06-21 20:04:09.559285
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account

    # Define a test ledger:
    account = Account("test", "Test ledger")
    initial = Balance(datetime.date(2020, 1, 1), Quantity(Decimal(1000)))
    test_ledger = Ledger(account, initial)
    # Create a test posting:
    debit_account = Account("test_debit", "Debit account")
    credit_account = Account("test_credit", "Credit account")
    test_posting = Posting(debit_account, Quantity(Decimal(100)))
    # Test the add method:
    assert test_ledger.add(test_posting).debit == Quantity(Decimal(100))
    assert test_ledger.add(test_posting).balance == Quantity(Decimal(1100))
    # Test the properties:
    assert test_

# Generated at 2022-06-21 20:04:19.221460
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .build import build_journal_reader
    from .commons.randomness import random_business_period
    from .journaling import ReadJournalEntries


# Generated at 2022-06-21 20:04:38.137367
# Unit test for method __repr__ of class GeneralLedger

# Generated at 2022-06-21 20:04:47.463453
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .generic import AccountTypes, Balance

    from .accounts import Account
    from .journaling import Journal, Posting

    ## Create a test account:
    account = Account("A1", AccountTypes.Asset, "Test account")

    ## Create a test ledger:
    ledger = Ledger(account, Balance(datetime.date.today(), Quantity(Decimal(100))))

    ## Create a test journal:
    journal = Journal(datetime.date.today(), "Test journal")

    ## Create two debit postings:
    posting1 = Posting(journal, account, Quantity(Decimal(10)), "Test")
    posting2 = Posting(journal, account, Quantity(Decimal(20)), "Test")

    ## Add the postings to the ledger:
    ledger.add(posting1)
    ledger.add(posting2)

    ## Assert

# Generated at 2022-06-21 20:04:59.498387
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    @dataclass
    class InitialBalances:
        """
        Provides an initial balances model.
        """

        #: Date of the initial balances.
        date: datetime.date

        #: Accounts with the opening balance amount.
        accounts: List[Account]


    class TestReadInitialBalances(Protocol):
        """
        Read initial balances.
        """

        def __call__(self, period: DateRange) -> InitialBalances:
            pass


    class TestReadInitialBalancesImpl(TestReadInitialBalances):
        """
        Read initial balances.
        """

        def __call__(self, period: DateRange) -> InitialBalances:
            return InitialBalances(period.since - datetime.timedelta(days=1), [])


    TestReadInitialBalancesImpl()

# Generated at 2022-06-21 20:05:00.111216
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    assert 1==1

# Generated at 2022-06-21 20:05:08.144460
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    from ..accounts.types import Account
    from ..commons.numbers import Amount
    from .categories import Category
    from .generic import InitialBalance, Balance
    from datetime import date
    from typing import Dict

    @dataclass
    class ReadInitialBalancesImpl:
        def __call__(self, period: DateRange) -> Dict[Account, Balance]:
            return {Account(Category.ASSET, "Cash"): InitialBalance(date(2018, 1, 1), 0)}

    initial_balances = ReadInitialBalancesImpl()
    assert initial_balances
    result = initial_balances(None)
    assert result['Cash'].value == 0


# Generated at 2022-06-21 20:05:12.601031
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    assert(str(repr(GeneralLedger(DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31)), {})))=="GeneralLedger(DateRange(since=datetime.date(2018, 1, 1), until=datetime.date(2018, 12, 31)), {})")

# Generated at 2022-06-21 20:05:22.240968
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    from datetime import date
    from ..commons.zeitgeist import date_range
    from .accounts import Account
    from .journaling import Posting, JournalEntry, PostingType

    a = Account("1000")
    b = Account("1100")
    c = Account("1200")
    d = Account("1210")
    e = Account("1220")
    f = Account("2000")
    g = Account("2100")
    h = Posting(a, PostingType.debit, Decimal(100))
    i = Posting(b, PostingType.credit, Decimal(50))
    j = Posting(c, PostingType.debit, Decimal(100))
    k = Posting(d, PostingType.credit, Decimal(75))

# Generated at 2022-06-21 20:05:29.751067
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    date_range = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))
    a = Account("a", "a")
    b = Account("b", "b")
    ledgers = {a: Ledger(a, Balance(a.name, Quantity(0))), b: Ledger(b, Balance(b.name, Quantity(0)))}
    gl = GeneralLedger(date_range, ledgers)
    assert (gl.period == date_range)
    assert (gl.ledgers == ledgers)

# Generated at 2022-06-21 20:05:30.192770
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert []

# Generated at 2022-06-21 20:05:42.104539
# Unit test for method add of class Ledger
def test_Ledger_add():
    ## Setup test
    class ReadJournalEntriesMock:
        def __init__(self, posting_list):
            self.posting_list = posting_list

        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            return self.posting_list

    a = Accounting()

    initial_balances = {}
    journal_entries = JournalEntry([Posting(datetime.datetime(2020, 4, 1, 0, 0).date(),a.bank, Decimal(100), "Test")])

    initial_balances = {}
    l1 = Ledger(a.bank, Balance(datetime.datetime(2020, 4, 1, 0, 0).date(),Quantity(Decimal(0))))

# Generated at 2022-06-21 20:06:06.790915
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    """
    Test to see whether dataclass GeneralLedgerProgram is created correctly
    """
    ## Create function that corresponds to ReadInitialBalances
    read_initial_balances = lambda period: {period.since:"balance"}

    ## Create function that corresponds to ReadJournalEntries
    read_journal_entries = lambda period: {period.since:"Balance"}

    ## Instantiate GeneralLedgerProgram and test whether it is instantiated correctly
    assert len(compile_general_ledger_program(read_initial_balances, read_journal_entries)) != 0


# Generated at 2022-06-21 20:06:16.503070
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..accounting.algebra import initialize_accounts_model
    from ..accounting.journaling import initialize_journal_entries_model

    # Set up an initial balances repo
    InitialBalancesRepo = initialize_accounts_model("InitialBalancesRepo")
    initial_balances_repo_impl = InitialBalancesRepo.impl
    assert initial_balances_repo_impl([]) == {}

    # Set up a journal entries repo
    JournalEntryRepo = initialize_journal_entries_model("JournalEntriesRepo")
    journal_entries_repo_impl = JournalEntryRepo.impl
    assert journal_entries_repo_impl([]) == []

    # Build the program

# Generated at 2022-06-21 20:06:28.105475
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    # Setup
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))
    journal_entry1 = JournalEntry(
        date=datetime.date(2019, 1, 1),
        description="Description1",
        posting1=Posting(
            account=Account(code="100", title="Account100"),
            amount=Amount(Decimal(10)),
            direction=PostingDirection.INBOUND
        ),
        posting2=Posting(
            account=Account(code="101", title="Account101"),
            amount=Amount(Decimal(10)),
            direction=PostingDirection.OUTBOUND
        )
    )

# Generated at 2022-06-21 20:06:36.766390
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    entry1 = LedgerEntry(
        Ledger(Account(10, "Test Account"), Balance(datetime.date(2017, 1, 1), Quantity(Decimal(1000)))),
        Posting(
            JournalEntry(datetime.date(2017, 1, 1), "Test Journal Entry"),
            Account(10, "Test Account"),
            Quantity(Decimal(100)),
        ),
        Quantity(Decimal(1100)),
    )

# Generated at 2022-06-21 20:06:45.333665
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    from ..books.journaling import JournalEntry, Posting
    from ..books.accounts import Account

    accounts: Dict[str, Account] = {
        "assets": Account(account_no=0, title="Assets", is_terminal=False),
        "cash": Account(account_no=1, title="Cash", is_terminal=True),
    }

    journal = JournalEntry(
        date=datetime.date.fromisoformat("2020-01-01"), description="Cash deposit", postings=[
            Posting(account=accounts["cash"], amount=1000, direction=True),
            Posting(account=accounts["assets"], amount=1000, direction=False),
        ]
    )


# Generated at 2022-06-21 20:06:46.863338
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    assert True

# Generated at 2022-06-21 20:06:53.582317
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    firstAccount = Account(1, "Cash")
    secondAccount = Account(2, "Supplier")
    firstEntry = Ledger(firstAccount, Balance(datetime.date(2019, 12, 1), Quantity(2)))
    secondEntry = Ledger(secondAccount, Balance(datetime.date(2019, 12, 1), Quantity(2)))
    assert firstEntry == firstEntry
    assert secondEntry == secondEntry
    assert firstEntry != secondEntry


# Generated at 2022-06-21 20:07:02.268179
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    class Algebra1:
        def __call__(self, period: DateRange):
            return {"acc": Balance(datetime.date(2020, 9, 30), Quantity(Decimal(100)))}

    class Algebra2:
        def __call__(self, period: DateRange):
            return [JournalEntry(datetime.date(2020, 9, 30), "Test", [Posting(False, Quantity(Decimal(100)))])]

    function1 = Algebra1()
    function2 = Algebra2()

    program = compile_general_ledger_program(function1, function2)
    result = program(DateRange(datetime.date(2020, 9, 30), datetime.date(2020, 9, 30)))


# Generated at 2022-06-21 20:07:09.893044
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    # The required input is the period that the general ledger will cover.
    period = [datetime.date(2020, 1, 1), datetime.date(2020, 1, 31)]
    print("Period: {}".format(period))
    # The output is the general ledger that covers the specified period.
    # ledger = compile_general_ledger_program(period)
    # print("ledger: {}".format(ledger))
    
    

# Generated at 2022-06-21 20:07:18.557834
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    """
    Testing function for class GeneralLedger
    """
    from ..journaling import (
        JournalEntry,
        Posting,
        ReadJournalEntriesFromInMemory,
    )
    from .accounts import build_account
    from .commons import Balance, Quantity
    from .journaling import build_accounting_period

    ## Create the accounts.
    cash = build_account(
        code="CASH",
        description="Cash",
        group="Cash, bank accounts, and short-term investments",
        classification="Asset",
        balance_type="Debit",
    )
    accounts_receivable = build_account(
        code="AR",
        description="Accounts receivable",
        group="Current assets",
        classification="Asset",
        balance_type="Debit",
    )
    taxes_payable = build_

# Generated at 2022-06-21 20:08:01.799412
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    from .accounts import Account
    from .commons import Currency
    from .journaling import Posting
    from .quantities import Quantity, Value
    from .money import Money
    from .commons import DateRange
    from typing import Generic, List, TypeVar
    from decimal import Decimal
    T = TypeVar('T', covariant=True, bound=Value)
    class Quantity(Generic[T], Value):
        _value: T
        def __init__(self, value: T) -> None:
            if value is None:
                raise ValueError("Invalid 'None' value.")
            self._value = value
        @property
        def value(self) -> T:
            return self._value
    class Balance(Quantity[Decimal]):
        _date: datetime.date

# Generated at 2022-06-21 20:08:14.213165
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .accounts import Account, AccountFreeze
    from .commons import Amount, Quantity
    from .journaling import JournalEntry, Posting, PostingDirection

    #: Create test accounts:
    accounts = [
        Account("000", "Cash"),
        Account("100", "Accounts Receivable"),
        Account("200", "Inventory"),
        Account("500", "Sales"),
        Account("800", "Cost of Goods Sold"),
    ]
    #: Create posting direction enum:
    DEBIT = PostingDirection(1)
    CREDIT = PostingDirection(-1)

    ## Create test postings:

# Generated at 2022-06-21 20:08:27.098823
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    # setup
    posting = Posting(Account("1"), Quantity(1), True)

    # assign
    ledger_entry = LedgerEntry(Ledger(Account("1"), Balance(datetime.date(2000, 1, 1), Quantity(1))), posting,
                               Quantity(1))

    # assert
    assert ledger_entry.ledger == Ledger(Account("1"), Balance(datetime.date(2000, 1, 1), Quantity(1)))
    assert ledger_entry.posting == posting
    assert ledger_entry.balance == Quantity(1)
    assert ledger_entry.date == posting.date
    assert ledger_entry.description == posting.journal.description
    assert ledger_entry.amount == posting.amount

# Generated at 2022-06-21 20:08:38.096704
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from .accounts import Account
    from .journaling import Journal, Posting, ReadPostings
    a1=Account(1,"1234","cash")
    a2=Account(2,"1234","cash")
    period = DateRange(datetime.date(2020, 7, 1), datetime.date(2020, 7, 2))
    j1 = Journal(1, period.since, "New beginning", [Posting(a1, Decimal(1)), Posting(a2, Decimal(1))])
    ledger=Ledger(a1,Balance(period.since, Quantity(Decimal(0))))
    ledger.add(j1.postings[0])
    ledger.add(j1.postings[1])
    entry=LedgerEntry(ledger,j1.postings[0],Quantity(Decimal(1)))
   

# Generated at 2022-06-21 20:08:48.852314
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    date_range = DateRange(datetime.date(2020, 8, 1), datetime.date(2020, 8, 31))
    account = Account('1.1.1.1')
    general_ledger = GeneralLedger(date_range, {account: Ledger(account, Balance(date_range.since, Quantity(1)))})
    str_general_ledger = str(general_ledger)
    print(str_general_ledger)

# Generated at 2022-06-21 20:09:01.746174
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    assert GeneralLedger(DateRange(datetime.date(2020,5,5),datetime.date(2020,5,8)),{}) == GeneralLedger(DateRange(datetime.date(2020,5,5),datetime.date(2020,5,8)),{})
    assert GeneralLedger(DateRange(datetime.date(2020,5,5),datetime.date(2020,5,8)),{}) != GeneralLedger(DateRange(datetime.date(2020,4,4),datetime.date(2020,4,7)),{})

# Generated at 2022-06-21 20:09:02.603846
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    assert False


# Generated at 2022-06-21 20:09:07.114385
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    @dataclass
    class ReadInitialBalancesImpl:
        def __call__(period: DateRange) -> InitialBalances:
            return {}

    ReadInitialBalancesImpl()(DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31)))



# Generated at 2022-06-21 20:09:11.023602
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, JournalingProgram, Posting, ReversionType
    from .ledgering import GeneralLedger, build_general_ledger
    g = GeneralLedger('per',{"acc":None})
    assert g.period == 'per'
    assert g.ledgers == {"acc":None}

# Generated at 2022-06-21 20:09:22.063330
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from .interpreters import build_read_initial_balances
    from .interpreters.ledger import build_initial_balances
    from .interpreters.journaling import build_read_journal_entries
    from ..coverage import coverage
    from ..test import (
        JournalEntry,
        Posting,
        build_journal_entries,
        build_read_initial_balances as build_read_initial_balances_,
    )

    # Preamble:
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))
    journal = build_journal_entries(
        JournalEntry(datetime.date(2019, 1, 1), "General ledger initial balances", [Posting(1, 2, Quantity(100))])
    )
    read_initial

# Generated at 2022-06-21 20:10:29.244547
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    period = DateRange(datetime.date(2020, 8, 1), datetime.date(2020, 10, 1))
    journal = []
    initial = InitialBalances()
    gl = build_general_ledger(period, journal, initial)  # gl = GeneralLedger()
    assert gl.period == period
    assert gl.ledgers == {}



# Generated at 2022-06-21 20:10:32.503297
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    assert (
        LedgerEntry(None, Posting(None, None, None), None)
        == LedgerEntry(None, Posting(None, None, None), None)
    )

# Generated at 2022-06-21 20:10:35.369706
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    entry = LedgerEntry(1, 2, 3)
    assert repr(entry) == 'LedgerEntry(1, 2, 3)'

# Generated at 2022-06-21 20:10:42.456619
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .journaling import Journal
    from .generic import Posting, Direction

    journal = Journal('Test Journal')
    journal.add(Direction.Debit, 'Assets:Current:Cash', 10)
    journal.add(Direction.Credit, 'Revenue', 10)

    l = Ledger('Assets:Current:Cash', initial=Balance(date=datetime.date(2018, 1, 1), value=0))
    assert l.add(journal.postings[0]) == LedgerEntry(l, Posting(journal, Direction.Debit, 10), Quantity(10))

# Generated at 2022-06-21 20:10:55.364908
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from .journaling import Journal
    from .accounts import Account, TerminalAccount, Asset

    # Create Journal, Postings and Journal Entry
    account1 = TerminalAccount(1, Asset)
    account2 = TerminalAccount(2, Asset)

    balance1 = Balance(date(2011, 1, 1), Quantity(0))
    balance2 = Balance(date(2011, 1, 1), Quantity(0))
    balance3 = Balance(date(2011, 1, 1), Quantity(0))

    journal = Journal(date(2011, 1, 1), "Journal Entry description 1")
    journal.add_posting(account1, Amount(10))
    journal.add_posting(account2, Amount(10))

    journal2 = Journal(date(2011, 2, 1), "Journal Entry description 2")
    journal2.add_

# Generated at 2022-06-21 20:11:01.452879
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    mockAccount1 = Account("mockAccount1Name")
    mockBalance1 = Balance(datetime.date(2017,6,22), Quantity(Decimal(5)))
    mockPosting1 = Posting(mockAccount1, datetime.date(2017,6,22), Quantity(Decimal(5)), 'mockDirection1')
    mockPosting2 = Posting(mockAccount1, datetime.date(2017,6,23), Quantity(Decimal(4)), 'mockDirection2')
    mockLedger1 = Ledger(mockAccount1, mockBalance1)
    mockLedgerEntry1 = LedgerEntry(mockLedger1,mockPosting1,Quantity(Decimal(5)))

# Generated at 2022-06-21 20:11:05.583474
# Unit test for constructor of class Ledger
def test_Ledger():
    account = Account("Sales", "4")
    balance = Balance(datetime.date(2020, 1, 1), Quantity(Decimal(100)))
    ledger = Ledger(account, balance)
    assert ledger.account == account
    assert ledger.initial == balance
    assert ledger.entries == []
