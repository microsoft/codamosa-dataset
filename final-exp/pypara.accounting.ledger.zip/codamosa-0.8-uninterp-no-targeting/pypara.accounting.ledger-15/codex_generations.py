

# Generated at 2022-06-21 20:01:24.782752
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    from .accounts import Account
    from .journaling import JournalEntry
    from .journaling import Posting
    
    account = Account('100100 Account')
    journal = JournalEntry('Journal ', 'Test journal entry')
    posting = Posting(account, journal, Quantiity(Decimal(100)))

    ledger = Ledger(account, Balance(date, Quantity(Decimal(0))))
    entry = LedgerEntry(ledger, posting, Quantity(Decimal(100)))
    
    assert entry == entry
    assert not entry == None
    assert not entry == ledger
    
    
test_Ledger___eq__()

# Generated at 2022-06-21 20:01:35.881676
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    # Setup:
    # Create the account ledger
    account = Account("44444444444444444444444444444444", 4, "Asset")
    balance = Balance(Decimal(10000), datetime.datetime(1, 1, 1, 0, 0))
    entries = [LedgerEntry(Ledger(account, balance))]
    gl = GeneralLedger(DateRange(datetime.datetime(1, 1, 1, 0, 0), datetime.datetime(1, 1, 1, 0, 0)),
                       {account: Ledger(account, balance, entries)})

    # Act: try to build general ledger
    if gl is None:
        raise Exception('General ledger creation failed')
    else:
        print('General ledger creation successful')


# Generated at 2022-06-21 20:01:47.216554
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from finance.accounting.storages.inmemory import InMemoryAccount, InMemoryJournalEntry
    from finance.accounting.storages.temporal import StrictPeriodicStorage
    from finance.commons.times import date_range

    s = StrictPeriodicStorage(InMemoryJournalEntry)

    ## Define some accounts (and their initial balances):
    a = InMemoryAccount("Assets")
    s.append(a.post(date=datetime.date(2015, 1, 1), amount=Decimal(-200), description=""))

    ## Define some accounts (and their initial balances):
    a = InMemoryAccount("Assets")
    b = InMemoryAccount("Equity")
    c = InMemoryAccount("Income")
    d = InMemoryAccount("Expenses")

    ## Build a general ledger and assert:
    g

# Generated at 2022-06-21 20:01:59.000927
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import Journal
    from .filtering import PostingFilter, JournalFilter, AccountFilter, SubAccountFilter

    from .testing.journaling import get_journal_entries
    from .testing.accounts import ASSETS, CAPITAL, LIABILITIES, REVENUES, EXPENSES
    from .testing.commons import D

    journal_entries = get_journal_entries()
    period = DateRange(datetime.date(2015, 8, 31), datetime.date(2015, 12, 31))

    ## Build a general ledger without any initial balances, and then print it out.
    gl = build_general_ledger(period, journal_entries, {})
    print(gl)

    ## Build a general ledger with initial balances, and then print it out.

# Generated at 2022-06-21 20:02:05.528484
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    empty_initial_balances = {}
    empty_journal_entries = []
    empty_general_ledger = GeneralLedger(DateRange(datetime.MINYEAR, datetime.MINYEAR), empty_initial_balances)
    mock_read_initial_balances = lambda period: empty_initial_balances
    mock_read_journal_entries = lambda period: empty_journal_entries
    assert compile_general_ledger_program(mock_read_initial_balances, mock_read_journal_entries)(
               DateRange(datetime.MINYEAR, datetime.MINYEAR)
           ) == empty_general_ledger


# Generated at 2022-06-21 20:02:14.951322
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Initializing LedgerEntryPosting with fields "date", "debit", "credit" and value parameters
    posting1 = Posting.for_debit("07.09.2020",10)
    posting2 = Posting.for_credit("07.09.2020",5)
    # Initializing Balance with fields "date" and "value" and value parameters
    initial = Balance("07.09.2020",5)
    # Initializing Ledger with fields "account" and "entries" and value parameters
    ledger1 = Ledger(Account.for_assets("Assets"),initial)
    # Invoking method add for the ledger with the parameter "posting"
    posting_list = [posting1,posting2]
    for posting in posting_list:
        ledgerEntry = ledger1.add(posting)
    # Asserting whether the actual

# Generated at 2022-06-21 20:02:18.387371
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    ledger = Ledger(Account("7020", "Accounts Payable"), Balance(datetime.date.today(), Decimal(50)))
    print(ledger)


# Generated at 2022-06-21 20:02:27.155624
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from paccbet.commons.datetimez import DateTimeZ
    from paccbet.commons.numbers import Amount
    from paccbet.domain.accounts import Account, TerminalAccount

    assert type(ReadInitialBalances.__call__) is ReadInitialBalances.__call__.__class__

    assert ReadInitialBalances.__call__.__annotations__ == {'return': InitialBalances}

    class TestReadInitialBalances(ReadInitialBalances):
        def __init__(self):
            super().__init__()

        def __call__(self, period: DateRange = None) -> InitialBalances:
            if period is None:
                period = DateTimeZ(date.today()).date.date_range


# Generated at 2022-06-21 20:02:38.560429
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():

    from ..commons.zeitgeist import date_range
    from .journaling import Transaction

    ## Create a dummy implementation of journal entries reader.
    def _read_journal_entries(period: DateRange) -> Iterable[Transaction[_T]]:
        """
        Dummy implementation of :py:class:`Transaction` entries reader.
        """
        return list()

    ## Create a dummy implementation of initial balances reader.
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        """
        Dummy implementation of initial balances reader.
        """
        return dict()

    ## Compile the program:
    program = compile_general_ledger_program(_read_initial_balances, _read_journal_entries)

    ## Execute the program:

# Generated at 2022-06-21 20:02:42.906431
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    le1 = LedgerEntry(None,None,Quantity(Decimal(1)))
    le2 = LedgerEntry(None,None,Quantity(Decimal(1)))
    assert le1 == le2, 'Returned false for equal __eq__'

test_LedgerEntry___eq__()


# Generated at 2022-06-21 20:02:56.279548
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    import copy
    import collections
    import mock

    readByInitial = mock.Mock()
    readByInitial.return_value = { 1:2 }

    read = mock.Mock()
    read.return_value = 3

    run = compile_general_ledger_program(readByInitial, read)
    result = run(4)
    print(result)

# Generated at 2022-06-21 20:03:01.265922
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    from .accounts import Account
    from .generic import Balance
    from .journaling import Posting, JournalEntry, Direction
    from .ledgers import Ledger

    posting = Posting(journal=JournalEntry(date=datetime.datetime(2015,12,31).date(), description="Test", postings=[
        Posting(account=Account("Test account"),amount=10, direction=Direction.Debit),
        Posting(account=Account("Test account 2"),amount=-5, direction=Direction.Credit)
    ]), account=Account("Test account"), amount=10, direction=Direction.Debit)

    ledger = Ledger(account=Account("Test account"), initial=Balance(datetime.datetime(2015,12,30).date(),5))
    result = ledger.__repr__()

# Generated at 2022-06-21 20:03:11.595553
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    account = Account("JEAN", "", "", "", "", "", "")
    ledger = Ledger(account, Balance(4, Quantity(4)))
    posting = Posting(1, "", "", "", "", "", "", "", "", [])
    balance = Quantity(4)
    class_object = LedgerEntry(ledger, posting, balance)
    assert class_object.date == posting.date
    assert class_object.description == posting.journal.description
    assert class_object.is_debit == posting.is_debit
    assert class_object.is_credit == posting.is_credit
    assert class_object.debit == posting.amount if posting.is_debit else None 
    assert class_object.credit == posting.amount if posting.is_credit else None
    assert class_object

# Generated at 2022-06-21 20:03:24.178229
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.test.test_journaling import create_journal_entries
    from .accounts import AccountSpec
    from .financial_periods import FinancialPeriod

    period = FinancialPeriod(datetime.datetime(2020, 1, 1), datetime.datetime(2020, 12, 31))
    account_tree = AccountSpec("Assets")
    assets = account_tree.resolve("Assets")
    inventory = account_tree.resolve("Assets/Inventory")
    journal_entries = create_journal_entries(period, account_tree)

    initial_balances = {inventory: Balance(period.since, Quantity(Decimal(1000)))}

    general_ledger = build_general_ledger(period, journal_entries, initial_balances)
    assert general_ledger.ledgers[inventory].ent

# Generated at 2022-06-21 20:03:36.552675
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    # Test that error is raised when period argument is not of type DateRange
    try:
        GeneralLedger(datetime.date(2019, 10, 10), {})
        raise ValueError('test_GeneralLedger test 1 failed')
    except TypeError:
        pass

    # Test that error is raised when ledgers argument is not of type Dict[Account, Ledger[_T]]
    try:
        GeneralLedger(DateRange(datetime.date(2019, 10, 10), datetime.date(2019, 10, 10)), [])
        raise ValueError('test_GeneralLedger test 2 failed')
    except TypeError:
        pass
    
    #Test whether GeneralLedger object is created without error 

# Generated at 2022-06-21 20:03:38.170443
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    assert ReadInitialBalances()



# Generated at 2022-06-21 20:03:45.999962
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    a = LedgerEntry(ledger = None, posting = None, balance = None)
    b = LedgerEntry(ledger = None, posting = None, balance = None)
    c = LedgerEntry(ledger = None, posting = None, balance = None)
    
    assert hash(a) == hash(b) and hash(a) == hash(c) and hash(b) == hash(c)
    assert a == b and a == c and b == c

# Generated at 2022-06-21 20:03:55.811226
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    # Arrange
    from ledger.models.entries import JournalEntries
    posting1 = Posting(Account("42"), 2, "", JournalEntries())
    posting2 = Posting(Account("43"), 3, "", JournalEntries())
    posting1.journal.add(posting1)
    posting1.journal.add(posting2)
    initial = Balance(datetime.datetime(2020, 1, 1, 0, 0, 0), Decimal(5))
    # Act
    ledger = Ledger[str](Account("42"), initial)
    ledger.add(posting1)
    strRepr = ledger.__repr__()
    # Assert

# Generated at 2022-06-21 20:03:56.892273
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
	pass


# Generated at 2022-06-21 20:04:05.509437
# Unit test for method add of class Ledger
def test_Ledger_add():
    acct = Account("Account")
    t = "T"
    direction = t
    balance = Quantity(Decimal(0))
    opening = Balance(DateRange().since, balance)
    ledger = Ledger(acct, opening)
    journal = JournalEntry(DateRange().since, 1, "desc", [Posting(t, 0, direction, acct)])
    posting = Posting(t, Decimal(0), direction, acct)
    posting.journal = journal
    expected = LedgerEntry(ledger, posting, balance)
    actual = ledger.add(posting)
    assert expected is actual


# Generated at 2022-06-21 20:04:18.353419
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():

    # declare objects
    account = Account("A0001")
    initial = Balance(datetime.datetime(2018, 9, 1, 0, 0), Quantity(Decimal(1000)))
    ledger = Ledger(account, initial)

    # AssertionError, object instantiated is not equal to the object expected

# Generated at 2022-06-21 20:04:29.810235
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    """
    Unit test for method __repr__ of class GeneralLedger.
    """
    ## Arrange:
    period = DateRange(since=datetime.date(2019, 1, 1), until=datetime.date(2019, 12, 31))
    entries = [
        LedgerEntry(
            ledger=Ledger(
                account=Account(name="Best Travel"),
                initial=Balance(date=None, value=Quantity(Decimal(0))),
                entries=[],
            ),
            posting=Posting(
                account=Account(name="Best Travel"),
                direction=Direction.debit,
                amount=Amount(Decimal(18.75)),
            ),
            balance=Quantity(Decimal(18.75)),
        ),
    ]

    ## Act:

# Generated at 2022-06-21 20:04:41.104378
# Unit test for function build_general_ledger
def test_build_general_ledger():
    """
    Unit tests for function build_general_ledger
    """
    from ..commons.zeitgeist import month_range
    from ..domain.entities import Account, Debit

    date_range = month_range("2020-01-01", "2020-12-31")
    period = DateRange(date_range[0], date_range[-1])

    # Sale of goods
    sale_of_goods = Account("01-0001", name="Sale of Goods")

    # Cash receipts from sale of goods
    cash_receipts_from_sale_of_goods = Account("01-0003", name="Cash Receipts from Sale of Goods")

    # Supplies
    supplies = Account("02-0001", name="Supplies")

    # Accounts receivable

# Generated at 2022-06-21 20:04:42.123942
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    pass


# Generated at 2022-06-21 20:04:49.819550
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    import types

    # Test if the type returned is a function
    _T = TypeVar('_T')
    read_initial_balances = lambda period: InitialBalances
    read_journal_entries = lambda period: JournalEntry[_T]
    compiled_general_ledger_program = compile_general_ledger_program(read_initial_balances, read_journal_entries)
    assert(isinstance(compiled_general_ledger_program, types.LambdaType))

    # Test if the type returned from the function is correct
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 31))
    compiled_general_ledger_program2 = compiled_general_ledger_program(period)

# Generated at 2022-06-21 20:04:50.555550
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    pass

# Generated at 2022-06-21 20:05:03.207720
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import parse_date

    @dataclass
    class _InitialBalance:
        account: Account
        balance: Balance

    @dataclass
    class _JournalEntry:
        date: datetime.date
        description: str
        postings: List[Posting]

        @property
        def account(self) -> Account:
            return self.postings[0].account

        @property
        def amount(self) -> int:
            return sum(p.amount for p in self.postings)

    # Mock implementations of initial balance reading algebra and journal entry reading algebra:

# Generated at 2022-06-21 20:05:04.368202
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert False, "Not implemented!"



# Generated at 2022-06-21 20:05:15.445373
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .journaling import Journal, Posting
    from .accounts import Account, AccountType

    journal = Journal(
        datetime.datetime(2020, 6, 30), "Journal Entry", [
            Posting(
                datetime.datetime(2020, 6, 30),
                Account(AccountType.Expense, 'Repairs'),
                Quantity(100),
                'Repairs and Maintenance'
            ),
            Posting(
                datetime.datetime(2020, 6, 30),
                Account(AccountType.Asset, 'Cash'),
                Quantity(-100),
                'Repairs and Maintenance'
            ),
        ]
    )
    posting = journal.postings[0]

# Generated at 2022-06-21 20:05:27.637876
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    try:
        import pytest
    except ImportError:
        pytest = None

    if pytest is None:
        return
    ## Create initial balances algebra implementation:

# Generated at 2022-06-21 20:05:51.686677
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    """
    Constructor of class GeneralLedger
    """
    from datetime import date
    from .accounts import Account

    gL = GeneralLedger(date(2020,1,1), date(2020,12,31), 
    {
        Account("1.11.21"): Ledger(Account("1.11.21"), Balance(date(2020, 1, 1), Quantity(100))),
        Account("1.11.22"): Ledger(Account("1.11.22"), Balance(date(2020, 1, 1), Quantity(200)))
    })
    assert gL.period.since == date(2020,1,1)
    assert gL.period.until == date(2020,12,31)
    assert gL.ledgers[Account("1.11.21")].account == Account("1.11.21")


# Generated at 2022-06-21 20:06:04.546400
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    account1 = Account("account1", "", "")
    account2 = Account("account2", "", "")
    account3 = Account("account3", "", "")
    account4 = Account("account4", "", "")
    account5 = Account("account5", "", "")
    account6 = Account("account6", "", "")
    account7 = Account("account7", "", "")
    account8 = Account("account8", "", "")


# Generated at 2022-06-21 20:06:15.213013
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    from .journaling import Journal, Posting
    from .accounts import Account

    a1 = Account('1000','Assets','Current Assets','Cash','Checking')
    a2 = Account('2000','Liabilities','Current Liabilities','Accounts Payable')
    journal = Journal('10/15/18', '', 'Payroll for October')
    posting1 = Posting(journal, a1, 1000, 'debit')
    posting2 = Posting(journal, a2, 1000, 'credit')

    l1 = Ledger(a1, Balance(posting1.date, posting1.amount))
    l2 = Ledger(a1, Balance(posting1.date, posting1.amount))
    l3 = Ledger(a2, Balance(posting2.date, posting2.amount))

# Generated at 2022-06-21 20:06:27.904483
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Unit test for function compile_general_ledger_program.
    """

    import datetime as dt
    import random
    import unittest

    from pytest import raises

    from ..commons.zeitgeist import DateRange

    from .accounts import Account, Type

    from .journaling import JournalEntry, Posting, compile_posting_program
    from .ledgering import build_general_ledger, compile_general_ledger_program

    #: Defines an account's initial balance.
    Balance = Decimal

    #: Defines a balance sheet account.
    BalanceSheetAccount = Account

    #: Defines a dictionary of balance sheet accounts and their respective initial balances.
    BalanceSheet = Dict[BalanceSheetAccount, Balance]

    #: Defines a balance sheet account's initial balance.
    BalanceShe

# Generated at 2022-06-21 20:06:40.335167
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    # Generates all input arguments of the function under test,
    # using all possible values of the type.
    period = DateRange(since=datetime.date(2019, 8, 15), until=datetime.date(2019, 9, 14))
    ledgers = dict()
    account_temp = Account(name='account1')
    initial2 = Balance(date=datetime.date(2019, 9, 14), value=Quantity(Decimal(99)))
    entries = list()

# Generated at 2022-06-21 20:06:52.674084
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    """This function unit test the method __eq__ of class Ledger
    """
    ## initialisation
    accountA = Account("", "A", "", [], True)
    accountB = Account("", "B", "", [], True)
    ledgerA = Ledger(accountA, Balance(datetime.date.today(), Quantity(Decimal(5))))
    ledgerB = Ledger(accountB, Balance(datetime.date.today(), Quantity(Decimal(5))))
    ## test with same object
    assert ledgerA == ledgerA
    ## test with different object but same account and same initial
    assert ledgerA == Ledger(accountA, Balance(datetime.date.today(), Quantity(Decimal(5))))
    ## test with different object but same account and one different initial

# Generated at 2022-06-21 20:07:01.716082
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    initial_balances = {
        Account("Payable"): Balance(
            period=DateRange(since=datetime.date.fromisoformat("2020-01-01"), until=datetime.date.fromisoformat("2020-01-31")),
            value=Quantity(Decimal("2.22"))
        ),
        Account("Receivable"): Balance(
            period=DateRange(since=datetime.date.fromisoformat("2020-01-01"), until=datetime.date.fromisoformat("2020-01-31")),
            value=Quantity(Decimal("2.22"))
        ),
    }


# Generated at 2022-06-21 20:07:13.858012
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Test for the GeneralLedgerProgram.__call__() method.
    """

    # Import required packages:
    from datetime import date, timedelta
    from operator import itemgetter
    from typing import NamedTuple

    # Import modules for which we are compiling program:
    from ..initialbalances import ReadInitialBalances as _ReadInitialBalances
    from ..journaling import ReadJournalEntries as _ReadJournalEntries

    # Define a mock type to simulate initial balances input:
    class _InitialBalances(NamedTuple):
        """
        Represents initial balances.
        """

        #: Accounting period.
        period: DateRange

        #: Initial balances.
        balances: InitialBalances

    # Define a mock type to simulate journal entries input:

# Generated at 2022-06-21 20:07:20.465590
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    account = Account(1, 'Test Account No.', 'Test account')
    initial = Balance(datetime.date(2020,7,31), Quantity(Decimal('150000.00')))
    ledger = Ledger(account, initial)
    ledger.add(Posting(datetime.date(2020,7,31), None, None, None))
    ledger.add(Posting(datetime.date(2020,8,31), None, None, None))


# Generated at 2022-06-21 20:07:31.168099
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Set up test data
    entry = LedgerEntry(Ledger(Account('A'), Balance(datetime.date(2020, 1, 1), Quantity(Decimal(1200)))), Posting(datetime.date(2020, 1, 1), JournalEntry(datetime.date(2020, 1, 1), 'Description 1', [Posting(datetime.date(2020, 1, 1), Account('B'), Quantity(Decimal(200)),  True), Posting(datetime.date(2020, 1, 1), Account('A'), Quantity(Decimal(200)), False)]), Account('A'), Quantity(Decimal(200)), False), Quantity(Decimal(1000)))
    assert entry.balance == Quantity(Decimal(1000))
    
    # Test add

# Generated at 2022-06-21 20:08:25.464195
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    assert ReadInitialBalances

# Generated at 2022-06-21 20:08:37.758834
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    # Test data
    z1 = LedgerEntry(
        ledger=Ledger(
            account=Account('E100000'), initial=Balance(date=None, value=Quantity(10)),
        ),
        posting=Posting(
            account=Account('E100000'),
            amount=Amount(5),
            description='',
            journal=JournalEntry(
                date=datetime.date(2020, 1, 1),
                description='',
                postings=[
                    Posting(
                        account=Account('E100000'),
                        amount=Amount(5),
                        description='',
                        journal=None,
                        direction=None,
                    ),
                ],
            ),
            direction=None,
        ),
        balance=Quantity(15),
    )

# Generated at 2022-06-21 20:08:46.875625
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Set up a sample journal
    journal = JournalEntry([Posting(Account.of_account('100.010'), Decimal(100), datetime.date(2020, 7, 30), "Test 1")])

    # Set up initial balance and inialize Ledger
    initial_balance = Balance(datetime.date(2020,7,1), Decimal(0))
    ledger = Ledger(Account.of_account('100.010'), initial_balance)

    # Test add method of class Ledger
    ledger.add(journal.postings[0])
    assert ledger.entries[0].balance == Decimal(100)



# Generated at 2022-06-21 20:08:53.919763
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    a = Account('1')
    b = Balance(date = datetime.date(2020,1,1), value = Decimal(10))
    e = LedgerEntry(None, None, Quantity(Decimal(-1)))
    l = Ledger(a, b, entries= [ e ])
    assert l.__repr__() == 'Ledger(account=Account(accnum=1), initial=Balance(date=datetime.date(2020, 1, 1), value=Decimal(\'10\')), entries=[LedgerEntry(ledger=None, posting=None, balance=Quantity(Decimal(\'-1\')))]), '


# Generated at 2022-06-21 20:08:55.465003
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():

    # This is an empty method definition for the time being.
    return NotImplemented

# Generated at 2022-06-21 20:09:04.985321
# Unit test for method add of class Ledger
def test_Ledger_add():
    from budget.registry import Registry
    from budget.commons.zeitgeist import Month
    from budget.journaling import JournalEntry, Posting, build_journal_entry
    from budget.accounts import Account, AccountCode, AccountType

    reg = Registry()
    reg.accounts.add_account(Account('Salary', AccountType.revenue, AccountCode('4001')))
    reg.accounts.add_account(Account('Bonus', AccountType.revenue, AccountCode('4002')))
    reg.accounts.add_account(Account('Rent', AccountType.expense, AccountCode('5001')))
    reg.accounts.add_account(Account('Consulting', AccountType.expense, AccountCode('5002')))

# Generated at 2022-06-21 20:09:05.712105
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    pass

# Generated at 2022-06-21 20:09:13.381268
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import JournalEntry
    from .postings import Posting
    from .test import accounts
    from .types import Date
    from .zeitgeist import DateRange

    period = DateRange(Date(2018, 1, 1), Date(2018, 12, 31))


# Generated at 2022-06-21 20:09:23.547615
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    #
    from . import accounts
    from . import journaling
    from . import general_ledger as ledger

    #Lägg till tillgångar
    def test_Ledger___eq__():
        b1 = Balance(datetime.date(2020, 1, 1), Quantity(100))
        b2 = Balance(datetime.date(2020, 1, 1), Quantity(100))
        b3 = Balance(datetime.date(2020, 1, 1), Quantity(200))
        ac1 = accounts.AssetAccount("3000", "Stockholm bank", "Bank")
        ac2 = accounts.AssetAccount("3000", "Stockholm bank", "Bank")
        ac3 = accounts.AssetAccount("3001", "Stockholm bank", "Bank")
        assert ac1 == ac2
        assert ac1 != ac3

        #Lägg till

# Generated at 2022-06-21 20:09:28.457068
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from .journaling import SampleJournalEntry, SamplePosting
    ledger = LedgerEntry(Ledger(10, Balance(datetime.date(2017, 1, 1), Quantity(Decimal(10)))), SamplePosting.credit, 200)
    assert ledger.ledger.account == 10
    assert ledger.posting.amount == 100
    assert ledger.balance == 200


# Generated at 2022-06-21 20:10:43.410906
# Unit test for constructor of class Ledger
def test_Ledger():
    """
    Tests the constructor of class Ledger.

    :return: None.
    """
    # Initialize account ledger
    account = Account("1010", "Cash")
    balance = Balance('2020-01-01', Quantity(0))
    entries = []
    ledger = Ledger(account, balance, entries)

    # Test case for account of class Ledger
    assert ledger.account == Account("1010", "Cash")

    # Test case for balance of class Ledger
    assert ledger.balance == Quantity(0)

    # Test case for entries of class Ledger
    assert ledger.entries == []


# Generated at 2022-06-21 20:10:44.403378
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass

# Generated at 2022-06-21 20:10:48.982372
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    # Create a class to use as the protocol
    class _ReadInitialBalances:
        def __init__(self, value):
            self.value = value
        def __call__(self, period):
            return self.value
    # Check the type is acceptable
    _test_variable = _ReadInitialBalances(None)
    assert isinstance(_test_variable, ReadInitialBalances)
    # Check the type is not acceptable
    _test_variable = int(1)
    assert not isinstance(_test_variable, ReadInitialBalances)


# Generated at 2022-06-21 20:10:51.745985
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    test = ReadInitialBalances()
    assert (test(1) == {})


# Generated at 2022-06-21 20:11:00.277384
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    from ..algebras import System, build_algebra

    ## Define an algebra and plug-in implementations:
    from ..commons import Amount, InitialBalance, Quantity, ReadInitialBalances

    algebra = build_algebra(System.initial_balances, System.journaling)
    algebra.initial_balances = ReadInitialBalances(
        lambda period: {
            InitialBalance.liability_customers: Balance(
                period.since, Amount(Decimal("42.42"))
            )
        }
    )

# Generated at 2022-06-21 20:11:07.585793
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from typing import Dict

    from ..commons.numbers import Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountNumber
    from ..apps.accounting.commons.numbers import Amount

    # Initialize mock
    mock = Mock(spec=ReadInitialBalances)

    # Invoke method
    result = mock(DateRange(date(2015,1,1), date(2015,12,31)))

    # Check result
    assert result == {} # type: ignore



# Generated at 2022-06-21 20:11:08.367243
# Unit test for constructor of class Ledger
def test_Ledger():
    temp = Ledger(0,0)

# Generated at 2022-06-21 20:11:15.672994
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # given
    from pyspecification.specifications import be, equal_to, satisfy

    read_initial_balances = lambda period: dict(A=Balance(period.since, Quantity(100)))
    read_journal_entries = lambda period: [
        JournalEntry(
            date=datetime.date(2018, 1, 1),
            description="Debit A for 100",
            postings=[Posting(Account("A"), Amount(100), True)],
        ),
        JournalEntry(
            date=datetime.date(2018, 1, 2),
            description="Credit A for 50",
            postings=[Posting(Account("A"), Amount(50), False)],
        ),
    ]

    general_ledger_program = compile_general_ledger_program(read_initial_balances, read_journal_entries)

    period