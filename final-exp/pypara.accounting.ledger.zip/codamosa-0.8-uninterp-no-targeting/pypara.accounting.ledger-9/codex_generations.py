

# Generated at 2022-06-21 20:01:19.665900
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    ledger = build_general_ledger(DateRange(since=datetime.date(2020, 1, 1), until=datetime.date(2020, 1, 1)), [], {})
    assert ledger.__repr__() == "<GeneralLedger> period=<DateRange> since=2020-01-01 until=2020-01-01 ledgers={} entries=0"

# Generated at 2022-06-21 20:01:28.357138
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from src.accounting.journaling.generic import JournalEntry
    from src.accounting.journaling.generic import Posting
    from src.accounting.accounts.generic import Account
    from src.commons.zeitgeist import DateRange
    from src.accounting.journaling.algebra import read_journal_entries as algebra_read
    from src.accounting.journaling.io import read_journal_entries as io_read
    from src.accounting.journaling.types import JournalEntryType
    from decimal import Decimal
    from src.accounting.accounts.generic import AccountBase
    from src.accounting.accounts.generic import AccountKind
    read_journal_entries = io_read(algebra_read)

# Generated at 2022-06-21 20:01:40.187748
# Unit test for function build_general_ledger
def test_build_general_ledger():
    # Create a journal
    from .journaling import JournalEntry
    from .accounts import Account, AccountType
    Cash = Account(code='40000', name='Cash', account_type=AccountType.asset)
    UtilityExpense = Account(code='60000', name='Utility Expense', account_type=AccountType.expense)

# Generated at 2022-06-21 20:01:51.769477
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Test :py:func:`compile_general_ledger_program` function.
    """
    from .journaling import JournalEntry, Posting

    from ..commons.algebras import FunctionIO

    from .accounts import Account, AccountPage, AccountPageKey, AccountTree, AccountType
    from .journaling import Journal, PostDate

    from ..commons.typing import KV
    from ..core import set_env

    set_env(Version="1.0", RunInTestMode=True)

    ## Define accounts:
    assests = AccountPage(AccountPageKey(AccountType.ASSETS, ""), AccountTree(Account("Assets"), Account("Cash")))
    expenses = AccountPage(AccountPageKey(AccountType.EXPENSES, ""), AccountTree(Account("Expenses")))
    revenues = AccountPage

# Generated at 2022-06-21 20:02:02.324439
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from .journaling import Journal, Posting

    # Test that a LedgerEntry can be constructed
    posting0 = Posting(date=datetime.date(2000, 10, 31), account=Account(code="110"), direction=1, amount=Amount(200000))
    ledger0 = Ledger(account=Account(code="110"), initial=Balance(date=posting0.date, value=0))
    le0 = LedgerEntry(ledger=ledger0, posting=posting0, balance=200000)

    assert le0.balance == 200000
    assert le0.is_debit == True

    # Test date, description and amount properties of LedgerEntry
    posting1 = Posting(date=datetime.date(2000, 10, 31), account=Account(code="110"), direction=1, amount=Amount(200000))

# Generated at 2022-06-21 20:02:14.372863
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from .accounts import Account, AccountType
    from .commons.numbers import Amount
    from .journaling import JournalEntry, Posting
    from .ledgers import Ledger

    # 1. Create a new ledger
    a = Account('000-0000', 'CHEQUING', AccountType.ASSET)
    b = Balance(datetime.date(2018,1,1), 1)
    ledger = Ledger(a, b)
    # 2. Create a new journal entry
    date = datetime.date(2018,1,10)
    desc = 'CASH SALE'
    amount = Amount(10.00)
    p = Posting(a, amount, 1)
    j = JournalEntry(date, desc, [p])
    # 3. Create a new ledger entry

# Generated at 2022-06-21 20:02:21.746323
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    # Setup
    from ..commons.generic import Account
    from .journaling import Journal, Posting
    account = Account('Cash', 'Assets', 'Current Assets')
    posting = Posting(account, 1, 'USD', Journal('payment', 'payment'))
    ledger = Ledger(account, Balance(balance=Decimal(0)))
    ledger_entry = LedgerEntry(ledger, posting, 0)
    # Exercise
    actual = ledger_entry.__repr__()
    # Verify

# Generated at 2022-06-21 20:02:27.671417
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    @dataclass
    class ReadInitialBalancesImpl(ReadInitialBalances):
        def __call__(self, period: DateRange):
            return InitialBalances()

    r = ReadInitialBalancesImpl()
    assert r.__call__(DateRange(period.since, period.until)) == InitialBalances()


# Generated at 2022-06-21 20:02:38.759797
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    # Defines a dummy implementation which returns nothing:
    read_initial_balances = lambda period: {}

    # Defines a dummy implementation which returns a single journal entry:
    read_journal_entries = lambda period: [JournalEntry(datetime.date.today(), [], "")]

    # Compile the general ledger program:
    program = compile_general_ledger_program(read_initial_balances, read_journal_entries)

    # Build the general ledger:
    period = DateRange(datetime.date.today(), datetime.date.today())
    general_ledger = program(period)

    # Check number of ledgers:
    assert general_ledger.period == period
    assert len(general_ledger.ledgers) == 0



# Generated at 2022-06-21 20:02:43.861284
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    program = compile_general_ledger_program(
        read_initial_balances=lambda period: {},
        read_journal_entries=lambda period: (),
    )
    GeneralLedger = program(DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31)))
    assert type(GeneralLedger) == GeneralLedger

# Generated at 2022-06-21 20:03:02.444890
# Unit test for method add of class Ledger
def test_Ledger_add():
    import datetime
    from .accounts import Account

    from .journaling import Journal, JournalEntry
    from .posting import Posting

    from .generalledger import LedgerEntry

    acc = Account(
        description="Test account",
        short_name="TEST",
        ledger_account="400000",
        account_type="asset",
        terminal=True,
    )

    ledger = Ledger(acc, "400000", "asset", True)

    ledger.add(Posting(JournalEntry(datetime.date.today(), "Test journal entry", [Posting(acc, Decimal("10.00"), True)])))

    assert ledger.entries[0].ledger == ledger
    assert ledger.entries[0].posting.account == acc

# Generated at 2022-06-21 20:03:12.124005
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from .accounts import Account, Asset
    from .journaling import JournalEntry, Posting
    from typing import Dict, List

    # Test data for constructor of class LedgerEntry
    # Define a new instance of account 11100A
    account11100A: Account = Account(11100, Asset, 'Current Assets', 'Accounts Receivable')
    # Define a new instance of account 11100L
    account11100L: Account = Account(11100, Asset, 'Current Assets', 'Accounts Receivable')
    # Define a new instance of account 11200A
    account11200A: Account = Account(11200, Asset, 'Current Assets', 'Cash in Safe')
    # Define a new instance of account 20000A
    account20000A: Account = Account(20000, Asset, 'Sales', 'Sales')
    # Define a

# Generated at 2022-06-21 20:03:24.335470
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    # Initialize a list of journal entries to be posted
    journal_entries = [JournalEntry(1, 'description', datetime.date(2019, 8, 16), [Posting('account1', 1, 'debit')])]
    # Initialize period
    period = DateRange(since=datetime.date(2019,8,1), until=datetime.date(2019, 8, 31))
    # Initialize initial balance
    initial_balances = {"account1": Balance(period.since, Quantity(Decimal(10)))}
    # Get a general ledger
    general_ledger = build_general_ledger(period, journal_entries, initial_balances)
    # Check the result of the method __repr__ 

# Generated at 2022-06-21 20:03:36.679808
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
	gl = GeneralLedger(period=DateRange(since=datetime.date(2018, 1, 1), until=datetime.date(2018, 12, 31)), ledgers={
        1001: Ledger(account=1001, initial=Balance(date=datetime.date(2018, 1, 1), value=0)),
        1002: Ledger(account=1002, initial=Balance(date=datetime.date(2018, 1, 1), value=0))})
	assert gl.period == DateRange(since=datetime.date(2018, 1, 1), until=datetime.date(2018, 12, 31))
	assert gl.ledgers[1001] == Ledger(account=1001, initial=Balance(date=datetime.date(2018, 1, 1), value=0))

# Generated at 2022-06-21 20:03:39.595950
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    a1 = LedgerEntry(None, None, None)
    a2 = LedgerEntry(None, None, None)
    assert a1 == a2

# Generated at 2022-06-21 20:03:51.908792
# Unit test for constructor of class Ledger

# Generated at 2022-06-21 20:03:52.744708
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert False


# Generated at 2022-06-21 20:03:55.524619
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    period = DateRange(since=datetime.date(2020, 1, 1), until=datetime.date(2020, 1, 31))
    journal = Iterable[JournalEntry]
    initial = InitialBalances
    GeneralLedger(period, journal, initial)

# Generated at 2022-06-21 20:04:07.357115
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    print("Unit test for constructor of class LedgerEntry")
    # Create an instance of class Ledger.
    ledger = Ledger(Account('Equities', 'Cash'), Balance(datetime.date(2018, 1, 1), Decimal(1000)))
    # Create an instance of class Journal.
    journal = JournalEntry(
        datetime.date(2018, 1, 1), "Dividends from XYZ Inc", [
            Posting(Account('Equities', 'Cash'), Decimal(10)),
            Posting(Account('Equities', 'Dividends Receivable'), Decimal(10))
        ]
    )
    # Create an instance of class Posting.
    posting = Posting(Account('Equities', 'Cash'), Decimal(10))
    # Create an instance of class LedgerEntry.

# Generated at 2022-06-21 20:04:17.847586
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from .accounting import Account
    from .commons import Currency
    from .journaling import Journal, JournalEntry, Ledger, JournalPosting
    from .money import Money
    #: Defines a generic type variable.
    _T = TypeVar("_T")

    # Create Journal class
    journal = Journal(description="Test journal 1")
    entry = JournalEntry(description="Test journal entry 1", date=datetime.date(2020, 1, 1))

    # Create Ledger class
    ledger = Ledger(account=Account(name="Test account 1"), initial=Balance(date=datetime.date(2019, 12, 31), value=Quantity(Decimal(0))))

    # Create JournalPosting class

# Generated at 2022-06-21 20:04:35.941639
# Unit test for constructor of class Ledger
def test_Ledger():
    # Create accounts for the ledgers
    account_1 = Account('Checking')
    account_2 = Account('Savings')
    # Create Balance objects for the accounts
    balance_1 = Balance(datetime.date.today(), Quantity(Decimal(0)))
    balance_2 = Balance(datetime.date.today(), Quantity(-50))
    # Create journal entry
    journal_entry = JournalEntry(
        'Groceries',
        [
            Posting(account_1, datetime.date.today(), Quantity(Decimal(50))),
            Posting(account_2, datetime.date.today(), Quantity(Decimal(-50)))
        ]
    )
    # Create ledgers based on the accounts and balances for the accounts
    ledger_1 = Ledger(account_1, balance_1)

# Generated at 2022-06-21 20:04:36.641024
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    pass

# Generated at 2022-06-21 20:04:37.786378
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-21 20:04:47.192433
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    from decimal import Decimal

    from ..commons.zeitgeist import DateRange

    from .accounts import Account

    from .journaling import JournalEntry, Posting

    def read_initial_balances(period: DateRange) -> InitialBalances:

        return {}

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry["T"]]:

        return {}


# Generated at 2022-06-21 20:04:59.213668
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    from .accounts import AccountType

    # Setup journal entries:
    journal_entries = [
        JournalEntry(
            date=datetime.date(2019, 4, 1),
            description="Test Journal Entry 1.",
            postings=[
                Posting(Account(type=AccountType.OTHERS, number="101"), amount=Amount(Decimal(120))),
                Posting(Account(type=AccountType.OTHERS, number="201"), amount=Amount(Decimal(120))),
            ],
        )
    ]

    # Setup initial balances:

# Generated at 2022-06-21 20:05:08.567263
# Unit test for method add of class Ledger
def test_Ledger_add():
    """
    Add a new ledger entry.
    :return: The new ledger entry.
    """
    # Initialize a testing ledger
    testledger = Ledger("Assets:Bank:Checking", Balance("2014-01-01", Quantity(Decimal("0"))))

# Generated at 2022-06-21 20:05:19.144261
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # pylint: disable=unused-variable
    # pylint: disable=expression-not-assigned

    # Fixture:
    CURRENT_PERIOD = DateRange(datetime.date(2018, 1, 1), datetime.date(2019, 12, 31))
    PREVIOUS_PERIOD = DateRange(datetime.date(2014, 1, 1), datetime.date(2017, 12, 31))

# Generated at 2022-06-21 20:05:30.984407
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    journal_entry1 = JournalEntry(
        date=datetime.date(2018, 10, 1),
        description="Test journal entry",
        postings=[Posting(account="1101", amount=Decimal("50")), Posting(account="5101", amount=Decimal("-50"))]
    )

    journal_entry2 = JournalEntry(
        date=datetime.date(2018, 10, 1),
        description="Test journal entry 2",
        postings=[Posting(account="1101", amount=Decimal("50")), Posting(account="5101", amount=Decimal("-50"))]
    )


# Generated at 2022-06-21 20:05:37.220278
# Unit test for constructor of class Ledger
def test_Ledger():
    account = Account(None, None, None, '710000')
    initial = Balance('2019-01-01', '1000')
    entry = Ledger(account, initial)
    entry.add(Posting('2019-01-01','Test','10','710000','',''))
    assert entry.entries[0].balance == '1010'


# Generated at 2022-06-21 20:05:45.601315
# Unit test for method __eq__ of class LedgerEntry

# Generated at 2022-06-21 20:06:16.061162
# Unit test for method add of class Ledger
def test_Ledger_add(): 
    """
    :param posting: Posting the ledger entry is based on.
    :return: The new ledger entry.
    """
    #Create Ledger
    a = Ledger(2, "Test",1.00,100.00)
    #Create Posting
    x = Posting(1,"Test","Test",datetime.datetime.now().date(),1.00)
    #Create LedgerEntry
    y = a.add(x)
    assert y.ledger == a
    assert y.posting == x
    assert y.balance == 101.00
    assert y.description == "Test"
    assert y.debit == 1.00
    assert y.credit == None

# Generated at 2022-06-21 20:06:28.064888
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    account1 = Account(1)
    account2 = Account(2)
    account3 = Account(3)
    account4 = Account(4)
    account1_ledger = Ledger(account1, Balance(datetime.date(2015, 1, 1), Quantity(Decimal(0))))
    account2_ledger = Ledger(account2, Balance(datetime.date(2015, 1, 1), Quantity(Decimal(0))))
    account3_ledger = Ledger(account3, Balance(datetime.date(2015, 1, 1), Quantity(Decimal(0))))
    account4_ledger = Ledger(account4, Balance(datetime.date(2015, 1, 1), Quantity(Decimal(0))))

# Generated at 2022-06-21 20:06:33.722726
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    @dataclass(init=False)
    class ReadInitialBalancesTester(ReadInitialBalances):
        def __init__(self, *args):
            self.args = args
        def __call__(self, period: DateRange) -> InitialBalances:
            pass
    ReadInitialBalancesTester("")



# Generated at 2022-06-21 20:06:43.835175
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    
    from ..commons import zeitgeist
    from .journaling import Posting
    
    @dataclass
    class Journal:
        description: str
        postings: List[Posting]
        

    @dataclass
    class JournalEntry:
        date: datetime.date
        journal: Journal
    
        
    # Initialize period
    period = DateRange(datetime.date(2020, 8, 2), datetime.date(2020, 8, 2))
    
    # Initialize initial balances
    initial_balances = {Account("1001"): Balance(period.since, Quantity(Decimal(100))), Account("1002"): Balance(period.since, Quantity(Decimal(100)))}
    
    # Initialize journal entries

# Generated at 2022-06-21 20:06:51.906470
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    # Setup
    test_account = Account('test account')
    test_balance = Balance(datetime.date(2020, 1, 1), 0)
    test_ledger = Ledger(test_account, test_balance)
    # Exercise
    result = test_ledger.__repr__()
    # Verify
    assert result == "Ledger(account=test account, initial=Balance(date=2020-01-01, value=0), entries=[])"


# Generated at 2022-06-21 20:06:52.985453
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    pass



# Generated at 2022-06-21 20:07:01.918739
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    import datetime
    from ..commons.numbers import Amount
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import Journal, JournalEntry, Posting, Transaction

    #: Amount of the ledger entry.
    generalledger_amount = Amount(Decimal(20))

    #: Ledger the entry belongs to
    generalledger_ledger = 2

    #: Posting of the ledger entry.
    generalledger_posting = Posting(5,6,0)

    #: Balance of the ledger entry.
    generalledger_balance = Amount(Decimal(20))

    date = datetime.date.today()

    #: Transaction of the journal entry.

# Generated at 2022-06-21 20:07:14.073924
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():

    # imports
    from copy import copy
    from decimal import Decimal
    from datetime import date
    from collections import namedtuple
    from itertools import chain
    import unittest

    from .accounts import AccountType
    from .journaling import JournalEntry, Posting, Direction
    from . import commodities

    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange

    # Initial Balances Algebra
    InitBal = namedtuple("InitBal", ("date", "balances"))

# Generated at 2022-06-21 20:07:19.235104
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    print(LedgerEntry(Ledger(Account(1, "a1"), Balance(1, Quantity(1))), Posting(DateRange(1, 2), Account(2, "a2"),
        Amount(2.0), Quantity(2), Direction.DEBIT), Quantity(3)).__eq__(LedgerEntry(Ledger(Account(1, "a1"),
        Balance(1, Quantity(1))), Posting(DateRange(1, 2), Account(2, "a2"), Amount(2.0), Quantity(2), Direction.DEBIT),
        Quantity(3))))


# Generated at 2022-06-21 20:07:24.517445
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    general_ledger = GeneralLedger(DateRange(since=1,until=2),Dict[Account, Ledger])
    if general_ledger.period == DateRange(since=1,until=2) and general_ledger.ledgers == Dict[Account, Ledger]:
        print("true")
    else:
        print("false")


# Generated at 2022-06-21 20:07:57.681601
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .types import DebitOrCredit

    period = DateRange("2019-01-01", "2019-01-31")

    ## Mock account instances.
    from account import Account, CompanyAccount, CustomerAccount, SupplierAccount

    a_sales_returns = Account("sales_returns", "Sales Returns", CompanyAccount)
    a_sales = Account("sales", "Sales", CompanyAccount)
    a_output_tax_liability = Account("output_tax_liability", "Output Tax Liability", CompanyAccount)
    a_input_tax_claim = Account("input_tax_claim", "Input Tax Claim", CompanyAccount)

# Generated at 2022-06-21 20:08:03.953728
# Unit test for method __call__ of class ReadInitialBalances

# Generated at 2022-06-21 20:08:08.137355
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import build_general_ledger, Ledger, GeneralLedger

    ## Assertion: General ledger successfully created
    opening_date = DateRange(date(2015, 1, 1), date(2015, 12, 31))
    journal = [[JournalEntry('', date(2015, 1, 3), 'transaction description', [Posting(Account('Assets:Cash'), '$100.00', 1), Posting(Account('Expenses:Gifts'), '$100.00', -1)])]]
    opening_balance = {Account('Expenses:Gifts'): Balance(date(2015, 1, 1), Quantity(Decimal(100)))}
    ledger = build_general

# Generated at 2022-06-21 20:08:09.306272
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    assert LedgerEntry.__doc__ != None

# Generated at 2022-06-21 20:08:20.165605
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    entry = LedgerEntry(Ledger(Account(code=1, name="Accounts Payable"), Balance(Decimal(100), None)),
                        Posting(JournalEntry(datetime.date(2019, 12, 31), "Description", [], None), Account(code=1, name="Accounts Receivable"), Decimal(100), None),
                        Decimal(200))

# Generated at 2022-06-21 20:08:29.971891
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    data = {
        datetime.datetime(2018, 12, 31):
            [JournalEntry(
                'Settlement',
                datetime.datetime(2018, 12, 31),
                [Posting('Cash', 500, 'debit')
                    , Posting('Allowance for Doubtful Accounts', 500, 'credit')
                 ]

            )]
    }
    # Initial balances
    initial_balances = {
        Account('Cash'): Balance(datetime.datetime(2018, 12, 31), Decimal(0)),
        Account('Allowance for Doubtful Accounts'): Balance(datetime.datetime(2018, 12, 31), Decimal(0)),
    }
    # General Ledger

# Generated at 2022-06-21 20:08:36.723349
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():

    class ReadInitialBalancesImpl:
        def __call__(self, period: DateRange) -> InitialBalances: return {}

    class ReadJournalEntriesImpl:
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]: return []

    program = compile_general_ledger_program(ReadInitialBalancesImpl(), ReadJournalEntriesImpl())
    assert program is not None
    assert callable(program)

# Generated at 2022-06-21 20:08:48.668767
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from datetime import date
    from ddd_ledger.infrastructure.serialization import read_initial_balances, read_journal_entries
    from ddd_ledger.infrastructure.serialization import write_general_ledger
    from ddd_ledger.infrastructure.serialization import deserialize_entry, deserialize_posting, deserialize_journal

    def _expected_result(period):
        from ddd_ledger.domain.ledger import GeneralLedger, Ledger
        from ddd_ledger.domain.accounts import Account


# Generated at 2022-06-21 20:09:01.697629
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    import datetime
    from decimal import Decimal
    from decimal import Decimal
    from typing import List
    from typing import List
    import unittest

    from .accounts import Account
    from .accounts import Account
    from .accounts import AccountTree
    from .accounts import AccountTree
    from .accounts import is_terminal
    from .accounts import is_terminal
    from .commons import Direction
    from .commons import Direction
    from .commons import Quantity
    from .commons import Quantity
    from .commons.zeitgeist import DateRange
    from .commons.zeitgeist import DateRange
    from .journaling import JournalEntry
    from .journaling import JournalEntry
    from .journaling import Posting
    from .journaling import Posting

    #:

# Generated at 2022-06-21 20:09:11.143201
# Unit test for function build_general_ledger
def test_build_general_ledger():
    #TEST_BUILD_GENERAL_LEDGER
    import datetime
    from pygreg import build_general_ledger, DateRange, Posting, JournalEntry, Account
    from pygreg import build_account_object as bao
    from pygreg.commons.numbers import ReadAmount
    from pygreg.commons.zeitgeist import today
    from pygreg.functions.journaling import read_journal_entries_from_journal
    from pygreg.functions.accounts import read_initial_balances_from_ledger_entries

    # Create an atomized BS account:
    asset_account = bao(accid='1000', account='Cash', balance=10, debit=0, credit=0)
    # Create an atomized PL account:

# Generated at 2022-06-21 20:10:10.860304
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from collections import defaultdict
    from .journaling import link as jlink
    from ..commons.zeitgeist import daterange
    Dr, Cr = Balance.Direction

    accounts = defaultdict(str)
    accounts[-1] = "cash"
    accounts[-2] = "accounts receivable"
    accounts[-3] = "inventory"
    accounts[-4] = "accounts payable"
    accounts[-5] = "sales"
    accounts[-6] = "cost of sales"

    # Test 1: A journal entry
    # Test 2: Trivial initial balances
    # Test 3: Non-trivial initial balances

    j1 = jlink([-1, -5], (1.11, 1.12))

# Generated at 2022-06-21 20:10:19.159045
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Test the compile_general_ledger_program function.
    """
    # pylint: disable=unused-import
    from .accounts import AccountType, AccountTree
    from .journaling import JournalEntry, Posting, add_journal_entry
    from .transactional import Transaction

    # pylint: disable=invalid-name
    Cash = Account("010000", "Cash")
    Bank = Account("010100", "Bank", AccountType.ASSET)
    Equity = Account("080100", "Equity", AccountType.RETENTION)

    # pylint: disable=invalid-name
    tree = AccountTree(Equity, Cash, Bank)
    chart = tree.chart()

    # pylint: disable=invalid-name

# Generated at 2022-06-21 20:10:23.582549
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    """
    Constructor of class ReadInitialBalances.
    """
    from ..double_entry.programs import read_initial_balances
    assert isinstance(read_initial_balances, ReadInitialBalances)


# Generated at 2022-06-21 20:10:27.063064
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    account = Account('Expense')
    initial_balance = Balance(datetime.date(2020, 1, 1),Quantity(Decimal(1000.00)))
    ledger = Ledger(account,initial_balance)
    l1 = Ledger(account,initial_balance)
    assert ledger == l1

# Generated at 2022-06-21 20:10:30.851023
# Unit test for method add of class Ledger
def test_Ledger_add():
    account = Account("5001","Assets")
    initial = Balance(datetime.date(2020,1,1), Decimal(100))
    ledger = Ledger(account, initial)
    entry = Posting(account, datetime.date(2020,1,1), Decimal(100), "test")
    ledger.add(entry)
    assert ledger.entries[0].balance == initial.value + entry.amount

# Generated at 2022-06-21 20:10:42.499186
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .journaling import Journal
    from .accounts import Account, Accounts
    from .accounts.asset import Asset
    from .accounts.expense import Expense
    from .accounts.income import Income
    from .accounts.liability import Liability
    from .accounts.revenue import Revenue
    from .accounts.equity import Equity


# Generated at 2022-06-21 20:10:49.434408
# Unit test for method add of class Ledger
def test_Ledger_add():
    acc = Account("A")
    date = datetime.date(2019, 1, 1)
    amt = Amount("100")
    posting1 = Posting(acc, amt, date, True)
    posting2 = Posting(acc, amt, date, False)
    journal1 = JournalEntry("desc", posting1, posting2, date)
    journal2 = JournalEntry("desc2", posting2, posting1, date)
    mondrian = Ledger(acc, Balance(date, amt))
    mondrian.add(posting1)
    assert mondrian.entries[0].balance.value == 100
    mondrian.add(posting2)
    assert mondrian.entries[1].balance.value == 0
    mondrian.add(posting1)
    assert mondrian.entries

# Generated at 2022-06-21 20:10:59.505889
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from .journaling import Journal, Posting

    # Test instantiation of LedgerEntry
    j = Journal("2020-01-02", "Journal1", "Entry1")
    j.add_posting("Assets:Cash", "Equity", 100)
    p = j.postings[0]
    l = Ledger("Assets:Cash", Balance(None, 0))
    le = LedgerEntry(l, p, 100)
    assert le.date == datetime.date(2020, 1, 2)
    assert le.description == "Entry1"
    assert le.amount == 100
    assert le.cntraccts == ["Equity"]
    assert le.is_debit == True
    assert le.is_credit == False
    assert le.debit == 100
    assert le.credit == None


# Generated at 2022-06-21 20:11:09.528591
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    from datetime import date
    from typing import Callable
    from ..commons.zeitgeist import DateRange
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account
    from .journaling import JournalEntry, Posting, TxID, Direction
    from .generic import Balance, Opening
    from .ledgers import Ledger, LedgerEntry, GeneralLedger, build_general_ledger

    # A function that returns the initial balance of a given account
    def dummy_initial_balance(account: Account) -> Balance:
        return Balance(date(year=2020, month=1, day=1), Quantity(Decimal(0)))

    # A function that returns general ledger entries given the accounting period