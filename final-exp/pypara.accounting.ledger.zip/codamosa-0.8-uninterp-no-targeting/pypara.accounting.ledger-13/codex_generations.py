

# Generated at 2022-06-21 20:01:35.572986
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    date = datetime.date(2020,11,8)
    balances = [Balance(date, Quantity(update_balance))]
    general_ledger = GeneralLedger(period = "period", ledgers = "ledgers")
    ledger_entry = LedgerEntry(ledger = "ledger", posting= "posting", balance= "balance")
    account = Account(name = "ACCOUNT", number =1234, parent = None)
    post_amount = 100
    bal = Balance(date, Quantity(post_amount))
    journ = JournalEntry(date = date, description = "", number = "", postings = [Posting(account, bal, None)])
    read_initial_balances = ReadInitialBalances()

    assert read_initial_balances("period") == InitialBalances

# Generated at 2022-06-21 20:01:36.158660
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    pass

# Generated at 2022-06-21 20:01:47.462859
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    from .accounts import Account, TerminalAccount
    from .commons.zeitgeist import DateRange
    from .journaling import JournalEntry, Posting
    from .general_ledger import build_general_ledger, GeneralLedger

    #: Accounting period.
    period = DateRange(datetime.date(2014, 1, 1), datetime.date(2014, 12, 31))

    #: All available journal entries.

# Generated at 2022-06-21 20:01:59.237013
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    report = LedgerEntry(Ledger(Account("A1"), Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0)))),
                         Posting(datetime.date(2020, 1, 1), JournalEntry(datetime.date(2020, 1, 1), "Test",
                                                                                          [Posting(datetime.date(2020, 1, 1), Account("A1"), Account("A2"),
                                                                                                   Quantity(Decimal(100))),
                                                                                              Posting(datetime.date(2020, 1, 1), Account("A2"), Account("A1"),
                                                                                                   Quantity(Decimal(-100)))]),
                                 Account("A1"), Account("A2"), Quantity(Decimal(100))),
                         Quantity(Decimal(100)))

    report2 = Led

# Generated at 2022-06-21 20:02:06.489070
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    import pytest
    from ..commons.numbers import Amount
    from ..commons.zeitgeist import DateRange
    from ..journaling import JournalEntry, LedgerEntry, Posting
    from .accounts import Account, AccountType
    from .generic import Balance

    ## Initial ledger balances:

# Generated at 2022-06-21 20:02:15.403801
# Unit test for function build_general_ledger
def test_build_general_ledger():
    ## Import needed modules
    import importlib
    import itertools
    import os
    import pandas as pd
    from typing import Dict, List, Optional, Protocol
    from ..commons import JournalEntry
    from ..commons.zeitgeist import DateRange, DateTime, Day

    ## Import the correct module.
    mod = importlib.import_module("." + os.path.splitext(os.path.basename(__file__))[0], __package__)

    ## Create a dictionary of the relevant classes
    classes = {name: getattr(mod, name) for name in ("Account", "InitialBalances", "JournalEntry", "LedgerEntry")}

    ## Create a dictionary of the relevant functions

# Generated at 2022-06-21 20:02:18.917860
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Test case for function compile_general_ledger_program
    """
    ## Test data:

    ## Test targets:
    pass



# Generated at 2022-06-21 20:02:24.271046
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    # Arrange
    ledger = Ledger(Account(1), Balance(datetime.date.today(), 1))
    expected = 'Ledger(account=Account(id=1), initial=Balance(date=datetime.date(2020, 1, 15), value=Decimal(\'1\')), entries=[])'

    # Act
    actual = ledger.__repr__()

    # Assert
    assert expected == actual


# Generated at 2022-06-21 20:02:31.766373
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    myEntry = LedgerEntry(Ledger("a",Balance(0,0)),Posting(0,"1",0,0),0)
    assert(myEntry.ledger != None)
    assert(myEntry.posting != None)
    assert(myEntry.balance != None)

if __name__ == "__main__":
    ## Run test with -v from the root:
    import sys
    from unittest import main

    # Main program:
    main(module=None, argv=sys.argv[:1], verbosity=2)

# Generated at 2022-06-21 20:02:39.826451
# Unit test for constructor of class Ledger
def test_Ledger():
    account = Account(number="1010", name="Cash in bank", terminal=True)
    initial = Balance(None, Quantity(Decimal(0)))
    entries = []
    test = Ledger(account,initial,entries)
    assert test.account.number == "1010"
    assert test.account.name == "Cash in bank"
    assert test.account.terminal == True
    assert test.initial.value == Decimal(0)
    assert test.entries == []
    assert test._last_balance == Decimal(0)


# Generated at 2022-06-21 20:02:49.270759
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    ledger: Ledger = Ledger(Account(100), Balance('2020-01-01', 100))
    assert repr(ledger) == "Ledger(account=Account(id=100), initial=Balance(since=2020-01-01, value=100))"


# Generated at 2022-06-21 20:03:01.612211
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():

    @dataclass
    class TestReadInitialBalances(Protocol):
        acc : Account
        bal : Balance

        def __call__(self, period: DateRange) -> InitialBalances:
            pass

    @dataclass
    class TestReadJournalEntries(Protocol):
        acc : Account
        amt : Amount
        dir : int

        def __call__(self, period: DateRange) -> InitialBalances:
            pass


    ibs = TestReadInitialBalances(Account("Equity","InitBalance"),Balance(datetime.date.today(),Quantity(Decimal(0))))
    jes = TestReadJournalEntries(Account("Equity","InitBalance"),Amount(Decimal(100)).currency("ZAR"),1)

    bld = compile_general_ledger_program(ibs,jes)
    gl = b

# Generated at 2022-06-21 20:03:08.441880
# Unit test for constructor of class Ledger
def test_Ledger():
    account = Account("FOO","Bar")
    balance = Balance(2000, Quantity(Decimal(0)))
    ledger = Ledger(account,balance)
    print("ledger.account:",ledger.account)
    print("ledger.initial:",ledger.initial)
    print("ledger.entries:",ledger.entries)



# Generated at 2022-06-21 20:03:17.810553
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    @dataclass
    class Mock:
        pass

    mock = Mock()
    mock.read_initial_balances = lambda period: {}
    mock.read_journal_entries = lambda period: []

    program = compile_general_ledger_program(read_initial_balances=mock.read_initial_balances, read_journal_entries=mock.read_journal_entries)
    _ = program(DateRange(since=datetime.date(2019,1,1), until=datetime.date(2019,12,31)))

# Generated at 2022-06-21 20:03:30.153599
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    ledger1 = Ledger(Account("A"), Balance(datetime.date(2018, 1, 1), 0))
    ledger1.add(Posting(
        datetime.date(2018, 1, 1), JournalEntry("", "", "", [Posting(datetime.date(2018, 1, 1), JournalEntry("", "", "", [Ledger(Account("A"), Balance(datetime.date(2018, 1, 1), 0))]))])
    ))
    ledger1.add(Posting(
        datetime.date(2018, 1, 1), JournalEntry("", "", "", [Posting(datetime.date(2018, 1, 1), JournalEntry("", "", "", [Ledger(Account("A"), Balance(datetime.date(2018, 1, 1), 0))]))])
    ))
    ledger2 = Ledger

# Generated at 2022-06-21 20:03:32.220194
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    GeneralLedgerProgram(_T)


# Generated at 2022-06-21 20:03:40.436301
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    # pylint: disable=missing-docstring,unused-argument,no-self-use
    class MockInitialBalances(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {}

    class MockJournalEntries(ReadJournalEntries):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry]:
            return []

    general_ledger_program = compile_general_ledger_program(
        read_initial_balances = MockInitialBalances(),
        read_journal_entries = MockJournalEntries(),
    )
    general_ledger_program(
        DateRange(
            since = datetime.date(2019, 1, 1),
            until = datetime.date(2019, 12, 31),
        ),
    )

# Generated at 2022-06-21 20:03:52.392585
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    import datetime
    from dataclasses import dataclass, field
    from decimal import Decimal
    from typing import Iterable, Optional
    from hamcrest import assert_that, equal_to
    from hamcrest.core.base_matcher import BaseMatcher
    from hamcrest.core.core.allof import all_of
    from hamcrest.core.core.isequal import equal_to as is_equal_to
    from hamcrest.core.core.isinstanceof import instance_of
    from hamcrest.core.helpers.hasmethod import has_method
    from hamcrest.core.helpers.wrap_matcher import wrap_matcher
    from hamcrest.library.number.ordering_comparison import greater_than
    from hamcrest.library.text.stringcontains import contains_string


# Generated at 2022-06-21 20:03:53.218884
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass



# Generated at 2022-06-21 20:04:05.161599
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from datetime import date
    from ledger.accounts import Account
    from ledger.journaling import Journal, Posting
    from ledger.general_ledger import Ledger
    from ledger.commons.numbers import Amount

    a1 = Account("My Cash Account")
    a2 = Account("Your Cash Account")
    a3 = Account("My Bank Account")
    a4 = Account("Your Bank Account")
    a5 = Account("My Portfolio")
    p1 = Posting(date(2020, 5, 25), a1, Amount(100), "Purchase of 100 shares of ABC Ltd.", a5)
    p2 = Posting(date(2020, 5, 25), a2, Amount(100), "Purchase of 100 shares of ABC Ltd.", a5)

# Generated at 2022-06-21 20:04:14.823212
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    # pylint: disable=missing-function-docstring,invalid-name,unnecessary-pass
    pass


# Generated at 2022-06-21 20:04:26.851465
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    from . import accounts

    _account1 = accounts.Account('ASSET', 'RECEIVABLES', 'A')
    _account2 = accounts.Account('ASSET', 'RECEIVABLES', 'B')
    _account3 = accounts.Account('ASSET', 'RECEIVABLES', 'C')

    _entry1 = LedgerEntry(None, None, None)
    _entry2 = LedgerEntry(None, None, None)
    _entry3 = LedgerEntry(None, None, None)

    _ledger1 = Ledger(_account1, None)
    _ledger2 = Ledger(_account2, None)
    _ledger3 = Ledger(_account3, None)
    
    _general_ledger1 = GeneralLedger(None, {_account1 : _ledger1})
    _general_

# Generated at 2022-06-21 20:04:38.639993
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    print("Testing method __repr__ of class GeneralLedger")

    from .journaling import JournalEntry, Posting, PostingDirection

    from .accounts import Account, AssetAccount, LiabilityAccount
    from .accounts import EquityAccount, RevenueAccount, ExpenseAccount

    period = DateRange("2018-01-01", "2018-12-31")
    account_1 = AssetAccount("1000")
    account_2 = LiabilityAccount("2000")
    account_3 = EquityAccount("3000")
    account_4 = RevenueAccount("4000")
    account_5 = ExpenseAccount("5000")

    journal_entry_1 = JournalEntry(
        "Test journal entry 1", datetime.date(2018, 5, 1), [Posting(account_1, Quantity(100), PostingDirection.DEBIT)]
    )
    journal_entry_

# Generated at 2022-06-21 20:04:42.673679
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
	@dataclass
	class Test:
		test_ledgers: InitialBalances
	test = Test(test_ledgers = {})
	assert type(test) == Test and len(test.test_ledgers) == 0, "Missing arguments in ReadInitialBalances"


# Generated at 2022-06-21 20:04:43.674761
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # TODO: implement.
    assert True is False

# Generated at 2022-06-21 20:04:45.004975
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    pass


# Generated at 2022-06-21 20:04:55.893789
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    """
    Test that method __eq__ for class LedgerEntry behaves properly
    """
    account1 = Account("A001")
    account2 = Account("A002")
    period = DateRange(since=datetime.date(2020, 9, 1), until=datetime.date(2020, 9, 30))
    e1 = LedgerEntry(Ledger(account1, Balance(period.until, Currency("EUR"))), Posting(period.until, account1, account2, 1), 1)
    e2 = LedgerEntry(Ledger(account1, Balance(period.until, Currency("EUR"))), Posting(period.until, account1, account2, 1), 1)
    assert e1 == e2


# Generated at 2022-06-21 20:05:02.935489
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    class _DummyReadJournalEntries:
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            pass

    class _DummyReadInitialBalances:
        def __call__(self, period: DateRange) -> InitialBalances:
            pass

    compile_general_ledger_program(_DummyReadInitialBalances(), _DummyReadJournalEntries())

# Generated at 2022-06-21 20:05:09.776221
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    account = Account("3000")
    debited = Account("1000")
    credited = Account("2000")
    posting = Posting(account, Amount(10), debited, credited, datetime.date(2020, 9, 18))
    ledger = Ledger[str](account, Balance(datetime.date(2020, 9, 15)))
    ledger_entry = LedgerEntry[str](ledger, posting, Quantity(3))


# Generated at 2022-06-21 20:05:13.795246
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    # Setup
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))
    general_ledger = GeneralLedger(period, dict())
    # Exercise
    s = repr(general_ledger)
    # Verify
    assert isinstance(s, str)
    assert "January 01, 2020" in s
    assert "December 31, 2020" in s
    # Cleanup - none necessary



# Generated at 2022-06-21 20:05:51.518017
# Unit test for method __repr__ of class GeneralLedger

# Generated at 2022-06-21 20:06:04.412826
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    @dataclass
    class Algebra:
        def __init__(self):
            self._counter = 0
        def read_initial_balances(self, period: DateRange) -> InitialBalances:
            return {Account("A"): Balance(period.since, Quantity(self._counter)),
                    Account("B"): Balance(period.since, Quantity(self._counter + 1))}
        def read_journal_entries(self, period: DateRange) -> List[JournalEntry[_T]]:
            return [JournalEntry("J", period.since, [Posting("A", period.since, Amount(self._counter))], []),
                    JournalEntry("J", period.since, [Posting("B", period.since, Amount(self._counter + 1))], [])]
    algebra = Algebra()
    program = compile_general_led

# Generated at 2022-06-21 20:06:05.087074
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert False

# Generated at 2022-06-21 20:06:11.369201
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Asset, CommonAccount

    from .accounts import CommonStock, CommonStockShares

    ledger = Ledger(CommonAccount(CommonStock, CommonStockShares), Balance(None, Quantity(20)))
    ledger.add(Posting(Account(CommonAccount(CommonStock, CommonStockShares)), Quantity(20), None, None))
    assert ledger.entries[-1].balance == Quantity(40)

# Generated at 2022-06-21 20:06:14.429139
# Unit test for constructor of class Ledger
def test_Ledger():
    Account("Test")
    Balance("2019-12-31", Quantity(Decimal(0)))
    Ledger(Account("Test"), Balance("2019-12-31", Quantity(Decimal(0))))
    assert True


# Generated at 2022-06-21 20:06:20.619199
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    _T = TypeVar("_T")
    account1 = Account("1234567")
    account2 = Account("1234568")
    posting1 = Posting(_T, Quantity(Decimal("10000.00")), account1)
    posting2 = Posting(_T, Quantity(Decimal("20000.00")), account2)
    journal1 = JournalEntry(_T, datetime.date(2017, 12, 31), "Test Journal1")
    journal1.record(posting1)
    journal2 = JournalEntry(_T, datetime.date(2017, 12, 31), "Test Journal2")
    journal2.record(posting2)


# Generated at 2022-06-21 20:06:30.731907
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account

    @dataclass
    class MockJournal:

        description: str
        date: datetime.date

    @dataclass
    class MockPosting:

        journal: MockJournal
        account: Account
        direction: Balance
        amount: Amount

    @dataclass
    class MockInitialBalance:

        value: Quantity

    @dataclass
    class MockBalance:
        since: datetime.date
        value: Quantity

    MockAccount = Account(number=123456, name='Test Account')
    MockDirection = Balance(
        debit = 1,
        credit = -1
    )
    MockAmount = Amount(
        currency = 'USD',
        value = 100
    )
    MockJournal = MockJournal(description='Test Journal', date=datetime.date(2019, 12, 31))
   

# Generated at 2022-06-21 20:06:42.412862
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..accounting.interpreters.journaling import compile_posting_program, compile_journal_entry_program

    @dataclass
    class Report:
        """
        Provides an immutable, general purpose reporting model.
        """

        #: Ledger.
        ledger: GeneralLedger

        #: Journal.
        journal: Iterable[JournalEntry]

    ## Create the interpreter:
    interpreter = compile_posting_program(
        compile_journal_entry_program(lambda x: [], lambda x: []), lambda x: None, lambda x: None, lambda x: None
    )

    ## Read initial balances:

# Generated at 2022-06-21 20:06:43.028605
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    pass

# Generated at 2022-06-21 20:06:55.707408
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    import datetime as dt
    import decimal as d
    import logging
    from decimal import Decimal
    from typing import Any

    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry

    _T = TypeVar("_T")

    class MockReadInitialBalances(ReadInitialBalances):
        """
        Implementation of the `ReadInitialBalances` algebra for unit testing of the `GeneralLedgerProgram`
        programming interface.
        """

        def __call__(self, _: DateRange) -> InitialBalances:
            return {}


# Generated at 2022-06-21 20:07:29.622877
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    account1 = Account('1234', 'Account 1')
    journal1 = JournalEntry(
        "Test journal entry 1",
        datetime.date(2015, 8, 7),
        [
            Posting(account1, Amount(20), journal1),
            Posting(account1, Amount(10), journal1),
        ]
    )
    journal2 = JournalEntry(
        "Test journal entry 2",
        datetime.date(2015, 8, 7),
        [
            Posting(account1, Amount(20), journal2),
            Posting(account1, Amount(10), journal2),
        ]
    )
    ledger1 = Ledger(account1, Balance(datetime.date(2015, 1, 1), -10))

# Generated at 2022-06-21 20:07:37.452638
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    @dataclass
    class ReadInitialBalancesImpl(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {period: Balance(period, Quantity(Decimal(100)))}
    readInitialBalances = ReadInitialBalancesImpl()
    print('Test constructor of class ReadInitialBalances: ' + str(readInitialBalances.__call__(DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 1)))))


# Generated at 2022-06-21 20:07:50.756535
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    a = Account("A")
    p = Period(Date(2018, 1, 1), Date(2018, 2, 1))

    # Test 1:
    x = Ledger(a, Balance(p.since, Decimal(10)))
    assert repr(x) == "Ledger(account=A, initial=Balance(date=2018-01-01, value=Decimal('10')))", \
        "Unexpected output for Ledger.__repr__"

    # Test 2:
    x.add(Posting(Journal(p.since, "J1", None, [Posting(a, Decimal(1), None, None), Posting(a, -1, None, None)])))

# Generated at 2022-06-21 20:07:56.999180
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    assert Ledger(Account("A"), Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0)))).__repr__() == "Ledger(account=Account(number='A'), initial=Balance(date=datetime.date(2020, 1, 1), value=Decimal('0')))".__repr__()


# Generated at 2022-06-21 20:08:03.323277
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    acc = Account(code = 'E001', name = 'Equipment', category = 'Current Assets')
    bal = Balance(value = Quantity(Decimal(5)), since = datetime.datetime(2019, 12, 1))
    bal2 = Balance(value = Quantity(Decimal(5)), since = datetime.datetime(2019, 12, 1))
    j1 = JournalEntry(date = datetime.datetime(2019, 12, 1), description = 'Purchace of equipment',
        postings = (Posting(account = acc, direction = Decimal(1), amount = Quantity(Decimal(6))),))

# Generated at 2022-06-21 20:08:14.619614
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    from datetime import date
    from decimal import Decimal
    from .accounts import Account, AccountType

    from .journaling import Journal, Posting, JournalEntry, ReadJournalEntries

    from .generic import Balance

    from . import GeneralLedger
    from .commons.zeitgeist import DateRange

    # Given a general ledger with two posting
    balance = Balance(date(2019,1,1),Decimal(100))
    generalLedger = GeneralLedger(DateRange(date(2019,1,1),date(2019,3,2)),{Account("test",AccountType.asset): Ledger(Account("test",AccountType.asset),balance)})


# Generated at 2022-06-21 20:08:27.147736
# Unit test for constructor of class Ledger
def test_Ledger():
    import unittest
    from ..commons.zeitgeist import today
    from ..entities.accounts import AccountCategory, AccountGroup, AccountType
    from ..entities.materials import Material
    from ..entities.products import Product
    
    class LedgerTest(unittest.TestCase):
        def test_initial(self):
            account = Account(account_group=AccountGroup.ASSETS, account_type=AccountType.CASH, code="1010", name="Cash")
            from .accounts import AmountBalance
            balance = AmountBalance(date=today(), value=Decimal(0))
            ledger = Ledger(account=account,initial=balance)
            self.assertEqual([], ledger.entries)
            
        def test_add(self):
            import datetime

# Generated at 2022-06-21 20:08:37.979202
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Unit test for method __call__ of class GeneralLedgerProgram
    """

    # Define expected:
    expected = {'1000': Decimal('100'), '2000': Decimal('200'), '3000': Decimal('300')}

    # Define input:
    period = DateRange(until=datetime.date(2020, 7, 31))

    # Define algebra:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return expected

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        return []

    # Compile general ledger program:
    program: GeneralLedgerProgram[_T] = compile_general_ledger_program(read_initial_balances, read_journal_entries)

    # Invoke:
    actual = program

# Generated at 2022-06-21 20:08:47.922975
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    unit_test_GeneralLedger___eq__ = dataclasses.make_dataclass(
        'unit_test_GeneralLedger___eq__',
        [('period', datetime.date), ('ledgers', Dict[Account, Ledger[_T]])]
    )
    assert unit_test_GeneralLedger___eq__(period="period", ledgers="ledgers") != unit_test_GeneralLedger___eq__(
        period="different_period", ledgers="ledgers")
    assert unit_test_GeneralLedger___eq__(period="period", ledgers="ledgers") != unit_test_GeneralLedger___eq__(
        period="period", ledgers="different_ledgers")


# Generated at 2022-06-21 20:08:53.963938
# Unit test for constructor of class Ledger
def test_Ledger():
    a = Account(0)
    b = Balance(datetime.date.today(), Decimal(0))
    l = Ledger(a, b)
    assert l.account == a
    assert l.initial == b


# Generated at 2022-06-21 20:10:07.382017
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    # given
    ledger_1 = Ledger(Account("123"), Balance(datetime.date.today(), Quantity(Decimal("10.00"))))
    ledger_2 = Ledger(Account("123"), Balance(datetime.date.today(), Quantity(Decimal("10.00"))))
    ledger_3 = Ledger(Account("123"), Balance(datetime.date.today(), Quantity(Decimal("11.00"))))
    ledger_4 = Ledger(Account("124"), Balance(datetime.date.today(), Quantity(Decimal("10.00"))))
    ledger_5 = Ledger(Account("123"), Balance(datetime.date.today(), Quantity(Decimal("10.00"))))
    posting = Posting(Account("123"), datetime.date.today(), Quantity(Decimal("10.00")))

# Generated at 2022-06-21 20:10:17.537051
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    ## Define initial balances:
    initial_balances = {
        Account("asset:bank:checking"): Balance(datetime.date(2018, 12, 31), Quantity(Decimal(100))),
    }

    ## Define the journal entry:
    journal_entry = JournalEntry(
        date=datetime.date(2019, 1, 1),
        description="cash withdrawal",
        postings=[
            Posting(
                Account("asset:bank:checking"),
                Quantity(Decimal("20")),
            ),
            Posting(
                Account("income:misc:withdrawal"),
                Quantity(Decimal("20")),
            ),
        ],
    )

    ## Define read initial balances algebra:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return initial_balances

   

# Generated at 2022-06-21 20:10:25.147583
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    test_constructor = Ledger(Account(3002, "INCOME"), Balance(Decimal(0)))
    test_repr_result = "Ledger(account=Account(code='3002', name='INCOME'), " \
                       "initial=Balance(date=datetime.date(1970, 1, 1), value=0))"
    assert repr(test_constructor) == test_repr_result


# Generated at 2022-06-21 20:10:31.989816
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # dummy inputs:
    accounts = {
        Account("12", "Assets", "Cash"),
        Account("17", "Assets", "Investments"),
        Account("1701", "Assets", "Investments", "Amazon stock"),
        Account("1702", "Assets", "Investments", "Facebook stock"),
        Account("21", "Liabilities", "Creditors"),
        Account("2102", "Liabilities", "Creditors", "John Doe"),
        Account("31", "Equity", "Partners capital"),
        Account("3101", "Equity", "Partners capital", "John Doe"),
        Account("41", "Revenues", "Dividend income"),
        Account("42", "Expenses", "Interest expense"),
        Account("43", "Expenses", "Tax expense"),
    }

    # dummy journal:

# Generated at 2022-06-21 20:10:36.917106
# Unit test for constructor of class Ledger
def test_Ledger():
    from .accounts import AccountType
    from ..commons.zeitgeist import Date
    from decimal import Decimal
    lg = Ledger(Account('10',
                        AccountType.CHART_OF_ACCOUNT,
                        'Cash'), Balance(Date(2000,10,1), Decimal(1)))
    assert lg.account.number == '10'
    assert lg.account.type == AccountType.CHART_OF_ACCOUNT
    assert lg.account.name == 'Cash'
    assert lg.initial.date == Date(2000,10,1)
    assert lg.initial.value == Decimal(1)
    assert lg.entries == list()


# Generated at 2022-06-21 20:10:46.008140
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    """
    Test for method Ledger.__eq__.
    """
    # Test for non-equal ledgers
    assert(Ledger(Account('123'),Balance(datetime.date(2018,12,31),Quantity(Decimal(1000)))) != Ledger(Account('123'),Balance(datetime.date(2018,12,31),Quantity(Decimal(1500)))))
    assert(Ledger(Account('123'),Balance(datetime.date(2018,12,31),Quantity(Decimal(1000)))) != Ledger(Account('456'),Balance(datetime.date(2018,12,31),Quantity(Decimal(1000)))))

# Generated at 2022-06-21 20:10:51.789293
# Unit test for constructor of class Ledger
def test_Ledger():
    account = Account('1')
    initial = Balance(datetime.date(2020, 3, 31), Quantity(Decimal(10)))
    ledger = Ledger(account, initial)
    assert ledger.account == account
    assert ledger.initial == initial
    assert ledger.entries == []


# Generated at 2022-06-21 20:10:52.403971
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    pass

# Generated at 2022-06-21 20:10:56.450653
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    journal = []
    gl = build_general_ledger(DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31)), journal, {})
    assert isinstance(gl, GeneralLedger)

# Generated at 2022-06-21 20:10:56.856982
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    assert ReadInitialBalances