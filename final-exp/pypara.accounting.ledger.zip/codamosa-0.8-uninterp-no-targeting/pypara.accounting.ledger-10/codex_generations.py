

# Generated at 2022-06-21 20:01:20.322160
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests the __call__ method of class GeneralLedgerProgram
    """
    pass

# Generated at 2022-06-21 20:01:25.153110
# Unit test for method add of class Ledger
def test_Ledger_add():
    period = DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31))
    journal = []
    account1 = Account(1, 1001, "Assets", "Cash")
    account2 = Account(2, 5001, "Liabilities", "Capital")
    account3 = Account(3, 4001, "Revenues", "Sales")
    balance1 = Balance(datetime.date(2018, 1, 1), Decimal(1000))
    balance2 = Balance(datetime.date(2018, 1, 1), Decimal(0))
    balance3 = Balance(datetime.date(2018, 1, 1), Decimal(0))
    initial = {account1: balance1, account2: balance2, account3: balance3}
    D = Decimal

# Generated at 2022-06-21 20:01:26.622841
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    assert('''assert type(ReadInitialBalances) == typing._ProtocolMeta''')


# Generated at 2022-06-21 20:01:37.476992
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance, BalanceType, Quantity
    from .currency import Currency

    a = Account("a")
    b = Account("b")

    initial_balances = {a: Balance(date(2020, 1, 1), Quantity(Decimal('1.0'))),
                        b: Balance(date(2020, 1, 1), Quantity(Decimal('2.0')))}
    period = DateRange(date(2020, 1, 1), date(2020, 1, 31))

    def read_initial_balances(p: DateRange) -> InitialBalances:
        if p == period:
            return initial_balances
        else:
            return {}
    assert read_initial_balances.__call__(period)

# Generated at 2022-06-21 20:01:41.997331
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {}
    def read_journal_entries(period: DateRange) -> JournalEntry:
        return {}
    glp = compile_general_ledger_program(read_initial_balances,read_journal_entries)


# Generated at 2022-06-21 20:01:43.934547
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Unit test for function compile_general_ledger_program
    """
    # FIXME
    pass

# Generated at 2022-06-21 20:01:56.644443
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import Since, Until
    from .journaling import Posting, JournalEntry
    from .accounts import Account
    from ..commons.numbers import Amount
    from ..commons.test import run_testcase
    from .test import (
        read_initial_balances_test,
        read_journal_entries_test,
    )

    @dataclass
    class Balance:
        date: datetime.date
        value: int

    ## Get initial balances as of the end of previous financial period:
    initial_balances = read_initial_balances_test(
        {Account(1): Balance(datetime.date(2019, 12, 31), 100)}
    )

    ## Read journal entries and post each of them:

# Generated at 2022-06-21 20:01:58.494334
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    """
    Test for method __repr__ of class Ledger
    """
    pass


# Generated at 2022-06-21 20:02:12.519448
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    GeneralLedger(DateRange(datetime.date(2019, 10, 1), datetime.date(2019, 12, 31)), {}) == \
    GeneralLedger(DateRange(datetime.date(2019, 10, 1), datetime.date(2019, 12, 31)), {})
    GeneralLedger(DateRange(datetime.date(2019, 10, 1), datetime.date(2019, 12, 31)), {}) != \
    GeneralLedger(DateRange(datetime.date(2019, 10, 1), datetime.date(2019, 12, 30)), {})

# Generated at 2022-06-21 20:02:23.357296
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    account = Account(code="100.10", name="Cash on Hand", description="Cash in wallet and pocket")
    balance = Balance(date=datetime.date(2019, 1, 1), value=Quantity(Decimal(100)))
    posting = Posting(date=datetime.date(2019, 1, 1), account=account, amount=Amount(Decimal(100)), direction=Direction.debit)
    entry = LedgerEntry(ledger=None, posting=posting, balance=Quantity(Decimal(100)))

    ledger = Ledger(account=account, initial=balance)
    # Add entry to the ledger.
    ledger.add(posting)

    assert ledger.__repr__() == "Ledger(account=%s, initial=%s, entries=[%s])" % (account, balance, entry)

# Generated at 2022-06-21 20:02:40.370548
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .generic import Balance
    from .accounts import Account
    from .commons import DateRange
    from .journaling import JournalEntry
    from .ledgering import build_general_ledger
    from .journaling import Posting, Transaction
    from datetime import date
    from typing import Dict
    import datetime

    #accounts: Dict[Account, Balance] = {}

    period = DateRange(since=date(2018, 1, 1), until=date(2018, 12, 31))


# Generated at 2022-06-21 20:02:48.848525
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    print("Testing function compile_general_ledger_program...")

    # Stub read_initial_balances:
    class StubReadInitialBalances:
        def __call__(self, period: DateRange) -> InitialBalances:
            return {"Assets:Bank:XTG1": Balance("2019-01-01", Quantity(250000))}

    # Stub read_journal_entries:
    class StubReadJournalEntries:
        def __call__(self, period: DateRange) -> Iterable[JournalEntry]:
            return []

    # Compile general ledger program:
    program = compile_general_ledger_program(StubReadInitialBalances(), StubReadJournalEntries())
    print("Program = " + repr(program))

    # Run the program:

# Generated at 2022-06-21 20:02:57.608866
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    a = Ledger(Account('1234'), Balance(datetime.date(2018, 1, 1), Quantity(Decimal(1))))
    b = Ledger(Account('1234'), Balance(datetime.date(2018, 1, 1), Quantity(Decimal(1))))
    c = Ledger(Account('5678'), Balance(datetime.date(2018, 1, 1), Quantity(Decimal(1))))

    assert(a == b)
    assert(a != c)
    assert(c != b)

# Generated at 2022-06-21 20:03:05.453872
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # Define a dummy function, which builds a general ledger, which is the test subject.
    program = compile_general_ledger_program(lambda x: InitialBalances(), lambda x: [])

    # Execute the test subject, including an assertion.
    general_ledger = program(DateRange(datetime.datetime(2020, 12, 1), datetime.datetime(2021, 2, 1)))

    # Execute an assertion.
    assert general_ledger


# Generated at 2022-06-21 20:03:12.944061
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    class _MockJournal(_T):
        def __init__(self, description: str):
            self.description = description

    class _MockPosting(_T):
        def __init__(self, date: datetime.date, direction: int, journal: _MockJournal, amount: Amount):
            self.date = date
            self.direction = direction
            self.journal = journal
            self.amount = amount

    class _MockBalance(_T):
        def __init__(self, value: Amount):
            self.value = value

    class _MockLedger(_T):
        def __init__(self, account: int):
            self.account = account


# Generated at 2022-06-21 20:03:24.977997
# Unit test for constructor of class Ledger
def test_Ledger():
    from ..accounts import Asset, Credit, Debit, Equity, Expense

    account1 = Asset(1)
    account2 = Equity(2)
    account3 = Credit(3)
    account4 = Debit(4)
    account5 = Expense(5)

    initial_balance = Balance(datetime.date(2020, 1, 1), Quantity(Decimal(20)))

    entry1 = LedgerEntry(account1, Debit(10))
    entry2 = LedgerEntry(account2, Credit(20))
    entry3 = LedgerEntry(account3, Debit(-5))
    entry4 = LedgerEntry(account4, Credit(-5))
    entry5 = LedgerEntry(account5, Credit(-5))

    ledger1 = Ledger(account=account1, initial=initial_balance)

# Generated at 2022-06-21 20:03:37.169247
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Tests the compile_general_ledger_program function.
    """

    ## Set up test dependencies:
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {Account("A", "1"): Balance(datetime.date(2020, 1, 1), Quantity(Decimal(10)))}


    def _read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        return [
            JournalEntry(
                date=datetime.date(2020, 1, 2),
                description="Test",
                postings=[Posting(Account("A", "1"), Decimal(5), 1)],
            )
        ]

    ## Compile the program:

# Generated at 2022-06-21 20:03:48.713593
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    GeneralLedgerProgram @dataclass()
    def __init__(self, period: DateRange,
    read_initial_balances: ReadInitialBalances,
    read_journal_entries: ReadJournalEntries[_T]):
        assert isinstance(read_initial_balances, ReadInitialBalances)
        assert isinstance(read_journal_entries, ReadJournalEntries[_T])
        # Get initial balances as of the end of previous financial period:
        initial_balances = read_initial_balances(period)
        # Read journal entries and post each of them:
        journal_entries = read_journal_entries(period)
        # Build the general ledger and return:
        build_general_ledger(period, journal_entries, initial_balances)

# Generated at 2022-06-21 20:03:50.767673
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    """Test method __repr__ of class GeneralLedger."""
    pass


# Generated at 2022-06-21 20:03:54.911622
# Unit test for constructor of class Ledger
def test_Ledger():
    ledger = Ledger(Account('1510'),Balance(datetime.date(2010,1,1),Quantity(Decimal(1000))))

    assert ledger.account == Account('1510')
    assert ledger.initial == Balance(datetime.date(2010,1,1),Quantity(Decimal(1000)))
    assert ledger.entries == []


# Generated at 2022-06-21 20:04:15.048224
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    from . import Account, Journal
    from .journaling import Posting
    from .generic import Balance

    account = Account.objects.create(name="Cash", debit="+", credit="-")
    journal = Journal.objects.create(description="Bought 1 book")
    posting = Posting.objects.create(account=account, journal=journal, amount=100)
    entry = LedgerEntry(posting=posting, balance=Balance(100))
    assert repr(entry) == "LedgerEntry(posting=Posting(account='Cash', journal='Bought 1 book', amount=100), " \
                          "balance=Balance(100))"


# Generated at 2022-06-21 20:04:27.248963
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    print("Test started for constructor of class LedgerEntry")
    # create a ledger
    ledger = Ledger(account = Account("1001"), initial = Balance(date = datetime.date(2020,1,1), value = 17.00), entries = [])
    # create a JE
    je = JournalEntry(date = datetime.date(2020,7,20), description = "test case", journal = None, postings = [Posting(1.00, Account("1001"), Direction.CREDIT, Category("test"), je)])
    # create a posting
    posting = Posting(1.00, Account("1001"), Direction.CREDIT, Category("test"), je)
    # create a ledger entry
    le = LedgerEntry(ledger = ledger, posting = posting, balance = Quantity(Decimal(18.00)))
    # print the properties of the ledger entry

# Generated at 2022-06-21 20:04:38.914080
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    class Mock(JournalEntry[object]):
        def __init__(self, date, description, ledger_entries):
            self.date = date
            self.description = description
            self.ledger_entries = ledger_entries

    def test_case_when_ledgers_are_equal():
        period = DateRange(since=datetime.date(2012, 1, 1), until=datetime.date(2012, 12, 31))

# Generated at 2022-06-21 20:04:40.398012
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    a = ReadInitialBalances()
    a = Period()


# Generated at 2022-06-21 20:04:43.758935
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    print(LedgerEntry(None,None,Decimal(100.00)))
    assert LedgerEntry(None,None,Decimal(100.00)) == LedgerEntry(None,None,Decimal(100.00))


# Generated at 2022-06-21 20:04:49.576665
# Unit test for constructor of class Ledger
def test_Ledger():
    a1 = Account(1, "cash")
    b1 = Balance(datetime.date(2020, 1, 1), Quantity(Decimal(10)))
    l1 = Ledger(a1, b1)
    assert l1.account == a1
    assert l1.initial == b1
    assert l1.entries == []


# Generated at 2022-06-21 20:05:02.304855
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    @dataclass
    class AccountBalance:
        """
        Provides a model of an account balance.
        """

        #: Account of the balance.
        account: Account

        #: Balance value.
        value: Quantity

    @dataclass
    class JournalEntryExtended(JournalEntry):
        """
        Provides an extended model of a journal entry which includes the journal entry balance.
        """

        #: Balance of the journal entry.
        balance: Quantity

    # Define a read_initial_balances function which returns opening balances for terminal accounts:

# Generated at 2022-06-21 20:05:10.094627
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from .accounts import Account
    from .journaling import JournalEntry, Journal, Posting, Direction, Side
    from .generic import Balance

    # Create a sample JournalEntry
    journal_date = datetime.date(2017, 10, 25)
    journal_description = "Value date was 2017-10-24"

    debited_account = Account("1111", "Cash in hand")
    debited_amount = Amount(12000, currency="INR")
    debited_posting = Posting(debited_account, debited_amount, Direction.LESS, Side.DEBIT)

    credited_account = Account("2222", "Bank")
    credited_amount = Amount(12000, currency="INR")
    credited_posting = Posting(credited_account, credited_amount, Direction.MORE, Side.CREDIT)

    journal_entry

# Generated at 2022-06-21 20:05:20.197364
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from datetime import date
    from types import FunctionType
    from .accounts import AccountName, TerminalAccount
    from .journaling import PostingDirection
    from .journaling import debit_posting, credit_posting, journal_entry
    from .journaling import ReadJournalEntriesAlgebra
    from .journaling import read_journal_entries
    from .journaling import JournalEntryAlgebra
    from .journaling import create_journal_entry
    from .journaling import PostingAlgebra
    from .journaling import create_posting

    class ReadInitialBalancesAlgebra(Protocol):
        def __call__(self, period: DateRange) -> InitialBalances:
            pass


# Generated at 2022-06-21 20:05:26.692539
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .algebras import WriteJournalEntry

    def _read_initial_balances(period: DateRange):
        return {Account("A", 0): Balance(period.since, Quantity(Decimal(30))),}

    def _read_journal_entries(period: DateRange):
        journal_entries = [
            JournalEntry(
                datetime.date(year, 1, 1),
                "Journal entry #1",
                [
                    Posting(Account("A", 0), Decimal(10), "Credit"),
                    Posting(Account("B", 0), Decimal(10), "Debit"),
                ],
            )
        ]
        return journal_entries

    ## Define the write journal entries program.
    write_journal_entries = compile_write_journal_entries(WriteJournalEntry)

    ## Compose the

# Generated at 2022-06-21 20:05:40.840646
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert False # implement your test here


# Generated at 2022-06-21 20:05:44.661637
# Unit test for constructor of class Ledger
def test_Ledger():
    assert Ledger("revenue", Quantity(10)) == "revenue"
    assert Ledger("expense", Quantity(-10)) == "expense"
    assert Ledger("balance", Quantity(100)) == "balance"

# Generated at 2022-06-21 20:05:47.986107
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    e1 = LedgerEntry(None,Posting(None,None,None),None)
    e2 = LedgerEntry(None,Posting(None,None,None),None)
    assert e1 == e2



# Generated at 2022-06-21 20:05:53.563245
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    assert Ledger("A",Balance("B")).__eq__(Ledger("A",Balance("B"))) == True
    assert Ledger("A",Balance("B")).__eq__(Ledger("B",Balance("B"))) == False
    assert Ledger("A",Balance("B")).__eq__(Ledger("A",Balance("C"))) == False
    assert Ledger("A",Balance("B")).__eq__(1) == False


# Generated at 2022-06-21 20:06:05.598710
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    acc1 = Account('1')
    acc2 = Account('2')
    bal1 = Balance((datetime.date(2020,6,12),datetime.date(2020,8,12)), (Decimal('1'),Decimal('2')))
    bal2 = Balance((datetime.date(2019,6,12),datetime.date(2019,8,12)), (Decimal('3'),Decimal('4')))
    bal3 = Balance((datetime.date(2021,6,12),datetime.date(2021,8,12)), (Decimal('5'),Decimal('6')))
    period = DateRange((datetime.date(2020,6,12),datetime.date(2020,8,12)))
    DateRange((datetime.date(2020,6,12),datetime.date(2020,8,12)))


# Generated at 2022-06-21 20:06:15.945648
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    """
    Tests that the :py:class:`GeneralLedgerProgram` class constructor
    returns a new instance of the class.
    """
    start_date = datetime.date.today()
    end_date = start_date + datetime.timedelta(days=365)
    read_initial_balances = lambda period : {Account('0000'): Balance(start_date, Quantity(Decimal(0)))}
    def read_journal_entries(period):
        return [JournalEntry(
            datetime.date(2018,1,1),
            'TEST',
            [Posting(Account('0000'), Amount(Decimal(1.0)), 'debit')])]
    compiled_program = compile_general_ledger_program(
        read_initial_balances, read_journal_entries)
    period = DateRange

# Generated at 2022-06-21 20:06:28.065550
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    from .asset import AssetAccount
    from .equity import CapitalAccount
    from .journaling import Journal, Posting
    from .liability import LiabilityAccount

    ## Create initial balances:
    initial = InitialBalances({
        AssetAccount("1010"): Balance(datetime.date(2019, 12, 31), Quantity(Decimal(0))),
        LiabilityAccount("2010"): Balance(datetime.date(2019, 12, 31), Quantity(Decimal(0))),
        CapitalAccount(): Balance(datetime.date(2019, 12, 31), Quantity(Decimal(0))),
    })

    ## Create journal entries:

# Generated at 2022-06-21 20:06:40.334694
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    def read_initial_balances_algebra(period : DateRange) -> InitialBalances:
        # stub for reading initial balances
        return {"1010" : Balance(datetime.datetime(2020, 1, 1), 0)}


# Generated at 2022-06-21 20:06:46.581548
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from ..persistence_adapters.ledger_adapters import ledger_entry_adapters, data_adapter
    import sqlalchemy
    acc = Account('test')
    le = Ledger(acc, Balance(2017, 2.0))
    posting = Posting(le, 3.2)
    le_entry = LedgerEntry(le, posting, 2.0)
    assert le_entry.ledger == le
    assert le_entry.posting == posting
    assert le_entry.balance == 2.0
    assert le_entry.date == le.initial.date
    assert le_entry.description == le.account
    assert le_entry.amount == 3.2
    assert le_entry.cntraccts == []
    assert le_entry.is_debit == True
    assert le_entry.is_credit == False

# Generated at 2022-06-21 20:06:49.623863
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    from ..domain.algebra import read_initial_balances
    print(type(read_initial_balances))
    assert type(read_initial_balances) == ReadInitialBalances

# Generated at 2022-06-21 20:07:16.576474
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass

# Generated at 2022-06-21 20:07:27.153141
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    """
    Unit test for method __eq__ of class LedgerEntry.
    """

    # Define and initialize ledger entries

# Generated at 2022-06-21 20:07:32.571947
# Unit test for function build_general_ledger
def test_build_general_ledger():
    # Period:
    period = DateRange(
        since=datetime.date(year=2018, month=1, day=1), until=datetime.date(year=2018, month=6, day=30)
    )

    # Initial balances:

# Generated at 2022-06-21 20:07:37.105774
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    def read_initial_balances(period: DateRange) -> InitialBalances:
        pass

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        pass

    compile_general_ledger_program(read_initial_balances, read_journal_entries)

# Generated at 2022-06-21 20:07:50.741351
# Unit test for function build_general_ledger
def test_build_general_ledger():
    import datetime
    from decimal import Decimal
    from dataclasses import dataclass
    from typing import List
    from functools import partial
    from nacc import Account, Balance, JournalEntry, LedgerEntry, Posting, build_general_ledger
    from nacc.algebra import journaling
    from nacc.commons.numbers import Amount, Quantity
    from nacc.commons.zeitgeist import DateRange
    
    assert_is_equal = partial(assertEqual, msg="check failed!")
    assert_is_none = partial(assertIsNone, msg="check failed!")
    assert_is_not_none = partial(assertIsNotNone, msg="check failed!")
    assert_is_in = partial(assertIn, msg="check failed!")

# Generated at 2022-06-21 20:07:56.323142
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    account = Account("Account")
    balance = Balance(datetime.date(1,1,1),Quantity(Decimal(0)))
    ledger = Ledger(account,balance)
    assert ledger.account == account
    assert ledger.initial == balance


# Generated at 2022-06-21 20:07:57.365615
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    pass

# Component test for method __repr__ of class LedgerEntry

# Generated at 2022-06-21 20:08:02.571414
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import now
    from .journaling import Journal, Posting

    # get the current date
    date = now()

    # Create a new journal
    j = Journal('Test Journal')

    # Create a new Posting
    p = Posting('A', Amount(10), date)

    # Add the posting to the journal
    j.add(p)

    # Create a new ledger
    l = Ledger('A')

    # Add posting to the ledger
    l.add(p)

    # Check that the new posting was added to the ledger
    assert 'Test Journal' == l.entries[0].description

# Generated at 2022-06-21 20:08:09.669843
# Unit test for constructor of class Ledger
def test_Ledger():
    a = Account(id= "a", account_type= "Assets", account_category= "Bank Accounts")
    opening_balance = Balance(date= "2000-10-1", value= 10)
    ledger = Ledger(account= a, initial= opening_balance)
    assert ledger.account == a
    assert ledger.initial == opening_balance


# Generated at 2022-06-21 20:08:20.215276
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    # Dummy implementations:
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        pass

    def _read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        pass

    # Compile the program.
    _program = compile_general_ledger_program(_read_initial_balances, _read_journal_entries)

    # Verify we have the correct signature.
    assert _program.__name__ == "compile_general_ledger_program.<locals>._program"
    assert _program.__annotations__["return"] == "GeneralLedger[_T]"
    assert _program.__annotations__["period"] == DateRange

# Generated at 2022-06-21 20:10:07.689769
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    @dataclass
    class Wallet:
        """
        Provides a wallet model for testing.
        """
        balance: Amount

    # Algebra implementation
    def read_initial_balances(period: DateRange) -> InitialBalances:
        """
        Implements the algebra.
        """
        return {Account("assets:cash"): Balance(period.since, Quantity(Decimal(100)))}

    def test_it_can_read_initial_balances():
        """
        Tests whether it can read initial balances.
        """
        # Read initial balances
        ib = read_initial_balances(DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31)))
        # Return initial balances
        return ib
        
    # Return the initial balances
    return test_it_can_read_

# Generated at 2022-06-21 20:10:17.641584
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    try:
        from unittest import mock
    except ImportError:
        import mock

    # Mock a ReadInitialBalances implementation
    def read_initial_balances(period: DateRange) -> InitialBalances:
        pass

    # Mock a ReadJournalEntries implementation
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        pass

    # Mock a DateRange instance
    date_range = mock.Mock(DateRange)

    # Mock a GeneralLedger instance
    general_ledger = mock.Mock(GeneralLedger[_T])

    # Mock a build_general_ledger function
    build_general_ledger_mock = mock.MagicMock(build_general_ledger, return_value=general_ledger)

    # Mock a GeneralLedgerProgram implementation
   

# Generated at 2022-06-21 20:10:25.147005
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..domains.general_ledger import GeneralLedgerProgram as GenLedgerProg
    from ..domains.general_ledger import read_initial_balances, read_journal_entries
    from ..domains.journaling import ReadJournalEntries, ReadInitialBalances

    program = compile_general_ledger_program(read_initial_balances, read_journal_entries)
    assert isinstance(program, GenLedgerProg)

# Generated at 2022-06-21 20:10:31.491999
# Unit test for method add of class Ledger
def test_Ledger_add():
    from datetime import date
    from ow_accounting.domain.journaling import Journal, Posting, Direction, JournalEntry
    l = Ledger(Account(0), Balance(date(2017, 12, 31), Quantity(0)))
    assert len(l.entries) == 0
    assert l._last_balance == 0
    p = Posting(Account(1), Direction(1), Amount(100))
    je = JournalEntry(Journal(date(2017, 12, 31), "", [p]), date(2017, 12, 31))
    print(je)
    le = l.add(p)
    assert le.balance == 100
    assert l._last_balance == 100
    assert len(l.entries) == 1

# Generated at 2022-06-21 20:10:38.638934
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    ledger = Ledger(Account('100'), Balance(datetime.date(2020, 1, 1), 0))
    posting = Posting(JournalEntry(datetime.date(2020, 1, 1), 'test'))
    posting.journal.add(posting)

    ledger_entry1 = LedgerEntry(ledger, posting, 0)
    ledger_entry2 = LedgerEntry(ledger, posting, 0)

    assert ledger_entry1 == ledger_entry2

# Generated at 2022-06-21 20:10:47.217217
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    from .accounts import Account, Assets, Liabilities, Equities
    from .bookkeeping import ReadBookkeeping
    from .journaling import ReadJournalEntries, JournalEntry
    from .common import ReadOpenClosedPeriods
    from .readers import console_read_initial_balances, console_read_accounts, console_read_open_closed_periods
    from .common import read_balances
    from .readers import console_read_bookkeeping, console_read_journal_entries


# Generated at 2022-06-21 20:10:56.163919
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from . import accounts
    from . import journaling
    assert compile_general_ledger_program(
        read_initial_balances=lambda period: {accounts.A: Balance(period.since, Quantity(0))},
        read_journal_entries=lambda period: [
            journaling.JournalEntry(period.since, "A->B", [Posting(accounts.A), Posting(accounts.B)])
        ],
    ) is not None

# vim: et:ts=4:sw=4

# Generated at 2022-06-21 20:11:06.215064
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    class ReadInitialBalancesImpl:
        def __call__(self, period: DateRange) -> InitialBalances:
            from ..commons.accounts import Account, AccountType
            from ..commons.numbers import Quantity
            from .generic import Balance

# Generated at 2022-06-21 20:11:10.524368
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    account = Account("1001")
    posting = Posting(account, Amount(100), Quantity(0), datetime.datetime(2019, 2, 12), False, False)
    ledger = Ledger(account, Balance(datetime.date(2019, 2, 11), Quantity(100)))
    entry = LedgerEntry(ledger, posting, Quantity(0))
    assert entry.account == account
    assert entry.posting == posting
    assert entry.balance == Quantity(0)
