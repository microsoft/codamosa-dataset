

# Generated at 2022-06-21 20:01:32.419670
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    # First ledger
    account = Account("AU-1")
    initial = Balance(date=datetime.date(2019, 1, 1), value=Decimal(1.0))
    ledger1 = Ledger(account=account, initial=initial)
    # Second ledger
    account = Account("AU-1")
    initial = Balance(date=datetime.date(2019, 1, 1), value=Decimal(1.0))
    ledger2 = Ledger(account=account, initial=initial)
    # Evaluate results
    assert ledger1 == ledger2


# Generated at 2022-06-21 20:01:37.711606
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    #: Accounting period.
    period = DateRange(since=datetime.date(2010, 1, 1), until=datetime.date(2010, 12, 31))
    #: Individual account ledgers of the general ledger.
    ledgers = {}
    general_ledger = GeneralLedger(period,ledgers)
    other = GeneralLedger(period,ledgers)
    assert general_ledger == other


# Generated at 2022-06-21 20:01:48.862743
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from datetime import date
    from .journaling import JournalEntry, Posting

    # Stub for the algebra:
    class StubReadInitialBalances:
        def __call__(self, period: DateRange) -> InitialBalances:
            return {
                Account("A1010"): Balance(date(2020, 1, 1), Quantity(100)),
                Account("A1020"): Balance(date(2020, 1, 1), Quantity(150)),
            }

    # Stub for the algebra:

# Generated at 2022-06-21 20:01:56.535352
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    # Arrange
    account = Account('John')
    posting = Posting(account, datetime.date(2020, 1, 1), Amount(123.45), None)
    ledger_entry = LedgerEntry(account, posting, Quantity(Decimal(0)))

    # Act
    repr_str = repr(ledger_entry)

    # Assert
    assert repr_str == f'LedgerEntry(ledger={account}, posting={posting}, balance=0.00)'


# Generated at 2022-06-21 20:02:05.005967
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from .roles import ReadOpenBalances

    ## Define example initial balances:
    initial_balances = {Account("A"), Balance(datetime.datetime.now(), Quantity(1))}

    ## Define a dummy algebra:
    class DummyAlgebra(ReadOpenBalances):
        def read_open_balances(self, period: DateRange) -> InitialBalances:
            return initial_balances

    ## Create an instance of the dummy algebra:
    dummy = DummyAlgebra()

    ## Create a function with same signature as __call__ of ReadInitialBalances:
    def compatible_function(period: DateRange) -> InitialBalances:
        return initial_balances

    ## Test if calling the __call__ of ReadInitialBalances returns the same as
    ## its compatible_function:

# Generated at 2022-06-21 20:02:17.092090
# Unit test for method add of class Ledger
def test_Ledger_add():
    #Test 1:
    accountA = Account('A', '', '', '')
    accountB = Account('B', '', '', '')
    accountC = Account('C', '', '', '')
    initialBalanceA = Balance(datetime.date(2020,1,1),0)
    initialBalanceB = Balance(datetime.date(2020,1,1),0)
    journalA = JournalEntry(datetime.date(2020,1,1), '', [Posting(accountA, Direction.DEBIT,500), Posting(accountB, Direction.CREDIT,500)])
    journalB = JournalEntry(datetime.date(2020,1,4), '', [Posting(accountB, Direction.DEBIT,200), Posting(accountC, Direction.CREDIT,200)])

# Generated at 2022-06-21 20:02:26.236620
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from .accounts import Account
    from .journaling import Journal
    from .ledgers import Ledger
    import unittest

    # create a ledger
    account = Account(account_id=1, parent=None, name="Cash and cash equivalents", description="", category="EQUITY",
                      **{})
    balance = Balance(date=None, value=None)
    led = Ledger(account=account, initial=balance)

    # create a Journal
    journal = Journal(journal_id=1, date="12/31/2019", description="Journal Entry",
                      **{})

    # create a posting
    posting = Posting(posting_id=1, journal=journal, account=account, amount=None, direction=None,
                      **{})

    #create the entry

# Generated at 2022-06-21 20:02:32.792113
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    ledgerA = Ledger(1, 2)
    ledgerB = Ledger(1, 2)
    ledgerC = Ledger(4, 2)
    ledgerD = Ledger(1, 3)
    ledgerE = Ledger(4, 3)

    assert ledgerA == ledgerB
    assert ledgerA != ledgerC
    assert ledgerA != ledgerD
    assert ledgerA != ledgerE
    assert ledgerC != ledgerD
    assert ledgerC != ledgerE
    assert ledgerD != ledgerE


# Generated at 2022-06-21 20:02:39.740334
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    assert (
        repr(GeneralLedger(DateRange(datetime.date(year=2020, month=1, day=1),datetime.date(year=2020, month=12, day=31)), ledgers={}))
        == "GeneralLedger(period=DateRange(since=datetime.date(2020, 1, 1), until=datetime.date(2020, 12, 31)), ledgers={})"
    )


# Generated at 2022-06-21 20:02:41.469859
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    assert repr(LedgerEntry(None, None, None)) == "(None: None) <None>"


# Generated at 2022-06-21 20:03:02.611131
# Unit test for function build_general_ledger
def test_build_general_ledger():
    import datetime
    from decimal import Decimal
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import Posting
    from .generic import Balance

    # Define test constants:

# Generated at 2022-06-21 20:03:10.943226
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    assert repr(LedgerEntry(Ledger(Account(1), Balance(datetime.date(2020, 1, 1), Quantity(10))), Posting(1, datetime.date(2020, 1, 2), 10), Quantity(20))) == "LedgerEntry(ledger=Ledger(account=Account(code=1), initial=Balance(date=datetime.date(2020, 1, 1), value=Decimal('10'))), posting=Posting(journal=1, date=datetime.date(2020, 1, 2), amount=Decimal('10'), direction=Direction.DEBIT), balance=Decimal('20'))"


# Generated at 2022-06-21 20:03:15.046747
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    x=LedgerEntry(None,None,None)
    y=LedgerEntry(None,None,None)
    assert x == y, 'Error: method __eq__ of class LedgerEntry fails'

# Generated at 2022-06-21 20:03:27.445675
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    a = Account('Cash')
    b = Account('Bank')
    c = Account('Cash')

    assert(Ledger(a, Balance({'date':datetime.datetime.today()}, Decimal(5))) == Ledger(a, Balance({'date':datetime.datetime.today()}, Decimal(5))))
    assert(Ledger(a, Balance({'date':datetime.datetime.today()}, Decimal(5))) == Ledger(c, Balance({'date':datetime.datetime.today()}, Decimal(5))))
    assert(Ledger(a, Balance({'date':datetime.datetime.today()}, Decimal(5))) != Ledger(b, Balance({'date':datetime.datetime.today()}, Decimal(5))))

# Generated at 2022-06-21 20:03:38.397993
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    """
    Test constructor for :py:class:`LedgerEntry<pyacc.general_ledger.ledger_entry.LedgerEntry>` class.
    """
    from .postings import Posting

    ## Construct a ledger entry and assert its properties:
    posting = Posting(None, None, None, datetime.date(2020, 1, 1), Amount(1), None)
    entry = LedgerEntry(None, posting, Quantity(Decimal(1)))
    assert entry.ledger is None
    assert entry.posting is posting
    assert entry.balance == Quantity(Decimal(1))
    assert entry.date == datetime.date(2020, 1, 1)
    assert entry.description == None
    assert entry.amount == Amount(1)
    assert entry.cntraccts == None
    assert entry.is_deb

# Generated at 2022-06-21 20:03:50.560132
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from .accounts import Account, AccountCode
    from .commons.numbers import Amount, Quantity

    balances = {
        Account(AccountCode('10'), 'Current Assets', Account.Type.ASSET, Account.Nature.CURRENT): Balance(
            datetime.date(2020, 1, 1), Quantity(42)
        ),
        Account(AccountCode('20'), 'Fixed Assets', Account.Type.ASSET, Account.Nature.FIXED): Balance(
            datetime.date(2020, 1, 1), Quantity(21)
        ),
        Account(AccountCode('30'), 'Current Liabilities', Account.Type.LIABILITY, Account.Nature.CURRENT): Balance(
            datetime.date(2020, 1, 1), Quantity(-21)
        ),
    }


# Generated at 2022-06-21 20:03:58.420046
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    ## Account definitions:
    account = Account(
        name="Income",
        parent=None,
        is_terminal=True,
        is_credit_positive=False,
    )
    ## Journal entry:
    journal = JournalEntry(
        date=datetime.date(2020, 1, 1),
        description="Sales",
        postings=[ Posting(account, Quantity(Decimal(100))) ],
    )
    ## Create the ledger entry:
    ledger = Ledger(account, Balance(datetime.date(2019,12,31), Quantity(Decimal(0))))
    entry = LedgerEntry(ledger,journal.postings[0], Quantity(Decimal(100)))

    assert entry.posting == journal.postings[0]
    assert entry.balance == Quantity(Decimal(100))
    assert entry.date == dat

# Generated at 2022-06-21 20:03:59.826415
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    foo = ReadInitialBalances
    foo = [1, 2]


# Generated at 2022-06-21 20:04:11.600076
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    ## Parametrize:
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))
    ## Create a mock initial balance reader:
    initial_balances = {
        Account(101, "Receivable"): Balance(period.until, Quantity(1000)),
        Account(111, "Sales"): Balance(period.until, Quantity(3000)),
    }

    def rd_initial_balances(p):
        return initial_balances

    ## Create a mock journal entry reader:

# Generated at 2022-06-21 20:04:15.309815
# Unit test for constructor of class Ledger
def test_Ledger():
    a = Ledger('a','b','c')
    assert a.account == 'a'
    assert a.initial == 'b'
    assert a.entries == ['a','b']
    assert a.ledgers == ['a','b']



# Generated at 2022-06-21 20:04:29.810743
# Unit test for constructor of class Ledger
def test_Ledger():
    """
    Unit test for constructor of class Ledger.
    """
    # Testing creation of Account instance
    import datetime

    account_number = 'Account'
    balance = Quantity(Decimal(5))
    account = Account(account_number)
    initial_balance = Balance(datetime.date(2019, 1, 1), balance)
    ledger = Ledger(account, initial_balance)
    assert ledger.account == account
    assert ledger.initial == initial_balance
    assert ledger.entries == []



# Generated at 2022-06-21 20:04:41.103961
# Unit test for constructor of class Ledger
def test_Ledger():
    # Create a ledger
    L = Ledger(Account('Assets', 'Cash'), Balance(datetime.date(2018,1,1),  10.00))
    # Check its entry
    p = Posting(datetime.date(2018, 1, 1), 'Cash', 2.00, 'Deposit', 'Deposit of $2500')
    L.add(p)
    assert len(L.entries) == 1
    assert L.entries[0].posting == p
    assert L.entries[0].balance == 12.00
    assert L.entries[0].amount == 2.00
    assert L.entries[0].is_credit == True
    assert L.entries[0].is_debit == False
    assert L.entries[0].credit == 2.00

# Generated at 2022-06-21 20:04:52.984643
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from decimal import Decimal
    from .journaling import Posting
    from .accounts import Account
    from .money import Money
    from .generic import Balance

    ## 3 postings in 2 transactions:

# Generated at 2022-06-21 20:05:04.922326
# Unit test for function build_general_ledger
def test_build_general_ledger():

    from datetime import date
    from unittest import TestCase
    from typing import List

    from .accounts import Account, AccountType
    from .journaling import Posting, JournalEntry
    from .commons.numbers import Amount, Quantity

    @dataclass
    class EntryWithDescription(JournalEntry):
        description: str

    # Constants:
    PERIOD = DateRange(since=date(2020, 1, 1), until=date(2020, 12, 31))

    # Test cases:

# Generated at 2022-06-21 20:05:15.226341
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    e0 = Ledger(
            Account(
                '123456789',
                'Dummy Account',
                True,
                True
            ),
            Balance(
                datetime.date(2000, 1, 1),
                Amount(
                    Decimal('1.00'),
                    'USD',
                    Decimal('1.00'),
                    datetime.date(2000, 1, 1)
                )
            )              
        )
    assert str(e0) == 'Ledger(account=Account(name=Dummy Account, terminal=True, document=True), initial=Balance(date=2000-01-01, value=Amount(quantity=1.00, currency=USD, rate=1.00, date=2000-01-01,)))'

# Generated at 2022-06-21 20:05:24.207077
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import is_journal_entry, JournalEntry, Posting, Direction, journal_entry

    import datetime

    from .accounts import Account, TerminalAccount, RealAccount, NominalAccount

    from .accounts import account_name_regex

    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange

    import pytest


    # This is an example journal with a single entry:

    # It is a journal entry dated 2019-01-01 with description "First entry",
    # and consisting of three postings:
    #
    # - a credit posting to account "Assets:Receivables:Cash" for amount $1,000
    # - a debit posting to account "Assets:Current Assets:Bank Account" for amount $1,000
    # - a debit posting to account "Expenses

# Generated at 2022-06-21 20:05:24.895456
# Unit test for constructor of class Ledger
def test_Ledger():
    pass

# Generated at 2022-06-21 20:05:33.928889
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account, AccountType

    @dataclass
    class JournalStub:
        date: datetime.date = datetime.date.today()
        cntracct: Account = Account("", AccountType.Asset)

    @dataclass
    class PostingStub:
        account: Account = Account("", AccountType.Asset)
        amount: Amount = Amount(0)
        journal: JournalStub = JournalStub()

    account = Account("", AccountType.Asset)
    initial = Balance(datetime.date.today(), Quantity(0))
    ledger = Ledger(account, initial)

    posting1 = PostingStub()
    posting1.account = account

    entry1 = LedgerEntry(ledger, posting1, Quantity(posting1.amount))

    result = ledger.add(posting1)

# Generated at 2022-06-21 20:05:39.128706
# Unit test for constructor of class Ledger
def test_Ledger():
    account=Account(123)
    initial=Balance(DateRange.latest(),Quantity(Decimal(0)))
    l=Ledger(account,initial)
    print(l.account)
    assert l.account.number == account.number
    assert l.initial.value == initial.value


# Generated at 2022-06-21 20:05:49.956845
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():

    M = int
    # Initial balances:
    initial_balances = {
        Account(1): Balance(datetime.date(2019, 1, 1), Quantity(Decimal(2000))),
        Account(4): Balance(datetime.date(2019, 1, 1), Quantity(Decimal(5000))),
    }

    # Journal entries:

# Generated at 2022-06-21 20:06:28.035675
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    import unittest
    import datetime

    from ..commons.zeitgeist import DateRange
    from .accounts import Account

    @dataclass
    class TestAccount(Account):
        pass

    @dataclass
    class TestLedger(ReadInitialBalances):
        pass

    source = TestLedger()

    def test(start_date, start_balance, end_date, end_balance):
        period = DateRange(start_date, end_date)
        actual = source(period)
        expected = {TestAccount(): Balance(start_date, start_balance), TestAccount(): Balance(end_date, end_balance)}
        assert actual == expected

    test(datetime.date(2019, 1, 1), 0, datetime.date(2020, 1, 1), 0)



# Generated at 2022-06-21 20:06:30.784969
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert compile_general_ledger_program(
        ReadInitialBalances.__call__, ReadJournalEntries.__call__
    )


# Generated at 2022-06-21 20:06:42.453459
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    from ..core import AccountingPeriod
    from ..domain.accounts import Terminal, Account
    from ..domain.journaling import Posting
    from ..domain.ledgering import Ledger
    from .accounts import Balance, ReadInitialBalances


# Generated at 2022-06-21 20:06:55.023569
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    from .journaling import Journal, Postings, JournalEntry
    from .accounts import Account
    from .numbers import Amount, Quantity

    def new_journal():
        debit_posting = Posting(
            account=Account("A001", "Income", "Sales", "Sales"),
            amount=Amount(100),
        )
        credit_posting = Posting(
            account=Account("A019", "Expenses", "Taxes", "VAT"),
            amount=Amount(20),
        )
        journal = Journal(
            date=datetime.date(2019, 1, 1),
            description="Sales - 100",
            postings=[debit_posting, credit_posting],
        )

        return journal
    
    journal = new_journal()


# Generated at 2022-06-21 20:07:03.848305
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    test_Account = Account('Test Acc')
    test_Posting = Posting(decimal.Decimal('100.00'), test_Account, True)
    test_Ledger = Ledger(test_Account, Balance(datetime.date(2000, 1, 1), decimal.Decimal('0.00')))
    test_LedgerEntry = LedgerEntry(test_Ledger, test_Posting, decimal.Decimal('100.00'))


# Generated at 2022-06-21 20:07:12.550804
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from .accounts import Account

    # Initialize account
    a1 = Account("a", Account.Type.ASSET, "a desc")
    a2 = Account("b", Account.Type.ASSET, "b desc")

    # Initialize journal entry
    je1 = JournalEntry(datetime.date.today(), "je desc")
    je2 = JournalEntry(datetime.date.today(), "je desc")

    # Initialize posting
    p1 = Posting(je1, a1, 500)
    p2 = Posting(je1, a2, -500)
    p3 = Posting(je2, a2, 2000)
    p4 = Posting(je2, a1, -2000)

    # Initialize balance
    b1 = Balance(datetime.date(2001, 1, 1), 0)

    #

# Generated at 2022-06-21 20:07:23.923425
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    from ..commons import Description, DescriptionType
    from .accounts import AccountType, AccountSubtype
    from .journaling import JournalEntry
    from .generic import Balance

    a: Account = Account(1, 'Cash', AccountType.ASSET, AccountSubtype.CURRENT_ASSET)
    b: Account = Account(2, 'Sales', AccountType.REVENUE, AccountSubtype.OPERATING_REVENUE)
    c: Account = Account(3, 'Inventory', AccountType.ASSET, AccountSubtype.CURRENT_ASSET)


# Generated at 2022-06-21 20:07:29.005563
# Unit test for constructor of class Ledger
def test_Ledger():
    account_test = Account(1, 'TEST', 'TEST', '1', '2', 3, 4, 5)
    balance_test = Balance(datetime.date(2019, 1, 1), 5)

    test_ledger = Ledger(account_test, balance_test)

    assert test_ledger.account.id == 1
    assert test_ledger.account.title == "TEST"
    assert test_ledger.account.type == "TEST"
    assert test_ledger.account.code == "1"
    assert test_ledger.account.number == "2"
    assert test_ledger.account.level == 3
    assert test_ledger.account.parent_id == 4
    assert test_ledger.account.root_id == 5

    assert test_ledger.initial.date == dat

# Generated at 2022-06-21 20:07:40.299920
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    # Test with two GeneralLedger instances that have the same attributes
    assert (
        GeneralLedger(DateRange("2010-01-01", "2010-01-31"), {Account("A01"): None, Account("A02"): None})
        == GeneralLedger(DateRange("2010-01-01", "2010-01-31"), {Account("A01"): None, Account("A02"): None})
    )
    # Test with two GeneralLedger instances that have different attributes

# Generated at 2022-06-21 20:07:52.959463
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    class JE:
        def __init__(self, date, desc, debit, credit):
            self.date = date
            self.description = desc
            self.debit = debit
            self.credit = credit
    a = Account("1001")
    b = Account("1002")
    c = Account("1003")
    d = Account("1004")
    e = Account("1005")
    f = Account("1006")
    g = Account("1007")
    h = Account("1008")
    i = Account("1009")
    j = Account("1010")
    k = Account("1011")
    l = Account("1012")
    m = Account("1013")
    n = Account("1014")
    o = Account("1015")
    p = Account("1016")

# Generated at 2022-06-21 20:08:28.573361
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    from .accounts import Account, AccountType

    account_1 = Account(1, AccountType.ASSET, "Account 1")
    account_2 = Account(2, AccountType.ASSET, "Account 2")

    account_1_balance = Balance(datetime.date(2015, 1, 1), Quantity(Decimal(1000)))
    account_2_balance = Balance(datetime.date(2015, 1, 1), Quantity(Decimal(2000)))

    read_initial_balances = ReadInitialBalances()

    initial_balances = read_initial_balances(
        DateRange(datetime.date(2015, 1, 1), datetime.date(2015, 12, 31))
    )

    assert initial_balances == {account_1: account_1_balance, account_2: account_2_balance}

# Generated at 2022-06-21 20:08:33.139074
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
  # Test 1
  entry1 = LedgerEntry('ledger', 'posting', 'balance')
  entry2 = LedgerEntry('ledger', 'posting', 'balance')

  assert entry1 == entry2


# Generated at 2022-06-21 20:08:36.712463
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from ..commons.test_commons import check_implementation_of_protocol


    def run(self) -> InitialBalances:
        return {}


    assert check_implementation_of_protocol(ReadInitialBalances, "__call__", run)



# Generated at 2022-06-21 20:08:42.994570
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..ledgers.journaling import make_journal_entry
    from ..ledgers.accounts import make_account
    from datetime import date
    from decimal import Decimal
    account1 = make_account(account_number=151000, account_name="Cash in Bank")
    account2 = make_account(account_number=230000, account_name="Building")
    account3 = make_account(account_number=231000, account_name="Office Furnitures")
    account4 = make_account(account_number=232000, account_name="Office Equipment")

# Generated at 2022-06-21 20:08:52.938246
# Unit test for constructor of class Ledger
def test_Ledger():
    from hamcrest import assert_that, instance_of
    from hamcrest.core.core.isequal import equal_to

    account = Account(id=1, name="account")
    assert_that(account, instance_of(Account))
    assert_that(account.id, equal_to(1))
    assert_that(account.name, equal_to("account"))

    date = datetime.date(2018, 2, 1)
    assert_that(date, equal_to(datetime.date(2018, 2, 1)))

    balance = Balance(date=date, value=Decimal("1000"))
    assert_that(balance, instance_of(Balance))
    assert_that(balance.date, equal_to(datetime.date(2018, 2, 1)))

# Generated at 2022-06-21 20:09:03.030566
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    import pytest
    from dataclasses import asdict

    def _expected():
        from .accounts import Subaccount, Terminal
        from .implementations import NewLedger, NewLedgerAccount

        return {
            Subaccount("20000", NewLedger("2020", "5000", NewLedgerAccount("5000"), [], [], None)): Balance(
                datetime.date(2020, 1, 1), 1
            )
        }

    def _program(period: DateRange) -> InitialBalances:
        return _expected()

    def _test(program: ReadInitialBalances):
        actual = program(DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31)))
        assert _expected() == actual

    _test(_program)



# Generated at 2022-06-21 20:09:12.234108
# Unit test for method add of class Ledger
def test_Ledger_add():
    account1 = Account("01-0000")
    account2 = Account("02-0000")
    balance1 = Balance(datetime.date(2000, 1, 1), Quantity(100))
    entry1 = LedgerEntry(None, Posting(None, account1, Decimal(100), False), Quantity(100))
    entry2 = LedgerEntry(None, Posting(None, account2, Decimal(100), True), Quantity(100))
    entry3 = LedgerEntry(None, Posting(None, account1, Decimal(100), False), Quantity(200))
    journal1 = JournalEntry("Test journal", datetime.date(2000,1,1), [entry1.posting, entry2.posting])

# Generated at 2022-06-21 20:09:22.994238
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .journaling import Bookings, JournalEntry, Posting, Contract, Direction, Journal

    # Set up test data
    account = Account(name='Assets', number='1000')
    debit_posting = Posting(account=account, amount=Amount(123), direction=Direction.debit)
    journal = Journal(
        date=datetime.date(2020, 1, 1), description='Initial balances', bookings=Bookings.initial_balances,
        postings=[debit_posting])

    initial_balance = Balance(date=datetime.date(2020, 1, 1), value=Quantity(1234))

    ledger = Ledger(account=account, initial=initial_balance)

    # Run method under test
    entry = ledger.add(debit_posting)

    # Check results
    assert entry.posting == debit_post

# Generated at 2022-06-21 20:09:27.884046
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    period = DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31))
    journal = read_journal_entries(period)
    initial = read_initial_balances(period)

    ledger = build_general_ledger(period, journal, initial)    
    
    assert ledger.period == period
    
    

# Generated at 2022-06-21 20:09:28.403073
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    assert 1 == 1

# Generated at 2022-06-21 20:11:12.509662
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    # Set up
    from neat.datatypes.trees import build_tree
    from neat.datatypes.embeddedtree import Leaf
    from neat.datatypes.accounts import Account
    account = Account.build_account(build_tree(Leaf(1), Leaf(2), Leaf(3)))
    initial_balance = Balance(datetime.date(2015, 1, 1), Quantity(1))
    ledger = Ledger(account, initial_balance)
    expected_repr = 'Ledger(Account(name=\'a_1\', is_terminal=True, is_group=False, description=None), ' \
                    'Balance(date=datetime.date(2015, 1, 1), value=1))'

    # Test
    assert repr(ledger) == expected_repr
