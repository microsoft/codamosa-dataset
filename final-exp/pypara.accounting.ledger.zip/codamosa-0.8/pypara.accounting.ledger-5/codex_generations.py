

# Generated at 2022-06-12 06:00:06.235092
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Tests the compile_general_ledger_program function.
    """
    from datetime import date
    from decimal import Decimal
    from typing import NamedTuple
    from .accounts import Account, Asset, Expense, Income
    from .journaling import Direction, JournalEntry as JournalEntryType, Posting, ReadJournalEntries
    from .numbers import Amount, Quantity
    from .typing import AccountingEntity

    ## Define test accounts:
    account_0 = Account(Expense, "1", "Account 0")
    account_1 = Account(Expense, "2", "Account 1")
    account_2 = Account(Income, "1", "Account 2")
    account_3 = Account(Asset, "1", "Account 3")

    ## Helper test functions:

# Generated at 2022-06-12 06:00:07.536228
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-12 06:00:15.017832
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    @dataclass()
    class FakeReadJournalEntries:
        journal_entries: Iterable[JournalEntry]
        def result(self, period):
            return self.journal_entries

    p = compile_general_ledger_program(lambda x: InitialBalances(), FakeReadJournalEntries([]))
    p(DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31)))

# Generated at 2022-06-12 06:00:20.099135
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from .accounts import ASSET
    from .commons import Zeichenkette

    __read_initial_balances = ReadInitialBalances()
    assert( [ ASSET ], Zeichenkette( "2019-04-01" ).to_date(), Zeichenkette( "2019-04-30" ).to_date() ) == __read_initial_balances.__call__


# Generated at 2022-06-12 06:00:30.323803
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import a_day
    from ..journaling import JournalEntry, Posting
    from ..accounting import Account, AccountType, Balance, BalanceType
    from ..bookkeeping import (
        Accounts,
        Interval,
        ReadAccounts,
        ReadBalances,
        ReadJournalEntries,
        ReadPostings,
    )

    ## Define a few accounts:
    accounts: Accounts = {
        Account(AccountType.ASSET, "Sales Revenue", None, "SALES"): Account(
            AccountType.ASSET, "Sales Revenue", None, "SALES"
        ),
        Account(AccountType.ASSET, "Cash", None, "CASH"): Account(
            AccountType.ASSET, "Cash", None, "CASH"
        ),
    }

    ## Define a

# Generated at 2022-06-12 06:00:38.829245
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .journaling import build_journal_entry, post
    from .accounts import AccountType
    from .commons.zeitgeist import DateRange

    ## A Python implementation of the algebra. It is a bit long winded, but its purpose is to be testable.
    @dataclass
    class Implementation:
        opening: datetime.date
        closing: datetime.date
        initial_balances: InitialBalances

        def read_initial_balances(self, period: DateRange) -> InitialBalances:
            return self.initial_balances

        def read_journal_entries(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            return [post(build_journal_entry(), self.closing, self.opening)]

    ## Build the test setup

# Generated at 2022-06-12 06:00:45.724063
# Unit test for method add of class Ledger
def test_Ledger_add():
    l = Ledger(Account(1), Balance(datetime.date(year=2019, month=1, day=1), Quantity(Decimal('100.00'))))
    l.add(Posting(decimal.Decimal(1), Account(1), Account(2), datetime.date(year=2019, month=1, day=1), 'test', [], ))
    assert len(l.entries) == 1
    assert l.entries[0].balance == Quantity(Decimal('200.00'))


# Generated at 2022-06-12 06:00:58.343487
# Unit test for function build_general_ledger
def test_build_general_ledger():
    ## Import:
    from ..commons.zeitgeist import DateRange
    from ..journaling.entries import JournalEntry, Posting
    from ..journaling.types import Amount
    from ..accounts.types import Account
    from ..accounts.currencies import EUR, USD
    from hypothesis import given, strategies as st
    from .types import Quantity
    from datetime import datetime
    import pytest
    import hypothesis.extra.fakefactory as ff

    class Fixture:
        def __init__(self):
            self.journal = []
            self.entries = []
            self.initial_balances = {}

        def _add_journal_entry(
            self, date: datetime, description: str, *postings: Posting,
        ):
            self.journal.append(JournalEntry(date, description, *postings))

# Generated at 2022-06-12 06:01:06.078643
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .accounts import Account
    from .journaling import JournalEntry
    from .types import AccountType

    a = Account(code="1", name="Cash", type=AccountType.ASSET)
    b = Account(code="2", name="Sales", type=AccountType.INCOME)
    c = Account(code="3", name="Bank", type=AccountType.ASSET)

    j1 = JournalEntry(date="2018-12-31", description="Startup")
    j1.postcr(c, amount=100)
    j1.postdr(a, amount=100)

    j2 = JournalEntry(date="2019-01-01", description="Sales for January")
    j2.postcr(b, amount=1000)
    j2.postdr(a, amount=1000)


# Generated at 2022-06-12 06:01:16.253099
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account
    from .commons.zeitgeist import Date, DateRange
    from .journaling import JournalEntry, Posting
    from .journaling.algebra import ReadJournalEntries
    from .types import GLTransaction

    # Mock algebra for reading journal entries.
    mock_read_journal_entries = ReadJournalEntries(lambda period: [])

    # Mock algebra for reading initial balances.
    class mock_read_initial_balances:

        @staticmethod
        def __call__(period: DateRange) -> InitialBalances:
            return InitialBalances({})

    # Compile the program.
    program = compile_general_ledger_program(mock_read_initial_balances, mock_read_journal_entries)

    # Mock accounting period.

# Generated at 2022-06-12 06:01:28.754471
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from .accounts import new_account
    from .journaling import new_journal_entry
    from .books import Book
    from ..commons.zeitgeist import DateRange
    from ..commons.numbers import Amount, Quantity, add
    from ..commons.types import Str, Enum
    from datetime import date
    import json

    # Define an enum type:
    Direction = Enum(["DEBIT", "CREDIT"])

    # Define an account:
    a_account = new_account(code="A", name="Asset", type=Str("Asset"))

    # Define the book:
    book = Book()

    # Define the test values:
    period = DateRange(since=date(2019, 1, 1), until=date(2019, 12, 31))

    # Define the test journal entries:
   

# Generated at 2022-06-12 06:01:39.126653
# Unit test for method add of class Ledger
def test_Ledger_add():
    from pyff.journaling import Posting, JournalEntry
    from pyff.commons.numbers import Amount, Quantity
    from pyff.accounting import Account, AccountType, Balance

    # Create assets entry
    assets = Account(1001, "Assets", AccountType.ASSET, None)

    # Create journal entry
    je = JournalEntry(datetime.date(2019, 12, 1), "Debit test")
    je.add(Posting(assets, Amount(100), True))
    je.add(Posting(assets, Amount(100), False))
    # Create initial balance
    initial = Balance(datetime.date(2019, 12, 1), Quantity(0))
    # Create Ledger
    ledger = Ledger(assets, initial)

    # Check debit
    assert ledger.debit is None

# Generated at 2022-06-12 06:01:48.237795
# Unit test for function build_general_ledger
def test_build_general_ledger():
    import unittest
    from datetime import date
    from decimal import Decimal
    from turnkey.journaling import Journal
    from turnkey.accounts import Account, AccountType as T

    # define test accounts
    assets = Account("assets", T.assets)
    cash = Account("cash", T.assets)
    stock = Account("stock", T.assets)
    equity = Account("equity", T.equity)
    income = Account("income", T.income)
    profit = Account("profit", T.income)
    expenses = Account("expenses", T.expenses)

    # define test journal entries
    journal1 = Journal(date(2020, 1, 1), "cash opening balance")
    journal1.post(
        amount=Decimal(100), direction=1, account=cash, journal=journal1
    )
    journal

# Generated at 2022-06-12 06:01:49.270696
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-12 06:01:57.554282
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from dataclasses import dataclass
    from decimal import Decimal
    from datetime import date
    from typing import Iterable
    from .accounts import Account, Cash
    from .journaling import Journal, Posting, JournalEntry
    from ..commons.zeitgeist import DateRange

    # Mock implementation of the ReadInitialBalances protocol:
    @dataclass
    class ReadInitialBalancesMock(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {Cash: Balance(period.since, Quantity(Decimal(1000)))}

    # Mock implementation of the ReadJournalEntries protocol:

# Generated at 2022-06-12 06:01:59.136926
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass



# Generated at 2022-06-12 06:02:08.639163
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # Read initial balances for period 2010-01-01 to 2010-12-31
    initial_balances = read_initial_balances(DateRange(datetime.date(2010, 1, 1), datetime.date(2010, 12, 31)))

# Generated at 2022-06-12 06:02:19.494689
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    import datetime
    from decimal import Decimal
    from doodledashboard.component.catalog.models import AccountModel
    from doodledashboard.component.journaling.models import PostingModel
    from doodledashboard.component.journaling.models import JournalEntryModel
    from doodledashboard.component.journaling.models import ReadJournalEntriesModel
    from doodledashboard.component.ledgers.models import ReadInitialBalancesModel
    import random
    import uuid
    from doodledashboard.component.ledgers.models import build_general_ledger
    from doodledashboard.component.ledgers.models import compile_general_ledger_program
    from doodledashboard.component.ledgers.models import GeneralLedger

    # Generate test data

# Generated at 2022-06-12 06:02:25.134301
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Setup
    account = Account(1, '1', True)
    balance = Balance(datetime.date(2018, 1, 1), Quantity(0))
    posting = Posting(datetime.date(2018, 1, 1), Quantity(0))
    posting.direction = 1
    posting.amount = Quantity(5)
    posting.journal = JournalEntry(datetime.date(2018, 1, 1), 'test')
    entry = LedgerEntry(account, posting, Quantity(0))
    test_ledger = Ledger(account, balance)
    # Expected value
    expected_balance = Quantity(5)
    # Execute
    test_ledger.add(posting)
    # Test
    assert test_ledger.entries[0].balance == expected_balance

# Generated at 2022-06-12 06:02:33.418987
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from datetime import date, timedelta

    from .accounts import Account

    # Initial balances:
    initial: InitialBalances = {
        Account("Assets:Cash"): Balance(date(2019, 9, 1), Quantity(Decimal("1000"))),
        Account("Liabilities:Accounts Payable"): Balance(date(2019, 9, 1), Quantity(Decimal("0"))),
        Account("Equity:Retained Earnings"): Balance(date(2019, 9, 1), Quantity(Decimal("0"))),
    }

    # ledger_program = compile_general_ledger_program(lambda p: initial, read_journal_entries)

# Generated at 2022-06-12 06:02:47.579176
# Unit test for function build_general_ledger
def test_build_general_ledger():
    period = DateRange(datetime.date(year=2019, month=1, day=1), datetime.date(year=2019, month=12, day=31))
    
    rounding = 2
    initial_balances = {
        Account(code="1000", name="Cash in Bank", category="C", terminal=True): Balance(date=period.since, value=Quantity(value=Decimal(100), rounding=rounding)),
        Account(code="2000", name="Accounts Receivable", category="A", terminal=True): Balance(date=period.since, value=Quantity(value=Decimal(200), rounding=rounding))
    }
    

# Generated at 2022-06-12 06:02:59.130824
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import latest, past

    from .accounts import LedgerAccount
    from .journaling import Journal, Posting, JournalEntry

    from .example_transactions import sale

    from .books import AssetBook, LiabilityBook

    asset_book = AssetBook()

    print('\n #### BUILD GENERAL LEDGER FUNCTION TEST')
    print('\n')
    print(' #### Setup - Asset Book')
    print(f'##### {asset_book.view_accounts}')
    print('\n')
    print(' #### Setup - General Ledger')
    print('##### create general ledger')
    period = past(day=1)

# Generated at 2022-06-12 06:03:03.400231
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # https://stackoverflow.com/a/52580141/
    from unittest.mock import Mock

    x = Mock(spec=ReadInitialBalances)
    x(123)
    assert x.called



# Generated at 2022-06-12 06:03:04.159540
# Unit test for function build_general_ledger
def test_build_general_ledger():
    ## TODO: implement unit test
    pass

# Generated at 2022-06-12 06:03:05.370188
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert issubclass(GeneralLedgerProgram, Protocol)



# Generated at 2022-06-12 06:03:08.674834
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    @dataclass
    class _T(ReadInitialBalances):
        def __call__(self, *args, **kwargs) -> InitialBalances:
            pass

    _T()(*args, **kwargs)


# Generated at 2022-06-12 06:03:17.955459
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .accounts import Account, AccountTree
    from .balancing import Balance
    from .journaling import Direction, Journal, Posting
    import datetime
    from decimal import Decimal
    from unittest.mock import MagicMock

    # Common setup

# Generated at 2022-06-12 06:03:18.957585
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert False, "Not implemented"


# Generated at 2022-06-12 06:03:19.920594
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-12 06:03:30.956307
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import today, yesterday
    from .accounts import Asset, Liability


# Generated at 2022-06-12 06:03:52.912353
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import create_journal_entry
    from .accounts import Account, AccountType
    import decimal
    import datetime
    from .generic import Day
    ## Initialize test data:
    initial_balances = {
        Account(AccountType.ASSET, 'Cash', terminal=True): Balance(date=datetime.date(2017, 12, 31), value=Quantity(decimal.Decimal(100))),
        Account(AccountType.ASSET, 'Equity', terminal=True): Balance(date=datetime.date(2017, 12, 31), value=Quantity(decimal.Decimal(0)))
    }

    ## Build the general ledger program:
    read_ib = lambda p: initial_balances

# Generated at 2022-06-12 06:04:03.098925
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Tests the :py:func:`compile_general_ledger_program` function.
    """
    # Algebra implementation which reads initial balances:
    def read_initial_balances(period):
        return {
            Account("ASSETS-BANK-USD"): Balance(period.since, Quantity(10)),
            Account("ASSETS-BANK-EUR"): Balance(period.since, Quantity(5)),
        }

    # Algebra implementation which reads journal entries.

# Generated at 2022-06-12 06:04:09.742393
# Unit test for method add of class Ledger
def test_Ledger_add():
    l = Ledger(1, Balance(1, Quantity(Decimal(0))))
    l.add(Posting(1, Quantity(Decimal(1))))
    assert(l.entries[0].balance == Quantity(Decimal(1)))
    l.add(Posting(1, Quantity(Decimal(2))))
    assert(l.entries[1].balance == Quantity(Decimal(3)))


# Generated at 2022-06-12 06:04:18.094769
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # Subclass of ReadInitialBalances:
    class _ReadInitialBalances(ReadInitialBalances):
        def __init__(self, initial_balances: InitialBalances):
            self.initial_balances = initial_balances

        def __call__(self, period: DateRange) -> InitialBalances:
            return self.initial_balances

    # Subclass of ReadJournalEntries:
    class _ReadJournalEntries(ReadJournalEntries[str]):
        def __init__(self, journal_entries: Iterable[JournalEntry[str]]):
            self.journal_entries = journal_entries

        def __call__(self, period: DateRange) -> Iterable[JournalEntry[str]]:
            return self.journal_entries

    # Argument:

# Generated at 2022-06-12 06:04:26.443016
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    @dataclass
    class MockInitialBalances(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {Account("11001", "Cash and Cash Equivalents"): Balance(period.since, Quantity(Decimal(0)))}
    assert MockInitialBalances()(DateRange(datetime.date(2018, 8, 1), datetime.date(2018, 8, 31))) == {Account("11001", "Cash and Cash Equivalents"): Balance(datetime.date(2018, 8, 1), Quantity(Decimal(0)))}


# Generated at 2022-06-12 06:04:37.457293
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    import unittest

    from ..commons.numbers import Amount

    from .accounts import Account, AccountType

    assert Account is not None
    assert AccountType is not None
    assert Amount is not None
    assert build_general_ledger is not None

    @dataclass
    class TestJournalEntry:
        date: date
        description: str
        debit_account: Account
        debit_amount: Amount
        credit_account: Account
        credit_amount: Amount

    class TestGeneralLedgerTests(unittest.TestCase):
        def test_build_general_ledger(self) -> None:
            # Arrange:
            period = DateRange(date(2019, 1, 1), date(2019, 1, 31))

# Generated at 2022-06-12 06:04:46.496149
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.context import Context
    from .accounts import Account, AccountGroup, AccountType
    from .journaling import JournalEntry, Posting
    from ..commons.zeitgeist import DateRange

    ################################################################################################
    # TEST1:
    ################################################################################################

    ## Initial balances:

# Generated at 2022-06-12 06:04:51.089504
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .pockets import Pocket
    from .transactions import LedgerTransaction
    from .accounts import COMPOUND_ACCOUNTS 

    def _get_journal_entries_stub(period: DateRange) -> Iterable[JournalEntry[LedgerTransaction]]:
        ## Import:
        from .journaling import Journal, JournalEntry, Posting

        ## Done, return:

# Generated at 2022-06-12 06:05:01.680994
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import JournalEntry, Posting
    from .accounts import Account

    a = Account("A", "")
    b = Account("B", "")
    c = Account("C", "")
    d = Account("D", "")
    e = Account("E", "")

    e1 = JournalEntry(
        datetime.date(2019, 11, 1),
        "1",
        [
            Posting(a, Decimal(100), Posting.Direction.Debit),
            Posting(b, Decimal(100), Posting.Direction.Credit),
        ],
    )

# Generated at 2022-06-12 06:05:10.633460
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import date_since, date_until
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .monads import Do

    ## Initial balances:

# Generated at 2022-06-12 06:05:49.638402
# Unit test for method add of class Ledger
def test_Ledger_add():
    """
    This method tests the add method of class Ledger.
    """
    from .journaling import JournalEntry
    from datetime import date
    from .ioc import Zeolite

    # Create test account.
    test_account = Account(code='1', name='test')
    # Create journal entries.
    entry1 = JournalEntry(date=date(2000,1,1), description='Entry1', postings=[Posting(account=test_account, amount=100, direction=Direction.CREDIT)])
    entry2 = JournalEntry(date=date(2000,1,2), description='Entry2', postings=[Posting(account=test_account, amount=100, direction=Direction.DEBIT)])
    # Create test ledger.

# Generated at 2022-06-12 06:06:00.347206
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():

    from unittest.mock import MagicMock
    import datetime
    from decimal import Decimal
    from hamcrest import assert_that, has_entries, has_length, has_entry, is_
    from ledger.accounts import Asset
    from ledger.amounts import Amount
    from ledger.balances import Balance
    from ledger.journaling import JournalEntry, Posting

    # For the module to pass automated test, it must adhere to the algebra's type definition.
    ReadInitialBalances = MagicMock(spec=ReadInitialBalances)
    ReadJournalEntries = MagicMock(spec=ReadJournalEntries)

    # Compile a program.
    program = compile_general_ledger_program(ReadInitialBalances, ReadJournalEntries)

    # Mock the initial balances.

# Generated at 2022-06-12 06:06:10.782584
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():

    # system under test:
    from basic_algebra import build_general_ledger_program as sut

    # corner cases:
    # - period: DateRange(since=datetime.date(year=2020, month=1, day=1), until=datetime.date(year=2020, month=1, day=31))
    #   - initial: {}
    #   - journal: []

    # cases:
    # - period: DateRange(since=datetime.date(year=2020, month=1, day=1), until=datetime.date(year=2020, month=1, day=31))
    #   - initial: {expenses: Balance(date=datetime.date(year=2020, month=1, day=1), value=Decimal('0'))}
    #   - journal_entries: [


# Generated at 2022-06-12 06:06:21.263448
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    def test_read_initial_balances(period: DateRange) -> InitialBalances:
        return {Account("10100"): Balance(period.since, Quantity(Decimal(12.34)))}

    def test_read_journal_entries(period: DateRange) -> "JournalEntries":
        raise NotImplementedError

    bp = compile_general_ledger_program(read_initial_balances=test_read_initial_balances, read_journal_entries=test_read_journal_entries)
    assert bp(DateRange(datetime.date(year=2020, month=9, day=1), datetime.date(year=2020, month=9, day=30)))

# Generated at 2022-06-12 06:06:26.990568
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from unittest.mock import patch

    # Stub:
    def stub_read_initial_balance(period: DateRange) -> InitialBalances:
        return {}

    def stub_read_journal_entries(period: DateRange) -> List[JournalEntry[_T]]:
        return []

    # Mock:
    def mock_build_general_ledger(
        period: DateRange, journal_entries: List[JournalEntry[_T]], initial_balances: InitialBalances
    ) -> GeneralLedger[_T]:
        return GeneralLedger(period, {})

    # Test:

# Generated at 2022-06-12 06:06:36.789340
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    class _ReadInitialBalancesStub:
        def __call__(self, period: DateRange) -> InitialBalances:
            return {
                Account("1010"): Balance(period.since, Quantity(Decimal(0))),
                Account("5000"): Balance(period.since, Quantity(Decimal(0))),
                Account("7000"): Balance(period.since, Quantity(Decimal(0))),
                Account("7030"): Balance(period.since, Quantity(Decimal(0))),
            }

    _read_initial_balances = _ReadInitialBalancesStub()


# Generated at 2022-06-12 06:06:37.414304
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass

# Generated at 2022-06-12 06:06:47.391039
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Tests function compile_general_ledger_program.
    """
    from ..books.assets import Asset, _T as _A
    from ..books.liabilities import Liability, _T as _L
    from ..books.transactions import Transaction
    from ..books.math import algebra, expose
    from ..commons.math_utils import zero
    from ..commons.types import _T as _E
    from ..financial_math.time_value_of_money import Quantity, _T as _Q, _U
    from .accounts import Account, AccountClass, OTHER_ASSET, OTHER_LIABILITY
    from .journaling import _T as _J, Journal, Posting
    from .reporting.balance_sheet import BalanceSheet
    from .reporting.income_statement import IncomeStatement

    ## Initialize some accounts:
    asset_

# Generated at 2022-06-12 06:06:48.118516
# Unit test for method add of class Ledger
def test_Ledger_add():
    pass

# Generated at 2022-06-12 06:06:59.451955
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .journaling import build, ReadJournalEntries
    from .accounts import build_accounts
    from .initial_balances import build_initial_balances
    from datetime import date, timedelta
    from inflect import engine as inflect

    # Define financial period.
    since = date(2019, 1, 1)
    until = date(2019, 12, 31)
    period = DateRange(since, until)

    # Build a list of accounts and a dictionary of initial balances.
    accounts = build_accounts()
    initial_balances = build_initial_balances(period)

    # Build a journal entry builder, a read journal entries algebra and a read initial balances algebra.

# Generated at 2022-06-12 06:08:32.298400
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    @dataclass
    class JournalEntryImpl:
        """
        Dummy implementation of journal entry.
        """

        def __init__(self, date: datetime.date):
            self.date = date

        @property
        def period(self):
            return DateRange(self.date, self.date)

    @dataclass
    class PostingImpl:
        """
        Dummy implementation of journal entry.
        """

        def __init__(self, account: Account, amount: Amount, direction: int):
            self.account = account
            self.amount = amount
            self.direction = direction

        @property
        def date(self) -> datetime.date:
            return datetime.date(2020, 1, 1)


# Generated at 2022-06-12 06:08:32.854514
# Unit test for function build_general_ledger
def test_build_general_ledger():
    pass

# Generated at 2022-06-12 06:08:44.237313
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .registers import ReadLedgerEntries, ReadLedgerInitialBalances

    @dataclass
    class GeneralLedgerState(Generic[_T]):
        """
        Helper class which implements the algebraic requirement.
        """

        initial: InitialBalances
        journal: List[JournalEntry[_T]]

    @dataclass
    class Algebra(ReadLedgerInitialBalances, ReadLedgerEntries[_T]):
        """
        Algebraic structure specific to this unit test.
        """

        state: Optional[GeneralLedgerState[_T]] = None


# Generated at 2022-06-12 06:08:51.459358
# Unit test for method add of class Ledger
def test_Ledger_add():
    import datetime
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .generic import Balance, Quantity
    from commons.numbers import Amount

    assetaccount = Account('Asset', AccountType.ASSET)
    incomeaccount = Account('Income', AccountType.INCOME)
    ledger = Ledger(assetaccount, Balance(datetime.date(2020,1,1), Quantity(0)))
    posting = Posting(assetaccount, Amount(100), 1)
    journal = JournalEntry(datetime.date(2020,1,1), 'Journal Entry')
    journal.add(posting)
    posting = Posting(assetaccount, Amount(100), 1, journal)

    entry = ledger.add(posting)

    assert entry.balance.value == 100


# Generated at 2022-06-12 06:09:02.061026
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from dataclasses import dataclass, field
    from werkzeug.datastructures import ImmutableDict
    from .accounts import AccountNumber

    @dataclass
    class MockReadInitialBalances:
        initial_balances: dict

# Generated at 2022-06-12 06:09:12.230191
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from . import BuildJournalEntries
    from .accounts import Cash, Expenses, GoodsSold, Income, Inventory

    # Set an accounting period:
    period = DateRange(datetime.date(year=2020, month=1, day=1), datetime.date(year=2020, month=12, day=31))

    # Set a journal entry:
    j = JournalEntry(
        datetime.date(year=2020, month=1, day=1),
        "Cash Sale",
        [
            Posting(Cash, Amount(Decimal(50)), True),
            Posting(Income, Amount(Decimal(50)), True),
            Posting(Inventory, Amount(Decimal(50)), False),
            Posting(GoodsSold, Amount(Decimal(50)), False),
        ],
    )

    # Set initial balances:

# Generated at 2022-06-12 06:09:22.221216
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from datetime import date

    from .commons.test.factories import JournalEntryFactory

    # Given the following journal entries:

# Generated at 2022-06-12 06:09:31.141007
# Unit test for method add of class Ledger
def test_Ledger_add():
    account = Account("1111", "account 1", 20, 10)
    initial = Balance(date=datetime.date(2019,1,1),value=Decimal(100))
    posting = Posting(date=datetime.date(2019,1,1),amount=Decimal(10),direction=1,account=account)
    posting1 = Posting(date=datetime.date(2019,1,2),amount=Decimal(10),direction=1,account=account)
    posting2 = Posting(date=datetime.date(2019,1,3),amount=-10,direction=-1,account=account)
    posting3 = Posting(date=datetime.date(2019,1,4),amount=-10,direction=-1,account=account)
    ledger = Ledger(account=account,initial=initial)

# Generated at 2022-06-12 06:09:33.644760
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-12 06:09:39.427926
# Unit test for function build_general_ledger
def test_build_general_ledger():
    ## Import everything from modules above:
    import os.path
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting, read_journal_entries_from_csv, write_journal_entries_to_csv
    from .ledgers import GeneralLedger, build_general_ledger, read_initial_balances_from_csv, \
        write_general_ledger_to_csv

    ## Fictitious data:
    iperiod = DateRange("2019-07-01", "2019-09-30")
    fpath_initial = "initial.csv"
    fpath_journal = "journal.csv"
    fpath_general = "general.csv"