

# Generated at 2022-06-12 06:00:05.414053
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..journaling import Journal
    from ..accounts import Account, AccountType

    period_since = datetime.date(2018, 1, 1)
    period_until = datetime.date(2018, 12, 31)
    period = DateRange(period_since, period_until)

    journal_1 = Journal(
        date=datetime.date(2018, 3, 30),
        description="Test journal #1",
        postings=[
            Posting(Account(code="A1", name="Account #1", type=AccountType.ASSET), Amount(Decimal(100)), None),
            Posting(Account(code="A2", name="Account #2", type=AccountType.ASSET), Amount(Decimal(-100)), None),
        ],
    )

# Generated at 2022-06-12 06:00:14.391048
# Unit test for function build_general_ledger
def test_build_general_ledger():
    try:
        import pytest
    except ModuleNotFoundError:
        raise AssertionError('"pytest" library is not installed.')
    else:
        import py.test

        def _from_accnt(name: str) -> Account:
            return Account(name, name)

        def _to_accnt(name: str) -> Account:
            return Account(f"{name}.to", name)

        py.test.skip(reason="TODO: Finish unit test code!")
        # pytest.main()

# Generated at 2022-06-12 06:00:15.028837
# Unit test for function build_general_ledger
def test_build_general_ledger():
    pass

# Generated at 2022-06-12 06:00:26.071336
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from datetime import date
    import pytest
    from zeitgeist.algebras.accounting import build_account_struct
    from zeitgeist.algebras.journaling import build_journal_entry

    # Create a minimal general ledger program:
    tree = build_account_struct(["Assets", "Current Assets", "Bank Accounts", "Cash"], date(2020, 1, 1))
    read_initial_balances = lambda _: {}
    read_journal_entries = lambda _: map(
        lambda i: build_journal_entry(
            date(2020, 1, 1), "", "", "",
            [("C", "Assets:Current Assets:Bank Accounts", i), ("D", "Assets:Current Assets:Bank Accounts:Cash", i)]
        ), range(3)
    )
    program = compile_

# Generated at 2022-06-12 06:00:34.020019
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from ..ledgers import ReadInitialBalances
    from ..simulation import SimulatedReadInitialBalances
    from ..journaling import ReadJournalEntries, SimulatedReadJournalEntries
    from datetime import date

    ## Define initial balances:
    initial_balances_ = {"A1010": Balance(date(2020, 1, 1), Quantity("100")), "A2010": Balance(date(2020, 1, 1), Quantity("200"))}

    ## Create algebra implementation:
    sim_balances = SimulatedReadInitialBalances(date(2020, 1, 1), initial_balances_)

    ## Create a function which returns initial balances as of a given date:
    read_initial_balances_: ReadInitialBalances = SimulatedReadInitialBalances.compile(sim_balances)

    ## Define journal entries:
    sim_journal_ent

# Generated at 2022-06-12 06:00:40.520965
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date, datetime
    from decimal import Decimal
    from .accounts import Account, Accounts
    from .commons import Quantity, Amount
    from .journaling import JournalEntry, Posting, J
    from .zeitgeist import DateRange
    from .general import build_general_ledger
    from .context import build_context
    
    ## Test data
    ## Initial Balances
    accounts = Accounts()
    account_1 = accounts.get_account("1", "Cash")
    account_2 = accounts.get_account("2", "Accounts Receivable")
    account_3 = accounts.get_account("3", "Supplies")
    account_4 = accounts.get_account("4", "Accounts Payable")
    account_5 = accounts.get_account("5", "Common Stock")

# Generated at 2022-06-12 06:00:43.719562
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from ..commons.zeitgeist import DateRange

    def foo() -> Dict[Account, Balance]:
        return Dict[Account, Balance]()

    assert foo() == foo.__call__()


# Generated at 2022-06-12 06:00:50.450697
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import Posting as _Posting

    @dataclass
    class _JournalEntry(_Posting.JournalEntry):
        pass

    ## Initial balances:
    initial_balances: InitialBalances = {
        Account(code=301, name="Account 301"): Balance(date=datetime.date(2020, 1, 1), value=500.00),
        Account(code=321, name="Account 321"): Balance(date=datetime.date(2020, 1, 1), value=2.00),
    }

    ## Journal entries:

# Generated at 2022-06-12 06:01:01.880358
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    @dataclass
    class _ReadInitialBalances:
        period: DateRange
        return_value: InitialBalances
        call_count: int = 0

        def __call__(self, period: DateRange) -> InitialBalances:
            self.call_count += 1
            assert self.period == period
            return self.return_value

    test = _ReadInitialBalances(DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31)), {Account("1001"): Balance(datetime.date(2018, 1, 1), Quantity(Decimal("0.00")))})
    assert test.call_count == 0
    test.__call__(DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31)))

# Generated at 2022-06-12 06:01:13.888239
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    import datetime
    from decimal import Decimal
    from ..commons.numbers import Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, TerminalAccount
    from .generic import Balance
    today = datetime.date.today()
    since = datetime.date(today.year, 1, 1)
    until = datetime.date(today.year, 12, 31)
    period = DateRange(since, until)
    account = TerminalAccount("1000", "Account 1000")
    initial_balances = {account: Balance(period.since, Quantity(Decimal(0)))}
    read_initial_balances = lambda period: initial_balances
    assert read_initial_balances(period) == initial_balances

# Generated at 2022-06-12 06:01:21.661712
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-12 06:01:33.796360
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from .journaling import Journal, Posting

    from . import ledger_fixtures

    journ = Journal(date(2019, 1, 1), "Jour")
    journ.add(Posting(ledger_fixtures.cash_account, Amount(1000)))
    journ.add(Posting(ledger_fixtures.supplies_account, Amount(300)))

    gen_ledger = build_general_ledger(DateRange(date(2019, 1, 1), date(2019, 1, 1)), [journ], InitialBalances())

    assert gen_ledger.period.since == DateRange(date(2019, 1, 1), date(2019, 1, 1)).since
    assert gen_ledger.period.until == DateRange(date(2019, 1, 1), date(2019, 1, 1)).until

# Generated at 2022-06-12 06:01:42.048100
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import ReadJournalEntries as ReadJournalEntries_
    from .journaling import read_journal_entries as read_journal_entries_
    from .accounts import ReadInitialBalances as ReadInitialBalances_
    from .accounts import read_initial_balances as read_initial_balances_
    from ..commons.zeitgeist import days_range
    program = compile_general_ledger_program(read_initial_balances_, read_journal_entries_)
    period = days_range(datetime.date(2019, 1, 1), datetime.date(2019, 1, 10))
    assert isinstance(program, GeneralLedgerProgram[str])
    assert isinstance(program(period), GeneralLedger[str])


# Generated at 2022-06-12 06:01:50.229152
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..journaling import Posting, build_journal_entry
    from ..cashflows import build_transaction
    from ..payables.algebras import build_invoice_journal_entry
    from .ledger_accounts import Account
    from .accounts import AccountGroup
    from .ledger_accounts import LedgerAccount
    from .accounts import TransactionAccount
    from .accounts import Balance
    import datetime
    def test_build_general_ledger():
        ## Create the accounting period:
        period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 31))

        ## Build up the journal:

# Generated at 2022-06-12 06:01:57.969583
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..books.journaling import JournalEntry, Posting
    from ..commons.zeitgeist import DateRange


# Generated at 2022-06-12 06:02:08.250452
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import Account
    from .mocks.algebras import mock_read_initial_balances, mock_read_journal_entries
    from .mocks.domain import mock_journal_entry
    from .mocks.domain.accounts import mock_account_factory

    ## Get the compiled program:
    program = compile_general_ledger_program(mock_read_initial_balances, mock_read_journal_entries)

    ## Create mock opening and closing dates:
    opening_date = datetime.datetime.now()
    closing_date = opening_date + datetime.timedelta(days=1)

    ## Create mock period:
    period = DateRange(opening_date, closing_date)

    ## Supply a mock journal entry and expected ledger entries of the mock general ledger:

# Generated at 2022-06-12 06:02:19.466992
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    This test ensures correct compilation of algebras which allow programs to read initial balances and journal entries,
    which are then used to build a general ledger.
    """
    ## Get the compiled program.
    program = compile_general_ledger_program(
        read_initial_balances=lambda _: {"1000": Balance(datetime.date(y=2020, m=4, d=30), Quantity(Decimal(0)))},
        read_journal_entries=lambda _: [],
    )

    ## Get and validate the general ledger.
    ledger = program(DateRange(datetime.date(y=2020, m=5, d=1), datetime.date(y=2020, m=5, d=31)))

# Generated at 2022-06-12 06:02:25.861724
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import find_previous_period_end
    from ..domain.simple import get_accounts_manager, get_journals_manager, get_account_types_manager
    from ..domain.sql import create_sqlite_database

    ## Generate test data:
    db = create_sqlite_database(":memory:")
    get_account_types_manager(db).init_data()
    get_accounts_manager(db).init_data()
    get_journals_manager(db).init_data()
    types = get_account_types_manager(db)
    accounts = get_accounts_manager(db)
    journals = get_journals_manager(db)

    # Extract a period range of interest:
    since = datetime.date(2019, 1, 1)

# Generated at 2022-06-12 06:02:35.297209
# Unit test for function build_general_ledger
def test_build_general_ledger():
    """
    Test function build_general_ledger.
    """
    from decimal import Decimal
    from datetime import date
    from ..accounts import Account
    from ..journaling import Journal, Posting, PostingDirection
    from ..commons.numbers import Amount, Quantity, Balance

    #: The test period.
    period = DateRange(date(2020, 7, 1), date(2020, 7, 31))  # July 2020

    #: Some accounts.

# Generated at 2022-06-12 06:02:36.635110
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass



# Generated at 2022-06-12 06:02:55.127215
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import create_journal, create_posting, Direction

    from .accounts.hierarchy import AccountHierarchy

    from .accounts import A, B, C, D

    journal = [
        create_journal("1", datetime.date(year=2020, month=1, day=1)),
        create_journal("2", datetime.date(year=2020, month=2, day=1)),
        create_journal("3", datetime.date(year=2020, month=3, day=1)),
    ]

    journal[0].add(create_posting(journal[0], A, Decimal("1"), Direction.Debit))
    journal[0].add(create_posting(journal[0], B, Decimal("1"), Direction.Credit))


# Generated at 2022-06-12 06:03:06.769605
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    import accounts
    import journaling
    import sqlalchemy
    from datetime import date
    from .journaling import Posting
    from .accounts import Account, AccountCategory
    
    ## Initialize DB connection:
    connstr = "sqlite:///:memory:"
    engine = sqlalchemy.create_engine(connstr)
    connection = engine.connect()
    metadata = sqlalchemy.MetaData()
    
    ## Create DB tables and insert some data:
    accounts.create_tables(connection, metadata)
    journaling.create_tables(connection, metadata)

# Generated at 2022-06-12 06:03:07.500900
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__(): ...


# Generated at 2022-06-12 06:03:08.429366
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # TODO: Implement unit test
    assert True is True

# Generated at 2022-06-12 06:03:17.737952
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    ### Substantive test.
    
    # Import test dataset:
    import journaling

    # Capture into local variables:
    read_initial_balances = journaling.journal_initial_balances
    read_journal_entries = journaling.journal_reader

    # Compile program:
    general_ledger_program = compile_general_ledger_program(read_initial_balances, read_journal_entries)

    # Get the general ledger:
    period = DateRange("2019-01-01", "2019-12-31")
    general_ledger = general_ledger_program(period)

    # Check a few things, e.g.:
    assert general_ledger.period == period
    assert general_ledger.ledgers[Account("PLANT & EQUIPMENT")].initial.value == Decimal("0")


# Generated at 2022-06-12 06:03:19.157576
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass
    # TODO: implement Unit Test



# Generated at 2022-06-12 06:03:19.740617
# Unit test for function build_general_ledger
def test_build_general_ledger():
    pass

# Generated at 2022-06-12 06:03:30.844385
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():

    from .accounts import read_accounts
    from .accounts import read_balance
    from .journaling import create_journal_entry
    from .journaling import post_journal_entry
    from .journaling import read_journal_entry
    from .journaling import read_journal_entries
    from .journaling import test_journal_entries

    # Declare the period.
    period = DateRange(datetime.date(2020, 4, 1), datetime.date(2020, 4, 30))

    # Build the algebra implementations.
    read_accounts = read_accounts(read_balance)
    create_journal_entry = create_journal_entry(read_accounts)
    post_journal_entry = post_journal_entry(read_accounts)

# Generated at 2022-06-12 06:03:40.938886
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import JournalEntry, Posting, Transaction, build_journal_entry
    from .accounts import Account
    from .generic import Balance, Quantity
    from . import saldos

    # Initialization:
    period = DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31))
    saldos.first_day = period.since
    saldos.journal_entries = []
    initial_balances = {
        Account("1110", "Caja"),
        Account("1210", "Cuenta bancaria"),
        Account("1310", "Cuenta corriente cliente A"),
        Account("1410", "Cuenta corriente cliente B"),
        Account("2110", "Mercadería"),
    }

# Generated at 2022-06-12 06:03:51.242933
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from .accounts import Accounts
    from .irrecoverable import ReadInitialBalances as Irrecoverable
    from .premiums import ReadInitialBalances as Premiums
    from .reserves import ReadInitialBalances as Reserves
    from .scope import ReadInitialBalances as Scope
    from .technical import ReadInitialBalances as Technical
    from datetime import date
    from random import uniform
    from ..commons.numbers import Amount

    def stochastic_initial_balances() -> InitialBalances:
        """
        Generates initial balances with random values.
        """

# Generated at 2022-06-12 06:04:04.282989
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass

# Generated at 2022-06-12 06:04:04.911426
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    ...

# Generated at 2022-06-12 06:04:14.144183
# Unit test for method __call__ of class GeneralLedgerProgram

# Generated at 2022-06-12 06:04:24.960190
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from accounting.commons.datetime import date_range
    from accounting.commons.numbers import Quantity
    from accounting.accounting.accounts import Account, AccountType
    from accounting.accounting.journaling import Journal, PostingDirection
    from accounting.accounting.journaling import JournalEntry, Posting
    from accounting.accounting.initial import OpeningBalances

    ## Initialize opening balances:
    initial_balances = OpeningBalances(
        Account(AccountType.Assets, "0001", "Bank of America"),
        Quantity(Decimal(100)),
        date(2020, 1, 1),
    )

    period = date_range(date(2020,2,1), date(2020,2,29))

    ## Create journal entries:

# Generated at 2022-06-12 06:04:36.206498
# Unit test for function build_general_ledger
def test_build_general_ledger():
    ## Import required modules and functions:
    from ..commons.transactions import (
        CreditAccount,
        DebitAccount,
        JournalEntryBuilder,
        Posting,
        ReadJournalEntries,
        ReadInitialBalances,
        compile_journal_entry_program,
    )
    from ..commons.zeitgeist import Period

    ## Structure of accounts:
    assets = Account("Assets", "", "")
    current = assets / "Current"
    inventories = current / "Inventories"
    accounts_receivable = current / "Accounts receivable"
    liabilities = Account("Liabilities", "", "")
    current = liabilities / "Current"
    borrowing = current / "Borrowings"

    ## Prepare initial balances buffer:

# Generated at 2022-06-12 06:04:44.025759
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account, AccountType
    from .journaling import Journal, Posting

    acc_type = AccountType('Test type', 'Test comment')
    acc = Account('Test account', 'Test account', acc_type)
    journal = Journal('Test journal entry', 'Test comment')
    posting = Posting(acc, journal, Decimal(100), False, 'Test posting')

    assert posting.amount == Decimal(100)

    ledger = Ledger(acc, Balance(datetime.date(2019, 3, 30), Decimal(0)))

    assert ledger.add(posting) == LedgerEntry(ledger, posting, Decimal(100))

# Generated at 2022-06-12 06:04:46.962565
# Unit test for method add of class Ledger
def test_Ledger_add():
    account = Account('111111')
    initial = Balance(Decimal(100))
    ledger = Ledger(account, initial)
    posting = Posting(Decimal(100))
    entry = ledger.add(posting)
    assert entry.balance == Decimal(200)

# Generated at 2022-06-12 06:04:51.916598
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from decimal import Decimal
    from datetime import date
    from ..accounting.accounts import Account
    from ..accounting.ledgers import AccountLedger
    from ..accounting.journaling import JournalEntry, Posting, Amount, Quantity, Balance
    from ..accounting.books import ReadJournalEntries

    ## Define a test journal.

# Generated at 2022-06-12 06:04:58.682914
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    ## Mock for the read_initial_balances algebra.
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        pass

    ## Mock for the read_journal_entries algebra.
    def _read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        pass

    ## Compile the program.
    program = compile_general_ledger_program(_read_initial_balances, _read_journal_entries)

    ## Done.
    pass

# Generated at 2022-06-12 06:05:07.104401
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from unittest.mock import MagicMock

    read_initial_balances = MagicMock()
    read_journal_entries = MagicMock()
    actual = compile_general_ledger_program(read_initial_balances, read_journal_entries)
    assert callable(actual)
    period = DateRange(datetime.date(2018, 6, 1), datetime.date(2018, 7, 31))
    actual(period)
    read_initial_balances.assert_called_once_with(period)
    read_journal_entries.assert_called_once_with(period)

# Generated at 2022-06-12 06:06:13.259173
# Unit test for function build_general_ledger
def test_build_general_ledger():
    """
    Unit test for function build_general_ledger.
    """
    from datetime import date
    from decimal import Decimal
    import pytest
    from .accounts import Account, Asset, Current, Equity, Liability, OpeningDebit, Permanent
    from .journaling import JournalEntry, Posting
    from .units import Common, Currency

    ## Test data:
    period = DateRange(date(2018, 1, 1), date(2018, 1, 31))

# Generated at 2022-06-12 06:06:15.804483
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert callable(ReadInitialBalances.__call__)
    assert isinstance(ReadInitialBalances.__call__(ReadInitialBalances()), InitialBalances)


# Generated at 2022-06-12 06:06:24.913091
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Tests the function :py:func:`compile_general_ledger_program`.
    """
    ## Import dependencies:
    import datetime
    from typing import List

    ## Import members to test:
    from .accounts import Account
    from .general import Balance
    from .journaling import JournalEntry
    from .postings import Posting

    ## Create dummy functions for testing purposes:
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {}

    def _read_journal_entries(period: DateRange) -> List[JournalEntry[_T]]:
        return []

    ## Compile the program.
    program = compile_general_ledger_program(_read_initial_balances, _read_journal_entries)

    ## Test the program:
    general_ledger = program

# Generated at 2022-06-12 06:06:27.971626
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert ReadInitialBalances.__call__(None, None) is not None


# Generated at 2022-06-12 06:06:37.221725
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.azdatetime import LocalDate

    ## Initialize date and date range:
    date = LocalDate("1.1.2020")
    period = DateRange(date.move(-1, "year"), date)

    ## Initialize account balances:
    balances = {i: Balance(period.since, Quantity(i)) for i in range(1, 10)}

    ## Create a journal and a posting:
    from .journaling import Journal, JournalEntry, Posting
    from .accounts import Account

    journal = Journal(
        description="Test",
        postings={
            Posting(Account("100"), period.since, Quantity(100)),
            Posting(Account("200"), period.since, Quantity(-100)),
        },
    )

    ## Generate journal entries:

# Generated at 2022-06-12 06:06:47.322659
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # pylint: disable=redefined-outer-name, protected-access
    """
    Unit test for method __call__ of class GeneralLedgerProgram.
    """

    ## Mock account 1:
    account1 = Account("X", "X")

    ## Mock account 2:
    account2 = Account("Y", "Y")

    ## Mock balances:
    balances = {account1: Balance(datetime.date(2000, 1, 1), Quantity(Decimal("100.55")))}

    ## Mock journal entries:

# Generated at 2022-06-12 06:06:58.791816
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry, Posting, build_journal_entry
    from .books import Book, build_book
    from .records import Record
    from .accounts import Account, AccountType, AccountScheme

    ## Create an account scheme, and books:
    account_scheme = AccountScheme([Account(a, AccountType.asset) for a in ["a", "b", "c"]], [])
    book_a = build_book(account_scheme)
    book_b = build_book(account_scheme)

    ## Create a journal entry:

# Generated at 2022-06-12 06:07:05.549431
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
 
    ## Define a fake accounting period:
    period = DateRange(datetime.date(2020,1,1),datetime.date(2020,1,30))

    ## Define fake initial balances:
    initial_balances = {
        Account(1): Balance(period.since,Quantity(Decimal(20))),
        Account(2): Balance(period.since,Quantity(Decimal(10)))
    }

    ## Define fake journal entries:

# Generated at 2022-06-12 06:07:12.856185
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # Test that the program can consume opening and closing dates and produce a general ledger
    from .accounts import AccountType
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgering import Ledger
    from .utils import accounts, journaling
    import datetime
    import decimal
    import unittest

    # Define a GeneralLedgerProgram which can be used in the test
    expected_initial_balances: InitialBalances = {
        Account(accounts.i_000010): Balance(datetime.date(2019, 1, 1), decimal.Decimal(100.0)),
        Account(accounts.i_000020): Balance(datetime.date(2019, 1, 1), decimal.Decimal(200.0)),
    }

# Generated at 2022-06-12 06:07:20.107817
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    @dataclass
    class _ReadInitialBalancesImpl(ReadInitialBalances):
        def __call__(self, period):
            return {Account("400000"): Balance(period.since, Amount(400))}

    # Set up
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))
    impl = _ReadInitialBalancesImpl()

    # Exercise
    initial_balances = impl(period)

    # Verify
    assert initial_balances == {Account("400000"): Balance(period.since, Amount(400))}


# Generated at 2022-06-12 06:08:33.727405
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .journaling import compile_journal_program
    from .balancing import compile_balance_sheet_program
    from .accounts import compile_chart_of_accounts_program
    from .coa import Indent, Leaf, Node

    coa = compile_chart_of_accounts_program(build_coa=lambda *_, __: Node([
        Node([
            Leaf("101001", "Cash in Bank (USD)"),
            Leaf("101005", "Cash in Hand (USD)"),
        ], "Cash (USD)"),
        Node([
            Leaf("103001", "Short Term Receivable"),
            Leaf("103002", "Long Term Receivable"),
        ], "Accounts Receivable"),
    ], ""))


# Generated at 2022-06-12 06:08:45.312758
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # Fixture for the testing ReadInitialBalances algebra implementation:
    @dataclass
    class _ReadInitialBalances:
        def __call__(self, period: DateRange) -> InitialBalances:
            return {Account.term("Assets", "Cash"): Balance(period.since, Quantity(Decimal(1000)))}

    # Fixture for the testing ReadJournalEntries algebra implementation:

# Generated at 2022-06-12 06:08:46.177470
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-12 06:08:52.548893
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # Test data
    @dataclass
    class _InitBalances:
        def __call__(self, prd: DateRange) -> InitialBalances:
            res = InitialBalances()
            res[Account(account_no="3101", name="CASH")] = Balance(prd.since, Quantity(Decimal(1000)))
            return res


# Generated at 2022-06-12 06:09:02.822165
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import today
    from .accounts import Account
    from .journaling import JournalEntry, Posting

    ## Create an account and a ledger for it:
    a1 = Account("Assets", "Cash")
    l1 = Ledger(a1, Balance(today(), Quantity(Decimal(1250))))

    ## Create a journal entry:
    j1 = JournalEntry()
    j1.date = today()
    j1.description = "Paid salary"
    j1.add(Posting(a1, -Quantity(Decimal(1000))))

    ## Add the journal entry to the ledger:
    l1.add(j1)
    assert str(l1.entries[0].posting.amount) == '-1000'

# Generated at 2022-06-12 06:09:12.617943
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests __call__ method of a class GeneralLedgerProgram implemented by compile_general_ledger_program.
    """
    import datetime
    from decimal import Decimal
    from typing import Dict
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .commons.numbers import Quantity, Amount
    from .generic import Balance
    import unittest
    from unittest.mock import Mock

    # Preparing test data:
    class TestAccount(Account):
        pass

    class TestTransaction(JournalEntry):
        pass

    class TestPosting(Posting):
        pass


# Generated at 2022-06-12 06:09:15.295167
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    @dataclass
    class _Fake(_ReadInitialBalances):
        balance: int

    fake = _Fake(balance=12)

    return fake(12) == 12

# Generated at 2022-06-12 06:09:16.348010
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-12 06:09:25.872041
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    ## Test setup
    #: Test data.
    read_initial_balances = _ReadInitialBalances()
    read_journal_entries = _ReadJournalEntries()
    period = DateRange(datetime.date(1999, 1, 1), datetime.date(1999, 12, 31))
    general_ledger_program = GeneralLedgerProgram(read_initial_balances, read_journal_entries)

# Generated at 2022-06-12 06:09:32.913376
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..journaling.generic import JournalEntries, Postings
    from .accounts import Account, Accounts
    from .commons import Balance
