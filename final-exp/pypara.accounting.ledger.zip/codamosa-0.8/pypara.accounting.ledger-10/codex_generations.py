

# Generated at 2022-06-12 06:00:14.149006
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from .accounts import AccountScheme, AccountType


# Generated at 2022-06-12 06:00:22.790500
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from typing import Callable
    from .accounts import Account, AccountType

    from .journaling import JournalEntry, Posting, PostingDirection

    from .commons.test import AlgebraTest, assert_algebra_returns

    # noinspection PyUnresolvedReferences
    from .commons.monads import Do

    from .journaling import compile_journal_entry_algebra

    # noinspection PyUnusedLocal
    read_initial_balances: Callable[[DateRange], InitialBalances] = Do(
        lambda period: {
            Account("1010", AccountType.TERMINAL): Balance(period.since.date(), Quantity(Decimal(0)))
        }
    )

    # noinspection PyUnusedLocal

# Generated at 2022-06-12 06:00:32.241882
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .journaling import build_journal_entry
    from .posting import Posting, PostingDirection
    from .transactions import build_transaction
    from .accounts import build_account

    @dataclass
    class LedgerEntry:
        account: Account
        direction: PostingDirection
        balance: Balance

    @dataclass
    class JournalEntry:
        date: datetime.date
        postingDirection: PostingDirection
        description: str
        account: Account
        amount: Amount

    @dataclass
    class JournalEntryRequest:
        period: DateRange

    @dataclass
    class InitialBalanceRequest:
        period: DateRange

    @dataclass
    class InitialBalance:
        account: Account
        balance: Balance

    @dataclass
    class InitialBalanceResponse:
        initialBal

# Generated at 2022-06-12 06:00:38.857045
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    import pytest
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    Period = DateRange('2018-01-01', '2018-12-31')
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            'AA': Balance(period.since, 0),
            'BB': Balance(period.since, 0),
        }
    assert {
        'AA': Balance(Period.since, 0),
        'BB': Balance(Period.since, 0),
    } == _read_initial_balances(Period)


# Generated at 2022-06-12 06:00:46.057697
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    import datetime

    from ..commons.numbers import Amount
    from ..commons.zeitgeist import Year
    from .accounts import Account

    dut: ReadInitialBalances = lambda period: {
        Account.ASSETS: Amount(3000),
        Account.LIABILITIES: Amount(3000),
    }

    assert dut(Year(datetime.date(2019, 1, 1))) == {
        Account.ASSETS: Amount(3000),
        Account.LIABILITIES: Amount(3000),
    }


# Generated at 2022-06-12 06:00:49.628978
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    #Case 1
    #Input
    period = DateRange(datetime.date(2017, 2, 1), datetime.date(2017, 2, 28))
    #expected
    expected = {1: Balance(datetime.date(2017, 2, 1), Decimal("1000.00"))}
    #actual
    actual = ReadInitialBalances().__call__(period)
    #compare
    assert actual == expected


# Generated at 2022-06-12 06:01:01.430523
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import TimePeriod
    from ..journaling.journaling import Journal, JournalEntry, Posting

    time_period = TimePeriod(since=datetime.date(2017, 1, 1), until=datetime.date(2017, 6, 30))

    a1 = Account("1", "Cash", True)
    a2 = Account("2", "Bonds", True)
    a3 = Account("3", "Stocks", True)
    a4 = Account("4", "Cash at bank", True)

    def _as_posting(account: Account, direction: int, amount: int) -> Posting:
        return Posting(JournalEntry(datetime.datetime.now(), Journal("foo", "bar"), []), account, direction, amount)


# Generated at 2022-06-12 06:01:13.854060
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from datetime import date

    from . import Accounts, Journals

    from .accounts import Account
    from .journaling import JournalEntry, Posting

    ## Define accounts:
    net_income = Account("Net Income")

    ## Define journal entries:
    j_net_income_2020_01_01 = JournalEntry(
        "Net Income",
        date(year=2020, month=1, day=1),
        [Posting(Journals.net_income, net_income, Quantity(1))],
    )
    j_net_income_2020_02_15 = JournalEntry(
        "Net Income",
        date(year=2020, month=2, day=15),
        [Posting(Journals.net_income, net_income, Quantity(2))],
    )

    ## Define initial balances:
    initial

# Generated at 2022-06-12 06:01:14.795205
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass  # TODO.



# Generated at 2022-06-12 06:01:23.105695
# Unit test for function build_general_ledger
def test_build_general_ledger():
    """
    Tests the function :py:func:`build_general_ledger`.
    """
    from ..monads.functions import as_value
    from .journaling import build_journal_entry
    from .accounts import parse_account

    ## Define period:
    period = DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 1, 2))

    ## Get initial balances as of the end of previous financial period:
    initial_balances = {parse_account("40101"): Balance(period.since, Quantity(Decimal(100000)))}

    ## Create journal entries:

# Generated at 2022-06-12 06:01:28.358557
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    ...


# Generated at 2022-06-12 06:01:38.865556
# Unit test for method add of class Ledger
def test_Ledger_add():
    ## Create a Ledger
    ledger = Ledger(Account('1001'), Balance(datetime.date(2020,1,1), Quantity(Decimal(42))))

    ## Add a test entry
    posting = Posting(datetime.date(2020,1,1), Amount(Decimal(20)), 1, Account('1002'), 'test')
    entry = ledger.add(posting)

    ## Check if the entry was added correctly
    assert entry.ledger == ledger
    assert entry.posting == posting
    assert entry.date == posting.date
    assert entry.description == posting.journal.description
    assert entry.amount == posting.amount
    assert entry.balance == Quantity(Decimal(62))
    assert ledger.entries[0].ledger == ledger
    assert ledger.entries[0].posting == posting
    assert ledger.entries

# Generated at 2022-06-12 06:01:48.088207
# Unit test for method add of class Ledger
def test_Ledger_add():
    print("Start test_Ledger_add...")
    # Read the journal entries for a specific period
    from dataclasses import dataclass
    from decimal import Decimal
    from datetime import date
    from db.journal import JournalEntry, Posting
    from db.accounts import Account
    from db.commons import Amount
    from db.commons.zeitgeist import DateRange
    JournalEntry = JournalEntry[dataclass]
    Posting = Posting[dataclass]
    Account = Account[dataclass]
    Amount = Amount[dataclass]
    DateRange = DateRange[date]
    period = DateRange(date(2018, 1, 1), date(2018, 12, 31))
    journal = []

# Generated at 2022-06-12 06:01:56.948359
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():

    #: Initial balances for terminal accounts as of the end of previous financial period.
    initial_balances = {
        Account(code="10", name="Bank Account", terminal=True): Balance(datetime.date(2019, 12, 31), Decimal(1000.00)),
        Account(code="15", name="Cash On Hand", terminal=True): Balance(datetime.date(2019, 12, 31), Decimal(500.00)),
    }

    #: Journal entries for the period of interest.

# Generated at 2022-06-12 06:01:58.189588
# Unit test for method __call__ of class GeneralLedgerProgram

# Generated at 2022-06-12 06:02:08.374637
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from dataclasses import asdict
    from decimal import Decimal
    from typing import Dict
    from .accounts import Account
    from .generic import Balance, Currency
    from .journaling import Posting, ReadJournalEntries

    ## Create mock for read_journal_entries.
    def read_journal_entries(date_range: DateRange):
        from .journaling import Journal
        from ..commons.zeitgeist import date_range_by_month
        from datetime import date

        ## Compile a program which reads journal entries
        ## as specified by build_general_ledger_test.

# Generated at 2022-06-12 06:02:19.470202
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .factories.accounts import SavingAccount, CheckingAccount
    from .factories.journals import JournalEntryFactory
    from .factories.postings import PostingFactory
    from .factories.zeitgeist import DateRangeFactory
    import pytest
    period = DateRangeFactory.period()
    saving_account = SavingAccount(name="Test saving account")
    checking_account = CheckingAccount(name="Test checking account")
    initial_balances = {
        saving_account: Balance(since=period.since, value=Decimal(100)),
        checking_account: Balance(since=period.since, value=Decimal(200)),
    }

# Generated at 2022-06-12 06:02:25.861161
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests method __call__ of class GeneralLedgerProgram.
    """
    from datetime import date
    from .generic import Direction, Posting

    ## Define an algebra implementation which reads initial balances:
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("A100"): Balance(date(2000, 1, 1), Amount(Decimal(30.00))),
            Account("A200"): Balance(date(2000, 1, 1), Amount(Decimal(20.00))),
            Account("A300"): Balance(date(2000, 1, 1), Amount(Decimal(10.00))),
        }

    ## Define an algebra implementation which reads journal entries:

# Generated at 2022-06-12 06:02:35.295817
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    import datetime
    from dataclasses import dataclass, field, astuple
    from decimal import Decimal
    from typing import Dict, Generic, Iterable, List, Optional, Protocol, TypeVar
    account = Account("Assets", "Cash")
    posting_journal = JournalEntry("170001", datetime.date(2020, 1, 1), "Withdrawal of petty cash")
    posting = Posting(posting_journal, account, Decimal("100"))
    test_initial_balance = Balance(datetime.date(2020, 1, 1), Decimal("100"))
    test_ledger = Ledger(account, test_initial_balance)
    entry = test_ledger.add(posting)

# Generated at 2022-06-12 06:02:42.084915
# Unit test for method add of class Ledger
def test_Ledger_add():
    acc = Account(1, "Account")
    bal = Balance(datetime.date(2020, 9, 1), Quantity(Decimal(0)))
    ledger = Ledger(acc, bal)
    journal = JournalEntry(datetime.date(2020, 9, 1), "Entry", [])
    posting = Posting(journal, acc, Quantity(Decimal(1)))
    res = ledger.add(posting)
    assert res.balance == Quantity(Decimal(1))


# Generated at 2022-06-12 06:02:59.209427
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from decimal import Decimal
    from datetime import date
    from ..commons.zeitgeist import DateRange
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account
    from .journaling import Journal, Posting, PostingDirection

    # Define date range:
    period = DateRange(date(2018, 1, 1), date(2018, 2, 28))

    # Define accounts:
    bank = Account(code='101', name='Bank', type='Assets')
    salary = Account(code='200', name='Salary', type='Income')
    cash = Account(code='101.001', name='Cash on Hand', type='Assets')

    # Define journal entries:

# Generated at 2022-06-12 06:03:08.726428
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import AccountType, AccountSubtype
    from .journals import Journal, Posting, Transaction

    # arrange
    t = Transaction('ABCD-1234', datetime.date(2018, 6, 30), 'TEST_TRANSACTION')
    t.add(Account(AccountType.ASSET, AccountSubtype.CASH, 'CASH'), 100.0)
    t.add(Account(AccountType.EXPENSE, AccountSubtype.INTEREST_EXPENSE, 'INTEREST_EXPENSE'), -100.0)

    j = Journal('Test Journal')
    j.post(t)

    ledger = Ledger(Account(AccountType.EXPENSE, AccountSubtype.INTEREST_EXPENSE, 'INTEREST_EXPENSE'), Balance(datetime.date(2017, 1, 1), Quantity(Decimal(0))))
    posting = Post

# Generated at 2022-06-12 06:03:09.645909
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-12 06:03:18.788067
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Create a checking account and a savings account
    checking = Account("Assets:Checking Account")
    savings = Account("Assets:Savings Account")

    # Create initial balances as of 31/12/2016
    initial_balances = {
        checking: Balance(datetime.date(2016, 12, 31), Quantity(Decimal(100))),
        savings: Balance(datetime.date(2016, 12, 31), Quantity(Decimal(100))),
    }

    # Create a ledger for the checking account
    checking_ledger = Ledger[Amount](checking, initial_balances[checking])

    # Create a debit posting
    debit_posting = Posting(checking, Decimal(50), datetime.date(2017, 1, 1))

    # Create a credit posting

# Generated at 2022-06-12 06:03:19.781021
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-12 06:03:30.882901
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from typing import Dict, List
    from ..commons.zeitgeist import DateRange
    from .accounts import Account

    # Assign
    x:DateRange = DateRange(date(2020, 10, 1), date(2020, 12, 31))

# Generated at 2022-06-12 06:03:40.938095
# Unit test for method add of class Ledger
def test_Ledger_add():
    journal = [JournalEntry(datetime.date(2020,1,1),"Primary","",[Posting(datetime.date(2020,1,1),Account(1001),Quantity(3),Direction.Debit)])]
    initial: InitialBalances = {}
    initial[Account(1001)] = Balance(datetime.date(2020,1,1), Quantity(0))
    period = DateRange(since=datetime.date(2020,1,1),until=datetime.date(2020,1,2))
    general_ledger = build_general_ledger(period, journal, initial)
    assert general_ledger.ledgers[Account(1001)].entries[0].balance.value == 3
    assert general_ledger.ledgers[Account(1001)].entries[0].posting.account.value == 1001
    assert general_

# Generated at 2022-06-12 06:03:51.248868
# Unit test for method add of class Ledger
def test_Ledger_add():
    
    from .accounts import Account, TerminalAccount

    # Create a dummy posting:
    posting = Posting(
        TerminalAccount("1000", "Cash"),
        TerminalAccount("2000", "Revenue"),
        datetime.date(2018, 12, 1),
        Quantity(Decimal(1000)),
        "test",
    )
    
    # Create a dummy ledger:
    ledger = Ledger(posting.account, Balance(datetime.date(2018, 1, 1), Quantity(Decimal(1000))))
    
    # Add the posting:
    entry = ledger.add(posting)
    
    # Assertions
    assert entry.date == datetime.date(2018, 12, 1)
    assert entry.description == "test"
    assert entry.amount == Quantity(Decimal(1000))
    assert entry.cntracct

# Generated at 2022-06-12 06:03:57.909388
# Unit test for method add of class Ledger
def test_Ledger_add():
    L = Ledger(Account('Cash'),Balance(datetime.date(2020,1,1),Quantity(Decimal(5))))
    assert len(L.entries) == 0
    L.add(Posting(Account('Cash'), datetime.date(2020, 1, 1), 'Foo', Quantity(Decimal(1))))
    assert len(L.entries) == 1

# Generated at 2022-06-12 06:04:04.831555
# Unit test for method add of class Ledger
def test_Ledger_add():
    import datetime
    from decimal import Decimal
    from typing import List
    from ..commons.numbers import Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType, Accounts
    from .journaling import Journal, Posting
    import ledger as mdl


# Generated at 2022-06-12 06:04:28.359026
# Unit test for function build_general_ledger
def test_build_general_ledger():
    # TODO: Replace with parameterized test - the file is too big now
    # Load data
    from os.path import dirname

    # Load journal entries:
    from ujson import load
    from ..commons.zeitgeist import DateRange
    from .journaling import JournalEntry
    from .accounts import Account, Category

    test_data_file = open(dirname(__file__) + "/test/test-journal-entries.json", "r")
    journal_entries = {JournalEntry.from_dict(e) for e in load(test_data_file)}
    test_data_file.close()

    # Load initial balances:
    test_data_file = open(dirname(__file__) + "/test/test-initial-balances.json", "r")

# Generated at 2022-06-12 06:04:39.428193
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..journaling.domain import Journal
    from ..journaling.algebras import JournalEntry, Posting, build_journal

    # Period
    period = DateRange(datetime.date(2000, 1, 1), datetime.date(2000, 12, 31))

    # Initial balances

# Generated at 2022-06-12 06:04:46.994839
# Unit test for method add of class Ledger
def test_Ledger_add():
    a = Account(name='a', subledger='a', terminal=True)
    j = JournalEntry(description='j', date=datetime.datetime(2020, 1, 1), period='2020-01-01')
    p1 = Posting(account=a, direction='Dr', amount=100, journal=j)
    p2 = Posting(account=a, direction='Cr', amount=50, journal=j)
    L = Ledger(a, Balance(datetime.datetime(2020, 1, 1), 100))
    L.add(p1)
    L.add(p2)
    assert L.entries[0].balance == 200
    assert L.entries[1].balance == 150


# Generated at 2022-06-12 06:04:53.823022
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.date_ranges import DateRanges

    from ..journaling.entries import JournalEntry
    from ..journaling.postings import Posting

    from .accounts import Accounts
    from .accounts.types import AccountType
    from .categories import Categories
    from .categories.types import CategoryType

    ## Create accounts:
    account1 = Accounts.expense.cash
    account2 = Accounts(AccountType.asset, "Current Account", "CUR")

    account3 = Accounts(AccountType.asset, "Cash", "CSH")
    account4 = Accounts.expense.cash

    account5 = Accounts.expense.cash
    account6 = Accounts(AccountType.asset, "Bank", "BNK")

    account7 = Accounts(AccountType.asset, "Current Account", "CUR")
   

# Generated at 2022-06-12 06:05:05.051681
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..journaling.entries import JournalEntry, Posting
    from ..journaling.models import Journal
    from ..accounting.models import Account, AccountType, SubCode

    purchases = Account(AccountType.EXPENSE, "Purchases", SubCode.NONE)
    petty_cash = Account(AccountType.CURRENT_ASSET, "Petty cash account", SubCode.NONE)

    #: Create a couple of journal entries for test purposes:

# Generated at 2022-06-12 06:05:15.181797
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .accounts import Account, balance
    from .journaling import Direction, JournalEntry, Posting

    deb = Direction.debit
    cre = Direction.credit
    asof = datetime.date
    asof_range = DateRange
    initial_balances = {
        Account("11000"): balance(asof(2019, 1, 1), Quantity(Decimal(0))),
        Account("31000"): balance(asof(2019, 1, 1), Quantity(Decimal(0))),
        Account("50000"): balance(asof(2019, 1, 1), Quantity(Decimal(0))),
        Account("60000"): balance(asof(2019, 1, 1), Quantity(Decimal(0))),
    }

    def read_initial_balances(period: DateRange) -> InitialBalances:
        return initial

# Generated at 2022-06-12 06:05:23.604604
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import Journal, Posting
    from .journal import JournalEntry
    account = Account(adtype='D', no='100', name='Accounts Payable')
    account1 = Account(adtype='C', no='200', name='Accounts Receivable')
    journal = Journal(description='Credit sales')
    journal.post(Posting(account, 500.00, 'Invoice 1'))
    journal.post(Posting(account1, 500.00, 'Invoice 1'))
    journalEntry = JournalEntry(journal)
    ledger = Ledger(account, Balance(1.01, 0.00))
    assert(ledger.add(journalEntry.postings[0]).balance == Amount(500.00))

# Generated at 2022-06-12 06:05:35.215007
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .journaling import create_journal_entry, PostingDirection

    ## Create a booking for transfer of funds.
    journal = create_journal_entry(
        date=datetime.date(2015, 4, 15),
        description="Test transaction",
        debit=(Account(1001, "Cash and cash equivalents"), Amount(100)),
        credit=(Account(1002, "Receivables"), Amount(100)),
    )

    ## Create an account balance.
    initial_balance = Balance(datetime.date(2015, 1, 1), Quantity(100))

    ## Create the ledger.
    ledger = Ledger(Account(1001, "Cash and cash equivalents"), initial_balance)

    ## Post the transaction to the ledger:
    ledger.add(Posting(journal, PostingDirection.DEBIT, Amount(100), None))

    ## Assert the

# Generated at 2022-06-12 06:05:35.926345
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    ...

# Generated at 2022-06-12 06:05:44.234157
# Unit test for function build_general_ledger
def test_build_general_ledger():

    class _A:
        pass

    _ACCT1 = Account('Acc1')
    _ACCT2 = Account('Acc2')

    _INITIAL = {
        _ACCT1: Balance(datetime.date(2018, 4, 1), Quantity(1000)),
        _ACCT2: Balance(datetime.date(2018, 4, 1), Quantity(2000)),
    }

    ## Create journal entries:

# Generated at 2022-06-12 06:06:37.786980
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import date, period
    from .accounts import AccountType, AccountCode, Account
    from ..commons.numbers import Amount

    p = period(date(2020, 1, 1), date(2020, 12, 31))

# Generated at 2022-06-12 06:06:38.883931
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-12 06:06:48.343211
# Unit test for method add of class Ledger
def test_Ledger_add():
    
    from .accounts import AssetRole, LiabilityRole, IncomeType, ExpenseType, SubType
    from .accounts import (
    Accounts,
    AccountCodes,
    AssetAccounts,
    LiabilityAccounts,
    IncomeAccounts,
    ExpenseAccounts,
    )


# Generated at 2022-06-12 06:06:59.620737
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from contextlib import ExitStack
    from decimal import Decimal
    from unittest.mock import Mock
    from .accounts import Account, AccountType, AccountTypeCode
    from .commons import Direction
    from .coding import JournalEntryCode
    from .journaling import JournalEntry, Posting
    from .generic import Balance
    from ..commons.zeitgeist import DateRange

    ## Set up a mock journal entry.

# Generated at 2022-06-12 06:07:10.444429
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import Date
    from .journaling import Journal, Posting


# Generated at 2022-06-12 06:07:20.615368
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .config import default_test_accounting_period
    from .test.journaling import (
        test_journal_entries_lst,
        test_journal_entries_read,
        test_journal_entries_read_as_of_financial_period,
        test_initial_balances_lst,
        test_initial_balances_read,
    )

    _period = default_test_accounting_period()

    # Test with prebuilt lists
    assert compile_general_ledger_program(
        lambda period: test_initial_balances_lst(_period),
        lambda period: test_journal_entries_lst(_period),
    )(_period)

    # Test with algebra implementations

# Generated at 2022-06-12 06:07:22.395846
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # pylint: disable=missing-function-docstring,invalid-name
    pass


# Generated at 2022-06-12 06:07:23.686820
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    pass


# Generated at 2022-06-12 06:07:24.774144
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-12 06:07:33.812682
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .accounts import Account
    from .journaling import JournalEntry, Posting

# Generated at 2022-06-12 06:08:39.172259
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    class Target:
        def __call__(self, period: DateRange) -> InitialBalances:
            pass

    Target()


# Generated at 2022-06-12 06:08:48.981600
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    # ReadInitalBalances algebra implementation:
    def read_balances(period: DateRange) -> InitialBalances:
        return {Account("1000"): Balance(period.since, Quantity(10))}

    # ReadJournalEntries algebra implementation:
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry]:
        return []

    # Compile program:
    ledger_program = compile_general_ledger_program(read_balances, read_journal_entries)
    assert ledger_program != None

    # Run the program with given dates:

# Generated at 2022-06-12 06:09:00.966119
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    #: `Quantity` type variable.
    _T = Quantity

    ## Dummy implementation of `ReadInitialBalances`.

# Generated at 2022-06-12 06:09:11.722125
# Unit test for function build_general_ledger
def test_build_general_ledger():
    """
    Unit test for function build_general_ledger.
    """
    ## Set up initial balances:

# Generated at 2022-06-12 06:09:22.186226
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.testing import assert_raises, assert_equals, assert_is_instance, assert_is_not_none

    ##
    period = DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31))
    initial_balances = {
        Account("11"): Balance(period.since, Quantity(Decimal(5235))),
        Account("1121"): Balance(period.since, Quantity(Decimal(5235))),
        Account("1122"): Balance(period.since, Quantity(Decimal(5235))),
    }
    journal_entries = [JournalEntry("20180001", period.since, "Initial", [])]

# Generated at 2022-06-12 06:09:27.178070
# Unit test for method add of class Ledger
def test_Ledger_add():
    account = Account(1, "Caja", True)
    posting = Posting(1, 1, account, Decimal(1000), "A")
    ledger = Ledger(account, Balance(1, Decimal(0)))
    assert len(ledger.entries) == 0
    ledger.add(posting)
    assert len(ledger.entries) == 1


# Generated at 2022-06-12 06:09:30.142064
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from unittest.mock import Mock

    inst = Mock()
    result = inst()
    inst.assert_called_once_with()
    assert isinstance(result, Dict)

if __name__ == "__main__":
    test_ReadInitialBalances___call__()  # pragma: no cover

# Generated at 2022-06-12 06:09:41.267855
# Unit test for function build_general_ledger
def test_build_general_ledger():
    # test for building general ledger
    from account_parser.models.accounts import AccountPosting, TerminalAccount
    from account_parser.models.journaling import PostingDirection
    from account_parser.models.journaling import Posting

    account = TerminalAccount('1', 'account1')
    direction = PostingDirection.CREDIT
    amount = Amount(10)
    posting = Posting(account, direction, amount)
    journal = JournalEntry(datetime.date(2019, 1, 1), 'test1', [posting])

    initial = {account: Balance(datetime.date(2018, 12, 31), amount, amount)}
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 1, 2))

# Generated at 2022-06-12 06:09:48.249399
# Unit test for method add of class Ledger
def test_Ledger_add():
    account = Account("00/0000")
    initial = Balance(datetime.date(2019, 1, 1), Quantity(100))
    posting = Posting(account, Quantity(100), Direction.debit, datetime.date(2019, 1, 2))
    ledger = Ledger(account, initial)

    core_entry = ledger.add(posting)

    assert core_entry.date == datetime.date(2019, 1, 2)
    assert core_entry.debit == Quantity(100)
    assert core_entry.balance == Quantity(200)


# Generated at 2022-06-12 06:09:58.268485
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    @dataclass
    class ReadInitialBalancesEndPrevPeriod:
        """
        Read initial balances as of the end of the previous period.
        """

        initial_balances: InitialBalances

        def __call__(self, period: DateRange) -> InitialBalances:
            """
            Read initial balances as of the end of the previous period.

            :param period: Accounting period.
            :return: Initial balances.
            """
            return self.initial_balances

    @dataclass
    class ReadJournalEntriesInPeriod:
        """
        Read journal entries in the period.
        """

        journal_entries: List[JournalEntry[_T]]
