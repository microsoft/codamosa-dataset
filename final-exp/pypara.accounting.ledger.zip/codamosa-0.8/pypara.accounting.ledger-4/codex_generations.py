

# Generated at 2022-06-12 06:00:05.381648
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from ..commons.zeitgeist import now

    @dataclass
    class X(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {
                "Cash": Balance(period.since, Quantity(100)),
            }

    ## We need a test double for the read-journal-entries algebra.
    read_initial_balances = X()

    ## We need a test double for the read-journal-entries algebra.
    @dataclass
    class Y(ReadJournalEntries[str]):
        def __call__(self, period: DateRange) -> List[JournalEntry[str]]:
            return [
                JournalEntry[str](now(), "1", [Posting("Cash", True, 1)])
            ]
    read_journal_entries = Y()



# Generated at 2022-06-12 06:00:17.876963
# Unit test for function build_general_ledger
def test_build_general_ledger():
    """
    Test for function build_general_ledger
    """
    from .accounts import Account, AssetAccount, ExpenseAccount
    from .journaling import Posting, PostingDirection, Journal, JournalEntry
    from decimal import Decimal
    from datetime import date
    period = DateRange(date(2020, 1, 1), date(2020, 12, 31))
    p1 = Posting(AssetAccount('asset'), PostingDirection.CREDIT, Decimal(1))
    p2 = Posting(ExpenseAccount('expense'), PostingDirection.DEBIT, Decimal(1))
    journal = Journal(date(2020,1,1), "test journal", [p1, p2], "")
    journal_entry = JournalEntry([p1, p2], date(2020,1,1), "test entry", "")


# Generated at 2022-06-12 06:00:28.406568
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange

    # Provide a starting date.
    date = datetime.date(2018, 4, 1)
    # Provide a range of dates.
    period = DateRange(date - datetime.timedelta(days=30), date)
    # Provide an empty list as an initial set of ledger entries.
    entries: List[JournalEntry] = []
    # Provide a dictionary of initial balances.
    initial: Dict[Account, Balance] = dict()
    # Create a general ledger.
    ledger = build_general_ledger(period, entries, initial)
    # Check the ledger is of the correct type.
    assert isinstance(ledger, GeneralLedger)
    # Check the ledger's period.
    assert isinstance(ledger.period, DateRange)
    # Check the ledger's period's dates

# Generated at 2022-06-12 06:00:32.946839
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    ## Mock implementation of ReadJournalEntries[T]
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        pass

    ## Mock implementation of ReadInitialBalances
    def read_initial_balances(_period) -> InitialBalances:
        pass

    ## Compile the program
    program = compile_general_ledger_program(read_initial_balances, read_journal_entries)

# Generated at 2022-06-12 06:00:38.606775
# Unit test for method add of class Ledger
def test_Ledger_add():
    account = Account(0, '', '', '', True, True)
    ledger = Ledger(account,Balance(datetime.date(2019, 1, 1), Quantity(1.0)))
    new_entry = Posting(datetime.date(2019, 2, 1), Quantity(1.0))
    ledger.add(new_entry)
    assert ledger.entries[0].date == datetime.date(2019, 2, 1)
    assert ledger.entries[0].amount == Quantity(1.0)


# Generated at 2022-06-12 06:00:48.206388
# Unit test for method add of class Ledger
def test_Ledger_add():

    from .accounts import Account
    from .entities import Customer
    from .journaling import Transaction, Posting, Journal
    from .commons.numbers import Amount, Quantity
    from .generic import Balance
    from .ledgers import Ledger, LedgerEntry

    cstmr = Customer("cstmr-001", "John Doe")
    acct1 = Account("01", cstmr, cstmr.name)
    acct2 = Account("02", cstmr, cstmr.name)
    acct3 = Account("03", cstmr, cstmr.name)

    trx1 = Transaction(cstmr, "trx-001")

    jrn1 = Journal(trx1, "jrn-001", "First journal")

# Generated at 2022-06-12 06:01:00.121759
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import TerminalAccount, is_terminal
    from .journaling import Money, Posting, Journal, PostJournalEntries
    from .generic import Balance
    from .ledgers import build_general_ledger
    from .models import JournalEntry, Posting
    from .commons.compile import compile_algebra

    ## Define test cases.
    TestCase = Dict[str, List[str]]


# Generated at 2022-06-12 06:01:05.484587
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    """
    Unit test method py:method:`ReadInitialBalances.__call__`.
    """
    # Create a mock:
    mock = MagicMock(spec_set=ReadInitialBalances)

    # Create a date range:
    date_range = DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31))

    # Execute __call__:
    mock(date_range)

    # Verify that mock has been called with the date range:
    mock.assert_called_once_with(date_range)



# Generated at 2022-06-12 06:01:15.900458
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import AccountNode

    ## Set up test data:
    # Initial balances of accounts:
    init_balances = {Account((1, )): Balance(datetime.date(2019, 1, 1), Quantity(Decimal(1))),
                     Account((1, 2)): Balance(datetime.date(2019, 1, 1), Quantity(Decimal(2)))}

    # Journal entries of accounts:

# Generated at 2022-06-12 06:01:26.440453
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from unittest import TestCase
    from unittest.mock import Mock
    from datetime import date
    from typing import Dict

    from ..commons.zeitgeist import DateRange

    from .accounts import Account
    from .generic import Balance
    from .journaling import Journal, Posting, JournalEntry

    # Set up the input:
    period = DateRange(date(2015, 1, 1), date(2015, 12, 31))

    # Set up the journal:

# Generated at 2022-06-12 06:01:49.387386
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..books.chart import get_terminal_accounts
    from ..books.chart import get_account_type
    from ..books.chart import AccountType
    from ..books.journal import Journal
    from ..books.journal import PostingSite
    from ..commons.daterange import DateRange
    from ..commons.zeitgeist import Date

    def prepare_trial_balance(accounts: List[Account], journal_entries: List[Journal]) -> InitialBalances:
        ledgers = build_general_ledger(DateRange(Date(2019, 1, 1), Date(2019, 12, 31)), journal_entries, {})
        return {acc: ledgers.ledgers[acc].initial for acc in accounts}

    # Cash
    cash = Account(number="120", name="Cash")
    # Accounts receivable
    account_re

# Generated at 2022-06-12 06:01:57.597171
# Unit test for method add of class Ledger
def test_Ledger_add():
    # First, we need a posting to add to the Ledger.
    # Import the library
    import sys
    sys.path.insert(0, '../journaling')
    from journaling import JournalEntry, Posting, Journal, Amount, Account
    # Make a JournalEntry(-10, '', [Posting(None, None)])
    p, a = Posting(None,None), Account("Acc1", None)
    j = Journal("Acc1", "", [p, p])
    je = JournalEntry(None, "", [j])
    # Make a Ledger and assert its balance (should be 0)
    l = Ledger(je.postings[0].account, Balance(None, 0))
    assert l.entries == []
    assert l.account.identifier == "Acc1"
    assert l.initial.value == 0

# Generated at 2022-06-12 06:02:06.909277
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    class TestReader(ReadInitialBalances):
        def __call__(self, period):
            return {"Account 1": Balance(datetime.date(2017, 1, 1), Quantity(Decimal(1000))), "Account 2": Balance(datetime.date(2017, 1, 1), Quantity(Decimal(2000)))}
    assert TestReader()(DateRange(datetime.date(2017, 1, 1), datetime.date(2017, 1, 2))) == {"Account 1": Balance(datetime.date(2017, 1, 1), Quantity(Decimal(1000))), "Account 2": Balance(datetime.date(2017, 1, 1), Quantity(Decimal(2000)))}


# Generated at 2022-06-12 06:02:18.690634
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # Arrange
    class ReadInitialBalances:  # noqa
        def __call__(self, period: DateRange) -> InitialBalances:
            return {Account(ident=1): Balance(date=datetime.date(2019, 7, 1), value=1000)}

    def journal_entries_as_of(period: DateRange) -> Iterable[JournalEntry[_T]]:
        return [
            JournalEntry(date=datetime.date(2019, 7, 1), description="", counterparty="", postings=[Posting(1, 100)]),
            JournalEntry(date=datetime.date(2019, 7, 2), description="", counterparty="", postings=[Posting(1, 200)]),
        ]


# Generated at 2022-06-12 06:02:19.320912
# Unit test for function build_general_ledger
def test_build_general_ledger():
    pass

# Generated at 2022-06-12 06:02:29.486562
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    import dataclasses
    import typing
    import pathlib
    import decimal
    import decimal
    from decimal import Decimal
    from pprint import pprint
    from pyleri import Choice, Grammar, List, Maybe, Sequence
    from pyleri import error, grammar, parsers, renderer, utility
    from pyleri.common import _Regex
    from pyleri.common import Error as _Error
    from pyleri.common import ParseError as _ParseError
    from pyleri.common import TraceLevel as _TraceLevel
    from pyleri.common import create_regex as _create_regex
    from pyleri.common import create_trace as _create_trace
    from pyleri.common import create_tracer as _create_tracer
    from pyleri.common import is_false as _

# Generated at 2022-06-12 06:02:37.514881
# Unit test for method add of class Ledger
def test_Ledger_add():
    l = Ledger(Account('2'), Balance(datetime.date(2019, 1, 1), Quantity(Decimal('20'))))
    post = Posting(
        JournalEntry('Dumm Posting', datetime.date(2019, 2, 1)),
        Account('2'),
        Amount(Decimal('10')),
        Direction.DEBIT
    )
    l.add(post)
    assert len(l.entries) == 1
    entry = l.entries[0]
    assert entry.balance == Quantity(Decimal('30'))
    assert entry.date == datetime.date(2019, 2, 1)
    assert entry.is_debit == True
    assert entry.is_credit == False
    assert entry.amount == Amount(Decimal('10'))

# Generated at 2022-06-12 06:02:46.656553
# Unit test for method add of class Ledger
def test_Ledger_add():
    # test data
    account = Account("Cash")
    initial = Balance("2019-12-31", Quantity(Decimal(0)))
    test_posting = Posting(account, "20200101", Amount(Decimal(1)), "Description", "Cash")

    # start test
    test_ledger = Ledger(account, initial)
    test_ledger.add(test_posting)

    # verify result
    assert test_ledger.account == account
    assert test_ledger.initial == initial
    assert test_ledger._last_balance == Quantity(Decimal(1))
    assert test_ledger.entries[0].posting == test_posting
    assert test_ledger.entries[0].balance == Quantity(Decimal(1))

# debugging

# Generated at 2022-06-12 06:02:58.509457
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .accounts import AccountType
    from .journaling import Journal, JournalEntry, Posting
    from datetime import date
    from decimal import Decimal
    from pytest import fixture
    import pandas as pd

    @fixture
    def def_period() -> DateRange:
        return DateRange(date(2019, 9, 1), date(2019, 9, 30))

    @fixture
    def def_initial() -> InitialBalances:
        return {
            Account(AccountType.ASSET, "1001"): Balance(date(2019, 9, 1), Quantity(Decimal("500.00"))),
            Account(AccountType.EXPENSE, "7000"): Balance(date(2019, 9, 1), Quantity(Decimal("0.00"))),
        }


# Generated at 2022-06-12 06:03:08.346023
# Unit test for function build_general_ledger
def test_build_general_ledger():
    import datetime as dt
    from decimal import Decimal as D

    from ..commons.numbers import Balance, Currency, Amount, Quantity, Money

    from .accounts import Account, Group
    from .journaling import Journal, PostingDirection

    # Unit test the function build_general_ledger
    def test_build_general_ledger(
        period: DateRange, journal: Iterable[JournalEntry[_T]], initial: InitialBalances
    ) -> GeneralLedger[_T]:
        ## Initialize ledgers buffer as per available initial balances:
        ledgers: Dict[Account, Ledger[_T]] = {a: Ledger(a, b) for a, b in initial.items()}

        ## Iterate over journal postings and populate ledgers:

# Generated at 2022-06-12 06:03:22.845376
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .journaling import Journal, Posting, PostingDirection
    from .units import Unit, UnitCategory

    category_vat = UnitCategory("VAT")
    unit_ex = Unit("Excl. VAT", category_vat)
    unit_in = Unit("Incl. VAT", category_vat)

    account = Account("1001", "Assets")
    ledger = Ledger(account, Balance(constant=Quantity(Decimal(0))))
    posting = Posting(
        PostingDirection.CREDIT,
        Account("1010", "Cash", unit_in),
        Quantity(Decimal(100), unit_in),
        Journal("Initial balance"),
    )
    ledger.add(posting)
    assert ledger.entries[0].balance == Quantity(Decimal(100))

# Generated at 2022-06-12 06:03:30.734001
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    kwargs = {
        "period": DateRange(since=datetime.date(2020, 1, 1), until=datetime.date(2020, 1, 3)),
        "initial": {
            Account("assets"): Balance(Decimal("0")),
            Account("liabilities"): Balance(Decimal("0")),
            Account("equity"): Balance(Decimal("0")),
        },
    }

    # Test "returns initial balances"
    assert ReadInitialBalances.__call__(**kwargs) == {
        Account("assets"): Balance(Decimal("0")),
        Account("liabilities"): Balance(Decimal("0")),
        Account("equity"): Balance(Decimal("0")),
    }



# Generated at 2022-06-12 06:03:38.370735
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():

    ## Create test cases.
    TestCase = Dict[str, Dict[str, DateRange]]

    testcases = {
        "01": {"period": DateRange(since=datetime.date(2019, 1, 1), until=datetime.date(2019, 1, 31))}
    }

    ## Iterate over test cases and run the tests.
    for tcid, tc in testcases.items():

        ## Extract test arguments from test case.
        period = tc["period"]

        ## Run test and ensure the general ledger is built.
        GeneralLedgerProgram()(period)

# Generated at 2022-06-12 06:03:47.653872
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    def read(period: DateRange) -> InitialBalances:
        return {}

    # Try to call the method on None:
    try:
        ReadInitialBalances.__call__(None, None)
        raise AssertionError("Should have failed")
    except TypeError:
        pass

    # Try to call the method without parameters:
    try:
        ReadInitialBalances.__call__(read)
        raise AssertionError("Should have failed")
    except TypeError:
        pass

    # Call the method with correct params:
    ReadInitialBalances.__call__(read, None)  # should be ok



# Generated at 2022-06-12 06:03:48.143578
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass

# Generated at 2022-06-12 06:03:49.768863
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    #     ___call__(self, period: DateRange) -> InitialBalances
    ...


# Generated at 2022-06-12 06:03:57.468518
# Unit test for method add of class Ledger
def test_Ledger_add():
    accnt = Account("test","All","test.all")
    deb_posting = Posting(datetime.date(2020, 1, 1), Quantity(10), accnt, "debit test")
    deb_posting.direction = -1
    led = Ledger(accnt, Balance(datetime.date(2019, 1, 1), Quantity(5)))
    le = led.add(deb_posting)
    assert le.balance == Quantity(5)


# Generated at 2022-06-12 06:04:04.640063
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .typing import JournalId, PostingId

    #Build test data
    account = Account("5001", "Expense - Rent")
    initial = Balance(datetime.date(2019, 12, 31), Quantity(Decimal(12)))
    posting = Posting(PostingId("00000000-0000-0000-0000-000000000001"), JournalEntry(JournalId("00000000-0000-0000-0000-000000000003"), datetime.date(2020, 1, 1), "Paid rent for the month"), account, 1, Amount(Decimal(1)))
    ledger = Ledger(account, initial)

    #Test method add
    entry = ledger.add(posting)
    assert entry.balance == Quantity(Decimal(13))

    #Test getter _last_balance

# Generated at 2022-06-12 06:04:12.085782
# Unit test for method add of class Ledger
def test_Ledger_add():
    ## Create Account
    account = Account("iban", "name", "type")
    ## Create Balance
    balance = Balance("since", "value")
    ## Create Posting
    posting = Posting("date", "amount", "account", "journal", "direction")
    ## Create Ledger
    ledger = Ledger(account, balance)
    ## Run Ledger_add
    ledger_add = ledger.add(posting)
    assert ledger_add == LedgerEntry(ledger, posting, Quantity(posting.amount * posting.direction.value))

# Generated at 2022-06-12 06:04:16.109612
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    @dataclass
    class ReadInitialBalancesImpl(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            pass

    assert callable(ReadInitialBalancesImpl.__call__)


# Generated at 2022-06-12 06:04:28.006096
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass


# Generated at 2022-06-12 06:04:39.130213
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, TerminalAccount
    from .journaling import JournalEntry, Posting
    from .numbers import Amount, Quantity
    from .zeitgeist import BusinessDate, DateRange
    from .interfaces import Algebra, ReadJournalEntries, ReadInitialBalances

    class StubInitialBalances(Algebra, ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {TerminalAccount("1000"): Balance(period.since, Quantity(Decimal("1000")))}


# Generated at 2022-06-12 06:04:47.541360
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import current_datetime, today
    from .accounts import Account

    print("==> Unit test for function build_general_ledger.")

    ## Create accounts:
    account_1 = Account(accountno="100", name="Account 1")
    account_2 = Account(accountno="200", name="Account 2")
    account_3 = Account(accountno="300", name="Account 3")
    account_4 = Account(accountno="400", name="Account 4")

    ## Create journal entries:

# Generated at 2022-06-12 06:04:54.160750
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    import functools
    import logging
    import sys
    from typing import Callable
    from dataclasses import dataclass

    import pytest
    from ..commons.numbers import Quantity
    from ..commons.zeitgeist import Date
    from ..journaling.accounts import Account, Asset, Liability
    from ..journaling.monetary import Currency
    from ..journaling.journaling import JournalEntry, Posting, Transaction, Direction, Credit, Debit, parse_journal_entry

    @dataclass
    class GLProgram(Generic[_T]):
        """
        Operator protocol model.
        """
        period: DateRange
        read_initial_balances: ReadInitialBalances
        read_journal_entries: ReadJournalEntries[_T]

    # Test logging
    logger = logging.getLogger(__name__)


# Generated at 2022-06-12 06:05:05.380841
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Test __call__ of class GeneralLedgerProgram
    """
    ## Mocking the read_initial_balances and read_journal_entries:
    init_balances = {"A": Balance(datetime.date(2020,1,1), Quantity(0)),"B": Balance(datetime.date(2020,1,1), Quantity(0)),"C": Balance(datetime.date(2020,1,1), Quantity(0))}
    read_initial_balances = lambda period: init_balances

# Generated at 2022-06-12 06:05:16.126661
# Unit test for function build_general_ledger
def test_build_general_ledger():
    # Initialize journal entries:
    from .accounts import Account, AccountType
    from .posting import Posting
    from .journaling import JournalEntry

    cash = Account(0, "Cash", AccountType.ASSET, None)
    revenue = Account(1, "Revenue", AccountType.REVENUE, None)

    # Initialize and append journal entries:
    je1 = JournalEntry(datetime.date(year=2018, month=1, day=1), "Cash Receipts")
    je1.append(Posting(cash, datetime.date(year=2018, month=1, day=1), 100, "Cash Receipts"))
    je1.append(Posting(revenue, datetime.date(year=2018, month=1, day=1), -100, "Cash Receipts"))
    je2 = Journal

# Generated at 2022-06-12 06:05:23.773846
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..books import journal_entries_period

    ## Initialize a simple journal:

# Generated at 2022-06-12 06:05:35.314649
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import CurrentPayables, CurrentReceivables
    from .journaling import WriteJournalEntry

    ## Period is from 1 to 30 June 2018.
    period = DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31))
    ## Define accounts:
    a1 = CurrentReceivables(id=1, name="A1")
    a2 = CurrentReceivables(id=2, name="A2")
    a3 = CurrentPayables(id=3, name="A3")

    ## Define initial balances:

# Generated at 2022-06-12 06:05:43.783519
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Compiles the general ledger program and verifies that the program works.

    :return: `None`
    """
    ## Temporary imports
    from ..ddd import IDomainService
    import typing

    ## Define dummy implementations.
    initial_balances = {
        Account(11910): Balance(datetime.date(2019, 12, 31), Quantity(1000)),
        Account(11960): Balance(datetime.date(2019, 12, 31), Quantity(2000)),
        Account(11940): Balance(datetime.date(2019, 12, 31), Quantity(3000)),
    }

    class DummyReadInitialBalances(IDomainService, Generic[typing.Any]):
        """
        Dummy implementation for initial balance reader.
        """


# Generated at 2022-06-12 06:05:50.596034
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests method __call__ of class GeneralLedgerProgram.
    """

    from .commons import ReferencePeriod
    from .journaling import JournalEntry
    from .scheduling import ScheduledJournalEntry


    ##
    ## ALGEBRA
    ##

    def _read_initial_balances(period: ReferencePeriod) -> InitialBalances:
        """
        Stub function which reads and returns initial balances.
        """
        return {}


    def _read_journal_entries(period: ReferencePeriod) -> Iterable[JournalEntry]:
        """
        Stub function which reads and returns journal entries.
        """
        return []



# Generated at 2022-06-12 06:06:36.581414
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Test for function compile_general_ledger_program
    """
    from .general_ledger_algebra import construct_read_initial_balances
    from .journaling_algebra import construct_read_journal_entries

    ## Input values:
    since = datetime.date(2020, 1, 1)
    until = datetime.date(2020, 12, 31)
    period = DateRange(since, until)

    ## Create the read initial balances algebra implementation:
    read_initial_balances = construct_read_initial_balances(None)

    ## Create the read journal entries algebra implementation:
    read_journal_entries = construct_read_journal_entries(None, None)

    ## Compile the program:

# Generated at 2022-06-12 06:06:37.646055
# Unit test for function build_general_ledger
def test_build_general_ledger():
    pass


# Generated at 2022-06-12 06:06:47.562963
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .journaling import JournalEntry, Journal, Posting, PostingDirection, PostingType
    from .accounts import Account, AccountType
    from .generic import Balance

    account_1 = Account("11.1", "Cash in hand", AccountType.ASSET)
    account_4 = Account("41.1", "Sales", AccountType.REVENUE)
    account_5 = Account("51.1", "Purchases", AccountType.EXPENSE)
    account_6 = Account("61.1", "Sales Returns", AccountType.EXPENSE)
    account_7 = Account("71.1", "Purchases Returns", AccountType.REVENUE)

    posting_1 = Posting(account_1, PostingDirection.DEBIT, PostingType.BASIC, Decimal(5.5))
    posting_4 = Posting

# Generated at 2022-06-12 06:06:58.933867
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    """
    Test case a simple implementation of `ReadInitialBalances` which reads initial balance from an
    array.
    """

    # Import needed modules:
    from datetime import date
    from decimal import Decimal
    from pytest import raises
    from dataclasses import dataclass
    from .accounts import Account, Balance
    from .generic import Quantity

    # Class used in this test case:
    @dataclass
    class Entry:
        account: Account
        value: Quantity

    # Define the array of initial balances:
    initial_balances = [Entry(Account("1150"), Quantity(Decimal(0))), Entry(Account("4240"), Quantity(Decimal(0)))]


# Generated at 2022-06-12 06:06:59.710433
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-12 06:07:07.354617
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    @dataclass
    class Impl(ReadInitialBalances):

        def __call__(self, period: DateRange) -> InitialBalances:
            return {
                Account("A-101"): Balance(period.since, Quantity(Decimal(100))),
                Account("A-201"): Balance(period.since, Quantity(Decimal(200))),
                Account("A-501"): Balance(period.since, Quantity(Decimal(300))),
            }

    assert Impl()(DateRange(until=datetime.date.today())) == ...


# Generated at 2022-06-12 06:07:07.807389
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass

# Generated at 2022-06-12 06:07:17.654361
# Unit test for method add of class Ledger
def test_Ledger_add():
    from bookkeeper.domain.general_ledger import Posting

    ## Arrange
    account = Account(number=123, name="Test")
    balance = Balance(date=datetime.date(2020, 1, 1), value=Quantity(Decimal(1000)))
    ledger = Ledger(account, balance)

    ## Act
    p1 = Posting(date=datetime.date(2020, 1, 2), account=account, amount=Amount(Decimal(100)), direction=1)
    ledger.add(p1)

    ## Assert
    assert len(ledger.entries) == 1
    assert ledger.entries[0].balance == Quantity(Decimal(1100))
    assert ledger.entries[0].posting.amount == Amount(Decimal(100))
    assert ledger.entries[0].posting.date == datetime

# Generated at 2022-06-12 06:07:23.799012
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry, Posting

    ## given:
    period = DateRange(since=datetime.date(2020, 1, 1), until=datetime.date(2020, 12, 31))
    read_initial_balances = lambda _: {Account("100"): Balance(datetime.date(2019, 12, 31), 1000)}

# Generated at 2022-06-12 06:07:32.161167
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    # Define a test algebra for reading initial balances
    def read_initial_balances(period: DateRange) -> Dict[Account, Balance]:
        pass

    # Define a test algebra for reading journal entries
    def read_journal_entries(period: DateRange) -> List[JournalEntry[_T]]:
        pass

    # Compile the program
    program = compile_general_ledger_program(read_initial_balances, read_journal_entries)

    # Unit test the program
    def test_program():
        period = DateRange(datetime.date.today(), datetime.date.today())
        program(period)

# Generated at 2022-06-12 06:08:47.608226
# Unit test for method add of class Ledger
def test_Ledger_add():
    test = 0
    if test == 1:
        a1 = Account(1, 'Test account', True)
        a2 = Account(2, 'Test account2', False)
        a3 = Account(3, 'Test account3', True)
        a4 = Account(4, 'Test account4', False)
        a5 = Account(5, 'Test account5', False)

        p1 = Posting(1, datetime.date(2021, 1, 1), a1, Quantity(Decimal(100)))
        p2 = Posting(1, datetime.date(2021, 1, 1), a2, Quantity(Decimal(10)))
        p3 = Posting(1, datetime.date(2021, 1, 1), a3, Quantity(Decimal(10)))

# Generated at 2022-06-12 06:08:49.135078
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Unit test for method __call__ of class GeneralLedgerProgram
    """
    pass

# Generated at 2022-06-12 06:09:01.114293
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests the method __call__ of class GeneralLedgerProgram.
    """
    from datetime import date
    from .ledgerlists import LedgerList
    class MockReadInitialBalances:
        def __call__(self, period: DateRange) -> InitialBalances:
            return {
                Account("101", "Cash and Cash Equivalents"): Balance(date(2020, 1, 1), Quantity(Decimal(0)))
            }

    class MockReadJournalEntries:
        def __call__(self, period: DateRange) -> LedgerList[_T]:
            return [
                JournalEntry(
                    date(2020, 2, 3), '"2202" "2020-02-03"', [Posting(Account("101", "Cash and Cash Equivalents"), Amount(Decimal(500)))]
                )
            ]

   

# Generated at 2022-06-12 06:09:11.777417
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from .journaling import Posting
    from .accounts import Account

    journal = [
        JournalEntry("Test", [Posting(Account("1010"), 100), Posting(Account("1040"), -100)], "2020-01-01"),
        JournalEntry("Test", [Posting(Account("1040"), 200), Posting(Account("1020"), -200)], "2020-01-02"),
    ]

    initial_balances = {Account("1020"): Balance(datetime.date(2019, 12, 31), Quantity(1000))}

    # initial_balances = {
    #     Account("1010"): Balance(datetime.date(2019, 12, 31), Quantity(100)),
    #     Account("1040"): Balance(datetime.date(2019, 12

# Generated at 2022-06-12 06:09:22.186884
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from datetime import date
    from typing import Mapping
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting, PostingType
    from .numbers import Quantity
    from .organizations import Organization

    @dataclass
    class InitialBalances:
        mapping: Mapping[Account, Quantity]

        def __call__(self, period: DateRange) -> Mapping[Account, Quantity]:
            return self.mapping

    @dataclass
    class JournalEntries:
        mapping: Mapping[date, JournalEntry]

        def __call__(self, period: DateRange) -> Mapping[date, JournalEntry]:
            return {j.date: j for j in self.mapping.values() if j.date <= period.until}


# Generated at 2022-06-12 06:09:31.141198
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from typing import Callable, Dict
    from itertools import chain
    from datetime import date
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from ..commons.numbers import Amount, Quantity
    from ..accounting.accounts import Account
    from ..accounting import journaling
    from ..accounting.generic import Balance
    from .generic import ReadInitialBalances, GeneralLedgerProgram

    @dataclass
    class JournalEntryMock:
        description: str
        date: date
        postings: List[journaling.Posting]

    @dataclass
    class AccountMock:
        name: str
        code: int
        type: journaling.AccountType

    @dataclass
    class AccountBalanceMock:
        account: AccountMock
        balance: Balance


# Generated at 2022-06-12 06:09:41.990133
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account
    from .commons import Money
    from .journaling import Transaction, build_transaction

    # Define an account:
    cash_account = Account("Cash")

    # Define initial balances:
    initial_balances = {cash_account: Balance(datetime.date(2018, 1, 15), Money(10))}

    # Define transactions to be posted:
    credits = {cash_account: Money(30)}
    debits = {cash_account: Money(10)}
    t1 = build_transaction(datetime.date(2018, 2, 10), "Description 1", credits=credits, debits=debits)
    t2 = build_transaction(datetime.date(2018, 2, 15), "Description 2", credits=credits, debits=debits)

    # Build expected journal

# Generated at 2022-06-12 06:09:43.372698
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # Write your unit test here
    raise NotImplementedError()

# Generated at 2022-06-12 06:09:53.773811
# Unit test for function build_general_ledger
def test_build_general_ledger():
    ## Import required modules:
    from ..commons.zeitgeist import DateRange
    from .accounts import AccountUnit
    from .journaling import JournalEntry
    from .vvv import document

    ## Set up
    #: Accounting period.
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

    #: General ledger.