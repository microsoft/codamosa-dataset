

# Generated at 2022-06-12 06:00:18.512280
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    ## The "read initial balances" implementation:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("A/C-11"): Balance(period.since, Quantity(Decimal(5000))),
            Account("A/C-22"): Balance(period.since, Quantity(Decimal(4000))),
            Account("A/C-25"): Balance(period.since, Quantity(Decimal(-3000))),
            Account("A/C-31"): Balance(period.since, Quantity(Decimal(-2000))),
            Account("A/C-45"): Balance(period.since, Quantity(Decimal(300))),
        }

    ## The list of postings we will use:

# Generated at 2022-06-12 06:00:19.528507
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass



# Generated at 2022-06-12 06:00:29.770331
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    # Import required packages
    from .commons.zeitgeist import DateRange
    from .journaling import Posting, Account, JournalEntry, Direction

    # Define function to return initial balance
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return { Account('Assets'): Balance(period.since, Quantity(1000)) }

    # Define function to return a journal entry

# Generated at 2022-06-12 06:00:35.662231
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .books import read_journal_entries
    from .simulate import simulate, simulate_initial_balances

    ## Initialize the books:
    R1 = simulate(simulate_initial_balances(datetime.date(2018, 1, 1)), "R1")
    R2 = simulate(R1.books, "R2")
    R3 = simulate(R2.books, "R3")
    R4 = simulate(R3.books, "R4")
    R5 = simulate(R4.books, "R5")
    R6 = simulate(R5.books, "R6")

    ## Build the general ledger program:
    program = compile_general_ledger_program(R6.books.read_initial_balances, read_journal_entries)

    ## Run the program:

# Generated at 2022-06-12 06:00:46.859441
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .journaling import build_journal_entry
    from .ledger import ReadInitialBalances, ReadJournalEntries, build_general_ledger, compile_general_ledger_program

    def mock_read_initial_balances(period: DateRange) -> InitialBalances:
        ...

    def mock_read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        ...

    program = compile_general_ledger_program(mock_read_initial_balances, mock_read_journal_entries)

    assert callable(program)
    assert program.__name__ == "_program"
    assert program.__doc__ == """
    Consumes the opening and closing dates and produces a general ledger.
    """

# Generated at 2022-06-12 06:00:51.794770
# Unit test for function build_general_ledger
def test_build_general_ledger():
    period = DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31))
    initial = {Account.by_code("2070"): Balance(datetime.date(2017, 12, 31), Quantity(10000)),
               Account.by_code("9900"): Balance(datetime.date(2017, 12, 31), Quantity(10000))}
    journal = [
        JournalEntry(datetime.date(2018, 1, 2), "1", [
            Posting(Account.by_code("2070"), Quantity(Decimal(1000)), "1",datetime.date(2018, 1, 2)),
            Posting(Account.by_code("9900"), Quantity(Decimal(1000)), "1",datetime.date(2018, 1, 2))])
    ]
    result = build_general_ledger

# Generated at 2022-06-12 06:00:53.320656
# Unit test for method add of class Ledger
def test_Ledger_add():
    ledger = Ledger(a, Balance(period.since, Quantity(Decimal(0))))

# Generated at 2022-06-12 06:01:03.767060
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import CreditCardAccount

    # Test the first transaction
    test_ledger = Ledger(CreditCardAccount("TestAccount"), Balance(datetime.date(2018,1,1), 0))
    test_ledger.add(Posting(datetime.date(2018,1,1),CreditCardAccount("TestAccount"),True,10))
    assert test_ledger.entries[0].balance == 10
    assert test_ledger.entries[0].amount == 10
    assert test_ledger.entries[0].is_debit
    assert test_ledger.entries[0].debit == 10
    assert test_ledger.entries[0].credit == None

    # Test the second transaction

# Generated at 2022-06-12 06:01:04.681132
# Unit test for function build_general_ledger
def test_build_general_ledger():
    assert True

# Generated at 2022-06-12 06:01:05.265428
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__(): ...


# Generated at 2022-06-12 06:01:17.100477
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .algebras.initialize import Initialize
    from .algebras.journaling import Journaling

    ini = Initialize()
    journal = Journaling()

    build_general_ledger = compile_general_ledger_program(ini.read_initial_balances, journal.read_journal_entries)

    gl = build_general_ledger(
        DateRange(
            since=datetime.date(2020, 1, 1),
            until=datetime.date(2020, 12, 31),
        )
    )

    assert len(gl.ledgers) == 2
    assert gl.ledgers[Account("A1")].entries[0].date == datetime.date(2020, 1, 1)

# Generated at 2022-06-12 06:01:27.407053
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import DateRange
    from ..journaling import read_journal_entries
    from ..transactions import Transaction, TransactionRecord
    from .accounts import Account, read_terminal_accounts

    # Define a data directory:
    DATADIR = "data/build_general_ledger"

    # Define a sample journal entry:
    from .accounts import Account
    from .journaling import JournalEntry, Posting

    # Define a sample journal entry:
    from .accounts import Account
    from .journaling import JournalEntry, Posting


# Generated at 2022-06-12 06:01:28.050935
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass

# Generated at 2022-06-12 06:01:38.671924
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from pytest import raises
    from datetime import datetime
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, TerminalAccount
    from .generic import Balance
    from .invoicing import InvoicePosting, Invoice

    def _test(initial_balances:InitialBalances):
        assert len(initial_balances) == 2
        assert initial_balances[Account(1)] == Balance(datetime(2016, 10, 1), Decimal(10))
        assert initial_balances[Account(2)] == Balance(datetime(2016, 10, 1), Decimal(20))

    _test(ReadInitialBalances()(DateRange(datetime(2016, 10, 1), datetime(2016, 10, 1))))

# Generated at 2022-06-12 06:01:39.259403
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    ...

# Generated at 2022-06-12 06:01:48.295689
# Unit test for function build_general_ledger
def test_build_general_ledger():
    """
    Unit test for function build_general_ledger.
    """
    from dataclasses import asdict
    from datetime import date
    from decimal import Decimal
    from .accounts import Account, AccountTree
    from .journaling import JournalEntry, Posting
    from .numbers import Amount, Quantity, Balance

    ## Build the account tree first:

# Generated at 2022-06-12 06:01:49.319789
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert False


# Generated at 2022-06-12 06:01:57.574919
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from elm.accounting.algebra import ReadJournalEntries, ReadInitialBalances

    ## Mock implementation which returns no initial balances:
    def read_initial_balances(period):
        return {}

    ## Mock implementation which reads journal entries for testing:
    def read_journal_entries(period):
        from ..commons.zeitgeist import create_date
        from .journaling import Journal, Posting

        ## Create some helper date instances:
        date1 = create_date(2013, 2, 15)
        date2 = create_date(2013, 3, 1)
        date3 = create_date(2013, 3, 15)

        ## Mock journals:
        journal1 = Journal(date1, "Transaction #1", [Posting(date1, "1000", "50", "1050")])

# Generated at 2022-06-12 06:02:08.019261
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from ..commons.import_test import import_test
    from .accounts import Account as A
    from .generic import Balance as B
    from .journaling import JournalEntry as JE
    from .journaling import Posting as P
    from .journaling import ReadJournalEntries as RJE
    from .journaling import read_journal_entries as _read_journal_entries
    from datetime import date, timedelta
    from decimal import Decimal
    import_test("journaling", "ReadJournalEntries")
    assert ReadInitialBalances.__call__
    assert Decimal("0.0001") == Decimal("0.0001")
    def _today(delta: int) -> date: return date.today() + timedelta(days=delta)

# Generated at 2022-06-12 06:02:09.214789
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass

# Generated at 2022-06-12 06:02:16.944520
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    """
    Performs unit test for method __call__ of class ReadInitialBalances.
    """
    assert False



# Generated at 2022-06-12 06:02:28.487103
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry, Posting, build_journal_entry

    ## Create a post-dated journal entry:
    journal = build_journal_entry(
        "Testing",
        datetime.date.today() - datetime.timedelta(days=1),
        Posting(Account("TEST", 0), Quantity(10), Order.DEBIT),
        Posting(Account("TEST", 1), Quantity(10), Order.CREDIT),
    )

    ## Create an algebra implementation which returns a list of journal entries.
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry]:
        return iter(journal)

    ## Create an algebra implementation which returns the list of initial balances.

# Generated at 2022-06-12 06:02:37.321802
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from datetime import date
    from .. import reader

    # Define the data store:
    store: Dict[str, List[str]] = {
        "accounts": ["001,terminal,working capital", "002,terminal,cash & deposits"],
        "initial_balances": ["001,2015-01-01,1000000", "002,2015-01-01,1000000"],
        "journal_entries": [
            "2015-01-01,001,sale,1000000",
            "2015-01-01,002,purchase,1000000",
            "2015-01-02,001,fixture,2000000",
            "2015-01-03,002,freight,3000000",
        ],
    }

    # Define the date range:

# Generated at 2022-06-12 06:02:46.538907
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Unit test for data strcture GeneralLedgerProgram
    """

    # Initialize variables for testing.
    initialBalances = {Account("1") : Balance(datetime.date.today(),Quantity(Decimal(0)))}
    journalEntry1 = JournalEntry("j1",datetime.date.today(),[Account("A"),Account("B")],[Amount(Decimal(12)),Amount(-12)])
    journalEntries = [journalEntry1]
    period = DateRange(datetime.date.today(),datetime.date.today())
    
    # Use the compiled program to produce a ledger.
    generalLedger = compile_general_ledger_program(lambda period: initialBalances,lambda period: journalEntries)(period)
    
    # Check if the general ledger is generated correctly.
    assert generalLedger.period == period
   

# Generated at 2022-06-12 06:02:58.506958
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from uuid import uuid4 as uuid
    from pytest import fixture
    from itertools import count
    from datetime import date, timedelta
    from unittest.mock import Mock
    from types import FunctionType
    from ..commons.numbers import Amount
    from ..commons.zeitgeist import DateRange
    from ..accounts import Account, AccountId

    @fixture
    def account() -> Account:
        return Account(AccountId(str(uuid())), "Test Account")

    @fixture
    def balances() -> dict:
        return {
            account: Amount(Decimal(value))
            for value, account in zip(count(100, step=100), map(lambda _: Account(AccountId(str(uuid())), "Test Account"), range(10)))
        }


# Generated at 2022-06-12 06:03:04.668267
# Unit test for method add of class Ledger
def test_Ledger_add():
    # given
    _post = Posting(Account(1),Decimal(1), Decimal(2), datetime.date(2020, 1, 1))
    _bal = Balance(Decimal(1))
    _led = Ledger(Account(1), _bal)
    # when
    _result = _led.add(_post)
    # then
    assert _result.balance == 3


# Generated at 2022-06-12 06:03:05.527722
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    ...


# Generated at 2022-06-12 06:03:14.937270
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from datetime import date
    from typing import NamedTuple
    from unittest import TestCase

    from ..sample.accounting import assets, equity, liabilities

    ## Define a dummy journal entry.
    class JournalEntry(NamedTuple):
        date: date
        description: str
        postings: List[tuple]

    ## Define a dummy read journal entries algebra implementation which generates a journal entry.
    def read_journal_entries(period: DateRange) -> List[JournalEntry]:
        return [
            JournalEntry(
                date=date(1998, 2, 1),
                description="Purchase new car",
                postings=[(assets.bank_account, 1000), (liabilities.car_loan_account, -1000)],
            )
        ]

    ## Define a dummy read initial balances algebra implementation which returns no initial balances.
   

# Generated at 2022-06-12 06:03:18.881033
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():

    # dummy definition for ReadInitialBalances:
    def _(period):
        return {}
    dummy_balances = _

    # dummy definition for ReadJournalEntries:
    def _(period):
        return []
    dummy_journal = _

    compile_general_ledger_program(dummy_balances, dummy_journal)

# Generated at 2022-06-12 06:03:30.176624
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Unit test for function compile_general_ledger_program.
    """
    from ..books.algebras import build_accounting_book_program
    from ..books.model import AccountingBook, AccountingBookProgram
    from ..commons import zeitgeist
    from ..commons.functional import curried

    # Tuple of date, description and postings:

# Generated at 2022-06-12 06:03:51.281641
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    import datetime

    def fake_initial_balances(period: DateRange) -> InitialBalances:
        return {}

    def fake_journal_entries(period: DateRange) -> Iterable[JournalEntry]:
        yield JournalEntry(
            datetime.date(2016, 12, 31),
            "Beginning",
            [Posting(Account("1.1.1"), Decimal(100))],
        )

    general_ledger = compile_general_ledger_program(fake_initial_balances, fake_journal_entries)(
        DateRange(datetime.date(2016, 12, 30), datetime.date(2016, 12, 31))
    )

    assert general_ledger.period == DateRange(datetime.date(2016, 12, 30), datetime.date(2016, 12, 31))
    assert general_ledger

# Generated at 2022-06-12 06:04:01.424066
# Unit test for method add of class Ledger
def test_Ledger_add():
    """
    Testing method add of class Ledger.
    """

    ## Create a dummy journal.
    journal = JournalEntry.from_postings(datetime.date(2020, 1, 1), "Dummy Journal", [Posting(Decimal(1), Account(1, "Account 1", True), True)])

    ## Create a dummy ledger.
    ledger = Ledger(Account(1, "Account 1", True), Balance(datetime.date(2020, 1, 1), Decimal(1)))

    ## Add all postings from the dummy journal to the dummy ledger.
    ledger.add(journal.postings[0])

    assert ledger.entries[0].balance == Decimal(2)

# Generated at 2022-06-12 06:04:13.319139
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..books.dsl_book import CreateDslBook
    from ..books.ingest_books import IngestBooks
    from ..books.pipeline import create_book
    from ..books.programs import compile_build_books_program

    book = create_book(CreateDslBook(Inventories=IngestBooks()), "./books/ingest_books.md", "./books/books.md")
    build_books = compile_build_books_program(book)
    books = build_books(DateRange(datetime.date(2019, 7, 1), datetime.date(2020, 6, 30)))

    for acct in books.accounts:
        if acct.is_terminal:
            initial_balances = (acct, books.ledger(acct).ending_balance)
            break
        
   

# Generated at 2022-06-12 06:04:22.369200
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    import unittest
    import datetime
    from abc import ABC, abstractmethod
    from decimal import Decimal
    from typing import Iterable
    from ..commons.zeitgeist import DateRange
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .ledgers import (
        GeneralLedger,
        GeneralLedgerProgram,
        LedgerEntry,
        InitialBalances,
        ReadInitialBalances,
        ReadJournalEntries,
        build_general_ledger,
        compile_general_ledger_program,
    )


# Generated at 2022-06-12 06:04:25.792290
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from unittest.mock import MagicMock
    reader = ReadInitialBalances.__call__.__wrapped__
    date_range = MagicMock(DateRange)
    result = reader(date_range)
    assert isinstance(result, dict)

# Generated at 2022-06-12 06:04:37.160302
# Unit test for function build_general_ledger

# Generated at 2022-06-12 06:04:46.216987
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import AccountCodes, AccountFactory
    from .journaling import JournalEntryFactory
    from .posting import PostingFactory
    from .journaling import Identifier
    from .journaling import IdentifierStrategy, ReferenceNumber
    from .journaling import IdentifierFactory
    from .readers import read_initial_balances, read_journal_entries
    from .tags import Tag
    from .tags import TagFactory
    from ..commons.zeitgeist import Period
    from datetime import date
    from decimal import Decimal
    from dataclasses import asdict
    from typing import Any, Dict
    import unittest

    # Test case 1:
    # Create test program
    period = Period(date(2019, 7, 1), date(2019, 7, 31))
    read_initial_balances = read_initial_bal

# Generated at 2022-06-12 06:04:53.356462
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    This method tests :py:meth:`GeneralLedgerProgram.__call__` method.
    """

    ## Preliminaries:
    from ..commons.zeitgeist import DateRange

    ##
    ## Setup an in-memory general journal consisting of a single double-entry.
    ##

    ## Import the required definitions from the framework:
    from binalyzer_core import (
        Binalyzer,
        BinalyzerExtension,
        Field,
        Template,
    )
    from binalyzer_template_provider import JSONTemplateProvider
    from .accounts import Account
    from .journaling import (
        Journal,
        JournalEntry,
        Posting,
    )
    from ..commons.numbers import (
        Amount,
        Currency,
    )

# Generated at 2022-06-12 06:05:04.388501
# Unit test for method add of class Ledger
def test_Ledger_add():
    test = Ledger(Account(10, "Test"), Balance(datetime.date(2020, 1, 1), Quantity(0)))
    test.add(Posting(
        JournalEntry(datetime.date(2020, 1, 1), "TEST", [
            Posting(Account(10, "Test"), Quantity(100), "Debit"),
            Posting(Account(20, "Test"), Quantity(100), "Credit")
        ]),
        Account(10, "Test"),
        Quantity(100),
        "Debit"

    ))
    assert test.entries[0].posting.date == datetime.date(2020, 1, 1)
    assert test.entries[0].posting.amount == Quantity(100)
    assert test.entries[0].posting.journal.description == "TEST"
    assert test.ent

# Generated at 2022-06-12 06:05:14.869429
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .algebras import (
        AlgebraicSystem,
        ReadInitialBalances as ReadInitialBalancesAlgebra,
        ReadJournalEntries as ReadJournalEntriesAlgebra,
    )
    import datetime
    from decimal import Decimal
    from pony.orm import db_session
    from typing import Deferred
    from unittest import TestCase
    from unittest.mock import Mock, patch
    from ..commons.zeitgeist import DateRange
    from .accounts import DEFAULT_CURRENCY, Account
    from .generic import Balance
    from .journaling import Entry, Posting


# Generated at 2022-06-12 06:05:48.978675
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():

    ## Fake initial balances read:
    fake_read_initial_balances = {a: Balance(datetime.date(2020, 1, 1), Quantity(Decimal(1000))) for a in Account.assets}

    def read_initial_balances(date_range: DateRange) -> InitialBalances:
        return fake_read_initial_balances

    ## Fake journal entries read:

# Generated at 2022-06-12 06:05:58.242933
# Unit test for function build_general_ledger
def test_build_general_ledger():
    ledger_1 = build_general_ledger(DateRange(datetime.date(2020,1,1), datetime.date(2020,1,31)), JournalEntry(datetime.date(2020,1,1), '', [Posting('Packing Supplies', '', '', '', Quantity(Decimal(0)))]), {})

    assert(ledger_1.period.since == datetime.date(2020,1,1))
    assert(ledger_1.period.until == datetime.date(2020,1,31))
    assert(ledger_1.ledgers == {})


# Generated at 2022-06-12 06:06:06.291370
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account

    account = Account("Assets.Cash")
    posting = Posting(True, Amount(Decimal("10.0")), "Assets.Cash", "Expense.Rent")
    ledger = Ledger(account, Balance(datetime.date(2020, 1, 1), Quantity(Decimal("10.0"))))

    entry = ledger.add(posting)

    assert posting == entry.posting
    assert Quantity(Decimal("10.0")) == entry.balance
    assert ledger == entry.ledger

# Generated at 2022-06-12 06:06:15.239228
# Unit test for method add of class Ledger
def test_Ledger_add():
    a = Account(name='a', terminal=False)
    b = Account(name='b', terminal=False)
    c = Account(name='c', terminal=True)
    d = Account(name='d', terminal=True)

    e = JournalEntry(
        date=datetime.date(2020,1,1),
        description='e',
        postings=[
            Posting(account=a, direction=1, amount=1),
            Posting(account=b, direction=-1, amount=1)
        ]
    )


# Generated at 2022-06-12 06:06:24.602200
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .journaling.algebras import ReadJournalEntries
    from .accounts.algebras import ReadInitialBalances
    from ..commons.zeitgeist import DateRange

    ## Dummy read journal entries implementation:
    def read_journal_entries(period: DateRange) -> ReadJournalEntries:
        return period
    ## Dummy read initial balances implementation:
    def read_initial_balances(period: DateRange) -> ReadInitialBalances:
        return period
    ## Dummy date range:
    daterange=DateRange(datetime.date(2020,1,1), datetime.date(2020,12,31))
    ## Compile the program
    compile_general_ledger_program(read_journal_entries, read_initial_balances)(daterange) == daterange

# Generated at 2022-06-12 06:06:36.102834
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from .accounts import Account, AccountType
    from .generic import Balance

    root = Account("Root", AccountType.ASSET, None)
    a = Account("A", AccountType.ASSET, root)
    b = Account("B", AccountType.ASSET, root)
    c = Account("C", AccountType.ASSET, root)

    def _initial_balances(period) -> InitialBalances:
        return {
            a: Balance(period.since, Quantity(1)),
            b: Balance(period.since, Quantity(2)),
            c: Balance(period.since, Quantity(3)),
        }


# Generated at 2022-06-12 06:06:46.737414
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from .accounts import Account
    from .commons import Period
    from .journaling import Journal, Posting
    from .basic_commons import ReadInitialBalancesByAccount, ReadJournalEntriesByAccount

    opening_balance_1 = {Account(1, "A1"): 1, Account(2, "A2"): 2, Account(3, "A3"): 3}
    opening_balance_2 = {Account(4, "A4"): 4, Account(5, "A5"): 5, Account(6, "A6"): 6}

    def _read_initial_balances_by_account(period: datetime.date):
        if period == Period(2019, 12, 31):
            return opening_balance_1
        elif period == Period(2020, 3, 31):
            return opening_balance_2
       

# Generated at 2022-06-12 06:06:58.082972
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from collections import defaultdict
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountClass
    from .journaling import JournalEntry, Posting
    from .generic import Balance


# Generated at 2022-06-12 06:07:05.188628
# Unit test for function build_general_ledger
def test_build_general_ledger():

    ## Import the modules we need:
    from .commons import load_accounts
    from .journaling import build_journaling_program

    ## Load accounts from fixtures:
    accounts = load_accounts("accounts.json")

    ## Open journal entries from fixtures:
    journaling_program = build_journaling_program("journal.json", accounts)

    ## Compile a general ledger program:
    general_ledger_program = compile_general_ledger_program(lambda p: {}, journaling_program)

    ## Create the accounting period:
    period = DateRange(datetime.date(2019, 7, 1), datetime.date(2019, 7, 30))

    ## Build the general ledger:
    general_ledger = general_ledger_program(period)

    ## Test the general ledger period:

# Generated at 2022-06-12 06:07:10.274424
# Unit test for method add of class Ledger
def test_Ledger_add():
    l = Ledger(Account('A'), Balance(datetime.date(2000, 1, 1), Quantity(Decimal(20))))
    assert l.add(Posting(Account('A'), datetime.date(2000, 1, 5), 1, Quantity(10))) == LedgerEntry(l, Posting(Account('A'), datetime.date(2000, 1, 5), 1, Quantity(10)), Quantity(30))

# Generated at 2022-06-12 06:08:15.018239
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..ledgers.ledgers import ledger_algebra
    from ..ledgers.dummy import dummy_read_initial_balances, dummy_read_journal_entries

    alg = compile_general_ledger_program(
        read_initial_balances=dummy_read_initial_balances, read_journal_entries=dummy_read_journal_entries
    )

    assert alg(DateRange("2019-01-01", "2019-06-30")) == ledger_algebra(DateRange("2019-01-01", "2019-06-30"))

# Generated at 2022-06-12 06:08:25.092230
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from ..algebras.accounting import AccountingAlgebra
    from ..domains.accounting import AccountKind
    from ..domains.accounting import AccountType
    from ..domains.accounting import OpeningBalance
    from ..domains.accounting import Tree
    from ..domains.accounting import create_account
    from ..domains.accounting import create_opening_balance
    from ..domains.accounting import create_tree

    ## Create tree:
    tree = create_tree()

    ## Create initial balances:

# Generated at 2022-06-12 06:08:28.264606
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    """
    Unit test method __call__ of class ReadInitialBalances
    """
    print("Starting test for method __call__ of class ReadInitialBalances")
    assert False, "Not implemented"
    print("Finishing test for method __call__ of class ReadInitialBalances")



# Generated at 2022-06-12 06:08:35.992248
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests method __call__ of class GeneralLedgerProgram.
    """
    ## Import dependencies
    from ..commons.zeitgeist import DateRange
    from ..journaling.types import JournalEntry, Posting
    from .commons import Direction, Quantity
    from .generic import Balance
    from .journaling.algebra import ReadJournalEntries
    from .journaling.algebra_example import example as read_journal_entries
    from .types import Account

    ## Define test parameters
    period = DateRange(since=datetime.date(2019, 1, 1), until=datetime.date(2019, 3, 31))


# Generated at 2022-06-12 06:08:46.385662
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account

    # Mocks:
    initial_balances = {
        Account.from_name("0000000"): Balance(Date=datetime.date(2019, 1, 1), Value=Quantity(Decimal(0))),
        Account.from_name("0000001"): Balance(Date=datetime.date(2019, 1, 1), Value=Quantity(Decimal(0))),
        Account.from_name("0000002"): Balance(Date=datetime.date(2019, 1, 1), Value=Quantity(Decimal(0))),
        Account.from_name("0000004"): Balance(Date=datetime.date(2019, 1, 1), Value=Quantity(Decimal(0))),
    }


# Generated at 2022-06-12 06:08:52.688129
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account
    from .journaling import JournalEntry, JournalEntryId, Posting, Direction
    from .generic import Balance
    from .metadata import AccountId

    ## Create a bunch of accounts:
    a1 = Account(AccountId("1.1"), "Cash")
    a2 = Account(AccountId("1.2"), "Cash Credit")
    a3 = Account(AccountId("1.3"), "Cash Debit")

    ## Define a list of journal entries:
    je1 = JournalEntry(
        JournalEntryId("1"), date(2019, 1, 1), "Purchase of goods", Posting(a1, Direction.debit, Amount(100_000)),
    )

# Generated at 2022-06-12 06:08:53.749379
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-12 06:08:54.418488
# Unit test for function build_general_ledger
def test_build_general_ledger():
    pass

# Generated at 2022-06-12 06:08:57.590432
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    @compile_general_ledger_program(None, None)
    def program(period: DateRange) -> GeneralLedger:
        pass


"""DisabledContent
"""

# Generated at 2022-06-12 06:09:04.944371
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    import decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .commons import Direction

    @dataclass
    class TestReadInitialBalances(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {Account("1000"): Balance(period.since, Quantity(decimal.Decimal("10000")))}

    @dataclass
    class TestReadJournalEntries(ReadJournalEntries):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry]:
            from .journaling import Journal
            from .journaling import Posting
