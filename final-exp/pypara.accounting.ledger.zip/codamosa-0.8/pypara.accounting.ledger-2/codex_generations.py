

# Generated at 2022-06-12 06:00:06.062420
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from unittest.mock import Mock, call
    from .accounts import AccountType
    from .generic import AccountBalance, Balance
    from .ledgering import AccountBalance, Balance
    from .numbers import Amount, B, Quantity
    from .units import MonetaryUnit, MonetaryUnits
    mu = MonetaryUnit(MonetaryUnits.USD, Decimal('1.0'))
    la1 = Account(AccountType.RECEIVABLE, ('AR1', 'LA1', 'AAA'), name='AR1', unit=mu)
    la2 = Account(AccountType.RECEIVABLE, ('AR2', 'LA2', 'AAA'), name='AR2', unit=mu)

# Generated at 2022-06-12 06:00:18.463846
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    def read_initial_balances(period):
        return {Account("A"): Balance(Date(1,1,2020), Quantity(Decimal(0))), Account("C"): Balance(Date(1,1,2020), Quantity(Decimal(0)))}

    def read_journal_entries(period):
        j1 = JournalEntry(Date(1,1,2020), "1")
        j2 = JournalEntry(Date(1,1,2020), "2")
        j3 = JournalEntry(Date(1,1,2020), "3")
        p1 = Posting(j1, Account("A"), Direction.DEBIT, Amount(Decimal(50)))
        p2 = Posting(j1, Account("B"), Direction.CREDIT, Amount(Decimal(50)))

# Generated at 2022-06-12 06:00:28.775697
# Unit test for function build_general_ledger
def test_build_general_ledger():
    # Some fake data ...
    date1 = datetime.date(1901, 1, 1)
    date2 = datetime.date(1901, 1, 2)
    date3 = datetime.date(1901, 1, 3)
    date4 = datetime.date(1901, 1, 4)
    date5 = datetime.date(1901, 1, 5)
    date6 = datetime.date(1901, 1, 6)
    date7 = datetime.date(1901, 1, 7)
    amount1 = Amount(100.00)
    amount2 = Amount(10.00)
    amount3 = Amount(5.00)
    amount4 = Amount(200.00)
    amount5 = Amount(10.00)
    amount6 = Amount(5.00)

# Generated at 2022-06-12 06:00:38.437834
# Unit test for method add of class Ledger
def test_Ledger_add():
    from datetime import date
    from decimal import Decimal
    from ..journaling.accounts import Account, Accounts
    from ..journaling.journaling import Journal, Posting
  
    accounts = Accounts()
    acct_clientes = accounts['Clientes']
    acct_bancos = accounts['Bancos 1']
    acct_capital = accounts['Capital']
    acct_ventas = accounts['Ventas']
    acct_gastos_anuales = accounts['Gastos Anuales']
    acct_gastos_sueldos = accounts['Gastos Sueldos']
    acct_gastos_honorarios = accounts['Gastos Honorarios']


# Generated at 2022-06-12 06:00:48.091597
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests :py:meth:`GeneralLedgerProgram.__call__`
    """
    import datetime
    from typing import Tuple
    from ..ledgers.ports import initial_balances

    def read_initial_balances(period: DateRange):
        return initial_balances.read_initial_balances(period)

    def read_journal_entries(period: DateRange):
        return journal_entries.read_journal_entries(period)

    def enter_journal_entries(je: Tuple[JournalEntry, ...]):
        journal_entries.enter_journal_entries(je)

    def clear_journal_entries():
        journal_entries.clear_journal_entries()

    from ..commons.datetime import DateRange

    from ..ledgers.ledger_entry import Led

# Generated at 2022-06-12 06:00:59.960305
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import JournalEntry, Posting
    from ..commons.zeitgeist import Date, DateTimespan

    # Preparation and Dummy Data
    period = DateTimespan.from_dates(Date(2019, 1, 1), Date(2019, 12, 31))
    journal_entries = [
        JournalEntry(
            date=Date(2019, 1, 1),
            description="dummy",
            postings=[Posting(direction="DEBIT", account="901", amount=Decimal(0)), Posting(direction="CREDIT", account="901", amount=Decimal(0))],
        )
    ]

    # Test
    general_ledger = build_general_ledger(period, journal_entries, {})
    assert len(general_ledger.ledgers) == 1
    assert general_ledger.period == period

# Generated at 2022-06-12 06:01:06.893416
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    ## Mocks.
    period = DateRange.from_date(datetime.date(year=2020, month=1, day=1))
    initial_balances = {"A": Balance(period.since, Quantity(Decimal(0))), "B": Balance(period.since, Quantity(Decimal(0)))}

# Generated at 2022-06-12 06:01:08.955388
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert False # TODO: implement your test here


# Generated at 2022-06-12 06:01:17.462746
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .journaling import Journal
    from .commons.zeitgeist import date
    from .accounts import Account

    journal = Journal(date(2020, 2, 11), "Test entry")
    journal.post(Account(10, "Sales"), Amount(Decimal(30)))
    journal.post(Account(20, "Purchases"), Amount(Decimal(40)))

    ledgers = {}
    ledgers[Account(10, "Sales")] = Ledger(Account(10, "Sales"), Balance(date(2020, 1, 1), Quantity(Decimal(0))))

    ledgers[Account(10, "Sales")].add(journal.postings[0])

    assert len(ledgers[Account(10, "Sales")].entries) == 1

# Generated at 2022-06-12 06:01:27.580470
# Unit test for function build_general_ledger
def test_build_general_ledger():
    # test data set
    from .journaling import JournalEntry
    from .accounts import Account, Accounts

    # journal_entries
    # pylint: disable=len-as-condition
    journal_entries: List[JournalEntry[str]] = list()

    journal_entry1: JournalEntry[str] = JournalEntry("JE01", "2019-01-01", "Journal Entry 01")
    journal_entry1.postings.append(Posting(Accounts.ar_usd, datetime.date(2019, 1, 1), Decimal("100.00")))
    journal_entry1.postings.append(Posting(Accounts.cash_usd, datetime.date(2019, 1, 1), Decimal("100.00")))
    journal_entries.append(journal_entry1)


# Generated at 2022-06-12 06:01:41.129578
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..components.journaling import post_journal_entry
    from ..components.accounts import book_accounts, RefData, TerminalAccount
    from ..commons.zeitgeist import Today

    # Using today as the period
    period = Today()

    # Create a reference data:
    refdata = RefData()

    # Create a reference date:
    refdate = period.since

    # Create some terminal accounts:
    assets = refdata.at(TerminalAccount, "Assets", None, False)
    a1 = refdata.at(TerminalAccount, "A1", assets)
    a2 = refdata.at(TerminalAccount, "A2", assets)
    capital = refdata.at(TerminalAccount, "Capital", None, False)

# Generated at 2022-06-12 06:01:49.740612
# Unit test for method add of class Ledger
def test_Ledger_add():
    '''
    Testing method add of class Ledger.
    '''
    test_posting = Posting(account='a', date=datetime.date(2019, 12, 31), amount=Decimal('100'), direction='debit')
    test_ledger = Ledger(account='a', initial=Balance(date=datetime.date(2019, 12, 31),value=Quantity(Decimal('0'))))
    result = test_ledger.add(test_posting)
    assert result.ledger == test_ledger
    assert result.posting == test_posting
    assert result.balance == Quantity(Decimal('100'))
    assert result.date == datetime.date(2019, 12, 31)
    assert result.description == None
    assert result.amount == Decimal('100')
    assert result.is_debit

# Generated at 2022-06-12 06:01:50.384629
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
  assert True

# Generated at 2022-06-12 06:01:58.041621
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import JournalEntry, Posting, DrCr

    # Input data
    period = DateRange(datetime.date(2020, 3, 1), datetime.date(2020, 3, 31))
    journal = [
        JournalEntry(datetime.date(2020, 3, 1), "JE1", [Posting(DrCr.DEBIT, 1, "1101", Decimal(10))]),
        JournalEntry(datetime.date(2020, 3, 2), "JE2", [Posting(DrCr.CREDIT, 1, "1101", Decimal(5))]),
        JournalEntry(datetime.date(2020, 3, 3), "JE3", [Posting(DrCr.DEBIT, 1, "1102", Decimal(1))]),
    ]

# Generated at 2022-06-12 06:02:05.930732
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    @dataclass
    class MyReadInitialBalances(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            pass
    
    @dataclass(init=False)
    class MyReadInitialBalances2(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            pass
    
    try:
        MyReadInitialBalances()
        assert False
    except:
        pass
    #
    MyReadInitialBalances2()


# Generated at 2022-06-12 06:02:17.958274
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():

    from typing import Dict

    from datetime import date

    from finances_automation.accounts import Account
    from finances_automation.commons.numbers import Amount, Quantity

    from finances_automation.infrastructure.data.implementation.in_memory import InMemoryAccounts

    from .generic import Balance

    ## Define test data:
    #  Indicate whether we already have a balance for each account:
    account_balance = Dict[Account, bool]({
        Account(name="Account #1", cntracct="General debe", vat=False): False,
        Account(name="Account #2", cntracct="General haber", vat=False): True
    })

    #  Initial balances, if any:

# Generated at 2022-06-12 06:02:28.677993
# Unit test for method __call__ of class GeneralLedgerProgram

# Generated at 2022-06-12 06:02:37.387455
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests if the __call__ method of class GeneralLedgerProgram works as expected.
    """
    ## Define unit test parameters:
    period = DateRange(datetime.date(2019, 8, 1), datetime.date(2019, 8, 31))

    ## Define the algebra being called by the program:
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return dict()


# Generated at 2022-06-12 06:02:42.634817
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    """
    Unit test for method __call__ of class ReadInitialBalances.
    """

    ## Arrange
    def fake(self, period: DateRange) -> InitialBalances:
        pass

    ## Act
    from inspect import signature

    ## Assert
    assert list(signature(fake).parameters.keys()) == ["self", "period"]


# Generated at 2022-06-12 06:02:54.865410
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from collections import defaultdict
    from datetime import date
    from decimal import Decimal

    from .accounts import Account
    from .journaling import JournalEntry, Posting

    from ..commons.zeitgeist import DateRange
    from .generic import Balance

    def mke(date, d, c) -> Posting:
        return Posting(Account(d), Amount(Decimal(d)), Account(c), Amount(Decimal(c)), date)

    def mje(description: str, date: date, posting: Posting, *postings) -> JournalEntry:
        """
        Builds a dummy journal entry.
        """
        return JournalEntry(description, date, posting, *postings)

    def mgl(period: DateRange, *journal: JournalEntry):
        """
        Builds a dummy general ledger.
        """
        return

# Generated at 2022-06-12 06:03:09.600236
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ._algebras import ReadInitialBalances as _ReadInitialBalances
    from ._algebras import ReadJournalEntries as _ReadJournalEntries

    ## Setup test data:

# Generated at 2022-06-12 06:03:17.105264
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():

    # Subclass the protocol ReadInitialBalances
    class ReadInitialBalancesSubclass(ReadInitialBalances):

        def __call__(self, period: DateRange) -> InitialBalances:
            pass

    # Subclass the protocol AccountingPeriod
    class ReadJournalEntriesSubclass(ReadJournalEntries):

        def __call__(self, period: DateRange) -> Iterable[JournalEntry]:
            pass

    # Various typed variables.
    read_initial_balances: ReadInitialBalancesSubclass
    read_journal_entries: ReadJournalEntriesSubclass
    program: GeneralLedgerProgram[int]

    # We don't do anything but exercise the typing of the function.
    program = compile_general_ledger_program(read_initial_balances, read_journal_entries)



# Generated at 2022-06-12 06:03:29.001408
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from ..ledger.soles import Sol
    from .accounts import Account
    from .journaling import Balance, Direction, JournalEntry, Posting, create_entry
    from .program import compile_journal_program

    def _create_journal_entry(date: date, d: Direction, acc: Account, amount: Sol, num: int) -> JournalEntry:
        if num == 1:
            return create_entry(date, d, acc, amount)
        else:
            return create_entry(
                date, d, acc, amount, d, acc, amount, d, acc, amount, d, acc, amount, d, acc, amount, d, acc, amount
            )


# Generated at 2022-06-12 06:03:36.298231
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    read_initial_balances = lambda period: InitialBalances({Account("A0"): Balance(period.since, Quantity(Decimal(1)))})
    read_journal_entries = lambda period: [
        JournalEntry(period.since, "T1", [
            Posting(period.since, Account("A0"), Quantity(Decimal(1)), ""),
            Posting(period.since, Account("A1"), Quantity(Decimal(1)), ""),
        ]),
        JournalEntry(period.since, "T2", [
            Posting(period.since, Account("A1"), Quantity(Decimal(1)), ""),
            Posting(period.since, Account("A2"), Quantity(Decimal(1)), ""),
        ]),
    ]


# Generated at 2022-06-12 06:03:47.609223
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    import random
    import uuid
    from cashbook.commons.zeitgeist import UnitTestTimeMachine
    from cashbook.journaling.algebra import PostJournalEntry, ReadJournalEntries
    from cashbook.journaling.model import JournalEntry
    from cashbook.journaling.repository import InMemoryJournalEntryRepository
    from cashbook.ledgering.algebra import BuildGeneralLedger, ReadInitialBalances
    from cashbook.ledgering.model import GeneralLedger, InitialBalances
    from cashbook.ledgering.repository import InMemoryInitialBalancesRepository

    ## Account prefix for test accounts:
    account_prefix = "ACCT"

    ## Source of random numbers:
    random_seed = random.Random(123)

    ## Current date time:
    now = datetime.datetime.now()

   

# Generated at 2022-06-12 06:03:52.097606
# Unit test for method add of class Ledger
def test_Ledger_add():
    l = Ledger(Account("A"), Balance(datetime.date.today(), 0))
    p = Posting(datetime.date.today(), 1, 1, True, Account("A"))
    p1 = Posting(datetime.date.today(), - 1, 1, False, Account("A"))
    entry = l.add(p)
    entry1 = l.add(p1)
    print(l.entries)

# Generated at 2022-06-12 06:04:02.863873
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # Arrange
    from ..fakes.ashen import Journal
    from ..fakes.bookkeeper import FakeBookKeeper

    from .dsl import from_account
    from .journaling import JournalEntry as _JournalEntry

    ## Define the initial balances:
    initial_balances: InitialBalances = {
        from_account(12): Balance(datetime.date(2016, 6, 30), Quantity(Decimal(1000)))
    }

    ## Define journal entries:
    journal_entries = [
        JournalEntry(from_account(2), from_account(12), Quantity(504), datetime.date(2016, 6, 30)),
        JournalEntry(from_account(12), from_account(2), Quantity(500), datetime.date(2016, 7, 1)),
    ]

    ## Define the expected result:
    ledger

# Generated at 2022-06-12 06:04:13.408332
# Unit test for function build_general_ledger
def test_build_general_ledger():

    from ..books.accounts import AccountType
    from ..books.model import Journal, JournalEntry, Posting

    ## Create some accounts:
    a1 = Account("0001", AccountType.ASSET, "Equipment")
    a2 = Account("0002", AccountType.ASSET, "Cash")
    a3 = Account("0003", AccountType.ASSET, "Accounts receivable")
    a4 = Account("0004", AccountType.LIABILITY, "Accounts payable")
    a5 = Account("0005", AccountType.LIABILITY, "Overdraft")
    a6 = Account("0006", AccountType.EQUITY, "Capital")
    a7 = Account("0007", AccountType.INCOME, "Sales")
    a8 = Account("0008", AccountType.EXPENSE, "Electricity")

# Generated at 2022-06-12 06:04:22.398990
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Create an account
    accountt = Account("asset", "active", "bank", None)
    # Create an initial balance
    initial = Balance(datetime.date(2020, 1, 1), Amount(56))
    # Create a ledger using account and initial balance
    ledger = Ledger(accountt, initial)
    # Create a journal entry
    datee = datetime.date(2020, 1, 1)
    descriptionn = "description"
    journal = JournalEntry(datee, descriptionn)
    # Create a posting
    accountt_1 = Account("asset", "active", "bank", None)
    debit_credit = 1
    amount = Amount(56)
    posting = Posting(accountt, debit_credit, amount, journal)
    # Add the posting to the ledger
    result = ledger.add(posting)
   

# Generated at 2022-06-12 06:04:26.943353
# Unit test for method add of class Ledger
def test_Ledger_add():
    test_posting = Posting( 1, "2019-01-01", 1000)
    test_ledger = Ledger(1, Balance("2019-01-01",0))
    test_ledger.add(test_posting)
    assert test_ledger.entries[0].balance == test_posting.amount

# Generated at 2022-06-12 06:04:41.359527
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass

# Generated at 2022-06-12 06:04:48.888493
# Unit test for method add of class Ledger
def test_Ledger_add():
    @dataclass
    class TestJournalEntry(JournalEntry):
        description: str
        date: datetime.date
        _postings: Iterable[Posting]

        @property
        def posting(self) -> Posting:
            return next(self._postings)

    journal_entry = TestJournalEntry(
        description="Description",
        date=datetime.date(2020, 1, 1),
        _postings=[
            Posting(
                account=Account("asset", "cash"),
                date=datetime.date(2020, 1, 1),
                amount=Decimal(2000),
                direction=1,
            ),
        ],
    )

# Generated at 2022-06-12 06:04:49.279292
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    ...

# Generated at 2022-06-12 06:04:50.573782
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from unittest.mock import Mock

    mock = Mock()

    mock.__call__(None)
    mock.assert_called_once_with(None)


# Generated at 2022-06-12 06:04:51.149530
# Unit test for method add of class Ledger
def test_Ledger_add():
    assert True

# Generated at 2022-06-12 06:05:01.781462
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import Journal
    from .invoice import Invoice
    from .algebras.initial_balances import initial_balances
    from .algebras.journaling import journaling

    def _read_initial_balances(period: DateRange) -> InitialBalances:
        r = initial_balances()

        return dict(r)

    def _read_journal_entries(period: DateRange) -> Iterable[JournalEntry]:
        jalgebra = journaling()

        r = jalgebra.read_journal_entries()

        return list(iter(r))

    glp = compile_general_ledger_program(_read_initial_balances, _read_journal_entries)

    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 4, 1))

# Generated at 2022-06-12 06:05:10.687967
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from decimal import Decimal
    from importlib import resources
    from ..commons.zeitgeist import date_range
    from ..accounting.journaling import JournalEntry, Posting, read_journal_entries_from_csv_resource
    from ..accounting.accounts import Account

    with resources.path("pacco.manager.accounting.tests", "chart.csv") as chart_csv_path:
        chart = [Account(code, name) for code, name in read_journal_entries_from_csv_resource(chart_csv_path)]
    with resources.path("pacco.manager.accounting.tests", "journal.csv") as journal_csv_path:
        journal = read_journal_entries_from_csv_resource(journal_csv_path)


# Generated at 2022-06-12 06:05:11.844994
# Unit test for method add of class Ledger
def test_Ledger_add():
    pass

# Generated at 2022-06-12 06:05:22.053399
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Unit test for method __call__ of class GeneralLedgerProgram.
    """

    from datetime import date, timedelta
    from decimal import Decimal
    from typing import Dict
    from .accounts import AccountType
    from .commons import Direction
    from .journaling import JournalEntry, Posting, journal_entry

    ## Initial balances:

# Generated at 2022-06-12 06:05:27.513549
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    import types

    ReadInitialBalancesMock = types.SimpleNamespace(__call__=lambda _: {})
    ReadJournalEntriesMock = types.SimpleNamespace(__call__=lambda _: [])

    assert isinstance(compile_general_ledger_program(ReadInitialBalancesMock, ReadJournalEntriesMock)(datetime.date.today()), GeneralLedger)

# Generated at 2022-06-12 06:06:23.035957
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .journaling import Journal, Posting

    account = Account(account="1234")
    initial = Balance(date=datetime.date(2010, 1, 1), value=0)
    myledger = Ledger(account=account, initial=initial)
    posting = Posting(
        account=account,
        amount=10,
        direction=1,
        journal=Journal(
            description="test description",
            date=datetime.date(2010, 1, 1),
            postings=[
                Posting(account=Account(account="4321"), amount=10, direction=-1, journal=None),
            ]
        )
    )
    ledgentry = myledger.add(posting)
    assert ledgentry.balance == 10
    assert ledgentry.description == "test description"
    assert ledgentry.credit

# Generated at 2022-06-12 06:06:32.359498
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from ..commons.zeitgeist import Period
    from ..commons.numbers import zero

    @dataclass(frozen=True)
    class P(Protocol):
        def __call__(self, period: Period) -> dict:
            pass

    @P.implementation_for(P)
    class Q():
        def __call__(self, period: Period) -> dict:
            return dict()

    print(Q().__call__(Period.between(datetime.date.today(), datetime.date.today() + datetime.timedelta(days=1))))

# Generated at 2022-06-12 06:06:39.003419
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import Journal, Posting, JournalEntry
    from .generic import PostingDirection

    ## Create the journal
    journal = Journal("Test Journal")

    ## Create the test account
    account = Account("Test Account", "1001", "test-account")

    ## Set initial balance
    initial = Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0)))

    ## Create the ledger
    ledger = Ledger(account, initial)

    ## Create the Posting
    posting = Posting(datetime.date(2020, 1, 1), account, PostingDirection.DEBIT, Quantity(Decimal(100)))

    ## Add the posting to the journal
    journal.add(posting)

    ## Create the Journal Entry

# Generated at 2022-06-12 06:06:48.409718
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    ## Define sample initial balances:
    initial_balances = {Account("assets:cash"): Balance(datetime.date(2018, 12, 31), Quantity(Decimal(1000)))}

    ## Define a sample journal entry:
    journal_entry = JournalEntry(
        date=datetime.date(2019, 1, 1),
        description="A journal entry",
        postings=[
            Posting(
                account=Account("assets:cash"),
                amount=Amount(Decimal(10)),
                direction=Posting.Debit
            ),
            Posting(
                account=Account("expenses:operating"),
                amount=Amount(Decimal(10)),
                direction=Posting.Credit
            )
        ]
    )

    ## Define mock algebra implementations:

# Generated at 2022-06-12 06:06:59.706063
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():

    # Test data for initial balances:
    initial_balances = {"A123": Balance(datetime.date(2018, 12, 31), Quantity(Decimal(1000))),
                        "A124": Balance(datetime.date(2018, 12, 31), Quantity(Decimal(1200)))}

    # Test data for journal entries:

# Generated at 2022-06-12 06:07:05.037737
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # Setup.
    class _ReadInitialBalances:

        def __call__(self, period):
            pass

    read_initial_balances = _ReadInitialBalances()

    # Exercise.
    ReadInitialBalances.__call__(read_initial_balances, DateRange("2020-01-01", "2020-12-31"))

    # Verify.
    pass


# Generated at 2022-06-12 06:07:12.651260
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    ## TEST: Build and execute a general ledger program:
    read_initial_balances = lambda period: {"Assets:Cash": Balance(period.until, Decimal(100))}
    read_journal_entries = lambda period: [JournalEntry(period.since, ["Debit Assets:Cash", "Credit Equity"])]

    program = compile_general_ledger_program(read_initial_balances, read_journal_entries)
    general_ledger = program(DateRange(datetime.date(2017, 1, 1), datetime.date(2017, 1, 31)))

    assert general_ledger.period == DateRange(datetime.date(2017, 1, 1), datetime.date(2017, 1, 31))

# Generated at 2022-06-12 06:07:13.666197
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    # FIXME: Add unit tests
    pass

# Generated at 2022-06-12 06:07:22.055324
# Unit test for function build_general_ledger
def test_build_general_ledger():
    """
    Unit test for function build_general_ledger
    """
    from .journaling import JournalEntry

    # Initialize general ledger
    period = DateRange(datetime.date(2020, 5, 1), datetime.date(2020, 5, 31))
    initial_balances = {}
    initial_balances['Assets:Checking'] = Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0)))
    initial_balances['Expense'] = Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0)))
    initial_balances['Income'] = Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0)))
    
    # Initialize journal entries
    journal_entries = []

    # Initialize journal entry and add to journal entries
    # On

# Generated at 2022-06-12 06:07:32.526513
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    acc1 = Account('acc1', 'test1 account', 'asset')
    acc2 = Account('acc2', 'test2 account', 'liability')
    acc3 = Account('acc3', 'test3 account', 'revenue')
    acc4 = Account('acc4', 'test4 account', 'expense')
    p1 = Posting(acc1, Decimal(100), 1)
    p2 = Posting(acc1, Decimal(100), 1)
    p3 = Posting(acc1, Decimal(100), -1)
    p4 = Posting(acc2, Decimal(100), 1)
    p5 = Posting(acc2, Decimal(100), -1)
    p6 = Posting(acc3, Decimal(100), 1)
    p7 = Post

# Generated at 2022-06-12 06:08:37.877768
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-12 06:08:38.927076
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    raise NotImplementedError()


# Generated at 2022-06-12 06:08:48.784138
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from mydata.accounting.journaling import build_journal_entries
    from mydata.accounting.journaling import compile_posting_program
    from mydata.accounting.journaling import ReadJournalEntries

    def test_read_initial_balances(period: DateRange) -> InitialBalances:
        return {Account("Assets:Current:Cash"): Balance(period.since, Quantity(18500))}

    period = DateRange(since=datetime.date(2019, 1, 1), until=datetime.date(2019, 12, 31))
    posting_program = compile_posting_program(period)
    journal_entries = build_journal_entries(posting_program, period)
    read_journal_entries: ReadJournalEntries = lambda period: journal_entries
    general_ledger_program = compile

# Generated at 2022-06-12 06:09:00.849986
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import FinancialYear, Month
    from ..domain.entities.accounting import AccountingTransaction
    from ..domain.entities.accountingperiod import AccountingPeriod
    from ..domain.entities.accountingperiod import AccountingPeriodRepository
    from ..domain.entities.openingbalances import OpeningBalances
    from ..domain.entities.openingbalances import OpeningBalancesRepository
    from ..domain.entities.journalentry import JournalEntryRepository
    from ..domain.entities.posting import PostingRepository
    from ..infrastructure.container import Container
    from ..infrastructure.container.domain.accountingperiod import AccountingPeriodBuilder
    from ..infrastructure.container.domain.journalentry import JournalEntryBuilder
    from ..infrastructure.container.domain.openingbalances import OpeningBalancesBuilder

# Generated at 2022-06-12 06:09:01.427952
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass  # TODO

# Generated at 2022-06-12 06:09:11.959821
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .types import DebitsCredits
    import datetime
    from decimal import Decimal
    import typing

    #: Algebra implementation of ReadInitialBalances

    class ReadInitialBalancesImplementation(typing.Protocol):
        def __call__(self, period: DateRange) -> InitialBalances: pass

    @dataclass
    class ReadInitialBalancesImplementationInstance:
        def __call__(self, period: DateRange) -> InitialBalances:
            from .types import DebitsCredits
            import datetime
            from decimal import Decimal


# Generated at 2022-06-12 06:09:22.228835
# Unit test for method add of class Ledger
def test_Ledger_add():
    """
    check if add method of Ledger class, adds a new Entry to the Ledger and if 
    the balance updated properly.
    """
    testDebit = Ledger(None,None,None)
    testCredit = Ledger(None,None,None)
    testPosting = Posting(None,None,None,None)
    testPosting.amount = Decimal("100")
    testPosting.direction = 1
    testLedgerEntry = LedgerEntry(None,None,None)    
    testLedgerEntry = testDebit.add(testPosting)
    testPosting.direction = -1
    testLedgerEntry2 = testCredit.add(testPosting)
    if(testLedgerEntry.balance == Decimal("100") and testLedgerEntry2.balance == Decimal("-100")):
        return

# Generated at 2022-06-12 06:09:29.700021
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Unit test for method __call__ of class GeneralLedgerProgram
    """


    # Consumes the opening and closing dates and produces a general ledger
    #
    # :param period: Accounting period.
    # :return: A general ledger.
    
    # Get initial balances as of the end of previous financial period:
    initial_balances = read_initial_balances(period)

    # Read journal entries and post each of them:
    journal_entries = read_journal_entries(period)

    # Build the general ledger and return:
    return build_general_ledger(period, journal_entries, initial_balances)

# Generated at 2022-06-12 06:09:41.078946
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from typing import Optional, Generic, Protocol
    from decimal import Decimal
    from dataclasses import dataclass
    from .accounts import Account, AccountType
    from .journaling import Journal, JournalEntry, Posting, ReadJournalEntries

    #: Defines a generic type variable.
    _T = TypeVar("_T")

    @dataclass(frozen=True)
    class Balance(Generic[_T]):
        #: Date of the balance.
        date: datetime.date

        #: Value of the balance.
        value: Amount

    #: Initial balances:
    InitialBalances = Dict[Account, Balance]

    #: Type of functions which read and return initial balances.
    class ReadInitialBalances(Protocol):

        def __call__(self, period: DateRange) -> InitialBalances:
            pass



# Generated at 2022-06-12 06:09:42.069808
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__(): ...  # type: ignore
