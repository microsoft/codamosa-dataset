

# Generated at 2022-06-12 06:00:06.771018
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # Setup test variables
    from examples.commons.memory import read_journal_entries, read_initial_balances
    from examples.core.journaling import JournalEntry, Posting, read_journal_entries
    from examples.core.banking import Bank, CurrentAccount, read_initial_balances
    from examples.core.types import BankAccount, BusinessAccount
    from kkross.core.zeitgeist import DateRange
    from decimal import Decimal
    from datetime import date


# Generated at 2022-06-12 06:00:19.153407
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Test parameters
    account = Account("1001")
    date = datetime.date(year=2020, month=1, day=1)
    amount = Amount(value=Decimal(15.33))
    description = "Test Journal"
    journal = JournalEntry(date, description)
    journal.post("1010", "1020", amount)
    posting = journal.postings[0]
    posting2 = journal.postings[1]
    initial = Balance(date, Quantity(Decimal(100.00)))
    ledger = Ledger(account, initial)
    assert len(ledger.entries) == 0

    # Test case 1:
    entry = ledger.add(posting)
    assert ledger.account == posting.account
    assert ledger.initial.date == initial.date
    assert ledger.initial.value == initial.value


# Generated at 2022-06-12 06:00:24.640779
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from dateutil.relativedelta import relativedelta
    from decimal import Decimal

    from ..commons.numbers import Amount, Quantity
    from .accounts import Account, AccountType
    from .journaling import JournalEntry

    # default_percentage_value = Decimal(0.1)
    percentage_value = Decimal(0.1)  # default_percentage_value
    account_sales = Account('SAL', AccountType.REVENUE)
    account_cash = Account('CAS', AccountType.CASH)
    account_income = Account('INC', AccountType.INCOME)
    account_credit_card = Account('CCA', AccountType.LIABILITY)

    date_range = DateRange(date(2020, 1, 1), date(2020, 12, 31))
    initial

# Generated at 2022-06-12 06:00:33.229474
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons import datatypehelpers as dth

    from .accounts import Account
    from .generic import Balance, Quantity
    from .journaling import JournalEntry, Posting

    from unittest.mock import MagicMock

    # Given
    read_initial_balances: ReadInitialBalances = MagicMock(spec=ReadInitialBalances)

# Generated at 2022-06-12 06:00:37.336684
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # Stub:
    def stub(period): # type: ignore
        return {Account('0001'): Balance(datetime.date(2019, 1, 1), Quantity(1))}
    assert stub(DateRange.from_year(2019)) == {Account('0001'): Balance(datetime.date(2019, 1, 1), Quantity(1))}


# Generated at 2022-06-12 06:00:45.892054
# Unit test for method add of class Ledger
def test_Ledger_add():
    date = datetime.date(2020,1,1)
    amount = Amount(Decimal(100.0))
    difference = Amount(Decimal(100.0))
    journal_entry = JournalEntry(date, 'test_journal_entry',[Posting(Posting.Direction.DEBIT, Account('11'), amount), Posting(Posting.Direction.CREDIT, Account('12'), amount)])
    ledger = Ledger(Account('11'),Balance(date,Decimal(0.0)))
    ledger.add(journal_entry.postings[0])
    assert(ledger.entries[0].balance == difference)

# Generated at 2022-06-12 06:00:47.229024
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass

# Generated at 2022-06-12 06:00:59.059601
# Unit test for method add of class Ledger
def test_Ledger_add():
    @dataclass
    class SamplePosting(Posting[_T]):
        pass

    @dataclass
    class SampleAccount(Account):
        pass

    @dataclass
    class SampleBalance(Balance):
        pass
    
    ledger = Ledger(SampleAccount(), SampleBalance())
    posting = SamplePosting()
    posting.amount = Quantity(5)
    posting.direction = Quantity(5)
    posting.account = SampleAccount()
    posting.date = datetime.date(2020,1,1)
    posting.journal.description = "sample journal"
    posting.is_debit()
    posting.is_credit()

    entry = ledger.add(posting)

    assert entry.balance == Quantity(10)
    assert entry.posting == posting
    assert entry.description == "sample journal"


# Unit

# Generated at 2022-06-12 06:01:03.953149
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests the __call__ method of a GeneralLedgerProgram instance.
    """
    uut = compile_general_ledger_program(
        read_initial_balances=lambda period: {},
        read_journal_entries=lambda period: [],
    )

    assert isinstance(uut(DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))), GeneralLedger)

# Generated at 2022-06-12 06:01:14.906843
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Unit test to validate functionality of function :py:func:`compile_general_ledger_program`.
    """

    ## Type alias:
    class Event(_T):
        pass

    ## Type alias:
    class State:
        pass
    
    ## Define initial balance function:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        pass

    ## Define journal entries reader:
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[Event]]:
        pass

    ## Compile the program:
    program = compile_general_ledger_program(read_initial_balances, read_journal_entries)

    ## Type of the program.
    assert isinstance(program, GeneralLedgerProgram[Event])

    ## Type of the general ledger.


# Generated at 2022-06-12 06:01:34.799314
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # Arrange
    # - Arrange all the parameters
    period = DateRange(
        datetime.date.today().replace(day=1, month=1, year=2018), datetime.date.today().replace(day=31, month=12, year=2018)
    )
    _journalEntries = [
        JournalEntry(datetime.date(2018, 1, 1), "Test Journal Entry 1"),
        JournalEntry(datetime.date(2018, 1, 2), "Test Journal Entry 2"),
    ]
    def read_journal_entries(period):
        return _journalEntries
    def read_initial_balances(period):
        return {}
    # - Build an instance of the class GeneralLedgerProgram

# Generated at 2022-06-12 06:01:45.018168
# Unit test for method add of class Ledger
def test_Ledger_add():
    @dataclass
    class T:
        pass

    ledger = Ledger(Account(), Balance(datetime.date(2014, 2, 28), Quantity(Decimal(0))))
    posting = Posting(datetime.date(2014, 3, 1), T(), True, Quantity(Decimal(77.34)))
    k = ledger.add(posting)
    assert k.account == ledger.account
    assert k.date == posting.date
    assert k.description == posting.journal.description
    assert k.amount == posting.amount
    assert k.is_debit == posting.is_debit
    assert k.is_credit == posting.is_credit
    assert k.debit == posting.amount
    assert k.credit == None
    assert ledger.entries[0].date == k.date

# Generated at 2022-06-12 06:01:54.578361
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():

    from .fixtures import read_initial_balances, read_journal_entries

    program: GeneralLedgerProgram[None] = compile_general_ledger_program(read_journal_entries=read_journal_entries,
                                                                         read_initial_balances=read_initial_balances)
    assert callable(program)

    general_ledger = program(DateRange(since=datetime.date(2014, 7, 1),
                                       until=datetime.date(2014, 7, 31)))
    assert general_ledger is not None

    assert general_ledger.period == DateRange(since=datetime.date(2014, 7, 1),
                                              until=datetime.date(2014, 7, 31))

# Generated at 2022-06-12 06:02:04.005194
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    import unittest.mock
    ReadInitialBalances.__call__.__doc__ = "Type of functions which reads and returns initial balances."
    ReadInitialBalances.__call__.__annotations__ = {"return": InitialBalances}
    assert isinstance(ReadInitialBalances.__call__.__annotations__, dict)
    assert callable(ReadInitialBalances.__call__)
    assert isinstance(ReadInitialBalances.__call__.__call__, unittest.mock.MagicMock)
    assert ReadInitialBalances.__call__.__name__ == "__call__"


# Generated at 2022-06-12 06:02:16.022248
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date 
    from .journaling import Journal, JournalEntry, Posting
    from .accounts import Account, AccountType 
    from commons.numbers import Amount

    ## Prepare test data:

# Generated at 2022-06-12 06:02:21.134961
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from mock import MagicMock
    from .journaling import Posting, JournalEntry

    # Consume a general ledger program
    program = compile_general_ledger_program(MagicMock(), MagicMock())

    # Create a period
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 6, 30))

    # Mock read_initial_balances and read_journal_entries
    program.read_initial_balances = MagicMock(return_value={'100': Balance(period.since, Quantity(Decimal(2500)))})

# Generated at 2022-06-12 06:02:26.976755
# Unit test for method add of class Ledger
def test_Ledger_add():
    amount = Amount(5.5)
    account = Account(123,'Test Account')
    balance = Balance(datetime.date.today(), Quantity(10))
    ledger = Ledger(account, balance)
    assert ledger.add(Posting(datetime.date.today(), amount, account)) == LedgerEntry(ledger, Posting(datetime.date.today(), amount, account), Quantity(15.5))

# Generated at 2022-06-12 06:02:36.197389
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from unittest import TestCase, main
    from datetime import date
    from decimal import Decimal
    from os.path import join, dirname

    from .accounts import Account, Asset, Equity
    from .currency import Banknote, Coin, Currency, CurrencyAccount
    from .journaling import JournalEntry, Posting
    from ..commons.numbers import Quantity, Amount

    from .ledgering import (
        build_general_ledger,
        GeneralLedger,
        Ledger,
        LedgerEntry,
    )

    def get_initial_balances() -> dict:
        """
        Returns test initial balances.
        """


# Generated at 2022-06-12 06:02:38.339313
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from nose.tools import assert_equal, assert_is_instance
    
    assert_equal(True, True)
    return


# Generated at 2022-06-12 06:02:44.987675
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    ### Mocks:
    class ReadInitialBalancesMock:
        def __call__(self, period: DateRange) -> InitialBalances:
            return {1:Balance(1, 1)}
    class ReadJournalEntriesMock:
        def __call__(self, period: DateRange) -> Iterable[JournalEntry]:
            return [JournalEntry]
    ### Invoke target:
    GeneralLedgerProgram__call__ = compile_general_ledger_program(ReadInitialBalancesMock(), ReadJournalEntriesMock())
    assert GeneralLedgerProgram__call__

# Generated at 2022-06-12 06:03:08.523038
# Unit test for method add of class Ledger
def test_Ledger_add():
    account = Account(1000, "Cash", True)
    balance = Balance(datetime.date(2019, 12, 31), Quantity(Decimal(10000.00)))
    ledger = Ledger(account, balance)

    # Debit Posting
    journal = JournalEntry(datetime.date(2020, 1, 1), "Opening balance")
    posting = Posting(journal, 1000, "Cash", datetime.date(2019, 12, 31), 500, True)
    entry = ledger.add(posting)

    assert entry.balance == Quantity(Decimal(10500.00))

    # Credit Posting
    journal = JournalEntry(datetime.date(2020, 1, 1), "Transfers")
    posting = Posting(journal, 3000, "Bank Account", datetime.date(2019, 12, 31), 1100, False)
    entry = ledger

# Generated at 2022-06-12 06:03:16.316513
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .test.test_journaling import build_journal_entries

    # Values used in testing
    JOURNAL_1_ENTRIES = [
        (datetime.date(2018, 1, 2), "Transaction 1", [("Expense 1", -10), ("Expense 2", 10)]),
        (datetime.date(2018, 1, 4), "Transaction 2", [("Expense 2", -5), ("Equity 1", 5)]),
        (datetime.date(2018, 1, 10), "Transaction 3", [("Expense 1", -25), ("Income 1", 25)]),
    ]

    # Test 1: Building with initial balance
    journa

# Generated at 2022-06-12 06:03:28.665603
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry, Posting
    from .accounts import Account

    @dataclass
    class FakeReadInitialBalances:
        def __call__(self, period: DateRange) -> InitialBalances:
            return {}


# Generated at 2022-06-12 06:03:35.945207
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling_algs import JournalEntry, Posting, ReadJournalEntries
    from .accounts_algs import Account, ReadInitialBalances
    from .commons.zeitgeist import DateRange
    from .generic import Balance
    from .generic_algs import TerminalAccount
    from .general_ledger_algs import build_general_ledger, GeneralLedger, compile_general_ledger_program
    import datetime
    from decimal import Decimal

    ## Initialize initial balances and the journal:
    initial_balances = {
        Account.of(TerminalAccount.Cash): Balance(datetime.date(2019, 10, 1), value=Decimal(1000))
    }

# Generated at 2022-06-12 06:03:37.180598
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests method __call__ of class GeneralLedgerProgram
    """
    pass

# Generated at 2022-06-12 06:03:48.566223
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from random import choices
    from string import ascii_uppercase
    from ..commons.numbers import Amount

    # Sample accounts
    account_list = []
    for i in range(10):
        account = '1' + str(i) + ''.join(choices(ascii_uppercase, k=3))
        account_list.append(account)

    # Opening balances
    opening_balances = {}
    for account in account_list:
        opening_balances[account] = Amount(choices(range(1, 10000)))

    # Generate some transactions
    transactions = []
    for i in range(20):
        txn_date = date(2019, choices(range(1, 13)), choices(range(1, 28)))

# Generated at 2022-06-12 06:03:49.485658
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-12 06:04:01.098344
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ledger.test.algebras import (
        read_initial_balances,
        read_journal_entries,
    )
    open = datetime.date(2017, 1, 1)
    close = datetime.date(2017, 7, 31)
    period = DateRange(since=open, until=close)
    general_ledger = compile_general_ledger_program(read_initial_balances, read_journal_entries)(period)

    assert general_ledger.period == period
    assert len(general_ledger.ledgers) == 21

    assert general_ledger.ledgers["10100"].initial.date == datetime.date(2016, 12, 31)
    assert general_ledger.ledgers["10100"].initial.value == Decimal("1014.02")

# Generated at 2022-06-12 06:04:12.363811
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from .accounts import Account
    from .general.commons import initial_balances

    # Arrange
    until = date(2015, 12, 31)

    # Act
    result = initial_balances(until)

    # Assert
    assert (
        result == {
            Account('1010'): Balance(None, Quantity(10999)),
            Account('1020'): Balance(None, Quantity(10999)),
            Account('1030'): Balance(None, Quantity(10999)),
            Account('1040'): Balance(None, Quantity(10999)),
            Account('1050'): Balance(None, Quantity(10999)),
        }
    )


# Generated at 2022-06-12 06:04:21.649067
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    # Define the start and end dates
    start_date = datetime.date(2018, 1, 1)
    end_date = datetime.date(2018, 2, 1)
    # Define the initial balances for the accounting period
    initial_balances = {Account('100.00'): Balance(end_date, Quantity(Decimal(0)))}
    # Define the list of postings for the journal entries
    postings1 = [Posting(Quantity(Decimal(100)), Account('100.00'), None, None)]
    postings2 = [Posting(Quantity(Decimal(100)), Account('100.00'), None, None)]
    postings3 = [Posting(Quantity(Decimal(100)), Account('100.00'), None, None)]

# Generated at 2022-06-12 06:04:49.148116
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from src.economy.accounts import Account
    from src.economy.accounts.domain.types import Amount, Balance, Quantity
    from src.economy.accounts.infrastructure import Database

    ## Arrange:
    period = date(2019, 1, 1), date(2019, 1, 31)
    initial_balances = {
        Account("01.0000"): Balance(period[0], Quantity(0)),
        Account("01.0001"): Balance(period[0], Quantity(0)),
        Account("02.0000"): Balance(period[0], Quantity(-100)),
        Account("02.0001"): Balance(period[0], Quantity(-100)),
    }

    def read_initial_balances(p: tuple) -> dict:
        return initial_balances

    ## Act:
    read_

# Generated at 2022-06-12 06:04:58.146899
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import JournalEntry

    from datetime import date

    from ..commons.numbers import Amount

    initial_balances = {
        "Checking Account": Balance(date(2014, 12, 31), Amount(60.24)),
        "Saving Account": Balance(date(2014, 12, 31), Amount(4_631.88)),
    }


# Generated at 2022-06-12 06:05:08.616378
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from unittest.mock import MagicMock
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, Asset, Liability
    from .journaling import JournalEntry, Posting


    def mock_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("C", Asset): Balance(period.since - datetime.timedelta(days=1), Quantity(Decimal(1000))),
            Account("D", Liability): Balance(
                period.since - datetime.timedelta(days=1), Quantity(Decimal(500))
            ),
        }



# Generated at 2022-06-12 06:05:20.671740
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import JournalEntry
    from .accounts import Account, AccountType, AccountKind, AccountNature
    from .commons.zeitgeist import Date
    from .commons.numbers import Amount, Quantity
    from .generic import Balance
    import datetime

    date1 = datetime.date(year=2019, month=7, day=1)
    date2 = datetime.date(year=2019, month=8, day=1)
    journal1 = JournalEntry(date1, "Journal 1", [])
    journal2 = JournalEntry(date2, "Journal 2", [])
    account1 = Account(name="Account1", acc_type=AccountType.assets, acc_kind=AccountKind.current, acc_nature=AccountNature.bank)

# Generated at 2022-06-12 06:05:28.782383
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    @dataclass
    class DummyReadInitialBalances(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {Account("1"): Balance(datetime.date(2020, 2, 30), Quantity(1.0))}

    assert DummyReadInitialBalances()(DateRange(datetime.date(2020, 2, 1), datetime.date(2020, 2, 29))) == {
        Account("1"): Balance(datetime.date(2020, 2, 30), Quantity(1.0))
    }


# Generated at 2022-06-12 06:05:38.981423
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Unit test for method __call__ of class GeneralLedgerProgram.
    """
    #
    # Imports:
    from datetime import date
    from typing import Any
    from unittest.mock import Mock
    #
    # Setup:
    read_initial_balances = Mock(spec=ReadInitialBalances)
    read_initial_balances.return_value = {"A1": Balance(date(2020, 12, 1), Quantity(1000))}

    read_journal_entries = Mock(spec=ReadJournalEntries[Any])

# Generated at 2022-06-12 06:05:48.768396
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import date, date_range
    from ..data.ledger import InitialBalances

    ## Define test subject:
    period = date_range(date(2018, 1, 1), date(2020, 12, 31))
    initial_balances = InitialBalances({Account("AAA"): Balance(date(2018, 1, 1), Quantity(Decimal("1000"))),})

# Generated at 2022-06-12 06:05:59.998197
# Unit test for function build_general_ledger
def test_build_general_ledger():
    import datetime
    from decimal import Decimal
    from typing import NamedTuple
    from ..commons.numbers import Amount, Quantity
    import algebras
    #from algebras import ReadJournalEntries, ReadInitialBalances
    from lib.ledger.journaling import JournalEntry
    from lib.ledger.accounts import Account, AccountType, Direction
    from lib.ledger.generic import Balance
    from lib.ledger.ledgers import GeneralLedger
    from accounts import *
    from lib.ledger.posting import Posting
    from lib.ledger.journaling import Journal
    from lib.ledger.ledgers import build_general_ledger, Ledger

    # unit tests for lib.ledger.ledgers.build_general_ledger
    class Mock(NamedTuple):
        description: str


# Generated at 2022-06-12 06:06:10.446326
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import compile_open_accounts_book
    from .journaling import ReadJournalEntries, compile_journal_with_accounts_book

    accounts_book = compile_open_accounts_book()
    journal = compile_journal_with_accounts_book(accounts_book)

    for account, balance in accounts_book.initial_balances:
        print(account)
        print(balance)

    #accounts_book.add_account(2001, 'Cash')
    
    #journal.add_entry('Deposit', datetime.date(2010, 12, 31), 'Petty cash', [("Cash", 100)])
    #journal.add_entry('Deposit', datetime.date(2011, 1, 1), 'Petty cash', [("Cash", 100)])


# Generated at 2022-06-12 06:06:21.946417
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Test that method ``__call__`` of class :py:class:`GeneralLedgerProgram` returns correct results.
    """

    ## Define the accounting period:
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 3, 31))

    ## Define the initial balances as of the end of previous financial period:
    initial_balances = {
        Account(["assets", "cash-on-hand"]): Balance(datetime.date(2018, 12, 31), Quantity(1000))
    }

    ## Define the journal entries:

# Generated at 2022-06-12 06:06:54.802946
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    ## Import dependencies:
    from ..commons.zeitgeist import now
    from .accounts import AccountClass, AccountType, Asset, Equity
    from .journaling import Journal, JournalEntry
    from .records import Record

    ## Define initial balances:
    initial_balances: InitialBalances = {
        ## Cash in hand:
        Asset(AccountClass.Cash, AccountType.BalanceSheet, None, None, None): Balance(now(), Quantity(Decimal(10000))),
        ## Foreign currency:
        Equity(AccountClass.FX, AccountType.BalanceSheet, None, None, None): Balance(now(), Quantity(Decimal(200))),
    }

    ## Define journal entries:

# Generated at 2022-06-12 06:07:03.607865
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from valispace import Account
    from valispace import AccountType
    from valispace.commons.enumerations import AccountCategory
    from valispace.commons.enumerations import AccountNature
    from valispace.commons.numbers import Balance
    from valispace.commons.zeitgeist import DateRange
    from valispace.ledger.ledgers import InitialBalances
    account = Account('8-0000', 'Cash', AccountType.ASSET, AccountCategory.CURRENT, AccountNature.NORMAL)
    initial_balances = {account: Balance(date(2019, 1, 1), Decimal('80.00'))}
    date_range = DateRange(date(2019, 1, 1), date(2019, 1, 31))
    read_initial_

# Generated at 2022-06-12 06:07:12.176136
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import AccountGroup, AccountTypes
    from .journaling import build_journal_entry, PostingDirection, build_posting

    # noinspection DuplicatedCode
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        from .accounting import BalanceTypes
        return {Account("1000", "Cash", AccountTypes.ASSET, AccountGroup.CURRENT_ASSETS, BalanceTypes.DEBIT): Balance(
            period.since, Quantity(Decimal(10000))
        )}


    def _read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        ## Create a cash account:
        cash = Account("1000", "Cash", AccountTypes.ASSET, AccountGroup.CURRENT_ASSETS)

        ## Create an accrual account:
        accrual

# Generated at 2022-06-12 06:07:14.211075
# Unit test for function build_general_ledger
def test_build_general_ledger():
    assert build_general_ledger(DateRange(), [], {}) == GeneralLedger(DateRange(), {})



# Generated at 2022-06-12 06:07:22.261248
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from unittest import TestCase, mock

    from . import Ledger

    from .accounts import AccountGroup, AccountType

    from .commons.numbers import Decimal, Quantity

    from .commons.zeitgeist import Date, DateRange

    from .journaling import Journal
    from .journaling import Posting

    from .slots import Slot

    from .transactions import Transaction

    from .units import Unit

    from ..commons.context import Context

    class ReadInitialBalancesMock(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {Ledger.account: Balance(period.since, Quantity(0))}


# Generated at 2022-06-12 06:07:32.673720
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry, Posting

    from datetime import date

    TestJournalEntry = JournalEntry[str]
    TestPosting = Posting[str]
    TestGeneralLedger = GeneralLedger[str]
    TestLedger = Ledger[str]
    TestLedgerEntry = LedgerEntry[str]

    test_initial_balances = {
        "Assets:Cash": Balance(date(2020, 1, 1), Quantity(1000)),
        "Expenses:Salaries": Balance(date(2020, 1, 1), Quantity(0)),
    }


# Generated at 2022-06-12 06:07:42.209377
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():

    #
    # Define accounting period
    #

    period_since = datetime.date(2100, 1, 1)
    period_until = datetime.date(2100, 2, 1)
    period = DateRange(period_since, period_until)

    #
    # Define initial balances
    #


# Generated at 2022-06-12 06:07:44.869931
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert ReadInitialBalances.__call__.__annotations__ == dict(self="ReadInitialBalances", period="DateRange", return_type="InitialBalances")


# Generated at 2022-06-12 06:07:51.089743
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from typing import TYPE_CHECKING
    from .accounts import Account, asset, equity
    from .journaling import journal_entry, JournalEntry
    from .money import Money

    if TYPE_CHECKING:
        from .money import Money

    cash = Account(id="1", code="1.1", name="Cash", category=asset)
    sale = Account(id="2", code="2.1", name="Sales", category=equity)
    taxes = Account(id="3", code="2.3", name="Taxes", category=equity)


# Generated at 2022-06-12 06:08:02.134516
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account, CurrentAssets, Liabilities, CurrentLiabilities, Sales, RetainedEarnings, Cash
    from .journaling import Posting, Journal, JournalEntry
    from .generic import Balance

    def read_journal(period: DateRange) -> Iterable[Journal]:
        """
        Dummy implementation of the `read_journal` algebra which returns a sequence of journal entries for the specified
        period.

        :param period: Accounting period.
        :return: List of journal entries.
        """
        return [
            Journal(Cash, "Payment received", [Posting(Sales, Decimal(200.0), "+"), Posting(Cash, Decimal(200.0), "-")]),
        ]
