

# Generated at 2022-06-12 06:00:04.973268
# Unit test for method add of class Ledger
def test_Ledger_add():
    """
    Test Ledger.add() method
    """
    #: posting = Posting(date=datetime.date(2018,1,1), account=Account(code="4.2.2.2"), amount=Amount(Decimal(-200)),direction=Direction.DEBIT,journal=Journal(date=datetime.date(2018,1,1),postings=[]))
    #: acc = Account(code="4.2.2.2")
    #: initial = Balance(date = period.since, value = Quantity(Decimal(0)))
    #: ledger = Ledger(acc,initial)
    #: ledger.add(posting)
    assert True

# Generated at 2022-06-12 06:00:08.646879
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    class Test:
        def __call__(self, arg1: str) -> str:
            return arg1

    assert Test()("hello") == "hello"


# Generated at 2022-06-12 06:00:19.946913
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Unit test for method __call__ of class GeneralLedgerProgram.
    """
    from ..commons.adapters import get_console_adapter
    from ..commons.date import Date
    from ..commons.numbers import Amount
    from .journaling import JournalEntry, Posting

    ## Get console adapter.
    console = get_console_adapter()

    ## Define test-data.
    a1 = Account(1, "Test Account 1", True)
    a2 = Account(2, "Test Account 2", True)

# Generated at 2022-06-12 06:00:28.774593
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from unittest.mock import Mock
    from .accounts import Account, AccountType
    from .ledgers import ReadInitialBalances

    mock = Mock(ReadInitialBalances)
    mock.__call__.return_value = {
        Account.build(AccountType.Asset, "10100", "Cash"),
        Balance(date(2019, 1, 1), Quantity(Decimal(100)))
    }

    mock(DateRange(date(2019, 1, 1), date(2019, 1, 31)))

    mock.__call__.assert_called_once_with(DateRange(date(2019, 1, 1), date(2019, 1, 31)))


# Generated at 2022-06-12 06:00:38.408336
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..journaling import Journal

    class Transaction(Journal):
        def __init__(self, date: datetime.date, amount: Amount, account: Account):
            super().__init__(date)
            self.post(account, amount).with_description("A transaction")

    period = DateRange(datetime.date(2019, 4, 1), datetime.date(2019, 4, 30))

    initial = {
        Account("1010", "Cash"): Balance(period.since, Quantity(Decimal("100"))),
        Account("3020", "Income"): Balance(period.since, Quantity(Decimal("10"))),
    }


# Generated at 2022-06-12 06:00:48.091433
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..cafe.algebras import ReadEntries

    ## Initialize a general ledger builder:

# Generated at 2022-06-12 06:00:59.959064
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..journaling.journal import JournalEntry as Je
    from ..accounts.account import Account as Ac
    from ..commons.zeitgeist import DateRange as Dr
    ledger = build_general_ledger(
        Dr(datetime.date(2020, 1, 1), datetime.date(2020, 2, 1)),
        (Je(datetime.date(2020, 1, 1), "credit", Posting(Ac("100"), "+100"), Posting(Ac("300"), "-100")), ),
        {Ac("100"): Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0))), Ac("300"): Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0)))},
    )
    assert ledger.ledgers[Ac("100")].initial.value == Decimal(0)
   

# Generated at 2022-06-12 06:01:00.978257
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    ...


# Generated at 2022-06-12 06:01:07.356706
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from collections import namedtuple
    from ..commons.monads import MonadType, maybemap
    from ..commons.numbers import DEFAULT_PRECISION
    from .journaling import maybemap_journal_entry
    from .accounts import Accounts, Account

    ## Initial balance
    balance = Balance(date(2018, 1, 1), Quantity(Decimal(0)))

    ## Accounts
    accounts = Accounts(
        Account("A1", None, True),
        Account("A2", None, True),
        Account("A3", None, True),
        Account("A4", None, True),
    )

    ## Locations
    location = namedtuple("Location", ("name",))

# Generated at 2022-06-12 06:01:08.809122
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # TODO
    pass

# Generated at 2022-06-12 06:01:23.964111
# Unit test for method add of class Ledger
def test_Ledger_add():
    from datetime import date
    from decimal import Decimal
    from numbers import Amount, Quantity
    from typing import Mapping, TypeVar
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType, CounterAccounts, EntryType, PostingType
    from .codebooks import Codebook
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from general_ledger import build_general_ledger, compile_general_ledger_program, GeneralLedger, Ledger, LedgerEntry, ReadInitialBalances
    from .messa import Messa
    from .schemas import Balance, Entry, Message, MessageSchema, Schema
    from .validated import Validated
    # Define a generic type variable.
    _T = TypeVar("_T")
    
    

# Generated at 2022-06-12 06:01:33.174457
# Unit test for function build_general_ledger
def test_build_general_ledger():
    initial_balance = {'110000': Balance('2018-01-01', Quantity(Decimal(1000)))}
    ledger = build_general_ledger(DateRange('2018-01-01', '2018-01-31'), [], initial_balance)
    assert len(ledger.ledgers['110000'].entries) == 0
    assert ledger.ledgers['110000'].initial == initial_balance['110000']
    assert ledger.ledgers['110000'].account == '110000'

if __name__ == '__main__':
    test_build_general_ledger()

# Generated at 2022-06-12 06:01:33.658139
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert True

# Generated at 2022-06-12 06:01:42.157446
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # yapf: disable
    from ..domain.algebra import read_initial_balances, read_journal_entries
    from ..domain.journaling import Journal, Posting, journal, post
    from ..domain.accounting import find_account_by_code

    #: Accounting period
    period = DateRange(datetime.date(2019, 4, 1), datetime.date(2019, 6, 30))

    #: Business accounts
    income = find_account_by_code("20201")
    expenses = find_account_by_code("23999")

    #: Asset accounts
    cash = find_account_by_code("10110")
    petty_cash = find_account_by_code("10120")

    #: Liability accounts
    capital = find_account_by_code("30000")

    #: General ledger

# Generated at 2022-06-12 06:01:43.495698
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-12 06:01:51.610708
# Unit test for method add of class Ledger
def test_Ledger_add():
    ## Initialize a posting for testing
    test_posting = Posting(Account(2), Posting.Direction.CR, Amount(1))
    ## Initialize a ledger for testing
    test_ledger = Ledger(Account(2), Balance(datetime.date(2019, 1, 1), Quantity(1)))
    ## Test the result
    assert test_ledger.add(test_posting) == LedgerEntry(test_ledger, test_posting, Quantity(0))

# Generated at 2022-06-12 06:02:04.000960
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..journaling.algebra import ReadJournalEntriesAlgebra
    from ..journaling.model import JournalEntryModel
    from ..journaling.program import create_journal_entry
    from ..journaling.serialization import read_csv
    from ..journaling.types import BatchID
    from ..commons.numbers import Amount
    from ..commons.zeitgeist import DateRange
    from ..banking.types import Currency
    from ..accounting.types import Account
    from decimal import Decimal
    from datetime import datetime
    from typing import Dict
    from pymonads import Right

    def _period(a: datetime, b: datetime) -> DateRange:
        return DateRange(since=a, until=b)

    ####################################################################################################################
    ## Data for testing journal entries.
    ####################################################################################################################

# Generated at 2022-06-12 06:02:10.952234
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Create a Posting instance
    account1 = Account(1, 'Assets')
    account2 = Account(2, 'Liabilities')
    posting = Posting(account1, account2, 100, '2020-06-02', 'test')
    # Create a Ledger instance
    ledger = Ledger(account1, Balance('2020-01-01', 0))

    # add the posting to the Ledger
    entry = ledger.add(posting)
    # The balance in the Ledger Entry should be updated 
    assert entry.balance == 100
    # The last balance in the Ledger should be updated 
    assert ledger._last_balance == 100
    # The the account of the Ledger should be 'Assets'
    assert ledger.account == account1
    # The the initial balance of the Ledger should be 0

# Generated at 2022-06-12 06:02:14.532850
# Unit test for method add of class Ledger
def test_Ledger_add():
    test_ledger = Ledger(Account.get("12"), Balance(datetime.date(2009,1,1), Quantity(Decimal(0))))
    test_posting = Posting(datetime.date(2009,1,1), Journal.get("1"), Account.get("12"), Amount(Decimal(12)), 1)
    test_ledger.add(test_posting)
    assert test_ledger.entries[0].amount == test_posting.amount

# Generated at 2022-06-12 06:02:22.208876
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date, datetime
    from pytest import raises

    from .accounts import Account, AccountName
    from .journaling import JournalEntry

    @dataclass
    class _Dummy:
        pass

    # An account with an initial balance
    asset_account = Account(AccountName.ASSETS, AccountName.CASH)
    initial_balance = Balance(date.today(), 7)
    initial_balances = {asset_account: initial_balance}

    # A journal entry with a posting in the period
    journal = JournalEntry(
        date=date.today(),
        description="a test entry",
        postings=[
            Posting(asset_account, 0, 1, _Dummy()),
            Posting(asset_account, 1, 1, _Dummy()),
        ],
    )

    # Build

# Generated at 2022-06-12 06:02:29.917901
# Unit test for function build_general_ledger
def test_build_general_ledger():
    assert True == True


# Generated at 2022-06-12 06:02:37.798015
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from datetime import date
    from decimal import Decimal
    import unittest


# Generated at 2022-06-12 06:02:46.789076
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    import random
    import unittest

    from datetime import date

    from .journaling import JournalEntryFactory, PostingFactory

    from .accounts import AccountFactory
    from .commons.zeitgeist import DateRange
    from .generic import Balance, BalanceFactory, ReadInitialBalances

    class DummyReadInitialBalances(ReadInitialBalances):
        def __init__(self, initial_balances):
            self.initial_balances = initial_balances

        def __call__(self, period: DateRange) -> InitialBalances:
            return self.initial_balances

    class DummyReadJournalEntries(ReadJournalEntries):
        def __init__(self, journal_entries):
            self.journal_entries = journal_entries


# Generated at 2022-06-12 06:02:58.639244
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .journaling import Journal
    from .records import Account

 
    X = Account('100', 'Cash', 'A')
    Y = Account('200', 'Accounts payable', 'L')
    journal = Journal(datetime.date(2020, 12, 13), 'The journal entry', X, 100, Y)
    ledger = Ledger(X, Balance(datetime.date(2020, 12, 13), Quantity(Decimal(0))))
    assert ledger.account == X
    assert ledger.initial.value == 0
    assert ledger.entries == []
    ledger.add(journal.postings[0])
    assert ledger.account == X
    assert ledger.initial.value == 0
    assert ledger.entries[0].posting == journal.postings[0]
    assert ledger.entries[0].balance == 100

# Unit

# Generated at 2022-06-12 06:02:59.437878
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass

# Generated at 2022-06-12 06:03:07.847518
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .tests import ReadInitialBalancesMock, ReadJournalEntriesMock

    ## Use mocks for the underlying algebra:
    read_initial_balances = ReadInitialBalancesMock()
    read_journal_entries = ReadJournalEntriesMock()

    ## Compile program:
    program = compile_general_ledger_program(read_initial_balances, read_journal_entries)

    ## Execute:
    program(DateRange(datetime.date(2000, 1, 1), datetime.date(2000, 2, 1)))

    ## Verify invocations:
    assert read_initial_balances.invocations == 1
    assert read_journal_entries.invocations == 1

# Generated at 2022-06-12 06:03:16.926961
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import Account
    from .commons.zeitgeist import DateRange
    from .journaling import JournalEntry, Posting
    from .money import AccountMoneyModel
    from .numbers import Amount, Quantity

    ## Unit test data:
    ### Set up general ledger program:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {Account(1234): Balance(datetime.date(2018, 1, 31), Quantity(12.34)),}

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[AccountMoneyModel]]:
        date = datetime.date(2018, 2, 1)

# Generated at 2022-06-12 06:03:28.965111
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.interfaces import IConfig, IEventStore

    from .accounting import AccountingPeriod, AccountingPolicy
    from .journaling import Posting, Journal, JournalEntry
    from .accounts import Account, AccountType, AccountKind, AccountCode
    
    class TestReadInitialBalances:
        def __init__(self, initial_balances):
            self.initial_balances = initial_balances
        def __call__(self, period):
            return self.initial_balances

    class TestReadJournalEntries:
        def __init__(self, journal_entries):
            self.journal_entries = journal_entries
        def __call__(self, period):
            return self.journal_entries


# Generated at 2022-06-12 06:03:36.262097
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.adt import Read
    from .algebras import AccountingAlgebra

    accounting_algebra = AccountingAlgebra()

    ## Data:
    period = DateRange(datetime.date.fromisoformat("2020-01-01"), datetime.date.fromisoformat("2020-03-31"))

# Generated at 2022-06-12 06:03:47.610241
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Unit test for method __call__ of class GeneralLedgerProgram
    """
    from .journaling import AccountancyJournal, AccountancyJournalEntry
    from .accounts import Assets, Equity, Expenses, Liabilities, Revenue
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .ledgers import GeneralLedgerEntry, GeneralLedger, Ledger, build_general_ledger, GeneralLedgerProgram, ReadInitialBalances, compile_general_ledger_program, ReadJournalEntries
    from ..commons.algebra import Context
    from ..commons.model import Model
    from ..commons.numbers import Amount
    from ..commons.zeitgeist import DateRange
    import datetime

    # Test variable definitions:

# Generated at 2022-06-12 06:04:00.544969
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    g = compile_general_ledger_program()

# Generated at 2022-06-12 06:04:12.731597
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    class _read_initial_balances:
        def __call__(self, period: DateRange) -> InitialBalances:
            pass

    class _read_journal_entries:
        def __call__(self, period: DateRange) -> Iterable[JournalEntry]:
            pass

    ## Implementation type:
    _T = read_initial_balances = _read_initial_balances()
    _T = read_journal_entries = _read_journal_entries()
    _T = period = DateRange(datetime.date(2020, 4, 1), datetime.date(2020, 6, 30))

    ## Test compile:
    _T = GeneralLedgerProgram(read_initial_balances, read_journal_entries)

# Generated at 2022-06-12 06:04:21.122005
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
  import dataclasses
  import datetime
  from decimal import Decimal
  from typing import Dict

  from maboio.reporting.accounts import Account

  from .accounts import Balance
  from .generic import Quantity

  @dataclasses.dataclass
  class MockReadInitialBalances(ReadInitialBalances):
    def __call__(self,period):
      return Dict[Account, Balance]
  Mock = MockReadInitialBalances()
  period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))
  res = isinstance(Mock.__call__(period),Dict[Account, Balance])
  assert res


# Generated at 2022-06-12 06:04:29.283883
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    import unittest

    from ..journaling.models import Journal, PostingJournalEntry

    from .accounts import Account

    from .journaling import Posting, ReadJournalEntries

    def read_initial_balances(period: DateRange):
        return {
            Account(name="Cash"): Balance(period.since, Quantity(Decimal("1500"))),
            Account(name="Accounts Receivable"): Balance(period.since, Quantity(Decimal("0"))),
            Account(name="Supplies"): Balance(period.since, Quantity(Decimal("0"))),
        }


# Generated at 2022-06-12 06:04:40.056362
# Unit test for method add of class Ledger
def test_Ledger_add():
    class Journal:
        entries: List[LedgerEntry] = []

    class Posting():
        def __init__(self, date: datetime.date, journal: Journal, amount: Amount, direction: int):
            self.date = date
            self.journal = journal
            self.amount = amount
            self.direction = direction

    j = Journal()
    acc = Account('The Account')

    for i in range(1,11):
        j.entries.append(Posting(datetime.date(2018,i,1),j, Amount(i), -1))

    l = Ledger(acc, 0)
    for e in j.entries:
        l.add(e)

    assert(l.entries[-1].amount == Amount(10))

# Generated at 2022-06-12 06:04:48.189348
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    ## Imports:
    from typing import Dict
    from unittest.mock import Mock
    from .journaling import JournalEntry, LedgerEntry, Posting
    from datetime import date

    ## Initialize the program to test:
    hkd = Mock()

# Generated at 2022-06-12 06:04:50.784562
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    assert True

# Generated at 2022-06-12 06:04:53.786615
# Unit test for method add of class Ledger
def test_Ledger_add():
    a = Account("a")
    j = JournalEntry(date=datetime.date(1990,1,1), amount=Amount(Decimal(100)), description="", postings=[Posting(a, Amount(Decimal(100)), True)])

# Generated at 2022-06-12 06:05:05.003528
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():

    from unittest import TestCase, mock
    from .accounts import _accounts
    from .currencies import Currency
    from .generic import Balance, Quantity
    from .journaling import JournalEntry
    from .ledgers import BuildGeneralLedger, ReadInitialBalances, ReadJournalEntries

    class _Mock(mock.MagicMock):
        pass

    class _UnitTests(TestCase):

        def test_read_initial_balances(self):

            # Prepare mock arguments:
            initial_balances = {_accounts["CASH"]: Balance(datetime.date(2018, 1, 1), Quantity(Decimal(100), Currency.USD))}

            # Create mock implementations:
            mock_initial_balances = mock.create_autospec(ReadInitialBalances, instance=True)

# Generated at 2022-06-12 06:05:05.624349
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # TBD
    pass

# Generated at 2022-06-12 06:05:50.219722
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    period: DateRange = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))
    initial_balances: InitialBalances = {}
    journal_entries: List[JournalEntry] = []
    read_initial_balances: ReadInitialBalances = lambda x: initial_balances
    read_journal_entries: ReadJournalEntries = lambda x: journal_entries
    program: GeneralLedgerProgram = compile_general_ledger_program(
        read_initial_balances,
        read_journal_entries
    )
    ledger: GeneralLedger = program(period)
    assert ledger.ledgers=={}

# Generated at 2022-06-12 06:06:00.648347
# Unit test for method add of class Ledger
def test_Ledger_add():

    from unittest.mock import MagicMock

    from ..commons.numbers import Amount
    from ..commons.zeitgeist import Date

    from .accounts import Account
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .ledgers import Ledger, LedgerEntry

    ledger = Ledger(Account("TheAccount"), Balance(Date(2020, 5, 1), Quantity(Decimal("123.45"))))

    posting = Posting(JournalEntry("TheJournal", "TheDescription", Date(2020, 5, 3), [posting]))

    ledger.add(posting)

    assert len(ledger.entries) == 1

    entry = ledger.entries[0]

    assert entry.ledger == ledger

    assert entry.posting == posting

    assert entry.balance == Quantity("246.9")

# Generated at 2022-06-12 06:06:01.487684
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-12 06:06:11.586778
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    import random
    import unittest.mock

    read_initial_balances = unittest.mock.Mock(spec=ReadInitialBalances)
    read_initial_balances.return_value = {}

    read_journal_entries = unittest.mock.Mock(spec=ReadJournalEntries)
    read_journal_entries.return_value = unittest.mock.Mock(spec=Iterable[JournalEntry])

    def compile_general_ledger_program(
        read_initial_balances: ReadInitialBalances,
        read_journal_entries: ReadJournalEntries,
    ) -> GeneralLedgerProgram:
        import random
        import unittest.mock

        read_initial_balances = unittest.mock.Mock(spec=ReadInitialBalances)
       

# Generated at 2022-06-12 06:06:15.380000
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    balance = dict()

    class MockReadInitialBalances:
        def __call__(self, period: DateRange) -> InitialBalances:
            return balance

    return MockReadInitialBalances()



# Generated at 2022-06-12 06:06:17.192697
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests method __call__ of class GeneralLedgerProgram.
    """
    ## FIXME:
    pass

# Generated at 2022-06-12 06:06:24.979972
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # This function tests the method __call__ of class ReadInitialBalances.
    # Return a mock function
    def mock_ReadInitialBalances(period) -> InitialBalances:
        return {
            Account("Chase Checking"): Balance(
                datetime.date(2019, 12, 31), Quantity(Decimal(400))
            )
        }

    assert(mock_ReadInitialBalances.__call__(
        DateRange(datetime.date(2019, 12, 31), datetime.date(2020, 1, 31))
    )) == {
        Account("Chase Checking"): Balance(
            datetime.date(2019, 12, 31), Quantity(Decimal(400))
        )
    }


# Generated at 2022-06-12 06:06:27.031803
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass

# Generated at 2022-06-12 06:06:28.385078
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-12 06:06:37.368320
# Unit test for method add of class Ledger
def test_Ledger_add():
    ## Initilize some accounts
    a = Account("A")
    b = Account("B")
    c = Account("C")

    ## Initialize a ledger
    ledger = Ledger[int](a, Balance(datetime.date.today(), Quantity(10)))

    ## Add a posting to the ledger
    p = Posting[int](datetime.date.today(), a, b, Quantity(5), Amount(5), "A->B")
    entry = ledger.add(p)

    # Check that the entry is added to the ledger
    assert entry in ledger.entries

    # Check that the entry has the correct quantity
    assert entry.balance.value == 15

    ## Add a second posting to the ledger with a different account

# Generated at 2022-06-12 06:07:29.435064
# Unit test for method add of class Ledger
def test_Ledger_add():
    # initialize
    result = Ledger[int](Account(1), Balance(datetime.date.today(), Quantity(0)))
    posting = Posting[int](JournalEntry[int](datetime.date.today(), 'description', [], []), Account(1, True), Quantity(0))

    # test
    result.add(posting)

    # verify
    assert result.entries[0].balance == Quantity(0)

# Generated at 2022-06-12 06:07:39.770266
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Unit test for the function compile_general_ledger_program.
    """
    from .accounts import Account
    from .journaling import JournalEntry, Posting, build_journal_entry
    from .numbers import Quantity
    import datetime

    # Read opening and closing dates:
    period = DateRange(since=datetime.date(2020, 1, 1), until=datetime.date(2020, 12, 31))

    # Read initial balances.
    def read_initial_balances(p: DateRange) -> InitialBalances:
        """
        Reads initial balances.

        :param p: The accounting period.
        :return: Initial balances.
        """
        # Get balances:

# Generated at 2022-06-12 06:07:50.555980
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date

    from .accounts import Account

    from .commons.algebra import WriteInitialBalances

    from .commons.testing import load_test_accounts
    from .commons.testing import load_test_journals

    ## Load test journal data:
    journal_entries = load_test_journals()

    ## Load test account data:
    accounts = load_test_accounts()

    ## Initialize the write initial balances algebra implementation with the test data:
    def write_initial_balances(balances: InitialBalances) -> None:
        ## Just print the initial balances:
        for account, balance in balances.items():
            print(f"{account} : {balance}")

    ## Compile the read initial balances program:

# Generated at 2022-06-12 06:08:01.688250
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journals import MemJournal
    from .generic import (
        MemInitialBalance,
        ReadInitialBalances,
        ReadJournalEntries,
        JournalEntry,
        Posting,
        Direction,
    )
    from .accounts import MemAccount

    acct1 = MemAccount(1, "A/C 1")
    acct2 = MemAccount(2, "A/C 2")
    acct3 = MemAccount(3, "A/C 3")
    acct4 = MemAccount(4, "A/C 4")
    acct5 = MemAccount(5, "A/C 5")

    ib1 = MemInitialBalance(acct1, Balance(datetime.date(2020, 9, 30), Quantity(100)))

# Generated at 2022-06-12 06:08:09.472597
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .journaling import Posting, SimpleJournalEntry

    from .accounts import Account
    from .accounts import Asset, Liability, Equity

    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity

    import datetime

    #Bank = Account("Bank", Asset)
    #Drawings = Account("Drawings", Equity)
    FaceValue = Account("Face value", Asset)
    Cost = Account("Cost", Asset)
    OutstandingShares = Account("Outstanding shares", Equity)
    Equity = Account("Equity", Equity)
    #ShareCapital = Account("Share capital", Equity)
    #SharePremium = Account("Share premium", Equity)
    #Sales = Account("Sales", Revenue)
    #Assets = Account("Assets", Asset)
    #Revenue = Account("Revenue", Revenue)


# Generated at 2022-06-12 06:08:20.397291
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.journaling import JournalEntry, Posting
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account

    from ..commons.zeitgeist import Day

    #: Example opening balance:
    USR_OPENING_BALANCE = Balance(Day(2016, 1, 1), Quantity(Decimal(1000.00)))

    #: Example initial balances:
    USR_INITIAL_BALANCES = {Account.A: USR_OPENING_BALANCE}

    #: Example journal entries:

# Generated at 2022-06-12 06:08:29.348573
# Unit test for function build_general_ledger
def test_build_general_ledger():

    from ..accounts import Account
    from ..commons.zeitgeist import DateRange

    class Journal:
        def __init__(self, date, description, amount, account, direction):
            self.date = date
            self.description = description
            self.amount = amount
            self.account = account
            self.direction = direction

    ## Initialize test data:
    journal = [
        Journal("2017-01-31", "Test", Amount("100.00"), Account("12000"), "Debit"),
        Journal("2017-01-31", "Test", Amount("100.00"), Account("12000"), "Credit"),
    ]

    initial = {"12000": Amount("100.00")}

    ## Build general ledger.

# Generated at 2022-06-12 06:08:36.218898
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    import random
    from decimal import Decimal
    from dataclasses import dataclass, field
    from datetime import date
    from typing import List, Dict
    from ..commons.context import ReadCtx, ReadCtxProtocol, UnitOfWorkProtocol, UnitOfWork
    from .accounts import Account
    from .journaling import JournalEntry, Posting

    from . import AccountsT, JournalEntryT, JournalEntriesT, LedgerProgramT

    @dataclass
    class _InitBalances(ReadCtx, ReadCtxProtocol):
        """
        Initial balances.
        """

    @dataclass
    class _JournalEntries(ReadCtx, ReadCtxProtocol):
        """
        Journal entries.
        """


# Generated at 2022-06-12 06:08:37.547849
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Unit test for function compile_general_ledger_program
    """
    pass

# Generated at 2022-06-12 06:08:47.690077
# Unit test for function build_general_ledger
def test_build_general_ledger():
    # TODO: I would like to be able to run the tests without loading the system
    # this means factoring out all the test data so it's separate from the db
    from .accounting import System

    from .accounts import Account, TerminalAccount

    from .journaling import Journal, JournalEntry, Posting, PostingDirection

    from .data import Country, Currency

    from ..commons.zeitgeist import DateRange

    from .numbers import Balance, Quantity

    from .journaling import JournalEntryStructure, SystemReadJournalEntries
    from .ledgering import SystemReadInitialBalances

    # Test data for general ledger build
    # Test date range
    date_range = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))
    # Test journal entries