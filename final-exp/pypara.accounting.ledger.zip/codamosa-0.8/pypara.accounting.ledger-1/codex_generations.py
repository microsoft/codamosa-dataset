

# Generated at 2022-06-12 06:00:06.428402
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from itertools import islice

    from src.accounting.algebras import ReadInitialBalances, ReadJournalEntries
    from src.accounting.domain import AccountBalance, AccountCode, AccountType, Journal, JournalEntry, Posting, build_journal_entry
    from src.accounting.ledgers import build_general_ledger

    ##
    ## Given:
    ##  * Accounting period for which the general ledger is built,
    ##  * an initial balance for the account,
    ##  * journal entries for that account,
    ##  * a function to read initial balances as of the end of previous financial period, and
    ##  * a function to read journal entries.
    ##
    period = DateRange(date(2018, 1, 1), date(2018, 1, 31))

# Generated at 2022-06-12 06:00:18.713499
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import JournalEntry, Posting, build_journal_entry
    from ..commons.error import LogicError

    # Setup accounts
    a = Account(1000, 'Cash')
    b = Account(100, 'Equity')
    c = Account(100, 'Equity', parent=b)

    # Setup and build journal entry
    entry = JournalEntry(datetime.date.today())
    entry.add(Posting(a, Amount(100)))
    entry.add(Posting(c, Amount(-100)))
    entry = build_journal_entry(entry)

    # Setup ledgers
    l1 = Ledger(a, Balance(datetime.date(2019, 12, 31), Quantity(0)))

# Generated at 2022-06-12 06:00:19.717426
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # Nothing to test.
    pass


# Generated at 2022-06-12 06:00:29.290546
# Unit test for method add of class Ledger
def test_Ledger_add():
    sut = Ledger('Asset','Opening Balance','Entries')
    test_posting = Posting()

    sut.add(test_posting)

    assert sut.posting == test_posting
    assert sut.balance == Quantity() + test_posting.amount * test_posting.direction.value
    assert sut.credit != 'None'
    assert sut.debit != 'None'
    assert sut.amount == test_posting.amount
    assert sut.is_credit == True
    assert sut.is_debit == False
    assert sut.cntraccts.count > 0
    assert sut.cntraccts[0] != 'None'
    assert sut.description != 'None'

# Generated at 2022-06-12 06:00:37.236706
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Create dummy ledger object
    ledger = Ledger(Account("test"),Balance(datetime.date(2020,5,10),Decimal(0)))
    ledger.add(Posting(Decimal(10),Account("test"),Account("test"),JournalEntry(datetime.date(2020,5,10),"test",Posting(Decimal(6),Account("test"),Account("test"),JournalEntry(datetime.date(2020,5,10),"test")))))
    assert ledger.entries[0].debit == 10
    assert ledger.entries[0].credit == None
    assert ledger.entries[0].balance == Decimal(10)
    

# Generated at 2022-06-12 06:00:47.702032
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    prev = datetime.date(year=2016, month=12, day=31)
    period = DateRange(since=prev + datetime.timedelta(days=1), until=prev.replace(year=prev.year + 1))

    accounts = [
        Account(1, 'Cash'),
        Account(2, 'Accounts receivable'),
        Account(3, 'Allowance for doubtful accounts'),
        Account(4, 'Accounts payable'),
        Account(5, 'Common stock'),
        Account(6, 'Revenue'),
        Account(7, 'Salaries'),
        Account(8, 'Sales'),
        Account(9, 'Salaries payable'),
        Account(10, 'Interest payable'),
    ]

# Generated at 2022-06-12 06:00:59.618559
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    def _read_initial_balances(period: DateRange):
        return {
            Account(code="1101", name="Cash"): Balance(period.since, Quantity(0)),
            Account(code="1102", name="Accounts receivable"): Balance(period.since, Quantity(0)),
        }


# Generated at 2022-06-12 06:01:06.722162
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .accounts import Account, Nature

    from .journaling import compose_journal_entry

    from .numbers import Amount, Quantity

    from .zeitgeist import DateRange

    ## Set up initial balances:

# Generated at 2022-06-12 06:01:09.164508
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # Tests that GeneralLedgerProgram___call__ returns a general ledger
    pass



# Generated at 2022-06-12 06:01:13.320308
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from typing import Dict
    from ..commons.numbers import Quantity

    @dataclass
    class ReadInitialBalancesImplementation(ReadInitialBalances):

        def __call__(self, period: DateRange) -> Dict[str, Balance]:
            return { "A": Balance(date(2018, 12, 31), Quantity(42)) }

    readInitialBalances = ReadInitialBalancesImplementation().__call__
    assert readInitialBalances(DateRange(date(2019,1,1), date(2019,1,31))) == { "A": Balance(date(2018, 12, 31), Quantity(42)) }


# Generated at 2022-06-12 06:01:36.170758
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Unit test for function compile_general_ledger_program.

    :return: None.
    """
    from ..accounts.algebra import ReadAccounts
    from ..accounts.models import Account
    from ..journaling.algebra import ReadJournalEntries
    from ..journaling.models import JournalEntry, Posting
    from ..commons.zeitgeist import date
    from ..commons.numbers import Amount
    from ..commons.algebra import Store

    ## Build a journal entry.
    def _build_journal(
        index: int,
        description: str,
        date: datetime.date,
        postings: List[Posting],
    ) -> JournalEntry:
        ## Build the journal entry:
        return JournalEntry(index, description, date, postings)

    ## Build a read-initial-balances program

# Generated at 2022-06-12 06:01:46.329305
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from ..commons.zeitgeist import Date
    from .accounts import AccountType, AccountTypes, AccountRegex, AccountClassifier

    ## Define test accounts:
    classifier = AccountClassifier(AccountTypes(AccountType("A", AccountRegex("^A.*"))), AccountTypes())
    period = DateRange(Date(2020, 1, 1), Date(2020, 12, 31))
    a_acct = Account("A1", classifier)
    b_acct = Account("B1", classifier)
    c_acct = Account("C1", classifier)

    ## Define test initial balances:
    initial_balances = {a_acct: Balance(period.since, Quantity(Decimal("0"))), b_acct: Balance(period.since, Quantity(Decimal("1")))}

    ## Define a call

# Generated at 2022-06-12 06:01:55.948274
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from .accounts import Account
    from .commons.zeitgeist import DateRange

    class _ReadInitialBalances(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {Account(101, Account.Type.EXPENSE): Balance(period.since, Quantity(0)),
                    Account(102, Account.Type.EXPENSE): Balance(period.since, Quantity(0))}

    _read_initial_balances = _ReadInitialBalances()
    _period = DateRange(datetime.date(2018, 4, 1), datetime.date(2018, 4, 30), True, True)


# Generated at 2022-06-12 06:02:07.104641
# Unit test for method add of class Ledger
def test_Ledger_add():
    """
    This is a unit test for method add of class Ledger.
    """

    # Import the required classes.
    from .accounts import Account
    from .commons import Direction
    from .journaling import Journal
    from .journaling import Posting

    # Create a journal.
    j = Journal("Transfer from savings to checking", datetime.date(2020, 1, 1))

    # Create two postings for the journal.
    p1 = Posting(j, Direction.DEBIT, Account("1234", "savings"), Amount(Decimal("1000")))
    p2 = Posting(j, Direction.CREDIT, Account("4321", "checking"), Amount(Decimal("1000")))

    # Create the ledger entry based on the posting.

# Generated at 2022-06-12 06:02:18.844110
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..books.accounts import create_account, AssetAccount, ExpenseAccount, LiabilityAccount
    from ..books.journaling import create_journal_entry, JournalEntry

    ## Create test accounts:
    Cash = AssetAccount("Cash")
    Inventory = AssetAccount("Inventory")
    Sales = ExpenseAccount("Sales")
    AccountsPayable = LiabilityAccount("Accounts Payable")
    AccountsReceivable = AssetAccount("Accounts Receivable")

    ## Create cash account balance at the beginning of the month:
    opening = {Cash: Balance(datetime.date(2020, 3, 1), 1000.00), AccountsReceivable: Balance(datetime.date(2020, 3, 1), 0.00)}

    ## Create test journal entries:

# Generated at 2022-06-12 06:02:20.217783
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-12 06:02:29.918193
# Unit test for method add of class Ledger
def test_Ledger_add():
    """
    JUnit test for add(self, posting: Posting[_T]) -> LedgerEntry[_T] of class Ledger
    """
    from .accounts import AccountList
    from .journaling import Journal, Posting, PostingDirection
    from .money import Money
    from ..commons.zeitgeist import Date
    from .common import EntryType, EntryState
    from .types import Transaction, Account
    from .submodules.payments import Payment
    from .submodules.supply import Shipment, Invoice
    
    account_list = AccountList()
    payment_payment = Payment(EntryType.PAYMENT, EntryState.STARTED, "", "", "", "", "", "", "", "", "", "")

# Generated at 2022-06-12 06:02:37.798561
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from ... import books

    ## Fixture:
    def _book(period: DateRange) -> books.Book:
        return books.Book(
            range=period,
            accounts=books.Accounts(),
            journals=books.Journals(),
            ## Stubs:
            initial_balances=lambda: {},
            read_journal_entries=lambda: [],
        )

    # Case: No account, no journal entry, no initial balance.
    b = _book(DateRange(date(2020, 1, 1), date(2020, 12, 31)))
    assert b.initial_balances() == {}

    # Case: No account and journal entry, no initial balance.
    b = _book(DateRange(date(2020, 1, 1), date(2020, 12, 31)))
    assert b.initial_balances() == {}



# Generated at 2022-06-12 06:02:46.788641
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .journaling import ReadJournalEntriesFromMemory

    @dataclass
    class _InMemoryInitialBalances:
        #: Initial balances.
        balances: InitialBalances

        def __call__(self, period: DateRange) -> InitialBalances:
            return self.balances

    ## Initial balances:
    initial_balances = InitialBalances({Account("a", "x"): Balance(datetime.date(2019, 1, 1), Quantity(1))})

    ## Journal entries:
    journal_entries = [
        JournalEntry(datetime.date(2019, 1, 1), "", [Posting(Account("a", "x"), Quantity(1), "d"), Posting(Account("b", "x"), Quantity(1), "c")])
    ]

    ## In-memory initial balances and journal entries readers:
    read_

# Generated at 2022-06-12 06:02:54.587733
# Unit test for method add of class Ledger
def test_Ledger_add():
    test_ledger_entries = Ledger(Account("Test-Account"), Balance(datetime.date(2019, 1, 1),Decimal(0)))

    test_ledger_entries.add(Posting(Account("Expenses"),
        Amount(Decimal(1)),
        datetime.date(2019, 9, 30),
        JournalEntry("Wages")
        ))

    assert test_ledger_entries.entries[0].balance == Decimal(-1)


# Generated at 2022-06-12 06:03:08.553166
# Unit test for method add of class Ledger
def test_Ledger_add():
    """
    The method add of class Ledger adds a new ledger entry.
    """
    # Prepare an empty ledger and a journal entry
    a = Account(Number="1000", Description="Asset")
    l = Ledger(a, Balance(datetime.date(2020,1,1), Decimal(0)))
    je = JournalEntry(datetime.date(2020,1,1), "test1", [Posting(a, Amount(Decimal(10000)), "Debit")])

    # Add the posting to the ledger
    le = l.add(je.postings[0])

    # The new ledger entry has the balance 10000
    assert le.balance == Decimal(10000)


# Generated at 2022-06-12 06:03:17.848051
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account, AccountType
    from .journaling import Posting, Transaction, Direction

    # Create an account
    account = Account(1, "Savings", AccountType.LIABILITY)

    # Create a ledger, with starting date and balance
    ledger = Ledger(account, Balance(datetime.date(2019, 1, 1), Quantity(Decimal('0.00'))))

    # Create a transaction with a debit and a credit posting
    transaction = Transaction(datetime.date(2019, 1, 1), "Paycheck")
    transaction.add(Posting(account, Direction.DEBIT, Quantity(Decimal('1000.00'))))
    transaction.add(Posting(account, Direction.CREDIT, Quantity(Decimal('1000.00'))))

    # Use the method add of the class Ledger

# Generated at 2022-06-12 06:03:24.552416
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    @dataclass
    class ReadInitialBalancesImpl:
        def __call__(self, period: DateRange) -> InitialBalances:
            return {}
    readInitialBalances = ReadInitialBalancesImpl()
    assert readInitialBalances(DateRange(
            datetime.date(2018, 1, 1),
            datetime.date(2018, 1, 31)
    )) == {}


# Generated at 2022-06-12 06:03:25.669586
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass



# Generated at 2022-06-12 06:03:33.244243
# Unit test for function build_general_ledger
def test_build_general_ledger():
    """
    Tests the implementation of build_general_ledger
    """

    from .accounts import Account, AccountNumber
    from .journaling import JournalEntry, Posting, Direction

    ## Create accounts:
    a1 = Account(AccountNumber(10, None), "Account1")
    a2 = Account(AccountNumber(20, None), "Account2")
    a3 = Account(AccountNumber(30, None), "Account3")
    a4 = Account(AccountNumber(40, None), "Account4")

    ## Create a journal entry:
    e = JournalEntry([
        Posting(a1, 1, Direction.Debit),
        Posting(a2, 1, Direction.Credit),
    ])

    ## Create another journal entry:

# Generated at 2022-06-12 06:03:42.071947
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..arrangement.algs import make_journal
    from ..arrangement.entities import Journal, JournalEntry as JE
    from ..arrangement.protocols import JournalAlgebra, ReadJournalEntries


    def _build_journal(date: datetime.date, amount: Amount, description: str) -> Journal:
        ## Define the journal entry:
        journal_entry: JournalEntry = JE(date, amount, description)

        ## Build and return the journal:
        return make_journal(journal_entry)



# Generated at 2022-06-12 06:03:52.133879
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import Journal, Posting
    from .books import Book, BookWriter, BookReader
    from .numbers import Decimal
    from stellar_sdk import Keypair, Network
    my_account = Account("MyAccount")
    my_posting = Posting(
        amount=Decimal("12.34"),
        account=my_account
    )
    my_journal = Journal(
        description="MyJournal",
        postings=[my_posting]
    )

# Generated at 2022-06-12 06:03:53.468560
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert True


# Generated at 2022-06-12 06:03:55.302904
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert False



# Generated at 2022-06-12 06:04:03.843001
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Create a single account ledger
    ledger = Ledger(Account("3001"), Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0))))
    # Create a journal entry
    je1 = JournalEntry(datetime.date(2020, 1, 1), "Test 1",
                   [Posting(Account("10000"), Quantity(Decimal("20000"))),
                    Posting(Account("3001"), Quantity(Decimal("-20000")))])
    # Add the posting of the journal entry to the ledger
    ledger.add(je1.postings[1])
    # Verify the content of the ledger entry
    assert ledger.entries[0].posting == je1.postings[1]
    assert ledger.entries[0].balance == Quantity(Decimal("-20000"))

# Generated at 2022-06-12 06:04:38.336251
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    @dataclass
    class _FakeJournalEntry:
        date: datetime.date
        postings: List[Posting[None]]

    @dataclass
    class _FakePosting:
        account: Account
        amount: Amount
        direction: int


# Generated at 2022-06-12 06:04:46.962527
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():

    # import pytest as pytest
    from .accounts import AccountType
    from .journaling import JournalEntry

    # Define test data

    class Dummy:
        def __init__(self):
            pass

        def __call__(self, period: DateRange) -> InitialBalances:
            return {"Cash": Balance(period.since, Amount(100000))}

    read_initial_balances = Dummy()
    read_journal_entries = lambda period: (
        JournalEntry(postings=[Posting(account="Cash", amount=Amount(100000), description="Test description")])
    )
    period = DateRange(since=datetime.date(2019, 1, 1), until=datetime.date(2019, 1, 1))

    # Compile the general ledger program
    compile_general_ledger_program1 = compile

# Generated at 2022-06-12 06:04:51.898402
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ._mocks import initial_balances, journal_entries
    from .journaling import Posting, journal_entry

    ## Prepare an instance of type for testing.
    p = compile_general_ledger_program(initial_balances, journal_entries)

    ## Define the expected output.

# Generated at 2022-06-12 06:05:01.927038
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from .accounts import AccountType

    result = ReadInitialBalances()(DateRange(since=datetime.date(2020, 1, 1), until=datetime.date(2020, 12, 31)))
    assert type(result) is dict
    assert all(type(key) is Account for key in result.keys())
    assert all(type(value) is Balance for value in result.values())

    result = ReadInitialBalances()(DateRange(since=datetime.date(2020, 1, 1), until=datetime.date(2020, 12, 31)))
    assert type(result) is dict
    assert all(type(key) is Account for key in result.keys())
    assert all(type(value) is Balance for value in result.values())



# Generated at 2022-06-12 06:05:10.763947
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # Decorator @dataclass makes this class a data class.
    # Basically, it generates __init__ method and allows us to
    # define custom __eq__  and __repr__ functions.
    @dataclass
    class MockReadInitialBalances:
        def __call__(self, period: DateRange) -> InitialBalances:
            return {account1: Balance(period.since, Quantity(500)), account2: Balance(period.since, Quantity(1000))}


# Generated at 2022-06-12 06:05:17.779203
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Arrange
    
    # Posting
    posting = Posting(Account("123", "Testaccount"), 1)
    
    # Ledger
    ledger = Ledger(Account("123", "Testaccount"), Balance("2020-01-01", 1))
    
    # Act
    ledger.add(posting)
    
    # Assert
    assert ledger.entries[0].balance == 2
    

# Generated at 2022-06-12 06:05:19.231896
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Tests function compile_general_ledger_program
    """
    pass

# Generated at 2022-06-12 06:05:31.547915
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .accounts import Account, create_account_type
    from .journaling import JournalType, Transaction, Posting
    from .journaling import JournalEntry, JournalLine
    from datetime import date

    at_income = create_account_type('income')
    at_balance = create_account_type('balance')
    at_expense = create_account_type('expense')

    acct_income = Account(at_income, 'income')
    acct_cash = Account(at_balance, 'cash')
    acct_expense = Account(at_expense, 'expense')


    cash_opening = Balance(date(2020, 1, 1), Quantity(Decimal(100)))
    cash_closing = Balance(date(2020, 12, 31), Quantity(Decimal(220)))

# Generated at 2022-06-12 06:05:40.788842
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import (
        BankingGiroJournal,
        BankStatementEntry,
        JournalEntryType,
        PaymentReference,
        PostingDirection,
    )

    account = Account(number="1234")
    posting = Posting(
        account=account,
        amount=Amount(Decimal(100)),
        direction=PostingDirection.Debit,
        journal=JournalEntry(
            date=datetime.date(2019, 1, 1),
            description="Test entry 1",
            journal_entry_type=JournalEntryType.Normal,
            postings=[
                Posting(
                    account=account,
                    amount=Amount(Decimal(100)),
                    direction=PostingDirection.Debit,
                    journal=None,
                )
            ],
        ),
    )

    ledger

# Generated at 2022-06-12 06:05:49.169547
# Unit test for method add of class Ledger
def test_Ledger_add():
    date1 = datetime.date(2019, 1, 10)
    date2 = datetime.date(2019, 1, 20)
    account1 = Account("1150", "Cash", Quantity(Decimal(0)))
    account2 = Account("4000", "Retained Earnings", Quantity(Decimal(0)))
    account3 = Account("3000", "Revenue", Quantity(Decimal(0)))
    account4 = Account("1000", "Assets", Quantity(Decimal(0)))
    balance1 = Balance(date1, Quantity(Decimal(1000)))
    balance2 = Balance(date1, Quantity(Decimal(0)))
    amount1 = Amount(Decimal(50))
    quantity1 = Quantity(Decimal(0))
    quantity2 = Quantity(Decimal(50))
    quantity3 = Quantity(Decimal(1050))
    ledger

# Generated at 2022-06-12 06:06:24.841629
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import Month
    from .assets import Assets
    from .accounts import Account
    from .general_ledger import GeneralLedger, Entry, build_general_ledger

    # Define dummy algebra functions:
    def read_initial_balances(period: Month) -> Dict[Account, Balance]:
        return {Account.from_string("A/A"): Balance(period.since, Quantity(0))}

    def read_journal_entries(period: Month) -> Assets:
        return [
            Entry(period.since, "expense", [("SEK:Expense", Quantity(1))]),
            Entry(period.since, "income", [("SEK:Income", Quantity(-1))]),
        ]

    # Compile the program:
    ledger_program = compile_general_ledger_program

# Generated at 2022-06-12 06:06:33.914536
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import Journal, Posting

    ledger = build_general_ledger(
        DateRange(datetime.date(year=2018, month=1, day=1), datetime.date(year=2018, month=12, day=31)),
        [Journal(datetime.date(year=2018, month=1, day=1), "Recievable account", [Posting("Receivable", 100)])],
        {},
    )
    assert list(ledger.ledgers.values())[0].entries[0].balance == 100

# Generated at 2022-06-12 06:06:46.087913
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from ..commons.zeitgeist import str2date
    from ..commons.numbers import a, q
    from .accounts import Account, Constant
    from ..journaling import Journal, Posting, JournalEntry, Direction
    from .generic import Balance

    period = DateRange(s=str2date('2020-01-01'), u=str2date('2021-12-31'))


# Generated at 2022-06-12 06:06:57.238997
# Unit test for function build_general_ledger
def test_build_general_ledger():
    """
    Unit test for function build_general_ledger
    """
    from ..commons.zeitgeist import now
    from .accounts import AccountType, AccountID
    from .journaling import JournalEntry

    ## Mocking journal entries:

# Generated at 2022-06-12 06:07:04.726473
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .algebras import initial_balances_from, journal_entries_from
    from .journaling import journal_entry_from, Posting, PostingDirection

    ## Given a read_initial_balances algebra implementation
    initial_balances = {Account("a", "1010"): Balance(datetime.date(2010, 1, 1), Quantity(Decimal(1000)))}
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return initial_balances_from(initial_balances)
    ## And a read_journal_entries algebra implementation

# Generated at 2022-06-12 06:07:12.533781
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from datetime import date
    from decimal import Decimal as D
    from ..commons import zeitgeist
    from .accounts import NormalAccount
    from .journaling import Journal, Posting
    from .ledgers import build_general_ledger
    from .typing import LedgerProgram

    class JournalRow:
        date: date
        description: str
        debit: D
        credit: D
        cash: D
        inventory: D


# Generated at 2022-06-12 06:07:21.511539
# Unit test for method add of class Ledger
def test_Ledger_add():
    """
    Test case for method add of class Ledger
    """
    # Setup
    period = DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31))
    d = datetime.date(2018, 1, 1)
    initial_balances = {Account("1001"): Balance(period.since, Quantity(Decimal(8000)))}
    journal_entries = [JournalEntry(d, "Expenses of the opening", [Posting(Account("1001"), Quantity(Decimal(4000)), d, "Debit")])]
    # Run method
    ledger = build_general_ledger(period, journal_entries, initial_balances).ledgers["1001"]
    # Check result

# Generated at 2022-06-12 06:07:32.125092
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Create test case
    unittest.TestCase()

    # Create the test ledger
    ledger = Ledger(account = 7, initial = Balance(datetime(2015, 1, 1), 0))

    # Create the test journal
    journal = JournalEntry(
        date = datetime(2015, 1, 1),
        description = "Test",
        postings = [
            Posting(account = 7, debit = 1000, label = "debit_label", description = "debit_description"),
            Posting(account = 8, credit = 1000, label = "credit_label", description = "credit_description")
        ]
    )

    # Create the test posting
    posting = journal.postings[0]

    # Call the function
    entry = ledger.add(posting)

    # Check the result

# Generated at 2022-06-12 06:07:41.817539
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import JournalEntry, Posting

    # Define test accounts
    a1 = Account('1', 'Account 1')
    a2 = Account('2', 'Account 2')

    # Define test posting
    p1 = Posting('1', a1, 1, '2018-01-01', 'Memo 1')
    p2 = Posting('2', a2, 1, '2018-01-01', 'Memo 2')

    # Define test journal entry
    j1 = JournalEntry('1', '2018-01-01', 'Memo 1', [p1, p2])

    # Define test ledger
    l1 = Ledger(a1, None)

    # Add posting to ledger
    le1 = l1.add(p1)

    # Test posting to ledger
   

# Generated at 2022-06-12 06:07:43.244802
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-12 06:09:21.422003
# Unit test for function build_general_ledger
def test_build_general_ledger():
    ## Imports:
    import random
    import string

    ## All accounts:
    accounts = [Account(i) for i in range(1, 100)]

    ## Initial balances:
    opening = {accounts[i]: Balance(datetime.date(2017, 1, 1), Quantity(i)) for i in range(0, 12)}

    ## Random postings:
    journal = []
    for i in range(0, 1000):
        account = random.choice(accounts)

        amount = random.randint(-100, 100)

        journal.append(Posting(datetime.date(2017, random.randint(1, 12), random.randint(1, 28)), account, amount))

# Generated at 2022-06-12 06:09:30.413073
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .accounts import Assets, Expenses, Liabilities, Revenue
    from .journaling import (
        Cash,
        create_general_journal,
        create_journal,
        create_journal_entry,
        create_posting,
        create_variable_general_journal,
    )
    from .segments import Currency

    cash = Cash(Currency.USD)
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

# Generated at 2022-06-12 06:09:33.100335
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert False, "Not implemented"



# Generated at 2022-06-12 06:09:39.042092
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..journaling.inmemory import ReadJournalEntries as ReadJournalEntriesInMemory
    from ..journaling.inmemory import Posting as PostingInMemory
    from ..journaling.inmemory import JournalEntry as JournalEntryInMemory
    from ..journaling.inmemory import Journal as JournalInMemory
    from ..accounts.inmemory import Account as AccountInMemory
    from ..commons.zeitgeist import DateRange
    from ..commons.numbers import Amount as AmountInMemory
    from datetime import date
    from typing import List,Dict
    

# Generated at 2022-06-12 06:09:48.507388
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Unit test for function compile_general_ledger_program.
    """

    ## Mock the implementation of ReadInitialBalances:
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        ## Return the mock initial balances:
        return {
            Account("Assets", "Cash"): Balance(period.since, Quantity(Decimal(0))),
            Account("Assets", "Inventory"): Balance(period.since, Quantity(Decimal(0))),
            Account("Liabilities", "Accounts Payable"): Balance(period.since, Quantity(Decimal(0))),
            Account("Equity", "Retained Earnings"): Balance(period.since, Quantity(Decimal(0))),
        }

    ## Mock the implementation of ReadJournalEntries:

# Generated at 2022-06-12 06:09:58.451029
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from datetime import date
    from unittest import TestCase, main
    from unittest.mock import Mock

    from ..commons.zeitgeist import DateRange
    from ..journaling.amounts import Cash
    from ..journaling.journal import Journal
    from ..journaling.posting import Posting, PostingDirection

    # Define test case class:
    class Test(TestCase):
        def test(self):
            # given
            read_initial_balances = Mock(__call__=Mock(return_value={}))