

# Generated at 2022-06-12 06:00:07.482777
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Unit test for the method __call__ of GeneralLedgerProgram.
    """
    import datetime
    from decimal import Decimal
    from dataclasses import dataclass
    from typing import Dict, List
    from ..commons.numbers import Quantity
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .preparing import build_general_ledger, compile_general_ledger_program, GeneralLedger, read_initial_balances
    from .reporting import balance_sheet
    from .types import Direction

    # Defines custom journal entry:
    @dataclass
    class MyJournalEntry(JournalEntry):
        """
        An example journal entry.
        """

        #: Transaction descriptor.
        descr: str

    # Def

# Generated at 2022-06-12 06:00:19.590909
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..books.simple_double_entry import Credit, Debit, Direction

    from ..books.accounts import Account, AccountType, build_chart_of_accounts


# Generated at 2022-06-12 06:00:20.182007
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass

# Generated at 2022-06-12 06:00:20.884063
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    ...

# Generated at 2022-06-12 06:00:21.908606
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    dummy test function
    """
    pass

# Generated at 2022-06-12 06:00:31.739628
# Unit test for method add of class Ledger
def test_Ledger_add():
    account = Account('1000')
    initial_balance = Balance(date=datetime.date(2018,1,1), value=0.0)
    ledger = Ledger(account, initial_balance)
    expected_ledger_size = 1
    entry = ledger.add(Posting(account, datetime.date(2018,1,1), Amount(100), True))
    assert ledger.entries[0].posting.amount == 100 and ledger.entries[0].balance == 100 and len(ledger.entries) == 1
    entry = ledger.add(Posting(account, datetime.date(2018,3,1), Amount(100), True))
    assert ledger.entries[1].posting.amount == 100 and ledger.entries[1].balance == 200 and len(ledger.entries) == 2

# Generated at 2022-06-12 06:00:32.343081
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass

# Generated at 2022-06-12 06:00:37.500734
# Unit test for method add of class Ledger
def test_Ledger_add():
    """
    Unit test for method add of class Ledger
    """
    # Setup ledger and posting
    account = Account("1001","Cash")
    ledger = Ledger(account, Balance(Decimal(100)))
    posting = Posting(account,Decimal(10),Decimal(1.5))

    # Add posting to ledger
    ledger.add(posting)

    # Test
    assert ledger.entries[0].balance == 110.5

# Generated at 2022-06-12 06:00:47.734190
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from datetime import date
    from genledger import GL

    ## Define the general ledger program:
    program = compile_general_ledger_program(
        read_initial_balances=lambda period: GL.initial_balances(period.since, period.until),
        read_journal_entries=lambda period: GL.journal_entries(period.since, period.until),
    )

    # Let's define an accounting period:
    period = DateRange(since=date(2019, 1, 1), until=date(2019, 2, 1))

    # Invoke the program:
    gl = program(period)

    # Assert the period:
    assert gl.period == period

    # Assert initial balances:
    assert gl.ledgers["1"].initial.date == date(2018, 12, 31)

# Generated at 2022-06-12 06:00:59.616145
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from ..commons.zeitgeist import Date, DateTime
    from datetime import timedelta
    from decimal import Decimal
    from ..commons.numbers import Amount, Quantity
    from ..commons.accounts import Account
    import sys
    from ..commons.persistence import Memory, Transaction
    from .accounts import Balance, read_balances as _read_balances
    from .capture import LedgerEntry as _LedgerEntry
    from .journaling import Journal, JournalEntry, Posting, round_amount
    from gin_fixtures.commons import gin
    from ..commons.zeitgeist import DateRange
    def test_ReadInitialBalances___call___do(data_store, init_balances):
        item: ReadInitialBalances = data_store

# Generated at 2022-06-12 06:01:14.041316
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from .accounts import AccountIdentity
    from .commons.test_utils import TimeMachine

    now = datetime.date(2018, 1, 2)
    initial_balances = {
        Account("Assets", "Cash & Bank", AccountIdentity("101")): Balance(now, Quantity(Decimal("8.54"))),
        Account("Assets", AccountIdentity("101")): Balance(now, Quantity(Decimal("8.54"))),
        Account("Expense", AccountIdentity("136")): Balance(now, Quantity(Decimal("132.00"))),
    }

    def test_subject(period: Optional[DateRange]) -> InitialBalances:
        return initial_balances

    with TimeMachine(now):
        assert test_subject(None) == initial_balances


# Generated at 2022-06-12 06:01:15.377922
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass # TODO


# Generated at 2022-06-12 06:01:25.958479
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Test the compiler output.
    """

    ## Mocked dependencies:
    initial_balances = {
        Account("10000000"): Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0))),
        Account("15000000"): Balance(datetime.date(2020, 1, 1), Quantity(Decimal(982))),
        Account("20000000"): Balance(datetime.date(2020, 1, 1), Quantity(Decimal(564))),
    }


# Generated at 2022-06-12 06:01:37.197975
# Unit test for function build_general_ledger
def test_build_general_ledger():
    import datetime

    from src.kata.journaling.tests.fakes import FakeJournaling
    from src.kata.ledger.models import (
        Balance,
        build_general_ledger,
        compile_general_ledger_program,
    )

    ## Build a DateRange:
    period = DateRange(since=datetime.date(year=2018, month=11, day=1), until=datetime.date(year=2018, month=12, day=31))

    ## Build a fake journaling:
    journaling = FakeJournaling()

    ## Compile the program:
    program = compile_general_ledger_program(journaling.initial_balances, journaling.journal_entries)

    ## Generate and assert the general ledger:
    general_ledger = program(period)

    ## Assert

# Generated at 2022-06-12 06:01:38.917149
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():

    def __call__(self, period: DateRange) -> InitialBalances:
        pass



# Generated at 2022-06-12 06:01:48.118976
# Unit test for function build_general_ledger
def test_build_general_ledger():
    A = Account.from_str("A")
    B = Account.from_str("B")

    from .journaling import JournalEntry, Posting

    #
    # Case 1
    #

# Generated at 2022-06-12 06:01:53.204568
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # Test data:
    class _ReadInitialBalances:
        def __call__(self, period: DateRange) -> InitialBalances:
            pass

    # Mocks:
    read_initial_balances = _ReadInitialBalances()

    # Test cases:
    class _Test:
        def test_ReadInitialBalances___call__(self):
            period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))
            read_initial_balances(period)
            read_initial_balances.__call__.assert_called_once_with(period)

    # Execute tests:
    _Test.test_ReadInitialBalances___call__(_Test())


# Generated at 2022-06-12 06:01:54.188206
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-12 06:02:05.887796
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from decimal import Decimal

    from ..commons.numbers import Amount
    from ..commons.zeitgeist import DateRange

    from .accounts import Account, Assets, Expenses, Liabilities, Revenues
    from .direction import Credit, Debit
    from .generic import Balance
    from .journaling import Journal

    ## Build initial balances:
    initial = {Assets.cash: Balance(date(2020, 1, 1), Decimal(100)), Revenues.sales: Balance(date(2020, 1, 1), Decimal(300))}

    ## Build journal entries:

# Generated at 2022-06-12 06:02:17.918827
# Unit test for function build_general_ledger

# Generated at 2022-06-12 06:02:43.426398
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():

    # Mocks:
    def read_initial_balances(period):
        return {
            Account("A"),
            Account("B"),
            Account("C"),
            Account("D"),
            Account("E"),
            Account("F"),
            Account("G"),
            Account("H"),
            Account("I"),
            Account("J"),
        }


# Generated at 2022-06-12 06:02:55.590785
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry
    from .accounts import Account
    from .commons.numbers import Amount, Quantity
    from .commons.zeitgeist import DateRange
    from .journals import Journal
    from .posts import Posting, Direction

    _READ_INITIAL_BALANCES = {
        Account.ASSET.CASH: Balance(Decimal(1), Quantity(1)),
        Account.ASSET.BANK: Balance(Decimal(2), Quantity(2)),
        Account.ASSET.AR: Balance(Decimal(3), Quantity(3)),
    }

# Generated at 2022-06-12 06:03:07.055731
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .accounts import Account
    from .journaling import JournalEntry, Posting, build_journal_entry, charge, create_account
    from .types import chart_of_accounts
    from ..commons.zeitgeist import DateRange, since, until

    ## Create accounts required:
    cash = create_account("Cash", chart_of_accounts.asset)
    revenue = create_account("Revenue", chart_of_accounts.revenue)
    expense = create_account("Expense", chart_of_accounts.expense)

    ## Create sample journal entries:

# Generated at 2022-06-12 06:03:16.155495
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """Unit test for method __call__ of class GeneralLedgerProgram."""
    from contextlib import ExitStack
    from dataclasses import replace
    from unittest.mock import Mock, patch
    from ..commons.zeitgeist import DateRange
    from ..journaling import JournalEntry
    from ..accounting.accounts import Account, AccountType
    from ..accounting.ledgering import build_general_ledger, ReadInitialBalances, ReadJournalEntries
    from ..accounting.ledgering import compile_general_ledger_program

    ## Define test data:
    DUMMY_DATE_RANGE = DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 1, 31))

# Generated at 2022-06-12 06:03:17.723067
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    ## TODO: implement post.
    assert True

# Generated at 2022-06-12 06:03:29.259169
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from ..algebras.initial_balances import read_initial_balances
    from ..algebras.journaling import read_journal_entries
    from ..types import PostingType
    from ..types.accounts import ASSET
    from ..types.dates import DateTimeSpan
    from ..types.descriptions import Description
    from ..types.journals import Journal
    from ..types.postings import Posting
    from datetime import datetime
    from decimal import Decimal
    
    # Create journal entries.

# Generated at 2022-06-12 06:03:36.667233
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from ..commons.numbers import Amount, Balance, Quantity
    a=Account("A")
    b=Account("B")
    c=Account("C")
    d=Account("D")
    class A(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {a: Balance(period.since, Quantity(1)), b: Balance(period.since, Quantity(2)), c: Balance(period.since, Quantity(3))}

# Generated at 2022-06-12 06:03:42.837562
# Unit test for method add of class Ledger
def test_Ledger_add():
  account1 = Account()
  amount = Amount(500)
  initial = Balance(datetime.date(2010, 12, 30), (1000))
  journal = JournalEntry(datetime.date(2011, 1, 1), "test_desc")
  journal.post(account1, amount)

  ledger = Ledger(account1, initial)
  ledger.add(journal.postings[0])

  assert ledger.entries[0].balance == 1500

# Generated at 2022-06-12 06:03:52.643220
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Tests the compile_general_ledger_program function.
    """

    from dataclasses import dataclass
    from decimal import Decimal
    from typing import Dict, Iterable, List
    from unittest import TestCase, main
    from unittest.mock import Mock
    from .commons.zeitgeist import DateRange
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting, ReadJournalEntries

    ## Mocked runtime:
    class MockRuntime:
        def __init__(self):
            pass

    mock_rt = MockRuntime()

    ## Mocked account balances:
    @dataclass
    class MockBalances:
        account: Account
        balance: Balance


# Generated at 2022-06-12 06:03:54.413678
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-12 06:04:18.751879
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    class _ReadJournalEntriesProtocol(_T):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            pass

    class _ReadInitialBalancesProtocol(_T):
        def __call__(self, period: DateRange) -> InitialBalances:
            pass

    _read_journal_entries: _ReadJournalEntriesProtocol = compile_read_journal_entries()
    _read_initial_balances: _ReadInitialBalancesProtocol = compile_read_initial_balances()
    _program = compile_general_ledger_program(_read_initial_balances, _read_journal_entries)

    assert callable(_program)

# Generated at 2022-06-12 06:04:28.448520
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import Journal, Posting, ReadJournalEntries, journaling

    def _program(period: DateRange) -> GeneralLedger[Journal]:
        """
        Consumes the opening and closing dates and produces a general ledger.

        :param period: Accounting period.
        :return: A general ledger.
        """

        ## Get initial balances as of the end of previous financial period:
        initial_balances = dict()

        ## Read journal entries and post each of them:

# Generated at 2022-06-12 06:04:39.510110
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import to_date
    from .accounts import Account, AccountType
    from .journaling import JournalEntry
    from .types import empty_journal_entry_repository, empty_initial_balances_reader
    from .types.initial_balances import InitialBalances
    from .types.journal_entries import JournalEntries
    from .types.period import Period

    ## Set up fixtures.
    opening = to_date("2020/01/01")
    closing = to_date("2020/12/30")


# Generated at 2022-06-12 06:04:47.812779
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # Inputs
    period_since = "2019-04-01"
    period_until = "2019-04-30"
    account_1 = "10-1100.00"
    balance_1 = "100.00"
    account_2 = "10-1200.00"
    balance_2 = "200.00"
    account_3 = "10-1300.00"
    balance_3 = "300.00"
    account_4 = "10-1400.00"
    balance_4 = "-400.00"
    account_5 = "10-1500.00"
    balance_5 = "-500.00"
    journal_description = "description"
    journal_date = "2019-04-15"
    journal_account_1 = "20-2100.00"

# Generated at 2022-06-12 06:04:50.747190
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass

# Generated at 2022-06-12 06:04:58.441479
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from datetime import date
    from decimal import Decimal
    from typing import List, Dict
    from .journaling import JournalEntry, Posting, Journal, JournalReader, JournalWriter
    from .accounts import Account, AccountType
    from .generic import Balance, BalanceType, BalanceReader
    from .commons.numbers import Quantity
    from .commons.zeitgeist import DateRange
    from .enrichment.enrich_transactions import enrich_transactions
    import tempfile
    import os
    import csv
    import json
    import re

    ## Program definition:
    def _program(period: DateRange) -> GeneralLedger:
        ## Get initial balances as of the end of previous financial period:
        initial_balances = read_initial_balances(period)

        ## Read journal entries and post each of them:
        journal_

# Generated at 2022-06-12 06:05:01.575584
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    assert callable(compile_general_ledger_program)
    assert hasattr(compile_general_ledger_program(ReadInitialBalances, ReadInitialBalances), "__call__")

# Generated at 2022-06-12 06:05:10.549705
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..finance.accounts import Equity, Revenue, Cash, Receivables, GoodsSold, Expenses
    from ..finance.journaling import Journal, StandardPosting, JournalEntry, PostingDirection
    from ..commons.zeitgeist import Date
    from decimal import Decimal
    from typing import Dict, List, Tuple
    ledger = Ledger(Equity, Balance(Date(12, 12, 2019), Quantity(Decimal(0))))
    journal = Journal('Test Journal')
    journal_entry = JournalEntry(Date(12, 12, 2019), 'Test Journal Entry', [
        StandardPosting(Revenue, PostingDirection.CREDIT, Quantity(Decimal(10.0))),
        StandardPosting(Cash, PostingDirection.DEBIT, Quantity(Decimal(10.0))),
    ])
    journal.add_

# Generated at 2022-06-12 06:05:13.698930
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    class ReadInitialBalancesImpl:
        def __call__(self, period: DateRange) -> InitialBalances:
            pass

    ReadInitialBalancesImpl()



# Generated at 2022-06-12 06:05:23.017597
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():

    # Creating a dataclass object of GeneralLedgerProgram
    m = compile_general_ledger_program(
        read_initial_balances = read_initial_balances(),
        read_journal_entries = read_journal_entries()
    )

    # Testing the value of calling the function compiled_general_ledger_program.

# Generated at 2022-06-12 06:06:24.865956
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-12 06:06:26.841216
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    ...

# Generated at 2022-06-12 06:06:36.701000
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from dataclasses import asdict, field
    from datetime import date
    from decimal import Decimal
    from datetime import datetime

    # Defines a type variable.
    T = TypeVar("T")

    @dataclass
    class DummyReadInitialBalances(ReadInitialBalances):
        """
        Dummy implementation of the algebra ReadInitialBalances for unit testing purposes.
        """

        # Predefined response to be returned by the algebra.

# Generated at 2022-06-12 06:06:46.922328
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """Tests method __call__ of class GeneralLedgerProgram."""

    # Import
    from datetime import date
    from decimal import Decimal
    from time import time

    # Setup:
    # - Create a mock implementation of algebra which reads initial
    #   ledger balances.
    # - Create a mock implementation of algebra which reads journal
    #   entries.
    # - Compile the program.
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("1010"): Balance(date(2021, 1, 1), Quantity(Decimal(100))),
            Account("1020"): Balance(date(2021, 1, 1), Quantity(Decimal(80))),
        }


# Generated at 2022-06-12 06:06:58.271191
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    import datetime
    from decimal import Decimal
    from journaling import JournalEntry
    from typing import List
    from unittest import TestCase
    from ..commons.numbers import Amount, Quantity, Balance

    from .accounts import Account
    from .journaling import Posting
    from .ledgers import (
        ReadInitialBalances,
        ReadJournalEntries,
        GeneralLedger,
        GeneralLedgerProgram,
        Ledger,
        LedgerEntry,
        build_general_ledger,
        compile_general_ledger_program,
    )

    #: Dummy read initial balances algebra implementation:

# Generated at 2022-06-12 06:06:58.892954
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass

# Generated at 2022-06-12 06:07:08.892571
# Unit test for function build_general_ledger
def test_build_general_ledger():
    """
    Test build_general_ledger.

    The general ledger is populated with data and the balance of the corresponding account is checked at the end.
    """
    from ..journaling.algebras import JournalEntryAlgebra

    ## Create an instance of the accounting journal algebra:
    algebra = JournalEntryAlgebra()

    ## Create an account:
    account = algebra.account(1, "Cash")

    ## Create some postings:
    posting_1 = algebra.posting(algebra.debit(account, Amount(1000)), DateRange(since=datetime.date(2019, 10, 1)))
    posting_2 = algebra.posting(algebra.credit(account, Amount(800)), DateRange(since=datetime.date(2019, 10, 2)))

# Generated at 2022-06-12 06:07:19.150416
# Unit test for function build_general_ledger
def test_build_general_ledger():
    """
    Test build_general_ledger
    """

    # TODO: extend this test

    # Define a test JournalEntry
    test_posting = Posting(
        date=datetime.date(2019,1,1),
        direction="DEBIT",
        account="A-401",
        amount=Decimal(100),
        journal="J-0001"
    )

    test_journal_entry = JournalEntry(
        date=datetime.date(2019,1,1),
        description="test journal entry",
        postings=[test_posting]
    )

    test_period = DateRange(
        since=datetime.date(2019,1,1),
        until=datetime.date(2019,1,1)
    )


# Generated at 2022-06-12 06:07:30.923660
# Unit test for function build_general_ledger
def test_build_general_ledger():

    '''
    First, generate your journal
    '''

    # Date range for the general ledger
    date_range = DateRange('2017-01-01', '2018-12-31')

    # Initial balance of terminal accounts

# Generated at 2022-06-12 06:07:41.138902
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # Assert
    from .test_algebras import ReadInitialBalances as Actual
    from .test_algebras import (
        Algebra,
        Account,
        Amount,
        Balance,
        InitialBalances,
        Quantity,
        BalanceSheet,
    )

    from datetime import date

    from ..commons.zeitgeist import DateRange

    # Arrange

# Generated at 2022-06-12 06:09:15.394563
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-12 06:09:24.605088
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Unit test for function compile_general_ledger_program.
    """

    ## Define algebra implementations:
    def read_initial_balances(period: DateRange):
        return {Account("1"): Balance(period.since, Quantity(Decimal("10"))), Account("2"): Balance(period.since, Quantity(Decimal("10")))}

    def read_journal_entries(period: DateRange):
        return [
            JournalEntry(period.since, "Test", [Posting(period.since, Account("1"), Amount(Decimal("1")), True), Posting(period.since, Account("2"), Amount(Decimal("1")), False)])
        ]

    ## Compile the program:
    program = compile_general_ledger_program(read_initial_balances, read_journal_entries)

# Generated at 2022-06-12 06:09:32.522665
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..journaling.algebras import post_journal_entry
    from ..journaling.models import JournalEntryType

    # Test case 1:
    # Create a journal entry
    journal_entry = JournalEntry(
        date = datetime.date(2020, 8, 1),
        description = "test description",
        type = JournalEntryType.GENERAL_JOURNAL,
        postings = [
            Posting(Account.get("5000", "90"), datetime.date(2020, 8, 1), Amount(100)),
            Posting(Account.get("4000", "99"), datetime.date(2020, 8, 1), Amount(100))
        ]
    )

    # Post the journal entry:
    post_journal_entry(journal_entry)

    # Create the ledger:

# Generated at 2022-06-12 06:09:38.663347
# Unit test for function build_general_ledger
def test_build_general_ledger():
    """
    Unit test for function build_general_ledger.
    """

    import random

    from .accounts.factory import BasicAccounting
    from .accounts.model import BasicAccountingAccount

    from ..commons.zeitgeist import DateRange
    from .journaling import JournalEntry, Posting, Transaction

    from ..commons.lut import make_lut
    from ..commons.numbers import Balance, Amount, Quantity

    ## Prepare the accounting model:
    _, accounts = BasicAccounting(tuple())

    ## Prepare the accounting period:
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))

    ## Prepare initial balances:

# Generated at 2022-06-12 06:09:40.440079
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Unit test for function compile_general_ledger_program.
    """
    pass

# Generated at 2022-06-12 06:09:43.087124
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from ..books.algebra import read_initial_balances

    read_initial_balances()(DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31)))



# Generated at 2022-06-12 06:09:44.413404
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    pass
    #TODO: Implement function test_compile_general_ledger_program

# Generated at 2022-06-12 06:09:45.477176
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass # TODO


# Generated at 2022-06-12 06:09:51.336475
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    """
    Tests method __call__ of class ReadInitialBalances
    """
    from datetime import date

    from ..examples import contrived

    # Get the contrived algebra.
    alg = contrived.get_algebra()

    # Compile the program which builds general ledger.
    build_general_ledger_program = compile_general_ledger_program(alg.read_initial_balances, alg.read_journal_entries)

    # Execute the program.
    general_ledger = build_general_ledger_program(DateRange(date(2020, 1, 1), date(2020, 12, 31)))

    # Check if expected leadsgers are present.
    assert general_ledger.ledgers[alg.accounts.cash] is not None