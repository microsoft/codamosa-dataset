

# Generated at 2022-06-12 06:00:03.859781
# Unit test for method add of class Ledger
def test_Ledger_add():
    d = datetime.datetime.strptime("2020-02-01",'%Y-%m-%d')
    j = JournalEntry(d, "Test", [Posting(d, Account("a"), Amount(2), "", "", "")])
    p = Posting(d, Account("a"), Amount(2), "", "", "")
    e = Ledger(Account("a"),Balance(d,Quantity(1)))
    assert e.entries == []
    assert e.add(p) == LedgerEntry(e, p, Quantity(3))
    assert e.entries[-1].ledger == e
    assert e.entries[-1].posting == p
    assert e.entries[-1].balance == Quantity(3)


# Generated at 2022-06-12 06:00:16.350908
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Setup
    from ..journaling.test.test_context import test_journaling_context
    from ..ledgering.test.test_context import test_ledgering_context
    journaling_context = test_journaling_context()
    ledgering_context = test_ledgering_context(journaling_context)
    date = datetime.datetime.now().date()
    posting = journaling_context.posting_factory.create(field_history=journaling_context.field_history,
                                                        id="id_" + __name__,
                                                        account=ledgering_context.assets,
                                                        direction="Dr",
                                                        amount=Decimal(500),
                                                        date=date)

# Generated at 2022-06-12 06:00:23.584802
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Create Account object for the ledger
    acc1 = Account("100", "Receivable")
    # Create Balance object for the ledger
    balance1 = Balance(datetime.date(2018, 9, 5), -500)
    # Create Ledger object using Account and Balance objects
    ledger1 = Ledger(acc1, balance1)
    
    # Create Account object for the Posting
    acc2 = Account("200", "Sales")
    # Create Journal object for the Posting
    journal1 = JournalEntry(datetime.date(2018, 9, 6), "Sale of 10 units @ $100")
    # Add Postings to the Journal object
    journal1.add(Posting(acc1, -1000, journal1))
    journal1.add(Posting(acc2, 1000, journal1))
    # Create Posting using the Journal object
   

# Generated at 2022-06-12 06:00:24.448149
# Unit test for function build_general_ledger
def test_build_general_ledger():
    pass

# Generated at 2022-06-12 06:00:27.780965
# Unit test for function build_general_ledger
def test_build_general_ledger():
    """
    Testing function build_general_ledger.
    """
    budget = 0
    debit = 1
    credit = -1
    GL = build_general_ledger
    GL(DateRange(None, None), [], {})



# Generated at 2022-06-12 06:00:28.365419
# Unit test for function build_general_ledger
def test_build_general_ledger():
    pass

# Generated at 2022-06-12 06:00:30.536862
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # Initialize the test variable
    test = None

    # Compare test variable with expected variable
    assert test == None, (
        f"Test variable 'test' is not initialized."
    )

    # Update the test variable
    test = True

    # Compare test variable with expected variable
    assert test == True, (
        f"Test variable 'test' is not equal to expected variable."
    )


# Generated at 2022-06-12 06:00:38.960599
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .commons import safe_build_accounting_period
    from .journaling import JournalEntry
    from .typing import AccountId
    from .values import AccountValue
    import datetime
    from decimal import Decimal
    from typing import List, Tuple
    _period: DateRange = safe_build_accounting_period(datetime.date(2014, 1, 1), datetime.date(2014, 12, 31))
    ## Initial balances:
    _initial_balances: List[Tuple[AccountId, Balance]] = [(1001, Balance(datetime.date(2013, 12, 31), Quantity(Decimal("5000.00")))), (1002, Balance(datetime.date(2013, 12, 31), Quantity(Decimal("5000.00"))))]

# Generated at 2022-06-12 06:00:48.399472
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from examples.accounting.accounts import ACCOUNTS

    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 22))
    initial = {
        ACCOUNTS.cash: Balance(period.since, Quantity(Decimal(1000))),
        ACCOUNTS.equity.retained_earnings: Balance(period.since, Quantity(Decimal(1000))),
    }

# Generated at 2022-06-12 06:00:49.050417
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    pass

# Generated at 2022-06-12 06:01:06.343639
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    """
    Unit test for method __call__ of class ReadInitialBalances
    """
    # pylint: disable=W0612
    class Fake_ReadInitialBalances(ReadInitialBalances):
        """
        Fake implementation of class ReadInitialBalances
        """
        def __call__(self, period: DateRange) -> Dict[Account, Balance]:
            return {}

        @staticmethod
        def _test_method(period: DateRange) -> Dict[Account, Balance]:
            """
            Fake implementation of method __call__ of class ReadInitialBalances
            """
            return {}

    assert Fake_ReadInitialBalances()._test_method(DateRange(datetime.date(2017, 1, 1), datetime.date(2017, 12, 31))) == {}


# Generated at 2022-06-12 06:01:16.418212
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests the method __call__ of the class GeneralLedgerProgram.
    """

    # Test data
    from .accounts import T, AccountCategory, Asset, Cash, CurrentAcc, Income, Liability, Revenue

    # Define expected initial balances
    expectedInitialBalances = {
        Asset: Balance(datetime.date(2020, 1, 1), 0),
        Cash: Balance(datetime.date(2020, 1, 1), 0),
        Liability: Balance(datetime.date(2020, 1, 1), 0),
        Income: Balance(datetime.date(2020, 1, 1), 0),
        Revenue: Balance(datetime.date(2020, 1, 1), 0),
        CurrentAcc: Balance(datetime.date(2020, 1, 1), 0),
    }

    # Define expected general ledger ledgers
    expected

# Generated at 2022-06-12 06:01:17.468231
# Unit test for function build_general_ledger
def test_build_general_ledger():
    pass


# Generated at 2022-06-12 06:01:27.552718
# Unit test for method add of class Ledger
def test_Ledger_add():
    from datetime import date
    from decimal import Decimal
    from dataclasses import InitVar
    from .commons.numbers import Amount, Quantity
    from .accounts import Account
    from .journaling import JournalEntry, Posting

    class FakeLedger(Ledger):
        def __init__(self, account: InitVar[Account], initial: InitVar[Balance], _last_balance: InitVar[Quantity]):
            Ledger.__init__(self, account, initial)
            self._last_balance = _last_balance


# Generated at 2022-06-12 06:01:38.277358
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .implementations.in_memory import in_memory_initial_balances, in_memory_journal_entries, AccountsImplementation
    from .implementations.in_memory import JournalEntriesImplementation, GeneralLedgerImplementation

    ## Get the program.

# Generated at 2022-06-12 06:01:45.890147
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .journaling import JournalEntry, Posting
    from .accounts import TerminalAccount, Account
    from .generic import Quantity
    from .ledgers import LedgerEntry, Ledger
    from ..commons.zeitgeist import Date

    ledger = Ledger(Account(''), TerminalAccount(''), Quantity(Decimal(0)))
    posting = Posting(Date(2020, 1, 1), JournalEntry(''), Account(''), Quantity(Decimal(10)))
    entry = ledger.add(posting)
    assert entry.balance == Quantity(Decimal(10))
    assert entry.credit == Quantity(Decimal(10))

# Generated at 2022-06-12 06:01:55.638757
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    ## Define some accounts:
    assets = Account("Assets")
    cash = Account("Cash", assets)
    receivables = Account("Receivables", assets)
    liabilities = Account("Liabilities")
    owners_equity = Account("Owners Equity")
    capital = Account("Capital", owners_equity)

    ## Create an example intial balances map:
    balances = {
        cash: Balance(datetime.date(2020, 1, 1), Quantity(Decimal(100))),
        receivables: Balance(datetime.date(2020, 1, 1), Quantity(Decimal(100))),
        capital: Balance(datetime.date(2020, 1, 1), Quantity(Decimal(100))),
        liabilities: Balance(datetime.date(2020, 1, 1), Quantity(Decimal(100))),
    }

   

# Generated at 2022-06-12 06:02:06.948974
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import AccountType
    from .accounts import TransactionType
    from .journaling import Posting, JournalEntry, Transaction
    from .journaling import TransactionDetail
    from .journaling import PostingDirection
    from .zeitgeist import Date
    ledger = Ledger(Account("200", "", AccountType.Assets, TransactionType.Debit), Balance(Date(2020, 1, 1), Quantity("100")))
    txn = Transaction("1001", Date(2020, 1, 1), "Test Transaction", "Test Transaction")
    dtl = TransactionDetail(txn, "", "", "1000", Quantity("100"), PostingDirection.Credit, Quantity("100"))
    txn.details.append(dtl)
    j = JournalEntry(txn, Date(2020, 1, 1), "Test Transaction")
    p = Post

# Generated at 2022-06-12 06:02:18.693646
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    import pytest
    from ..commons.zeitgeist import DateRange

    period = DateRange(since=datetime.date(year=2018, month=12, day=1), until=datetime.date(year=2018, month=12, day=31))
    initial_balances = {
        Account("assets:cash"): Balance(datetime.date(year=2018, month=12, day=1), Quantity(10))
    }
    journal_entries = iter([])
    result = compile_general_ledger_program(lambda period: initial_balances, lambda period: journal_entries)(period)
    assert result is not None
    assert isinstance(result, GeneralLedger)
    assert period == result.period
    assert len(initial_balances) == len(result.ledgers)

# Generated at 2022-06-12 06:02:28.825661
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    ## Initialize required dependencies:
    initial = lambda p: {Account("1"): Balance(date=p.since, value=Quantity(10))}
    journal = lambda p: [
        JournalEntry(date=datetime.date(year=d.year, month=d.month, day=d.day), postings=[Posting(Account("1"), 1)])
        for d in p.days
    ]

    ## Compile the program:
    gl = compile_general_ledger_program(initial, journal)(DateRange(datetime.date(year=2000, month=5, day=1), 30))

    ## Assertions:
    assert len(gl.ledgers) == 1
    assert len(gl.ledgers[Account("1")].entries) == 30

    ## Done!

# Generated at 2022-06-12 06:03:06.583157
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # Define a sample initial balance
    sample_account = Account(number="sample_number", name="sample_name", terminal=True)
    sample_amount = Amount(Decimal(10.00))
    sample_initial_balance = { sample_account: Balance(datetime.date(2019, 12, 31), sample_amount) }

    # Define the class
    class SampleInitialBalances(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return sample_initial_balance

    # Execute the unit test
    assert SampleInitialBalances()(DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))) == sample_initial_balance


# Generated at 2022-06-12 06:03:15.912814
# Unit test for method add of class Ledger
def test_Ledger_add():
    from src.commons.zeitgeist import Date
    from src.journaling import Journal
    from src.accounts.domain import Account
    from src.accounts.ledgering import Balance, Ledger

    acct_cash = Account.new("Cash")
    bal_cash = Balance(Date(2019, 1, 1), Quantity(Decimal(0)))
    gl = Ledger(acct_cash, bal_cash)

    # Create an instance of Journal

# Generated at 2022-06-12 06:03:18.273270
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    """
    Test instrumentation for method __call__ of class ReadInitialBalances.
    """
    pass


# Generated at 2022-06-12 06:03:26.347979
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # Basic initialization
    # There is no test possible

    # Test read_initial_balances.__call__()
    '''
    try:
        assert read_initial_balances.__call__(period)
        print('test_ReadInitialBalances___call__ --> true')
    except:
        print('test_ReadInitialBalances___call__ --> false')
    '''
    print('test_ReadInitialBalances___call__ --> not yet implemented')

# Generated at 2022-06-12 06:03:29.442433
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    """
    Unit test for method __call__ of class ReadInitialBalances.
    """
    pass_ = True # If all assertions pass.
    try:
        pass
    except Exception as e:
        print(e)
        pass_ = False
    assert pass_


# Generated at 2022-06-12 06:03:35.628141
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from .accounts import AccountType as T, AccountKind as K

    class JournalEntryMock(JournalEntry[None]):
        def __init__(self, a: Account, b: Account, c: Account, d: Account, date: date, description: str, amount: Amount):
            super().__init__(None, date, description)
            self.add_posting(Posting(a, amount, T.Assets, K.Debit))
            self.add_posting(Posting(b, amount, T.Liabilities, K.Credit))
            self.add_posting(Posting(c, amount, T.Revenues, K.Credit))
            self.add_posting(Posting(d, amount, T.Expenses, K.Debit))


# Generated at 2022-06-12 06:03:46.888663
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    ## Set up test:
    period = DateRange(since=datetime.date(2018, 1, 1), until=datetime.date(2018, 12, 31))

# Generated at 2022-06-12 06:03:58.054726
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Covers test case for method __call__ of class GeneralLedgerProgram.
    """

    # Set value of period.
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))
    # Set value of initial_balances.
    initial_balances = {Account('100000'): Balance(datetime.date(2018, 12, 31), Quantity(Decimal('1000'))), }
    # Set value of journal_entries.

# Generated at 2022-06-12 06:04:04.893397
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests the method __call__ of class GeneralLedgerProgram
    """

    from .accounts import AccountCollection
    from .journaling import Journal

    ## Create a collection of test accounts.
    accounts = AccountCollection()

    ## Record two journal entries.
    journal = Journal("First Journal Entry")
    journal.add(
        Posting("1", datetime.date(2019, 1, 1), accounts["A"], accounts["B"], Quantity(100)),
        Posting("1", datetime.date(2019, 1, 1), accounts["B"], accounts["A"], Quantity(100)),
    )

# Generated at 2022-06-12 06:04:14.167601
# Unit test for method add of class Ledger
def test_Ledger_add():
    """
    Test for method add of class Ledger
    """
    from datetime import date
    from decimal import Decimal
    from ..commons.numbers import Amount, Quantity

    from .accounts import Account
    from .journaling import Journal, Posting, Transaction
    from .generic import Balance

    from djed.events.events import Event
    from djed.events.interfaces import IEventBus

    from typing import List, Optional
    import datetime

    event_bus = Event(IEventBus)

    Transaction.event_bus = event_bus
    Posting.event_bus = event_bus
    Journal.event_bus = event_bus
    Ledger.event_bus = event_bus

    a = Account(None,1, 1, 'Assets', 'Current Assets', 'Bank', 'Current Account', 'EUR')
   

# Generated at 2022-06-12 06:04:45.767238
# Unit test for function build_general_ledger
def test_build_general_ledger():
    # pylint: disable=missing-function-docstring,missing-class-docstring,invalid-name,too-many-locals,too-many-statements
    from unittest import TestCase
    from collections import namedtuple
    from freezegun import freeze_time

    Date = namedtuple("Date", ["year", "month", "day"])


# Generated at 2022-06-12 06:04:51.345511
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    
    """
    Compile a general ledger program.
    """
    from .accounts import Account, AccountType
    from .journaling import JournalEntry, Posting
    from .intervals import interval, interval_union
    from .ledgers import build_general_ledger, compile_general_ledger_program
    import datetime
    from dataclasses import dataclass, field
    from decimal import Decimal
    from typing import Dict, Generic, Iterable, List, Optional, Protocol, TypeVar
    
    #: Defines a generic type variable.
    _T = TypeVar("_T")


    #: Initial balances:
    InitialBalances = Dict[Account, Balance]


    @dataclass
    class LedgerEntry(Generic[_T]):
        """
        Provides a ledger entry model.
        """

        #

# Generated at 2022-06-12 06:05:02.069238
# Unit test for method add of class Ledger
def test_Ledger_add():
    class TestPosting(Posting):
        def __init__(self, date, account: Account, amount: Amount, direction: PostingDirection):
            self.date = date
            self.account = account
            self.amount = amount
            self.direction = direction

    journal_entry1 = JournalEntry(datetime.date(2019, 1, 2), 'Payday', [])
    journal_entry1.add(TestPosting(datetime.date(2019, 1, 2), Account('Salary', False), Decimal(4800), PostingDirection.CREDIT))
    journal_entry1.add(TestPosting(datetime.date(2019, 1, 2), Account('Cash', False), Decimal(4800), PostingDirection.DEBIT))

# Generated at 2022-06-12 06:05:03.596679
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert callable(ReadInitialBalances.__call__)


# Generated at 2022-06-12 06:05:10.764584
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    def _read_journal_entries(period: DateRange) -> List[JournalEntry[_T]]:
        pass

    def _read_initial_balances(period: DateRange) -> InitialBalances:
        pass

    FunctionType = type(_read_journal_entries)
    GeneralLedgerProgramType = type(compile_general_ledger_program(_read_journal_entries, _read_initial_balances))

    assert isinstance(
        compile_general_ledger_program(_read_journal_entries, _read_initial_balances), GeneralLedgerProgramType
    )
    assert issubclass(GeneralLedgerProgramType, FunctionType)



# Generated at 2022-06-12 06:05:21.741950
# Unit test for method add of class Ledger
def test_Ledger_add():
    class JournalEntry:
        def __init__(self, date, postin):
            self.date = date
            self.postings = postin
    class Posting:
        def __init__(self, amount, account, direction):
            self.amount = amount
            self.account = account
            self.direction = direction
    class Account:
        def __init__(self, accountid):
            self.id = accountid
    
    account1 = Account('12345')
    posting1 = Posting(1000, account1, 1)
    posting2 = Posting(2000, account1, -1)
    posting3 = Posting(200, account1, 1)
    posting4 = Posting(100, account1, -1)
    date = datetime.date(2020, 3, 23)

# Generated at 2022-06-12 06:05:32.882399
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import account
    from .masterdata import MasterData
    from .transact import transact

    import unittest

    ## Provide a class which provides a transaction used to close terminal accounts:
    class _PeriodEndTransactions(Generic[_T]):
        def __init__(self):
            self._period_end: Optional[JournalEntry[_T]] = None

        @property
        def period_end(self) -> JournalEntry[_T]:
            if self._period_end is None:
                self._period_end = transact(datetime.date(2019, 12, 31), "Period End 2019")
            return self._period_end

    ## Create some accounts:
    sales = account("Sales")

# Generated at 2022-06-12 06:05:33.537421
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass

# Generated at 2022-06-12 06:05:37.911710
# Unit test for method add of class Ledger
def test_Ledger_add():
    general_ledger_program = compile_general_ledger_program(ReadInitialBalances, ReadJournalEntries)
    journal_entry = JournalEntry(Posting)
    date_range = DateRange(begin_date, end_date)
    initial_balance = initial_balance
    posting = Posting



# Generated at 2022-06-12 06:05:38.425748
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    pass

# Generated at 2022-06-12 06:06:34.684210
# Unit test for method add of class Ledger

# Generated at 2022-06-12 06:06:40.142760
# Unit test for function build_general_ledger

# Generated at 2022-06-12 06:06:48.874391
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():

    from .accounts import TerminalAccount
    from .journaling import Journal

    from ..commons.zeitgeist import Z1
    from ..commons.numbers import Q1, Q2, Q3, Q4

    ## Terminal accounts.
    a1 = TerminalAccount("A1")
    a2 = TerminalAccount("A2")
    a3 = TerminalAccount("A3")
    a4 = TerminalAccount("A4")

    ## Initial balances:
    initial_balances = {a1: Balance(Z1.jan01, Q1), a2: Balance(Z1.jan01, Q2)}

    ## Journal entries:
    j1 = Journal(Z1.jan03, "J1", [Posting(a1, Q1), Posting(a2, Q1)])

# Generated at 2022-06-12 06:06:53.280245
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import Account
    from .journaling import Journal, JournalEntry, Posting, build_journal

    def test_read_initial_balances(period) -> InitialBalances:
        return {Account(1010, 'Cash in Office'): Balance(period.since, 0)}


# Generated at 2022-06-12 06:07:02.739256
# Unit test for method add of class Ledger
def test_Ledger_add():
    print(">>> test_Ledger_add")
    account1 = Account(1, "1")
    account2 = Account(2, "2")
    period = DateRange(datetime.date(2018,1,1),datetime.date(2018,12,31))
    ledger = Ledger(account1, Balance(datetime.date(2018,1,1), Quantity(Decimal(0))))
    journal = JournalEntry(period.since, ["1"], ["2"], "journal", [Posting(account1, period.since, Quantity(Decimal(10)), "USD"),
                                                                  Posting(account2, period.since, Quantity(Decimal(-10)), "USD")])
    for posting in journal.postings:
        if posting.account == account1:
            ledger.add(posting)

# Generated at 2022-06-12 06:07:12.117469
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    import unittest
    import io

    @dataclass
    class _MockJournalEntry:
        date: datetime.date
        description: str
        postings: List[Posting]

    @dataclass
    class _MockPosting:
        account: Account
        amount: Amount
        direction: int

    @dataclass
    class _MockAccount:
        name: str
        code: str


# Generated at 2022-06-12 06:07:21.230168
# Unit test for method add of class Ledger
def test_Ledger_add():
    ## Prepare test data
    ledger1 = Ledger(Account(1), Balance(datetime.date(2020, 1, 1), Quantity(Decimal(800))))
    journal1 = JournalEntry(datetime.date(2020, 1, 20), 'Journal1', [Posting(Account(1), 1, Amount(Decimal(200)))])
    #  ledger1.add(journal1)
    ledger1.add(journal1.postings[0])

    ## Test: assert the balance of the ledger after the journal entry is added
    assert ledger1.entries[-1].balance == Quantity(Decimal(1000))

    ## Prepare test data
    ledger2 = Ledger(Account(1), Balance(datetime.date(2020, 1, 1), Quantity(Decimal(800))))

# Generated at 2022-06-12 06:07:30.727231
# Unit test for method add of class Ledger
def test_Ledger_add():
    account = Account(account_name="Test", description="Test Account", group=1)
    initial = Balance(datetime.date(year=2020, month=1, day=1), Quantity(Decimal(0)))
    ledger = Ledger(account, initial)
    journal = JournalEntry(date=datetime.date(year=2020, month=1, day=1), description="Test journal", postings={})
    posting = Posting(account=account, amount=Quantity(Decimal(1)), journal=journal, direction=Direction.DEBIT)
    entry = ledger.add(posting)
    assert entry is not None
    assert ledger.entries[-1] is not None
    


# Generated at 2022-06-12 06:07:36.132652
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    d = Date(2019, 1, 1)
    period = DateRange(d, d)
    initial_balances = {
        Account("A2"): Balance(d, Quantity(0.0)),
        Account("A3"): Balance(d, Quantity(5.5)),
    }
    print(initial_balances)
    # assert initial_balances == initial_balances_calculated

# Generated at 2022-06-12 06:07:43.266237
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .algebras import read_initial_balances, read_journal_entries
    import dateutil.parser
    from .api.types import ReadGeneralLedger, ReadInitialBalances, ReadJournalEntries

    # Define parameter values
    period = dateutil.parser.parse("2018-01-01")

    # Invoke the function
    result = compile_general_ledger_program(
        read_initial_balances, read_journal_entries
    )(period)
    assert isinstance(
        result, GeneralLedger
    ), f"Incorrect return type: expected GeneralLedger[T], got {result.__class__.__name__}"