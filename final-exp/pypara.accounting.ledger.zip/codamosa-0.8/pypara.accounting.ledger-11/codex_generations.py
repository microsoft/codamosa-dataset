

# Generated at 2022-06-12 05:59:57.540691
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass

# Generated at 2022-06-12 06:00:07.063116
# Unit test for method add of class Ledger
def test_Ledger_add():
    test_account = Account('TEST') 
    test_posting = Posting(test_account, datetime.date(2020, 7, 16), 'Description', Amount(25.00), 1)

    test_ledger = Ledger(test_account, Balance(datetime.date(2020, 7, 15), Quantity(Decimal(0))))
    test_ledger.add(test_posting)
    assert test_ledger.entries[0].balance == Decimal(25.00)
    assert test_ledger.entries[0].date == datetime.date(2020, 7, 16)
    assert test_ledger.entries[0].description == 'Description'
    assert test_ledger.entries[0].amount == Amount(25.00)


# Generated at 2022-06-12 06:00:08.796789
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-12 06:00:12.758318
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    class ReadInitialBalances_Finder:
        def __call__(self, period: DateRange) -> InitialBalances:
            pass

    f = ReadInitialBalances_Finder()
    assert isinstance(f, ReadInitialBalances)


# Generated at 2022-06-12 06:00:22.216310
# Unit test for method add of class Ledger

# Generated at 2022-06-12 06:00:29.727829
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {}

    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        return None

    program = compile_general_ledger_program(read_initial_balances, read_journal_entries)
    assert program(DateRange(datetime.date(2000, 1, 1), datetime.date(2000, 12, 31))) == GeneralLedger(DateRange(datetime.date(2000, 1, 1), datetime.date(2000, 12, 31)), {})

# Generated at 2022-06-12 06:00:35.650865
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    import pytest

    ## Create a new ledger program:

# Generated at 2022-06-12 06:00:46.823116
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.times import now
    # Import the accounts and main entry examples
    import double_entry.examples.main
    # Mock the DateTime.now() method to a fixed date
    date = now().replace(year=2019, month=12, day=29)
    date.now = lambda: date
    # Call the examples main method
    journal_entries = double_entry.examples.main.run()
    # Create the open and close dates for this period
    period = DateRange(date.replace(month = 12, day = 1), date)
    # Define the initial balances

# Generated at 2022-06-12 06:00:58.652987
# Unit test for method add of class Ledger
def test_Ledger_add():
    """
    Tests the add() method of class Ledger.
    """
    ## Create a ledger:
    ledger1 = Ledger(Account("1110", "100", "31"), Balance(datetime.date(2019, 1, 1), Quantity(Decimal(0))))

    ## Fact: when adding a posting, a ledger entry is returned.
    expect_posting = Posting(JournalEntry(datetime.date(2019, 1, 31), "SALES", [], False), Account("1200", "100", "31"),
                             Quantity(Decimal(1000)), False)

    ledger1.add(expect_posting)
    assert(len(ledger1.entries) == 1)
    assert (ledger1.entries[0].posting == expect_posting)

# Generated at 2022-06-12 06:00:59.715431
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-12 06:01:14.391091
# Unit test for function build_general_ledger
def test_build_general_ledger():
    # define the period
    period = DateRange(datetime.date(2016, 1, 1), datetime.date(2016, 12, 31))
    # define the account
    a1 = Account('A1')
    a2 = Account('A2')
    a3 = Account('A3')
    # define the initial balance of the account
    initial = {
        a1: Balance(datetime.date(2015, 1, 1), Quantity(Decimal(100))),
        a2: Balance(datetime.date(2015, 1, 1), Quantity(Decimal(100))),
        a3: Balance(datetime.date(2015, 1, 1), Quantity(Decimal(100)))
    }
    # define the journal entries
    je1 = JournalEntry(datetime.date(2016, 1, 1), 'je1')
    je1

# Generated at 2022-06-12 06:01:25.219186
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.types import Dimensions, Transaction
    from ..journaling.algebras import BuildJournal
    from ..journaling.models import AccountGroup
    from .algebras import ReadInitialBalances as RIB
    
    ## Accounting period:
    period = DateRange(2020, 1, 1, 2020, 12, 31)

    ## Account groups:
    pnl = AccountGroup([1001, 1002, 1003, 1004, 1005, 1006])
    assets = AccountGroup([2001, 2002, 2003])
    liabs = AccountGroup([3001, 3002, 3003])
    equity = AccountGroup([4001, 4002])
    cash = AccountGroup([2001, 3003])
    expenses = AccountGroup(pnl.accounts[:5])
    income = AccountGroup(pnl.accounts[-1])

   

# Generated at 2022-06-12 06:01:35.510301
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # Mocked implementations for read_initial_balances and read_journal_entries:
    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {}

    def _read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        return []

    ## Compile the program:
    program = compile_general_ledger_program(_read_initial_balances, _read_journal_entries)

    ## Call the program:
    period = DateRange(since=datetime.date(2020, 1, 1), until=datetime.date(2020, 12, 31))
    ledger = program(period)

    ## Assertion:
    assert ledger.period == period
    assert not ledger.ledgers

# Generated at 2022-06-12 06:01:42.855551
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from collections import abc
    from dataclasses import dataclass
    from decimal import Decimal

    from ..commons.numbers import Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType, AccountSubType

    ## Mock account type, sub-type, and account:
    class AccountTypeMock(AccountType):
        @property
        def is_terminal(self):
            return True

    class AccountSubTypeMock(AccountSubType):
        @property
        def is_terminal(self):
            return True

    class AccountMock(Account):
        def __init__(self, code, description, account_type, account_subtype):
            self.code = code
            self.description = description
            self.account_type = account_type
            self.account_sub

# Generated at 2022-06-12 06:01:54.352581
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import ReadJournalEntries
    from .accounts import Account, AccountType
    from .commons.zeitgeist import DateRange

    # Test program:
    def read_initial_balances(period: DateRange) -> Dict[Account, Balance]:
        """
        Read initial balances.
        """

# Generated at 2022-06-12 06:02:06.019028
# Unit test for method __call__ of class GeneralLedgerProgram

# Generated at 2022-06-12 06:02:17.994493
# Unit test for function build_general_ledger
def test_build_general_ledger():

    # :param period: Accounting period.
    # :param journal: All available journal entries.
    # :param initial: Opening balances for terminal accounts, if any.
    #:return: A :py:class:`GeneralLedger` instance.

    import journal
    import accounts
    import ledgers
    import datetime

    qty_opening = Quantity(Decimal(5))

    period = journal.DateRange(since=datetime.date(2020,1,1), until=datetime.date(2020,12,31))
    journal = []
    amount_1 = Amount(Decimal(100))
    amount_2 = Amount(Decimal(-70))
    posting_1 = journal.Posting(accounts.accounts["CA"], amount_1, journal.Direction.DEBIT,datetime.date(2020,1,1))
    posting

# Generated at 2022-06-12 06:02:28.714274
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .accounts import Account, TerminalAccount

    from .journaling import Posting, PostingAffix, PostingDirection

    from .journaling import Journal, JournalEntry

    from datetime import date, timedelta

    ## Prepare test inputs:
    period = DateRange(since=date(2018, 1, 1), until=date(2018, 1, 31))
    assert period.count == 31

    ## Cash account:
    cash = TerminalAccount("Cash")

    ## Supplier account:
    supplier = TerminalAccount("Supplier")

    ## Build and return journal entries:
    def _build_journal_entries() -> List[JournalEntry]:

        def _debit(amount: Decimal, date: date) -> Posting:
            return Posting(PostingDirection.DEBIT, cash, date, amount)


# Generated at 2022-06-12 06:02:30.117836
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    ## TODO: Implement
    pass

# Generated at 2022-06-12 06:02:37.914425
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Unit test for method __call__ of class GeneralLedgerProgram.
    """
    ## Test data:
    ## Accounting period:
    period = DateRange(datetime.date(2017, 1, 1), datetime.date(2017, 3, 31))

    ## Postings:
    journal_posts = [
        Posting(datetime.date(2017, 1, 1), Amount(Decimal("20.00")), "Foo", Account("Asset 1"), Direction.debit),
        Posting(datetime.date(2017, 1, 1), Amount(Decimal("20.00")), "Foo", Account("Equity 1"), Direction.credit),
    ]

    ## Journal entries:

# Generated at 2022-06-12 06:02:58.507280
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..journaling import build_journal_entry
    from ..taxation import Tax, is_taxable, is_withholding_tax
    from ..eaccounting import (
        Activity,
        Asset,
        Expense,
        Income,
        Liability,
        Revenue,
        TaxableRevenue,
    )

    ## Activities
    activities = [
        Activity(20, "Consulting")
    ]
    ## Assets
    assets = [
        Asset(10, "Cash"),
        Asset(11, "Accounts Receivable"),
        Asset(12, "Inventory"),
        Asset(13, "Prepaid Expenses"),
        Asset(16, "Other Current Assets"),
    ]
    ## Expense Accounts

# Generated at 2022-06-12 06:03:05.656208
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():

    from .algebras import InitialBalancesAlgebra, JournalEntriesAlgebra

    # Initial balances:
    initial = {
        Account("1", "Cash"): Balance(datetime.date(2020, 1, 1), Quantity(Decimal(5000)))
    }

    # Journal entries:

# Generated at 2022-06-12 06:03:15.080189
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import AccountCode
    from .journaling import Posting, PostingDirection
    from .journaling.algebra import ReadJournalEntries, JournalEntry, ReadJournalEntriesViaTransactions

    @dataclass
    class MockReadJournalEntries(ReadJournalEntries[_T]):
        """
        A mock of ReadJournalEntries algebra which returns a list of journal entries.
        """

        #: A list of journal entries.
        entries: List[JournalEntry[_T]]

        def __call__(self, period: DateRange) -> List[JournalEntry[_T]]:
            return self.entries

    @dataclass
    class MockReadTransactions(ReadJournalEntriesViaTransactions[_T]):
        """
        A mock of ReadJournalEntriesViaTransactions algebra which returns a list of journal entries.
        """

       

# Generated at 2022-06-12 06:03:23.281908
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from datetime import date
    from decimal import Decimal
    from pytest import fixture
    from unittest.mock import MagicMock
    from redbaron.redbaron import RedBaron

    from ..commons.numbers import Amount
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import (Journal, JournalEntry, Posting,
                             build_journal_entry, compile_journal_entry_program)
    from .ledgering import (GeneralLedger, ReadInitialBalances, ReadJournalEntries,
                            build_general_ledger, compile_general_ledger_program)

    # Fixtures
    @fixture
    def accounts():
        return MagicMock()

    @fixture
    def journals():
        return MagicMock()


# Generated at 2022-06-12 06:03:31.667751
# Unit test for function build_general_ledger
def test_build_general_ledger():
    """
    User Story: As a business accountant I must be able to build general ledgers in order to prepare financial
    statements.
    """
    ## Algebra implementation:
    def _initial_balances(period: DateRange) -> InitialBalances:
        return {
            Account("1010"): Balance(period.since, Quantity(Decimal(5))),
            Account("2000"): Balance(period.since, Quantity(Decimal(-10))),
        }


# Generated at 2022-06-12 06:03:34.905217
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Unit test for method __call__ of class GeneralLedgerProgram
    """
    # TODO: Implement unit test
    pass

# Generated at 2022-06-12 06:03:46.074137
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Create account
    account = Account("test", "test")

    # Create posting
    posting = Posting(account, 100, True)

    # Create ledger
    ledger = Ledger(account, Balance(datetime.date(2020, 1, 1), 0))

    # Add posting to the ledger
    entry = ledger.add(posting)

    # Check the ledger entry
    assert entry.date == posting.date, "Ledger Entry date should equal to posting date"
    assert entry.amount == posting.amount, "Ledger Entry amount should equal to posting amount"
    assert entry.is_debit == posting.is_debit, "Ledger Entry should be debited"
    assert entry.balance == posting.amount, "Ledger Entry balance should equal to posting amount"

# Generated at 2022-06-12 06:03:54.254139
# Unit test for method add of class Ledger
def test_Ledger_add():
    """
    Unit test for method add of class Ledger
    """

    from .journaling import Journal, ReadJournalEntry

    # create some test journals
    journal1 = Journal(entry_date=datetime.date(2020, 1, 1), description='journal 1', postings=[
                       Posting(account=Account('12'), amount=Amount(100)),
                       Posting(account=Account('41'), amount=Amount(-100))])
    journal2 = Journal(entry_date=datetime.date(2020, 2, 1), description='journal 2', postings=[
                       Posting(account=Account('12'), amount=Amount(200)),
                       Posting(account=Account('41'), amount=Amount(-200))])

# Generated at 2022-06-12 06:04:03.537169
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from datetime import date
    import io
    from unittest.mock import patch

    from ..commons.zeitgeist import DateRange
    from ..models import accounts, journaling
    from ..models.accounts import AssetAccount, LiabilityAccount
    from ..models.journaling import Posting

    # Initial balances table:
    initial_balances_table = [
        AssetAccount("1010", "Cash"),
        LiabilityAccount("2010", "Loans"),
        LiabilityAccount("2020", "Accounts Payable"),
    ]

    # Transactions table:

# Generated at 2022-06-12 06:04:04.700957
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass



# Generated at 2022-06-12 06:04:28.091157
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests method __call__ of class GeneralLedgerProgram.
    """

    from .accounts import AccountType, ledger_account

    from .journaling import JournalEntry, Posting

    from ..commons.zeitgeist import today

    # Asset account
    a = ledger_account("111000", "Cash", AccountType.ASSET)

    # Liability account
    b = ledger_account("222000", "Debt", AccountType.LIABILITY)

    # Equity account
    c = ledger_account("330000", "Equity", AccountType.EQUITY)

    # Income account
    d = ledger_account("411000", "Sales", AccountType.INCOME)

    # Expense account
    e = ledger_account("512000", "Costs", AccountType.EXPENSE)

    # Set initial balances:
    initial

# Generated at 2022-06-12 06:04:33.432514
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    @dataclass
    class Test(ReadInitialBalances):
        def __init__(self):
            self.called = False

        def __call__(self, period: DateRange) -> InitialBalances:
            self.called = True
            return {"test"}

    t = Test()
    t("test")
    assert t.called



# Generated at 2022-06-12 06:04:43.405259
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from copy import copy
    from pytest import raises
    from math import isclose as _isclose
    from .accounts import Account, AccountType, AssetAccount, LiabilityAccount

    ## Initialize accounts:
    asset = AssetAccount("Cash", AccountType.Assets)
    liability = LiabilityAccount("Capital", AccountType.Liabilities)
    expense = AssetAccount("Expenses", AccountType.Expenses)
    income = AssetAccount("Income", AccountType.Income)
    period = DateRange(datetime.date(2017, 1, 1), datetime.date(2017, 12, 31))

# Generated at 2022-06-12 06:04:51.394378
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Mock the object posting
    posting = {
        "id": "jtest",
        "date": "2020-04-15",
        "description": "testing ledger entries",
        "postings": [
            {
                "account": "expenses:meals:food:groceries",
                "direction": "O",
                "amount": 1000,
                "currency": "USD"
            },
            {
                "account": "assets:cash",
                "direction": "I",
                "amount": 1000,
                "currency": "USD"
            }
        ]
    }

    # Initialize ledger
    led = Ledger(posting.postings[0].account, Balance(2020, 1000))
    
    # Add the posting to the ledger
    led.add(posting)
    
    # Check if the ledger

# Generated at 2022-06-12 06:05:02.118748
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    @dataclass
    class ExampleInitialBalance(Generic[_T]):
        """
        Example initial balance
        """
        account: Account
        balance: Balance[_T]

    @dataclass
    class ExampleInitialBalances(Protocol):
        """
        Example initial balances
        """

        def __call__(self, period: DateRange) -> InitialBalances:
            pass

    # example of an initial balance
    example_initial_balance = ExampleInitialBalance(
        account=Account("current assets:cash:checking"), balance=Balance(date=datetime.date(2020, 1, 1), value=0)
    )

    # Example of initial balances
    example_initial_balances = {
        example_initial_balance.account: example_initial_balance.balance
    }  # type: InitialBalances

    # Example of read initial

# Generated at 2022-06-12 06:05:03.197141
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    ...



# Generated at 2022-06-12 06:05:11.611391
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests the __call__ method of class GeneralLedgerProgram
    """
    import logging
    import json

    from .accounts import Account, AccountType
    from .journaling import post

    ## Setup logging system:
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)

    ## The following code is test data, based on the double-entry bookkeeping system example in Wikipedia.
    ## We use it to build a general ledger.
    ## A real-life general ledger would probably come from an accounting system, like Sage, Xero, or ERP5.
    ## So the main point of these tests is to make sure the general ledger can be built, not to test bookkeeping rules.

    ## Define your accounts.
    ## The following accounts follow the general ledger account code, based on the double-entry

# Generated at 2022-06-12 06:05:21.914933
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..books import build_books
    from ..books.initial_balances import build_initial_balances
    from ..books.journal_entries import AccumulateJournalEntries
    from ..books.journal_entries import AccumulateJournalEntriesFromBooks
    from ..books.journal_entries import PostToLedgers
    from ..books.read_journal_entries import AccumulateReadJournalEntries

    books = build_books(None, AccumulateJournalEntries, AccumulateReadJournalEntries, PostToLedgers, build_initial_balances)
    books_func = AccumulateJournalEntriesFromBooks(books)
    read_journal_entries = AccumulateReadJournalEntries(books_func)

# Generated at 2022-06-12 06:05:33.070832
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from . import accounts
    from . import journaling

    def _test_impl(period: DateRange) -> GeneralLedger[None]:
        import datetime
        from decimal import Decimal
        from typing import Dict, List
        from unittest.mock import Mock, call

        #: Accounts map for unit testing:
        _accounts = {
            "I001": accounts.Assets,
            "I002": accounts.Assets,
            "I003": accounts.Assets,
            "I004": accounts.Income,
            "I005": accounts.Expenses,
            "I006": accounts.Expenses,
            "I007": accounts.Income,
        }

        #: Account initial balances as of the end of previous financial period:

# Generated at 2022-06-12 06:05:41.033341
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account, DebitCredit
    from .balance import Balance
    from .journaling import Journal, Posting
    
    account = Account("Test Account", DebitCredit.Debit)
    journal = Journal("Test description", datetime.date(2020,2,2), "REF1")
    posting = Posting(account, journal, 100)
    
    initial_balance = Balance(datetime.date(2020, 2, 1), 100)
    ledger = Ledger(account, initial_balance)
    
    ledger_entry = ledger.add(posting)
    
    assert ledger_entry.posting.amount == posting.amount and ledger_entry.posting.journal == posting.journal

# Generated at 2022-06-12 06:06:16.446999
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..fiscalyear.algebra import OpenNextFiscalYear
    from ..fiscalyear.models import FiscalYear
    from ..journaling.algebra import InitializeJournal, PostJournal
    from ..journaling.models import JournalEntry
    from ..transaction.algebra import OpenTransaction
    from ..transaction.models import Transaction
    from .models import Account, ReadAccounts, read_accounts

    # Define the period:
    since = datetime.date(2020, 1, 1)
    until = datetime.date(2020, 12, 31)
    period = DateRange(since, until)

    # Define accounts:

# Generated at 2022-06-12 06:06:24.061033
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # Fixture
    accounting_period = DateRange(since=datetime.date(2010, 1, 1), until=datetime.date(2020, 12, 31))

    # Exercise
    general_ledger_program = compile_general_ledger_program(
        read_initial_balances = lambda period : InitialBalances(), 
        read_journal_entries = lambda period : list(),
    )
    general_ledger = general_ledger_program(accounting_period)
    # Validate
    assert general_ledger.period == accounting_period
    assert general_ledger.ledgers == {}
    # Cleanup - none necessary

# Generated at 2022-06-12 06:06:24.979894
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-12 06:06:27.396666
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-12 06:06:36.982337
# Unit test for function build_general_ledger
def test_build_general_ledger():
    """
    Tests function build_general_ledger.
    """

    from .accounts import Account

    from .journaling import Journal, Posting

    period = DateRange(since=datetime.date(2020, 1, 1), until=datetime.date(2020, 12, 31))

    _A1 = Account(
        code="1000",
        name="Cash",
        type="A",
        nature="A",
        is_ext_cashflow=False,
        currency="EUR",
        is_group=False,
    )
    _A2 = Account(
        code="1100",
        name="Cash at bank",
        type="A",
        nature="A",
        is_ext_cashflow=False,
        currency="EUR",
        is_group=False,
    )
    _A3 = Account

# Generated at 2022-06-12 06:06:45.558964
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    """
    Unit test for method __call__ of class ReadInitialBalances
    """
    from .test.test_model import _read_initial_balances
    assert isinstance(_read_initial_balances, ReadInitialBalances)
    period = DateRange(since=datetime.date(2019, 1, 1), until=datetime.date(2019, 1, 31))
    initial_balances = _read_initial_balances(period)
    assert initial_balances == {Account("1110"): Balance(value=Quantity(Decimal("0")), date=datetime.date(2018, 12, 31))}


# Generated at 2022-06-12 06:06:56.149558
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    class InitialBalance(ReadInitialBalances):
        def __init__(self, initial_balances: InitialBalances):
            self.initial_balances = initial_balances
        
        def __call__(self, period: DateRange) -> InitialBalances:
            return self.initial_balances
    
    class JournalEntry(ReadJournalEntries):
        def __init__(self, journal_entries: Iterable[JournalEntry]):
            self.journal_entries = journal_entries

        def __call__(self, period: DateRange) -> Iterable[JournalEntry]:
            return self.journal_entries
    
    read_initial_balances = InitialBalance({})
    read_journal_entries = JournalEntry([])
    period = DateRange.today()

# Generated at 2022-06-12 06:06:58.365306
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    ReadInitialBalances.__call__("any period"(), returns=InitialBalances)


# Generated at 2022-06-12 06:07:08.175588
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # Test empty entries.
    assert test_ReadInitialBalances___call__.__call__(DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 1))) == {}

    # Test single expected entry.
    assert test_ReadInitialBalances___call__.__call__(DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 1))) == {account: balance}

    # Test multiple expected entries in order.
    assert test_ReadInitialBalances___call__.__call__(DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 1))) == {account: balance}

    # Test multiple expected entries reverse order.

# Generated at 2022-06-12 06:07:18.268102
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.algebras import Algebra, Program

    from .accounts import Account, AccountScheme

    from .journaling import (
        JournalEntry,
        ReadJournalEntries,
        build_journal_entry,
    )

    # Initial balances algebra:

    class InitialBalancesInterpreter(Algebra[ReadInitialBalances]):
        """
        Defines an interpreter for the initial balances algebra.
        """

        def __init__(
            self, scheme: AccountScheme, initial: InitialBalances,
        ):
            """
            Initializes the interpreter.

            :param scheme: Account scheme.
            :param initial: Initial balances.
            """
            self._scheme = scheme
            self._initial = initial


# Generated at 2022-06-12 06:09:01.298432
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    ## Import classes for test
    from .accounts import Balance, Account, Beat
    from ..commons.zeitgeist import DateRange
    from .journaling import JournalEntry, Posting, PostingDirection, Currency
    from .generic import Balance, Amount
    from .numbers import Quantity

    ## Declare the fake algebra implementation, which returns the hard-coded initial balances
    def read_initial_balances(period: DateRange):
        return {
            Account(Beat.ASSET, "101", "Cash"): Balance(period.since, Quantity(0)),
            Account(Beat.ASSET, "102", "Accounts Receivable"): Balance(period.since, Quantity(0)),
            Account(Beat.LIABILITY, "201", "Accounts Payable"): Balance(period.since, Quantity(0)),
        }

    ## Declare the fake

# Generated at 2022-06-12 06:09:02.038076
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert True == True

# Generated at 2022-06-12 06:09:12.207840
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    def read_initial_balances(period):
        return dict()

    def read_journal_entries(_):
        return []

    def test_case(period):
        return compile_general_ledger_program(read_initial_balances, read_journal_entries)(period)

    period = DateRange(datetime.date(year=2020, month=1, day=1), datetime.date(year=2020, month=12, day=31))
    general_ledger = test_case(period)
    assert isinstance(general_ledger, GeneralLedger)
    assert general_ledger.period == period
    assert general_ledger.ledgers == {}


# Generated at 2022-06-12 06:09:14.368286
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert ReadInitialBalances.__call__.__objclass__ is ReadInitialBalances



# Generated at 2022-06-12 06:09:23.609327
# Unit test for function build_general_ledger
def test_build_general_ledger():
    # Test the method build_general_ledger
    # Import necessary libraries
    import datetime
    from dataclasses import dataclass, field
    from decimal import Decimal
    from typing import Dict, Generic, Iterable, List, Optional, Protocol, TypeVar
    from dateutil.relativedelta import relativedelta

    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting, ReadJournalEntries

    _T = TypeVar("_T")

    @dataclass
    class LedgerEntry(Generic[_T]):
        """
        Provides a ledger entry model.
        """

        #: Ledger the entry belongs to.
        ledger: "Ledger[_T]"

        #: Posting of the ledger entry.
        posting: Posting[_T]

        #: Balance of the

# Generated at 2022-06-12 06:09:32.066015
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .journaling.tests.test_journaling import test_JournalEntry
    from .journaling.tests.test_journaling import test_JournalEntry_postings
    journal = test_JournalEntry()
    postings = test_JournalEntry_postings(journal)
    account = postings[0].account
    period = DateRange(datetime.date.fromisoformat('2018-01-01'),
                       datetime.date.fromisoformat('2018-03-31'))
    initial = {account: Balance(period.since, Quantity(Decimal(0)))}
    ledgers = {account: Ledger(account, initial[account])}
    for posting in postings:
        ledgers[posting.account].add(posting)
    expected_balance = Decimal('30500.00')
    balance = ledgers[posting.account].balance


# Generated at 2022-06-12 06:09:34.495182
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # TODO: Write unit test for method __call__ of class GeneralLedgerProgram
    assert False


# Generated at 2022-06-12 06:09:39.879782
# Unit test for method __call__ of class GeneralLedgerProgram

# Generated at 2022-06-12 06:09:49.536847
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():

    from .accounts import Account, AccountType
    from .journaling import Journal, JournalEntry

    from .journaling import Posting, AccountType

    from .accounts import Account
    from .journaling import Posting

    from .journaling import Posting

    import datetime

    from .journaling import Posting

    from .commons.numbers import Amount, Quantity

    from .accounts import Account
    from .commons.numbers import Amount, Quantity

    from .journaling import Posting

    from .journaling import Posting

    from .journaling import Posting

    from .journaling import Posting

    from .journaling import Posting

    import typing

    from .journaling import JournalEntry, Posting

    from .commons.zeitgeist import DateRange

    from .accounts import Account