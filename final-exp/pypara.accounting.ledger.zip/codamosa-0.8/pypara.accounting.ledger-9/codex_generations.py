

# Generated at 2022-06-12 06:00:07.288167
# Unit test for method add of class Ledger
def test_Ledger_add():
    account_sample = Account("A1")
    initial_sample = Balance("2020-01-01", Quantity(Decimal(10)))
    entry_sample = Ledger(account_sample, initial_sample)
    posting_sample = Posting("2020-01-01", Decimal(20))

    entry_sample.add(posting_sample)

    assert isinstance(entry_sample.entries[0], LedgerEntry)
    assert entry_sample.entries[0].ledger == entry_sample
    assert entry_sample.entries[0].posting == posting_sample
    assert entry_sample.entries[0].balance == Quantity(Decimal(30))
    assert entry_sample.entries[0].date == posting_sample.date
    assert entry_sample.entries[0].description == posting_sample.description


# Unit

# Generated at 2022-06-12 06:00:17.483475
# Unit test for method add of class Ledger
def test_Ledger_add():
    account = Account(1, 'Test account 1')
    balance = Balance(datetime.date(2020, 1, 1), Decimal(10))
    journal_entry = JournalEntry(2, 'Test journal 1', datetime.date(2020, 1, 1))
    posting = Posting(account, journal_entry, Decimal(10), 1)
    ledger = Ledger(account, balance) 
    assert ledger._last_balance == Decimal(10)
    ledger.add(posting)
    assert ledger._last_balance == Decimal(20)
    assert ledger.entries[0].balance == Decimal(20)


# Generated at 2022-06-12 06:00:20.864808
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from ..commons.zeitgeist import DateRange
    from .._factory import factory

    read_initial_balances = factory.build_read_initial_balances()
    read_initial_balances(DateRange(20190101, 20190131))[factory.build_account()]

# Generated at 2022-06-12 06:00:30.940551
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account, AccountTypes
    from .journaling import JournalEntry, Posting
    
    ## Setup the test:
    account = Account('0400', AccountTypes.ASSET, 'First Account')
    l = Ledger(account, Balance(datetime.date.today(), Quantity(Decimal(100))))
    
    ## Start with a test entry which is a debit.
    posting = Posting(JournalEntry(datetime.date.today(), 'Test entry', [Posting(account, Amount(Decimal(100), 'USD', datetime.date.today()), 'Debit'), Posting(account, Amount(Decimal(100), 'USD', datetime.date.today()), 'Credit')]), 'Debit')
    entry = LedgerEntry(l, posting, Quantity(Decimal(200)))

# Generated at 2022-06-12 06:00:39.082475
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    ##
    ## Setup
    ##
    ## Mock the read_initial_balances function:
    def read_initial_balances(period):
        return {
            a: Balance(
                period.since,
                Quantity(
                    Decimal(1) if a % 2 == 0 else Decimal(0),
                )
            ) for a in range(10)
        }

    ## Mock the read_journal_entries function:
    def read_journal_entries(period):
        date = period.since

# Generated at 2022-06-12 06:00:48.478579
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from typing import cast
    from typing_extensions import TypedDict
    from .accounts import AccountId

    class AccountIdDict(TypedDict):
      AccountId: AccountId

    class AccountIdDictDict(TypedDict):
      AccountIdDict: AccountIdDict

    class AmountDict(TypedDict):
      Amount: Amount

    class AmountDictDict(TypedDict):
      AmountDict: AmountDict

    class DateDict(TypedDict):
      Date: datetime.date

    class DateDictDict(TypedDict):
      DateDict: DateDict

    class PostingDict(TypedDict):
      account: AccountId
      amount: Amount
      currency: str
      date: datetime.date


# Generated at 2022-06-12 06:01:00.363350
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import compile_journal_posting_program

    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from .accounts import Account, ReadAccounts
    from .accounts import Asset, Liability, Revenue, Expense, Capital, Terminal

    def _read_journal_entries(
        period: DateRange,
    ) -> ReadJournalEntries:
        "Mock implementation of the algebra to read journal entries."


# Generated at 2022-06-12 06:01:07.077884
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import today
    from .accounts import Account
    from .journaling import Ledger, Posting, Side, JournalEntry

    # Arrange
    period = DateRange(today.replace(day=1), today)
    account = Account("411", "Retained Earnings")
    initial_balances = {account : Balance(today.replace(day=1), Quantity(Decimal(1000000000000)))}

    posting = Posting(account, Side.Debit, Quantity(Decimal(1000000)))
    journal_entries = [
        JournalEntry(today.replace(day=1), "Opening Balance", "Opening Balance", [posting])
    ]

    read_initial_balances = lambda p: initial_balances
    read_journal_entries = lambda p: journal_entries

    general_ledger_

# Generated at 2022-06-12 06:01:08.693836
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert False, "Not implemented"


# Generated at 2022-06-12 06:01:13.723970
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .accounts import AccountType, Account

    @dataclass
    class MockOperation:
        pass

    @dataclass
    class MockCustomer:
        pass

    cash = Account(
        "CASH",
        "Cash",
        AccountType.Asset,
        None,
    )
    sale_revenue = Account(
        "SLREVENUE",
        "Sales Revenue",
        AccountType.Revenue,
        None,
    )
    sale_expense = Account(
        "SLEXPENSE",
        "Sales Expense",
        AccountType.Expense,
        None,
    )
    customer_accounts_receivable = Account(
        "CUSTAR",
        "Accounts Receivable from Customers",
        AccountType.Asset,
        None,
    )
    sale_revenue_deferred

# Generated at 2022-06-12 06:01:31.504052
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import date_range
    from ..journaling import JournalEntry
    from . import accounts
    from .accounts import Account
    from .operations import post_journal

    #: Account definitions:
    bank = accounts.bank("my-bank")
    cash = accounts.cash("my-cash")

    #: This program just reads from a buffer:
    read_initial_balances = lambda period: {bank: Balance(period.since, Quantity(Decimal(1000.00)))}

# Generated at 2022-06-12 06:01:33.174425
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-12 06:01:41.892592
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests method __call__ of class GeneralLedgerProgram.
    """
    import pathlib
    from .accounts import Account, Category
    from .general_ledger import accounts
    from ..commons import zeitgeist

    ## Read initial balances:
    with pathlib.Path(accounts.__file__).parent.joinpath("data", "initial_balances").open() as f:
        initial_balances = {Account(category=Category[c[0]], number=c[1:]): Balance(date, Amount(Decimal(a))) for c, a, date in (l.split() for l in f)}

    ## Get the program:
    program = compile_general_ledger_program(lambda p: initial_balances, read_journal_entries=lambda p: [])

    ## Run test:
    general_led

# Generated at 2022-06-12 06:01:49.960731
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from moneyflow.commons.zeitgeist import DateRange
    from moneyflow.ledgers.accounts import Account
    from moneyflow.ledgers.generic import Balance, Quantity
    import datetime

    # 0. Setup
    ledger = {Account((1, 2)): Balance(datetime.date(2017, 1, 1), Quantity(100)),
              Account((1, 3)): Balance(datetime.date(2017, 1, 1), Quantity(200))
              }

    # 1. Example
    x = ReadInitialBalances()
    x.__call__ = lambda period: ledger
    actual = x.__call__(DateRange(datetime.date(2017, 1, 1), datetime.date(2017, 1, 1)))

    # 2. Assert
    assert ledger == actual


# Generated at 2022-06-12 06:01:57.866044
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    initial_balances = {
        Account("assets:cash", "Cash", True):
            Balance(datetime.date(2020, 7, 1), Quantity(Decimal(100))),
        Account("assets:bank", "Bank", True):
            Balance(datetime.date(2020, 7, 1), Quantity(Decimal(200)))
    }


# Generated at 2022-06-12 06:02:08.217278
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    @dataclass
    class _ReadInitialBalances:
        _initial_balances: InitialBalances

        def __call__(self, period: DateRange) -> InitialBalances:
            return self._initial_balances

    assert _ReadInitialBalances({})(None) == {}

# Generated at 2022-06-12 06:02:19.470569
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Arrange
    # Aggregate initial balance
    initial_aggregate_balance = 100.0
    # Account 1 initial balance
    initial_balance_1 = 150.0
    # Account 2 initial balance
    initial_balance_2 = -50.0
    current_account = Account(name='Cash')
    counter_account = Account(name='Income')
    current_date = datetime.date(2019, 9, 1)
    journal_entry_amount = 50.0
    journal = JournalEntry(date=current_date, description='Rent', counter_account=counter_account, amount=journal_entry_amount)
    ledger_1 = Ledger(current_account, initial_balance_1)
    ledger_2 = Ledger(counter_account, initial_balance_2)
    # Expected ledger entry
    expected_ledger_

# Generated at 2022-06-12 06:02:25.905740
# Unit test for method add of class Ledger
def test_Ledger_add():
    AccountDebit = Account("Debit Account")
    AccountCredit = Account("Credit Account")
    initial_balance = Balance(datetime.date(2020, 1, 1), Decimal("100.00"))
    ledger_debit = Ledger(AccountDebit, initial_balance)
    ledger_credit = Ledger(AccountCredit, initial_balance)
    entry = Posting(AccountDebit, datetime.date(2020, 2, 1), Decimal("100.00"), 1)
    journal = JournalEntry(datetime.date(2020, 2, 1), "Test", [entry])
    posting = journal.postings[0]
    ledger_entry = LedgerEntry(ledger_debit, posting, initial_balance.value)
    assert ledger_debit.add(posting) == ledger_entry

# Generated at 2022-06-12 06:02:35.367451
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import Transaction, Posting, JournalEntry, Direction
    from .generic import Balance, Quantity
    from .journaling import ReadJournalEntries

    def test_algebra():
        """
        An algebra implementation for unit testing.
        """

# Generated at 2022-06-12 06:02:45.362225
# Unit test for function build_general_ledger
def test_build_general_ledger():
	
	## Initialize ledger as per available initial balances:
    ledgers: Dict[Account, Ledger[_T]] = {a: Ledger(a, b) for a, b in initial_balances.items()}

    ## Iterate over journal postings and populate ledgers:
    for posting in (p for j in journal for p in j.postings if period.since <= j.date <= period.until):
        ## Check if we have the ledger yet, and create if not:
        if posting.account not in ledgers:
            ledgers[posting.account] = Ledger(posting.account, Balance(period.since, Quantity(Decimal(0))))

        ## Add the posting to the ledger:
        ledgers[posting.account].add(posting)

    ## Done, return general ledger.

# Generated at 2022-06-12 06:03:07.123891
# Unit test for function build_general_ledger
def test_build_general_ledger():
    import datetime

    # (1) Create journal entries:
    def journal_entries():
        yield JournalEntry(datetime.date(2005, 1, 11), "A", [Posting(10, Account(101))])
        yield JournalEntry(datetime.date(2005, 1, 11), "B", [Posting(-1, Account(101))])
        yield JournalEntry(datetime.date(2005, 1, 12), "C", [Posting(-1, Account(102))])
        yield JournalEntry(datetime.date(2005, 1, 13), "D", [Posting(-10, Account(102))])
        yield JournalEntry(datetime.date(2005, 1, 13), "E", [Posting(1, Account(101))])

# Generated at 2022-06-12 06:03:13.880943
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    ## Type checking:
    glp = compile_general_ledger_program(
        read_initial_balances=lambda period: {}, read_journal_entries=lambda period: (JournalEntry(date=dt.date.today(), description="test", postings=[]) for _ in range(3))
    )
    assert callable(glp)
    assert GeneralLedgerProgram.__args__ == glp.__annotations__["return"].__args__

    ## Value checking:
    assert glp(period=DateRange(since=dt.date.today(), until=dt.date.today())).ledgers == {}

# Generated at 2022-06-12 06:03:22.584638
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Unit test for method __call__ of class GeneralLedgerProgram
    """

    # Defines a protocol for initial balances and implements it:
    class _ReadInitialBalances(Protocol):
        def __call__(self, period: DateRange) -> InitialBalances:
            pass

    def _read_initial_balances(period: DateRange) -> InitialBalances:
        return {Account.by_name("1010"): Balance(period.since, Quantity(Decimal(5000)))}

    read_initial_balances_in_1010 = _read_initial_balances

    # Defines a protocol for reading journal entries and implements it:
    class _ReadJournalEntries(Protocol):
        def __call__(self, period: DateRange) -> Iterable[JournalEntry]:
            pass


# Generated at 2022-06-12 06:03:31.005446
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    ## Test Parameters
    period = DateRange(
        since=datetime.date(year=2000, month=1, day=1),
        until=datetime.date(year=2000, month=12, day=31),
    )
    journal = []

# Generated at 2022-06-12 06:03:31.561860
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__(): pass


# Generated at 2022-06-12 06:03:41.609343
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import date
    from .accounts import _Account, Account
    from .journaling import Journal, Posting, _JournalEntry, JournalEntry

    # First, test a basic case:
    period = DateRange(date(2016, 1, 1), date(2016, 12, 31))

    # Initial balances:
    initial: InitialBalances = {}

    # Journal entries:
    journal: Iterable[JournalEntry[_T]] = []

    # Run the function
    general_ledger = build_general_ledger(period, journal, initial)

    # Now, test a more comprehensive case:
    period = DateRange(date(2016, 1, 1), date(2016, 12, 31))

    # Initial balances:

# Generated at 2022-06-12 06:03:51.775434
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from unittest.mock import Mock

    ## Prepare adhoc values for arguments:
    period = DateRange(datetime.date(2020, 9, 1), datetime.date(2020, 9, 30))
    read_journal_entries_returns = [JournalEntry(datetime.date(2020, 9, 1), "Note", [Posting(Account("10.000"), Decimal("12"))])]

# Generated at 2022-06-12 06:03:58.441280
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    class RIB(ReadInitialBalances):
        def __init__(self, initial_balances):
            self.initial_balances = initial_balances

        def __call__(self, period: DateRange) -> InitialBalances:
            return self.initial_balances
    print(test_ReadInitialBalances___call__.__doc__)

# Generated at 2022-06-12 06:04:00.306752
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    assert compile_general_ledger_program(None, None).__call__(None) is not None

# Generated at 2022-06-12 06:04:10.994382
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from finance.accounts.generic import Balance
    from finance.accounting.ledgers.generic import ReadInitialBalances, InitialBalances
    from finance.domain.accounts import Account

    read_initial_balances: ReadInitialBalances = lambda period: InitialBalances(
        {
            Account.fromstring("000001"): Balance(period.since, Quantity(Decimal(0)))
        }
    )

    assert read_initial_balances(DateRange(date(2018, 1, 1), date(2018, 12, 31))).keys() == {Account.fromstring('000001')}



# Generated at 2022-06-12 06:04:37.116773
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    'General ledger program'

    # First, a couple of tests with fixed payloads, since these are trivial and do not require any external dependencies:
    def _test(
        initial: InitialBalances,
        journal_entries: List[JournalEntry[_T]],
        period: DateRange,
        expected: GeneralLedger[_T],
    ):
        'Test the general ledger program'

        # Define algebras:
        def _read_initial(p: DateRange) -> InitialBalances:
            return initial

        def _read_journal(p: DateRange) -> List[JournalEntry[_T]]:
            return journal_entries

        # Compile the program:
        ledger_program = compile_general_ledger_program(_read_initial, _read_journal)

        # Execute the program:
        general_ledger = ledger

# Generated at 2022-06-12 06:04:46.183778
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Unit test for method __call__ of class GeneralLedgerProgram
    """
    from .accounts import Account, AccountId
    from .journaling import BuildJournal, BuildJournalEntry
    from .taxonomies import Taxonomy, TaxonomyId
    from .units import Unit, UnitId
    import pytest

    ## Initialize taxonomy:
    taxonomy = Taxonomy(
        "Taxonomy", "Taxonomy", TaxonomyId("taxonomy"),
        ["Assets", "Liabilities", "Equity", "Income", "Expenses", "Cost of goods sold", "Other revenues", "Other expenses"]
    )

    ## Initialize units:

# Generated at 2022-06-12 06:04:50.659899
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from decimal import Decimal
    from ..commons.zeitgeist import Date, DateRange
    from .accounts import Account


# Generated at 2022-06-12 06:04:57.704496
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Ledger(account, initial)
    l=Ledger(Account("A"), Balance(datetime.date(2019, 1, 1), Quantity(Decimal(0))))
    # Posting(account, date, amount, direction, journal)
    p=Posting(Account("B"), datetime.date(2019, 1, 1), Amount(Decimal(1)), 1, Journal(datetime.date(2019, 1, 1), "J"))
    # create the entry
    entry = LedgerEntry(l, p, Quantity(Decimal(1)))
    # add the posting to the ledger
    l.add(p)
    assert l.entries[0].__repr__()==entry.__repr__()


# Generated at 2022-06-12 06:05:08.275419
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .accounts import Accounts
    from .journaling import Group, Posting

    ## Define a test date range:
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 3, 31))

    ## Create an accounts repository.
    accounts = Accounts()

    ## Add some dummy accounts.
    assets = accounts.add_terminal("assets")
    cash = accounts.add_terminal(assets, "cash")
    accounts_receivable = accounts.add_terminal(assets, "accounts_receivable")
    inventory = accounts.add_terminal(assets, "inventory")

    liabilities = accounts.add_terminal("liabilities")
    accounts_payable = accounts.add_terminal(liabilities, "accounts_payable")


# Generated at 2022-06-12 06:05:20.408917
# Unit test for function build_general_ledger
def test_build_general_ledger():
    ## Journal entry for October 31:
    journal_oct_31 = JournalEntry(
        date=datetime.date(2020, 10, 31), description="Debit side of the journal entry.",
        postings=[
            Posting(account=Account("Cash", 1010), amount=Amount(1_000), direction=Direction.DEBIT),
            Posting(account=Account("Goods", 5011), amount=Amount(1_000), direction=Direction.CREDIT)
        ]
    )

    ## Journal entry for November 1:

# Generated at 2022-06-12 06:05:31.751277
# Unit test for method __call__ of class GeneralLedgerProgram

# Generated at 2022-06-12 06:05:40.896918
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # ASSEMBLE
    class Test(ReadJournalEntries):
        def __init__(self, journaL_entries):
            self.journal_entries = journaL_entries

        def __call__(self, since, until):
            return self.journal_entries

    class Test2(ReadInitialBalances):
        def __init__(self, initial_balances):
            self.initial_balances = initial_balances

        def __call__(self, since, until):
            return self.initial_balances

        # ACT


# Generated at 2022-06-12 06:05:49.247018
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import JournalEntry, Posting, Debit, Credit

    # initialize account and journal
    account = Account("1110", "Cash" ,True)
    ledger = Ledger(account, Balance(datetime.datetime(2000, 1, 1), Quantity(Decimal(0))))
    journal = JournalEntry("Entered a JournalEntry")
    posting = Posting(journal, account, Debit, Amount(Decimal(100.0)))

    # add posting to the ledger
    entry = ledger.add(posting)

    # verify the results
    assert entry.ledger == ledger
    assert entry.posting == posting
    assert entry.balance == Quantity(Decimal(100.0))
    assert entry.date == journal.date
    assert entry.description == journal.description
    assert entry.amount == posting

# Generated at 2022-06-12 06:06:00.309320
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..models.events import AccountTransaction, JournalEntry


# Generated at 2022-06-12 06:06:37.603137
# Unit test for function build_general_ledger
def test_build_general_ledger():

    import datetime
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import Posting, JournalEntry
    from .generic import Balance
    from .ledgers import LedgerEntry

    date = datetime.date(2012, 1, 1)

# Generated at 2022-06-12 06:06:38.602690
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-12 06:06:48.177206
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests method __call__ of class GeneralLedgerProgram.
    """
    # Define test data:
    period = DateRange(
        datetime.date(2019, 4, 1),
        datetime.date(2019, 4, 30),
    )
    initial_balances = InitialBalances({})
    journal_entries = {JournalEntry(datetime.date(2019, 4, 1), 'echo')}

# Generated at 2022-06-12 06:06:59.494909
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import AccountType
    from .journaling import JournalEntry, JournalEntryType, Posting

    # terminal account:
    a1 = Account("current account", AccountType.LIABILITY)
    # contra-account:
    a2 = Account("income", AccountType.INCOME)
    # terminal account:
    a3 = Account("cash account", AccountType.ASSET)
    # contra-account:
    a4 = Account("expenses", AccountType.EXPENSE)


# Generated at 2022-06-12 06:07:09.742847
# Unit test for method add of class Ledger
def test_Ledger_add():
    """
    Testing method add of class Ledger
    """
    from datetime import date
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import Journal, Posting, ReadJournalEntries
    from .generic import Balance
    from .ledgers import Ledger

    @dataclass
    class JournalEntry(object):
        date: date
        description: str
        postings: List[Posting]

    @dataclass
    class MyJournalEntry(JournalEntry):
        pass

    @dataclass
    class MyJournal(Journal):
        pass

    @dataclass
    class MyPosting(Posting):
        pass

    @dataclass
    class MyBalance(Balance):
        pass


# Generated at 2022-06-12 06:07:20.074235
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from datetime import date
    from ..commons.zeitgeist import date_range
    from ..composition.algebra import AccountingAlgebra
    from ..composition.interpreters import AccountingInterpreter
    from ..composition.program import AccountingProgram
    from ..composition.repositories import InMemoryRepository
    from ..examples.accounting import AccountingExample
    from ..examples.journaling import JournalingExample
    from .accounts import Account, TerminalAccount
    from .generic import GenericAccountingAlgebra
    from .ledgers import InitialBalances, GeneralLedger, LedgerEntry

    ## Define the accounting period.
    period = date_range(date(year=2019, month=4, day=1), date(year=2019, month=6, day=30))

    ## Define the accounting repository.
    repository = In

# Generated at 2022-06-12 06:07:31.038724
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.numbers import Quantity
    from ..core.accounts import Account
    from ..core.journaling import Journal, Posting
    from ..core.ledgers import Ledger

    # Prepare the account
    account_1 = Account(1, 'Challenge', '2020', 'current', 'liability')
    account_2 = Account(2, 'Bank', '2020', 'current', 'asset')

    # Prepare the posting
    journal = Journal(1, 'Challenge', datetime.date.today())
    journal.add_posting(account_1, Quantity(2), 'debit')
    journal.add_posting(account_2, Quantity(2), 'credit')
    posting = Posting(journal, datetime.date(2020, 1, 1), account_1, Quantity(0), 'debit')

    # Prepare

# Generated at 2022-06-12 06:07:41.244244
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from .accounts import Account, AccountType
    from .journaling import ReadJournalEntries
    from .journaling import JournalEntry
    from .journaling import Posting
    from .journaling import Direction

    class TestReadJournalEntries(ReadJournalEntries[_T]):
        def __init__(self, ledger: GeneralLedger[_T]):
            self.ledger = ledger

        def __call__(self, period: DateRange) -> Iterable[JournalEntry[_T]]:
            yield JournalEntry[None](
                period.since, "ENTRY1", [Posting(Direction.CREDIT, Quantity(100), self.ledger.ledgers[self.account1].account)]
            )

    class TestReadInitialBalances(ReadInitialBalances):
        def __init__(self, account1, account2):
            self.account

# Generated at 2022-06-12 06:07:43.575694
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert issubclass(ReadInitialBalances, Generic)



# Generated at 2022-06-12 06:07:44.590665
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass



# Generated at 2022-06-12 06:08:28.405512
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .bookkeeping import Balance, Book
    from .journaling import JournalEntry
    from .posting import Posting


# Generated at 2022-06-12 06:08:29.698070
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # ...
    return



# Generated at 2022-06-12 06:08:35.929707
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # Unit test for method __call__ of class GeneralLedgerProgram
    from ..ledger.algebra import (
        FirstOfMonthReadInitialBalances,
        FirstOfMonthReadJournalEntries,
    )

    program = compile_general_ledger_program(
        FirstOfMonthReadInitialBalances(),
        FirstOfMonthReadJournalEntries(),
    )

    general_ledger = program(DateRange(since=datetime.date(2018, 1, 1), until=datetime.date(2018, 1, 31)))

    assert len(general_ledger.ledgers) == 6

# Quick unit test execution
if __name__ == "__main__":
    test_GeneralLedgerProgram___call__()

# Generated at 2022-06-12 06:08:46.385332
# Unit test for method add of class Ledger

# Generated at 2022-06-12 06:08:52.660421
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from .accounts import read_accounts
    from .accounting import read_initial_balances, read_journal_entries

    # Read accounts from file
    accounts: Dict[str, Account] = read_accounts("../data/accounts.csv")

    # Extract initial balance for account 101
    initial_balance = read_initial_balances(accounts)(DateRange(datetime.date(2016, 1, 1), datetime.date(2016, 12, 31)))

    # Read journal entries and post them
    journal_entries = read_journal_entries(accounts)(DateRange(datetime.date(2016, 1, 1), datetime.date(2016, 12, 31)))

    # Build the general ledger

# Generated at 2022-06-12 06:08:53.647689
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # Test body
    pass


# Generated at 2022-06-12 06:09:03.491036
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from collections import namedtuple, OrderedDict
    import datetime as dt

    from ..commons.zeitgeist import date_range

    from .accounts import AccountType, Account

    from .journaling import Journal, Posting, JournalEntry, Direction

    from .generic import Balance

    #: Defines a named tuple for mock data:
    MockData = namedtuple("MockData", ["period", "balances", "journal"])

    #: Defines a mock data set:

# Generated at 2022-06-12 06:09:09.096513
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    @dataclass
    class _ReadInitialBalancesImpl(ReadInitialBalances):
        def __call__(self, period: DateRange):
            pass
    ReadInitialBalancesImpl = _ReadInitialBalancesImpl()
    ReadInitialBalancesImpl.__call__(None)


# Generated at 2022-06-12 06:09:19.629458
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from datetime import date
    from .general_ledger import GeneralLedgerProgram, compile_general_ledger_program
    from .journaling import JournalEntry, Posting
    from .commons.numbers import Quantity, Amount

    ## Mock implementation for algebra ReadJournalEntries
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry]:
        return [
            JournalEntry(
                date(2020, 1, 1),
                "First journal entry",
                [
                    Posting(1, Quantity(1000)),
                    Posting(-1, Quantity(1000)),
                ]
            ),
            JournalEntry(
                date(2020, 1, 10),
                "Second journal entry",
                [
                    Posting(1, Quantity(2000)),
                    Posting(-1, Quantity(2000)),
                ]
            ),
        ]

# Generated at 2022-06-12 06:09:28.931201
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from os import path
    from ..commons.files import read_json
    from ..commons.zeitgeist import Period
    from .journaling import build_journal, read_csv

    ## Module path:
    module_path = path.abspath(path.join(path.dirname(__file__), "../../../test/general-ledger"))

    ## Assertions:
    def _assert(gl: GeneralLedger[None]):

        ## Check number of ledgers:
        assert len(gl.ledgers) == 10

        ## Check account ledger:
        assert gl.ledgers["Cash"].entries[0].amount == -Decimal(3)
        assert gl.ledgers["Cash"].entries[0].balance == Decimal(7)
        assert gl.ledgers["Cash"].entries[0].c