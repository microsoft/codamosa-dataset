

# Generated at 2022-06-12 05:59:58.789184
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass #TODO


# Generated at 2022-06-12 06:00:06.856163
# Unit test for method add of class Ledger
def test_Ledger_add():
    
    account = Account(code="0101", name="Cash")
    initial_balance = Balance(date=datetime.date(2020, 1, 1), value=1000)
    ledger = Ledger(account, initial_balance)
    journal = JournalEntry(date=datetime.date(2020, 1, 1), description="Sample")
    post = Posting(account, journal, Amount(2000), "Credit")
    post2 = Posting(account, journal, Amount(3000), "Debit")
    testpost = ledger.add(post)
    testpost2 = ledger.add(post2)
    
    assert testpost.ledger == ledger
    assert testpost.posting == post
    assert testpost.balance == 3000
    assert testpost2.ledger == ledger
    assert testpost2.posting == post2
    assert testpost

# Generated at 2022-06-12 06:00:19.152959
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Unit test for function compile_general_ledger_program.
    """
    from unittest.mock import Mock

    ## Given
    period = DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))
    initial_balances = {Account("1"): Balance(period.since, Quantity(Decimal(0)))}
    journal_entries = [JournalEntry("", period.since, [])]
    read_initial_balances = Mock(return_value=initial_balances)
    read_journal_entries = Mock(return_value=journal_entries)

    ## When
    program = compile_general_ledger_program(read_initial_balances, read_journal_entries)

    ## Then
    assert program(period) == build_general_ledger

# Generated at 2022-06-12 06:00:23.917219
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ...journaling.models import Journal
    from ...accounting.models import Account, Direction
    from ...commons.zeitgeist import DateRange
    from .models import Ledger, LedgerEntry

    # Initializing the ledger
    journal = Journal(datetime.datetime.now(), 1, "test")
    account = Account(1, "test", Direction.DEBIT)
    ledger = Ledger(account, Balance(datetime.datetime.now(), 10))

    # Testing method add
    ledger.add(journal.post(account, 10))
    assert isinstance(ledger.entries[0], LedgerEntry)


# Generated at 2022-06-12 06:00:32.976715
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .posting import testing_posting
    from .journaling import testing_journal
    from .accounts import AccountType
    from .balance import Balance
    from ..commons.zeitgeist import DateRange

    test_period = DateRange(datetime.date.today(), datetime.date.today())
    test_initial_balance = Balance(test_period.since, Quantity(Decimal(0)))
    test_account = Account('test_account', AccountType.Liability)
    test_journal = testing_journal(test_period)
    test_posting = testing_posting(test_journal)
    test_ledger = Ledger(test_account, test_initial_balance)
    test_ledger_entry = test_ledger.add(test_posting)

    assert test_ledger.account == test_account
   

# Generated at 2022-06-12 06:00:40.173838
# Unit test for method add of class Ledger
def test_Ledger_add():
    from datetime import date
    from etl.tests.models.accounts import AccountTree
    from etl.tests.models.journaling import Posting, Transaction

    ## Create a general ledger for the account tree:
    gl = build_general_ledger(
        DateRange(date(year=2020, month=1, day=1), date(year=2021, month=1, day=1)),
        [],
        AccountTree.initial_balances,
    )

    ## Get a sample transaction:

# Generated at 2022-06-12 06:00:48.984769
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # arrange
    from collections import namedtuple
    from datetime import date

    from more_itertools import last

    from ..commons.zeitgeist import Period

    from .accounts import TerminalAccount, create_account_program
    from .journaling import create_journal_entry_program
    from .journaling.algebra import ReadJournalEntries, ReadJournalEntriesImperative
    from ..core.adt import Case

    from .journaling.adt import JournalEntry as JournalEntryADT

    account = TerminalAccount("1", "Account")

    Period = Period(date(2019, 1, 1), date(2019, 12, 31))

    JournalEntry = namedtuple(
        "JournalEntry", ["date", "description", "account", "direction", "amount", "journal_id"]
    )

# Generated at 2022-06-12 06:00:57.831828
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from unittest.mock import Mock

    # Arrange
    read_initial_balances = Mock(spec=ReadInitialBalances)
    read_initial_balances.return_value = {}
    read_journal_entries = Mock(spec=ReadJournalEntries)
    read_journal_entries.return_value = []
    period = DateRange()

    # Act
    _call = compile_general_ledger_program(read_initial_balances, read_journal_entries)

    # Assert
    assert isinstance(_call(period), GeneralLedger)



# Generated at 2022-06-12 06:01:05.857827
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    ## Build general ledger program:
    read_initial_balances = lambda period: {"ASSET: Current Assets: Petty Cash": Balance("2000-01-01", Quantity(0)),
                                            "ASSET: Current Assets: Bank": Balance("2000-01-01", Quantity(0))}

# Generated at 2022-06-12 06:01:16.145612
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Tests __call__ method of class GeneralLedgerProgram.
    """

    #: Test accounts:
    GLO = Account(name="General ledger operations", code="GLO", is_terminal=False)
    BNK = Account(name="Bank", code="BNK", is_terminal=True)

    #: Test dates:
    since = datetime.date(2020, 1, 1)
    until = datetime.date(2020, 12, 31)

    #: Test initial balances:
    initial_balances: InitialBalances = {BNK: Balance(since, Quantity(Decimal(100)))}

    #: Test balance:
    initial_balance = initial_balances[BNK]

    #: Test journal entry:

# Generated at 2022-06-12 06:01:32.833253
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    # Implement the algebra.
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return {account_1: Balance(period.since, Quantity(Decimal(0)))}


# Generated at 2022-06-12 06:01:41.701777
# Unit test for method add of class Ledger
def test_Ledger_add():
    '''
    Test the method add of class Ledger
    '''
    
    rec_date1 = datetime.date(2018,10,7)
    rec_date2 = datetime.date(2018,10,8)
    
    posting1 = Posting("abc", Quantity(10), rec_date1, "debit")
    posting2 = Posting("abc", Quantity(10), rec_date2, "credit")
    
    account1 = Account("abc", "asset")
    account2 = Account("abc", "liability")
    
    balance1 = Balance("abc", Quantity(100), rec_date1)
    balance2 = Balance("abc", Quantity(0), rec_date1)
    
    ledger1 = Ledger(account1, balance1)
    ledger2 = Ledger(account2, balance2)


# Generated at 2022-06-12 06:01:43.065761
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert False, "Not yet implemented."


# Generated at 2022-06-12 06:01:54.577593
# Unit test for method add of class Ledger
def test_Ledger_add():
    #: Account of the ledger.
    account = Account("1234", "Cash on hand")

    #: Initial balance of the ledger.
    initial = Balance(datetime.date.today(), Quantity(Decimal(200)))

    # Create a Ledger
    Ledger_Test = Ledger(account, initial)

    # Create a JournalEntry
    Posting1 = Posting(datetime.date.today(), Account("1234", "Cash on hand"), Amount(Decimal(100)), "Debit")
    Posting2 = Posting(datetime.date.today(), Account("1234", "Cash on hand"), Amount(Decimal(100)), "Debit")
    Posting3 = Posting(datetime.date.today(), Account("1234", "Cash on hand"), Amount(Decimal(100)), "Debit")
    Posting4 = Posting

# Generated at 2022-06-12 06:02:06.226336
# Unit test for function build_general_ledger
def test_build_general_ledger():

    from .journaling import JournalEntry, Posting

    # Create a test account
    from .accounts import Account
    from .commons.numbers import Amount, Quantity

    # Creating a test account
    account = Account(name = 'Account', 
                      parent = None, 
                      terminal = False)
    
    # Creating a test posting
    posting = Posting(account = account, 
                      date = datetime.datetime(2020, 3, 2), 
                      amount = Amount('123.45'))

    # Create test journal entry
    journal_entry = JournalEntry(description = 'Test journal entry', 
                                 date = datetime.datetime(2020, 3, 2), 
                                 postings = [posting])

    # Set up test initial balances

# Generated at 2022-06-12 06:02:06.833044
# Unit test for function build_general_ledger
def test_build_general_ledger():
    pass

# Generated at 2022-06-12 06:02:18.624829
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    from .generic import Quantity
    from .reporting import build_general_ledger
    from datetime import date
    # create entries to test
    account = Account("123","Assets")
    account2 = Account("124","Liabilities")
    account3 = Account("125","Equity")
    account4 = Account("126","Income")
    account5 = Account("127","Expense")
    account6 = Account("128","Equity")
    date = date(2015,12,31)
    date2 = date(2016,12,31)
    date3 = date(2017,12,31)
    date4 = date(2014,12,31)
    date5 = date(2010,12,31)

# Generated at 2022-06-12 06:02:29.076085
# Unit test for function build_general_ledger
def test_build_general_ledger():
    import random
    from .models import AccountType
    from .journaling import JournalEntry as JE

    accounts = [
        Account("001", "Cash Account"),
        Account("002", "Investments"),
        Account("003", "Accounts Receivable", AccountType.ASSET),
        Account("004", "Accounts Payable", AccountType.LIABILITIES),
        Account("005", "Sales"),
        Account("006", "Depreciation Expense"),
    ]

    def fake_initial_balances(period: DateRange) -> InitialBalances:
        """
        Returns some initial balances.
        """
        return {account: Balance(period.since, Quantity(random.randint(0, 1000))) for account in accounts}


# Generated at 2022-06-12 06:02:37.611943
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import date
    from .accounts import build_account

    ## Define some accounts:
    acc1 = build_account("acc1", "")
    acc2 = build_account("acc2", "")
    acc3 = build_account("acc3", "")
    acc4 = build_account("acc4", "")

    ## Add some postings at the end of the period:

# Generated at 2022-06-12 06:02:46.709978
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .accounts import Account
    from .journaling import Entry, Posting, Journal
    import datetime
    from decimal import Decimal
    from math import pi
    from typing import List
    ## Account to debit:
    a1 = Account()
    ## Account to credit:
    a2 = Account()
    ## Account to credit:
    a3 = Account()
    #
    # Ledger entries to post on the account:
    #
    ## Posting:
    p1 = Posting(datetime.date(2020, 2, 12), a1, 50)
    ## Journal:
    j1 = Journal(datetime.date(2020, 2, 12), "First journal entry.", [p1])
    ## Posting:
    p2 = Posting(datetime.date(2020, 3, 12), a1, 50)
    ##

# Generated at 2022-06-12 06:03:06.392406
# Unit test for method add of class Ledger
def test_Ledger_add():
    acc = Account("Testing 123")
    bal = Balance(datetime.date(2000, 1, 1), Quantity(Decimal(0)))
    j_entries = JournalEntry(datetime.date(2000, 1, 1), "This is a test", Posting(acc, Amount(Decimal(1)), Direction.debit), Posting(acc, Amount(Decimal(1)), Direction.credit))
    ledger = Ledger(acc, bal)
    ledger.add(Posting(acc, Amount(Decimal(1)), Direction.debit))
    expected = [LedgerEntry(ledger, Posting(acc, Amount(Decimal(1)), Direction.debit), Quantity(Decimal(1)))]
    assert expected == ledger.entries, "Should return a list with one ledger entry"


# Generated at 2022-06-12 06:03:15.677039
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    def _journal_entries(period: DateRange) -> Iterable[JournalEntry]:
        # An implementation of method __call__ of class ReadJournalEntries
        # The function must read journal entries from the input source and return them.
        yield JournalEntry(datetime.date(2015, 10, 1), "Opening balance", [Posting(Account(1000), Amount(-9000))])
        yield JournalEntry(
            datetime.date(2015, 10, 2), "Purchase $50", [Posting(Account(1000), Amount(-50)), Posting(Account(1100), Amount(50))]
        )
        yield JournalEntry(
            datetime.date(2015, 10, 18), "Sale $150", [Posting(Account(1000), Amount(150)), Posting(Account(1200), Amount(-150))]
        )


# Generated at 2022-06-12 06:03:19.930781
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    class Impl(ReadInitialBalances):
        pass

    # noinspection PyTypeChecker
    instance = Impl()

    from datetime import date

    assert instance(DateRange(since=date(2018, 1, 1), until=date(2018, 1, 31))) == {}


# Generated at 2022-06-12 06:03:21.750073
# Unit test for method add of class Ledger
def test_Ledger_add():
    pass


# Generated at 2022-06-12 06:03:22.266525
# Unit test for function build_general_ledger
def test_build_general_ledger():
    pass

# Generated at 2022-06-12 06:03:27.273996
# Unit test for method add of class Ledger
def test_Ledger_add():
    posting=Posting(None,None,1,1)
    ledger=Ledger(posting.account,Balance(None,Quantity(0)))
    entry=ledger.add(posting)
    assert entry.balance.value == 1
    assert ledger.entries.pop().balance.value == 1
    assert entry.posting == posting
    assert entry.ledger == ledger
    assert ledger.initial == Balance(None,Quantity(0))


# Generated at 2022-06-12 06:03:34.340234
# Unit test for method add of class Ledger
def test_Ledger_add():
    """
    Unit test for method add of class Ledger
    """
    test_account = Account("TestAccount")
    test_balance = Balance(datetime.date(2020, 1, 1), Quantity(Decimal(100)))
    test_ledger = Ledger(test_account, test_balance)

    test_posting = Posting(None, test_account, Amount(Decimal(100)), None)
    test_posting2 = Posting(None, test_account, Amount(Decimal(100)), None)

    assert test_ledger.add(test_posting) == LedgerEntry(ledger=test_ledger, posting=test_posting, balance=Quantity(200))

# Generated at 2022-06-12 06:03:45.974863
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .commons import AccountGroup, AccountKind, AccountType
    from .commons import Currency, PostingDirection
    from .commons import Account
    from .journaling import Journal
    from .journaling import Posting
    from .journaling import Entry
    from .types import Date, Amount, Quantity
    from dataclasses import dataclass
    from decimal import Decimal
    import datetime as dt

    class Ledger(Generic[T]):
        def __init__(self, account, initial):
            """
            :param account: Account of the ledger.
            :param initial: Initial balance of the ledger.
            :return: A :py:class:`Ledger` instance.
            """
            self.account = account
            self.initial = initial
            self.entries = []


# Generated at 2022-06-12 06:03:54.198926
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..business.accounts import TerminalAccount
    from ..test.test_fixtures import build_period, build_posting, build_journal

    # Define the period to be used in the test:
    period = build_period(year=2018, month=2)

    # Define a test journal:
    journal = build_journal(  # 5,000.00
        build_posting(
            account=TerminalAccount(code="11101", name="Cash"),
            amount=Decimal("5000"),
            direction=-1,
        ),  # 5,000.00
        build_posting(
            account=TerminalAccount(code="11102", name="Accounts Receivable"),
            amount=Decimal("5000"),
            direction=1,
        ),  # 7,500.00
    )

    # Prepare the initial balances as

# Generated at 2022-06-12 06:04:03.479012
# Unit test for function build_general_ledger
def test_build_general_ledger():
    """
    Unit test for function ``build_general_ledger``.
    """
    import datetime
    from decimal import Decimal
    from typing import List
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting, PostingDirection, build_journal_entry

    #: A helper routine to build a ledger entry for a given posting.
    def _build_entry(posting: Posting) -> LedgerEntry:
        return LedgerEntry(
            ledger=ledger,
            posting=posting,
            balance=Quantity(previous_balance + posting.amount * posting.direction.value),
        )

    ## Sample accounts.
    assets = Account("assets")
    liabilities = Account("liabilities")

# Generated at 2022-06-12 06:04:46.402191
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-12 06:04:53.470429
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .journaling import Posting
    from .accounts import Account
    @dataclass
    class _Stub(Generic[_T]):
        date: datetime.date
        accounts: Dict[Account, Balance]
    account = Account("1000", "Cash")
    stub = _Stub(datetime.date.today(), {account: Balance(datetime.date.today(), Quantity(Decimal(0)))})
    posting = Posting("1", account, datetime.datetime.now(), Quantity(Decimal("100")))
    posting.date = datetime.date.today()
    ledger = stub.accounts[account]
    new_entry_ledger = ledger.add(posting)
    assert ledger == new_entry_ledger.ledger
    assert posting == new_entry_ledger.posting

# Generated at 2022-06-12 06:05:02.834514
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from ..commons.zeitgeist import Date

    @dataclass
    class MockReader(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {"a": Balance(Date(2019, 8, 31), Quantity(Decimal(100))), "b": Balance(Date(2019, 8, 31), Quantity(Decimal(50)))}

    assert MockReader()(DateRange(Date(2019, 8, 31), Date(2019, 8, 31))) == {"a": Balance(Date(2019, 8, 31), Quantity(Decimal(100))), "b": Balance(Date(2019, 8, 31), Quantity(Decimal(50)))}


# Generated at 2022-06-12 06:05:07.841088
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    ## Get a valid GeneralLedgerProgram instance
    gl_program = compile_general_ledger_program(
        lambda period: {},
        lambda period: [],
    )

    # Test a valid date range
    assert gl_program(DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 1, 31))) is not None


# Generated at 2022-06-12 06:05:17.092883
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    journal_entries = []
    read_initial_balances = lambda period: {Account("1") : Balance(period.since, Quantity(Decimal(0)))}
    period = DateRange(since=datetime.date(year=2019, month=10, day=1), until=datetime.date(year=2019, month=10, day=15))
    read_journal_entries = lambda period: journal_entries
    compile_general_ledger_program(read_initial_balances, read_journal_entries)(period)
    assert len(journal_entries) == 0

# Generated at 2022-06-12 06:05:18.157796
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-12 06:05:24.412025
# Unit test for function build_general_ledger
def test_build_general_ledger():

    # import other required modules
    from datetime import datetime
    from decimal import Decimal
    from typing import Dict, List, Optional
    from test.books.liabilities import Accounts
    from test.books.liabilities.journaling import Posting, JournalEntry
    from test.books.liabilities.core import Balance, Amount, Quantity, DateRange, \
        build_general_ledger

    # define test data

# Generated at 2022-06-12 06:05:36.006338
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .ledger_algebra_test import read_initial_balances, read_journal_entries
    from .ledger_algebra_test import err_initial_balances, err_journal_entries
    from .accounts import Account, AccountType
    from .journaling import Journal, Posting, PostingDirection
    from .commons.zeitgeist import DateRange

    try:
        compile_general_ledger_program(read_initial_balances, read_journal_entries)
    except Exception as e:
        print(e)
        assert False

    def program( period: DateRange) -> GeneralLedger:
        """
        Consumes the opening and closing dates and produces a general ledger.

        :param period: Accounting period.
        :return: A general ledger.
        """
        ## Get initial balances as of the end

# Generated at 2022-06-12 06:05:36.853566
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-12 06:05:45.447891
# Unit test for function build_general_ledger
def test_build_general_ledger():
    '''
    Tests the proper functioning of the function build_general_ledger
    '''
    from ..commons.zeitgeist import Quarter, TimePeriod
    from .accounts import Account, AccountType, BalanceType
    from .journaling import Amount, Date, Direction, Journal, JournalEntry, LedgerEntry, Posting

    #####################################
    #  A. Journal entries to be posted  #
    #####################################

    ## Initialize accounts to be used:
    ra = Account(101, "Retained Earnings", AccountType.EQUITY, BalanceType.DEBIT)
    sa = Account(102, "Sales", AccountType.REVENUE, BalanceType.CREDIT)
    ca = Account(103, "Cash", AccountType.ASSET, BalanceType.DEBIT)

# Generated at 2022-06-12 06:06:22.070287
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .commons.units import Unit
    from .journaling import Journal, Posting
    from .money import Money
    from .numbers import Amount, Quantity
    from .types import UnitType, Direction
    from .zeitgeist import DateRange
    from ..commons.zeitgeist import DateRange
    import datetime
    import decimal
    import pytest

    # Test initial conditions
    journal_entry = Journal("1", "entry 1", datetime.date(2020, 1, 1))
    acc1 = Account('Assets')
    acc2 = Account('Expenses')
    posting1 = Posting(journal_entry, Direction.DEBIT, acc1, Amount(decimal.Decimal(2)), UnitType(Unit.DOLLAR))

# Generated at 2022-06-12 06:06:34.041833
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Compiles a general ledger program for a fictional accounting system.
    """

    read_initial_balances = lambda period: {
        Account("1001"): Balance(period.since, Quantity(Decimal(10000))),
        Account("1002"): Balance(period.since, Quantity(Decimal(20000))),
        Account("1003"): Balance(period.since, Quantity(Decimal(30000))),
        Account("1004"): Balance(period.since, Quantity(Decimal(40000))),
    }


# Generated at 2022-06-12 06:06:42.164306
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    read_initial_balances: ReadInitialBalances = lambda period: {}
    read_journal_entries: ReadJournalEntries[_T] = lambda period: []
    program: GeneralLedgerProgram[_T] = compile_general_ledger_program(read_initial_balances, read_journal_entries)
    general_ledger: GeneralLedger[_T] = program(DateRange(period.since, period.until))
    assert isinstance(general_ledger, GeneralLedger)

# Generated at 2022-06-12 06:06:49.593066
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from decimal import Decimal
    from datetime import date
    from unittest.mock import MagicMock
    from typing import Iterable
    from forex_types.oer_types import Currency, Amount
    from accounting.journaling import ReadJournalEntries, JournalEntry
    from accounting.accounts import Account, AccountType
    from accounting.commons.zeitgeist import DateRange
    from accounting.commons.numbers import Amount, Quantity

    # Setup
    period = DateRange(date(2020, 1, 1), date(2020, 2, 29))

# Generated at 2022-06-12 06:07:00.073435
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from account_model.journaling import Journal, Posting, JournalEntry
    from account_model.accounts import Account, Asset, Liability, Equity
    from account_model.ledgering import LedgerEntry, GeneralLedger, build_general_ledger, Balance

    reports = []

    ## Build a general ledger:

# Generated at 2022-06-12 06:07:06.317321
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .accounts import Account, ContractAccount, TemporaryAccount
    from .journaling import Journal, Posting, PostingDirection
    from datetime import date
    
    assert build_general_ledger(DateRange(date(2000,1,1), date(2000,12,31)), [], {})

# Generated at 2022-06-12 06:07:15.354709
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling.algebra import journal_entry_factory
    from .journaling.data import DATE, DESCRIPTION
    from datetime import date

    ## Initial balances:
    initial: InitialBalances = {
        Account("Assets:Bank:Checking", "Assets"): Balance(date(2020, 1, 1), Quantity(Decimal(100))),
        Account("Liabilities:CreditCards:Bob", "Liabilities"): Balance(date(2020, 1, 1), Quantity(Decimal(200))),
        Account("Income:Salary", "Income"): Balance(date(2020, 1, 1), Quantity(Decimal(0))),
    }

    ## Simulate journal entries for the first 10 days of February 2020:
    journal: List[JournalEntry] = []

# Generated at 2022-06-12 06:07:17.954853
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # Define the class
    class ReadInitialBalances_X(ReadInitialBalances):
        def __call__(self, period: DateRange):
            return period


# Generated at 2022-06-12 06:07:23.935142
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account
    from .journaling import JournalEntry, Posting, build_journal

    ## Build a journal entry.
    journal_entry = build_journal(
        date=datetime.date(year=2019, month=12, day=31),
        description="Foo Inc. transaction",
        postings=[
            Posting(account=Account("0000", "Cash"), direction=1, amount=Decimal(123.45)),
            Posting(account=Account("1000", "Sales"), direction=-1, amount=Decimal(123.45)),
        ],
    )

    ## Create a ledger and add the journal entry:

# Generated at 2022-06-12 06:07:24.976530
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-12 06:09:22.070812
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    import datetime as dt
    import unittest

    # Setup test data:
    account_101 = Account("101", "Cash")
    account_200 = Account("200", "Accounts Receivable")
    account_271 = Account("271", "Accounts Payable")
    account_310 = Account("310", "Rent Expense")
    account_400 = Account("400", "Sales")
    account_600 = Account("600", "Rent Expense")
    account_700 = Account("700", "Cost of Goods Sold")
    account_800 = Account("800", "Admin Expenses")
    account_810 = Account("810", "Utilities")
    account_900 = Account("900", "Drawings")

    balance_101 = Balance(dt.date(2020, 1, 1), Quantity(Decimal(0)))
    balance_200

# Generated at 2022-06-12 06:09:24.265126
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    """
    Tests the method __call__ of class ReadInitialBalances. This is a protocol class and hence has no implementation.
    """
    assert True


# Generated at 2022-06-12 06:09:32.396034
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import construct_journal_entry
    from .accounts import construct_accounting_account

    def _test_build_general_ledger():
        from datetime import date
        from decimal import Decimal
        from .typing import DebitOrCredit
        from .numbers import Amount

        # dummy data
        date_range = DateRange(
            since=date(2019, 1, 1), until=date(2019, 12, 31)
        )

# Generated at 2022-06-12 06:09:42.188607
# Unit test for method add of class Ledger
def test_Ledger_add():
    """
    Unit test for method add of class Ledger.
    """

    ## Create a dummy general ledger and a ledger based on it.
    ledger = Ledger(Account("7111"), Balance(datetime.date(2020, 1, 1), Quantity(Decimal(0))))

    ## Create a dummy JournalEntry and a Posting based on it.
    posting1 = Posting(JournalEntry(datetime.date(2020, 1, 1), "", ""), Account("7111"), Amount(Decimal(100.0)), 1)
    posting2 = Posting(JournalEntry(datetime.date(2020, 1, 2), "", ""), Account("7111"), Amount(Decimal(200.0)), 1)

# Generated at 2022-06-12 06:09:51.928359
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import JournalEntry, Posting, AccountingPeriod
    from .accounts import AccountType, Account, AccountsConsolidation

    # Set up accounts:
    accounts: AccountsConsolidation = AccountsConsolidation(AccountType.ASSET, AccountType.PURCHASE, AccountType.PROFIT)

    accounts.set_account(1, "Cash")
    accounts.set_account(11, "Petty cash", 0)
    accounts.set_account(12, "Cash in bank", 0)
    accounts.set_account(17, "Cash in transit", 0)
    accounts.set_account(2, "Inventory")
    accounts.set_account(201, "Inventory at cost", 0)
    accounts.set_account(202, "Inventory at market value", 0)