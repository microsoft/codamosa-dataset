

# Generated at 2022-06-12 06:00:04.845959
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    #
    class JournalEntrySpy(JournalEntry[_T]):
        date = datetime.date(2020, 1, 1)

    ##
    def get_period():
        return DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 2, 28))

    ##
    def read_journal_entries(_: DateRange):
        return [JournalEntrySpy(), JournalEntrySpy()]

    ##
    def read_initial_balances(_: DateRange):
        return dict()

    ##
    result = compile_general_ledger_program(read_initial_balances, read_journal_entries)(get_period())
    #
    assert result.period == get_period()
    assert result.ledgers == dict()
    #

# Generated at 2022-06-12 06:00:17.440065
# Unit test for function build_general_ledger
def test_build_general_ledger():
    """
    Tests function build_general_ledger by constructing a ledger
    with the following sequence of postings:

    | Date     | Account | Amount  |
    |----------|---------|---------|
    | 2010-01-01 | A | 1000 |
    | 2010-01-02 | B | 1000 |
    | 2010-01-03 | A | 2000 |
    | 2010-01-04 | A | -3000 |
    | 2010-01-05 | B | -3000 |
    """

    class JournalEntryMock(_T):
        def __init__(self, date: datetime.date, account: Account, amount: Amount, description: str = "Desc"):
            self.date = date
            self.account = account
            self.amount = amount
            self.description = description


# Generated at 2022-06-12 06:00:24.056301
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    #given
    from .journaling import build_journal_entry, Transaction, Posting, Account, TransactionInput, TransactionOutput
    from .accounts import AccountType, Balance

    #when
    g = compile_general_ledger_program(
        read_initial_balances = lambda period: {Account("c1"): Balance(period.since, Quantity(Decimal(0)))},
        read_journal_entries = lambda period:
        [
            build_journal_entry(
                Transaction(TransactionInput("c1", Amount(Decimal(100))),
                            TransactionOutput("c2", Amount(Decimal(100)))),
                datetime.date(2020, 1, 1))
        ],
    )(DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 1)))

    #then

# Generated at 2022-06-12 06:00:25.251209
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-12 06:00:33.552184
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    class Mock:
        @staticmethod
        def read_initial_balances(period: DateRange):
            return {Account.get_instance("1000"): Balance(period.since, Quantity(Decimal(500)))}

        @staticmethod
        def read_journal_entries(period: DateRange):
            return [JournalEntry(period.since, "Journal entry", [Posting(Account.get_instance("1000"), Quantity(Decimal(100)), "Debit")])]

    glp = compile_general_ledger_program(Mock.read_initial_balances, Mock.read_journal_entries)
    gl = glp(DateRange(datetime.date(2000, 1, 1), datetime.date(2000, 1, 1)))

# Generated at 2022-06-12 06:00:40.424425
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .accounts import AccountType
    from .journaling import Posting
    from ..commons.time import datetime_from_date, month_range

    # Account types:
    assets = AccountType(1, "Assets", lambda b: True, "Dr")
    liabilities = AccountType(2, "Liabilities", lambda b: True, "Cr")
    equity = AccountType(3, "Equity", lambda b: True, "Cr")

    # Accounts:
    bank_account = Account(assets, "Bank Account", "Bank account", "1", True)
    interest_expense_account = Account(liabilities, "Interest Expense Account", "Interest expense account", "5", True)
    interest_revenue_account = Account(equity, "Interest Revenue Account", "Interest revenue account", "6", True)

    # Journal entries:


# Generated at 2022-06-12 06:00:41.058893
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass

# Generated at 2022-06-12 06:00:49.361016
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Unit test for method ``__call__`` of class ``GeneralLedgerProgram``.
    """
    from .accounts import AccountType
    from .journaling import (
        Journal,
        Posting,
        ReadJournalEntries,
        ReadJournalEntriesAlgebra,
        read_journal_entries,
    )

    ## Provide an account for the test:
    account = Account(1000, "Cash", AccountType.ASSET)

    ## Provide a journal for the test:
    journal = [
        Journal(date=datetime.date(2018, 12, 31), description="Cash december 2018"),
        Journal(date=datetime.date(2019, 1, 31), description="Cash January 2019"),
    ]

    ## Provide a journal entry buffer:
    journal_entries: List[JournalEntry] = []


# Generated at 2022-06-12 06:01:01.185204
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    @dataclass
    class Test:
        def __call__(self, period: DateRange) -> InitialBalances:
            return {
                Account(code="1234"): Balance(date=datetime.datetime(2000, 1, 1).date(), value=Decimal("100.0")),
                Account(code="4321"): Balance(date=datetime.datetime(2000, 1, 1).date(), value=Decimal("200.0")),
            }

    ReadInitialBalances_test = ReadInitialBalances()
    ReadInitialBalances_test = ReadInitialBalances_test.__call__(
        Test(), period=DateRange(since=datetime.datetime(2000, 1, 1).date(), until=datetime.datetime(2000, 1, 1).date())
    )

# Generated at 2022-06-12 06:01:03.533612
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    @dataclass
    class _ReadInitialBalances(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            pass
    assert True



# Generated at 2022-06-12 06:01:24.242990
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from .accounts import Account, AccountGroup
    from .journaling import JournalEntry, Posting
    from .commons.numbers import Amount, Quantity
    initial_balances = {Account(1): Balance(date(2020, 2, 20), Quantity(0))}
    period = DateRange(date(2020, 2, 20), date(2020, 2, 20))
    journal = [JournalEntry(date(2020, 2, 20), 'test', [Posting(AccountGroup.ASSETS, Account(1), True, Amount(100))])]

# Generated at 2022-06-12 06:01:36.055510
# Unit test for function build_general_ledger
def test_build_general_ledger():
    ## Assert that a general ledger is built properly from initial balances and journal entries.

    ## Import journaling components:
    from ..journaling import JournalEntry, Posting, from_booking_str
    from ..journaling.types import Booking

    ## Booking for the initial balances:
    initial = [
        Booking("2019-01-01", "Initial balances", "Balance sheet accounts", ["10100 Cash", "20200 Accounts receivable"]),
        Booking("2019-01-01", "Initial balances", "Profit & loss accounts", ["40100 Sales"]),
    ]

    ## Booking entries and related postings:

# Generated at 2022-06-12 06:01:37.525547
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-12 06:01:47.092940
# Unit test for method add of class Ledger
def test_Ledger_add():
    ledger_entry1 = LedgerEntry(Ledger(Account(100), Balance(datetime.date(2020, 1, 1), Quantity(1))), Posting(JournalEntry(datetime.date(2020, 1, 1), 0, "text"), Account(100), 1, 0), Quantity(1))
    ledger_entry2 = LedgerEntry(Ledger(Account(100), Balance(datetime.date(2020, 1, 1), Quantity(1))), Posting(JournalEntry(datetime.date(2020, 1, 2), 0, "text"), Account(100), 1, 0), Quantity(2))
    l = Ledger(Account(100), Balance(datetime.date(2020, 1, 1), Quantity(1)))

# Generated at 2022-06-12 06:01:48.327459
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-12 06:01:53.672023
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # arrange
    from ..commons.zeitgeist import now
    from .journaling import Entry, Posting
    from .accounts import Account
    from dataclasses import dataclass

    @dataclass
    class FakeReadInitialBalances(ReadInitialBalances):
        def __call__(self, period):
            return {
                Account("Account ", "1010 Cash in Bank"): Balance(period.since, Quantity(0)),
                Account("Account ", "1020 Cash in Hand"): Balance(period.since, Quantity(0)),
                Account("Account ", "2010 Owners Equity"): Balance(period.since, Quantity(0)),
                Account("Account ", "4040 Heating"): Balance(period.since, Quantity(0)),
            }


# Generated at 2022-06-12 06:02:05.396037
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .accounts import (
        Account,
        AccountType,
        AssetAccount,
        AssetAccountType,
        Balance,
        ExpenseAccount,
        ExpenseAccountType,
        LiabilityAccount,
        LiabilityAccountType,
        ReveneuAccount,
        ReveneuAccountType,
    )
    from .journaling import (
        Journal,
        JournalEntry,
        Posting,
        build_journal,
        posted_on,
        transaction,
        vend_2001_from_acme,
        vend_2002_from_wile,
    )
    import datetime


# Generated at 2022-06-12 06:02:06.352066
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-12 06:02:13.473950
# Unit test for method add of class Ledger
def test_Ledger_add():
    ledger = Ledger(Account("TestLedger"), 5)
    a = Journal(1, "hello", [Posting(1, Account("testA"), 5)])
    ledger.add(Posting(1, Account("testA"), 5))
    assert int(ledger.entries[0].balance) == 10
    assert ledger.entries[0].posting.account.name == "testA"

# Generated at 2022-06-12 06:02:20.021467
# Unit test for method add of class Ledger
def test_Ledger_add():
    a=Account(1,"a1","a1")
    b=Balance(1,2)
    l=Ledger(a,b)
    j=JournalEntry(1,"j1")
    p=Posting(1,j,"s",a,1,None,None)
    o=LedgerEntry(l,p,3)
    q=l.add(p)
    assert o.amount==q.amount
    assert o.balance==q.balance
    assert o.date==q.date

if __name__ == '__main__':
    test_Ledger_add()

# Generated at 2022-06-12 06:03:00.193948
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from ..models.ledgers import GeneralLedger, Account, InitialBalances

    @dataclass
    class MyModel:
        opening: datetime.date

    @dataclass
    class MyBalance(Balance):
        model: MyModel

    model = MyModel(datetime.date(2020,9,30))


# Generated at 2022-06-12 06:03:01.065306
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass

# Generated at 2022-06-12 06:03:09.445754
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    print("GeneralLedgerProgram.__call__")
    from . import account_tree
    from . import journal_repository
    from . import initial_balances_repository
    import uuid
    # Prepare the account tree:
    _tree = account_tree.build_account_tree()
    # Prepare the journal repository:
    journal_repo = journal_repository.build_journal_repository(_tree)
    # Prepare the initial balances repository:
    init_bal = initial_balances_repository.build_initial_balances_repository(_tree)
    # Build the program:
    program = compile_general_ledger_program(
        read_initial_balances=init_bal,
        read_journal_entries=journal_repo
    )
    # Prepare the opening and closing dates:


# Generated at 2022-06-12 06:03:10.167103
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-12 06:03:18.317828
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from decimal import Decimal
    from datetime import date

    from .journaling import JournalEntry, Posting, build_journal_entry
    from .accounts import Account


    j_date = date(2019, 1, 10)
    # j_date = date.today()
    j_desc = "Some description"

    a_clients = Account(1010, "Clients")
    a_sales = Account(5020, "Sales", terminal=True)
    a_purchases = Account(4020, "Purchases", terminal=True)
    a_inventory = Account(1510, "Inventory")
    a_vat_payable = Account(2210, "VAT Payable", terminal=True)
    a_bank_01 = Account(1010, "Bank Account 01")
    a_bank_02 = Account

# Generated at 2022-06-12 06:03:18.964253
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass

# Generated at 2022-06-12 06:03:22.047020
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    ...
    # 
    # def test_ReadInitialBalances___call__(self):
        # 
        # 
        #                 

# Generated at 2022-06-12 06:03:30.485526
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from . import identity_map

    def _read_initial_balances_algebra(period: DateRange) -> InitialBalances:
        return {
            Account(1): Balance(period.since, Quantity(Decimal(887.12))),
            Account(2): Balance(period.since, Quantity(Decimal(22.12))),
            Account(3): Balance(period.since, Quantity(Decimal(0))),
        }


# Generated at 2022-06-12 06:03:40.864456
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from .journaling import Posting

    from hamcrest import assert_that, contains, contains_inanyorder, has_entry
    from unittest.mock import Mock

    m = Mock(ReadInitialBalances)

    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31))

    m.__call__(period).return_value = {
        Account("1210"): Balance(
            period.since,
            Quantity(Decimal("-100.00")),
        ),
        Account("1220"): Balance(
            period.since,
            Quantity(Decimal("1200.00")),
        ),
    }


# Generated at 2022-06-12 06:03:51.201782
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .journaling import JournalEntry, Posting, ReadJournalEntries
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, Balance
    from .general_ledgers import GeneralLedger, build_general_ledger

    @dataclass
    class FakeReadJournalEntries(ReadJournalEntries):
        """
        Reads journal entries.
        """

        def __call__(self, period: DateRange) -> Iterable[JournalEntry]:
            """
            Reads journal entries.

            :param period: Accounting period.
            :return: Iterable of :py:class:`JournalEntry` instances.
            """
            entries=[]

# Generated at 2022-06-12 06:04:11.719862
# Unit test for method add of class Ledger
def test_Ledger_add():
    p1 = Posting(Account("40123"), Amount(10), True)
    l1 = Ledger(Account("40123"), Balance(datetime.date(2020,1,1), Quantity(40)))
    l1.add(p1)
    assert l1.entries[0].posting == p1
    assert l1.entries[0].balance == p1.amount + l1.initial.value
    assert l1.entries[0].posting.journal.description == p1.journal.description


# Generated at 2022-06-12 06:04:21.156544
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .accounts import AccountType
    from .journaling import JournalEntry, Posting
    import datetime
    from decimal import Decimal
    from  ..commons.zeitgeist import DateRange
    print(datetime.date.today())
    period = DateRange(datetime.datetime(2019,1,1),datetime.datetime(2019,12,31))
    print(period.since,period.until)
    generalledger = build_general_ledger(period,JournalEntry(datetime.datetime(2020,1,1),"",[Posting(Account(AccountType.ASSETS,1),"",Decimal(0),Decimal(-3.3))]),{})
    print(generalledger)

# Generated at 2022-06-12 06:04:23.002752
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    """
    Test for method __call__ of class GeneralLedgerProgram
    """
    return GeneralLedgerProgram



# Generated at 2022-06-12 06:04:34.760552
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..commons.zeitgeist import Period
    from ..data.accounts import Account as A
    from ..data.entries import Entry, Posting
    from ..data.journal import Journal

    p = Period.from_str("2019")
    j = Journal(A.Assets.Cash, {}, "Sample transaction", Posting(Date(2019, 10, 17), A.Assets.Cash, 1000))

    g = build_general_ledger(p.range, [j], {})
    assert len(g.ledgers) == 1
    assert g.ledgers[A.Assets.Cash].balance == 1000

    j = Journal(A.Assets.Cash, {}, "Sample transaction", Posting(Date(2019, 10, 17), A.Liabilities.AccountsPayable, 2000))


# Generated at 2022-06-12 06:04:44.315523
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Tests how :py:func:`compile_general_ledger_program()` works.
    """

    ## Mocking initial balances reading function.
    def _read_initial_balances(_: DateRange) -> InitialBalances:
        return {Account("1000"): Balance(datetime.date.today(), Quantity(Decimal(1000)))}

    ## Mocking journal entries reading function.
    def _read_journal_entries(_: DateRange) -> ReadJournalEntries[_T]:
        return []

    ## Compile the program and run it:
    program = compile_general_ledger_program(_read_initial_balances, _read_journal_entries)
    gl = program(DateRange(datetime.date.today(), datetime.date.today()))

    ## Validate results.
    assert gl.period.since

# Generated at 2022-06-12 06:04:47.090168
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass

# vim: et:ts=4:sw=4:tw=0:fdm=marker:ft=python:ff=unix:fenc=utf-8:fmt=black

# Generated at 2022-06-12 06:04:47.617487
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass
    # assert True


# Generated at 2022-06-12 06:04:54.210255
# Unit test for function build_general_ledger
def test_build_general_ledger():
    p = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 31))
    j = ConstructJournalEntry()
    j.description = "Trading in cash"
    j.addPosting(ConstructPosting().addAccount("Assets:Cash").addDebit(100))
    j.addPosting(ConstructPosting().addAccount("Equity:Opening Balances").addCredit(100))

    j2 = ConstructJournalEntry()
    j2.description = "Trading in cash"
    j2.addPosting(ConstructPosting().addAccount("Assets:Cash").addDebit(200))
    j2.addPosting(ConstructPosting().addAccount("Equity:Opening Balances").addCredit(200))

    j3 = ConstructJournalEntry()

# Generated at 2022-06-12 06:05:03.547100
# Unit test for method add of class Ledger
def test_Ledger_add():
    ##TODO: we only test the debit, not the credit. 
    l = Ledger(Account("401000"),Balance(datetime.datetime(2020, 1, 1),Quantity(0)))
    posting = Posting(datetime.datetime(2020, 1, 1), Account("401000"), Quantity(0), True, "")
    entry = l.add(posting)
    assert entry.balance == Quantity(0)
    posting2 = Posting(datetime.datetime(2020, 1, 2), Account("401000"), Quantity(10), True, "")
    entry2 = l.add(posting2)
    assert entry2.balance == Quantity(10)

# Generated at 2022-06-12 06:05:11.806856
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():

    from .confirmation import DebtorConfirmation, CreditorConfirmation, Confirm, Confirmations

    #: Sample nominal ledger:

# Generated at 2022-06-12 06:05:48.497612
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():

    ## Mock read initial balances algebra.
    def _read_initial_balances(period: DateRange):
        return {Account('1'): Balance(period.since, Quantity(Decimal(1000)))}

    ## Mock read journal entries algebra.
    def _read_journal_entries(period: DateRange):
        return [JournalEntry(['12/1/2020'], 'Debit entry 1', [Posting(Account('1'), 'Debit', Quantity(Decimal(100)))])]

    ## Compile the general ledger program.
    program = compile_general_ledger_program(
        _read_initial_balances,
        _read_journal_entries,
    )

    ## Run the program and test the results.

# Generated at 2022-06-12 06:05:59.759830
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from itertools import chain
    from datetime import date
    from decimal import Decimal
    from typing import cast
    from .commons.numbers import Amount
    from .accounts import Account, AssetAccount, LiabilityAccount, ExpenseAccount, RevenueAccount
    from .journaling import Debit, Credit, JournalEntry, Posting, ReadJournalEntries, BuildJournalEntry


# Generated at 2022-06-12 06:06:00.930890
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # No testable state; only contracts
    pass


# Generated at 2022-06-12 06:06:11.119352
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    A unit test for function compile_general_ledger_program().
    """
    ## Let's define and compile the general ledger program:
    gl_program = compile_general_ledger_program(lambda period: {"A": Balance(period.since, Quantity(10))}, lambda period: [])

    ## Let's execute the general ledger program:
    period = DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31))
    gl = gl_program(period)

    ## We assert that we got a general ledger:
    assert isinstance(gl, GeneralLedger)

    ## We assert the general ledger period is what we expected:
    assert gl.period == period

    ## We assert the length of the general ledger is one:
    assert len(gl.ledgers) == 1

    ## We assert the

# Generated at 2022-06-12 06:06:22.505732
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Testing case 1:
    test_account = Account("ACC001")
    test_journal = JournalEntry("JE001", "Description", datetime.date(2020, 1, 1))
    test_posting = Posting(test_account, 100, test_journal)
    test_balance = Balance(datetime.date(2020, 1, 1), 100)
    test_ledger = Ledger(test_account, test_balance)
    test_ledger.add(test_posting)
    assert len(test_ledger.entries) == 1
    assert test_ledger.entries[0].posting.account == test_account
    assert test_ledger.entries[0].posting.amount == 100
    assert test_ledger.entries[0].balance == 200


# Generated at 2022-06-12 06:06:34.526908
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .journaling import ReadJournalEntries
    from .accounts import Account
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .ledger import build_general_ledger
    from dataclasses import dataclass, field
    from typing import Dict, List, Tuple, Union
    import datetime

    @dataclass
    class JournalEntry:
        date: datetime.date
        description: str
        postings: List['Posting']

    @dataclass
    class Posting:
        account: Account
        amount: Decimal
        direction: int

    #: Defines a generic type variable.
    T = TypeVar("T")

    @dataclass
    class GeneralLedger:
        period: DateRange

# Generated at 2022-06-12 06:06:46.127413
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    """
    Unit test for method __call__ of class ReadInitialBalances
    """
    ## Define the set of accounts.
    from .accounts import Accounts


# Generated at 2022-06-12 06:06:57.338461
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from ..commons.zeitgeist import parse_date
    from ..domain.accounting import Account, Balance, AccountType
    from ..domain.journaling import LedgerEntry as JournalEntry
    from .accounts import AccountLedgerHeader
    import decimal

    ## Various accounts:
    equity = Account(AccountLedgerHeader(1, AccountType.EQUITY, "Equity"))
    ri = Account(AccountLedgerHeader(2, AccountType.INCOME, "Revenues"))
    ex = Account(AccountLedgerHeader(3, AccountType.EXPENSE, "Expenses"))
    cash = Account(AccountLedgerHeader(4, AccountType.ASSET, "Cash"))

    ## Initial balances:

# Generated at 2022-06-12 06:07:04.777629
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Unit test for function compile_general_ledger_program
    """
    from unittest.mock import Mock

    print("general ledger.compile_general_ledger_program")

    read_initial_balances = Mock(return_value={})
    read_journal_entries = Mock(return_value=[])

    program = compile_general_ledger_program(read_initial_balances, read_journal_entries)
    assert callable(program)

    period = DateRange(since=datetime.date(2020, 1, 1), until=datetime.date(2020, 12, 31))
    program(period)

    assert read_initial_balances.call_count == 1
    assert read_journal_entries.call_count == 1

    read_initial_balances.assert_called_once_with

# Generated at 2022-06-12 06:07:12.553573
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Unit test for compiling a general ledger program.
    """
    ## Import Python modules:
    import pytest
    from decimal import Decimal
    from datetime import date

    ## Import apm modules:
    from apm.core import Account, Amount, Balance, DateRange, JournalEntry, Posting

    @dataclass
    class _MockLedgerEntry:
        account: Account
        value: Amount

    @dataclass
    class _MockJournalEntry:
        date: date
        postings: List[Posting]

    @dataclass
    class _MockJournalEntries:
        entries: List[_MockJournalEntry]

    @dataclass
    class _MockInitialBalances:
        entries: List[_MockLedgerEntry]

    ## Mock implementations of algebras:

# Generated at 2022-06-12 06:08:26.355197
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from random import choice
    from os.path import dirname, join
    from csv import DictReader
    from ..commons.zeitgeist import parse_date
    from .accounts import AccountType
    from .journaling import read_journal_entries_csv, JournalEntry, Posting, Direction
    from .generic import Balance

    # read initial balance
    with open(join(dirname(__file__), "../../data/initial_balances.csv")) as f:
        d = DictReader(f, delimiter=",")
        initial_balances = {Account(int(r["account"]), r["name"], AccountType[r["type"]]): Balance(parse_date(r["date"]), int(r["value"])) for r in d}

    # read journals
    journal_entries

# Generated at 2022-06-12 06:08:26.871613
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass

# Generated at 2022-06-12 06:08:32.978510
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from datetime import date
    from decimal import Decimal
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting

    ## Mock implementation of ReadJournalEntries:

# Generated at 2022-06-12 06:08:44.362916
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    """
    Ensure that method '__call__' of class 'ReadInitialBalances' works as per expectations.
    """
    from .accounts import AccountType
    from .commons import AccountNotFoundError

    ## Set up test subject:
    class TestSubject:
        """
        Test subject.
        """

        def __call__(self, period: DateRange) -> InitialBalances:
            return {Account.from_string("1000"): Balance(period.since, Quantity(Decimal(1000)))}

    ## Execute the test.
    x = TestSubject()
    expected = {Account.from_string("1000"): Balance(datetime.date(2020, 1, 1), Quantity(Decimal(1000)))}

# Generated at 2022-06-12 06:08:51.537948
# Unit test for function build_general_ledger
def test_build_general_ledger():
    """
        Unit test for function build_general_ledger
    """

    from timeit import default_timer as timer

    from ..commons import zeitgeist
    from ..commons.zeitgeist import days_period
    from ..journaling.memories import memory_journal_entries
    from ..tests.fixtures import TestCases
    from .memories import memory_initial_balances

    def generate_journal_entries(amount: Amount, cntracct: Account) -> Iterable[JournalEntry[_T]]:
        """
        Generates journal entries locally.
        """
        i = 0
        while True:
            i = i + 1

# Generated at 2022-06-12 06:08:52.941344
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # TODO: to implement
    return


# Generated at 2022-06-12 06:08:53.992966
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-12 06:09:01.001717
# Unit test for method add of class Ledger
def test_Ledger_add():
    date, date0 = datetime.date.today(), datetime.date(1900, 1, 1)
    a, a1, a2 = Account('a'), Account('a1'), Account('a2')
    p = Posting(a, 1, date, 'test')
    l = Ledger(a, Balance(date0, 0))
    l.add(p)
    assert l.entries[-1].posting.__dict__ == p.__dict__



# Generated at 2022-06-12 06:09:01.618301
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass

# Generated at 2022-06-12 06:09:12.061553
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..accounts import Accounts
    from ..journaling import create_journal_entry

    period = DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31))
    account_a = Accounts.a.balance
    account_b = Accounts.b.balance
    account_c = Accounts.c.balance
    initial_balances = {account_a: Balance(period.since, Quantity(1)), account_b: Balance(period.since, Quantity(2))}

    journal1 = create_journal_entry(
        date = datetime.date(2018, 7, 1),
        description = "Test journal entry",
        postings = [account_a.C(100), account_b.D(100)],
    )
