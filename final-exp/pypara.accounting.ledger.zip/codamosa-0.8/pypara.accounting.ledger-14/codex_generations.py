

# Generated at 2022-06-12 06:00:06.110857
# Unit test for method add of class Ledger
def test_Ledger_add():
    import os
    import datetime
    from decimal import Decimal
    from dataclasses import field
    from accounting.journaling import JournalEntry,Posting,Journal
    from accounting.commons.numbers import Amount, Quantity
    from accounting.commons.zeitgeist import DateRange
    from accounting.accounts import Account, AccountType
    from accounting.accounting import GeneralLedger,Balance


# Generated at 2022-06-12 06:00:18.112190
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account, AccountType
    from .commons import LedgerType
    from .journaling import Journal, Posting
    from .numbers import Amount, Direction

    account = Account(AccountType.ASSET, "00001", "My account")
    initial = Balance(datetime.date(2020, 1, 1), Amount(Decimal(0)))
    journal = Journal(
        datetime.date(2020, 2, 15),
        "My journal",
        Posting(Direction.DEBIT, Amount(Decimal(100)), account, None),
    )
    ledger = Ledger(LedgerType.ASSET, initial)
    entry = ledger.add(journal.postings[0])
    assert entry is ledger.entries[0]



# Generated at 2022-06-12 06:00:28.453946
# Unit test for function build_general_ledger
def test_build_general_ledger():
    """Unit test for function build_general_ledger"""
    from ..commons.zeitgeist import parse_date

    ## The journaling entries:
    je1 = JournalEntry(parse_date("2018-11-03"), "Received A", [Posting("Debit", "Bank", Quantity(Decimal("150"))),],)
    je2 = JournalEntry(parse_date("2018-11-05"), "Received B", [Posting("Debit", "Sales", Quantity(Decimal("50"))),],)

    ## The initial balances:
    initial = {
        "Bank": Balance(parse_date("2018-11-03"), Quantity(Decimal("0"))),
        "Sales": Balance(parse_date("2018-11-03"), Quantity(Decimal("0"))),
    }

    ## Build the general ledger:
    general_led

# Generated at 2022-06-12 06:00:32.315549
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..books.journaling import JournalEntry
    from ..books.accounts import Account, AccountType
    from ..books.posting import Posting
    from ..commons.zeitgeist import DateRange
    from .accounts import Balance
    from .generic import Quantity
    from decimal import Decimal
    period = DateRange(datetime.date(2019,1,1), datetime.date(2019,1,3))

# Generated at 2022-06-12 06:00:39.839305
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.operations import read_journal_entries_from_csv, read_initial_balance_from_excel
    from ..commons.zeitgeist import OneMonth

    ## Read initial balances as of end of previous financial period:
    path = "./commons/examples/directory/initial_balance.xlsx"
    read_initial_balance = read_initial_balance_from_excel(path, "Initial balance")
    initial_balances = read_initial_balance(DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 31)))

    ## Read journal entries:
    path = "./commons/examples/directory/journal.csv"
    read_journal_entries = read_journal_entries_from_csv(path)
    journal_entries = read_journal

# Generated at 2022-06-12 06:00:48.838012
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    def do_test(
        read_initial_balances,
        read_journal_entries,
        period,
        expected_initial_balances,
        expected_journal_entries,
        expected_general_ledger
    ):
        """
        Executes a test case.

        :param read_initial_balances: Algebra implementation which reads initial balances.
        :param read_journal_entries: Algebra implementation which reads journal entries.
        :param period: Accounting period.
        :param expected_initial_balances: Expected initial balances.
        :param expected_journal_entries: Expected journal entries.
        :param expected_general_ledger: Expected general ledger.
        :return: None.
        """

# Generated at 2022-06-12 06:00:58.702272
# Unit test for method add of class Ledger
def test_Ledger_add():
    account = Account()
    initial_balance = Balance(datetime.date(2020, 1, 1), Quantity(Decimal(123.45)))
    ledger = Ledger(account, initial_balance)
    test_posting = Posting(None, account, datetime.date(2020, 1, 2), Quantity(Decimal(23.45)))
    result = ledger.add(test_posting)
    assert result.date == test_posting.date
    assert result.amount == test_posting.amount
    assert result.balance == Quantity(Decimal(123.45) + Decimal(23.45))

##
## EOF
##

# Generated at 2022-06-12 06:01:06.291638
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():

    # Setup
    OpeningDate = datetime.date (2018, 1, 1)
    ClosingDate = datetime.date (2018, 6, 30)
    def my_read_initial_balances(period):
        assert period.since == OpeningDate
        assert period.until == ClosingDate
        return InitialBalances ({
            Account ("Assets") : Balance (OpeningDate, Decimal (0)),
            Account ("Expenses") : Balance (OpeningDate, Decimal (0)),
            })

# Generated at 2022-06-12 06:01:15.238925
# Unit test for method add of class Ledger
def test_Ledger_add():
    account = Account(code='01.02.01.01', description="")
    entry = LedgerEntry(ledger=None, posting=None, balance=Quantity(Decimal(0)))

    testLedger = Ledger(account = account, initial = Balance(datetime.date(1,1,1), Quantity(Decimal(0))))
    testLedger.add(Posting(account=account,direction=None,amount=Amount(Decimal(0))))
    assert testLedger.initial.value == Decimal(0)
    assert testLedger.account.code == '01.02.01.01'
    assert testLedger.entries[-1] == entry

# Generated at 2022-06-12 06:01:16.315189
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    # FIXME: Implement me!
    pass

# Generated at 2022-06-12 06:01:33.631199
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ._testing import ReadInitialBalancesDouble, ReadJournalEntriesDouble

    ## Build the general ledger program:
    general_ledger_program = compile_general_ledger_program(ReadInitialBalancesDouble(), ReadJournalEntriesDouble())

    ## Build and verify the general ledger:
    gl = general_ledger_program(DateRange(datetime.date(year=2018, month=1, day=1), datetime.date(year=2018, month=2, day=28)))
    assert gl.period == DateRange(datetime.date(year=2018, month=1, day=1), datetime.date(year=2018, month=2, day=28))
    assert gl.ledgers["C10001"].initial.value == Decimal("0.00")
    assert gl.ledgers["C10001"].initial.date == dat

# Generated at 2022-06-12 06:01:42.154977
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from datetime import date
    from decimal import Decimal
    from itertools import chain
    from collections import namedtuple

    from ..fakes import Fake, FakeAccount, FakeCreditCardAccount, FakeEntry, FakePosting

    class FakeReadInitialBalances(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {}


# Generated at 2022-06-12 06:01:50.279536
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from pytest import mark
    from ..commons import ledger_strings

    @dataclass
    class State:
        """
        Defines the state of the individual test case.
        """

        #: Date range of the test case.
        period: DateRange

        #: Initial balances of the test case.
        initial_balances: InitialBalances

        #: Journal entries of the test case.
        journal_entries: Iterable[JournalEntry[str]]

        #: Expected general ledger.
        general_ledger: GeneralLedger[str]


# Generated at 2022-06-12 06:01:57.988451
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import DateRange
    from ..commons.numbers import Amount, Quantity
    from .accounts import Account

    # Create a GeneralLedger
    general_ledger = build_general_ledger(
        DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31)),
        [],
        {}
    )

    # Create a Ledger
    ledger = Ledger(Account(1), Balance(datetime.date(2019, 1, 1), Quantity(Decimal(1))))

    # Create a Posting
    posting = Posting(
        datetime.date(2019, 1, 1),
        Amount(Decimal(2)),
        1,
        0,
    )

    # Create a LedgerEntry
    ledger.add(posting)

    # Test attribute

# Generated at 2022-06-12 06:02:08.281846
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..journaling import ReadJournalEntries
    from ..journaling.memorystorage import read_journal_entries

    ## Initial balances:
    initial_balances = {"00001": Balance(datetime.date(2020, 3, 31), Quantity(Decimal(300)))}

    ## Initialize read initial balances algebra:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        return initial_balances

    ## Journal entries:
    j1 = JournalEntry(datetime.date(2020, 4, 1), "Purchased office supplies", [
        Posting("00001", Amount(Decimal(50))),
        Posting("00002", Amount(Decimal(50))),
    ])

# Generated at 2022-06-12 06:02:19.467769
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Test data
    account = Account(1)
    posting = Posting(Decimal(100), Account(2), Account(3), datetime.date(1,1,1))
    initial = Balance(datetime.date(1,1,1), Decimal(100))
    ledger = Ledger(account, initial)
    # Test execution
    ledger_entry = ledger.add(posting)
    # Test assertions
    assert ledger_entry.ledger == ledger, f"ledger_entry.ledger:{ledger_entry.ledger}, ledger:{ledger}"
    assert ledger_entry.posting == posting, f"ledger_entry.posting:{ledger_entry.posting}, posting:{posting}"

# Generated at 2022-06-12 06:02:25.861226
# Unit test for method add of class Ledger
def test_Ledger_add():
    account = Account("Assets")
    entries: List[LedgerEntry[_T]] = []
    posting = Posting("2018-07-07","Debit","Assets","Expenses", Amount(Decimal(10)))
    balance = Balance("2018-07-07", Quantity(Decimal(0)))
    ledger = Ledger(account, balance)
    entries.append(ledger.add(posting))
    assert entries[0].balance == ledger.initial.value + posting.amount * posting.direction.value
    assert entries[0].description == posting.journal.description
    assert entries[0].amount == posting.amount
    assert len(ledger.cntraccts) > 0
    assert entries[0].is_debit == posting.is_debit
    assert entries[0].is_credit == posting.is_credit
    assert entries

# Generated at 2022-06-12 06:02:30.462508
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    assert compile_general_ledger_program(ReadInitialBalances(), ReadJournalEntries()) \
        (DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31))) \
        == GeneralLedger(DateRange(datetime.date(2019, 1, 1), datetime.date(2019, 12, 31)), {})

# Generated at 2022-06-12 06:02:38.039659
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .journaling import SimpleTransaction
    from .journaling import SimpleJournal
    from .journaling import ReadJournalEntries
    from decimal import Decimal
    from .accounts import Account
    from .accounts import AccountType
    from .commons.numbers import Amount

    tx = SimpleTransaction(
        datetime.date(2019, 6, 3),
        "some description 2",
        [
            Posting(Account("abc", AccountType.ASSET, ""), Amount(1)),
            Posting(Account("def", AccountType.CURRENT_ASSET, ""), Amount(-1)),
        ],
    )


# Generated at 2022-06-12 06:02:46.922431
# Unit test for method add of class Ledger
def test_Ledger_add():
    journals = [JournalEntry("1", "Paycheck", "Paycheck #1", datetime.date.today(), None, [Posting("Cash", Amount("1.00"))])]
    initial_balances = {}
    period = DateRange()
    journal_entries = [j for j in journals]
    Cash = Account("Cash")
    initial_balances.update({Cash: Balance(period.since, Quantity("0.00"))})
    ledgers = {Cash: Ledger(Cash, initial_balances[Cash])}

# Generated at 2022-06-12 06:03:07.456448
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from decimal import Decimal
    from ..finance.data.accounts import Account, AccountType, AccountLedger
    from ..finance.data.journaling import JournalEntry, Posting
    from ..finance.data.general_ledger import build_general_ledger, Ledger, InitialBalances
    from ..commons.numbers import Quantity
    from ..commons.zeitgeist import DateRange
    
    # Create account
    Cash = Account(
        'Cash',
        AccountType.ASSET,
        AccountLedger.TRANSACTIONAL
    )
    Cost = Account(
        'Cost',
        AccountType.ASSET,
        AccountLedger.TRANSACTIONAL
    )

# Generated at 2022-06-12 06:03:16.554090
# Unit test for function build_general_ledger
def test_build_general_ledger():
    """
    Unit test for function :py:func:`build_general_ledger`.
    """
    from .journaling import JournalEntry, Posting, from_rows
    from .accounts import AccountType, Account

    ## Define some simple data:
    period = DateRange(since=datetime.date(year=2020, month=1, day=1), until=datetime.date(year=2020, month=1, day=4))

# Generated at 2022-06-12 06:03:28.890009
# Unit test for method add of class Ledger
def test_Ledger_add():
    testaccount1 = Account("Cash", True)
    testbalance1 = Balance(datetime.date(2020, 1, 1), Quantity(Decimal(1000)))
    testjournal1 = JournalEntry(datetime.date(2020, 1, 1), "Recieved 200")
    testposting1 = Posting(testaccount1, testjournal1, Quantity(Decimal(200)))
    test_ledger = Ledger(testaccount1, testbalance1)
    test_posting = test_ledger.add(testposting1)
    assert test_posting.balance == Quantity(Decimal(1200))
    assert test_posting.date == datetime.date(2020, 1, 1)
    assert test_posting.description == "Recieved 200"
    assert test_posting.amount == Quantity(Decimal(200))
    assert test_

# Generated at 2022-06-12 06:03:30.364186
# Unit test for method add of class Ledger
def test_Ledger_add():
    le = Ledger()
    # ve = le.add()
    # assert , "le.add() != ve"

# Generated at 2022-06-12 06:03:32.643222
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    class MockReadInitialBalances(ReadInitialBalances):
        def __call__(self, period: DateRange) -> InitialBalances:
            return {None: None}

    assert MockReadInitialBalances().__call__(None) == {None: None}


# Generated at 2022-06-12 06:03:41.763619
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from decimal import Decimal
    from typing import Dict
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import Posting, JournalEntry
    from .generic import Balance
    from .ledgers import build_general_ledger, Ledger, GeneralLedger

    #Test data:
    open_date = date(2020, 1, 1)
    close_date = date(2020,12,31)
    period = DateRange(open_date, close_date)

    #Accounts:
    a1 = Account("Assets", "Equities", "Cash")
    a2 = Account("Revenues", "Product-based", "Sales")

# Generated at 2022-06-12 06:03:51.921454
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from .accounts import Account
    from .generic import Balance
    from .journaling import Journal
    from .journaling import Posting
    from .journaling import Transaction
    from .journaling import Direction
    from .ledgers import GeneralLedger
    from .ledgers import Ledger
    from datetime import date
    from decimal import Decimal
    import inspect
    from pytest import raises
    from typing import Dict
    from typing import List
    from typing import cast
    from typing import TYPE_CHECKING
    if TYPE_CHECKING:
        from pytest import mark
    test_date = date(year=2019, month=1, day=31)

# Generated at 2022-06-12 06:04:02.753787
# Unit test for function build_general_ledger
def test_build_general_ledger():
    
    # create a test journal entry
    je = JournalEntry("test_entry")
    a1 = Account("aaaa", 'aaa', True)
    a2 = Account("bbbb", 'bbb', True)
    a1.balance = Quantity("0.0")
    a2.balance = Quantity("0.0")
    je.add_posting(Posting(a1, Quantity("2000.00"), "debit"))
    je.add_posting(Posting(a2, Quantity("1000.00"), "credit"))
    print("JournalEntry: " + str(je))

    period = DateRange(datetime.date(2019,1,1), datetime.date(2019,1,1))

    initial_balances = dict()
    initial_balances[a1] = Balance(period.since, Quantity("0.00"))

# Generated at 2022-06-12 06:04:13.407943
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import Posting, JournalEntry, Journal
    from .accounts import Account

    entries: List[JournalEntry[str]] = []

    cash = Account(
        name="Cash",
        number="100",
        type="Asset",
        description="Cash",
        contra=False,
        subledger=False,
        normal_balance="debit",
    )
    purchases = Account(
        name="Purchases",
        number="200",
        type="Expense",
        description="Purchases",
        contra=False,
        subledger=False,
        normal_balance="debit",
    )

# Generated at 2022-06-12 06:04:15.612846
# Unit test for method add of class Ledger
def test_Ledger_add():
    ## ledger = Ledger(account, initial)
    pass
 

# Generated at 2022-06-12 06:04:43.319598
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Creating a journal entry
    je = JournalEntry(datetime.date(2020,3,15), "This is a test")

    # Creating a posting
    p1 = Posting(je, quantity=5, account=1)

    # Creating an account ledger
    l = Ledger(p1.account, Balance(datetime.date(2020,3,1),Quantity(0)))

    # Adding a new ledger entry
    p2 = Posting(je, quantity=15, account=1)
    le = l.add(p2)

    assert(le.balance == Quantity(20))

# Generated at 2022-06-12 06:04:43.867252
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass

# Generated at 2022-06-12 06:04:50.326168
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from datetime import date
    from ..commons.numbers import Amount
    from ..commons.zeitgeist import DateRange
    from .accounts import Account, AccountType
    from .journaling import Posting, build_journal_entry, JournalEntry
    from .generic import Balance

    assert build_general_ledger(DateRange(period_since=date(2014, 12, 1), period_until=date(2014, 12, 31)), None, None)

    receivables_ledger = Ledger(Account(code='100', type=AccountType.ASSET), Balance(DateRange(period_since=date(2014, 12, 1), period_until=date(2014, 12, 3)), Amount(Decimal(0.00))))


# Generated at 2022-06-12 06:04:56.119719
# Unit test for method add of class Ledger
def test_Ledger_add():
    l = Ledger('AAAA', Balance(datetime.date(2020,1,1), Quantity(Decimal(0))))
    l.add(Posting(datetime.date(2020,1,1),Journal('AAAA', 'BBBB', [Posting(datetime.date(2020,1,1),'CCCC', Quantity(Decimal(0))),\
              Posting(datetime.date(2020,1,1),'AAAA', Quantity(Decimal(50)))])))
    assert l.entries[0].amount == Amount(50)

# Generated at 2022-06-12 06:05:02.069219
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .journaling import JournalEntry, Posting
    from .accounts import Account

    ## Prerequisites:
    account = Account('1')
    posting = Posting(JournalEntry('4'), account, '4')

    ## Actual test:
    ledger = Ledger(account, '2')
    ledger.add(posting)

    ## Verdict:
    return True


# Generated at 2022-06-12 06:05:10.837575
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from ..commons.zeitgeist import DateRange

    balances = {
        Account("H101-0000"): Balance(datetime.date(2018, 1, 1), Quantity(0)),
        Account("H101-0001"): Balance(datetime.date(2018, 1, 1), Quantity(100)),
        Account("H101-0002"): Balance(datetime.date(2018, 1, 1), Quantity(200)),
    }


# Generated at 2022-06-12 06:05:21.801538
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from decimal import Decimal
    from unittest.mock import MagicMock
    from dataclasses import asdict
    from ..commons.zeitgeist import DateRange, Date
    from .accounts import Account
    from .generic import Balance

    # Arrange
    period = DateRange(Date(2019, 1, 1), Date(2019, 12, 31))
    mock = MagicMock(spec=ReadInitialBalances)

# Generated at 2022-06-12 06:05:32.979446
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():

    # Set up fixtures:
    def read_initial_balances(period: DateRange):
        return {
            Account("A", "B", "C"): Balance(period.until, Quantity(5)),
            Account("X", "Y", "Z"): Balance(period.until, Quantity(10)),
        }


# Generated at 2022-06-12 06:05:41.803360
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    """
    Tests the function compile_general_ledger_program.
    """
    from .journaling import build_journal, compile_read_journal_entries

    from .accounts import (
        Account,
        AccountType,
        compile_read_accounts,
        test_compile_read_accounts,
        test_read_accounts,
    )

    from .ledgers import test_read_initial_balances

    # Compile a program which reads accounts:
    read_accounts = compile_read_accounts(
        test_read_accounts(dict(john=Account("A1", "John's checking account", AccountType.ASSETS)))
    )
    # Read the accounts:
    accounts = read_accounts()

    # Compile a program which reads journal entries:
    read_journal_entries = compile

# Generated at 2022-06-12 06:05:49.877963
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..core.journaling import make_journal

    #: Accounting period.
    period = DateRange(datetime.date(year=2017, month=1, day=1), datetime.date(year=2017, month=12, day=31))

    #: Initial balances.
    initial = {
        Account("A/A"): Balance(period.since, Quantity(100)),
        Account("A/B"): Balance(period.since, Quantity(200)),
        Account("A/C"): Balance(period.since, Quantity(300)),
    }

    #: Make a journal entry with given posting.
    def entry(pstng):
        return make_journal('DESC', [(pstng, None)])

    #: Journal entries to post.

# Generated at 2022-06-12 06:06:25.465574
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    ## Get initial balances as of the end of previous financial period:
    def read_initial_balances(period: DateRange) -> InitialBalances:
        if period.since != datetime.date(2020, 1, 1):
            raise AssertionError("Not expected period:", period)

        ## Done, return:
        return {
            Account(1, "Cash"): Balance(datetime.date(2019, 12, 31), Quantity(Decimal(1000))),
            Account(2, "Inventory"): Balance(datetime.date(2019, 12, 31), Quantity(Decimal(100))),
        }

    ## Read journal entries and return:
    def read_journal_entries(period: DateRange) -> Iterable[JournalEntry[_T]]:
        if period.since != datetime.date(2020, 1, 1):
            raise

# Generated at 2022-06-12 06:06:36.427926
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    import datetime
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import Journal, JournalEntry, Posting

    ## Build accounts:
    account_100 = Account(100, "Cash")
    account_101 = Account(101, "Accounts receivable")
    account_102 = Account(102, "Allowance for doubtful accounts")
    account_103 = Account(103, "Inventory")
    account_110 = Account(110, "Prepaid insurance")
    account_120 = Account(120, "Office supplies")

    account_200 = Account(200, "Accounts payable")
    account_201 = Account(201, "Notes payable")
    account_203 = Account(203, "Unearned revenue")
    account_204 = Account(204, "Capital")


# Generated at 2022-06-12 06:06:44.854314
# Unit test for method add of class Ledger
def test_Ledger_add():
    test_account = Account("TEST", "TEST ACCOUNT", "A")
    test_initial = Balance(datetime.datetime.now().date(), Quantity(Decimal(100)))
    test_posting = Posting(
        datetime.datetime.now().date(), Decimal(20), test_account, "DEBIT", JournalEntry("test")
    )
    test_ledger = Ledger(test_account, test_initial)
    test_entry = test_ledger.add(test_posting)
    assert test_entry.balance == Quantity(Decimal(120))



# Generated at 2022-06-12 06:06:51.190024
# Unit test for method add of class Ledger
def test_Ledger_add():
    a = Ledger(Account('A', Account.Level.terminal),Balance(datetime.date(2020,1,1), Quantity(Decimal(100))))
    J = JournalEntry(datetime.date(2020,1,2), 'test', [Posting(a.account, Amount(Decimal(20)), 'A')])
    a.add(J.postings[0])
    assert a.entries[0].balance == Quantity(Decimal(120))


# Generated at 2022-06-12 06:07:01.274731
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from .algebras import ReadInitialBalances as Algebra
    from .types import Balance as Type

# Generated at 2022-06-12 06:07:11.228613
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import journal_entry

    openings = {
        Account("1010000"): Balance(datetime.date(2020, 1, 1), Quantity(Decimal(1000.0))),
        Account("1020000"): Balance(datetime.date(2020, 1, 1), Quantity(Decimal(2000.0))),
    }
    postings = (
        journal_entry(datetime.date(2020, 1, 1), "Payroll", 1, [Account("1010000"), Account("1020000")])
        + journal_entry(datetime.date(2020, 1, 1), "VAT", 1, [Account("1020000"), Account("1030000")])
    )
    period = DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 1, 31))
    gl = build_general_led

# Generated at 2022-06-12 06:07:20.674421
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    import time
    import uuid
    from ..commons.reframing import Identity
    from ..lib.pq import Program, compiler, runtime
    from .accounts import Account, read_accounts
    from .generic import Balance

    ## Define the application context.
    context = Program(
        read_accounts=read_accounts,
        read_journal_entries=lambda period: [],
        read_initial_balances=lambda period: {
            Account("ACCOUNT-A000"): Balance(period.since, Quantity(0)),
            Account("ACCOUNT-A001"): Balance(period.since, Quantity(0)),
            Account("ACCOUNT-A002"): Balance(period.since, Quantity(0)),
        },
    )

    ## Compile the application.
    program = compiler.compile(context, Identity)



# Generated at 2022-06-12 06:07:31.457468
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from ..accounting.journaling import JournalEntry, Posting, Account, Cash, AccountType, Balance

    id, period = "1", DateRange(datetime.date(2018, 1, 1), datetime.date(2018, 12, 31))

# Generated at 2022-06-12 06:07:40.231813
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Create JournalEntry and Posting
    j = JournalEntry("Test", [Posting("a", Amount.of(2))])
    p = j.postings[0]
    # Create initial balances and Ledger
    initial_balances = {p.account: Balance(datetime.date(2018, 12, 31), Quantity.of(1))}
    l = Ledger(p.account, initial_balances[p.account])
    # Add posting to Ledger
    entry = l.add(p)
    # Check if entry has been added to ledger
    assert len(l.entries) == 1
    assert entry.balance.value == Quantity.of(3)

# Generated at 2022-06-12 06:07:40.755287
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    pass

# Generated at 2022-06-12 06:08:53.463733
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..ledger import build_general_ledger
    from ..booking.algebra.accounting.readjournalentries import ReadJournalEntries
    from ..booking import JournalEntry
    from ..commons.zeitgeist import DateRange
    from ..commons.accounting import Account
    from ..commons.numbers import Amount
    from .initialbalances import InitialBalances
    from .accounts import Account
    from decimal import Decimal

    period = DateRange("2020-01-01", "2020-01-02")
    initial_balances = InitialBalances()
    initial_balances[Account("A")] = Balance("2020-01-01", Quantity(Decimal("100")))
    initial_balances[Account("B")] = Balance("2020-01-01", Quantity(Decimal("200")))
    initial_balances

# Generated at 2022-06-12 06:09:03.449481
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from decimal import Decimal as D
    from .accounts import DefineAccount
    from .journaling import Posting, _JournalEntry, _Posting

    ## Define accounts:
    _account = DefineAccount()
    A = _account(101, "Test Account #1", False)
    B = _account(102, "Test Account #2", False)
    C = _account(201, "Test Account #3", False)

    ## Define posting:
    _posting = _Posting()
    posting_a = _posting(A, D("100"), None)
    posting_b = _posting(B, None, D("100"))
    posting_c = _posting(C, D("200"), None)

    ## Define journal entry:
    _journal = _JournalEntry()

# Generated at 2022-06-12 06:09:12.880768
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .currency import Currency
    from .journaling import Journal

    # Create objects for the test
    account = Account("Test account", Account.Category.ASSET)
    global_currency = Currency("Global currency", Decimal(1.0))
    currency = Currency("Test currency", Decimal(1.0))
    account.currencies[currency] = True
    account.currencies[global_currency] = True
    
    # Create the ledger
    ledger = Ledger(account, Balance(datetime.date(2000, 1, 1), Quantity(Decimal(100))))

    # Create the journal entry
    journal = Journal(
        datetime.date(2000, 1, 2),
        "Test description",
        DescriptionType.TEXT,
    )

    # Create the posting

# Generated at 2022-06-12 06:09:22.476167
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .journaling import Journal, JournalEntry
    from .accounts import Account
    from .types import Company
    from ..commons.numbers import Amount, Quantity
    from . import journaling
    from . import accounts
    from . import types
    from datetime import datetime
    from datetime import date
    from decimal import Decimal

    # Define Journal Entry 1
    date_1 = date(2002, 2, 2)
    journal_1 = Journal(date_1, 'Transaction 1')
    acc1 = Account(account_type=accounts.account_types.Asset, account_subtype=accounts.account_subtypes.Cash,
                   company=Company(), name='Cash', description='Cash balance')
    journal_1.post(acc1, journaling.Debit, Amount(Decimal(10.00)))

# Generated at 2022-06-12 06:09:26.187517
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    ##
    class _ReadInitialBalancesImpl(ReadInitialBalances):
        def __init__(self):
            pass
        def __call__(self, period: DateRange) -> InitialBalances:
            pass
    ##
    ##
    ##
    ##


# Generated at 2022-06-12 06:09:27.134531
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    # TODO
    pass


# Generated at 2022-06-12 06:09:31.252184
# Unit test for method add of class Ledger
def test_Ledger_add():

    from ..commons.zeitgeist import now

    a = Account(code="A", title="Account")
    b = Account(code="B", title="Account")
    l = Ledger(a, Balance(now(), Quantity(0)))
    p = Posting(a, now(), Quantity(100), "Posting")
    r = l.add(p)

    assert r.balance == Quantity(100)


# Generated at 2022-06-12 06:09:33.729405
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-12 06:09:39.468959
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .algebras.readjournalentries import read_journal_entries
    from .algebras.readinitialbalances import read_initial_balances
    from .journaling import build_journal_entry
    from .accounts import build_account
    from ..commons.zeitgeist import parse_datetime
    @dataclass
    class AccountWithInitialBalance:
        account: Account
        initial_balance: Balance
        posting_date: datetime.date
        
    @dataclass
    class JournalEntryWithInitialBalance:
        journal_entry: JournalEntry
        initial_balance: Quantity
        
    @dataclass
    class GeneralLedgerWithInitialBalance:
        general_ledger: GeneralLedger
        initial_balance: Quantity
        posting_date: datetime.date


# Generated at 2022-06-12 06:09:48.870502
# Unit test for method add of class Ledger
def test_Ledger_add():
    from ..commons.zeitgeist import date_range
    from .accounts import Account
    from .journaling import JournalEntry, Posting
    
    period = date_range("2020-01-01", "2020-01-31")
    initial_balances = {
        Account("Assets:Cash"): Balance("2020-01-01", Decimal(0)),
        Account("Expenses:Advertising"): Balance("2020-01-01", Decimal(0)),
        Account("Expenses:Supplies"): Balance("2020-01-01", Decimal(0)),
    }