

# Generated at 2022-06-24 00:57:41.795093
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    pass


# Generated at 2022-06-24 00:57:46.938298
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    a1 = Account("a1")
    a2 = Account("a2")

    b1 = Balance(datetime.date(2018, 1, 1), Quantity(Decimal(1)))
    b2 = Balance(datetime.date(2018, 1, 1), Quantity(Decimal(2)))

    le1 = LedgerEntry(None, Posting(None, a1, True, Decimal(1)), b1)
    le2 = LedgerEntry(None, Posting(None, a2, False, Decimal(2)), b2)

    l1 = Ledger(a1, b1, [le1])
    l2 = Ledger(a2, b2, [le2])

    res = "[" + repr(le1) + ", " + repr(le2) + "]"
    assert (l1 + l2).__re

# Generated at 2022-06-24 00:57:56.616967
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    from .accounts import Account
    from .generic import Balance
    from .journaling import JournalEntry, Posting
    from .units import Unit
    from datetime import date, datetime, timedelta
    from decimal import Decimal
    from unittest import TestCase, main

    class _T(Unit):
        pass

    #class _T1(Unit):
    #    pass


# Generated at 2022-06-24 00:58:06.329479
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from typer import run
    from . import sample_algebra_impls

    app = read_initial_balances = sample_algebra_impls.read_initial_balances
    result = run(app, ["10000", "20000", "30000", "40000", "50000", "60000", "70000", "80000", "90000", "100000"])

# Generated at 2022-06-24 00:58:12.471686
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .test_journaling import TestJournalEntry
    class TestAccount(Account):
        def __init__(self, name: str) -> None:
            super().__init__(name, "")
    
    account = TestAccount("Test Account")
    posting = TestJournalEntry(
        "1",
        datetime.date(2020, 2, 1),
        account,
        100.0
    )
    ledger = Ledger(account, Balance(datetime.date(2020, 2, 1), 0.0))
    assert ledger.add(posting).amount == 100.0

# Generated at 2022-06-24 00:58:22.306978
# Unit test for function build_general_ledger
def test_build_general_ledger():
    import pytest
    from decimal import Decimal
    from ledger.journaling import JournalEntry, Posting
    from ledger.accounts import Account
    from ledger.generic import Balance
    
    # define input data
    period = DateRange(None, None)

# Generated at 2022-06-24 00:58:32.699093
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    account=Account('1101','Банкови сметки','Банкови сметки','Банкови сметки','Банкови сметки')
    posting = Posting(account,Decimal('10000.00'),'Пробен изпит','2101','Вх.каса - текущи вноски',True)
    entry = LedgerEntry(Ledger(account, Balance(datetime.date.today(), Quantity(Decimal('10000.01')))), posting, Quantity(Decimal('10000.01')))
    print(entry)


# Generated at 2022-06-24 00:58:34.714721
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    _T = type(ReadInitialBalances)
    assert hasattr(_T, '__call__'), "expected: hasattr(%s, '__call__')" % _T
    assert callable(getattr(_T, '__call__')), "expected: callable(getattr(%s, '__call__'))" % _T


# Generated at 2022-06-24 00:58:45.414524
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    a1 = Account("a")
    d1 = datetime.date(2020, 3, 20)
    d2 = datetime.date(2020, 3, 21)
    a2 = Account("b")
    a1_ledger = Ledger(a1, Balance(d2, Quantity(Decimal(0))))
    a1_ledger.add(Posting(d1, JournalEntry("d1", [Posting(d1, a1, Amount(Decimal(10)))])))
    a1_ledger.add(Posting(d2, JournalEntry("d2", [Posting(d2, a1, Amount(Decimal(-20)))])))
    a2_ledger = Ledger(a1, Balance(d2, Quantity(Decimal(0))))
    assert(a1_ledger == a2_ledger)

# Generated at 2022-06-24 00:58:48.841843
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():

    ledger1 = Ledger('123', Quantity(Decimal(10)))
    ledger2 = Ledger('123', Quantity(Decimal(10)))
    ledger3 = Ledger('234', Quantity(Decimal(10)))

    assert ledger1 == ledger2
    assert ledger1 != ledger3
    assert ledger2 != ledger3

# Generated at 2022-06-24 00:58:52.637139
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    assert GeneralLedger(DateRange(datetime.date(2020, 1, 1), datetime.date(2020, 12, 31)), 0).__repr__() == "GeneralLedger(period=DateRange(since=datetime.date(2020, 1, 1), until=datetime.date(2020, 12, 31)), ledgers={})"


# Generated at 2022-06-24 00:58:57.144535
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    @dataclass
    class Journal:
        description: str

    @dataclass
    class Posting:
        account: Account

    @dataclass
    class LedgerEntry:
        ledger: Ledger

    assert ledger_entry_instance.date == ...
    assert ledger_entry_instance.description == ...
    assert ledger_entry_instance.amount == ...
    assert ledger_entry_instance.cntraccts == ...
    assert ledger_entry_instance.is_debit == True
    assert ledger_entry_instance.is_credit == False
    assert ledger_entry_instance.debit == ...
    assert ledger_entry_instance.credit == ...


# Generated at 2022-06-24 00:58:57.683406
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    pass

# Generated at 2022-06-24 00:58:58.710259
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    assert ReadInitialBalances

# Generated at 2022-06-24 00:59:02.914596
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    # Arrange
    first_account = Account("0001", "Cash")
    second_account = Account("0002", "Receivables")
    first_posting = Posting(first_account, Quantity(Decimal("500.00")), datetime.date(2020, 1, 1))
    second_posting = Posting(second_account, Quantity(Decimal("300.00")), datetime.date(2020, 1, 1))
    first_entry = LedgerEntry(first_account, first_posting, Quantity(Decimal("750.00")))
    second_entry = LedgerEntry(second_account, second_posting, Quantity(Decimal("450.00")))
    first_ledger = Ledger(first_account, Quantity(Decimal("250.00")))

# Generated at 2022-06-24 00:59:05.673436
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    assert ReadInitialBalances


# Generated at 2022-06-24 00:59:15.396492
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    """
    unit test for method __repr__ of class LedgerEntry
    """
    acct = Account("1", "一")
    acct.group = "資產"
    posting = Posting(None, acct, 100, True)
    ledger = Ledger(acct, Balance(datetime.date(2020,1,1), 100))
    entry = LedgerEntry(ledger, posting, 200)

# Generated at 2022-06-24 00:59:26.673125
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    period = DateRange(datetime.date.today(), datetime.date.today())

    initial_balances = {
        Account.get_by_code_and_name("A1", "Cash"): Balance(
            period.since, Quantity(Decimal(100))
        ),
        Account.get_by_code_and_name("A2", "Fed Earnings"): Balance(
            period.since, Quantity(Decimal(100))
        ),
        Account.get_by_code_and_name("A3", "Owners Equity"): Balance(
            period.since, Quantity(Decimal(100))
        ),
        Account.get_by_code_and_name("A4", "Dividend"): Balance(
            period.since, Quantity(Decimal(100))
        ),
    }

    journal_entries

# Generated at 2022-06-24 00:59:36.828725
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    from . import accounts, journals
    from .models import JournalEntry

    period = DateRange(datetime.date(2014, 5, 1), datetime.date(2014, 5, 31))
    initial_balances = {
        accounts.URUGUAY_ACCT: Balance(datetime.date(2014, 1, 1), Quantity(Decimal(13.0))),
        accounts.ARGENTINA_ACCT: Balance(datetime.date(2014, 1, 1), Quantity(Decimal(14.0))),
    }

    ## Create the expected journal entries:

# Generated at 2022-06-24 00:59:37.455117
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    ...


# Generated at 2022-06-24 00:59:47.971343
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():

    from .journals import Journal
    from .accounts import AccountId

    new_id = AccountId()

    @dataclass
    class TestInitialBalance:
        account: AccountId
        balance: int

    @dataclass
    class TestJournalEntry:
        date: datetime.date
        journal_description: str
        is_debit: bool
        account: AccountId
        amount: int

    period = DateRange("2019-01-01", "2019-12-31")

    test_initial_balances = [
        TestInitialBalance(account=new_id("0001"), balance=3),
        TestInitialBalance(account=new_id("0002"), balance=5),
    ]

# Generated at 2022-06-24 00:59:58.457413
# Unit test for method add of class Ledger
def test_Ledger_add():
    account1 = Account("10/101","Account101")
    account2 = Account("10/102","Account102")
    account3 = Account("10/103","Account103")

    account1_ledger = Ledger(account1, Balance(datetime.date.today(), Quantity(Decimal(0))))
    account2_ledger = Ledger(account2, Balance(datetime.date.today(), Quantity(Decimal(0))))
    account3_ledger = Ledger(account3, Balance(datetime.date.today(), Quantity(Decimal(0))))

    journal1 = JournalEntry(datetime.date.today(), "Journal 1", Posting(account1, Amount(Decimal(100))))
    journal2 = JournalEntry(datetime.date.today(), "Journal 2", Posting(account3, Amount(Decimal(50))))
    journal3

# Generated at 2022-06-24 01:00:05.150295
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    from .journaling import Journal, Posting, DEBIT, CREDIT, JournalEntry
    from .accounts import Account, AccountType, AccountNameSpace

    journal = Journal(journal_id='j1',
                      date=datetime.date(2019, 1, 1),
                      description='first journal',
                      entries=[
                          Posting(account=Account(AccountType.ASSET, AccountNameSpace.GENERAL, 'cash', 'GL'),
                                  direction=DEBIT,
                                  amount=1200),
                          Posting(account=Account(AccountType.LIABILITY, AccountNameSpace.GENERAL, 'B1', 'GL'),
                                  direction=CREDIT,
                                  amount=1200),
                      ])
    entry = LedgerEntry(journal.entries[0])
    assert entry.posting == journal.entries[0]


#

# Generated at 2022-06-24 01:00:09.204578
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    assert Ledger(Account("L401"), Balance(None, Quantity(0))) == Ledger(Account("L401"), Balance(None, Quantity(0)))


# Generated at 2022-06-24 01:00:09.753308
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    pass

# Generated at 2022-06-24 01:00:16.548172
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    from .journaling import JournalEntry, Posting
    from .accounts import Accounts
    from .ledger import ReadInitialBalances, GeneralLedgerProgram, GeneralLedger
    from datetime import date, datetime
    from decimal import Decimal
    from ..commons.zeitgeist import DateRange

    # Provide sample journal entries.

# Generated at 2022-06-24 01:00:21.458105
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    test_GeneralLedger = GeneralLedger("period", "ledgers")
    print(test_GeneralLedger)
    assert test_GeneralLedger.__repr__() == "GeneralLedger(period='period', ledgers='ledgers')"


# Generated at 2022-06-24 01:00:29.973473
# Unit test for constructor of class Ledger
def test_Ledger():
    from .accounts import Account
    @dataclass
    class MockPosting:
        account: Account
        amount: Amount
        direction: int
        def is_debit(self):
            return True
    @dataclass
    class MockLedger:
        account: Account
    @dataclass
    class MockLedgerEntry:
        ledger: MockLedger
        posting: MockPosting
        balance: Quantity
    @dataclass
    class MockBalance:
        date: datetime.date
        value: Decimal
    MOCK_ACCOUNT = Account("Cash")
    MOCK_LEDGER = MockLedger(MOCK_ACCOUNT)

# Generated at 2022-06-24 01:00:36.206444
# Unit test for method __eq__ of class GeneralLedger

# Generated at 2022-06-24 01:00:44.937511
# Unit test for method add of class Ledger
def test_Ledger_add():
    """
    Test the add method of the Ledger class.
    """
    # Test data:
    account = Account('current_assets', 'Current assets', Account.Type.ASSET)
    initial = Balance(datetime.date(2020, 1, 1), Quantity(10000))
    journal_date = datetime.date(2020, 1, 1)
    journal_description = 'First journal entry'
    amount = 1000
    debit = amount
    credit = 0
    balance = 11000
    account2 = Account('accounts_payable', 'Accounts Payable', Account.Type.LIABILITY)
    amount2 = 1000
    balance2 = 9000

    # Create the journal entry:
    journal = JournalEntry(journal_date, journal_description)
    journal.post(account, amount)
    journal.post(account2, amount2)



# Generated at 2022-06-24 01:00:54.248129
# Unit test for method add of class Ledger

# Generated at 2022-06-24 01:00:57.902250
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    assert ReadInitialBalances


# Generated at 2022-06-24 01:01:06.206727
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from dataclasses import field
    from decimal import Decimal
    from datetime import date
    from accounting.domain.accounts import AccountType, Account, AccountGroup
    #from accounting.domain.generic import Balance, Quantity
    from accounting.domain.test.test import test_date
    from typing import Dict
    from .test.test import test_account, test_datarange, test_posting, test_journal

    ## Define the accounts:
    chequing = Account(test_account(), None, 'Chequing', AccountType.assets, AccountGroup.current_assets)
    prepaid_expenses = Account(test_account(), None, 'Prepaid Expenses', AccountType.assets, AccountGroup.current_assets)

# Generated at 2022-06-24 01:01:17.757749
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    from .journaling import JournalEntry, Posting
    from .accounts import Account

    from .generic import Balance

    from .testing import make_algebra, make_test_journal_entry
    
    # Create the algebra (don't use testing.make_algebra because it does not provide initial balances):

# Generated at 2022-06-24 01:01:22.415601
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    l1 = Ledger(Account("10100", "", ""), Balance(0,0))
    l2 = Ledger(Account("10100", "", ""), Balance(0,0))
    assert l1.__eq__(l2) == True


# Generated at 2022-06-24 01:01:23.343322
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    pass


# Generated at 2022-06-24 01:01:24.380720
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    pass


# Generated at 2022-06-24 01:01:29.912071
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    """
    Unit test for method __eq__ of class Ledger
    """

    from .accounts import Account

    ledger1 = Ledger(Account("0"), Balance(datetime.date(2016, 1, 1), Quantity(1)))
    ledger2 = Ledger(Account("1"), Balance(datetime.date(2016, 1, 1), Quantity(1)))
    assert ledger1 != ledger2
 


# Generated at 2022-06-24 01:01:37.757092
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():

    from datetime import date

    from typing import IO

    class GLProgram(GeneralLedgerProgram[_T]):
        def __call__(self, period: DateRange):
            general_ledger = compile_general_ledger_program(ReadInitialBalances(), ReadJournalEntries())
            return general_ledger(period)
        pass

    @dataclass
    class Balance:
        account: Account
        balance: Decimal
        pass

    class ReadInitialBalances():
        def __call__(self, period: DateRange) -> Dict[Account, Balance]:
            initial_balances = {}
            initial_balance = Balance(Account(abbreviation="CASH", fullname="Cash"), balance=Decimal(726.50))
            initial_balances[initial_balance.account] = initial_balance
            return initial_balances


# Generated at 2022-06-24 01:01:43.697620
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    import dataclasses
    import pytest

    from ..commons.numbers import Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import Journal, JournalEntry, Posting, Transaction

    #
    # Mock implementation of the algebra:
    #

    class InitialBalances:
        def __init__(self, balances: dict):
            self._balances = balances

        def __call__(self, _period: DateRange) -> dict:
            return self._balances

    class ReadJournalEntries:
        def __init__(self, journal_entries: Iterable[JournalEntry]):
            self._journal_entries = journal_entries


# Generated at 2022-06-24 01:01:53.674399
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from decimal import Decimal
    from datetime import date
    from ..commons.numbers import Quantity, Amount
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting

    # Define accounts to be used in tests:
    cash = Account("11.01.00.01")
    bank = Account("11.01.01.01")
    receivables = Account("11.02.01.01")
    sales = Account("60.01.01.01")
    vat = Account("44.01.01.06")
    purchases = Account("52.01.01.01")
    cost_of_sales = Account("50.01.01.01")

    # Define journal entries to be used in tests:

# Generated at 2022-06-24 01:01:59.590911
# Unit test for constructor of class Ledger
def test_Ledger():
    # Create Account
    account1 = Account("112233")

    # Create Balance
    balance = Balance("2019-11-01", Decimal("230.00"))

    # Create Ledger
    ledger = Ledger(account1, balance)

    # Check attributes of Ledger
    assert ledger.account == account1
    assert ledger.initial == balance


# Generated at 2022-06-24 01:02:08.744182
# Unit test for method add of class Ledger
def test_Ledger_add():
    """
    unit test for add the entry in the ledger
    """
    # code
    @dataclass
    class MyModel:
        """
        Define a new model class.
        """

        pass

    ## Create accounts
    test_account = Account("100100", "Cash", True)
    test_account_2 = Account("100101", "Treasury", True)

    ## Create postings
    test_posting = Posting.debit(test_account, Amount(10), datetime.date(2020, 10, 1))
    test_posting_2 = Posting.debit(test_account, Amount(10), datetime.date(2020, 10, 2))
    test_posting_3 = Posting.debit(test_account, Amount(10), datetime.date(2020, 10, 3))

    ## Create

# Generated at 2022-06-24 01:02:20.368980
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():

    from .accounts import Account
    from .commons import Currency
    from .commons.numbers import Amount
    from .journaling import Journal, JournalEntry, Posting
    from .ledgers import GeneralLedger, build_general_ledger
    from .types import AccountGroup


    _account_current_assets = Account(1, AccountGroup.ASSETS, "Cash and Cash Equivalents", Currency.USD)
    _account_liabilities = Account(2, AccountGroup.LIABILITIES, "Current Liabilities", Currency.USD)
    _account_equity = Account(3, AccountGroup.EQUITY, "Equity", Currency.USD)
    _account_inventories = Account(4, AccountGroup.ASSETS, "Inventories", Currency.USD)

# Generated at 2022-06-24 01:02:30.664642
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    from .accounts import AccountNumber
    from .commons import Amount, Quantity, DateRange
    from .journaling import JournalEntry, Posting, JournalEntryType
    from . import general as mod

    # Data for method test
    period = DateRange(datetime.date(2020, 2, 1), datetime.date(2020, 2, 28))
    initial_balances = {}
    journal_entries = []

    # Create an instance of the class GeneralLedger
    ledgers = mod.GeneralLedger(period, initial_balances)

    # Check the result of calling method __repr__ of class GeneralLedger
    assert ledgers.__repr__() == "GeneralLedger(period=DateRange(since=datetime.date(2020, 2, 1), until=datetime.date(2020, 2, 28)), ledgers={})"



# Generated at 2022-06-24 01:02:42.053719
# Unit test for method add of class Ledger
def test_Ledger_add():
    from .accounts import Account, AccountCategory
    from .journaling import Journal, JournalEntry
    from .commons.zeitgeist import TimeSpan, DateRange, Date
    from .commons.numbers import Currency
    from .solids import Solid

    # create a currency
    currency = Currency(name="Euro", ticker="EUR")

    # create a solid
    solid = Solid(name="Grand Canyon", amount=Quantity(Decimal(42000)), currency=currency)

    # create an account
    account = Account(name="Sales", category=AccountCategory.REVENUE)

    # create a journal
    journal = Journal(description="Selling Grand Canyon", date=Date(2020, 1, 1), postings=[
        Posting(account=account, amount=solid.amount, direction=1, solid=solid)
    ])

    # create a

# Generated at 2022-06-24 01:02:48.793092
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    a = GeneralLedger(DateRange(datetime.datetime(2020, 1, 1), datetime.datetime(2020, 1, 2)), {})
    b = GeneralLedger(DateRange(datetime.datetime(2020, 1, 1), datetime.datetime(2020, 1, 2)), {})
    assert a == b


# Generated at 2022-06-24 01:02:58.033261
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    @dataclass
    class LedgerEntry(Generic[_T]):
        """
        Provides a ledger entry model.
        """

        #: Ledger the entry belongs to.
        ledger: "Ledger[_T]"

        #: Posting of the ledger entry.
        posting: Posting[_T]

        #: Balance of the ledger entry.
        balance: Quantity

        @property
        def date(self) -> datetime.date:
            """
            Date of the ledger entry.
            """
            return self.posting.date

        @property
        def description(self) -> str:
            """
            Description of the ledger entry.
            """
            return self.posting.journal.description

        @property
        def amount(self) -> Amount:
            """
            Amount of the ledger entry.
            """

# Generated at 2022-06-24 01:03:03.420576
# Unit test for method __call__ of class GeneralLedgerProgram
def test_GeneralLedgerProgram___call__():
    import dataclasses
    import unittest

    from _pytest.python import Metafunc

    from .accounts import Account, Assets, Expenses, Liabilities, Revenue

    @dataclasses.dataclass
    class _AccountLedgerAlgebra:
        def read_initial_balances(self, period: DateRange) -> InitialBalances:
            return {
                Liabilities.Equity.OwnerCapital: Balance(
                    period.since, Quantity(Decimal(1000))
                ),
                Assets.Current.Cash: Balance(period.since, Quantity(Decimal(1200))),
            }


# Generated at 2022-06-24 01:03:14.373209
# Unit test for function build_general_ledger
def test_build_general_ledger():
    import uuid

    from datetime import date

    from pyappex.commons.adt import Currency

    from pyappex.ledger import Journal, PostingDirection

    from pyappex.general_ledgers import build_general_ledger

    # Create a couple of accounts:
    a = Account(uuid.uuid4(), "Assets")
    b = Account(uuid.uuid4(), "Liabilities", children=[a])

    # Create a couple of journals:
    j1 = Journal(uuid.uuid4(), date(2019, 1, 1), "Journal #1", [
        Posting(a, PostingDirection.Debit, Decimal(10)),
        Posting(b, PostingDirection.Credit, Decimal(10)),
    ])

# Generated at 2022-06-24 01:03:25.208850
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():

    from .journaling import (
        AlgebraException,
        JournalEntry,
        ReadJournalEntries,
        compile_read_journal_entries,
    )

    @dataclass
    class LedgerEntry(Generic[_T]):
        """
        Provides a ledger entry model.
        """

        #: Ledger the entry belongs to.
        account: str

        #: Posting of the ledger entry.
        posting: Posting[_T]

        #: Balance of the ledger entry.
        balance: Quantity

        @property
        def date(self) -> datetime.date:
            """
            Date of the ledger entry.
            """
            return self.posting.date

        @property
        def description(self) -> str:
            """
            Description of the ledger entry.
            """
            return self.posting.journal

# Generated at 2022-06-24 01:03:36.195804
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    @dataclass
    class Journal:
        description: str

    @dataclass
    class Posting(Generic[_T]):
        amount: Amount
        journal: Journal

    # test data
    ledger = Ledger(Account.assets, Balance(datetime.date, Quantity(Decimal(0))))
    posting = Posting[Journal](Amount(1), Journal("description"))
    entry = LedgerEntry(ledger, posting, Quantity(Decimal(1)))
    other = LedgerEntry(ledger, posting, Quantity(Decimal(1)))

    # common tests
    assert entry == other, "Expected to be equal"
    assert not entry != other, "Expected to be equal"
    assert hash(entry) == hash(other), "Expected to be equal"

    # test cases

# Generated at 2022-06-24 01:03:38.403356
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    ReadInitialBalances

# Generated at 2022-06-24 01:03:46.091406
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    import unittest

    from .accounts import Account, AccountType
    from .transactions import Transaction

    # Create different financial transactions.
    sample_transaction: Transaction = Transaction([], [])
    debit_transaction: Transaction = Transaction([], [])
    credit_transaction: Transaction = Transaction([], [])
    sales_transaction: Transaction = Transaction([], [])

    # Create different accounts.
    sample_account: Account = Account(AccountType.ASSET, "Sample Account")
    debit_account: Account = Account(AccountType.LIABILITY, "Debit Account")
    credit_account: Account = Account(AccountType.EXPENSE, "Credit Account")

    # Create different ledgers.

# Generated at 2022-06-24 01:03:51.723317
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    from .journaling import JournalEntry
    from .books import ReadJournalEntries, ReadInitialBalances, BuildGeneralLedger, GeneralLedger
    from .accounts import Account
    from .commons.zeitgeist import DateRange
    from .commons.numbers import Amount, Quantity
    from .generic import Balance
    from .journaling import Journal, Posting, Direction, EntryType
    from datetime import date
    from decimal import Decimal
    from collections import defaultdict

    @dataclass
    class JournalEntryImpl(JournalEntry):
        pass

    # Implementing the algebra
    class JournalEntriesImpl(ReadJournalEntries):
        def __init__(self, journal : Journal):
            self.journal = journal

        def __call__(self, dr : DateRange):
            return self.journal


# Generated at 2022-06-24 01:04:03.376142
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .journaling import Posting
    from .accounts import Account, AccountType
    from .commons import Direction
    from .generic import Quantity
    from . financials import DateRange

    period = DateRange(datetime.date.today(), datetime.date.today())

    postings = [
        Posting(direction=Direction.Debit, amount=Quantity(100), account=Account(name='cash', type=AccountType.Asset)),
        Posting(direction=Direction.Debit, amount=Quantity(200), account=Account(name='cash', type=AccountType.Asset)),
        Posting(direction=Direction.Credit, amount=Quantity(300), account=Account(name='cash', type=AccountType.Asset)),
    ]

    initial_balances = {Account(name='cash', type=AccountType.Asset): Quantity(100)}



# Generated at 2022-06-24 01:04:04.071102
# Unit test for constructor of class Ledger
def test_Ledger():
    pass

# Generated at 2022-06-24 01:04:07.854919
# Unit test for constructor of class Ledger
def test_Ledger():
    ledger = Ledger(account=Account("1234"), initial=Balance(date=datetime.date(2020,5,5), value=0))
    assert ledger.account == Account("1234") and ledger.initial == Balance(date=datetime.date(2020,5,5), value=0) 


# Generated at 2022-06-24 01:04:18.433855
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    from datetime import date
    from .accounts import Account
    from .journaling import JournalEntry, Posting, ReadJournalEntries

    @dataclass
    class ReadJournalEntriesImpl(ReadJournalEntries):

        def __call__(self, period: DateRange) -> Iterable[JournalEntry]:
            from .journaling import Posting
            from .accounts import Account

            def _post(d: datetime.date, a: Account, amt: Amount, desc: str = "") -> Iterable[Posting]:
                return [
                    Posting(JournalEntry(d, desc), a, amt, 1),
                    Posting(JournalEntry(d, desc), a, amt, -1),
                ]


# Generated at 2022-06-24 01:04:19.157517
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    assert LedgerEntry


# Generated at 2022-06-24 01:04:25.521460
# Unit test for constructor of class LedgerEntry
def test_LedgerEntry():
    # Arrange
    amount = 2000
    balance = 4000
    account = Account("ABC", "account name")
    date = datetime.date(2009,11,30)
    description = "test description"

    # Act
    pe = Posting(account, amount, 1, date)
    je = JournalEntry(date, description, [pe])
    le = LedgerEntry(account, pe, balance)

    # Assert
    assert le.amount == amount
    assert le.cntraccts == [account]
    assert le.balance == balance
    assert le.date == date
    assert le.description == description
    assert le.is_debit == True
    assert le.is_credit == False


# Generated at 2022-06-24 01:04:35.987194
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    from .accounts import Account
    from .journaling import Transaction
    from .ledgers import AccountLedger, AccountLedgerProgram

    ## Create an account:
    asset_account = Account("Assets", "Cash", "CAD")
    expr_account = Account("Expenses", "Remuneration")

    ## Create a journal entry:
    journal_entry = Transaction("Salary payment", datetime.date(2018, 12, 1))
    journal_entry.add(asset_account, Decimal("1000"), "CAD")
    journal_entry.add(expr_account, Decimal("1000"), "CAD")

    ## Compile the program:
    compile_account_ledger_program = AccountLedgerProgram()

# Generated at 2022-06-24 01:04:45.564021
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    """
    Method __eq__ of class LedgerEntry needs to work as expected.
    """
    from hamcrest import assert_that, equal_to
    from .journaling import JournalEntry, Posting, RawJournalEntry
    from .accounts import Account

    # Data
    A1 = Account("A1", 10)
    A2 = Account("A2", 20)
    ledgers = {A1: Ledger(A1, Balance(datetime.date(2020, 1, 1), Quantity(0))),
               A2: Ledger(A2, Balance(datetime.date(2020, 1, 1), Quantity(0)))}
    A1_1 = Account("A1.1", 11)

# Generated at 2022-06-24 01:04:52.998133
# Unit test for constructor of class Ledger
def test_Ledger():
    @dataclass
    class T:
        date: datetime.date
        amount: Decimal

    l = Ledger('Test', Balance(datetime.date(2019, 9, 1), Decimal(0)))
    assert l.account == 'Test'
    assert l.initial.date == datetime.date(2019, 9, 1)
    assert l.initial.value == Decimal(0)
    assert l.entries == []

    l = Ledger('Test', Balance(datetime.date(2019, 9, 1), Decimal(0)))
    p = Posting(datetime.date(2019, 9, 3), T(datetime.date(2019, 9, 3), Decimal(-10)), 'Test', Decimal(-10))
    assert l.add(p).date == p.date
    assert l.add(p).amount

# Generated at 2022-06-24 01:05:05.268607
# Unit test for function build_general_ledger
def test_build_general_ledger():
    from .tests.data import test_period, test_journal

    ## Given a period and journal:
    period = test_period
    journal = test_journal

    ## When I build a general ledger,
    gl = build_general_ledger(period, journal, {})

    ## Then I expect a general ledger with the right period and ledger entries:
    assert gl.period == period
    assert gl.ledgers["Assets"].entries[-1].balance == Decimal("17000")
    assert gl.ledgers["Stock"].entries[-1].balance == Decimal("4500")
    assert gl.ledgers["Cash"].entries[-1].balance == Decimal("12500")
    assert gl.ledgers["Sales"].entries[-1].balance == Decimal("12500")

# Generated at 2022-06-24 01:05:12.264240
# Unit test for constructor of class Ledger
def test_Ledger():
    """
    Testing constructor of class Ledger
    """
    a = Account(code="1234", description="Description")
    period = DateRange(since="2018-01-01", until="2018-03-01")
    b1 = Balance(period.since, Quantity(Decimal(0)))
    b2 = Balance(period.since, Quantity(Decimal(1)))

    l1 = Ledger(a, b1)
    assert a == l1.account
    assert b1 == l1.initial
    assert [] == l1.entries
    assert Quanti

# Generated at 2022-06-24 01:05:18.020095
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    """
    Test the constructor of class GeneralLedger.
    """
    ## Create a GeneralLedger instance
    GeneralLedger = GeneralLedger("period", "ledgers")

    assert GeneralLedger.period == "period"
    assert GeneralLedger.ledgers == "ledgers"

# Generated at 2022-06-24 01:05:19.291324
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    assert ReadInitialBalances

# Generated at 2022-06-24 01:05:28.907941
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    # Read initial balances function
    read_initial_balances = lambda period: {
        Account(code="1002", name="Bank", type="asset"): Balance(datetime.date(2019, 12, 31), Decimal(1000.00)),
        Account(code="2001", name="Accounts Receivable", type="asset"): Balance(datetime.date(2019, 12, 31), Decimal(0.00))
    }

    # Read journal entries function

# Generated at 2022-06-24 01:05:34.810159
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    def read_initial_balances(period: DateRange) -> InitialBalances: pass
    def read_journal_entries(period: DateRange) -> JournalEntry: pass

    GeneralLedgerProgram(read_initial_balances, read_journal_entries)


# Generated at 2022-06-24 01:05:38.770399
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    """
    Test method __eq__ of class LedgerEntry
    """
    assert LedgerEntry == LedgerEntry


# Generated at 2022-06-24 01:05:45.997319
# Unit test for constructor of class Ledger
def test_Ledger():
    account = Account()
    initial = Balance(datetime.datetime(2020,9,9), Quantity(Decimal(0)))
    entries = [LedgerEntry(Ledger(account, initial), Posting(datetime.datetime(2020,9,9), 1, Account(), Account()), Quantity(Decimal(1)))]
    ledger = Ledger(account, initial, entries)
    assert ledger is not None


# Generated at 2022-06-24 01:05:56.242633
# Unit test for constructor of class GeneralLedgerProgram
def test_GeneralLedgerProgram():
    import pytest
    from ..commons.zeitgeist import DateRange
    from ..tests.journaling import test_program_journaling

    # Define the input data
    period: DateRange = DateRange(datetime.date(2018, 10, 1), datetime.date(2018, 11, 30))
    journal_entries: List[JournalEntry] = test_program_journaling()
    journal_entries = [journal_entries[0], journal_entries[1], journal_entries[2], journal_entries[3]]

# Generated at 2022-06-24 01:06:06.592581
# Unit test for method __eq__ of class LedgerEntry
def test_LedgerEntry___eq__():
    ## Prepare required test data.
    account = Account("1")
    journal = JournalEntry(datetime.date(2020, 4, 1), account, "")
    posting = Posting(journal, account)
    balance = Balance(datetime.date(2020, 4, 1), Quantity(Decimal(1)))
    ledger = Ledger(account, balance)

    ## Prepare the ledger entry.
    ledger_entry = LedgerEntry(ledger, posting, balance.value)

    ## Assert that ledger entry is equal to itself.
    assert ledger_entry.__eq__(ledger_entry)

    ## Assert that ledger entry is equal to another value.
    assert not ledger_entry.__eq__("Another Value")

    ## Assert that ledger entry is not equal to another ledger entry.

# Generated at 2022-06-24 01:06:07.177699
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances(): pass

# Generated at 2022-06-24 01:06:11.607294
# Unit test for constructor of class GeneralLedger
def test_GeneralLedger():
    x: GeneralLedger[str] = GeneralLedger(
        datetime.date(2019, 1, 1), datetime.date(2019, 12, 31), {"a": 1, "b": 2}
    )
    assert isinstance(x, GeneralLedger)

# Generated at 2022-06-24 01:06:20.538442
# Unit test for method __eq__ of class GeneralLedger
def test_GeneralLedger___eq__():
    """Unit test for method __eq__ of class GeneralLedger"""
    from datetime import date
    from decimal import Decimal

    def __eq__(
        period: DateRange,
        ledgers: Dict[Account, Ledger],
        period_: DateRange,
        ledgers_: Dict[Account, Ledger],
        result: bool
    ):
        assert (
            GeneralLedger(period, ledgers) ==
            GeneralLedger(period_, ledgers_)
        ) == result

    __eq__(
        DateRange(date(2020, 1, 1), date(2021, 1, 1)),
        {},
        DateRange(date(2020, 1, 1), date(2021, 1, 1)),
        {},
        True
    )


# Generated at 2022-06-24 01:06:30.307296
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    test_repr = repr(GeneralLedger(DateRange(since=datetime.date(2019, 1, 1), until=datetime.date(2019, 1, 31)),
                                   {Account('0001'): Ledger(Account('0001'), Balance(datetime.date(2019, 1, 1),
                                                                                 Quantity(Decimal(0))))}))
    assert 'period=DateRange(since=datetime.date(2019, 1, 1), until=datetime.date(2019, 1, 31))' in test_repr
    assert 'account=Account(identifier=' + '0001' in test_repr
    assert 'initial=Balance(as_of=datetime.date(2019, 1, 1), value=Quantity(value=Decimal(' in test_repr

# Generated at 2022-06-24 01:06:39.500149
# Unit test for method __repr__ of class LedgerEntry
def test_LedgerEntry___repr__():
    # test_case_id = "9c9f8a80-c1ee-4419-97b1-a38f8b0bbd3f"
    # ledger = Ledger()
    # posting = Posting()
    # balance = Quantity()
    # test_data = [(ledger, posting, balance)]
    # expected = 'LedgerEntry(ledger=' + repr(ledger) + ', posting=' + repr(posting) + ', balance=' + repr(balance) + ')'

    # for ledger, posting, balance in test_data:
    #     actual = repr(LedgerEntry(ledger, posting, balance))

    #     assert actual == expected
    pass

# Generated at 2022-06-24 01:06:43.529087
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Compile the program to build general ledger
    general_ledger_program = compile_general_ledger_program(
        read_initial_balances=read_initial_balances,
        read_journal_entries=read_journal_entries,
    )


# Generated at 2022-06-24 01:06:50.408281
# Unit test for method add of class Ledger
def test_Ledger_add():
    # Create a new Account, ledger and posting with the same Account
    account = Account('1000')
    ledger = Ledger(account, Balance(datetime.date(2000,1,1), Quantity(0)))
    posting = Posting(account, Quantity(1), datetime.date(2000,1,1), datetime.date(2000,1,2), 'Test')

    # Add the posting to the ledger
    ledger.add(posting)

    # Check if the balance of the last entry equals the initial balance + posting.amount * posting.direction
    assert ledger.entries[-1].balance == ledger.initial.value + posting.amount * posting.direction.value

# Generated at 2022-06-24 01:07:00.386632
# Unit test for function compile_general_ledger_program
def test_compile_general_ledger_program():
    import datetime
    from dataclasses import dataclass
    from typing import List, Optional
    from ..commons.numbers import Amount, Quantity
    from ..commons.zeitgeist import DateRange
    from .accounts import Account
    from .journaling import JournalEntry, Posting, PostingDirection, ReadJournalEntries

    #: Defines a posting type.
    @dataclass
    class _Posting(Posting[None]):
        account: Account

        def to_posting(self) -> Posting[None]:
            return Posting(account=self.account, amount=self.amount, direction=self.direction, journal=self.journal)

    #: Defines a journal entry type.
    @dataclass
    class _JournalEntry(JournalEntry[None]):
        description: str

# Generated at 2022-06-24 01:07:05.305012
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    from .read import read_initial_balances
    class Test:
        def __call__(self, period: DateRange):
            # Expected call arguments
            assert period == DateRange("2019-08-01", "2019-08-31")

            return {a: b for a, b in initial_balances.items() if period.since <= b.date <= period.until}
    read_initial_balances(Test())


# Generated at 2022-06-24 01:07:08.144755
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    pass


# Generated at 2022-06-24 01:07:15.900512
# Unit test for method add of class Ledger
def test_Ledger_add():
    # arrange
    import datetime
    from .accounts import Account
    from .journaling import JournalEntry, Posting

    # act
    account1 = Account("111", "111", "111")
    account2 = Account("222", "222", "222")
    account3 = Account("333", "333", "333")
    account4 = Account("444", "444", "444")

    Ledger1 = Ledger(account1, Balance(datetime.date(2019, 1, 1), Quantity(Decimal(10))))
    posting1 = Posting(datetime.date(2019, 1, 10), JournalEntry(datetime.date(2019, 1, 10), "111", [], None, None),
                       Quantity(Decimal(1)), account1, "debit")

# Generated at 2022-06-24 01:07:19.102099
# Unit test for method __repr__ of class Ledger
def test_Ledger___repr__():
    l1 = Ledger(Account("A"), Balance(datetime.date.today(), Quantity(Decimal(100.0))))
    l2 = Ledger(Account("A"), Balance(datetime.date.today(), Quantity(Decimal(-100.0))))
    l3 = Ledger(Account("B"), Balance(datetime.date.today(), Quantity(Decimal(100.0))))
    print(l1)
    print(l2)
    print(l3)

# Generated at 2022-06-24 01:07:24.011576
# Unit test for method __call__ of class ReadInitialBalances
def test_ReadInitialBalances___call__():
    @dataclass
    class _ReadInitialBalances(Protocol):
        def __call__(self, period: DateRange) -> InitialBalances:
            pass

    assert issubclass(ReadInitialBalances, object)
    assert issubclass(ReadInitialBalances, _ReadInitialBalances)


# Generated at 2022-06-24 01:07:33.172350
# Unit test for method __repr__ of class GeneralLedger

# Generated at 2022-06-24 01:07:34.075020
# Unit test for constructor of class ReadInitialBalances
def test_ReadInitialBalances():
    pass


# Generated at 2022-06-24 01:07:39.513589
# Unit test for method __repr__ of class GeneralLedger
def test_GeneralLedger___repr__():
    """
    Unit test for method __repr__ of class GeneralLedger
    """
    assert str(GeneralLedger(DateRange(datetime.date(2020,1,1), datetime.date(2020,6,30)), {})) == "GeneralLedger(period=DateRange(since=datetime.date(2020, 1, 1), until=datetime.date(2020, 6, 30)), ledgers={})"

# Generated at 2022-06-24 01:07:41.335094
# Unit test for method __eq__ of class Ledger
def test_Ledger___eq__():
    assert (Ledger(2, 3) == Ledger(2, 4)) is False
